package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.LastPage
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FirstPage
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.chess.BoardTheme
import com.example.chess.ChessBoardState
import com.example.chess.ChessPiece
import com.example.chess.EngineChoice
import com.example.chess.EngineEvaluation
import com.example.chess.PieceColor
import com.example.chess.PieceType
import com.example.chess.Square
import com.example.pdf.SampleChessPdfGenerator
import com.example.ui.theme.DividerHairline
import com.example.ui.theme.EnginePlusBlue
import com.example.ui.theme.EngineSwitchOrange
import com.example.ui.theme.EngineSwitchTrackOrange
import com.example.ui.theme.SheetBottomBarBg
import com.example.ui.theme.SheetHandleBarBg
import com.example.ui.theme.SheetHandlePill
import com.example.ui.theme.SheetIconGray
import com.example.ui.theme.SheetSurfaceWhite
import com.example.ui.theme.StudyCapPurple

@Composable
fun DockedAnalysisSheet(
    boardState: ChessBoardState,
    boardTheme: BoardTheme,
    isEngineEnabled: Boolean,
    engineChoice: EngineChoice,
    engineDepth: Int,
    engineEval: EngineEvaluation?,
    isCollapsed: Boolean,
    onDragDeltaPx: (Float, Boolean) -> Unit,
    onToggleKingCollapse: () -> Unit,
    onOpenPmsStudyModal: () -> Unit,
    onOpenBoardMenuSheet: () -> Unit,
    onMove: (Square, Square, PieceType?) -> Unit,
    onPlayPvFirstMove: (String) -> Unit,
    onSetEngineEnabled: (Boolean) -> Unit,
    onSelectEngine: (EngineChoice) -> Unit,
    onIncrementDepth: () -> Unit,
    onUpdateMoveComment: (String) -> Unit,
    onGoStart: () -> Unit,
    onGoPrev: () -> Unit,
    onGoNext: () -> Unit,
    onGoEnd: () -> Unit,
    onFlipBoard: () -> Unit,
    isLandscape: Boolean = false,
    modifier: Modifier = Modifier
) {
    var engineDropdownOpen by remember { mutableStateOf(false) }
    var showInlineCommentEditor by remember { mutableStateOf(false) }

    Surface(
        color = SheetSurfaceWhite,
        shadowElevation = 10.dp,
        shape = if (isLandscape) {
            RoundedCornerShape(topStart = 18.dp, bottomStart = 18.dp)
        } else {
            RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp)
        },
        modifier = modifier.testTag("docked_analysis_sheet")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Draggable Top Handle Bar + King Toggle (Left) + Purple Graduation Cap (Right)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SheetHandleBarBg)
                    .pointerInput(isLandscape) {
                        detectDragGestures(
                            onDrag = { change, dragAmount ->
                                change.consume()
                                val delta = if (isLandscape) dragAmount.x else dragAmount.y
                                onDragDeltaPx(delta, false)
                            },
                            onDragEnd = {
                                onDragDeltaPx(0f, true)
                            }
                        )
                    }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("docked_sheet_drag_handle")
            ) {
                // Center drag pill
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .width(34.dp)
                        .height(3.5.dp)
                        .clip(CircleShape)
                        .background(SheetHandlePill)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp)
                ) {
                    // Left: White King Pill Toggle (matches screenshot)
                    Box(
                        contentAlignment = Alignment.CenterStart,
                        modifier = Modifier
                            .width(54.dp)
                            .height(40.dp)
                            .clickable { onToggleKingCollapse() }
                            .testTag("king_board_toggle")
                    ) {
                        Box(
                            modifier = Modifier
                                .width(46.dp)
                                .height(16.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFD4D4D8))
                                .align(Alignment.CenterStart)
                        )
                        Canvas(
                            modifier = Modifier
                                .size(34.dp)
                                .align(if (isCollapsed) Alignment.CenterEnd else Alignment.CenterStart)
                        ) {
                            drawIntoCanvas { c ->
                                SampleChessPdfGenerator.drawStauntonPieceOnCanvas(
                                    canvas = c.nativeCanvas,
                                    piece = ChessPiece(PieceColor.WHITE, PieceType.KING),
                                    left = 0f,
                                    top = 0f,
                                    cellSize = size.width
                                )
                            }
                        }
                    }

                    if (!boardState.loadedTitle.isNullOrBlank()) {
                        Text(
                            text = boardState.loadedTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }

                    // Right: Purple Graduation Cap Icon (PMS Study Positions)
                    IconButton(
                        onClick = onOpenPmsStudyModal,
                        modifier = Modifier.size(48.dp).testTag("pms_graduation_cap_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = stringResource(R.string.cd_pms_study),
                            tint = StudyCapPurple,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            if (!isCollapsed) {
                // 2. Main Side-by-Side Board + Engine Analysis Area (Exact Screenshot Layout)
                Row(
                    verticalAlignment = Alignment.Top,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    // Left: 8x8 Interactive Chessboard
                    Box(
                        contentAlignment = Alignment.TopStart,
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(0.46f)
                    ) {
                        ChessboardComposable(
                            boardState = boardState,
                            theme = boardTheme,
                            engineArrows = if (isEngineEnabled) engineEval?.bestMoveArrows.orEmpty() else emptyList(),
                            onMove = onMove,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Right: Engine Score, Selector, Depth, Orange Switch, PV Lines & Move Comments
                    Column(
                        modifier = Modifier
                            .weight(0.54f)
                            .fillMaxHeight()
                            .background(SheetSurfaceWhite)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Top Engine Header Row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            // Bold Evaluation Score (+0.4)
                            Text(
                                text = if (isEngineEnabled) (engineEval?.scoreText ?: "+0.4") else "—",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF18181B),
                                modifier = Modifier.padding(end = 6.dp).testTag("engine_eval_score")
                            )

                            // Engine Selector + Depth Stack
                            Column(modifier = Modifier.weight(1f)) {
                                Box {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clickable { engineDropdownOpen = true }
                                            .padding(vertical = 2.dp)
                                            .testTag("engine_selector_dropdown")
                                    ) {
                                        Text(
                                            text = engineChoice.shortLabel,
                                            fontSize = 13.sp,
                                            color = Color(0xFF27272A),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Icon(
                                            Icons.Default.ArrowDropDown,
                                            contentDescription = "Select engine",
                                            tint = Color(0xFF3F3F46),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = engineDropdownOpen,
                                        onDismissRequest = { engineDropdownOpen = false }
                                    ) {
                                        for (choice in EngineChoice.entries) {
                                            DropdownMenuItem(
                                                text = { Text(choice.displayLabel) },
                                                onClick = {
                                                    engineDropdownOpen = false
                                                    onSelectEngine(choice)
                                                }
                                            )
                                        }
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable { onIncrementDepth() }
                                ) {
                                    val shownDepth = if (engineChoice == EngineChoice.LICHESS_CLOUD && (engineEval?.depth ?: 0) > 5) {
                                        engineEval?.depth ?: 23
                                    } else {
                                        engineDepth * 6 + 5 // Displays search depth indicator cleanly
                                    }
                                    Text(
                                        text = "Depth $shownDepth",
                                        fontSize = 12.sp,
                                        color = Color(0xFF3F3F46)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = "Increase engine depth",
                                        tint = EnginePlusBlue,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }

                            // Orange Engine Toggle Switch (matches screenshot)
                            Switch(
                                checked = isEngineEnabled,
                                onCheckedChange = onSetEngineEnabled,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = EngineSwitchOrange,
                                    checkedTrackColor = EngineSwitchTrackOrange,
                                    uncheckedThumbColor = Color(0xFFA1A1AA),
                                    uncheckedTrackColor = Color(0xFFE4E4E7)
                                ),
                                modifier = Modifier.testTag("engine_toggle_switch")
                            )
                        }

                        HorizontalDivider(color = DividerHairline)

                        // Principal Variation Lines (Matches "+0.4  1.e4 e6 2.Nc3 d5 ...")
                        if (isEngineEnabled) {
                            val lines = engineEval?.pvLines.orEmpty()
                            for (pv in lines) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            pv.firstMoveUci?.let { onPlayPvFirstMove(it) }
                                        }
                                        .padding(horizontal = 8.dp, vertical = 7.dp)
                                ) {
                                    Text(
                                        text = pv.scoreText,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF18181B),
                                        modifier = Modifier.padding(end = 8.dp)
                                    )
                                    Text(
                                        text = pv.sanSequence,
                                        fontSize = 13.sp,
                                        color = Color(0xFF27272A),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                HorizontalDivider(color = DividerHairline)
                            }
                        }

                        // Active Move & Quick Comment Row (for annotating book lines & imported games)
                        val curNode = boardState.currentNode
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showInlineCommentEditor = !showInlineCommentEditor }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("inline_comment_toggle")
                        ) {
                            Icon(
                                Icons.Default.EditNote,
                                contentDescription = "Move comment",
                                tint = StudyCapPurple,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            val label = if (curNode.comment.isNotBlank()) {
                                "${curNode.san}${curNode.nags.joinToString("")}: ${curNode.comment}"
                            } else if (curNode.san.isNotBlank()) {
                                "${curNode.san}${curNode.nags.joinToString("")} — Tap to add comment"
                            } else {
                                "Tap to add position comment"
                            }
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                color = if (curNode.comment.isNotBlank()) Color(0xFF1E1B4B) else SheetIconGray,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (showInlineCommentEditor) {
                            OutlinedTextField(
                                value = curNode.comment,
                                onValueChange = onUpdateMoveComment,
                                placeholder = { Text("Write comment on move...", fontSize = 12.sp) },
                                textStyle = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                    .testTag("inline_move_comment_field")
                            )
                        }
                    }
                }

                // 3. Bottom Transport & Menu Row (|<, <, >, >|, Flip, Menu) matching screenshot
                HorizontalDivider(color = DividerHairline)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SheetBottomBarBg)
                        .navigationBarsPadding()
                        .height(54.dp)
                ) {
                    IconButton(
                        onClick = onGoStart,
                        enabled = boardState.canGoBack,
                        modifier = Modifier.size(48.dp).testTag("btn_first_move")
                    ) {
                        Icon(
                            Icons.Default.FirstPage,
                            contentDescription = stringResource(R.string.cd_first_move),
                            tint = if (boardState.canGoBack) SheetIconGray else Color(0xFFD4D4D8),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    IconButton(
                        onClick = onGoPrev,
                        enabled = boardState.canGoBack,
                        modifier = Modifier.size(48.dp).testTag("btn_prev_move")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = stringResource(R.string.cd_prev_move),
                            tint = if (boardState.canGoBack) SheetIconGray else Color(0xFFD4D4D8),
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    IconButton(
                        onClick = onGoNext,
                        enabled = boardState.canGoForward,
                        modifier = Modifier.size(48.dp).testTag("btn_next_move")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = stringResource(R.string.cd_next_move),
                            tint = if (boardState.canGoForward) SheetIconGray else Color(0xFFD4D4D8),
                            modifier = Modifier.size(30.dp)
                        )
                    }
                    IconButton(
                        onClick = onGoEnd,
                        enabled = boardState.canGoForward,
                        modifier = Modifier.size(48.dp).testTag("btn_last_move")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.LastPage,
                            contentDescription = stringResource(R.string.cd_last_move),
                            tint = if (boardState.canGoForward) SheetIconGray else Color(0xFFD4D4D8),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    IconButton(
                        onClick = onFlipBoard,
                        modifier = Modifier.size(48.dp).testTag("btn_flip_board")
                    ) {
                        Icon(
                            Icons.Default.Cached,
                            contentDescription = stringResource(R.string.cd_flip_board),
                            tint = SheetIconGray,
                            modifier = Modifier.size(25.dp)
                        )
                    }
                    IconButton(
                        onClick = onOpenBoardMenuSheet,
                        modifier = Modifier.size(48.dp).testTag("btn_board_menu")
                    ) {
                        Icon(
                            Icons.Default.Menu,
                            contentDescription = stringResource(R.string.cd_board_menu),
                            tint = SheetIconGray,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }
    }
}
