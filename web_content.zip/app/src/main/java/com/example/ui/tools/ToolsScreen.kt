package com.example.ui.tools

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Percent
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.engine.FormattingOptions
import com.example.tools.ToolGroup
import com.example.tools.ToolId
import com.example.ui.components.AetherFilterChip
import com.example.ui.theme.AetherTheme

@Composable
fun ToolsScreen(
  formatting: FormattingOptions,
  hapticsEnabled: Boolean,
  onCopyResult: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedTool by remember { mutableStateOf<ToolId?>(null) }
  var selectedGroup by remember { mutableStateOf<ToolGroup?>(null) }

  BackHandler(enabled = selectedTool != null) {
    selectedTool = null
  }

  val colors = AetherTheme.colors

  Box(
    modifier = modifier.fillMaxSize().background(colors.background),
    contentAlignment = Alignment.TopCenter,
  ) {
    val activeTool = selectedTool
    if (activeTool != null) {
      Column(
        modifier =
          Modifier
            .fillMaxSize()
            .widthIn(max = 560.dp)
            .padding(horizontal = 16.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().height(52.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(
            onClick = { selectedTool = null },
            modifier = Modifier.size(44.dp).testTag("tool_back_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
              contentDescription = stringResource(R.string.cd_back),
              tint = colors.textPrimary,
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Column {
            Text(
              text = activeTool.title,
              style = MaterialTheme.typography.titleLarge,
              color = colors.textPrimary,
            )
            Text(
              text = activeTool.group.title,
              style = MaterialTheme.typography.labelSmall,
              color = colors.lavender,
            )
          }
        }

        Column(
          modifier =
            Modifier
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(top = 8.dp, bottom = 24.dp),
        ) {
          when (activeTool.group) {
            ToolGroup.PERCENTAGE, ToolGroup.FINANCE ->
              PercentageAndFinanceToolView(activeTool, formatting, hapticsEnabled, onCopyResult)
            ToolGroup.EVERYDAY ->
              when (activeTool) {
                ToolId.DISCOUNT,
                ToolId.SALE_PRICE,
                ToolId.TAX_GST,
                ToolId.TIP,
                ToolId.SPLIT_BILL,
                ToolId.RATIO,
                ToolId.AVERAGE ->
                  EverydayUtilityToolsAView(activeTool, formatting, hapticsEnabled, onCopyResult)
                else ->
                  EverydayUtilityToolsBView(activeTool, formatting, hapticsEnabled, onCopyResult)
              }
          }
        }
      }
    } else {
      val visibleGroups =
        if (selectedGroup == null) ToolGroup.entries else listOf(selectedGroup!!)

      Column(
        modifier =
          Modifier
            .fillMaxSize()
            .widthIn(max = 560.dp)
            .padding(horizontal = 16.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().height(48.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.nav_tools),
            style = MaterialTheme.typography.headlineSmall,
            color = colors.textPrimary,
          )
        }

        LazyRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          contentPadding = PaddingValues(vertical = 6.dp),
        ) {
          item {
            AetherFilterChip(
              label = "All (${ToolId.entries.size})",
              selected = selectedGroup == null,
              onClick = { selectedGroup = null },
              hapticsEnabled = hapticsEnabled,
            )
          }
          items(ToolGroup.entries) { group ->
            AetherFilterChip(
              label = group.title,
              selected = selectedGroup == group,
              onClick = { selectedGroup = group },
              hapticsEnabled = hapticsEnabled,
            )
          }
        }

        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(top = 8.dp, bottom = 20.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          visibleGroups.forEach { group ->
            item(key = "header_${group.name}") {
              Text(
                text = group.title,
                style = MaterialTheme.typography.labelLarge,
                color = colors.lavender,
                modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
              )
            }
            val groupTools = ToolId.entries.filter { it.group == group }
            items(groupTools, key = { it.name }) { tool ->
              ToolListRow(
                tool = tool,
                onClick = { selectedTool = tool },
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ToolListRow(
  tool: ToolId,
  onClick: () -> Unit,
) {
  val colors = AetherTheme.colors
  val icon =
    when (tool.group) {
      ToolGroup.PERCENTAGE -> Icons.Outlined.Percent
      ToolGroup.FINANCE -> Icons.Outlined.AccountBalance
      ToolGroup.EVERYDAY -> Icons.Outlined.Calculate
    }

  Surface(
    modifier =
      Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .clickable(onClick = onClick)
        .testTag("tool_row_${tool.name}"),
    shape = RoundedCornerShape(16.dp),
    color = colors.surface,
    border = BorderStroke(1.dp, colors.borderSubtle),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = colors.surfaceElevated,
        modifier = Modifier.size(40.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = colors.lavender,
            modifier = Modifier.size(20.dp),
          )
        }
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = tool.title,
          style = MaterialTheme.typography.titleMedium,
          color = colors.textPrimary,
        )
        Text(
          text = tool.subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = colors.textSecondary,
        )
      }
      Icon(
        imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
        contentDescription = null,
        tint = colors.textSecondary,
      )
    }
  }
}
