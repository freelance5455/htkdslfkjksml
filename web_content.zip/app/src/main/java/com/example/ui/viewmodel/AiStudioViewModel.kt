package com.example.ui.viewmodel

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.io.File

private const val TAG = "AiStudioViewModel"

sealed interface AiTaskState<out T> {
    data object Idle : AiTaskState<Nothing>
    data class Loading(val label: String) : AiTaskState<Nothing>
    data class Success<T>(val data: T) : AiTaskState<T>
    data class Error(val message: String) : AiTaskState<Nothing>
}

data class SmartSearchInterpretation(
    val explanation: String,
    val keywords: List<String>,
    val extensions: List<String>,
    val categoryName: String?,
    val minSizeBytes: Long?,
    val maxSizeBytes: Long?,
    val modifiedAfterEpochMs: Long?
)

data class VideoAiInsights(
    val summary: String,
    val captions: List<String>,
    val sceneHighlights: List<String>,
    val editSuggestions: List<String>
)

class AiStudioViewModel : ViewModel() {

    private val smartSearchSchema = Schema.obj(
        properties = mapOf(
            "explanation" to Schema.string(description = "Short friendly summary of applied filters"),
            "keywords" to Schema.array(
                items = Schema.string(),
                description = "Filename keywords to match (empty if matching all files of a type)"
            ),
            "extensions" to Schema.array(
                items = Schema.string(),
                description = "Lowercase extensions without dot such as pdf, jpg, mp4, apk, zip"
            ),
            "categoryName" to Schema.string(
                description = "Optional category from IMAGES, AUDIO, VIDEOS, DOCUMENTS, DOWNLOADS, INSTALLATION, COMPRESSED, or empty string"
            ),
            "minSizeBytes" to Schema.integer(description = "Minimum size in bytes, or 0 if none"),
            "maxSizeBytes" to Schema.integer(description = "Maximum size in bytes, or 0 if none"),
            "daysBack" to Schema.integer(description = "If query specifies recency like 'last week' (7) or 'yesterday' (1), number of days back, else 0")
        )
    )

    private val videoInsightSchema = Schema.obj(
        properties = mapOf(
            "summary" to Schema.string(description = "Concise 2-sentence overview of the video content and visual tone"),
            "captions" to Schema.array(
                items = Schema.string(),
                description = "3 to 5 timestamped or sequential auto-captions suitable for overlays"
            ),
            "sceneHighlights" to Schema.array(
                items = Schema.string(),
                description = "Key visual moments or scene highlights observed across frames"
            ),
            "editSuggestions" to Schema.array(
                items = Schema.string(),
                description = "Actionable trim, speed, text overlay, or pacing recommendations"
            )
        )
    )

    // Lazy initialization per Firebase AI Logic mandatory guidelines
    private val smartSearchModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = smartSearchSchema
            }
        )
    }

    private val videoInsightModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = videoInsightSchema
            }
        )
    }

    private val imageEditModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-nano-banana-2.1",
            generationConfig = generationConfig {
                responseModalities = listOf(ResponseModality.IMAGE)
            }
        )
    }

    private val _smartSearchState = MutableStateFlow<AiTaskState<SmartSearchInterpretation>>(AiTaskState.Idle)
    val smartSearchState: StateFlow<AiTaskState<SmartSearchInterpretation>> = _smartSearchState.asStateFlow()

    private val _imageAiState = MutableStateFlow<AiTaskState<Bitmap>>(AiTaskState.Idle)
    val imageAiState: StateFlow<AiTaskState<Bitmap>> = _imageAiState.asStateFlow()

    private val _videoAiState = MutableStateFlow<AiTaskState<VideoAiInsights>>(AiTaskState.Idle)
    val videoAiState: StateFlow<AiTaskState<VideoAiInsights>> = _videoAiState.asStateFlow()

    fun resetImageAiState() {
        _imageAiState.value = AiTaskState.Idle
    }

    fun resetVideoAiState() {
        _videoAiState.value = AiTaskState.Idle
    }

    fun interpretNaturalLanguageSearch(
        naturalQuery: String,
        onParsed: (SmartSearchInterpretation) -> Unit
    ) {
        if (naturalQuery.isBlank()) return
        viewModelScope.launch {
            _smartSearchState.value = AiTaskState.Loading("Analyzing query with Gemini...")
            try {
                val prompt = """
                    Convert this natural-language mobile file manager search request into structured filter fields:
                    User query: "$naturalQuery"
                    Note: 1 MB = 1000000 bytes, 1 GB = 1000000000 bytes.
                    If the user asks for a file category (e.g., "PDFs from last week"), leave keywords empty and populate extensions=["pdf"] and daysBack=7.
                """.trimIndent()

                val response = withTimeout(45_000L) {
                    smartSearchModel.generateContent(prompt)
                }
                val rawJson = response.text ?: throw IllegalStateException("Empty AI response")
                val obj = JSONObject(rawJson)

                val kwArr = obj.optJSONArray("keywords")
                val keywords = buildList {
                    if (kwArr != null) {
                        for (i in 0 until kwArr.length()) add(kwArr.getString(i))
                    }
                }
                val extArr = obj.optJSONArray("extensions")
                val extensions = buildList {
                    if (extArr != null) {
                        for (i in 0 until extArr.length()) add(extArr.getString(i))
                    }
                }
                val cat = obj.optString("categoryName").takeIf { it.isNotBlank() }
                val minB = obj.optLong("minSizeBytes", 0L).takeIf { it > 0L }
                val maxB = obj.optLong("maxSizeBytes", 0L).takeIf { it > 0L }
                val daysBack = obj.optInt("daysBack", 0)
                val modAfter = if (daysBack > 0) {
                    System.currentTimeMillis() - daysBack * 24L * 60L * 60L * 1000L
                } else null

                val parsed = SmartSearchInterpretation(
                    explanation = obj.optString("explanation", "Filtered by Gemini AI"),
                    keywords = keywords,
                    extensions = extensions,
                    categoryName = cat,
                    minSizeBytes = minB,
                    maxSizeBytes = maxB,
                    modifiedAfterEpochMs = modAfter
                )
                _smartSearchState.value = AiTaskState.Success(parsed)
                onParsed(parsed)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Smart search timed out", e)
                _smartSearchState.value = AiTaskState.Error("Smart search timed out after 45 seconds.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Smart search failed", e)
                _smartSearchState.value = AiTaskState.Error(e.localizedMessage ?: "AI smart search failed.")
            }
        }
    }

    fun editImageWithGemini(sourceBitmap: Bitmap, instruction: String) {
        viewModelScope.launch {
            _imageAiState.value = AiTaskState.Loading("Synthesizing image edit (may take 30–60s)...")
            try {
                // Keep inline bitmap well below 20MB payload limit
                val safeInput = downscaleIfNeeded(sourceBitmap, maxDim = 1280)
                val resultBitmap = withTimeout(60_000L) {
                    val response = imageEditModel.generateContent(
                        content {
                            image(safeInput)
                            text(instruction)
                        }
                    )
                    response.candidates.firstOrNull()
                        ?.content?.parts?.filterIsInstance<ImagePart>()
                        ?.firstOrNull()?.image
                }

                if (resultBitmap != null) {
                    _imageAiState.value = AiTaskState.Success(resultBitmap)
                } else {
                    _imageAiState.value = AiTaskState.Error("Model did not return an edited image.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI image edit timed out", e)
                _imageAiState.value = AiTaskState.Error("Image generation timed out after 60 seconds.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI image edit failed", e)
                _imageAiState.value = AiTaskState.Error(e.localizedMessage ?: "AI image editing failed.")
            }
        }
    }

    fun analyzeVideoWithGemini(localVideoFile: File, customPrompt: String? = null) {
        viewModelScope.launch {
            _videoAiState.value = AiTaskState.Loading("Extracting keyframes & analyzing with Gemini...")
            try {
                val frames = withContext(Dispatchers.IO) {
                    extractKeyframes(localVideoFile, frameCount = 4)
                }
                if (frames.isEmpty()) {
                    _videoAiState.value = AiTaskState.Error("Could not decode video frames for AI inspection.")
                    return@launch
                }

                val response = withTimeout(60_000L) {
                    videoInsightModel.generateContent(
                        content {
                            frames.forEach { bmp -> image(bmp) }
                            val userGoal = if (!customPrompt.isNullOrBlank()) {
                                "User edit goal: \"$customPrompt\". Tailor editSuggestions and captions specifically to this request."
                            } else {
                                "Generate concise auto-captions, scene highlights, and smart editing suggestions."
                            }
                            text("Analyze these sequential keyframes from user video '${localVideoFile.name}'. $userGoal")
                        }
                    )
                }

                val jsonString = response.text ?: throw IllegalStateException("Model returned empty video analysis.")
                val json = JSONObject(jsonString)

                val captionsArr = json.optJSONArray("captions")
                val captions = buildList {
                    if (captionsArr != null) {
                        for (i in 0 until captionsArr.length()) add(captionsArr.getString(i))
                    }
                }
                val highlightsArr = json.optJSONArray("sceneHighlights")
                val highlights = buildList {
                    if (highlightsArr != null) {
                        for (i in 0 until highlightsArr.length()) add(highlightsArr.getString(i))
                    }
                }
                val editsArr = json.optJSONArray("editSuggestions")
                val suggestions = buildList {
                    if (editsArr != null) {
                        for (i in 0 until editsArr.length()) add(editsArr.getString(i))
                    }
                }

                _videoAiState.value = AiTaskState.Success(
                    VideoAiInsights(
                        summary = json.optString("summary", "Video analyzed."),
                        captions = captions,
                        sceneHighlights = highlights,
                        editSuggestions = suggestions
                    )
                )
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Video AI analysis timed out", e)
                _videoAiState.value = AiTaskState.Error("Video AI analysis timed out after 60 seconds.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Video AI analysis failed", e)
                _videoAiState.value = AiTaskState.Error(e.localizedMessage ?: "Video AI analysis failed.")
            }
        }
    }

    private fun downscaleIfNeeded(bmp: Bitmap, maxDim: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        if (w <= maxDim && h <= maxDim) return bmp
        val ratio = maxDim.toFloat() / maxOf(w, h).toFloat()
        val nw = (w * ratio).toInt().coerceAtLeast(1)
        val nh = (h * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bmp, nw, nh, true)
    }

    private fun extractKeyframes(videoFile: File, frameCount: Int): List<Bitmap> {
        val frames = mutableListOf<Bitmap>()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(videoFile.absolutePath)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 4_000L
            val safeDurationUs = (durationMs.coerceAtLeast(500L)) * 1_000L
            for (i in 0 until frameCount) {
                val timeUs = (safeDurationUs * i) / frameCount.coerceAtLeast(1)
                val frame = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (frame != null) {
                    frames.add(downscaleIfNeeded(frame, 640))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Keyframe extraction error", e)
        } finally {
            runCatching { retriever.release() }
        }
        return frames
    }
}
