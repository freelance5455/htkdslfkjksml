package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CreatorDarkColorScheme = darkColorScheme(
    primary = Blue500,
    onPrimary = Color.White,
    secondary = Cyan400,
    onSecondary = Color.White,
    background = Slate950,
    onBackground = Slate200,
    surface = Slate900,
    onSurface = Slate200,
    surfaceVariant = Slate800,
    onSurfaceVariant = Slate400,
    outline = Slate700
)

@Composable
fun CreatorPulseTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CreatorDarkColorScheme,
        typography = Typography,
        content = content
    )
}
