package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = AtcAeroBlueDark,
  onPrimary = Color(0xFF032238),
  primaryContainer = Color(0xFF0C3D5F),
  onPrimaryContainer = Color(0xFFBAE6FD),
  secondary = AtcSecondaryDark,
  onSecondary = Color(0xFF0F172A),
  secondaryContainer = Color(0xFF1E293B),
  onSecondaryContainer = Color(0xFFCBD5E1),
  background = AtcDeepNavy,
  onBackground = Color(0xFFF1F5F9),
  surface = AtcSurfaceDark,
  onSurface = Color(0xFFF8FAFC),
  surfaceVariant = AtcCardDark,
  onSurfaceVariant = Color(0xFFCBD5E1),
  outline = AtcBorderDark,
  error = StatusRed,
  onError = Color.White
)

private val LightColorScheme = lightColorScheme(
  primary = AtcAeroBlueLight,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE0F2FE),
  onPrimaryContainer = Color(0xFF0369A1),
  secondary = AtcSecondaryLight,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFF1F5F9),
  onSecondaryContainer = Color(0xFF1E293B),
  background = AtcLightBg,
  onBackground = Color(0xFF0F172A),
  surface = AtcLightSurface,
  onSurface = Color(0xFF0F172A),
  surfaceVariant = AtcLightCard,
  onSurfaceVariant = Color(0xFF334155),
  outline = AtcLightBorder,
  error = StatusRed,
  onError = Color.White
)

@Composable
fun AtcWeatherTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(
    colorScheme = colorScheme,
    typography = AppTypography,
    content = content
  )
}
