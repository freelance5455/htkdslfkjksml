package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val SuesaDarkColorScheme = darkColorScheme(
    primary = PurplePrimary,
    onPrimary = TextPrimary,
    primaryContainer = PurpleDark,
    onPrimaryContainer = TextPrimary,
    secondary = PurpleLight,
    onSecondary = SuesaBackground,
    background = SuesaBackground,
    onBackground = TextPrimary,
    surface = SuesaSurface,
    onSurface = TextPrimary,
    surfaceVariant = SuesaSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = SuesaCardBorder,
    error = AccentError,
    onError = TextPrimary
)

@Composable
fun SuesaAITheme(
    darkTheme: Boolean = true, // Dark mode default as requested
    content: @Composable () -> Unit
) {
    val colorScheme = SuesaDarkColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = SuesaBackground.toArgb()
                window.navigationBarColor = SuesaBackground.toArgb()
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = false
                controller.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
