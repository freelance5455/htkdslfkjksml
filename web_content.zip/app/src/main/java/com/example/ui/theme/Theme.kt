package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val YiffyDarkColorScheme = darkColorScheme(
    primary = YiffyPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4A0020),
    onPrimaryContainer = Color(0xFFFFD9E2),
    secondary = YiffySecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF2C0075),
    onSecondaryContainer = Color(0xFFEADBFF),
    tertiary = YiffyTertiary,
    onTertiary = Color.Black,
    background = YiffyDarkBackground,
    onBackground = YiffyTextPrimary,
    surface = YiffySurface,
    onSurface = YiffyTextPrimary,
    surfaceVariant = YiffySurfaceVariant,
    onSurfaceVariant = YiffyTextSecondary,
    outline = YiffyCardBorder,
    outlineVariant = Color(0xFF1E212B)
)

@Composable
fun YiffyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Media feed app is optimized for OLED deep dark immersion
    MaterialTheme(
        colorScheme = YiffyDarkColorScheme,
        typography = Typography,
        content = content
    )
}
