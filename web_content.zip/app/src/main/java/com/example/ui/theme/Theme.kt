package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color(0xFF1C1300),
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = GoldLight,
    secondary = EmeraldLight,
    onSecondary = Color(0xFF002919),
    secondaryContainer = MidnightCardSecondary,
    onSecondaryContainer = Color(0xFFD1FAE5),
    tertiary = AmberGlow,
    onTertiary = Color(0xFF241400),
    background = MidnightBackground,
    onBackground = MidnightTextPrimary,
    surface = MidnightCard,
    onSurface = MidnightTextPrimary,
    surfaceVariant = MidnightCardSecondary,
    onSurfaceVariant = MidnightTextSecondary,
    outline = MidnightBorder
)

private val LightColorScheme = lightColorScheme(
    primary = GoldDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = Color(0xFF78350F),
    secondary = EmeraldMedium,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = Color(0xFF064E3B),
    tertiary = AmberGlow,
    onTertiary = Color.White,
    background = AlabasterBackground,
    onBackground = AlabasterTextPrimary,
    surface = AlabasterSurface,
    onSurface = AlabasterTextPrimary,
    surfaceVariant = AlabasterCard,
    onSurfaceVariant = AlabasterTextSecondary,
    outline = AlabasterBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

