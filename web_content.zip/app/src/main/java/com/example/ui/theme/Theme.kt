package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = DopingPrimaryLight,
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF312E81),
    onPrimaryContainer = Color(0xFFE0E7FF),
    secondary = DopingAmber,
    onSecondary = Color(0xFF451A03),
    secondaryContainer = Color(0xFF78350F),
    onSecondaryContainer = Color(0xFFFEF3C7),
    tertiary = DopingTeal,
    onTertiary = Color(0xFF083344),
    background = DopingDarkBackground,
    onBackground = Color(0xFFF8FAFC),
    surface = DopingDarkSurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = DopingDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5E1),
    error = DopingRed,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = DopingPrimary,
    onPrimary = Color.White,
    primaryContainer = DopingPrimaryContainer,
    onPrimaryContainer = Color(0xFF1E1B4B),
    secondary = DopingAmberDark,
    onSecondary = Color.White,
    secondaryContainer = DopingAmberLight,
    onSecondaryContainer = Color(0xFF78350F),
    tertiary = DopingTeal,
    onTertiary = Color.White,
    background = DopingLightBackground,
    onBackground = DopingTextPrimary,
    surface = DopingLightSurface,
    onSurface = DopingTextPrimary,
    surfaceVariant = DopingLightSurfaceVariant,
    onSurfaceVariant = DopingTextSecondary,
    error = DopingRed,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use intentional branded palette for Doping Hafıza
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }
      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
