package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val HavenDarkColorScheme = darkColorScheme(
    primary = DarkSagePrimary,
    onPrimary = DarkSageOnPrimary,
    primaryContainer = DarkSageContainer,
    onPrimaryContainer = DarkSageOnContainer,
    secondary = DarkTerracottaSecondary,
    onSecondary = DarkTerracottaOnSecondary,
    secondaryContainer = DarkTerracottaContainer,
    onSecondaryContainer = DarkTerracottaOnContainer,
    tertiary = DarkLavenderTertiary,
    onTertiary = DarkLavenderOnTertiary,
    tertiaryContainer = DarkLavenderContainer,
    onTertiaryContainer = DarkLavenderOnContainer,
    background = NightSlateBackground,
    onBackground = NightOnBackground,
    surface = NightSurface,
    onSurface = NightOnBackground,
    surfaceVariant = NightSurfaceVariant,
    onSurfaceVariant = NightOnSurfaceVariant,
    error = SosCrimson,
    errorContainer = SosCrimsonContainer,
    onErrorContainer = SosOnCrimsonContainer
)

private val HavenLightColorScheme = lightColorScheme(
    primary = SagePrimary,
    onPrimary = SageOnPrimary,
    primaryContainer = SagePrimaryContainer,
    onPrimaryContainer = SageOnPrimaryContainer,
    secondary = TerracottaSecondary,
    onSecondary = TerracottaOnSecondary,
    secondaryContainer = TerracottaContainer,
    onSecondaryContainer = TerracottaOnSecondaryContainer,
    tertiary = LavenderTertiary,
    onTertiary = LavenderOnTertiary,
    tertiaryContainer = LavenderContainer,
    onTertiaryContainer = LavenderOnTertiaryContainer,
    background = WarmCreamBackground,
    onBackground = CharcoalOnBackground,
    surface = SandSurface,
    onSurface = CharcoalOnBackground,
    surfaceVariant = SandSurfaceVariant,
    onSurfaceVariant = SandOnSurfaceVariant,
    outline = OutlineWarm,
    error = SosCrimson,
    errorContainer = SosCrimsonContainer,
    onErrorContainer = SosOnCrimsonContainer
)

val HavenShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun HavenTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> HavenDarkColorScheme
        else -> HavenLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = HavenTypography,
        shapes = HavenShapes,
        content = content
    )
}
