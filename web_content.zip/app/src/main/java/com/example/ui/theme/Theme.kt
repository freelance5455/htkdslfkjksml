package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val OmnitrixDarkColorScheme = darkColorScheme(
    primary = OmnitrixGreen,
    onPrimary = GalvanBlack,
    primaryContainer = OmnitrixGreenDark,
    onPrimaryContainer = OmnitrixGreenBright,
    secondary = AlienCyan,
    onSecondary = GalvanBlack,
    secondaryContainer = GalvanSurfaceLight,
    onSecondaryContainer = AlienCyan,
    tertiary = AlienGold,
    onTertiary = GalvanBlack,
    background = GalvanBlack,
    onBackground = WhitePure,
    surface = GalvanDark,
    onSurface = WhitePure,
    surfaceVariant = GalvanSurface,
    onSurfaceVariant = WhiteMuted,
    outline = GalvanBorder,
    outlineVariant = OmnitrixGreenDim
)

val UltimateDarkColorScheme = darkColorScheme(
    primary = UltimateRed,
    onPrimary = GalvanBlack,
    primaryContainer = UltimateRedDark,
    onPrimaryContainer = UltimateRedBright,
    secondary = AlienOrange,
    onSecondary = GalvanBlack,
    secondaryContainer = GalvanSurfaceLight,
    onSecondaryContainer = UltimateRedBright,
    tertiary = AlienGold,
    onTertiary = GalvanBlack,
    background = GalvanBlack,
    onBackground = WhitePure,
    surface = Color(0xFF13090B),
    onSurface = WhitePure,
    surfaceVariant = Color(0xFF1F0E12),
    onSurfaceVariant = WhiteMuted,
    outline = Color(0xFF42181D),
    outlineVariant = UltimateRedDim
)

@Composable
fun MyApplicationTheme(
    isUltimateMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isUltimateMode) UltimateDarkColorScheme else OmnitrixDarkColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
