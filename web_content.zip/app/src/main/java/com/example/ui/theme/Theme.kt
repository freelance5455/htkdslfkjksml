package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = EmeraldOnPrimary,
    primaryContainer = EmeraldContainer,
    onPrimaryContainer = EmeraldOnContainer,
    secondary = GoldSecondary,
    onSecondary = GoldOnSecondary,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = GoldOnContainer,
    tertiary = SlateTertiary,
    onTertiary = SlateOnTertiary,
    tertiaryContainer = SlateContainer,
    onTertiaryContainer = SlateOnContainer,
    background = AlabasterBackground,
    onBackground = CharcoalOnSurface,
    surface = WarmSurface,
    onSurface = CharcoalOnSurface,
    surfaceVariant = WarmSurfaceVariant,
    onSurfaceVariant = MutedOnSurfaceVariant,
    outline = SubtleOutline,
    error = UrgentCrimson,
    errorContainer = UrgentCrimsonContainer
)

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldDarkPrimary,
    onPrimary = EmeraldDarkOnPrimary,
    primaryContainer = EmeraldDarkContainer,
    onPrimaryContainer = EmeraldDarkOnContainer,
    secondary = GoldDarkSecondary,
    onSecondary = GoldDarkOnSecondary,
    secondaryContainer = GoldDarkContainer,
    onSecondaryContainer = GoldDarkOnContainer,
    tertiary = SlateContainer,
    onTertiary = SlateOnContainer,
    background = ObsidianBackground,
    onBackground = IvoryOnDark,
    surface = ObsidianSurface,
    onSurface = IvoryOnDark,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = MutedOnDark,
    outline = DarkOutline,
    error = UrgentCrimson,
    errorContainer = UrgentCrimsonContainer
)

val TrueAShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun TrueATheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = TrueATypography,
        shapes = TrueAShapes,
        content = content
    )
}
