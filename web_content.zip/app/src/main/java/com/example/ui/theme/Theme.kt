package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ChromaPrimary,
    onPrimary = ChromaOnPrimary,
    primaryContainer = Color(0xFF004D59),
    onPrimaryContainer = Color(0xFFA5EEFF),
    secondary = ChromaSecondary,
    onSecondary = ChromaOnSecondary,
    secondaryContainer = Color(0xFF005236),
    onSecondaryContainer = Color(0xFF86F8C8),
    tertiary = ChromaTertiary,
    onTertiary = ChromaOnTertiary,
    background = ChromaDarkBackground,
    onBackground = ChromaTextPrimary,
    surface = ChromaDarkSurface,
    onSurface = ChromaTextPrimary,
    surfaceVariant = ChromaDarkSurfaceVariant,
    onSurfaceVariant = ChromaTextSecondary,
    outline = ChromaOutline
)

private val LightColorScheme = darkColorScheme( // For pro camera apps, dark interface is preferred for contrast against live feed
    primary = ChromaPrimary,
    onPrimary = ChromaOnPrimary,
    secondary = ChromaSecondary,
    onSecondary = ChromaOnSecondary,
    tertiary = ChromaTertiary,
    onTertiary = ChromaOnTertiary,
    background = ChromaDarkBackground,
    onBackground = ChromaTextPrimary,
    surface = ChromaDarkSurface,
    onSurface = ChromaTextPrimary,
    surfaceVariant = ChromaDarkSurfaceVariant,
    onSurfaceVariant = ChromaTextSecondary,
    outline = ChromaOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep consistent pro-camera dark aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
