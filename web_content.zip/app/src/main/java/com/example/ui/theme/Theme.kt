package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Aviation Daylight Console Color Scheme (Ocean Blue & Soft Lilac)
private val LightAviationColorScheme = lightColorScheme(
  primary = OceanBlue,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE0F2FE),
  onPrimaryContainer = OceanBlueDark,
  secondary = AtcSecondaryLight,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFF1F5F9),
  onSecondaryContainer = Color(0xFF1E293B),
  background = SoftLilacBg,
  onBackground = AtcTextMain,
  surface = Color.White,
  onSurface = AtcTextMain,
  surfaceVariant = Color(0xFFF5F0FB),
  onSurfaceVariant = AtcTextMuted,
  outline = Color(0xFFCBD5E1),
  error = StatusRed,
  onError = Color.White
)

@Composable
fun AtcWeatherTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = LightAviationColorScheme,
    typography = AppTypography,
    content = content
  )
}

