package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val NovaDarkColorScheme = darkColorScheme(
    primary = ElectricLime,
    onPrimary = DeepEmerald,
    primaryContainer = ForestEmerald,
    onPrimaryContainer = ElectricLime,
    secondary = BrightEmerald,
    onSecondary = DeepEmerald,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = ElectricLime,
    tertiary = WarmGold,
    onTertiary = DeepEmerald,
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkMuted,
    outline = DarkBorder,
    error = Color(0xFFFF897D),
    onError = Color(0xFF680008),
    errorContainer = Color(0xFF93000F),
    onErrorContainer = Color(0xFFFFDAD6)
)

private val NovaLightColorScheme = lightColorScheme(
    primary = ForestEmerald,
    onPrimary = Color.White,
    primaryContainer = MintSurfaceVariant,
    onPrimaryContainer = ForestEmerald,
    secondary = VibrantEmerald,
    onSecondary = Color.White,
    secondaryContainer = ElectricLime,
    onSecondaryContainer = DeepEmerald,
    tertiary = WarmGold,
    onTertiary = DeepEmerald,
    background = MintPaper,
    onBackground = InkDark,
    surface = MintSurface,
    onSurface = InkDark,
    surfaceVariant = MintSurfaceVariant,
    onSurfaceVariant = MutedSage,
    outline = MintBorder,
    error = CoralAlert,
    onError = Color.White,
    errorContainer = CoralContainer,
    onErrorContainer = Color(0xFF731910)
)

val NovaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun NovaBazarTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NovaDarkColorScheme else NovaLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = NovaTypography,
        shapes = NovaShapes,
        content = content
    )
}
