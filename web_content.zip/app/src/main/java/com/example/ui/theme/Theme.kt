package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = IndigoPrimaryDark,
    onPrimary = IndigoOnPrimaryDark,
    primaryContainer = IndigoContainerDark,
    onPrimaryContainer = IndigoOnContainerDark,
    secondary = SakuraSecondaryDark,
    secondaryContainer = SakuraContainerDark,
    onSecondaryContainer = SakuraOnContainerDark,
    background = NightBackgroundDark,
    surface = NightSurfaceDark,
    surfaceVariant = NightSurfaceVariantDark,
    onBackground = NightOnSurfaceDark,
    onSurface = NightOnSurfaceDark
)

private val LightColorScheme = lightColorScheme(
    primary = IndigoPrimaryLight,
    onPrimary = IndigoOnPrimaryLight,
    primaryContainer = IndigoContainerLight,
    onPrimaryContainer = IndigoOnContainerLight,
    secondary = SakuraSecondaryLight,
    secondaryContainer = SakuraContainerLight,
    onSecondaryContainer = SakuraOnContainerLight,
    background = LavenderBackgroundLight,
    surface = LavenderSurfaceLight,
    surfaceVariant = LavenderSurfaceVariantLight,
    onBackground = LavenderOnSurfaceLight,
    onSurface = LavenderOnSurfaceLight
)

@Composable
fun IchimatsuTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
