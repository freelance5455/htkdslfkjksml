package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val MinecraftColorScheme = darkColorScheme(
  primary = MinecraftEmerald,
  onPrimary = MinecraftBackground,
  primaryContainer = MinecraftGrassDark,
  onPrimaryContainer = MinecraftText,
  secondary = MinecraftGold,
  onSecondary = MinecraftBackground,
  secondaryContainer = MinecraftDirt,
  onSecondaryContainer = MinecraftText,
  tertiary = MinecraftDiamond,
  onTertiary = MinecraftBackground,
  background = MinecraftBackground,
  onBackground = MinecraftText,
  surface = MinecraftSurface,
  onSurface = MinecraftText,
  surfaceVariant = MinecraftSurfaceVariant,
  onSurfaceVariant = MinecraftTextDim,
  outline = MinecraftBorder,
  error = MinecraftRedstone,
  onError = MinecraftText
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Preserve authentic Minecraft palette
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = MinecraftColorScheme,
    typography = Typography,
    content = content
  )
}
