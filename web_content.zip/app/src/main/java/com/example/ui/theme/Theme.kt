package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DexterDarkColorScheme = darkColorScheme(
    primary = DexterCyanPrimary,
    onPrimary = DexterCyanOnPrimary,
    primaryContainer = DexterCyanContainer,
    onPrimaryContainer = DexterCyanOnContainer,
    secondary = DexterEmeraldSecondary,
    onSecondary = DexterEmeraldOnSecondary,
    secondaryContainer = DexterEmeraldContainer,
    onSecondaryContainer = DexterEmeraldOnContainer,
    tertiary = DexterAmberTertiary,
    onTertiary = DexterAmberOnTertiary,
    tertiaryContainer = DexterAmberContainer,
    onTertiaryContainer = DexterAmberOnContainer,
    background = DexterBackground,
    onBackground = Color(0xFFF1F5F9),
    surface = DexterSurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = DexterSurfaceVariant,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = DexterOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DexterDarkColorScheme,
        typography = Typography,
        content = content
    )
}
