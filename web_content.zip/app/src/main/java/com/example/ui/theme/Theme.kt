package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NursingGreenPrimaryDark,
    onPrimary = Color(0xFF003915),
    primaryContainer = Color(0xFF005322),
    onPrimaryContainer = Color(0xFF86F89E),
    secondary = ClinicalBlueSecondaryDark,
    onSecondary = Color(0xFF00344F),
    secondaryContainer = Color(0xFF004C70),
    onSecondaryContainer = Color(0xFFBCE9FF),
    tertiary = MedicalTealTertiaryDark,
    onTertiary = Color(0xFF003733),
    tertiaryContainer = Color(0xFF00504B),
    onTertiaryContainer = Color(0xFF73F8EE),
    background = CollegeBackgroundDark,
    surface = CollegeSurfaceDark,
    surfaceVariant = CollegeSurfaceVariantDark,
    onSurface = CollegeOnSurfaceDark,
    outline = CollegeOutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = NursingGreenPrimary,
    onPrimary = NursingGreenOnPrimary,
    primaryContainer = NursingGreenContainer,
    onPrimaryContainer = NursingGreenOnContainer,
    secondary = ClinicalBlueSecondary,
    onSecondary = ClinicalBlueOnSecondary,
    secondaryContainer = ClinicalBlueContainer,
    onSecondaryContainer = ClinicalBlueOnContainer,
    tertiary = MedicalTealTertiary,
    onTertiary = MedicalTealOnTertiary,
    tertiaryContainer = MedicalTealContainer,
    onTertiaryContainer = MedicalTealOnContainer,
    background = CollegeBackgroundLight,
    surface = CollegeSurfaceLight,
    surfaceVariant = CollegeSurfaceVariantLight,
    onSurface = CollegeOnSurfaceLight,
    outline = CollegeOutlineLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep intentional GNMTC nursing green/blue brand palette
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
