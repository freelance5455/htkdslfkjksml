package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val MoonChessColorScheme = lightColorScheme(
    primary = PrimaryIndigo,
    onPrimary = OnPrimaryWhite,
    primaryContainer = PrimaryContainerIndigo,
    onPrimaryContainer = OnPrimaryContainerIndigo,
    secondary = SecondaryAmber,
    onSecondary = OnPrimaryWhite,
    secondaryContainer = SecondaryContainerAmber,
    background = SurfaceLight,
    onBackground = OnSurfaceDark,
    surface = SheetSurfaceWhite,
    onSurface = OnSurfaceDark,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = OnSurfaceVariantMuted,
    outline = DividerHairline
)

@Composable
fun MoonChessTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = MoonChessColorScheme,
        typography = Typography,
        content = content
    )
}
