package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = HazimCyan,
    onPrimary = HazimDarkBackground,
    primaryContainer = HazimDarkSurfaceVariant,
    onPrimaryContainer = HazimCyanGlow,
    secondary = HazimPurple,
    onSecondary = TextPrimaryDark,
    tertiary = HazimEmerald,
    background = HazimDarkBackground,
    onBackground = TextPrimaryDark,
    surface = HazimDarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = HazimDarkSurfaceVariant,
    onSurfaceVariant = TextSecondaryDark,
    outline = HazimDarkBorder
)

private val LightColorScheme = lightColorScheme(
    primary = HazimPurple,
    onPrimary = HazimLightBackground,
    primaryContainer = HazimLightSurfaceVariant,
    onPrimaryContainer = HazimPurple,
    secondary = HazimCyan,
    onSecondary = HazimDarkBackground,
    tertiary = HazimEmerald,
    background = HazimLightBackground,
    onBackground = TextPrimaryLight,
    surface = HazimLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = HazimLightSurfaceVariant,
    onSurfaceVariant = TextSecondaryLight,
    outline = HazimLightBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to sleek ChatGPT / Gemini dark theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
