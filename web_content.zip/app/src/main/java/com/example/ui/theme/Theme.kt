package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color(0xFF022C22),
    primaryContainer = EmeraldContainerDark,
    onPrimaryContainer = Color(0xFFA7F3D0),
    secondary = SlateSecondary,
    onSecondary = TextPrimaryDark,
    secondaryContainer = SlateContainerDark,
    onSecondaryContainer = TextPrimaryDark,
    tertiary = AmberWarning,
    onTertiary = Color(0xFF271400),
    tertiaryContainer = AmberContainerDark,
    onTertiaryContainer = Color(0xFFFDE68A),
    error = CrimsonAlert,
    onError = Color.White,
    errorContainer = CrimsonContainerDark,
    onErrorContainer = Color(0xFFFECACA),
    background = ShieldObsidian,
    onBackground = TextPrimaryDark,
    surface = ShieldNavySurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = ShieldCardDark,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainer = ShieldCardDark,
    surfaceContainerHigh = ShieldCardElevatedDark,
    outline = OutlineDark,
)

private val LightColorScheme = lightColorScheme(
    primary = EmeraldDark,
    onPrimary = Color.White,
    primaryContainer = EmeraldContainerLight,
    onPrimaryContainer = EmeraldOnContainerLight,
    secondary = SlateSecondary,
    onSecondary = Color.White,
    secondaryContainer = ShieldLightContainer,
    onSecondaryContainer = TextPrimaryLight,
    tertiary = AmberWarning,
    onTertiary = Color.White,
    tertiaryContainer = AmberContainerLight,
    onTertiaryContainer = AmberOnContainerLight,
    error = CrimsonAlert,
    onError = Color.White,
    errorContainer = CrimsonContainerLight,
    onErrorContainer = Color(0xFF991B1B),
    background = ShieldLightBg,
    onBackground = TextPrimaryLight,
    surface = ShieldLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = ShieldLightContainer,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainer = ShieldLightSurface,
    surfaceContainerHigh = ShieldLightContainer,
    outline = OutlineLight,
)

@Composable
fun EscudoPinTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content,
    )
}
