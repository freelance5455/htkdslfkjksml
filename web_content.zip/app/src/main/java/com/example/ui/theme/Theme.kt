package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val YmSecretColorScheme = lightColorScheme(
    primary = BlackPure,
    onPrimary = SilverLight,
    primaryContainer = SilverSurface,
    onPrimaryContainer = BlackPure,
    secondary = SilverDark,
    onSecondary = WhitePure,
    secondaryContainer = SilverSurfaceVariant,
    onSecondaryContainer = BlackCharcoal,
    tertiary = BlackCharcoal,
    onTertiary = WhitePure,
    background = SilverLight,
    onBackground = BlackPure,
    surface = SilverLight,
    onSurface = BlackPure,
    surfaceVariant = SilverSurface,
    onSurfaceVariant = BlackCharcoal,
    outline = BlackPure,
    outlineVariant = SilverDark
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = YmSecretColorScheme,
        typography = Typography,
        content = content
    )
}
