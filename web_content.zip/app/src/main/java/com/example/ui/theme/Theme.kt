package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = GoldDarkPrimary,
    onPrimary = GoldDarkOnPrimary,
    primaryContainer = GoldDarkContainer,
    onPrimaryContainer = GoldDarkOnContainer,
    secondary = RoseDarkSecondary,
    onSecondary = RoseDarkOnSecondary,
    secondaryContainer = RoseDarkContainer,
    onSecondaryContainer = RoseDarkOnContainer,
    tertiary = SageDarkTertiary,
    onTertiary = SageDarkOnTertiary,
    tertiaryContainer = SageDarkContainer,
    onTertiaryContainer = SageDarkOnContainer,
    background = MidnightBackground,
    onBackground = CreamOnBackground,
    surface = MidnightSurface,
    onSurface = CreamOnBackground,
    surfaceVariant = MidnightSurfaceVariant,
    onSurfaceVariant = CreamOnSurfaceVariant
)

private val LightColorScheme = lightColorScheme(
    primary = CrimsonPrimary,
    onPrimary = CrimsonOnPrimary,
    primaryContainer = CrimsonContainer,
    onPrimaryContainer = CrimsonOnContainer,
    secondary = AntiqueGoldSecondary,
    onSecondary = AntiqueGoldOnSecondary,
    secondaryContainer = AntiqueGoldContainer,
    onSecondaryContainer = AntiqueGoldOnContainer,
    tertiary = SlateTertiary,
    onTertiary = SlateOnTertiary,
    tertiaryContainer = SlateContainer,
    onTertiaryContainer = SlateOnContainer,
    background = ParchmentBackground,
    onBackground = InkOnBackground,
    surface = ParchmentSurface,
    onSurface = InkOnBackground,
    surfaceVariant = ParchmentSurfaceVariant,
    onSurfaceVariant = InkOnSurfaceVariant
)

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}
