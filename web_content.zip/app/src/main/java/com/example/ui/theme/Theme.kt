package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = SufiGoldBright,
    onPrimary = SufiMaroonDark,
    primaryContainer = SufiMaroonDark,
    onPrimaryContainer = SufiGoldBright,
    secondary = SufiGold,
    onSecondary = CandleNightDark,
    background = CandleNightDark,
    onBackground = CandleNightText,
    surface = CandleNightSurface,
    onSurface = CandleNightText,
    surfaceVariant = CandleNightSurfaceVariant,
    onSurfaceVariant = CandleNightMuted,
    outline = SufiMaroonLight,
    tertiary = CandleGlow
)

private val LightColorScheme = lightColorScheme(
    primary = SufiMaroon,
    onPrimary = ParchmentBase,
    primaryContainer = ParchmentSurfaceVariant,
    onPrimaryContainer = SufiMaroonDark,
    secondary = SufiGold,
    onSecondary = ParchmentBase,
    background = ParchmentBase,
    onBackground = SufiCharcoal,
    surface = ParchmentSurface,
    onSurface = SufiCharcoal,
    surfaceVariant = ParchmentSurfaceVariant,
    onSurfaceVariant = SufiMutedText,
    outline = ParchmentBorder,
    tertiary = SufiGoldBright
)

@Composable
fun SufiSomeSaysTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
