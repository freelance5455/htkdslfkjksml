package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NovaDarkColorScheme = darkColorScheme(
    primary = NovaElectricBlue,
    onPrimary = Color(0xFF001F25),
    primaryContainer = NovaUserBubbleStart,
    onPrimaryContainer = NovaTextPrimaryDark,
    secondary = NovaDeepViolet,
    onSecondary = Color.White,
    secondaryContainer = NovaSurfaceGlass,
    onSecondaryContainer = NovaSilver,
    tertiary = NovaVioletGlow,
    background = NovaObsidian,
    onBackground = NovaTextPrimaryDark,
    surface = NovaCharcoal,
    onSurface = NovaTextPrimaryDark,
    surfaceVariant = NovaSurfaceElevated,
    onSurfaceVariant = NovaTextSecondaryDark,
    outline = NovaBorderDark,
    error = Color(0xFFFF6B81)
)

private val NovaLightColorScheme = lightColorScheme(
    primary = NovaDeepVioletLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8E2FF),
    onPrimaryContainer = Color(0xFF1A0952),
    secondary = NovaElectricBlueLight,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDDF5F9),
    onSecondaryContainer = Color(0xFF00363E),
    tertiary = NovaDeepViolet,
    background = NovaLightBackground,
    onBackground = NovaTextPrimaryLight,
    surface = NovaLightSurface,
    onSurface = NovaTextPrimaryLight,
    surfaceVariant = NovaLightSurfaceVariant,
    onSurfaceVariant = NovaTextSecondaryLight,
    outline = NovaBorderLight,
    error = Color(0xFFD32F2F)
)

@Composable
fun NovaAITheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NovaDarkColorScheme else NovaLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NovaTypography,
        content = content
    )
}
