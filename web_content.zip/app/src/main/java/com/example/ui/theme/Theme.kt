package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryGold,
    onPrimary = OnPrimaryDark,
    secondary = SecondaryGreen,
    onSecondary = Color.Black,
    tertiary = TertiaryRed,
    onTertiary = Color.White,
    background = BackgroundDark,
    onBackground = MinecraftTextPrimary,
    surface = SurfaceDark,
    onSurface = MinecraftTextPrimary,
    surfaceVariant = MinecraftCardBg,
    onSurfaceVariant = MinecraftTextSecondary,
    outline = MinecraftCardBorder
)

private val LightColorScheme = DarkColorScheme // Gaming companion retains dark gaming theme

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
