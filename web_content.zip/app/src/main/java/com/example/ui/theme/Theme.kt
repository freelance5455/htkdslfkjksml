package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val FlamiDarkColorScheme = darkColorScheme(
    primary = EmberPrimary,
    onPrimary = EmberOnPrimary,
    primaryContainer = EmberPrimaryContainer,
    onPrimaryContainer = EmberOnPrimaryContainer,
    secondary = CyanSecondary,
    onSecondary = CyanOnSecondary,
    secondaryContainer = CyanSecondaryContainer,
    onSecondaryContainer = CyanOnSecondaryContainer,
    tertiary = GoldTertiary,
    onTertiary = GoldOnTertiary,
    background = ObsidianBackground,
    onBackground = SlateTextPrimary,
    surface = ObsidianSurface,
    onSurface = SlateTextPrimary,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = SlateTextSecondary,
    surfaceContainerHigh = ObsidianSurfaceHigh,
    outline = ObsidianOutline,
    error = ErrorCoral
)

private val FlamiLightColorScheme = lightColorScheme(
    primary = LightEmberPrimary,
    onPrimary = LightEmberOnPrimary,
    primaryContainer = LightEmberContainer,
    onPrimaryContainer = LightEmberOnContainer,
    secondary = LightCyanSecondary,
    onSecondary = LightCyanOnSecondary,
    secondaryContainer = LightCyanContainer,
    onSecondaryContainer = LightCyanOnContainer,
    tertiary = GoldTertiary,
    onTertiary = GoldOnTertiary,
    background = AlabasterBackground,
    onBackground = InkTextPrimary,
    surface = AlabasterSurface,
    onSurface = InkTextPrimary,
    surfaceVariant = AlabasterSurfaceVariant,
    onSurfaceVariant = InkTextSecondary,
    outline = AlabasterOutline,
    error = ErrorCoral
)

private val FlamiShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun FlamiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) FlamiDarkColorScheme else FlamiLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FlamiTypography,
        shapes = FlamiShapes,
        content = content
    )
}
