package com.example.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AestheticPinkColorScheme = lightColorScheme(
    primary = KawaiiPink,
    onPrimary = PureWhite,
    primaryContainer = PastelPinkContainer,
    onPrimaryContainer = DeepPink,

    secondary = AestheticBlack,
    onSecondary = PureWhite,
    secondaryContainer = CardGrey,
    onSecondaryContainer = AestheticBlack,

    tertiary = DarkGrey,
    onTertiary = PureWhite,
    tertiaryContainer = SoftGreyBg,
    onTertiaryContainer = AestheticBlack,

    background = PastelPinkBg,
    onBackground = AestheticBlack,

    surface = PureWhite,
    onSurface = AestheticBlack,
    surfaceVariant = PastelPinkContainer,
    onSurfaceVariant = TextGrey,

    outline = BorderGrey,
    outlineVariant = Color(0xFFF3E8EE),

    error = DeepPink,
    onError = PureWhite
)

// Subtle dark mode alternative staying in the pink/black/grey aesthetic
private val AestheticDarkColorScheme = darkColorScheme(
    primary = KawaiiPink,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFF4A152E),
    onPrimaryContainer = PastelPinkContainer,

    secondary = PastelPinkContainer,
    onSecondary = AestheticBlack,
    secondaryContainer = Color(0xFF27272A),
    onSecondaryContainer = PureWhite,

    tertiary = RoseTint,
    onTertiary = AestheticBlack,

    background = Color(0xFF141216),
    onBackground = PureWhite,

    surface = Color(0xFF1F1C24),
    onSurface = PureWhite,
    surfaceVariant = Color(0xFF2B2633),
    onSurfaceVariant = MutedGrey,

    outline = Color(0xFF3F3B4A),
    outlineVariant = Color(0xFF2E2938),

    error = DeepPink,
    onError = PureWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false, // Default to user's requested light pink, grey, white, black aesthetic
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) AestheticDarkColorScheme else AestheticPinkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
