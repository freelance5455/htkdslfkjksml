package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SuesaDarkColorScheme = darkColorScheme(
    primary = SuesaAccentWhite,
    onPrimary = Color(0xFF111111),
    primaryContainer = SuesaPurple,
    onPrimaryContainer = SuesaAccentWhite,
    secondary = SuesaPurple,
    onSecondary = SuesaAccentWhite,
    secondaryContainer = Color(0xFF241C2E),
    onSecondaryContainer = SuesaTextPrimary,
    tertiary = SuesaSuccess,
    background = SuesaBackground,
    onBackground = SuesaTextPrimary,
    surface = SuesaSurface,
    onSurface = SuesaTextPrimary,
    surfaceVariant = SuesaBubbleModel,
    onSurfaceVariant = SuesaTextSecondary,
    outline = SuesaBorder,
    error = SuesaDanger
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SuesaDarkColorScheme,
        typography = Typography,
        content = content
    )
}
