package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TacticalDarkColorScheme = darkColorScheme(
    primary = TacticalBlue,
    onPrimary = TextLight,
    secondary = GoldAccent,
    onSecondary = DarkNavyBg,
    tertiary = WarRed,
    onTertiary = TextLight,
    background = DarkNavyBg,
    onBackground = TextLight,
    surface = DarkSlateSurface,
    onSurface = TextLight,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = TextMuted
)

@Composable
fun StickWarTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TacticalDarkColorScheme,
        typography = Typography,
        content = content
    )
}
