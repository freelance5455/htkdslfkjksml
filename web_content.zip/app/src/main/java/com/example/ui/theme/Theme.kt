package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val KavoshColorScheme = darkColorScheme(
  primary = SageGreen,
  onPrimary = ForestDark,
  secondary = GoldenSun,
  onSecondary = ForestDark,
  background = ForestDark,
  onBackground = WarmCream,
  surface = ForestSurface,
  onSurface = WarmCream,
  onSurfaceVariant = MutedSage,
)

@Composable
fun KavoshHouseTheme(
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = KavoshColorScheme,
    typography = Typography,
    content = content,
  )
}
