package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = ArkDarkAccent,
    onPrimary = Color(0xFF0E1326),
    primaryContainer = Color(0xFF232C4B),
    onPrimaryContainer = Color(0xFFD9E1FF),
    secondary = Color(0xFF9E8CFF),
    onSecondary = Color(0xFF140F2E),
    secondaryContainer = Color(0xFF282442),
    onSecondaryContainer = Color(0xFFE7E2FF),
    tertiary = ArkSuccessDark,
    onTertiary = Color(0xFF042113),
    background = ArkDarkBackground,
    onBackground = ArkDarkInk,
    surface = ArkDarkSurface,
    onSurface = ArkDarkInk,
    surfaceVariant = ArkDarkSurfaceSecondary,
    onSurfaceVariant = ArkDarkInk2,
    outline = ArkDarkHairline,
    error = ArkErrorDark,
    onError = Color(0xFF2D0606)
)

private val LightColorScheme = lightColorScheme(
    primary = ArkLightAccent,
    onPrimary = Color.White,
    primaryContainer = ArkLightAccentSoft,
    onPrimaryContainer = Color(0xFF162C70),
    secondary = Color(0xFF5D5FEF),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEEEEFE),
    onSecondaryContainer = Color(0xFF201F6B),
    tertiary = ArkSuccessLight,
    onTertiary = Color.White,
    background = ArkLightBackground,
    onBackground = ArkLightInk,
    surface = ArkLightSurface,
    onSurface = ArkLightInk,
    surfaceVariant = ArkLightSurfaceSecondary,
    onSurfaceVariant = ArkLightInk2,
    outline = ArkLightHairline,
    error = ArkErrorLight,
    onError = Color.White
)

val ArkShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun ArkTheme(
    themeMode: String = "system",
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val colorScheme = if (useDark) DarkColorScheme else LightColorScheme
    val extendedColors = if (useDark) DarkArkColors else LightArkColors

    CompositionLocalProvider(LocalArkColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = ArkTypography,
            shapes = ArkShapes,
            content = content
        )
    }
}

object ArkThemeTokens {
    val colors: ArkExtendedColors
        @Composable get() = LocalArkColors.current
}
