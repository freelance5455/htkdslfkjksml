package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val SdTravelColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = BackgroundWhite,
    primaryContainer = NavyContainer,
    onPrimaryContainer = GoldBright,
    secondary = GoldSecondary,
    onSecondary = NavyPrimary,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = GoldDark,
    tertiary = NavyLight,
    onTertiary = BackgroundWhite,
    background = SurfaceLightGray,
    onBackground = TextPrimary,
    surface = BackgroundWhite,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceMuted,
    onSurfaceVariant = TextSecondary,
    outline = BorderLight,
    error = StatusCancelledFg,
    onError = BackgroundWhite,
    errorContainer = StatusCancelledBg,
    onErrorContainer = StatusCancelledFg,
)

private val SdTravelShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
    extraLarge = RoundedCornerShape(24.dp),
)

@Composable
fun SdTravelTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = SdTravelColorScheme,
            typography = SdTravelTypography,
            shapes = SdTravelShapes,
            content = content,
        )
    }
}
