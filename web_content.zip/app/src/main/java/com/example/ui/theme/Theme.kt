package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AlQaedLightColorScheme = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    primaryContainer = NavySurface,
    onPrimaryContainer = GoldAccent,
    secondary = GoldPrimary,
    onSecondary = NavyDeep,
    secondaryContainer = GoldContainer,
    onSecondaryContainer = GoldDark,
    tertiary = GoldAccent,
    onTertiary = NavyDeep,
    background = BackgroundLight,
    onBackground = TextDarkPrimary,
    surface = SurfaceLight,
    onSurface = TextDarkPrimary,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = TextDarkSecondary,
    outline = BorderLight
)

private val AlQaedDarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    onPrimary = NavyDeep,
    primaryContainer = NavyCard,
    onPrimaryContainer = Color.White,
    secondary = GoldPrimary,
    onSecondary = NavyDeep,
    secondaryContainer = NavySurface,
    onSecondaryContainer = GoldAccent,
    background = NavyDeep,
    onBackground = Color.White,
    surface = NavySurface,
    onSurface = Color.White,
    surfaceVariant = NavyCard,
    onSurfaceVariant = GoldLight,
    outline = NavyLight
)

@Composable
fun AlQaedTheme(
    darkTheme: Boolean = false, // Default to clean crisp Egyptian educational theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AlQaedDarkColorScheme else AlQaedLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
