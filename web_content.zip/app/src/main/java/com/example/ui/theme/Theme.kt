package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RaynoxDarkColorScheme = darkColorScheme(
    primary = RaynoxAmber,
    onPrimary = Color(0xFF0E1117),
    primaryContainer = RaynoxAmberContainer,
    onPrimaryContainer = RaynoxAmber,
    secondary = RaynoxAmberDark,
    onSecondary = Color.White,
    secondaryContainer = RaynoxUserBubbleDark,
    onSecondaryContainer = RaynoxTextPrimaryDark,
    tertiary = RaynoxCyanAccent,
    onTertiary = Color.Black,
    background = RaynoxCharcoalBg,
    onBackground = RaynoxTextPrimaryDark,
    surface = RaynoxSurfaceDark,
    onSurface = RaynoxTextPrimaryDark,
    surfaceVariant = RaynoxSurfaceElevated,
    onSurfaceVariant = RaynoxTextSecondaryDark,
    outline = RaynoxBorderDark,
    outlineVariant = Color(0xFF1F2330),
    error = RaynoxError,
    onError = Color.White,
    errorContainer = RaynoxErrorContainerDark,
    onErrorContainer = Color(0xFFFCA5A5)
)

private val RaynoxLightColorScheme = lightColorScheme(
    primary = RaynoxAmberDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF3C7),
    onPrimaryContainer = Color(0xFF78350F),
    secondary = RaynoxAmber,
    onSecondary = Color.Black,
    secondaryContainer = RaynoxUserBubbleLight,
    onSecondaryContainer = RaynoxTextPrimaryLight,
    tertiary = RaynoxIndigo,
    onTertiary = Color.White,
    background = RaynoxLightBg,
    onBackground = RaynoxTextPrimaryLight,
    surface = RaynoxSurfaceLight,
    onSurface = RaynoxTextPrimaryLight,
    surfaceVariant = RaynoxSurfaceElevatedLight,
    onSurfaceVariant = RaynoxTextSecondaryLight,
    outline = RaynoxBorderLight,
    outlineVariant = Color(0xFFE5E7EB),
    error = RaynoxError,
    onError = Color.White,
    errorContainer = RaynoxErrorContainerLight,
    onErrorContainer = Color(0xFF991B1B)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) RaynoxDarkColorScheme else RaynoxLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun RaynoxTheme(
    themeMode: String = "DARK",
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        "LIGHT" -> false
        "SYSTEM" -> isSystemInDarkTheme()
        else -> true
    }
    MyApplicationTheme(darkTheme = isDark, content = content)
}
