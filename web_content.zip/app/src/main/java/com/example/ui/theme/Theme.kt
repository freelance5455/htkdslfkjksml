package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.model.CalendarThemeOption

private val MonochromeWhiteBlackScheme = lightColorScheme(
    primary = PureBlack,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFFF5F5F5),
    onPrimaryContainer = PureBlack,
    secondary = Color(0xFF212121),
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFEEEEEE),
    onSecondaryContainer = PureBlack,
    tertiary = Color(0xFF333333),
    background = PureWhite,
    onBackground = PureBlack,
    surface = PureWhite,
    onSurface = PureBlack,
    surfaceVariant = SoftSurfaceGray,
    onSurfaceVariant = PureBlack,
    outline = LightBorderGray,
    outlineVariant = Color(0xFFEEEEEE)
)

private val KesarLightScheme = lightColorScheme(
    primary = KesarPrimary,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFFF5F5F5),
    onPrimaryContainer = PureBlack,
    secondary = KesarSecondary,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFEEEEEE),
    onSecondaryContainer = PureBlack,
    tertiary = KesarTertiary,
    background = PureWhite,
    onBackground = PureBlack,
    surface = PureWhite,
    onSurface = PureBlack,
    surfaceVariant = SoftSurfaceGray,
    onSurfaceVariant = PureBlack,
    outline = LightBorderGray,
    outlineVariant = Color(0xFFEEEEEE)
)

private val SindoorLightScheme = lightColorScheme(
    primary = SindoorPrimary,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFFF5F5F5),
    onPrimaryContainer = PureBlack,
    secondary = SindoorSecondary,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFEEEEEE),
    onSecondaryContainer = PureBlack,
    tertiary = SindoorTertiary,
    background = PureWhite,
    onBackground = PureBlack,
    surface = PureWhite,
    onSurface = PureBlack,
    surfaceVariant = SoftSurfaceGray,
    onSurfaceVariant = PureBlack,
    outline = LightBorderGray,
    outlineVariant = Color(0xFFEEEEEE)
)

private val MayurLightScheme = lightColorScheme(
    primary = MayurPrimary,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFFF5F5F5),
    onPrimaryContainer = PureBlack,
    secondary = MayurSecondary,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFEEEEEE),
    onSecondaryContainer = PureBlack,
    tertiary = MayurTertiary,
    background = PureWhite,
    onBackground = PureBlack,
    surface = PureWhite,
    onSurface = PureBlack,
    surfaceVariant = SoftSurfaceGray,
    onSurfaceVariant = PureBlack,
    outline = LightBorderGray,
    outlineVariant = Color(0xFFEEEEEE)
)

private val ChandanLightScheme = lightColorScheme(
    primary = ChandanPrimary,
    onPrimary = PureWhite,
    primaryContainer = Color(0xFFF5F5F5),
    onPrimaryContainer = PureBlack,
    secondary = ChandanSecondary,
    onSecondary = PureWhite,
    secondaryContainer = Color(0xFFEEEEEE),
    onSecondaryContainer = PureBlack,
    tertiary = ChandanTertiary,
    background = PureWhite,
    onBackground = PureBlack,
    surface = PureWhite,
    onSurface = PureBlack,
    surfaceVariant = SoftSurfaceGray,
    onSurfaceVariant = PureBlack,
    outline = LightBorderGray,
    outlineVariant = Color(0xFFEEEEEE)
)

fun getThemeColorScheme(theme: CalendarThemeOption, isSystemDark: Boolean): ColorScheme {
    return when (theme) {
        CalendarThemeOption.SHVET_SHYAM -> MonochromeWhiteBlackScheme
        CalendarThemeOption.KESAR_GOLD -> KesarLightScheme
        CalendarThemeOption.SINDOOR_MAROON -> SindoorLightScheme
        CalendarThemeOption.MAYUR_PEACOCK -> MayurLightScheme
        CalendarThemeOption.CHANDAN_LOTUS -> ChandanLightScheme
    }
}

@Composable
fun VedicCalendarTheme(
    selectedTheme: CalendarThemeOption = CalendarThemeOption.SHVET_SHYAM,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = getThemeColorScheme(selectedTheme, darkTheme)
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
