package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = IslamicEmerald,
  onPrimary = Color.White,
  primaryContainer = IslamicGreenDark,
  onPrimaryContainer = Color.White,
  secondary = IslamicGold,
  onSecondary = Color.Black,
  background = Color(0xFF102219),
  surface = Color(0xFF172C21),
  onBackground = Color(0xFFE8F5EE),
  onSurface = Color(0xFFE8F5EE)
)

private val LightColorScheme = lightColorScheme(
  primary = IslamicGreenPrimary,
  onPrimary = Color.White,
  primaryContainer = IslamicEmeraldLight,
  onPrimaryContainer = IslamicGreenDark,
  secondary = IslamicGold,
  onSecondary = Color.White,
  secondaryContainer = IslamicGoldLight,
  onSecondaryContainer = IslamicGoldDark,
  tertiary = IslamicEmerald,
  onTertiary = Color.White,
  background = BackgroundLight,
  surface = SurfaceLight,
  onBackground = TextPrimary,
  onSurface = TextPrimary,
  outline = BorderSubtle
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Keep consistent Islamic aesthetic
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}

