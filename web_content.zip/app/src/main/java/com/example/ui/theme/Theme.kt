package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.unit.dp
import com.example.core.ClassicThemeMode
import com.example.core.DesignSystem

val LocalFlamiDesign = compositionLocalOf { DesignSystem.FLAMI_ORIGINAL }

private val FlamiOriginalColorScheme = darkColorScheme(
    primary = OriginalVioletPrimary,
    onPrimary = OriginalOnVioletPrimary,
    primaryContainer = OriginalVioletContainer,
    onPrimaryContainer = OriginalOnVioletContainer,
    secondary = OriginalBurgundySecondary,
    onSecondary = OriginalOnBurgundy,
    secondaryContainer = OriginalBurgundyContainer,
    onSecondaryContainer = OriginalOnBurgundyContainer,
    tertiary = OriginalBurgundyDeep,
    onTertiary = OriginalOnBurgundy,
    background = OriginalObsidianBg,
    onBackground = OriginalTextPrimary,
    surface = OriginalObsidianSurface,
    onSurface = OriginalTextPrimary,
    surfaceVariant = OriginalSurfaceVariant,
    onSurfaceVariant = OriginalTextSecondary,
    outline = OriginalOutline,
    error = ErrorCoral
)

private val AnimeWorldColorScheme = darkColorScheme(
    primary = AnimeSakuraPrimary,
    onPrimary = AnimeOnSakura,
    primaryContainer = AnimeSakuraContainer,
    onPrimaryContainer = AnimeOnSakuraContainer,
    secondary = AnimeCyanSecondary,
    onSecondary = AnimeOnCyan,
    secondaryContainer = AnimeCyanContainer,
    onSecondaryContainer = AnimeOnCyanContainer,
    background = AnimeTwilightBg,
    onBackground = AnimeTextPrimary,
    surface = AnimeGlassSurface,
    onSurface = AnimeTextPrimary,
    surfaceVariant = AnimeGlassVariant,
    onSurfaceVariant = AnimeTextSecondary,
    outline = AnimeOutline,
    error = ErrorCoral
)

private val ClassicAiLightColorScheme = lightColorScheme(
    primary = ClassicLightPrimary,
    onPrimary = ClassicLightOnPrimary,
    primaryContainer = ClassicLightContainer,
    onPrimaryContainer = ClassicLightOnContainer,
    secondary = ClassicLightText,
    onSecondary = ClassicLightBg,
    secondaryContainer = ClassicLightVariant,
    onSecondaryContainer = ClassicLightText,
    background = ClassicLightBg,
    onBackground = ClassicLightText,
    surface = ClassicLightSurface,
    onSurface = ClassicLightText,
    surfaceVariant = ClassicLightVariant,
    onSurfaceVariant = ClassicLightTextSecondary,
    outline = ClassicLightOutline,
    error = ErrorCoral
)

private val ClassicAiDarkColorScheme = darkColorScheme(
    primary = ClassicDarkPrimary,
    onPrimary = ClassicDarkOnPrimary,
    primaryContainer = ClassicDarkContainer,
    onPrimaryContainer = ClassicDarkOnContainer,
    secondary = ClassicDarkText,
    onSecondary = ClassicDarkBg,
    secondaryContainer = ClassicDarkVariant,
    onSecondaryContainer = ClassicDarkText,
    background = ClassicDarkBg,
    onBackground = ClassicDarkText,
    surface = ClassicDarkSurface,
    onSurface = ClassicDarkText,
    surfaceVariant = ClassicDarkVariant,
    onSurfaceVariant = ClassicDarkTextSecondary,
    outline = ClassicDarkOutline,
    error = ErrorCoral
)

private val AnimeShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private val OriginalShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

private val ClassicShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp)
)

@Composable
fun FlamiTheme(
    designSystem: DesignSystem = DesignSystem.FLAMI_ORIGINAL,
    classicThemeMode: ClassicThemeMode = ClassicThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val colorScheme = when (designSystem) {
        DesignSystem.ANIME_WORLD -> AnimeWorldColorScheme
        DesignSystem.FLAMI_ORIGINAL -> FlamiOriginalColorScheme
        DesignSystem.CLASSIC_AI -> {
            val useDark = when (classicThemeMode) {
                ClassicThemeMode.DARK -> true
                ClassicThemeMode.LIGHT -> false
                ClassicThemeMode.SYSTEM -> systemDark
            }
            if (useDark) ClassicAiDarkColorScheme else ClassicAiLightColorScheme
        }
    }

    val shapes = when (designSystem) {
        DesignSystem.ANIME_WORLD -> AnimeShapes
        DesignSystem.FLAMI_ORIGINAL -> OriginalShapes
        DesignSystem.CLASSIC_AI -> ClassicShapes
    }

    CompositionLocalProvider(LocalFlamiDesign provides designSystem) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = FlamiTypography,
            shapes = shapes,
            content = content
        )
    }
}
