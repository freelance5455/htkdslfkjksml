package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val LightColorScheme = lightColorScheme(
    primary = NavyDeep,
    onPrimary = PureWhite,
    primaryContainer = NavyContainer,
    onPrimaryContainer = NavyDeep,
    secondary = OrangeBrand,
    onSecondary = PureWhite,
    secondaryContainer = OrangeContainer,
    onSecondaryContainer = OrangeDark,
    tertiary = VerifiedGreen,
    onTertiary = PureWhite,
    tertiaryContainer = VerifiedGreenContainer,
    onTertiaryContainer = DarkGrey,
    background = OffWhite,
    onBackground = DarkGrey,
    surface = SurfaceCardLight,
    onSurface = DarkGrey,
    surfaceVariant = SurfaceVariantLight,
    onSurfaceVariant = CharcoalGrey,
    outline = BorderGrey,
    error = ErrorRed,
    onError = PureWhite,
    errorContainer = ErrorRedContainer,
    onErrorContainer = ErrorRed
)

private val DarkColorScheme = darkColorScheme(
    primary = OrangeBrand,
    onPrimary = PureWhite,
    primaryContainer = NavyElevated,
    onPrimaryContainer = PureWhite,
    secondary = OrangeBright,
    onSecondary = NavyDeep,
    secondaryContainer = NavyMuted,
    onSecondaryContainer = OrangeContainer,
    tertiary = VerifiedGreen,
    onTertiary = PureWhite,
    background = NavyDeep,
    onBackground = PureWhite,
    surface = NavyElevated,
    onSurface = PureWhite,
    surfaceVariant = NavyMuted,
    onSurfaceVariant = BorderGrey,
    outline = SlateGrey,
    error = ErrorRed,
    onError = PureWhite
)

val SmartJonesShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SmartJonesTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = SmartJonesTypography,
        shapes = SmartJonesShapes,
        content = content
    )
}
