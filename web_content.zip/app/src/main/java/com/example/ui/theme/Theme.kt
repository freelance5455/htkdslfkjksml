package com.example.ui.theme

import android.app.Activity
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

enum class AppThemeMode(val label: String) {
  OLED_DARK("OLED Dark"),
  AETHER_DARK("Slate Dark"),
  LIGHT("Light"),
}

@Immutable
data class AetherColors(
  val background: Color,
  val surface: Color,
  val surfaceElevated: Color,
  val surfaceHighest: Color,
  val accent: Color,
  val accentPressed: Color,
  val lavender: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val borderSubtle: Color,
  val borderElevated: Color,
  val error: Color,
  val isDark: Boolean,
)

private val OledAetherColors =
  AetherColors(
    background = AetherBackgroundOled,
    surface = AetherSurface,
    surfaceElevated = AetherSurfaceElevated,
    surfaceHighest = AetherSurfaceHighest,
    accent = AetherViolet,
    accentPressed = AetherVioletPressed,
    lavender = AetherLavender,
    textPrimary = AetherTextPrimary,
    textSecondary = AetherTextSecondary,
    borderSubtle = AetherBorderSubtle,
    borderElevated = AetherBorderElevated,
    error = AetherError,
    isDark = true,
  )

private val SlateAetherColors =
  OledAetherColors.copy(background = AetherBackgroundSlate)

private val LightAetherColors =
  AetherColors(
    background = LightBackground,
    surface = LightSurface,
    surfaceElevated = LightSurfaceElevated,
    surfaceHighest = LightSurfaceHighest,
    accent = LightViolet,
    accentPressed = AetherVioletPressed,
    lavender = LightLavender,
    textPrimary = LightTextPrimary,
    textSecondary = LightTextSecondary,
    borderSubtle = LightBorderSubtle,
    borderElevated = LightBorderElevated,
    error = LightError,
    isDark = false,
  )

val LocalAetherColors = staticCompositionLocalOf { OledAetherColors }

object AetherTheme {
  val colors: AetherColors
    @Composable get() = LocalAetherColors.current
}

@Composable
fun AetherCalculatorTheme(
  themeMode: AppThemeMode = AppThemeMode.OLED_DARK,
  content: @Composable () -> Unit,
) {
  val aetherColors =
    when (themeMode) {
      AppThemeMode.OLED_DARK -> OledAetherColors
      AppThemeMode.AETHER_DARK -> SlateAetherColors
      AppThemeMode.LIGHT -> LightAetherColors
    }

  val materialScheme =
    if (aetherColors.isDark) {
      darkColorScheme(
        primary = aetherColors.accent,
        onPrimary = AetherTextPrimary,
        primaryContainer = aetherColors.surfaceElevated,
        onPrimaryContainer = aetherColors.lavender,
        secondary = aetherColors.lavender,
        onSecondary = AetherBackgroundOled,
        secondaryContainer = aetherColors.surfaceElevated,
        onSecondaryContainer = aetherColors.textPrimary,
        background = aetherColors.background,
        onBackground = aetherColors.textPrimary,
        surface = aetherColors.surface,
        onSurface = aetherColors.textPrimary,
        surfaceVariant = aetherColors.surfaceElevated,
        onSurfaceVariant = aetherColors.textSecondary,
        outline = aetherColors.borderElevated,
        outlineVariant = aetherColors.borderSubtle,
        error = aetherColors.error,
        onError = Color(0xFF690005),
      )
    } else {
      lightColorScheme(
        primary = aetherColors.accent,
        onPrimary = Color.White,
        primaryContainer = Color(0xFFEDE9FE),
        onPrimaryContainer = aetherColors.lavender,
        secondary = aetherColors.lavender,
        onSecondary = Color.White,
        secondaryContainer = aetherColors.surfaceElevated,
        onSecondaryContainer = aetherColors.textPrimary,
        background = aetherColors.background,
        onBackground = aetherColors.textPrimary,
        surface = aetherColors.surface,
        onSurface = aetherColors.textPrimary,
        surfaceVariant = aetherColors.surfaceElevated,
        onSurfaceVariant = aetherColors.textSecondary,
        outline = aetherColors.borderElevated,
        outlineVariant = aetherColors.borderSubtle,
        error = aetherColors.error,
        onError = Color.White,
      )
    }

  val view = LocalView.current
  if (!view.isInEditMode) {
    LaunchedEffect(aetherColors.isDark) {
      val activity = view.context as? ComponentActivity
      if (activity != null) {
        val barStyle =
          if (aetherColors.isDark) {
            SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
          } else {
            SystemBarStyle.light(
              android.graphics.Color.TRANSPARENT,
              android.graphics.Color.TRANSPARENT,
            )
          }
        activity.enableEdgeToEdge(statusBarStyle = barStyle, navigationBarStyle = barStyle)
      } else {
        val window = (view.context as? Activity)?.window
        if (window != null) {
          val insetsController = WindowCompat.getInsetsController(window, view)
          insetsController.isAppearanceLightStatusBars = !aetherColors.isDark
          insetsController.isAppearanceLightNavigationBars = !aetherColors.isDark
        }
      }
    }
  }

  CompositionLocalProvider(LocalAetherColors provides aetherColors) {
    MaterialTheme(
      colorScheme = materialScheme,
      typography = AetherTypography,
      content = content,
    )
  }
}
