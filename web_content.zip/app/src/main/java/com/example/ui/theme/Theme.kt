package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

@Composable
fun MyApplicationTheme(
    appColorTheme: AppColorTheme = AppColorTheme.NEON_CYAN,
    isDarkMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = appColorTheme.toColorScheme(isDarkMode = isDarkMode)
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
