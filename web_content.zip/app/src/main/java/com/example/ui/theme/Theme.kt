package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import com.example.data.model.AppSettingsEntity

@Composable
fun DailyStudyTheme(
    themeMode: String = AppSettingsEntity.THEME_NORMAL,
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val effectiveKey = if (themeMode != AppSettingsEntity.THEME_NORMAL) {
        themeMode
    } else if (darkTheme) {
        AppSettingsEntity.THEME_DARK
    } else {
        AppSettingsEntity.THEME_NORMAL
    }

    val themeDef = AppThemes.getTheme(effectiveKey)

    val customShapes = Shapes(
        extraSmall = RoundedCornerShape(4.dp),
        small = RoundedCornerShape(8.dp),
        medium = themeDef.cardShape,
        large = themeDef.cardShape,
        extraLarge = RoundedCornerShape(28.dp)
    )

    MaterialTheme(
        colorScheme = themeDef.colorScheme,
        typography = themeDef.typography,
        shapes = customShapes,
        content = content
    )
}
