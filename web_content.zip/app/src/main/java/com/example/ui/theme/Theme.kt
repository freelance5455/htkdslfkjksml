package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NoirColorScheme = darkColorScheme(
    primary = CrispWhite,
    onPrimary = ObsidianBlack,
    primaryContainer = ElevatedGraphite,
    onPrimaryContainer = PureIvory,
    secondary = ChampagneGold,
    onSecondary = ObsidianBlack,
    secondaryContainer = Color(0xFF2B2412),
    onSecondaryContainer = SoftGold,
    tertiary = EmeraldVerified,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = PureIvory,
    surface = Color(0xFF141419),
    onSurface = PureIvory,
    surfaceVariant = ElevatedGraphite,
    onSurfaceVariant = MutedPlatinum,
    outline = SubtleSlate,
    error = CrimsonError,
    onError = CrispWhite
)

private val EditorialLightColorScheme = lightColorScheme(
    primary = ObsidianBlack,
    onPrimary = CrispWhite,
    primaryContainer = Color(0xFFEBEAE4),
    onPrimaryContainer = ObsidianBlack,
    secondary = Color(0xFF9C7A1C),
    onSecondary = CrispWhite,
    secondaryContainer = Color(0xFFF6EED5),
    onSecondaryContainer = ObsidianBlack,
    tertiary = Color(0xFF198754),
    onTertiary = CrispWhite,
    background = PureIvory,
    onBackground = ObsidianBlack,
    surface = CrispWhite,
    onSurface = ObsidianBlack,
    surfaceVariant = Color(0xFFF0EFEA),
    onSurfaceVariant = Color(0xFF52525E),
    outline = Color(0xFFD5D4CE),
    error = Color(0xFFD32F2F),
    onError = CrispWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to sleek black & white noir luxury aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NoirColorScheme else EditorialLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
