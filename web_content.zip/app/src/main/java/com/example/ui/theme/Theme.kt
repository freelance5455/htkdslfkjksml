package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MotionForgeDarkColorScheme =
  darkColorScheme(
    primary = ElectricOrange,
    onPrimary = Color.White,
    secondary = AmberGlow,
    onSecondary = Color.Black,
    tertiary = AmberGlow,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = OutlineColor
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = MotionForgeDarkColorScheme,
    typography = Typography,
    content = content
  )
}
