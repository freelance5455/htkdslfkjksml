package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = Color(0xFF00222F),
    primaryContainer = Color(0xFF00384D),
    onPrimaryContainer = CyanAccent,
    secondary = BullGreen,
    onSecondary = Color(0xFF002214),
    secondaryContainer = Color(0xFF003823),
    onSecondaryContainer = BullGreen,
    tertiary = WarningAmber,
    onTertiary = Color(0xFF261D00),
    error = BearRed,
    onError = Color.White,
    background = BackgroundDark,
    onBackground = TextPrimary,
    surface = SurfaceDark,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = BorderFocused
)

@Composable
fun IQTradeProTheme(
    darkTheme: Boolean = true, // Professional trading apps default to rich dark mode
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
