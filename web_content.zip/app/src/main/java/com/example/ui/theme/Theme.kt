package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val IgnisDarkColorScheme = darkColorScheme(
    primary = IgnisOrangePrimary,
    onPrimary = Color.White,
    primaryContainer = IgnisOrangeDark,
    onPrimaryContainer = Color.White,
    secondary = IgnisTechBlue,
    onSecondary = Color.White,
    secondaryContainer = Slate800,
    onSecondaryContainer = IgnisTechBlueLight,
    tertiary = IgnisAmber,
    background = Slate900,
    onBackground = Slate50,
    surface = SurfaceDark,
    onSurface = Slate50,
    surfaceVariant = SurfaceContainerDark,
    onSurfaceVariant = Slate400,
    outline = Slate700
)

private val IgnisLightColorScheme = lightColorScheme(
    primary = IgnisOrangePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFECE5),
    onPrimaryContainer = IgnisOrangeDark,
    secondary = IgnisTechBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    tertiary = IgnisAmber,
    background = Slate50,
    onBackground = Slate900,
    surface = SurfaceLight,
    onSurface = Slate900,
    surfaceVariant = Slate100,
    onSurfaceVariant = Slate600,
    outline = Slate200
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep Ignis signature flame brand styling consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> IgnisDarkColorScheme
        else -> IgnisLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
