package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private val MerkopLightColorScheme = lightColorScheme(
    primary = MerkopOrange,
    onPrimary = MerkopWhite,
    primaryContainer = MerkopOrangeContainer,
    onPrimaryContainer = MerkopOrangeDeep,
    secondary = MerkopOrangeBright,
    onSecondary = MerkopWhite,
    secondaryContainer = MerkopOrangeSoft,
    onSecondaryContainer = MerkopInk,
    tertiary = MerkopOrangeDeep,
    onTertiary = MerkopWhite,
    background = MerkopWarmWhite,
    onBackground = MerkopInk,
    surface = MerkopWhite,
    onSurface = MerkopInk,
    surfaceVariant = MerkopSurfaceLow,
    onSurfaceVariant = MerkopInkMuted,
    outline = MerkopOrangeBorder,
    outlineVariant = MerkopOrangeSoft,
    error = MerkopError,
    onError = MerkopWhite,
    errorContainer = MerkopErrorContainer,
    onErrorContainer = MerkopError
)

private val MerkopDarkColorScheme = darkColorScheme(
    primary = MerkopOrangeBright,
    onPrimary = MerkopWhite,
    primaryContainer = MerkopDarkOrangeContainer,
    onPrimaryContainer = MerkopOrangeContainer,
    secondary = MerkopOrange,
    onSecondary = MerkopWhite,
    secondaryContainer = MerkopDarkSurfaceHigh,
    onSecondaryContainer = MerkopDarkInk,
    tertiary = MerkopOrangeContainer,
    onTertiary = MerkopDarkBackground,
    background = MerkopDarkBackground,
    onBackground = MerkopDarkInk,
    surface = MerkopDarkSurface,
    onSurface = MerkopDarkInk,
    surfaceVariant = MerkopDarkSurfaceHigh,
    onSurfaceVariant = MerkopDarkInkMuted,
    outline = MerkopOrangeDeep,
    outlineVariant = MerkopDarkSurfaceHigh,
    error = MerkopErrorContainer,
    onError = MerkopError
)

val MerkopShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MerkopTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> MerkopDarkColorScheme
        else -> MerkopLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        shapes = MerkopShapes,
        content = content
    )
}
