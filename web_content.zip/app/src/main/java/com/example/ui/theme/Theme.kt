package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val OneUiShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun MyFilesTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    amoledBlack: Boolean = false,
    accentPreset: AccentPreset = AccentPreset.BLUE,
    dynamicSeedArgb: Int = 0xFF0381FE.toInt(),
    animationMode: AnimationMode = AnimationMode.MEDIUM,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ThemeMode.SYSTEM -> systemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val (primaryColor, primaryContainerColor) = remember(accentPreset, dynamicSeedArgb, useDark) {
        if (accentPreset == AccentPreset.DYNAMIC_IMAGE) {
            DynamicImageColorExtractor.deriveDynamicColors(dynamicSeedArgb, useDark)
        } else {
            if (useDark) {
                accentPreset.primaryDark to accentPreset.containerDark
            } else {
                accentPreset.primaryLight to accentPreset.containerLight
            }
        }
    }

    val colorScheme = if (useDark) {
        val bg = if (amoledBlack) Color(0xFF000000) else Color(0xFF101114)
        val surfaceCard = if (amoledBlack) Color(0xFF121316) else Color(0xFF1B1C21)
        val surfaceElevated = if (amoledBlack) Color(0xFF1A1C21) else Color(0xFF24262D)
        darkColorScheme(
            primary = primaryColor,
            onPrimary = Color(0xFF041326),
            primaryContainer = primaryContainerColor,
            onPrimaryContainer = Color(0xFFEAF3FF),
            secondary = primaryColor.copy(alpha = 0.85f),
            onSecondary = Color(0xFF081420),
            secondaryContainer = surfaceElevated,
            onSecondaryContainer = Color(0xFFE3E5EC),
            background = bg,
            onBackground = Color(0xFFF3F4F8),
            surface = surfaceCard,
            onSurface = Color(0xFFF3F4F8),
            surfaceVariant = surfaceElevated,
            onSurfaceVariant = Color(0xFFA2A6B3),
            outline = Color(0xFF343742),
            outlineVariant = Color(0xFF262932),
            error = Color(0xFFFF6B6B)
        )
    } else {
        lightColorScheme(
            primary = primaryColor,
            onPrimary = Color.White,
            primaryContainer = primaryContainerColor,
            onPrimaryContainer = Color(0xFF071B36),
            secondary = primaryColor.copy(alpha = 0.88f),
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFECEEF4),
            onSecondaryContainer = Color(0xFF1E222B),
            background = Color(0xFFF4F5F9),
            onBackground = Color(0xFF13151A),
            surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF13151A),
            surfaceVariant = Color(0xFFECEEF4),
            onSurfaceVariant = Color(0xFF5E6370),
            outline = Color(0xFFD5D8E2),
            outlineVariant = Color(0xFFE4E6EE),
            error = Color(0xFFD32F2F)
        )
    }

    val animationSpecs = remember(animationMode) { AppAnimationSpecs(animationMode) }

    CompositionLocalProvider(LocalAnimationSpecs provides animationSpecs) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            shapes = OneUiShapes,
            content = content
        )
    }
}
