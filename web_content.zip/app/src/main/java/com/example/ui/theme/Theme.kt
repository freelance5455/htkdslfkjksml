package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ZingColorScheme = darkColorScheme(
    primary = ZingNeonPink,
    onPrimary = Color.White,
    primaryContainer = ZingElectricViolet,
    onPrimaryContainer = Color.White,
    secondary = ZingCyan,
    onSecondary = ZingBlack,
    secondaryContainer = ZingCardSurface,
    onSecondaryContainer = ZingTextPrimary,
    tertiary = ZingGold,
    onTertiary = ZingBlack,
    background = ZingBlack,
    onBackground = ZingTextPrimary,
    surface = ZingDarkSurface,
    onSurface = ZingTextPrimary,
    surfaceVariant = ZingCardSurface,
    onSurfaceVariant = ZingTextSecondary,
    outline = ZingBorder
)

@Composable
fun ZingTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ZingColorScheme,
        typography = Typography,
        content = content
    )
}
