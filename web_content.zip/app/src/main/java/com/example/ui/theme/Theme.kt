package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val BeyazMinimalColorScheme = lightColorScheme(
    primary = DeepInk,
    onPrimary = PureWhite,
    primaryContainer = AlabasterSurface,
    onPrimaryContainer = DeepInk,
    secondary = GeminiBlue,
    onSecondary = PureWhite,
    secondaryContainer = GeminiSoftBg,
    onSecondaryContainer = DeepInk,
    tertiary = VaultEmerald,
    onTertiary = PureWhite,
    tertiaryContainer = VaultEmeraldSoft,
    onTertiaryContainer = DeepInk,
    background = PureWhite,
    onBackground = DeepInk,
    surface = PureWhite,
    onSurface = DeepInk,
    surfaceVariant = AlabasterSurface,
    onSurfaceVariant = SlateSecondary,
    outline = HairlineBorder,
    outlineVariant = SoftGraySurface,
    error = DangerRose,
    onError = PureWhite,
    errorContainer = DangerRoseSoft,
    onErrorContainer = DangerRose
)

@Composable
fun BeyazBrowserTheme(
    content: @Composable () -> Unit
) {
    // Deliberately enforces the crisp, pure-white minimalist theme requested by the user
    MaterialTheme(
        colorScheme = BeyazMinimalColorScheme,
        typography = Typography,
        content = content
    )
}
