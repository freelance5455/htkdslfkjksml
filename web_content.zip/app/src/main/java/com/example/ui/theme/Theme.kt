package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CyberDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF002028),
    primaryContainer = Color(0xFF004D59),
    onPrimaryContainer = Color(0xFF80F2FF),
    secondary = NeonPurple,
    onSecondary = Color(0xFF28003A),
    secondaryContainer = Color(0xFF5A0082),
    onSecondaryContainer = Color(0xFFF0B3FF),
    tertiary = NeonBlue,
    onTertiary = Color.White,
    background = CyberBackground,
    onBackground = TextPrimary,
    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = CyberBorder,
    error = NeonRed,
    onError = Color.White
)

@Composable
fun TKLinkTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // The cybersecurity lab is intentionally designed with a premium dark cyber aesthetic
    MaterialTheme(
        colorScheme = CyberDarkColorScheme,
        typography = Typography,
        content = content
    )
}
