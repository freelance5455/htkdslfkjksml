package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val JobyLightColorScheme = lightColorScheme(
  primary = TealPrimary,
  onPrimary = Color.White,
  primaryContainer = TealContainerLight,
  onPrimaryContainer = OnTealContainerLight,
  secondary = SaffronSecondary,
  onSecondary = Color.White,
  secondaryContainer = SaffronContainerLight,
  onSecondaryContainer = OnSaffronContainerLight,
  tertiary = EmeraldTertiary,
  onTertiary = Color.White,
  tertiaryContainer = EmeraldContainerLight,
  onTertiaryContainer = OnEmeraldContainerLight,
  background = SurfaceWarmLight,
  onBackground = OnSurfaceLight,
  surface = SurfaceCardLight,
  onSurface = OnSurfaceLight,
  surfaceVariant = SurfaceVariantLight,
  onSurfaceVariant = OnSurfaceMutedLight,
  outline = OutlineLight,
  error = ErrorRed,
  onError = Color.White,
  errorContainer = ErrorContainerLight,
  onErrorContainer = Color(0xFF410002)
)

private val JobyDarkColorScheme = darkColorScheme(
  primary = TealPrimaryDark,
  onPrimary = OnTealPrimaryDark,
  primaryContainer = TealContainerDark,
  onPrimaryContainer = OnTealContainerDark,
  secondary = SaffronSecondaryDark,
  onSecondary = OnSaffronSecondaryDark,
  secondaryContainer = SaffronContainerDark,
  onSecondaryContainer = OnSaffronContainerDark,
  tertiary = EmeraldTertiaryDark,
  onTertiary = OnEmeraldTertiaryDark,
  tertiaryContainer = EmeraldContainerDark,
  onTertiaryContainer = OnEmeraldContainerDark,
  background = SurfaceDark,
  onBackground = OnSurfaceDark,
  surface = SurfaceCardDark,
  onSurface = OnSurfaceDark,
  surfaceVariant = SurfaceVariantDark,
  onSurfaceVariant = OnSurfaceMutedDark,
  outline = OutlineDark,
  error = ErrorRedDark,
  onError = Color(0xFF690005),
  errorContainer = ErrorContainerDark,
  onErrorContainer = ErrorRedDark
)

val JobyShapes = Shapes(
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(16.dp),
  large = RoundedCornerShape(22.dp),
  extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun JobyTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) JobyDarkColorScheme else JobyLightColorScheme
  MaterialTheme(
    colorScheme = colorScheme,
    typography = JobyTypography,
    shapes = JobyShapes,
    content = content
  )
}
