package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = XtraCyanPrimary,
    onPrimary = Color(0xFF00363D),
    primaryContainer = Color(0xFF004F58),
    onPrimaryContainer = Color(0xFF97F0FF),

    secondary = XtraElectricBlue,
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF003258),
    onSecondaryContainer = Color(0xFFCCE5FF),

    tertiary = XtraPurpleAccent,
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFF4C1D95),
    onTertiaryContainer = Color(0xFFE9D5FF),

    background = XtraDarkNavyBg,
    onBackground = XtraTextHigh,
    surface = XtraSurfaceDark,
    onSurface = XtraTextHigh,
    surfaceVariant = XtraCardDark,
    onSurfaceVariant = XtraTextMed,
    outline = XtraCardBorder,
    error = XtraAlertRed,
    onError = Color.White
)

private val LightColorScheme = DarkColorScheme // XTRA uses high-tech cyber dark theme by design

@Composable
fun XtraTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    XtraTheme(content = content)
}
