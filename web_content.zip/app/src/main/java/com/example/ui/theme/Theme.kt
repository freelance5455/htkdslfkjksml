package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val NexusDarkColorScheme = darkColorScheme(
    primary = NexusCyan,
    onPrimary = NexusTextPrimary,
    primaryContainer = NexusCyanDark,
    onPrimaryContainer = NexusVioletLight,

    secondary = NexusViolet,
    onSecondary = NexusTextPrimary,
    secondaryContainer = NexusVioletDark,
    onSecondaryContainer = NexusVioletLight,

    tertiary = NexusEmerald,
    onTertiary = NexusBackground,
    tertiaryContainer = NexusEmeraldDim,
    onTertiaryContainer = NexusVioletLight,

    background = NexusBackground,
    onBackground = NexusTextPrimary,

    surface = NexusSurface,
    onSurface = NexusTextPrimary,
    surfaceVariant = NexusSurfaceVariant,
    onSurfaceVariant = NexusTextSecondary,

    outline = NexusBorder,
    outlineVariant = NexusBorder,
    error = NexusRose,
    onError = NexusTextPrimary
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                @Suppress("DEPRECATION")
                window.statusBarColor = NexusBackground.toArgb()
                @Suppress("DEPRECATION")
                window.navigationBarColor = NexusBackground.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = NexusDarkColorScheme,
        typography = Typography,
        content = content
    )
}
