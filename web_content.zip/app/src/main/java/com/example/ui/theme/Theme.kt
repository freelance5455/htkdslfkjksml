package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = VelvetCyan,
    onPrimary = Color(0xFF062030),
    primaryContainer = VelvetCyanContainer,
    onPrimaryContainer = Color(0xFFE0F2FE),
    secondary = VelvetCoral,
    onSecondary = Color(0xFF2F0510),
    secondaryContainer = VelvetCoralContainer,
    onSecondaryContainer = Color(0xFFFFE4E6),
    tertiary = VelvetIndigo,
    background = VelvetMidnightBg,
    onBackground = Color(0xFFF1F5F9),
    surface = VelvetMidnightSurface,
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = VelvetMidnightSurfaceElevated,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF2D364D)
)

private val LightColorScheme = lightColorScheme(
    primary = VelvetPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0C4A6E),
    secondary = VelvetSecondaryLight,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE4E6),
    onSecondaryContainer = Color(0xFF881337),
    tertiary = Color(0xFF4F46E5),
    background = VelvetLightBg,
    onBackground = VelvetOnLight,
    surface = VelvetLightSurface,
    onSurface = VelvetOnLight,
    surfaceVariant = VelvetLightSurfaceVariant,
    onSurfaceVariant = VelvetOnLightMuted,
    outline = Color(0xFFCBD5E1)
)

@Composable
fun VelvetKeyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
