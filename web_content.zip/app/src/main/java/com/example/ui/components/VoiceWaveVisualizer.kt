package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDim
import com.example.ui.theme.NexusViolet
import com.example.ui.theme.NexusVioletLight
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun VoiceWaveVisualizer(
    isActive: Boolean,
    amplitude: Float = 0f,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    barCount: Int = 24
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_phase")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val targetAmp = if (isActive) (amplitude.coerceIn(0.1f, 1f)) else 0.05f
    val smoothAmp = remember { Animatable(0.05f) }

    LaunchedEffect(targetAmp) {
        smoothAmp.animateTo(
            targetValue = targetAmp,
            animationSpec = tween(durationMillis = 100, easing = LinearEasing)
        )
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val totalWidth = size.width
        val canvasHeight = size.height
        val barWidth = (totalWidth / (barCount * 1.8f)).coerceAtLeast(3.dp.toPx())
        val spacing = (totalWidth - (barCount * barWidth)) / (barCount + 1)
        val centerY = canvasHeight / 2f

        for (i in 0 until barCount) {
            val progress = i.toFloat() / barCount
            val envelope = sin(progress * Math.PI).toFloat()
            val wave = abs(sin((progress * 4f) + phase))
            val dynamicFactor = if (isActive) {
                (0.2f + wave * 0.8f) * smoothAmp.value * envelope
            } else {
                0.06f * envelope
            }

            val barHeight = (canvasHeight * dynamicFactor * 0.9f).coerceIn(4.dp.toPx(), canvasHeight)
            val left = spacing + i * (barWidth + spacing)
            val top = centerY - (barHeight / 2f)

            val barBrush = Brush.verticalGradient(
                colors = listOf(
                    if (isActive) NexusVioletLight else NexusCyanDim,
                    NexusCyan,
                    NexusViolet
                ),
                startY = top,
                endY = top + barHeight
            )

            drawRoundRect(
                brush = barBrush,
                topLeft = Offset(left, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
