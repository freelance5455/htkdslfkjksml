package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Greens (Health, Vitality, Nutrition)
val EmeraldGreenPrimary = Color(0xFF1E7E34)
val EmeraldGreenDark = Color(0xFF155724)
val EmeraldGreenLight = Color(0xFFE8F5E9)

// Vibrant Accents (Calories, Flame, Energy)
val CalorieOrange = Color(0xFFFF6D00)
val CalorieOrangeLight = Color(0xFFFFF3E0)
val CalorieRed = Color(0xFFD32F2F)

// Nutrients Colors
val ProteinBlue = Color(0xFF1976D2)
val ProteinBlueLight = Color(0xFFE3F2FD)
val CarbsAmber = Color(0xFFFFA000)
val CarbsAmberLight = Color(0xFFFFF8E1)
val FatPurple = Color(0xFF7B1FA2)
val FatPurpleLight = Color(0xFFF3E5F5)
val FiberGreen = Color(0xFF388E3C)

// Neutral & Backgrounds
val SurfaceLight = Color(0xFFFAFAFA)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF121413)
val SurfaceCardDark = Color(0xFF1C201E)

val TextPrimaryLight = Color(0xFF1A1C1A)
val TextSecondaryLight = Color(0xFF555F56)
val TextPrimaryDark = Color(0xFFE1E3DE)
val TextSecondaryDark = Color(0xFFA4AAA1)
