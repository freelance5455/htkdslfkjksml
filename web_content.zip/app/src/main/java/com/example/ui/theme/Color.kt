package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Islamic Modern Theme Colors
val IslamicGreenPrimary = Color(0xFF0D5C3A)
val IslamicGreenDark = Color(0xFF093E26)
val IslamicGreenLight = Color(0xFF1E8254)
val IslamicEmerald = Color(0xFF2ECC71)
val IslamicEmeraldLight = Color(0xFFE8F6ED)

val IslamicGold = Color(0xFFD4AF37)
val IslamicGoldDark = Color(0xFFB38F24)
val IslamicGoldLight = Color(0xFFFFF9E6)

val BackgroundLight = Color(0xFFF6FAF7)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceCard = Color(0xFFFFFFFF)

val TextPrimary = Color(0xFF1B2E24)
val TextSecondary = Color(0xFF536B5E)
val TextTertiary = Color(0xFF88A093)

val BorderSubtle = Color(0xFFE1ECE5)
val ShadowSubtle = Color(0x1A0D5C3A)

val ExpenseRed = Color(0xFFD32F2F)
val ExpenseRedLight = Color(0xFFFFEBEE)
val IncomeGreen = Color(0xFF2E7D32)
val IncomeGreenLight = Color(0xFFE8F5E9)
val DepositBlue = Color(0xFF0277BD)
val DepositBlueLight = Color(0xFFE1F5FE)
val LoanOrange = Color(0xFFE65100)
val LoanOrangeLight = Color(0xFFFFF3E0)
val RepaidPurple = Color(0xFF6A1B9A)
val RepaidPurpleLight = Color(0xFFF3E5F5)

