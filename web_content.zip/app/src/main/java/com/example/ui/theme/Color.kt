package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Islamic Golden Accents
val GoldPrimary = Color(0xFFE5A93C)
val GoldLight = Color(0xFFFCD34D)
val GoldDark = Color(0xFFB45309)
val AmberGlow = Color(0xFFF59E0B)

// Emerald & Islamic Green Tones
val EmeraldDark = Color(0xFF064E3B)
val EmeraldMedium = Color(0xFF047857)
val EmeraldLight = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF062E25)

// Deep Midnight Dark Canvas (Theme)
val MidnightBackground = Color(0xFF070B14)
val MidnightCard = Color(0xFF0E1626)
val MidnightCardSecondary = Color(0xFF141F36)
val MidnightBorder = Color(0xFF1E2E4E)
val MidnightTextPrimary = Color(0xFFF8FAFC)
val MidnightTextSecondary = Color(0xFF94A3B8)

// Light Theme Tones
val AlabasterBackground = Color(0xFFF4F6F9)
val AlabasterSurface = Color(0xFFFFFFFF)
val AlabasterCard = Color(0xFFF1F5F9)
val AlabasterBorder = Color(0xFFCBD5E1)
val AlabasterTextPrimary = Color(0xFF0F172A)
val AlabasterTextSecondary = Color(0xFF475569)

// Accent Status
val ActivePrayerGreen = Color(0xFF10B981)
val NextPrayerAmber = Color(0xFFFBBF24)

