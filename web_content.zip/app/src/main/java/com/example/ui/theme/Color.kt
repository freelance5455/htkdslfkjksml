package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dexter-Style High-End Obsidian & Neon Palette
val DexterBackground = Color(0xFF080C14)
val DexterSurface = Color(0xFF0F172A)
val DexterSurfaceVariant = Color(0xFF1E293B)
val DexterSurfaceElevated = Color(0xFF243048)
val DexterOutline = Color(0xFF334155)
val DexterOutlineSubtle = Color(0xFF1E293B)

// Neon & Tech Accents
val DexterCyanPrimary = Color(0xFF38BDF8)
val DexterCyanOnPrimary = Color(0xFF001E2E)
val DexterCyanContainer = Color(0xFF0C3553)
val DexterCyanOnContainer = Color(0xFFBAE6FD)

val DexterEmeraldSecondary = Color(0xFF10B981)
val DexterEmeraldOnSecondary = Color(0xFF003822)
val DexterEmeraldContainer = Color(0xFF064E3B)
val DexterEmeraldOnContainer = Color(0xFFA7F3D0)

val DexterAmberTertiary = Color(0xFFF59E0B)
val DexterAmberOnTertiary = Color(0xFF451A03)
val DexterAmberContainer = Color(0xFF78350F)
val DexterAmberOnContainer = Color(0xFFFDE68A)

// Cycle Neon Colors
val Cycle1Color = Color(0xFF38BDF8) // Electric Cyan (1 to 10)
val Cycle2Color = Color(0xFFA855F7) // Electric Purple (11 to 20)
val Cycle3Color = Color(0xFF10B981) // Neon Emerald (21 to 31)

// Financial Glow Accents
val KamaiGreenGlow = Color(0xFF34D399)
val SettledGreen = Color(0xFF10B981)
val PendingOrange = Color(0xFFFB923C)
val CardBorderGlow = Color(0xFF2E3F5E)
