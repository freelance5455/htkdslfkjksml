package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NOVA BAZAR Signature Botanical Emerald, Lime & Gold Palette
val ForestEmerald = Color(0xFF103D2C)
val DeepEmerald = Color(0xFF0B2B1F)
val VibrantEmerald = Color(0xFF159768)
val BrightEmerald = Color(0xFF20B878)
val ElectricLime = Color(0xFFB7EF68)
val WarmGold = Color(0xFFD6AE58)

val MintPaper = Color(0xFFF5F8F5)
val MintSurface = Color(0xFFFFFFFF)
val MintSurfaceVariant = Color(0xFFEAF3EC)
val MintBorder = Color(0xFFDCE8DF)
val InkDark = Color(0xFF14231C)
val MutedSage = Color(0xFF607368)

val CoralAlert = Color(0xFFC94435)
val CoralContainer = Color(0xFFFFEDE9)
val AmberNotice = Color(0xFF8C6214)
val AmberContainer = Color(0xFFFFF6DC)

// Dark Theme Tokens
val DarkBackground = Color(0xFF0A1712)
val DarkSurface = Color(0xFF11231B)
val DarkSurfaceVariant = Color(0xFF193227)
val DarkBorder = Color(0xFF244536)
val DarkOnSurface = Color(0xFFE7F3EC)
val DarkMuted = Color(0xFFA0B8AA)
