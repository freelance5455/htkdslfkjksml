package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Ember Palette — Dark Mode Primary
val EmberPrimary = Color(0xFFFF7A45)
val EmberOnPrimary = Color(0xFF1F0B00)
val EmberPrimaryContainer = Color(0xFF3E1E0F)
val EmberOnPrimaryContainer = Color(0xFFFFDCCB)

val CyanSecondary = Color(0xFF38BDF8)
val CyanOnSecondary = Color(0xFF001F2E)
val CyanSecondaryContainer = Color(0xFF0C2D42)
val CyanOnSecondaryContainer = Color(0xFFBAE6FD)

val GoldTertiary = Color(0xFFFBBF24)
val GoldOnTertiary = Color(0xFF261900)

val ObsidianBackground = Color(0xFF090D16)
val ObsidianSurface = Color(0xFF0E1422)
val ObsidianSurfaceVariant = Color(0xFF161F33)
val ObsidianSurfaceHigh = Color(0xFF1E2942)
val ObsidianOutline = Color(0xFF2B3954)
val SlateTextPrimary = Color(0xFFF1F5F9)
val SlateTextSecondary = Color(0xFF94A3B8)

// Light Mode Companion Palette — Warm Alabaster & Ember
val LightEmberPrimary = Color(0xFFD9531E)
val LightEmberOnPrimary = Color(0xFFFFFFFF)
val LightEmberContainer = Color(0xFFFFE5D9)
val LightEmberOnContainer = Color(0xFF3B1200)

val LightCyanSecondary = Color(0xFF0284C7)
val LightCyanOnSecondary = Color(0xFFFFFFFF)
val LightCyanContainer = Color(0xFFE0F2FE)
val LightCyanOnContainer = Color(0xFF082F49)

val AlabasterBackground = Color(0xFFF8FAFC)
val AlabasterSurface = Color(0xFFFFFFFF)
val AlabasterSurfaceVariant = Color(0xFFEEF2F6)
val AlabasterOutline = Color(0xFFCBD5E1)
val InkTextPrimary = Color(0xFF0F172A)
val InkTextSecondary = Color(0xFF475569)

val ErrorCoral = Color(0xFFEF4444)
val SuccessEmerald = Color(0xFF10B981)
val CodeBlockBg = Color(0xFF070B12)
val CodeBlockHeaderBg = Color(0xFF111827)
