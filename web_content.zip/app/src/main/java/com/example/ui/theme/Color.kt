package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding - Modern Studio Blue & Electric Accents
val StudioPrimaryLight = Color(0xFF1E40AF)
val StudioOnPrimaryLight = Color(0xFFFFFFFF)
val StudioPrimaryContainerLight = Color(0xFFDBEAFE)
val StudioOnPrimaryContainerLight = Color(0xFF1E3A8A)

val StudioSecondaryLight = Color(0xFF0F766E)
val StudioOnSecondaryLight = Color(0xFFFFFFFF)
val StudioSecondaryContainerLight = Color(0xFFCCFBF1)
val StudioOnSecondaryContainerLight = Color(0xFF115E59)

val StudioTertiaryLight = Color(0xFF7C3AED)
val StudioOnTertiaryLight = Color(0xFFFFFFFF)
val StudioTertiaryContainerLight = Color(0xFFEDE9FE)
val StudioOnTertiaryContainerLight = Color(0xFF5B21B6)

val StudioBackgroundLight = Color(0xFFF8FAFC)
val StudioSurfaceLight = Color(0xFFFFFFFF)
val StudioSurfaceVariantLight = Color(0xFFF1F5F9)
val StudioOutlineLight = Color(0xFFCBD5E1)

// Dark Palette
val StudioPrimaryDark = Color(0xFF60A5FA)
val StudioOnPrimaryDark = Color(0xFF0F172A)
val StudioPrimaryContainerDark = Color(0xFF1E3A8A)
val StudioOnPrimaryContainerDark = Color(0xFFDBEAFE)

val StudioSecondaryDark = Color(0xFF2DD4BF)
val StudioOnSecondaryDark = Color(0xFF042F2E)
val StudioSecondaryContainerDark = Color(0xFF134E4A)
val StudioOnSecondaryContainerDark = Color(0xFFCCFBF1)

val StudioTertiaryDark = Color(0xFFA78BFA)
val StudioOnTertiaryDark = Color(0xFF2E1065)
val StudioTertiaryContainerDark = Color(0xFF5B21B6)
val StudioOnTertiaryContainerDark = Color(0xFFEDE9FE)

val StudioBackgroundDark = Color(0xFF0B0F19)
val StudioSurfaceDark = Color(0xFF111827)
val StudioSurfaceVariantDark = Color(0xFF1F2937)
val StudioOutlineDark = Color(0xFF374151)

// Custom Status & Accent Colors
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenContainer = Color(0xFFD1FAE5)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberContainer = Color(0xFFFEF3C7)
val InfoBlue = Color(0xFF3B82F6)
val ErrorRed = Color(0xFFEF4444)
val PurpleAccent = Color(0xFF8B5CF6)
val TelegramBlue = Color(0xFF0088CC)
val UpiGreen = Color(0xFF00A86B)

