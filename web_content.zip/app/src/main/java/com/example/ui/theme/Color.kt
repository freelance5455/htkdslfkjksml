package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern 2026 Accent Palette
val ElectricBlue = Color(0xFF3478F6)
val ElectricBlueDark = Color(0xFF2563EB)
val ElectricBlueContainer = Color(0xFFEBF2FE)
val ElectricBlueContainerDark = Color(0xFF1E2E4A)

val SoftViolet = Color(0xFF8B5CF6)
val SoftVioletContainer = Color(0xFFF3E8FF)
val SoftVioletContainerDark = Color(0xFF2E204A)

val SubtleMint = Color(0xFF36CFA0)
val SubtleMintContainer = Color(0xFFE6F9F3)
val SubtleMintContainerDark = Color(0xFF163C31)

// Light Mode Neutral Palette (Soft Off-White)
val BackgroundLight = Color(0xFFF8F9FA)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEFF1F5)
val OutlineLight = Color(0xFFE2E4E9)
val OutlineVariantLight = Color(0xFFEAECEF)
val TextPrimaryLight = Color(0xFF191B1F)
val TextSecondaryLight = Color(0xFF5F6672)
val KeypadNumberLight = Color(0xFFF1F3F7)
val KeypadNumberTextLight = Color(0xFF191B1F)
val KeypadActionLight = Color(0xFFE2E6ED)

// Dark Mode Neutral Palette (Deep Charcoal)
val BackgroundDark = Color(0xFF121316)
val SurfaceDark = Color(0xFF1A1B20)
val SurfaceVariantDark = Color(0xFF23252C)
val OutlineDark = Color(0xFF2E313B)
val OutlineVariantDark = Color(0xFF262830)
val TextPrimaryDark = Color(0xFFF4F5F7)
val TextSecondaryDark = Color(0xFF9AA1AE)
val KeypadNumberDark = Color(0xFF1F2128)
val KeypadNumberTextDark = Color(0xFFF4F5F7)
val KeypadActionDark = Color(0xFF2B2E38)

val ErrorRed = Color(0xFFEF4444)
val WarningAmber = Color(0xFFF59E0B)
