package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// Light Theme Tokens — Natural Photography & Refined Liquid Glass
val ArkLightBackground = Color(0xFFF7F7F5)
val ArkLightSurface = Color(0xFFFFFFFF)
val ArkLightSurfaceSecondary = Color(0xFFF1F2F4)
val ArkLightInk = Color(0xFF191919)
val ArkLightInk2 = Color(0xFF777777)
val ArkLightInk3 = Color(0xFF999999)
val ArkLightAccent = Color(0xFF4267D5)
val ArkLightAccentSoft = Color(0xFFEAF0FF)
val ArkLightHairline = Color(0xFFE5E6EB)

// Dark Theme Tokens — Obsidian Neutral & Subtle Sapphire Accent
val ArkDarkBackground = Color(0xFF111214)
val ArkDarkSurface = Color(0xFF1B1D20)
val ArkDarkSurfaceSecondary = Color(0xFF24262A)
val ArkDarkInk = Color(0xFFF5F5F5)
val ArkDarkInk2 = Color(0xB8FFFFFF)
val ArkDarkInk3 = Color(0x7AFFFFFF)
val ArkDarkAccent = Color(0xFF829BFF)
val ArkDarkAccentSoft = Color(0x24829BFF)
val ArkDarkHairline = Color(0xFF2A2D34)

// Semantic Accents
val ArkSuccessLight = Color(0xFF269B68)
val ArkSuccessDark = Color(0xFF34C483)
val ArkErrorLight = Color(0xFFE45454)
val ArkErrorDark = Color(0xFFFF6B6B)
val ArkAmberLight = Color(0xFFD08B17)
val ArkAmberDark = Color(0xFFF1B94D)

@Immutable
data class ArkExtendedColors(
    val isDark: Boolean,
    val background: Color,
    val backgroundTop: Color,
    val backgroundBottom: Color,
    val surface: Color,
    val surfaceSecondary: Color,
    val hairline: Color,
    val ink: Color,
    val ink2: Color,
    val ink3: Color,
    val accent: Color,
    val accentSoft: Color,
    val success: Color,
    val error: Color,
    val glass: Color,
    val glass2: Color,
    val glassLine: Color,
    // Unified surface/glass aliases used across screens
    val glassSurface: Color,
    val glassSurfaceElevated: Color,
    val glassBorder: Color,
    val glassHighlight: Color,
    val cyan: Color,
    val violet: Color,
    val coral: Color,
    val emerald: Color,
    val gold: Color,
    val textPrimary: Color,
    val textSecondary: Color
)

val DarkArkColors = ArkExtendedColors(
    isDark = true,
    background = ArkDarkBackground,
    backgroundTop = ArkDarkBackground,
    backgroundBottom = Color(0xFF141519),
    surface = ArkDarkSurface,
    surfaceSecondary = ArkDarkSurfaceSecondary,
    hairline = ArkDarkHairline,
    ink = ArkDarkInk,
    ink2 = ArkDarkInk2,
    ink3 = ArkDarkInk3,
    accent = ArkDarkAccent,
    accentSoft = ArkDarkAccentSoft,
    success = ArkSuccessDark,
    error = ArkErrorDark,
    glass = Color(0xCC1E2025),
    glass2 = Color(0x8C2A2D34),
    glassLine = Color(0x2EFFFFFF),
    glassSurface = ArkDarkSurface,
    glassSurfaceElevated = ArkDarkSurfaceSecondary,
    glassBorder = ArkDarkHairline,
    glassHighlight = Color(0x2EFFFFFF),
    cyan = ArkDarkAccent,
    violet = Color(0xFF9E8CFF),
    coral = ArkErrorDark,
    emerald = ArkSuccessDark,
    gold = ArkAmberDark,
    textPrimary = ArkDarkInk,
    textSecondary = ArkDarkInk2
)

val LightArkColors = ArkExtendedColors(
    isDark = false,
    background = ArkLightBackground,
    backgroundTop = ArkLightBackground,
    backgroundBottom = Color(0xFFF3F3F0),
    surface = ArkLightSurface,
    surfaceSecondary = ArkLightSurfaceSecondary,
    hairline = ArkLightHairline,
    ink = ArkLightInk,
    ink2 = ArkLightInk2,
    ink3 = ArkLightInk3,
    accent = ArkLightAccent,
    accentSoft = ArkLightAccentSoft,
    success = ArkSuccessLight,
    error = ArkErrorLight,
    glass = Color(0xCCFFFFFF),
    glass2 = Color(0x99F1F2F4),
    glassLine = Color(0xBFFFFFFF),
    glassSurface = ArkLightSurface,
    glassSurfaceElevated = ArkLightSurfaceSecondary,
    glassBorder = ArkLightHairline,
    glassHighlight = Color(0xBFFFFFFF),
    cyan = ArkLightAccent,
    violet = Color(0xFF5D5FEF),
    coral = ArkErrorLight,
    emerald = ArkSuccessLight,
    gold = ArkAmberLight,
    textPrimary = ArkLightInk,
    textSecondary = ArkLightInk2
)

val LocalArkColors = staticCompositionLocalOf { LightArkColors }
