package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MinecraftDirtDark = Color(0xFF382313)
val MinecraftDirtMid = Color(0xFF5C3A21)
val MinecraftGrassGreen = Color(0xFF4CAF50)
val MinecraftGold = Color(0xFFFFB703)
val MinecraftRed = Color(0xFFE63946)
val MinecraftDarkBg = Color(0xFF131518)
val MinecraftCardBg = Color(0xFF1D222A)
val MinecraftCardBorder = Color(0xFF2C3442)
val MinecraftTextPrimary = Color(0xFFECEFF4)
val MinecraftTextSecondary = Color(0xFFA0AEC0)

val PrimaryGold = Color(0xFFFFB703)
val OnPrimaryDark = Color(0xFF1E1300)
val SecondaryGreen = Color(0xFF2ECC71)
val TertiaryRed = Color(0xFFE63946)
val BackgroundDark = Color(0xFF121417)
val SurfaceDark = Color(0xFF1A1F27)
