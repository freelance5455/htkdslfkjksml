package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Cyber & Obsidian Theme Palette
val ObsidianBg = Color(0xFF090A10)
val SurfaceDark = Color(0xFF121422)
val SurfaceElevated = Color(0xFF1B1E32)
val SurfaceBorder = Color(0xFF282C48)

val NeonCyan = Color(0xFF00F0FF)
val NeonPurple = Color(0xFFA855F7)
val NeonPink = Color(0xFFEC4899)
val NeonGreen = Color(0xFF10B981)
val NeonAmber = Color(0xFFF59E0B)
val ElectricBlue = Color(0xFF3B82F6)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val AccentGradientStart = Color(0xFF00F0FF)
val AccentGradientMiddle = Color(0xFFA855F7)
val AccentGradientEnd = Color(0xFFEC4899)
