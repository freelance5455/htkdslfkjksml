package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Primary Colors (Electric Blue / Tech Indigo)
val BrandPrimary = Color(0xFF2979FF)
val BrandPrimaryLight = Color(0xFF75A7FF)
val BrandPrimaryDark = Color(0xFF004ECB)

// Accent Colors
val BrandSecondary = Color(0xFF00E5FF)
val BrandTertiary = Color(0xFFFFB300)

// Semantic
val SuccessGreen = Color(0xFF00E676)
val WarningAmber = Color(0xFFFFAB00)
val DangerRed = Color(0xFFFF5252)
val InfoCyan = Color(0xFF00B0FF)

// Dark Theme Colors
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1B2640)
val DarkSurfaceCard = Color(0xFF202D4A)
val DarkTextPrimary = Color(0xFFF0F4F8)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF243456)

// Light Theme Colors
val LightBackground = Color(0xFFF4F6F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightSurfaceCard = Color(0xFFFFFFFF)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
val LightBorder = Color(0xFFCBD5E1)
