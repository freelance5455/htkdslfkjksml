package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Editorial Monochrome + Champagne Luxury Palette
val ObsidianBlack = Color(0xFF0A0A0D)
val RichCharcoal = Color(0xFF141419)
val ElevatedGraphite = Color(0xFF1E1E26)
val SubtleSlate = Color(0xFF2C2C38)
val PureIvory = Color(0xFFFAF9F6)
val CrispWhite = Color(0xFFFFFFFF)
val MutedPlatinum = Color(0xFFB4B4C0)
val ChampagneGold = Color(0xFFD4AF37)
val SoftGold = Color(0xFFF3E5AB)
val EmeraldVerified = Color(0xFF2EBD85)
val CrimsonError = Color(0xFFEF5350)
