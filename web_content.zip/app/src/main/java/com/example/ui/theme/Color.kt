package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Original Spotify-inspired luxury dark music palette
val DarkBackground = Color(0xFF0C0F14)
val DarkSurface = Color(0xFF141820)
val DarkSurfaceElevated = Color(0xFF1B212D)
val DarkSurfaceHighlight = Color(0xFF252D3D)
val DarkSurfaceBorder = Color(0xFF2A3445)

// Restrained vibrant emerald accent
val EmeraldPrimary = Color(0xFF1DB97D)
val EmeraldBright = Color(0xFF00E699)
val EmeraldContainer = Color(0xFF0B3826)
val OnEmeraldContainer = Color(0xFF6CF0B8)

// Text tokens
val TextPrimary = Color(0xFFF2F5F8)
val TextSecondary = Color(0xFFA2ACB9)
val TextTertiary = Color(0xFF6C7684)

// Functional colors
val DarkError = Color(0xFFFF5252)
val DarkFavorite = Color(0xFFFF4081)
val DarkWarning = Color(0xFFFFB74D)
