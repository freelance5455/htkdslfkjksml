package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kawaii Aesthetic Palette: Light Pink, Grey, White, Black
val PastelPinkBg = Color(0xFFFFF0F5)      // Soft blossom light pink
val PastelPinkSurface = Color(0xFFFDF2F8) // Very light pink card
val PastelPinkContainer = Color(0xFFFCE7F3) // Soft pink container / badge
val KawaiiPink = Color(0xFFF472B6)        // Main accent pink
val DeepPink = Color(0xFFDB2777)          // Stronger pink for accents
val RoseTint = Color(0xFFFDA4AF)          // Gentle rose tint

// White
val PureWhite = Color(0xFFFFFFFF)
val StickerWhite = Color(0xFFFFFFFF)

// Grey
val SoftGreyBg = Color(0xFFF9FAFB)
val CardGrey = Color(0xFFF3F4F6)
val BorderGrey = Color(0xFFE5E7EB)
val MutedGrey = Color(0xFF9CA3AF)
val TextGrey = Color(0xFF6B7280)
val DarkGrey = Color(0xFF374151)

// Black
val AestheticBlack = Color(0xFF18181B)   // Soft ink black for high contrast text
val CharcoalBlack = Color(0xFF27272A)
val LineBlack = Color(0xFF1E1E24)

// Minimalist Pink / Grey Subject color tokens (no garish rainbow!)
val PaletteSubjectColors = listOf(
    "#F472B6", // Kawaii Pink
    "#FDA4AF", // Soft Rose
    "#DB2777", // Deep Pink
    "#18181B", // Aesthetic Black
    "#4B5563", // Slate Grey
    "#9CA3AF", // Soft Grey
    "#E879F9", // Lavender Pink
    "#F87171"  // Coral Blush
)
