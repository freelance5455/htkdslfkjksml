package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic Terracotta & Sufi Palette (From Image Artwork)
val TerracottaBackground = Color(0xFF4A1F16)
val TerracottaDark = Color(0xFF230B07)
val TerracottaWarm = Color(0xFF6D2F22)
val TerracottaLight = Color(0xFF8A3C2B)

val GoldLuster = Color(0xFFE5C07A)
val GoldLusterBright = Color(0xFFFFE59E)
val GoldLusterDark = Color(0xFF996E2A)
val GoldGleam = Color(0xFFFFF5D9)

// Warm Sufi Palette - Parchment, Maroon & Candle Gold
val SufiMaroon = Color(0xFF5A1420)
val SufiMaroonDark = Color(0xFF380912)
val SufiMaroonLight = Color(0xFF822334)

val SufiGold = Color(0xFFC99738)
val SufiGoldBright = Color(0xFFE5B558)
val SufiGoldDark = Color(0xFF8C661D)

val ParchmentBase = Color(0xFF4A1F16) // Rich Terracotta Ambient Base
val ParchmentSurface = Color(0xFF57251B)
val ParchmentSurfaceVariant = Color(0xFF6E3023)
val ParchmentBorder = Color(0xFFC99738)

val SufiCharcoal = Color(0xFFFFF2DC) // High-contrast warm off-white on terracotta
val SufiCharcoalLight = Color(0xFFE8D5C0)
val SufiMutedText = Color(0xFFD6BBA5)

// Dark / Candlelight Room Palette
val CandleNightDark = Color(0xFF1B0A06)
val CandleNightSurface = Color(0xFF28100B)
val CandleNightSurfaceVariant = Color(0xFF3B1710)
val CandleNightText = Color(0xFFFFF2DC)
val CandleNightMuted = Color(0xFFC4A694)
val CandleGlow = Color(0xFFFFB03B)
val CandleOrange = Color(0xFFFF841F)
