package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Volcanic Obsidian & Dark Violet Palette
val NexusBackground = Color(0xFF07050C)
val NexusBackgroundGlow = Color(0xFF150A29)
val NexusCodeBackground = Color(0xFF040207)
val NexusSurface = Color(0xFF0F0A1B)
val NexusSurfaceVariant = Color(0xFF171028)
val NexusSurfaceElevated = Color(0xFF22163B)

// Primary Amethyst & Dark Violet Accents
val NexusCyan = Color(0xFFA855F7)
val NexusCyanDim = Color(0xFF7E22CE)
val NexusCyanDark = Color(0xFF2D124E)

val NexusViolet = Color(0xFF6D28D9)
val NexusVioletLight = Color(0xFFD8B4FE)
val NexusVioletDark = Color(0xFF220A3D)

// Harmonized Orchid Active Indicator (replaces neon green)
val NexusEmerald = Color(0xFFC084FC)
val NexusEmeraldDim = Color(0xFF4C1D95)

val NexusRose = Color(0xFFE11D48)
val NexusAmber = Color(0xFFB794F4)

// High-Contrast Pearl Lavender Typography on Obsidian
val NexusTextPrimary = Color(0xFFF5F3FF)
val NexusTextSecondary = Color(0xFFB8A9D1)
val NexusTextTertiary = Color(0xFF7E6D9B)

// Obsidian Violet Borders
val NexusBorder = Color(0xFF2B1D46)
val NexusBorderFocused = Color(0xFFA855F7)

val NexusObsidianBackdrop = Brush.verticalGradient(
    colors = listOf(
        NexusBackgroundGlow,
        NexusBackground,
        Color(0xFF0B0614)
    )
)
