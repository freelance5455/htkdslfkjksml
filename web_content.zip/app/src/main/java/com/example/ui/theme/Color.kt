package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SaffronOrange = Color(0xFFFF6B35)
val SaffronOrangeDark = Color(0xFFE5531D)
val SaffronOrangeLight = Color(0xFFFF895C)
val WarmBackgroundLight = Color(0xFFFFFBF5)
val WarmSurfaceLight = Color(0xFFFFFFFF)

val DeepNavy = Color(0xFF1E293B)
val NavyLight = Color(0xFF334155)

val DarkBackground = Color(0xFF121214)
val DarkSurface = Color(0xFF1E1E22)
val DarkSurfaceVariant = Color(0xFF2B2B30)

val UserBubbleColor = Color(0xFFFF6B35)
val AiBubbleColorLight = Color(0xFFFFFFFF)
val AiBubbleColorDark = Color(0xFF26262B)
