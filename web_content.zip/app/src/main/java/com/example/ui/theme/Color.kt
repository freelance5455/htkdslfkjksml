package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Scanova Premium Futuristic Palette
val CyanPrimary = Color(0xFF00E5FF)
val CyanPrimaryDark = Color(0xFF00B4D8)
val CyanOnPrimary = Color(0xFF00363D)
val CyanContainer = Color(0xFF004E59)
val CyanOnContainer = Color(0xFF99F2FF)

val VioletSecondary = Color(0xFF8B5CF6)
val VioletSecondaryDark = Color(0xFF6D28D9)
val VioletContainer = Color(0xFF3B1D78)
val VioletOnContainer = Color(0xFFE9D8FD)

val EmeraldTertiary = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF064E3B)
val EmeraldOnContainer = Color(0xFFA7F3D0)

val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFEF4444)

// Dark Theme Surfaces
val ObsidianBackground = Color(0xFF080C14)
val ObsidianSurface = Color(0xFF0F1726)
val ObsidianSurfaceVariant = Color(0xFF192234)
val ObsidianSurfaceContainer = Color(0xFF202C42)
val ObsidianBorder = Color(0xFF283852)

// Light Theme Surfaces
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceContainer = Color(0xFFE2E8F0)
val LightBorder = Color(0xFFCBD5E1)

// Glass & Accents
val GlassCyan = Color(0x3300E5FF)
val GlassDark = Color(0xB30F1726)
val GlassWhite = Color(0x99FFFFFF)
val LaserGlow = Color(0xFF00F0FF)
