package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Primary Colors (Indigo / Violet)
val PrimaryLight = Color(0xFF4338CA)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFEEF2FF)
val OnPrimaryContainerLight = Color(0xFF1E1B4B)

val PrimaryDark = Color(0xFF818CF8)
val OnPrimaryDark = Color(0xFF1E1B4B)
val PrimaryContainerDark = Color(0xFF312E81)
val OnPrimaryContainerDark = Color(0xFFE0E7FF)

// Secondary Colors (Teal / Cyan)
val SecondaryLight = Color(0xFF0D9488)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFCCFBF1)
val OnSecondaryContainerLight = Color(0xFF134E4A)

val SecondaryDark = Color(0xFF2DD4BF)
val OnSecondaryDark = Color(0xFF134E4A)
val SecondaryContainerDark = Color(0xFF115E59)
val OnSecondaryContainerDark = Color(0xFFCCFBF1)

// Tertiary (Warm Amber / Gold)
val TertiaryLight = Color(0xFFD97706)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFEF3C7)
val OnTertiaryContainerLight = Color(0xFF78350F)

val TertiaryDark = Color(0xFFFBBF24)
val OnTertiaryDark = Color(0xFF78350F)
val TertiaryContainerDark = Color(0xFF92400E)
val OnTertiaryContainerDark = Color(0xFFFEF3C7)

// Background & Surface
val BackgroundLight = Color(0xFFF8FAFC)
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)

val BackgroundDark = Color(0xFF0B0F19)
val OnBackgroundDark = Color(0xFFF1F5F9)
val SurfaceDark = Color(0xFF111827)
val OnSurfaceDark = Color(0xFFF1F5F9)
val SurfaceVariantDark = Color(0xFF1F2937)
val OnSurfaceVariantDark = Color(0xFF9CA3AF)

// Status & Action Colors
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenContainer = Color(0xFFD1FAE5)
val WarningRed = Color(0xFFEF4444)
val WarningRedContainer = Color(0xFFFEE2E2)
val HighlightGold = Color(0xFFF59E0B)
val HighlightGoldContainer = Color(0xFFFEF3C7)
