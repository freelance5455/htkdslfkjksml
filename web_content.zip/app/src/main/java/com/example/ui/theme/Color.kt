package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Fintech Deep Navy & Emerald Palette
val NavyPrimary = Color(0xFF0B2545)
val NavyLight = Color(0xFF134074)
val TealAccent = Color(0xFF00677F)
val EmeraldProfit = Color(0xFF10B981)
val CoralLoss = Color(0xFFEF4444)
val AmberWarning = Color(0xFFF59E0B)

val PrimaryDark = Color(0xFF82D2EC)
val SecondaryDark = Color(0xFFB1C5FF)
val TertiaryDark = Color(0xFF77DAA7)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)

val PrimaryLight = Color(0xFF00677F)
val SecondaryLight = Color(0xFF485D92)
val TertiaryLight = Color(0xFF006C4C)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEEF2F6)
