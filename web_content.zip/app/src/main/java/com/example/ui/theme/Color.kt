package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Camera Palette
val ChromaDarkBackground = Color(0xFF0C0E12)
val ChromaDarkSurface = Color(0xFF14171F)
val ChromaDarkSurfaceVariant = Color(0xFF1E232E)
val ChromaDarkSurfaceSubtle = Color(0xFF282F3D)

val ChromaPrimary = Color(0xFF00E5FF) // Electric cyan/teal accent
val ChromaOnPrimary = Color(0xFF001F29)
val ChromaSecondary = Color(0xFF10B981) // High-visibility emerald
val ChromaOnSecondary = Color(0xFF003823)

val ChromaTertiary = Color(0xFFFFB703) // Amber warning/trigger
val ChromaOnTertiary = Color(0xFF402D00)

val ChromaRed = Color(0xFFEF4444)
val ChromaGreen = Color(0xFF10B981)
val ChromaYellow = Color(0xFFFBBF24)
val ChromaBlue = Color(0xFF3B82F6)
val ChromaOrange = Color(0xFFF97316)
val ChromaPurple = Color(0xFFA855F7)

val ChromaTextPrimary = Color(0xFFF1F5F9)
val ChromaTextSecondary = Color(0xFF94A3B8)
val ChromaOutline = Color(0xFF334155)
