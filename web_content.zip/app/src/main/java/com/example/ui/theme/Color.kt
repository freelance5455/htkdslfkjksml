package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Screenshot-Matched Reader Chrome Palette
val ReaderTopBarIndigo = Color(0xFF1D184E)
val ReaderTopBarIndigoDark = Color(0xFF141038)
val ReaderPageInputPurple = Color(0xFF332D6E)
val ReaderPageInputBorder = Color(0xFF4F46A5)
val ReaderActiveGreenDot = Color(0xFF4ADE80)
val ReaderPageDividerGray = Color(0xFF3F3F46)
val ReaderCanvasBg = Color(0xFFE5E7EB)

// Docked Sheet & Engine Panel Palette (Matching Screenshot)
val SheetHandleBarBg = Color(0xFFF3F4F6)
val SheetHandlePill = Color(0xFF6B7280)
val SheetSurfaceWhite = Color(0xFFFFFFFF)
val SheetBottomBarBg = Color(0xFFF8F9FA)
val SheetIconGray = Color(0xFF737373)
val StudyCapPurple = Color(0xFF3B1D82)
val EngineSwitchOrange = Color(0xFFEA580C)
val EngineSwitchTrackOrange = Color(0xFFFDBA74)
val EnginePlusBlue = Color(0xFF0284C7)
val DividerHairline = Color(0xFFE5E7EB)

// Default Screenshot Chessboard Colors (Classic Wood / Lichess Brown)
val BoardLightWood = Color(0xFFF0D9B5)
val BoardDarkWood = Color(0xFFB58863)
val BoardArrowGray = Color(0x8852525B)
val BoardArrowEngine = Color(0x883B82F6)
val BoardLastMoveHighlight = Color(0x66CDA349)
val BoardSelectedHighlight = Color(0x8015803D)

// Material 3 Semantic Palette
val PrimaryIndigo = Color(0xFF2E2673)
val OnPrimaryWhite = Color(0xFFFFFFFF)
val PrimaryContainerIndigo = Color(0xFFE0E7FF)
val OnPrimaryContainerIndigo = Color(0xFF1E1B4B)
val SecondaryAmber = Color(0xFFD97706)
val SecondaryContainerAmber = Color(0xFFFEF3C7)
val SurfaceLight = Color(0xFFFCFAF7)
val OnSurfaceDark = Color(0xFF18181B)
val SurfaceVariantLight = Color(0xFFF4F4F5)
val OnSurfaceVariantMuted = Color(0xFF52525B)
