package com.example.ui.theme

import android.graphics.Bitmap
import androidx.compose.ui.graphics.Color
import kotlin.math.max
import kotlin.math.min

enum class ThemeMode(val label: String) {
    SYSTEM("System default"),
    LIGHT("Light"),
    DARK("Dark")
}

enum class AccentPreset(
    val label: String,
    val primaryLight: Color,
    val primaryDark: Color,
    val containerLight: Color,
    val containerDark: Color
) {
    BLUE(
        label = "One UI Blue",
        primaryLight = Color(0xFF0381FE),
        primaryDark = Color(0xFF5CAEFF),
        containerLight = Color(0xFFD9ECFF),
        containerDark = Color(0xFF003875)
    ),
    TEAL(
        label = "Ocean Teal",
        primaryLight = Color(0xFF008F82),
        primaryDark = Color(0xFF4CDAD0),
        containerLight = Color(0xFFD0F6F2),
        containerDark = Color(0xFF004F47)
    ),
    GREEN(
        label = "Emerald Green",
        primaryLight = Color(0xFF1F8A45),
        primaryDark = Color(0xFF6EE092),
        containerLight = Color(0xFFD4F8DF),
        containerDark = Color(0xFF064E22)
    ),
    PURPLE(
        label = "Galaxy Violet",
        primaryLight = Color(0xFF723CE8),
        primaryDark = Color(0xFFBBA0FF),
        containerLight = Color(0xFFECE3FF),
        containerDark = Color(0xFF39138A)
    ),
    PINK(
        label = "Rose Pink",
        primaryLight = Color(0xFFD81B60),
        primaryDark = Color(0xFFFF82AE),
        containerLight = Color(0xFFFFDCE8),
        containerDark = Color(0xFF6B002B)
    ),
    RED(
        label = "Crimson Red",
        primaryLight = Color(0xFFD32F2F),
        primaryDark = Color(0xFFFF8A80),
        containerLight = Color(0xFFFFDAD6),
        containerDark = Color(0xFF690005)
    ),
    ORANGE(
        label = "Sunset Orange",
        primaryLight = Color(0xFFE65100),
        primaryDark = Color(0xFFFFB580),
        containerLight = Color(0xFFFFE2CF),
        containerDark = Color(0xFF662200)
    ),
    AMBER(
        label = "Golden Amber",
        primaryLight = Color(0xFFC78500),
        primaryDark = Color(0xFFFFCA58),
        containerLight = Color(0xFFFFEFCA),
        containerDark = Color(0xFF573800)
    ),
    DYNAMIC_IMAGE(
        label = "Dynamic Image",
        primaryLight = Color(0xFF0381FE),
        primaryDark = Color(0xFF5CAEFF),
        containerLight = Color(0xFFD9ECFF),
        containerDark = Color(0xFF003875)
    )
}

/**
 * Extracts a vibrant accent seed color from a user-chosen Bitmap for the Dynamic Image palette.
 */
object DynamicImageColorExtractor {
    fun extractSeedArgb(bitmap: Bitmap): Int {
        val scaled = Bitmap.createScaledBitmap(bitmap, 24, 24, true)
        var bestR = 3
        var bestG = 129
        var bestB = 254
        var highestScore = -1f

        val pixels = IntArray(scaled.width * scaled.height)
        scaled.getPixels(pixels, 0, scaled.width, 0, 0, scaled.width, scaled.height)

        var sumR = 0L
        var sumG = 0L
        var sumB = 0L

        for (px in pixels) {
            val r = (px shr 16) and 0xFF
            val g = (px shr 8) and 0xFF
            val b = px and 0xFF
            sumR += r
            sumG += g
            sumB += b

            val maxC = max(r, max(g, b))
            val minC = min(r, min(g, b))
            val chroma = (maxC - minC) / 255f
            val luma = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
            // Favor saturated mid-tone colors that work well as UI accents
            val midToneWeight = 1f - kotlin.math.abs(luma - 0.52f)
            val score = chroma * 1.8f + midToneWeight * 0.4f
            if (score > highestScore && maxC > 40 && minC < 230) {
                highestScore = score
                bestR = r
                bestG = g
                bestB = b
            }
        }

        if (highestScore < 0.25f && pixels.isNotEmpty()) {
            bestR = (sumR / pixels.size).toInt().coerceIn(30, 210)
            bestG = (sumG / pixels.size).toInt().coerceIn(30, 210)
            bestB = (sumB / pixels.size).toInt().coerceIn(30, 210)
        }
        return (0xFF shl 24) or (bestR shl 16) or (bestG shl 8) or bestB
    }

    fun deriveDynamicColors(seedArgb: Int, isDark: Boolean): Pair<Color, Color> {
        val r = ((seedArgb shr 16) and 0xFF) / 255f
        val g = ((seedArgb shr 8) and 0xFF) / 255f
        val b = (seedArgb and 0xFF) / 255f

        return if (isDark) {
            val primary = Color(
                red = (r * 0.65f + 0.35f).coerceIn(0f, 1f),
                green = (g * 0.65f + 0.35f).coerceIn(0f, 1f),
                blue = (b * 0.65f + 0.35f).coerceIn(0f, 1f)
            )
            val container = Color(
                red = (r * 0.35f).coerceIn(0f, 1f),
                green = (g * 0.35f).coerceIn(0f, 1f),
                blue = (b * 0.35f).coerceIn(0f, 1f)
            )
            primary to container
        } else {
            val primary = Color(
                red = (r * 0.82f).coerceIn(0f, 0.85f),
                green = (g * 0.82f).coerceIn(0f, 0.85f),
                blue = (b * 0.82f).coerceIn(0f, 0.85f)
            )
            val container = Color(
                red = (r * 0.18f + 0.82f).coerceIn(0f, 1f),
                green = (g * 0.18f + 0.82f).coerceIn(0f, 1f),
                blue = (b * 0.18f + 0.82f).coerceIn(0f, 1f)
            )
            primary to container
        }
    }
}
