package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Suesa AI Modern Dark Palette
val SuesaBackground = Color(0xFF171717)
val SuesaSurface = Color(0xFF212121)
val SuesaSurfaceVariant = Color(0xFF2A2A2A)
val SuesaCardBorder = Color(0xFF333333)

val PurplePrimary = Color(0xFFA855F7)
val PurpleDark = Color(0xFF7C3AED)
val PurpleLight = Color(0xFFC084FC)
val PurpleGlow = Color(0x33A855F7)

val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

val UserBubbleBg = Color(0xFF2D2638)
val AssistantBubbleBg = Color(0xFF1F1F23)
val CodeBlockBg = Color(0xFF0F0F12)

val AccentSuccess = Color(0xFF10B981)
val AccentError = Color(0xFFEF4444)
val AccentWarning = Color(0xFFF59E0B)
