package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ben 10 Ultimatrix Green Palette
val OmnitrixGreen = Color(0xFF00FF66)
val OmnitrixGreenBright = Color(0xFF39FF14)
val OmnitrixGreenDim = Color(0xFF109B45)
val OmnitrixGreenDark = Color(0xFF052B14)
val OmnitrixGreenGlow = Color(0x6600FF66)
val OmnitrixGreenTrace = Color(0x2200FF66)

// Ultimate Mode Red / Crimson Palette
val UltimateRed = Color(0xFFFF1E27)
val UltimateRedBright = Color(0xFFFF4136)
val UltimateRedDim = Color(0xFFA81218)
val UltimateRedDark = Color(0xFF300609)
val UltimateRedGlow = Color(0x66FF1E27)
val UltimateRedTrace = Color(0x22FF1E27)

// Galvan Metallic & Gauntlet Surface
val GalvanBlack = Color(0xFF07090B)
val GalvanDark = Color(0xFF0E1217)
val GalvanSurface = Color(0xFF151B22)
val GalvanSurfaceLight = Color(0xFF1E2630)
val GalvanBorder = Color(0xFF2C3844)
val GalvanHighlight = Color(0xFF3B4D5D)

// Cartoon / Sci-Fi Accent Colors
val AlienCyan = Color(0xFF00F0FF)
val AlienGold = Color(0xFFFFCC00)
val AlienOrange = Color(0xFFFF6A00)
val AlienPurple = Color(0xFFB026FF)
val WhitePure = Color(0xFFFFFFFF)
val WhiteMuted = Color(0xFFB8C5D0)
val TextMuted = Color(0xFF6C7F93)
