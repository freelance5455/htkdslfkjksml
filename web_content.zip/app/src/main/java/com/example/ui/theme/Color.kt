package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand: Deep Royal Academic Navy
val NavyPrimary = Color(0xFF14347D)
val NavyPrimaryDark = Color(0xFF0F2559)
val NavyContainer = Color(0xFFDBE4FF)
val OnNavyContainer = Color(0xFF071B4B)

// Secondary Accent: Warm Academic Gold / Amber
val GoldSecondary = Color(0xFFD97706)
val GoldContainer = Color(0xFFFEF3C7)
val OnGoldContainer = Color(0xFF451A03)

// Semantic Status Colors
val EmeraldSuccess = Color(0xFF059669)
val EmeraldContainer = Color(0xFFD1FAE5)
val CrimsonAlert = Color(0xFFDC2626)
val CrimsonContainer = Color(0xFFFEE2E2)
val SlateInfo = Color(0xFF475569)

// Surfaces & Neutrals
val AlabasterBackground = Color(0xFFF8FAFC)
val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineHairline = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)

// Dark Theme Tokens
val DarkNavyPrimary = Color(0xFF9DB8FF)
val DarkNavyContainer = Color(0xFF1E3A8A)
val DarkGoldSecondary = Color(0xFFFBBF24)
val DarkBackground = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOutline = Color(0xFF334155)
