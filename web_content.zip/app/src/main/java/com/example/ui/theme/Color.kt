package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Silver & Black Palette for YM Secret
val SilverLight = Color(0xFFE5E7EB)       // Light silver background
val SilverSurface = Color(0xFFD6D9DF)     // Element / button silver surface
val SilverSurfaceVariant = Color(0xFFC7CBD3) // Slightly darker surface
val SilverDark = Color(0xFF5B616B)        // Dark silver elements
val SilverMuted = Color(0xFF8B929E)       // Muted silver
val SilverBorder = Color(0xFFB0B6C0)      // Subtle silver border

val BlackPure = Color(0xFF000000)        // Pure black for primary text, borders, icons
val BlackCharcoal = Color(0xFF16181B)    // Charcoal black
val BlackSoft = Color(0xFF282B30)        // Soft black details

val WhitePure = Color(0xFFFFFFFF)
val AccentRed = Color(0xFFB91C1C)        // For delete / errors
val AccentGreen = Color(0xFF15803D)      // For success notifications
