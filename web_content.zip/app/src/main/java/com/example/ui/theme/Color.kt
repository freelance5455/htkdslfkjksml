package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Obsidian & Deep Amethyst Editorial Palette (ChatGPT + Claude style)
val NexusBackground = Color(0xFF09080E)
val NexusBackgroundGlow = Color(0xFF141023)
val NexusCodeBackground = Color(0xFF06050A)
val NexusSurface = Color(0xFF12101B)
val NexusSurfaceVariant = Color(0xFF181525)
val NexusSurfaceElevated = Color(0xFF241B3B)

// Primary Amethyst & Deep Violet Accents
val NexusCyan = Color(0xFF9D6BFF)
val NexusCyanDim = Color(0xFF6D3BDD)
val NexusCyanDark = Color(0xFF261942)

val NexusViolet = Color(0xFF7C3AED)
val NexusVioletLight = Color(0xFFD8B4FE)
val NexusVioletDark = Color(0xFF1D1236)

// Status & Semantic Tones
val NexusEmerald = Color(0xFFB794F4)
val NexusEmeraldDim = Color(0xFF3F2373)

val NexusRose = Color(0xFFE11D48)
val NexusAmber = Color(0xFFC4B5FD)

// Editorial Typography Colors
val NexusTextPrimary = Color(0xFFF4F1FA)
val NexusTextSecondary = Color(0xFFB3AAC9)
val NexusTextTertiary = Color(0xFF766D8F)

// Subtle Hairline Dividers (0.8dp)
val NexusBorder = Color(0xFF231D34)
val NexusBorderFocused = Color(0xFF9D6BFF)

val NexusObsidianBackdrop = Brush.verticalGradient(
    colors = listOf(
        NexusBackground,
        NexusBackground,
        Color(0xFF0C0914)
    )
)

val NexusAuroraBackdrop = Brush.radialGradient(
    colors = listOf(
        Color(0xFF22143F),
        Color(0xFF110C1E),
        NexusBackground
    )
)
