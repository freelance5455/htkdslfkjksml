package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Minimalist Dark Cyberpunk / Obsidian Palette
val NexusBackground = Color(0xFF080B10)
val NexusCodeBackground = Color(0xFF06090E)
val NexusSurface = Color(0xFF0E131E)
val NexusSurfaceVariant = Color(0xFF141C2C)
val NexusSurfaceElevated = Color(0xFF1A2438)

val NexusCyan = Color(0xFF00F0FF)
val NexusCyanDim = Color(0xFF00A3B5)
val NexusCyanDark = Color(0xFF003840)

val NexusViolet = Color(0xFF8B5CF6)
val NexusVioletLight = Color(0xFFA78BFA)
val NexusVioletDark = Color(0xFF4C1D95)

val NexusEmerald = Color(0xFF10B981)
val NexusEmeraldDim = Color(0xFF059669)

val NexusRose = Color(0xFFF43F5E)
val NexusAmber = Color(0xFFF59E0B)

val NexusTextPrimary = Color(0xFFF1F5F9)
val NexusTextSecondary = Color(0xFF94A3B8)
val NexusTextTertiary = Color(0xFF64748B)

val NexusBorder = Color(0xFF202B3E)
val NexusBorderFocused = Color(0xFF00F0FF)
