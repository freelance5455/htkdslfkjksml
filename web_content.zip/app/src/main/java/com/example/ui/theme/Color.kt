package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NavyPrimary = Color(0xFF0F3D78)
val NavyDark = Color(0xFF0A2540)
val NavyLight = Color(0xFF2563EB)

val EmeraldGreen = Color(0xFF059669)
val EmeraldLight = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFD1FAE5)

val AmberGold = Color(0xFFD97706)
val AmberLight = Color(0xFFFBBF24)

val SlateBackground = Color(0xFFF8FAFC)
val SlateSurface = Color(0xFFFFFFFF)
val SlateBorder = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)

val DarkBackground = Color(0xFF0B132B)
val DarkSurface = Color(0xFF1C2541)
val DarkBorder = Color(0xFF3A506B)
