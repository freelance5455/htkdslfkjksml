package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Stealth Obsidian & Neon Palette for Yiffy
val YiffyDarkBackground = Color(0xFF0A0B0E)
val YiffySurface = Color(0xFF13151B)
val YiffySurfaceVariant = Color(0xFF1C1F28)
val YiffyCardBorder = Color(0xFF2B2F3D)

val YiffyPrimary = Color(0xFFFF2E7E) // Electric Magenta
val YiffyPrimaryVariant = Color(0xFFFF539A)
val YiffySecondary = Color(0xFF8A4FFF) // Electric Violet
val YiffyTertiary = Color(0xFF00E5FF) // Cyber Cyan

val YiffyTextPrimary = Color(0xFFF0F2F8)
val YiffyTextSecondary = Color(0xFF9EA5B6)
val YiffyTextMuted = Color(0xFF5E6575)

// Tag category colors
val TagArtist = Color(0xFFFFB300)
val TagCharacter = Color(0xFF00E5FF)
val TagCopyright = Color(0xFFD500F9)
val TagGeneral = Color(0xFF90A4AE)
val TagMeta = Color(0xFF78909C)

// Platform Branding colors
val PlatformPornhub = Color(0xFFFF9900)
val PlatformE621 = Color(0xFF00549E)
val PlatformRule34 = Color(0xFFAAE5A4)
val PlatformBluesky = Color(0xFF1185FE)
val PlatformTwitter = Color(0xFF1DA1F2)
val PlatformReddit = Color(0xFFFF4500)
val PlatformEHentai = Color(0xFFED3554)
val PlatformMyReadingManga = Color(0xFF9C27B0)
