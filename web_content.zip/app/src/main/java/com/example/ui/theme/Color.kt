package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aether Personal OS Core Palette
val AetherBackgroundOled = Color(0xFF0B0B0F)
val AetherBackgroundSlate = Color(0xFF13131A)
val AetherSurface = Color(0xFF1A1A22)
val AetherSurfaceElevated = Color(0xFF252530)
val AetherSurfaceHighest = Color(0xFF323240)

val AetherViolet = Color(0xFF8B5CF6)
val AetherVioletPressed = Color(0xFF7C3AED)
val AetherLavender = Color(0xFFB9A0FF)

val AetherTextPrimary = Color(0xFFF1F0F5)
val AetherTextSecondary = Color(0xFF8E8D9A)

val AetherBorderSubtle = Color(0x14FFFFFF) // White at ~8% opacity
val AetherBorderElevated = Color(0x1FFFFFFF) // White at ~12% opacity

val AetherError = Color(0xFFFFB4AB)
val AetherErrorContainer = Color(0xFF93000A)
val AetherSuccess = Color(0xFF86EFAC)
val AetherAmber = Color(0xFFFFB869)

// Crisp Light Alternative Palette (optional in Settings)
val LightBackground = Color(0xFFF7F7FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFEEEEF4)
val LightSurfaceHighest = Color(0xFFE2E1EC)
val LightTextPrimary = Color(0xFF14141C)
val LightTextSecondary = Color(0xFF646373)
val LightBorderSubtle = Color(0x14000000)
val LightBorderElevated = Color(0x1F000000)
val LightViolet = Color(0xFF7C3AED)
val LightLavender = Color(0xFF5B21B6)
val LightError = Color(0xFFBA1A1A)
