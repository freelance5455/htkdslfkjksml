package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ForestDark = Color(0xFF19241E)
val ForestSurface = Color(0xFF202C23)
val SageGreen = Color(0xFFB6CAA1)
val WarmCream = Color(0xFFF4F0E6)
val MutedSage = Color(0xFFC1C6BC)
val GoldenSun = Color(0xFFE5D2A9)
