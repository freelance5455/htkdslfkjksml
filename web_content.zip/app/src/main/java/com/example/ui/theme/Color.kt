package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Emerald Studio Palette
val StudioBlack = Color(0xFF090D0B)
val StudioDarkBg = Color(0xFF0D1410)
val StudioSurface = Color(0xFF131C17)
val StudioSurfaceElevated = Color(0xFF1A2620)
val StudioSurfaceVariant = Color(0xFF22322A)

// Emerald & Neon Accents
val EmeraldPrimary = Color(0xFF00E599)
val EmeraldLight = Color(0xFF5CFFC1)
val EmeraldDark = Color(0xFF00875A)
val EmeraldContainer = Color(0xFF053826)
val EmeraldGlow = Color(0x3300E599)

// Metallic Studio Accents (Boss DD-3 inspired metallic controls)
val MetallicGold = Color(0xFFD4AF37)
val MetallicGoldLight = Color(0xFFF3E5AB)
val MetallicGoldDark = Color(0xFF997A15)
val MetallicSilver = Color(0xFFCFD8DC)
val MetallicSilverDark = Color(0xFF78909C)
val MetallicKnobBg = Color(0xFF1C2420)
val MetallicKnobBorder = Color(0xFF384B42)

// Meter & Status LEDs
val LedGreen = Color(0xFF00FF7F)
val LedYellow = Color(0xFFFFB300)
val LedRed = Color(0xFFFF3B30)
val LedOff = Color(0xFF1F2B24)

// Studio Text & Outlines
val TextPrimary = Color(0xFFEFFBF5)
val TextSecondary = Color(0xFF9CB8A9)
val TextMuted = Color(0xFF647B70)
val StudioBorder = Color(0xFF27382F)
val StudioDivider = Color(0xFF1E2B24)
