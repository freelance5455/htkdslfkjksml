package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aviation ATC Operational Color Palette
val AtcDeepNavy = Color(0xFF08121E)
val AtcSurfaceDark = Color(0xFF0E1A29)
val AtcCardDark = Color(0xFF162538)
val AtcBorderDark = Color(0xFF22364E)

val AtcLightBg = Color(0xFFF1F5F9)
val AtcLightSurface = Color(0xFFFFFFFF)
val AtcLightCard = Color(0xFFF8FAFC)
val AtcLightBorder = Color(0xFFCBD5E1)

// Primary accents
val AtcAeroBlueDark = Color(0xFF38BDF8)
val AtcAeroBlueLight = Color(0xFF0284C7)
val AtcSecondaryDark = Color(0xFF94A3B8)
val AtcSecondaryLight = Color(0xFF475569)

// Flight category operational indicators
val CategoryVfr = Color(0xFF10B981)   // Green
val CategoryMvfr = Color(0xFF0284C7)  // Blue
val CategoryIfr = Color(0xFFF59E0B)   // Amber
val CategoryLifr = Color(0xFFD946EF)  // Magenta

// Status indicators
val StatusGreen = Color(0xFF22C55E)
val StatusYellow = Color(0xFFEAB308)
val StatusRed = Color(0xFFEF4444)
val StatusGray = Color(0xFF64748B)

// Runway condition RWYCC colors (0-6)
val Rwycc6Color = Color(0xFF10B981) // Good
val Rwycc5Color = Color(0xFF34D399) // Good to Medium
val Rwycc4Color = Color(0xFF38BDF8) // Medium to Good
val Rwycc3Color = Color(0xFFFBBF24) // Medium
val Rwycc2Color = Color(0xFFF97316) // Medium to Poor
val Rwycc1Color = Color(0xFFEF4444) // Poor
val Rwycc0Color = Color(0xFF991B1B) // Less than Poor
