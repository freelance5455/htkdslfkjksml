package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Zing Original Color Palette
val ZingBlack = Color(0xFF0D0C13)
val ZingDarkSurface = Color(0xFF16151E)
val ZingCardSurface = Color(0xFF201E2B)
val ZingBorder = Color(0xFF2C2A3B)

val ZingNeonPink = Color(0xFFFF2A6D)
val ZingElectricViolet = Color(0xFF8A2BE2)
val ZingCyan = Color(0xFF00F2FE)
val ZingGold = Color(0xFFFFD166)
val ZingEmerald = Color(0xFF06D6A0)

val ZingTextPrimary = Color(0xFFFFFFFF)
val ZingTextSecondary = Color(0xFFA5A4BA)
val ZingTextMuted = Color(0xFF6E6D82)

val ZingOverlayDark = Color(0x99000000)
val ZingHeartRed = Color(0xFFFF3366)
