package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Core: Trust, Provenance & Auction Authority
val EmeraldPrimary = Color(0xFF0B5D4B)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldContainer = Color(0xFFC8EFE3)
val EmeraldOnContainer = Color(0xFF002119)

val GoldSecondary = Color(0xFFC98A2C)
val GoldOnSecondary = Color(0xFFFFFFFF)
val GoldContainer = Color(0xFFFFE5BA)
val GoldOnContainer = Color(0xFF2B1800)

val SlateTertiary = Color(0xFF1E3A5F)
val SlateOnTertiary = Color(0xFFFFFFFF)
val SlateContainer = Color(0xFFD5E3FF)
val SlateOnContainer = Color(0xFF001C3B)

// Warm Ivory Light Surfaces
val AlabasterBackground = Color(0xFFF9F8F5)
val WarmSurface = Color(0xFFFFFFFF)
val WarmSurfaceVariant = Color(0xFFECE9E1)
val CharcoalOnSurface = Color(0xFF161D1B)
val MutedOnSurfaceVariant = Color(0xFF535E5A)
val SubtleOutline = Color(0xFFD5D1C7)

// Deep Obsidian Dark Surfaces
val ObsidianBackground = Color(0xFF0E1412)
val ObsidianSurface = Color(0xFF161E1B)
val ObsidianSurfaceVariant = Color(0xFF222C28)
val IvoryOnDark = Color(0xFFE9EEEB)
val MutedOnDark = Color(0xFF9FB0A9)
val DarkOutline = Color(0xFF33403B)

val EmeraldDarkPrimary = Color(0xFF5AD5B5)
val EmeraldDarkOnPrimary = Color(0xFF00382C)
val EmeraldDarkContainer = Color(0xFF004F3E)
val EmeraldDarkOnContainer = Color(0xFFC8EFE3)

val GoldDarkSecondary = Color(0xFFF5BF69)
val GoldDarkOnSecondary = Color(0xFF452B00)
val GoldDarkContainer = Color(0xFF633F00)
val GoldDarkOnContainer = Color(0xFFFFE5BA)

// Semantic Status Colors
val UrgentCrimson = Color(0xFFB3261E)
val UrgentCrimsonContainer = Color(0xFFF9DEDC)
val VerifiedEmerald = Color(0xFF146C43)
val VerifiedEmeraldContainer = Color(0xFFD1F2E1)
