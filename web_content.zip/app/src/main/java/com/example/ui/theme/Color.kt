package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimary = Color(0xFF1B5E3F)
val EmeraldOnPrimary = Color(0xFFFFFFFF)
val EmeraldPrimaryContainer = Color(0xFFD0F0DE)
val EmeraldOnPrimaryContainer = Color(0xFF07291A)

val GoldSecondary = Color(0xFF8A6518)
val GoldOnSecondary = Color(0xFFFFFFFF)
val GoldSecondaryContainer = Color(0xFFFFEAB8)
val GoldOnSecondaryContainer = Color(0xFF2D1E00)

val SlateTertiary = Color(0xFF39656B)
val SlateOnTertiary = Color(0xFFFFFFFF)
val SlateTertiaryContainer = Color(0xFFBDEAF0)
val SlateOnTertiaryContainer = Color(0xFF001F24)

val ParchmentBackground = Color(0xFFF6F4EF)
val ParchmentSurface = Color(0xFFFFFDF9)
val ParchmentSurfaceVariant = Color(0xFFE9E4D6)
val InkOnSurface = Color(0xFF1A1F1C)
val MutedOnSurfaceVariant = Color(0xFF5A635E)
val WarmOutline = Color(0xFFC5BFA9)
val WarmOutlineVariant = Color(0xFFE0DAC8)

val DangerRed = Color(0xFFB3261E)
val DangerContainer = Color(0xFFF9DEDC)
val WhatsAppGreen = Color(0xFF1F9D55)

// Dark mode tokens
val DarkEmeraldPrimary = Color(0xFF6DD59E)
val DarkEmeraldOnPrimary = Color(0xFF003822)
val DarkEmeraldContainer = Color(0xFF0D4D32)
val DarkEmeraldOnContainer = Color(0xFFD0F0DE)

val DarkGoldSecondary = Color(0xFFE5C16C)
val DarkGoldOnSecondary = Color(0xFF422D00)
val DarkGoldContainer = Color(0xFF5F4200)
val DarkGoldOnContainer = Color(0xFFFFEAB8)

val DarkBg = Color(0xFF121614)
val DarkSurface = Color(0xFF1B201D)
val DarkSurfaceVariant = Color(0xFF272E2A)
val DarkOnSurface = Color(0xFFECEAE4)
val DarkOnSurfaceVariant = Color(0xFFAEABA2)
val DarkOutline = Color(0xFF4B524D)
