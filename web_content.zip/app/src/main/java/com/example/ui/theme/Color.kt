package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Literary Atelier Palette - Light (Warm Parchment & Deep Ink)
val ParchmentBackground = Color(0xFFFBF8F3)
val ParchmentSurface = Color(0xFFF4EFE6)
val ParchmentSurfaceVariant = Color(0xFFE9E0D1)
val InkOnBackground = Color(0xFF1C1917)
val InkOnSurfaceVariant = Color(0xFF575049)

val CrimsonPrimary = Color(0xFF7C1F28)
val CrimsonOnPrimary = Color(0xFFFFFFFF)
val CrimsonContainer = Color(0xFFFCE8EA)
val CrimsonOnContainer = Color(0xFF3B080E)

val AntiqueGoldSecondary = Color(0xFFB5832A)
val AntiqueGoldOnSecondary = Color(0xFFFFFFFF)
val AntiqueGoldContainer = Color(0xFFFAEBD0)
val AntiqueGoldOnContainer = Color(0xFF3B2806)

val SlateTertiary = Color(0xFF283845)
val SlateOnTertiary = Color(0xFFFFFFFF)
val SlateContainer = Color(0xFFD6E3F0)
val SlateOnContainer = Color(0xFF0E1A24)

// Literary Atelier Palette - Dark (Midnight Library & Warm Amber)
val MidnightBackground = Color(0xFF12161B)
val MidnightSurface = Color(0xFF1B2129)
val MidnightSurfaceVariant = Color(0xFF262F3A)
val CreamOnBackground = Color(0xFFF3ECE2)
val CreamOnSurfaceVariant = Color(0xFFC5BBAE)

val GoldDarkPrimary = Color(0xFFE5B869)
val GoldDarkOnPrimary = Color(0xFF2E1F04)
val GoldDarkContainer = Color(0xFF4B350C)
val GoldDarkOnContainer = Color(0xFFFCE1B6)

val RoseDarkSecondary = Color(0xFFE88B93)
val RoseDarkOnSecondary = Color(0xFF471117)
val RoseDarkContainer = Color(0xFF631B22)
val RoseDarkOnContainer = Color(0xFFFFD9DC)

val SageDarkTertiary = Color(0xFF8CC4B2)
val SageDarkOnTertiary = Color(0xFF0B372B)
val SageDarkContainer = Color(0xFF194E3F)
val SageDarkOnContainer = Color(0xFFA7E0CE)

// Typographic Book Cover Accents
val CoverCrimsonBg = Color(0xFF5E1920)
val CoverCrimsonBorder = Color(0xFFE0B46A)
val CoverMidnightBg = Color(0xFF1B2838)
val CoverMidnightBorder = Color(0xFFD4AF37)
val CoverEmeraldBg = Color(0xFF173B2E)
val CoverEmeraldBorder = Color(0xFFD8C287)
val CoverParchmentBg = Color(0xFFEFE6D5)
val CoverParchmentBorder = Color(0xFF6E472B)
val CoverObsidianBg = Color(0xFF1E1E22)
val CoverObsidianBorder = Color(0xFFC5A059)
