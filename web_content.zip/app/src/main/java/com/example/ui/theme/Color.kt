package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Smart Jones Security Brand Palette: Deep Navy Blue, Safety Orange, White, Dark Grey
val NavyDeep = Color(0xFF0B1F3A)
val NavyElevated = Color(0xFF122B4D)
val NavyMuted = Color(0xFF1E3A5F)
val NavyContainer = Color(0xFFE2E8F2)

val OrangeBrand = Color(0xFFFF6B00)
val OrangeBright = Color(0xFFFF8533)
val OrangeContainer = Color(0xFFFFEDE0)
val OrangeDark = Color(0xFFC85000)

val PureWhite = Color(0xFFFFFFFF)
val OffWhite = Color(0xFFF6F8FB)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEAF0F6)

val DarkGrey = Color(0xFF1E293B)
val CharcoalGrey = Color(0xFF334155)
val SlateGrey = Color(0xFF64748B)
val BorderGrey = Color(0xFFD5DEE8)

val VerifiedGreen = Color(0xFF0E9F6E)
val VerifiedGreenContainer = Color(0xFFDDF7EC)
val WarningAmber = Color(0xFFD97706)
val WarningAmberContainer = Color(0xFFFEF3C7)
val ErrorRed = Color(0xFFDC2626)
val ErrorRedContainer = Color(0xFFFEE2E2)
