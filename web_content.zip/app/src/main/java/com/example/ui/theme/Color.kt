package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberNavy = Color(0xFF070F1B)
val CyberCard = Color(0xFF0D1E35)
val CyberCardBorder = Color(0xFF1B355A)
val CyberSurfaceVariant = Color(0xFF162A48)
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDim = Color(0xFF0099B8)
val CyberTeal = Color(0xFF00F5D4)
val CyberGreen = Color(0xFF00E676)
val CyberRed = Color(0xFFFF3366)
val CyberAmber = Color(0xFFFFB703)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
