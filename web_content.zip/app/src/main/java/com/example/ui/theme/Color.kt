package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors (Electric Cyan & Tech Indigo)
val CyberCyan = Color(0xFF00B4D8)
val CyberCyanLight = Color(0xFF90E0EF)
val CyanPrimaryDark = Color(0xFF0077B6)

val TechNavyDark = Color(0xFF0B1329)
val TechNavySurface = Color(0xFF111C38)
val TechNavyCard = Color(0xFF162244)
val TechNavyElevated = Color(0xFF1E2D56)

val ElectricViolet = Color(0xFF7C3AED)
val ElectricVioletLight = Color(0xFFA78BFA)

val SuccessGreen = Color(0xFF10B981)
val SuccessGreenContainer = Color(0xFF064E3B)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberContainer = Color(0xFF78350F)
val ErrorRed = Color(0xFFEF4444)
val ErrorRedContainer = Color(0xFF7F1D1D)

// Light Theme Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOutline = Color(0xFFCBD5E1)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)

// Dark Theme Palette
val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF10172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkOutline = Color(0xFF334155)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
