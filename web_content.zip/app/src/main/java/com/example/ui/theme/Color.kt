package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GNMTC SGNR Nursing College Theme: Green, White, and Blue Palette
val NursingGreenPrimary = Color(0xFF0D6938)
val NursingGreenOnPrimary = Color(0xFFFFFFFF)
val NursingGreenContainer = Color(0xFFE6F4EA)
val NursingGreenOnContainer = Color(0xFF023618)

val ClinicalBlueSecondary = Color(0xFF0284C7)
val ClinicalBlueOnSecondary = Color(0xFFFFFFFF)
val ClinicalBlueContainer = Color(0xFFE0F2FE)
val ClinicalBlueOnContainer = Color(0xFF03456C)

val MedicalTealTertiary = Color(0xFF0F766E)
val MedicalTealOnTertiary = Color(0xFFFFFFFF)
val MedicalTealContainer = Color(0xFFCCFBF1)
val MedicalTealOnContainer = Color(0xFF115E59)

val CollegeBackgroundLight = Color(0xFFF8FAFC)
val CollegeSurfaceLight = Color(0xFFFFFFFF)
val CollegeSurfaceVariantLight = Color(0xFFF1F5F9)
val CollegeOnSurfaceLight = Color(0xFF0F172A)
val CollegeOutlineLight = Color(0xFFCBD5E1)

// Dark Theme Variants
val NursingGreenPrimaryDark = Color(0xFF4ADE80)
val ClinicalBlueSecondaryDark = Color(0xFF38BDF8)
val MedicalTealTertiaryDark = Color(0xFF2DD4BF)
val CollegeBackgroundDark = Color(0xFF0F172A)
val CollegeSurfaceDark = Color(0xFF1E293B)
val CollegeSurfaceVariantDark = Color(0xFF334155)
val CollegeOnSurfaceDark = Color(0xFFF8FAFC)
val CollegeOutlineDark = Color(0xFF475569)

// Accent Status Colors
val StatusReceivedColor = Color(0xFF3B82F6)
val StatusUnderReviewColor = Color(0xFFF59E0B)
val StatusInProgressColor = Color(0xFF8B5CF6)
val StatusResolvedColor = Color(0xFF10B981)
val StatusRejectedColor = Color(0xFFEF4444)
