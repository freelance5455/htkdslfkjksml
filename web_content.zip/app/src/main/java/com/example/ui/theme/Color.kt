package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Normal (Default) Light Theme Palette - Clean, focused, academic indigo & neutral
val PrimaryLight = Color(0xFF2563EB)        // Royal Indigo Blue
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFDBEAFE)
val OnPrimaryContainerLight = Color(0xFF1E3A8A)

val SecondaryLight = Color(0xFF0D9488)      // Scholarly Teal
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFCCFBF1)
val OnSecondaryContainerLight = Color(0xFF134E4A)

val BackgroundLight = Color(0xFFF8FAFC)     // Clean off-white paper
val OnBackgroundLight = Color(0xFF0F172A)   // Deep slate
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Palette - Low-light friendly, high-contrast text
val PrimaryDark = Color(0xFF60A5FA)         // High-contrast soft blue
val OnPrimaryDark = Color(0xFF0B1B3A)
val PrimaryContainerDark = Color(0xFF1D4ED8)
val OnPrimaryContainerDark = Color(0xFFEFF6FF)

val SecondaryDark = Color(0xFF2DD4BF)       // Luminous teal
val OnSecondaryDark = Color(0xFF042F2E)
val SecondaryContainerDark = Color(0xFF0F766E)
val OnSecondaryContainerDark = Color(0xFFF0FDFA)

val BackgroundDark = Color(0xFF0B0F19)      // Midnight obsidian
val OnBackgroundDark = Color(0xFFF1F5F9)    // Crisp high-contrast text
val SurfaceDark = Color(0xFF131B2E)         // Deep midnight surface
val OnSurfaceDark = Color(0xFFF1F5F9)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)

// Status & Accent Colors
val ErrorRed = Color(0xFFDC2626)
val ErrorContainerLight = Color(0xFFFEE2E2)
val ErrorContainerDark = Color(0xFF7F1D1D)
val SuccessGreen = Color(0xFF16A34A)
val WarningAmber = Color(0xFFD97706)
