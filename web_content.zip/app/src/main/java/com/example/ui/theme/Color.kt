package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Obsidian & Electric Cyan / Indigo Studio Palette
val StudioObsidian = Color(0xFF0B0F19)
val StudioSurface = Color(0xFF111827)
val StudioSurfaceElevated = Color(0xFF1E293B)
val StudioSurfaceVariant = Color(0xFF26334D)

val ElectricCyan = Color(0xFF38BDF8)
val ElectricCyanContainer = Color(0xFF0C4A6E)
val OnElectricCyan = Color(0xFF042F49)

val IndigoPulse = Color(0xFF818CF8)
val IndigoContainer = Color(0xFF312E81)

val EmeraldMint = Color(0xFF34D399)
val EmeraldContainer = Color(0xFF064E3B)

val AmberSignal = Color(0xFFFBBF24)
val RoseAlert = Color(0xFFFB7185)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val BorderSubtleDark = Color(0xFF334155)

// Light mode high-contrast architectural studio palette
val StudioLightBackground = Color(0xFFF8FAFC)
val StudioLightSurface = Color(0xFFFFFFFF)
val StudioLightSurfaceVariant = Color(0xFFE2E8F0)
val ElectricBlueLight = Color(0xFF0284C7)
val IndigoLight = Color(0xFF4F46E5)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
