package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VelvetMidnightBg = Color(0xFF0B0E17)
val VelvetMidnightSurface = Color(0xFF141824)
val VelvetMidnightSurfaceElevated = Color(0xFF1E2436)

val VelvetCyan = Color(0xFF38BDF8)
val VelvetCyanContainer = Color(0xFF0C4A6E)
val VelvetCoral = Color(0xFFFB7185)
val VelvetCoralContainer = Color(0xFF881337)
val VelvetIndigo = Color(0xFF818CF8)

val VelvetLightBg = Color(0xFFF6F8FC)
val VelvetLightSurface = Color(0xFFFFFFFF)
val VelvetLightSurfaceVariant = Color(0xFFE9EEF7)
val VelvetPrimaryLight = Color(0xFF0284C7)
val VelvetSecondaryLight = Color(0xFFE11D48)
val VelvetOnLight = Color(0xFF0F172A)
val VelvetOnLightMuted = Color(0xFF475569)
