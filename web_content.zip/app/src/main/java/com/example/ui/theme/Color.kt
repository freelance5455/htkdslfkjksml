package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aviation ATC Operational Daylight Color Palette (No Dark Mode)
// 1. Ocean Blue for Header & Bottom Navigation Bar
val OceanBlue = Color(0xFF026AA7)
val OceanBlueDark = Color(0xFF014E7D)
val OceanBlueBarBg = Color(0xFF025B8F)
val OceanBlueLight = Color(0xFF0382CE)

// 2. Soft Lilac Background (پشت زمینه یاسی ملایم)
val SoftLilacBg = Color(0xFFF5EEF8)
val SoftLilacSurface = Color(0xFFFFFFFF)

// 3. Soft Turquoise Blue Card for Airport Search on Dashboard (آبی فیروزه ای ملایم)
val DashboardSearchCardBg = Color(0xFFB2EBF2)
val DashboardSearchCardBorder = Color(0xFF0097A7)
val DashboardSearchCardText = Color(0xFF004D40)

// 4. METAR Card: Soft Purple / Mild Violet (بنفش ملایم - خود کارت کاملاً بنفش)
val MetarCardBg = Color(0xFFDDD6FE)
val MetarCardBorder = Color(0xFF8B5CF6)
val MetarCardText = Color(0xFF3B0764)

// 5. TAF Card: Soft Green / Mild Green (سبز ملایم - خود کارت کاملاً سبز)
val TafCardBg = Color(0xFFBBF7D0)
val TafCardBorder = Color(0xFF22C55E)
val TafCardText = Color(0xFF14532D)

// 6. SIGMET Card: Soft Orange / Mild Orange (نارنجی ملایم - خود کارت کاملاً نارنجی)
val SigmetCardBg = Color(0xFFFED7AA)
val SigmetCardBorder = Color(0xFFF97316)
val SigmetCardText = Color(0xFF7C2D12)

// 7. SNOWTAM Card: Soft Blue / Mild Blue (آبی ملایم - خود کارت کاملاً آبی)
val SnowtamCardBg = Color(0xFFBFDBFE)
val SnowtamCardBorder = Color(0xFF3B82F6)
val SnowtamCardText = Color(0xFF1E3A8A)

// 8. WIND ALOFT Card: Soft Cyan/Teal (باد سطوح فوقانی)
val WindAloftCardBg = Color(0xFFCCFBF1)
val WindAloftCardBorder = Color(0xFF14B8A6)
val WindAloftCardText = Color(0xFF0F766E)

val AtcSkyBlue = Color(0xFF0284C7)
val AtcSkyBlueDark = Color(0xFF0369A1)
val AtcSkyLight = Color(0xFFE0F2FE)
val AtcSkyLightest = Color(0xFFF0F9FF)
val AtcConsoleBg = SoftLilacBg
val AtcConsoleSurface = Color(0xFFFFFFFF)
val AtcCardDefaultBg = Color(0xFFFFFFFF)
val AtcCardBorder = Color(0xFFE2E8F0)

val AtcTextMain = Color(0xFF0F172A)
val AtcTextMuted = Color(0xFF475569)
val AtcTextSubtle = Color(0xFF64748B)

// Primary accents
val AtcAeroBlueLight = Color(0xFF026AA7)
val AtcAeroBlueDark = Color(0xFF014E7D)
val AtcAeroBlueHover = Color(0xFF014E7D)
val AtcSecondaryLight = Color(0xFF334155)

// Information-Specific Thematic Card Colors (Soft, Ergonomic, Non-Tiring for ATC)
// 1. Wind & Gust Card (Aero Cyan/Sky)
val WindCardBg = Color(0xFFF0F9FF)
val WindCardBorder = Color(0xFFBAE6FD)
val WindAccent = Color(0xFF0284C7)
val WindGustBadgeBg = Color(0xFFFFF7ED)
val WindGustBadgeBorder = Color(0xFFFDBA74)
val WindGustBadgeText = Color(0xFFC2410C)

// 2. Visibility & RVR Cards (Flight Category Themed)
val CategoryVfr = Color(0xFF15803D)   // Calming Green
val CategoryVfrBg = Color(0xFFF0FDF4)
val CategoryVfrBorder = Color(0xFF86EFAC)

val CategoryMvfr = Color(0xFF0369A1)  // Aero Blue
val CategoryMvfrBg = Color(0xFFF0F9FF)
val CategoryMvfrBorder = Color(0xFF7DD3FC)

val CategoryIfr = Color(0xFFB45309)   // Attention Amber
val CategoryIfrBg = Color(0xFFFFFBEB)
val CategoryIfrBorder = Color(0xFFFCD34D)

val CategoryLifr = Color(0xFF9D174D)  // Caution Magenta
val CategoryLifrBg = Color(0xFFFDF2F8)
val CategoryLifrBorder = Color(0xFFF472B6)

// 3. Clouds & Ceiling Card (Soft Indigo/Periwinkle)
val CloudsCardBg = Color(0xFFF5F3FF)
val CloudsCardBorder = Color(0xFFDDD6FE)
val CloudsAccent = Color(0xFF4F46E5)

// 4. Temperature & Dew Point Card (Warm Apricot/Coral)
val TempCardBg = Color(0xFFFFF7ED)
val TempCardBorder = Color(0xFFFED7AA)
val TempAccent = Color(0xFFEA580C)

// 5. Altimeter & QNH Pressure Card (Crisp Teal)
val QnhCardBg = Color(0xFFF0FDFA)
val QnhCardBorder = Color(0xFF99F6E4)
val QnhAccent = Color(0xFF0D9488)

// 6. Raw Message Terminal Box (Slate Technical)
val RawTerminalBg = Color(0xFFF8FAFC)
val RawTerminalBorder = Color(0xFFCBD5E1)
val RawTerminalText = Color(0xFF0B2545)

// 7. Operational Status & Alerts
val StatusGreen = Color(0xFF16A34A)
val StatusYellow = Color(0xFFD97706)
val StatusRed = Color(0xFFDC2626)
val StatusGray = Color(0xFF64748B)

// 8. TAF Forecast Group Accents
val TafBaseCardBg = Color(0xFFFFFFFF)
val TafTempoCardBg = Color(0xFFFFFBEB)
val TafTempoBorder = Color(0xFFFDE68A)
val TafTempoText = Color(0xFFB45309)

val TafBecmgCardBg = Color(0xFFFAF5FF)
val TafBecmgBorder = Color(0xFFE9D5FF)
val TafBecmgText = Color(0xFF7E22CE)

val TafProbCardBg = Color(0xFFF0FDFA)
val TafProbBorder = Color(0xFFCCFBF1)
val TafProbText = Color(0xFF0F766E)

// 9. SIGMET Hazards
val SigmetTurbBg = Color(0xFFFFFBEB)
val SigmetTurbBorder = Color(0xFFFCD34D)
val SigmetTurbText = Color(0xFFB45309)

val SigmetTsBg = Color(0xFFFEF2F2)
val SigmetTsBorder = Color(0xFFFECACA)
val SigmetTsText = Color(0xFFB91C1C)

val SigmetIceBg = Color(0xFFF0F9FF)
val SigmetIceBorder = Color(0xFFBAE6FD)
val SigmetIceText = Color(0xFF0369A1)

// 10. Runway RWYCC Colors (0-6)
val Rwycc6Color = Color(0xFF16A34A) // Good
val Rwycc5Color = Color(0xFF059669) // Good to Medium
val Rwycc4Color = Color(0xFF0284C7) // Medium to Good
val Rwycc3Color = Color(0xFFD97706) // Medium
val Rwycc2Color = Color(0xFFEA580C) // Medium to Poor
val Rwycc1Color = Color(0xFFDC2626) // Poor
val Rwycc0Color = Color(0xFF991B1B) // Less than Poor
