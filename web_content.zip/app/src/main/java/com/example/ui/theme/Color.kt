package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFFFB300)
val GoldLight = Color(0xFFFFD54F)
val GoldDark = Color(0xFFFF8F00)

val GemCyan = Color(0xFF00D2FF)
val GemDark = Color(0xFF0099CC)

val RoyalPurple = Color(0xFF8A2BE2)
val DeepViolet = Color(0xFF6C5CE7)

val DarkBg = Color(0xFF0D0B16)
val DarkSurface = Color(0xFF161324)
val DarkCard = Color(0xFF1F1A33)
val DarkCardHover = Color(0xFF2A2345)
val DarkBorder = Color(0xFF2E274D)

val SuccessGreen = Color(0xFF2ED573)
val DangerRed = Color(0xFFFF4757)
val WarningOrange = Color(0xFFFFA502)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFAAA5B8)
val TextMuted = Color(0xFF756F88)
