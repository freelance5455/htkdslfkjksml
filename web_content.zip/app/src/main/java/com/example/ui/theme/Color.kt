package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo / Electric Violet
val DopingPrimary = Color(0xFF4F46E5)
val DopingPrimaryVariant = Color(0xFF4338CA)
val DopingPrimaryLight = Color(0xFF818CF8)
val DopingPrimaryContainer = Color(0xFFE0E7FF)

// Secondary Energetic Amber / Gold Lightning
val DopingAmber = Color(0xFFF59E0B)
val DopingAmberLight = Color(0xFFFDE68A)
val DopingAmberDark = Color(0xFFD97706)

// Accent Cyan / Brain Teal
val DopingTeal = Color(0xFF06B6D4)
val DopingTealLight = Color(0xFFCFFAFE)

// Support Emerald / Success
val DopingGreen = Color(0xFF10B981)
val DopingGreenContainer = Color(0xFFD1FAE5)

// Support Coral / Error
val DopingRed = Color(0xFFEF4444)
val DopingRedContainer = Color(0xFFFEE2E2)

// Dark Palette
val DopingDarkBackground = Color(0xFF0F172A)
val DopingDarkSurface = Color(0xFF1E293B)
val DopingDarkSurfaceVariant = Color(0xFF334155)

// Light Palette
val DopingLightBackground = Color(0xFFF8FAFC)
val DopingLightSurface = Color(0xFFFFFFFF)
val DopingLightSurfaceVariant = Color(0xFFF1F5F9)
val DopingTextPrimary = Color(0xFF0F172A)
val DopingTextSecondary = Color(0xFF64748B)
val DopingTextMuted = Color(0xFF94A3B8)
