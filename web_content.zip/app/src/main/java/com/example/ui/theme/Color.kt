package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Palette
val CyanPrimaryDark = Color(0xFF38BDF8)
val CyanOnPrimaryDark = Color(0xFF082F49)
val CyanPrimaryContainerDark = Color(0xFF0C4A6E)
val CyanOnPrimaryContainerDark = Color(0xFFBAE6FD)

val EmeraldSecondaryDark = Color(0xFF34D399)
val EmeraldOnSecondaryDark = Color(0xFF064E3B)
val EmeraldSecondaryContainerDark = Color(0xFF065F46)
val EmeraldOnSecondaryContainerDark = Color(0xFFA7F3D0)

val VioletTertiaryDark = Color(0xFFA78BFA)
val BackgroundDark = Color(0xFF0B111E)
val SurfaceDark = Color(0xFF131C2E)
val SurfaceVariantDark = Color(0xFF1E293B)
val SurfaceOutlineDark = Color(0xFF334155)

// Light Palette
val CyanPrimaryLight = Color(0xFF0284C7)
val CyanOnPrimaryLight = Color(0xFFFFFFFF)
val CyanPrimaryContainerLight = Color(0xFFE0F2FE)
val CyanOnPrimaryContainerLight = Color(0xFF0369A1)

val EmeraldSecondaryLight = Color(0xFF059669)
val EmeraldOnSecondaryLight = Color(0xFFFFFFFF)
val EmeraldSecondaryContainerLight = Color(0xFFD1FAE5)
val EmeraldOnSecondaryContainerLight = Color(0xFF047857)

val VioletTertiaryLight = Color(0xFF7C3AED)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val SurfaceOutlineLight = Color(0xFFCBD5E1)
