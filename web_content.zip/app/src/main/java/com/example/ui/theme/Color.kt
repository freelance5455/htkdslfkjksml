package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MerkopOrange = Color(0xFFFF6B00)
val MerkopOrangeDeep = Color(0xFFD95300)
val MerkopOrangeBright = Color(0xFFFF852D)
val MerkopOrangeSoft = Color(0xFFFFF0E4)
val MerkopOrangeContainer = Color(0xFFFFE4CE)
val MerkopOrangeBorder = Color(0xFFFFCFA8)

val MerkopWhite = Color(0xFFFFFFFF)
val MerkopWarmWhite = Color(0xFFFFFAF6)
val MerkopSurfaceLow = Color(0xFFFFF4EC)
val MerkopSurfaceCard = Color(0xFFFFFFFF)

val MerkopInk = Color(0xFF1F1916)
val MerkopInkMuted = Color(0xFF6B5B51)
val MerkopError = Color(0xFFC62828)
val MerkopErrorContainer = Color(0xFFFFEBEE)

// Dark theme warm espresso + vibrant orange
val MerkopDarkBackground = Color(0xFF16110E)
val MerkopDarkSurface = Color(0xFF211915)
val MerkopDarkSurfaceHigh = Color(0xFF2E221C)
val MerkopDarkInk = Color(0xFFFFF4EC)
val MerkopDarkInkMuted = Color(0xFFD7C2B5)
val MerkopDarkOrangeContainer = Color(0xFF5A2600)
