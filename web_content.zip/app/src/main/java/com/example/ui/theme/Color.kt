package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark Studio Palette
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF131B2E)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceElevated = Color(0xFF27354E)

val StudioCyan = Color(0xFF00E5FF)
val StudioCyanDark = Color(0xFF00B4D8)
val StudioCyanGlow = Color(0x3300E5FF)

val StudioAmber = Color(0xFFF59E0B)
val StudioAmberLight = Color(0xFFFBBF24)

val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

val DarkBorder = Color(0xFF334155)
val DarkCardBorder = Color(0x4038BDF8)

val StatusSuccess = Color(0xFF10B981)
val StatusError = Color(0xFFEF4444)
val StatusWarning = Color(0xFFF59E0B)

// Light Studio Palette
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceElevated = Color(0xFFE2E8F0)

val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)
