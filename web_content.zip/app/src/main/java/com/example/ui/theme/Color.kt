package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SagePrimary = Color(0xFF0E7C66)
val SageOnPrimary = Color(0xFFFFFFFF)
val SagePrimaryContainer = Color(0xFFBDF5E6)
val SageOnPrimaryContainer = Color(0xFF032E25)

val TerracottaSecondary = Color(0xFFFF6B4A)
val TerracottaOnSecondary = Color(0xFFFFFFFF)
val TerracottaContainer = Color(0xFFFFDFD5)
val TerracottaOnSecondaryContainer = Color(0xFF4A1104)

val LavenderTertiary = Color(0xFF6B4EFF)
val LavenderOnTertiary = Color(0xFFFFFFFF)
val LavenderContainer = Color(0xFFE7E0FF)
val LavenderOnTertiaryContainer = Color(0xFF1E0F5C)

val WarmCreamBackground = Color(0xFFFFFBF5)
val CharcoalOnBackground = Color(0xFF18201E)
val SandSurface = Color(0xFFFFFFFF)
val SandSurfaceVariant = Color(0xFFEAF3F0)
val SandOnSurfaceVariant = Color(0xFF43524E)
val OutlineWarm = Color(0xFF72837E)

val SosCrimson = Color(0xFFC62828)
val SosCrimsonContainer = Color(0xFFFFDAD6)
val SosOnCrimsonContainer = Color(0xFF410002)

// Dark / Sleep Wind-Down Palette
val DarkSagePrimary = Color(0xFF9CD4BE)
val DarkSageOnPrimary = Color(0xFF052E23)
val DarkSageContainer = Color(0xFF1B4539)
val DarkSageOnContainer = Color(0xFFB8F0DA)

val DarkTerracottaSecondary = Color(0xFFFFB5A0)
val DarkTerracottaOnSecondary = Color(0xFF561F0F)
val DarkTerracottaContainer = Color(0xFF733422)
val DarkTerracottaOnContainer = Color(0xFFFFDBD1)

val DarkLavenderTertiary = Color(0xFFD0C0FF)
val DarkLavenderOnTertiary = Color(0xFF372A5D)
val DarkLavenderContainer = Color(0xFF4E4075)
val DarkLavenderOnContainer = Color(0xFFEADDFF)

val NightSlateBackground = Color(0xFF101614)
val NightOnBackground = Color(0xFFE2E7E4)
val NightSurface = Color(0xFF171E1B)
val NightSurfaceVariant = Color(0xFF26302C)
val NightOnSurfaceVariant = Color(0xFFC0C9C4)

// Accent semantic colors for wellness cards
val WaterBlue = Color(0xFF2B7A9E)
val WaterBlueSoft = Color(0xFFD6EEF8)
val FreshAirGreen = Color(0xFF3D7A53)
val FreshAirGreenSoft = Color(0xFFD7EEDB)
val SleepIndigo = Color(0xFF474E8C)
val SleepIndigoSoft = Color(0xFFE0E2FA)
val CycleRose = Color(0xFFB84A6E)
val CycleRoseSoft = Color(0xFFFCE1EA)
val VitalityAmber = Color(0xFFB36B1E)
val VitalityAmberSoft = Color(0xFFFFEBD2)
