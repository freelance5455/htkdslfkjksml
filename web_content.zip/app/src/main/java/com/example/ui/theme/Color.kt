package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Trading Canvas Colors
val BackgroundDark = Color(0xFF090D16)
val SurfaceDark = Color(0xFF101725)
val SurfaceElevated = Color(0xFF172033)
val SurfaceHighlight = Color(0xFF1E2B45)
val BorderSubtle = Color(0xFF222E42)
val BorderFocused = Color(0xFF334666)

// Professional Brand & Accent Colors
val CyanAccent = Color(0xFF00E5FF)
val CyanAccentDark = Color(0xFF00B4D8)
val BullGreen = Color(0xFF0ECB81)
val BullGreenBg = Color(0x1A0ECB81)
val BearRed = Color(0xFFF6465D)
val BearRedBg = Color(0x1AF6465D)
val WarningAmber = Color(0xFFF0B90B)
val WarningAmberBg = Color(0x1AF0B90B)

// Typography & Text
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)
val TextDisabled = Color(0xFF475569)

// Safe Status Colors
val StatusConnected = Color(0xFF0ECB81)
val StatusConnecting = Color(0xFFF0B90B)
val StatusDisconnected = Color(0xFF64748B)
val StatusError = Color(0xFFF6465D)
val StatusSafeOff = Color(0xFF38BDF8)
