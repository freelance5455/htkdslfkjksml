package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Naruto Shinobi Orange & Flame Accents
val NarutoOrange = Color(0xFFFF6A00)
val NarutoOrangeDark = Color(0xFFE65100)
val NarutoOrangeLight = Color(0xFFFF9442)
val NarutoFlame = Color(0xFFFF4500)
val NarutoGold = Color(0xFFFFB300)

// Chakra Cyan & Deep Ninja Blue
val ChakraCyan = Color(0xFF00C3FF)
val ChakraBlue = Color(0xFF0077D4)
val ChakraDeepBlue = Color(0xFF0A192F)
val ChakraDarkBlue = Color(0xFF0F172A)

// Dark Theme Surfaces (Shinobi Night)
val DarkBackground = Color(0xFF0D0F17)
val DarkSurface = Color(0xFF151926)
val DarkSurfaceVariant = Color(0xFF1E2335)
val DarkCardBorder = Color(0xFF2C334D)
val DarkTextPrimary = Color(0xFFF1F5F9)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Theme Surfaces (Scroll & Ivory Parchment)
val LightBackground = Color(0xFFFAF7F2)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1EDE6)
val LightCardBorder = Color(0xFFE2D9CC)
val LightTextPrimary = Color(0xFF1E293B)
val LightTextSecondary = Color(0xFF64748B)

// Subject Signature Colors
val PhysicsColor = Color(0xFF2563EB)     // Azure Blue
val ChemistryColor = Color(0xFF059669)   // Jade Green
val MathsColor = Color(0xFFDC2626)       // Crimson Red
val ComputerSciColor = Color(0xFF7C3AED) // Royal Violet

// Status Colors
val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val WarningAmber = Color(0xFFF59E0B)
