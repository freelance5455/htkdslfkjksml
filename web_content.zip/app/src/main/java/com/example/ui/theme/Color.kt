package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic JARVIS / XTRA Palette
val XtraCyanPrimary = Color(0xFF00F0FF)
val XtraCyanGlow = Color(0xFF38BDF8)
val XtraCyanDark = Color(0xFF0284C7)

val XtraElectricBlue = Color(0xFF0077FE)
val XtraDarkNavyBg = Color(0xFF050B14)
val XtraSurfaceDark = Color(0xFF0A1322)
val XtraCardDark = Color(0xFF101F35)
val XtraCardBorder = Color(0xFF1E3A5F)

val XtraNeonGreen = Color(0xFF10B981)
val XtraWarningGold = Color(0xFFFFB703)
val XtraAlertRed = Color(0xFFEF4444)
val XtraPurpleAccent = Color(0xFFA855F7)

val XtraTextHigh = Color(0xFFF0F9FF)
val XtraTextMed = Color(0xFF94A3B8)
val XtraTextMuted = Color(0xFF64748B)

val XtraCyanLight = Color(0xFF0284C7)
val XtraSurfaceLight = Color(0xFFF8FAFC)
