package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PureWhite = Color(0xFFFFFFFF)
val AlabasterSurface = Color(0xFFF8FAFC)
val SoftGraySurface = Color(0xFFF1F5F9)
val HairlineBorder = Color(0xFFE2E8F0)

val DeepInk = Color(0xFF0F172A)
val SlateSecondary = Color(0xFF475569)
val MutedSlate = Color(0xFF94A3B8)

val GeminiBlue = Color(0xFF0284C7)
val GeminiIndigo = Color(0xFF2563EB)
val GeminiSoftBg = Color(0xFFE0F2FE)
val GeminiBorder = Color(0xFFBAE6FD)

val VaultEmerald = Color(0xFF059669)
val VaultEmeraldSoft = Color(0xFFD1FAE5)
val DangerRose = Color(0xFFE11D48)
val DangerRoseSoft = Color(0xFFFFE4E6)
