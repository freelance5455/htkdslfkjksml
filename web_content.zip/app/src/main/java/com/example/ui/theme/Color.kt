package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// XIRE AI Light Palette (matches editorial white/warm-paper aesthetic)
val LightBg = Color(0xFFFFFFFF)
val LightSidebar = Color(0xFFF6F6F6)
val LightCard = Color(0xFFFFFFFF)
val LightText = Color(0xFF111111)
val LightMuted = Color(0xFF6B6B6B)
val LightAccent = Color(0xFF111111)
val LightOnAccent = Color(0xFFFFFFFF)
val LightBorder = Color(0xFFE4E4E4)
val LightDanger = Color(0xFFB3402F)

// XIRE AI Dark Palette (matches deep obsidian #141414 / #0b0b0b aesthetic)
val DarkBg = Color(0xFF141414)
val DarkSidebar = Color(0xFF0B0B0B)
val DarkCard = Color(0xFF1E1E1E)
val DarkText = Color(0xFFF2F2F2)
val DarkMuted = Color(0xFF9A9A9A)
val DarkAccent = Color(0xFFF2F2F2)
val DarkOnAccent = Color(0xFF111111)
val DarkBorder = Color(0xFF2D2D2D)
val DarkDanger = Color(0xFFE06C5A)

// Subtle warm bronze tint matching the XIRE logo mark
val XireBronze = Color(0xFFC4A78B)
