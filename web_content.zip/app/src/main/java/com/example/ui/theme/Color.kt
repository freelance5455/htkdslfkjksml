package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberGreen = Color(0xFF00FF88)
val CyberCyan = Color(0xFF00CFFF)
val CyberNeonPink = Color(0xFFFF0077)
val CyberGold = Color(0xFFFFD600)
val DarkBackground = Color(0xFF06090E)
val DarkSurface = Color(0xFF0D1520)
val DarkSurfaceVariant = Color(0xFF131F30)
val NeonGreenOnDark = Color(0xFF00E676)
val CyberBorder = Color(0x6600FF88)
