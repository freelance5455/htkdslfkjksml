package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RAYNOX AI — Minimalist Executive Obsidian Palette (Primary)
val RaynoxCharcoalBg = Color(0xFF0E1117)
val RaynoxSurfaceDark = Color(0xFF161922)
val RaynoxSurfaceElevated = Color(0xFF1E222D)
val RaynoxUserBubbleDark = Color(0xFF222634)
val RaynoxCodeBlockBgDark = Color(0xFF0A0C11)
val RaynoxBorderDark = Color(0xFF262C3A)

val RaynoxTextPrimaryDark = Color(0xFFF8FAFC)
val RaynoxTextSecondaryDark = Color(0xFF94A3B8)
val RaynoxTextMutedDark = Color(0xFF64748B)

// Minimalist Executive Amber / Warm Gold Accents
val RaynoxAmber = Color(0xFFF59E0B)
val RaynoxAmberDark = Color(0xFFD97706)
val RaynoxAmberContainer = Color(0xFF3B2A0F)
val RaynoxAmberGlow = Color(0x33F59E0B)

// Indigo and Cyan references
val RaynoxIndigo = Color(0xFF6366F1)
val RaynoxBlue = Color(0xFF3B82F6)
val RaynoxViolet = Color(0xFF8B5CF6)
val RaynoxCyanAccent = Color(0xFF38BDF8)

// Semantic Status Colors
val RaynoxError = Color(0xFFEF4444)
val RaynoxErrorContainerDark = Color(0xFF2D161B)
val RaynoxSuccess = Color(0xFF10B981)

// RAYNOX AI — Polished Light Palette
val RaynoxLightBg = Color(0xFFF9FAFB)
val RaynoxSurfaceLight = Color(0xFFFFFFFF)
val RaynoxSurfaceElevatedLight = Color(0xFFF3F4F6)
val RaynoxUserBubbleLight = Color(0xFFEEF2FF)
val RaynoxCodeBlockBgLight = Color(0xFF111827)
val RaynoxBorderLight = Color(0xFFE5E7EB)

val RaynoxTextPrimaryLight = Color(0xFF111827)
val RaynoxTextSecondaryLight = Color(0xFF4B5563)
val RaynoxErrorContainerLight = Color(0xFFFEE2E2)
