package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Primaries - Ignis Flame & Ember
val IgnisOrangePrimary = Color(0xFFFF5722)
val IgnisOrangeDark = Color(0xFFD84315)
val IgnisOrangeLight = Color(0xFFFF8A65)
val IgnisFlameCrimson = Color(0xFFE11D48)

// Tech Accents - Innovation & Trust
val IgnisTechBlue = Color(0xFF0284C7)
val IgnisTechBlueLight = Color(0xFF38BDF8)
val IgnisAmber = Color(0xFFF59E0B)
val IgnisEmerald = Color(0xFF10B981)

// Neutral Grays & Surfaces (Dark & Light)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Card & Container surfaces
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceContainerLight = Color(0xFFF8FAFC)
val SurfaceDark = Color(0xFF131B2A)
val SurfaceContainerDark = Color(0xFF1E293B)
