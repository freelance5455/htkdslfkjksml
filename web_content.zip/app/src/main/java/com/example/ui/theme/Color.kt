package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Studio Light Palette
val StudioLightBackground = Color(0xFFF6F8FC)
val StudioLightSurface = Color(0xFFFFFFFF)
val StudioLightSurfaceVariant = Color(0xFFEEF2F8)
val StudioLightOnSurface = Color(0xFF0F172A)
val StudioLightOnSurfaceVariant = Color(0xFF475569)
val StudioLightOutline = Color(0xFFE2E8F0)

val IndigoPrimaryLight = Color(0xFF4F46E5)
val IndigoPrimaryContainerLight = Color(0xFFE0E7FF)
val IndigoOnPrimaryContainerLight = Color(0xFF1E1B4B)

val EmeraldSecondaryLight = Color(0xFF059669)
val EmeraldSecondaryContainerLight = Color(0xFFD1FAE5)
val EmeraldOnSecondaryContainerLight = Color(0xFF064E3B)

val AmberTertiaryLight = Color(0xFFD97706)
val AmberTertiaryContainerLight = Color(0xFFFEF3C7)
val AmberOnTertiaryContainerLight = Color(0xFF78350F)

// Studio Dark Palette (Obsidian & Luminous Indigo)
val StudioDarkBackground = Color(0xFF090D16)
val StudioDarkSurface = Color(0xFF111827)
val StudioDarkSurfaceVariant = Color(0xFF1E293B)
val StudioDarkOnSurface = Color(0xFFF1F5F9)
val StudioDarkOnSurfaceVariant = Color(0xFF94A3B8)
val StudioDarkOutline = Color(0xFF283548)

val IndigoPrimaryDark = Color(0xFF818CF8)
val IndigoOnPrimaryDark = Color(0xFF0F0D2E)
val IndigoPrimaryContainerDark = Color(0xFF312E81)
val IndigoOnPrimaryContainerDark = Color(0xFFE0E7FF)

val EmeraldSecondaryDark = Color(0xFF34D399)
val EmeraldOnSecondaryDark = Color(0xFF022C22)
val EmeraldSecondaryContainerDark = Color(0xFF064E3B)
val EmeraldOnSecondaryContainerDark = Color(0xFFA7F3D0)

val AmberTertiaryDark = Color(0xFFFBBF24)
val AmberOnTertiaryDark = Color(0xFF3D1D00)
val AmberTertiaryContainerDark = Color(0xFF78350F)
val AmberOnTertiaryContainerDark = Color(0xFFFEF3C7)

// Semantic Status & Priority Tokens
val PriorityUrgentColor = Color(0xFFEF4444)
val PriorityHighColor = Color(0xFFF97316)
val PriorityMediumColor = Color(0xFFF59E0B)
val PriorityLowColor = Color(0xFF0EA5E9)

val StatusTodoColor = Color(0xFF64748B)
val StatusInProgressColor = Color(0xFF6366F1)
val StatusDoneColor = Color(0xFF10B981)

// Project Accent Palette
val ProjectAccentColors = listOf(
    Color(0xFF4F46E5), // Electric Indigo
    Color(0xFF10B981), // Mint Emerald
    Color(0xFF0EA5E9), // Sky Cyan
    Color(0xFFF59E0B), // Warm Amber
    Color(0xFFEC4899), // Vivid Rose
    Color(0xFF8B5CF6), // Royal Violet
    Color(0xFFF97316), // Sunset Coral
    Color(0xFF14B8A6)  // Deep Teal
)
