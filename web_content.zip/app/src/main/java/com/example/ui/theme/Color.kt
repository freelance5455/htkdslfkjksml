package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Cyan / Teal palette for Tathbeet
val Cyan80 = Color(0xFF67E8F9)
val Cyan40 = Color(0xFF0284C7)
val Cyan20 = Color(0xFF082F49)

// Indigo secondary
val Indigo80 = Color(0xFFA5B4FC)
val Indigo40 = Color(0xFF4F46E5)
val Indigo20 = Color(0xFF1E1B4B)

// Emerald Tertiary / Success
val Emerald80 = Color(0xFF6EE7B7)
val Emerald40 = Color(0xFF059669)

// Dark Slate Backgrounds
val Slate950 = Color(0xFF090D16)
val Slate900 = Color(0xFF0F172A)
val Slate850 = Color(0xFF151F38)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate50 = Color(0xFFF8FAFC)

// Amber Warning
val Amber400 = Color(0xFFFBBF24)
val Rose500 = Color(0xFFF43F5E)
