package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MinecraftDirt = Color(0xFF866043)
val MinecraftDirtDark = Color(0xFF4E3524)
val MinecraftGrass = Color(0xFF5C8E32)
val MinecraftGrassDark = Color(0xFF385E1E)
val MinecraftStone = Color(0xFF6B6B6B)
val MinecraftStoneDark = Color(0xFF333333)
val MinecraftGold = Color(0xFFF5B041)
val MinecraftDiamond = Color(0xFF4DEEEA)
val MinecraftRedstone = Color(0xFFE74C3C)
val MinecraftEmerald = Color(0xFF2ECC71)
val MinecraftBackground = Color(0xFF14100D)
val MinecraftSurface = Color(0xFF241C16)
val MinecraftSurfaceVariant = Color(0xFF362B22)
val MinecraftBorder = Color(0xFF4E3E33)
val MinecraftText = Color(0xFFF2ECE1)
val MinecraftTextDim = Color(0xFFA69A89)
