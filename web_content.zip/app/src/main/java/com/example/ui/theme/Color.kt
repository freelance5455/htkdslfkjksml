package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TacticalBlue = Color(0xFF3B82F6)
val TacticalBlueDark = Color(0xFF1D4ED8)
val GoldAccent = Color(0xFFF59E0B)
val WarRed = Color(0xFFEF4444)
val DarkNavyBg = Color(0xFF080C14)
val DarkSlateSurface = Color(0xFF0F172A)
val SurfaceVariant = Color(0xFF1E293B)
val TextLight = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
