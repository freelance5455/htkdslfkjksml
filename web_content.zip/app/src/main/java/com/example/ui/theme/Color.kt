package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SD TRAVEL Brand Colors
val NavyPrimary = Color(0xFF0B1F3A)
val NavyContainer = Color(0xFF153055)
val NavyLight = Color(0xFF234778)
val NavyDark = Color(0xFF061326)

val GoldSecondary = Color(0xFFD4AF37)
val GoldBright = Color(0xFFE5C558)
val GoldDark = Color(0xFF9E7E1B)
val GoldContainer = Color(0xFFFDF6DF)

val BackgroundWhite = Color(0xFFFFFFFF)
val SurfaceLightGray = Color(0xFFF4F6F9)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceMuted = Color(0xFFE8ECF2)

val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextTertiary = Color(0xFF64748B)
val BorderLight = Color(0xFFDCE2EC)

// Status Semantic Colors
val StatusConfirmedFg = Color(0xFF0F766E)
val StatusConfirmedBg = Color(0xFFE6F6F3)

val StatusPendingFg = Color(0xFFB45309)
val StatusPendingBg = Color(0xFFFEF3C7)

val StatusCompletedFg = Color(0xFF1D4ED8)
val StatusCompletedBg = Color(0xFFDBEAFE)

val StatusCancelledFg = Color(0xFFB91C1C)
val StatusCancelledBg = Color(0xFFFEE2E2)
