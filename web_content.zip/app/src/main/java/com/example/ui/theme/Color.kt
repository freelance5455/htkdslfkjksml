package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0D0D0D)
val DarkSurface = Color(0xFF161616)
val DarkSurfaceVariant = Color(0xFF222222)
val ElectricOrange = Color(0xFFFF6B00)
val AmberGlow = Color(0xFFFF9E00)
val TextPrimary = Color(0xFFF3F3F3)
val TextSecondary = Color(0xFF9E9E9E)
val OutlineColor = Color(0xFF333333)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
