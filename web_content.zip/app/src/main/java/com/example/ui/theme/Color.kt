package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Android Brand & Game Palette
val AndroidGreen = Color(0xFF3DDC84)
val AndroidDarkGreen = Color(0xFF1E824C)
val AndroidLightGreen = Color(0xFF80E8A8)
val AndroidNavy = Color(0xFF073042)
val AndroidDarkNavy = Color(0xFF031926)

val SkyBlueTop = Color(0xFF4FC3F7)
val SkyBlueBottom = Color(0xFFB3E5FC)
val NightSkyTop = Color(0xFF0D1B2A)
val NightSkyBottom = Color(0xFF1B263B)

val GroundGreen = Color(0xFF4CAF50)
val GroundDarkGreen = Color(0xFF2E7D32)
val GroundBrown = Color(0xFF795548)
val GroundDarkBrown = Color(0xFF4E342E)

val PipeGreen = Color(0xFF2E7D32)
val PipeLightGreen = Color(0xFF4CAF50)
val PipeRim = Color(0xFF1B5E20)

val AccentGold = Color(0xFFFFD700)
val AccentOrange = Color(0xFFFF9800)
val AccentRed = Color(0xFFE53935)
val AccentCyan = Color(0xFF00E5FF)

val SurfaceDark = Color(0xFF121820)
val SurfaceCardDark = Color(0xFF1E2633)
val SurfaceCardBorder = Color(0xFF2C394B)
