package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Rose / Wine Palette
val RosePrimary = Color(0xFF881337)       // Deep Rose 900
val RoseSecondary = Color(0xFF9F1239)     // Rose 800
val RoseTertiary = Color(0xFFBE123C)      // Rose 700
val RoseLight = Color(0xFFBE185D)         // Rose 600
val RoseContainer = Color(0xFFFFF1F2)     // Rose 50
val OnRoseContainer = Color(0xFF4C0519)   // Rose 950

// Accent Gold / Champagne
val GoldAccent = Color(0xFFD97706)        // Amber 600
val GoldContainer = Color(0xFFFEF3C7)     // Amber 100
val OnGoldContainer = Color(0xFF78350F)   // Amber 900

// Status & Semantic Colors
val StatusExpired = Color(0xFFDC2626)     // Red 600
val StatusExpiredBg = Color(0xFFFEE2E2)   // Red 100
val StatusWarning = Color(0xFFD97706)     // Amber 600
val StatusWarningBg = Color(0xFFFEF3C7)   // Amber 100
val StatusSuccess = Color(0xFF059669)     // Emerald 600
val StatusSuccessBg = Color(0xFFD1FAE5)   // Emerald 100

// Backgrounds & Surfaces
val BackgroundLight = Color(0xFFF8FAFC)   // Slate 50
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)// Slate 100
val TextPrimary = Color(0xFF0F172A)       // Slate 900
val TextSecondary = Color(0xFF64748B)     // Slate 500
val BorderLight = Color(0xFFE2E8F0)       // Slate 200

// Dark Theme Variants
val RosePrimaryDark = Color(0xFFFDA4AF)
val RoseContainerDark = Color(0xFF4C0519)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
