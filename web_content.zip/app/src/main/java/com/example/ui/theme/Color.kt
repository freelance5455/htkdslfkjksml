package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SuesaBackground = Color(0xFF111111)
val SuesaSurface = Color(0xFF151515)
val SuesaCard = Color(0xFF1C1C1C)
val SuesaBubbleModel = Color(0xFF242424)
val SuesaBubbleUser = Color(0xFF303030)
val SuesaBorder = Color(0xFF363636)
val SuesaTextPrimary = Color(0xFFF5F5F5)
val SuesaTextSecondary = Color(0xFF9E9E9E)
val SuesaAccentWhite = Color(0xFFFFFFFF)
val SuesaPurple = Color(0xFF7B3FF2)
val SuesaPurpleBorder = Color(0xFF6940A8)
val SuesaOverlayBg = Color(0xF0140A23)
val SuesaCodeBg = Color(0xFF0D0D0D)
val SuesaCodeHeader = Color(0xFF181818)
val SuesaSuccess = Color(0xFF34D399)
val SuesaWarning = Color(0xFFFBBF24)
val SuesaDanger = Color(0xFFF87171)
