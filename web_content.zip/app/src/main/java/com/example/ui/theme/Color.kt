package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IndigoPrimaryLight = Color(0xFF5D3FD3)
val IndigoOnPrimaryLight = Color(0xFFFFFFFF)
val IndigoContainerLight = Color(0xFFE7DFFF)
val IndigoOnContainerLight = Color(0xFF1D0D52)

val SakuraSecondaryLight = Color(0xFFD63E83)
val SakuraContainerLight = Color(0xFFFFD9E7)
val SakuraOnContainerLight = Color(0xFF3E001F)

val LavenderBackgroundLight = Color(0xFFF6F4FF)
val LavenderSurfaceLight = Color(0xFFFFFFFF)
val LavenderSurfaceVariantLight = Color(0xFFECE8FA)
val LavenderOnSurfaceLight = Color(0xFF1E1B2E)

val IndigoPrimaryDark = Color(0xFFB9A7FF)
val IndigoOnPrimaryDark = Color(0xFF2B1272)
val IndigoContainerDark = Color(0xFF3F2699)
val IndigoOnContainerDark = Color(0xFFE7DFFF)

val SakuraSecondaryDark = Color(0xFFFFB0CE)
val SakuraContainerDark = Color(0xFF7B1647)
val SakuraOnContainerDark = Color(0xFFFFD9E7)

val NightBackgroundDark = Color(0xFF14121F)
val NightSurfaceDark = Color(0xFF1E1B2E)
val NightSurfaceVariantDark = Color(0xFF2B2642)
val NightOnSurfaceDark = Color(0xFFEFECFB)
