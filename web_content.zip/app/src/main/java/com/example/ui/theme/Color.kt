package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Traffic Light Specific Vibrant Colors
val TrafficRed = Color(0xFFFF2A42)
val TrafficRedGlow = Color(0xFFFF5269)
val TrafficRedDark = Color(0xFF38080E)

val TrafficYellow = Color(0xFFFFB300)
val TrafficYellowGlow = Color(0xFFFFD54F)
val TrafficYellowDark = Color(0xFF3B2E05)

val TrafficGreen = Color(0xFF00E676)
val TrafficGreenGlow = Color(0xFF69F0AE)
val TrafficGreenDark = Color(0xFF053317)

val TrafficHousing = Color(0xFF151921)
val TrafficHousingBorder = Color(0xFF2B3342)
val TrafficHousingCap = Color(0xFF1F2633)

val RoadAsphalt = Color(0xFF11141A)
val RoadMarking = Color(0xFFF0F2F5)
val PedestrianWalkGreen = Color(0xFF00E676)
val PedestrianWaitRed = Color(0xFFFF2A42)

