package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Navy Blue Palette (Primary Egyptian Educational Style)
val NavyDeep = Color(0xFF0A1626)
val NavyPrimary = Color(0xFF0F223D)
val NavySurface = Color(0xFF162D4E)
val NavyCard = Color(0xFF1B365D)
val NavyLight = Color(0xFF2B4D7E)

// Gold Palette (Royal Accent)
val GoldPrimary = Color(0xFFD4AF37)
val GoldAccent = Color(0xFFE5B834)
val GoldLight = Color(0xFFF3D274)
val GoldContainer = Color(0xFFFFF7DD)
val GoldDark = Color(0xFFA68019)

// Neutrals & Surfaces
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val BorderLight = Color(0xFFE2E8F0)
val TextDarkPrimary = Color(0xFF0F172A)
val TextDarkSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF64748B)

// Status Colors
val StatusPending = Color(0xFFE67E22) // "لسه هتنزل"
val StatusPendingBg = Color(0xFFFEF3C7)
val StatusPublished = Color(0xFF10B981)
val StatusPublishedBg = Color(0xFFD1FAE5)
val StatusAdmin = Color(0xFF8B5CF6)
