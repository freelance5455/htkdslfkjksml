package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JOBY Brand Palette: Deep Indigo-Teal, Warm Saffron, Verified Emerald
val TealPrimary = Color(0xFF0F4C5C)
val TealPrimaryLight = Color(0xFF3E7889)
val TealContainerLight = Color(0xFFD2EEF5)
val OnTealContainerLight = Color(0xFF062730)

val SaffronSecondary = Color(0xFFE07A22)
val SaffronContainerLight = Color(0xFFFFE5CC)
val OnSaffronContainerLight = Color(0xFF4A2200)

val EmeraldTertiary = Color(0xFF1B7A4B)
val EmeraldContainerLight = Color(0xFFCFF6DF)
val OnEmeraldContainerLight = Color(0xFF06331D)

val SurfaceWarmLight = Color(0xFFF7F9FA)
val SurfaceCardLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE9EFF2)
val OnSurfaceLight = Color(0xFF121C20)
val OnSurfaceMutedLight = Color(0xFF4E5E65)
val OutlineLight = Color(0xFFCAD6DC)

// Dark Theme Tokens
val TealPrimaryDark = Color(0xFF7AD0E6)
val OnTealPrimaryDark = Color(0xFF003642)
val TealContainerDark = Color(0xFF0B3A47)
val OnTealContainerDark = Color(0xFFC8ECF6)

val SaffronSecondaryDark = Color(0xFFFFB77B)
val OnSaffronSecondaryDark = Color(0xFF4D2400)
val SaffronContainerDark = Color(0xFF6B3506)
val OnSaffronContainerDark = Color(0xFFFFDEC2)

val EmeraldTertiaryDark = Color(0xFF73DDA5)
val OnEmeraldTertiaryDark = Color(0xFF00381E)
val EmeraldContainerDark = Color(0xFF0B5130)
val OnEmeraldContainerDark = Color(0xFFC3F7D8)

val SurfaceDark = Color(0xFF0D1518)
val SurfaceCardDark = Color(0xFF142024)
val SurfaceVariantDark = Color(0xFF1E2D33)
val OnSurfaceDark = Color(0xFFE8F0F2)
val OnSurfaceMutedDark = Color(0xFF9EB1B8)
val OutlineDark = Color(0xFF32454D)

val ErrorRed = Color(0xFFC62828)
val ErrorContainerLight = Color(0xFFFFDAD6)
val ErrorRedDark = Color(0xFFFFB4AB)
val ErrorContainerDark = Color(0xFF93000A)
