package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bangladesh Flag & Youth Organization Inspired Emerald & Crimson Palette
val EmeraldPrimary = Color(0xFF15803D)
val EmeraldLight = Color(0xFF22C55E)
val EmeraldDark = Color(0xFF14532D)

val CrimsonAccent = Color(0xFFDC2626)
val CrimsonLight = Color(0xFFFEE2E2)

val GoldAccent = Color(0xFFCA8A04)
val GoldLight = Color(0xFFFEF9C3)

// High-contrast, sharp dark text colors (Fixing all pale/faded texts)
val TextPrimary = Color(0xFF111827) // Pitch Black / Deep Charcoal
val TextSecondary = Color(0xFF1F2937) // Rich Dark Gray (high contrast, bold)
val TextMuted = Color(0xFF374151) // Readable muted text
val TextHint = Color(0xFF4B5563) // Legible hint/placeholder

// Light Theme
val LightBg = Color(0xFFF3F4F6)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE5E7EB)
val LightOnSurface = Color(0xFF111827)
val LightOutline = Color(0xFF4B5563)

// Dark Theme
val DarkBg = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkOnSurface = Color(0xFFF8FAFC)
val DarkOutline = Color(0xFF94A3B8)

// Badge & State Colors
val BadgeCommittee = Color(0xFF15803D)
val BadgeWorker = Color(0xFF7E22CE)
val BadgeBlood = Color(0xFFDC2626)
val CardBorder = Color(0xFFD1D5DB)
