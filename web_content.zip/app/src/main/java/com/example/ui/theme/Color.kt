package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AURA AI Next-Gen Holographic Aurora Palette (Cosmic Onyx, Aurora Mint-Cyan, Prism Indigo, Neon Coral)
val NovaObsidian = Color(0xFF040814)
val NovaCharcoal = Color(0xFF0A1124)
val NovaSurfaceElevated = Color(0xFF111C38)
val NovaSurfaceGlass = Color(0xFF17254A)
val NovaElectricBlue = Color(0xFF00F5D4) // Aurora Mint-Cyan primary accent
val NovaDeepViolet = Color(0xFF6366F1)   // Prism Indigo secondary accent
val NovaVioletGlow = Color(0xFF38BDF8)   // Sky Cyan highlight
val NovaAuroraRose = Color(0xFFF43F5E)   // Subtle Rose-Coral accent
val NovaSilver = Color(0xFFE2E8F0)
val NovaTextPrimaryDark = Color(0xFFF8FAFC)
val NovaTextSecondaryDark = Color(0xFF94A3B8)
val NovaBorderDark = Color(0xFF1E293B)
val NovaUserBubbleStart = Color(0xFF0284C7)
val NovaUserBubbleEnd = Color(0xFF4F46E5)

// AURA AI Light Palette
val NovaLightBackground = Color(0xFFF0F6FF)
val NovaLightSurface = Color(0xFFFFFFFF)
val NovaLightSurfaceVariant = Color(0xFFE2EEFF)
val NovaElectricBlueLight = Color(0xFF008075)
val NovaDeepVioletLight = Color(0xFF4338CA)
val NovaTextPrimaryLight = Color(0xFF090E1A)
val NovaTextSecondaryLight = Color(0xFF475569)
val NovaBorderLight = Color(0xFFCBD5E1)
