package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// HAZIM AI Brand Palette - Sleek OpenAI / Anthropic / Gemini aesthetic
val HazimDarkBackground = Color(0xFF0D1117)
val HazimDarkSurface = Color(0xFF161B22)
val HazimDarkSurfaceVariant = Color(0xFF21262D)
val HazimDarkBorder = Color(0xFF30363D)

val HazimCyan = Color(0xFF00E5FF)
val HazimCyanGlow = Color(0xFF38BDF8)
val HazimPurple = Color(0xFF8B5CF6)
val HazimViolet = Color(0xFFA855F7)
val HazimEmerald = Color(0xFF10B981)
val HazimAmber = Color(0xFFF59E0B)

val TextPrimaryDark = Color(0xFFF3F4F6)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextTertiaryDark = Color(0xFF6B7280)

val UserBubbleDark = Color(0xFF232936)
val AiBubbleDark = Color(0xFF161B22)

// Light theme counterparts
val HazimLightBackground = Color(0xFFF8FAFC)
val HazimLightSurface = Color(0xFFFFFFFF)
val HazimLightSurfaceVariant = Color(0xFFF1F5F9)
val HazimLightBorder = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
