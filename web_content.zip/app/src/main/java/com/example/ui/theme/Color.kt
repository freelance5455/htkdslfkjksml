package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Security Obsidian & Emerald Palette
val ShieldObsidian = Color(0xFF090E17)
val ShieldNavySurface = Color(0xFF111827)
val ShieldCardDark = Color(0xFF1A2333)
val ShieldCardElevatedDark = Color(0xFF232E42)

val ShieldLightBg = Color(0xFFF3F6FA)
val ShieldLightSurface = Color(0xFFFFFFFF)
val ShieldLightContainer = Color(0xFFE8EEF5)

val EmeraldPrimary = Color(0xFF10B981)
val EmeraldDark = Color(0xFF059669)
val EmeraldContainerDark = Color(0xFF064E3B)
val EmeraldContainerLight = Color(0xFFD1FAE5)
val EmeraldOnContainerLight = Color(0xFF065F46)

val SlateSecondary = Color(0xFF64748B)
val SlateContainerDark = Color(0xFF1E293B)

val AmberWarning = Color(0xFFF59E0B)
val AmberContainerDark = Color(0xFF451A03)
val AmberContainerLight = Color(0xFFFEF3C7)
val AmberOnContainerLight = Color(0xFF92400E)

val CrimsonAlert = Color(0xFFEF4444)
val CrimsonContainerDark = Color(0xFF450A0A)
val CrimsonContainerLight = Color(0xFFFEE2E2)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val OutlineDark = Color(0xFF2D3A4F)
val OutlineLight = Color(0xFFCBD5E1)
