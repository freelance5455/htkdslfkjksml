package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.model.ShopSettings
import com.example.model.UiState
import com.example.ui.components.AdminSalesChart
import com.example.ui.components.NovaBrandMark
import com.example.ui.components.ProductThumbnail
import com.example.ui.components.compressUriToBase64
import com.example.ui.components.decodeBase64Bitmap
import com.example.ui.components.formatBdt
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberNotice
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CoralContainer
import com.example.ui.theme.ForestEmerald
import com.example.ui.theme.VibrantEmerald

@Composable
fun AccountAndAdminScreen(
    userDisplayName: String,
    userEmail: String,
    productsState: UiState<List<Product>>,
    ordersState: UiState<List<Order>>,
    shopSettings: ShopSettings,
    isAdminUnlocked: Boolean,
    isMutating: Boolean,
    onUnlockAdmin: (String) -> Boolean,
    onLockAdmin: () -> Unit,
    onSaveProduct: (
        existing: Product?,
        name: String,
        cat: String,
        price: Long,
        oldPrice: Long,
        emoji: String,
        desc: String,
        imageBase64: String?,
        featured: Boolean,
        onComplete: () -> Unit
    ) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onUpdateOrderStatus: (String, OrderStatus) -> Unit,
    onUpdateShopSettings: (
        shopName: String,
        phone: String,
        facebookUrl: String,
        currentPin: String,
        newPin: String,
        dhakaFee: Long,
        outsideFee: Long
    ) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showPinDialog by remember { mutableStateOf(false) }

    if (isAdminUnlocked) {
        BackHandler { onLockAdmin() }
        AdminControlCenter(
            productsState = productsState,
            ordersState = ordersState,
            shopSettings = shopSettings,
            isMutating = isMutating,
            onBack = onLockAdmin,
            onSaveProduct = onSaveProduct,
            onDeleteProduct = onDeleteProduct,
            onUpdateOrderStatus = onUpdateOrderStatus,
            onUpdateShopSettings = onUpdateShopSettings,
            modifier = modifier
        )
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 680.dp).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("অ্যাকাউন্ট ও সেবা", style = MaterialTheme.typography.headlineSmall)

            // User Google Profile Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = ForestEmerald,
                        modifier = Modifier.size(54.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = userDisplayName.firstOrNull()?.uppercase() ?: "N",
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userDisplayName.ifBlank { "NOVA BAZAR User" },
                            style = MaterialTheme.typography.titleLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = userEmail,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Store Contact & Social Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        NovaBrandMark(size = 34.dp)
                        Column {
                            Text(
                                text = shopSettings.shopName.ifBlank { "NOVA BAZAR" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "সারা বাংলাদেশে ডেলিভারি • Cash on Delivery",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val dial = Intent(Intent.ACTION_DIAL).apply {
                                    data = Uri.parse("tel:${shopSettings.phone}")
                                }
                                runCatching { context.startActivity(dial) }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(shopSettings.phone, maxLines = 1)
                        }

                        if (shopSettings.facebookUrl.isNotBlank()) {
                            OutlinedButton(
                                onClick = {
                                    val fb = Intent(Intent.ACTION_VIEW, Uri.parse(shopSettings.facebookUrl))
                                    runCatching { context.startActivity(fb) }
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.Public, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Facebook Page", maxLines = 1)
                            }
                        }
                    }
                }
            }

            // Admin Control Center Entry Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = ForestEmerald),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { showPinDialog = true }
                    .testTag("open_admin_button")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.16f),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.AdminPanelSettings,
                                contentDescription = null,
                                tint = Color(0xFFB7EF68),
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Admin Control Center",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = "পণ্য যোগ/সম্পাদনা (গ্যালারি ছবি), অর্ডার পরিচালনা ও সেটিংস",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFD2EFE0)
                        )
                    }
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = Color(0xFFB7EF68)
                    )
                }
            }

            // Sign Out
            OutlinedButton(
                onClick = onSignOut,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CoralAlert),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("sign_out_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Google অ্যাকাউন্ট থেকে লগআউট")
            }
        }
    }

    if (showPinDialog) {
        AdminPinDialog(
            onDismiss = { showPinDialog = false },
            onSubmit = { pin ->
                if (onUnlockAdmin(pin)) {
                    showPinDialog = false
                }
            }
        )
    }
}

@Composable
private fun AdminPinDialog(
    onDismiss: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = ForestEmerald) },
        title = { Text("Admin Login") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "অ্যাডমিন কন্ট্রোল সেন্টারে প্রবেশ করতে পিন দিন (ডিফল্ট পিন: 6708)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    label = { Text("Admin PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("admin_pin_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(pin) },
                colors = ButtonDefaults.buttonColors(containerColor = ForestEmerald, contentColor = Color.White),
                modifier = Modifier.testTag("admin_pin_submit")
            ) {
                Text("লগইন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
private fun AdminControlCenter(
    productsState: UiState<List<Product>>,
    ordersState: UiState<List<Order>>,
    shopSettings: ShopSettings,
    isMutating: Boolean,
    onBack: () -> Unit,
    onSaveProduct: (
        existing: Product?,
        name: String,
        cat: String,
        price: Long,
        oldPrice: Long,
        emoji: String,
        desc: String,
        imageBase64: String?,
        featured: Boolean,
        onComplete: () -> Unit
    ) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onUpdateOrderStatus: (String, OrderStatus) -> Unit,
    onUpdateShopSettings: (String, String, String, String, String, Long, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Overview", "অর্ডার", "পণ্য", "সেটিংস")

    val products = (productsState as? UiState.Success)?.data.orEmpty()
    val orders = (ordersState as? UiState.Success)?.data.orEmpty()

    Column(modifier = modifier.fillMaxSize()) {
        // Admin Header
        Surface(
            color = ForestEmerald,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ফিরে যান",
                            tint = Color.White
                        )
                    }
                    Column {
                        Text(
                            text = "Admin Control Center",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = "${shopSettings.shopName} • ক্লাউড সিঙ্ক",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFB7EF68)
                        )
                    }
                }
                TextButton(onClick = onBack) {
                    Text("Logout", color = Color(0xFFB7EF68))
                }
            }
        }

        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        val suffix = if (index == 1) " (${orders.size})" else ""
                        Text("$title$suffix", style = MaterialTheme.typography.labelMedium, maxLines = 1)
                    }
                )
            }
        }

        when (selectedTab) {
            0 -> AdminOverviewTab(products = products, orders = orders)
            1 -> AdminOrdersTab(orders = orders, onUpdateOrderStatus = onUpdateOrderStatus)
            2 -> AdminProductsTab(
                products = products,
                isMutating = isMutating,
                onSaveProduct = onSaveProduct,
                onDeleteProduct = onDeleteProduct
            )
            else -> AdminSettingsTab(
                shopSettings = shopSettings,
                isMutating = isMutating,
                onUpdateShopSettings = onUpdateShopSettings
            )
        }
    }
}

@Composable
private fun AdminOverviewTab(
    products: List<Product>,
    orders: List<Order>
) {
    val completedSales = orders.filter { it.statusEnum == OrderStatus.COMPLETED }.sumOf { it.total }
    val pendingCount = orders.count {
        it.statusEnum in listOf(OrderStatus.NEW, OrderStatus.CONFIRMED, OrderStatus.PROCESSING)
    }
    val statusCounts = remember(orders) {
        OrderStatus.entries.map { st ->
            st.label to orders.count { it.statusEnum == st }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatCard("মোট পণ্য", "${products.size}", Modifier.weight(1f))
                AdminStatCard("মোট অর্ডার", "${orders.size}", Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatCard("অপেক্ষমাণ অর্ডার", "$pendingCount", Modifier.weight(1f))
                AdminStatCard("সম্পন্ন বিক্রয়", formatBdt(completedSales), Modifier.weight(1f))
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("অর্ডার স্ট্যাটাস বিশ্লেষণ", style = MaterialTheme.typography.titleMedium)
                    AdminSalesChart(statusCounts = statusCounts)
                }
            }
        }
        item {
            Text("সাম্প্রতিক অর্ডার", style = MaterialTheme.typography.titleLarge)
        }
        if (orders.isEmpty()) {
            item {
                Text("এখনো কোনো অর্ডার আসেনি।", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            items(orders.take(5), key = { it.id }) { order ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("#${order.orderNumber} • ${order.customerName}", style = MaterialTheme.typography.titleSmall)
                            Text(order.phone, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatBdt(order.total), style = MaterialTheme.typography.titleMedium, color = ForestEmerald)
                            Text(order.status, style = MaterialTheme.typography.labelSmall, color = VibrantEmerald)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineMedium, color = ForestEmerald, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
private fun AdminOrdersTab(
    orders: List<Order>,
    onUpdateOrderStatus: (String, OrderStatus) -> Unit
) {
    var filterStatus by remember { mutableStateOf<OrderStatus?>(null) }
    val filtered = remember(orders, filterStatus) {
        if (filterStatus == null) orders else orders.filter { it.statusEnum == filterStatus }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = filterStatus == null,
                    onClick = { filterStatus = null },
                    label = { Text("সব (${orders.size})") }
                )
            }
            items(OrderStatus.entries) { st ->
                FilterChip(
                    selected = filterStatus == st,
                    onClick = { filterStatus = st },
                    label = { Text(st.label) }
                )
            }
        }

        if (filtered.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("এই স্ট্যাটাসে কোনো অর্ডার নেই", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.id }) { order ->
                    val currentStatus = order.statusEnum
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("#${order.orderNumber} • ${order.customerName}", style = MaterialTheme.typography.titleMedium)
                                Text(formatBdt(order.total), style = MaterialTheme.typography.titleMedium, color = ForestEmerald)
                            }
                            Text("${order.phone} • ${order.address}", style = MaterialTheme.typography.bodySmall)
                            if (order.note.isNotBlank()) {
                                Text("নোট: ${order.note}", style = MaterialTheme.typography.bodySmall, color = AmberNotice)
                            }
                            order.items.forEach { item ->
                                Text("• ${item.name} × ${item.qty} (${formatBdt(item.price * item.qty)})", style = MaterialTheme.typography.bodySmall)
                            }
                            HorizontalDivider()

                            if (currentStatus.terminal) {
                                Surface(
                                    color = if (currentStatus == OrderStatus.COMPLETED) Color(0xFFDDF7E8) else CoralContainer,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "চূড়ান্ত স্ট্যাটাস: ${currentStatus.label} (লক করা হয়েছে)",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (currentStatus == OrderStatus.COMPLETED) ForestEmerald else CoralAlert,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            } else {
                                Text("স্ট্যাটাস পরিবর্তন করুন:", style = MaterialTheme.typography.labelMedium)
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    items(OrderStatus.entries) { st ->
                                        FilterChip(
                                            selected = currentStatus == st,
                                            onClick = {
                                                if (st != currentStatus) {
                                                    onUpdateOrderStatus(order.id, st)
                                                }
                                            },
                                            label = { Text(st.label, style = MaterialTheme.typography.labelSmall) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = ForestEmerald,
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminProductsTab(
    products: List<Product>,
    isMutating: Boolean,
    onSaveProduct: (
        existing: Product?,
        name: String,
        cat: String,
        price: Long,
        oldPrice: Long,
        emoji: String,
        desc: String,
        imageBase64: String?,
        featured: Boolean,
        onComplete: () -> Unit
    ) -> Unit,
    onDeleteProduct: (String) -> Unit
) {
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showProductForm by remember { mutableStateOf(false) }
    var deleteCandidate by remember { mutableStateOf<Product?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Button(
                onClick = {
                    editingProduct = null
                    showProductForm = true
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ForestEmerald, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_add_product_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("নতুন পণ্য যোগ করুন")
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(products, key = { it.id }) { product ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        ProductThumbnail(
                            product = product,
                            modifier = Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)),
                            emojiFontSizeSp = 28
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(product.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${product.category} • ${formatBdt(product.price)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = {
                            editingProduct = product
                            showProductForm = true
                        }) {
                            Icon(Icons.Filled.Edit, contentDescription = "সম্পাদনা", tint = ForestEmerald)
                        }
                        IconButton(onClick = { deleteCandidate = product }) {
                            Icon(Icons.Filled.Delete, contentDescription = "মুছুন", tint = CoralAlert)
                        }
                    }
                }
            }
        }
    }

    if (showProductForm) {
        BackHandler { showProductForm = false }
        ProductEditorSheet(
            existing = editingProduct,
            isMutating = isMutating,
            onDismiss = { showProductForm = false },
            onSave = { name, cat, price, oldPrice, emoji, desc, imageBase64, featured ->
                onSaveProduct(editingProduct, name, cat, price, oldPrice, emoji, desc, imageBase64, featured) {
                    showProductForm = false
                }
            }
        )
    }

    deleteCandidate?.let { victim ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("পণ্য মুছে ফেলবেন?") },
            text = { Text("আপনি কি নিশ্চিত '${victim.name}' মুছে ফেলতে চান?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteProduct(victim.id)
                        deleteCandidate = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CoralAlert, contentColor = Color.White)
                ) {
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteCandidate = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductEditorSheet(
    existing: Product?,
    isMutating: Boolean,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        cat: String,
        price: Long,
        oldPrice: Long,
        emoji: String,
        desc: String,
        imageBase64: String?,
        featured: Boolean
    ) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "") }
    var priceText by remember { mutableStateOf(existing?.price?.toString() ?: "") }
    var oldPriceText by remember { mutableStateOf(existing?.oldPrice?.takeIf { it > 0 }?.toString() ?: "") }
    var emoji by remember { mutableStateOf(existing?.emoji ?: "📦") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var imageBase64 by remember { mutableStateOf(existing?.imageBase64) }
    var featured by remember { mutableStateOf(existing?.featured ?: false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val encoded = compressUriToBase64(context, uri)
            if (encoded != null) {
                imageBase64 = encoded
                errorMsg = null
            } else {
                errorMsg = "ছবিটি প্রসেস করা যায়নি, অন্য ছবি চেষ্টা করুন"
            }
        }
    }

    val decodedPreview = remember(imageBase64) { decodeBase64Bitmap(imageBase64) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = if (existing == null) "নতুন পণ্য যোগ করুন" else "পণ্য সম্পাদনা করুন",
                style = MaterialTheme.typography.headlineSmall
            )

            // Photo Picker Preview Box (Zero-Permission Android Photo Picker)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    }
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (decodedPreview != null) {
                        Image(
                            bitmap = decodedPreview,
                            contentDescription = "পণ্যের ছবি",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }) {
                                Text("ছবি পরিবর্তন")
                            }
                            TextButton(onClick = { imageBase64 = null }) {
                                Text("ছবি সরান", color = CoralAlert)
                            }
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Filled.PhotoLibrary,
                            contentDescription = null,
                            tint = ForestEmerald,
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "📷 গ্যালারি থেকে পণ্যের ছবি নির্বাচন করুন",
                            style = MaterialTheme.typography.labelLarge,
                            color = ForestEmerald
                        )
                        Text(
                            text = "ছবি না দিলে ইমোজি আইকন দেখানো হবে",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it; errorMsg = null },
                label = { Text("পণ্যের নাম *") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = category,
                onValueChange = { category = it; errorMsg = null },
                label = { Text("ক্যাটাগরি * (যেমন: ফ্যাশন)") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it.filter(Char::isDigit); errorMsg = null },
                    label = { Text("দাম (৳) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = oldPriceText,
                    onValueChange = { oldPriceText = it.filter(Char::isDigit) },
                    label = { Text("আগের দাম (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = emoji,
                    onValueChange = { emoji = it.take(4) },
                    label = { Text("ইমোজি") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.width(100.dp)
                )
                Row(
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ফ্ল্যাশ ডিলে দেখান", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = featured, onCheckedChange = { featured = it })
                }
            }
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("পণ্যের বিবরণ") },
                minLines = 2,
                maxLines = 4,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMsg != null) {
                Text(errorMsg!!, color = CoralAlert, style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = {
                    val price = priceText.toLongOrNull() ?: 0L
                    val oldPrice = oldPriceText.toLongOrNull() ?: 0L
                    when {
                        name.isBlank() -> errorMsg = "পণ্যের নাম লিখুন"
                        category.isBlank() -> errorMsg = "ক্যাটাগরি লিখুন"
                        price <= 0L -> errorMsg = "সঠিক দাম লিখুন"
                        else -> onSave(name, category, price, oldPrice, emoji, description, imageBase64, featured)
                    }
                },
                enabled = !isMutating,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ForestEmerald, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                if (isMutating) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Text("পণ্য সংরক্ষণ করুন")
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun AdminSettingsTab(
    shopSettings: ShopSettings,
    isMutating: Boolean,
    onUpdateShopSettings: (String, String, String, String, String, Long, Long) -> Unit
) {
    var shopName by remember(shopSettings) { mutableStateOf(shopSettings.shopName) }
    var phone by remember(shopSettings) { mutableStateOf(shopSettings.phone) }
    var facebookUrl by remember(shopSettings) { mutableStateOf(shopSettings.facebookUrl) }
    var dhakaFeeText by remember(shopSettings) { mutableStateOf(shopSettings.dhakaDeliveryFee.toString()) }
    var outsideFeeText by remember(shopSettings) { mutableStateOf(shopSettings.outsideDeliveryFee.toString()) }
    var currentPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            color = AmberContainer,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "এখানে দোকানের নাম, যোগাযোগ নম্বর, ডেলিভারি চার্জ ও অ্যাডমিন পিন পরিবর্তন করতে পারবেন।",
                style = MaterialTheme.typography.bodySmall,
                color = AmberNotice,
                modifier = Modifier.padding(12.dp)
            )
        }

        OutlinedTextField(
            value = shopName,
            onValueChange = { shopName = it },
            label = { Text("দোকানের নাম") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it.filter(Char::isDigit).take(11) },
            label = { Text("দোকানের ফোন নম্বর (01XXXXXXXXX)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = facebookUrl,
            onValueChange = { facebookUrl = it },
            label = { Text("Facebook Page লিংক") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = dhakaFeeText,
                onValueChange = { dhakaFeeText = it.filter(Char::isDigit) },
                label = { Text("ঢাকা ডেলিভারি চার্জ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = outsideFeeText,
                onValueChange = { outsideFeeText = it.filter(Char::isDigit) },
                label = { Text("ঢাকার বাইরে চার্জ") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f)
            )
        }

        HorizontalDivider()

        Text("অ্যাডমিন পিন যাচাই ও পরিবর্তন", style = MaterialTheme.typography.titleMedium)

        OutlinedTextField(
            value = currentPin,
            onValueChange = { currentPin = it; localError = null },
            label = { Text("বর্তমান পিন *") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = newPin,
            onValueChange = { newPin = it; localError = null },
            label = { Text("নতুন পিন (ঐচ্ছিক, কমপক্ষে ৪ অক্ষর)") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        if (localError != null) {
            Text(localError!!, color = CoralAlert, style = MaterialTheme.typography.bodySmall)
        }

        Button(
            onClick = {
                if (currentPin.isBlank()) {
                    localError = "সেটিংস সংরক্ষণ করতে বর্তমান পিন দিন"
                    return@Button
                }
                if (newPin.isNotBlank() && newPin.length < 4) {
                    localError = "নতুন পিন কমপক্ষে ৪ অক্ষরের হতে হবে"
                    return@Button
                }
                onUpdateShopSettings(
                    shopName,
                    phone,
                    facebookUrl,
                    currentPin,
                    newPin,
                    dhakaFeeText.toLongOrNull() ?: 60L,
                    outsideFeeText.toLongOrNull() ?: 120L
                )
            },
            enabled = !isMutating,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ForestEmerald, contentColor = Color.White),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("সেটিংস সংরক্ষণ করুন")
        }
    }
}
