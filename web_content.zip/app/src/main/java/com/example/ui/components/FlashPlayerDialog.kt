package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.xp.WindowsXpTheme

@Composable
fun FlashPlayerSettingsDialog(
    onDismiss: () -> Unit,
    onLaunchFlashHub: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var storageSlider by remember { mutableFloatStateOf(3f) }
    var allowPeerNetworking by remember { mutableStateOf(true) }
    var hardwareAcceleration by remember { mutableStateOf(true) }
    var qualitySelection by remember { mutableStateOf("High") }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(WindowsXpTheme.Background)
                .border(2.dp, Color(0xFF0058EE), RoundedCornerShape(6.dp))
        ) {
            // Dialog Title Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .background(WindowsXpTheme.TitleBarGradient)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(WindowsXpTheme.FlashRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "f",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Adobe Flash Player Settings",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(WindowsXpTheme.CloseRed)
                        .clickable { onDismiss() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            // Tabs: Storage, Quality, Advanced
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFD4D0C8))
                    .padding(top = 4.dp, start = 6.dp, end = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                listOf("Local Storage", "Display & Quality", "About").forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                            .background(if (isSelected) WindowsXpTheme.Background else Color(0xFFB0AEA6))
                            .border(
                                1.dp,
                                if (isSelected) WindowsXpTheme.BorderDark else Color.Transparent,
                                RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)
                            )
                            .clickable { selectedTab = index }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = Color.Black
                        )
                    }
                }
            }

            // Tab Content
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        // Storage
                        Text(
                            text = "Local Storage Settings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF003399)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "How much information can websites save on your computer for Flash Player v10 games and animations?",
                            fontSize = 11.sp,
                            color = Color(0xFF333333)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        val limits = listOf("None", "100 KB", "1 MB", "10 MB", "Unlimited")
                        val currentLimit = limits[storageSlider.toInt().coerceIn(0, 4)]
                        Text(
                            text = "Storage Limit: $currentLimit",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color.Black
                        )

                        Slider(
                            value = storageSlider,
                            onValueChange = { storageSlider = it },
                            valueRange = 0f..4f,
                            steps = 3,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF0058EE),
                                activeTrackColor = Color(0xFF0058EE)
                            )
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = allowPeerNetworking,
                                onCheckedChange = { allowPeerNetworking = it },
                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF0058EE))
                            )
                            Text(
                                text = "Allow peer-assisted networking (RTMFP)",
                                fontSize = 11.sp,
                                color = Color.Black
                            )
                        }
                    }

                    1 -> {
                        // Display & Quality
                        Text(
                            text = "Display & Stage Quality",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF003399)
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = hardwareAcceleration,
                                onCheckedChange = { hardwareAcceleration = it },
                                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF0058EE))
                            )
                            Text(
                                text = "Enable hardware acceleration (GPU Level 2)",
                                fontSize = 11.sp,
                                color = Color.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Vector Rendering Quality:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )

                        listOf("Low (Fastest)", "Medium", "High (Anti-aliased)", "Best").forEach { q ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clickable { qualitySelection = q }
                                    .padding(vertical = 2.dp)
                            ) {
                                RadioButton(
                                    selected = qualitySelection == q,
                                    onClick = { qualitySelection = q }
                                )
                                Text(text = q, fontSize = 11.sp, color = Color.Black)
                            }
                        }
                    }

                    2 -> {
                        // About
                        Text(
                            text = "Adobe® Flash® Player 10",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = WindowsXpTheme.FlashRed
                        )
                        Text(
                            text = "Version 10.3.183.90 (ActiveX Control)",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Supports ActionScript 3.0, 3D transformations, Pixel Bender filters, WebAssembly Ruffle emulation, and vintage Flash games.",
                            fontSize = 11.sp,
                            color = Color(0xFF333333),
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                onDismiss()
                                onLaunchFlashHub()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = WindowsXpTheme.FlashRed),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("Launch Flash 10 Interactive Hub", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Bottom Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFE0DDD2))
                    .border(1.dp, WindowsXpTheme.BorderDark)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFECE9D8)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7F9DB9)),
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text("Close", color = Color.Black, fontSize = 11.sp)
                }
            }
        }
    }
}
