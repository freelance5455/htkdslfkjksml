package com.example

import android.app.Application
import com.example.data.MusicDatabase
import com.example.data.MusicFileManager
import com.example.data.MusicRepository
import com.example.data.PlaylistTransferManager
import com.example.playback.MusicPlaybackController

class MusicApplication : Application() {
    val database by lazy { MusicDatabase.getInstance(this) }
    val repository by lazy {
        MusicRepository(
            songDao = database.songDao(),
            playlistDao = database.playlistDao(),
            queueDao = database.queueDao()
        )
    }
    val fileManager by lazy { MusicFileManager(this, repository) }
    val playlistTransferManager by lazy { PlaylistTransferManager(this, repository) }
    val playbackController by lazy { MusicPlaybackController(this, repository) }

    override fun onCreate() {
        super.onCreate()
    }
}
