package com.example.croverlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: TextView? = null
    private var enabled = false

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showBubble()
        return START_STICKY
    }
    private fun params(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }
    }
    private fun showBubble() {
        if (bubble != null) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "ESP OFF"; textSize = 13f; setTextColor(Color.BLACK); setTypeface(null, Typeface.BOLD)
            setPadding(22, 14, 22, 14); setBackgroundColor(0xFFB8FF38.toInt())
            setOnClickListener { toggle() }
            setOnTouchListener(object : View.OnTouchListener {
                var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val lp = v.layoutParams as WindowManager.LayoutParams
                    when(e.action) {
                        MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; moved=false; return true }
                        MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true; lp.x=ox+dx; lp.y=oy+dy; wm.updateViewLayout(v,lp); return true }
                        MotionEvent.ACTION_UP -> { if(!moved) toggle(); return true }
                    }
                    return false
                }
            })
        }
        bubble=b; wm.addView(b, params())
    }
    private fun toggle() {
        enabled=!enabled
        bubble?.text=if(enabled) "ESP ON" else "ESP OFF"
        if(enabled) showDemoPanel() else removePanel()
    }
    private fun showDemoPanel() {
        if(panel!=null) return
        val p=TextView(this).apply {
            text="ESP DEMO\nМетки условные\nДанные игры не считываются"
            textSize=12f; setTextColor(Color.WHITE); setPadding(16,12,16,12)
            setBackgroundColor(0xCC202020.toInt())
        }
        panel=p
        val lp=params().apply { y=260 }
        wm.addView(p,lp)
    }
    private fun removePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null }
    override fun onDestroy() { removePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble=null; super.onDestroy() }
}
