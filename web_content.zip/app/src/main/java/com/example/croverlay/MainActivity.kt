package com.example.croverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface fun startOverlay() { runOnUiThread { startOverlayService() } }
            @android.webkit.JavascriptInterface fun stopOverlay() { runOnUiThread { stopService(Intent(this@MainActivity, OverlayService::class.java)) } }
        }, "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Разреши отображение поверх приложений, затем вернись и нажми ВКЛ.", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Плавающая кнопка включена", Toast.LENGTH_SHORT).show()
    }
}
