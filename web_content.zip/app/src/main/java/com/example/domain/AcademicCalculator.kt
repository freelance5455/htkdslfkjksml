package com.example.domain

import com.example.model.AttendanceRecord
import com.example.model.ClassAnalytics
import com.example.model.ObservationRule
import com.example.model.SchoolClass
import com.example.model.SchoolConfig
import com.example.model.Student
import com.example.model.StudentComputedResult
import com.example.model.Subject
import com.example.model.SubjectComputedResult
import com.example.model.TeacherAssignment
import java.util.Locale

object AcademicCalculator {

    fun formatNumber(value: Double): String {
        return if (value % 1.0 == 0.0) {
            value.toLong().toString()
        } else {
            String.format(Locale.US, "%.1f", value)
        }
    }

    fun resolveAutoObservation(percentage: Double, rules: List<ObservationRule>): String {
        val sorted = rules.sortedByDescending { it.minPct }
        for (rule in sorted) {
            if (percentage >= rule.minPct.toDouble()) {
                return rule.commentText
            }
        }
        return sorted.lastOrNull()?.commentText.orEmpty()
    }

    fun computeClassAnalytics(
        subjects: List<Subject>,
        students: List<Student>,
        config: SchoolConfig,
    ): ClassAnalytics {
        val orderedSubjects = subjects.sortedBy { it.sortOrder }
        var maxTestGrand = 0L
        var maxExamGrand = 0L
        var maxTotGrand = 0L
        var anyExamEnabled = false

        orderedSubjects.forEach { sub ->
            val mTest = sub.maxTest.coerceAtLeast(0L)
            val mExam = sub.maxExam.coerceAtLeast(0L)
            if (mExam > 0L) anyExamEnabled = true
            maxTestGrand += mTest
            maxExamGrand += mExam
            maxTotGrand += mTest + mExam
        }

        val decimals = config.decimalPlaces.toInt().coerceIn(0, 2)

        val mutableResults = students.map { stu ->
            var stuTestGrand = 0.0
            var stuExamGrand = 0.0
            var stuTotGrand = 0.0
            val subjectMap = LinkedHashMap<String, SubjectComputedResult>(orderedSubjects.size)

            orderedSubjects.forEach { sub ->
                val mTest = sub.maxTest.coerceAtLeast(0L)
                val mExam = sub.maxExam.coerceAtLeast(0L)
                val mTot = mTest + mExam

                val hasTest = stu.testScores.containsKey(sub.id)
                val hasExam = stu.examScores.containsKey(sub.id)
                val testVal = stu.testScores[sub.id] ?: 0.0
                val examVal = if (mExam > 0L) (stu.examScores[sub.id] ?: 0.0) else 0.0
                val subTot = testVal + examVal

                stuTestGrand += testVal
                if (mExam > 0L) stuExamGrand += examVal
                stuTotGrand += subTot

                subjectMap[sub.id] = SubjectComputedResult(
                    subjectId = sub.id,
                    maxTest = mTest,
                    maxExam = mExam,
                    maxTot = mTot,
                    hasTest = hasTest,
                    hasExam = hasExam,
                    test = testVal,
                    exam = examVal,
                    tot = subTot,
                    rank = 1,
                )
            }

            val rawPct = if (maxTotGrand > 0L) (stuTotGrand / maxTotGrand.toDouble()) * 100.0 else 0.0
            val formattedPct = String.format(Locale.US, "%.${decimals}f", rawPct)

            MutableStudentHolder(
                student = stu,
                subjectResults = subjectMap,
                studentTestGrand = stuTestGrand,
                studentExamGrand = stuExamGrand,
                studentTotGrand = stuTotGrand,
                rawPct = rawPct,
                formattedPct = formattedPct,
                overallRank = 1,
            )
        }

        // Per-subject competition ranking (1, 2, 2, 4)
        orderedSubjects.forEach { sub ->
            val sortedForSub = mutableResults.sortedByDescending { it.subjectResults[sub.id]?.tot ?: 0.0 }
            sortedForSub.forEachIndexed { idx, holder ->
                val currentTot = holder.subjectResults[sub.id]?.tot ?: 0.0
                val rank = if (idx == 0) {
                    1
                } else {
                    val prev = sortedForSub[idx - 1]
                    val prevTot = prev.subjectResults[sub.id]?.tot ?: 0.0
                    if (currentTot == prevTot) prev.subjectResults[sub.id]?.rank ?: 1 else idx + 1
                }
                holder.subjectResults[sub.id]?.let { existing ->
                    holder.subjectResults[sub.id] = existing.copy(rank = rank)
                }
            }
        }

        // Overall class competition ranking (1, 2, 2, 4)
        val sortedOverall = mutableResults.sortedByDescending { it.studentTotGrand }
        sortedOverall.forEachIndexed { idx, holder ->
            holder.overallRank = if (idx == 0) {
                1
            } else {
                val prev = sortedOverall[idx - 1]
                if (holder.studentTotGrand == prev.studentTotGrand) prev.overallRank else idx + 1
            }
        }

        val finalList = mutableResults.map {
            StudentComputedResult(
                student = it.student,
                subjectResults = it.subjectResults,
                studentTestGrand = it.studentTestGrand,
                studentExamGrand = it.studentExamGrand,
                studentTotGrand = it.studentTotGrand,
                rawPct = it.rawPct,
                formattedPct = it.formattedPct,
                overallRank = it.overallRank,
            )
        }

        val count = finalList.size
        val classAvgPct = if (count > 0) finalList.sumOf { it.rawPct } / count else 0.0
        val highestPct = finalList.maxOfOrNull { it.rawPct } ?: 0.0
        val passThreshold = config.passMark.toDouble()
        val passedCount = finalList.count { it.rawPct >= passThreshold }
        val passRatePct = if (count > 0) (passedCount.toDouble() / count) * 100.0 else 0.0

        return ClassAnalytics(
            studentsComputed = finalList,
            byId = finalList.associateBy { it.student.id },
            maxTestGrand = maxTestGrand,
            maxExamGrand = maxExamGrand,
            maxTotGrand = maxTotGrand,
            anyExamEnabled = anyExamEnabled,
            classAvgPct = classAvgPct,
            highestPct = highestPct,
            passRatePct = passRatePct,
        )
    }

    private class MutableStudentHolder(
        val student: Student,
        val subjectResults: MutableMap<String, SubjectComputedResult>,
        val studentTestGrand: Double,
        val studentExamGrand: Double,
        val studentTotGrand: Double,
        val rawPct: Double,
        val formattedPct: String,
        var overallRank: Int,
    )
}

data class SchoolBackupBundle(
    val config: SchoolConfig,
    val classes: List<SchoolClass>,
    val subjects: List<Subject>,
    val students: List<Student>,
    val attendance: List<AttendanceRecord>,
    val teacherAssignments: List<TeacherAssignment>,
    val observationRules: List<ObservationRule>,
)
