package com.example.domain

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.model.ClassAnalytics
import com.example.model.SchoolClass
import com.example.model.SchoolConfig
import com.example.model.StudentComputedResult
import com.example.model.Subject
import com.example.model.defaultReportLabels
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream

object ReportPdfGenerator {
    // Standard A4 size in points (72 DPI): 595 x 842
    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN_X = 34f
    private const val MARGIN_TOP = 28f

    fun generatePdfToStream(
        context: Context,
        outputStream: OutputStream,
        schoolClass: SchoolClass,
        subjects: List<Subject>,
        studentsToExport: List<StudentComputedResult>,
        analytics: ClassAnalytics,
        config: SchoolConfig,
        totalStudentsInClass: Int,
        logoBitmap: Bitmap?,
        signatureBitmap: Bitmap?,
    ) {
        val pdfDocument = PdfDocument()
        val orderedSubjects = subjects.sortedBy { it.sortOrder }

        val serifTypeface = ResourcesCompat.getFont(context, R.font.merriweather) ?: Typeface.SERIF
        val sansTypeface = ResourcesCompat.getFont(context, R.font.plus_jakarta_sans) ?: Typeface.SANS_SERIF
        val baseTypeface = if (config.reportFont == "sans") sansTypeface else serifTypeface

        studentsToExport.forEachIndexed { index, studentResult ->
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, index + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            drawReportPage(
                canvas = page.canvas,
                baseTypeface = baseTypeface,
                schoolClass = schoolClass,
                orderedSubjects = orderedSubjects,
                studentResult = studentResult,
                analytics = analytics,
                config = config,
                totalStudentsInClass = totalStudentsInClass,
                logoBitmap = logoBitmap,
                signatureBitmap = signatureBitmap,
            )
            pdfDocument.finishPage(page)
        }

        pdfDocument.writeTo(outputStream)
        pdfDocument.close()
    }

    fun generateTempPdfFile(
        context: Context,
        fileName: String,
        schoolClass: SchoolClass,
        subjects: List<Subject>,
        studentsToExport: List<StudentComputedResult>,
        analytics: ClassAnalytics,
        config: SchoolConfig,
        totalStudentsInClass: Int,
        logoBitmap: Bitmap?,
        signatureBitmap: Bitmap?,
    ): File {
        val dir = File(context.cacheDir, "pdfs").apply { mkdirs() }
        val file = File(dir, fileName)
        FileOutputStream(file).use { out ->
            generatePdfToStream(
                context = context,
                outputStream = out,
                schoolClass = schoolClass,
                subjects = subjects,
                studentsToExport = studentsToExport,
                analytics = analytics,
                config = config,
                totalStudentsInClass = totalStudentsInClass,
                logoBitmap = logoBitmap,
                signatureBitmap = signatureBitmap,
            )
        }
        return file
    }

    private fun parseColorSafe(hex: String, fallback: Int): Int {
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            fallback
        }
    }

    private fun drawReportPage(
        canvas: Canvas,
        baseTypeface: Typeface,
        schoolClass: SchoolClass,
        orderedSubjects: List<Subject>,
        studentResult: StudentComputedResult,
        analytics: ClassAnalytics,
        config: SchoolConfig,
        totalStudentsInClass: Int,
        logoBitmap: Bitmap?,
        signatureBitmap: Bitmap?,
    ) {
        canvas.drawColor(Color.WHITE)

        val borderColor = parseColorSafe(config.borderColorHex, Color.parseColor("#1F2937"))
        val headerBgColor = parseColorSafe(config.headerBgHex, Color.parseColor("#F8FAFC"))
        val labels = defaultReportLabels() + config.labels

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#111827")
            typeface = Typeface.create(baseTypeface, Typeface.NORMAL)
            textSize = 10f
        }
        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#111827")
            typeface = Typeface.create(baseTypeface, Typeface.BOLD)
            textSize = 10f
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = borderColor
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
        }
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = headerBgColor
            style = Paint.Style.FILL
        }

        val contentWidth = PAGE_WIDTH - MARGIN_X * 2f
        val rightEdge = PAGE_WIDTH - MARGIN_X
        var cursorY = MARGIN_TOP

        // 1. Centered School Logo / Stamp
        if (config.showLogo) {
            val logoSize = (config.logoSizeDp.toFloat() * 0.72f).coerceIn(36f, 88f)
            val centerX = PAGE_WIDTH / 2f
            val centerY = cursorY + logoSize / 2f
            if (logoBitmap != null) {
                val dstRect = RectF(
                    centerX - logoSize / 2f,
                    cursorY,
                    centerX + logoSize / 2f,
                    cursorY + logoSize,
                )
                if (config.logoCircular) {
                    canvas.save()
                    val clipPath = Path().apply {
                        addOval(dstRect, Path.Direction.CW)
                    }
                    canvas.clipPath(clipPath)
                    canvas.drawBitmap(logoBitmap, null, dstRect, null)
                    canvas.restore()
                } else {
                    canvas.drawBitmap(logoBitmap, null, dstRect, null)
                }
            } else {
                drawDefaultEmblemStamp(canvas, centerX, centerY, logoSize / 2f, config.schoolName)
            }
            cursorY += logoSize + 10f
        }

        // 2. Two-Column Header Metadata
        val leftX = MARGIN_X
        boldPaint.textSize = 10f
        textPaint.textSize = 10f

        var leftY = cursorY + 10f
        canvas.drawText(config.country.uppercase(), leftX, leftY, boldPaint)
        leftY += 14f
        val schoolPrefix = labels["schoolPrefix"].orEmpty()
        canvas.drawText(schoolPrefix, leftX, leftY, textPaint)
        val prefixW = textPaint.measureText("$schoolPrefix ")
        canvas.drawText(config.schoolName.uppercase(), leftX + prefixW, leftY, boldPaint)
        leftY += 14f
        canvas.drawText("${labels["poBoxPrefix"].orEmpty()} ${config.poBox}", leftX, leftY, textPaint)
        leftY += 16f
        canvas.drawText("${labels["telPrefix"].orEmpty()} ${config.tel}", leftX, leftY, textPaint)

        var rightY = cursorY + 10f
        boldPaint.textAlign = Paint.Align.RIGHT
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText(config.ministry.uppercase(), rightEdge, rightY, boldPaint)
        rightY += 14f
        canvas.drawText(config.academicYear, rightEdge, rightY, boldPaint)
        rightY += 16f
        canvas.drawText(config.term, rightEdge, rightY, boldPaint)
        boldPaint.textAlign = Paint.Align.LEFT
        textPaint.textAlign = Paint.Align.LEFT

        cursorY = maxOf(leftY, rightY) + 12f

        // 3. Full-Width Bordered Banner Title
        val bannerPaint = Paint(borderPaint).apply { strokeWidth = 1.6f }
        canvas.drawLine(MARGIN_X, cursorY, rightEdge, cursorY, bannerPaint)
        val bannerHeight = 24f
        boldPaint.textSize = 13f
        boldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(config.reportTitle.uppercase(), PAGE_WIDTH / 2f, cursorY + 16.5f, boldPaint)
        boldPaint.textAlign = Paint.Align.LEFT
        cursorY += bannerHeight
        canvas.drawLine(MARGIN_X, cursorY, rightEdge, cursorY, borderPaint)

        // 4. Student Info Grid
        cursorY += 16f
        val stu = studentResult.student
        textPaint.textSize = 10.5f
        boldPaint.textSize = 10.5f
        val labelColWidth = 96f

        canvas.drawText(labels["studentName"].orEmpty(), leftX + 4f, cursorY, textPaint)
        canvas.drawText(stu.name.uppercase(), leftX + labelColWidth, cursorY, boldPaint)
        cursorY += 16f

        canvas.drawText(labels["className"].orEmpty(), leftX + 4f, cursorY, textPaint)
        canvas.drawText(schoolClass.name.uppercase(), leftX + labelColWidth, cursorY, boldPaint)

        val totalDisplay = if (config.manualStudentCount.isNotBlank()) {
            config.manualStudentCount
        } else {
            totalStudentsInClass.toString()
        }
        val conductDisplay = when {
            stu.conduct.isBlank() -> "-"
            config.conductMax.isNotBlank() -> "${stu.conduct}/${config.conductMax}"
            else -> stu.conduct
        }
        val nStudentsX = leftX + contentWidth * 0.48f
        val conductX = leftX + contentWidth * 0.76f
        canvas.drawText("${labels["numStudents"].orEmpty()} $totalDisplay", nStudentsX, cursorY, boldPaint)
        canvas.drawText("${labels["conduct"].orEmpty()} $conductDisplay", conductX, cursorY, boldPaint)
        cursorY += 16f

        canvas.drawText(labels["idNo"].orEmpty(), leftX + 4f, cursorY, textPaint)
        canvas.drawText(stu.studentIdNo, leftX + labelColWidth, cursorY, boldPaint)
        cursorY += 12f

        // 5. 8-Column Marks Table
        val colFractions = floatArrayOf(0.32f, 0.09f, 0.09f, 0.10f, 0.09f, 0.09f, 0.11f, 0.11f)
        val colWidths = colFractions.map { it * contentWidth }
        val rowHeight = if (orderedSubjects.size > 10) 19f else 22f
        val headerRowHeight = 24f

        val headers = listOf(
            labels["subjects"].orEmpty(),
            labels["test"].orEmpty(),
            labels["exam"].orEmpty(),
            labels["tot"].orEmpty(),
            labels["test"].orEmpty(),
            labels["exam"].orEmpty(),
            labels["tot"].orEmpty(),
            labels["rank"].orEmpty(),
        )

        // Header Row
        canvas.drawRect(MARGIN_X, cursorY, rightEdge, cursorY + headerRowHeight, fillPaint)
        drawTableRow(
            canvas = canvas,
            y = cursorY,
            height = headerRowHeight,
            startX = MARGIN_X,
            colWidths = colWidths,
            cells = headers,
            firstColLeftAlign = true,
            paint = boldPaint.apply { textSize = 9.5f },
            borderPaint = borderPaint,
        )
        cursorY += headerRowHeight

        // Subject Rows
        orderedSubjects.forEach { sub ->
            val res = studentResult.subjectResults[sub.id]
            val examEnabled = (res?.maxExam ?: 0L) > 0L
            val cells = listOf(
                sub.name.uppercase(),
                (res?.maxTest ?: sub.maxTest).toString(),
                if (examEnabled) (res?.maxExam ?: sub.maxExam).toString() else "-",
                (res?.maxTot ?: (sub.maxTest + sub.maxExam)).toString(),
                if (res?.hasTest == true) AcademicCalculator.formatNumber(res.test) else "0",
                if (examEnabled) {
                    if (res?.hasExam == true) AcademicCalculator.formatNumber(res.exam) else "0"
                } else "-",
                AcademicCalculator.formatNumber(res?.tot ?: 0.0),
                (res?.rank ?: 1).toString(),
            )
            drawTableRow(
                canvas = canvas,
                y = cursorY,
                height = rowHeight,
                startX = MARGIN_X,
                colWidths = colWidths,
                cells = cells,
                firstColLeftAlign = true,
                paint = textPaint.apply { textSize = 9.5f },
                borderPaint = borderPaint,
                boldColumns = setOf(0, 3, 6, 7),
                boldPaint = boldPaint.apply { textSize = 9.5f },
            )
            cursorY += rowHeight
        }

        // Total Row
        canvas.drawRect(MARGIN_X, cursorY, rightEdge, cursorY + rowHeight, fillPaint)
        val totalCells = listOf(
            labels["totalRow"].orEmpty(),
            analytics.maxTestGrand.toString(),
            if (analytics.anyExamEnabled) analytics.maxExamGrand.toString() else "-",
            analytics.maxTotGrand.toString(),
            AcademicCalculator.formatNumber(studentResult.studentTestGrand),
            if (analytics.anyExamEnabled) AcademicCalculator.formatNumber(studentResult.studentExamGrand) else "-",
            AcademicCalculator.formatNumber(studentResult.studentTotGrand),
            "",
        )
        drawTableRow(
            canvas = canvas,
            y = cursorY,
            height = rowHeight,
            startX = MARGIN_X,
            colWidths = colWidths,
            cells = totalCells,
            firstColLeftAlign = true,
            paint = boldPaint.apply { textSize = 9.5f },
            borderPaint = borderPaint,
            shadedLastCol = true,
        )
        cursorY += rowHeight

        // Summary Row: Average | % | Position | Rank | Lates | n | Absences | n
        val posDisplay = if (config.positionFormat == "fraction") {
            "${studentResult.overallRank} / $totalDisplay"
        } else {
            studentResult.overallRank.toString()
        }
        val latesDisplay = if (stu.latesCount > 0L) stu.latesCount.toString() else "-"
        val absencesDisplay = if (stu.absencesCount > 0L) stu.absencesCount.toString() else "-"
        val summaryCells = listOf(
            labels["average"].orEmpty(),
            "${studentResult.formattedPct}%",
            labels["position"].orEmpty(),
            posDisplay,
            labels["lates"].orEmpty(),
            latesDisplay,
            labels["absences"].orEmpty(),
            absencesDisplay,
        )
        drawTableRow(
            canvas = canvas,
            y = cursorY,
            height = rowHeight + 2f,
            startX = MARGIN_X,
            colWidths = colWidths,
            cells = summaryCells,
            firstColLeftAlign = true,
            paint = textPaint.apply { textSize = 9.5f },
            borderPaint = borderPaint,
            boldColumns = setOf(1, 3),
            boldPaint = boldPaint.apply { textSize = 9.5f },
        )
        cursorY += rowHeight + 18f

        // 6. Two-Column Footer Box: Observations & Signatures
        val footerHeight = 132f
        val midX = MARGIN_X + contentWidth / 2f
        canvas.drawRect(MARGIN_X, cursorY, rightEdge, cursorY + footerHeight, borderPaint)
        canvas.drawLine(midX, cursorY, midX, cursorY + footerHeight, borderPaint)
        val sigMidY = cursorY + footerHeight / 2f
        canvas.drawLine(midX, sigMidY, rightEdge, sigMidY, borderPaint)

        // Left: Observations
        boldPaint.textSize = 10f
        boldPaint.textAlign = Paint.Align.CENTER
        canvas.drawText(labels["observations"].orEmpty(), MARGIN_X + contentWidth * 0.25f, cursorY + 18f, boldPaint)

        val obsText = stu.observation
        if (obsText.isNotBlank()) {
            textPaint.textSize = 10.5f
            textPaint.textAlign = Paint.Align.CENTER
            val lines = wrapText(obsText, textPaint, contentWidth * 0.44f)
            var obsY = cursorY + 56f - ((lines.size - 1) * 7f)
            lines.take(4).forEach { line ->
                canvas.drawText(line, MARGIN_X + contentWidth * 0.25f, obsY, textPaint)
                obsY += 14f
            }
        }

        // Right Top: Teacher Signature
        val rightCenterX = midX + contentWidth * 0.25f
        canvas.drawText(labels["teacherSignature"].orEmpty(), rightCenterX, cursorY + 18f, boldPaint)
        if (signatureBitmap != null) {
            val sigH = (config.signatureSizeDp.toFloat() * 0.7f).coerceIn(22f, 40f)
            val aspect = signatureBitmap.width.toFloat() / signatureBitmap.height.coerceAtLeast(1).toFloat()
            val sigW = (sigH * aspect).coerceAtMost(contentWidth * 0.4f)
            val dst = RectF(
                rightCenterX - sigW / 2f,
                cursorY + 22f,
                rightCenterX + sigW / 2f,
                cursorY + 22f + sigH,
            )
            canvas.drawBitmap(signatureBitmap, null, dst, null)
        } else if (config.teacherName.isNotBlank()) {
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 10f
            canvas.drawText(config.teacherName, rightCenterX, cursorY + 46f, textPaint)
        }

        // Right Bottom: Parent Signature
        canvas.drawText(labels["parentSignature"].orEmpty(), rightCenterX, sigMidY + 18f, boldPaint)
        boldPaint.textAlign = Paint.Align.LEFT
        textPaint.textAlign = Paint.Align.LEFT

        // 7. Bottom Authenticity Line
        val footerLineY = PAGE_HEIGHT - 24f
        val subtlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B")
            textSize = 8f
            typeface = Typeface.create(baseTypeface, Typeface.NORMAL)
        }
        canvas.drawText("${config.schoolName} • ${config.academicYear} (${config.term})", MARGIN_X, footerLineY, subtlePaint)
        subtlePaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("Official Report Card • Trizzie School Management", rightEdge, footerLineY, subtlePaint)
    }

    private fun drawTableRow(
        canvas: Canvas,
        y: Float,
        height: Float,
        startX: Float,
        colWidths: List<Float>,
        cells: List<String>,
        firstColLeftAlign: Boolean,
        paint: Paint,
        borderPaint: Paint,
        boldColumns: Set<Int> = emptySet(),
        boldPaint: Paint = paint,
        shadedLastCol: Boolean = false,
    ) {
        var x = startX
        val baselineOffset = height / 2f + 3.5f
        cells.forEachIndexed { idx, rawText ->
            val w = colWidths[idx]
            if (shadedLastCol && idx == cells.lastIndex) {
                val shadePaint = Paint().apply {
                    color = Color.parseColor("#E2E8F0")
                    style = Paint.Style.FILL
                }
                canvas.drawRect(x, y, x + w, y + height, shadePaint)
            }
            canvas.drawRect(x, y, x + w, y + height, borderPaint)

            val activePaint = if (idx in boldColumns) boldPaint else paint
            val maxTextW = w - 8f
            val clipped = fitText(rawText, activePaint, maxTextW)
            if (idx == 0 && firstColLeftAlign) {
                activePaint.textAlign = Paint.Align.LEFT
                canvas.drawText(clipped, x + 5f, y + baselineOffset, activePaint)
            } else {
                activePaint.textAlign = Paint.Align.CENTER
                canvas.drawText(clipped, x + w / 2f, y + baselineOffset, activePaint)
            }
            x += w
        }
        paint.textAlign = Paint.Align.LEFT
        boldPaint.textAlign = Paint.Align.LEFT
    }

    private fun fitText(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var trimmed = text
        while (trimmed.length > 1 && paint.measureText("$trimmed…") > maxWidth) {
            trimmed = trimmed.dropLast(1)
        }
        return if (trimmed.length < text.length) "$trimmed…" else trimmed
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var current = ""
        for (word in words) {
            val candidate = if (current.isEmpty()) word else "$current $word"
            if (paint.measureText(candidate) <= maxWidth) {
                current = candidate
            } else {
                if (current.isNotEmpty()) lines.add(current)
                current = word
            }
        }
        if (current.isNotEmpty()) lines.add(current)
        return lines
    }

    private fun drawDefaultEmblemStamp(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        radius: Float,
        schoolName: String,
    ) {
        val bluePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1D4ED8")
            style = Paint.Style.STROKE
            strokeWidth = 1.8f
        }
        val fillBlue = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#EFF6FF")
            style = Paint.Style.FILL
        }
        canvas.drawCircle(cx, cy, radius, fillBlue)
        canvas.drawCircle(cx, cy, radius, bluePaint)
        canvas.drawCircle(cx, cy, radius * 0.88f, bluePaint.apply { strokeWidth = 0.8f })
        canvas.drawCircle(cx, cy, radius * 0.56f, bluePaint.apply { strokeWidth = 1.1f })

        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1E40AF")
            textSize = (radius * 0.2f).coerceIn(5.5f, 8.5f)
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val shortName = schoolName.take(18).uppercase()
        canvas.drawText(shortName, cx, cy - radius * 0.65f, labelPaint)
        canvas.drawText("★   ACADEMIC STAMP   ★", cx, cy + radius * 0.76f, labelPaint.apply { textSize *= 0.85f })

        // Center open book motif
        val bookPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1D4ED8")
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
        }
        val bw = radius * 0.36f
        val bh = radius * 0.24f
        val path = Path().apply {
            moveTo(cx - bw, cy - bh * 0.5f)
            quadTo(cx - bw * 0.5f, cy - bh, cx, cy - bh * 0.35f)
            quadTo(cx + bw * 0.5f, cy - bh, cx + bw, cy - bh * 0.5f)
            lineTo(cx + bw, cy + bh * 0.6f)
            quadTo(cx + bw * 0.5f, cy + bh * 0.25f, cx, cy + bh * 0.65f)
            quadTo(cx - bw * 0.5f, cy + bh * 0.25f, cx - bw, cy + bh * 0.6f)
            close()
        }
        canvas.drawPath(path, bookPaint)
        canvas.drawLine(cx, cy - bh * 0.35f, cx, cy + bh * 0.65f, bookPaint)
    }

    fun createPrintAdapter(
        pdfFile: File,
        jobName: String,
    ): PrintDocumentAdapter {
        return object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: Bundle?,
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(jobName)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback,
            ) {
                try {
                    FileInputStream(pdfFile).use { input ->
                        FileOutputStream(destination.fileDescriptor).use { output ->
                            input.copyTo(output)
                        }
                    }
                    if (cancellationSignal?.isCanceled == true) {
                        callback.onWriteCancelled()
                    } else {
                        callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    }
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                }
            }
        }
    }
}
