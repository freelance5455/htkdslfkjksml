package com.example

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ==========================================
// ADMIN LOGIN SCREEN: Manual Entry Only
// Credentials never written on screen
// ==========================================
@Composable
fun MtxAdminLoginScreen(
  onLoginSuccess: () -> Unit,
  onCancel: () -> Unit
) {
  var usernameInput by remember { mutableStateOf("") }
  var passwordInput by remember { mutableStateOf("") }
  var errorMessage by remember { mutableStateOf("") }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0B0E14))
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, Color(0xFF252D3D), RoundedCornerShape(24.dp)),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
      shape = RoundedCornerShape(24.dp)
    ) {
      Column(
        modifier = Modifier.padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(Color(0xFF7C3AED).copy(alpha = 0.2f))
            .border(1.dp, Color(0xFF7C3AED), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Lock, contentDescription = "Admin Lock", tint = Color(0xFFC084FC), modifier = Modifier.size(26.dp))
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text("Administrator Verification", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(
          "Enter your administrative credentials to manage media catalogues and approve Dark User access requests.",
          color = Color(0xFF94A3B8),
          fontSize = 11.sp,
          textAlign = TextAlign.Center,
          modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
        )

        if (errorMessage.isNotEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(Color(0xFFEF4444).copy(alpha = 0.15f), RoundedCornerShape(10.dp))
              .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(10.dp))
              .padding(10.dp)
          ) {
            Text(errorMessage, color = Color(0xFFFCA5A5), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
          }
          Spacer(modifier = Modifier.height(14.dp))
        }

        OutlinedTextField(
          value = usernameInput,
          onValueChange = {
            usernameInput = it
            errorMessage = ""
          },
          label = { Text("Username", fontSize = 12.sp) },
          placeholder = { Text("Enter admin username", color = Color(0xFF64748B), fontSize = 12.sp) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_username_input"),
          singleLine = true,
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF0B0E14),
            unfocusedContainerColor = Color(0xFF0B0E14),
            focusedBorderColor = Color(0xFF8B5CF6),
            unfocusedBorderColor = Color(0xFF232C3D),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          ),
          shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = passwordInput,
          onValueChange = {
            passwordInput = it
            errorMessage = ""
          },
          label = { Text("Password", fontSize = 12.sp) },
          placeholder = { Text("Enter admin password", color = Color(0xFF64748B), fontSize = 12.sp) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_password_input"),
          visualTransformation = PasswordVisualTransformation(),
          singleLine = true,
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF0B0E14),
            unfocusedContainerColor = Color(0xFF0B0E14),
            focusedBorderColor = Color(0xFF8B5CF6),
            unfocusedBorderColor = Color(0xFF232C3D),
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          ),
          shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
          onClick = {
            if (usernameInput.trim().equals("admin", ignoreCase = true) && passwordInput == "admin123") {
              onLoginSuccess()
            } else {
              errorMessage = "Invalid credentials. Please verify administrator username and password."
            }
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("admin_submit_login_button"),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("Sign In as Administrator", fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedButton(
          onClick = onCancel,
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF94A3B8))
        ) {
          Text("Cancel & Return", fontSize = 11.sp)
        }
      }
    }
  }
}

// ==========================================
// ADMIN PANEL SCREEN
// 4 Tabs: Regular Videos, Regular Photos, Dark Site Media, Dark User Requests
// ==========================================
@Composable
fun MtxAdminPanelScreen(
  videos: List<VideoItem>,
  photos: List<PhotoItem>,
  onAddVideo: (VideoItem) -> Unit,
  onDeleteVideo: (Int) -> Unit,
  onTogglePublish: (Int) -> Unit,
  onAddPhoto: (PhotoItem) -> Unit,
  onDeletePhoto: (Int) -> Unit,
  onTogglePublishPhoto: (Int) -> Unit,
  onLogout: () -> Unit,
  onBackToVideos: () -> Unit,
  onGoToPhotos: () -> Unit,
  onGoToDarkSite: () -> Unit,
  onGoToWatch: (VideoItem) -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  // Admin Tab: 0 = Videos, 1 = Photos, 2 = Dark Media, 3 = Dark User Requests
  var selectedAdminTab by remember { mutableIntStateOf(0) }

  var statusMessage by remember { mutableStateOf("") }
  var isProcessingUpload by remember { mutableStateOf(false) }

  // Dark User Requests & Normal Users State
  val darkUserRequests = remember { mutableStateListOf<DarkUserApplication>() }
  val normalUsersList = remember { mutableStateListOf<NormalUser>() }
  var selectedUsersSubFilter by remember { mutableIntStateOf(0) } // 0 = Dark Users, 1 = Pending Requests, 2 = Normal Users
  var isLoadingRequests by remember { mutableStateOf(false) }
  var isServerUnreachable by remember { mutableStateOf(false) }

  fun loadDarkRequests() {
    coroutineScope.launch {
      isLoadingRequests = true
      isServerUnreachable = false

      // 1. Immediately read all requests saved on this device
      val localList = withContext(Dispatchers.IO) {
        DarkRequestStorage.loadRequests(context)
      }
      darkUserRequests.clear()
      darkUserRequests.addAll(localList)

      // 2. Fetch users summary from cloud server (/api/users/all)
      val summary = withContext(Dispatchers.IO) {
        MtxCloudSync.fetchUsersSummary()
      }

      if (summary != null) {
        isServerUnreachable = false
        normalUsersList.clear()
        normalUsersList.addAll(summary.normalUsers)

        val cloudAll = if (summary.allDarkApplications.isNotEmpty()) {
          summary.allDarkApplications
        } else {
          summary.approvedDarkUsers + summary.pendingDarkUsers
        }
        val merged = cloudAll.toMutableList()
        for (local in localList) {
          if (!merged.any { it.userId == local.userId }) {
            merged.add(local)
          }
        }
        darkUserRequests.clear()
        darkUserRequests.addAll(merged)
        withContext(Dispatchers.IO) {
          DarkRequestStorage.saveRequests(context, merged)
        }
      } else {
        // Fallback to fetchDarkUsersList if summary fails
        val cloudList = withContext(Dispatchers.IO) {
          MtxCloudSync.fetchDarkUsersList()
        }
        if (cloudList == null) {
          isServerUnreachable = true
        } else {
          isServerUnreachable = false
          val merged = cloudList.toMutableList()
          for (local in localList) {
            if (!merged.any { it.userId == local.userId }) {
              merged.add(local)
            }
          }
          darkUserRequests.clear()
          darkUserRequests.addAll(merged)
          withContext(Dispatchers.IO) {
            DarkRequestStorage.saveRequests(context, merged)
          }
        }
      }
      isLoadingRequests = false
    }
  }

  // Load requests as soon as admin opens panel
  LaunchedEffect(Unit) {
    loadDarkRequests()
  }

  LaunchedEffect(selectedAdminTab) {
    if (selectedAdminTab == 3) {
      loadDarkRequests()
    }
  }

  // Category selections for uploads
  var selectedUploadNormalCategory by remember { mutableStateOf("Trending") }
  var selectedUploadDarkCategory by remember { mutableStateOf("Dark Thrillers") }

  // Gallery Picker: Regular Video
  val regularVideoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      coroutineScope.launch {
        isProcessingUpload = true
        statusMessage = "Reading video from gallery..."
        val (savedPath, extractedTitle) = withContext(Dispatchers.IO) {
          copyMediaUriToLocalStorage(context, uri, "mtx_video", "mp4")
        }
        val duration = withContext(Dispatchers.IO) { extractVideoDuration(savedPath) }

        statusMessage = "Uploading video to MTX Cloud for all downloaders..."
        val uploadedUrl = withContext(Dispatchers.IO) {
          MtxCloudSync.uploadMediaFile(File(savedPath), "video/mp4")
        }

        if (uploadedUrl == null) {
          isProcessingUpload = false
          statusMessage = "Upload failed: Server unreachable or connection timed out. Please check connection and try again."
          return@launch
        }

        val colorPresets = listOf(Color(0xFF6366F1), Color(0xFF10B981), Color(0xFFEC4899), Color(0xFF8B5CF6))
        val newVid = VideoItem(
          id = (System.currentTimeMillis() % 100000).toInt(),
          title = extractedTitle,
          category = selectedUploadNormalCategory,
          duration = duration,
          views = "1",
          description = "Uploaded by admin to MTX Cloud.",
          videoUri = uploadedUrl,
          isLocalFile = false,
          accentColor = colorPresets[(videos.size) % colorPresets.size],
          isPublished = true,
          isDark = false
        )

        val metadataSynced = withContext(Dispatchers.IO) { MtxCloudSync.syncVideoToCloud(newVid) }
        onAddVideo(newVid)
        isProcessingUpload = false
        statusMessage = if (metadataSynced) {
          "Video '$extractedTitle' uploaded & live for all downloaders in '$selectedUploadNormalCategory'!"
        } else {
          "Video file uploaded, but cloud catalogue sync failed. It is saved on this device; retry publishing when the server is available."
        }
      }
    }
  }

  // Gallery Picker: Regular Photo
  val regularPhotoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      coroutineScope.launch {
        isProcessingUpload = true
        statusMessage = "Processing gallery photo..."
        val (savedPath, extractedTitle) = withContext(Dispatchers.IO) {
          copyMediaUriToLocalStorage(context, uri, "mtx_photo", "jpg")
        }

        statusMessage = "Uploading photo to MTX Cloud..."
        val uploadedUrl = withContext(Dispatchers.IO) {
          MtxCloudSync.uploadMediaFile(File(savedPath), "image/jpeg")
        }
        val finalUri = uploadedUrl ?: savedPath

        val newPhoto = PhotoItem(
          id = (System.currentTimeMillis() % 100000).toInt(),
          title = extractedTitle,
          category = "Posters & Art",
          imageUri = finalUri,
          isLocalFile = uploadedUrl == null,
          uploadDate = "Today",
          likes = 14,
          isPublished = true,
          isDark = false
        )

        withContext(Dispatchers.IO) { MtxCloudSync.syncPhotoToCloud(newPhoto) }
        onAddPhoto(newPhoto)
        isProcessingUpload = false
        statusMessage = "Photo '$extractedTitle' uploaded and synced for all downloaders!"
      }
    }
  }

  // Gallery Picker: Dark Video
  val darkVideoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      coroutineScope.launch {
        isProcessingUpload = true
        statusMessage = "Reading dark gallery video..."
        val (savedPath, extractedTitle) = withContext(Dispatchers.IO) {
          copyMediaUriToLocalStorage(context, uri, "dark_video", "mp4")
        }
        val duration = withContext(Dispatchers.IO) { extractVideoDuration(savedPath) }

        statusMessage = "Uploading dark video to MTX Cloud..."
        val uploadedUrl = withContext(Dispatchers.IO) {
          MtxCloudSync.uploadMediaFile(File(savedPath), "video/mp4")
        }

        if (uploadedUrl == null) {
          isProcessingUpload = false
          statusMessage = "Dark video upload failed: Server unreachable or connection timed out. Please retry."
          return@launch
        }

        val newVid = VideoItem(
          id = (System.currentTimeMillis() % 100000).toInt(),
          title = extractedTitle,
          category = selectedUploadDarkCategory,
          duration = duration,
          views = "1",
          description = "Exclusive Dark Site video uploaded by admin.",
          videoUri = uploadedUrl,
          isLocalFile = false,
          accentColor = Color(0xFFDC2626),
          isPublished = true,
          isDark = true
        )

        val metadataSynced = withContext(Dispatchers.IO) { MtxCloudSync.syncVideoToCloud(newVid) }
        onAddVideo(newVid)
        isProcessingUpload = false
        statusMessage = if (metadataSynced) {
          "Dark Video '$extractedTitle' uploaded & live for all approved Dark Users in '$selectedUploadDarkCategory'!"
        } else {
          "Dark video file uploaded, but cloud catalogue sync failed. It is saved on this device; retry publishing when the server is available."
        }
      }
    }
  }

  // Gallery Picker: Dark Photo
  val darkPhotoPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      coroutineScope.launch {
        isProcessingUpload = true
        statusMessage = "Processing dark photo..."
        val (savedPath, extractedTitle) = withContext(Dispatchers.IO) {
          copyMediaUriToLocalStorage(context, uri, "dark_photo", "jpg")
        }

        statusMessage = "Uploading dark photo to MTX Cloud..."
        val uploadedUrl = withContext(Dispatchers.IO) {
          MtxCloudSync.uploadMediaFile(File(savedPath), "image/jpeg")
        }
        val finalUri = uploadedUrl ?: savedPath

        val newPhoto = PhotoItem(
          id = (System.currentTimeMillis() % 100000).toInt(),
          title = extractedTitle,
          category = "Dark Aesthetic",
          imageUri = finalUri,
          isLocalFile = uploadedUrl == null,
          uploadDate = "Exclusive",
          likes = 28,
          isPublished = true,
          isDark = true
        )

        withContext(Dispatchers.IO) { MtxCloudSync.syncPhotoToCloud(newPhoto) }
        onAddPhoto(newPhoto)
        isProcessingUpload = false
        statusMessage = "Dark Photo '$extractedTitle' uploaded to Dark Site!"
      }
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0B0E14)),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(onClick = onBackToVideos, modifier = Modifier.size(36.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text("Admin Control Hub", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        Button(
          onClick = onLogout,
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444).copy(alpha = 0.2f)),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Text("Exit Admin", color = Color(0xFFF87171), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 4 Administrative Tabs
    item {
      TabRow(
        selectedTabIndex = selectedAdminTab,
        containerColor = Color(0xFF151A24),
        contentColor = Color.White,
        indicator = { tabPositions ->
          SecondaryIndicator(
            Modifier.tabIndicatorOffset(tabPositions[selectedAdminTab]),
            color = if (selectedAdminTab >= 2) Color(0xFFEF4444) else Color(0xFF7C3AED),
            height = 3.dp
          )
        }
      ) {
        Tab(
          selected = selectedAdminTab == 0,
          onClick = { selectedAdminTab = 0 },
          text = { Text("Videos", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
          modifier = Modifier.testTag("admin_tab_videos")
        )
        Tab(
          selected = selectedAdminTab == 1,
          onClick = { selectedAdminTab = 1 },
          text = { Text("Photos", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
          modifier = Modifier.testTag("admin_tab_photos")
        )
        Tab(
          selected = selectedAdminTab == 2,
          onClick = { selectedAdminTab = 2 },
          text = { Text("Dark Media", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444)) },
          modifier = Modifier.testTag("admin_tab_dark_media")
        )
        val pendingCount = darkUserRequests.count { it.status == "pending" }
        Tab(
          selected = selectedAdminTab == 3,
          onClick = { selectedAdminTab = 3 },
          text = {
            Text(
              if (pendingCount > 0) "Users ($pendingCount ⏳)" else "Users",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              color = if (pendingCount > 0) Color(0xFFFDE047) else Color(0xFFEAB308)
            )
          },
          modifier = Modifier.testTag("admin_tab_users")
        )
      }
    }

    // Status Message Banner
    if (statusMessage.isNotEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF10B981).copy(alpha = 0.15f), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
            .padding(12.dp)
        ) {
          Text(statusMessage, color = Color(0xFF34D399), fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        }
      }
    }

    // ==========================================
    // TAB 0: REGULAR VIDEOS
    // ==========================================
    if (selectedAdminTab == 0) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF252D3D))
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Text("Upload Video from Device Gallery", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
              "Select any MP4 video from your gallery. It will be uploaded to MTX Cloud and instantly available to all new and existing downloaders.",
              color = Color(0xFF94A3B8),
              fontSize = 11.sp,
              modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
            )

            Text("Select Video Category / Genre:", color = Color(0xFF60A5FA), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            androidx.compose.foundation.lazy.LazyRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
            ) {
              items(availableVideoCategories) { cat ->
                val isSelected = cat == selectedUploadNormalCategory
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) Color(0xFF2563EB) else Color(0xFF0B0E14))
                    .border(1.dp, if (isSelected) Color(0xFF3B82F6) else Color(0xFF252D3D), RoundedCornerShape(8.dp))
                    .clickable { selectedUploadNormalCategory = cat }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                  Text(cat, color = if (isSelected) Color.White else Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                }
              }
            }

            Button(
              onClick = { regularVideoPicker.launch("video/*") },
              enabled = !isProcessingUpload,
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("choose_video_from_gallery_button"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
              shape = RoundedCornerShape(14.dp)
            ) {
              if (isProcessingUpload) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Uploading to Cloud...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
              } else {
                Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text("Choose Video from Gallery", fontSize = 13.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }

      val regularVideos = videos.filter { !it.isDark }
      item {
        Text("Active Regular Videos (${regularVideos.size})", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
      }

      items(regularVideos) { vid ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF252D3D), RoundedCornerShape(14.dp)),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
          shape = RoundedCornerShape(14.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(vid.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
              Text("${vid.category} • ${vid.duration}", color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = { onTogglePublish(vid.id) }, modifier = Modifier.size(36.dp)) {
                Icon(if (vid.isPublished) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
              }
              IconButton(onClick = { onDeleteVideo(vid.id) }, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }
    }

    // ==========================================
    // TAB 1: REGULAR PHOTOS
    // ==========================================
    if (selectedAdminTab == 1) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF252D3D))
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Text("Upload Photos from Device Gallery", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
              "Choose photos from your phone gallery. Photos appear in the user Photo section and sync across all downloaders.",
              color = Color(0xFF94A3B8),
              fontSize = 11.sp,
              modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
            )

            Button(
              onClick = { regularPhotoPicker.launch("image/*") },
              enabled = !isProcessingUpload,
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("choose_photo_from_gallery_button"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
              shape = RoundedCornerShape(14.dp)
            ) {
              if (isProcessingUpload) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Uploading Photo...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
              } else {
                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text("Choose Photo from Device Gallery", fontSize = 13.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }

      val regularPhotos = photos.filter { !it.isDark }
      item {
        Text("Active Regular Photos (${regularPhotos.size})", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
      }

      items(regularPhotos) { photo ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF252D3D), RoundedCornerShape(14.dp)),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
          shape = RoundedCornerShape(14.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(photo.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
              Text("${photo.category} • ${photo.likes} likes", color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = { onTogglePublishPhoto(photo.id) }, modifier = Modifier.size(36.dp)) {
                Icon(if (photo.isPublished) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = null, tint = Color(0xFFC084FC), modifier = Modifier.size(18.dp))
              }
              IconButton(onClick = { onDeletePhoto(photo.id) }, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }
    }

    // ==========================================
    // TAB 2: DARK SITE MEDIA (Uploads from Gallery for Dark Site!)
    // ==========================================
    if (selectedAdminTab == 2) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF150F1E)),
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFEF4444).copy(alpha = 0.5f))
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Upload Dark Site Media from Gallery", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            Text(
              "Upload exclusive videos and photos specifically for approved Dark Users. Uploaded media will appear in the Dark Site section with full YouTube-style streaming and photo lightbox.",
              color = Color(0xFF94A3B8),
              fontSize = 11.sp,
              modifier = Modifier.padding(top = 4.dp, bottom = 12.dp),
              lineHeight = 16.sp
            )

            Text("Select Dark Category / Genre:", color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            androidx.compose.foundation.lazy.LazyRow(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
            ) {
              items(availableDarkCategories) { cat ->
                val isSelected = cat == selectedUploadDarkCategory
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) Color(0xFFDC2626) else Color(0xFF0F0914))
                    .border(1.dp, if (isSelected) Color(0xFFEF4444) else Color(0xFF381F28), RoundedCornerShape(8.dp))
                    .clickable { selectedUploadDarkCategory = cat }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                  Text(cat, color = if (isSelected) Color.White else Color(0xFF94A3B8), fontSize = 10.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                }
              }
            }

            // Button 1: Upload Dark Video from Gallery
            Button(
              onClick = { darkVideoPicker.launch("video/*") },
              enabled = !isProcessingUpload,
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("admin_upload_dark_video_button"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
              shape = RoundedCornerShape(14.dp)
            ) {
              Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(10.dp))
              Text("Upload Dark Video from Gallery", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Button 2: Upload Dark Photo from Gallery
            Button(
              onClick = { darkPhotoPicker.launch("image/*") },
              enabled = !isProcessingUpload,
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("admin_upload_dark_photo_button"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9333EA)),
              shape = RoundedCornerShape(14.dp)
            ) {
              Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(10.dp))
              Text("Upload Dark Photo from Gallery", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      val darkVideosList = videos.filter { it.isDark }
      val darkPhotosList = photos.filter { it.isDark }

      item {
        Text("Active Dark Site Videos (${darkVideosList.size})", color = Color(0xFFF87171), fontSize = 14.sp, fontWeight = FontWeight.Bold)
      }

      items(darkVideosList) { vid ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF381F28), RoundedCornerShape(14.dp)),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF140D18)),
          shape = RoundedCornerShape(14.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(vid.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
              Text("DARK • ${vid.category} • ${vid.duration}", color = Color(0xFFEF4444), fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(onClick = { onTogglePublish(vid.id) }, modifier = Modifier.size(36.dp)) {
                Icon(if (vid.isPublished) Icons.Default.Visibility else Icons.Default.VisibilityOff, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(18.dp))
              }
              IconButton(onClick = { onDeleteVideo(vid.id) }, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }

      item {
        Text("Active Dark Site Photos (${darkPhotosList.size})", color = Color(0xFFC084FC), fontSize = 14.sp, fontWeight = FontWeight.Bold)
      }

      items(darkPhotosList) { photo ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF3B1E32), RoundedCornerShape(14.dp)),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF150D20)),
          shape = RoundedCornerShape(14.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(photo.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
              Text("DARK • ${photo.category}", color = Color(0xFFA855F7), fontSize = 11.sp)
            }
            IconButton(onClick = { onDeletePhoto(photo.id) }, modifier = Modifier.size(36.dp)) {
              Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(18.dp))
            }
          }
        }
      }
    }

    // ==========================================
    // TAB 3: USER MANAGEMENT (Dark Users & Normal Users)
    // Admin can remove Dark User at any time!
    // ==========================================
    if (selectedAdminTab == 3) {
      val approvedDarkUsers = darkUserRequests.filter { it.status == "approved" }
      val pendingDarkRequests = darkUserRequests.filter { it.status == "pending" }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("User Management Hub", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(
              "Review Dark & Normal user lists. Remove Dark Site members at any time.",
              color = Color(0xFF94A3B8),
              fontSize = 11.sp
            )
          }

          IconButton(onClick = { loadDarkRequests() }, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color(0xFFEAB308), modifier = Modifier.size(20.dp))
          }
        }
      }

      // 3-way Sub-filter: Dark Users | Pending Requests | Normal Users
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF151A24), RoundedCornerShape(12.dp))
            .padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          // Tab A: Dark Users (Approved)
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (selectedUsersSubFilter == 0) Color(0xFFDC2626) else Color.Transparent)
              .clickable { selectedUsersSubFilter = 0 }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              "Dark Users (${approvedDarkUsers.size})",
              color = if (selectedUsersSubFilter == 0) Color.White else Color(0xFFF87171),
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              textAlign = TextAlign.Center
            )
          }

          // Tab B: Pending Requests
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (selectedUsersSubFilter == 1) Color(0xFFCA8A04) else Color.Transparent)
              .clickable { selectedUsersSubFilter = 1 }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              "Pending (${pendingDarkRequests.size})",
              color = if (selectedUsersSubFilter == 1) Color.White else Color(0xFFFDE047),
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              textAlign = TextAlign.Center
            )
          }

          // Tab C: Normal Users
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(RoundedCornerShape(8.dp))
              .background(if (selectedUsersSubFilter == 2) Color(0xFF2563EB) else Color.Transparent)
              .clickable { selectedUsersSubFilter = 2 }
              .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              "Normal Users (${normalUsersList.size})",
              color = if (selectedUsersSubFilter == 2) Color.White else Color(0xFF60A5FA),
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              textAlign = TextAlign.Center
            )
          }
        }
      }

      if (isServerUnreachable) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(Color(0xFFEF4444).copy(alpha = 0.15f), RoundedCornerShape(12.dp))
              .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(12.dp))
              .padding(12.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Server unreachable. Showing cached users. Tap refresh to retry.", color = Color(0xFFFCA5A5), fontSize = 11.sp)
            }
          }
        }
      }

      if (isLoadingRequests) {
        item {
          Box(modifier = Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color(0xFFEAB308))
          }
        }
      } else if (selectedUsersSubFilter == 0) {
        // ==========================================
        // SUB-VIEW 0: APPROVED DARK USERS (With Revoke/Remove button!)
        // ==========================================
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Approved Dark Site Members (${approvedDarkUsers.size})", color = Color(0xFFEF4444), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("Admin can remove any user", color = Color(0xFF94A3B8), fontSize = 10.sp)
          }
        }

        if (approvedDarkUsers.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF151A24), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFF252D3D), RoundedCornerShape(16.dp))
                .padding(24.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(10.dp))
                Text("No Approved Dark Users Yet", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(
                  "Users must apply with a live camera face photo. Once approved, they appear here and you can remove their access at any time.",
                  color = Color(0xFF94A3B8),
                  fontSize = 11.sp,
                  textAlign = TextAlign.Center
                )
              }
            }
          }
        } else {
          items(approvedDarkUsers) { userReq ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFDC2626), RoundedCornerShape(16.dp)),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF1A0E14)),
              shape = RoundedCornerShape(16.dp)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  // Face Photo
                  Box(
                    modifier = Modifier
                      .size(64.dp)
                      .clip(RoundedCornerShape(12.dp))
                      .border(1.5.dp, Color(0xFFDC2626), RoundedCornerShape(12.dp))
                      .background(Color(0xFF090A0F))
                  ) {
                    if (userReq.facePhotoUri.isNotBlank()) {
                      AsyncImage(
                        model = userReq.facePhotoUri,
                        contentDescription = "Dark User Face",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                      )
                    } else {
                      Icon(Icons.Default.Face, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.align(Alignment.Center).size(32.dp))
                    }
                  }

                  Spacer(modifier = Modifier.width(12.dp))

                  Column(modifier = Modifier.weight(1f)) {
                    Text(userReq.userName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("ID: ${userReq.userId}", color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFDC2626).copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                      Text("Active Dark Member", color = Color(0xFFF87171), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Admin Remove Dark User Button
                Button(
                  onClick = {
                    coroutineScope.launch {
                      withContext(Dispatchers.IO) {
                        MtxCloudSync.revokeDarkUser(userReq.userId)
                        DarkRequestStorage.updateStatus(context, userReq.userId, "revoked")
                        val currentAuth = DarkUserStorage.load(context)
                        if (currentAuth.userId == userReq.userId) {
                          val updated = currentAuth.copy(isApproved = false, status = "revoked")
                          DarkUserStorage.save(context, updated)
                        }
                      }
                      statusMessage = "Dark access REMOVED for '${userReq.userName}'. User must reapply to enter Dark Site."
                      loadDarkRequests()
                    }
                  },
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .testTag("remove_dark_user_button_${userReq.userId}"),
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.Delete, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Remove Dark User", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      } else if (selectedUsersSubFilter == 1) {
        // ==========================================
        // SUB-VIEW 1: PENDING FACE REQUESTS
        // ==========================================
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Pending Face Requests (${pendingDarkRequests.size})", color = Color(0xFFEAB308), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("Verify camera selfies", color = Color(0xFF94A3B8), fontSize = 10.sp)
          }
        }

        if (pendingDarkRequests.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF151A24), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFF252D3D), RoundedCornerShape(16.dp))
                .padding(24.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Face, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(10.dp))
                Text("No Pending Applications", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("When users take a live photo and apply, applications appear here for approval.", color = Color(0xFF94A3B8), fontSize = 11.sp, textAlign = TextAlign.Center)
              }
            }
          }
        } else {
          items(pendingDarkRequests) { userReq ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFFEAB308), RoundedCornerShape(16.dp)),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF151522)),
              shape = RoundedCornerShape(16.dp)
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Box(
                    modifier = Modifier
                      .size(68.dp)
                      .clip(RoundedCornerShape(12.dp))
                      .border(1.5.dp, Color(0xFFEAB308), RoundedCornerShape(12.dp))
                      .background(Color(0xFF090A0F))
                  ) {
                    if (userReq.facePhotoUri.isNotBlank()) {
                      AsyncImage(
                        model = userReq.facePhotoUri,
                        contentDescription = "User Face",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                      )
                    } else {
                      Icon(Icons.Default.Face, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.align(Alignment.Center).size(36.dp))
                    }
                  }

                  Spacer(modifier = Modifier.width(12.dp))

                  Column(modifier = Modifier.weight(1f)) {
                    Text(userReq.userName, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("ID: ${userReq.userId}", color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFFEAB308).copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                      Text("⏳ Pending Admin Approval", color = Color(0xFFFDE047), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Button(
                    onClick = {
                      coroutineScope.launch {
                        withContext(Dispatchers.IO) {
                          DarkRequestStorage.updateStatus(context, userReq.userId, "approved")
                          val currentAuth = DarkUserStorage.load(context)
                          if (currentAuth.userId == userReq.userId) {
                            val updated = currentAuth.copy(isApproved = true, status = "approved")
                            DarkUserStorage.save(context, updated)
                          }
                          MtxCloudSync.approveDarkUser(userReq.userId)
                        }
                        statusMessage = "User '${userReq.userName}' APPROVED! Permanent Dark Site access granted."
                        loadDarkRequests()
                      }
                    },
                    modifier = Modifier
                      .weight(1f)
                      .height(40.dp)
                      .testTag("approve_dark_user_button_${userReq.userId}"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Approve Access", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }

                  OutlinedButton(
                    onClick = {
                      coroutineScope.launch {
                        withContext(Dispatchers.IO) {
                          DarkRequestStorage.updateStatus(context, userReq.userId, "rejected")
                          val currentAuth = DarkUserStorage.load(context)
                          if (currentAuth.userId == userReq.userId) {
                            val updated = currentAuth.copy(status = "rejected")
                            DarkUserStorage.save(context, updated)
                          }
                          MtxCloudSync.rejectDarkUser(userReq.userId)
                        }
                        statusMessage = "User '${userReq.userName}' application rejected."
                        loadDarkRequests()
                      }
                    },
                    modifier = Modifier
                      .weight(1f)
                      .height(40.dp)
                      .testTag("reject_dark_user_button_${userReq.userId}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF87171))
                  ) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Reject", fontSize = 11.sp)
                  }
                }
              }
            }
          }
        }
      } else {
        // ==========================================
        // SUB-VIEW 2: NORMAL USERS (All registered app downloaders)
        // ==========================================
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Registered Normal Users (${normalUsersList.size})", color = Color(0xFF60A5FA), fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("Public Vault access", color = Color(0xFF94A3B8), fontSize = 10.sp)
          }
        }

        if (normalUsersList.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF151A24), RoundedCornerShape(16.dp))
                .border(1.dp, Color(0xFF252D3D), RoundedCornerShape(16.dp))
                .padding(24.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Face, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(10.dp))
                Text("No Normal Users Registered Yet", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(
                  "When new downloaders open the MTX app, their devices are registered here automatically.",
                  color = Color(0xFF94A3B8),
                  fontSize = 11.sp,
                  textAlign = TextAlign.Center
                )
              }
            }
          }
        } else {
          items(normalUsersList) { normalUser ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0xFF2563EB).copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF111726)),
              shape = RoundedCornerShape(14.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2563EB).copy(alpha = 0.2f))
                    .border(1.dp, Color(0xFF3B82F6), CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.Face, contentDescription = null, tint = Color(0xFF60A5FA), modifier = Modifier.size(24.dp))
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                  Text(normalUser.userName, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                  Text("ID: ${normalUser.userId} • ${normalUser.deviceModel}", color = Color(0xFF94A3B8), fontSize = 10.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                  Spacer(modifier = Modifier.height(4.dp))
                  Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF2563EB).copy(alpha = 0.2f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                      Text("Normal User", color = Color(0xFF93C5FD), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF10B981).copy(alpha = 0.15f))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                      Text(normalUser.lastSeen, color = Color(0xFF34D399), fontSize = 9.sp)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
