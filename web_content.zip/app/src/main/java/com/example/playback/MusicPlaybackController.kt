package com.example.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.MusicRepository
import com.example.data.model.SongEntity
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class MusicPlaybackController(
    private val context: Context,
    private val repository: MusicRepository
) {
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    private val _currentSong = MutableStateFlow<SongEntity?>(null)
    val currentSong: StateFlow<SongEntity?> = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isBuffering = MutableStateFlow(false)
    val isBuffering: StateFlow<Boolean> = _isBuffering.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _durationMs = MutableStateFlow(0L)
    val durationMs: StateFlow<Long> = _durationMs.asStateFlow()

    private val _queue = MutableStateFlow<List<SongEntity>>(emptyList())
    val queue: StateFlow<List<SongEntity>> = _queue.asStateFlow()

    private val _currentQueueIndex = MutableStateFlow(-1)
    val currentQueueIndex: StateFlow<Int> = _currentQueueIndex.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    // 0 = OFF, 1 = REPEAT_ALL, 2 = REPEAT_ONE
    private val _repeatMode = MutableStateFlow(0)
    val repeatMode: StateFlow<Int> = _repeatMode.asStateFlow()

    private val _sleepTimerRemainingSeconds = MutableStateFlow<Long?>(null)
    val sleepTimerRemainingSeconds: StateFlow<Long?> = _sleepTimerRemainingSeconds.asStateFlow()

    private var sleepTimerJob: Job? = null
    private var progressTickerJob: Job? = null

    init {
        initializeController()
        restoreQueue()
    }

    private fun initializeController() {
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            try {
                mediaController = controllerFuture?.get()
                setupPlayerListener()
            } catch (_: Exception) {}
        }, MoreExecutors.directExecutor())
    }

    private fun setupPlayerListener() {
        val controller = mediaController ?: return
        controller.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                _isPlaying.value = isPlaying
                if (isPlaying) {
                    startProgressTicker()
                } else {
                    stopProgressTicker()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                _isBuffering.value = (playbackState == Player.STATE_BUFFERING)
                if (playbackState == Player.STATE_READY) {
                    _durationMs.value = controller.duration.coerceAtLeast(0L)
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val mediaId = mediaItem?.mediaId?.toLongOrNull()
                if (mediaId != null) {
                    val song = _queue.value.find { it.id == mediaId }
                    if (song != null) {
                        _currentSong.value = song
                        _currentQueueIndex.value = _queue.value.indexOf(song)
                        _durationMs.value = song.durationMs
                        scope.launch { repository.recordPlay(song.id) }
                    }
                }
            }
        })
    }

    private fun restoreQueue() {
        scope.launch {
            val saved = repository.getSavedQueue()
            if (saved.isNotEmpty()) {
                _queue.value = saved
                _currentSong.value = saved.firstOrNull()
                _currentQueueIndex.value = 0
            }
        }
    }

    private fun startProgressTicker() {
        progressTickerJob?.cancel()
        progressTickerJob = scope.launch {
            while (isActive) {
                mediaController?.let {
                    _currentPositionMs.value = it.currentPosition.coerceAtLeast(0L)
                    val dur = it.duration
                    if (dur > 0L) {
                        _durationMs.value = dur
                    }
                }
                delay(400)
            }
        }
    }

    private fun stopProgressTicker() {
        progressTickerJob?.cancel()
    }

    fun playSong(song: SongEntity, newQueue: List<SongEntity> = listOf(song), startIndex: Int = 0) {
        val controller = mediaController ?: return
        val targetIndex = if (newQueue.contains(song)) newQueue.indexOf(song) else startIndex

        _queue.value = newQueue
        _currentSong.value = song
        _currentQueueIndex.value = targetIndex

        scope.launch {
            repository.saveQueue(newQueue.map { it.id })
            repository.recordPlay(song.id)
        }

        val mediaItems = newQueue.map { buildMediaItem(it) }
        controller.setMediaItems(mediaItems, targetIndex, 0L)
        controller.prepare()
        controller.play()
    }

    fun togglePlayPause() {
        val controller = mediaController ?: return
        if (controller.isPlaying) {
            controller.pause()
        } else {
            if (controller.mediaItemCount == 0 && _queue.value.isNotEmpty()) {
                val index = _currentQueueIndex.value.coerceAtLeast(0)
                val song = _queue.value.getOrNull(index) ?: _queue.value.first()
                playSong(song, _queue.value, index)
            } else {
                controller.play()
            }
        }
    }

    fun seekTo(positionMs: Long) {
        mediaController?.seekTo(positionMs)
        _currentPositionMs.value = positionMs
    }

    fun skipToNext() {
        val controller = mediaController ?: return
        if (controller.hasNextMediaItem()) {
            controller.seekToNextMediaItem()
        } else if (_queue.value.isNotEmpty()) {
            val nextIndex = (_currentQueueIndex.value + 1) % _queue.value.size
            playSongAtIndex(nextIndex)
        }
    }

    fun skipToPrevious() {
        val controller = mediaController ?: return
        if (controller.currentPosition > 3000L) {
            controller.seekTo(0L)
            _currentPositionMs.value = 0L
        } else if (controller.hasPreviousMediaItem()) {
            controller.seekToPreviousMediaItem()
        } else if (_queue.value.isNotEmpty()) {
            val prevIndex = if (_currentQueueIndex.value - 1 < 0) _queue.value.size - 1 else _currentQueueIndex.value - 1
            playSongAtIndex(prevIndex)
        }
    }

    fun playSongAtIndex(index: Int) {
        val songs = _queue.value
        if (index in songs.indices) {
            val song = songs[index]
            val controller = mediaController ?: return
            if (controller.mediaItemCount == songs.size) {
                controller.seekToDefaultPosition(index)
                controller.play()
            } else {
                playSong(song, songs, index)
            }
        }
    }

    fun toggleShuffle() {
        val controller = mediaController ?: return
        val newShuffle = !_isShuffle.value
        _isShuffle.value = newShuffle
        controller.shuffleModeEnabled = newShuffle
    }

    fun cycleRepeatMode() {
        val controller = mediaController ?: return
        // 0: OFF -> 1: ALL -> 2: ONE -> 0: OFF
        val next = (_repeatMode.value + 1) % 3
        _repeatMode.value = next
        controller.repeatMode = when (next) {
            1 -> Player.REPEAT_MODE_ALL
            2 -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun addToQueue(song: SongEntity) {
        val updated = _queue.value + song
        _queue.value = updated
        mediaController?.addMediaItem(buildMediaItem(song))
        scope.launch { repository.saveQueue(updated.map { it.id }) }
    }

    fun playNext(song: SongEntity) {
        val currentIdx = _currentQueueIndex.value
        val list = _queue.value.toMutableList()
        val insertAt = if (currentIdx >= 0 && currentIdx < list.size) currentIdx + 1 else list.size
        list.add(insertAt, song)
        _queue.value = list
        mediaController?.addMediaItem(insertAt, buildMediaItem(song))
        scope.launch { repository.saveQueue(list.map { it.id }) }
    }

    fun removeFromQueue(index: Int) {
        val list = _queue.value.toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            _queue.value = list
            mediaController?.removeMediaItem(index)
            scope.launch { repository.saveQueue(list.map { it.id }) }
        }
    }

    fun reorderQueue(fromIndex: Int, toIndex: Int) {
        val list = _queue.value.toMutableList()
        if (fromIndex in list.indices && toIndex in list.indices) {
            val item = list.removeAt(fromIndex)
            list.add(toIndex, item)
            _queue.value = list
            mediaController?.moveMediaItem(fromIndex, toIndex)
            scope.launch { repository.saveQueue(list.map { it.id }) }
        }
    }

    fun clearQueue() {
        mediaController?.clearMediaItems()
        _queue.value = emptyList()
        _currentSong.value = null
        _currentQueueIndex.value = -1
        scope.launch { repository.saveQueue(emptyList()) }
    }

    fun startSleepTimer(minutes: Int) {
        cancelSleepTimer()
        val totalSeconds = minutes * 60L
        _sleepTimerRemainingSeconds.value = totalSeconds

        sleepTimerJob = scope.launch {
            var remaining = totalSeconds
            while (remaining > 0 && isActive) {
                delay(1000)
                remaining--
                _sleepTimerRemainingSeconds.value = remaining
            }
            if (remaining <= 0) {
                mediaController?.pause()
                _sleepTimerRemainingSeconds.value = null
            }
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null
        _sleepTimerRemainingSeconds.value = null
    }

    fun updateCurrentSongMetadata(updatedSong: SongEntity) {
        if (_currentSong.value?.id == updatedSong.id) {
            _currentSong.value = updatedSong
        }
        val list = _queue.value.map { if (it.id == updatedSong.id) updatedSong else it }
        _queue.value = list
    }

    private fun buildMediaItem(song: SongEntity): MediaItem {
        val metadataBuilder = MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)

        if (!song.customArtworkPath.isNullOrBlank()) {
            val artFile = File(song.customArtworkPath)
            if (artFile.exists()) {
                metadataBuilder.setArtworkUri(Uri.fromFile(artFile))
            }
        }

        return MediaItem.Builder()
            .setMediaId(song.id.toString())
            .setUri(Uri.fromFile(File(song.filePath)))
            .setMediaMetadata(metadataBuilder.build())
            .build()
    }

    fun release() {
        stopProgressTicker()
        sleepTimerJob?.cancel()
        controllerFuture?.let {
            MediaController.releaseFuture(it)
        }
    }
}
