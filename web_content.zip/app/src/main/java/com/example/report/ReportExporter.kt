package com.example.report

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.CycleSummary
import com.example.data.model.DeliveryEntry
import com.example.data.model.UserProfile
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReportExporter {

    fun generateCsvExcel(
        context: Context,
        entries: List<DeliveryEntry>,
        cycleSummaries: List<CycleSummary>,
        userProfile: UserProfile,
        periodTitle: String
    ): File? {
        return try {
            val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val file = File(reportsDir, "Delivery_Report_${timeStamp}.csv")

            val writer = file.bufferedWriter(Charsets.UTF_8)
            // UTF-8 BOM so Microsoft Excel reads UTF-8 characters cleanly
            writer.write("\uFEFF")

            // Metadata Headers
            writer.write("DELIVERY AGENT EARNINGS & INVOICE REPORT\n")
            writer.write("Agent Name,\"${userProfile.agentName}\"\n")
            writer.write("Vehicle Number,\"${userProfile.vehicleNumber}\"\n")
            writer.write("Period,\"$periodTitle\"\n")
            writer.write("Generated On,\"${SimpleDateFormat("dd-MMM-yyyy HH:mm", Locale.getDefault()).format(Date())}\"\n\n")

            // Cycle Summaries Table
            writer.write("INVOICE CYCLES SUMMARY\n")
            writer.write("Cycle,Date Range,Total Deliveries,Total Kamai (INR),Status\n")
            for (cs in cycleSummaries) {
                writer.write("\"${cs.label}\",\"${cs.dateRangeText}\",${cs.totalDeliveries},\"₹${cs.totalEarnings.toInt()}\",\"${cs.status}\"\n")
            }
            writer.write("\n")

            // Daily Entries Table
            writer.write("DAILY DELIVERIES BREAKDOWN\n")
            writer.write("Date,Day of Month,Invoice Cycle,Deliveries Count,Rate Per Delivery (INR),Total Daily Kamai (INR),GPS Location,Notes\n")

            var grandTotalDeliveries = 0
            var grandTotalEarnings = 0.0

            for (entry in entries) {
                grandTotalDeliveries += entry.deliveriesCount
                grandTotalEarnings += entry.totalEarnings
                val gpsInfo = if (entry.latitude != null && entry.longitude != null) {
                    "${"%.4f".format(entry.latitude)},${"%.4f".format(entry.longitude)}"
                } else entry.locationTag ?: "-"

                writer.write("\"${entry.dateString}\",${entry.dayOfMonth},\"Cycle ${entry.cycleNumber}\",${entry.deliveriesCount},${entry.ratePerDelivery},${entry.totalEarnings},\"$gpsInfo\",\"${entry.notes.replace("\"", "\"\"")}\"\n")
            }

            // Summary Row
            writer.write("\n")
            writer.write("TOTALS,,,\"$grandTotalDeliveries Deliveries\",,\"₹${grandTotalEarnings.toInt()}\",,\n")
            writer.flush()
            writer.close()

            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun generatePdf(
        context: Context,
        entries: List<DeliveryEntry>,
        cycleSummaries: List<CycleSummary>,
        userProfile: UserProfile,
        periodTitle: String
    ): File? {
        return try {
            val doc = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 standard (595x842 pt)
            val page = doc.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }

            // Header Background Banner
            paint.color = Color.rgb(0, 86, 210) // Electric Blue
            canvas.drawRect(0f, 0f, 595f, 90f, paint)

            // App Title
            paint.color = Color.WHITE
            paint.textSize = 18f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("DELIVERY AGENT PAYOUT & INVOICE REPORT", 24f, 40f, paint)

            paint.textSize = 11f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText("Period: $periodTitle  |  Generated: ${SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(Date())}", 24f, 65f, paint)

            // Agent Profile Section
            paint.color = Color.rgb(33, 33, 33)
            paint.textSize = 12f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            var y = 115f
            canvas.drawText("Agent Name: ${userProfile.agentName}", 24f, y, paint)
            if (userProfile.vehicleNumber.isNotBlank()) {
                canvas.drawText("Vehicle No: ${userProfile.vehicleNumber}", 350f, y, paint)
            }

            // KPI Summary Cards
            y += 20f
            var grandDeliveries = 0
            var grandEarnings = 0.0
            entries.forEach {
                grandDeliveries += it.deliveriesCount
                grandEarnings += it.totalEarnings
            }

            // Box 1: Total Deliveries
            paint.color = Color.rgb(238, 242, 255)
            canvas.drawRoundRect(24f, y, 190f, y + 55f, 8f, 8f, paint)
            paint.color = Color.rgb(0, 86, 210)
            paint.textSize = 10f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("TOTAL DELIVERIES", 36f, y + 20f, paint)
            paint.textSize = 18f
            canvas.drawText("$grandDeliveries", 36f, y + 45f, paint)

            // Box 2: Total Kamai
            paint.color = Color.rgb(235, 251, 243)
            canvas.drawRoundRect(205f, y, 385f, y + 55f, 8f, 8f, paint)
            paint.color = Color.rgb(0, 135, 90)
            paint.textSize = 10f
            canvas.drawText("TOTAL EARNINGS (KAMAI)", 217f, y + 20f, paint)
            paint.textSize = 18f
            canvas.drawText("Rs. ${grandEarnings.toInt()}", 217f, y + 45f, paint)

            // Box 3: Active Days
            paint.color = Color.rgb(255, 247, 237)
            canvas.drawRoundRect(400f, y, 571f, y + 55f, 8f, 8f, paint)
            paint.color = Color.rgb(230, 81, 0)
            paint.textSize = 10f
            canvas.drawText("DAYS RECORDED", 412f, y + 20f, paint)
            paint.textSize = 18f
            canvas.drawText("${entries.size} Days", 412f, y + 45f, paint)

            // Invoice Cycles Breakdown Table
            y += 75f
            paint.color = Color.rgb(30, 41, 59)
            paint.textSize = 12f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("MONTHLY INVOICE CYCLES (3-TIME SPLIT)", 24f, y, paint)

            y += 15f
            // Cycles Header
            paint.color = Color.rgb(241, 245, 249)
            canvas.drawRect(24f, y, 571f, y + 22f, paint)
            paint.color = Color.rgb(71, 85, 105)
            paint.textSize = 9.5f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("CYCLE", 32f, y + 15f, paint)
            canvas.drawText("DATE WINDOW", 140f, y + 15f, paint)
            canvas.drawText("DELIVERIES", 270f, y + 15f, paint)
            canvas.drawText("TOTAL KAMAI", 380f, y + 15f, paint)
            canvas.drawText("STATUS", 490f, y + 15f, paint)

            y += 24f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            for (cs in cycleSummaries) {
                paint.color = Color.rgb(30, 41, 59)
                paint.textSize = 9.5f
                canvas.drawText("Cycle ${cs.cycleNumber}", 32f, y + 14f, paint)
                canvas.drawText(cs.dateRangeText, 140f, y + 14f, paint)
                canvas.drawText("${cs.totalDeliveries} pkts", 270f, y + 14f, paint)
                canvas.drawText("Rs. ${cs.totalEarnings.toInt()}", 380f, y + 14f, paint)

                paint.color = when (cs.status) {
                    "PAID" -> Color.rgb(0, 135, 90)
                    "INVOICED" -> Color.rgb(0, 86, 210)
                    else -> Color.rgb(230, 81, 0)
                }
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText(cs.status, 490f, y + 14f, paint)
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)

                y += 20f
                paint.color = Color.rgb(226, 232, 240)
                canvas.drawLine(24f, y, 571f, y, paint)
            }

            // Daily Entries Table Header
            y += 18f
            paint.color = Color.rgb(30, 41, 59)
            paint.textSize = 12f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("DAILY DELIVERIES BREAKDOWN", 24f, y, paint)

            y += 14f
            paint.color = Color.rgb(241, 245, 249)
            canvas.drawRect(24f, y, 571f, y + 20f, paint)
            paint.color = Color.rgb(71, 85, 105)
            paint.textSize = 9f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("DATE", 32f, y + 14f, paint)
            canvas.drawText("CYCLE", 130f, y + 14f, paint)
            canvas.drawText("DELIVERIES", 210f, y + 14f, paint)
            canvas.drawText("RATE", 310f, y + 14f, paint)
            canvas.drawText("TOTAL EARNED", 400f, y + 14f, paint)
            canvas.drawText("NOTES / GPS", 495f, y + 14f, paint)

            y += 22f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            val maxRows = 22 // Fits on 1 page comfortably
            val displayEntries = entries.take(maxRows)
            for (entry in displayEntries) {
                paint.color = Color.rgb(51, 65, 85)
                paint.textSize = 9f
                canvas.drawText(entry.dateString, 32f, y + 12f, paint)
                canvas.drawText("Cycle ${entry.cycleNumber}", 130f, y + 12f, paint)
                canvas.drawText("${entry.deliveriesCount}", 210f, y + 12f, paint)
                canvas.drawText("Rs. ${entry.ratePerDelivery.toInt()}", 310f, y + 12f, paint)

                paint.color = Color.rgb(0, 135, 90)
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("Rs. ${entry.totalEarnings.toInt()}", 400f, y + 12f, paint)

                paint.color = Color.rgb(100, 116, 139)
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                val noteSnippet = if (entry.notes.isNotBlank()) {
                    if (entry.notes.length > 12) entry.notes.take(12) + ".." else entry.notes
                } else if (entry.latitude != null) "GPS Tagged" else "-"
                canvas.drawText(noteSnippet, 495f, y + 12f, paint)

                y += 18f
                paint.color = Color.rgb(241, 245, 249)
                canvas.drawLine(24f, y, 571f, y, paint)
            }

            if (entries.size > maxRows) {
                paint.color = Color.rgb(100, 116, 139)
                paint.textSize = 8.5f
                canvas.drawText("+ ${entries.size - maxRows} more entries included in Excel CSV export", 24f, y + 14f, paint)
                y += 16f
            }

            // Footer / Net Payable
            y += 15f
            paint.color = Color.rgb(238, 242, 255)
            canvas.drawRoundRect(24f, y, 571f, y + 36f, 6f, 6f, paint)
            paint.color = Color.rgb(0, 86, 210)
            paint.textSize = 12f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("GRAND TOTAL PAYOUT:  Rs. ${grandEarnings.toInt()}  ($grandDeliveries Successful Deliveries)", 36f, y + 23f, paint)

            doc.finishPage(page)

            val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val file = File(reportsDir, "Delivery_Invoice_${timeStamp}.pdf")
            val fos = FileOutputStream(file)
            doc.writeTo(fos)
            fos.close()
            doc.close()

            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareFile(context: Context, file: File, mimeType: String, title: String) {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "$title\nGenerated from Delivery Agent App")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share $title"))
        } catch (e: Exception) {
            Toast.makeText(context, "Error sharing file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun saveToDownloads(context: Context, file: File, mimeType: String, displayName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/DeliveryReports")
                }
                val uri: Uri? = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        file.inputStream().use { input -> input.copyTo(out) }
                    }
                    Toast.makeText(context, "Saved to Downloads: $displayName", Toast.LENGTH_LONG).show()
                    true
                } else false
            } else {
                val destDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "DeliveryReports")
                destDir.mkdirs()
                val destFile = File(destDir, displayName)
                file.copyTo(destFile, overwrite = true)
                Toast.makeText(context, "Saved to Downloads/DeliveryReports", Toast.LENGTH_LONG).show()
                true
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Could not save to downloads: ${e.message}", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
