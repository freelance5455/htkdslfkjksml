package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.remote.MultiModelAiService
import com.example.data.repository.ApiHubPreferences
import com.example.data.repository.StudioProjectRepository
import com.example.ui.OmniPromptViewModel
import com.example.ui.ProjectsUiState
import com.example.ui.screens.ApiHubSettingsScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HtmlZipToAppConverterScreen
import com.example.ui.screens.LiveSandboxExportScreen
import com.example.ui.screens.StudioDashboardScreen
import com.example.ui.screens.WebsiteMakerScreen
import com.example.ui.screens.onGoogleSignInClicked
import com.example.ui.screens.signOutOmniStudio
import com.example.ui.theme.MyApplicationTheme
import com.example.util.configureAppCheck
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

enum class OmniDestination(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    STUDIO(
        labelRes = R.string.nav_studio,
        selectedIcon = Icons.Filled.AutoAwesome,
        unselectedIcon = Icons.Outlined.AutoAwesome,
        testTag = "tab_studio"
    ),
    WEB_MAKER(
        labelRes = R.string.nav_web_maker,
        selectedIcon = Icons.Filled.Language,
        unselectedIcon = Icons.Outlined.Language,
        testTag = "tab_web_maker"
    ),
    CONVERTER(
        labelRes = R.string.nav_converter,
        selectedIcon = Icons.Filled.PhoneAndroid,
        unselectedIcon = Icons.Outlined.PhoneAndroid,
        testTag = "tab_converter"
    ),
    SANDBOX(
        labelRes = R.string.nav_sandbox,
        selectedIcon = Icons.Filled.Widgets,
        unselectedIcon = Icons.Outlined.Widgets,
        testTag = "tab_sandbox"
    ),
    API_HUB(
        labelRes = R.string.nav_api_hub,
        selectedIcon = Icons.Filled.Hub,
        unselectedIcon = Icons.Outlined.Hub,
        testTag = "tab_api_hub"
    )
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        // STEP 2: Enable edge-to-edge and render Compose UI
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                OmniPromptRootApp()
            }
        }
    }
}

@Composable
fun OmniPromptRootApp(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser
    var isGuestPreviewMode by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(user) {
        if (user != null) {
            isGuestPreviewMode = false
        }
    }

    if (user == null && !isGuestPreviewMode) {
        AuthScreen(
            onAuthSuccess = { isGuestPreviewMode = false },
            onContinueAsGuest = { isGuestPreviewMode = true }
        )
    } else {
        AuthenticatedStudioShell(
            currentUserId = user?.uid.orEmpty(),
            userEmail = user?.email,
            onExitGuestMode = { isGuestPreviewMode = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthenticatedStudioShell(
    currentUserId: String,
    userEmail: String?,
    onExitGuestMode: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val isGuest = currentUserId.isBlank()

    val viewModel: OmniPromptViewModel = viewModel(
        key = currentUserId.ifBlank { "guest_preview_session" },
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                OmniPromptViewModel(
                    repository = StudioProjectRepository(db),
                    apiHubPreferences = ApiHubPreferences(app),
                    aiService = MultiModelAiService(),
                    currentUserId = currentUserId,
                    currentUserEmail = userEmail
                )
            }
        }
    )

    val apiConfig by viewModel.apiConfig.collectAsStateWithLifecycle()
    val userSubscription by viewModel.userSubscription.collectAsStateWithLifecycle()
    val isProcessingBilling by viewModel.isProcessingBilling.collectAsStateWithLifecycle()
    val activeCheckoutSession by viewModel.activeCheckoutSession.collectAsStateWithLifecycle()
    val activeUpiSession by viewModel.activeUpiSession.collectAsStateWithLifecycle()
    val activeCardSession by viewModel.activeCardSession.collectAsStateWithLifecycle()
    val promptInput by viewModel.promptInput.collectAsStateWithLifecycle()
    val websitePromptInput by viewModel.websitePromptInput.collectAsStateWithLifecycle()
    val websiteLayoutPreset by viewModel.websiteLayoutPreset.collectAsStateWithLifecycle()
    val websiteThemePalette by viewModel.websiteThemePalette.collectAsStateWithLifecycle()
    val isEnhancingPrompt by viewModel.isEnhancingPrompt.collectAsStateWithLifecycle()
    val isEnhancingWebsitePrompt by viewModel.isEnhancingWebsitePrompt.collectAsStateWithLifecycle()
    val isRefiningProject by viewModel.isRefiningProject.collectAsStateWithLifecycle()
    val isRefiningWebsite by viewModel.isRefiningWebsite.collectAsStateWithLifecycle()
    val isTestingEndpoint by viewModel.isTestingEndpoint.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val workspaceFilter by viewModel.workspaceFilter.collectAsStateWithLifecycle()
    val workspaceSort by viewModel.workspaceSort.collectAsStateWithLifecycle()
    val synthesisState by viewModel.synthesisState.collectAsStateWithLifecycle()
    val websiteSynthesisState by viewModel.websiteSynthesisState.collectAsStateWithLifecycle()
    val projectsState by viewModel.projectsState.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeProject.collectAsStateWithLifecycle()
    val activeWebsiteProject by viewModel.activeWebsiteProject.collectAsStateWithLifecycle()
    val scenarioSnapshots by viewModel.scenarioSnapshots.collectAsStateWithLifecycle()
    val telemetryHistory by viewModel.telemetryHistory.collectAsStateWithLifecycle()
    val exportBanner by viewModel.exportBanner.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val requiresGoogleSignInPrompt by viewModel.requiresGoogleSignInPrompt.collectAsStateWithLifecycle()

    var currentTab by rememberSaveable { mutableStateOf(OmniDestination.STUDIO) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissStatusMessage()
        }
    }

    if (requiresGoogleSignInPrompt != null) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissGoogleSignInPrompt() },
            icon = {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Google Sign-In Required",
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            title = {
                Text(
                    text = "Sign in with Google Required",
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Text(
                    text = "${requiresGoogleSignInPrompt.orEmpty()}\n\nGuest mode allows browsing the OmniPrompt Studio interface. Sign in with your Google account to generate Android apps, build websites, or store API Hub credentials.",
                    style = MaterialTheme.typography.bodySmall
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.dismissGoogleSignInPrompt()
                        onGoogleSignInClicked(
                            context = context,
                            credentialManager = credentialManager,
                            onAuthSuccess = {},
                            onAuthError = { err ->
                                onExitGuestMode()
                            },
                            scope = scope,
                            onAuthCancelled = {}
                        )
                    },
                    modifier = Modifier.testTag("dialog_google_sign_in_button")
                ) {
                    Text(stringResource(R.string.sign_in_google))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        viewModel.dismissGoogleSignInPrompt()
                        onExitGuestMode()
                    }
                ) {
                    Text("Back to Login Screen")
                }
            }
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.app_name),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${apiConfig.selectedProvider.displayName} • ${userSubscription.tier.displayName} (${userSubscription.remainingGenerations} left)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                onClick = { currentTab = OmniDestination.API_HUB },
                                modifier = Modifier.testTag("top_bar_model_chip")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Hub,
                                        contentDescription = "API Hub",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = apiConfig.selectedModel.displayName,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )

                if (isGuest) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("guest_preview_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Guest Preview Mode",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Sign in with Google to generate apps, build websites, or save keys.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onAuthSuccess = {},
                                        onAuthError = { onExitGuestMode() },
                                        scope = scope
                                    )
                                },
                                modifier = Modifier.testTag("guest_banner_sign_in_button"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Sign In", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                OmniDestination.entries.forEach { dest ->
                    val selected = currentTab == dest
                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentTab = dest },
                        icon = {
                            Icon(
                                imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                contentDescription = stringResource(dest.labelRes)
                            )
                        },
                        label = {
                            Text(
                                text = stringResource(dest.labelRes),
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        modifier = Modifier.testTag(dest.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                OmniDestination.STUDIO -> {
                    StudioDashboardScreen(
                        apiConfig = apiConfig,
                        promptInput = promptInput,
                        isEnhancingPrompt = isEnhancingPrompt,
                        searchQuery = searchQuery,
                        workspaceFilter = workspaceFilter,
                        workspaceSort = workspaceSort,
                        synthesisState = synthesisState,
                        projectsState = projectsState,
                        onPromptChange = viewModel::updatePromptInput,
                        onEnhancePromptClick = viewModel::enhancePromptWithAi,
                        onSearchQueryChange = viewModel::updateSearchQuery,
                        onSelectWorkspaceFilter = viewModel::selectWorkspaceFilter,
                        onSelectWorkspaceSort = viewModel::selectWorkspaceSort,
                        onSelectProvider = viewModel::selectProvider,
                        onSelectModel = viewModel::selectModel,
                        onSelectArchitecturePreset = viewModel::selectArchitecturePreset,
                        onSynthesizeClick = {
                            viewModel.synthesizeApp(
                                onOpenSandbox = { currentTab = OmniDestination.SANDBOX }
                            )
                        },
                        onOpenProjectInSandbox = { project ->
                            viewModel.selectActiveProject(project)
                            currentTab = if (project.isWebsiteProject()) {
                                OmniDestination.WEB_MAKER
                            } else {
                                OmniDestination.SANDBOX
                            }
                        },
                        onTogglePin = viewModel::togglePinProject,
                        onDeleteProject = viewModel::deleteProject,
                        onNavigateToApiHub = { currentTab = OmniDestination.API_HUB }
                    )
                }

                OmniDestination.WEB_MAKER -> {
                    WebsiteMakerScreen(
                        apiConfig = apiConfig,
                        websitePromptInput = websitePromptInput,
                        websiteLayoutPreset = websiteLayoutPreset,
                        websiteThemePalette = websiteThemePalette,
                        isEnhancingWebsitePrompt = isEnhancingWebsitePrompt,
                        isRefiningWebsite = isRefiningWebsite,
                        websiteSynthesisState = websiteSynthesisState,
                        projectsState = projectsState,
                        activeWebsiteProject = activeWebsiteProject,
                        exportBanner = exportBanner,
                        onWebsitePromptChange = viewModel::updateWebsitePromptInput,
                        onSelectLayoutPreset = viewModel::selectWebsiteLayoutPreset,
                        onSelectThemePalette = viewModel::selectWebsiteThemePalette,
                        onEnhanceWebsitePrompt = viewModel::enhanceWebsitePromptWithAi,
                        onSynthesizeWebsite = { viewModel.synthesizeWebsite() },
                        onSelectWebsiteProject = viewModel::selectActiveWebsiteProject,
                        onRefineWebsite = viewModel::refineActiveWebsiteWithAi,
                        onAddCustomWebsiteSection = { section ->
                            activeWebsiteProject?.let { proj ->
                                viewModel.addCustomWebsiteSection(proj, section)
                            } ?: viewModel.requestGoogleSignInForFeature("Website Section Builder")
                        },
                        onSaveEditedWebsiteSource = { html, css, js, specJson ->
                            activeWebsiteProject?.let { proj ->
                                viewModel.saveEditedProjectSource(proj, html, css, js, specJson)
                            } ?: viewModel.requestGoogleSignInForFeature("Web Code Editor")
                        },
                        onExportToUri = { project, uri ->
                            viewModel.exportProjectToUri(context, project, uri)
                        },
                        onExportToWorkspace = { project ->
                            viewModel.exportProjectToWorkspace(context, project)
                        },
                        onDismissExportBanner = viewModel::dismissExportBanner,
                        onNavigateBackToStudio = { currentTab = OmniDestination.STUDIO }
                    )
                }

                OmniDestination.CONVERTER -> {
                    val savedProjectsList = (projectsState as? ProjectsUiState.Success)?.projects.orEmpty()
                    HtmlZipToAppConverterScreen(
                        savedProjects = savedProjectsList,
                        exportBanner = exportBanner,
                        onDismissExportBanner = viewModel::dismissExportBanner,
                        onSaveConvertedAppToWorkspace = { config, bundle ->
                            viewModel.saveConvertedWebAppToWorkspace(
                                config = config,
                                bundle = bundle,
                                onSavedToSandbox = { currentTab = OmniDestination.SANDBOX }
                            )
                        },
                        onExportConvertedZipToUri = { config, bundle, uri ->
                            viewModel.exportConvertedAppZipToUri(context, config, bundle, uri)
                        },
                        onExportConvertedZipToWorkspace = { config, bundle ->
                            viewModel.exportConvertedAppZipToWorkspace(context, config, bundle)
                        },
                        onShowMessage = viewModel::postStatusMessage,
                        onNavigateBackToStudio = { currentTab = OmniDestination.STUDIO }
                    )
                }

                OmniDestination.SANDBOX -> {
                    val activeId = activeProject?.id.orEmpty()
                    LiveSandboxExportScreen(
                        activeProject = activeProject,
                        isRefiningProject = isRefiningProject,
                        includeFullGradleScaffold = apiConfig.includeFullGradleScaffold,
                        scenarioSnapshots = scenarioSnapshots[activeId].orEmpty(),
                        exportBanner = exportBanner,
                        onDismissExportBanner = viewModel::dismissExportBanner,
                        onRefineProject = viewModel::refineActiveProjectWithAi,
                        onAddCustomWidget = { widget, mode, label, unit ->
                            activeProject?.let { proj ->
                                viewModel.addCustomSandboxWidget(proj, widget, mode, label, unit)
                            } ?: viewModel.requestGoogleSignInForFeature("Custom Sandbox Widget Builder")
                        },
                        onSaveEditedSource = { kt, manifest, gradle, specJson ->
                            activeProject?.let { proj ->
                                viewModel.saveEditedProjectSource(proj, kt, manifest, gradle, specJson)
                            } ?: viewModel.requestGoogleSignInForFeature("Inline Source Editor")
                        },
                        onCaptureSnapshot = { label, result, unit, nums, toggles, texts ->
                            viewModel.saveScenarioSnapshot(activeId, label, result, unit, nums, toggles, texts)
                        },
                        onDeleteSnapshot = { snapId ->
                            viewModel.deleteScenarioSnapshot(activeId, snapId)
                        },
                        onExportToUri = { project, uri ->
                            viewModel.exportProjectToUri(context, project, uri)
                        },
                        onExportToWorkspace = { project ->
                            viewModel.exportProjectToWorkspace(context, project)
                        },
                        onNavigateBackToStudio = { currentTab = OmniDestination.STUDIO }
                    )
                }

                OmniDestination.API_HUB -> {
                    ApiHubSettingsScreen(
                        apiConfig = apiConfig,
                        userSubscription = userSubscription,
                        isProcessingBilling = isProcessingBilling,
                        activeCheckoutSession = activeCheckoutSession,
                        activeUpiSession = activeUpiSession,
                        activeCardSession = activeCardSession,
                        isTestingEndpoint = isTestingEndpoint,
                        telemetryHistory = telemetryHistory,
                        userEmail = if (isGuest) "Guest Preview Mode (Not Signed In)" else userEmail,
                        onSelectProvider = viewModel::selectProvider,
                        onSelectModel = viewModel::selectModel,
                        onSaveStripeKey = viewModel::saveStripeSecretKey,
                        onStartUpiCheckout = viewModel::startUpiCheckout,
                        onSelectUpiHandle = viewModel::selectUpiHandle,
                        onUpiIntentResponse = viewModel::onUpiIntentResponse,
                        onVerifyUpiUtr = viewModel::verifyUpiUtrAndActivate,
                        onDismissUpiModal = viewModel::dismissUpiCheckoutModal,
                        onStartCardCheckout = viewModel::startCardCheckout,
                        onSelectCardSettlementHandle = viewModel::selectCardSettlementHandle,
                        onAuthorizeCardDetails = viewModel::authorizeCardDetails,
                        onCardSettlementIntentResponse = viewModel::onCardSettlementIntentResponse,
                        onVerifyCardOtpOrRrn = viewModel::verifyCardOtpOrRrnAndActivate,
                        onDismissCardModal = viewModel::dismissCardCheckoutModal,
                        onStartStripeCheckout = viewModel::startStripeCheckoutSession,
                        onVerifyCheckoutSession = viewModel::verifyStripeCheckoutSession,
                        onCancelSubscription = viewModel::cancelStripeSubscription,
                        onDismissCheckoutModal = viewModel::dismissCheckoutModal,
                        onSaveCredentials = viewModel::saveApiHubCredentials,
                        onTestEndpointConnection = viewModel::testActiveEndpointLatency,
                        onClearCredentials = viewModel::clearCredentials,
                        onSignOut = {
                            if (isGuest) {
                                onExitGuestMode()
                            } else {
                                signOutOmniStudio(
                                    credentialManager = credentialManager,
                                    onSignOutComplete = {},
                                    scope = scope
                                )
                            }
                        },
                        onNavigateBackToStudio = { currentTab = OmniDestination.STUDIO }
                    )
                }
            }
        }
    }
}
