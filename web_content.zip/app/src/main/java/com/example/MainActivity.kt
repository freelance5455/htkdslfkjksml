package com.example

import android.os.Bundle
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import android.view.WindowManager
import androidx.compose.ui.window.Dialog

// ==========================================
// MAIN ACTIVITY
// ==========================================
class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // Screenshot & Screen Recording Protection:
    // Prevents screenshots, screen recording, and recent-app overview captures
    // across both Dark and Normal sections.
    window.setFlags(
      WindowManager.LayoutParams.FLAG_SECURE,
      WindowManager.LayoutParams.FLAG_SECURE
    )
    enableEdgeToEdge()
    setContent {
      val mtxDarkScheme = darkColorScheme(
        primary = Color(0xFF2563EB),
        secondary = Color(0xFF7C3AED),
        tertiary = Color(0xFFA855F7),
        background = Color(0xFF0B0E14),
        surface = Color(0xFF151A24),
        onPrimary = Color.White,
        onSecondary = Color.White,
        onBackground = Color(0xFFF8FAFC),
        onSurface = Color(0xFFF8FAFC)
      )

      MaterialTheme(colorScheme = mtxDarkScheme) {
        MtxMainApp()
      }
    }
  }
}

@Composable
fun MtxMainApp() {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  // Navigation: "browse", "photos", "player", "dark_site", "admin"
  var currentScreen by remember { mutableStateOf("browse") }

  // Admin Authentication State
  var isAdminAuthenticated by remember { mutableStateOf(false) }

  // Fullscreen Video State (YouTube-like immersive experience)
  var isPlayerFullscreen by remember { mutableStateOf(false) }

  // Lightbox Photo State
  var activeLightboxPhoto by remember { mutableStateOf<PhotoItem?>(null) }

  // Persistent Uploaded Videos & Photos
  val uploadedVideos = remember {
    mutableStateListOf<VideoItem>().apply {
      addAll(VideoStorage.loadVideos(context))
    }
  }

  val uploadedPhotos = remember {
    mutableStateListOf<PhotoItem>().apply {
      addAll(PhotoStorage.loadPhotos(context))
    }
  }

  // Dark User Auth State (Permanent Once Approved!)
  var darkUserAuth by remember { mutableStateOf(DarkUserStorage.load(context)) }

  // First-time Member Registration Prompt (Requirement 2)
  var showRegistrationDialog by remember {
    mutableStateOf(darkUserAuth.userName.isBlank())
  }
  var memberNameInput by remember { mutableStateOf("") }

  // Active Video for Watch Player (strictly non-dark initially)
  var activeVideo by remember {
    mutableStateOf<VideoItem?>(uploadedVideos.firstOrNull { it.isPublished && !it.isDark })
  }

  // Cloud Sync Status Indicator
  var isSyncingCloud by remember { mutableStateOf(false) }

  fun performCloudSync() {
    coroutineScope.launch {
      isSyncingCloud = true

      val cloudVideos = withContext(Dispatchers.IO) { MtxCloudSync.fetchVideos(context) }
      if (cloudVideos != null) {
        uploadedVideos.clear()
        uploadedVideos.addAll(cloudVideos)
      }

      val cloudPhotos = withContext(Dispatchers.IO) { MtxCloudSync.fetchPhotos(context) }
      if (cloudPhotos != null) {
        uploadedPhotos.clear()
        uploadedPhotos.addAll(cloudPhotos)
      }

      if (activeVideo == null || !uploadedVideos.any { it.id == activeVideo?.id }) {
        activeVideo = uploadedVideos.firstOrNull { it.isPublished && !it.isDark }
      }

      // Register member on cloud server
      withContext(Dispatchers.IO) {
        val displayName = if (darkUserAuth.userName.isNotBlank()) darkUserAuth.userName else "Member " + darkUserAuth.userId.takeLast(4)
        MtxCloudSync.registerNormalUser(darkUserAuth.userId, displayName)
      }

      // Check Dark User Approval Status from Server
      val (isApprovedOnServer, statusOnServer) = withContext(Dispatchers.IO) {
        MtxCloudSync.checkDarkUserStatus(darkUserAuth.userId)
      }
      if (isApprovedOnServer && !darkUserAuth.isApproved) {
        val updated = darkUserAuth.copy(isApproved = true, status = "approved")
        DarkUserStorage.save(context, updated)
        darkUserAuth = updated
      } else if (!isApprovedOnServer && darkUserAuth.isApproved) {
        // Admin removed dark user access!
        val updated = darkUserAuth.copy(isApproved = false, status = "revoked")
        DarkUserStorage.save(context, updated)
        darkUserAuth = updated
      } else if (statusOnServer == "pending" && darkUserAuth.status != "pending") {
        val updated = darkUserAuth.copy(status = "pending")
        DarkUserStorage.save(context, updated)
        darkUserAuth = updated
      }

      isSyncingCloud = false
    }
  }

  // Initial Startup Cloud Sync
  LaunchedEffect(Unit) {
    performCloudSync()
  }

  // Search & Filter State
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("All") }

  BackHandler(enabled = activeLightboxPhoto != null) {
    activeLightboxPhoto = null
  }

  BackHandler(enabled = activeLightboxPhoto == null && isPlayerFullscreen) {
    isPlayerFullscreen = false
  }

  BackHandler(enabled = activeLightboxPhoto == null && !isPlayerFullscreen && currentScreen != "browse") {
    currentScreen = "browse"
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0B0E14)),
    topBar = {
      if (!isPlayerFullscreen && activeLightboxPhoto == null && currentScreen != "admin") {
        MtxTopHeader(
          isAdmin = isAdminAuthenticated,
          isSyncing = isSyncingCloud,
          onSyncClick = { performCloudSync() },
          onCornerAdminClick = { currentScreen = "admin" },
          onLogoutAdmin = {
            isAdminAuthenticated = false
            currentScreen = "browse"
          }
        )
      }
    },
    bottomBar = {
      if (!isPlayerFullscreen && activeLightboxPhoto == null && currentScreen != "admin") {
        NavigationBar(
          containerColor = Color(0xFF0E131E),
          contentColor = Color.White,
          modifier = Modifier.testTag("bottom_nav_bar")
        ) {
          // Tab 1: Videos
          NavigationBarItem(
            selected = currentScreen == "browse",
            onClick = {
              currentScreen = "browse"
              isPlayerFullscreen = false
            },
            icon = { Icon(Icons.Default.Home, contentDescription = "Videos") },
            label = { Text("Videos", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color.White,
              selectedTextColor = Color(0xFF60A5FA),
              indicatorColor = Color(0xFF2563EB),
              unselectedIconColor = Color(0xFF94A3B8),
              unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_browse")
          )

          // Tab 2: Photos
          NavigationBarItem(
            selected = currentScreen == "photos",
            onClick = {
              currentScreen = "photos"
              isPlayerFullscreen = false
            },
            icon = { Icon(Icons.Default.PhotoLibrary, contentDescription = "Photos") },
            label = { Text("Photos", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color.White,
              selectedTextColor = Color(0xFFC084FC),
              indicatorColor = Color(0xFF7C3AED),
              unselectedIconColor = Color(0xFF94A3B8),
              unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_photos")
          )

          // Tab 3: Watch Player
          NavigationBarItem(
            selected = currentScreen == "player",
            onClick = { currentScreen = "player" },
            icon = { Icon(Icons.Default.SmartDisplay, contentDescription = "Watch Player") },
            label = { Text("Watch", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color.White,
              selectedTextColor = Color(0xFF60A5FA),
              indicatorColor = Color(0xFF2563EB),
              unselectedIconColor = Color(0xFF94A3B8),
              unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_player")
          )

          // Tab 4: Dark Site (NEW!)
          NavigationBarItem(
            selected = currentScreen == "dark_site",
            onClick = {
              currentScreen = "dark_site"
              isPlayerFullscreen = false
            },
            icon = {
              Icon(
                Icons.Default.Security,
                contentDescription = "Dark Site",
                tint = if (currentScreen == "dark_site") Color(0xFFEF4444) else if (darkUserAuth.isApproved) Color(0xFFFDE047) else Color(0xFF94A3B8)
              )
            },
            label = {
              Text(
                if (darkUserAuth.isApproved) "Dark VIP" else "Dark Site",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = if (currentScreen == "dark_site") Color(0xFFEF4444) else if (darkUserAuth.isApproved) Color(0xFFFDE047) else Color(0xFF94A3B8)
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = Color.White,
              selectedTextColor = Color(0xFFEF4444),
              indicatorColor = Color(0xFFDC2626),
              unselectedIconColor = Color(0xFF94A3B8),
              unselectedTextColor = Color(0xFF94A3B8)
            ),
            modifier = Modifier.testTag("nav_tab_dark_site")
          )
        }
      }
    }
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFF0B0E14))
        .padding(if (isPlayerFullscreen || activeLightboxPhoto != null) PaddingValues(0.dp) else paddingValues)
    ) {
      when (currentScreen) {
        "browse" -> {
          MtxBrowseScreen(
            videos = uploadedVideos.filter { it.isPublished && !it.isDark },
            searchQuery = searchQuery,
            onSearchChange = { searchQuery = it },
            selectedCategory = selectedCategory,
            onCategoryChange = { selectedCategory = it },
            onSelectVideo = {
              activeVideo = it
              currentScreen = "player"
            }
          )
        }

        "photos" -> {
          MtxPhotosScreen(
            photos = uploadedPhotos.filter { it.isPublished && !it.isDark },
            onSelectPhoto = { activeLightboxPhoto = it }
          )
        }

        "player" -> {
          MtxPlayerScreen(
            video = activeVideo,
            allVideos = uploadedVideos.filter { it.isPublished && (it.isDark == (activeVideo?.isDark ?: false)) },
            isFullscreen = isPlayerFullscreen,
            onToggleFullscreen = { isPlayerFullscreen = !isPlayerFullscreen },
            onSelectRelated = { activeVideo = it }
          )
        }

        "dark_site" -> {
          MtxDarkSiteScreen(
            darkAuth = darkUserAuth,
            darkVideos = uploadedVideos.filter { it.isPublished && it.isDark },
            darkPhotos = uploadedPhotos.filter { it.isPublished && it.isDark },
            onUpdateAuth = { updated ->
              darkUserAuth = updated
              DarkUserStorage.save(context, updated)
            },
            onSelectVideo = {
              activeVideo = it
              currentScreen = "player"
            },
            onSelectPhoto = { activeLightboxPhoto = it },
            onRefreshStatus = { performCloudSync() }
          )
        }

        "admin" -> {
          if (!isAdminAuthenticated) {
            MtxAdminLoginScreen(
              onLoginSuccess = { isAdminAuthenticated = true },
              onCancel = { currentScreen = "browse" }
            )
          } else {
            MtxAdminPanelScreen(
              videos = uploadedVideos,
              photos = uploadedPhotos,
              onAddVideo = { newVideo ->
                uploadedVideos.add(0, newVideo)
                // Only set activeVideo if it's a Normal video, so dark videos NEVER leak into the normal player!
                if (!newVideo.isDark) {
                  activeVideo = newVideo
                }
                VideoStorage.saveVideos(context, uploadedVideos)
              },
              onDeleteVideo = { videoId ->
                uploadedVideos.removeAll { it.id == videoId }
                if (activeVideo?.id == videoId) {
                  activeVideo = uploadedVideos.firstOrNull { it.isPublished && !it.isDark }
                }
                VideoStorage.saveVideos(context, uploadedVideos)
                coroutineScope.launch(Dispatchers.IO) {
                  MtxCloudSync.deleteVideoFromCloud(videoId)
                }
              },
              onTogglePublish = { videoId ->
                val index = uploadedVideos.indexOfFirst { it.id == videoId }
                if (index != -1) {
                  val item = uploadedVideos[index]
                  uploadedVideos[index] = item.copy(isPublished = !item.isPublished)
                  VideoStorage.saveVideos(context, uploadedVideos)
                }
              },
              onAddPhoto = { newPhoto ->
                uploadedPhotos.add(0, newPhoto)
                PhotoStorage.savePhotos(context, uploadedPhotos)
              },
              onDeletePhoto = { photoId ->
                uploadedPhotos.removeAll { it.id == photoId }
                PhotoStorage.savePhotos(context, uploadedPhotos)
                coroutineScope.launch(Dispatchers.IO) {
                  MtxCloudSync.deletePhotoFromCloud(photoId)
                }
              },
              onTogglePublishPhoto = { photoId ->
                val index = uploadedPhotos.indexOfFirst { it.id == photoId }
                if (index != -1) {
                  val item = uploadedPhotos[index]
                  uploadedPhotos[index] = item.copy(isPublished = !item.isPublished)
                  PhotoStorage.savePhotos(context, uploadedPhotos)
                }
              },
              onLogout = {
                isAdminAuthenticated = false
                darkUserAuth = DarkUserStorage.load(context)
                currentScreen = "browse"
              },
              onBackToVideos = {
                darkUserAuth = DarkUserStorage.load(context)
                currentScreen = "browse"
              },
              onGoToPhotos = {
                darkUserAuth = DarkUserStorage.load(context)
                currentScreen = "photos"
              },
              onGoToDarkSite = {
                darkUserAuth = DarkUserStorage.load(context)
                currentScreen = "dark_site"
              },
              onGoToWatch = { vid ->
                darkUserAuth = DarkUserStorage.load(context)
                activeVideo = vid
                currentScreen = "player"
              }
            )
          }
        }
      }

      // Full-Screen Photo Lightbox Modal
      if (activeLightboxPhoto != null) {
        MtxPhotoLightbox(
          photo = activeLightboxPhoto!!,
          onClose = { activeLightboxPhoto = null }
        )
      }

      // First-time Member Registration Dialog (Requirement 2)
      if (showRegistrationDialog) {
        Dialog(onDismissRequest = { /* Require member registration */ }) {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, Color(0xFF3B82F6), RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
            shape = RoundedCornerShape(20.dp)
          ) {
            Column(
              modifier = Modifier.padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Image(
                painter = painterResource(id = R.drawable.ic_app_logo),
                contentDescription = "MTX Logo",
                modifier = Modifier
                  .size(56.dp)
                  .clip(RoundedCornerShape(14.dp))
                  .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
              )
              Spacer(modifier = Modifier.height(14.dp))
              Text("Welcome to MTX", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
              Text(
                "Please enter your name to register your membership and access the streaming platform.",
                color = Color(0xFF94A3B8),
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
              )

              OutlinedTextField(
                value = memberNameInput,
                onValueChange = { memberNameInput = it },
                label = { Text("Your Name", fontSize = 12.sp) },
                placeholder = { Text("e.g. Alex Hunter", color = Color(0xFF64748B), fontSize = 12.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("member_registration_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = Color(0xFF0B0E14),
                  unfocusedContainerColor = Color(0xFF0B0E14),
                  focusedBorderColor = Color(0xFF3B82F6),
                  unfocusedBorderColor = Color(0xFF252D3D),
                  focusedTextColor = Color.White,
                  unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
              )

              Spacer(modifier = Modifier.height(8.dp))
              Text(
                "Member ID: ${darkUserAuth.userId}",
                color = Color(0xFF60A5FA),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )

              Spacer(modifier = Modifier.height(18.dp))

              Button(
                onClick = {
                  val trimmedName = memberNameInput.trim().ifBlank { "Member " + darkUserAuth.userId.takeLast(4) }
                  val updated = darkAuthCopy(darkUserAuth, trimmedName)
                  DarkUserStorage.save(context, updated)
                  darkUserAuth = updated
                  showRegistrationDialog = false
                  coroutineScope.launch(Dispatchers.IO) {
                    MtxCloudSync.registerNormalUser(updated.userId, updated.userName)
                  }
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(46.dp)
                  .testTag("submit_member_registration_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                shape = RoundedCornerShape(12.dp)
              ) {
                Text("Complete Registration", fontSize = 13.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

private fun darkAuthCopy(auth: DarkUserAuth, newName: String): DarkUserAuth {
  return auth.copy(userName = newName)
}

// ==========================================
// TOP HEADER: Logo + Discreet Corner Login + Sync
// ==========================================
@Composable
fun MtxTopHeader(
  isAdmin: Boolean,
  isSyncing: Boolean,
  onSyncClick: () -> Unit,
  onCornerAdminClick: () -> Unit,
  onLogoutAdmin: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(Color(0xFF0B0E14))
      .padding(top = 40.dp, start = 16.dp, end = 16.dp, bottom = 10.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    // Brand: Custom MTX Logo + Title
    Row(verticalAlignment = Alignment.CenterVertically) {
      Image(
        painter = painterResource(id = R.drawable.ic_app_logo),
        contentDescription = "MTX Logo",
        modifier = Modifier
          .size(38.dp)
          .clip(RoundedCornerShape(10.dp))
          .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
      )
      Spacer(modifier = Modifier.width(10.dp))
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text("M", color = Color.White, fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 1.sp)
        Text("TX", color = Color(0xFFA855F7), fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 1.sp)
      }
    }

    // Right Corner Actions: Sync Indicator + Discreet Corner Admin Lock
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Discreet Sync Button
      IconButton(
        onClick = onSyncClick,
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(Color(0xFF151A24))
          .border(1.dp, Color(0xFF252D3D), CircleShape)
          .testTag("cloud_sync_refresh_button")
      ) {
        if (isSyncing) {
          CircularProgressIndicator(color = Color(0xFF60A5FA), modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
        } else {
          Icon(Icons.Default.Sync, contentDescription = "Sync Cloud", tint = Color(0xFF60A5FA), modifier = Modifier.size(16.dp))
        }
      }

      if (isAdmin) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF7C3AED).copy(alpha = 0.25f))
            .clickable { onCornerAdminClick() }
            .border(1.dp, Color(0xFF7C3AED), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("corner_admin_panel_button")
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color(0xFFC084FC), modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Admin", color = Color(0xFFC084FC), fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFEF4444).copy(alpha = 0.15f))
            .clickable { onLogoutAdmin() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("corner_admin_logout_button")
        ) {
          Text("Logout", color = Color(0xFFF87171), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      } else {
        // Discreet lock icon at corner
        IconButton(
          onClick = onCornerAdminClick,
          modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFF151A24))
            .border(1.dp, Color(0xFF252D3D), CircleShape)
            .testTag("corner_admin_login_icon")
        ) {
          Icon(Icons.Default.Lock, contentDescription = "Admin Login", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
        }
      }
    }
  }
}

// ==========================================
// 1. VIDEOS BROWSE SCREEN
// ==========================================
@Composable
fun MtxBrowseScreen(
  videos: List<VideoItem>,
  searchQuery: String,
  onSearchChange: (String) -> Unit,
  selectedCategory: String,
  onCategoryChange: (String) -> Unit,
  onSelectVideo: (VideoItem) -> Unit
) {
  val filteredVideos = remember(videos, searchQuery, selectedCategory) {
    videos.filter { video ->
      val matchesCat = (selectedCategory == "All") || (video.category == selectedCategory)
      val matchesQuery = searchQuery.isBlank() ||
        video.title.contains(searchQuery, ignoreCase = true) ||
        video.description.contains(searchQuery, ignoreCase = true)
      matchesCat && matchesQuery
    }
  }

  Column(modifier = Modifier.fillMaxSize()) {
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchChange,
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp)
        .testTag("user_search_input"),
      placeholder = { Text("Search MTX videos...", color = Color(0xFF64748B), fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF64748B)) },
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = Color(0xFF151A24),
        unfocusedContainerColor = Color(0xFF151A24),
        focusedBorderColor = Color(0xFF3B82F6),
        unfocusedBorderColor = Color(0xFF252D3D),
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White
      ),
      shape = RoundedCornerShape(14.dp)
    )

    val categoryChips = remember(videos) {
      val dynamic = videos.map { it.category }.filter { it.isNotBlank() }
      listOf("All") + (availableVideoCategories + dynamic).distinct()
    }

    LazyRow(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(categoryChips) { cat ->
        val isSelected = cat == selectedCategory
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) Color(0xFF2563EB) else Color(0xFF151A24))
            .border(1.dp, if (isSelected) Color(0xFF3B82F6) else Color(0xFF252D3D), RoundedCornerShape(10.dp))
            .clickable { onCategoryChange(cat) }
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("cat_chip_$cat")
        ) {
          Text(
            cat,
            color = if (isSelected) Color.White else Color(0xFF94A3B8),
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
          )
        }
      }
    }

    if (videos.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF252D3D))
        ) {
          Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Image(
              painter = painterResource(id = R.drawable.ic_app_logo),
              contentDescription = "MTX Logo",
              modifier = Modifier
                .size(68.dp)
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, Color(0xFF8B5CF6).copy(alpha = 0.5f), RoundedCornerShape(18.dp))
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text("No videos uploaded yet", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              "Videos published by the administrator will appear here automatically for all downloaders.",
              color = Color(0xFF94A3B8),
              fontSize = 12.sp,
              textAlign = TextAlign.Center,
              lineHeight = 18.sp
            )
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        items(filteredVideos) { video ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(20.dp))
              .border(1.dp, Color(0xFF252D3D), RoundedCornerShape(20.dp))
              .clickable { onSelectVideo(video) }
              .testTag("video_card_${video.id}"),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
            shape = RoundedCornerShape(20.dp)
          ) {
            Column {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .aspectRatio(16f / 9f)
                  .background(
                    Brush.radialGradient(
                      listOf(video.accentColor.copy(alpha = 0.35f), Color(0xFF0F172A))
                    )
                  ),
                contentAlignment = Alignment.Center
              ) {
                Box(
                  modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2563EB).copy(alpha = 0.9f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(32.dp))
                }

                Box(
                  modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(10.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.75f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                  Text(video.duration, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
              }

              Column(modifier = Modifier.padding(14.dp)) {
                Text(video.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(4.dp))
                Text(video.description, color = Color(0xFF94A3B8), fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 16.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(video.category, color = Color(0xFF60A5FA), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                  Text(video.views, color = Color(0xFF64748B), fontSize = 11.sp)
                }
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// 2. PHOTOS SCREEN
// ==========================================
@Composable
fun MtxPhotosScreen(
  photos: List<PhotoItem>,
  onSelectPhoto: (PhotoItem) -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("All") }

  val filteredPhotos = remember(photos, searchQuery, selectedCategory) {
    photos.filter { photo ->
      val matchesCat = (selectedCategory == "All") || (photo.category == selectedCategory)
      val matchesQuery = searchQuery.isBlank() || photo.title.contains(searchQuery, ignoreCase = true)
      matchesCat && matchesQuery
    }
  }

  Column(modifier = Modifier.fillMaxSize()) {
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp)
        .testTag("photo_search_input"),
      placeholder = { Text("Search MTX photo gallery...", color = Color(0xFF64748B), fontSize = 13.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF64748B)) },
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = Color(0xFF151A24),
        unfocusedContainerColor = Color(0xFF151A24),
        focusedBorderColor = Color(0xFF7C3AED),
        unfocusedBorderColor = Color(0xFF252D3D),
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White
      ),
      shape = RoundedCornerShape(14.dp)
    )

    if (photos.isNotEmpty()) {
      val cats = listOf("All") + photos.map { it.category }.distinct()
      LazyRow(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(cats) { cat ->
          val isSelected = cat == selectedCategory
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(if (isSelected) Color(0xFF7C3AED) else Color(0xFF151A24))
              .border(1.dp, if (isSelected) Color(0xFF8B5CF6) else Color(0xFF252D3D), RoundedCornerShape(10.dp))
              .clickable { selectedCategory = cat }
              .padding(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Text(cat, color = if (isSelected) Color.White else Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
          }
        }
      }
    }

    if (filteredPhotos.isEmpty()) {
      Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text("No photos available in this category.", color = Color(0xFF94A3B8), fontSize = 12.sp)
      }
    } else {
      LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(filteredPhotos) { photo ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(16.dp))
              .border(1.dp, Color(0xFF252D3D), RoundedCornerShape(16.dp))
              .clickable { onSelectPhoto(photo) }
              .testTag("photo_item_${photo.id}"),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF151A24)),
            shape = RoundedCornerShape(16.dp)
          ) {
            Column {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .aspectRatio(1f)
                  .background(Color(0xFF0F172A))
              ) {
                AsyncImage(
                  model = photo.imageUri,
                  contentDescription = photo.title,
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize()
                )
              }

              Column(modifier = Modifier.padding(10.dp)) {
                Text(photo.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(photo.category, color = Color(0xFF94A3B8), fontSize = 10.sp)
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Favorite, contentDescription = "Likes", tint = Color(0xFFEC4899), modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("${photo.likes}", color = Color.White, fontSize = 10.sp)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// 3. FULLSCREEN / REGULAR WATCH PLAYER
// ==========================================
@Composable
fun MtxPlayerScreen(
  video: VideoItem?,
  allVideos: List<VideoItem>,
  isFullscreen: Boolean,
  onToggleFullscreen: () -> Unit,
  onSelectRelated: (VideoItem) -> Unit
) {
  var isPlaying by remember { mutableStateOf(true) }
  var isBuffering by remember { mutableStateOf(true) }
  var playbackError by remember { mutableStateOf(false) }
  var showHudControls by remember { mutableStateOf(true) }

  if (video == null) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(24.dp),
      contentAlignment = Alignment.Center
    ) {
      Text("No video selected. Choose a video to play.", color = Color(0xFF94A3B8), fontSize = 13.sp)
    }
    return
  }

  val resolvedUri = remember(video.videoUri) { resolveMediaUri(video.videoUri) }

  // Reset errors and buffering whenever a new video or URI is selected
  LaunchedEffect(resolvedUri) {
    playbackError = false
    isBuffering = true
  }

  if (isFullscreen) {
    // Immersive YouTube Fullscreen
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black)
        .clickable { showHudControls = !showHudControls }
        .testTag("fullscreen_video_container"),
      contentAlignment = Alignment.Center
    ) {
      if (resolvedUri.isNotBlank()) {
        AndroidView(
          factory = { ctx ->
            VideoView(ctx).apply {
              // Suppress Android default "Can't play this video" AlertDialog
              setOnErrorListener { _, what, extra ->
                playbackError = true
                isBuffering = false
                true
              }
              setOnInfoListener { _, what, _ ->
                if (what == android.media.MediaPlayer.MEDIA_INFO_BUFFERING_START) isBuffering = true
                if (what == android.media.MediaPlayer.MEDIA_INFO_BUFFERING_END) isBuffering = false
                true
              }
              val controller = MediaController(ctx)
              controller.setAnchorView(this)
              setMediaController(controller)
              setOnPreparedListener { mp ->
                isBuffering = false
                playbackError = false
                mp.isLooping = true
                start()
              }
            }
          },
          update = { vView ->
            val currentTag = vView.tag as? String
            if (currentTag != resolvedUri) {
              vView.tag = resolvedUri
              try {
                vView.stopPlayback()
                isBuffering = true
                playbackError = false
                if (resolvedUri.startsWith("/")) {
                  vView.setVideoPath(resolvedUri)
                } else {
                  vView.setVideoURI(android.net.Uri.parse(resolvedUri))
                }
              } catch (e: Exception) {
                playbackError = true
                isBuffering = false
              }
            }
          },
          modifier = Modifier.fillMaxSize()
        )
      }

      if (isBuffering && !playbackError) {
        CircularProgressIndicator(color = Color(0xFF60A5FA), modifier = Modifier.size(44.dp))
      }

      if (playbackError) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(20.dp)) {
          Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFF87171), modifier = Modifier.size(36.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text("Video stream unavailable or still uploading.", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Text("Tap to exit fullscreen or retry", color = Color(0xFF94A3B8), fontSize = 11.sp)
        }
      }

      if (showHudControls) {
        // Top HUD Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.TopCenter)
            .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)))
            .padding(horizontal = 16.dp, vertical = 32.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onToggleFullscreen) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit Fullscreen", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(video.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
          }

          IconButton(onClick = onToggleFullscreen) {
            Icon(Icons.Default.Fullscreen, contentDescription = "Exit Fullscreen", tint = Color(0xFF60A5FA), modifier = Modifier.size(24.dp))
          }
        }
      }
    }
  } else {
    // Normal Mode with edge-to-edge player + related videos
    Column(modifier = Modifier.fillMaxSize()) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .aspectRatio(16f / 9f)
          .background(Color.Black),
        contentAlignment = Alignment.Center
      ) {
        if (resolvedUri.isNotBlank()) {
          AndroidView(
            factory = { ctx ->
              VideoView(ctx).apply {
                setOnErrorListener { _, what, extra ->
                  playbackError = true
                  isBuffering = false
                  true
                }
                setOnInfoListener { _, what, _ ->
                  if (what == android.media.MediaPlayer.MEDIA_INFO_BUFFERING_START) isBuffering = true
                  if (what == android.media.MediaPlayer.MEDIA_INFO_BUFFERING_END) isBuffering = false
                  true
                }
                val controller = MediaController(ctx)
                controller.setAnchorView(this)
                setMediaController(controller)
                setOnPreparedListener { mp ->
                  isBuffering = false
                  playbackError = false
                  mp.isLooping = true
                  start()
                }
              }
            },
            update = { vView ->
              val currentTag = vView.tag as? String
              if (currentTag != resolvedUri) {
                vView.tag = resolvedUri
                try {
                  vView.stopPlayback()
                  isBuffering = true
                  playbackError = false
                  if (resolvedUri.startsWith("/")) {
                    vView.setVideoPath(resolvedUri)
                  } else {
                    vView.setVideoURI(android.net.Uri.parse(resolvedUri))
                  }
                } catch (e: Exception) {
                  playbackError = true
                  isBuffering = false
                }
              }
            },
            modifier = Modifier.fillMaxSize()
          )
        }

        if (isBuffering && !playbackError) {
          CircularProgressIndicator(color = Color(0xFF60A5FA), modifier = Modifier.size(36.dp))
        }

        if (playbackError) {
          Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
            Text("Unable to stream video", color = Color(0xFFF87171), fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }

        IconButton(
          onClick = onToggleFullscreen,
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(10.dp)
            .size(38.dp)
            .background(Color.Black.copy(alpha = 0.7f), CircleShape)
            .testTag("enter_fullscreen_button")
        ) {
          Icon(Icons.Default.Fullscreen, contentDescription = "Watch in Fullscreen", tint = Color.White, modifier = Modifier.size(22.dp))
        }
      }

      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        item {
          Text(video.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(video.category, color = if (video.isDark) Color(0xFFEF4444) else Color(0xFF60A5FA), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(video.views, color = Color(0xFF94A3B8), fontSize = 12.sp)
          }

          Spacer(modifier = Modifier.height(10.dp))
          Text(video.description, color = Color(0xFFCBD5E1), fontSize = 12.sp, lineHeight = 17.sp)

          Spacer(modifier = Modifier.height(14.dp))

          Button(
            onClick = onToggleFullscreen,
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .testTag("watch_full_screen_button"),
            colors = ButtonDefaults.buttonColors(containerColor = if (video.isDark) Color(0xFFDC2626) else Color(0xFF2563EB)),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Watch on Full Screen (YouTube Style)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }

        item {
          Spacer(modifier = Modifier.height(6.dp))
          Text(if (video.isDark) "More Exclusive Dark Videos" else "More Videos in MTX", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }

        val related = allVideos.filter { it.id != video.id && it.isPublished && (it.isDark == video.isDark) }
        items(related) { rel ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, if (rel.isDark) Color(0xFF381F28) else Color(0xFF252D3D), RoundedCornerShape(14.dp))
              .clickable { onSelectRelated(rel) },
            colors = CardDefaults.cardColors(containerColor = if (rel.isDark) Color(0xFF140D18) else Color(0xFF151A24)),
            shape = RoundedCornerShape(14.dp)
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(80.dp, 50.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (rel.isDark) Color(0xFFDC2626).copy(alpha = 0.35f) else rel.accentColor.copy(alpha = 0.35f)),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
              }

              Spacer(modifier = Modifier.width(12.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(rel.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${rel.category} • ${rel.duration}", color = Color(0xFF94A3B8), fontSize = 11.sp)
              }
            }
          }
        }
      }
    }
  }
}

// ==========================================
// 4. PHOTO LIGHTBOX MODAL
// ==========================================
@Composable
fun MtxPhotoLightbox(
  photo: PhotoItem,
  onClose: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color.Black.copy(alpha = 0.96f))
      .clickable { onClose() }
      .testTag("photo_lightbox_container"),
    contentAlignment = Alignment.Center
  ) {
    AsyncImage(
      model = photo.imageUri,
      contentDescription = photo.title,
      contentScale = ContentScale.Fit,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    )

    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.TopCenter)
        .padding(top = 40.dp, start = 16.dp, end = 16.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(photo.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text("${photo.category} • ${photo.likes} Likes", color = Color(0xFF94A3B8), fontSize = 11.sp)
      }

      IconButton(
        onClick = onClose,
        modifier = Modifier
          .size(40.dp)
          .background(Color.Black.copy(alpha = 0.6f), CircleShape)
      ) {
        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
      }
    }
  }
}
