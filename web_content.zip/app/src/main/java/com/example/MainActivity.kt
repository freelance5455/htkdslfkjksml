package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.preferences.PreferencesRepository
import com.example.data.repository.HistoryRepository
import com.example.ui.calculator.CalculatorScreen
import com.example.ui.calculator.CalculatorViewModel
import com.example.ui.calculator.HistoryBottomSheet
import com.example.ui.converter.ConverterScreen
import com.example.ui.converter.ConverterViewModel
import com.example.ui.settings.SettingsBottomSheet
import com.example.ui.theme.AetherCalculatorTheme
import com.example.ui.theme.AetherTheme
import com.example.ui.tools.ToolsScreen
import kotlinx.coroutines.launch

enum class MainTab(
  val labelRes: Int,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
) {
  CALCULATOR(R.string.nav_calculator, Icons.Filled.Calculate, Icons.Outlined.Calculate, "nav_calculator"),
  CONVERT(R.string.nav_convert, Icons.Filled.SwapHoriz, Icons.Outlined.SwapHoriz, "nav_convert"),
  TOOLS(R.string.nav_tools, Icons.Filled.Build, Icons.Outlined.Build, "nav_tools"),
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val database = AppDatabase.getInstance(applicationContext)
    val historyRepository = HistoryRepository(database.historyDao())
    val preferencesRepository = PreferencesRepository(applicationContext)

    setContent {
      AetherCalculatorApp(
        historyRepository = historyRepository,
        preferencesRepository = preferencesRepository,
      )
    }
  }
}

@Composable
fun AetherCalculatorApp(
  historyRepository: HistoryRepository,
  preferencesRepository: PreferencesRepository,
) {
  val calcViewModel: CalculatorViewModel =
    viewModel(factory = CalculatorViewModel.Factory(historyRepository, preferencesRepository))
  val converterViewModel: ConverterViewModel = viewModel()

  val prefs by calcViewModel.preferences.collectAsStateWithLifecycle()
  val calcState by calcViewModel.uiState.collectAsStateWithLifecycle()
  val history by calcViewModel.history.collectAsStateWithLifecycle()
  val converterState by converterViewModel.state.collectAsStateWithLifecycle()

  var currentTab by rememberSaveable { mutableStateOf(MainTab.CALCULATOR) }
  var showHistorySheet by rememberSaveable { mutableStateOf(false) }
  var showSettingsSheet by rememberSaveable { mutableStateOf(false) }

  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val context = LocalContext.current
  val copiedLabel = stringResource(R.string.copied_to_clipboard)

  val copyToClipboard: (String) -> Unit = { text ->
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("Calculator result", text))
    scope.launch {
      snackbarHostState.currentSnackbarData?.dismiss()
      snackbarHostState.showSnackbar(
        message = "$copiedLabel: $text",
        duration = SnackbarDuration.Short,
      )
    }
  }

  BackHandler(enabled = currentTab != MainTab.CALCULATOR) {
    currentTab = MainTab.CALCULATOR
  }

  AetherCalculatorTheme(themeMode = prefs.themeMode) {
    val colors = AetherTheme.colors

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(colors.background)) {
      val useRail = maxWidth >= 600.dp

      Scaffold(
        containerColor = colors.background,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = {
          SnackbarHost(hostState = snackbarHostState) { data ->
            Snackbar(
              snackbarData = data,
              containerColor = colors.surfaceElevated,
              contentColor = colors.textPrimary,
              shape = RoundedCornerShape(14.dp),
            )
          }
        },
        bottomBar = {
          if (!useRail) {
            CompactBottomBar(
              currentTab = currentTab,
              onSelectTab = { currentTab = it },
            )
          }
        },
      ) { innerPadding ->
        Row(
          modifier =
            Modifier
              .fillMaxSize()
              .padding(innerPadding),
        ) {
          if (useRail) {
            NavigationRail(
              containerColor = colors.surface,
              contentColor = colors.textPrimary,
              modifier = Modifier.fillMaxHeight().statusBarsPadding().navigationBarsPadding(),
            ) {
              MainTab.entries.forEach { tab ->
                val selected = currentTab == tab
                NavigationRailItem(
                  selected = selected,
                  onClick = { currentTab = tab },
                  icon = {
                    Icon(
                      imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                      contentDescription = stringResource(tab.labelRes),
                    )
                  },
                  label = { Text(stringResource(tab.labelRes)) },
                  colors =
                    NavigationRailItemDefaults.colors(
                      selectedIconColor = Color(0xFFF1F0F5),
                      selectedTextColor = colors.lavender,
                      indicatorColor = colors.accent,
                      unselectedIconColor = colors.textSecondary,
                      unselectedTextColor = colors.textSecondary,
                    ),
                  modifier = Modifier.testTag(tab.testTag),
                )
              }
            }
            VerticalDivider(color = colors.borderSubtle, thickness = 1.dp)
          }

          Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            when (currentTab) {
              MainTab.CALCULATOR ->
                CalculatorScreen(
                  uiState = calcState,
                  hapticsEnabled = prefs.hapticEnabled,
                  onDigit = calcViewModel::onDigit,
                  onDecimal = calcViewModel::onDecimal,
                  onOperator = calcViewModel::onOperator,
                  onPercent = calcViewModel::onPercent,
                  onToggleSign = calcViewModel::onToggleSign,
                  onClearAll = calcViewModel::onClearAll,
                  onBackspace = calcViewModel::onBackspace,
                  onEquals = calcViewModel::onEquals,
                  onToggleScientific = calcViewModel::toggleScientificMode,
                  onCollapseScientific = { calcViewModel.setScientificMode(false) },
                  onToggleSecondPage = calcViewModel::toggleSecondPage,
                  onToggleHyperbolic = calcViewModel::toggleHyperbolic,
                  onToggleAngleMode = calcViewModel::toggleAngleMode,
                  onScientificFunction = calcViewModel::onScientificFunction,
                  onScientificConstant = calcViewModel::onScientificConstant,
                  onScientificPostfix = calcViewModel::onScientificPostfix,
                  onReciprocal = calcViewModel::onReciprocal,
                  onParen = calcViewModel::onParen,
                  onComma = calcViewModel::onComma,
                  onMemoryClear = calcViewModel::onMemoryClear,
                  onMemoryRecall = calcViewModel::onMemoryRecall,
                  onMemoryAdd = calcViewModel::onMemoryAdd,
                  onMemorySubtract = calcViewModel::onMemorySubtract,
                  onOpenHistory = { showHistorySheet = true },
                  onOpenSettings = { showSettingsSheet = true },
                  onCopyResult = copyToClipboard,
                )

              MainTab.CONVERT ->
                ConverterScreen(
                  state = converterState,
                  formatting = prefs.formattingOptions,
                  hapticsEnabled = prefs.hapticEnabled,
                  onSelectCategory = converterViewModel::selectCategory,
                  onSelectFromUnit = converterViewModel::selectFromUnit,
                  onSelectToUnit = converterViewModel::selectToUnit,
                  onSwapUnits = converterViewModel::swapUnits,
                  onDigit = converterViewModel::onDigit,
                  onDecimal = converterViewModel::onDecimal,
                  onToggleSign = converterViewModel::onToggleSign,
                  onBackspace = converterViewModel::onBackspace,
                  onClear = converterViewModel::onClear,
                  onCustomRateChanged = converterViewModel::onCustomRateChanged,
                  onCopyResult = copyToClipboard,
                )

              MainTab.TOOLS ->
                ToolsScreen(
                  formatting = prefs.formattingOptions,
                  hapticsEnabled = prefs.hapticEnabled,
                  onCopyResult = copyToClipboard,
                )
            }
          }
        }
      }

      if (showHistorySheet) {
        HistoryBottomSheet(
          history = history,
          onDismiss = { showHistorySheet = false },
          onReuseExpression = calcViewModel::reuseHistoryItem,
          onCopyResult = copyToClipboard,
          onDeleteItem = calcViewModel::deleteHistoryItem,
          onClearAll = calcViewModel::clearAllHistory,
        )
      }

      if (showSettingsSheet) {
        SettingsBottomSheet(
          preferences = prefs,
          onDismiss = { showSettingsSheet = false },
          onSelectTheme = { mode ->
            scope.launch { preferencesRepository.setThemeMode(mode) }
          },
          onToggleHaptics = { enabled ->
            scope.launch { preferencesRepository.setHapticEnabled(enabled) }
          },
          onSelectGrouping = { style ->
            scope.launch { preferencesRepository.setGroupingStyle(style) }
          },
          onSelectPrecision = { precision ->
            scope.launch { preferencesRepository.setDecimalPrecision(precision) }
          },
        )
      }
    }
  }
}

@Composable
private fun CompactBottomBar(
  currentTab: MainTab,
  onSelectTab: (MainTab) -> Unit,
) {
  val colors = AetherTheme.colors
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(colors.surface)
        .navigationBarsPadding(),
  ) {
    HorizontalDivider(color = colors.borderSubtle, thickness = 1.dp)
    Row(
      modifier = Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 12.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      MainTab.entries.forEach { tab ->
        val selected = currentTab == tab
        Box(
          contentAlignment = Alignment.Center,
          modifier =
            Modifier
              .weight(1f)
              .height(48.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(if (selected) colors.surfaceElevated else Color.Transparent)
              .clickable { onSelectTab(tab) }
              .testTag(tab.testTag),
        ) {
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
          ) {
            Icon(
              imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
              contentDescription = stringResource(tab.labelRes),
              tint = if (selected) colors.lavender else colors.textSecondary,
              modifier = Modifier.size(20.dp),
            )
            Text(
              text = stringResource(tab.labelRes),
              style = MaterialTheme.typography.labelSmall,
              color = if (selected) colors.textPrimary else colors.textSecondary,
            )
          }
        }
      }
    }
  }
}
