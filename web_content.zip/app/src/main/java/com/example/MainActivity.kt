package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.installer.ApkInstaller
import com.example.data.model.ApkInfo
import com.example.ui.components.ApkResultCard
import com.example.ui.components.AppHtmlFeaturedCard
import com.example.ui.components.ConversionProgressCard
import com.example.ui.components.ConvertedHistoryList
import com.example.ui.components.FilePickerSection
import com.example.ui.components.HeaderCard
import com.example.ui.components.HtmlPreviewDialog
import com.example.ui.components.InstallPermissionDialog
import com.example.ui.components.InstallationGuideSection
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ConverterViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: ConverterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle incoming intents (if user opens a ZIP/XAPK/HTML file with our app)
        intent?.data?.let { uri ->
            viewModel.convertFromUri(uri)
        }

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val layoutDirection = if (uiState.isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                MyApplicationTheme {
                    MainScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun MainScreen(viewModel: ConverterViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    // Launcher for selecting a source file to convert
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.convertFromUri(it) }
    }

    // Pending APK for saving to storage
    var pendingSaveApk by remember { mutableStateOf<ApkInfo?>(null) }
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { destUri: Uri? ->
        val apkToSave = pendingSaveApk
        if (destUri != null && apkToSave != null) {
            viewModel.saveApkToStorage(context, apkToSave, destUri)
        }
        pendingSaveApk = null
    }

    // Launcher for exporting index.html
    val createHtmlLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/html")
    ) { destUri: Uri? ->
        if (destUri != null) {
            viewModel.saveIndexHtmlToStorage(context, destUri)
        }
    }

    // Handle snackbar messages
    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = uiState.currentTab == 0,
                    onClick = { viewModel.selectTab(0) },
                    icon = { Icon(Icons.Default.SyncAlt, contentDescription = null) },
                    label = { Text(if (uiState.isArabic) "التحويل" else "Convert") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_convert_tab")
                )
                NavigationBarItem(
                    selected = uiState.currentTab == 1,
                    onClick = { viewModel.selectTab(1) },
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    label = {
                        Text(
                            if (uiState.isArabic) "المحفوظة (${uiState.historyApks.size})"
                            else "Saved (${uiState.historyApks.size})"
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_history_tab")
                )
                NavigationBarItem(
                    selected = uiState.currentTab == 2,
                    onClick = { viewModel.selectTab(2) },
                    icon = { Icon(Icons.Default.HelpOutline, contentDescription = null) },
                    label = { Text(if (uiState.isArabic) "دليل التثبيت" else "Guide") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.testTag("nav_guide_tab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(12.dp))

                HeaderCard(
                    isArabic = uiState.isArabic,
                    onToggleLanguage = { viewModel.toggleLanguage() },
                    onOpenGuide = { viewModel.selectTab(2) },
                    convertedCount = uiState.historyApks.size
                )

                Spacer(modifier = Modifier.height(14.dp))

                when (uiState.currentTab) {
                    0 -> {
                        // Convert Tab
                        val scrollState = rememberScrollState()
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(scrollState)
                                .padding(bottom = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            if (uiState.isConverting) {
                                ConversionProgressCard(
                                    progress = uiState.progress,
                                    isArabic = uiState.isArabic
                                )
                            }

                            AnimatedVisibility(
                                visible = uiState.lastConvertedApk != null && !uiState.isConverting,
                                enter = fadeIn(),
                                exit = fadeOut()
                            ) {
                                uiState.lastConvertedApk?.let { apkInfo ->
                                    ApkResultCard(
                                        apkInfo = apkInfo,
                                        isArabic = uiState.isArabic,
                                        onInstallClick = { viewModel.installApk(context, apkInfo) },
                                        onSaveToStorageClick = {
                                            pendingSaveApk = apkInfo
                                            createDocumentLauncher.launch(apkInfo.fileName)
                                        },
                                        onShareClick = { viewModel.shareApk(context, apkInfo) }
                                    )
                                }
                            }

                            // Featured App index.html Card
                            AppHtmlFeaturedCard(
                                isArabic = uiState.isArabic,
                                onPreviewClick = { viewModel.openHtmlPreview() },
                                onConvertAndInstallClick = { viewModel.convertAppIndexHtml() },
                                onSaveHtmlClick = { createHtmlLauncher.launch("index.html") },
                                isConverting = uiState.isConverting
                            )

                            // Main File Picker
                            FilePickerSection(
                                isArabic = uiState.isArabic,
                                customAppName = uiState.customAppName,
                                onAppNameChange = { viewModel.setCustomAppName(it) },
                                onPickFileClick = {
                                    openDocumentLauncher.launch(
                                        arrayOf(
                                            "application/zip",
                                            "application/x-zip-compressed",
                                            "application/octet-stream",
                                            "text/html",
                                            "application/vnd.android.package-archive",
                                            "*/*"
                                        )
                                    )
                                },
                                samples = uiState.sampleList,
                                onSelectSample = { sample -> viewModel.convertSample(sample) },
                                isConverting = uiState.isConverting
                            )
                        }
                    }
                    1 -> {
                        // History Tab
                        ConvertedHistoryList(
                            historyList = uiState.historyApks,
                            isArabic = uiState.isArabic,
                            onInstallClick = { apkInfo -> viewModel.installApk(context, apkInfo) },
                            onShareClick = { apkInfo -> viewModel.shareApk(context, apkInfo) },
                            onSaveClick = { apkInfo ->
                                pendingSaveApk = apkInfo
                                createDocumentLauncher.launch(apkInfo.fileName)
                            },
                            onDeleteClick = { apkInfo -> viewModel.promptDeleteApk(apkInfo) },
                            onClearAllClick = { viewModel.clearAllHistory() },
                            onSwitchToConvertTab = { viewModel.selectTab(0) }
                        )
                    }
                    2 -> {
                        // Guide Tab
                        InstallationGuideSection(
                            isArabic = uiState.isArabic,
                            onOpenSettingsClick = { ApkInstaller.openInstallPermissionSettings(context) }
                        )
                    }
                }
            }
        }
    }

    // Permission Dialog
    if (uiState.showPermissionDialog) {
        InstallPermissionDialog(
            isArabic = uiState.isArabic,
            onConfirm = {
                viewModel.dismissPermissionDialog()
                ApkInstaller.openInstallPermissionSettings(context)
            },
            onDismiss = { viewModel.dismissPermissionDialog() }
        )
    }

    // In-App HTML Preview Dialog
    if (uiState.showHtmlPreviewDialog) {
        HtmlPreviewDialog(
            isArabic = uiState.isArabic,
            onDismiss = { viewModel.closeHtmlPreview() },
            onConvertToApk = { viewModel.convertAppIndexHtml() },
            onSaveHtml = { createHtmlLauncher.launch("index.html") }
        )
    }

    // Delete Single APK Confirmation Dialog
    uiState.apkToDelete?.let { toDelete ->
        AlertDialog(
            onDismissRequest = { viewModel.cancelDelete() },
            title = {
                Text(if (uiState.isArabic) "حذف الملف المحول؟" else "Delete Converted File?")
            },
            text = {
                Text(
                    text = if (uiState.isArabic)
                        "هل أنت متأكد من حذف ${toDelete.appName} (${toDelete.fileName}) من الذاكرة؟"
                    else
                        "Are you sure you want to delete ${toDelete.appName} (${toDelete.fileName})?"
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmDelete() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text(if (uiState.isArabic) "حذف" else "Delete")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { viewModel.cancelDelete() }) {
                    Text(if (uiState.isArabic) "إلغاء" else "Cancel")
                }
            }
        )
    }
}
