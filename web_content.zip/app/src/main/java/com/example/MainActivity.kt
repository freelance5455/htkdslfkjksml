package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.DojoTab
import com.example.ui.QuizMode
import com.example.ui.StudyDojoViewModel
import com.example.ui.components.DojoBottomNavigation
import com.example.ui.components.DojoTopBar
import com.example.ui.screens.DoubtChatScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.screens.SyllabusScreen
import com.example.ui.screens.TimerScreen
import com.example.ui.theme.StudyDojoTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      StudyDojoApp()
    }
  }
}

@Composable
fun StudyDojoApp(
  viewModel: StudyDojoViewModel = viewModel()
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  // Handle Android hardware/gesture back press
  BackHandler(enabled = uiState.currentTab != DojoTab.SYLLABUS || uiState.quizMode != QuizMode.SELECTION) {
    if (uiState.currentTab == DojoTab.QUIZ && uiState.quizMode != QuizMode.SELECTION) {
      viewModel.backToQuizSelection()
    } else {
      viewModel.switchTab(DojoTab.SYLLABUS)
    }
  }

  StudyDojoTheme(darkTheme = uiState.isDarkMode) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      topBar = {
        DojoTopBar(
          isDarkMode = uiState.isDarkMode,
          onToggleDarkMode = { viewModel.toggleDarkMode() },
          ninjaRankTitle = uiState.ninjaRank.title
        )
      },
      bottomBar = {
        DojoBottomNavigation(
          currentTab = uiState.currentTab,
          onTabSelected = { viewModel.switchTab(it) }
        )
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(top = innerPadding.calculateTopPadding())
      ) {
        when (uiState.currentTab) {
          DojoTab.SYLLABUS -> SyllabusScreen(
            uiState = uiState,
            onToggleChapter = { viewModel.toggleChapter(it) },
            onAddChapter = { subject, title -> viewModel.addCustomChapter(subject, title) },
            onRenameChapter = { id, title -> viewModel.renameChapter(id, title) },
            onDeleteChapter = { viewModel.deleteChapter(it) },
            onSelectSubjectFilter = { viewModel.filterBySubject(it) },
            onSelectStatusFilter = { viewModel.setChapterStatusFilter(it) },
            onSearchQueryChanged = { viewModel.updateSyllabusSearch(it) }
          )

          DojoTab.TIMER -> TimerScreen(
            uiState = uiState,
            onSelectSubject = { viewModel.setTimerSubject(it) },
            onSetPresetMinutes = { viewModel.setTimerPresetMinutes(it) },
            onStartTimer = { viewModel.startTimer() },
            onPauseTimer = { viewModel.pauseTimer() },
            onResumeTimer = { viewModel.resumeTimer() },
            onResetTimer = { viewModel.resetTimer() },
            onDismissDialog = { viewModel.dismissTimerDialog() }
          )

          DojoTab.QUIZ -> QuizScreen(
            uiState = uiState,
            onSelectSubject = { viewModel.setQuizSubject(it) },
            onStartQuiz = { viewModel.startQuiz(it) },
            onSelectOption = { viewModel.selectQuizOption(it) },
            onNextQuestion = { viewModel.nextQuizQuestion() },
            onViewHistory = { viewModel.viewQuizHistory() },
            onBackToSelection = { viewModel.backToQuizSelection() }
          )

          DojoTab.SENSEI_CHAT -> DoubtChatScreen(
            uiState = uiState,
            onSwitchSensei = { viewModel.switchSensei(it) },
            onChatInputChanged = { viewModel.updateChatInput(it) },
            onSendMessage = { viewModel.sendChatMessage(it) },
            onClearChat = { viewModel.clearChatHistory() }
          )

          DojoTab.STATS -> StatsScreen(
            uiState = uiState,
            onToggleDarkMode = { viewModel.toggleDarkMode() },
            onExportBackup = { viewModel.getBackupJson() },
            onRestoreBackup = { viewModel.restoreFromBackup(it) }
          )
        }
      }
    }
  }
}
