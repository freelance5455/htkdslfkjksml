package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ai.configureAppCheck
import com.example.auth.AuthScreen
import com.example.auth.authStateFlow
import com.example.auth.signOutGoogle
import com.example.ui.IchimatsuScreen
import com.example.ui.theme.IchimatsuTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch intent before any UI or ViewModels.
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            IchimatsuTheme {
                Surface {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val currentUser by Firebase.auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = Firebase.auth.currentUser)
    var isGuestMode by rememberSaveable { mutableStateOf(false) }

    val user = currentUser
    LaunchedEffect(user?.uid) {
        if (user != null) {
            isGuestMode = false
        }
    }

    when {
        user != null -> {
            key(user.uid) {
                IchimatsuScreen(
                    currentUserId = user.uid,
                    displayName = user.displayName?.takeIf { it.isNotBlank() } ?: "Friend",
                    email = user.email,
                    isGuest = false,
                    onSignOut = {
                        signOutGoogle(
                            credentialManager = credentialManager,
                            scope = scope
                        )
                    }
                )
            }
        }
        isGuestMode -> {
            key("guest") {
                IchimatsuScreen(
                    currentUserId = "guest",
                    displayName = "Guest",
                    email = null,
                    isGuest = true,
                    onSignOut = {
                        isGuestMode = false
                    }
                )
            }
        }
        else -> {
            AuthScreen(
                onAuthSuccess = {
                    isGuestMode = false
                },
                onContinueAsGuest = {
                    isGuestMode = true
                }
            )
        }
    }
}
