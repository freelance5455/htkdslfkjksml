package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CommentBottomSheet
import com.example.ui.components.GiftBottomSheet
import com.example.ui.components.ReportVideoDialog
import com.example.ui.components.ShareVideoDialog
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AuthDialog
import com.example.ui.screens.CreatorDashboardScreen
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.FeedScreen
import com.example.ui.screens.HtmlAppScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.UploadScreen
import com.example.ui.theme.ZingBlack
import com.example.ui.theme.ZingCyan
import com.example.ui.theme.ZingDarkSurface
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextMuted
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary
import com.example.ui.theme.ZingTheme
import com.example.ui.viewmodel.ZingNavTab
import com.example.ui.viewmodel.ZingViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: ZingViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ZingTheme {
                val currentNavTab by viewModel.currentNavTab.collectAsStateWithLifecycle()
                val feedVideos by viewModel.feedVideos.collectAsStateWithLifecycle()
                val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
                val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
                val notifications by viewModel.notifications.collectAsStateWithLifecycle()
                val payouts by viewModel.payouts.collectAsStateWithLifecycle()
                val reports by viewModel.reports.collectAsStateWithLifecycle()
                val allVideosAdmin by viewModel.allVideosAdmin.collectAsStateWithLifecycle()
                val likedVideos by viewModel.likedVideos.collectAsStateWithLifecycle()
                val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()

                val activeCommentVid by viewModel.activeCommentVideoId.collectAsStateWithLifecycle()
                val activeComments by viewModel.activeComments.collectAsStateWithLifecycle()
                val activeShareVid by viewModel.activeShareVideo.collectAsStateWithLifecycle()
                val activeGiftVid by viewModel.activeGiftVideo.collectAsStateWithLifecycle()
                val activeReportVid by viewModel.activeReportVideo.collectAsStateWithLifecycle()
                val viewingProfileUserId by viewModel.viewingProfileUserId.collectAsStateWithLifecycle()
                val showAuthDialog by viewModel.showAuthDialog.collectAsStateWithLifecycle()

                val commentSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
                val giftSheetState = rememberModalBottomSheetState()
                val coroutineScope = rememberCoroutineScope()

                // Back Handler
                BackHandler(enabled = currentNavTab != ZingNavTab.FEED || viewingProfileUserId != null) {
                    if (viewingProfileUserId != null) {
                        viewModel.viewingProfileUserId.value = null
                    } else {
                        viewModel.setNavTab(ZingNavTab.FEED)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = ZingBlack,
                    bottomBar = {
                        // Show bottom nav on main tabs
                        if (currentNavTab != ZingNavTab.UPLOAD && currentNavTab != ZingNavTab.ADMIN && currentNavTab != ZingNavTab.CREATOR_STUDIO && currentNavTab != ZingNavTab.WEB_FRONTEND && viewingProfileUserId == null) {
                            ZingBottomBar(
                                currentTab = currentNavTab,
                                onTabSelected = { tab ->
                                    viewModel.setNavTab(tab)
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = if (currentNavTab != ZingNavTab.UPLOAD && currentNavTab != ZingNavTab.ADMIN && currentNavTab != ZingNavTab.CREATOR_STUDIO && currentNavTab != ZingNavTab.WEB_FRONTEND && viewingProfileUserId == null) 60.dp else 0.dp)
                    ) {
                        // Check if viewing another creator's profile
                        if (viewingProfileUserId != null) {
                            val targetUser = allUsers.find { it.id == viewingProfileUserId }
                            val targetVideos = feedVideos.filter { it.creatorId == viewingProfileUserId }
                            ProfileScreen(
                                user = targetUser,
                                isCurrentUser = targetUser?.id == currentUser?.id,
                                userVideos = targetVideos,
                                likedVideos = emptyList(),
                                allUsers = allUsers,
                                onBack = { viewModel.viewingProfileUserId.value = null },
                                onFollowClick = {
                                    targetUser?.let { viewModel.toggleFollow(it.id, it.isFollowing) }
                                },
                                onOpenCreatorStudio = { viewModel.setNavTab(ZingNavTab.CREATOR_STUDIO) },
                                onOpenAdminDashboard = { viewModel.setNavTab(ZingNavTab.ADMIN) },
                                onSwitchUser = { viewModel.switchUser(it) },
                                onUpdateProfile = { name, bio -> viewModel.updateProfile(name, bio) },
                                onOpenAuthDialog = { viewModel.showAuthDialog.value = true },
                                onVideoClick = { video ->
                                    viewModel.viewingProfileUserId.value = null
                                    viewModel.setNavTab(ZingNavTab.FEED)
                                }
                            )
                        } else {
                            when (currentNavTab) {
                                ZingNavTab.FEED -> {
                                    FeedScreen(
                                        videos = feedVideos,
                                        onLikeClick = { viewModel.toggleLike(it) },
                                        onCommentClick = { viewModel.activeCommentVideoId.value = it.id },
                                        onShareClick = { viewModel.activeShareVideo.value = it },
                                        onGiftClick = { viewModel.activeGiftVideo.value = it },
                                        onFollowClick = { creatorId ->
                                            val creator = allUsers.find { it.id == creatorId }
                                            creator?.let { viewModel.toggleFollow(it.id, it.isFollowing) }
                                        },
                                        onReportClick = { viewModel.activeReportVideo.value = it },
                                        onBlockCreatorClick = { creatorId -> viewModel.blockUser(creatorId) },
                                        onCreatorProfileClick = { creatorId -> viewModel.viewingProfileUserId.value = creatorId },
                                        onOpenSearch = { viewModel.setNavTab(ZingNavTab.DISCOVER) },
                                        onOpenCreatorStudio = { viewModel.setNavTab(ZingNavTab.CREATOR_STUDIO) },
                                        onOpenWebFrontend = { viewModel.setNavTab(ZingNavTab.WEB_FRONTEND) }
                                    )
                                }
                                ZingNavTab.DISCOVER -> {
                                    DiscoverScreen(
                                        searchQuery = searchQuery,
                                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                                        videos = feedVideos,
                                        users = allUsers,
                                        onVideoClick = { video ->
                                            viewModel.setNavTab(ZingNavTab.FEED)
                                        },
                                        onCreatorClick = { creatorId -> viewModel.viewingProfileUserId.value = creatorId },
                                        onFollowClick = { creatorId, status -> viewModel.toggleFollow(creatorId, status) }
                                    )
                                }
                                ZingNavTab.UPLOAD -> {
                                    UploadScreen(
                                        onBack = { viewModel.setNavTab(ZingNavTab.FEED) },
                                        onPublish = { caption, sound, tags, cat, uri, poster, start, end ->
                                            viewModel.publishVideo(caption, sound, tags, cat, uri, poster, start, end)
                                        }
                                    )
                                }
                                ZingNavTab.NOTIFICATIONS -> {
                                    NotificationsScreen(
                                        notifications = notifications,
                                        onMarkAllRead = { viewModel.markAllNotificationsRead() }
                                    )
                                }
                                ZingNavTab.PROFILE -> {
                                    val myVideos = feedVideos.filter { it.creatorId == currentUser?.id }
                                    ProfileScreen(
                                        user = currentUser,
                                        isCurrentUser = true,
                                        userVideos = myVideos,
                                        likedVideos = likedVideos,
                                        allUsers = allUsers,
                                        onBack = null,
                                        onFollowClick = {},
                                        onOpenCreatorStudio = { viewModel.setNavTab(ZingNavTab.CREATOR_STUDIO) },
                                        onOpenAdminDashboard = { viewModel.setNavTab(ZingNavTab.ADMIN) },
                                        onSwitchUser = { viewModel.switchUser(it) },
                                        onUpdateProfile = { name, bio -> viewModel.updateProfile(name, bio) },
                                        onOpenAuthDialog = { viewModel.showAuthDialog.value = true },
                                        onVideoClick = { video ->
                                            viewModel.setNavTab(ZingNavTab.FEED)
                                        },
                                        onOpenWebFrontend = { viewModel.setNavTab(ZingNavTab.WEB_FRONTEND) }
                                    )
                                }
                                ZingNavTab.CREATOR_STUDIO -> {
                                    CreatorDashboardScreen(
                                        user = currentUser,
                                        payouts = payouts,
                                        onBack = { viewModel.setNavTab(ZingNavTab.FEED) },
                                        onRequestPayout = { amount, method, details ->
                                            viewModel.requestPayout(amount, method, details)
                                        }
                                    )
                                }
                                ZingNavTab.ADMIN -> {
                                    AdminDashboardScreen(
                                        reports = reports,
                                        videos = allVideosAdmin,
                                        payouts = payouts,
                                        users = allUsers,
                                        onBack = { viewModel.setNavTab(ZingNavTab.PROFILE) },
                                        onResolveReport = { id, takeDown, vid ->
                                            viewModel.adminResolveReport(id, takeDown, vid)
                                        },
                                        onToggleVideoTakeDown = { vid, takeDown ->
                                            viewModel.adminToggleTakeDown(vid, takeDown)
                                        },
                                        onUpdatePayoutStatus = { pid, status ->
                                            viewModel.adminUpdatePayoutStatus(pid, status)
                                        },
                                        onToggleBlockUser = { uid, blocked ->
                                            if (blocked) viewModel.blockUser(uid) else viewModel.unblockUser(uid)
                                        }
                                    )
                                }
                                ZingNavTab.WEB_FRONTEND -> {
                                    HtmlAppScreen(
                                        onBackToNative = { viewModel.setNavTab(ZingNavTab.FEED) }
                                    )
                                }
                            }
                        }

                        // --- Interactive Modal Drawers & Dialogs ---

                        // Comment Bottom Sheet
                        if (activeCommentVid != null) {
                            CommentBottomSheet(
                                comments = activeComments,
                                sheetState = commentSheetState,
                                onDismiss = {
                                    coroutineScope.launch { commentSheetState.hide() }.invokeOnCompletion {
                                        viewModel.activeCommentVideoId.value = null
                                    }
                                },
                                onSendComment = { text ->
                                    activeCommentVid?.let { viewModel.postComment(it, text) }
                                },
                                onLikeComment = { comment ->
                                    viewModel.toggleCommentLike(comment)
                                }
                            )
                        }

                        // Gift Tipping Bottom Sheet
                        if (activeGiftVid != null) {
                            GiftBottomSheet(
                                sheetState = giftSheetState,
                                userCoinBalance = currentUser?.coinBalance ?: 500,
                                creatorName = activeGiftVid?.creatorName ?: "Creator",
                                onDismiss = {
                                    coroutineScope.launch { giftSheetState.hide() }.invokeOnCompletion {
                                        viewModel.activeGiftVideo.value = null
                                    }
                                },
                                onSendGift = { gift ->
                                    activeGiftVid?.let {
                                        viewModel.sendGift(it.id, gift.name, gift.coins)
                                    }
                                }
                            )
                        }

                        // Share Dialog
                        activeShareVid?.let { video ->
                            ShareVideoDialog(
                                video = video,
                                onDismiss = { viewModel.activeShareVideo.value = null }
                            )
                        }

                        // Report Dialog
                        activeReportVid?.let { video ->
                            ReportVideoDialog(
                                video = video,
                                onDismiss = { viewModel.activeReportVideo.value = null },
                                onSubmitReport = { reason ->
                                    viewModel.submitReport(video, reason)
                                }
                            )
                        }

                        // Auth / Register Dialog
                        if (showAuthDialog) {
                            AuthDialog(
                                onDismiss = { viewModel.showAuthDialog.value = false },
                                onRegisterOrLogin = { username, name, bio ->
                                    viewModel.registerOrLogin(username, name, bio)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ZingBottomBar(
    currentTab: ZingNavTab,
    onTabSelected: (ZingNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = ZingDarkSurface.copy(alpha = 0.95f),
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Home / Feed
            BottomBarItem(
                icon = if (currentTab == ZingNavTab.FEED) Icons.Filled.Home else Icons.Outlined.Home,
                label = "Feed",
                isSelected = currentTab == ZingNavTab.FEED,
                onClick = { onTabSelected(ZingNavTab.FEED) },
                testTag = "nav_feed"
            )

            // Discover
            BottomBarItem(
                icon = if (currentTab == ZingNavTab.DISCOVER) Icons.Filled.Explore else Icons.Outlined.Explore,
                label = "Discover",
                isSelected = currentTab == ZingNavTab.DISCOVER,
                onClick = { onTabSelected(ZingNavTab.DISCOVER) },
                testTag = "nav_discover"
            )

            // Center Upload Button (+)
            Box(
                modifier = Modifier
                    .size(width = 46.dp, height = 34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(ZingCyan, ZingNeonPink)
                        )
                    )
                    .clickable { onTabSelected(ZingNavTab.UPLOAD) }
                    .testTag("nav_upload"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 40.dp, height = 28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Upload",
                        tint = ZingBlack,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Notifications
            BottomBarItem(
                icon = if (currentTab == ZingNavTab.NOTIFICATIONS) Icons.Filled.Notifications else Icons.Outlined.Notifications,
                label = "Inbox",
                isSelected = currentTab == ZingNavTab.NOTIFICATIONS,
                onClick = { onTabSelected(ZingNavTab.NOTIFICATIONS) },
                testTag = "nav_notifications"
            )

            // Profile
            BottomBarItem(
                icon = if (currentTab == ZingNavTab.PROFILE) Icons.Filled.Person else Icons.Outlined.Person,
                label = "Profile",
                isSelected = currentTab == ZingNavTab.PROFILE,
                onClick = { onTabSelected(ZingNavTab.PROFILE) },
                testTag = "nav_profile"
            )
        }
    }
}

@Composable
private fun BottomBarItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) Color.White else ZingTextSecondary,
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = label,
            color = if (isSelected) Color.White else ZingTextSecondary,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
