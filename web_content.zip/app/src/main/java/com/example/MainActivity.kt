package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.model.ThemeMode
import com.example.data.preferences.ThemePreferences
import com.example.data.repository.ProjectRepository
import com.example.ui.navigation.ProzheYarApp
import com.example.ui.theme.ProzheYarTheme
import com.example.ui.viewmodel.ProjectViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getDatabase(applicationContext)
        val preferences = ThemePreferences(applicationContext)
        val repository = ProjectRepository(database.projectDao(), preferences)
        val factory = ProjectViewModel.Factory(repository)

        setContent {
            val viewModel: ProjectViewModel = viewModel(factory = factory)
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val darkTheme = when (themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                ProzheYarTheme(darkTheme = darkTheme) {
                    ProzheYarApp(
                        viewModel = viewModel,
                        themeMode = themeMode
                    )
                }
            }
        }
    }
}
