package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.authStateFlow
import com.example.core.configureAppCheck
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.FlamiWorkspaceScreen
import com.example.ui.theme.FlamiTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure Firebase App Check with launch intent BEFORE setContent or any Firebase calls
        configureAppCheck(this, intent)

        setContent {
            FlamiTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            FlamiWorkspaceScreen(
                currentUserId = user.uid,
                initialDisplayName = user.displayName ?: user.email ?: "FLAMI User"
            )
        }
    }
}
