package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AiAuditDialog
import com.example.ui.components.AppBottomNavBar
import com.example.ui.components.AppTopBar
import com.example.ui.components.NotificationModal
import com.example.ui.components.ProjectDetailDialog
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.KeystoreScreen
import com.example.ui.screens.NewProjectScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.theme.AppBundleTheme
import com.example.ui.viewmodel.AppBundleViewModel
import com.example.ui.viewmodel.AppScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: AppBundleViewModel = viewModel()
            val isArabic by viewModel.isArabic.collectAsStateWithLifecycle()
            val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
            val projects by viewModel.projects.collectAsStateWithLifecycle()
            val keystores by viewModel.keystores.collectAsStateWithLifecycle()
            val notifications by viewModel.notifications.collectAsStateWithLifecycle()
            val unreadCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()
            val isOnline by viewModel.cloudSyncManager.isOnline.collectAsStateWithLifecycle()
            val isSyncing by viewModel.cloudSyncManager.isSyncing.collectAsStateWithLifecycle()
            val debugMode by viewModel.debugModeEnabled.collectAsStateWithLifecycle()
            val showNotifications by viewModel.showNotificationDialog.collectAsStateWithLifecycle()
            val selectedProject by viewModel.selectedProject.collectAsStateWithLifecycle()
            val activeAiAudit by viewModel.activeAiAudit.collectAsStateWithLifecycle()

            // Direction: RTL for Arabic, LTR for English
            val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

            // Back button handling
            BackHandler(enabled = selectedProject != null || showNotifications || currentScreen != AppScreen.DASHBOARD) {
                when {
                    selectedProject != null -> viewModel.setSelectedProject(null)
                    showNotifications -> viewModel.setNotificationDialogVisible(false)
                    currentScreen != AppScreen.DASHBOARD -> viewModel.setScreen(AppScreen.DASHBOARD)
                }
            }

            AppBundleTheme(darkTheme = true) {
                CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                    Scaffold(
                        topBar = {
                            AppTopBar(
                                isArabic = isArabic,
                                isOnline = isOnline,
                                isSyncing = isSyncing,
                                debugMode = debugMode,
                                unreadNotifications = unreadCount,
                                onSyncClick = { viewModel.triggerCloudSync() },
                                onLanguageClick = { viewModel.toggleLanguage() },
                                onDebugToggle = { viewModel.toggleDebugMode() },
                                onNotificationsClick = { viewModel.setNotificationDialogVisible(true) }
                            )
                        },
                        bottomBar = {
                            AppBottomNavBar(
                                currentScreen = currentScreen,
                                isArabic = isArabic,
                                onScreenSelected = { viewModel.setScreen(it) }
                            )
                        },
                        containerColor = MaterialTheme.colorScheme.background,
                        modifier = Modifier.fillMaxSize()
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.background)
                                .padding(innerPadding)
                        ) {
                            when (currentScreen) {
                                AppScreen.DASHBOARD -> DashboardScreen(
                                    viewModel = viewModel,
                                    projects = projects,
                                    isArabic = isArabic
                                )
                                AppScreen.PROJECTS -> ProjectsScreen(
                                    viewModel = viewModel,
                                    projects = projects,
                                    isArabic = isArabic
                                )
                                AppScreen.NEW_PROJECT -> NewProjectScreen(
                                    viewModel = viewModel,
                                    keystores = keystores,
                                    isArabic = isArabic
                                )
                                AppScreen.KEYSTORES -> KeystoreScreen(
                                    viewModel = viewModel,
                                    keystores = keystores,
                                    isArabic = isArabic
                                )
                                AppScreen.TOOLS -> ToolsScreen(
                                    viewModel = viewModel,
                                    isArabic = isArabic
                                )
                            }
                        }

                        // Project Inspector Dialog
                        if (selectedProject != null) {
                            ProjectDetailDialog(
                                project = selectedProject!!,
                                isArabic = isArabic,
                                onDismiss = { viewModel.setSelectedProject(null) },
                                onOpenAiReport = {
                                    // Kept open or handled
                                }
                            )
                        }

                        // AI Audit Dialog
                        if (activeAiAudit != null && selectedProject != null) {
                            AiAuditDialog(
                                audit = activeAiAudit!!,
                                projectName = selectedProject!!.name,
                                isArabic = isArabic,
                                onDismiss = { viewModel.setSelectedProject(null) }
                            )
                        }

                        // Notifications Dialog
                        if (showNotifications) {
                            NotificationModal(
                                notifications = notifications,
                                isArabic = isArabic,
                                onDismiss = { viewModel.setNotificationDialogVisible(false) },
                                onMarkAllRead = { viewModel.markNotificationsAsRead() },
                                onClearAll = { viewModel.clearNotifications() }
                            )
                        }
                    }
                }
            }
        }
    }
}
