package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.attemptAutoSignIn
import com.example.auth.signOut
import com.example.data.HifzRepository
import com.example.data.SeedData
import com.example.ui.MainViewModel
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DailyReportScreen
import com.example.ui.screens.MonthlySummaryScreen
import com.example.ui.screens.StudentProfilesScreen
import com.example.ui.screens.WorkspaceSetupScreen
import com.example.ui.theme.HifzReportTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

private enum class AppSubScreen { DAILY_REPORT, MONTHLY_SUMMARY, STUDENT_PROFILES, ADMIN_PANEL }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HifzReportTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    var checkedAutoSignIn by remember { mutableStateOf(Firebase.auth.currentUser != null) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(Unit) {
        if (currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                    checkedAutoSignIn = true
                },
                onUnauthenticated = { checkedAutoSignIn = true },
                scope = scope
            )
        }
    }

    val user = currentUser
    if (!checkedAutoSignIn) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else if (user == null) {
        AuthScreen(onAuthSuccess = { currentUser = Firebase.auth.currentUser })
    } else {
        val uid = user.uid
        val email = user.email ?: ""
        key(uid) {
            AuthenticatedContent(
                uid = uid,
                email = email,
                onSignOut = {
                    signOut(credentialManager, scope) {
                        currentUser = null
                    }
                }
            )
        }
    }
}

@Composable
private fun AuthenticatedContent(
    uid: String,
    email: String,
    onSignOut: () -> Unit
) {
    val viewModel: MainViewModel = viewModel(
        key = uid,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                MainViewModel(
                    repository = HifzRepository(app),
                    currentUserId = uid,
                    currentUserEmail = email
                )
            }
        }
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val attendanceFilter by viewModel.attendanceFilter.collectAsStateWithLifecycle()
    val pendingInvite by viewModel.pendingInvite.collectAsStateWithLifecycle()
    val summaryClassId by viewModel.summaryClassId.collectAsStateWithLifecycle()
    val summaryYearMonth by viewModel.summaryYearMonth.collectAsStateWithLifecycle()
    val monthlySummaryState by viewModel.monthlySummaryState.collectAsStateWithLifecycle()
    val adminSelectedClassId by viewModel.adminSelectedClassId.collectAsStateWithLifecycle()
    val adminStudents by viewModel.adminStudents.collectAsStateWithLifecycle()
    val adminSavedDates by viewModel.adminSavedDates.collectAsStateWithLifecycle()
    val adminInvites by viewModel.adminInvites.collectAsStateWithLifecycle()
    val adminPin by viewModel.adminPin.collectAsStateWithLifecycle()
    val classPins by viewModel.classPins.collectAsStateWithLifecycle()
    val backupJson by viewModel.backupJson.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf(AppSubScreen.DAILY_REPORT) }

    when {
        uiState.isBootstrapping -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    CircularProgressIndicator()
                    Text("لوڈ ہو رہا ہے…", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        uiState.needsWorkspaceSetup -> {
            WorkspaceSetupScreen(
                userEmail = email,
                isLoading = uiState.isBootstrapping,
                errorMessage = uiState.errorMessage,
                pendingInvite = pendingInvite,
                onCheckInvite = viewModel::checkPendingInvite,
                onAcceptInvite = viewModel::acceptPendingInvite,
                onJoinWithPin = viewModel::joinSchoolWithPin,
                onCreateWorkspace = viewModel::createNewWorkspace,
                onSignOut = onSignOut
            )
        }
        else -> {
            when (currentScreen) {
                AppSubScreen.DAILY_REPORT -> {
                    DailyReportScreen(
                        uiState = uiState,
                        searchQuery = searchQuery,
                        attendanceFilter = attendanceFilter,
                        onSearchQueryChange = viewModel::setSearchQuery,
                        onFilterChange = viewModel::setAttendanceFilter,
                        onSelectClass = viewModel::switchClass,
                        onSelectDate = viewModel::selectDate,
                        onUpdateAttendance = viewModel::updateAttendance,
                        onUpdateField = viewModel::updateStudentTextField,
                        onSelectSotd = viewModel::updateStudentOfTheDay,
                        onMarkAllPresent = viewModel::markAllPresent,
                        onOpenMonthlySummary = { currentScreen = AppSubScreen.MONTHLY_SUMMARY },
                        onOpenStudentProfiles = { currentScreen = AppSubScreen.STUDENT_PROFILES },
                        onOpenAdmin = { currentScreen = AppSubScreen.ADMIN_PANEL },
                        onSwitchRoleOrSignOut = onSignOut,
                        onClearToast = viewModel::clearToast,
                        onClearError = viewModel::clearError
                    )
                }
                AppSubScreen.STUDENT_PROFILES -> {
                    StudentProfilesScreen(
                        isAdmin = uiState.member?.role == "admin",
                        classes = uiState.classes,
                        selectedClassId = uiState.selectedClassId,
                        students = uiState.students,
                        toastMessage = uiState.toastMessage,
                        errorMessage = uiState.errorMessage,
                        onSelectClass = viewModel::switchClass,
                        onAddStudentProfile = viewModel::addStudentProfileForCurrentClass,
                        onUpdateStudentProfile = viewModel::updateStudentProfileForCurrentClass,
                        onMoveStudent = viewModel::moveStudentForCurrentClass,
                        onDeleteStudent = viewModel::deleteStudentForCurrentClass,
                        onClearToast = viewModel::clearToast,
                        onClearError = viewModel::clearError,
                        onBack = { currentScreen = AppSubScreen.DAILY_REPORT }
                    )
                }
                AppSubScreen.MONTHLY_SUMMARY -> {
                    MonthlySummaryScreen(
                        title = uiState.school?.title ?: SeedData.DEFAULT_TITLE,
                        centre = uiState.school?.centre ?: SeedData.DEFAULT_CENTRE,
                        isAdmin = uiState.member?.role == "admin",
                        classes = uiState.classes,
                        selectedClassId = summaryClassId,
                        yearMonth = summaryYearMonth,
                        summaryState = monthlySummaryState,
                        onSelectClass = viewModel::setSummaryClassId,
                        onChangeMonth = viewModel::setSummaryYearMonth,
                        onBack = { currentScreen = AppSubScreen.DAILY_REPORT }
                    )
                }
                AppSubScreen.ADMIN_PANEL -> {
                    val school = uiState.school
                    if (school != null && uiState.member?.role == "admin") {
                        AdminPanelScreen(
                            school = school,
                            classes = uiState.classes,
                            classPins = classPins,
                            adminPin = adminPin,
                            selectedClassId = adminSelectedClassId,
                            students = adminStudents,
                            savedDates = adminSavedDates,
                            invites = adminInvites,
                            backupJson = backupJson,
                            onLoadSecrets = viewModel::loadAdminSecrets,
                            onSaveHeading = viewModel::saveHeading,
                            onSelectClass = viewModel::selectAdminClass,
                            onAddClass = viewModel::addClass,
                            onRenameClass = viewModel::renameClass,
                            onUpdateClassPin = viewModel::updateClassPin,
                            onDeleteClass = viewModel::deleteClass,
                            onAddStudent = viewModel::addStudent,
                            onRenameStudent = viewModel::renameStudent,
                            onMoveStudent = viewModel::moveStudent,
                            onDeleteStudent = viewModel::deleteStudent,
                            onOpenSavedSheet = viewModel::openSavedSheet,
                            onDeleteSavedSheet = viewModel::deleteSavedSheet,
                            onAddInvite = viewModel::addInvite,
                            onRemoveInvite = viewModel::removeInvite,
                            onUpdateAdminPin = viewModel::updateAdminPin,
                            onExportBackup = viewModel::exportBackup,
                            onBack = { currentScreen = AppSubScreen.DAILY_REPORT }
                        )
                    } else {
                        currentScreen = AppSubScreen.DAILY_REPORT
                    }
                }
            }
        }
    }
}
