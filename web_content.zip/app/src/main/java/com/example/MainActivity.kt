package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localization.PanchangStrings
import com.example.model.DailyPanchang
import com.example.model.MuhuratCategory
import com.example.notification.NotificationHelper
import com.example.ui.MainViewModel
import com.example.ui.components.AddReminderDialog
import com.example.ui.components.AllOptionsScreen
import com.example.ui.components.CalendarMonthGrid
import com.example.ui.components.ChoghadiyaScreen
import com.example.ui.components.DayDetailsModalSheet
import com.example.ui.components.DayPanchangDetailsView
import com.example.ui.components.FeedbackDialog
import com.example.ui.components.MonthYearPickerDialog
import com.example.ui.components.PanchakBichhudaScreen
import com.example.ui.components.QuickLanguageDialog
import com.example.ui.components.QuickOptionsGrid
import com.example.ui.components.RashifalScreen
import com.example.ui.components.RemindersScreen
import com.example.ui.components.SmartToolsScreen
import com.example.ui.components.TopVedicBar
import com.example.ui.components.VivahMuhuratScreen
import com.example.ui.components.VratKathaScreen
import com.example.ui.components.WebCalendarViewScreen
import com.example.ui.theme.VedicCalendarTheme
import java.util.Calendar

data class NavigationTabItem(
    val index: Int,
    val titleKey: String,
    val icon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.createNotificationChannel(this)

        setContent {
            val selectedTheme by viewModel.selectedTheme.collectAsStateWithLifecycle()
            val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
            val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
            val selectedMuhuratCategory by viewModel.selectedMuhuratCategory.collectAsStateWithLifecycle()
            val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
            val viewMonth by viewModel.viewMonth.collectAsStateWithLifecycle()
            val currentPanchang by viewModel.currentPanchang.collectAsStateWithLifecycle()
            val reminders by viewModel.reminders.collectAsStateWithLifecycle()
            val showAddReminderDialog by viewModel.showAddReminderDialog.collectAsStateWithLifecycle()
            val showThemeDialog by viewModel.showThemeDialog.collectAsStateWithLifecycle()
            val showLanguageDialog by viewModel.showLanguageDialog.collectAsStateWithLifecycle()

            val context = LocalContext.current

            var showDayDetailsSheet by remember { mutableStateOf(false) }
            var showMonthYearPicker by remember { mutableStateOf(false) }
            var showFeedbackDialog by remember { mutableStateOf(false) }

            val permissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { isGranted ->
                if (isGranted) {
                    Toast.makeText(context, "सूचनाएं सक्रिय हो गईं", Toast.LENGTH_SHORT).show()
                }
            }

            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            var dialogInitialDate by remember { mutableStateOf(currentPanchang.dateString) }
            var dialogInitialTitle by remember { mutableStateOf("") }
            var dialogInitialCategory by remember { mutableStateOf("PERSONAL") }

            val allTabs = listOf(
                NavigationTabItem(0, "tab_calendar", Icons.Default.CalendarMonth, "nav_tab_calendar"),
                NavigationTabItem(1, "tab_options", Icons.Default.Widgets, "nav_tab_options")
            )

            VedicCalendarTheme(selectedTheme = selectedTheme) {
                BackHandler(enabled = selectedTab != 0) {
                    if (selectedTab >= 2) {
                        viewModel.setTab(1)
                    } else {
                        viewModel.setTab(0)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = Color.White,
                    topBar = {
                        TopVedicBar(
                            panchang = currentPanchang,
                            language = selectedLanguage,
                            onLanguageClick = { viewModel.setShowLanguageDialog(true) },
                            onFeedbackClick = { showFeedbackDialog = true }
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = Color.White,
                            tonalElevation = 3.dp,
                            modifier = Modifier.testTag("bottom_nav_bar")
                        ) {
                            allTabs.forEach { tabItem ->
                                val isSelected = if (tabItem.index == 1) selectedTab >= 1 else selectedTab == 0
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { viewModel.setTab(tabItem.index) },
                                    icon = { Icon(tabItem.icon, contentDescription = null) },
                                    label = {
                                        Text(
                                            text = PanchangStrings.get(selectedLanguage, tabItem.titleKey),
                                            maxLines = 1,
                                            fontSize = 11.5.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.Black,
                                        unselectedIconColor = Color(0xFF666666),
                                        selectedTextColor = Color.Black,
                                        unselectedTextColor = Color(0xFF666666),
                                        indicatorColor = Color(0xFFEEEEEE)
                                    ),
                                    modifier = Modifier.testTag(tabItem.testTag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.White)
                            .padding(innerPadding)
                    ) {
                        when (selectedTab) {
                            0 -> {
                                // Main Screen: Clean Vedic Calendar + Selected Day Full Panchang + Clean Link to Options
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White)
                                        .verticalScroll(rememberScrollState())
                                        .padding(bottom = 16.dp)
                                ) {
                                    // 1. Month Calendar Grid (100% responsive, equal-width 7 columns)
                                    CalendarMonthGrid(
                                        viewMonth = viewMonth,
                                        selectedDate = selectedDate,
                                        language = selectedLanguage,
                                        onDateSelected = { cal ->
                                            viewModel.selectDate(cal)
                                        },
                                        onPreviousMonth = { viewModel.changeMonth(-1) },
                                        onNextMonth = { viewModel.changeMonth(1) },
                                        onTodayClick = { viewModel.jumpToToday() },
                                        onMonthYearClick = { showMonthYearPicker = true }
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // 2. Comprehensive Daily Vedic Panchang details for the selected date
                                    DayPanchangDetailsView(
                                        panchang = currentPanchang,
                                        language = selectedLanguage,
                                        onAddReminderClick = {
                                            dialogInitialDate = currentPanchang.dateString
                                            dialogInitialTitle = "${currentPanchang.tithiName} (${currentPanchang.paksha.name})"
                                            dialogInitialCategory = "TITHI"
                                            viewModel.setShowAddReminderDialog(true)
                                        }
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    // 3. Clean Card: सभी विकल्प एवं सुविधाएं (Opens Options Hub)
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp)
                                            .clickable { viewModel.setTab(1) }
                                            .testTag("home_open_options_btn"),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA)),
                                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                        shape = RoundedCornerShape(14.dp),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(42.dp)
                                                        .clip(CircleShape)
                                                        .background(Color.Black),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Widgets,
                                                        contentDescription = null,
                                                        tint = Color.White,
                                                        modifier = Modifier.size(22.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(
                                                        text = "पंचांग के सभी विकल्प एवं सेवाएं",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp,
                                                        color = Color.Black
                                                    )
                                                    Text(
                                                        text = "चौघड़िया, मुहूर्त, पंचक, राशिफल, स्मार्ट उपकरण",
                                                        fontSize = 11.5.sp,
                                                        color = Color(0xFF555555)
                                                    )
                                                }
                                            }
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                                contentDescription = "Open Options",
                                                tint = Color.Black,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            1 -> {
                                // Comprehensive Options Hub (सभी विकल्प व सेवाएं अंदर)
                                AllOptionsScreen(
                                    currentPanchang = currentPanchang,
                                    language = selectedLanguage,
                                    onNavigateToChoghadiya = { viewModel.setTab(2) },
                                    onNavigateToMuhurat = {
                                        viewModel.openMuhuratCategory(null)
                                        viewModel.setTab(3)
                                    },
                                    onNavigateToMakanUdghatan = {
                                        viewModel.openMuhuratCategory(MuhuratCategory.GRIHA_PRAVESH)
                                        viewModel.setTab(3)
                                    },
                                    onNavigateToOfficeUdghatan = {
                                        viewModel.openMuhuratCategory(MuhuratCategory.OFFICE_UDGHATAN)
                                        viewModel.setTab(3)
                                    },
                                    onNavigateToPanchak = { viewModel.setTab(4) },
                                    onNavigateToRashifal = { viewModel.setTab(5) },
                                    onNavigateToVratKatha = { viewModel.setTab(6) },
                                    onNavigateToReminders = { viewModel.setTab(7) },
                                    onNavigateToSmartTools = { viewModel.setTab(8) },
                                    onNavigateToWebApp = { viewModel.setTab(9) },
                                    onOpenLanguageDialog = { viewModel.setShowLanguageDialog(true) },
                                    onOpenMonthYearPicker = { showMonthYearPicker = true },
                                    onOpenFeedback = { showFeedbackDialog = true }
                                )
                            }

                            2 -> {
                                // Sub-screen: Choghadiya with Top Back Header
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { viewModel.setTab(1) }) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                contentDescription = "Back",
                                                tint = Color.Black
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "चौघड़िया मुहूर्त (Choghadiya)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                    ChoghadiyaScreen(
                                        panchang = currentPanchang,
                                        language = selectedLanguage,
                                        onSetChoghadiyaReminder = { item ->
                                            dialogInitialDate = currentPanchang.dateString
                                            dialogInitialTitle = "${item.name} चौघड़िया (${item.nature})"
                                            dialogInitialCategory = "CHOGHADIYA"
                                            viewModel.setShowAddReminderDialog(true)
                                        }
                                    )
                                }
                            }

                            3 -> {
                                // Sub-screen: Muhurat with Top Back Header
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { viewModel.setTab(1) }) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                contentDescription = "Back",
                                                tint = Color.Black
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "शुभ मुहूर्त (Shubh Muhurat)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                    VivahMuhuratScreen(
                                        language = selectedLanguage,
                                        initialCategory = selectedMuhuratCategory,
                                        onCategoryChanged = { category -> viewModel.setMuhuratCategory(category) },
                                        onSetReminder = { muhurat ->
                                            dialogInitialDate = muhurat.dateString
                                            dialogInitialTitle = "${muhurat.auspiciousLagna} ${muhurat.tithi}"
                                            dialogInitialCategory = when (muhurat.category) {
                                                MuhuratCategory.GRIHA_PRAVESH -> "GRIHA_PRAVESH"
                                                MuhuratCategory.OFFICE_UDGHATAN -> "OFFICE_UDGHATAN"
                                                MuhuratCategory.VIVAH -> "VIVAH"
                                                else -> "MUHURAT"
                                            }
                                            viewModel.setShowAddReminderDialog(true)
                                        }
                                    )
                                }
                            }

                            4 -> {
                                // Sub-screen: Panchak with Top Back Header
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { viewModel.setTab(1) }) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                contentDescription = "Back",
                                                tint = Color.Black
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "पंचक एवं बिछुड़ा विवरण (Panchak)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                    PanchakBichhudaScreen(
                                        panchang = currentPanchang,
                                        language = selectedLanguage,
                                        onSetPanchakReminder = {
                                            dialogInitialDate = currentPanchang.dateString
                                            dialogInitialTitle = "पंचक आरंभ सूचना"
                                            dialogInitialCategory = "PANCHAK"
                                            viewModel.setShowAddReminderDialog(true)
                                        },
                                        onSetBichhudaReminder = {
                                            dialogInitialDate = currentPanchang.dateString
                                            dialogInitialTitle = "बिछुड़ा (वृश्चिक चंद्र) सूचना"
                                            dialogInitialCategory = "BICHHUDA"
                                            viewModel.setShowAddReminderDialog(true)
                                        }
                                    )
                                }
                            }

                            5 -> {
                                // Detailed Rashifal Screen with Top Back Header
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { viewModel.setTab(1) }) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                contentDescription = "Back",
                                                tint = Color.Black
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "दैनिक राशिफल (Daily Horoscope)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                    RashifalScreen(language = selectedLanguage)
                                }
                            }

                            6 -> {
                                // Detailed Vrat Katha Screen with Top Back Header
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { viewModel.setTab(1) }) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                contentDescription = "Back",
                                                tint = Color.Black
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "प्रमुख व्रत कथाएं व नियम (Vrat Katha)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                    VratKathaScreen(language = selectedLanguage)
                                }
                            }

                            7 -> {
                                // Detailed Reminders & Vrats Screen with Top Back Header
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(onClick = { viewModel.setTab(1) }) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                contentDescription = "Back",
                                                tint = Color.Black
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "स्मरण एवं व्रत अलर्ट (Reminders)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Black
                                        )
                                    }
                                    RemindersScreen(
                                        reminders = reminders,
                                        language = selectedLanguage,
                                        onAddReminderClick = {
                                            dialogInitialDate = currentPanchang.dateString
                                            dialogInitialTitle = ""
                                            dialogInitialCategory = "PERSONAL"
                                            viewModel.setShowAddReminderDialog(true)
                                        },
                                        onToggleReminder = { viewModel.toggleReminder(it, context) },
                                        onDeleteReminder = { viewModel.deleteReminder(it, context) },
                                        onSendTestNotification = {
                                            viewModel.sendTestNotification(context)
                                            Toast.makeText(context, "परीक्षण अलर्ट भेजा गया!", Toast.LENGTH_SHORT).show()
                                        },
                                        onQuickAddVrat = { name, dateStr ->
                                            viewModel.quickAddVratReminder(name, dateStr, context)
                                            Toast.makeText(context, "$name अनुस्मारक जोड़ा गया!", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                }
                            }

                            8 -> {
                                // Smart Vedic Tools & Instruments Hub (स्मार्ट वैदिक उपकरण)
                                SmartToolsScreen(
                                    currentPanchang = currentPanchang,
                                    language = selectedLanguage,
                                    onBack = { viewModel.setTab(1) }
                                )
                            }

                            9 -> {
                                // Standalone single-file HTML5 Web App View (index.html)
                                WebCalendarViewScreen(
                                    onBack = { viewModel.setTab(1) }
                                )
                            }
                        }
                    }

                    if (showDayDetailsSheet) {
                        DayDetailsModalSheet(
                            panchang = currentPanchang,
                            language = selectedLanguage,
                            onDismiss = { showDayDetailsSheet = false },
                            onAddReminder = {
                                showDayDetailsSheet = false
                                dialogInitialDate = currentPanchang.dateString
                                dialogInitialTitle = "${currentPanchang.tithiName} (${currentPanchang.paksha.name})"
                                dialogInitialCategory = "TITHI"
                                viewModel.setShowAddReminderDialog(true)
                            }
                        )
                    }

                    if (showAddReminderDialog) {
                        AddReminderDialog(
                            initialDate = dialogInitialDate,
                            initialTitle = dialogInitialTitle,
                            initialCategory = dialogInitialCategory,
                            language = selectedLanguage,
                            onDismiss = { viewModel.setShowAddReminderDialog(false) },
                            onConfirm = { title, desc, date, category ->
                                viewModel.addReminder(
                                    title = title,
                                    description = desc,
                                    targetDate = date,
                                    category = category,
                                    context = context
                                )
                                Toast.makeText(context, "अनुस्मारक सुरक्षित किया गया", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }

                    if (showLanguageDialog) {
                        QuickLanguageDialog(
                            currentLanguage = selectedLanguage,
                            onDismiss = { viewModel.setShowLanguageDialog(false) },
                            onSelectLanguage = { viewModel.setLanguage(it) }
                        )
                    }

                    if (showMonthYearPicker) {
                        MonthYearPickerDialog(
                            currentCalendar = viewMonth,
                            onDismiss = { showMonthYearPicker = false },
                            onConfirm = { year, month ->
                                viewModel.selectMonthYear(year, month)
                                showMonthYearPicker = false
                            }
                        )
                    }

                    if (showFeedbackDialog) {
                        FeedbackDialog(
                            onDismissRequest = { showFeedbackDialog = false }
                        )
                    }
                }
            }
        }
    }
}
