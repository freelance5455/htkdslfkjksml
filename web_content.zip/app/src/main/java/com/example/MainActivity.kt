package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.ThemePreferencesStore
import com.example.core.attemptAutoSignIn
import com.example.core.authStateFlow
import com.example.core.configureAppCheck
import com.example.data.repository.LocalGuestStore
import com.example.ui.screens.FlamiWorkspaceScreen
import com.example.ui.theme.FlamiTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure Firebase App Check with launch intent BEFORE setContent or any Firebase calls
        configureAppCheck(this, intent)

        setContent {
            val context = LocalContext.current
            val themeStore = remember(context) { ThemePreferencesStore(context.applicationContext) }
            val appearance by themeStore.appearanceFlow.collectAsStateWithLifecycle()

            FlamiTheme(
                designSystem = appearance.designSystem,
                classicThemeMode = appearance.classicThemeMode
            ) {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val auth = Firebase.auth
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

    // Silently restore an existing authorized Google session in the background if available,
    // without ever blocking direct access to the chat workspace.
    LaunchedEffect(Unit) {
        if (auth.currentUser == null) {
            attemptAutoSignIn(
                context = context,
                credentialManager = credentialManager,
                onAuthSuccess = {},
                onUnauthenticated = {},
                scope = scope
            )
        }
    }

    val user = currentUser
    val sessionKey = user?.uid ?: LocalGuestStore.GUEST_UID
    key(sessionKey) {
        FlamiWorkspaceScreen(
            isSignedIn = user != null,
            currentUserId = sessionKey,
            initialDisplayName = user?.displayName ?: user?.email ?: "FLAMI Guest"
        )
    }
}
