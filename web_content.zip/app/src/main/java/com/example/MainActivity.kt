package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.game.GameScreen
import com.example.ui.game.GameViewModel
import com.example.ui.menu.LevelSelectScreen
import com.example.ui.menu.MainTitleScreen
import com.example.ui.theme.MyApplicationTheme

sealed class Screen {
    object Title : Screen()
    object LevelSelect : Screen()
    data class Game(val stage: Int) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val gameViewModel: GameViewModel = viewModel()
                var currentScreen by remember { mutableStateOf<Screen>(Screen.Title) }

                when (val screen = currentScreen) {
                    is Screen.Title -> {
                        MainTitleScreen(
                            onStartGame = { currentScreen = Screen.Game(1) },
                            onSelectStage = { currentScreen = Screen.LevelSelect }
                        )
                    }
                    is Screen.LevelSelect -> {
                        LevelSelectScreen(
                            onStageSelected = { stage -> currentScreen = Screen.Game(stage) },
                            onBack = { currentScreen = Screen.Title }
                        )
                    }
                    is Screen.Game -> {
                        GameScreen(
                            stage = screen.stage,
                            viewModel = gameViewModel,
                            onBack = { currentScreen = Screen.Title }
                        )
                    }
                }
            }
        }
    }
}
