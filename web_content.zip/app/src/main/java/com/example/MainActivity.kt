package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.SignalPhase
import com.example.ui.components.SettingsDialog
import com.example.ui.components.StreetSimulationView
import com.example.ui.components.TrafficControlPanel
import com.example.ui.components.TrafficEducationView
import com.example.ui.components.TrafficLightDisplay
import com.example.ui.components.TrafficQuizView
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TrafficGreen
import com.example.ui.theme.TrafficRed
import com.example.ui.theme.TrafficYellow
import com.example.viewmodel.TrafficLightViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true, dynamicColor = false) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    TrafficApp()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrafficApp(
    viewModel: TrafficLightViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showSettingsDialog by remember { mutableStateOf(false) }

    if (showSettingsDialog) {
        SettingsDialog(
            currentConfig = uiState.config,
            onDismiss = { showSettingsDialog = false },
            onSave = { newConfig -> viewModel.updateConfig(newConfig) }
        )
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D1117)),
        containerColor = Color(0xFF0D1117),
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF131822),
                contentColor = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("main_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = uiState.selectedTab == 0,
                    onClick = { viewModel.setSelectedTab(0) },
                    icon = { Icon(Icons.Default.Traffic, contentDescription = null) },
                    label = { Text("إشارة المرور", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TrafficGreen,
                        selectedTextColor = TrafficGreen,
                        indicatorColor = Color(0xFF1E2838),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_tab_traffic")
                )

                NavigationBarItem(
                    selected = uiState.selectedTab == 1,
                    onClick = { viewModel.setSelectedTab(1) },
                    icon = { Icon(Icons.Default.DirectionsCar, contentDescription = null) },
                    label = { Text("المحاكاة", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF29B6F6),
                        selectedTextColor = Color(0xFF29B6F6),
                        indicatorColor = Color(0xFF1E2838),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_tab_simulation")
                )

                NavigationBarItem(
                    selected = uiState.selectedTab == 2,
                    onClick = { viewModel.setSelectedTab(2) },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = null) },
                    label = { Text("الإرشادات", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TrafficYellow,
                        selectedTextColor = TrafficYellow,
                        indicatorColor = Color(0xFF1E2838),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_tab_education")
                )

                NavigationBarItem(
                    selected = uiState.selectedTab == 3,
                    onClick = { viewModel.setSelectedTab(3) },
                    icon = { Icon(Icons.Default.Quiz, contentDescription = null) },
                    label = { Text("الاختبار", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFFAB47BC),
                        selectedTextColor = Color(0xFFAB47BC),
                        indicatorColor = Color(0xFF1E2838),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    ),
                    modifier = Modifier.testTag("nav_tab_quiz")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Header Bar
            AppHeader(
                currentPhase = uiState.currentPhase,
                secondsRemaining = uiState.secondsRemaining
            )

            // Content Area based on Tab
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                when (uiState.selectedTab) {
                    0 -> {
                        // Main Traffic Light and Controls
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            TrafficLightDisplay(
                                currentPhase = uiState.currentPhase,
                                secondsRemaining = uiState.secondsRemaining,
                                operatingMode = uiState.operatingMode,
                                isNightFlashOn = uiState.isNightFlashOn,
                                pedestrianState = uiState.pedestrianState,
                                isPedestrianRequested = uiState.isPedestrianRequested,
                                pedestrianSecondsRemaining = uiState.pedestrianSecondsRemaining,
                                onLampClick = { phase -> viewModel.manualSelectPhase(phase) },
                                onPedestrianButtonClick = { viewModel.requestPedestrianCrossing() }
                            )

                            TrafficControlPanel(
                                currentPhase = uiState.currentPhase,
                                secondsRemaining = uiState.secondsRemaining,
                                operatingMode = uiState.operatingMode,
                                isPaused = uiState.isPaused,
                                config = uiState.config,
                                onModeChange = { mode -> viewModel.setOperatingMode(mode) },
                                onTogglePause = { viewModel.togglePause() },
                                onManualPhaseSelect = { phase -> viewModel.manualSelectPhase(phase) },
                                onNextPhase = { viewModel.nextPhaseManual() },
                                onOpenSettings = { showSettingsDialog = true },
                                onToggleSound = {
                                    viewModel.updateConfig(
                                        uiState.config.copy(soundEnabled = !uiState.config.soundEnabled)
                                    )
                                },
                                onToggleVibrate = {
                                    viewModel.updateConfig(
                                        uiState.config.copy(vibrationEnabled = !uiState.config.vibrationEnabled)
                                    )
                                }
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    1 -> {
                        // Street Simulation Tab
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            StreetSimulationView(
                                currentPhase = uiState.currentPhase,
                                pedestrianState = uiState.pedestrianState,
                                cars = uiState.cars,
                                pedestrians = uiState.pedestrians,
                                onSpawnCar = { viewModel.spawnNewCar() }
                            )

                            // Quick mini controls while watching simulation
                            TrafficControlPanel(
                                currentPhase = uiState.currentPhase,
                                secondsRemaining = uiState.secondsRemaining,
                                operatingMode = uiState.operatingMode,
                                isPaused = uiState.isPaused,
                                config = uiState.config,
                                onModeChange = { mode -> viewModel.setOperatingMode(mode) },
                                onTogglePause = { viewModel.togglePause() },
                                onManualPhaseSelect = { phase -> viewModel.manualSelectPhase(phase) },
                                onNextPhase = { viewModel.nextPhaseManual() },
                                onOpenSettings = { showSettingsDialog = true },
                                onToggleSound = {
                                    viewModel.updateConfig(
                                        uiState.config.copy(soundEnabled = !uiState.config.soundEnabled)
                                    )
                                },
                                onToggleVibrate = {
                                    viewModel.updateConfig(
                                        uiState.config.copy(vibrationEnabled = !uiState.config.vibrationEnabled)
                                    )
                                }
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }

                    2 -> {
                        // Traffic Education Tab
                        TrafficEducationView()
                    }

                    3 -> {
                        // Traffic Quiz Tab
                        TrafficQuizView(
                            questions = viewModel.quizQuestions,
                            currentIndex = uiState.currentQuizIndex,
                            selectedAnswer = uiState.selectedQuizAnswer,
                            score = uiState.quizScore,
                            isFinished = uiState.isQuizFinished,
                            onSelectOption = { index -> viewModel.selectQuizOption(index) },
                            onNextQuestion = { viewModel.nextQuizQuestion() },
                            onResetQuiz = { viewModel.resetQuiz() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AppHeader(
    currentPhase: SignalPhase,
    secondsRemaining: Int,
    modifier: Modifier = Modifier
) {
    val phaseColor = when (currentPhase) {
        SignalPhase.RED -> TrafficRed
        SignalPhase.YELLOW, SignalPhase.RED_YELLOW, SignalPhase.FLASHING_YELLOW -> TrafficYellow
        SignalPhase.GREEN -> TrafficGreen
        else -> Color.Gray
    }

    Surface(
        color = Color(0xFF131822),
        modifier = modifier.fillMaxWidth(),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222B3B))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF263345), Color(0xFF18202C))
                            )
                        )
                        .border(1.dp, Color(0xFF3B4A61), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Traffic,
                        contentDescription = null,
                        tint = phaseColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column {
                    Text(
                        text = "إشارة المرور الذكية",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = currentPhase.titleAr,
                        style = MaterialTheme.typography.bodySmall,
                        color = phaseColor,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Seconds badge
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF1E2838),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334257))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(phaseColor)
                    )
                    Text(
                        text = "$secondsRemaining ثانية",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
