package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.AuthScreen
import com.example.auth.GoogleAuthHelper
import com.example.data.MarketplaceRepository
import com.example.localization.AppLang
import com.example.localization.LanguageStore
import com.example.localization.SjsStrings
import com.example.model.*
import com.example.ui.components.SmartJonesTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.viewmodel.MarketplaceViewModel
import com.example.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

private enum class MainTab {
    HOME,
    ORDERS,
    PROVIDER,
    ADMIN,
    PROFILE
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmartJonesTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val context = LocalContext.current
    val languageStore = remember(context) { LanguageStore(context.applicationContext) }
    val lang by languageStore.languageFlow.collectAsStateWithLifecycle(initialValue = AppLang.SW)
    val scope = rememberCoroutineScope()

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(
            lang = lang,
            onToggleLang = {
                val next = if (lang == AppLang.SW) AppLang.EN else AppLang.SW
                scope.launch { languageStore.setLanguage(next) }
            },
            onAuthSuccess = { currentUser = Firebase.auth.currentUser }
        )
    } else {
        val uid = user.uid
        val email = user.email ?: ""
        val isAdmin = user.isEmailVerified && email.equals(MarketplaceConstants.ADMIN_EMAIL, ignoreCase = true)

        key(uid) {
            val viewModel: MarketplaceViewModel = viewModel(
                key = uid,
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY]) {
                            "APPLICATION_KEY missing from CreationExtras"
                        }
                        val databaseId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(databaseId)
                        MarketplaceViewModel(
                            repository = MarketplaceRepository(db),
                            languageStore = LanguageStore(app),
                            currentUserId = uid,
                            currentUserEmail = email,
                            isAdminUser = isAdmin
                        )
                    }
                }
            )
            MainMarketplaceShell(viewModel = viewModel)
        }
    }
}

@Composable
private fun MainMarketplaceShell(viewModel: MarketplaceViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val lang by viewModel.language.collectAsStateWithLifecycle()
    val activeRole by viewModel.activeRole.collectAsStateWithLifecycle()
    val filters by viewModel.filters.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val feedback by viewModel.feedbackMessage.collectAsStateWithLifecycle()

    val userProfileState by viewModel.userProfile.collectAsStateWithLifecycle()
    val providersState by viewModel.providersState.collectAsStateWithLifecycle()
    val servicesState by viewModel.servicesState.collectAsStateWithLifecycle()
    val filteredProviders by viewModel.filteredProviders.collectAsStateWithLifecycle()
    val filteredServices by viewModel.filteredServices.collectAsStateWithLifecycle()
    val myProvider by viewModel.myProvider.collectAsStateWithLifecycle()

    val customerOrdersState by viewModel.customerOrdersState.collectAsStateWithLifecycle()
    val providerOrdersState by viewModel.providerOrdersState.collectAsStateWithLifecycle()
    val customerPaymentsState by viewModel.customerPaymentsState.collectAsStateWithLifecycle()
    val providerPaymentsState by viewModel.providerPaymentsState.collectAsStateWithLifecycle()
    val customerComplaintsState by viewModel.customerComplaintsState.collectAsStateWithLifecycle()

    val adminUsersState by viewModel.adminUsersState.collectAsStateWithLifecycle()
    val adminOrdersState by viewModel.adminOrdersState.collectAsStateWithLifecycle()
    val adminPaymentsState by viewModel.adminPaymentsState.collectAsStateWithLifecycle()
    val adminComplaintsState by viewModel.adminComplaintsState.collectAsStateWithLifecycle()
    val adminAuditLogsState by viewModel.adminAuditLogsState.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(MainTab.HOME) }
    var selectedProvider by remember { mutableStateOf<SecurityProvider?>(null) }
    var preselectedService by remember { mutableStateOf<SecurityServiceListing?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedback) {
        feedback?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearFeedback()
        }
    }

    val userProfile = (userProfileState as? UiState.Success)?.data
    val allProviders = (providersState as? UiState.Success)?.data ?: emptyList()
    val allServices = (servicesState as? UiState.Success)?.data ?: emptyList()
    val customerPayments = (customerPaymentsState as? UiState.Success)?.data ?: emptyList()
    val providerPayments = (providerPaymentsState as? UiState.Success)?.data ?: emptyList()
    val customerComplaints = (customerComplaintsState as? UiState.Success)?.data ?: emptyList()

    Scaffold(
        topBar = {
            SmartJonesTopBar(
                lang = lang,
                activeRole = activeRole,
                onToggleLang = {
                    viewModel.setLanguage(if (lang == AppLang.SW) AppLang.EN else AppLang.SW)
                },
                onRoleBadgeClick = {
                    selectedProvider = null
                    currentTab = when (activeRole) {
                        ActiveAppRole.CUSTOMER -> {
                            viewModel.setActiveRole(ActiveAppRole.PROVIDER)
                            MainTab.PROVIDER
                        }
                        ActiveAppRole.PROVIDER -> {
                            if (viewModel.isAdminUser) {
                                viewModel.setActiveRole(ActiveAppRole.ADMIN)
                                MainTab.ADMIN
                            } else {
                                viewModel.setActiveRole(ActiveAppRole.CUSTOMER)
                                MainTab.HOME
                            }
                        }
                        ActiveAppRole.ADMIN -> {
                            viewModel.setActiveRole(ActiveAppRole.CUSTOMER)
                            MainTab.HOME
                        }
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = PureWhite,
                contentColor = NavyDeep
            ) {
                NavigationBarItem(
                    selected = currentTab == MainTab.HOME,
                    onClick = {
                        selectedProvider = null
                        preselectedService = null
                        viewModel.setActiveRole(ActiveAppRole.CUSTOMER)
                        currentTab = MainTab.HOME
                    },
                    icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                    label = { Text(SjsStrings.t(lang, "Nyumbani", "Home")) },
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = currentTab == MainTab.ORDERS,
                    onClick = {
                        selectedProvider = null
                        currentTab = MainTab.ORDERS
                    },
                    icon = { Icon(Icons.Filled.Assignment, contentDescription = null) },
                    label = { Text(SjsStrings.t(lang, "Oda", "Orders")) },
                    modifier = Modifier.testTag("nav_orders")
                )
                NavigationBarItem(
                    selected = currentTab == MainTab.PROVIDER,
                    onClick = {
                        selectedProvider = null
                        viewModel.setActiveRole(ActiveAppRole.PROVIDER)
                        currentTab = MainTab.PROVIDER
                    },
                    icon = { Icon(Icons.Filled.Business, contentDescription = null) },
                    label = { Text(SjsStrings.t(lang, "Kampuni", "Provider")) },
                    modifier = Modifier.testTag("nav_provider")
                )
                if (viewModel.isAdminUser) {
                    NavigationBarItem(
                        selected = currentTab == MainTab.ADMIN,
                        onClick = {
                            selectedProvider = null
                            viewModel.setActiveRole(ActiveAppRole.ADMIN)
                            currentTab = MainTab.ADMIN
                        },
                        icon = { Icon(Icons.Filled.AdminPanelSettings, contentDescription = null) },
                        label = { Text("Admin") },
                        modifier = Modifier.testTag("nav_admin")
                    )
                }
                NavigationBarItem(
                    selected = currentTab == MainTab.PROFILE,
                    onClick = {
                        selectedProvider = null
                        currentTab = MainTab.PROFILE
                    },
                    icon = { Icon(Icons.Filled.Person, contentDescription = null) },
                    label = { Text(SjsStrings.t(lang, "Akaunti", "Account")) },
                    modifier = Modifier.testTag("nav_profile")
                )
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            val detailProv = selectedProvider
            if (detailProv != null) {
                CompanyDetailScreen(
                    provider = detailProv,
                    services = allServices,
                    userProfile = userProfile,
                    lang = lang,
                    initialService = preselectedService,
                    isBusy = busy,
                    onBack = {
                        selectedProvider = null
                        preselectedService = null
                    },
                    onSubmitOrderRequest = { name, phone, srv, cat, title, loc, desc, photos ->
                        viewModel.submitOrderRequest(
                            customerName = name,
                            customerPhone = phone,
                            provider = detailProv,
                            service = srv,
                            category = cat,
                            serviceTitle = title,
                            location = loc,
                            requirementDescription = desc,
                            attachmentPreviews = photos
                        ) {
                            selectedProvider = null
                            preselectedService = null
                            currentTab = MainTab.ORDERS
                        }
                    }
                )
            } else {
                when (currentTab) {
                    MainTab.HOME -> CustomerHomeScreen(
                        lang = lang,
                        filters = filters,
                        providersState = providersState,
                        servicesState = servicesState,
                        filteredProviders = filteredProviders,
                        filteredServices = filteredServices,
                        isAdminUser = viewModel.isAdminUser,
                        onUpdateFilters = viewModel::updateFilters,
                        onSelectProvider = { prov ->
                            preselectedService = null
                            selectedProvider = prov
                        },
                        onBookService = { prov, srv ->
                            preselectedService = srv
                            selectedProvider = prov
                        },
                        onOpenSupportComplaint = { currentTab = MainTab.PROFILE },
                        onBootstrapCatalog = viewModel::bootstrapStarterCatalog
                    )

                    MainTab.ORDERS -> OrdersAndChatScreen(
                        lang = lang,
                        isProviderMode = activeRole == ActiveAppRole.PROVIDER,
                        currentUserId = viewModel.currentUserId,
                        userProfile = userProfile,
                        ordersState = if (activeRole == ActiveAppRole.PROVIDER) providerOrdersState else customerOrdersState,
                        payments = (customerPayments + providerPayments).distinctBy { it.id },
                        providers = allProviders,
                        isBusy = busy,
                        observeMessages = viewModel::observeOrderMessages,
                        onMarkReceived = viewModel::markOrderReceived,
                        onSubmitQuotation = viewModel::submitQuotation,
                        onAcceptQuotation = viewModel::acceptQuotation,
                        onInitiatePayment = { order, phone, onCreated ->
                            viewModel.initiateOrderPayment(
                                order = order,
                                payerName = userProfile?.fullName ?: "Mteja",
                                payerPhone = phone,
                                onCreated = onCreated
                            )
                        },
                        onVerifyPaymentCallback = { tx -> viewModel.verifyPaymentCallback(tx) },
                        onMarkDelivered = viewModel::markServiceDelivered,
                        onConfirmCompletion = viewModel::confirmCompletionAndClose,
                        onCancelOrder = viewModel::cancelOrder,
                        onDisputeOrder = viewModel::disputeOrder,
                        onRateOrder = viewModel::rateOrder,
                        onSendMessage = { order, text ->
                            viewModel.sendOrderMessage(
                                order = order,
                                senderName = userProfile?.fullName?.ifBlank { viewModel.currentUserEmail } ?: viewModel.currentUserEmail,
                                text = text
                            )
                        }
                    )

                    MainTab.PROVIDER -> ProviderConsoleScreen(
                        lang = lang,
                        myProvider = myProvider,
                        services = allServices,
                        providerOrders = (providerOrdersState as? UiState.Success)?.data ?: emptyList(),
                        userProfile = userProfile,
                        isBusy = busy,
                        onRegisterProvider = { name, desc, cats, locs, price, brela, psra, phone, rev, logo, gallery ->
                            viewModel.registerProvider(name, desc, cats, locs, price, brela, psra, phone, rev, logo, gallery)
                        },
                        onSwitchRevenueModel = viewModel::switchRevenueModel,
                        onCreateService = { prov, cat, title, desc, price, unit, loc, badge, disc ->
                            viewModel.createServiceListing(prov, cat, title, desc, price, unit, loc, badge, disc)
                        },
                        onDeleteService = viewModel::deleteServiceListing,
                        onInitiateSubscriptionPayment = { prov, phone, onCreated ->
                            viewModel.initiateSubscriptionPayment(prov, prov.companyName, phone, onCreated)
                        },
                        onVerifySubscriptionPayment = { tx -> viewModel.verifyPaymentCallback(tx) },
                        onOpenProviderOrders = {
                            viewModel.setActiveRole(ActiveAppRole.PROVIDER)
                            currentTab = MainTab.ORDERS
                        }
                    )

                    MainTab.ADMIN -> AdminDashboardScreen(
                        lang = lang,
                        usersState = adminUsersState,
                        providersState = providersState,
                        ordersState = adminOrdersState,
                        paymentsState = adminPaymentsState,
                        complaintsState = adminComplaintsState,
                        auditLogsState = adminAuditLogsState,
                        isBusy = busy,
                        onVerifyProvider = viewModel::verifyProviderByAdmin,
                        onCollectCommission = viewModel::markCommissionCollected,
                        onVerifyPayment = { tx -> viewModel.verifyPaymentCallback(tx) },
                        onResolveComplaint = viewModel::resolveComplaint,
                        onBootstrapCatalog = viewModel::bootstrapStarterCatalog
                    )

                    MainTab.PROFILE -> ProfileSupportScreen(
                        lang = lang,
                        currentUserEmail = viewModel.currentUserEmail,
                        isAdminUser = viewModel.isAdminUser,
                        activeRole = activeRole,
                        userProfileState = userProfileState,
                        payments = customerPayments,
                        complaints = customerComplaints,
                        isBusy = busy,
                        onSwitchRole = { role ->
                            viewModel.setActiveRole(role)
                            currentTab = when (role) {
                                ActiveAppRole.CUSTOMER -> MainTab.HOME
                                ActiveAppRole.PROVIDER -> MainTab.PROVIDER
                                ActiveAppRole.ADMIN -> MainTab.ADMIN
                            }
                        },
                        onSetLanguage = viewModel::setLanguage,
                        onUpdateProfile = { name, phone, region, address ->
                            viewModel.updateUserProfile(name, phone, region, address)
                        },
                        onSubmitComplaint = { subject, desc ->
                            viewModel.submitComplaint(
                                customerName = userProfile?.fullName ?: viewModel.currentUserEmail,
                                subject = subject,
                                description = desc
                            )
                        },
                        onSignOut = {
                            GoogleAuthHelper.signOut(credentialManager, scope)
                        }
                    )
                }
            }
        }
    }
}
