package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.data.repository.VaultRepository
import com.example.ui.navigation.VaultDestination
import com.example.ui.screens.CreatePdfScreen
import com.example.ui.screens.FileRecordingScreen
import com.example.ui.screens.InformationScreen
import com.example.ui.screens.InformationStorageScreen
import com.example.ui.screens.MainScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.ViewPdfScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SilverLight

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val repository = remember { VaultRepository(applicationContext) }
                YmSecretApp(repository = repository)
            }
        }
    }
}

@Composable
fun YmSecretApp(repository: VaultRepository) {
    val backStack = remember { mutableStateListOf<VaultDestination>(VaultDestination.Splash) }
    val currentScreen = backStack.lastOrNull() ?: VaultDestination.Main

    fun popBackStack() {
        if (backStack.size > 1) {
            backStack.removeAt(backStack.lastIndex)
        }
    }

    // System Back Gesture handling matching the X button
    BackHandler(enabled = backStack.size > 1 && currentScreen !is VaultDestination.Splash) {
        popBackStack()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SilverLight)
    ) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                if (initialState is VaultDestination.Splash) {
                    fadeIn() togetherWith fadeOut()
                } else {
                    (slideInHorizontally { width -> width / 3 } + fadeIn()) togetherWith
                            (slideOutHorizontally { width -> -width / 3 } + fadeOut())
                }
            },
            label = "ScreenTransition"
        ) { destination ->
            when (destination) {
                is VaultDestination.Splash -> {
                    SplashScreen(
                        onSplashFinished = {
                            backStack.clear()
                            backStack.add(VaultDestination.Main)
                        }
                    )
                }

                is VaultDestination.Main -> {
                    MainScreen(
                        onNavigateToSection = { targetDestination ->
                            backStack.add(targetDestination)
                        }
                    )
                }

                is VaultDestination.FileRecording -> {
                    FileRecordingScreen(
                        repository = repository,
                        onBack = { popBackStack() }
                    )
                }

                is VaultDestination.Information -> {
                    InformationScreen(
                        repository = repository,
                        onBack = { popBackStack() }
                    )
                }

                is VaultDestination.CreatePdf -> {
                    CreatePdfScreen(
                        repository = repository,
                        onBack = { popBackStack() },
                        onPdfCreated = {
                            // After creating PDF, navigate directly to View PDFs
                            backStack.add(VaultDestination.ViewPdfs)
                        }
                    )
                }

                is VaultDestination.ViewPdfs -> {
                    ViewPdfScreen(
                        repository = repository,
                        onBack = { popBackStack() }
                    )
                }

                is VaultDestination.InformationStorage -> {
                    InformationStorageScreen(
                        repository = repository,
                        onBack = { popBackStack() }
                    )
                }
            }
        }
    }
}
