package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ToolsScreen
import com.example.ui.screens.VoiceScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCodeBackground
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceElevated
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusVioletLight
import com.example.ui.theme.SpaceGroteskFontFamily
import kotlinx.coroutines.launch

enum class AppScreen {
    CHAT,
    VOICE,
    TOOLS,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.util.configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NexusApp()
            }
        }
    }
}

@Composable
fun NexusApp(viewModel: MainViewModel = viewModel()) {
    var currentScreen by remember { mutableStateOf(AppScreen.CHAT) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val sessions by viewModel.allSessions.collectAsStateWithLifecycle()
    val currentSessionId by viewModel.currentSessionId.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var chatSearchQuery by remember { mutableStateOf("") }

    val filteredSessions = remember(sessions, chatSearchQuery) {
        if (chatSearchQuery.isBlank()) sessions
        else sessions.filter {
            it.title.contains(chatSearchQuery, ignoreCase = true) ||
                it.lastMessagePreview.contains(chatSearchQuery, ignoreCase = true)
        }
    }

    BackHandler(enabled = drawerState.isOpen || currentScreen != AppScreen.CHAT) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else {
            currentScreen = AppScreen.CHAT
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = NexusSurface,
                drawerContentColor = NexusTextPrimary,
                modifier = Modifier.width(304.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Top Search & New Chat Row (ChatGPT / Claude Sidebar style)
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = NexusCodeBackground,
                            border = BorderStroke(0.8.dp, NexusBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TextField(
                                value = chatSearchQuery,
                                onValueChange = { chatSearchQuery = it },
                                placeholder = {
                                    Text(
                                        text = "Поиск чатов...",
                                        fontSize = 13.5.sp,
                                        color = NexusTextTertiary
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.Search,
                                        contentDescription = null,
                                        tint = NexusTextTertiary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Search
                                ),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = NexusTextPrimary,
                                    unfocusedTextColor = NexusTextPrimary,
                                    cursorColor = NexusVioletLight
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("sidebar_search_input")
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        SidebarSectionRow(
                            title = "Новый чат",
                            icon = Icons.Outlined.Add,
                            selected = false,
                            accent = true,
                            onClick = {
                                viewModel.startNewChat()
                                currentScreen = AppScreen.CHAT
                                scope.launch { drawerState.close() }
                            },
                            tag = "sidebar_new_chat_button"
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        SidebarSectionRow(
                            title = "Чат",
                            icon = Icons.AutoMirrored.Outlined.Chat,
                            selected = currentScreen == AppScreen.CHAT,
                            accent = false,
                            onClick = {
                                currentScreen = AppScreen.CHAT
                                scope.launch { drawerState.close() }
                            },
                            tag = "sidebar_chat_item"
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        SidebarSectionRow(
                            title = "Голосовой помощник",
                            icon = Icons.Outlined.GraphicEq,
                            selected = currentScreen == AppScreen.VOICE,
                            accent = false,
                            onClick = {
                                currentScreen = AppScreen.VOICE
                                scope.launch { drawerState.close() }
                            },
                            tag = "sidebar_voice_item"
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        SidebarSectionRow(
                            title = "Инструменты",
                            icon = Icons.Outlined.GridView,
                            selected = currentScreen == AppScreen.TOOLS,
                            accent = false,
                            onClick = {
                                currentScreen = AppScreen.TOOLS
                                scope.launch { drawerState.close() }
                            },
                            tag = "sidebar_tools_item"
                        )
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    // Chronological Chats List
                    Text(
                        text = "Чаты",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextTertiary,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
                    )

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        items(filteredSessions, key = { it.id }) { session ->
                            val isActive = session.id == currentSessionId && currentScreen == AppScreen.CHAT
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isActive) NexusSurfaceElevated else Color.Transparent)
                                    .clickable {
                                        viewModel.selectSession(session.id)
                                        currentScreen = AppScreen.CHAT
                                        scope.launch { drawerState.close() }
                                    }
                                    .padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp)
                                    .testTag("sidebar_session_${session.id}"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = session.title,
                                    fontSize = 13.5.sp,
                                    fontWeight = if (isActive) FontWeight.Medium else FontWeight.Normal,
                                    color = if (isActive) NexusTextPrimary else NexusTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { viewModel.deleteSession(session.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.DeleteOutline,
                                        contentDescription = "Удалить диалог",
                                        tint = NexusTextTertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    // Sticky Bottom Profile -> Settings Footer (exact ChatGPT & Claude placement)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                currentScreen = AppScreen.SETTINGS
                                scope.launch { drawerState.close() }
                            }
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                            .testTag("sidebar_settings_item"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(NexusCyanDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = settings.assistantName.take(1).uppercase(),
                                fontFamily = SpaceGroteskFontFamily,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NexusVioletLight
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = settings.assistantName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = NexusTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Настройки • ${settings.effectiveGeminiModelTitle()}",
                                fontSize = 11.sp,
                                color = NexusTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = "Настройки",
                            tint = NexusTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NexusBackground)
        ) {
            when (currentScreen) {
                AppScreen.CHAT -> ChatScreen(
                    viewModel = viewModel,
                    onOpenSidebar = { scope.launch { drawerState.open() } }
                )
                AppScreen.VOICE -> VoiceScreen(
                    viewModel = viewModel,
                    onNavigateToChat = { currentScreen = AppScreen.CHAT },
                    onOpenSettings = { currentScreen = AppScreen.SETTINGS }
                )
                AppScreen.TOOLS -> ToolsScreen(
                    viewModel = viewModel,
                    onNavigateToChat = { currentScreen = AppScreen.CHAT },
                    onNavigateToVoice = { currentScreen = AppScreen.VOICE },
                    onNavigateToSettings = { currentScreen = AppScreen.SETTINGS }
                )
                AppScreen.SETTINGS -> SettingsScreen(
                    viewModel = viewModel,
                    onBack = { currentScreen = AppScreen.CHAT }
                )
            }
        }
    }
}

@Composable
private fun SidebarSectionRow(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    accent: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                when {
                    selected -> NexusSurfaceVariant
                    accent -> NexusCyanDark.copy(alpha = 0.72f)
                    else -> Color.Transparent
                }
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = when {
                selected || accent -> NexusVioletLight
                else -> NexusTextSecondary
            },
            modifier = Modifier.size(19.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = if (selected || accent) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected || accent) NexusTextPrimary else NexusTextSecondary
        )
    }
}
