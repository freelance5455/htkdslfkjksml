package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AdminPinDialog
import com.example.ui.components.AlQaedBottomBar
import com.example.ui.components.AlQaedHeader
import com.example.ui.components.StudentLoginDialog
import com.example.ui.components.StudentRegisterDialog
import com.example.ui.components.UserProfileDialog
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.CourseDetailScreen
import com.example.ui.screens.CoursesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LessonDetailScreen
import com.example.ui.screens.StudentDashboardScreen
import com.example.ui.theme.AlQaedTheme
import com.example.ui.viewmodel.PlatformViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: PlatformViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            // Force Arabic Right-to-Left (RTL) Layout Direction
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                AlQaedTheme {
                    MainScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun MainScreen(viewModel: PlatformViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val courses by viewModel.courses.collectAsStateWithLifecycle()
    val lessons by viewModel.lessons.collectAsStateWithLifecycle()
    val announcements by viewModel.announcements.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val registeredUsers by viewModel.registeredUsers.collectAsStateWithLifecycle()
    val supabaseUrl by viewModel.supabaseUrl.collectAsStateWithLifecycle()
    val supabaseKey by viewModel.supabaseKey.collectAsStateWithLifecycle()

    val showLoginDialog by viewModel.showLoginDialog.collectAsStateWithLifecycle()
    val showRegisterDialog by viewModel.showRegisterDialog.collectAsStateWithLifecycle()
    val showAdminPinDialog by viewModel.showAdminPinDialog.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

    var showProfileDialog by remember { mutableStateOf(false) }

    // Toast feedback listener
    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    // Android back navigation handling
    val canNavigateBack = currentScreen !is Screen.Home
    BackHandler(enabled = canNavigateBack) {
        viewModel.navigateBack()
    }

    Scaffold(
        topBar = {
            AlQaedHeader(
                currentUser = currentUser,
                canNavigateBack = canNavigateBack,
                onBackClick = { viewModel.navigateBack() },
                onProfileClick = {
                    if (currentUser != null) {
                        showProfileDialog = true
                    } else {
                        viewModel.setLoginDialog(true)
                    }
                },
                onAdminClick = {
                    if (currentUser?.role == "admin") {
                        viewModel.navigateTo(Screen.AdminDashboard)
                    } else {
                        viewModel.setAdminPinDialog(true)
                    }
                }
            )
        },
        bottomBar = {
            AlQaedBottomBar(
                currentScreen = currentScreen,
                onTabSelected = { target ->
                    if (target is Screen.AdminDashboard && currentUser?.role != "admin") {
                        viewModel.setAdminPinDialog(true)
                    } else {
                        viewModel.navigateTo(target)
                    }
                }
            )
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC))
        ) {
            when (val screen = currentScreen) {
                is Screen.Home -> {
                    HomeScreen(
                        courses = courses,
                        lessons = lessons,
                        announcements = announcements,
                        currentUser = currentUser,
                        onCourseClick = { courseId -> viewModel.openCourse(courseId) },
                        onNavigateToCourses = { viewModel.navigateTo(Screen.Courses) },
                        onNavigateToStudent = { viewModel.navigateTo(Screen.StudentDashboard) },
                        onNavigateToAdmin = {
                            if (currentUser?.role == "admin") viewModel.navigateTo(Screen.AdminDashboard)
                            else viewModel.setAdminPinDialog(true)
                        },
                        onOpenRegister = { viewModel.setRegisterDialog(true) }
                    )
                }

                is Screen.Courses -> {
                    CoursesScreen(
                        courses = courses,
                        lessons = lessons,
                        onCourseClick = { courseId -> viewModel.openCourse(courseId) }
                    )
                }

                is Screen.CourseDetail -> {
                    val course = courses.find { it.id == screen.courseId }
                    CourseDetailScreen(
                        course = course,
                        lessons = lessons,
                        currentUser = currentUser,
                        onBack = { viewModel.navigateBack() },
                        onLessonClick = { lessonId -> viewModel.openLesson(lessonId) },
                        onEnrollClick = { courseId -> viewModel.enrollInCourse(courseId) },
                        onOpenRegister = { viewModel.setRegisterDialog(true) }
                    )
                }

                is Screen.LessonDetail -> {
                    val lesson = lessons.find { it.id == screen.lessonId }
                    val course = courses.find { it.id == lesson?.courseId }
                    LessonDetailScreen(
                        lesson = lesson,
                        course = course,
                        onBack = { viewModel.navigateBack() },
                        onNotifyMe = {
                            viewModel.showToast("تم تفعيل إشعار نزول المحاضرة على هاتفك بنجاح ✓")
                        }
                    )
                }

                is Screen.StudentDashboard -> {
                    StudentDashboardScreen(
                        currentUser = currentUser,
                        courses = courses,
                        lessons = lessons,
                        announcements = announcements,
                        onCourseClick = { courseId -> viewModel.openCourse(courseId) },
                        onLoginClick = { viewModel.setLoginDialog(true) },
                        onRegisterClick = { viewModel.setRegisterDialog(true) },
                        onLogoutClick = { viewModel.logout() }
                    )
                }

                is Screen.AdminDashboard -> {
                    AdminDashboardScreen(
                        courses = courses,
                        lessons = lessons,
                        announcements = announcements,
                        registeredUsers = registeredUsers,
                        supabaseUrl = supabaseUrl,
                        supabaseKey = supabaseKey,
                        onAddLesson = { cId, t, st, d, v, p ->
                            viewModel.addLesson(cId, t, st, d, v, p)
                        },
                        onUpdateLesson = { updated ->
                            viewModel.updateLesson(updated)
                        },
                        onDeleteLesson = { id ->
                            viewModel.deleteLesson(id)
                        },
                        onToggleLessonPublish = { id ->
                            viewModel.toggleLessonPublish(id)
                        },
                        onToggleCoursePublish = { id ->
                            viewModel.toggleCoursePublish(id)
                        },
                        onDeleteCourse = { id ->
                            viewModel.deleteCourse(id)
                        },
                        onAddAnnouncement = { t, c, p ->
                            viewModel.addAnnouncement(t, c, p)
                        },
                        onDeleteAnnouncement = { id ->
                            viewModel.deleteAnnouncement(id)
                        },
                        onSaveSupabaseConfig = { u, k ->
                            viewModel.saveSupabaseConfig(u, k)
                        },
                        onExitAdmin = {
                            viewModel.navigateTo(Screen.Home)
                        }
                    )
                }
            }
        }
    }

    // Dialogs
    if (showLoginDialog) {
        StudentLoginDialog(
            onDismiss = { viewModel.setLoginDialog(false) },
            onLogin = { phone, pass -> viewModel.loginStudent(phone, pass) },
            onSwitchToRegister = {
                viewModel.setLoginDialog(false)
                viewModel.setRegisterDialog(true)
            }
        )
    }

    if (showRegisterDialog) {
        StudentRegisterDialog(
            onDismiss = { viewModel.setRegisterDialog(false) },
            onRegister = { name, phone, stage, pass ->
                viewModel.registerStudent(name, phone, stage, pass)
            },
            onSwitchToLogin = {
                viewModel.setRegisterDialog(false)
                viewModel.setLoginDialog(true)
            }
        )
    }

    if (showAdminPinDialog) {
        AdminPinDialog(
            onDismiss = { viewModel.setAdminPinDialog(false) },
            onSubmitPin = { pin -> viewModel.loginAdmin(pin) }
        )
    }

    if (showProfileDialog && currentUser != null) {
        UserProfileDialog(
            user = currentUser!!,
            onDismiss = { showProfileDialog = false },
            onLogout = {
                showProfileDialog = false
                viewModel.logout()
            }
        )
    }
}
