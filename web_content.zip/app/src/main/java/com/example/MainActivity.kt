package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppDatabase
import com.example.data.model.AppConfigSettings
import com.example.data.model.User
import com.example.data.repository.AuthRepository
import com.example.data.repository.FirestoreRepository
import com.example.data.repository.LeaderboardFilter
import com.example.ui.components.AppTopBar
import com.example.ui.components.MenuBottomSheet
import com.example.ui.components.RewardedAdOverlay
import com.example.ui.screens.BlockedScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageFinderGameDialog
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SuperOfferDialog
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.QuestRewardsTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

enum class AppTab(val title: String) {
    HOME("Home"),
    TASKS("Tasks"),
    LEADERBOARD("Leaderboard"),
    WALLET("Wallet")
}

class MainActivity : ComponentActivity() {
    private lateinit var authRepository: AuthRepository
    private lateinit var firestoreRepository: FirestoreRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        authRepository = AuthRepository(this)
        firestoreRepository = FirestoreRepository(this)

        setContent {
            QuestRewardsTheme {
                MainApp(
                    authRepository = authRepository,
                    firestoreRepository = firestoreRepository
                )
            }
        }
    }
}

@Composable
fun MainApp(
    authRepository: AuthRepository,
    firestoreRepository: FirestoreRepository
) {
    val scope = rememberCoroutineScope()
    // Synchronous immediate check for zero-loading screen delay
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)

        // Attempt silent background sign in only if not logged in
        if (currentUser == null) {
            authRepository.attemptAutoSignIn(
                scope = scope,
                onAuthSuccess = { user -> currentUser = user },
                onUnauthenticated = { /* Stay on login screen */ }
            )
        }

        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0D0B16))) {
        if (currentUser == null) {
            LoginScreen(
                authRepository = authRepository,
                onLoginSuccess = { currentUser = Firebase.auth.currentUser }
            )
        } else {
            val uid = currentUser!!.uid
            key(uid) {
                AuthenticatedApp(
                    firebaseUser = currentUser!!,
                    authRepository = authRepository,
                    firestoreRepository = firestoreRepository
                )
            }
        }

        // Global Rewarded Ad overlay on top of everything
        RewardedAdOverlay()
    }
}

@Composable
fun AuthenticatedApp(
    firebaseUser: FirebaseUser,
    authRepository: AuthRepository,
    firestoreRepository: FirestoreRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val localDb = remember { AppDatabase.getInstance(context) }

    // Start with quick local fallback user for instant render
    var userState by remember {
        mutableStateOf(
            User(
                uid = firebaseUser.uid,
                displayName = firebaseUser.displayName ?: "",
                email = firebaseUser.email ?: "",
                photoUrl = firebaseUser.photoUrl?.toString(),
                coins = 0L,
                gems = 0L
            )
        )
    }

    // Synchronous initial Room read & Firestore sync
    LaunchedEffect(firebaseUser.uid) {
        // 1. Fast local read
        val localUser = localDb.userDao().getUser(firebaseUser.uid)
        if (localUser != null) {
            userState = userState.copy(
                displayName = localUser.displayName.ifBlank { userState.displayName },
                coins = localUser.coins,
                gems = localUser.gems,
                dailyCoins = localUser.dailyCoins,
                weeklyCoins = localUser.weeklyCoins,
                isBlocked = localUser.isBlocked
            )
        }

        // 2. Real-time Firestore sync
        firestoreRepository.syncUserProfile(
            displayName = firebaseUser.displayName ?: "Quest Player",
            email = firebaseUser.email ?: "",
            photoUrl = firebaseUser.photoUrl?.toString()
        ).catch { e ->
            // Handled in repository logger
        }.collect { updatedUser ->
            userState = updatedUser
        }
    }

    // Blocked User Protection
    if (userState.isBlocked) {
        BlockedScreen(
            onLogoutClick = {
                authRepository.signOut(scope) {
                    scope.launch { firestoreRepository.clearLocalData() }
                }
            }
        )
        return
    }

    // App State
    var currentTab by remember { mutableStateOf(AppTab.HOME) }
    var showMenuSheet by remember { mutableStateOf(false) }
    var showImageFinderDialog by remember { mutableStateOf(false) }
    var showSuperOfferDialog by remember { mutableStateOf(false) }

    // App Economy settings
    var appSettings by remember { mutableStateOf(AppConfigSettings()) }
    LaunchedEffect(Unit) {
        firestoreRepository.observeAppSettings().collect { appSettings = it }
    }

    // Tasks & Categories state
    var selectedCategory by remember { mutableStateOf("ALL") }
    val tasksState by firestoreRepository.observeTasks(selectedCategory)
        .collectAsState(initial = emptyList())
    val categoriesState by firestoreRepository.observeCategories()
        .collectAsState(initial = emptyList())

    // Leaderboard state
    var leaderboardFilter by remember { mutableStateOf(LeaderboardFilter.ALL_TIME) }
    val leaderboardUsers by firestoreRepository.observeLeaderboard(leaderboardFilter)
        .collectAsState(initial = emptyList())

    // Payout methods & withdrawals
    val payoutMethods by firestoreRepository.observePayoutMethods()
        .collectAsState(initial = emptyList())
    val userWithdrawals by firestoreRepository.observeUserWithdrawals()
        .collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            AppTopBar(
                coins = userState.coins,
                gems = userState.gems,
                onMenuClick = { showMenuSheet = true },
                onCoinsClick = { currentTab = AppTab.WALLET },
                onGemsClick = { showImageFinderDialog = true }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                AppTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    val icon = when (tab) {
                        AppTab.HOME -> Icons.Default.Home
                        AppTab.TASKS -> Icons.Default.TaskAlt
                        AppTab.LEADERBOARD -> Icons.Default.EmojiEvents
                        AppTab.WALLET -> Icons.Default.AccountBalanceWallet
                    }
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = tab.title,
                                tint = if (isSelected) GoldPrimary else Color.Gray
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                color = if (isSelected) GoldPrimary else Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = GoldPrimary.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppTab.HOME -> {
                    HomeScreen(
                        user = userState,
                        settings = appSettings,
                        onPlayImageFinder = { showImageFinderDialog = true },
                        onOpenSuperOffer = { showSuperOfferDialog = true },
                        onNavigateToTasks = { currentTab = AppTab.TASKS },
                        onNavigateToLeaderboard = { currentTab = AppTab.LEADERBOARD },
                        onNavigateToWallet = { currentTab = AppTab.WALLET }
                    )
                }
                AppTab.TASKS -> {
                    TasksScreen(
                        tasks = tasksState,
                        categories = categoriesState,
                        selectedCategory = selectedCategory,
                        onCategorySelected = { selectedCategory = it },
                        onClaimReward = { task ->
                            firestoreRepository.claimTaskReward(task.rewardCoins)
                        }
                    )
                }
                AppTab.LEADERBOARD -> {
                    LeaderboardScreen(
                        currentUserId = userState.uid,
                        topUsers = leaderboardUsers,
                        selectedFilter = leaderboardFilter,
                        onFilterSelected = { leaderboardFilter = it }
                    )
                }
                AppTab.WALLET -> {
                    WalletScreen(
                        user = userState,
                        settings = appSettings,
                        payoutMethods = payoutMethods,
                        withdrawals = userWithdrawals,
                        onRequestWithdrawal = { method, accountDetail ->
                            firestoreRepository.submitWithdrawal(
                                userName = userState.displayName.ifBlank { "Player" },
                                userEmail = userState.email,
                                payoutMethod = method,
                                accountDetail = accountDetail
                            )
                        }
                    )
                }
            }
        }
    }

    // Image Finder Game Dialog
    if (showImageFinderDialog) {
        ImageFinderGameDialog(
            onDismiss = { showImageFinderDialog = false },
            onGemEarned = {
                scope.launch {
                    firestoreRepository.awardGameGem()
                }
            }
        )
    }

    // Super Offer Dialog
    if (showSuperOfferDialog) {
        SuperOfferDialog(
            userGems = userState.gems,
            requiredGems = appSettings.superOfferUnlockGems,
            rewardCoins = appSettings.superOfferUnlockCoins,
            onDismiss = { showSuperOfferDialog = false },
            onUnlockWithGems = {
                firestoreRepository.completeSuperOffer(
                    requiredGems = appSettings.superOfferUnlockGems,
                    rewardCoins = appSettings.superOfferUnlockCoins
                )
            }
        )
    }

    // Hamburger Menu Bottom Sheet
    if (showMenuSheet) {
        MenuBottomSheet(
            user = userState,
            onDismiss = { showMenuSheet = false },
            onLogoutClick = {
                authRepository.signOut(scope) {
                    scope.launch {
                        firestoreRepository.clearLocalData()
                    }
                }
            },
            onNavigateToWallet = {
                currentTab = AppTab.WALLET
            }
        )
    }
}
