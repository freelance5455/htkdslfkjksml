package com.example

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private var speechRecognizer: SpeechRecognizer? = null
    private var speechEnabled = false

    private val photoPicker = registerForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris -> uris.forEach { sendUriToJs(it) } }

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> uris.forEach { sendUriToJs(it) } }

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) captureCamera()
        else js("window.onNativeVoiceError && window.onNativeVoiceError('Kamera izni verilmedi.')")
    }

    private val cameraPreview = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) sendBitmapToJs(bitmap)
    }

    private val audioPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoiceInternal()
        else js("window.onNativeVoiceError && window.onNativeVoiceError('Mikrofon izni verilmedi.')")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        val html = assets.open("index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
        webView.loadDataWithBaseURL(
            "https://suesa.local/",
            html,
            "text/html",
            "UTF-8",
            null
        )
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun pickPhotos() {
            runOnUiThread {
                firstUseConfirm("Fotoğraflar", "Fotoğraf seçicisini açmak için devam edelim mi?") {
                    photoPicker.launch(
                        androidx.activity.result.PickVisualMediaRequest(
                            ActivityResultContracts.PickVisualMedia.ImageOnly
                        )
                    )
                }
            }
        }

        @JavascriptInterface
        fun pickFiles() {
            runOnUiThread {
                firstUseConfirm("Dosyalar", "Telefondaki dosya seçicisini açmak için devam edelim mi?") {
                    filePicker.launch(arrayOf("*/*"))
                }
            }
        }

        @JavascriptInterface
        fun takePhoto() {
            runOnUiThread {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED
                ) captureCamera()
                else cameraPermission.launch(Manifest.permission.CAMERA)
            }
        }

        @JavascriptInterface
        fun toggleVoice(enable: Boolean) {
            runOnUiThread {
                if (enable) {
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED
                    ) startVoiceInternal()
                    else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                } else stopVoice()
            }
        }

        @JavascriptInterface
        fun openOverlaySettings() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        }
    }

    private fun firstUseConfirm(key: String, message: String, onContinue: () -> Unit) {
        val prefs = getSharedPreferences("suesa_native_prefs", MODE_PRIVATE)
        val prefKey = "asked_$key"
        if (prefs.getBoolean(prefKey, false)) {
            onContinue()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("$key izni")
            .setMessage(message)
            .setNegativeButton("Vazgeç", null)
            .setPositiveButton("Devam") { _, _ ->
                prefs.edit().putBoolean(prefKey, true).apply()
                onContinue()
            }
            .show()
    }

    private fun captureCamera() {
        cameraPreview.launch(null)
    }

    private fun sendBitmapToJs(bitmap: Bitmap) {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 88, stream)
        val b64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
        val payload = JSONObject()
            .put("name", "Kamera.jpg")
            .put("mime", "image/jpeg")
            .put("dataUrl", "data:image/jpeg;base64,$b64")
            .toString()
        js("window.onNativeFileSelected && window.onNativeFileSelected(${JSONObject.quote(payload)})")
    }

    private fun sendUriToJs(uri: Uri) {
        Thread {
            try {
                val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                val name = queryDisplayName(uri) ?: "Dosya"
                val bytes = contentResolver.openInputStream(uri)?.use { it.readAllBytesCompat(25 * 1024 * 1024) }
                    ?: throw IllegalStateException("Dosya okunamadı")
                val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                val payload = JSONObject()
                    .put("name", name)
                    .put("mime", mime)
                    .put("dataUrl", "data:$mime;base64,$b64")
                    .toString()
                runOnUiThread {
                    js("window.onNativeFileSelected && window.onNativeFileSelected(${JSONObject.quote(payload)})")
                }
            } catch (e: Exception) {
                runOnUiThread { js("window.onNativeFileError && window.onNativeFileError('Dosya okunamadı veya 25 MB sınırını aştı.')") }
            }
        }.start()
    }

    private fun InputStream.readAllBytesCompat(maxBytes: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var total = 0
        while (true) {
            val n = read(buf)
            if (n <= 0) break
            total += n
            if (total > maxBytes) throw IllegalArgumentException("Dosya çok büyük")
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return uri.lastPathSegment
    }

    private fun startVoiceInternal() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.onNativeVoiceError && window.onNativeVoiceError('Bu cihazda ses tanıma kullanılamıyor.')")
            return
        }
        stopVoice()
        speechEnabled = true
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) js("window.onNativeVoiceResult && window.onNativeVoiceResult(${JSONObject.quote(text)})")
                    if (speechEnabled) restartVoice()
                }
                override fun onError(error: Int) {
                    if (speechEnabled) restartVoice() else js("window.onNativeVoiceError && window.onNativeVoiceError('Ses tanıma durduruldu.')")
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        restartVoice()
    }

    private fun restartVoice() {
        if (!speechEnabled) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        runCatching { speechRecognizer?.startListening(intent) }
    }

    private fun stopVoice() {
        speechEnabled = false
        runCatching { speechRecognizer?.stopListening() }
        runCatching { speechRecognizer?.cancel() }
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    private fun js(script: String) {
        webView.post { webView.evaluateJavascript(script, null) }
    }

    override fun onDestroy() {
        stopVoice()
        webView.removeJavascriptInterface("AndroidBridge")
        webView.destroy()
        super.onDestroy()
    }
}
