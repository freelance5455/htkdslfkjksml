package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.InterceptionLog
import com.example.service.LockOverlayManager
import com.example.ui.AppGateState
import com.example.ui.MainUiState
import com.example.ui.MainViewModel
import com.example.ui.components.PinKeypad
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(uiState.statusMessage) {
                    uiState.statusMessage?.let {
                        snackbarHostState.showSnackbar(it)
                        viewModel.clearStatusMessage()
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CyberNavy
                ) {
                    when (uiState.gateState) {
                        AppGateState.FIRST_TIME_CREATE_PIN -> {
                            FirstTimePinSetupScreen(
                                title = "Establece tu PIN de 6 Dígitos",
                                subtitle = "Crea un PIN numérico para proteger TecnoGuard y los apartados del sistema contra robo.",
                                onPinComplete = { pin -> viewModel.onFirstTimeCreatePin(pin) },
                                errorMessage = uiState.errorMessage,
                                onClearError = { viewModel.clearErrorMessage() }
                            )
                        }

                        AppGateState.FIRST_TIME_CONFIRM_PIN -> {
                            FirstTimePinSetupScreen(
                                title = "Confirma tu PIN de 6 Dígitos",
                                subtitle = "Vuelve a ingresar el mismo PIN numérico de 6 dígitos.",
                                onPinComplete = { pin -> viewModel.onFirstTimeConfirmPin(pin) },
                                errorMessage = uiState.errorMessage,
                                onClearError = { viewModel.clearErrorMessage() }
                            )
                        }

                        AppGateState.APP_LOCKED_ENTER_PIN -> {
                            AppLockedScreen(
                                onPinComplete = { pin -> viewModel.onUnlockPinEntered(pin) },
                                errorMessage = uiState.errorMessage,
                                onClearError = { viewModel.clearErrorMessage() }
                            )
                        }

                        AppGateState.CHANGE_PIN_OLD -> {
                            ChangePinStepScreen(
                                stepTitle = "Introduce tu PIN Actual",
                                stepSubtitle = "Verifica tu identidad antes de cambiar el PIN.",
                                onPinComplete = { pin -> viewModel.onChangePinOldEntered(pin) },
                                errorMessage = uiState.errorMessage,
                                onCancel = { viewModel.cancelChangePin() },
                                onClearError = { viewModel.clearErrorMessage() }
                            )
                        }

                        AppGateState.CHANGE_PIN_NEW -> {
                            ChangePinStepScreen(
                                stepTitle = "Nuevo PIN de 6 Dígitos",
                                stepSubtitle = "Ingresa tu nuevo PIN de 6 dígitos.",
                                onPinComplete = { pin -> viewModel.onChangePinNewEntered(pin) },
                                errorMessage = uiState.errorMessage,
                                onCancel = { viewModel.cancelChangePin() },
                                onClearError = { viewModel.clearErrorMessage() }
                            )
                        }

                        AppGateState.CHANGE_PIN_CONFIRM -> {
                            ChangePinStepScreen(
                                stepTitle = "Confirma el Nuevo PIN",
                                stepSubtitle = "Ingresa nuevamente tu nuevo PIN de 6 dígitos.",
                                onPinComplete = { pin -> viewModel.onChangePinConfirmEntered(pin) },
                                errorMessage = uiState.errorMessage,
                                onCancel = { viewModel.cancelChangePin() },
                                onClearError = { viewModel.clearErrorMessage() }
                            )
                        }

                        AppGateState.UNLOCKED_MAIN_DASHBOARD -> {
                            MainDashboardScreen(
                                uiState = uiState,
                                viewModel = viewModel,
                                snackbarHostState = snackbarHostState
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshStatus()
    }
}

@Composable
fun FirstTimePinSetupScreen(
    title: String,
    subtitle: String,
    onPinComplete: (String) -> Unit,
    errorMessage: String?,
    onClearError: () -> Unit
) {
    var enteredPin by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF041C32), CyberNavy, Color(0xFF040D1A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 32.dp)
        ) {
            PinKeypad(
                currentPin = enteredPin,
                onPinChange = {
                    enteredPin = it
                    if (errorMessage != null) onClearError()
                },
                onPinComplete = {
                    onPinComplete(it)
                    enteredPin = ""
                },
                errorMessage = errorMessage,
                title = title,
                subtitle = subtitle,
                modifier = Modifier.testTag("setup_pin_keypad")
            )
        }
    }
}

@Composable
fun AppLockedScreen(
    onPinComplete: (String) -> Unit,
    errorMessage: String?,
    onClearError: () -> Unit
) {
    var enteredPin by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF041C32), CyberNavy, Color(0xFF040D1A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 32.dp)
        ) {
            PinKeypad(
                currentPin = enteredPin,
                onPinChange = {
                    enteredPin = it
                    if (errorMessage != null) onClearError()
                },
                onPinComplete = {
                    onPinComplete(it)
                    enteredPin = ""
                },
                errorMessage = errorMessage,
                title = "TecnoGuard Protegido",
                subtitle = "Introduce tu PIN de 6 dígitos para acceder al panel",
                modifier = Modifier.testTag("app_locked_pin_keypad")
            )
        }
    }
}

@Composable
fun ChangePinStepScreen(
    stepTitle: String,
    stepSubtitle: String,
    onPinComplete: (String) -> Unit,
    errorMessage: String?,
    onCancel: () -> Unit,
    onClearError: () -> Unit
) {
    var enteredPin by remember { mutableStateOf("") }

    BackHandler(onBack = onCancel)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavy),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 24.dp)
        ) {
            PinKeypad(
                currentPin = enteredPin,
                onPinChange = {
                    enteredPin = it
                    if (errorMessage != null) onClearError()
                },
                onPinComplete = {
                    onPinComplete(it)
                    enteredPin = ""
                },
                errorMessage = errorMessage,
                title = stepTitle,
                subtitle = stepSubtitle,
                modifier = Modifier.testTag("change_pin_keypad")
            )

            Spacer(modifier = Modifier.height(16.dp))

            TextButton(
                onClick = onCancel,
                modifier = Modifier.testTag("cancel_change_pin_button")
            ) {
                Text("Cancelar", color = TextSecondary)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen(
    uiState: MainUiState,
    viewModel: MainViewModel,
    snackbarHostState: SnackbarHostState
) {
    val context = LocalContext.current
    var showLogsDialog by remember { mutableStateOf(false) }

    val allEssentialGranted = uiState.isAccessibilityEnabled &&
            uiState.isDeviceAdminEnabled &&
            uiState.isOverlayPermissionGranted

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(CyberCard)
                                .border(1.dp, CyberCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "TecnoGuard",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.startChangePin() },
                        modifier = Modifier.testTag("action_change_pin")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = "Cambiar PIN",
                            tint = CyberCyan
                        )
                    }
                    IconButton(
                        onClick = { showLogsDialog = !showLogsDialog },
                        modifier = Modifier.testTag("action_toggle_logs")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Historial",
                            tint = TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberNavy
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = CyberNavy
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("main_dashboard_list"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Hero Status Card
            item {
                StatusHeroCard(
                    allGranted = allEssentialGranted,
                    onTestLock = {
                        LockOverlayManager.triggerLock(
                            context = context,
                            reason = "Prueba de Pantalla de Bloqueo Antirrobo",
                            targetPackage = context.packageName
                        )
                    }
                )
            }

            // Section: Required Permissions
            item {
                SectionHeader(
                    title = "PERMISOS REQUERIDOS",
                    subtitle = "Necesarios para interceptar acciones en HiOS / Android 13"
                )
            }

            item {
                PermissionCard(
                    title = "Servicio de Accesibilidad",
                    description = "Detecta e intercepta en tiempo real la apertura del menú de apagado, reinicio y ajustes protegidos.",
                    icon = Icons.Default.Security,
                    isGranted = uiState.isAccessibilityEnabled,
                    buttonLabel = if (uiState.isAccessibilityEnabled) "Activo" else "Activar Accesibilidad",
                    onAction = {
                        viewModel.preparePermissionNavigation()
                        try {
                            context.startActivity(viewModel.getAccessibilitySettingsIntent())
                            Toast.makeText(
                                context,
                                "Busca 'TecnoGuard Antirrobo' y actívalo",
                                Toast.LENGTH_LONG
                            ).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error abriendo ajustes: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    testTag = "permission_accessibility"
                )
            }

            item {
                PermissionCard(
                    title = "Protección contra Desinstalación",
                    description = "Concede permisos de Administrador para evitar que borren o desinstalen la app sin tu consentimiento.",
                    icon = Icons.Default.AdminPanelSettings,
                    isGranted = uiState.isDeviceAdminEnabled,
                    buttonLabel = if (uiState.isDeviceAdminEnabled) "Activo" else "Activar Administrador",
                    onAction = {
                        viewModel.preparePermissionNavigation()
                        try {
                            context.startActivity(viewModel.getDeviceAdminIntent())
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    testTag = "permission_device_admin"
                )
            }

            item {
                PermissionCard(
                    title = "Mostrar sobre otras aplicaciones",
                    description = "Permite a la aplicación desplegar la pantalla de bloqueo con PIN instantáneamente sobre el menú de apagado y ajustes.",
                    icon = Icons.Outlined.Layers,
                    isGranted = uiState.isOverlayPermissionGranted,
                    buttonLabel = if (uiState.isOverlayPermissionGranted) "Concedido" else "Permitir Superposición",
                    onAction = {
                        viewModel.preparePermissionNavigation()
                        try {
                            context.startActivity(viewModel.getOverlayPermissionIntent())
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    testTag = "permission_overlay"
                )
            }

            item {
                PermissionCard(
                    title = "Segundo Plano sin Restricciones (HiOS)",
                    description = "Evita que el optimizador de batería de Tecno HiOS cierre el servicio de protección antirrobo.",
                    icon = Icons.Default.Settings,
                    isGranted = uiState.isBatteryOptimizationIgnored,
                    buttonLabel = if (uiState.isBatteryOptimizationIgnored) "Optimizado" else "Configurar Batería",
                    onAction = {
                        viewModel.preparePermissionNavigation()
                        try {
                            context.startActivity(viewModel.getBatteryOptimizationIntent())
                        } catch (e: Exception) {
                            Toast.makeText(context, "Ajustes de batería no disponibles", Toast.LENGTH_SHORT).show()
                        }
                    },
                    testTag = "permission_battery"
                )
            }

            // Section: Protected Modules with Switches
            item {
                SectionHeader(
                    title = "APARTADOS PROTEGIDOS CON PIN",
                    subtitle = "Cualquier intento de acceso solicitará tu PIN de 6 dígitos"
                )
            }

            item {
                ModuleToggleCard(
                    title = "Menú de Apagado y Reinicio",
                    description = "Impide apagar o reiniciar el dispositivo en caso de robo.",
                    icon = Icons.Default.PowerSettingsNew,
                    iconColor = CyberCyan,
                    isChecked = uiState.isPowerProtected,
                    onCheckedChange = { viewModel.togglePowerProtection(it) },
                    testTag = "toggle_power_menu"
                )
            }

            item {
                ModuleToggleCard(
                    title = "Función de Memoria y Reinicios Internos",
                    description = "Protege 'Función de memoria' (MemFusion), extensión de RAM y restablecimiento que requieran reinicio.",
                    icon = Icons.Default.Memory,
                    iconColor = CyberTeal,
                    isChecked = uiState.isMemoryProtected,
                    onCheckedChange = { viewModel.toggleMemoryProtection(it) },
                    testTag = "toggle_memory_function"
                )
            }

            item {
                ModuleToggleCard(
                    title = "Ajustes de Accesibilidad y Administrador",
                    description = "Evita que un ladrón ingrese a la configuración del sistema para deshabilitar los permisos de TecnoGuard.",
                    icon = Icons.Default.AdminPanelSettings,
                    iconColor = CyberGreen,
                    isChecked = uiState.isAdminAndAccessibilityProtected,
                    onCheckedChange = { viewModel.toggleAdminAccessibilityProtection(it) },
                    testTag = "toggle_admin_accessibility"
                )
            }

            item {
                ModuleToggleCard(
                    title = "Configuración de Escritorio (HiOS)",
                    description = "Bloquea el menú de ajustes de pantalla de inicio y gestos del HiOS Launcher.",
                    icon = Icons.Default.Dashboard,
                    iconColor = CyberCyan,
                    isChecked = uiState.isDesktopProtected,
                    onCheckedChange = { viewModel.toggleDesktopProtection(it) },
                    testTag = "toggle_desktop_settings"
                )
            }

            // Logs Section
            item {
                InterceptionLogsHeader(
                    logCount = uiState.interceptionLogs.size,
                    onClearLogs = { viewModel.clearLogs() }
                )
            }

            if (uiState.interceptionLogs.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CyberCard)
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No hay intentos de apagado o intrusión registrados.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                items(uiState.interceptionLogs) { log ->
                    InterceptionLogRow(log)
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun StatusHeroCard(
    allGranted: Boolean,
    onTestLock: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("status_hero_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = CyberCard
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                listOf(
                    if (allGranted) CyberGreen.copy(alpha = 0.6f) else CyberRed.copy(alpha = 0.6f),
                    CyberCyan.copy(alpha = 0.3f)
                )
            ),
            width = 1.5.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            if (allGranted) CyberGreen.copy(alpha = 0.15f) else CyberRed.copy(alpha = 0.15f)
                        )
                        .border(
                            1.dp,
                            if (allGranted) CyberGreen else CyberRed,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (allGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (allGranted) CyberGreen else CyberRed,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = if (allGranted) "PROTECCIÓN COMPLETA ACTIVA" else "PROTECCIÓN INCOMPLETA",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (allGranted) CyberGreen else CyberRed,
                            letterSpacing = 0.5.sp
                        )
                    )
                    Text(
                        text = if (allGranted)
                            "El dispositivo está blindado contra apagado y desinstalación"
                        else
                            "Concede los permisos marcados abajo para activar el bloqueo nativo",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            HorizontalDivider(color = CyberCardBorder, thickness = 1.dp)

            Spacer(modifier = Modifier.height(16.dp))

            // Test Lock Screen button
            Button(
                onClick = onTestLock,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("test_lock_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyberCyan,
                    contentColor = Color(0xFF001E28)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Probar Pantalla de Bloqueo con PIN",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, subtitle: String) {
    Column(modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge.copy(
                fontWeight = FontWeight.Bold,
                color = CyberCyan,
                letterSpacing = 1.sp
            )
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
        )
    }
}

@Composable
fun PermissionCard(
    title: String,
    description: String,
    icon: ImageVector,
    isGranted: Boolean,
    buttonLabel: String,
    onAction: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                listOf(
                    if (isGranted) CyberGreen.copy(alpha = 0.4f) else CyberCardBorder,
                    CyberCardBorder
                )
            ),
            width = 1.dp
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (isGranted) CyberGreen.copy(alpha = 0.15f) else CyberSurfaceVariant
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isGranted) CyberGreen else CyberCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )

                        // Status Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isGranted) CyberGreen.copy(alpha = 0.15f) else CyberRed.copy(alpha = 0.15f)
                                )
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (isGranted) "ACTIVO" else "PENDIENTE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isGranted) CyberGreen else CyberRed,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            lineHeight = 18.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!isGranted) {
                        Button(
                            onClick = onAction,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCyan,
                                contentColor = Color(0xFF001E28)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                        ) {
                            Text(
                                text = buttonLabel,
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    } else {
                        OutlinedButton(
                            onClick = onAction,
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = CyberGreen
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = Brush.horizontalGradient(listOf(CyberGreen, CyberTeal))
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = CyberGreen
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Permiso Concedido",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ModuleToggleCard(
    title: String,
    description: String,
    icon: ImageVector,
    iconColor: Color,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(
                listOf(
                    if (isChecked) iconColor.copy(alpha = 0.35f) else CyberCardBorder,
                    CyberCardBorder
                )
            ),
            width = 1.dp
        )
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(iconColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Switch(
                checked = isChecked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF001E28),
                    checkedTrackColor = iconColor,
                    uncheckedThumbColor = TextMuted,
                    uncheckedTrackColor = CyberSurfaceVariant
                )
            )
        }
    }
}

@Composable
fun InterceptionLogsHeader(
    logCount: Int,
    onClearLogs: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "HISTORIAL DE INTERCEPCIONES",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = CyberCyan,
                    letterSpacing = 1.sp
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(CyberSurfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "$logCount",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        if (logCount > 0) {
            TextButton(
                onClick = onClearLogs,
                contentPadding = PaddingValues(horizontal = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Limpiar",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                )
            }
        }
    }
}

@Composable
fun InterceptionLogRow(log: InterceptionLog) {
    val dateString = remember(log.timestamp) {
        val sdf = SimpleDateFormat("HH:mm:ss - dd/MM", Locale.getDefault())
        sdf.format(Date(log.timestamp))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(CyberRed.copy(alpha = 0.4f), CyberCardBorder)),
            width = 1.dp
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(CyberRed.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = CyberRed,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = log.reason,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                )
                if (log.targetApp.isNotBlank()) {
                    Text(
                        text = "App: ${log.targetApp}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                }
            }

            Text(
                text = dateString,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            )
        }
    }
}
