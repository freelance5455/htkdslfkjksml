package com.example

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.QrCode
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.ParsedQr
import com.example.ui.components.ResultBottomSheet
import com.example.ui.components.SafeLinkDialog
import com.example.ui.screens.GenerateScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.ScanScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.ScanovaTheme
import com.example.viewmodel.ScannerViewModel

enum class NavigationTab(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    SCAN("Scan", Icons.Filled.QrCodeScanner, Icons.Outlined.QrCodeScanner, "tab_scan"),
    GENERATE("Generate", Icons.Filled.QrCode, Icons.Outlined.QrCode, "tab_generate"),
    HISTORY("History", Icons.Filled.History, Icons.Outlined.History, "tab_history"),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "tab_settings")
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ScanovaTheme {
                ScanovaApp()
            }
        }
    }
}

@Composable
fun ScanovaApp(
    viewModel: ScannerViewModel = viewModel()
) {
    var currentTab by rememberSaveable { mutableStateOf(NavigationTab.SCAN) }
    val currentResult by viewModel.currentResult.collectAsState()
    val currentUrlMetadata by viewModel.currentUrlMetadata.collectAsState()
    val pendingUrl by viewModel.pendingUrlToOpen.collectAsState()

    // Handle system back navigation if not on SCAN tab
    BackHandler(enabled = currentTab != NavigationTab.SCAN) {
        currentTab = NavigationTab.SCAN
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_nav_bar"),
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            if (currentTab == NavigationTab.HISTORY && tab != NavigationTab.HISTORY) {
                                viewModel.lockHistory()
                            }
                            currentTab = tab
                        },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.label
                            )
                        },
                        label = {
                            Text(
                                text = tab.label,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.testTag(tab.testTag),
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00363D),
                            selectedTextColor = CyanPrimary,
                            indicatorColor = CyanPrimary,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_crossfade"
            ) { tab ->
                when (tab) {
                    NavigationTab.SCAN -> {
                        ScanScreen(
                            viewModel = viewModel,
                            onNavigateToGenerate = { currentTab = NavigationTab.GENERATE }
                        )
                    }
                    NavigationTab.GENERATE -> {
                        GenerateScreen(viewModel = viewModel)
                    }
                    NavigationTab.HISTORY -> {
                        HistoryScreen(
                            viewModel = viewModel,
                            onOpenResult = { parsed ->
                                viewModel.onBarcodeDetected(parsed.rawText)
                            }
                        )
                    }
                    NavigationTab.SETTINGS -> {
                        SettingsScreen(viewModel = viewModel)
                    }
                }
            }
        }

        // Result Dialog / Sheet
        currentResult?.let { result ->
            ResultBottomSheet(
                result = result,
                urlMetadata = currentUrlMetadata,
                onDismiss = { viewModel.dismissResult() },
                onCopy = { text -> viewModel.copyToClipboard(text) },
                onOpenUrlRequest = { url -> viewModel.requestOpenUrl(url) }
            )
        }

        // Safe Link Confirmation Dialog
        pendingUrl?.let { url ->
            SafeLinkDialog(
                url = url,
                metadata = currentUrlMetadata,
                onConfirm = { viewModel.confirmOpenUrl() },
                onDismiss = { viewModel.dismissUrlConfirmation() }
            )
        }
    }
}
