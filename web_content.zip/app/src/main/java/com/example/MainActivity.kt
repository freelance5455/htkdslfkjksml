package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MotionForgeViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: MotionForgeViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          val navController = rememberNavController()

          NavHost(navController = navController, startDestination = "home") {
            composable("home") {
              HomeScreen(
                viewModel = viewModel,
                onNavigateToPreview = { navController.navigate("preview") },
                onNavigateToRecipeEditor = { navController.navigate("recipe_editor") },
                onNavigateToTimeline = { navController.navigate("timeline") },
                onNavigateToExport = { navController.navigate("export") }
              )
            }
            composable("recipe_editor") {
              RecipeEditorScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToPreview = { navController.navigate("preview") }
              )
            }
            composable("timeline") {
              TimelineEditorScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToPreview = { navController.navigate("preview") }
              )
            }
            composable("preview") {
              PreviewScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onNavigateToTimeline = { navController.navigate("timeline") },
                onNavigateToExport = { navController.navigate("export") }
              )
            }
            composable("export") {
              ExportScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
              )
            }
          }
        }
      }
    }
  }
}
