package com.example

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : ComponentActivity() {

  private var webView: WebView? = null
  private var uploadMessage: ValueCallback<Array<Uri>>? = null

  private val fileChooserLauncher = registerForActivityResult(
    ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      val data = result.data
      val results = WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
      uploadMessage?.onReceiveValue(results)
    } else {
      uploadMessage?.onReceiveValue(null)
    }
    uploadMessage = null
  }

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
      override fun handleOnBackPressed() {
        if (webView?.canGoBack() == true) {
          webView?.goBack()
        } else {
          isEnabled = false
          onBackPressedDispatcher.onBackPressed()
        }
      }
    })

    val webViewInstance = WebView(this).apply {
      webView = this
      layoutParams = ViewGroup.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
      )

      // Set software layer type to avoid Mesa "Failed to open rendernode" driver error in virtual/emulator environments
      try {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null)
      } catch (_: Exception) {
        // Fallback gracefully
      }

      settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        databaseEnabled = true
        allowFileAccess = true
        allowContentAccess = true
        allowFileAccessFromFileURLs = true
        allowUniversalAccessFromFileURLs = true
        cacheMode = WebSettings.LOAD_DEFAULT
        useWideViewPort = true
        loadWithOverviewMode = true
        displayZoomControls = false
        builtInZoomControls = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
          mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
      }

      webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
          val url = request?.url?.toString() ?: return false
          return handleUrlNavigation(url)
        }

        @Deprecated("Deprecated in Java")
        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
          if (url == null) return false
          return handleUrlNavigation(url)
        }

        private fun handleUrlNavigation(url: String): Boolean {
          if (url.startsWith("file:///android_asset/")) {
            return false
          }
          if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("sms:")) {
            try {
              val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
              context.startActivity(intent)
              return true
            } catch (_: Exception) {
              return false
            }
          }
          if (url.startsWith("http:") || url.startsWith("https:")) {
            // Allow Firebase and internal assets to load without redirection
            if (!url.contains("googleapis.com") && !url.contains("gstatic.com") && !url.contains("firebaseapp.com")) {
              try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
                return true
              } catch (_: Exception) {
                return false
              }
            }
          }
          return false
        }

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
          // Prevent application crash if the renderer process encounters GPU driver or memory issues
          view?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.destroy()
          }
          webView = null
          return true
        }

        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
          super.onReceivedError(view, request, error)
        }
      }

      webChromeClient = object : WebChromeClient() {
        override fun onShowFileChooser(
          webView: WebView?,
          filePathCallback: ValueCallback<Array<Uri>>?,
          fileChooserParams: FileChooserParams?
        ): Boolean {
          uploadMessage?.onReceiveValue(null)
          uploadMessage = filePathCallback

          val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
          }
          try {
            fileChooserLauncher.launch(intent)
          } catch (_: Exception) {
            uploadMessage = null
            return false
          }
          return true
        }
      }

      loadUrl("file:///android_asset/www/index.html")
    }

    setContentView(webViewInstance)

    // Apply system window insets padding for edge-to-edge layout
    ViewCompat.setOnApplyWindowInsetsListener(webViewInstance) { v, insets ->
      val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
      v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
      insets
    }
  }

  override fun onDestroy() {
    webView?.destroy()
    webView = null
    super.onDestroy()
  }
}
