package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.AppLanguage
import com.example.localization.StringsProvider
import com.example.system.BiometricAuthManager
import com.example.system.SosTriggerAction
import com.example.ui.HavenViewModel
import com.example.ui.components.BiometricLockScreen
import com.example.ui.components.DndPermissionDialog
import com.example.ui.screens.LearnScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PillowScreen
import com.example.ui.screens.ProfileSettingsScreen
import com.example.ui.screens.SosConnectScreen
import com.example.ui.screens.TodayScreen
import com.example.ui.screens.WellnessScreen
import com.example.ui.theme.HavenTheme

const val ROUTE_TODAY = "today"
const val ROUTE_PILLOW = "pillow"
const val ROUTE_LEARN = "learn"
const val ROUTE_WELLNESS = "wellness"
const val ROUTE_SOS = "sos"
const val ROUTE_PROFILE = "profile"

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: HavenViewModel = viewModel()
            val profile by viewModel.userProfile.collectAsStateWithLifecycle()
            HavenTheme(darkTheme = profile.sleepQuietModeActive) {
                HavenRootApp(
                    activity = this,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun HavenRootApp(
    activity: FragmentActivity,
    viewModel: HavenViewModel
) {
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val todayCareLogs by viewModel.todayCareLogs.collectAsStateWithLifecycle()
    val reminders by viewModel.reminderSchedules.collectAsStateWithLifecycle()
    val diaryEntries by viewModel.diaryEntries.collectAsStateWithLifecycle()
    val cycleLogs by viewModel.cycleLogs.collectAsStateWithLifecycle()
    val vitalityLogs by viewModel.vitalityLogs.collectAsStateWithLifecycle()
    val hormoneChecks by viewModel.hormoneChecks.collectAsStateWithLifecycle()
    val hormoneCycleLogs by viewModel.dailyHormoneCycleLogs.collectAsStateWithLifecycle()
    val contacts by viewModel.emergencyContacts.collectAsStateWithLifecycle()
    val sosMessages by viewModel.sosMessages.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val tutorMessages by viewModel.tutorMessages.collectAsStateWithLifecycle()
    val learnedFactsCount by viewModel.learnedFactsCount.collectAsStateWithLifecycle()
    val quizStreak by viewModel.quizStreak.collectAsStateWithLifecycle()
    val isAiThinking by viewModel.isAiThinking.collectAsStateWithLifecycle()
    val selectedMood by viewModel.selectedMood.collectAsStateWithLifecycle()
    val awards by viewModel.awards.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBannerMessage.collectAsStateWithLifecycle()
    val showDndDialog by viewModel.needsDndAccessDialog.collectAsStateWithLifecycle()
    val isUnlocked by viewModel.isUnlocked.collectAsStateWithLifecycle()

    val biometricManager = remember { BiometricAuthManager(activity) }
    var biometricError by remember { mutableStateOf<String?>(null) }

    val triggerBiometricPrompt = {
        biometricError = null
        biometricManager.authenticate(
            activity = activity,
            onSuccess = { viewModel.markUnlocked() },
            onError = { err -> biometricError = err }
        )
    }

    LaunchedEffect(profile.biometricLockEnabled, isUnlocked) {
        if (profile.onboardingCompleted && profile.isLoggedIn && profile.biometricLockEnabled && !isUnlocked) {
            if (biometricManager.isBiometricOrDeviceCredentialAvailable()) {
                triggerBiometricPrompt()
            } else {
                viewModel.markUnlocked()
            }
        }
    }

    if (!profile.onboardingCompleted || !profile.isLoggedIn) {
        OnboardingScreen(
            initialProfile = profile,
            onCompleteOnboarding = { updated -> viewModel.saveUserProfile(updated) }
        )
        return
    }

    if (profile.biometricLockEnabled && !isUnlocked) {
        BiometricLockScreen(
            onUnlockClick = triggerBiometricPrompt,
            errorMessage = biometricError
        )
        return
    }

    val strings = StringsProvider.get(profile.language)
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: ROUTE_TODAY
    val snackbarHostState = remember { SnackbarHostState() }
    var currentLocationText by remember {
        mutableStateOf(viewModel.phoneControl.getBestLastKnownLocationText())
    }

    LaunchedEffect(statusBanner) {
        statusBanner?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearStatusBanner()
        }
    }

    if (showDndDialog) {
        DndPermissionDialog(
            onOpenSettings = { viewModel.phoneControl.openDndPolicySettings() },
            onDismiss = { viewModel.dismissDndDialog() }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                val navItems = listOf(
                    Triple(ROUTE_TODAY, strings.navToday, Icons.Filled.Home),
                    Triple(ROUTE_PILLOW, strings.navPillow, Icons.Filled.Favorite),
                    Triple(ROUTE_LEARN, "Learn", Icons.Filled.MenuBook),
                    Triple(ROUTE_WELLNESS, strings.navWellness, Icons.Filled.Spa),
                    Triple(ROUTE_SOS, strings.navSos, Icons.Filled.Warning)
                )
                navItems.forEach { (route, label, icon) ->
                    NavigationBarItem(
                        selected = currentRoute == route,
                        onClick = {
                            if (currentRoute != route) {
                                navController.navigate(route) {
                                    popUpTo(ROUTE_TODAY) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        modifier = Modifier.testTag("nav_$route")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Box(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
                NavHost(
                    navController = navController,
                    startDestination = ROUTE_TODAY
                ) {
                    composable(ROUTE_TODAY) {
                        TodayScreen(
                            profile = profile,
                            strings = strings,
                            todayLogs = todayCareLogs,
                            reminders = reminders,
                            awards = awards,
                            onToggleDataFree = { viewModel.toggleDataFreeMode(it) },
                            onCycleLanguage = {
                                val all = AppLanguage.entries
                                val next = all[(all.indexOf(profile.language) + 1) % all.size]
                                viewModel.setLanguage(next)
                            },
                            onExecuteCommand = { viewModel.executePhoneCommand(it) },
                            onToggleSleepQuietMode = { viewModel.toggleSleepQuietMode(it) },
                            onLogCare = { viewModel.logCareAction(it) },
                            onUpdateReminder = { cat, h, m, on -> viewModel.updateReminder(cat, h, m, on) },
                            onTestNotification = { cat ->
                                viewModel.reminderManager.showNotificationNow(
                                    cat.ordinal + 500,
                                    "Haven: ${strings.careLabels[cat] ?: cat.name}",
                                    "Gentle reminder to take care of yourself right now!"
                                )
                            },
                            onSetWakeAlarm = { viewModel.phoneControl.setWakeUpAlarm(6, 30) },
                            onOpenProfile = {
                                navController.navigate(ROUTE_PROFILE) {
                                    launchSingleTop = true
                                }
                            }
                        )
                    }
                    composable(ROUTE_PILLOW) {
                        PillowScreen(
                            strings = strings,
                            selectedMood = selectedMood,
                            chatMessages = chatMessages,
                            isAiThinking = isAiThinking,
                            diaryEntries = diaryEntries,
                            onSelectMood = { viewModel.selectMood(it) },
                            onSendPillowMessage = { viewModel.sendPillowMessage(it) },
                            onSaveDiaryEntry = { t, c, m, e, v -> viewModel.saveDiaryEntry(t, c, m, e, v) },
                            onDeleteDiaryEntry = { viewModel.deleteDiaryEntry(it) },
                            onBackupToEmail = { viewModel.backupToEmail() }
                        )
                    }
                    composable(ROUTE_LEARN) {
                        LearnScreen(
                            tutorMessages = tutorMessages,
                            isAiThinking = isAiThinking,
                            learnedCount = learnedFactsCount,
                            quizStreak = quizStreak,
                            onMarkFactLearned = { viewModel.markFactLearned() },
                            onQuizAnswered = { viewModel.recordQuizAnswer(it) },
                            onAskTutor = { q, s -> viewModel.askTutorTshenoloMaseko(q, s) }
                        )
                    }
                    composable(ROUTE_WELLNESS) {
                        WellnessScreen(
                            profile = profile,
                            strings = strings,
                            cycleLogs = cycleLogs,
                            vitalityLogs = vitalityLogs,
                            hormoneChecks = hormoneChecks,
                            hormoneCycleLogs = hormoneCycleLogs,
                            isAiThinking = isAiThinking,
                            onLogPeriodToday = { f, c, s, n -> viewModel.logPeriodStartToday(f, c, s, n) },
                            onLogBoysVitality = { m, wt, p, z, sl, n -> viewModel.logBoysVitality(m, wt, p, z, sl, n) },
                            onRunHormoneCheck = { e, m, sk, sl, st, sym -> viewModel.runHormoneCheck(e, m, sk, sl, st, sym) }
                        )
                    }
                    composable(ROUTE_SOS) {
                        SosConnectScreen(
                            profile = profile,
                            strings = strings,
                            contacts = contacts,
                            sosMessages = sosMessages,
                            currentLocationText = currentLocationText,
                            onRefreshLocation = {
                                currentLocationText = viewModel.phoneControl.getBestLastKnownLocationText()
                            },
                            onCallNumber = { viewModel.sosIntentHelper.initiateEmergencyCall(it) },
                            onActivateSosTrigger = { action, msg -> viewModel.activateSosTrigger(action, msg) },
                            onSendSmsDirect = { p, m -> viewModel.phoneControl.sendSms(p, m) },
                            onSendWhatsAppDirect = { p, m -> viewModel.phoneControl.sendWhatsAppOrShare(p, m) },
                            onDispatchSos = { c, m, ch -> viewModel.dispatchSosMessage(c, m, ch) },
                            onAddContact = { n, p, r -> viewModel.addEmergencyContact(n, p, r) },
                            onDeleteContact = { viewModel.deleteEmergencyContact(it) }
                        )
                    }
                    composable(ROUTE_PROFILE) {
                        ProfileSettingsScreen(
                            profile = profile,
                            awards = awards,
                            biometricAvailable = biometricManager.isBiometricOrDeviceCredentialAvailable(),
                            onSaveProfile = { viewModel.saveUserProfile(it) },
                            onSetLanguage = { viewModel.setLanguage(it) },
                            onToggleDataFree = { viewModel.toggleDataFreeMode(it) },
                            onToggleBiometric = { viewModel.toggleBiometricLock(it) },
                            onBackupToEmail = { viewModel.backupToEmail() },
                            onLockNow = { viewModel.lockApp() },
                            onLogout = { viewModel.logout() }
                        )
                    }
                }
            }
        }
    }
}
