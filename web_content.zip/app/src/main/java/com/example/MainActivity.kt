package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.ai.AIEngine
import com.example.ai.AIProcessingState
import com.example.ai.AppIntent
import com.example.bridge.SuesaBridge
import com.example.data.api.GeminiApiClient
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessage
import com.example.data.local.ChatSession
import com.example.data.local.PreferencesManager
import com.example.system.AndroidActionManager
import com.example.system.PermissionManager
import com.example.voice.VoiceEventListener
import com.example.voice.VoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class MainActivity : ComponentActivity(), VoiceEventListener {

    private lateinit var webView: WebView
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var actionManager: AndroidActionManager
    private lateinit var permissionManager: PermissionManager
    private lateinit var voiceManager: VoiceManager
    private lateinit var aiEngine: AIEngine
    private lateinit var database: AppDatabase

    private var activeSessionId: Long = 1L
    private var pendingPermissionCallback: (() -> Unit)? = null

    // Activity Result Launchers
    private val takePhotoLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap: Bitmap? ->
        if (bitmap != null) {
            handleSelectedBitmap(bitmap, "camera_photo.jpg")
        }
    }

    private val pickPhotoLauncher = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            handleSelectedUri(uri)
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        notifyPermissionsUpdated()
        if (isGranted) {
            pendingPermissionCallback?.invoke()
        } else {
            Toast.makeText(this, "Gerekli izin verilmedi.", Toast.LENGTH_SHORT).show()
        }
        pendingPermissionCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Services & Database
        database = AppDatabase.getDatabase(applicationContext)
        preferencesManager = PreferencesManager(this)
        actionManager = AndroidActionManager(this)
        permissionManager = PermissionManager(this)
        aiEngine = AIEngine(GeminiApiClient())
        voiceManager = VoiceManager(this, this)
        voiceManager.speechRate = preferencesManager.getSpeechRate()

        // Root container with dark background
        val rootLayout = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#171717"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Configure WebView
        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#171717"))
            setLayerType(View.LAYER_TYPE_SOFTWARE, null)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccess = true
                allowContentAccess = true
                cacheMode = WebSettings.LOAD_DEFAULT
                useWideViewPort = true
                loadWithOverviewMode = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            }

            webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    // Filter or log for debugging
                    return super.onConsoleMessage(consoleMessage)
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val url = request?.url?.toString() ?: ""
                    if (url.startsWith("file:///android_asset/")) {
                        return false
                    }
                    // Dış bağlantıları (Vikipedi vb.) harici tarayıcıda aç
                    return try {
                        val browserIntent = android.content.Intent(
                            android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse(url)
                        )
                        startActivity(browserIntent)
                        true
                    } catch (e: Exception) {
                        false
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                }
            }

            // Expose Suesa JavaScript Bridge
            addJavascriptInterface(SuesaBridge(this@MainActivity), "Suesa")
        }

        rootLayout.addView(webView)
        setContentView(rootLayout)

        // Handle WindowInsets for clean edge-to-edge & dynamic keyboard sizing
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val bottomPadding = if (ime.bottom > 0) ime.bottom else systemBars.bottom
            view.setPadding(0, systemBars.top, 0, bottomPadding)
            insets
        }

        // Hardware Back Button
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (voiceManager.isCurrentlySpeaking()) {
                    voiceManager.stopSpeaking()
                    return
                }
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        // Initialize default session in Room
        lifecycleScope.launch(Dispatchers.IO) {
            val savedSessionId = preferencesManager.getActiveSessionId()
            val session = if (savedSessionId > 0) {
                database.appDao().getSessionById(savedSessionId)
            } else null

            if (session != null) {
                activeSessionId = session.id
            } else {
                val newId = database.appDao().insertSession(
                    ChatSession(title = "Suesa Asistan")
                )
                activeSessionId = newId
                preferencesManager.setActiveSessionId(newId)
            }

            withContext(Dispatchers.Main) {
                // Load local HTML asset
                webView.loadUrl("file:///android_asset/index.html")
            }
        }
    }

    override fun onDestroy() {
        voiceManager.destroy()
        super.onDestroy()
    }

    // ----------------------------------------------------
    // Bridge Operations Called from SuesaBridge
    // ----------------------------------------------------

    fun handleBridgeCommand(command: String): String {
        val trimmed = command.trim()
        val lower = trimmed.lowercase()
        val result = when {
            lower == "open_google" -> actionManager.openGoogle()
            lower == "open_youtube" -> actionManager.openYouTube()
            lower == "open_chrome" -> actionManager.openChrome()
            lower == "open_whatsapp" -> actionManager.openWhatsApp()
            lower == "open_camera" -> actionManager.openCamera()
            lower == "open_gallery" -> actionManager.openGallery()
            lower == "open_phone" || lower == "open_dialer" -> actionManager.openPhone()
            lower == "open_messages" -> actionManager.openMessages()
            lower == "open_clock" -> actionManager.openClockOrAlarm()
            lower == "open_calculator" -> actionManager.openCalculator()
            lower == "open_wifi" -> actionManager.openSetting(com.example.ai.SettingType.WIFI)
            lower == "open_bluetooth" -> actionManager.openSetting(com.example.ai.SettingType.BLUETOOTH)
            lower == "open_settings" -> actionManager.openSetting(com.example.ai.SettingType.GENERAL)
            lower == "open_default_assistant_settings" -> actionManager.openDefaultAssistantSettings()
            lower.startsWith("open_app:") -> actionManager.openApplicationByName(trimmed.removePrefix("open_app:").trim())
            lower == "start_voice" -> {
                runOnUiThread { startVoiceRecognition() }
                com.example.system.ActionResult(true, "Sesli dinleme başlatıldı.")
            }
            lower == "stop_voice" -> {
                runOnUiThread { stopVoiceRecognition() }
                com.example.system.ActionResult(true, "Sesli dinleme durduruldu.")
            }
            else -> com.example.system.ActionResult(false, "Bilinmeyen komut: $command")
        }

        return JSONObject().apply {
            put("success", result.isSuccess)
            put("message", result.message)
            if (result.requiresPermission != null) {
                put("requiresPermission", result.requiresPermission)
            }
        }.toString()
    }

    fun processUserMessage(text: String, imageBase64: String?) {
        val apiKey = preferencesManager.getEffectiveApiKey()

        lifecycleScope.launch(Dispatchers.IO) {
            // 1. Save user message to database
            val userMsg = ChatMessage(
                sessionId = activeSessionId,
                role = "user",
                content = text,
                imageUri = null
            )
            database.appDao().insertMessage(userMsg)
            database.appDao().touchSession(activeSessionId)

            // 2. Process via AI Engine with status updates
            val result = aiEngine.processUserRequest(
                userPrompt = text,
                apiKey = apiKey,
                imageBase64 = imageBase64,
                isWebSearchEnabled = preferencesManager.isWebSearchEnabled(),
                onStatusUpdate = { status ->
                    runOnUiThread {
                        notifyStateChange(status)
                    }
                }
            )

            // 3. Handle Result
            when (result) {
                is AIProcessingState.Complete -> {
                    val answer = result.response

                    // Execute device action safely on Main UI thread
                    var finalAnswerText = answer.text
                    if (answer.isAction) {
                        runOnUiThread {
                            when (result.detectedIntent) {
                                is com.example.ai.AppIntent.OpenApp -> {
                                    val actionRes = actionManager.executeAppAction(
                                        result.detectedIntent.appType,
                                        result.detectedIntent.parameter
                                    )
                                    if (!actionRes.isSuccess) {
                                        dispatchMessageToJs("assistant", actionRes.message, null, null)
                                    }
                                }
                                is com.example.ai.AppIntent.OpenSetting -> {
                                    actionManager.openSetting(result.detectedIntent.settingType)
                                }
                                is com.example.ai.AppIntent.CallContact -> {
                                    handleCallContact(result.detectedIntent.targetNameOrNumber)
                                }
                                else -> {}
                            }
                        }
                    }

                    // Save assistant message to database
                    val assistantMsg = ChatMessage(
                        sessionId = activeSessionId,
                        role = "assistant",
                        content = answer.text
                    )
                    database.appDao().insertMessage(assistantMsg)
                    database.appDao().touchSession(activeSessionId)

                    // Dispatch to JavaScript
                    withContext(Dispatchers.Main) {
                        dispatchMessageToJs(
                            role = "assistant",
                            content = answer.text,
                            sourceTitle = answer.sourceTitle,
                            sourceUrl = answer.sourceUrl
                        )

                        // TTS auto speak if enabled
                        if (preferencesManager.isTtsAutoSpeakEnabled()) {
                            voiceManager.speak(answer.text)
                        }
                    }
                }
                is AIProcessingState.Error -> {
                    withContext(Dispatchers.Main) {
                        dispatchMessageToJs(
                            role = "assistant",
                            content = "Üzgünüm, bir sorunla karşılaştım: ${result.errorMessage}",
                            sourceTitle = null,
                            sourceUrl = null
                        )
                    }
                }
                else -> {}
            }
        }
    }

    private fun handleCallContact(target: String) {
        val actionResult = actionManager.searchAndCall(target)
        if (!actionResult.isSuccess && actionResult.requiresPermission != null) {
            runOnUiThread {
                Toast.makeText(this, actionResult.message, Toast.LENGTH_LONG).show()
                requestNamedPermission(actionResult.requiresPermission)
            }
        }
    }

    fun startVoiceRecognition() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingPermissionCallback = { voiceManager.startListening() }
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            voiceManager.startListening()
        }
    }

    fun stopVoiceRecognition() {
        voiceManager.stopListening()
    }

    fun speakText(text: String) {
        voiceManager.speak(text)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun launchCameraCapture() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingPermissionCallback = { takePhotoLauncher.launch(null) }
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        } else {
            takePhotoLauncher.launch(null)
        }
    }

    fun launchPhotoPicker() {
        pickPhotoLauncher.launch(
            androidx.activity.result.PickVisualMediaRequest(
                ActivityResultContracts.PickVisualMedia.ImageOnly
            )
        )
    }

    fun showSettingsInApp() {
        evalJs("elements.settingsModal.classList.add('open');")
    }

    fun getPreferencesJson(): String {
        return JSONObject().apply {
            put("customApiKey", preferencesManager.getCustomApiKey())
            put("ttsAutoSpeak", preferencesManager.isTtsAutoSpeakEnabled())
            put("speechRate", preferencesManager.getSpeechRate().toDouble())
            put("webSearchEnabled", preferencesManager.isWebSearchEnabled())
        }.toString()
    }

    fun savePreferencesJson(prefsJson: String): Boolean {
        return try {
            val json = JSONObject(prefsJson)
            if (json.has("customApiKey")) {
                preferencesManager.setCustomApiKey(json.getString("customApiKey"))
            }
            if (json.has("ttsAutoSpeak")) {
                preferencesManager.setTtsAutoSpeakEnabled(json.getBoolean("ttsAutoSpeak"))
            }
            if (json.has("speechRate")) {
                val rate = json.getDouble("speechRate").toFloat()
                preferencesManager.setSpeechRate(rate)
                voiceManager.speechRate = rate
            }
            if (json.has("webSearchEnabled")) {
                preferencesManager.setWebSearchEnabled(json.getBoolean("webSearchEnabled"))
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getSessionsJson(): String {
        val array = JSONArray()
        try {
            // Bloklamadan senkron veya hızlı çekim
            val list = runBlockingOnIO { database.appDao().getSessionById(activeSessionId) }
            val sessionList = runBlockingOnIO {
                // Room Query for top 20 sessions
                val cursor = database.query("SELECT * FROM chat_sessions ORDER BY updatedAt DESC LIMIT 25", null)
                val items = mutableListOf<JSONObject>()
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(cursor.getColumnIndexOrThrow("id"))
                    val title = cursor.getString(cursor.getColumnIndexOrThrow("title"))
                    val updated = cursor.getLong(cursor.getColumnIndexOrThrow("updatedAt"))
                    items.add(JSONObject().apply {
                        put("id", id)
                        put("title", title)
                        put("lastTimestamp", updated)
                    })
                }
                cursor.close()
                items
            }

            for (item in sessionList) {
                array.put(item)
            }
        } catch (e: Exception) {
            array.put(JSONObject().apply {
                put("id", activeSessionId)
                put("title", "Sohbet")
                put("lastTimestamp", System.currentTimeMillis())
            })
        }
        return array.toString()
    }

    fun loadSessionJson(sessionId: Long): String {
        activeSessionId = sessionId
        preferencesManager.setActiveSessionId(sessionId)
        val array = JSONArray()
        try {
            val messages = runBlockingOnIO { database.appDao().getMessagesList(sessionId) }
            for (m in messages) {
                array.put(JSONObject().apply {
                    put("id", m.id)
                    put("role", m.role)
                    put("content", m.content)
                    put("imageUri", m.imageUri)
                    put("timestamp", m.timestamp)
                })
            }
        } catch (e: Exception) {
            // empty
        }
        return array.toString()
    }

    fun createNewSessionJson(): String {
        return try {
            val newId = runBlockingOnIO {
                database.appDao().insertSession(ChatSession(title = "Yeni Sohbet"))
            }
            activeSessionId = newId
            preferencesManager.setActiveSessionId(newId)
            JSONObject().apply {
                put("id", newId)
                put("title", "Yeni Sohbet")
                put("lastTimestamp", System.currentTimeMillis())
            }.toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("id", System.currentTimeMillis())
                put("title", "Yeni Sohbet")
            }.toString()
        }
    }

    fun deleteSessionById(sessionId: Long): Boolean {
        return try {
            lifecycleScope.launch(Dispatchers.IO) {
                database.appDao().deleteSessionById(sessionId)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun clearAllChatHistory(): Boolean {
        return try {
            lifecycleScope.launch(Dispatchers.IO) {
                database.appDao().deleteAllSessions()
                val newId = database.appDao().insertSession(ChatSession(title = "Sohbet"))
                activeSessionId = newId
                preferencesManager.setActiveSessionId(newId)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getPermissionsJson(): String {
        return permissionManager.getPermissionsStateJson()
    }

    fun requestNamedPermission(key: String) {
        requestPermissionLauncher.launch(key)
    }

    fun testApiKey(apiKey: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            val client = GeminiApiClient()
            val result = client.testConnection(apiKey)
            withContext(Dispatchers.Main) {
                if (result.isSuccess) {
                    Toast.makeText(this@MainActivity, "✓ Gemini API bağlantısı başarılı!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, "Hata: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ----------------------------------------------------
    // Helper Methods & Callbacks to JS
    // ----------------------------------------------------

    private fun handleSelectedBitmap(bitmap: Bitmap, name: String) {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val bytes = stream.toByteArray()
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        dispatchImageSelectedToJs(base64, "image/jpeg", name)
    }

    private fun handleSelectedUri(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        val outStream = ByteArrayOutputStream()
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outStream)
                        val bytes = outStream.toByteArray()
                        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                        withContext(Dispatchers.Main) {
                            dispatchImageSelectedToJs(base64, "image/jpeg", "image.jpg")
                        }
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Görsel yüklenemedi.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun dispatchMessageToJs(
        role: String,
        content: String,
        sourceTitle: String? = null,
        sourceUrl: String? = null
    ) {
        val json = JSONObject().apply {
            put("role", role)
            put("content", content)
            put("sourceTitle", sourceTitle)
            put("sourceUrl", sourceUrl)
            put("timestamp", System.currentTimeMillis())
        }
        evalJs("window.onSuesaMessageReceived(${json});")
    }

    private fun dispatchImageSelectedToJs(base64: String, mimeType: String, name: String) {
        evalJs("window.onImageSelected('$base64', '$mimeType', '$name');")
    }

    private fun notifyStateChange(statusText: String) {
        val json = JSONObject().apply { put("status", statusText) }
        evalJs("window.onSuesaStateChanged(${json});")
    }

    private fun notifyPermissionsUpdated() {
        val perms = permissionManager.getPermissionsStateJson()
        evalJs("window.onPermissionsUpdated($perms);")
    }

    private fun evalJs(script: String) {
        runOnUiThread {
            webView.evaluateJavascript(script, null)
        }
    }

    private fun <T> runBlockingOnIO(block: suspend () -> T): T {
        return kotlinx.coroutines.runBlocking(Dispatchers.IO) {
            block()
        }
    }

    // ----------------------------------------------------
    // VoiceEventListener Callbacks from VoiceManager
    // ----------------------------------------------------

    override fun onSpeechRecognized(text: String, isFinal: Boolean) {
        val safeText = JSONObject.quote(text)
        evalJs("window.onSpeechRecognized($safeText, $isFinal);")
    }

    override fun onListeningStateChanged(isListening: Boolean) {
        evalJs("window.onVoiceListeningChanged($isListening);")
    }

    override fun onSpeakingStateChanged(isSpeaking: Boolean) {
        evalJs("window.onVoiceSpeakingChanged($isSpeaking);")
    }

    override fun onRmsChanged(rmsdB: Float) {
        // Can be used for visualizer if desired
    }

    override fun onError(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            evalJs("window.onVoiceListeningChanged(false);")
        }
    }
}
