package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.audio.PrismAudioEngine
import com.example.data.SongRepository
import com.example.model.EqualizerPreset
import com.example.model.Song
import com.example.ui.components.EqualizerScreen
import com.example.ui.components.VisualizerCanvas
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.NowPlayingScreen
import com.example.ui.screens.SyncScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class MainScreen {
    LIBRARY,
    NOW_PLAYING,
    EQUALIZER,
    SYNC
}

class MainActivity : ComponentActivity() {

    private lateinit var repository: SongRepository
    private lateinit var audioEngine: PrismAudioEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        repository = SongRepository(applicationContext)
        audioEngine = PrismAudioEngine(applicationContext)

        setContent {
            MyApplicationTheme {
                PrismSoundApp(repository = repository, audioEngine = audioEngine)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        audioEngine.release()
    }
}

@Composable
fun PrismSoundApp(
    repository: SongRepository,
    audioEngine: PrismAudioEngine
) {
    var currentScreen by remember { mutableStateOf(MainScreen.LIBRARY) }

    val songs by repository.songs.collectAsStateWithLifecycle()
    val activeSong by repository.activeSong.collectAsStateWithLifecycle()
    val equalizerPresets by repository.equalizerPresets.collectAsStateWithLifecycle()
    val currentEqualizer by repository.currentEqualizer.collectAsStateWithLifecycle()
    val selectedVisualizerId by repository.selectedVisualizerId.collectAsStateWithLifecycle()
    val syncProfile by repository.syncProfile.collectAsStateWithLifecycle()

    val isPlaying by audioEngine.isPlaying.collectAsStateWithLifecycle()
    val currentPositionSec by audioEngine.currentPositionSec.collectAsStateWithLifecycle()
    val spectrumData by audioEngine.spectrumData.collectAsStateWithLifecycle()

    val scope = rememberCoroutineScope()

    // Handle back button for secondary screens
    if (currentScreen != MainScreen.LIBRARY) {
        BackHandler {
            currentScreen = MainScreen.LIBRARY
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .statusBarsPadding()
            .navigationBarsPadding(),
        bottomBar = {
            if (currentScreen != MainScreen.NOW_PLAYING) {
                Column {
                    // Persistent Mini Player
                    activeSong?.let { song ->
                        MiniPlayerBar(
                            song = song,
                            isPlaying = isPlaying,
                            selectedVisualizerId = selectedVisualizerId,
                            spectrumData = spectrumData,
                            onPlayPause = {
                                if (isPlaying) {
                                    audioEngine.pause()
                                } else {
                                    audioEngine.playSong(song, currentEqualizer)
                                }
                            },
                            onNext = {
                                val currentIndex = songs.indexOfFirst { it.id == song.id }
                                if (currentIndex != -1 && songs.isNotEmpty()) {
                                    val nextIndex = (currentIndex + 1) % songs.size
                                    val nextSong = songs[nextIndex]
                                    repository.selectSong(nextSong)
                                    audioEngine.playSong(nextSong, currentEqualizer)
                                }
                            },
                            onClick = { currentScreen = MainScreen.NOW_PLAYING }
                        )
                    }

                    // Navigation Bar
                    NavigationBar(
                        containerColor = SurfaceDark,
                        tonalElevation = 8.dp
                    ) {
                        NavigationBarItem(
                            selected = currentScreen == MainScreen.LIBRARY,
                            onClick = { currentScreen = MainScreen.LIBRARY },
                            icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Library") },
                            label = { Text("Library", fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ObsidianBg,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = Color.Gray,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("nav_item_library")
                        )

                        NavigationBarItem(
                            selected = currentScreen == MainScreen.NOW_PLAYING,
                            onClick = { currentScreen = MainScreen.NOW_PLAYING },
                            icon = { Icon(Icons.Default.PlayCircle, contentDescription = "Now Playing") },
                            label = { Text("Visualizer", fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ObsidianBg,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = Color.Gray,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("nav_item_now_playing")
                        )

                        NavigationBarItem(
                            selected = currentScreen == MainScreen.EQUALIZER,
                            onClick = { currentScreen = MainScreen.EQUALIZER },
                            icon = { Icon(Icons.Default.Equalizer, contentDescription = "Equalizer") },
                            label = { Text("Equalizer", fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ObsidianBg,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = Color.Gray,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("nav_item_equalizer")
                        )

                        NavigationBarItem(
                            selected = currentScreen == MainScreen.SYNC,
                            onClick = { currentScreen = MainScreen.SYNC },
                            icon = { Icon(Icons.Default.CloudSync, contentDescription = "Sync Hub") },
                            label = { Text("Sync", fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ObsidianBg,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = Color.Gray,
                                unselectedTextColor = Color.Gray
                            ),
                            modifier = Modifier.testTag("nav_item_sync")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                MainScreen.LIBRARY -> {
                    LibraryScreen(
                        songs = songs,
                        allDistinctTags = repository.allDistinctTags,
                        activeSong = activeSong,
                        isPlaying = isPlaying,
                        onSongSelected = { song ->
                            repository.selectSong(song)
                            audioEngine.playSong(song, currentEqualizer)
                        },
                        onToggleFavorite = { repository.toggleFavorite(it) },
                        onUpdateSongTags = { id, tags -> repository.setSongTags(id, tags) },
                        onImportSong = { title, artist, uri, duration ->
                            repository.addImportedSong(title, artist, uri, duration)
                        },
                        onNavigateToEqualizer = { currentScreen = MainScreen.EQUALIZER },
                        onNavigateToSync = { currentScreen = MainScreen.SYNC },
                        onNavigateToNowPlaying = { currentScreen = MainScreen.NOW_PLAYING }
                    )
                }

                MainScreen.NOW_PLAYING -> {
                    activeSong?.let { song ->
                        NowPlayingScreen(
                            song = song,
                            isPlaying = isPlaying,
                            currentPositionSec = currentPositionSec,
                            selectedVisualizerId = selectedVisualizerId,
                            spectrumData = spectrumData,
                            currentEqualizer = currentEqualizer,
                            onPlayPause = {
                                if (isPlaying) {
                                    audioEngine.pause()
                                } else {
                                    audioEngine.playSong(song, currentEqualizer)
                                }
                            },
                            onNext = {
                                val currentIndex = songs.indexOfFirst { it.id == song.id }
                                if (currentIndex != -1 && songs.isNotEmpty()) {
                                    val nextIndex = (currentIndex + 1) % songs.size
                                    val nextSong = songs[nextIndex]
                                    repository.selectSong(nextSong)
                                    audioEngine.playSong(nextSong, currentEqualizer)
                                }
                            },
                            onPrevious = {
                                val currentIndex = songs.indexOfFirst { it.id == song.id }
                                if (currentIndex != -1 && songs.isNotEmpty()) {
                                    val prevIndex = if (currentIndex - 1 < 0) songs.size - 1 else currentIndex - 1
                                    val prevSong = songs[prevIndex]
                                    repository.selectSong(prevSong)
                                    audioEngine.playSong(prevSong, currentEqualizer)
                                }
                            },
                            onSeek = { seconds -> audioEngine.seekTo(seconds) },
                            onToggleFavorite = { repository.toggleFavorite(song.id) },
                            onSelectVisualizer = { id -> repository.selectVisualizer(id) },
                            onRandomVisualizer = { repository.selectRandomVisualizer() },
                            onNavigateToEqualizer = { currentScreen = MainScreen.EQUALIZER },
                            onCollapse = { currentScreen = MainScreen.LIBRARY }
                        )
                    }
                }

                MainScreen.EQUALIZER -> {
                    EqualizerScreen(
                        currentPreset = currentEqualizer,
                        allPresets = equalizerPresets,
                        onPresetSelected = { preset ->
                            repository.setEqualizerPreset(preset)
                            audioEngine.updateEqualizer(preset)
                        },
                        on10BandsChanged = { b31, b62, b125, b250, b500, b1k, b2k, b4k, b8k, b16k, preamp, bassTone, trebleTone, stereoWidener, balance ->
                            repository.update10Bands(
                                b31 = b31, b62 = b62, b125 = b125, b250 = b250, b500 = b500,
                                b1k = b1k, b2k = b2k, b4k = b4k, b8k = b8k, b16k = b16k,
                                preamp = preamp, bassTone = bassTone, trebleTone = trebleTone,
                                stereoWidener = stereoWidener, balance = balance
                            )
                            audioEngine.updateEqualizer(repository.currentEqualizer.value)
                        },
                        onToggleLimiter = {
                            repository.toggleLimiter()
                            audioEngine.updateEqualizer(repository.currentEqualizer.value)
                        },
                        onToggleDvc = {
                            repository.toggleDvc()
                            audioEngine.updateEqualizer(repository.currentEqualizer.value)
                        },
                        onSaveCustomPreset = { name -> repository.saveCustomPreset(name) },
                        onDeleteCustomPreset = { id -> repository.deleteCustomPreset(id) },
                        onBack = { currentScreen = MainScreen.LIBRARY }
                    )
                }

                MainScreen.SYNC -> {
                    SyncScreen(
                        profile = syncProfile,
                        onTriggerCloudSync = {
                            repository.triggerCloudSyncSimulation {
                                // callback
                            }
                            scope.launch {
                                delay(1200)
                                repository.completeCloudSyncSimulation()
                            }
                        },
                        onExportBundle = { repository.exportSyncBundleJson() },
                        onImportBundle = { json -> repository.importSyncBundleJson(json) },
                        onUpdateServerUrl = { url -> repository.updateServerUrl(url) },
                        onBack = { currentScreen = MainScreen.LIBRARY }
                    )
                }
            }
        }
    }
}

@Composable
fun MiniPlayerBar(
    song: Song,
    isPlaying: Boolean,
    selectedVisualizerId: Int,
    spectrumData: com.example.audio.AudioSpectrumData,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceElevated)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("mini_player_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Live Mini-Visualizer thumbnail
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(ObsidianBg),
                contentAlignment = Alignment.Center
            ) {
                VisualizerCanvas(
                    visualizerId = selectedVisualizerId,
                    spectrumData = spectrumData,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Title & Artist
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = song.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(NeonCyan.copy(alpha = 0.15f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = song.codec,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NeonCyan
                        )
                    }
                }
                Text(
                    text = "${song.artist} • ${song.bitDepth}b/${song.sampleRateHz / 1000}kHz",
                    fontSize = 11.sp,
                    color = Color.LightGray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Play / Pause
            IconButton(
                onClick = onPlayPause,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(NeonCyan)
                    .testTag("mini_play_pause_btn")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = ObsidianBg,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = onNext,
                modifier = Modifier.size(38.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Next",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
