package com.example

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private var gameWebView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0F172A))
                ) {
                    NepaliPuzzleApp(
                        onWebViewReady = { webView ->
                            gameWebView = webView
                        },
                        onBackPressed = {
                            handleBackPressed()
                        }
                    )
                }
            }
        }
    }

    private fun handleBackPressed() {
        gameWebView?.let { wv ->
            wv.evaluateJavascript("window.onAndroidBackPressed ? window.onAndroidBackPressed() : false;") { result ->
                // If JavaScript handled the back press (e.g. closed a modal or returned to home screen)
                val handled = result == "true" || result == "\"true\""
                if (!handled) {
                    if (wv.canGoBack()) {
                        wv.goBack()
                    } else {
                        finish()
                    }
                }
            }
        } ?: run {
            finish()
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun NepaliPuzzleApp(
    onWebViewReady: (WebView) -> Unit,
    onBackPressed: () -> Unit
) {
    val context = LocalContext.current

    // Android system back navigation
    BackHandler {
        onBackPressed()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )

                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        allowFileAccess = true
                        cacheMode = WebSettings.LOAD_DEFAULT
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        builtInZoomControls = false
                        displayZoomControls = false
                        setSupportZoom(false)
                        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    }

                    // Native AdMob bridge
                    val bridge = AndroidAdMobBridge(ctx, this)
                    addJavascriptInterface(bridge, "AndroidAdMobBridge")

                    webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                        }
                    }

                    webChromeClient = WebChromeClient()

                    // Load bundled Nepali Puzzle web game from assets
                    loadUrl("file:///android_asset/nepali-puzzle/index.html")
                    onWebViewReady(this)
                }
            },
            update = { /* Updates if needed */ }
        )
    }
}

/**
 * Android JavaScriptInterface Bridge for Google Mobile Ads (AdMob)
 * and native device capabilities (haptics, sharing)
 */
class AndroidAdMobBridge(
    private val context: Context,
    private val webView: WebView
) {
    @JavascriptInterface
    fun isAndroidApp(): Boolean = true

    @JavascriptInterface
    fun showRewardedAd() {
        (context as? ComponentActivity)?.runOnUiThread {
            AlertDialog.Builder(context)
                .setTitle("गुगल एडमोब टेस्ट विज्ञापन (AdMob Rewarded)")
                .setMessage("नेपाली पजल: ५ सेकेन्डको परीक्षण विज्ञापन हेरेर +२५ सिक्का प्राप्त गर्नुहोस्।")
                .setPositiveButton("सिक्का लिनुहोस् (+२५)") { _, _ ->
                    webView.evaluateJavascript("window.onNativeRewardedAdCompleted(25);", null)
                    Toast.makeText(context, "+२५ सिक्का थपियो! 🎉", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("रद्द गर्नुहोस्") { _, _ ->
                    webView.evaluateJavascript("window.onNativeRewardedAdFailed('विज्ञापन रद्द गरियो');", null)
                }
                .setCancelable(false)
                .show()
        }
    }

    @JavascriptInterface
    fun showInterstitialAd() {
        (context as? ComponentActivity)?.runOnUiThread {
            AlertDialog.Builder(context)
                .setTitle("🎉 स्तर सम्पन्न! (AdMob Interstitial)")
                .setMessage("प्राकृतिक विश्राम विज्ञापन (AdMob Test Interstitial Unit: ca-app-pub-3940256099942544/1033173712)")
                .setPositiveButton("जारी राख्नुहोस्") { _, _ ->
                    webView.evaluateJavascript("window.onNativeInterstitialDismissed();", null)
                }
                .setCancelable(false)
                .show()
        }
    }

    @JavascriptInterface
    fun showBannerAd() {
        // Native banner integration hook
    }

    @JavascriptInterface
    fun hideBannerAd() {
        // Native banner hide hook
    }

    @JavascriptInterface
    fun vibrateHaptic(durationMs: Long) {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(
                        durationMs.coerceAtLeast(10),
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    @JavascriptInterface
    fun shareGameProgress(score: Int, solved: Int) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(
                    Intent.EXTRA_TEXT,
                    "मैले 'नेपाली पजल — दिमाग खेल' मा $score अङ्क प्राप्त गरी $solved वटा पजलहरू हल गरेँ! तपाईं पनि खेल्नुहोस्।"
                )
            }
            context.startActivity(Intent.createChooser(shareIntent, "साथीहरूलाई सेयर गर्नुहोस्"))
        } catch (_: Exception) {}
    }
}
