package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppTab
import com.example.ui.ChaufalandViewModel
import com.example.ui.components.MinecraftBannerHeader
import com.example.ui.components.MinecraftButton
import com.example.ui.components.PlayerAvatar
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.GuideScreen
import com.example.ui.screens.RadarScreen
import com.example.ui.screens.ServerScreen
import com.example.ui.screens.VoiceScreen
import com.example.ui.theme.MinecraftBackground
import com.example.ui.theme.MinecraftBorder
import com.example.ui.theme.MinecraftEmerald
import com.example.ui.theme.MinecraftGold
import com.example.ui.theme.MinecraftGrass
import com.example.ui.theme.MinecraftRedstone
import com.example.ui.theme.MinecraftSurface
import com.example.ui.theme.MinecraftSurfaceVariant
import com.example.ui.theme.MinecraftText
import com.example.ui.theme.MinecraftTextDim
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        ChaufalandApp()
      }
    }
  }
}

@Composable
fun ChaufalandApp(viewModel: ChaufalandViewModel = viewModel()) {
  val currentTab by viewModel.currentTab.collectAsState()
  val showGamerTagDialog by viewModel.showGamerTagDialog.collectAsState()
  val gamerTag by viewModel.gamerTag.collectAsState()
  val currentVoiceChannel by viewModel.currentVoiceChannel.collectAsState()
  val notification by viewModel.notification.collectAsState()
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(notification) {
    notification?.let {
      snackbarHostState.showSnackbar(it.message)
      viewModel.dismissNotice()
    }
  }

  // DIÁLOGO OBLIGATORIO DE GAMERTAG
  if (showGamerTagDialog) {
    GamerTagSetupDialog(
      initialTag = gamerTag,
      onSave = { viewModel.saveGamerTag(it) },
      canDismiss = gamerTag.isNotBlank(),
      onDismiss = { viewModel.closeGamerTagDialog() }
    )
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    containerColor = MinecraftBackground
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MinecraftBackground)
    ) {
      // 1. BANNER/HEADER OFICIAL CON LOGO 3D CHAUFALAND Y FONDO DIRT
      MinecraftBannerHeader()

      // 2. BARRA DE PESTAÑAS (TABS)
      AppNavigationBar(
        currentTab = currentTab,
        onTabSelected = { viewModel.setTab(it) }
      )

      // 3. CONTENIDO PRINCIPAL SEGÚN PESTAÑA SELECCIONADA
      Box(modifier = Modifier.weight(1f)) {
        when (currentTab) {
          AppTab.SERVER -> ServerScreen(viewModel = viewModel)
          AppTab.VOICE -> VoiceScreen(viewModel = viewModel)
          AppTab.RADAR -> RadarScreen(viewModel = viewModel)
          AppTab.GUIDE -> GuideScreen()
          AppTab.ADMIN -> AdminScreen(viewModel = viewModel)
        }
      }

      // 4. BARRA INFERIOR DE ESTADO DEL USUARIO
      BottomUserStatusBar(
        gamerTag = gamerTag,
        channelName = currentVoiceChannel?.name,
        onChangeGamerTagClick = { viewModel.openGamerTagDialog() }
      )
    }
  }
}

@Composable
private fun AppNavigationBar(
  currentTab: AppTab,
  onTabSelected: (AppTab) -> Unit
) {
  val scrollState = rememberScrollState()

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(Color(0xFF1B140F))
      .border(1.dp, MinecraftBorder)
      .horizontalScroll(scrollState)
      .padding(horizontal = 8.dp, vertical = 6.dp),
    horizontalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    AppTab.values().forEach { tab ->
      val isSelected = currentTab == tab
      val (bg, txt) = when {
        isSelected -> MinecraftGrass to Color.White
        tab == AppTab.ADMIN -> Color(0xFF6B1D1D) to MinecraftGold
        else -> MinecraftSurfaceVariant to MinecraftText
      }

      Box(
        modifier = Modifier
          .background(bg, RoundedCornerShape(2.dp))
          .border(
            1.dp,
            if (isSelected) MinecraftEmerald else MinecraftBorder,
            RoundedCornerShape(2.dp)
          )
          .clickable { onTabSelected(tab) }
          .padding(horizontal = 10.dp, vertical = 6.dp)
          .testTag("nav_tab_${tab.name.lowercase()}"),
        contentAlignment = Alignment.Center
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = tab.icon, fontSize = 13.sp)
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = tab.title.uppercase(),
            color = txt,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}

@Composable
private fun BottomUserStatusBar(
  gamerTag: String,
  channelName: String?,
  onChangeGamerTagClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(Color(0xFF16100B))
      .border(1.dp, MinecraftBorder)
      .padding(horizontal = 12.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.clickable { onChangeGamerTagClick() }
    ) {
      PlayerAvatar(gamerTag = gamerTag.ifBlank { "Steve" }, size = 32.dp)
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = gamerTag.ifBlank { "Ingresar GamerTag" },
            color = MinecraftGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(text = "✏️", fontSize = 10.sp)
        }
        Text(
          text = channelName?.let { "🔊 $it" } ?: "Sin voz",
          color = if (channelName != null) MinecraftEmerald else MinecraftTextDim,
          fontSize = 10.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Box(
      modifier = Modifier
        .background(Color(0xFF2A1F17), RoundedCornerShape(2.dp))
        .border(1.dp, MinecraftBorder, RoundedCornerShape(2.dp))
        .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
      Text(
        text = "CHAUFALAND v1.0",
        color = MinecraftTextDim,
        fontSize = 10.sp,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}

@Composable
fun GamerTagSetupDialog(
  initialTag: String,
  onSave: (String) -> Unit,
  canDismiss: Boolean,
  onDismiss: () -> Unit
) {
  var tagInput by remember { mutableStateOf(initialTag) }

  AlertDialog(
    onDismissRequest = {
      if (canDismiss) onDismiss()
    },
    confirmButton = {
      MinecraftButton(
        text = "ENTRAR A CHAUFALAND ⛏️",
        containerColor = MinecraftGrass,
        onClick = {
          if (tagInput.isNotBlank()) {
            onSave(tagInput.trim())
          }
        },
        modifier = Modifier.fillMaxWidth(),
        testTag = "btn_dialog_save_gamertag"
      )
    },
    title = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(text = "⛏️", fontSize = 28.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "BIENVENIDO A CHAUFALAND",
          color = MinecraftGold,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "Ingresa obligatoriamente tu GamerTag real de Minecraft para conectar tu voz y skin:",
          color = MinecraftText,
          fontSize = 12.sp,
          fontFamily = FontFamily.Monospace,
          lineHeight = 16.sp
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = tagInput,
          onValueChange = { tagInput = it },
          placeholder = { Text("Ej: Juansito", color = MinecraftTextDim) },
          singleLine = true,
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF140F0C),
            unfocusedContainerColor = Color(0xFF140F0C),
            focusedBorderColor = MinecraftGold,
            unfocusedBorderColor = MinecraftBorder,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("input_dialog_gamertag")
        )
      }
    },
    containerColor = MinecraftSurface,
    shape = RoundedCornerShape(4.dp),
    modifier = Modifier.border(2.dp, MinecraftGold, RoundedCornerShape(4.dp))
  )
}
