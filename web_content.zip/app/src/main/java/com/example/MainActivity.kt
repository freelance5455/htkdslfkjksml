package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.TopAppHeader
import com.example.ui.screens.AddCommitteeMemberScreen
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.EntryScreen
import com.example.ui.screens.ProgramsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AiViewModel
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()
    private val aiViewModel: AiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Mandatory App Check configuration with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainApp(viewModel = viewModel, aiViewModel = aiViewModel)
            }
        }
    }
}

@Composable
fun MainApp(
    viewModel: MainViewModel,
    aiViewModel: AiViewModel
) {
    val currentView by viewModel.currentView.collectAsState()
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()

    // Handle back button: if in secondary views, return to form view
    BackHandler(enabled = currentView != "form") {
        if (currentView == "add_committee_member") {
            viewModel.currentView.value = "list"
        } else {
            viewModel.currentView.value = "form"
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            TopAppHeader(
                isAdminLoggedIn = isAdminLoggedIn,
                onAdminClick = {
                    if (isAdminLoggedIn) {
                        viewModel.currentView.value = if (currentView == "form") "list" else "form"
                    } else {
                        // Switch to admin view to show the password check screen
                        viewModel.currentView.value = "list"
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("main_bottom_nav")
            ) {
                NavigationBarItem(
                    selected = currentView == "form",
                    onClick = { viewModel.currentView.value = "form" },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = "ডাটা এন্ট্রি",
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "এন্ট্রি",
                            fontSize = 11.sp,
                            fontWeight = if (currentView == "form") FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF15803D),
                        selectedTextColor = Color(0xFF15803D),
                        indicatorColor = Color(0xFFDCFCE7),
                        unselectedIconColor = Color(0xFF1F2937),
                        unselectedTextColor = Color(0xFF1F2937)
                    ),
                    modifier = Modifier.testTag("nav_item_entry")
                )

                NavigationBarItem(
                    selected = currentView == "programs",
                    onClick = { viewModel.currentView.value = "programs" },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "কর্মসূচি",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "কর্মসূচি",
                            fontSize = 11.sp,
                            fontWeight = if (currentView == "programs") FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF15803D),
                        selectedTextColor = Color(0xFF15803D),
                        indicatorColor = Color(0xFFDCFCE7),
                        unselectedIconColor = Color(0xFF1F2937),
                        unselectedTextColor = Color(0xFF1F2937)
                    ),
                    modifier = Modifier.testTag("nav_item_programs")
                )

                NavigationBarItem(
                    selected = currentView == "ai",
                    onClick = { viewModel.currentView.value = "ai" },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI সহকারী",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "AI সহকারী",
                            fontSize = 11.sp,
                            fontWeight = if (currentView == "ai") FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF15803D),
                        selectedTextColor = Color(0xFF15803D),
                        indicatorColor = Color(0xFFDCFCE7),
                        unselectedIconColor = Color(0xFF1F2937),
                        unselectedTextColor = Color(0xFF1F2937)
                    ),
                    modifier = Modifier.testTag("nav_item_ai")
                )

                NavigationBarItem(
                    selected = currentView == "list",
                    onClick = { viewModel.currentView.value = "list" },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "ড্যাশবোর্ড",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "ড্যাশবোর্ড",
                            fontSize = 11.sp,
                            fontWeight = if (currentView == "list") FontWeight.Bold else FontWeight.SemiBold
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF15803D),
                        selectedTextColor = Color(0xFF15803D),
                        indicatorColor = Color(0xFFDCFCE7),
                        unselectedIconColor = Color(0xFF1F2937),
                        unselectedTextColor = Color(0xFF1F2937)
                    ),
                    modifier = Modifier.testTag("nav_item_admin")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentView) {
                "programs" -> ProgramsScreen(viewModel = viewModel)
                "ai" -> AiAssistantScreen(aiViewModel = aiViewModel)
                "list" -> AdminScreen(
                    viewModel = viewModel,
                    onOpenAddCommitteeMember = { viewModel.currentView.value = "add_committee_member" }
                )
                "add_committee_member" -> AddCommitteeMemberScreen(
                    onNavigateBack = { viewModel.currentView.value = "list" }
                )
                else -> EntryScreen(viewModel = viewModel)
            }
        }
    }
}
