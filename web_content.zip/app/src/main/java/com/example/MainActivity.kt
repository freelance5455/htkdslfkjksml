package com.example

import android.annotation.SuppressLint
import android.content.ContentValues
import android.graphics.Color as AndroidColor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.CreditRepository
import com.example.data.UserAccount
import com.example.ui.AdminPanelScreen
import com.example.ui.AdminViewModel
import com.example.ui.PixelForgeAuthScreen
import com.example.ui.UiState
import com.example.ui.attemptAutoSignIn
import com.example.ui.signOutUser
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class MainActivity : ComponentActivity() {

  private var pendingFilePathCallback: ValueCallback<Array<Uri>>? = null
  private var isFullscreen by mutableStateOf(false)
  private var webViewRef: WebView? = null

  private val pickImageLauncher =
      registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val callback = pendingFilePathCallback
        pendingFilePathCallback = null
        if (callback != null) {
          if (uri != null) {
            callback.onReceiveValue(arrayOf(uri))
          } else {
            callback.onReceiveValue(null)
          }
        }
      }

  private val fallbackGetContentLauncher =
      registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val callback = pendingFilePathCallback
        pendingFilePathCallback = null
        if (callback != null) {
          if (uri != null) {
            callback.onReceiveValue(arrayOf(uri))
          } else {
            callback.onReceiveValue(null)
          }
        }
      }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
        statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
        navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
    )

    setContent {
      MaterialTheme(
          colorScheme =
              darkColorScheme(
                  primary = Color(0xFF00D2FF),
                  secondary = Color(0xFF6366F1),
                  background = Color(0xFF080A0F),
                  surface = Color(0xFF101521),
              )
      ) {
        AppNavigation(
            isFullscreen = isFullscreen,
            onExitFullscreen = { applyFullscreen(false) },
            onConfigureWebView = { webView ->
              webViewRef = webView
              configureWebView(webView)
              webView.loadUrl("file:///android_asset/pixelforge_ai.html")
            },
        )
      }
    }
  }

  @SuppressLint("SetJavaScriptEnabled")
  private fun configureWebView(webView: WebView) {
    webView.setBackgroundColor(AndroidColor.parseColor("#080A0F"))
    webView.settings.apply {
      javaScriptEnabled = true
      domStorageEnabled = true
      allowFileAccess = true
      allowContentAccess = true
      useWideViewPort = true
      loadWithOverviewMode = true
      setSupportZoom(false)
      builtInZoomControls = false
      displayZoomControls = false
      mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
    }

    webView.addJavascriptInterface(PixelForgeAndroidBridge(), "AndroidBridge")

    webView.webViewClient =
        object : WebViewClient() {
          override fun shouldOverrideUrlLoading(
              view: WebView?,
              request: WebResourceRequest?,
          ): Boolean {
            return false
          }
        }

    webView.webChromeClient =
        object : WebChromeClient() {
          override fun onShowFileChooser(
              webView: WebView?,
              filePathCallback: ValueCallback<Array<Uri>>?,
              fileChooserParams: FileChooserParams?,
          ): Boolean {
            pendingFilePathCallback?.onReceiveValue(null)
            pendingFilePathCallback = filePathCallback

            return try {
              if (ActivityResultContracts.PickVisualMedia.isPhotoPickerAvailable(this@MainActivity)) {
                pickImageLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
              } else {
                fallbackGetContentLauncher.launch("image/*")
              }
              true
            } catch (_: Exception) {
              pendingFilePathCallback?.onReceiveValue(null)
              pendingFilePathCallback = null
              false
            }
          }
        }
  }

  private fun applyFullscreen(enabled: Boolean) {
    isFullscreen = enabled
    val controller = WindowCompat.getInsetsController(window, window.decorView)
    controller.systemBarsBehavior =
        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    if (enabled) {
      controller.hide(WindowInsetsCompat.Type.systemBars())
    } else {
      controller.show(WindowInsetsCompat.Type.systemBars())
    }
  }

  inner class PixelForgeAndroidBridge {
    @JavascriptInterface
    fun setFullscreen(enabled: Boolean) {
      runOnUiThread { applyFullscreen(enabled) }
    }

    @JavascriptInterface
    fun saveImage(dataUrl: String, fileName: String, mimeType: String): Boolean {
      return try {
        val base64Part = dataUrl.substringAfter("base64,", missingDelimiterValue = "")
        if (base64Part.isEmpty()) return false
        val bytes = Base64.decode(base64Part, Base64.DEFAULT)
        if (bytes.isEmpty()) return false

        val safeName = fileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          val values =
              ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    "${Environment.DIRECTORY_PICTURES}/PixelForgeAI",
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
              }
          val uri =
              contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                  ?: return false
          contentResolver.openOutputStream(uri)?.use { out -> out.write(bytes) } ?: return false
          values.clear()
          values.put(MediaStore.Images.Media.IS_PENDING, 0)
          contentResolver.update(uri, values, null, null)
          true
        } else {
          val dir = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "PixelForgeAI")
          if (!dir.exists()) dir.mkdirs()
          val outFile = File(dir, safeName)
          FileOutputStream(outFile).use { it.write(bytes) }
          true
        }
      } catch (_: Exception) {
        false
      }
    }
  }

  override fun onDestroy() {
    pendingFilePathCallback?.onReceiveValue(null)
    pendingFilePathCallback = null
    webViewRef?.destroy()
    webViewRef = null
    super.onDestroy()
  }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
  val listener = FirebaseAuth.AuthStateListener { auth -> trySend(auth.currentUser) }
  addAuthStateListener(listener)
  awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun AppNavigation(
    isFullscreen: Boolean,
    onExitFullscreen: () -> Unit,
    onConfigureWebView: (WebView) -> Unit,
) {
  val context = LocalContext.current
  val scope = androidx.compose.runtime.rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }
  val auth = remember { Firebase.auth }
  val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)

  var autoSignInAttempted by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    if (!autoSignInAttempted) {
      autoSignInAttempted = true
      attemptAutoSignIn(
          context = context,
          credentialManager = credentialManager,
          onAuthSuccess = {},
          onUnauthenticated = {},
          scope = scope,
      )
    }
  }

  val safeModifier =
      Modifier.fillMaxSize()
          .background(Color(0xFF080A0F))
          .let { mod ->
            if (isFullscreen) mod
            else mod.windowInsetsPadding(WindowInsets.safeDrawing).imePadding()
          }

  Box(modifier = safeModifier) {
    val user = currentUser
    if (user == null) {
      PixelForgeAuthScreen(onAuthSuccess = {})
    } else {
      key(user.uid) {
        val adminViewModel: AdminViewModel =
            viewModel(
                key = user.uid,
                factory =
                    viewModelFactory {
                      initializer {
                        val app =
                            checkNotNull(this[APPLICATION_KEY]) {
                              "APPLICATION_KEY missing from CreationExtras"
                            }
                        val databaseId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(databaseId)
                        AdminViewModel(
                            repository = CreditRepository(db, Firebase.auth),
                            currentUserId = user.uid,
                            currentUserEmail = user.email ?: "",
                        )
                      }
                    },
            )

        AuthenticatedWorkspace(
            user = user,
            viewModel = adminViewModel,
            isFullscreen = isFullscreen,
            onExitFullscreen = onExitFullscreen,
            onConfigureWebView = onConfigureWebView,
            onSignOut = {
              signOutUser(
                  credentialManager = credentialManager,
                  scope = scope,
              )
            },
        )
      }
    }
  }
}

@Composable
fun AuthenticatedWorkspace(
    user: FirebaseUser,
    viewModel: AdminViewModel,
    isFullscreen: Boolean,
    onExitFullscreen: () -> Unit,
    onConfigureWebView: (WebView) -> Unit,
    onSignOut: () -> Unit,
) {
  var showAdminPanel by remember { mutableStateOf(false) }
  val accountState by viewModel.currentAccountState.collectAsStateWithLifecycle()
  val account = (accountState as? UiState.Success)?.data
  val isAdmin =
      account?.isAdmin == true ||
          user.email.equals(UserAccount.BOOTSTRAPPED_ADMIN_EMAIL, ignoreCase = true)

  BackHandler(enabled = showAdminPanel || isFullscreen) {
    if (showAdminPanel) {
      showAdminPanel = false
    } else if (isFullscreen) {
      onExitFullscreen()
    }
  }

  Column(modifier = Modifier.fillMaxSize()) {
    if (!isFullscreen) {
      Row(
          modifier =
              Modifier.fillMaxWidth()
                  .background(Color(0xFF0C101A))
                  .border(1.dp, Color.White.copy(alpha = 0.08f))
                  .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
              text = account?.displayName ?: user.displayName ?: "PixelForge Account",
              color = Color(0xFFF1F5F9),
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.5.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
          )
          Text(
              text = user.email ?: "",
              color = Color(0xFF94A3B8),
              fontSize = 10.5.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
          )
        }

        Surface(
            shape = RoundedCornerShape(99.dp),
            color = Color(0xFF152033),
            border =
                androidx.compose.foundation.BorderStroke(
                    1.dp,
                    Color(0xFF00D2FF).copy(alpha = 0.35f),
                ),
        ) {
          Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Icon(
                imageVector = Icons.Filled.Bolt,
                contentDescription = "Credit balance",
                tint = Color(0xFF00D2FF),
                modifier = Modifier.size(14.dp),
            )
            Text(
                text = "${account?.credits ?: 0} cr",
                color = Color(0xFFF1F5F9),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
            )
          }
        }

        Button(
            onClick = { showAdminPanel = !showAdminPanel },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
            modifier =
                Modifier.height(34.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("open_admin_panel_btn"),
            shape = RoundedCornerShape(8.dp),
            colors =
                ButtonDefaults.buttonColors(
                    containerColor =
                        if (showAdminPanel) Color(0xFF6366F1)
                        else if (isAdmin) Color(0xFF00D2FF)
                        else Color(0xFF1E293B),
                    contentColor =
                        if (!showAdminPanel && isAdmin) Color(0xFF050811) else Color(0xFFF1F5F9),
                ),
        ) {
          Icon(
              imageVector = Icons.Filled.AdminPanelSettings,
              contentDescription = null,
              modifier = Modifier.size(15.dp),
          )
          Text(
              text =
                  if (showAdminPanel) "Editor"
                  else if (isAdmin) "Admin"
                  else "Wallet",
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(start = 4.dp),
          )
        }

        IconButton(
            onClick = onSignOut,
            modifier = Modifier.size(36.dp).minimumInteractiveComponentSize().testTag("sign_out_btn"),
        ) {
          Icon(
              imageVector = Icons.AutoMirrored.Filled.Logout,
              contentDescription = "Sign out",
              tint = Color(0xFF94A3B8),
              modifier = Modifier.size(18.dp),
          )
        }
      }
    }

    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
      // Keep WebView composed so user edits aren't lost while opening/closing Admin Panel
      AndroidView(
          modifier = Modifier.fillMaxSize().testTag("pixelforge_webview"),
          factory = { context ->
            WebView(context).apply {
              layoutParams =
                  ViewGroup.LayoutParams(
                      ViewGroup.LayoutParams.MATCH_PARENT,
                      ViewGroup.LayoutParams.MATCH_PARENT,
                  )
              onConfigureWebView(this)
            }
          },
      )

      if (showAdminPanel) {
        AdminPanelScreen(
            viewModel = viewModel,
            onBackToEditor = { showAdminPanel = false },
            modifier = Modifier.fillMaxSize(),
        )
      }
    }
  }
}
