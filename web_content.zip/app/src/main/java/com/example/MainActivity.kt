package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.ThemeMode
import com.example.ui.navigation.AppNavGraph
import com.example.ui.theme.AtcWeatherTheme
import com.example.ui.viewmodel.WeatherViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: WeatherViewModel = viewModel()
      val settings by viewModel.appSettings.collectAsState()
      val systemDark = isSystemInDarkTheme()

      val isDark = when (settings.themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> systemDark
      }

      AtcWeatherTheme(darkTheme = isDark) {
        AppNavGraph(viewModel = viewModel)
      }
    }
  }
}
