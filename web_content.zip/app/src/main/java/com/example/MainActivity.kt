package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppSettingsEntity
import com.example.ui.auth.AuthViewModel
import com.example.ui.auth.AuthViewModelFactory
import com.example.ui.auth.ForgotPasswordDialog
import com.example.ui.auth.LoginScreen
import com.example.ui.auth.RecoveryCodeDialog
import com.example.ui.auth.ResetAppDialog
import com.example.ui.auth.ScreenDestination
import com.example.ui.auth.SignUpScreen
import com.example.ui.main.MainScreen
import com.example.ui.notes.NotesViewModel
import com.example.ui.notes.NotesViewModelFactory
import com.example.ui.profile.ProfileViewModel
import com.example.ui.profile.ProfileViewModelFactory
import com.example.ui.settings.SettingsViewModel
import com.example.ui.settings.SettingsViewModelFactory
import com.example.ui.study.StudyViewModel
import com.example.ui.study.StudyViewModelFactory
import com.example.ui.theme.DailyStudyTheme

class MainActivity : ComponentActivity() {

    private val authViewModel: AuthViewModel by viewModels {
        val app = application as DailyStudyApplication
        AuthViewModelFactory(app.authRepository)
    }

    private val profileViewModel: ProfileViewModel by viewModels {
        val app = application as DailyStudyApplication
        ProfileViewModelFactory(app.profileRepository)
    }

    private val settingsViewModel: SettingsViewModel by viewModels {
        val app = application as DailyStudyApplication
        SettingsViewModelFactory(app.settingsRepository, app.backupManager)
    }

    private val studyViewModel: StudyViewModel by viewModels {
        val app = application as DailyStudyApplication
        StudyViewModelFactory(app.subjectRepository, app.studySessionRepository, app.examRepository)
    }

    private val notesViewModel: NotesViewModel by viewModels {
        val app = application as DailyStudyApplication
        NotesViewModelFactory(app.noteRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settingsState by settingsViewModel.uiState.collectAsStateWithLifecycle()
            val authState by authViewModel.uiState.collectAsStateWithLifecycle()
            val profileState by profileViewModel.uiState.collectAsStateWithLifecycle()
            val studyState by studyViewModel.uiState.collectAsStateWithLifecycle()
            val notesState by notesViewModel.uiState.collectAsStateWithLifecycle()
            val context = LocalContext.current

            DailyStudyTheme(themeMode = settingsState.appliedThemeMode) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    when (authState.currentScreen) {
                        ScreenDestination.LOADING -> {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        ScreenDestination.SIGN_UP -> {
                            SignUpScreen(
                                state = authState,
                                onUsernameChange = authViewModel::onUsernameChange,
                                onToggleUsernameVisibility = authViewModel::toggleUsernameVisibility,
                                onPasswordChange = authViewModel::onPasswordChange,
                                onTogglePasswordVisibility = authViewModel::togglePasswordVisibility,
                                onSignUpClick = authViewModel::onSignUp,
                                onSwitchToLoginClick = authViewModel::switchToLogin
                            )
                        }

                        ScreenDestination.LOGIN -> {
                            LoginScreen(
                                state = authState,
                                onUsernameChange = authViewModel::onUsernameChange,
                                onToggleUsernameVisibility = authViewModel::toggleUsernameVisibility,
                                onPasswordChange = authViewModel::onPasswordChange,
                                onTogglePasswordVisibility = authViewModel::togglePasswordVisibility,
                                onLoginClick = authViewModel::onLogin,
                                onSwitchToSignUpClick = authViewModel::switchToSignUp,
                                onForgotPasswordClick = authViewModel::openForgotPasswordDialog,
                                onResetAppClick = authViewModel::openResetAppDialog
                            )
                        }

                        ScreenDestination.AUTHENTICATED -> {
                            MainScreen(
                                currentUser = authState.currentUser,
                                profileState = profileState,
                                settingsState = settingsState,
                                studyState = studyState,
                                notesState = notesState,
                                onNameChange = profileViewModel::onEditNameChange,
                                onInstituteChange = profileViewModel::onEditInstituteChange,
                                onPhotoSelected = { uri -> profileViewModel.onPhotoPicked(context, uri) },
                                onRemovePhoto = profileViewModel::onRemovePhoto,
                                onOpenProfileEdit = profileViewModel::openEditDialog,
                                onCloseProfileEdit = profileViewModel::closeEditDialog,
                                onSaveProfile = profileViewModel::saveProfile,
                                onSelectPreviewTheme = settingsViewModel::onSelectPreviewTheme,
                                onApplyTheme = settingsViewModel::applyTheme,
                                onExportBackup = settingsViewModel::exportBackup,
                                onRestoreBackup = settingsViewModel::restoreBackup,
                                onDismissBackupFeedback = settingsViewModel::dismissBackupFeedback,
                                onLogout = authViewModel::logout,
                                // Timer callbacks
                                onStartTimer = studyViewModel::startTimer,
                                onPauseTimer = studyViewModel::pauseTimer,
                                onResumeTimer = studyViewModel::resumeTimer,
                                onStopTimer = studyViewModel::stopTimerAndOpenLog,
                                onResetTimer = studyViewModel::resetTimer,
                                onSelectTimerSubject = studyViewModel::selectTimerSubject,
                                // Subject callbacks
                                onOpenAddSubject = studyViewModel::openAddSubjectDialog,
                                onOpenEditSubject = studyViewModel::openEditSubjectDialog,
                                onCloseSubjectDialog = studyViewModel::closeSubjectDialog,
                                onSubjectNameChange = studyViewModel::onSubjectNameChange,
                                onSubjectColorChange = studyViewModel::onSubjectColorChange,
                                onSubjectIconChange = studyViewModel::onSubjectIconChange,
                                onSubjectTargetHoursChange = studyViewModel::onSubjectTargetHoursChange,
                                onSaveSubject = studyViewModel::saveSubject,
                                onOpenArchiveConfirm = studyViewModel::openArchiveConfirmDialog,
                                onCloseArchiveConfirm = studyViewModel::closeArchiveConfirmDialog,
                                onConfirmArchiveSubject = studyViewModel::confirmArchiveSubject,
                                onRestoreSubject = studyViewModel::restoreSubject,
                                onToggleArchivedSection = studyViewModel::toggleArchivedSection,
                                // Session callbacks
                                onOpenAddManualSession = studyViewModel::openAddManualSessionDialog,
                                onOpenEditSession = studyViewModel::openEditSessionDialog,
                                onCloseSessionDialog = studyViewModel::closeSessionDialog,
                                onSessionSubjectChange = studyViewModel::onSessionSubjectChange,
                                onSessionDateChange = studyViewModel::onSessionDateChange,
                                onSessionStartTimeChange = studyViewModel::onSessionStartTimeChange,
                                onSessionHoursChange = studyViewModel::onSessionHoursChange,
                                onSessionMinutesChange = studyViewModel::onSessionMinutesChange,
                                onSessionTopicChange = studyViewModel::onSessionTopicChange,
                                onSessionRemarkChange = studyViewModel::onSessionRemarkChange,
                                onSaveSession = studyViewModel::saveSession,
                                onOpenDeleteSessionConfirm = studyViewModel::openDeleteSessionConfirm,
                                onCloseDeleteSessionConfirm = studyViewModel::closeDeleteSessionConfirm,
                                onConfirmDeleteSession = studyViewModel::confirmDeleteSession,
                                onAddExam = studyViewModel::addExam,
                                onUpdateExam = studyViewModel::updateExam,
                                onDeleteExam = studyViewModel::deleteExam,
                                // Note callbacks (PRD section 6)
                                onNotesSearchChange = notesViewModel::onSearchQueryChange,
                                onNotesSortChange = notesViewModel::onSortModeChange,
                                onNotesSubjectFilterChange = notesViewModel::onSubjectFilterChange,
                                onOpenNewNote = notesViewModel::openNewNote,
                                onOpenEditNote = notesViewModel::openEditNote,
                                onCloseNoteEditor = notesViewModel::closeEditor,
                                onTogglePinInList = notesViewModel::onTogglePinInList,
                                onNoteTitleChange = notesViewModel::onTitleChange,
                                onNoteDocumentChange = notesViewModel::onDocumentChange,
                                onNoteSubjectChange = notesViewModel::onSubjectChange,
                                onTogglePinInEditor = notesViewModel::onTogglePin,
                                onFontFamilyChange = notesViewModel::onFontFamilyChange,
                                onFontSizeChange = notesViewModel::onFontSizeChange,
                                onAlignmentChange = notesViewModel::onAlignmentChange,
                                onBlockTypeChange = notesViewModel::setBlockType,
                                onBlockTextChange = notesViewModel::updateBlockText,
                                onToggleChecklist = notesViewModel::toggleChecklist,
                                onAddBlock = notesViewModel::addBlock,
                                onRemoveBlock = notesViewModel::removeBlock,
                                onApplyInlineSpan = notesViewModel::applyInlineSpanToBlock,
                                onUndoNote = notesViewModel::undo,
                                onRedoNote = notesViewModel::redo,
                                onSaveNote = notesViewModel::saveNow,
                                onDeleteNote = notesViewModel::openDeleteConfirm,
                                onDeleteCurrentEditingNote = notesViewModel::openDeleteCurrentEditingNote
                            )
                        }
                    }

                    // Dialogs
                    if (authState.showRecoveryCodeDialog && authState.recoveryCodeToDisplay != null) {
                        RecoveryCodeDialog(
                            recoveryCode = authState.recoveryCodeToDisplay!!,
                            onConfirmed = authViewModel::onRecoveryCodeConfirmed
                        )
                    }

                    if (authState.showForgotPasswordDialog) {
                        ForgotPasswordDialog(
                            usernameInput = authState.forgotUsernameInput,
                            isUsernameVisible = authState.isForgotUsernameVisible,
                            onUsernameChange = authViewModel::onForgotUsernameChange,
                            onToggleUsernameVisibility = authViewModel::toggleForgotUsernameVisibility,
                            recoveryCodeInput = authState.forgotRecoveryCodeInput,
                            onRecoveryCodeChange = authViewModel::onForgotRecoveryCodeChange,
                            newPasswordInput = authState.forgotNewPasswordInput,
                            isNewPasswordVisible = authState.isForgotNewPasswordVisible,
                            onNewPasswordChange = authViewModel::onForgotNewPasswordChange,
                            onToggleNewPasswordVisibility = authViewModel::toggleForgotNewPasswordVisibility,
                            errorMessage = authState.forgotErrorMessage,
                            isLoading = authState.isForgotLoading,
                            onDismiss = authViewModel::dismissForgotPasswordDialog,
                            onSubmit = authViewModel::submitForgotPassword
                        )
                    }

                    if (authState.showResetAppDialog) {
                        ResetAppDialog(
                            onDismiss = authViewModel::dismissResetAppDialog,
                            onConfirmReset = authViewModel::confirmResetApp
                        )
                    }
                }
            }
        }
    }
}
