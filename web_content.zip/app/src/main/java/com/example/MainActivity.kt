package com.example

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      val darkColors = remember {
        darkColorScheme(
          primary = Color(0xFF00F0FF),
          secondary = Color(0xFFFF007F),
          background = Color(0xFF0B0E14),
          surface = Color(0xFF101624),
          onPrimary = Color.Black,
          onBackground = Color.White,
          onSurface = Color.White
        )
      }

      MaterialTheme(colorScheme = darkColors) {
        StickBubbleScreen()
      }
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun StickBubbleScreen() {
  val context = LocalContext.current
  val webView = remember {
    WebView(context).apply {
      layoutParams = ViewGroup.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
      )

      setBackgroundColor(android.graphics.Color.parseColor("#0B0E14"))
      setLayerType(View.LAYER_TYPE_HARDWARE, null)

      settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        allowFileAccess = true
        allowContentAccess = true
        useWideViewPort = true
        loadWithOverviewMode = true
        databaseEnabled = true
        cacheMode = WebSettings.LOAD_DEFAULT
        mediaPlaybackRequiresUserGesture = false
      }

      webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(
          view: WebView?,
          request: WebResourceRequest?
        ): Boolean {
          val url = request?.url?.toString() ?: return false
          if (url.startsWith("mailto:")) {
            try {
              val intent = Intent(Intent.ACTION_SENDTO, Uri.parse(url))
              context.startActivity(intent)
            } catch (_: Exception) {
              // Graceful fallback if no email client installed
            }
            return true
          }
          return false
        }
      }

      webChromeClient = WebChromeClient()

      loadUrl("file:///android_asset/index.html")
    }
  }

  // Handle hardware back button inside the game
  BackHandler {
    webView.evaluateJavascript(
      """
      (function() {
        if (window.game) {
          if (window.game.state === 'PLAYING') {
            window.game.pauseGame();
            return 'paused';
          } else if (window.game.state === 'PAUSED' || window.game.state === 'CLEAR' || window.game.state === 'OVER') {
            window.game.showStartMenu();
            return 'menu';
          }
        }
        return 'exit';
      })();
      """.trimIndent()
    ) { result ->
      if (result == "\"exit\"" || result == null) {
        (context as? ComponentActivity)?.finish()
      }
    }
  }

  DisposableEffect(webView) {
    onDispose {
      webView.destroy()
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0B0E14))
      .safeDrawingPadding()
      .testTag("game_screen")
  ) {
    AndroidView(
      modifier = Modifier
        .fillMaxSize()
        .testTag("game_canvas_webview"),
      factory = { webView }
    )
  }
}
