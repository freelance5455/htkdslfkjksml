package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  private var gameWebView: WebView? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = Color(0xFF050B14)
        ) {
          GameScreen(
            onWebViewCreated = { webView -> gameWebView = webView },
            onBackPress = {
              gameWebView?.evaluateJavascript("if (window.handleAndroidBackPressed) window.handleAndroidBackPressed(); else false;") { result ->
                if (result == "false" || result == null) {
                  finish()
                }
              }
            }
          )
        }
      }
    }
  }

  override fun onPause() {
    super.onPause()
    gameWebView?.evaluateJavascript("if (window.handleAndroidBackPressed) window.handleAndroidBackPressed();", null)
    gameWebView?.onPause()
  }

  override fun onResume() {
    super.onResume()
    gameWebView?.onResume()
  }

  override fun onDestroy() {
    gameWebView?.destroy()
    super.onDestroy()
  }
}

class AndroidBridge(private val context: Context) {
  @JavascriptInterface
  fun vibrate(milliseconds: Long) {
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        val vibrator = vibratorManager?.defaultVibrator
        vibrator?.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          vibrator?.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
          @Suppress("DEPRECATION")
          vibrator?.vibrate(milliseconds)
        }
      }
    } catch (_: Exception) {}
  }

  @JavascriptInterface
  fun saveScore(score: Long, coins: Long) {
    try {
      val prefs = context.getSharedPreferences("nathan_city_run_prefs", Context.MODE_PRIVATE)
      prefs.edit().putLong("high_score", score).putLong("total_coins", coins).apply()
    } catch (_: Exception) {}
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GameScreen(
  onWebViewCreated: (WebView) -> Unit,
  onBackPress: () -> Unit
) {
  BackHandler {
    onBackPress()
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF050B14))
  ) {
    AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { ctx ->
        WebView(ctx).apply {
          layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
          )
          setBackgroundColor(0xFF050B14.toInt())

          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            useWideViewPort = true
            loadWithOverviewMode = true
          }

          webChromeClient = WebChromeClient()
          webViewClient = WebViewClient()

          addJavascriptInterface(AndroidBridge(ctx), "AndroidBridge")

          loadUrl("file:///android_asset/index.html")
          onWebViewCreated(this)
        }
      }
    )
  }
}
