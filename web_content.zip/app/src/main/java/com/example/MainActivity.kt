package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.utils.configureAppCheck
import com.example.ui.theme.CreatorPulseTheme
import com.example.viewmodel.CreatorPulseViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.KeywordScreen
import com.example.ui.screens.IdeasScreen
import com.example.ui.screens.SeoScreen

class MainActivity : ComponentActivity() {
    private val viewModel: CreatorPulseViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // CRITICAL: Configure App Check before UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            CreatorPulseTheme {
                var selectedTab by remember { mutableIntStateOf(0) }
                var seoTitleParam by remember { mutableStateOf("") }
                var seoTagsParam by remember { mutableStateOf(listOf<String>()) }

                val keywordState by viewModel.keywordState.collectAsState()
                val ideasState by viewModel.ideasState.collectAsState()
                val aiStatus by viewModel.aiStatus.collectAsState()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = Color.White
                        ) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.BarChart, contentDescription = null) },
                                label = { Text("Ringkasan", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.CompassCalibration, contentDescription = null) },
                                label = { Text("Riset", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                icon = { Icon(Icons.Default.Lightbulb, contentDescription = null) },
                                label = { Text("Ide AI", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 3,
                                onClick = { selectedTab = 3 },
                                icon = { Icon(Icons.Default.Tune, contentDescription = null) },
                                label = { Text("SEO Audit", fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.primary,
                                    selectedTextColor = MaterialTheme.colorScheme.primary,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (selectedTab) {
                            0 -> DashboardScreen(
                                onNavigateToIdeas = { selectedTab = 2 },
                                onNavigateToKeywords = { selectedTab = 1 }
                            )
                            1 -> KeywordScreen(
                                keywordResult = keywordState,
                                aiStatus = aiStatus,
                                onSearchKeyword = { query -> viewModel.analyzeKeyword(query) }
                            )
                            2 -> IdeasScreen(
                                ideas = ideasState,
                                aiStatus = aiStatus,
                                onGenerateIdeas = { niche -> viewModel.generateIdeas(niche) },
                                onSendToSeo = { title, tags ->
                                    seoTitleParam = title
                                    seoTagsParam = tags
                                    selectedTab = 3
                                }
                            )
                            3 -> SeoScreen(
                                initialTitle = seoTitleParam,
                                initialTags = seoTagsParam,
                                aiStatus = aiStatus,
                                onOptimizeSeo = { t, d, cb -> viewModel.optimizeSeo(t, d, cb) }
                            )
                        }
                    }
                }
            }
        }
    }
}
