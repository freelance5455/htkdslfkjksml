package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.SecurityPreferences
import com.example.model.ProtectedSection
import com.example.security.PermissionStatusChecker
import com.example.service.PinLockOverlayManager
import com.example.ui.MainViewModel
import com.example.ui.PinScreenMode
import com.example.ui.components.MainDashboardScreen
import com.example.ui.components.PinEntryScreen
import com.example.ui.theme.EscudoPinTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EscudoPinTheme {
                val context = LocalContext.current
                val lifecycleOwner = LocalLifecycleOwner.current
                val viewModel: MainViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val snackbarHostState = remember { SnackbarHostState() }
                val scope = rememberCoroutineScope()

                val testOverlayManager = remember(context) {
                    PinLockOverlayManager(
                        context = context.applicationContext,
                        securityPreferences = SecurityPreferences.getInstance(context),
                    )
                }

                val deviceAdminLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult(),
                ) {
                    viewModel.refreshState()
                }

                DisposableEffect(lifecycleOwner) {
                    val observer = LifecycleEventObserver { _, event ->
                        when (event) {
                            Lifecycle.Event.ON_RESUME -> viewModel.refreshState()
                            Lifecycle.Event.ON_STOP -> viewModel.onAppBackgrounded()
                            else -> Unit
                        }
                    }
                    lifecycleOwner.lifecycle.addObserver(observer)
                    onDispose {
                        lifecycleOwner.lifecycle.removeObserver(observer)
                    }
                }

                when (val mode = uiState.mode) {
                    PinScreenMode.Dashboard -> {
                        MainDashboardScreen(
                            uiState = uiState,
                            snackbarHostState = snackbarHostState,
                            onRequestAccessibility = {
                                viewModel.markAwaitingSystemPermissionReturn()
                                PermissionStatusChecker.openAccessibilitySettings(context)
                            },
                            onRequestDeviceAdmin = {
                                viewModel.markAwaitingSystemPermissionReturn()
                                if (uiState.permissions.deviceAdminEnabled) {
                                    PermissionStatusChecker.openAppDetailsSettings(context)
                                } else {
                                    deviceAdminLauncher.launch(
                                        PermissionStatusChecker.buildDeviceAdminIntent(context),
                                    )
                                }
                            },
                            onRequestOverlay = {
                                viewModel.markAwaitingSystemPermissionReturn()
                                PermissionStatusChecker.openOverlaySettings(context)
                            },
                            onToggleMaster = viewModel::setMasterProtection,
                            onTogglePowerRule = viewModel::setPowerRule,
                            onToggleAdminRule = viewModel::setAdminRule,
                            onToggleDesktopRule = viewModel::setDesktopRule,
                            onChangePin = viewModel::startChangePin,
                            onLockPanel = viewModel::lockDashboard,
                            onTestOverlayLock = {
                                if (PermissionStatusChecker.isOverlayPermissionGranted(context)) {
                                    testOverlayManager.show(
                                        section = ProtectedSection.POWER_AND_REBOOT,
                                        accessibilityService = null,
                                        isTestMode = true,
                                    )
                                } else {
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            "Primero concede el permiso de monitoreo y bloqueo en pantalla.",
                                        )
                                    }
                                }
                            },
                            onOpenAppSettings = {
                                viewModel.markAwaitingSystemPermissionReturn()
                                PermissionStatusChecker.openAppDetailsSettings(context)
                            },
                        )
                    }

                    else -> {
                        PinEntryScreen(
                            mode = mode,
                            enteredLength = uiState.enteredDigits.length,
                            errorMessage = uiState.errorMessage,
                            onDigitClick = viewModel::onDigitPressed,
                            onBackspace = viewModel::onBackspace,
                            onClear = viewModel::onClearDigits,
                            onCancelChangePin = viewModel::cancelChangePin,
                        )
                    }
                }
            }
        }
    }
}
