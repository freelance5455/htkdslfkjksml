package com.example

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.StickWarTheme
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {

    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            StickWarTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    containerColor = MaterialTheme.colorScheme.background
                ) { innerPadding ->
                    StickWarGameScreen(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        onWebViewReady = { wv -> webView = wv }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
    }

    override fun onPause() {
        super.onPause()
        webView?.onPause()
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun StickWarGameScreen(
    modifier: Modifier = Modifier,
    onWebViewReady: (WebView) -> Unit = {}
) {
    val context = LocalContext.current
    var menuExpanded by remember { mutableStateOf(false) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var localWebView by remember { mutableStateOf<WebView?>(null) }

    Box(modifier = modifier) {
        // Native Hardware-Accelerated WebView
        AndroidView(
            modifier = Modifier
                .fillMaxSize()
                .testTag("game_webview"),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )

                    // Hardware Acceleration
                    setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    overScrollMode = View.OVER_SCROLL_NEVER
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false

                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        databaseEnabled = true
                        allowFileAccess = true
                        mediaPlaybackRequiresUserGesture = false
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        cacheMode = WebSettings.LOAD_NO_CACHE
                        mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                            return true
                        }
                    }

                    webViewClient = object : WebViewClient() {}

                    loadUrl("file:///android_asset/index.html")
                    localWebView = this
                    onWebViewReady(this)
                }
            },
            update = { wv ->
                localWebView = wv
            }
        )

        // Floating Quick Tactical Actions Menu Button
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 10.dp, end = 10.dp)
        ) {
            IconButton(
                onClick = { menuExpanded = true },
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f))
                    .testTag("menu_button")
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Tactical Menu",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false },
                modifier = Modifier.testTag("tactical_dropdown_menu")
            ) {
                DropdownMenuItem(
                    text = { Text("Restart Game") },
                    leadingIcon = {
                        Icon(Icons.Default.Refresh, contentDescription = "Restart")
                    },
                    onClick = {
                        menuExpanded = false
                        localWebView?.reload()
                        Toast.makeText(context, "Game Reloaded", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("menu_restart_item")
                )

                DropdownMenuItem(
                    text = { Text("Copy Single-File HTML") },
                    leadingIcon = {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy HTML")
                    },
                    onClick = {
                        menuExpanded = false
                        copyHtmlToClipboard(context)
                    },
                    modifier = Modifier.testTag("menu_copy_html_item")
                )

                DropdownMenuItem(
                    text = { Text("How to Play & Guide") },
                    leadingIcon = {
                        Icon(Icons.Default.Info, contentDescription = "Guide")
                    },
                    onClick = {
                        menuExpanded = false
                        showInfoDialog = true
                    },
                    modifier = Modifier.testTag("menu_guide_item")
                )
            }
        }

        // Guide Dialog
        if (showInfoDialog) {
            AlertDialog(
                onDismissRequest = { showInfoDialog = false },
                title = { Text("Stick War Strategy Guide") },
                text = {
                    Text(
                        "• Train Miners to harvest gold sacks from the gold vein on the far left.\n" +
                        "• Train Swordsmen for fast melee strikes against enemy archers.\n" +
                        "• Deploy Archers for high-trajectory curved arrow support.\n" +
                        "• Use Spearmen to tank enemy advances with heavy polearms.\n" +
                        "• Unleash Giants for devastating ground-shattering AoE smashes!\n" +
                        "• Use Attack, Defend, and Retreat stances to command your legion.\n" +
                        "• Upgrade Citadel walls, passive gold rate, and balista turret to defend against endless waves."
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = { showInfoDialog = false },
                        modifier = Modifier.testTag("close_guide_btn")
                    ) {
                        Text("Dismiss")
                    }
                }
            )
        }
    }
}

private fun copyHtmlToClipboard(context: Context) {
    try {
        val assetManager = context.assets
        val inputStream = assetManager.open("index.html")
        val reader = BufferedReader(InputStreamReader(inputStream))
        val sb = StringBuilder()
        var line: String?
        while (reader.readLine().also { line = it } != null) {
            sb.append(line).append("\n")
        }
        reader.close()

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Stick War Single File HTML", sb.toString())
        clipboard.setPrimaryClip(clip)

        Toast.makeText(
            context,
            "Single-file index.html copied! Ready to test in Pydroid / VS Code.",
            Toast.LENGTH_LONG
        ).show()
    } catch (e: Exception) {
        Toast.makeText(context, "Failed to read HTML: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
