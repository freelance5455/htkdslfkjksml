package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.components.CollegeTopAppBar
import com.example.ui.components.RoleSwitcherDialog
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NursingGreenPrimary
import com.example.ui.viewmodel.CollegeViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {
    private val viewModel: CollegeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScreen(viewModel: CollegeViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showRoleModal by remember { mutableStateOf(false) }

    // Display operation messages in snackbar
    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // System BackHandler for non-home screens
    if (currentScreen != Screen.Home) {
        BackHandler {
            viewModel.navigateTo(Screen.Home)
        }
    }

    Scaffold(
        topBar = {
            CollegeTopAppBar(
                viewModel = viewModel,
                onOpenRoleDialog = { showRoleModal = true }
            )
        },
        bottomBar = {
            // Quick Navigation Bar on mobile
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp
            ) {
                NavigationBarItem(
                    selected = currentScreen == Screen.Home,
                    onClick = { viewModel.navigateTo(Screen.Home) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NursingGreenPrimary,
                        selectedTextColor = NursingGreenPrimary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.BatchManagement,
                    onClick = { viewModel.navigateTo(Screen.BatchManagement) },
                    icon = { Icon(Icons.Default.Groups, contentDescription = "Batches") },
                    label = { Text("Batches") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NursingGreenPrimary,
                        selectedTextColor = NursingGreenPrimary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.ClinicalDuty,
                    onClick = { viewModel.navigateTo(Screen.ClinicalDuty) },
                    icon = { Icon(Icons.Default.LocalHospital, contentDescription = "Clinical") },
                    label = { Text("Clinical") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NursingGreenPrimary,
                        selectedTextColor = NursingGreenPrimary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.NoticeBoard,
                    onClick = { viewModel.navigateTo(Screen.NoticeBoard) },
                    icon = { Icon(Icons.Default.Campaign, contentDescription = "Notices") },
                    label = { Text("Notices") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NursingGreenPrimary,
                        selectedTextColor = NursingGreenPrimary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
                NavigationBarItem(
                    selected = currentScreen == Screen.AdminDashboard,
                    onClick = { viewModel.navigateTo(Screen.AdminDashboard) },
                    icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin") },
                    label = { Text("Admin") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NursingGreenPrimary,
                        selectedTextColor = NursingGreenPrimary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.Home -> HomeScreen(viewModel = viewModel, onOpenRoleDialog = { showRoleModal = true })
                Screen.TeacherDirectory -> TeacherDirectoryScreen(viewModel = viewModel)
                Screen.BatchManagement -> BatchManagementScreen(viewModel = viewModel)
                Screen.ComplaintRegistration -> ComplaintRegistrationScreen(viewModel = viewModel)
                Screen.ComplaintStatus -> ComplaintStatusScreen(viewModel = viewModel)
                Screen.NoticeBoard -> NoticeBoardScreen(viewModel = viewModel)
                Screen.HolidayCalendar -> HolidayCalendarScreen(viewModel = viewModel)
                Screen.ClinicalDuty -> ClinicalDutyScreen(viewModel = viewModel)
                Screen.AdminDashboard -> AdminDashboardScreen(viewModel = viewModel, onOpenRoleDialog = { showRoleModal = true })
                Screen.HtmlAppView -> HtmlAppScreen(viewModel = viewModel)
            }
        }
    }

    if (showRoleModal) {
        RoleSwitcherDialog(
            viewModel = viewModel,
            onDismiss = { showRoleModal = false }
        )
    }
}
