package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
  private var webViewRef: WebView? = null
  private var bridge: JarvisNativeBridge? = null
  private var pendingPermissionCallback: ((Map<String, Boolean>) -> Unit)? = null
  private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
  private var isFullscreen by mutableStateOf(false)

  private lateinit var permissionLauncher: ActivityResultLauncher<Array<String>>
  private lateinit var filePickerLauncher: ActivityResultLauncher<Array<String>>

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    WindowCompat.getInsetsController(window, window.decorView).apply {
      isAppearanceLightStatusBars = false
      isAppearanceLightNavigationBars = false
    }

    permissionLauncher =
      registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        pendingPermissionCallback?.invoke(results)
        pendingPermissionCallback = null
      }

    filePickerLauncher =
      registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val callback = pendingFileCallback
        pendingFileCallback = null
        if (uris.isNotEmpty()) {
          callback?.onReceiveValue(uris.toTypedArray())
        } else {
          callback?.onReceiveValue(null)
        }
      }

    val nativeBridge =
      JarvisNativeBridge(
        context = this,
        webViewProvider = { webViewRef },
        onRequestPermissions = { perms, callback ->
          pendingPermissionCallback = callback
          permissionLauncher.launch(perms)
        },
        onToggleFullscreen = { enabled ->
          isFullscreen = enabled
          applySystemBarsVisibility(enabled)
        },
      )
    bridge = nativeBridge

    setContent {
      JarvisHostScreen(
        bridge = nativeBridge,
        isFullscreen = isFullscreen,
        onWebViewCreated = { wv -> webViewRef = wv },
        onRequestPermissions = { perms, callback ->
          pendingPermissionCallback = callback
          permissionLauncher.launch(perms)
        },
        onLaunchFilePicker = { acceptTypes, callback ->
          pendingFileCallback?.onReceiveValue(null)
          pendingFileCallback = callback
          val mimeTypes =
            acceptTypes
              ?.filter { it.isNotBlank() }
              ?.takeIf { it.isNotEmpty() }
              ?.toTypedArray() ?: arrayOf("*/*")
          filePickerLauncher.launch(mimeTypes)
        },
        onBackPressed = {
          val wv = webViewRef
          if (wv != null) {
            wv.evaluateJavascript(
              "(function(){ return window.__jarvisHandleBack ? window.__jarvisHandleBack() : false; })();"
            ) { result ->
              if (result != "true") {
                if (wv.canGoBack()) {
                  wv.goBack()
                } else {
                  finish()
                }
              }
            }
          } else {
            finish()
          }
        },
      )
    }
  }

  private fun applySystemBarsVisibility(fullscreen: Boolean) {
    val controller = WindowCompat.getInsetsController(window, window.decorView)
    if (fullscreen) {
      controller.systemBarsBehavior =
        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
      controller.hide(WindowInsetsCompat.Type.systemBars())
    } else {
      controller.show(WindowInsetsCompat.Type.systemBars())
    }
  }

  override fun onPause() {
    super.onPause()
    webViewRef?.onPause()
  }

  override fun onResume() {
    super.onResume()
    webViewRef?.onResume()
  }

  override fun onDestroy() {
    pendingFileCallback?.onReceiveValue(null)
    pendingFileCallback = null
    bridge?.destroy()
    webViewRef?.destroy()
    webViewRef = null
    super.onDestroy()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun JarvisHostScreen(
  bridge: JarvisNativeBridge,
  isFullscreen: Boolean,
  onWebViewCreated: (WebView) -> Unit,
  onRequestPermissions: (Array<String>, (Map<String, Boolean>) -> Unit) -> Unit,
  onLaunchFilePicker: (Array<String>?, ValueCallback<Array<Uri>>) -> Unit,
  onBackPressed: () -> Unit,
) {
  BackHandler(onBack = onBackPressed)

  val containerModifier =
    if (isFullscreen) {
      Modifier.fillMaxSize().background(Color(0xFF040A18))
    } else {
      Modifier.fillMaxSize()
        .background(Color(0xFF040A18))
        .windowInsetsPadding(WindowInsets.safeDrawing)
    }

  Box(modifier = containerModifier) {
    AndroidView(
      modifier = Modifier.fillMaxSize(),
      factory = { ctx ->
        WebView(ctx).apply {
          layoutParams =
            ViewGroup.LayoutParams(
              ViewGroup.LayoutParams.MATCH_PARENT,
              ViewGroup.LayoutParams.MATCH_PARENT,
            )
          setBackgroundColor(0xFF040A18.toInt())
          settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = false
            displayZoomControls = false
          }

          addJavascriptInterface(bridge, "JarvisAndroidBridge")

          webViewClient =
            object : WebViewClient() {
              override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?,
              ): WebResourceResponse? {
                val url = request?.url ?: return null
                if (url.host == "jarvis.local" && (url.path == "/index.html" || url.path == "/")) {
                  return try {
                    WebResourceResponse(
                      "text/html",
                      "UTF-8",
                      ctx.assets.open("index.html"),
                    )
                  } catch (_: Exception) {
                    null
                  }
                }
                return null
              }

              override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?,
              ): Boolean {
                val url = request?.url ?: return false
                if (request.isForMainFrame && url.host != "jarvis.local") {
                  return try {
                    val intent = Intent(Intent.ACTION_VIEW, url).apply {
                      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    ctx.startActivity(intent)
                    true
                  } catch (_: Exception) {
                    false
                  }
                }
                return false
              }
            }

          webChromeClient =
            object : WebChromeClient() {
              override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                val neededPerms = mutableListOf<String>()
                if (
                  request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) !=
                      PackageManager.PERMISSION_GRANTED
                ) {
                  neededPerms.add(Manifest.permission.RECORD_AUDIO)
                }
                if (
                  request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) !=
                      PackageManager.PERMISSION_GRANTED
                ) {
                  neededPerms.add(Manifest.permission.CAMERA)
                }
                if (neededPerms.isEmpty()) {
                  request.grant(request.resources)
                } else {
                  onRequestPermissions(neededPerms.toTypedArray()) { results ->
                    val allOk = neededPerms.all { results[it] == true }
                    if (allOk) request.grant(request.resources) else request.deny()
                  }
                }
              }

              override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?,
              ) {
                if (callback == null) return
                val hasLoc =
                  ContextCompat.checkSelfPermission(
                    ctx,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                  ) == PackageManager.PERMISSION_GRANTED
                if (hasLoc) {
                  callback.invoke(origin, true, false)
                } else {
                  onRequestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION)) { res ->
                    val granted = res[Manifest.permission.ACCESS_COARSE_LOCATION] == true
                    callback.invoke(origin, granted, false)
                  }
                }
              }

              override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?,
              ): Boolean {
                if (filePathCallback == null) return false
                onLaunchFilePicker(fileChooserParams?.acceptTypes, filePathCallback)
                return true
              }
            }

          onWebViewCreated(this)
          loadUrl("https://jarvis.local/index.html")
        }
      },
    )
  }
}
