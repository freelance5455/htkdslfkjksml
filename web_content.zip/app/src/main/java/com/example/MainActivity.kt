package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Route
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.LessonEntity
import com.example.data.local.TrackEntity
import com.example.data.local.TrackLessonEntity
import com.example.data.model.MainTab
import com.example.ui.StudyViewModel
import com.example.ui.components.ConfettiOverlay
import com.example.ui.components.ConfirmActionDialog
import com.example.ui.components.CountdownMotivationBanner
import com.example.ui.components.LessonEditorDialog
import com.example.ui.components.SettingsBackupDialog
import com.example.ui.components.StatsDashboardGrid
import com.example.ui.components.TopPlatformHeader
import com.example.ui.components.TrackEditorDialog
import com.example.ui.components.TrackLessonEditorDialog
import com.example.ui.screens.FocusScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.TimetableScreen
import com.example.ui.screens.TracksScreen
import com.example.ui.theme.ThanaweyaTheme
import com.example.util.DateTimeUtils
import com.example.util.TimetablePrinter
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: StudyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            ThanaweyaTheme(darkTheme = uiState.isDarkTheme) {
                ThanaweyaApp(viewModel = viewModel)
            }
        }
    }
}

private sealed class ActiveDialog {
    data class LessonEditor(val lesson: LessonEntity?, val prefillDay: String) : ActiveDialog()
    data class TrackEditor(val track: TrackEntity?) : ActiveDialog()
    data class TrackLessonEditor(val trackId: String, val lesson: TrackLessonEntity?) : ActiveDialog()
    data object Settings : ActiveDialog()
    data class Confirm(val message: String, val onConfirm: () -> Unit) : ActiveDialog()
}

@Composable
fun ThanaweyaApp(viewModel: StudyViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var activeDialog by remember { mutableStateOf<ActiveDialog?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                runCatching {
                    val json = viewModel.exportBackupJson()
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    }
                }.onSuccess {
                    snackbarHostState.showSnackbar("تم تصدير النسخة الاحتياطية 💾")
                }.onFailure {
                    snackbarHostState.showSnackbar("تعذر حفظ ملف النسخة الاحتياطية")
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val raw = runCatching {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                }.getOrNull()
                if (raw != null) {
                    viewModel.importBackupJson(raw)
                    activeDialog = null
                } else {
                    snackbarHostState.showSnackbar("تعذر قراءة الملف المحدد")
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.toastEvents.collect { msg ->
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(msg)
        }
    }

    BackHandler(enabled = uiState.activeTab != MainTab.TIMETABLE) {
        viewModel.switchTab(MainTab.TIMETABLE)
    }

    val navItems = listOf(
        Triple(MainTab.TIMETABLE, "الجدول", Icons.Filled.CalendarMonth),
        Triple(MainTab.TRACKS, "المناهج", Icons.Filled.Route),
        Triple(MainTab.TASKS, "الواجبات", Icons.Filled.Checklist),
        Triple(MainTab.FOCUS, "التركيز", Icons.Filled.Timer)
    )

    Box(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpanded = maxWidth >= 840.dp
            val isMedium = maxWidth >= 600.dp

            Scaffold(
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                bottomBar = {
                    if (!isExpanded) {
                        NavigationBar {
                            navItems.forEach { (tab, label, icon) ->
                                NavigationBarItem(
                                    selected = uiState.activeTab == tab,
                                    onClick = { viewModel.switchTab(tab) },
                                    icon = { Icon(icon, contentDescription = label) },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag("nav_tab_${tab.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isExpanded) {
                        NavigationRail(
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            navItems.forEach { (tab, label, icon) ->
                                NavigationRailItem(
                                    selected = uiState.activeTab == tab,
                                    onClick = { viewModel.switchTab(tab) },
                                    icon = { Icon(icon, contentDescription = label) },
                                    label = { Text(label) },
                                    modifier = Modifier.testTag("rail_tab_${tab.route}")
                                )
                            }
                        }
                    }

                    Scaffold(
                        topBar = {
                            TopPlatformHeader(
                                uiState = uiState,
                                onAddLessonClick = {
                                    activeDialog = ActiveDialog.LessonEditor(null, uiState.todayDayName)
                                },
                                onSettingsClick = { activeDialog = ActiveDialog.Settings },
                                onPrintClick = { TimetablePrinter.printTimetable(context, uiState.lessons) },
                                onToggleThemeClick = { viewModel.toggleDarkTheme() },
                                onTimerPillClick = { viewModel.switchTab(MainTab.FOCUS) }
                            )
                        }
                    ) { contentPadding ->
                        val scrollState = rememberScrollState()
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(contentPadding)
                                .verticalScroll(scrollState),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Column(
                                modifier = Modifier
                                    .widthIn(max = 1100.dp)
                                    .fillMaxWidth()
                                    .padding(PaddingValues(horizontal = 16.dp, vertical = 14.dp)),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                CountdownMotivationBanner(
                                    uiState = uiState,
                                    onNextQuoteClick = { viewModel.nextQuote() },
                                    onEditExamDateClick = { activeDialog = ActiveDialog.Settings },
                                    isWide = isMedium
                                )

                                StatsDashboardGrid(
                                    uiState = uiState,
                                    isWide = isExpanded,
                                    onStatClick = { tab, ttFilter ->
                                        viewModel.switchTab(tab)
                                        if (ttFilter != null) viewModel.setTimetableFilter(ttFilter)
                                    }
                                )

                                when (uiState.activeTab) {
                                    MainTab.TIMETABLE -> {
                                        val cols = when {
                                            isExpanded -> 3
                                            isMedium -> 2
                                            else -> 1
                                        }
                                        TimetableScreen(
                                            uiState = uiState,
                                            columnCount = cols,
                                            onFilterChange = viewModel::setTimetableFilter,
                                            onSearchChange = viewModel::setTimetableSearch,
                                            onResetWeeklyAttendance = {
                                                activeDialog = ActiveDialog.Confirm(
                                                    message = "هل تريد تصفير علامات الحضور لبدء أسبوع جديد؟",
                                                    onConfirm = { viewModel.resetWeeklyAttendance() }
                                                )
                                            },
                                            onAddLessonForDay = { day ->
                                                activeDialog = ActiveDialog.LessonEditor(null, day)
                                            },
                                            onEditLesson = { lesson ->
                                                activeDialog = ActiveDialog.LessonEditor(lesson, lesson.day)
                                            },
                                            onToggleAttended = viewModel::toggleLessonAttended,
                                            onDeleteLesson = { lesson ->
                                                activeDialog = ActiveDialog.Confirm(
                                                    message = "حذف درس \"${lesson.subject}\" من الجدول؟",
                                                    onConfirm = { viewModel.deleteLesson(lesson.id) }
                                                )
                                            }
                                        )
                                    }

                                    MainTab.TRACKS -> {
                                        TracksScreen(
                                            uiState = uiState,
                                            isWide = isMedium,
                                            onFilterChange = viewModel::setTrackFilter,
                                            onAddTrackClick = { activeDialog = ActiveDialog.TrackEditor(null) },
                                            onEditTrackClick = { track -> activeDialog = ActiveDialog.TrackEditor(track) },
                                            onDeleteTrackClick = { track ->
                                                activeDialog = ActiveDialog.Confirm(
                                                    message = "حذف مسار \"${track.name}\" وكافة دروسه؟",
                                                    onConfirm = { viewModel.deleteTrack(track.id) }
                                                )
                                            },
                                            onOpenMultiLessonModal = { trackId ->
                                                activeDialog = ActiveDialog.TrackLessonEditor(trackId, null)
                                            },
                                            onQuickAddLesson = { trackId, title ->
                                                viewModel.saveTrackLesson(trackId, null, title, "")
                                            },
                                            onToggleLesson = viewModel::toggleTrackLesson,
                                            onEditLesson = { trackId, lesson ->
                                                activeDialog = ActiveDialog.TrackLessonEditor(trackId, lesson)
                                            },
                                            onDeleteLesson = { lesson ->
                                                viewModel.deleteTrackLesson(lesson.id)
                                            }
                                        )
                                    }

                                    MainTab.TASKS -> {
                                        TasksScreen(
                                            uiState = uiState,
                                            onFilterChange = viewModel::setTaskFilter,
                                            onSearchChange = viewModel::setTaskSearch,
                                            onAddTask = viewModel::addTask,
                                            onToggleTask = viewModel::toggleTask,
                                            onDeleteTask = { task -> viewModel.deleteTask(task.id) },
                                            onClearCompleted = {
                                                val count = uiState.tasks.count { it.completed }
                                                if (count == 0) {
                                                    viewModel.clearCompletedTasks()
                                                } else {
                                                    activeDialog = ActiveDialog.Confirm(
                                                        message = "مسح $count مهام مكتملة؟",
                                                        onConfirm = { viewModel.clearCompletedTasks() }
                                                    )
                                                }
                                            }
                                        )
                                    }

                                    MainTab.FOCUS -> {
                                        FocusScreen(
                                            uiState = uiState,
                                            isWide = isMedium,
                                            onModeChange = viewModel::setPomodoroMode,
                                            onSubjectChange = viewModel::setPomodoroSubject,
                                            onToggleTimer = viewModel::togglePomodoro,
                                            onResetTimer = viewModel::resetPomodoro
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        ConfettiOverlay(
            burst = uiState.confettiBurst,
            onFinished = { viewModel.clearConfetti() }
        )
    }

    when (val dialog = activeDialog) {
        is ActiveDialog.LessonEditor -> {
            LessonEditorDialog(
                initialLesson = dialog.lesson,
                prefillDay = dialog.prefillDay,
                onDismiss = { activeDialog = null },
                onSave = { id, subject, day, mode, teacher, time, location, colorHex ->
                    viewModel.saveLesson(id, subject, day, mode, teacher, time, location, colorHex)
                    activeDialog = null
                }
            )
        }

        is ActiveDialog.TrackEditor -> {
            TrackEditorDialog(
                initialTrack = dialog.track,
                onDismiss = { activeDialog = null },
                onSave = { id, name, teacher, colorHex ->
                    viewModel.saveTrack(id, name, teacher, colorHex)
                    activeDialog = null
                }
            )
        }

        is ActiveDialog.TrackLessonEditor -> {
            TrackLessonEditorDialog(
                trackId = dialog.trackId,
                initialLesson = dialog.lesson,
                onDismiss = { activeDialog = null },
                onSaveSingle = { trackId, lessonId, title, note ->
                    viewModel.saveTrackLesson(trackId, lessonId, title, note)
                    activeDialog = null
                },
                onSaveBulk = { trackId, lines ->
                    viewModel.addBulkTrackLessons(trackId, lines)
                    activeDialog = null
                }
            )
        }

        is ActiveDialog.Settings -> {
            SettingsBackupDialog(
                currentExamDate = uiState.examDate,
                onDismiss = { activeDialog = null },
                onSaveExamDate = { dateIso -> viewModel.setExamDate(dateIso) },
                onExportBackup = {
                    exportLauncher.launch("thanaweya-backup-${DateTimeUtils.todayIsoKey()}.json")
                },
                onImportBackup = {
                    importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                },
                onPrintTimetable = {
                    TimetablePrinter.printTimetable(context, uiState.lessons)
                },
                onRequestResetAll = {
                    activeDialog = ActiveDialog.Confirm(
                        message = "سيتم مسح الجدول والمناهج والواجبات نهائياً! هل أنت متأكد؟",
                        onConfirm = { viewModel.resetAllData() }
                    )
                }
            )
        }

        is ActiveDialog.Confirm -> {
            ConfirmActionDialog(
                message = dialog.message,
                onDismiss = { activeDialog = null },
                onConfirm = dialog.onConfirm
            )
        }

        null -> Unit
    }
}
