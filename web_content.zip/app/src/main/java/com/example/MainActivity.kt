package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.firebase.AdminRepository
import com.example.data.firebase.AuctionRepository
import com.example.data.firebase.AuthAndWalletRepository
import com.example.data.model.UiState
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOut
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AuctionDetailScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.MarketplaceScreen
import com.example.ui.screens.SellerDashboardScreen
import com.example.ui.screens.WalletAndProfileScreen
import com.example.ui.theme.TrueATheme
import com.example.ui.viewmodel.AuctionDetailViewModel
import com.example.ui.viewmodel.TrueAViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

const val ROUTE_MARKETPLACE = "marketplace"
const val ROUTE_HISTORY = "history"
const val ROUTE_SELLER = "seller"
const val ROUTE_WALLET = "wallet"
const val ROUTE_ADMIN = "admin"
const val ROUTE_AUCTION_DETAIL = "auction_detail/{auctionId}"

private data class TopTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val TOP_TABS = listOf(
    TopTab(ROUTE_MARKETPLACE, "Live", Icons.Filled.Gavel, Icons.Outlined.Gavel, "nav_live"),
    TopTab(ROUTE_HISTORY, "History", Icons.Filled.History, Icons.Outlined.History, "nav_history"),
    TopTab(ROUTE_SELLER, "Sell", Icons.Filled.Storefront, Icons.Outlined.Storefront, "nav_sell"),
    TopTab(ROUTE_WALLET, "Wallet", Icons.Filled.AccountBalanceWallet, Icons.Outlined.AccountBalanceWallet, "nav_wallet")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TrueATheme {
                AppNavigation()
            }
        }
    }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            TrueAMainHost(currentUserId = user.uid)
        }
    }
}

@Composable
fun TrueAMainHost(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val mainViewModel: TrueAViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                TrueAViewModel(
                    authWalletRepo = AuthAndWalletRepository(db),
                    auctionRepo = AuctionRepository(db),
                    adminRepo = AdminRepository(db),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val profileState by mainViewModel.userProfileState.collectAsStateWithLifecycle()
    val walletState by mainViewModel.walletState.collectAsStateWithLifecycle()
    val auctionsState by mainViewModel.auctionsState.collectAsStateWithLifecycle()
    val myBidRecordsState by mainViewModel.myBidRecordsState.collectAsStateWithLifecycle()
    val activeAdsState by mainViewModel.activeBusinessAdsState.collectAsStateWithLifecycle()
    val transactionsState by mainViewModel.walletTransactionsState.collectAsStateWithLifecycle()
    val myWithdrawalsState by mainViewModel.myWithdrawalsState.collectAsStateWithLifecycle()
    val isAdmin by mainViewModel.isAdminState.collectAsStateWithLifecycle()
    val nowMillis by mainViewModel.nowMillis.collectAsStateWithLifecycle()
    val statusBanner by mainViewModel.statusBanner.collectAsStateWithLifecycle()
    val isBusy by mainViewModel.isBusy.collectAsStateWithLifecycle()

    val allUsersAdmin by mainViewModel.allUsersAdmin.collectAsStateWithLifecycle()
    val allWithdrawalsAdmin by mainViewModel.allWithdrawalsAdmin.collectAsStateWithLifecycle()
    val allBusinessAdsAdmin by mainViewModel.allBusinessAdsAdmin.collectAsStateWithLifecycle()
    val allAdInquiriesAdmin by mainViewModel.allAdInquiriesAdmin.collectAsStateWithLifecycle()
    val allTransactionsAdmin by mainViewModel.allTransactionsAdmin.collectAsStateWithLifecycle()

    val profile = (profileState as? UiState.Success)?.data
    val wallet = (walletState as? UiState.Success)?.data

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showTopLevelNav = currentRoute in TOP_TABS.map { it.route }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusBanner) {
        if (statusBanner != null) {
            snackbarHostState.showSnackbar(statusBanner!!)
            mainViewModel.clearStatusBanner()
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = if (showTopLevelNav) {
                WindowInsets.statusBars.only(WindowInsetsSides.Top)
            } else {
                WindowInsets(0, 0, 0, 0)
            },
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (showTopLevelNav && !useRail) {
                    NavigationBar {
                        TOP_TABS.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(ROUTE_MARKETPLACE) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showTopLevelNav && useRail) {
                    NavigationRail {
                        TOP_TABS.forEach { tab ->
                            val selected = currentRoute == tab.route
                            NavigationRailItem(
                                selected = selected,
                                onClick = {
                                    navController.navigate(tab.route) {
                                        popUpTo(ROUTE_MARKETPLACE) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.label
                                    )
                                },
                                label = { Text(tab.label) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_MARKETPLACE,
                    modifier = Modifier.weight(1f)
                ) {
                    composable(ROUTE_MARKETPLACE) {
                        MarketplaceScreen(
                            auctionsState = auctionsState,
                            adsState = activeAdsState,
                            profile = profile,
                            wallet = wallet,
                            nowMillis = nowMillis,
                            isAdmin = isAdmin,
                            currentUserId = currentUserId,
                            onOpenAuction = { id -> navController.navigate("auction_detail/$id") },
                            onOpenWallet = {
                                navController.navigate(ROUTE_WALLET) {
                                    popUpTo(ROUTE_MARKETPLACE) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            onSubmitAdInquiry = { name, budget, msg ->
                                mainViewModel.submitAdInquiry(name, budget, msg)
                            },
                            onSeedShowcase = { mainViewModel.adminSeedShowcase() }
                        )
                    }

                    composable(ROUTE_HISTORY) {
                        HistoryScreen(
                            auctionsState = auctionsState,
                            myBidRecordsState = myBidRecordsState,
                            nowMillis = nowMillis,
                            currentUserId = currentUserId,
                            onOpenAuction = { id -> navController.navigate("auction_detail/$id") }
                        )
                    }

                    composable(ROUTE_SELLER) {
                        SellerDashboardScreen(
                            auctionsState = auctionsState,
                            profile = profile,
                            wallet = wallet,
                            nowMillis = nowMillis,
                            currentUserId = currentUserId,
                            isBusy = isBusy,
                            onOpenAuction = { id -> navController.navigate("auction_detail/$id") },
                            onCreateAuction = { title, desc, cat, imgs, startBid, minInc, hours, featured ->
                                if (profile != null) {
                                    mainViewModel.createAuction(
                                        profile = profile,
                                        title = title,
                                        description = desc,
                                        category = cat,
                                        imageItems = imgs,
                                        startingBid = startBid,
                                        minIncrement = minInc,
                                        durationHours = hours,
                                        featureListing = featured
                                    )
                                }
                            },
                            onUpgradeFeatured = { id, title -> mainViewModel.upgradeAuctionToFeatured(id, title) },
                            onCancelAuction = { id -> mainViewModel.cancelAuctionBeforeBids(id) }
                        )
                    }

                    composable(ROUTE_WALLET) {
                        WalletAndProfileScreen(
                            profile = profile,
                            wallet = wallet,
                            transactionsState = transactionsState,
                            withdrawalsState = myWithdrawalsState,
                            isAdmin = isAdmin,
                            isBusy = isBusy,
                            onDeposit = { amt, method -> mainViewModel.depositFunds(amt, method) },
                            onRequestWithdrawal = { amt, bank, acctNo, acctName ->
                                if (profile != null) {
                                    mainViewModel.requestWithdrawal(profile, amt, bank, acctNo, acctName)
                                }
                            },
                            onUpdateProfile = { name, phone, bank, acctNo, acctName ->
                                mainViewModel.updateProfile(name, phone, bank, acctNo, acctName)
                            },
                            onOpenAdminConsole = { navController.navigate(ROUTE_ADMIN) },
                            onSignOut = { signOut(credentialManager, scope) }
                        )
                    }

                    composable(
                        route = ROUTE_AUCTION_DETAIL,
                        arguments = listOf(navArgument("auctionId") { type = NavType.StringType })
                    ) { entry ->
                        val auctionId = entry.arguments?.getString("auctionId") ?: return@composable
                        val detailVm: AuctionDetailViewModel = viewModel(
                            key = "${currentUserId}_$auctionId",
                            factory = viewModelFactory {
                                initializer {
                                    val app = checkNotNull(this[APPLICATION_KEY])
                                    val db = FirebaseFirestore.getInstance(app.getString(R.string.firestore_database_id))
                                    AuctionDetailViewModel(
                                        auctionRepo = AuctionRepository(db),
                                        auctionId = auctionId,
                                        currentUserId = currentUserId
                                    )
                                }
                            }
                        )
                        AuctionDetailScreen(
                            detailViewModel = detailVm,
                            profile = profile,
                            wallet = wallet,
                            nowMillis = nowMillis,
                            currentUserId = currentUserId,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(ROUTE_ADMIN) {
                        AdminDashboardScreen(
                            auctionsState = auctionsState,
                            usersState = allUsersAdmin,
                            withdrawalsState = allWithdrawalsAdmin,
                            adsState = allBusinessAdsAdmin,
                            inquiriesState = allAdInquiriesAdmin,
                            transactionsState = allTransactionsAdmin,
                            isBusy = isBusy,
                            onBack = { navController.popBackStack() },
                            onSeedShowcase = { mainViewModel.adminSeedShowcase() },
                            onUpdateAuctionStatus = { id, st -> mainViewModel.adminUpdateAuctionStatus(id, st) },
                            onToggleAuctionFeatured = { id, feat -> mainViewModel.adminToggleAuctionFeatured(id, feat) },
                            onDeleteAuction = { id -> mainViewModel.adminDeleteAuction(id) },
                            onProcessWithdrawal = { id, ok, note -> mainViewModel.adminProcessWithdrawal(id, ok, note) },
                            onToggleUserStatus = { id, st -> mainViewModel.adminToggleUserStatus(id, st) },
                            onSaveBusinessAd = { id, n, t, c, cat, f, st ->
                                mainViewModel.adminSaveBusinessAd(id, n, t, c, cat, f, st)
                            },
                            onDeleteBusinessAd = { id -> mainViewModel.adminDeleteBusinessAd(id) },
                            onUpdateAdInquiry = { id, st, note -> mainViewModel.adminUpdateAdInquiryStatus(id, st, note) }
                        )
                    }
                }
            }
        }
    }
}
