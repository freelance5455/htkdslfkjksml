package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppDatabase
import com.example.data.repository.FoodRepositoryImpl
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.DiaryScreen
import com.example.ui.screens.ExportScreen
import com.example.ui.screens.ScanScreen
import com.example.ui.theme.CalorieOrange
import com.example.ui.theme.CalorieSnapTheme
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.MainViewModelFactory
import com.example.ui.viewmodel.NavigationTab

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        val db = AppDatabase.getDatabase(applicationContext)
        val repo = FoodRepositoryImpl(db.mealDao())
        MainViewModelFactory(repo)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CalorieSnapTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val scanState by viewModel.scanState.collectAsState()
    val todayMeals by viewModel.todayMeals.collectAsState()
    val todayCalories by viewModel.todayCalories.collectAsState()
    val dailyGoal by viewModel.dailyCalorieGoal.collectAsState()
    val userMessage by viewModel.userMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    BackHandler(enabled = currentTab != NavigationTab.SCAN) {
        viewModel.selectTab(NavigationTab.SCAN)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "کالری‌اسنپ | CalorieSnap",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.testTag("app_top_bar")
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                NavigationBarItem(
                    selected = currentTab == NavigationTab.SCAN,
                    onClick = { viewModel.selectTab(NavigationTab.SCAN) },
                    icon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_camera),
                            contentDescription = "اسکن",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("اسکن غذا", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldGreenPrimary,
                        selectedTextColor = EmeraldGreenPrimary,
                        indicatorColor = EmeraldGreenPrimary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_tab_scan")
                )

                NavigationBarItem(
                    selected = currentTab == NavigationTab.DIARY,
                    onClick = { viewModel.selectTab(NavigationTab.DIARY) },
                    icon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_book),
                            contentDescription = "دفترچه",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("دفترچه کالری", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CalorieOrange,
                        selectedTextColor = CalorieOrange,
                        indicatorColor = CalorieOrange.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_tab_diary")
                )

                NavigationBarItem(
                    selected = currentTab == NavigationTab.CALCULATOR,
                    onClick = { viewModel.selectTab(NavigationTab.CALCULATOR) },
                    icon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_calculator),
                            contentDescription = "محاسبه",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("محاسبه نیاز", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldGreenPrimary,
                        selectedTextColor = EmeraldGreenPrimary,
                        indicatorColor = EmeraldGreenPrimary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_tab_calculator")
                )

                NavigationBarItem(
                    selected = currentTab == NavigationTab.EXPORT,
                    onClick = { viewModel.selectTab(NavigationTab.EXPORT) },
                    icon = {
                        Icon(
                            painter = painterResource(R.drawable.ic_folder_zip),
                            contentDescription = "سورس",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("سورس و APK", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldGreenPrimary,
                        selectedTextColor = EmeraldGreenPrimary,
                        indicatorColor = EmeraldGreenPrimary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_tab_export")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                NavigationTab.SCAN -> {
                    ScanScreen(
                        viewModel = viewModel,
                        scanState = scanState,
                        presets = viewModel.samplePresets
                    )
                }
                NavigationTab.DIARY -> {
                    DiaryScreen(
                        viewModel = viewModel,
                        meals = todayMeals,
                        totalCalories = todayCalories,
                        dailyGoal = dailyGoal
                    )
                }
                NavigationTab.CALCULATOR -> {
                    CalculatorScreen(viewModel = viewModel)
                }
                NavigationTab.EXPORT -> {
                    ExportScreen()
                }
            }
        }
    }
}
