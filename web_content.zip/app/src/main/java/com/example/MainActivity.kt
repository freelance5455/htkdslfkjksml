package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.core.content.ContextCompat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.receiver.AlarmReceiver
import com.example.ui.screens.AboutUsScreen
import com.example.ui.screens.ActiveRingingDialog
import com.example.ui.screens.AlarmsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.MainViewModel

enum class NavTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    ALARMS("Alarms", Icons.Filled.Alarm, Icons.Outlined.Alarm, "tab_alarms"),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "tab_settings"),
    ABOUT_US("About Us", Icons.Filled.Info, Icons.Outlined.Info, "tab_about_us")
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIntent(intent)

        setContent {
            val currentTheme by viewModel.currentTheme.collectAsState()
            val alarms by viewModel.alarms.collectAsState()
            val settings by viewModel.settings.collectAsState()
            val nextAlarm by viewModel.nextAlarm.collectAsState()
            val activeAlarm by viewModel.activeRingingAlarm.collectAsState()

            val context = LocalContext.current
            val notificationPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { _ -> }

            LaunchedEffect(Unit) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val isGranted = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                    if (!isGranted) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            MyApplicationTheme(
                appColorTheme = currentTheme,
                isDarkMode = settings.isDarkMode
            ) {
                var selectedTab by remember { mutableStateOf(NavTab.ALARMS) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MaterialTheme.colorScheme.background,
                    topBar = {
                        ChronoTopBar(
                            isDarkMode = settings.isDarkMode,
                            activeThemeName = currentTheme.displayName,
                            activeThemeColor = currentTheme.accentColor,
                            onToggleDarkMode = { viewModel.toggleDarkMode() },
                            onThemeClick = { selectedTab = NavTab.SETTINGS }
                        )
                    },
                    bottomBar = {
                        ChronoBottomBar(
                            currentTab = selectedTab,
                            onTabSelected = { selectedTab = it }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        Crossfade(targetState = selectedTab, label = "tab_crossfade") { tab ->
                            when (tab) {
                                NavTab.ALARMS -> {
                                    AlarmsScreen(
                                        alarms = alarms,
                                        nextAlarm = nextAlarm,
                                        is24Hour = settings.is24HourFormat,
                                        onToggleAlarm = { viewModel.toggleAlarm(it) },
                                        onDeleteAlarm = { viewModel.deleteAlarm(it) },
                                        onAddAlarm = { h, m, l, d, v, t, s, audioPath, audioTitle ->
                                            viewModel.addAlarm(h, m, l, d, v, t, s, audioPath, audioTitle)
                                        },
                                        onUpdateAlarm = { viewModel.updateAlarm(it) },
                                        onTestAlarm = { viewModel.testAlarmNow(it) }
                                    )
                                }
                                NavTab.SETTINGS -> {
                                    SettingsScreen(
                                        settings = settings,
                                        currentTheme = currentTheme,
                                        onToggleDarkMode = { viewModel.toggleDarkMode() },
                                        onSelectTheme = { viewModel.selectTheme(it) },
                                        onToggle24Hour = { viewModel.toggle24HourFormat() },
                                        onUpdateDefaultSnooze = { viewModel.updateDefaultSnooze(it) },
                                        onUpdateDefaultTone = { viewModel.updateDefaultTone(it) },
                                        onUpdateDefaultCustomAudio = { path, title ->
                                            viewModel.updateDefaultCustomAudio(path, title)
                                        },
                                        onTestRinging = { viewModel.testAlarmNow(null) }
                                    )
                                }
                                NavTab.ABOUT_US -> {
                                    AboutUsScreen()
                                }
                            }
                        }

                        // Ringing Alarm Fullscreen Overlay if an alarm is actively ringing
                        if (activeAlarm != null && activeAlarm?.isRinging == true) {
                            val state = activeAlarm!!
                            ActiveRingingDialog(
                                label = state.label,
                                snoozeMinutes = state.snoozeMinutes,
                                is24Hour = settings.is24HourFormat,
                                onDismiss = { viewModel.dismissActiveAlarm() },
                                onSnooze = { viewModel.snoozeActiveAlarm() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        when (intent?.action) {
            AlarmReceiver.ACTION_DISMISS_ALARM -> viewModel.dismissActiveAlarm()
            AlarmReceiver.ACTION_SNOOZE_ALARM -> viewModel.snoozeActiveAlarm()
        }
    }
}

@Composable
fun ChronoTopBar(
    isDarkMode: Boolean,
    activeThemeName: String,
    activeThemeColor: androidx.compose.ui.graphics.Color,
    onToggleDarkMode: () -> Unit,
    onThemeClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        color = MaterialTheme.colorScheme.background
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Alarm,
                        contentDescription = "Chrono App",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = "CHRONO",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    ),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // Right action controls: Quick Dark/Light mode toggle + Theme badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onToggleDarkMode,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .testTag("quick_dark_mode_button")
                ) {
                    Icon(
                        imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = if (isDarkMode) "Switch to Light Mode" else "Switch to Dark Mode",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Theme badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                        .clickable { onThemeClick() }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("theme_selector_pill"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(activeThemeColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = activeThemeName,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun ChronoBottomBar(
    currentTab: NavTab,
    onTabSelected: (NavTab) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 4.dp,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavTab.entries.forEach { tab ->
                val isSelected = currentTab == tab
                val primary = MaterialTheme.colorScheme.primary
                val icon = if (isSelected) tab.selectedIcon else tab.unselectedIcon

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else androidx.compose.ui.graphics.Color.Transparent)
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                        .testTag(tab.testTag),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = tab.title,
                        tint = if (isSelected) primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                        modifier = Modifier.size(20.dp)
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = tab.title,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp
                        ),
                        color = if (isSelected) primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                    )
                }
            }
        }
    }
}
