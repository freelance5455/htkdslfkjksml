package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Movie
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppDatabase
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.GoogleDriveSyncRepository
import com.example.data.repository.MediaRepository
import com.example.ui.components.AddSourceDialog
import com.example.ui.components.ComicReaderView
import com.example.ui.components.ComicsFeedView
import com.example.ui.components.CommentsAndTagsSheet
import com.example.ui.components.FeedView
import com.example.ui.components.MiscFeedView
import com.example.ui.components.PicturesFeedView
import com.example.ui.components.ProfileView
import com.example.ui.components.SettingsView
import com.example.ui.components.SidebarDrawer
import com.example.ui.theme.YiffyPrimary
import com.example.ui.theme.YiffyTheme
import com.example.ui.viewmodel.FeedViewModel
import com.example.ui.viewmodel.MainNavigationTab
import com.example.ui.viewmodel.ProfileViewModel
import com.example.ui.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val prefsRepo = UserPreferencesRepository(applicationContext)
        val mediaRepo = MediaRepository(applicationContext, prefsRepo)
        val driveRepo = GoogleDriveSyncRepository(applicationContext, mediaRepo, prefsRepo)
        val database = AppDatabase.getInstance(applicationContext)

        val feedViewModel = FeedViewModel(mediaRepo, prefsRepo)
        val profileViewModel = ProfileViewModel(mediaRepo, prefsRepo, database)
        val settingsViewModel = SettingsViewModel(prefsRepo, driveRepo)

        setContent {
            YiffyTheme {
                YiffyAppContent(
                    feedViewModel = feedViewModel,
                    profileViewModel = profileViewModel,
                    settingsViewModel = settingsViewModel
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YiffyAppContent(
    feedViewModel: FeedViewModel,
    profileViewModel: ProfileViewModel,
    settingsViewModel: SettingsViewModel
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val feedUiState by feedViewModel.uiState.collectAsState()
    val profileUiState by profileViewModel.uiState.collectAsState()
    val settingsUiState by settingsViewModel.uiState.collectAsState()
    val userPrefs by feedViewModel.userPreferences.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Sync status banner notification
    LaunchedEffect(settingsUiState.statusBanner) {
        settingsUiState.statusBanner?.let { message ->
            snackbarHostState.showSnackbar(message)
            settingsViewModel.clearBanner()
        }
    }

    // Feed status messages
    LaunchedEffect(feedUiState.statusMessage) {
        feedUiState.statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            feedViewModel.clearStatusMessage()
        }
    }

    // Handle Hardware / Gesture Back Button
    BackHandler(
        enabled = profileUiState.isSettingsOpen || feedUiState.isComicReaderOpen || drawerState.isOpen || feedUiState.isCommentsSheetVisible
    ) {
        when {
            profileUiState.isSettingsOpen -> profileViewModel.openSettings(false)
            feedUiState.isComicReaderOpen -> feedViewModel.closeComicReader()
            feedUiState.isCommentsSheetVisible -> feedViewModel.closeCommentsSheet()
            drawerState.isOpen -> coroutineScope.launch { drawerState.close() }
        }
    }

    // Modal Drawer holding Sidebar Slider
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            SidebarDrawer(
                currentTab = feedUiState.currentTab,
                selectedSource = feedUiState.selectedSourceFilter,
                genderFilter = userPrefs.genderFilter,
                isGoogleConnected = userPrefs.isGoogleConnected,
                onSelectTab = { tab -> feedViewModel.selectTab(tab) },
                onSelectSource = { source ->
                    feedViewModel.setSourceFilter(source)
                    feedViewModel.loadContent()
                },
                onSelectGenderFilter = { feedViewModel.setGenderFilter(it) },
                onClose = { coroutineScope.launch { drawerState.close() } }
            )
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                // Bottom Bar is hidden during full-screen comic reading or settings
                if (!profileUiState.isSettingsOpen && !feedUiState.isComicReaderOpen) {
                    YiffyBottomNavBar(
                        currentTab = feedUiState.currentTab,
                        onTabSelected = { tab -> feedViewModel.selectTab(tab) }
                    )
                }
            },
            containerColor = Color.Black
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when {
                    // Full-screen Settings View
                    profileUiState.isSettingsOpen -> {
                        SettingsView(
                            uiState = settingsUiState,
                            userPrefs = userPrefs,
                            onBack = { profileViewModel.openSettings(false) },
                            onSyncGoogleDrive = { email -> settingsViewModel.syncGoogleDrive(email) },
                            onViewDoc = { docName -> settingsViewModel.viewDocument(docName) },
                            onCloseDocViewer = { settingsViewModel.closeDocViewer() },
                            onOpenCaptchaWebView = { url -> settingsViewModel.openCaptchaWebView(url) },
                            onCloseCaptchaWebView = { settingsViewModel.closeCaptchaWebView() },
                            onSaveApiKeys = { l, a, r, rc, rcs, b, bp, t ->
                                settingsViewModel.saveApiKeys(l, a, r, rc, rcs, b, bp, t)
                            },
                            onUpdateUiScale = { settingsViewModel.updateUiScale(it) },
                            onUpdateDownloadFolder = { settingsViewModel.updateDownloadFolder(it) },
                            onSelectGenderFilter = { settingsViewModel.setGenderFilter(it) },
                            onSaveSourceQueryConfigs = { s, e, r, p -> settingsViewModel.saveSourceQueryConfigs(s, e, r, p) }
                        )
                    }

                    // Full-screen Comic Reader
                    feedUiState.isComicReaderOpen && feedUiState.activeComicForReading != null -> {
                        ComicReaderView(
                            comic = feedUiState.activeComicForReading!!,
                            onClose = { feedViewModel.closeComicReader() }
                        )
                    }

                    // Main App Tabs
                    else -> {
                        when (feedUiState.currentTab) {
                            MainNavigationTab.PROFILE -> {
                                ProfileView(
                                    uiState = profileUiState,
                                    userPrefs = userPrefs,
                                    onSelectSubTab = { profileViewModel.selectSubTab(it) },
                                    onToggleDropdown = { profileViewModel.toggleDropdown(it) },
                                    onSelectPlatformFilter = { profileViewModel.setPlatformFilter(it) },
                                    onSelectMediaTypeFilter = { profileViewModel.setMediaTypeFilter(it) },
                                    onSelectGenderFilter = { profileViewModel.setGenderFilter(it) },
                                    onOpenSettings = { profileViewModel.openSettings(true) },
                                    onOpenEditProfile = { profileViewModel.openEditProfile(true) },
                                    onSaveProfile = { name, bio -> profileViewModel.saveProfile(name, bio) },
                                    onDeleteDownloaded = { profileViewModel.deleteDownloadedItem(it) }
                                )
                            }
                            MainNavigationTab.VIDEOS -> {
                                FeedView(
                                    items = feedUiState.items,
                                    onItemVisible = { feedViewModel.onMediaItemVisible(it) },
                                    onToggleLike = { feedViewModel.toggleLike(it) },
                                    onToggleFavorite = { feedViewModel.toggleFavorite(it) },
                                    onOpenComments = { feedViewModel.openCommentsSheet(it) },
                                    onDownload = { feedViewModel.downloadItem(it) },
                                    onToggleSidebar = { coroutineScope.launch { drawerState.open() } },
                                    genderFilter = userPrefs.genderFilter,
                                    onSelectGenderFilter = { feedViewModel.setGenderFilter(it) },
                                    currentSourceFilter = feedUiState.selectedSourceFilter,
                                    onClearSourceFilter = {
                                        feedViewModel.setSourceFilter(null)
                                        feedViewModel.loadContent()
                                    },
                                    onRefresh = { feedViewModel.refreshContent() }
                                )
                            }
                            MainNavigationTab.PICTURES -> {
                                PicturesFeedView(
                                    items = feedUiState.items,
                                    onToggleLike = { feedViewModel.toggleLike(it) },
                                    onToggleFavorite = { feedViewModel.toggleFavorite(it) },
                                    onOpenComments = { feedViewModel.openCommentsSheet(it) },
                                    onDownload = { feedViewModel.downloadItem(it) },
                                    onOpenAddSource = { feedViewModel.toggleAddSourceDialog(true) }
                                )
                            }
                            MainNavigationTab.COMICS -> {
                                ComicsFeedView(
                                    comics = feedUiState.comics,
                                    onOpenComic = { comic -> feedViewModel.openComicReader(comic) }
                                )
                            }
                            MainNavigationTab.MISC -> {
                                MiscFeedView(
                                    items = feedUiState.items,
                                    onToggleLike = { feedViewModel.toggleLike(it) },
                                    onToggleFavorite = { feedViewModel.toggleFavorite(it) },
                                    onOpenComments = { feedViewModel.openCommentsSheet(it) },
                                    onDownload = { feedViewModel.downloadItem(it) },
                                    onOpenAddSource = { feedViewModel.toggleAddSourceDialog(true) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Bottom Sheet for Comments & Categorized Tags
    if (feedUiState.isCommentsSheetVisible && feedUiState.activePostForComments != null) {
        CommentsAndTagsSheet(
            mediaItem = feedUiState.activePostForComments!!,
            comments = feedUiState.currentPostComments,
            tags = feedUiState.currentPostTags,
            onDismiss = { feedViewModel.closeCommentsSheet() },
            onPostComment = { text -> feedViewModel.postComment(text) },
            sheetState = sheetState,
            initialPage = feedUiState.activeCommentsPage
        )
    }

    // Add Source Dialog
    if (feedUiState.isAddSourceDialogOpen) {
        AddSourceDialog(
            enabledSources = userPrefs.enabledSources,
            onToggleSource = { feedViewModel.addCustomSource(it) },
            onDismiss = { feedViewModel.toggleAddSourceDialog(false) }
        )
    }
}

/**
 * Yiffy Bottom Navigation Bar:
 * Exactly ordered: Profile (first on left) | Videos | Pictures | Comics | Miscellaneous
 */
@Composable
fun YiffyBottomNavBar(
    currentTab: MainNavigationTab,
    onTabSelected: (MainNavigationTab) -> Unit
) {
    Surface(
        color = Color(0xFF0F1117).copy(alpha = 0.95f),
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val navItems = listOf(
                BottomNavEntry(MainNavigationTab.PROFILE, "Profile", Icons.Filled.AccountCircle, Icons.Outlined.AccountCircle),
                BottomNavEntry(MainNavigationTab.VIDEOS, "Videos", Icons.Filled.Movie, Icons.Outlined.Movie),
                BottomNavEntry(MainNavigationTab.PICTURES, "Pictures", Icons.Filled.Image, Icons.Outlined.Image),
                BottomNavEntry(MainNavigationTab.COMICS, "Comics", Icons.Filled.Book, Icons.Outlined.Book),
                BottomNavEntry(MainNavigationTab.MISC, "Misc", Icons.Filled.Public, Icons.Outlined.Public)
            )

            navItems.forEach { entry ->
                val isSelected = currentTab == entry.tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable { onTabSelected(entry.tab) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("nav_tab_${entry.tab.name.lowercase()}")
                ) {
                    Icon(
                        imageVector = if (isSelected) entry.selectedIcon else entry.unselectedIcon,
                        contentDescription = entry.label,
                        tint = if (isSelected) YiffyPrimary else Color(0xFF888F9F),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text = entry.label,
                        color = if (isSelected) YiffyPrimary else Color(0xFF888F9F),
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

private data class BottomNavEntry(
    val tab: MainNavigationTab,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)
