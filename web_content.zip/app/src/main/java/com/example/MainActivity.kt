package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import com.example.core.configureAppCheck
import com.example.data.local.MyFilesDatabase
import com.example.data.local.SettingsDataStore
import com.example.data.storage.DeviceAndSafStorageAdapter
import com.example.data.storage.UsbOtgMonitor
import com.example.ui.components.ApkInspectorBottomSheet
import com.example.ui.components.ConflictResolutionDialog
import com.example.ui.components.TransferProgressDialog
import com.example.ui.screens.AiImageEditorScreen
import com.example.ui.screens.AiVideoEditorScreen
import com.example.ui.screens.AnalyzeStorageScreen
import com.example.ui.screens.CameraCaptureScreen
import com.example.ui.screens.FileBrowserScreen
import com.example.ui.screens.FilePreviewScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PermissionsSettingsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SmartSearchScreen
import com.example.ui.screens.TrashScreen
import com.example.ui.theme.LocalAnimationSpecs
import com.example.ui.theme.MyFilesTheme
import com.example.ui.viewmodel.AiStudioViewModel
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.FilesViewModel

class MainActivity : ComponentActivity() {

    private val database by lazy {
        Room.databaseBuilder(
            applicationContext,
            MyFilesDatabase::class.java,
            "my_files_metadata.db"
        ).fallbackToDestructiveMigration(true).build()
    }

    private val settingsDataStore by lazy { SettingsDataStore(applicationContext) }
    private val usbOtgMonitor by lazy { UsbOtgMonitor(applicationContext) }
    private val storageAdapter by lazy {
        DeviceAndSafStorageAdapter(
            context = applicationContext,
            dao = database.metadataDao(),
            usbMonitor = usbOtgMonitor
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure Firebase App Check before setContent, ViewModels, or Firebase calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        val shortcutTargetPath = intent?.getStringExtra("SHORTCUT_PATH")

        setContent {
            val filesViewModel: FilesViewModel = viewModel(
                factory = FilesViewModel.provideFactory(
                    appContext = applicationContext,
                    storageAdapter = storageAdapter,
                    dao = database.metadataDao(),
                    settingsDataStore = settingsDataStore,
                    usbMonitor = usbOtgMonitor
                )
            )
            val aiViewModel: AiStudioViewModel = viewModel()
            val settings by filesViewModel.settingsState.collectAsStateWithLifecycle()

            LaunchedEffect(shortcutTargetPath) {
                if (!shortcutTargetPath.isNullOrBlank()) {
                    filesViewModel.openFolder(shortcutTargetPath, pushHistory = false)
                }
            }

            MyFilesTheme(
                themeMode = settings.themeMode,
                amoledBlack = settings.amoledBlack,
                accentPreset = settings.accentPreset,
                dynamicSeedArgb = settings.dynamicSeedArgb,
                animationMode = settings.animationMode
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MyFilesRootContent(
                        filesViewModel = filesViewModel,
                        aiViewModel = aiViewModel
                    )
                }
            }
        }
    }
}

@Composable
private fun MyFilesRootContent(
    filesViewModel: FilesViewModel,
    aiViewModel: AiStudioViewModel
) {
    val context = LocalContext.current
    val animSpecs = LocalAnimationSpecs.current
    val snackbarHostState = remember { SnackbarHostState() }

    val settings by filesViewModel.settingsState.collectAsStateWithLifecycle()
    val destination by filesViewModel.currentDestination.collectAsStateWithLifecycle()
    val volumes by filesViewModel.volumes.collectAsStateWithLifecycle()
    val recentFiles by filesViewModel.recentFiles.collectAsStateWithLifecycle()
    val shortcuts by filesViewModel.shortcutItems.collectAsStateWithLifecycle()
    val categorySummary by filesViewModel.categorySummary.collectAsStateWithLifecycle()
    val trashItems by filesViewModel.trashItems.collectAsStateWithLifecycle()
    val breadcrumbs by filesViewModel.breadcrumbs.collectAsStateWithLifecycle()
    val browserItems by filesViewModel.browserItems.collectAsStateWithLifecycle()
    val selectedPaths by filesViewModel.selectedPaths.collectAsStateWithLifecycle()
    val clipboard by filesViewModel.clipboard.collectAsStateWithLifecycle()
    val isRefreshing by filesViewModel.isRefreshing.collectAsStateWithLifecycle()
    val activeCategory by filesViewModel.activeCategory.collectAsStateWithLifecycle()
    val categoryFiles by filesViewModel.categoryFiles.collectAsStateWithLifecycle()
    val favoriteNodes by filesViewModel.favoriteNodes.collectAsStateWithLifecycle()
    val analysisReport by filesViewModel.analysisReport.collectAsStateWithLifecycle()
    val searchFilters by filesViewModel.searchFilters.collectAsStateWithLifecycle()
    val searchResults by filesViewModel.searchResults.collectAsStateWithLifecycle()
    val activePreviewNode by filesViewModel.activePreviewNode.collectAsStateWithLifecycle()
    val inspectedApk by filesViewModel.inspectedApkMetadata.collectAsStateWithLifecycle()
    val transferProgress by filesViewModel.transferProgress.collectAsStateWithLifecycle()
    val conflictPrompt by filesViewModel.activeConflict.collectAsStateWithLifecycle()
    val statusMessage by filesViewModel.statusMessage.collectAsStateWithLifecycle()
    val currentPath by filesViewModel.currentPath.collectAsStateWithLifecycle()

    val smartSearchAiState by aiViewModel.smartSearchState.collectAsStateWithLifecycle()
    val imageAiState by aiViewModel.imageAiState.collectAsStateWithLifecycle()
    val videoAiState by aiViewModel.videoAiState.collectAsStateWithLifecycle()

    var pendingCloudSafRequest by remember { mutableStateOf(false) }

    val safTreeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            filesViewModel.registerGrantedSafTree(uri, isCloud = pendingCloudSafRequest)
        }
        pendingCloudSafRequest = false
    }

    LaunchedEffect(statusMessage) {
        val msg = statusMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            filesViewModel.postMessage(null)
        }
    }

    if (!settings.onboardingCompleted) {
        OnboardingScreen(
            volumes = volumes,
            onGrantSafFolder = {
                pendingCloudSafRequest = false
                safTreeLauncher.launch(null)
            },
            onContinue = { filesViewModel.completeOnboarding() }
        )
        return
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTabletWide = maxWidth >= 720.dp

        Box(modifier = Modifier.fillMaxSize()) {
            Row(modifier = Modifier.fillMaxSize()) {
                // Canonical Tablet / Foldable NavigationRail for wide screens
                if (isTabletWide) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(Modifier.padding(top = 16.dp))
                        NavigationRailItem(
                            selected = destination == AppDestination.HOME,
                            onClick = { filesViewModel.navigateTo(AppDestination.HOME) },
                            icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                            label = { Text("Home") }
                        )
                        NavigationRailItem(
                            selected = destination == AppDestination.BROWSER,
                            onClick = {
                                filesViewModel.openFolder(filesViewModel.storageAdapter.workspaceRootPath, pushHistory = false)
                            },
                            icon = { Icon(Icons.Filled.Folder, contentDescription = "Storage") },
                            label = { Text("Files") }
                        )
                        NavigationRailItem(
                            selected = destination == AppDestination.SEARCH,
                            onClick = { filesViewModel.navigateTo(AppDestination.SEARCH) },
                            icon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                            label = { Text("Search") }
                        )
                        NavigationRailItem(
                            selected = destination == AppDestination.ANALYZE_STORAGE,
                            onClick = { filesViewModel.navigateTo(AppDestination.ANALYZE_STORAGE) },
                            icon = { Icon(Icons.Filled.PieChart, contentDescription = "Analyze") },
                            label = { Text("Analyze") }
                        )
                        NavigationRailItem(
                            selected = destination == AppDestination.TRASH,
                            onClick = { filesViewModel.navigateTo(AppDestination.TRASH) },
                            icon = { Icon(Icons.Filled.DeleteOutline, contentDescription = "Trash") },
                            label = { Text("Trash") }
                        )
                        NavigationRailItem(
                            selected = destination == AppDestination.SETTINGS,
                            onClick = { filesViewModel.navigateTo(AppDestination.SETTINGS) },
                            icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                            label = { Text("Settings") }
                        )
                    }
                    VerticalDivider()
                }

                // Animated Screen Host reading global AnimationContext
                AnimatedContent(
                    targetState = destination,
                    transitionSpec = {
                        animSpecs.screenEnter() togetherWith animSpecs.screenExit()
                    },
                    label = "app_screen_transition",
                    modifier = Modifier.weight(1f)
                ) { screen ->
                    when (screen) {
                        AppDestination.ONBOARDING, AppDestination.HOME -> {
                            HomeDashboardScreen(
                                volumes = volumes,
                                recentFiles = recentFiles,
                                shortcuts = shortcuts,
                                categoryCounts = categorySummary.first,
                                categorySizes = categorySummary.second,
                                trashCount = trashItems.size,
                                showExtensions = settings.showFileExtensions,
                                onOpenSearch = { filesViewModel.navigateTo(AppDestination.SEARCH) },
                                onOpenSettings = { filesViewModel.navigateTo(AppDestination.SETTINGS) },
                                onOpenCamera = { filesViewModel.navigateTo(AppDestination.CAMERA_CAPTURE) },
                                onOpenCategory = { filesViewModel.openCategory(it) },
                                onOpenFavorites = { filesViewModel.navigateTo(AppDestination.FAVORITES) },
                                onOpenVolume = { vol ->
                                    if (vol.rootPath.startsWith("usb://")) {
                                        pendingCloudSafRequest = false
                                        safTreeLauncher.launch(null)
                                    } else {
                                        filesViewModel.openVolume(vol)
                                    }
                                },
                                onMountDeviceFolder = {
                                    pendingCloudSafRequest = false
                                    safTreeLauncher.launch(null)
                                },
                                onMountCloudProvider = {
                                    pendingCloudSafRequest = true
                                    safTreeLauncher.launch(null)
                                },
                                onEjectVolume = { filesViewModel.ejectOrUnmountVolume(it) },
                                onOpenRecentFile = { filesViewModel.openFileNode(it) },
                                onOpenShortcutPath = { path ->
                                    filesViewModel.openFolder(path, pushHistory = false)
                                },
                                onOpenTrash = { filesViewModel.navigateTo(AppDestination.TRASH) },
                                onOpenAnalyzeStorage = { filesViewModel.navigateTo(AppDestination.ANALYZE_STORAGE) }
                            )
                        }

                        AppDestination.BROWSER -> {
                            FileBrowserScreen(
                                titleOverride = null,
                                breadcrumbs = breadcrumbs,
                                items = browserItems,
                                selectedPaths = selectedPaths,
                                clipboard = clipboard,
                                settings = settings,
                                isRefreshing = isRefreshing,
                                onBack = { filesViewModel.navigateBack() },
                                onNavigateBreadcrumb = { filesViewModel.openFolder(it, pushHistory = true) },
                                onRefresh = { filesViewModel.refreshBrowser(showSkeleton = true) },
                                onOpenNode = { filesViewModel.openFileNode(it) },
                                onToggleSelect = { filesViewModel.toggleSelection(it) },
                                onSelectAll = { filesViewModel.selectAllInCurrentView(browserItems) },
                                onClearSelection = { filesViewModel.clearSelection() },
                                onChangeViewMode = { filesViewModel.setViewMode(it) },
                                onChangeSort = { f, asc -> filesViewModel.setSort(f, asc) },
                                onToggleShowHidden = { filesViewModel.setShowHidden(it) },
                                onCreateFolder = { filesViewModel.createFolder(it) },
                                onCreateTextNote = { n, b -> filesViewModel.createTextNote(n, b) },
                                onOpenCameraHere = { filesViewModel.navigateTo(AppDestination.CAMERA_CAPTURE) },
                                onOpenSearch = { filesViewModel.navigateTo(AppDestination.SEARCH) },
                                onShareSelected = { filesViewModel.shareNodes(context, selectedPaths.toList()) },
                                onCopySelected = { filesViewModel.stageCopy() },
                                onMoveSelected = { filesViewModel.stageMove() },
                                onPasteHere = { filesViewModel.pasteClipboardHere() },
                                onCancelClipboard = { filesViewModel.cancelClipboard() },
                                onDeleteSelected = { filesViewModel.deleteSelectedToTrash() },
                                onSwipeDeleteSingle = { filesViewModel.deleteSelectedToTrash(listOf(it.path)) },
                                onRenameNode = { node, newName -> filesViewModel.renameSingle(node.path, newName) },
                                onCompressSelected = { filesViewModel.compressSelectedToZip(it) },
                                onExtractZip = { filesViewModel.extractZipArchive(it) },
                                onToggleFavorite = { filesViewModel.toggleFavorite(it) },
                                onToggleHideNode = { filesViewModel.toggleHiddenStatus(it) },
                                onAddShortcut = { filesViewModel.addShortcutForNode(it) }
                            )
                        }

                        AppDestination.CATEGORY_LIST -> {
                            FileBrowserScreen(
                                titleOverride = activeCategory?.label ?: "Category",
                                breadcrumbs = emptyList(),
                                items = categoryFiles,
                                selectedPaths = selectedPaths,
                                clipboard = null,
                                settings = settings,
                                isRefreshing = isRefreshing,
                                onBack = { filesViewModel.navigateBack() },
                                onNavigateBreadcrumb = {},
                                onRefresh = { activeCategory?.let { filesViewModel.openCategory(it) } },
                                onOpenNode = { filesViewModel.openFileNode(it) },
                                onToggleSelect = { filesViewModel.toggleSelection(it) },
                                onSelectAll = { filesViewModel.selectAllInCurrentView(categoryFiles) },
                                onClearSelection = { filesViewModel.clearSelection() },
                                onChangeViewMode = { filesViewModel.setViewMode(it) },
                                onChangeSort = { f, asc -> filesViewModel.setSort(f, asc) },
                                onToggleShowHidden = { filesViewModel.setShowHidden(it) },
                                onCreateFolder = {},
                                onCreateTextNote = { _, _ -> },
                                onOpenCameraHere = {},
                                onOpenSearch = { filesViewModel.navigateTo(AppDestination.SEARCH) },
                                onShareSelected = { filesViewModel.shareNodes(context, selectedPaths.toList()) },
                                onCopySelected = { filesViewModel.stageCopy() },
                                onMoveSelected = { filesViewModel.stageMove() },
                                onPasteHere = {},
                                onCancelClipboard = {},
                                onDeleteSelected = { filesViewModel.deleteSelectedToTrash() },
                                onSwipeDeleteSingle = { filesViewModel.deleteSelectedToTrash(listOf(it.path)) },
                                onRenameNode = { node, newName -> filesViewModel.renameSingle(node.path, newName) },
                                onCompressSelected = { filesViewModel.compressSelectedToZip(it) },
                                onExtractZip = { filesViewModel.extractZipArchive(it) },
                                onToggleFavorite = { filesViewModel.toggleFavorite(it) },
                                onToggleHideNode = { filesViewModel.toggleHiddenStatus(it) },
                                onAddShortcut = { filesViewModel.addShortcutForNode(it) }
                            )
                        }

                        AppDestination.FAVORITES -> {
                            FileBrowserScreen(
                                titleOverride = "Favorites",
                                breadcrumbs = emptyList(),
                                items = favoriteNodes,
                                selectedPaths = selectedPaths,
                                clipboard = null,
                                settings = settings,
                                isRefreshing = false,
                                onBack = { filesViewModel.navigateBack() },
                                onNavigateBreadcrumb = {},
                                onRefresh = { filesViewModel.navigateTo(AppDestination.FAVORITES) },
                                onOpenNode = { filesViewModel.openFileNode(it) },
                                onToggleSelect = { filesViewModel.toggleSelection(it) },
                                onSelectAll = { filesViewModel.selectAllInCurrentView(favoriteNodes) },
                                onClearSelection = { filesViewModel.clearSelection() },
                                onChangeViewMode = { filesViewModel.setViewMode(it) },
                                onChangeSort = { f, asc -> filesViewModel.setSort(f, asc) },
                                onToggleShowHidden = { filesViewModel.setShowHidden(it) },
                                onCreateFolder = {},
                                onCreateTextNote = { _, _ -> },
                                onOpenCameraHere = {},
                                onOpenSearch = { filesViewModel.navigateTo(AppDestination.SEARCH) },
                                onShareSelected = { filesViewModel.shareNodes(context, selectedPaths.toList()) },
                                onCopySelected = { filesViewModel.stageCopy() },
                                onMoveSelected = { filesViewModel.stageMove() },
                                onPasteHere = {},
                                onCancelClipboard = {},
                                onDeleteSelected = { filesViewModel.deleteSelectedToTrash() },
                                onSwipeDeleteSingle = { filesViewModel.deleteSelectedToTrash(listOf(it.path)) },
                                onRenameNode = { node, newName -> filesViewModel.renameSingle(node.path, newName) },
                                onCompressSelected = { filesViewModel.compressSelectedToZip(it) },
                                onExtractZip = { filesViewModel.extractZipArchive(it) },
                                onToggleFavorite = { filesViewModel.toggleFavorite(it) },
                                onToggleHideNode = { filesViewModel.toggleHiddenStatus(it) },
                                onAddShortcut = { filesViewModel.addShortcutForNode(it) }
                            )
                        }

                        AppDestination.ANALYZE_STORAGE -> {
                            AnalyzeStorageScreen(
                                report = analysisReport,
                                onCleanNodesToTrash = { filesViewModel.deleteSelectedToTrash(it) },
                                onOpenNode = { filesViewModel.openFileNode(it) },
                                onBack = { filesViewModel.navigateBack() }
                            )
                        }

                        AppDestination.TRASH -> {
                            TrashScreen(
                                trashItems = trashItems,
                                autoEmptyEnabled = settings.autoEmptyTrash30Days,
                                onRestore = { filesViewModel.restoreFromTrash(it) },
                                onEmptyAll = { filesViewModel.emptyTrashAll() },
                                onBack = { filesViewModel.navigateBack() }
                            )
                        }

                        AppDestination.SEARCH -> {
                            SmartSearchScreen(
                                filters = searchFilters,
                                results = searchResults,
                                aiState = smartSearchAiState,
                                showExtensions = settings.showFileExtensions,
                                onUpdateFilters = { filesViewModel.updateSearchFilters(it) },
                                onRunAiSmartSearch = { nlQuery ->
                                    aiViewModel.interpretNaturalLanguageSearch(nlQuery) { parsed ->
                                        filesViewModel.applySmartAiFilter(
                                            keywords = parsed.keywords,
                                            extensions = parsed.extensions,
                                            categoryName = parsed.categoryName,
                                            minBytes = parsed.minSizeBytes,
                                            maxBytes = parsed.maxSizeBytes,
                                            modifiedAfterMs = parsed.modifiedAfterEpochMs
                                        )
                                    }
                                },
                                onOpenNode = { filesViewModel.openFileNode(it) },
                                onBack = { filesViewModel.navigateBack() }
                            )
                        }

                        AppDestination.SETTINGS -> {
                            SettingsScreen(
                                settings = settings,
                                onSetThemeMode = { filesViewModel.setThemeMode(it) },
                                onSetAmoledBlack = { filesViewModel.setAmoledBlack(it) },
                                onSetAccentPreset = { filesViewModel.setAccentPreset(it) },
                                onSetDynamicImageSeed = { filesViewModel.setDynamicSeed(it) },
                                onSetAnimationMode = { filesViewModel.setAnimationMode(it) },
                                onSetDefaultView = { filesViewModel.setViewMode(it) },
                                onSetSort = { f, a -> filesViewModel.setSort(f, a) },
                                onSetShowHidden = { filesViewModel.setShowHidden(it) },
                                onSetShowExtensions = { filesViewModel.setShowExtensions(it) },
                                onSetAutoEmptyTrash = { filesViewModel.setAutoEmptyTrash(it) },
                                onSetLanguage = { filesViewModel.setLanguage(it) },
                                onOpenPermissions = { filesViewModel.navigateTo(AppDestination.PERMISSIONS) },
                                onOpenTrash = { filesViewModel.navigateTo(AppDestination.TRASH) },
                                onBack = { filesViewModel.navigateBack() }
                            )
                        }

                        AppDestination.PERMISSIONS -> {
                            PermissionsSettingsScreen(
                                volumes = volumes,
                                onGrantSafFolder = {
                                    pendingCloudSafRequest = false
                                    safTreeLauncher.launch(null)
                                },
                                onBack = { filesViewModel.navigateBack() }
                            )
                        }

                        AppDestination.CAMERA_CAPTURE -> {
                            CameraCaptureScreen(
                                targetFolderPath = currentPath,
                                storageAdapter = filesViewModel.storageAdapter,
                                onMediaSaved = { msg ->
                                    filesViewModel.refreshBrowser(showSkeleton = false)
                                    filesViewModel.refreshHomeDashboard()
                                    filesViewModel.postMessage(msg)
                                },
                                onBack = { filesViewModel.navigateBack() }
                            )
                        }

                        AppDestination.PREVIEWER -> {
                            val node = activePreviewNode
                            if (node != null) {
                                FilePreviewScreen(
                                    node = node,
                                    storageAdapter = filesViewModel.storageAdapter,
                                    onOpenAiImageEditor = { filesViewModel.openImageEditor(it) },
                                    onOpenAiVideoEditor = { filesViewModel.openVideoEditor(it) },
                                    onExtractZip = {
                                        filesViewModel.extractZipArchive(it)
                                        filesViewModel.navigateBack()
                                    },
                                    onShare = { filesViewModel.shareNodes(context, listOf(it.path)) },
                                    onBack = { filesViewModel.navigateBack() }
                                )
                            } else {
                                filesViewModel.navigateBack()
                            }
                        }

                        AppDestination.IMAGE_EDITOR -> {
                            val node = activePreviewNode
                            if (node != null) {
                                AiImageEditorScreen(
                                    node = node,
                                    storageAdapter = filesViewModel.storageAdapter,
                                    aiViewModel = aiViewModel,
                                    aiState = imageAiState,
                                    onSavedMessage = { msg ->
                                        filesViewModel.refreshBrowser(showSkeleton = false)
                                        filesViewModel.refreshHomeDashboard()
                                        filesViewModel.postMessage(msg)
                                    },
                                    onBack = { filesViewModel.navigateBack() }
                                )
                            } else {
                                filesViewModel.navigateBack()
                            }
                        }

                        AppDestination.VIDEO_EDITOR -> {
                            val node = activePreviewNode
                            if (node != null) {
                                AiVideoEditorScreen(
                                    node = node,
                                    siblingVideos = browserItems,
                                    storageAdapter = filesViewModel.storageAdapter,
                                    aiViewModel = aiViewModel,
                                    aiState = videoAiState,
                                    onExportSaved = { msg ->
                                        filesViewModel.refreshBrowser(showSkeleton = false)
                                        filesViewModel.refreshHomeDashboard()
                                        filesViewModel.postMessage(msg)
                                    },
                                    onBack = { filesViewModel.navigateBack() }
                                )
                            } else {
                                filesViewModel.navigateBack()
                            }
                        }
                    }
                }
            }

            // Global Overlays: Transfer Progress, Conflict Resolution, APK Inspector, Snackbar
            if (transferProgress != null) {
                TransferProgressDialog(
                    progress = transferProgress!!,
                    onCancel = { filesViewModel.cancelActiveTransfer() }
                )
            }

            if (conflictPrompt != null) {
                ConflictResolutionDialog(
                    prompt = conflictPrompt!!,
                    onResolve = { action, applyAll ->
                        filesViewModel.resolveConflict(action, applyAll)
                    }
                )
            }

            if (inspectedApk != null) {
                ApkInspectorBottomSheet(
                    metadata = inspectedApk!!,
                    onShareInstaller = {
                        val target = browserItems.find { it.name == inspectedApk!!.fileName }
                            ?: recentFiles.find { it.name == inspectedApk!!.fileName }
                        if (target != null) {
                            filesViewModel.shareNodes(context, listOf(target.path))
                        }
                        filesViewModel.dismissApkInspector()
                    },
                    onDismiss = { filesViewModel.dismissApkInspector() }
                )
            }

            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 18.dp)
            )
        }
    }
}
