package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.StudioSettingsDialog
import com.example.ui.components.StudioTab
import com.example.ui.components.StudioTopAppBar
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.ClientOrderScreen
import com.example.ui.screens.OrderTrackerScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.OrderViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                EditoXApp()
            }
        }
    }
}

@Composable
fun EditoXApp(
    viewModel: OrderViewModel = viewModel()
) {
    var currentTab by remember { mutableStateOf(StudioTab.ORDER_FORM) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val allOrders by viewModel.allOrders.collectAsStateWithLifecycle()
    val upiId by viewModel.upiId.collectAsStateWithLifecycle()
    val botToken by viewModel.telegramBotToken.collectAsStateWithLifecycle()
    val chatId by viewModel.telegramChatId.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            StudioTopAppBar(
                currentTab = currentTab,
                onTabSelected = { currentTab = it },
                onSettingsClick = { showSettingsDialog = true },
                orderCount = allOrders.size
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Crossfade(
                targetState = currentTab,
                label = "ScreenTransition"
            ) { tab ->
                when (tab) {
                    StudioTab.ORDER_FORM -> {
                        ClientOrderScreen(
                            viewModel = viewModel,
                            onViewOrderInDashboard = {
                                currentTab = StudioTab.DASHBOARD
                            }
                        )
                    }

                    StudioTab.DASHBOARD -> {
                        AdminDashboardScreen(
                            viewModel = viewModel
                        )
                    }

                    StudioTab.TRACK_ORDER -> {
                        OrderTrackerScreen(
                            viewModel = viewModel
                        )
                    }
                }
            }
        }

        if (showSettingsDialog) {
            StudioSettingsDialog(
                viewModel = viewModel,
                initialUpi = upiId,
                initialBotToken = botToken,
                initialChatId = chatId,
                onDismiss = { showSettingsDialog = false }
            )
        }
    }
}

