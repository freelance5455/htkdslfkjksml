package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  private var webView: WebView? = null
  private var filePathCallback: ValueCallback<Array<Uri>>? = null

  private val fileChooserLauncher = registerForActivityResult(
    ActivityResultContracts.StartActivityForResult()
  ) { result ->
    val uri = result.data?.data
    if (uri != null) {
      filePathCallback?.onReceiveValue(arrayOf(uri))
    } else {
      filePathCallback?.onReceiveValue(null)
    }
    filePathCallback = null
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
      override fun handleOnBackPressed() {
        val wv = webView
        if (wv != null) {
          // Check if drawer or modal is open in JavaScript
          wv.evaluateJavascript(
            """
            (function() {
              const modal = document.getElementById('generic-modal');
              if (modal && modal.classList.contains('active')) {
                UI.closeModal();
                return 'modal_closed';
              }
              const drawer = document.getElementById('drawer-menu');
              if (drawer && drawer.classList.contains('active')) {
                UI.closeDrawer();
                return 'drawer_closed';
              }
              if (UI.currentView !== 'dashboard') {
                UI.switchView('dashboard');
                return 'view_switched';
              }
              return 'exit';
            })();
            """.trimIndent()
          ) { result ->
            if (result == "\"exit\"" || result == null) {
              isEnabled = false
              onBackPressedDispatcher.onBackPressed()
            }
          }
        } else {
          isEnabled = false
          onBackPressedDispatcher.onBackPressed()
        }
      }
    })

    setContent {
      MyApplicationTheme {
        Scaffold(
          modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .testTag("main_screen")
        ) { innerPadding ->
          PondManagementApp(
            modifier = Modifier
              .fillMaxSize()
              .padding(innerPadding),
            onWebViewCreated = { wv ->
              webView = wv
            },
            onShowFileChooser = { callback, intent ->
              filePathCallback = callback
              try {
                fileChooserLauncher.launch(intent)
              } catch (e: Exception) {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = null
              }
            },
            context = this@MainActivity
          )
        }
      }
    }
  }

  override fun onDestroy() {
    webView?.destroy()
    webView = null
    super.onDestroy()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PondManagementApp(
  modifier: Modifier = Modifier,
  onWebViewCreated: (WebView) -> Unit,
  onShowFileChooser: (ValueCallback<Array<Uri>>, Intent) -> Unit,
  context: Context
) {
  AndroidView(
    modifier = modifier.testTag("app_webview"),
    factory = { ctx ->
      WebView(ctx).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(false)

        addJavascriptInterface(
          WebAppInterface(ctx, this),
          "AndroidApp"
        )

        webViewClient = object : WebViewClient() {}

        webChromeClient = object : WebChromeClient() {
          override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
          ): Boolean {
            if (filePathCallback == null) return false
            val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
              type = "*/*"
            }
            onShowFileChooser(filePathCallback, intent)
            return true
          }
        }

        loadUrl("file:///android_asset/index.html")
        onWebViewCreated(this)
      }
    }
  )
}

class WebAppInterface(private val context: Context, private val webView: WebView) {

  @JavascriptInterface
  fun showToast(message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
  }

  @JavascriptInterface
  fun printPage() {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
    val printAdapter = webView.createPrintDocumentAdapter("AlKarim_Pond_Report")
    val jobName = "আল-কারীম পুকুর রিপোর্ট"
    printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

