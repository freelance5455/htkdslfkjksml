package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import com.example.data.models.ScreenDestination
import com.example.ui.components.AuthDialog
import com.example.ui.components.DrawerContent
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.ImageToVideoScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SpeechToVoiceScreen
import com.example.ui.screens.TextToImageScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.HazimAiViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: HazimAiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                HazimAiApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun HazimAiApp(viewModel: HazimAiViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val currentScreen by viewModel.currentScreen.collectAsState()
    val chatSessions by viewModel.chatSessions.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val chatLanguage by viewModel.chatLanguage.collectAsState()
    val userAccount by viewModel.userAccount.collectAsState()
    val isAuthDialogOpen by viewModel.isAuthDialogOpen.collectAsState()

    // Android Back Button handler
    BackHandler(enabled = drawerState.isOpen || currentScreen != ScreenDestination.CHAT) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else if (currentScreen != ScreenDestination.CHAT) {
            viewModel.navigateTo(ScreenDestination.CHAT)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                DrawerContent(
                    currentScreen = currentScreen,
                    chatSessions = chatSessions,
                    currentSessionId = currentSessionId,
                    currentLanguage = chatLanguage,
                    userAccount = userAccount,
                    onNavigate = { screen ->
                        viewModel.navigateTo(screen)
                        scope.launch { drawerState.close() }
                    },
                    onNewChat = {
                        viewModel.createNewChat()
                        scope.launch { drawerState.close() }
                    },
                    onSelectChatSession = { sessionId ->
                        viewModel.switchChatSession(sessionId)
                        scope.launch { drawerState.close() }
                    },
                    onDeleteChatSession = { sessionId ->
                        viewModel.deleteChatSession(sessionId)
                    },
                    onSelectLanguage = { lang ->
                        viewModel.setChatLanguage(lang)
                    },
                    onOpenAuth = {
                        scope.launch { drawerState.close() }
                        viewModel.openAuthDialog()
                    }
                )
            }
        }
    ) {
        when (currentScreen) {
            ScreenDestination.CHAT -> {
                ChatScreen(
                    viewModel = viewModel,
                    onOpenDrawer = { scope.launch { drawerState.open() } }
                )
            }
            ScreenDestination.TEXT_TO_IMAGE -> {
                TextToImageScreen(
                    viewModel = viewModel,
                    onOpenDrawer = { scope.launch { drawerState.open() } }
                )
            }
            ScreenDestination.IMAGE_TO_VIDEO -> {
                ImageToVideoScreen(
                    viewModel = viewModel,
                    onOpenDrawer = { scope.launch { drawerState.open() } }
                )
            }
            ScreenDestination.SPEECH_TO_VOICE -> {
                SpeechToVoiceScreen(
                    viewModel = viewModel,
                    onOpenDrawer = { scope.launch { drawerState.open() } }
                )
            }
            ScreenDestination.GALLERY -> {
                GalleryScreen(
                    viewModel = viewModel,
                    onOpenDrawer = { scope.launch { drawerState.open() } }
                )
            }
            ScreenDestination.PROFILE -> {
                ProfileScreen(
                    viewModel = viewModel,
                    onOpenDrawer = { scope.launch { drawerState.open() } }
                )
            }
        }

        // Authentication Modal Dialog
        AuthDialog(
            isOpen = isAuthDialogOpen,
            onDismiss = { viewModel.closeAuthDialog() },
            onLoginSuccess = { provider, email, name ->
                viewModel.login(provider, email, name)
            }
        )
    }
}
