package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.configureAppCheck
import com.example.ui.components.ActionConfirmationDialog
import com.example.ui.screens.AiChatScreen
import com.example.ui.screens.AppLauncherScreen
import com.example.ui.screens.AutomationRoutinesScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PhoneControlsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.UtilitiesVisionScreen
import com.example.ui.theme.XtraCardDark
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraDarkNavyBg
import com.example.ui.theme.XtraTextMed
import com.example.ui.theme.XtraTheme
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.XtraScreen

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory App Check initialization with launch intent as required by Firebase AI Logic
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            XtraTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

data class NavItem(
    val screen: XtraScreen,
    val icon: ImageVector,
    val label: String
)

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val pendingConfirmation by viewModel.pendingConfirmation.collectAsState()

    // Handle back button to return to Dashboard if on another sub-screen
    BackHandler(enabled = currentScreen != XtraScreen.DASHBOARD) {
        viewModel.navigateTo(XtraScreen.DASHBOARD)
    }

    val navItems = listOf(
        NavItem(XtraScreen.DASHBOARD, Icons.Default.Dashboard, "Core"),
        NavItem(XtraScreen.AI_CHAT, Icons.Default.Chat, "Chat"),
        NavItem(XtraScreen.PHONE_CONTROLS, Icons.Default.Tune, "Control"),
        NavItem(XtraScreen.APP_LAUNCHER, Icons.Default.Apps, "Apps"),
        NavItem(XtraScreen.AUTOMATION, Icons.Default.Bolt, "Routines"),
        NavItem(XtraScreen.UTILITIES_VISION, Icons.Default.Visibility, "Vision"),
        NavItem(XtraScreen.SETTINGS, Icons.Default.Settings, "Config")
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(XtraDarkNavyBg),
        bottomBar = {
            NavigationBar(
                containerColor = XtraCardDark,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("main_navigation_bar")
            ) {
                navItems.forEach { item ->
                    val isSelected = currentScreen == item.screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.navigateTo(item.screen) },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label,
                                tint = if (isSelected) XtraCyanPrimary else XtraTextMed
                            )
                        },
                        label = {
                            Text(
                                text = item.label,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) XtraCyanGlow else XtraTextMed
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = XtraCyanPrimary.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_tab_${item.screen.name}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
        ) {
            Crossfade(
                targetState = currentScreen,
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    XtraScreen.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                    XtraScreen.AI_CHAT -> AiChatScreen(viewModel = viewModel)
                    XtraScreen.PHONE_CONTROLS -> PhoneControlsScreen(viewModel = viewModel)
                    XtraScreen.APP_LAUNCHER -> AppLauncherScreen(viewModel = viewModel)
                    XtraScreen.AUTOMATION -> AutomationRoutinesScreen(viewModel = viewModel)
                    XtraScreen.UTILITIES_VISION -> UtilitiesVisionScreen(viewModel = viewModel)
                    XtraScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }
            }

            // Global Security Confirmation Modal
            pendingConfirmation?.let { action ->
                ActionConfirmationDialog(
                    action = action,
                    onDismiss = { viewModel.dismissPendingAction() },
                    onConfirm = { viewModel.confirmPendingAction() }
                )
            }
        }
    }
}
