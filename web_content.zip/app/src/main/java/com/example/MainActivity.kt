package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.WithdrawalScreen
import com.example.ui.screens.BillPaymentScreen
import com.example.ui.screens.ExpensesScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BusinessViewModel

enum class AppDestination(val label: String, val icon: ImageVector) {
    DASHBOARD("Dashboard", Icons.Default.Dashboard),
    WITHDRAWAL("Withdrawal", Icons.Default.CreditCard),
    BILL_PAYMENT("Bill Pay", Icons.Default.Receipt),
    EXPENSES("Expenses", Icons.Default.MoneyOff),
    REPORTS("Reports", Icons.Default.Assessment),
    HISTORY("History", Icons.Default.History),
    SETTINGS("Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CredPayApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CredPayApp(viewModel: BusinessViewModel = viewModel()) {
    var currentDestination by remember { mutableStateOf(AppDestination.DASHBOARD) }

    // Android back handler: Return to Dashboard if on another screen
    BackHandler(enabled = currentDestination != AppDestination.DASHBOARD) {
        currentDestination = AppDestination.DASHBOARD
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = currentDestination.label,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(
                        onClick = { currentDestination = AppDestination.HISTORY },
                        modifier = Modifier.testTag("nav_history_action")
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Transaction History",
                            tint = if (currentDestination == AppDestination.HISTORY) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = { currentDestination = AppDestination.SETTINGS },
                        modifier = Modifier.testTag("nav_settings_action")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = if (currentDestination == AppDestination.SETTINGS) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                listOf(
                    AppDestination.DASHBOARD,
                    AppDestination.WITHDRAWAL,
                    AppDestination.BILL_PAYMENT,
                    AppDestination.EXPENSES,
                    AppDestination.REPORTS
                ).forEach { destination ->
                    val isSelected = currentDestination == destination
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentDestination = destination },
                        icon = {
                            Icon(
                                imageVector = destination.icon,
                                contentDescription = destination.label,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        label = { Text(destination.label) },
                        modifier = Modifier.testTag("nav_item_${destination.name.lowercase()}")
                    )
                }
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        when (currentDestination) {
            AppDestination.DASHBOARD -> DashboardScreen(
                viewModel = viewModel,
                onNavigateToWithdrawal = { currentDestination = AppDestination.WITHDRAWAL },
                onNavigateToBillPayment = { currentDestination = AppDestination.BILL_PAYMENT },
                onNavigateToExpenses = { currentDestination = AppDestination.EXPENSES },
                onNavigateToReports = { currentDestination = AppDestination.REPORTS },
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.WITHDRAWAL -> WithdrawalScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.BILL_PAYMENT -> BillPaymentScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.EXPENSES -> ExpensesScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.REPORTS -> ReportsScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.HISTORY -> HistoryScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
            AppDestination.SETTINGS -> SettingsScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
        }
    }
}
