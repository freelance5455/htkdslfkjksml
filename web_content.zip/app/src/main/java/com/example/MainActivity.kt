package com.example

import android.app.Application
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AppDestination
import com.example.ui.components.IslamicDrawerContent
import com.example.ui.components.IslamicHeader
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DepositScreen
import com.example.ui.screens.ExpenseScreen
import com.example.ui.screens.IncomeScreen
import com.example.ui.screens.LoanScreen
import com.example.ui.screens.QuickAddScreen
import com.example.ui.screens.ReportScreen
import com.example.ui.screens.SalaryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.FinanceViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NijerHisabApp()
            }
        }
    }
}

@Composable
fun NijerHisabApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val viewModel: FinanceViewModel = viewModel(
        factory = FinanceViewModel.provideFactory(context.applicationContext as Application)
    )

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var currentDestination by remember { mutableStateOf(AppDestination.DASHBOARD) }

    // Observe user toast notifications
    LaunchedEffect(viewModel) {
        viewModel.userMessage.collect { message ->
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
    }

    // Back button handling:
    // 1. If drawer is open -> close drawer
    // 2. If inside another sub-screen -> go back to Dashboard
    BackHandler(enabled = drawerState.isOpen || currentDestination != AppDestination.DASHBOARD) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else if (currentDestination != AppDestination.DASHBOARD) {
            currentDestination = AppDestination.DASHBOARD
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet {
                IslamicDrawerContent(
                    currentDestination = currentDestination,
                    profileUri = settings?.profileImageUri,
                    onDestinationSelected = { destination ->
                        currentDestination = destination
                        scope.launch { drawerState.close() }
                    },
                    onProfileClick = {
                        currentDestination = AppDestination.SETTINGS
                        scope.launch { drawerState.close() }
                    }
                )
            }
        }
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                IslamicHeader(
                    title = currentDestination.title,
                    profileUri = settings?.profileImageUri,
                    onOpenDrawer = {
                        scope.launch { drawerState.open() }
                    },
                    onProfileClick = {
                        currentDestination = AppDestination.SETTINGS
                    }
                )
            },
            containerColor = Color(0xFFF9FCFA)
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(Color(0xFFF9FCFA))
            ) {
                when (currentDestination) {
                    AppDestination.DASHBOARD -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigate = { currentDestination = it }
                    )
                    AppDestination.INCOME -> IncomeScreen(viewModel = viewModel)
                    AppDestination.EXPENSE -> ExpenseScreen(viewModel = viewModel)
                    AppDestination.DEPOSIT -> DepositScreen(viewModel = viewModel)
                    AppDestination.LOAN -> LoanScreen(viewModel = viewModel)
                    AppDestination.SALARY -> SalaryScreen(viewModel = viewModel)
                    AppDestination.QUICK_ADD -> QuickAddScreen(viewModel = viewModel)
                    AppDestination.REPORT -> ReportScreen(viewModel = viewModel)
                    AppDestination.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }
            }
        }
    }
}
