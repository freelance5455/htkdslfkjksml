package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {

    private var webView: WebView? = null
    private var filePathCallback: ValueCallback<Array<android.net.Uri>>? = null

    private val fileChooserLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (filePathCallback != null) {
                val dataIntent = result.data
                val results = if (result.resultCode == RESULT_OK && dataIntent != null) {
                    val data = dataIntent.data
                    val clipData = dataIntent.clipData
                    if (clipData != null) {
                        Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    } else if (data != null) {
                        arrayOf(data)
                    } else {
                        null
                    }
                } else {
                    null
                }
                filePathCallback?.onReceiveValue(results)
                filePathCallback = null
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = webView
                if (wv != null) {
                    wv.evaluateJavascript(
                        """
                        (function() {
                          const modal = document.getElementById('generic-modal');
                          if (modal && modal.classList.contains('active')) {
                            UI.closeModal();
                            return 'modal_closed';
                          }
                          const drawer = document.getElementById('drawer-menu');
                          if (drawer && drawer.classList.contains('active')) {
                            UI.closeDrawer();
                            return 'drawer_closed';
                          }
                          if (UI.currentView !== 'dashboard') {
                            UI.switchView('dashboard');
                            return 'view_switched';
                          }
                          return 'exit';
                        })();
                        """.trimIndent()
                    ) { result ->
                        if (result == "\"exit\"" || result == "null" || result == null) {
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                            isEnabled = true
                        }
                    }
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })

        setContent {
            Scaffold(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("main_screen")
            ) { innerPadding ->
                PondManagementApp(
                    modifier = Modifier.padding(innerPadding),
                    onWebViewCreated = { webView = it },
                    onShowFileChooser = { callback, intent ->
                        filePathCallback = callback
                        fileChooserLauncher.launch(intent)
                    },
                    context = this
                )
            }
        }
    }

    override fun onDestroy() {
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PondManagementApp(
    modifier: Modifier = Modifier,
    onWebViewCreated: (WebView) -> Unit,
    onShowFileChooser: (ValueCallback<Array<android.net.Uri>>, Intent) -> Unit,
    context: Context
) {
    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    allowFileAccess = true
                    databaseEnabled = true
                    loadWithOverviewMode = true
                    useWideViewPort = true
                    displayZoomControls = false
                    builtInZoomControls = false
                }
                addJavascriptInterface(WebAppInterface(ctx, this), "AndroidApp")
                webViewClient = WebViewClient()
                webChromeClient = object : WebChromeClient() {
                    override fun onShowFileChooser(
                        wv: WebView?,
                        callback: ValueCallback<Array<android.net.Uri>>?,
                        params: FileChooserParams?
                    ): Boolean {
                        if (callback != null) {
                            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "*/*"
                            }
                            onShowFileChooser(callback, intent)
                            return true
                        }
                        return false
                    }
                }
                onWebViewCreated(this)
                loadUrl("file:///android_asset/index.html")
            }
        },
        modifier = modifier
            .fillMaxSize()
            .testTag("app_webview")
    )
}

class WebAppInterface(
    private val context: Context,
    private val webView: WebView
) {
    @JavascriptInterface
    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    @JavascriptInterface
    fun printPage() {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
        val printAdapter = webView.createPrintDocumentAdapter("AlKarim_Pond_Report")
        printManager?.print("আল-কারীম পুকুর রিপোর্ট", printAdapter, PrintAttributes.Builder().build())
    }
}
