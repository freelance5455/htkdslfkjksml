package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.SufiMainScreen
import com.example.ui.SufiViewModel
import com.example.ui.theme.ParchmentBase
import com.example.ui.theme.SufiSomeSaysTheme

class MainActivity : ComponentActivity() {
    private val viewModel: SufiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SufiSomeSaysTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = ParchmentBase
                ) {
                    SufiMainScreen(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.soundManager.startAmbientLoop()
    }

    override fun onPause() {
        super.onPause()
        viewModel.soundManager.stopAmbient()
    }
}
