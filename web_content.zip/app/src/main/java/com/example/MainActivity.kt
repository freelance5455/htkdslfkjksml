package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.lifecycle.AppLifecycleManager
import com.example.core.model.NavSection
import com.example.core.ui.components.AppHeader
import com.example.core.ui.components.AppNavigation
import com.example.features.analysis.AnalysisScreen
import com.example.features.autotrade.AutoTradeScreen
import com.example.features.binance.BinanceScreen
import com.example.features.more.MoreScreen
import com.example.features.news.NewsScreen
import com.example.features.portfolio.PortfolioScreen
import com.example.features.terminal.TerminalScreen
import com.example.ui.theme.BearRed
import com.example.ui.theme.IQTradeProTheme
import com.example.viewmodel.IQTradeViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: IQTradeViewModel by viewModels()
    private val appLifecycleManager = AppLifecycleManager()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycle.addObserver(appLifecycleManager)
        enableEdgeToEdge()

        setContent {
            IQTradeProTheme {
                val state by viewModel.uiState.collectAsStateWithLifecycle()

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        AppHeader(
                            currentSymbol = state.selectedSymbol,
                            currentMarket = state.selectedMarket.displayName,
                            isOnline = state.isNetworkOnline,
                            binanceConnectionState = state.binanceConnectionState,
                            paperBalance = state.paperBalance,
                            isLiveMode = state.isLiveTradingEnabled
                        )
                    },
                    bottomBar = {
                        AppNavigation(
                            currentSection = state.currentSection,
                            onSectionSelected = { viewModel.navigateTo(it) }
                        )
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (state.showNewsScreen) {
                            NewsScreen(
                                state = state,
                                onBack = { viewModel.setShowNewsScreen(false) },
                                onRefreshNews = { viewModel.fetchNews(forceRefresh = true) },
                                onSearchQueryChanged = { viewModel.setNewsSearchQuery(it) },
                                onMarketFilterSelected = { viewModel.setSelectedNewsMarket(it) },
                                onSentimentFilterSelected = { viewModel.setSelectedNewsSentiment(it) },
                                onImpactFilterSelected = { viewModel.setSelectedNewsImpact(it) },
                                onToggleOnlySelectedSymbol = { viewModel.toggleFilterOnlySelectedSymbol(it) },
                                onToggleOnlyBreaking = { /* handled via impact filter */ },
                                onNavigateToConfig = {
                                    viewModel.setShowNewsScreen(false)
                                    viewModel.navigateTo(NavSection.BINANCE)
                                }
                            )
                        } else {
                            // Main View Navigation Router
                            when (state.currentSection) {
                            NavSection.TERMINAL -> {
                                TerminalScreen(
                                    state = state,
                                    onMarketSelected = { market ->
                                        viewModel.selectMarket(market)
                                    },
                                    onInstrumentSelected = { instrument ->
                                        viewModel.selectInstrument(instrument)
                                    },
                                    onOpenSymbolPicker = {
                                        viewModel.setSymbolSearchOpen(true)
                                    },
                                    onCloseSymbolPicker = {
                                        viewModel.setSymbolSearchOpen(false)
                                    },
                                    onSearchQueryChanged = { query ->
                                        viewModel.setSymbolSearchQuery(query)
                                    },
                                    onQuoteFilterSelected = { quote ->
                                        viewModel.setSelectedQuoteFilter(quote)
                                    },
                                    onRefreshSymbols = {
                                        viewModel.refreshSymbols()
                                    },
                                    onTimeframeSelected = { tf ->
                                        viewModel.selectTimeframe(tf)
                                    },
                                    onToggleIndicators = { enabled ->
                                        viewModel.toggleIndicators(enabled)
                                    },
                                    onToggleVolume = { enabled ->
                                        viewModel.toggleVolume(enabled)
                                    },
                                    onToggleSignals = { enabled ->
                                        viewModel.toggleSignalPlotting(enabled)
                                    },
                                    onSimulatePaperTrade = { side, amount ->
                                        viewModel.simulatePaperTrade(side, amount)
                                    },
                                    onAddIndicator = { type, period, color ->
                                        viewModel.addIndicator(type, period, color)
                                    },
                                    onRemoveIndicator = { id ->
                                        viewModel.removeIndicator(id)
                                    },
                                    onToggleIndicator = { id, enabled ->
                                        viewModel.toggleIndicator(id, enabled)
                                    },
                                    onUpdateIndicatorPeriod = { id, period ->
                                        viewModel.updateIndicatorPeriod(id, period)
                                    },
                                    onSelectDrawingTool = { tool ->
                                        viewModel.setDrawingTool(tool)
                                    },
                                    onClearAllDrawings = {
                                        viewModel.clearDrawings()
                                    },
                                    onDrawingCreated = { drawing ->
                                        viewModel.addDrawing(drawing)
                                    },
                                    onExecuteOrder = { side, orderType, price, qty, protection ->
                                        viewModel.executeOrder(side, orderType, price, qty, protection)
                                    },
                                    onFloatClick = {
                                        viewModel.floatingController.requestOverlayActivation(this@MainActivity)
                                    },
                                    onReloadChartData = {
                                        viewModel.reloadChartData()
                                    },
                                    onPriceAlert = { alert ->
                                        viewModel.onPriceAlert(alert)
                                    },
                                    onDismissPriceAlert = {
                                        viewModel.dismissPriceAlert()
                                    }
                                )
                            }
                            NavSection.ANALYSIS -> {
                                AnalysisScreen(
                                    state = state,
                                    onRefreshAnalysis = {
                                        viewModel.refreshCompleteAnalysis()
                                    }
                                )
                            }
                            NavSection.PORTFOLIO -> {
                                PortfolioScreen(
                                    state = state,
                                    onResetAccount = {
                                        viewModel.resetPaperAccount()
                                    },
                                    onClosePosition = { tradeId ->
                                        viewModel.closePosition(tradeId)
                                    },
                                    onEmergencyStop = {
                                        viewModel.panicCloseAllPositions()
                                    }
                                )
                            }
                            NavSection.AUTO_TRADE -> {
                                AutoTradeScreen(
                                    state = state,
                                    onEmergencyStop = {
                                        viewModel.panicCloseAllPositions()
                                    },
                                    onSelectTradingMode = { mode ->
                                        viewModel.selectTradingMode(mode)
                                    },
                                    onSaveProtection = { protection ->
                                        viewModel.saveProtectionSettings(protection)
                                    },
                                    onExecuteScalpOrder = { side ->
                                        viewModel.executeOneClickScalpOrder(side)
                                    },
                                    onExecuteOrder = { side, type, price, qty, protection ->
                                        viewModel.executeOrder(side, type, price, qty, protection)
                                    },
                                    onTimeframeSelected = { tf ->
                                        viewModel.selectTimeframe(tf)
                                    },
                                    onOpenSymbolPicker = {
                                        viewModel.setSymbolSearchOpen(true)
                                    },
                                    onReloadChartData = {
                                        viewModel.reloadChartData()
                                    },
                                    onResetPaperAccount = {
                                        viewModel.resetPaperAccount()
                                    },
                                    onToggleIndicators = { visible ->
                                        viewModel.toggleIndicators(visible)
                                    },
                                    onToggleVolume = { visible ->
                                        viewModel.toggleVolume(visible)
                                    },
                                    onToggleSignals = { visible ->
                                        viewModel.toggleSignalPlotting(visible)
                                    },
                                    onAddIndicator = { type, period, colorHex ->
                                        viewModel.addIndicator(type, period, colorHex)
                                    },
                                    onRemoveIndicator = { id ->
                                        viewModel.removeIndicator(id)
                                    },
                                    onToggleIndicator = { id, visible ->
                                        viewModel.toggleIndicator(id, visible)
                                    },
                                    onUpdateIndicatorPeriod = { id, period ->
                                        viewModel.updateIndicatorPeriod(id, period)
                                    },
                                    onSelectDrawingTool = { tool ->
                                        viewModel.setDrawingTool(tool)
                                    },
                                    onClearAllDrawings = {
                                        viewModel.clearDrawings()
                                    },
                                    onDrawingCreated = { drawing ->
                                        viewModel.addDrawing(drawing)
                                    },
                                    onFloatClick = {
                                        viewModel.floatingController.requestOverlayActivation(this@MainActivity)
                                    },
                                    onToggleSmartMode = { enabled ->
                                        viewModel.toggleSmartMode(enabled)
                                    },
                                    onToggleAutoTrading = { armed ->
                                        viewModel.toggleAutoTrading(armed)
                                    },
                                    onToggleLiveTrading = { enabled ->
                                        viewModel.toggleLiveTrading(enabled)
                                    },
                                    onDismissPriceAlert = {
                                        viewModel.dismissPriceAlert()
                                    },
                                    onUpdateCustomConfig = { indicators, timeframes ->
                                        viewModel.updateCustomModeConfig(indicators, timeframes)
                                    }
                                )
                            }
                            NavSection.MORE -> {
                                MoreScreen(
                                    state = state,
                                    onResetPaperAccount = {
                                        viewModel.resetPaperAccount()
                                    },
                                    onNavigateToAnalysis = {
                                        viewModel.navigateTo(NavSection.ANALYSIS)
                                    },
                                    onOpenNewsFeed = {
                                        viewModel.setShowNewsScreen(true)
                                    }
                                )
                            }
                            NavSection.BINANCE -> {
                                BinanceScreen(
                                    state = state,
                                    onSaveCredentials = { apiKey, secretKey ->
                                        viewModel.saveBinanceCredentials(apiKey, secretKey)
                                    },
                                    onConnectTest = {
                                        viewModel.connectBinanceTest()
                                    },
                                    onDisconnect = {
                                        viewModel.disconnectBinance()
                                    },
                                    onClearCredentials = {
                                        viewModel.clearBinanceCredentials()
                                    },
                                    onSaveNewsApiKey = { key ->
                                        viewModel.saveNewsApiCredentials(key)
                                    },
                                    onToggleNewsApiConnection = { enable ->
                                        viewModel.toggleNewsApiConnection(enable)
                                    },
                                    onClearNewsApiKey = {
                                        viewModel.clearNewsApiCredentials()
                                    },
                                    onOpenNewsFeed = {
                                        viewModel.setShowNewsScreen(true)
                                    },
                                    onSaveWhatsAppConfig = { phone, key, phoneId ->
                                        viewModel.saveWhatsAppConfig(phone, key, phoneId)
                                    },
                                    onVerifyAndConnectWhatsApp = { phone, key, phoneId ->
                                        viewModel.verifyAndConnectWhatsApp(phone, key, phoneId)
                                    },
                                    onDisconnectWhatsApp = {
                                        viewModel.disconnectWhatsApp()
                                    },
                                    onSelectWhatsAppMethod = { method ->
                                        viewModel.setWhatsAppConnectionMethod(method)
                                    },
                                    onClearWhatsAppConfig = {
                                        viewModel.clearWhatsAppConfig()
                                    },
                                    onUpdateWhatsAppPreferences = { prefs ->
                                        viewModel.updateWhatsAppPreferences(prefs)
                                    },
                                    onSendWhatsAppTestAlert = { phone, key, phoneId ->
                                        viewModel.sendTestWhatsAppAlert(phone, key, phoneId)
                                    }
                                )
                            }
                        }
                    }

                        // Global Error Notification Banner
                        AnimatedVisibility(
                            visible = state.currentError != null,
                            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                                .align(Alignment.TopCenter)
                        ) {
                            state.currentError?.let { error ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF2D1217), RoundedCornerShape(10.dp))
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Alert",
                                        tint = BearRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = error.title,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color.White
                                        )
                                        Text(
                                            text = error.userMessage,
                                            fontSize = 11.sp,
                                            color = Color(0xFFFCA5A5)
                                        )
                                    }
                                    IconButton(
                                        onClick = { viewModel.dismissError() },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Dismiss",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
