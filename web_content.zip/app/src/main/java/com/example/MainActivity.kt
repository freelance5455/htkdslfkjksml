package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.SongEntity
import com.example.ui.LibraryFilter
import com.example.ui.MusicViewModel
import com.example.ui.components.MiniPlayer
import com.example.ui.dialogs.AddToPlaylistDialog
import com.example.ui.dialogs.EditMetadataDialog
import com.example.ui.dialogs.RemoveFromLibraryDialog
import com.example.ui.dialogs.SleepTimerDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.NowPlayingScreen
import com.example.ui.screens.PlaylistsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.OnEmeraldContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

enum class NavDestination {
    HOME,
    LIBRARY,
    PLAYLISTS,
    SETTINGS
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as MusicApplication

        setContent {
            MyApplicationTheme {
                val viewModel: MusicViewModel = viewModel(
                    factory = MusicViewModel.Factory(
                        repository = app.repository,
                        fileManager = app.fileManager,
                        playlistTransferManager = app.playlistTransferManager,
                        playbackController = app.playbackController
                    )
                )

                MusicAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MusicAppContent(viewModel: MusicViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Request notification permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Graceful handling */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Navigation State
    var currentTab by remember { mutableStateOf(NavDestination.HOME) }
    var isNowPlayingExpanded by remember { mutableStateOf(false) }

    // Dialog States
    var editingMetadataSong by remember { mutableStateOf<SongEntity?>(null) }
    var songToAddToPlaylist by remember { mutableStateOf<SongEntity?>(null) }
    var isAddingSelectedToPlaylist by remember { mutableStateOf(false) }
    var songToRemoveFromLibrary by remember { mutableStateOf<SongEntity?>(null) }
    var isRemovingSelectedFromLibrary by remember { mutableStateOf(false) }
    var isSleepTimerDialogOpen by remember { mutableStateOf(false) }

    // Collect states from ViewModel
    val allSongs by viewModel.allSongs.collectAsState()
    val favoriteSongs by viewModel.favoriteSongs.collectAsState()
    val recentlyPlayedSongs by viewModel.recentlyPlayedSongs.collectAsState()
    val recentlyAddedSongs by viewModel.recentlyAddedSongs.collectAsState()
    val playlists by viewModel.playlists.collectAsState()
    val displayedLibrarySongs by viewModel.displayedLibrarySongs.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val sortOption by viewModel.sortOption.collectAsState()
    val sortAscending by viewModel.sortAscending.collectAsState()
    val libraryFilter by viewModel.libraryFilter.collectAsState()

    val isMultiSelectMode by viewModel.isMultiSelectMode.collectAsState()
    val selectedSongIds by viewModel.selectedSongIds.collectAsState()

    val isImporting by viewModel.isImporting.collectAsState()
    val importProgress by viewModel.importProgress.collectAsState()
    val snackbarMessage by viewModel.snackbarMessage.collectAsState()
    val storageStats by viewModel.storageStats.collectAsState()

    // Playback state
    val playbackController = viewModel.playbackController
    val currentSong by playbackController.currentSong.collectAsState()
    val isPlaying by playbackController.isPlaying.collectAsState()
    val isBuffering by playbackController.isBuffering.collectAsState()
    val currentPositionMs by playbackController.currentPositionMs.collectAsState()
    val durationMs by playbackController.durationMs.collectAsState()
    val queue by playbackController.queue.collectAsState()
    val currentQueueIndex by playbackController.currentQueueIndex.collectAsState()
    val isShuffle by playbackController.isShuffle.collectAsState()
    val repeatMode by playbackController.repeatMode.collectAsState()
    val sleepTimerRemainingSeconds by playbackController.sleepTimerRemainingSeconds.collectAsState()

    // Handle Snackbar messages
    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    // System Back Handler
    BackHandler(enabled = isNowPlayingExpanded || isMultiSelectMode || currentTab != NavDestination.HOME) {
        when {
            isNowPlayingExpanded -> isNowPlayingExpanded = false
            isMultiSelectMode -> viewModel.clearSelection()
            currentTab != NavDestination.HOME -> currentTab = NavDestination.HOME
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Mini Player
                if (currentSong != null && !isNowPlayingExpanded) {
                    MiniPlayer(
                        song = currentSong,
                        isPlaying = isPlaying,
                        currentPositionMs = currentPositionMs,
                        durationMs = durationMs,
                        onPlayPauseClick = { playbackController.togglePlayPause() },
                        onSkipNextClick = { playbackController.skipToNext() },
                        onFavoriteClick = { currentSong?.let { viewModel.toggleFavorite(it) } },
                        onClick = { isNowPlayingExpanded = true }
                    )
                }

                // Bottom Navigation Bar
                NavigationBar(
                    containerColor = DarkSurfaceElevated,
                    tonalElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    NavigationBarItem(
                        selected = (currentTab == NavDestination.HOME),
                        onClick = { currentTab = NavDestination.HOME },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = OnEmeraldContainer,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldContainer,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_item_home")
                    )

                    NavigationBarItem(
                        selected = (currentTab == NavDestination.LIBRARY),
                        onClick = { currentTab = NavDestination.LIBRARY },
                        icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Library") },
                        label = { Text("Library") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = OnEmeraldContainer,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldContainer,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_item_library")
                    )

                    NavigationBarItem(
                        selected = (currentTab == NavDestination.PLAYLISTS),
                        onClick = { currentTab = NavDestination.PLAYLISTS },
                        icon = { Icon(Icons.Default.QueueMusic, contentDescription = "Playlists") },
                        label = { Text("Playlists") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = OnEmeraldContainer,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldContainer,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_item_playlists")
                    )

                    NavigationBarItem(
                        selected = (currentTab == NavDestination.SETTINGS),
                        onClick = { currentTab = NavDestination.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings") },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = OnEmeraldContainer,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldContainer,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_item_settings")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Destination Content
            when (currentTab) {
                NavDestination.HOME -> {
                    HomeScreen(
                        allSongs = allSongs,
                        favoriteSongs = favoriteSongs,
                        recentlyPlayedSongs = recentlyPlayedSongs,
                        recentlyAddedSongs = recentlyAddedSongs,
                        playlists = playlists,
                        onAddSongs = { uris -> viewModel.importAudioFiles(uris) },
                        onSongClick = { song, list -> playbackController.playSong(song, list) },
                        onPlaylistClick = { currentTab = NavDestination.PLAYLISTS },
                        onFavoritesClick = {
                            viewModel.libraryFilter.value = LibraryFilter.FAVORITES
                            currentTab = NavDestination.LIBRARY
                        },
                        onNavigateToLibrary = { currentTab = NavDestination.LIBRARY }
                    )
                }

                NavDestination.LIBRARY -> {
                    LibraryScreen(
                        songs = displayedLibrarySongs,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.searchQuery.value = it },
                        sortOption = sortOption,
                        sortAscending = sortAscending,
                        onSortOptionChange = { viewModel.sortOption.value = it },
                        onSortAscendingToggle = { viewModel.sortAscending.value = !viewModel.sortAscending.value },
                        libraryFilter = libraryFilter,
                        onFilterChange = { viewModel.libraryFilter.value = it },
                        isMultiSelectMode = isMultiSelectMode,
                        selectedSongIds = selectedSongIds,
                        onToggleSelectSong = { viewModel.toggleSongSelection(it) },
                        onSelectAll = { viewModel.selectAllDisplayed(displayedLibrarySongs) },
                        onClearSelection = { viewModel.clearSelection() },
                        onDeleteSelectedSongs = { isRemovingSelectedFromLibrary = true },
                        onAddSelectedToPlaylist = { isAddingSelectedToPlaylist = true },
                        onSongClick = { song, list -> playbackController.playSong(song, list) },
                        onPlayNext = { playbackController.playNext(it) },
                        onAddToQueue = { playbackController.addToQueue(it) },
                        onAddToPlaylist = { songToAddToPlaylist = it },
                        onEditMetadata = { editingMetadataSong = it },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onRemoveFromLibrary = { songToRemoveFromLibrary = it },
                        onAddSongs = { uris -> viewModel.importAudioFiles(uris) }
                    )
                }

                NavDestination.PLAYLISTS -> {
                    PlaylistsScreen(
                        playlists = playlists,
                        repository = (context.applicationContext as MusicApplication).repository,
                        allSongs = allSongs,
                        favoriteSongs = favoriteSongs,
                        recentlyPlayedSongs = recentlyPlayedSongs,
                        onCreatePlaylist = { name, desc, cover -> viewModel.createPlaylist(name, desc, cover) },
                        onUpdatePlaylist = { pl, name, desc, cover, remove -> viewModel.updatePlaylist(pl, name, desc, cover, remove) },
                        onDeletePlaylist = { viewModel.deletePlaylist(it) },
                        onPlaySong = { song, list -> playbackController.playSong(song, list) },
                        onExportPlaylist = { pl, sList, uri -> viewModel.exportPlaylist(pl, sList, uri) },
                        onImportPlaylist = { uri -> viewModel.importPlaylist(uri) { /* Handled with snackbar */ } }
                    )
                }

                NavDestination.SETTINGS -> {
                    SettingsScreen(
                        storageStats = storageStats,
                        sleepTimerRemainingSeconds = sleepTimerRemainingSeconds,
                        onRefreshStorage = { viewModel.refreshStorageStats() },
                        onCleanStorage = { viewModel.cleanUnusedAudioFiles() },
                        onOpenSleepTimer = { isSleepTimerDialogOpen = true },
                        onImportPlaylist = { uri -> viewModel.importPlaylist(uri) {} }
                    )
                }
            }

            // Import Progress Floating Toast Banner
            if (isImporting && importProgress != null) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(16.dp)
                        .clip(RoundedCornerShape(24.dp)),
                    color = DarkSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                    tonalElevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = EmeraldPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Importing ${importProgress?.current}/${importProgress?.total}: ${importProgress?.currentFileName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary
                        )
                    }
                }
            }

            // Animated Fullscreen Now Playing Overlay
            AnimatedVisibility(
                visible = isNowPlayingExpanded,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                NowPlayingScreen(
                    song = currentSong,
                    isPlaying = isPlaying,
                    isBuffering = isBuffering,
                    currentPositionMs = currentPositionMs,
                    durationMs = durationMs,
                    queue = queue,
                    currentQueueIndex = currentQueueIndex,
                    isShuffle = isShuffle,
                    repeatMode = repeatMode,
                    sleepTimerRemainingSeconds = sleepTimerRemainingSeconds,
                    onDismiss = { isNowPlayingExpanded = false },
                    onPlayPauseClick = { playbackController.togglePlayPause() },
                    onSeekTo = { playbackController.seekTo(it) },
                    onSkipNext = { playbackController.skipToNext() },
                    onSkipPrevious = { playbackController.skipToPrevious() },
                    onToggleShuffle = { playbackController.toggleShuffle() },
                    onCycleRepeat = { playbackController.cycleRepeatMode() },
                    onToggleFavorite = { viewModel.toggleFavorite(it) },
                    onPlaySongInQueue = { playbackController.playSongAtIndex(it) },
                    onRemoveFromQueue = { playbackController.removeFromQueue(it) },
                    onClearQueue = { playbackController.clearQueue() },
                    onOpenSleepTimer = { isSleepTimerDialogOpen = true },
                    onAddToPlaylist = { songToAddToPlaylist = it },
                    onEditMetadata = { editingMetadataSong = it }
                )
            }
        }
    }

    // Dialogs Handling
    if (editingMetadataSong != null) {
        EditMetadataDialog(
            song = editingMetadataSong!!,
            onDismiss = { editingMetadataSong = null },
            onSave = { title, artist, album, genre, year, artworkUri, removeArtwork ->
                viewModel.updateSongMetadata(
                    songId = editingMetadataSong!!.id,
                    newTitle = title,
                    newArtist = artist,
                    newAlbum = album,
                    newGenre = genre,
                    newYear = year,
                    newArtworkUri = artworkUri,
                    removeArtwork = removeArtwork
                )
                editingMetadataSong = null
            }
        )
    }

    if (songToAddToPlaylist != null) {
        AddToPlaylistDialog(
            playlists = playlists,
            onDismiss = { songToAddToPlaylist = null },
            onPlaylistSelected = { plId ->
                viewModel.addSongToPlaylist(plId, songToAddToPlaylist!!.id)
                songToAddToPlaylist = null
            },
            onCreateNewPlaylist = { name ->
                viewModel.createPlaylist(name) { newId ->
                    viewModel.addSongToPlaylist(newId, songToAddToPlaylist!!.id)
                    songToAddToPlaylist = null
                }
            }
        )
    }

    if (isAddingSelectedToPlaylist) {
        AddToPlaylistDialog(
            playlists = playlists,
            onDismiss = { isAddingSelectedToPlaylist = false },
            onPlaylistSelected = { plId ->
                viewModel.addMultipleSongsToPlaylist(plId, selectedSongIds.toList())
                isAddingSelectedToPlaylist = false
            },
            onCreateNewPlaylist = { name ->
                viewModel.createPlaylist(name) { newId ->
                    viewModel.addMultipleSongsToPlaylist(newId, selectedSongIds.toList())
                    isAddingSelectedToPlaylist = false
                }
            }
        )
    }

    if (songToRemoveFromLibrary != null) {
        RemoveFromLibraryDialog(
            song = songToRemoveFromLibrary,
            onDismiss = { songToRemoveFromLibrary = null },
            onConfirm = {
                viewModel.removeSongFromLibrary(songToRemoveFromLibrary!!)
                songToRemoveFromLibrary = null
            }
        )
    }

    if (isRemovingSelectedFromLibrary) {
        RemoveFromLibraryDialog(
            song = null,
            multipleCount = selectedSongIds.size,
            onDismiss = { isRemovingSelectedFromLibrary = false },
            onConfirm = {
                viewModel.removeMultipleSongsFromLibrary(selectedSongIds)
                isRemovingSelectedFromLibrary = false
            }
        )
    }

    if (isSleepTimerDialogOpen) {
        SleepTimerDialog(
            remainingSeconds = sleepTimerRemainingSeconds,
            onDismiss = { isSleepTimerDialogOpen = false },
            onStartTimer = { minutes -> playbackController.startSleepTimer(minutes) },
            onCancelTimer = { playbackController.cancelSleepTimer() }
        )
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
