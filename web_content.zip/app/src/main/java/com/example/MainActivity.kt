package com.example

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.ChatViewModel
import com.example.ui.components.AboutRaynoxDialog
import com.example.ui.components.BottomMessageComposer
import com.example.ui.components.ChatMessageRow
import com.example.ui.components.ProfileDialog
import com.example.ui.components.RaynoxSidebarDrawerContent
import com.example.ui.components.RaynoxTopBar
import com.example.ui.components.RaynoxWelcomeScreen
import com.example.ui.components.RenameConversationDialog
import com.example.ui.components.SettingsDialog
import com.example.ui.components.TemporalCalendarSheet
import com.example.ui.components.ToolsAndAssistantSheet
import com.example.ui.components.WakeWordDetailDialog
import com.example.ui.theme.RaynoxTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.data.remote.LocalBackendServer.startIfNeeded()
        enableEdgeToEdge()
        setContent {
            val chatViewModel: ChatViewModel = viewModel()
            val settings by chatViewModel.userSettings.collectAsStateWithLifecycle()

            RaynoxTheme(themeMode = settings.themeMode) {
                RaynoxChatApp(viewModel = chatViewModel)
            }
        }
    }
}

@Composable
fun RaynoxChatApp(viewModel: ChatViewModel) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val coroutineScope = rememberCoroutineScope()

    val settings by viewModel.userSettings.collectAsStateWithLifecycle()
    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val activeConversationId by viewModel.activeConversationId.collectAsStateWithLifecycle()
    val messages by viewModel.activeMessages.collectAsStateWithLifecycle()
    val inputText by viewModel.inputText.collectAsStateWithLifecycle()
    val pendingAttachment by viewModel.pendingAttachment.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val speakingMessageId by viewModel.speakingMessageId.collectAsStateWithLifecycle()
    val wakeWordStatus by viewModel.wakeWordStatus.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val temporalContext by viewModel.liveTemporalContext.collectAsStateWithLifecycle()
    val reminders by viewModel.reminders.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val isTorchOn by viewModel.isTorchOn.collectAsStateWithLifecycle()
    val networkTimeResult by viewModel.networkTimeResult.collectAsStateWithLifecycle()
    val isCheckingNetworkTime by viewModel.isCheckingNetworkTime.collectAsStateWithLifecycle()
    val connectionStatus by viewModel.connectionStatus.collectAsStateWithLifecycle()
    val connectionMessage by viewModel.connectionMessage.collectAsStateWithLifecycle()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()

    var showSettingsDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showWakeWordDialog by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showCalendarSheet by remember { mutableStateOf(false) }
    var showToolsSheet by remember { mutableStateOf(false) }

    // Close drawer on system back press when open
    BackHandler(enabled = drawerState.isOpen) {
        coroutineScope.launch { drawerState.close() }
    }

    // Show snackbar notifications
    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    // Auto-scroll to newest message or streaming chunk
    val lastMsgContentLen = messages.lastOrNull()?.content?.length ?: 0
    LaunchedEffect(messages.size, lastMsgContentLen) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Zero-permission Photo Picker for images/screenshots
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.attachFileFromUri(uri)
        }
    }

    // Document Picker for PDF, text, and code files
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.attachFileFromUri(uri)
        }
    }

    // Microphone permission launcher for in-app STT
    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.startOrStopVoiceInput(hasAudioPermission = true, onRequestAudioPermission = {})
        }
    }

    // Permissions launcher for "Hey Raynox" Foreground Service
    val wakeWordPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val audioGranted = result[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (audioGranted) {
            viewModel.toggleWakeWordGuard(hasAudioPermission = true, onRequestPermissions = {})
        }
    }

    fun checkAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun requestWakeWordPermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        wakeWordPermissionsLauncher.launch(perms.toTypedArray())
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            RaynoxSidebarDrawerContent(
                conversations = conversations,
                activeConversationId = activeConversationId,
                searchQuery = searchQuery,
                onSearchQueryChange = viewModel::onSearchQueryChanged,
                wakeWordStatus = wakeWordStatus,
                userName = settings.userName,
                onNewChat = {
                    viewModel.startNewChat()
                    coroutineScope.launch { drawerState.close() }
                },
                onSelectConversation = { id ->
                    viewModel.selectConversation(id)
                    coroutineScope.launch { drawerState.close() }
                },
                onDeleteConversation = viewModel::deleteConversation,
                onOpenWakeWordModal = {
                    coroutineScope.launch { drawerState.close() }
                    showWakeWordDialog = true
                },
                onOpenCalendarSheet = {
                    coroutineScope.launch { drawerState.close() }
                    showCalendarSheet = true
                },
                onOpenToolsSheet = {
                    coroutineScope.launch { drawerState.close() }
                    showToolsSheet = true
                },
                onOpenSettings = {
                    coroutineScope.launch { drawerState.close() }
                    showSettingsDialog = true
                },
                onOpenProfile = {
                    coroutineScope.launch { drawerState.close() }
                    showProfileDialog = true
                },
                onOpenAbout = {
                    coroutineScope.launch { drawerState.close() }
                    showAboutDialog = true
                }
            )
        }
    ) {
        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                RaynoxTopBar(
                    currentModel = settings.selectedModel,
                    hasMessages = messages.isNotEmpty(),
                    isDarkTheme = settings.themeMode != "LIGHT",
                    autoSpeakEnabled = settings.autoSpeakResponses,
                    wakeWordRunning = wakeWordStatus.isRunning,
                    temporalContext = temporalContext,
                    onOpenCalendarSheet = { showCalendarSheet = true },
                    onOpenToolsSheet = { showToolsSheet = true },
                    onOpenSidebar = {
                        focusManager.clearFocus()
                        coroutineScope.launch { drawerState.open() }
                    },
                    onNewChat = {
                        focusManager.clearFocus()
                        viewModel.startNewChat()
                    },
                    onSwitchModel = viewModel::updateSelectedModel,
                    onRenameChat = { showRenameDialog = true },
                    onCopyTranscript = {
                        val transcript = messages.joinToString("\n\n") { msg ->
                            val speaker = if (msg.role == "user") "You" else "Raynox AI"
                            "$speaker:\n${msg.content}"
                        }
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Raynox Transcript", transcript))
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Conversation copied to clipboard")
                        }
                    },
                    onToggleAutoSpeak = {
                        viewModel.updateAutoSpeak(!settings.autoSpeakResponses)
                    },
                    onToggleWakeWord = {
                        showWakeWordDialog = true
                    },
                    onToggleTheme = {
                        val nextTheme = if (settings.themeMode == "LIGHT") "DARK" else "LIGHT"
                        viewModel.updateThemeMode(nextTheme)
                    },
                    onDeleteCurrentChat = {
                        activeConversationId?.let { viewModel.deleteConversation(it) }
                    }
                )
            },
            bottomBar = {
                BottomMessageComposer(
                    inputText = inputText,
                    onInputTextChanged = viewModel::onInputTextChanged,
                    pendingAttachment = pendingAttachment,
                    onRemoveAttachment = viewModel::removePendingAttachment,
                    onPickImage = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickDocument = {
                        documentPickerLauncher.launch(arrayOf("*/*"))
                    },
                    isGenerating = isGenerating,
                    onSendMessage = {
                        focusManager.clearFocus()
                        viewModel.sendMessage()
                    },
                    onStopGenerating = viewModel::stopGeneration,
                    voiceState = voiceState,
                    voiceLanguage = settings.voiceLanguage,
                    onCycleVoiceLanguage = viewModel::cycleVoiceLanguage,
                    onToggleVoiceInput = {
                        viewModel.startOrStopVoiceInput(
                            hasAudioPermission = checkAudioPermission(),
                            onRequestAudioPermission = {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        )
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                if (messages.isEmpty()) {
                    // Welcome Screen centered when no messages exist
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        RaynoxWelcomeScreen(
                            userName = settings.userName,
                            onSelectPrompt = { prompt ->
                                focusManager.clearFocus()
                                viewModel.sendPromptText(prompt)
                            }
                        )
                    }
                } else {
                    // Conversation Message List
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("conversation_message_list"),
                        contentPadding = PaddingValues(top = 12.dp, bottom = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(
                            items = messages,
                            key = { it.id }
                        ) { message ->
                            ChatMessageRow(
                                message = message,
                                isSpeakingThisMessage = speakingMessageId == message.id,
                                onRetry = viewModel::retryOrRegenerateMessage,
                                onRegenerate = viewModel::retryOrRegenerateMessage,
                                onToggleSpeak = viewModel::toggleSpeakMessage
                            )
                        }
                    }
                }
            }
        }
    }

    // Dialogs & Modals
    if (showSettingsDialog) {
        SettingsDialog(
            settings = settings,
            wakeWordStatus = wakeWordStatus,
            connectionStatus = connectionStatus,
            connectionMessage = connectionMessage,
            onTestPing = { viewModel.testPingConnection(true) },
            onUpdateTheme = viewModel::updateThemeMode,
            onUpdateModel = viewModel::updateSelectedModel,
            onUpdateVoiceLanguage = viewModel::updateVoiceLanguage,
            onUpdateAutoSpeak = viewModel::updateAutoSpeak,
            onToggleWakeWordService = {
                viewModel.toggleWakeWordGuard(
                    hasAudioPermission = checkAudioPermission(),
                    onRequestPermissions = { requestWakeWordPermissions() }
                )
            },
            onClearAllChats = {
                viewModel.clearAllConversations()
                showSettingsDialog = false
            },
            onDismiss = { showSettingsDialog = false }
        )
    }

    if (showProfileDialog) {
        ProfileDialog(
            currentName = settings.userName,
            currentInstructions = settings.customInstructions,
            onSaveProfile = viewModel::saveUserProfile,
            onDismiss = { showProfileDialog = false }
        )
    }

    if (showWakeWordDialog) {
        WakeWordDetailDialog(
            status = wakeWordStatus,
            onToggleService = {
                viewModel.toggleWakeWordGuard(
                    hasAudioPermission = checkAudioPermission(),
                    onRequestPermissions = { requestWakeWordPermissions() }
                )
            },
            onDismiss = { showWakeWordDialog = false }
        )
    }

    if (showAboutDialog) {
        AboutRaynoxDialog(onDismiss = { showAboutDialog = false })
    }

    if (showRenameDialog) {
        val currentConv = conversations.firstOrNull { it.id == activeConversationId }
        RenameConversationDialog(
            currentTitle = currentConv?.title ?: "Conversation",
            onConfirmRename = viewModel::renameActiveConversation,
            onDismiss = { showRenameDialog = false }
        )
    }

    if (showCalendarSheet) {
        TemporalCalendarSheet(
            temporalContext = temporalContext,
            networkTimeResult = networkTimeResult,
            isCheckingNetworkTime = isCheckingNetworkTime,
            onCheckNetworkTime = viewModel::checkNetworkTime,
            onDismiss = { showCalendarSheet = false }
        )
    }

    if (showToolsSheet) {
        ToolsAndAssistantSheet(
            isTorchOn = isTorchOn,
            onToggleTorch = viewModel::toggleFlashlight,
            reminders = reminders,
            onCreateReminder = { title, minutes -> viewModel.createReminder(title, minutes) },
            onToggleReminderCompleted = viewModel::toggleReminderCompleted,
            onDeleteReminder = viewModel::deleteReminder,
            memories = memories,
            onSaveMemory = viewModel::saveMemory,
            onDeleteMemory = viewModel::deleteMemory,
            onOpenApp = viewModel::openAppByName,
            onOpenSettings = viewModel::openSettingsScreen,
            onDismiss = { showToolsSheet = false }
        )
    }
}
