package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DeliveryEntry
import com.example.ui.DeliveryViewModel
import com.example.ui.components.AddEditEntryDialog
import com.example.ui.screens.dashboard.DashboardScreen
import com.example.ui.screens.entries.DailyEntriesScreen
import com.example.ui.screens.reports.ReportsScreen
import com.example.ui.screens.settings.SettingsDialog
import com.example.ui.theme.DexterBackground
import com.example.ui.theme.DexterCyanPrimary
import com.example.ui.theme.DexterEmeraldSecondary
import com.example.ui.theme.DexterSurface
import com.example.ui.theme.MyApplicationTheme
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val viewModel: DeliveryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(viewModel: DeliveryViewModel) {
    var currentScreenIndex by remember { mutableIntStateOf(0) }

    val selectedMonth by viewModel.selectedMonth.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val userMessage by viewModel.userMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    var showAddDialog by remember { mutableStateOf(false) }
    var entryToEdit by remember { mutableStateOf<DeliveryEntry?>(null) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    LaunchedEffect(userMessage) {
        userMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUserMessage()
        }
    }

    val displayMonthName = remember(selectedMonth) {
        try {
            val parts = selectedMonth.split("-")
            val cal = Calendar.getInstance()
            cal.set(Calendar.YEAR, parts[0].toInt())
            cal.set(Calendar.MONTH, parts[1].toInt() - 1)
            SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
        } catch (_: Exception) {
            selectedMonth
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DexterBackground),
        containerColor = DexterBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Delivery Agent",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                        // Month Selector Switcher
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 2.dp)
                        ) {
                            Icon(
                                Icons.Default.ChevronLeft,
                                contentDescription = "Previous Month",
                                modifier = Modifier
                                    .size(20.dp)
                                    .clickable { viewModel.changeMonth(-1) },
                                tint = DexterCyanPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = displayMonthName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = DexterCyanPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                Icons.Default.ChevronRight,
                                contentDescription = "Next Month",
                                modifier = Modifier
                                    .size(20.dp)
                                    .clickable { viewModel.changeMonth(1) },
                                tint = DexterCyanPrimary
                            )
                        }
                    }
                },
                navigationIcon = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DexterEmeraldSecondary.copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, DexterEmeraldSecondary.copy(alpha = 0.3f)),
                        modifier = Modifier.padding(start = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(DexterEmeraldSecondary)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "Offline",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = DexterEmeraldSecondary
                            )
                        }
                    }
                },
                actions = {},
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = DexterSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DexterSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentScreenIndex == 0,
                    onClick = { currentScreenIndex = 0 },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Dashboard", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF001E2E),
                        selectedTextColor = DexterCyanPrimary,
                        indicatorColor = DexterCyanPrimary,
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_dashboard")
                )
                NavigationBarItem(
                    selected = currentScreenIndex == 1,
                    onClick = { currentScreenIndex = 1 },
                    icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Deliveries") },
                    label = { Text("Deliveries", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF001E2E),
                        selectedTextColor = DexterCyanPrimary,
                        indicatorColor = DexterCyanPrimary,
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_entries")
                )
                NavigationBarItem(
                    selected = currentScreenIndex == 2,
                    onClick = { currentScreenIndex = 2 },
                    icon = { Icon(Icons.Default.Description, contentDescription = "Reports") },
                    label = { Text("Reports", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF001E2E),
                        selectedTextColor = DexterCyanPrimary,
                        indicatorColor = DexterCyanPrimary,
                        unselectedIconColor = Color(0xFF64748B),
                        unselectedTextColor = Color(0xFF64748B)
                    ),
                    modifier = Modifier.testTag("nav_reports")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreenIndex,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { screenIndex ->
                when (screenIndex) {
                    0 -> DashboardScreen(
                        viewModel = viewModel,
                        onOpenAddEntry = {
                            entryToEdit = null
                            showAddDialog = true
                        },
                        onOpenSettings = { showSettingsDialog = true }
                    )
                    1 -> DailyEntriesScreen(
                        viewModel = viewModel,
                        onAddEntry = {
                            entryToEdit = null
                            showAddDialog = true
                        },
                        onEditEntry = { entry ->
                            entryToEdit = entry
                            showAddDialog = true
                        }
                    )
                    2 -> ReportsScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    // Add / Edit Entry Dialog
    if (showAddDialog) {
        AddEditEntryDialog(
            initialEntry = entryToEdit,
            defaultRate = profile.defaultRate,
            currentDateString = viewModel.todayDateString,
            onDismiss = {
                showAddDialog = false
                entryToEdit = null
            },
            onSave = { date, count, rate, notes, id ->
                viewModel.addOrUpdateEntry(
                    dateString = date,
                    count = count,
                    rate = rate,
                    notes = notes,
                    existingId = id
                )
                showAddDialog = false
                entryToEdit = null
            }
        )
    }

    // Settings Dialog
    if (showSettingsDialog) {
        SettingsDialog(
            userProfile = profile,
            onDismiss = { showSettingsDialog = false },
            onSave = { name, defaultRate, vehicleNumber ->
                viewModel.saveProfile(name, defaultRate, vehicleNumber)
                showSettingsDialog = false
            }
        )
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Delivery Agent $name", modifier = modifier)
}
