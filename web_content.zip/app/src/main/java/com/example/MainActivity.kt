package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.camera.BarcodeScannerDialog
import com.example.ui.screens.EstoqueScreen
import com.example.ui.screens.ValidadeScreen
import com.example.ui.screens.VendasScreen
import com.example.ui.screens.components.AddEditPerfumeDialog
import com.example.ui.screens.components.EditVendaDialog
import com.example.ui.theme.PerfumeStockTheme
import com.example.ui.theme.RosePrimary
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.PerfumeViewModel
import com.example.ui.viewmodel.ScannerTarget

class MainActivity : ComponentActivity() {
    private val viewModel: PerfumeViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PerfumeStockTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: PerfumeViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val allPerfumes by viewModel.allPerfumes.collectAsStateWithLifecycle()
    val produtosAgrupados by viewModel.produtosAgrupados.collectAsStateWithLifecycle()
    val filteredProdutosAgrupados by viewModel.filteredProdutosAgrupados.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()

    val totalAlertasCount by viewModel.totalAlertasCount.collectAsStateWithLifecycle()
    val vencidosList by viewModel.vencidosList.collectAsStateWithLifecycle()
    val aVencerList by viewModel.aVencerList.collectAsStateWithLifecycle()

    // PDV / Vendas
    val vendaCodigo by viewModel.vendaCodigo.collectAsStateWithLifecycle()
    val vendaQuantidade by viewModel.vendaQuantidade.collectAsStateWithLifecycle()
    val produtoEncontrado by viewModel.vendaProdutoEncontrado.collectAsStateWithLifecycle()
    val lotesDoProdutoVenda by viewModel.lotesDoProdutoVenda.collectAsStateWithLifecycle()
    val vendaLoteSelecionadoId by viewModel.vendaLoteSelecionadoId.collectAsStateWithLifecycle()

    // Controle Mês a Mês
    val vendasFiltradasPorMes by viewModel.vendasFiltradasPorMes.collectAsStateWithLifecycle()
    val mesesDisponiveis by viewModel.mesesDisponiveis.collectAsStateWithLifecycle()
    val mesSelecionado by viewModel.mesSelecionado.collectAsStateWithLifecycle()
    val kpiMes by viewModel.kpiMesSelecionado.collectAsStateWithLifecycle()

    val vendaFeedback by viewModel.vendaFeedback.collectAsStateWithLifecycle()
    val isVendaError by viewModel.isVendaError.collectAsStateWithLifecycle()

    // Modals
    val isAddEditOpen by viewModel.isAddEditModalOpen.collectAsStateWithLifecycle()
    val editingPerfume by viewModel.editingPerfume.collectAsStateWithLifecycle()
    val isEditVendaModalOpen by viewModel.isEditVendaModalOpen.collectAsStateWithLifecycle()
    val vendaSendoEditada by viewModel.vendaSendoEditada.collectAsStateWithLifecycle()
    val isScannerOpen by viewModel.isScannerOpen.collectAsStateWithLifecycle()
    val scannedCodeForCadastro by viewModel.scannedCodeForCadastro.collectAsStateWithLifecycle()

    // Back button behavior
    if (currentTab != MainTab.ESTOQUE) {
        BackHandler {
            viewModel.selectTab(MainTab.ESTOQUE)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color(0xFFFDE047),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Perfumaria Express",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                },
                actions = {
                    // Quick Scanner button in header
                    IconButton(
                        onClick = {
                            if (currentTab == MainTab.VENDAS) {
                                viewModel.openScanner(ScannerTarget.VENDA)
                            } else {
                                viewModel.openScanner(ScannerTarget.CADASTRO)
                            }
                        },
                        modifier = Modifier.testTag("topbar_scanner_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Abrir Scanner",
                            tint = Color.White
                        )
                    }

                    // Quick Add button in header
                    IconButton(
                        onClick = { viewModel.openAddPerfume() },
                        modifier = Modifier.testTag("topbar_add_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Adicionar Lote / Perfume",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = RosePrimary,
                    titleContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                // Tab 1: Estoque
                NavigationBarItem(
                    selected = currentTab == MainTab.ESTOQUE,
                    onClick = { viewModel.selectTab(MainTab.ESTOQUE) },
                    icon = {
                        Icon(Icons.Default.Inventory, contentDescription = "Estoque")
                    },
                    label = { Text("Estoque", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RosePrimary,
                        selectedTextColor = RosePrimary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_estoque")
                )

                // Tab 2: Vendas (PDV)
                NavigationBarItem(
                    selected = currentTab == MainTab.VENDAS,
                    onClick = { viewModel.selectTab(MainTab.VENDAS) },
                    icon = {
                        Icon(Icons.Default.PointOfSale, contentDescription = "Frente de Caixa")
                    },
                    label = { Text("Frente de Caixa", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RosePrimary,
                        selectedTextColor = RosePrimary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_vendas")
                )

                // Tab 3: Validade
                NavigationBarItem(
                    selected = currentTab == MainTab.ALERTAS,
                    onClick = { viewModel.selectTab(MainTab.ALERTAS) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (totalAlertasCount > 0) {
                                    Badge(
                                        containerColor = MaterialTheme.colorScheme.error,
                                        contentColor = Color.White
                                    ) {
                                        Text("$totalAlertasCount")
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = "Validade")
                        }
                    },
                    label = { Text("Validade", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RosePrimary,
                        selectedTextColor = RosePrimary,
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_alertas")
                )
            }
        },
        floatingActionButton = {
            if (currentTab == MainTab.ESTOQUE) {
                ExtendedFloatingActionButton(
                    onClick = { viewModel.openAddPerfume() },
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Novo Lote / Perfume", fontWeight = FontWeight.Bold) },
                    containerColor = RosePrimary,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("fab_add_perfume")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (currentTab) {
                MainTab.ESTOQUE -> {
                    EstoqueScreen(
                        produtosAgrupados = filteredProdutosAgrupados,
                        searchQuery = searchQuery,
                        onSearchChange = { viewModel.searchQuery.value = it },
                        selectedFilter = selectedFilter,
                        onFilterChange = { viewModel.selectedFilter.value = it },
                        onNovoLoteParaProduto = { codigo -> viewModel.openAddPerfume(codigo) },
                        onEditLote = { lote -> viewModel.openEditPerfume(lote) },
                        onDeleteLote = { id -> viewModel.deletePerfumeLote(id) },
                        onAdjustStockLote = { id, delta -> viewModel.adjustStock(id, delta) },
                        onResetDefaults = { viewModel.resetToDefaults() }
                    )
                }
                MainTab.VENDAS -> {
                    VendasScreen(
                        vendaCodigo = vendaCodigo,
                        onCodigoChange = { viewModel.updateVendaCodigo(it) },
                        vendaQuantidade = vendaQuantidade,
                        onQuantidadeChange = { viewModel.updateVendaQuantidade(it) },
                        produtoEncontrado = produtoEncontrado,
                        lotesDisponiveis = lotesDoProdutoVenda,
                        loteSelecionadoId = vendaLoteSelecionadoId,
                        onSelectLote = { viewModel.selectVendaLote(it) },
                        vendasFiltradas = vendasFiltradasPorMes,
                        mesesDisponiveis = mesesDisponiveis,
                        mesSelecionado = mesSelecionado,
                        onSelectMes = { viewModel.mesSelecionado.value = it },
                        kpiMes = kpiMes,
                        vendaFeedback = vendaFeedback,
                        isVendaError = isVendaError,
                        onOpenScanner = { viewModel.openScanner(ScannerTarget.VENDA) },
                        onFinalizarVenda = { viewModel.finalizarVenda() },
                        onEditarVenda = { venda -> viewModel.abrirEdicaoVenda(venda) }
                    )
                }
                MainTab.ALERTAS -> {
                    ValidadeScreen(
                        vencidosList = vencidosList,
                        aVencerList = aVencerList,
                        onEditPerfume = { perf -> viewModel.openEditPerfume(perf) },
                        onNavigateToPDVWithCode = { codigo ->
                            viewModel.updateVendaCodigo(codigo)
                            viewModel.selectTab(MainTab.VENDAS)
                        }
                    )
                }
            }
        }
    }

    // Modal: Cadastrar / Editar Perfume ou Lote
    if (isAddEditOpen) {
        AddEditPerfumeDialog(
            perfumeToEdit = editingPerfume,
            existingProducts = produtosAgrupados,
            scannedBarcode = scannedCodeForCadastro,
            onDismiss = {
                viewModel.closeAddEditModal()
                viewModel.clearScannedCodeForCadastro()
            },
            onOpenScanner = {
                viewModel.openScanner(ScannerTarget.CADASTRO)
            },
            onSave = { id, codigo, nome, marca, custo, venda, estoque, validade, numeroLote ->
                viewModel.savePerfume(id, codigo, nome, marca, custo, venda, estoque, validade, numeroLote)
                viewModel.clearScannedCodeForCadastro()
            }
        )
    }

    // Modal: Editar Venda (Correção ou Estorno)
    if (isEditVendaModalOpen && vendaSendoEditada != null) {
        EditVendaDialog(
            venda = vendaSendoEditada!!,
            onDismiss = { viewModel.fecharEdicaoVenda() },
            onSave = { vendaId, novaQtd, novoPreco ->
                viewModel.salvarEdicaoVenda(vendaId, novaQtd, novoPreco)
            },
            onCancelarVenda = { vendaId ->
                viewModel.cancelarVenda(vendaId)
            }
        )
    }

    // Modal: Scanner de Código de Barras (CameraX + ML Kit + Quick Pickers)
    if (isScannerOpen) {
        val suggestedList = produtosAgrupados.map { Pair(it.codigo, it.nome) }
        BarcodeScannerDialog(
            onDismiss = { viewModel.closeScanner() },
            onBarcodeScanned = { barcode ->
                viewModel.onBarcodeScanned(barcode)
            },
            suggestedCodes = suggestedList
        )
    }
}
