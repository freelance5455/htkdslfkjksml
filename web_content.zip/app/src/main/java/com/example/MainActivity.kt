package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(AndroidColor.parseColor("#040B14")),
      navigationBarStyle = SystemBarStyle.dark(AndroidColor.parseColor("#040B14"))
    )

    setContent {
      MyApplicationTheme {
        val context = LocalContext.current
        val lifecycleOwner = LocalLifecycleOwner.current
        var webViewRef by remember { mutableStateOf<WebView?>(null) }

        DisposableEffect(lifecycleOwner, webViewRef) {
          val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
              webViewRef?.evaluateJavascript("if (window.onAppPause) window.onAppPause();", null)
              webViewRef?.onPause()
            } else if (event == Lifecycle.Event.ON_RESUME) {
              webViewRef?.onResume()
            }
          }
          lifecycleOwner.lifecycle.addObserver(observer)
          onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
          }
        }

        BackHandler {
          val webView = webViewRef
          if (webView != null) {
            webView.evaluateJavascript(
              "(function(){ return window.handleAndroidBack ? window.handleAndroidBack() : false; })()"
            ) { result ->
              if (result != "true") {
                finish()
              }
            }
          } else {
            finish()
          }
        }

        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF040B14))
            .windowInsetsPadding(WindowInsets.systemBars)
        ) {
          AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
              createGameWebView(ctx).also { webViewRef = it }
            }
          )
        }
      }
    }
  }

  @SuppressLint("SetJavaScriptEnabled")
  private fun createGameWebView(context: Context): WebView {
    return WebView(context).apply {
      setBackgroundColor(AndroidColor.parseColor("#040B14"))
      isVerticalScrollBarEnabled = false
      isHorizontalScrollBarEnabled = false
      overScrollMode = WebView.OVER_SCROLL_NEVER

      settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        allowFileAccess = true
        useWideViewPort = true
        loadWithOverviewMode = true
        mediaPlaybackRequiresUserGesture = false
        setSupportZoom(false)
        builtInZoomControls = false
        displayZoomControls = false
        cacheMode = WebSettings.LOAD_DEFAULT
      }

      webViewClient = WebViewClient()
      webChromeClient = WebChromeClient()
      addJavascriptInterface(AndroidBridge(context), "AndroidBridge")
      loadUrl("file:///android_asset/index.html")
    }
  }

  private class AndroidBridge(private val context: Context) {
    @JavascriptInterface
    fun vibrate(durationMs: Long) {
      val duration = durationMs.coerceIn(5L, 250L)
      val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
      } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
      } ?: return

      if (!vibrator.hasVibrator()) return
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(duration)
      }
    }

    @JavascriptInterface
    fun shareScore(text: String) {
      val sendIntent = Intent(Intent.ACTION_SEND).apply {
        putExtra(Intent.EXTRA_TEXT, text)
        type = "text/plain"
      }
      val chooser = Intent.createChooser(sendIntent, "Share Flappy Droid Score").apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      context.startActivity(chooser)
    }
  }
}
