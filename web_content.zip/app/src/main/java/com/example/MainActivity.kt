package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VoiceScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusVioletLight

enum class AppScreen(
    val title: String,
    val activeIcon: ImageVector,
    val inactiveIcon: ImageVector
) {
    VOICE("Голос", Icons.Filled.GraphicEq, Icons.Outlined.GraphicEq),
    CHAT("Чат", Icons.Filled.Chat, Icons.Outlined.Chat),
    HISTORY("История", Icons.Filled.History, Icons.Outlined.History),
    SETTINGS("Настройки", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.util.configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NexusApp()
            }
        }
    }
}

@Composable
fun NexusApp(viewModel: MainViewModel = viewModel()) {
    var currentScreen by remember { mutableStateOf(AppScreen.VOICE) }

    // Intercept back button to return to Voice screen if on sub-screen
    BackHandler(enabled = currentScreen != AppScreen.VOICE) {
        currentScreen = AppScreen.VOICE
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = NexusBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            Column(modifier = Modifier.background(NexusSurface)) {
                HorizontalDivider(thickness = 1.dp, color = NexusBorder)
                NavigationBar(
                    containerColor = NexusSurface,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("main_navigation_bar")
                ) {
                    AppScreen.values().forEach { screen ->
                        val isSelected = currentScreen == screen
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentScreen = screen },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) screen.activeIcon else screen.inactiveIcon,
                                    contentDescription = screen.title
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NexusVioletLight,
                                selectedTextColor = NexusVioletLight,
                                indicatorColor = NexusCyanDark,
                                unselectedIconColor = NexusTextTertiary,
                                unselectedTextColor = NexusTextTertiary
                            ),
                            modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        val screenModifier = Modifier.padding(innerPadding)
        when (currentScreen) {
            AppScreen.VOICE -> VoiceScreen(
                viewModel = viewModel,
                onNavigateToChat = { currentScreen = AppScreen.CHAT },
                modifier = screenModifier
            )
            AppScreen.CHAT -> ChatScreen(
                viewModel = viewModel,
                modifier = screenModifier
            )
            AppScreen.HISTORY -> HistoryScreen(
                viewModel = viewModel,
                onSessionSelected = { currentScreen = AppScreen.CHAT },
                modifier = screenModifier
            )
            AppScreen.SETTINGS -> SettingsScreen(
                viewModel = viewModel,
                modifier = screenModifier
            )
        }
    }
}
