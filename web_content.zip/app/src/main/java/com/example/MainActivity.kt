package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.ai.BookAiService
import com.example.data.repository.BookRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutUser
import com.example.ui.screens.AiBookCreatorScreen
import com.example.ui.screens.BookDetailReaderScreen
import com.example.ui.screens.HomeLibraryScreen
import com.example.ui.screens.ManualBookCreatorScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BookStudioViewModel
import com.example.ui.viewmodel.StudioDestination
import com.example.util.configureAppCheck
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // MANDATORY: Configure App Check with launch intent before any UI, ViewModels, or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AppNavigation()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        configureAppCheck(this, intent)
    }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(
            onAuthSuccess = { /* AuthStateListener automatically transitions to MainFeatureScreen */ }
        )
    } else {
        MainFeatureScreen(currentUserId = user.uid)
    }
}

@Composable
fun MainFeatureScreen(currentUserId: String) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val studioViewModel: BookStudioViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                BookStudioViewModel(
                    repository = BookRepository(db),
                    aiService = BookAiService(),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val destination by studioViewModel.currentDestination.collectAsStateWithLifecycle()
    val booksState by studioViewModel.booksState.collectAsStateWithLifecycle()
    val selectedFilter by studioViewModel.libraryFilter.collectAsStateWithLifecycle()
    val searchQuery by studioViewModel.searchQuery.collectAsStateWithLifecycle()
    val aiCreationState by studioViewModel.aiCreationState.collectAsStateWithLifecycle()
    val activeBook by studioViewModel.activeBookState.collectAsStateWithLifecycle()
    val activeChaptersState by studioViewModel.activeChaptersState.collectAsStateWithLifecycle()
    val operationMessage by studioViewModel.operationMessage.collectAsStateWithLifecycle()
    val isSavingManual by studioViewModel.isSavingManual.collectAsStateWithLifecycle()
    val isGeneratingChapterAi by studioViewModel.isGeneratingChapterAi.collectAsStateWithLifecycle()

    Crossfade(targetState = destination, label = "studio_navigation") { screen ->
        when (screen) {
            StudioDestination.HOME_LIBRARY -> {
                HomeLibraryScreen(
                    booksState = booksState,
                    selectedFilter = selectedFilter,
                    searchQuery = searchQuery,
                    operationMessage = operationMessage,
                    onSelectAiCreate = { studioViewModel.navigateToAiCreator() },
                    onSelectManualCreate = { studioViewModel.navigateToManualCreator() },
                    onOpenBook = { bookId -> studioViewModel.openBookReader(bookId) },
                    onFilterChange = { filter -> studioViewModel.setLibraryFilter(filter) },
                    onSearchChange = { query -> studioViewModel.setSearchQuery(query) },
                    onClearMessage = { studioViewModel.clearOperationMessage() },
                    onSignOut = {
                        signOutUser(
                            context = context,
                            credentialManager = credentialManager,
                            onSignOutComplete = {},
                            scope = coroutineScope
                        )
                    }
                )
            }

            StudioDestination.CREATE_WITH_AI -> {
                AiBookCreatorScreen(
                    aiCreationState = aiCreationState,
                    onGenerateBook = { topic, genre, tone, chapterCount, coverTheme ->
                        studioViewModel.createBookWithAi(
                            topic = topic,
                            genre = genre,
                            tone = tone,
                            chapterCount = chapterCount,
                            coverTheme = coverTheme
                        )
                    },
                    onBack = { studioViewModel.navigateHome() }
                )
            }

            StudioDestination.CREATE_MANUALLY -> {
                ManualBookCreatorScreen(
                    isSaving = isSavingManual,
                    onSaveManualBook = { title, subtitle, synopsis, genre, tone, coverTheme, chapters, onValidationError ->
                        studioViewModel.createManualBook(
                            title = title,
                            subtitle = subtitle,
                            synopsis = synopsis,
                            genre = genre,
                            tone = tone,
                            coverTheme = coverTheme,
                            chapters = chapters,
                            onValidationError = onValidationError
                        )
                    },
                    onBack = { studioViewModel.navigateHome() }
                )
            }

            StudioDestination.BOOK_READER -> {
                BookDetailReaderScreen(
                    book = activeBook,
                    chaptersState = activeChaptersState,
                    isGeneratingAiChapter = isGeneratingChapterAi,
                    operationMessage = operationMessage,
                    onAddManualChapter = { book, nextNum, title, summary, content, onComplete ->
                        studioViewModel.addManualChapter(
                            book = book,
                            nextChapterNumber = nextNum,
                            title = title,
                            summary = summary,
                            content = content,
                            onComplete = onComplete
                        )
                    },
                    onAddAiChapter = { book, nextNum, directionPrompt, onComplete ->
                        studioViewModel.generateAndAddAiChapter(
                            book = book,
                            nextChapterNumber = nextNum,
                            directionPrompt = directionPrompt,
                            onComplete = onComplete
                        )
                    },
                    onExpandChapterWithAi = { book, chapter, totalChapters ->
                        studioViewModel.expandExistingChapterWithAi(
                            book = book,
                            chapter = chapter,
                            totalChapters = totalChapters
                        )
                    },
                    onUpdateChapter = { book, chapter, newTitle, newSummary, newContent, onComplete ->
                        studioViewModel.updateExistingChapter(
                            book = book,
                            chapter = chapter,
                            newTitle = newTitle,
                            newSummary = newSummary,
                            newContent = newContent,
                            onComplete = onComplete
                        )
                    },
                    onDeleteBook = { bookId, chapterIds ->
                        studioViewModel.deleteBook(bookId, chapterIds)
                    },
                    onClearMessage = { studioViewModel.clearOperationMessage() },
                    onBack = { studioViewModel.navigateHome() }
                )
            }
        }
    }
}
