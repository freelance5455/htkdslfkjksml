package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.DopingBottomNavigation
import com.example.ui.components.DopingTopBar
import com.example.ui.screens.ErrorNotebookScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LecturesScreen
import com.example.ui.screens.PomodoroScreen
import com.example.ui.screens.QuestionBankScreen
import com.example.ui.screens.QuizScreen
import com.example.ui.screens.StorageSettingsScreen
import com.example.ui.screens.StudyPlanScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.DopingViewModel
import com.example.ui.viewmodel.ScreenTab

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        DopingHafizaApp()
      }
    }
  }
}

@Composable
fun DopingHafizaApp(
  viewModel: DopingViewModel = viewModel()
) {
  val userProgress by viewModel.userProgress.collectAsStateWithLifecycle()
  val tasks by viewModel.tasks.collectAsStateWithLifecycle()
  val topics by viewModel.topics.collectAsStateWithLifecycle()
  val questions by viewModel.questions.collectAsStateWithLifecycle()
  val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
  val selectedTopic by viewModel.selectedTopic.collectAsStateWithLifecycle()
  val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
  val selectedSubjectFilter by viewModel.selectedSubjectFilter.collectAsStateWithLifecycle()
  val quizState by viewModel.quizState.collectAsStateWithLifecycle()
  val pomodoroState by viewModel.pomodoroState.collectAsStateWithLifecycle()
  val subjectProgress by viewModel.subjectProgress.collectAsStateWithLifecycle()
  val storageBreakdown by viewModel.storageBreakdown.collectAsStateWithLifecycle()
  val selectedCalendarDate by viewModel.selectedCalendarDate.collectAsStateWithLifecycle()

  // Handle system back navigation to return to Home if on another screen
  if (currentScreen != ScreenTab.HOME) {
    BackHandler {
      if (currentScreen == ScreenTab.LECTURES && selectedTopic != null) {
        viewModel.selectTopic(null)
      } else if (currentScreen == ScreenTab.QUIZ) {
        viewModel.navigateTo(ScreenTab.QUESTION_BANK)
      } else {
        viewModel.navigateTo(ScreenTab.HOME)
      }
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    topBar = {
      DopingTopBar(
        selectedExam = userProgress.selectedExam,
        streakDays = userProgress.streakDays,
        onExamSelected = { viewModel.setExam(it) }
      )
    },
    bottomBar = {
      DopingBottomNavigation(
        currentTab = currentScreen,
        onTabSelected = { viewModel.navigateTo(it) }
      )
    }
  ) { innerPadding ->
    val modifier = Modifier.padding(innerPadding)

    when (currentScreen) {
      ScreenTab.HOME -> {
        HomeScreen(
          userProgress = userProgress,
          tasks = tasks,
          topics = topics,
          coachingTips = viewModel.coachingTips,
          badges = viewModel.badges,
          dailyTrend = viewModel.dailyTrend,
          onNavigate = { viewModel.navigateTo(it) },
          onTopicSelected = {
            viewModel.selectTopic(it)
            viewModel.navigateTo(ScreenTab.LECTURES)
          },
          onToggleTask = { viewModel.toggleTask(it) },
          onStartQuizForSubject = {
            viewModel.selectSubjectFilter(it)
            viewModel.navigateTo(ScreenTab.QUESTION_BANK)
          },
          modifier = modifier
        )
      }

      ScreenTab.COACH_PLAN -> {
        StudyPlanScreen(
          tasks = tasks,
          userProgress = userProgress,
          coachingTips = viewModel.coachingTips,
          selectedCalendarDate = selectedCalendarDate,
          onSelectCalendarDate = { viewModel.selectCalendarDate(it) },
          onToggleTask = { viewModel.toggleTask(it) },
          onToggleReminder = { viewModel.toggleReminder(it) },
          onAddTask = { title, subject, questionsTarget, minutes, priority, date, reminderTime, hasReminder, notes ->
            viewModel.addTask(title, subject, questionsTarget, minutes, priority, date, reminderTime, hasReminder, notes)
          },
          onDeleteTask = { viewModel.deleteTask(it) },
          onGenerateSmartCoachPlan = { hours ->
            viewModel.generateSmartCoachPlan(hours)
          },
          modifier = modifier
        )
      }

      ScreenTab.QUESTION_BANK -> {
        QuestionBankScreen(
          testCategories = viewModel.testCategories,
          subjectProgress = subjectProgress,
          onStartTestCategory = { viewModel.startQuizForTestCategory(it) },
          onStartSubjectQuiz = { viewModel.startQuizForSubject(it) },
          modifier = modifier
        )
      }

      ScreenTab.LECTURES -> {
        LecturesScreen(
          topics = topics,
          selectedTopic = selectedTopic,
          searchQuery = searchQuery,
          selectedSubject = selectedSubjectFilter,
          onTopicSelected = { viewModel.selectTopic(it) },
          onSearchQueryChanged = { viewModel.updateSearchQuery(it) },
          onSubjectFilterChanged = { viewModel.selectSubjectFilter(it) },
          onToggleComplete = { viewModel.toggleTopicComplete(it) },
          onToggleFavorite = { viewModel.toggleTopicFavorite(it) },
          onStartQuizForTopic = { viewModel.startQuizForTopic(it) },
          modifier = modifier
        )
      }

      ScreenTab.QUIZ -> {
        val currentQ = quizState.questions.getOrNull(quizState.currentIndex)
        val isSavedInErrorNotebook = currentQ != null && userProgress.errorNotebookQuestionIds.contains(currentQ.id)

        QuizScreen(
          quizState = quizState,
          onSelectAnswer = { viewModel.selectAnswer(it) },
          onToggleEliminate = { viewModel.toggleEliminateOption(it) },
          onToggleSolution = { viewModel.toggleSolutionVisibility() },
          onNextQuestion = { viewModel.nextQuestion() },
          onPreviousQuestion = { viewModel.previousQuestion() },
          onGoToQuestion = { viewModel.goToQuestion(it) },
          onFinishQuiz = { viewModel.finishQuiz() },
          onRestartQuiz = { viewModel.restartQuiz() },
          onToggleErrorNotebook = { viewModel.toggleErrorNotebookForCurrentQuestion() },
          isSavedInErrorNotebook = isSavedInErrorNotebook,
          modifier = modifier
        )
      }

      ScreenTab.ERROR_NOTEBOOK -> {
        val errorQuestions = questions.filter { userProgress.errorNotebookQuestionIds.contains(it.id) }

        ErrorNotebookScreen(
          errorQuestions = errorQuestions,
          onStartErrorQuiz = { viewModel.startErrorNotebookQuiz() },
          onRemoveFromErrorNotebook = { viewModel.toggleQuestionInErrorNotebook(it) },
          modifier = modifier
        )
      }

      ScreenTab.POMODORO -> {
        PomodoroScreen(
          pomodoroState = pomodoroState,
          onToggleTimer = { viewModel.togglePomodoro() },
          onResetTimer = { viewModel.resetPomodoro() },
          onSwitchMode = { viewModel.switchPomodoroMode(it) },
          modifier = modifier
        )
      }

      ScreenTab.SETTINGS_STORAGE -> {
        StorageSettingsScreen(
          storageBreakdown = storageBreakdown,
          onToggleOfflineDownload = { viewModel.toggleOfflineDownload() },
          onClearCache = { viewModel.clearCache() },
          modifier = modifier
        )
      }
    }
  }
}
