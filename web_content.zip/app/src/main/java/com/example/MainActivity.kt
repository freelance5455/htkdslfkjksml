package com.example

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {
  private var filePathCallback: ValueCallback<Array<Uri>>? = null

  private val fileChooserLauncher = registerForActivityResult(
    ActivityResultContracts.StartActivityForResult()
  ) { result ->
    val results: Array<Uri>? = if (result.resultCode == Activity.RESULT_OK) {
      val data = result.data
      val clipData = data?.clipData
      if (clipData != null) {
        val uris = Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
        uris
      } else {
        val dataUri = data?.data
        if (dataUri != null) arrayOf(dataUri) else null
      }
    } else {
      null
    }
    filePathCallback?.onReceiveValue(results)
    filePathCallback = null
  }

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
          TapToPlayWebView(
            onOpenFileChooser = { callback, params ->
              filePathCallback?.onReceiveValue(null)
              filePathCallback = callback
              try {
                val acceptTypes = params?.acceptTypes?.filter { !it.isNullOrBlank() }
                val isVideo = acceptTypes?.any { it.contains("video", ignoreCase = true) } == true
                val isImage = acceptTypes?.any { it.contains("image", ignoreCase = true) } == true

                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                  addCategory(Intent.CATEGORY_OPENABLE)
                  if (isVideo && !isImage) {
                    type = "video/*"
                    putExtra(
                      Intent.EXTRA_MIME_TYPES,
                      arrayOf("video/*", "video/mp4", "video/webm", "video/quicktime", "video/3gpp", "video/x-matroska")
                    )
                  } else if (isImage && !isVideo) {
                    type = "image/*"
                    putExtra(
                      Intent.EXTRA_MIME_TYPES,
                      arrayOf("image/*", "image/jpeg", "image/png", "image/webp")
                    )
                  } else {
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
                  }
                }
                val chooserTitle = if (isVideo) "Select Video" else "Select Media"
                val chooserIntent = Intent.createChooser(intent, chooserTitle)
                fileChooserLauncher.launch(chooserIntent)
                true
              } catch (e: Exception) {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = null
                false
              }
            }
          )
        }
      }
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TapToPlayWebView(
  onOpenFileChooser: (ValueCallback<Array<Uri>>, WebChromeClient.FileChooserParams?) -> Boolean
) {
  var webViewInstance: WebView? = null

  BackHandler(enabled = true) {
    if (webViewInstance?.canGoBack() == true) {
      webViewInstance?.goBack()
    }
  }

  AndroidView(
    modifier = Modifier.fillMaxSize(),
    factory = { context ->
      WebView(context).apply {
        webViewInstance = this
        settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = true
          databaseEnabled = true
          allowFileAccess = true
          allowContentAccess = true
          allowFileAccessFromFileURLs = true
          allowUniversalAccessFromFileURLs = true
          mediaPlaybackRequiresUserGesture = false
          cacheMode = WebSettings.LOAD_DEFAULT
          useWideViewPort = true
          loadWithOverviewMode = true
        }
        webChromeClient = object : WebChromeClient() {
          override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
          ): Boolean {
            if (filePathCallback != null) {
              return onOpenFileChooser(filePathCallback, fileChooserParams)
            }
            return false
          }
        }
        webViewClient = object : WebViewClient() {}
        loadUrl("file:///android_asset/index.html")
      }
    }
  )
}
