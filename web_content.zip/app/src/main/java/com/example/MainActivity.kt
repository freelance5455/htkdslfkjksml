package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.auth.AuthScreen
import com.example.auth.SignUpDraft
import com.example.auth.signOutUser
import com.example.model.DeliveryZone
import com.example.model.OrderItem
import com.example.model.Product
import com.example.ui.screens.AccountAndAdminScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.CheckoutSheet
import com.example.ui.screens.MarketScreen
import com.example.ui.screens.OrderSuccessDialog
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.WishlistScreen
import com.example.ui.theme.NovaBazarTheme
import com.example.viewmodel.NovaBazarViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

private data class NavTabItem(
    val titleRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val mainTabs = listOf(
    NavTabItem(R.string.nav_market, Icons.Filled.Storefront, Icons.Outlined.Storefront, "nav_tab_market"),
    NavTabItem(R.string.nav_wishlist, Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder, "nav_tab_wishlist"),
    NavTabItem(R.string.nav_cart, Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart, "nav_tab_cart"),
    NavTabItem(R.string.nav_orders, Icons.AutoMirrored.Filled.ReceiptLong, Icons.AutoMirrored.Outlined.ReceiptLong, "nav_tab_orders"),
    NavTabItem(R.string.nav_account, Icons.Filled.Person, Icons.Outlined.Person, "nav_tab_account")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NovaBazarTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    var pendingSignUpDraft by remember { mutableStateOf<SignUpDraft?>(null) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    if (user == null) {
        AuthScreen(
            onAuthSuccess = { draft ->
                pendingSignUpDraft = draft
                currentUser = Firebase.auth.currentUser
            }
        )
    } else {
        key(user.uid) {
            NovaBazarMainShell(
                currentUserId = user.uid,
                userDisplayName = user.displayName ?: "NOVA BAZAR User",
                userEmail = user.email ?: "",
                pendingSignUpDraft = pendingSignUpDraft,
                onConsumeSignUpDraft = { pendingSignUpDraft = null }
            )
        }
    }
}

@Composable
private fun NovaBazarMainShell(
    currentUserId: String,
    userDisplayName: String,
    userEmail: String,
    pendingSignUpDraft: SignUpDraft?,
    onConsumeSignUpDraft: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val viewModel: NovaBazarViewModel = viewModel(
        key = currentUserId,
        factory = NovaBazarViewModel.provideFactory(currentUserId)
    )

    val filteredProductsState by viewModel.filteredProductsState.collectAsStateWithLifecycle()
    val allProductsState by viewModel.productsState.collectAsStateWithLifecycle()
    val ordersState by viewModel.ordersState.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val wishlistIds by viewModel.wishlistIds.collectAsStateWithLifecycle()
    val shopSettings by viewModel.shopSettings.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val filterState by viewModel.filterState.collectAsStateWithLifecycle()
    val selectedZone by viewModel.selectedDeliveryZone.collectAsStateWithLifecycle()
    val isAdminUnlocked by viewModel.isAdminUnlocked.collectAsStateWithLifecycle()
    val isMutating by viewModel.isMutating.collectAsStateWithLifecycle()
    val cartBadgeCount by viewModel.cartBadgeCount.collectAsStateWithLifecycle()

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }

    // Direct Buy Now state
    var directBuyProduct by remember { mutableStateOf<Pair<Product, Long>?>(null) }
    var directOrderNumber by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pendingSignUpDraft) {
        pendingSignUpDraft?.let { draft ->
            viewModel.saveUserProfile(
                fullName = draft.fullName,
                phone = draft.phone,
                defaultAddress = draft.defaultAddress,
                preferredZone = draft.preferredZone
            )
            onConsumeSignUpDraft()
        }
    }

    LaunchedEffect(Unit) {
        viewModel.toastEvents.collect { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    if (selectedTab != 0) {
        BackHandler { selectedTab = 0 }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar {
                        mainTabs.forEachIndexed { index, tab ->
                            NavigationBarItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = {
                                    NavTabIcon(
                                        tab = tab,
                                        selected = selectedTab == index,
                                        cartBadgeCount = if (index == 2) cartBadgeCount else 0,
                                        wishlistCount = if (index == 1) wishlistIds.size else 0
                                    )
                                },
                                label = { Text(stringResource(tab.titleRes), maxLines = 1) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail {
                        mainTabs.forEachIndexed { index, tab ->
                            NavigationRailItem(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                icon = {
                                    NavTabIcon(
                                        tab = tab,
                                        selected = selectedTab == index,
                                        cartBadgeCount = if (index == 2) cartBadgeCount else 0,
                                        wishlistCount = if (index == 1) wishlistIds.size else 0
                                    )
                                },
                                label = { Text(stringResource(tab.titleRes)) },
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    when (selectedTab) {
                        0 -> MarketScreen(
                            productsState = filteredProductsState,
                            allProductsState = allProductsState,
                            categories = categories,
                            filterState = filterState,
                            wishlistIds = wishlistIds,
                            cartCount = cartBadgeCount,
                            shopSettings = shopSettings,
                            onSearchChange = viewModel::updateSearchQuery,
                            onSelectCategory = viewModel::selectCategory,
                            onSortChange = viewModel::updateSortOption,
                            onToggleDiscountOnly = viewModel::toggleDiscountOnly,
                            onToggleWishlist = viewModel::toggleWishlist,
                            onAddToCart = viewModel::addToCart,
                            onBuyNow = { product, qty ->
                                directBuyProduct = product to qty
                            },
                            onOpenCart = { selectedTab = 2 }
                        )

                        1 -> WishlistScreen(
                            productsState = allProductsState,
                            wishlistIds = wishlistIds,
                            onToggleWishlist = viewModel::toggleWishlist,
                            onAddToCart = { viewModel.addToCart(it, 1L) },
                            onBrowseMarket = { selectedTab = 0 }
                        )

                        2 -> CartScreen(
                            cartItems = cartItems,
                            productsState = allProductsState,
                            selectedZone = selectedZone,
                            shopSettings = shopSettings,
                            isMutating = isMutating,
                            defaultCustomerName = userProfile.fullName.ifBlank { userDisplayName },
                            defaultPhone = userProfile.phone,
                            defaultAddress = userProfile.defaultAddress,
                            onSelectZone = viewModel::selectDeliveryZone,
                            onUpdateQty = viewModel::updateCartQuantity,
                            onBrowseMarket = { selectedTab = 0 },
                            onPlaceOrder = viewModel::placeOrder,
                            onGoToOrders = { selectedTab = 3 }
                        )

                        3 -> OrdersScreen(
                            ordersState = ordersState,
                            onReorder = { order ->
                                viewModel.reorderItems(order)
                                selectedTab = 2
                            },
                            onBrowseMarket = { selectedTab = 0 }
                        )

                        else -> AccountAndAdminScreen(
                            userDisplayName = userDisplayName,
                            userEmail = userEmail,
                            productsState = allProductsState,
                            ordersState = ordersState,
                            shopSettings = shopSettings,
                            isAdminUnlocked = isAdminUnlocked,
                            isMutating = isMutating,
                            onUnlockAdmin = viewModel::unlockAdmin,
                            onLockAdmin = viewModel::lockAdmin,
                            onSaveProduct = viewModel::saveProduct,
                            onDeleteProduct = viewModel::deleteProduct,
                            onUpdateOrderStatus = viewModel::updateOrderStatus,
                            onUpdateShopSettings = viewModel::updateShopSettings,
                            onSignOut = {
                                signOutUser(
                                    credentialManager = credentialManager,
                                    scope = scope
                                )
                            }
                        )
                    }
                }
            }
        }
    }

    // Direct Buy Now Sheet
    directBuyProduct?.let { (product, qty) ->
        BackHandler { directBuyProduct = null }
        val fee = if (selectedZone == com.example.model.DeliveryZone.DHAKA_CITY) {
            shopSettings.dhakaDeliveryFee
        } else {
            shopSettings.outsideDeliveryFee
        }
        val orderItems = listOf(
            OrderItem(
                productId = product.id,
                name = product.name,
                price = product.price,
                qty = qty,
                emoji = product.emoji
            )
        )
        CheckoutSheet(
            items = orderItems,
            selectedZone = selectedZone,
            deliveryFee = fee,
            defaultName = userProfile.fullName.ifBlank { userDisplayName },
            defaultPhone = userProfile.phone,
            defaultAddress = userProfile.defaultAddress,
            isMutating = isMutating,
            onSelectZone = viewModel::selectDeliveryZone,
            onDismiss = { directBuyProduct = null },
            onConfirmOrder = { name, phone, address, note ->
                viewModel.placeOrder(
                    customerName = name,
                    phone = phone,
                    address = address,
                    note = note,
                    items = orderItems,
                    clearCartAfterOrder = false
                ) { orderNo ->
                    directBuyProduct = null
                    directOrderNumber = orderNo
                }
            }
        )
    }

    directOrderNumber?.let { orderNo ->
        OrderSuccessDialog(
            orderNumber = orderNo,
            onDismiss = { directOrderNumber = null },
            onViewOrders = {
                directOrderNumber = null
                selectedTab = 3
            }
        )
    }
}

@Composable
private fun NavTabIcon(
    tab: NavTabItem,
    selected: Boolean,
    cartBadgeCount: Int,
    wishlistCount: Int
) {
    val icon = if (selected) tab.selectedIcon else tab.unselectedIcon
    val badgeValue = when {
        cartBadgeCount > 0 -> cartBadgeCount
        wishlistCount > 0 -> wishlistCount
        else -> 0
    }
    if (badgeValue > 0) {
        BadgedBox(
            badge = {
                Badge(
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = MaterialTheme.colorScheme.onError
                ) {
                    Text("$badgeValue")
                }
            }
        ) {
            Icon(imageVector = icon, contentDescription = stringResource(tab.titleRes))
        }
    } else {
        Icon(imageVector = icon, contentDescription = stringResource(tab.titleRes))
    }
}
