package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.chess.ChessPiece
import com.example.chess.PieceColor
import com.example.chess.PieceType
import com.example.chess.Square
import com.example.firebase.configureAppCheck
import com.example.pdf.SampleChessPdfGenerator
import com.example.ui.AppSection
import com.example.ui.BoardToolsBottomSheet
import com.example.ui.DiagramReviewModal
import com.example.ui.DockedAnalysisSheet
import com.example.ui.GameImportScreen
import com.example.ui.LibraryScreen
import com.example.ui.MoonChessTopBar
import com.example.ui.MoonChessViewModel
import com.example.ui.NotesScreen
import com.example.ui.PdfReaderContent
import com.example.ui.PmsStudyModal
import com.example.ui.PrinciplesScreen
import com.example.ui.ProjectZipExporterDialog
import com.example.ui.theme.MoonChessTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            MoonChessTheme {
                MoonChessRootApp()
            }
        }
    }
}

@Composable
fun MoonChessRootApp(
    vm: MoonChessViewModel = viewModel()
) {
    val context = LocalContext.current

    val activeSection by vm.activeSection.collectAsStateWithLifecycle()
    val books by vm.books.collectAsStateWithLifecycle()
    val activeBook by vm.activeBook.collectAsStateWithLifecycle()
    val pdfController by vm.pdfController.collectAsStateWithLifecycle()
    val currentPage by vm.currentPage.collectAsStateWithLifecycle()
    val zoomScale by vm.zoomScale.collectAsStateWithLifecycle()

    val isSearchOpen by vm.isSearchOpen.collectAsStateWithLifecycle()
    val searchQuery by vm.searchQuery.collectAsStateWithLifecycle()
    val searchMatches by vm.searchMatches.collectAsStateWithLifecycle()
    val currentMatchIndex by vm.currentMatchIndex.collectAsStateWithLifecycle()
    val isSearchingPdf by vm.isSearchingPdf.collectAsStateWithLifecycle()
    val pageAnnotationsMap by vm.pageAnnotationsMap.collectAsStateWithLifecycle()

    val boardSizePercent by vm.boardSizePercent.collectAsStateWithLifecycle()
    val boardState by vm.boardState.collectAsStateWithLifecycle()
    val boardTheme by vm.boardTheme.collectAsStateWithLifecycle()
    val isEngineEnabled by vm.isEngineEnabled.collectAsStateWithLifecycle()
    val engineChoice by vm.engineChoice.collectAsStateWithLifecycle()
    val engineDepth by vm.engineDepth.collectAsStateWithLifecycle()
    val engineEval by vm.engineEval.collectAsStateWithLifecycle()

    val activeSensor by vm.activeSensor.collectAsStateWithLifecycle()
    val batchScanState by vm.batchScanState.collectAsStateWithLifecycle()
    val catalogDiagrams by vm.catalogDiagrams.collectAsStateWithLifecycle()
    val templateCoverage by vm.activeBookTemplateCoverage.collectAsStateWithLifecycle()

    val notes by vm.notes.collectAsStateWithLifecycle()
    val principles by vm.principles.collectAsStateWithLifecycle()
    val pmsPositions by vm.pmsPositions.collectAsStateWithLifecycle()
    val importedGames by vm.importedGames.collectAsStateWithLifecycle()
    val isFetchingOnlineGames by vm.isFetchingOnlineGames.collectAsStateWithLifecycle()

    val toastMessage by vm.toastMessage.collectAsStateWithLifecycle()
    val openExternalUrl by vm.openExternalUrl.collectAsStateWithLifecycle()

    var showPmsStudyModal by remember { mutableStateOf(false) }
    var showBoardToolsSheet by remember { mutableStateOf(false) }
    var showDiagramReviewModal by remember { mutableStateOf(false) }
    var showExportZipDialog by remember { mutableStateOf(false) }

    // Handle external URL launches (Stockfish 19 & Lichess FEN transfer)
    LaunchedEffect(openExternalUrl) {
        val url = openExternalUrl ?: return@LaunchedEffect
        vm.consumeExternalUrl()
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }

    // Auto-dismiss status banner
    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(2800)
            vm.clearToast()
        }
    }

    val isDockedBoardOpen = boardSizePercent >= 6f

    fun playUciMoveString(uci: String) {
        if (uci.length < 4) return
        val from = Square.fromAlgebraic(uci.substring(0, 2)) ?: return
        val to = Square.fromAlgebraic(uci.substring(2, 4)) ?: return
        val promo = if (uci.length >= 5) PieceType.fromChar(uci[4]) else null
        vm.makeMove(from, to, promo)
    }

    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Screenshot-Matched Top Bar + Upper Heading Section Switcher
            MoonChessTopBar(
                activeSection = activeSection,
                activeBook = activeBook,
                currentPage = currentPage,
                isDockedBoardOpen = isDockedBoardOpen,
                onBackClick = {
                    when (activeSection) {
                        AppSection.READER -> vm.navigateBackToLibrary()
                        AppSection.LIBRARY -> {
                            if (activeBook != null) vm.selectSection(AppSection.READER)
                        }
                        else -> {
                            vm.selectSection(if (activeBook != null) AppSection.READER else AppSection.LIBRARY)
                        }
                    }
                },
                onSelectSection = { sec -> vm.selectSection(sec) },
                onCycleSplitBoard = { vm.cycleQuickSplitSize() },
                onJumpToPage = { page -> vm.jumpToPage(page) },
                onToggleSearch = { vm.toggleSearchBar() },
                onZoomOut = { vm.adjustZoom(-0.2f) },
                onZoomIn = { vm.adjustZoom(+0.2f) },
                onOpenExportZipDialog = { showExportZipDialog = true }
            )

            // 2. Main Split Workspace (Reader / Study Hub + Draggable Docked Analysis Sheet)
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                val isLandscape = maxWidth > maxHeight && maxWidth >= 600.dp
                val totalHeightPx = with(density) { maxHeight.toPx() }.coerceAtLeast(1f)
                val totalWidthPx = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)

                val clampedPercent = boardSizePercent.coerceIn(0f, 75f)

                @Composable
                fun PrimarySectionPane(paneModifier: Modifier) {
                    when (activeSection) {
                        AppSection.READER -> {
                            val book = activeBook
                            val ctrl = pdfController
                            if (book != null && ctrl != null) {
                                PdfReaderContent(
                                    book = book,
                                    controller = ctrl,
                                    currentPage = currentPage,
                                    zoomScale = zoomScale,
                                    isSearchOpen = isSearchOpen,
                                    searchQuery = searchQuery,
                                    searchMatches = searchMatches,
                                    currentMatchIndex = currentMatchIndex,
                                    isSearchingPdf = isSearchingPdf,
                                    pageAnnotationsMap = pageAnnotationsMap,
                                    activeSensor = activeSensor,
                                    onPageVisible = { vm.onPageVisible(it) },
                                    onRunSearch = { vm.runPdfSearch(it) },
                                    onStepSearchMatch = { vm.stepSearchMatch(it) },
                                    onCloseSearch = { vm.toggleSearchBar(false) },
                                    onOpenSensorAt = { page, nx, ny -> vm.openDiagramSensorOnPage(page, nx, ny) },
                                    onUpdateSensorBox = { nx, ny, nw, nh, rescan ->
                                        vm.updateSensorBox(nx, ny, nw, nh, rescan)
                                    },
                                    onToggleSensorTurn = { vm.toggleSensorTurn() },
                                    onLoadSensorDiagram = { vm.confirmAndLoadSensorDiagram() },
                                    onOpenDiagramReviewModal = { showDiagramReviewModal = true },
                                    onTriggerGeminiScan = { vm.triggerGeminiCloudScanOnSensor() },
                                    onCloseSensor = { vm.closeSensor() },
                                    onAddPageStroke = { p, s -> vm.addPageStroke(p, s) },
                                    onUndoPageStroke = { p -> vm.undoLastPageStroke(p) },
                                    onClearPageStrokes = { p -> vm.clearPageStrokes(p) },
                                    modifier = paneModifier
                                )
                            } else {
                                LibraryScreen(
                                    books = books,
                                    onImportPdfUri = { vm.importPdfFromUri(it) },
                                    onGenerateSampleBook = { vm.generateAndOpenSampleBook(it) },
                                    onOpenBook = { vm.openBook(it) },
                                    onDeleteBook = { vm.deleteBook(it) },
                                    onNavigateSection = { vm.selectSection(it) },
                                    onOpenExportZipDialog = { showExportZipDialog = true },
                                    modifier = paneModifier
                                )
                            }
                        }

                        AppSection.LIBRARY -> {
                            LibraryScreen(
                                books = books,
                                onImportPdfUri = { vm.importPdfFromUri(it) },
                                onGenerateSampleBook = { vm.generateAndOpenSampleBook(it) },
                                onOpenBook = { vm.openBook(it) },
                                onDeleteBook = { vm.deleteBook(it) },
                                onNavigateSection = { vm.selectSection(it) },
                                onOpenExportZipDialog = { showExportZipDialog = true },
                                modifier = paneModifier
                            )
                        }

                        AppSection.NOTES -> {
                            NotesScreen(
                                notes = notes,
                                currentBoardFen = boardState.fen,
                                onSaveNote = { id, title, content, tags, attachFen, existingFen, pinned ->
                                    vm.saveStudyNote(id, title, content, tags, attachFen, existingFen, pinned)
                                },
                                onTogglePin = { vm.togglePinNote(it) },
                                onDeleteNote = { vm.deleteStudyNote(it) },
                                onLoadFenOnBoard = { fen, title -> vm.loadFenOntoBoard(fen, title) },
                                onBack = {
                                    vm.selectSection(if (activeBook != null) AppSection.READER else AppSection.LIBRARY)
                                },
                                modifier = paneModifier
                            )
                        }

                        AppSection.PRINCIPLES -> {
                            PrinciplesScreen(
                                principles = principles,
                                currentBoardFen = boardState.fen,
                                onSavePrinciple = { id, phase, title, desc, attachFen, existingFen ->
                                    vm.savePrinciple(id, phase, title, desc, attachFen, existingFen)
                                },
                                onDeletePrinciple = { vm.deletePrinciple(it) },
                                onLoadFenOnBoard = { fen, title -> vm.loadFenOntoBoard(fen, title) },
                                onBack = {
                                    vm.selectSection(if (activeBook != null) AppSection.READER else AppSection.LIBRARY)
                                },
                                modifier = paneModifier
                            )
                        }

                        AppSection.GAMES -> {
                            GameImportScreen(
                                importedGames = importedGames,
                                isFetchingOnline = isFetchingOnlineGames,
                                onFetchLichess = { vm.fetchLichessGames(it) },
                                onFetchChessCom = { vm.fetchChessComGames(it) },
                                onImportRawPgn = { vm.importPgnToBoard(it, saveToGamesHub = true) },
                                onOpenGameOnBoard = { vm.openImportedGameOnBoard(it) },
                                onDeleteGame = { vm.deleteImportedGame(it) },
                                onBack = {
                                    vm.selectSection(if (activeBook != null) AppSection.READER else AppSection.LIBRARY)
                                },
                                modifier = paneModifier
                            )
                        }
                    }
                }

                if (isLandscape) {
                    val boardWidthDp = maxWidth * (clampedPercent / 100f)
                    val contentWidthDp = maxWidth - boardWidthDp
                    Row(modifier = Modifier.fillMaxSize()) {
                        PrimarySectionPane(
                            Modifier
                                .width(contentWidthDp)
                                .fillMaxHeight()
                        )
                        if (isDockedBoardOpen) {
                            DockedAnalysisSheet(
                                boardState = boardState,
                                boardTheme = boardTheme,
                                isEngineEnabled = isEngineEnabled,
                                engineChoice = engineChoice,
                                engineDepth = engineDepth,
                                engineEval = engineEval,
                                isCollapsed = false,
                                isLandscape = true,
                                onDragDeltaPx = { dx, isEnd ->
                                    val nextPct = boardSizePercent - (dx / totalWidthPx) * 100f
                                    vm.updateBoardDragPercent(nextPct, isLandscape = true, persistNow = isEnd)
                                },
                                onToggleKingCollapse = { vm.toggleKingDockedBoard() },
                                onOpenPmsStudyModal = { showPmsStudyModal = true },
                                onOpenBoardMenuSheet = { showBoardToolsSheet = true },
                                onMove = { f, t, p -> vm.makeMove(f, t, p) },
                                onPlayPvFirstMove = { playUciMoveString(it) },
                                onSetEngineEnabled = { vm.setEngineEnabled(it) },
                                onSelectEngine = { vm.selectEngineChoice(it) },
                                onIncrementDepth = { vm.incrementEngineDepth() },
                                onUpdateMoveComment = { vm.updateCurrentMoveComment(it) },
                                onGoStart = { vm.goStart() },
                                onGoPrev = { vm.goPrev() },
                                onGoNext = { vm.goNext() },
                                onGoEnd = { vm.goEnd() },
                                onFlipBoard = { vm.flipBoard() },
                                modifier = Modifier
                                    .width(boardWidthDp)
                                    .fillMaxHeight()
                            )
                        }
                    }
                } else {
                    val boardHeightDp = maxHeight * (clampedPercent / 100f)
                    val contentHeightDp = maxHeight - boardHeightDp
                    Column(modifier = Modifier.fillMaxSize()) {
                        PrimarySectionPane(
                            Modifier
                                .fillMaxWidth()
                                .height(contentHeightDp)
                        )
                        if (isDockedBoardOpen) {
                            DockedAnalysisSheet(
                                boardState = boardState,
                                boardTheme = boardTheme,
                                isEngineEnabled = isEngineEnabled,
                                engineChoice = engineChoice,
                                engineDepth = engineDepth,
                                engineEval = engineEval,
                                isCollapsed = false,
                                isLandscape = false,
                                onDragDeltaPx = { dy, isEnd ->
                                    val nextPct = boardSizePercent - (dy / totalHeightPx) * 100f
                                    vm.updateBoardDragPercent(nextPct, isLandscape = false, persistNow = isEnd)
                                },
                                onToggleKingCollapse = { vm.toggleKingDockedBoard() },
                                onOpenPmsStudyModal = { showPmsStudyModal = true },
                                onOpenBoardMenuSheet = { showBoardToolsSheet = true },
                                onMove = { f, t, p -> vm.makeMove(f, t, p) },
                                onPlayPvFirstMove = { playUciMoveString(it) },
                                onSetEngineEnabled = { vm.setEngineEnabled(it) },
                                onSelectEngine = { vm.selectEngineChoice(it) },
                                onIncrementDepth = { vm.incrementEngineDepth() },
                                onUpdateMoveComment = { vm.updateCurrentMoveComment(it) },
                                onGoStart = { vm.goStart() },
                                onGoPrev = { vm.goPrev() },
                                onGoNext = { vm.goNext() },
                                onGoEnd = { vm.goEnd() },
                                onFlipBoard = { vm.flipBoard() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(boardHeightDp)
                            )
                        }
                    }
                }

                // Floating White King Restore Button when docked board is collapsed/hidden (0%)
                if (!isDockedBoardOpen) {
                    Surface(
                        color = Color.White,
                        shape = CircleShape,
                        shadowElevation = 8.dp,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .navigationBarsPadding()
                            .padding(16.dp)
                            .size(50.dp)
                            .clickable { vm.toggleKingDockedBoard() }
                            .testTag("restore_docked_board_fab")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Canvas(modifier = Modifier.size(34.dp)) {
                                drawIntoCanvas { c ->
                                    SampleChessPdfGenerator.drawStauntonPieceOnCanvas(
                                        canvas = c.nativeCanvas,
                                        piece = ChessPiece(PieceColor.WHITE, PieceType.KING),
                                        left = 0f,
                                        top = 0f,
                                        cellSize = size.width
                                    )
                                }
                            }
                        }
                    }
                }

                // Subtle Status / Toast Notification Pill
                toastMessage?.let { msg ->
                    Surface(
                        color = Color(0xFF18181B).copy(alpha = 0.92f),
                        shape = RoundedCornerShape(20.dp),
                        shadowElevation = 6.dp,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 10.dp, start = 16.dp, end = 16.dp)
                    ) {
                        Text(
                            text = msg,
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }

    // Modals & Bottom Sheets
    if (showPmsStudyModal) {
        PmsStudyModal(
            currentFen = boardState.fen,
            savedPositions = pmsPositions,
            onSaveCurrent = { title, note -> vm.saveCurrentPositionToPms(title, note) },
            onLoadFen = { fen, title -> vm.loadFenOntoBoard(fen, title) },
            onDeletePosition = { vm.deletePmsPosition(it) },
            onResetStart = { vm.resetBoardToStart() },
            onDismiss = { showPmsStudyModal = false }
        )
    }

    if (showBoardToolsSheet) {
        BoardToolsBottomSheet(
            boardState = boardState,
            currentTheme = boardTheme,
            catalogDiagrams = catalogDiagrams,
            templateCoverage = templateCoverage,
            batchScanState = batchScanState,
            onSelectNode = { vm.selectMoveNode(it) },
            onPromoteVariation = { vm.promoteNodeVariation(it) },
            onDeleteBranch = { vm.deleteMoveBranch(it) },
            onUpdateMoveComment = { vm.updateCurrentMoveComment(it) },
            onToggleNag = { vm.toggleCurrentMoveNag(it) },
            onImportPgn = { pgn, save -> vm.importPgnToBoard(pgn, save) },
            onExportPgn = { vm.exportCurrentPgn() },
            onSelectTheme = { vm.selectBoardTheme(it) },
            onLoadDiagramFromCatalog = { diag -> vm.loadFenOntoBoard(diag.fen, diag.title) },
            onJumpToPage = { p ->
                vm.jumpToPage(p)
                vm.selectSection(AppSection.READER)
            },
            onStartBatchScan = { vm.startBatchCatalogScan() },
            onPauseResumeBatchScan = { vm.togglePauseBatchScan() },
            onCancelBatchScan = { vm.cancelBatchScan() },
            onOpenExportZipDialog = { showExportZipDialog = true },
            onDismiss = { showBoardToolsSheet = false }
        )
    }

    if (showDiagramReviewModal && activeSensor?.lastResult != null) {
        activeSensor?.let { sensor ->
            DiagramReviewModal(
                sensorState = sensor,
                onConfirmAndLearn = { editedGrid ->
                    showDiagramReviewModal = false
                    vm.confirmAndLoadSensorDiagram(editedGrid = editedGrid, learnTemplates = true)
                },
                onDismiss = { showDiagramReviewModal = false }
            )
        }
    }

    if (showExportZipDialog) {
        ProjectZipExporterDialog(
            onDismiss = { showExportZipDialog = false },
            onExportStatus = { /* status displayed in dialog */ }
        )
    }
}
