package com.example

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.MyApplicationTheme
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class MainActivity : ComponentActivity() {

    companion object {
        init {
            try {
                android.system.Os.setenv("MESA_LOG_FILE", "/dev/null", true)
                android.system.Os.setenv("MESA_DEBUG", "0", true)
            } catch (e: Throwable) {
                // Ignore if environment cannot be modified
            }
        }
    }

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var webViewInstance: WebView? = null
    private var pendingPermissionRequest: PermissionRequest? = null

    // File picker launcher for custom PNG frame uploads
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (fileUploadCallback == null) return@registerForActivityResult
        val results: Array<Uri>? = when {
            result.resultCode == RESULT_OK && result.data != null -> {
                val clipData = result.data?.clipData
                val dataUri = result.data?.data
                when {
                    clipData != null -> {
                        (0 until clipData.itemCount).map { clipData.getItemAt(it).uri }.toTypedArray()
                    }
                    dataUri != null -> {
                        arrayOf(dataUri)
                    }
                    else -> null
                }
            }
            else -> null
        }
        fileUploadCallback?.onReceiveValue(results)
        fileUploadCallback = null
    }

    // Dynamic runtime permissions launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: hasCameraPermission()
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: hasAudioPermission()

        if (cameraGranted) {
            Log.d("FrameCamera", "Camera permission granted by user")
            pendingPermissionRequest?.let { req ->
                try {
                    val resourcesToGrant = mutableListOf<String>()
                    if (req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && cameraGranted) {
                        resourcesToGrant.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    }
                    if (req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && audioGranted) {
                        resourcesToGrant.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    }
                    if (resourcesToGrant.isNotEmpty()) {
                        req.grant(resourcesToGrant.toTypedArray())
                    } else {
                        req.deny()
                    }
                } catch (e: Exception) {
                    Log.e("FrameCamera", "Error granting permission request", e)
                }
                pendingPermissionRequest = null
            }
            webViewInstance?.evaluateJavascript(
                "if(typeof onCameraPermissionResult === 'function') onCameraPermissionResult(true);",
                null
            )
        } else {
            Log.w("FrameCamera", "Camera permission denied by user")
            pendingPermissionRequest?.deny()
            pendingPermissionRequest = null
            webViewInstance?.evaluateJavascript(
                "if(typeof onCameraPermissionResult === 'function') onCameraPermissionResult(false);",
                null
            )
            Toast.makeText(
                this,
                "Izin kamera diperlukan untuk mengambil foto & video",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Keep screen on while using camera
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Request runtime permissions dynamically on app launch
        checkAndRequestPermissions()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = webViewInstance
                if (wv != null && wv.canGoBack()) {
                    wv.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        setContent {
            MyApplicationTheme {
                CameraWebViewScreen(
                    onWebViewCreated = { wv ->
                        webViewInstance = wv
                    },
                    onRequestPermissions = {
                        checkAndRequestPermissions()
                    },
                    onSaveMedia = { base64Data, filename, mimeType ->
                        saveMediaToStorage(base64Data, filename, mimeType)
                    },
                    onOpenGallery = {
                        openDeviceGallery()
                    },
                    onOpenFileChooser = { callback, intent ->
                        fileUploadCallback?.onReceiveValue(null)
                        fileUploadCallback = callback
                        try {
                            fileChooserLauncher.launch(intent)
                        } catch (e: Exception) {
                            fileUploadCallback?.onReceiveValue(null)
                            fileUploadCallback = null
                        }
                    }
                )
            }
        }
    }

    fun setPendingPermissionRequest(request: PermissionRequest) {
        pendingPermissionRequest = request
    }

    fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            permissionsToRequest.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

        val missing = permissionsToRequest.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        } else {
            // Already granted
            webViewInstance?.evaluateJavascript(
                "if(typeof onCameraPermissionResult === 'function') onCameraPermissionResult(true);",
                null
            )
        }
    }

    private fun saveMediaToStorage(base64Data: String, filename: String, mimeType: String) {
        try {
            val bytes = Base64.decode(base64Data, Base64.DEFAULT)
            val isVideo = mimeType.startsWith("video")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val collection = if (isVideo) {
                    MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                } else {
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                }

                val relativeLocation = if (isVideo) {
                    Environment.DIRECTORY_MOVIES + "/FrameCamera"
                } else {
                    Environment.DIRECTORY_PICTURES + "/FrameCamera"
                }

                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativeLocation)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val uri = contentResolver.insert(collection, contentValues)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { stream: OutputStream ->
                        stream.write(bytes)
                        stream.flush()
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    contentResolver.update(uri, contentValues, null, null)

                    runOnUiThread {
                        val typeText = if (isVideo) "Video" else "Foto"
                        Toast.makeText(this, "$typeText berhasil tersimpan di Galeri!", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                // Fallback for Android 9 and lower
                val directory = if (isVideo) {
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                } else {
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                }
                val subDir = File(directory, "FrameCamera")
                if (!subDir.exists()) subDir.mkdirs()

                val file = File(subDir, filename)
                FileOutputStream(file).use { out ->
                    out.write(bytes)
                    out.flush()
                }

                MediaScannerConnection.scanFile(
                    this,
                    arrayOf(file.absolutePath),
                    arrayOf(mimeType),
                    null
                )

                runOnUiThread {
                    val typeText = if (isVideo) "Video" else "Foto"
                    Toast.makeText(this, "$typeText tersimpan di Galeri!", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Log.e("FrameCamera", "Error saving media", e)
            runOnUiThread {
                Toast.makeText(this, "Gagal menyimpan: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openDeviceGallery() {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_GALLERY)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent)
            } catch (err: Exception) {
                Toast.makeText(this, "Silakan buka aplikasi Galeri atau Foto di perangkat Anda", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        webViewInstance?.onResume()
    }

    override fun onPause() {
        super.onPause()
        webViewInstance?.onPause()
    }

    override fun onDestroy() {
        webViewInstance?.destroy()
        super.onDestroy()
    }
}

class AndroidBridge(
    private val activity: MainActivity,
    private val onRequestPermissions: () -> Unit,
    private val onSaveMedia: (String, String, String) -> Unit,
    private val onOpenGallery: () -> Unit
) {
    @JavascriptInterface
    fun hasCameraPermission(): Boolean {
        return activity.hasCameraPermission()
    }

    @JavascriptInterface
    fun hasAudioPermission(): Boolean {
        return activity.hasAudioPermission()
    }

    @JavascriptInterface
    fun requestPermissions() {
        activity.runOnUiThread {
            onRequestPermissions()
        }
    }

    @JavascriptInterface
    fun saveMedia(base64Data: String, filename: String, mimeType: String) {
        onSaveMedia(base64Data, filename, mimeType)
    }

    @JavascriptInterface
    fun openDeviceGallery() {
        activity.runOnUiThread {
            onOpenGallery()
        }
    }

    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun CameraWebViewScreen(
    onWebViewCreated: (WebView) -> Unit,
    onRequestPermissions: () -> Unit,
    onSaveMedia: (String, String, String) -> Unit,
    onOpenGallery: () -> Unit,
    onOpenFileChooser: (ValueCallback<Array<Uri>>, Intent) -> Unit
) {
    val context = LocalContext.current
    val activity = context as MainActivity

    AndroidView(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        factory = { ctx ->
            WebView(ctx).apply {
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(android.graphics.Color.BLACK)

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    allowFileAccess = true
                    allowContentAccess = true
                    mediaPlaybackRequiresUserGesture = false
                    databaseEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    builtInZoomControls = false
                    displayZoomControls = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    cacheMode = WebSettings.LOAD_DEFAULT
                }

                // Inject JavaScript interface
                addJavascriptInterface(
                    AndroidBridge(
                        activity = activity,
                        onRequestPermissions = onRequestPermissions,
                        onSaveMedia = onSaveMedia,
                        onOpenGallery = onOpenGallery
                    ),
                    "AndroidBridge"
                )

                webChromeClient = object : WebChromeClient() {
                    override fun onPermissionRequest(request: PermissionRequest) {
                        activity.runOnUiThread {
                            val hasCamera = activity.hasCameraPermission()
                            val hasAudio = activity.hasAudioPermission()

                            val needsCamera = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                            val needsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)

                            val cameraOk = !needsCamera || hasCamera
                            val audioOk = !needsAudio || hasAudio

                            if (cameraOk && audioOk) {
                                request.grant(request.resources)
                            } else {
                                // Defer granting until Android OS permission dialog completes
                                activity.setPendingPermissionRequest(request)
                                activity.checkAndRequestPermissions()
                            }
                        }
                    }

                    override fun onShowFileChooser(
                        webView: WebView?,
                        filePathCallback: ValueCallback<Array<Uri>>?,
                        fileChooserParams: FileChooserParams?
                    ): Boolean {
                        if (filePathCallback == null) return false
                        val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                            type = "image/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        }
                        onOpenFileChooser(filePathCallback, intent)
                        return true
                    }

                    override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
                        Log.d("FrameCameraJS", "${consoleMessage?.message()} [line ${consoleMessage?.lineNumber()}]")
                        return true
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                        return false
                    }
                }

                loadUrl("file:///android_asset/index.html")
                onWebViewCreated(this)
            }
        }
    )
}
