package com.example

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.ui.theme.ForestDark
import com.example.ui.theme.KavoshHouseTheme
import com.example.ui.theme.MutedSage
import com.example.ui.theme.SageGreen
import com.example.ui.theme.WarmCream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream

private const val GAME_HOST = "kavosh.local"
private const val GAME_URL = "https://$GAME_HOST/kavosh_house.html"

class MainActivity : ComponentActivity() {

  private var webViewRef: WebView? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    configureImmersiveLandscapeWindow()

    setContent {
      KavoshHouseTheme {
        KavoshGameContainer(
          onWebViewReady = { webView -> webViewRef = webView },
          onExitGame = { finish() },
        )
      }
    }
  }

  override fun onResume() {
    super.onResume()
    configureImmersiveLandscapeWindow()
    webViewRef?.onResume()
    webViewRef?.evaluateJavascript("window.__kavoshOnResume && window.__kavoshOnResume()", null)
  }

  override fun onPause() {
    webViewRef?.evaluateJavascript("window.__kavoshOnPause && window.__kavoshOnPause()", null)
    webViewRef?.onPause()
    super.onPause()
  }

  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    if (hasFocus) {
      configureImmersiveLandscapeWindow()
    }
  }

  private fun configureImmersiveLandscapeWindow() {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
      window.attributes =
        window.attributes.apply {
          layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }
    val controller = WindowCompat.getInsetsController(window, window.decorView)
    controller.systemBarsBehavior =
      WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    controller.hide(WindowInsetsCompat.Type.systemBars())
  }
}

@Composable
private fun KavoshGameContainer(
  onWebViewReady: (WebView) -> Unit,
  onExitGame: () -> Unit,
) {
  var isEngineReady by remember { mutableStateOf(false) }
  var webViewInstance by remember { mutableStateOf<WebView?>(null) }

  BackHandler {
    val wv = webViewInstance
    if (wv == null) {
      onExitGame()
    } else {
      wv.evaluateJavascript("window.__kavoshBack ? window.__kavoshBack() : false") { result ->
        if (result != "true") {
          onExitGame()
        }
      }
    }
  }

  DisposableEffect(Unit) {
    onDispose {
      webViewInstance?.apply {
        stopLoading()
        removeJavascriptInterface("AndroidBridge")
        destroy()
      }
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(ForestDark)
  ) {
    AndroidView(
      modifier = Modifier
        .fillMaxSize()
        .testTag("kavosh_game_viewport"),
      factory = { context ->
        createConfiguredWebView(
          context = context,
          onReady = { isEngineReady = true },
        ).also { wv ->
          webViewInstance = wv
          onWebViewReady(wv)
        }
      },
    )

    AnimatedVisibility(
      visible = !isEngineReady,
      exit = fadeOut(animationSpec = tween(durationMillis = 450)),
    ) {
      LoadingVeil()
    }
  }
}

@Composable
private fun LoadingVeil() {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(ForestDark)
      .testTag("loading_veil"),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Text(
        text = "KĀVOSH",
        color = SageGreen,
        fontSize = 14.sp,
        letterSpacing = 4.sp,
        fontWeight = FontWeight.Medium,
      )
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "خانهٔ آرام",
        style = MaterialTheme.typography.headlineMedium,
        color = WarmCream,
      )
      Spacer(modifier = Modifier.height(16.dp))
      CircularProgressIndicator(
        modifier = Modifier.size(28.dp),
        color = SageGreen,
        strokeWidth = 2.5.dp,
      )
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = "در حال آماده‌سازی فضای سه‌بعدی…",
        style = MaterialTheme.typography.bodySmall,
        color = MutedSage,
      )
    }
  }
}

@SuppressLint("SetJavaScriptEnabled")
private fun createConfiguredWebView(
  context: Context,
  onReady: () -> Unit,
): WebView {
  val webView = WebView(context).apply {
    layoutParams = ViewGroup.LayoutParams(
      ViewGroup.LayoutParams.MATCH_PARENT,
      ViewGroup.LayoutParams.MATCH_PARENT,
    )
    setBackgroundColor(Color.parseColor("#19241E"))
    setLayerType(View.LAYER_TYPE_HARDWARE, null)
    isHorizontalScrollBarEnabled = false
    isVerticalScrollBarEnabled = false
    overScrollMode = View.OVER_SCROLL_NEVER
    isFocusable = true
    isFocusableInTouchMode = true

    settings.apply {
      javaScriptEnabled = true
      domStorageEnabled = true
      mediaPlaybackRequiresUserGesture = false
      useWideViewPort = true
      loadWithOverviewMode = true
      setSupportZoom(false)
      builtInZoomControls = false
      displayZoomControls = false
      allowFileAccess = false
      allowContentAccess = false
      cacheMode = WebSettings.LOAD_DEFAULT
    }
  }

  val pushSafeInsets: (WindowInsetsCompat) -> Unit = { insets ->
    val cutout = insets.getInsets(WindowInsetsCompat.Type.displayCutout())
    val density = context.resources.displayMetrics.density.coerceAtLeast(1f)
    val topDp = (cutout.top / density).toInt()
    val rightDp = (cutout.right / density).toInt()
    val bottomDp = (cutout.bottom / density).toInt()
    val leftDp = (cutout.left / density).toInt()
    webView.post {
      webView.evaluateJavascript(
        "window.__setSafeInsets && window.__setSafeInsets($topDp,$rightDp,$bottomDp,$leftDp)",
        null,
      )
    }
  }

  ViewCompat.setOnApplyWindowInsetsListener(webView) { _, insets ->
    pushSafeInsets(insets)
    insets
  }

  webView.webChromeClient = WebChromeClient()

  webView.webViewClient = object : WebViewClient() {
    override fun shouldInterceptRequest(
      view: WebView?,
      request: WebResourceRequest?,
    ): WebResourceResponse? {
      val uri = request?.url ?: return null
      if (uri.host == GAME_HOST && uri.path == "/kavosh_house.html") {
        return try {
          val bytes = context.assets.open("kavosh_house.html").use { it.readBytes() }
          WebResourceResponse(
            "text/html",
            "UTF-8",
            200,
            "OK",
            mapOf("Cache-Control" to "no-cache"),
            ByteArrayInputStream(bytes),
          )
        } catch (_: Exception) {
          null
        }
      }
      return null
    }

    override fun onPageFinished(view: WebView?, url: String?) {
      super.onPageFinished(view, url)
      ViewCompat.getRootWindowInsets(webView)?.let(pushSafeInsets)
    }
  }

  webView.addJavascriptInterface(
    KavoshAndroidBridge(context = context, webView = webView, onReady = onReady),
    "AndroidBridge",
  )

  webView.loadUrl(GAME_URL)
  return webView
}

private class KavoshAndroidBridge(
  private val context: Context,
  private val webView: WebView,
  private val onReady: () -> Unit,
) {

  @JavascriptInterface
  fun onReady() {
    webView.post { onReady.invoke() }
  }

  @JavascriptInterface
  fun hapticFeedback(kind: String?) {
    webView.post {
      val constant = when (kind) {
        "success" ->
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            HapticFeedbackConstants.CONFIRM
          } else {
            HapticFeedbackConstants.LONG_PRESS
          }
        else -> HapticFeedbackConstants.KEYBOARD_TAP
      }
      webView.performHapticFeedback(constant)
    }
  }

  @JavascriptInterface
  fun savePhoto(dataUrl: String, filename: String): Boolean {
    return try {
      val base64Part = dataUrl.substringAfter("base64,", "")
      if (base64Part.isEmpty()) return false
      val pngBytes = Base64.decode(base64Part, Base64.DEFAULT)
      val safeName = filename.replace(Regex("[^a-zA-Z0-9._-]"), "_")

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
          put(MediaStore.Images.Media.DISPLAY_NAME, safeName)
          put(MediaStore.Images.Media.MIME_TYPE, "image/png")
          put(
            MediaStore.Images.Media.RELATIVE_PATH,
            "${Environment.DIRECTORY_PICTURES}/Kavosh",
          )
          put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
          ?: return false
        resolver.openOutputStream(uri)?.use { out ->
          out.write(pngBytes)
        } ?: return false
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        true
      } else {
        val dir = File(
          context.getExternalFilesDir(Environment.DIRECTORY_PICTURES),
          "Kavosh",
        ).apply { mkdirs() }
        val file = File(dir, safeName)
        FileOutputStream(file).use { it.write(pngBytes) }
        true
      }
    } catch (_: Exception) {
      false
    }
  }
}
