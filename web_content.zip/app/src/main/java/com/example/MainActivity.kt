package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.AssistantMode
import com.example.data.model.AttachmentType
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.PendingAttachment
import com.example.data.repository.NovaFirestoreRepository
import com.example.service.NovaWakeWordForegroundService
import com.example.ui.NovaViewModel
import androidx.compose.foundation.verticalScroll
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutUser
import com.example.ui.components.AccountAndMemorySheet
import com.example.ui.components.ChatMessageRow
import com.example.ui.components.IntroductionSheet
import com.example.ui.components.PhoneAssistantSheet
import com.example.ui.components.RichMarkdownContent
import com.example.ui.components.VoiceAssistantSheet
import com.example.ui.theme.NovaAITheme
import com.example.ui.theme.NovaDeepViolet
import com.example.ui.theme.NovaElectricBlue
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

import com.example.ui.auth.NovaSessionManager
import com.example.ui.auth.SavedUserSession
import com.google.firebase.FirebaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            FirebaseApp.initializeApp(this)
        } catch (_: Exception) {
        }
        enableEdgeToEdge()
        setContent {
            NovaAppRoot()
        }
    }
}

@Composable
fun NovaAppRoot() {
    val context = LocalContext.current
    val auth = remember {
        try {
            FirebaseApp.initializeApp(context)
            FirebaseAuth.getInstance()
        } catch (_: Exception) {
            null
        }
    }
    var activeSession by remember { mutableStateOf(NovaSessionManager.getActiveSession(context)) }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val fbUser = firebaseAuth.currentUser
            if (fbUser != null) {
                val updated = SavedUserSession(
                    uid = fbUser.uid,
                    email = fbUser.email ?: "Signed in with Google",
                    displayName = fbUser.displayName ?: "AURA AI User"
                )
                NovaSessionManager.saveSession(context, updated)
                activeSession = updated
            } else {
                activeSession = NovaSessionManager.getActiveSession(context)
            }
        }
        auth?.addAuthStateListener(listener)
        onDispose {
            auth?.removeAuthStateListener(listener)
        }
    }

    val session = activeSession
    if (session == null) {
        NovaAITheme(darkTheme = true) {
            AuthScreen(
                onAuthSuccess = { newSession ->
                    NovaSessionManager.saveSession(context, newSession)
                    activeSession = newSession
                }
            )
        }
    } else {
        val vm: NovaViewModel = viewModel(
            key = session.uid,
            factory = viewModelFactory {
                initializer {
                    val app = checkNotNull(this[APPLICATION_KEY])
                    val db = try {
                        FirebaseApp.initializeApp(app)
                        val databaseId = app.getString(R.string.firestore_database_id)
                        FirebaseFirestore.getInstance(databaseId)
                    } catch (_: Exception) {
                        null
                    }
                    val safeAuth = try {
                        FirebaseAuth.getInstance()
                    } catch (_: Exception) {
                        null
                    }
                    NovaViewModel(
                        appContext = app,
                        repository = NovaFirestoreRepository(db, safeAuth),
                        currentUserId = session.uid
                    )
                }
            }
        )
        val isDarkTheme by vm.isDarkTheme.collectAsStateWithLifecycle()
        NovaAITheme(darkTheme = isDarkTheme) {
            NovaMainWorkspace(
                viewModel = vm,
                userEmail = session.email,
                userDisplayName = session.displayName,
                onSignOutComplete = {
                    NovaSessionManager.clearSession(context)
                    activeSession = null
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NovaMainWorkspace(
    viewModel: NovaViewModel,
    userEmail: String?,
    userDisplayName: String?,
    onSignOutComplete: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val credentialManager = remember { CredentialManager.create(context) }

    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val activeConversationId by viewModel.activeConversationId.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val historySearchQuery by viewModel.historySearchQuery.collectAsStateWithLifecycle()

    val selectedMode by viewModel.selectedMode.collectAsStateWithLifecycle()
    val answerLength by viewModel.answerLength.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()
    val composerText by viewModel.composerText.collectAsStateWithLifecycle()
    val pendingAttachments by viewModel.pendingAttachments.collectAsStateWithLifecycle()
    val isUploadingAttachment by viewModel.isUploadingAttachment.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val streamingPartialText by viewModel.streamingPartialText.collectAsStateWithLifecycle()
    val uiBannerMessage by viewModel.uiBannerMessage.collectAsStateWithLifecycle()
    val pendingCallCandidates by viewModel.pendingCallCandidates.collectAsStateWithLifecycle()
    val deviceSnapshot by viewModel.deviceSnapshot.collectAsStateWithLifecycle()

    // Voice & Wake-Word States
    val isListening by viewModel.voiceManager.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsStateWithLifecycle()
    val partialTranscript by viewModel.voiceManager.partialTranscript.collectAsStateWithLifecycle()
    val voiceError by viewModel.voiceManager.voiceError.collectAsStateWithLifecycle()
    val selectedVoiceLang by viewModel.voiceManager.selectedLanguage.collectAsStateWithLifecycle()
    val speechRate by viewModel.voiceManager.speechRate.collectAsStateWithLifecycle()
    val wakePhrase by viewModel.wakePhrase.collectAsStateWithLifecycle()
    val isWakeServiceRunning by NovaWakeWordForegroundService.isRunning.collectAsStateWithLifecycle()
    val wakeServiceStatus by NovaWakeWordForegroundService.statusText.collectAsStateWithLifecycle()

    // Modals & Dialogs
    var showIntroductionSheet by remember { mutableStateOf(false) }
    var showVoiceSheet by remember { mutableStateOf(false) }
    var showPhoneSheet by remember { mutableStateOf(false) }
    var showAccountSheet by remember { mutableStateOf(false) }
    var messageToEdit by remember { mutableStateOf<ChatMessage?>(null) }
    var editedMessageText by remember { mutableStateOf("") }
    var conversationToRename by remember { mutableStateOf<Conversation?>(null) }
    var renameTitleInput by remember { mutableStateOf("") }

    // Media & Permission Launchers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(5)
    ) { uris ->
        uris.forEach { viewModel.attachFromUri(it) }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { viewModel.attachFromUri(it) }
    }

    val cameraPreviewLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            viewModel.attachCameraBitmap(bitmap)
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            cameraPreviewLauncher.launch(null)
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.voiceManager.startListening()
        }
    }

    val wakeServicePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val micOk = results[Manifest.permission.RECORD_AUDIO] == true
        if (micOk) {
            viewModel.toggleWakeWordService(true)
        }
    }

    val contactsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.refreshDeviceSnapshot()
    }

    val callPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val listState = rememberLazyListState()

    // Auto-scroll to bottom when new messages or streaming chunks arrive
    LaunchedEffect(messages.size, streamingPartialText) {
        val totalItems = messages.size + (if (isGenerating) 1 else 0)
        if (totalItems > 0) {
            listState.animateScrollToItem(totalItems - 1)
        }
    }

    // BackHandler returns to New Chat screen if inside an active conversation
    BackHandler(enabled = activeConversationId != null) {
        viewModel.startNewChat()
    }

    val filteredConversations = remember(conversations, historySearchQuery) {
        if (historySearchQuery.isBlank()) {
            conversations
        } else {
            val q = historySearchQuery.trim().lowercase()
            conversations.filter {
                it.title.lowercase().contains(q) || it.lastMessagePreview.lowercase().contains(q)
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(310.dp)
            ) {
                ConversationSidebarContent(
                    conversations = filteredConversations,
                    activeConversationId = activeConversationId,
                    searchQuery = historySearchQuery,
                    onSearchQueryChange = viewModel::updateHistorySearchQuery,
                    onOpenIntroduction = {
                        scope.launch { drawerState.close() }
                        showIntroductionSheet = true
                    },
                    onStartNewChat = {
                        viewModel.startNewChat()
                        scope.launch { drawerState.close() }
                    },
                    onSelectConversation = { id ->
                        viewModel.selectConversation(id)
                        scope.launch { drawerState.close() }
                    },
                    onRenameConversation = { conv ->
                        conversationToRename = conv
                        renameTitleInput = conv.title
                    },
                    onDeleteConversation = viewModel::deleteConversation
                )
            }
        }
    ) {
        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                NovaTopBar(
                    activeConversationTitle = conversations.firstOrNull { it.id == activeConversationId }?.title ?: "AURA AI",
                    isWakeWordActive = isWakeServiceRunning,
                    onOpenDrawer = { scope.launch { drawerState.open() } },
                    onStartNewChat = viewModel::startNewChat,
                    onOpenVoiceSheet = { showVoiceSheet = true },
                    onOpenPhoneSheet = {
                        viewModel.refreshDeviceSnapshot()
                        showPhoneSheet = true
                    },
                    onOpenAccountSheet = { showAccountSheet = true }
                )
            },
            bottomBar = {
                NovaMessageComposer(
                    text = composerText,
                    onTextChange = viewModel::updateComposerText,
                    selectedMode = selectedMode,
                    onSelectMode = viewModel::setAssistantMode,
                    pendingAttachments = pendingAttachments,
                    isUploadingAttachment = isUploadingAttachment,
                    isGenerating = isGenerating,
                    isListening = isListening,
                    onRemoveAttachment = viewModel::removePendingAttachment,
                    onPickImages = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickDocuments = {
                        documentPickerLauncher.launch(arrayOf("*/*"))
                    },
                    onLaunchCamera = {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    },
                    onToggleVoiceInput = {
                        if (isListening) {
                            viewModel.voiceManager.stopListening()
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onSend = { viewModel.sendMessage() },
                    onStopGeneration = viewModel::stopGeneration
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(innerPadding)
            ) {
                // Notification / Error Banner
                AnimatedVisibility(visible = !uiBannerMessage.isNullOrBlank()) {
                    Surface(
                        color = NovaDeepViolet.copy(alpha = 0.2f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = uiBannerMessage.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = viewModel::clearBannerMessage,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss notification", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                // Ambiguous Contact Disambiguation Banner
                AnimatedVisibility(visible = pendingCallCandidates.isNotEmpty()) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Select Contact to Call:",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = NovaElectricBlue
                                )
                                IconButton(
                                    onClick = viewModel::dismissPendingCallCandidates,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Close contact picker")
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            pendingCallCandidates.forEach { contact ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${contact.displayName} (${contact.phoneNumber})", style = MaterialTheme.typography.bodyMedium)
                                    Button(
                                        onClick = {
                                            viewModel.deviceController.openDialer(contact.phoneNumber)
                                            viewModel.dismissPendingCallCandidates()
                                        }
                                    ) {
                                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Dial")
                                    }
                                }
                            }
                        }
                    }
                }

                // Main Content Area: Sleek NOVA AI Dashboard OR Conversation Stream
                if (activeConversationId == null && messages.isEmpty() && !isGenerating) {
                    NovaCleanEmptyCanvas(
                        onActionCardClick = { actionType ->
                            when (actionType) {
                                WelcomeAction.ASK_ANYTHING -> {
                                    viewModel.setAssistantMode(AssistantMode.GENERAL)
                                    viewModel.sendMessage("Hello AURA! Explain quantum computing in simple Hinglish and English.")
                                }
                                WelcomeAction.ANALYZE_IMAGE -> {
                                    viewModel.setAssistantMode(AssistantMode.GENERAL)
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                WelcomeAction.UPLOAD_DOCUMENT -> {
                                    viewModel.setAssistantMode(AssistantMode.GENERAL)
                                    documentPickerLauncher.launch(arrayOf("*/*"))
                                }
                                WelcomeAction.WRITE_OR_IMPROVE -> {
                                    viewModel.setAssistantMode(AssistantMode.CREATIVE)
                                    viewModel.updateComposerText("Write a polished professional project proposal email for ")
                                }
                                WelcomeAction.HELP_CODING -> {
                                    viewModel.setAssistantMode(AssistantMode.CODING)
                                    viewModel.sendMessage("Write a clean Kotlin Coroutines + StateFlow example for Android Jetpack Compose with error handling.")
                                }
                                WelcomeAction.START_VOICE -> {
                                    showVoiceSheet = true
                                }
                                WelcomeAction.CHECK_PHONE_INFO -> {
                                    viewModel.refreshDeviceSnapshot()
                                    showPhoneSheet = true
                                }
                                WelcomeAction.RESEARCH_TOPIC -> {
                                    viewModel.setAssistantMode(AssistantMode.RESEARCH)
                                    viewModel.sendMessage("Research the latest advancements in solid-state batteries and summarize key pros, cons, and sources.")
                                }
                            }
                        }
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .testTag("chat_messages_list"),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        items(
                            items = messages,
                            key = { it.id.ifBlank { it.hashCode().toString() } }
                        ) { msg ->
                            ChatMessageRow(
                                message = msg,
                                onCopyText = { text ->
                                    clipboard.setText(AnnotatedString(text))
                                },
                                onEditUserMessage = { targetMsg ->
                                    messageToEdit = targetMsg
                                    editedMessageText = targetMsg.content
                                },
                                onRegenerateAiMessage = { targetMsg ->
                                    viewModel.regenerateAiResponse(targetMsg)
                                },
                                onSpeakMessage = { text ->
                                    viewModel.voiceManager.speak(text)
                                }
                            )
                        }

                        // Live Streaming AI Response (STRICTLY ON THE LEFT SIDE WITH SUBTLE SLIDE-IN)
                        if (isGenerating) {
                            item(key = "streaming_ai_indicator") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.Start,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(11.dp))
                                            .background(
                                                Brush.linearGradient(
                                                    colors = listOf(
                                                        NovaElectricBlue.copy(alpha = 0.25f),
                                                        NovaDeepViolet.copy(alpha = 0.38f)
                                                    )
                                                )
                                            )
                                            .border(1.2.dp, NovaElectricBlue, RoundedCornerShape(11.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            color = NovaElectricBlue,
                                            strokeWidth = 2.dp
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Surface(
                                        shape = RoundedCornerShape(
                                            topStart = 6.dp,
                                            topEnd = 20.dp,
                                            bottomEnd = 20.dp,
                                            bottomStart = 20.dp
                                        ),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                        modifier = Modifier
                                            .weight(1f)
                                            .border(
                                                width = 1.dp,
                                                color = NovaElectricBlue.copy(alpha = 0.4f),
                                                shape = RoundedCornerShape(
                                                    topStart = 6.dp,
                                                    topEnd = 20.dp,
                                                    bottomEnd = 20.dp,
                                                    bottomStart = 20.dp
                                                )
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                                            Text(
                                                text = "✦ AURA AI • Synthesizing...",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = NovaElectricBlue
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            if (streamingPartialText.isNotBlank()) {
                                                RichMarkdownContent(
                                                    markdown = streamingPartialText,
                                                    onCopyCode = { clipboard.setText(AnnotatedString(it)) }
                                                )
                                            } else {
                                                Text(
                                                    text = "Thinking...",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Edit & Resend User Message Dialog
    if (messageToEdit != null) {
        AlertDialog(
            onDismissRequest = { messageToEdit = null },
            title = { Text("Edit & Resend Message") },
            text = {
                OutlinedTextField(
                    value = editedMessageText,
                    onValueChange = { editedMessageText = it },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 6
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = messageToEdit
                        if (target != null && editedMessageText.isNotBlank()) {
                            viewModel.editAndResendUserMessage(target, editedMessageText)
                        }
                        messageToEdit = null
                    }
                ) {
                    Text("Save & Resend")
                }
            },
            dismissButton = {
                TextButton(onClick = { messageToEdit = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Rename Conversation Dialog
    if (conversationToRename != null) {
        AlertDialog(
            onDismissRequest = { conversationToRename = null },
            title = { Text("Rename Conversation") },
            text = {
                OutlinedTextField(
                    value = renameTitleInput,
                    onValueChange = { renameTitleInput = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val conv = conversationToRename
                        if (conv != null && renameTitleInput.isNotBlank()) {
                            viewModel.renameConversation(conv.id, renameTitleInput)
                        }
                        conversationToRename = null
                    }
                ) {
                    Text("Rename")
                }
            },
            dismissButton = {
                TextButton(onClick = { conversationToRename = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Introduction & Button Guide Sheet (Opened from Three-Line Menu)
    if (showIntroductionSheet) {
        IntroductionSheet(
            onDismiss = { showIntroductionSheet = false }
        )
    }

    // Modal Bottom Sheets
    if (showVoiceSheet) {
        VoiceAssistantSheet(
            isListening = isListening,
            isSpeaking = isSpeaking,
            partialTranscript = partialTranscript,
            voiceError = voiceError,
            selectedLanguage = selectedVoiceLang,
            speechRate = speechRate,
            isWakeServiceRunning = isWakeServiceRunning,
            wakeServiceStatus = wakeServiceStatus,
            wakePhrase = wakePhrase,
            onUpdateWakePhrase = viewModel::updateWakePhrase,
            onToggleListening = {
                if (isListening) {
                    viewModel.voiceManager.stopListening()
                } else {
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            },
            onStopSpeaking = { viewModel.voiceManager.stopSpeaking() },
            onSelectLanguage = { viewModel.voiceManager.setVoiceLanguage(it) },
            onChangeSpeechRate = { viewModel.voiceManager.setSpeakingSpeed(it) },
            onToggleWakeWordService = { enable ->
                if (enable) {
                    val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    wakeServicePermissionLauncher.launch(perms.toTypedArray())
                } else {
                    viewModel.toggleWakeWordService(false)
                }
            },
            onSendVoicePrompt = { prompt ->
                showVoiceSheet = false
                viewModel.setAutoSpeakResponses(true)
                viewModel.sendMessage(overridePrompt = prompt)
            },
            onDismiss = { showVoiceSheet = false }
        )
    }

    if (showPhoneSheet) {
        PhoneAssistantSheet(
            deviceController = viewModel.deviceController,
            deviceSnapshot = deviceSnapshot,
            onRefreshSnapshot = viewModel::refreshDeviceSnapshot,
            onRequestContactsPermission = {
                contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
            },
            onRequestCallPermission = {
                callPermissionLauncher.launch(Manifest.permission.CALL_PHONE)
            },
            onSendDeviceQuestionToChat = { question ->
                showPhoneSheet = false
                viewModel.sendMessage(overridePrompt = question)
            },
            onDismiss = { showPhoneSheet = false }
        )
    }

    if (showAccountSheet) {
        AccountAndMemorySheet(
            userEmail = userEmail,
            userDisplayName = userDisplayName,
            isDarkTheme = isDarkTheme,
            answerLength = answerLength,
            memories = memories,
            onToggleDarkTheme = viewModel::setDarkTheme,
            onSelectAnswerLength = viewModel::setAnswerLength,
            onAddMemory = viewModel::addMemory,
            onDeleteMemory = viewModel::deleteMemory,
            onClearAllMemories = viewModel::clearAllMemories,
            onClearAllConversations = viewModel::clearAllConversations,
            onSignOut = {
                showAccountSheet = false
                signOutUser(
                    context = context,
                    credentialManager = credentialManager,
                    onSignOutComplete = onSignOutComplete,
                    scope = scope
                )
            },
            onDismiss = { showAccountSheet = false }
        )
    }
}

@Composable
private fun NovaTopBar(
    activeConversationTitle: String,
    isWakeWordActive: Boolean,
    onOpenDrawer: () -> Unit,
    onStartNewChat: () -> Unit,
    onOpenVoiceSheet: () -> Unit,
    onOpenPhoneSheet: () -> Unit,
    onOpenAccountSheet: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
        tonalElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier.testTag("open_history_drawer_button")
                ) {
                    Icon(Icons.Default.Menu, contentDescription = "Open menu")
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = activeConversationTitle,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (isWakeWordActive) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(NovaElectricBlue)
                            )
                        }
                    }
                    if (isWakeWordActive) {
                        Text(
                            text = "Hands-Free 'Hello Aura' Active",
                            style = MaterialTheme.typography.bodySmall,
                            color = NovaElectricBlue,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Prominent New Chat Button
                IconButton(
                    onClick = onStartNewChat,
                    modifier = Modifier.testTag("new_chat_top_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Chat",
                        tint = NovaElectricBlue
                    )
                }
                // Voice Assistant Studio Button
                IconButton(
                    onClick = onOpenVoiceSheet,
                    modifier = Modifier.testTag("open_voice_studio_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Voice Assistant & Wake Word",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                // Phone Information & Actions Hub Button
                IconButton(
                    onClick = onOpenPhoneSheet,
                    modifier = Modifier.testTag("open_phone_hub_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = "Phone Information & Calling",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                // Account & Memory Settings Button
                IconButton(
                    onClick = onOpenAccountSheet,
                    modifier = Modifier.testTag("open_account_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Account & Memory Settings",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

private enum class WelcomeAction(
    val title: String,
    val subtitle: String,
    val icon: ImageVector
) {
    ASK_ANYTHING("Ask anything", "Hindi, Hinglish & English Q&A", Icons.Default.AutoAwesome),
    ANALYZE_IMAGE("Analyze an image", "Extract text, charts & photos", Icons.Default.Image),
    UPLOAD_DOCUMENT("Upload a document", "PDF, DOCX, CSV, JSON & Code", Icons.Default.Description),
    WRITE_OR_IMPROVE("Write or improve text", "Emails, essays & translations", Icons.Default.Edit),
    HELP_CODING("Help with coding", "Kotlin, Python, JS, SQL & debug", Icons.Default.Code),
    START_VOICE("Start a voice conversation", "Talk naturally + 'Hello Aura'", Icons.Default.Mic),
    CHECK_PHONE_INFO("Check phone information", "Battery, storage, Wi-Fi & calls", Icons.Default.PhoneAndroid),
    RESEARCH_TOPIC("Research a topic", "Grounded analysis & citations", Icons.Default.Public)
}

@Composable
private fun NovaCleanEmptyCanvas(
    onActionCardClick: (WelcomeAction) -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // AURA AI Next-Gen Holographic Prism Core Badge
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = NovaElectricBlue.copy(alpha = 0.12f),
                modifier = Modifier
                    .border(
                        width = 1.dp,
                        color = NovaElectricBlue.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(999.dp)
                    )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(NovaElectricBlue)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "AURA NEURAL CORE • ONLINE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = NovaElectricBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Box(
                modifier = Modifier
                    .size(78.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(NovaElectricBlue.copy(alpha = 0.28f), NovaDeepViolet.copy(alpha = 0.42f))
                        )
                    )
                    .border(1.8.dp, Brush.linearGradient(listOf(NovaElectricBlue, NovaDeepViolet)), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AURA AI",
                    tint = NovaElectricBlue,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "AURA AI",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = "Next-Gen Conversational AI & Android Personal Assistant",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))

            val actions = WelcomeAction.entries
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                actions.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { action ->
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(18.dp))
                                    .border(
                                        width = 1.dp,
                                        brush = Brush.linearGradient(
                                            colors = listOf(
                                                NovaElectricBlue.copy(alpha = 0.3f),
                                                NovaDeepViolet.copy(alpha = 0.25f)
                                            )
                                        ),
                                        shape = RoundedCornerShape(18.dp)
                                    )
                                    .clickable { onActionCardClick(action) }
                                    .testTag("welcome_card_${action.name.lowercase()}"),
                                shape = RoundedCornerShape(18.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                Brush.linearGradient(
                                                    colors = listOf(
                                                        NovaElectricBlue.copy(alpha = 0.2f),
                                                        NovaDeepViolet.copy(alpha = 0.25f)
                                                    )
                                                )
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = action.icon,
                                            contentDescription = null,
                                            tint = NovaElectricBlue,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = action.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = action.subtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NovaMessageComposer(
    text: String,
    onTextChange: (String) -> Unit,
    selectedMode: AssistantMode,
    onSelectMode: (AssistantMode) -> Unit,
    pendingAttachments: List<PendingAttachment>,
    isUploadingAttachment: Boolean,
    isGenerating: Boolean,
    isListening: Boolean,
    onRemoveAttachment: (String) -> Unit,
    onPickImages: () -> Unit,
    onPickDocuments: () -> Unit,
    onLaunchCamera: () -> Unit,
    onToggleVoiceInput: () -> Unit,
    onSend: () -> Unit,
    onStopGeneration: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Mode Selector Strip (General, Coding, Research, Writing, Image Studio)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AssistantMode.entries.forEach { mode ->
                    FilterChip(
                        selected = selectedMode == mode,
                        onClick = { onSelectMode(mode) },
                        label = { Text(mode.label, style = MaterialTheme.typography.bodySmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NovaElectricBlue.copy(alpha = 0.2f),
                            selectedLabelColor = NovaElectricBlue
                        )
                    )
                }
            }

            // Upload Progress Indicator
            if (isUploadingAttachment) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 6.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Validating & preparing attachment...", style = MaterialTheme.typography.bodySmall)
                }
            }

            // Attachment Previews Bar
            if (pendingAttachments.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    pendingAttachments.forEach { att ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (att.bitmapPreview != null) {
                                    androidx.compose.foundation.Image(
                                        bitmap = att.bitmapPreview.asImageBitmap(),
                                        contentDescription = att.fileName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (att.type == AttachmentType.CODE) Icons.Default.Code else Icons.Default.Description,
                                        contentDescription = null,
                                        tint = NovaElectricBlue,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.widthIn(max = 150.dp)) {
                                    Text(
                                        text = att.fileName,
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = com.example.util.AttachmentHelper.formatFileSize(att.fileSizeBytes),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(
                                    onClick = { onRemoveAttachment(att.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove attachment",
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Attachment & Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom
            ) {
                // Gallery Image Button
                IconButton(
                    onClick = onPickImages,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("attach_image_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "Attach image from gallery",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // File / Document Button
                IconButton(
                    onClick = onPickDocuments,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("attach_file_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "Attach document or code file",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Camera Button
                IconButton(
                    onClick = onLaunchCamera,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("camera_capture_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Take photo with camera",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Multiline Text Input
                OutlinedTextField(
                    value = text,
                    onValueChange = onTextChange,
                    placeholder = {
                        Text(
                            text = "Message AURA AI...",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    },
                    maxLines = 5,
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaElectricBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .padding(horizontal = 4.dp)
                        .testTag("chat_message_input")
                )

                // Voice Input Shortcut
                IconButton(
                    onClick = onToggleVoiceInput,
                    modifier = Modifier
                        .size(42.dp)
                        .testTag("voice_mic_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = if (isListening) "Stop voice input" else "Voice input",
                        tint = if (isListening) MaterialTheme.colorScheme.error else NovaElectricBlue
                    )
                }

                // Send OR Stop-Generation Button
                if (isGenerating) {
                    IconButton(
                        onClick = onStopGeneration,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.error)
                            .testTag("stop_generation_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop generation",
                            tint = Color.White
                        )
                    }
                } else {
                    val canSend = text.isNotBlank() || pendingAttachments.isNotEmpty()
                    IconButton(
                        onClick = onSend,
                        enabled = canSend,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (canSend) NovaElectricBlue else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .testTag("send_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = if (canSend) "Send message" else "Enter message or attach file to send",
                            tint = if (canSend) Color(0xFF001F25) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConversationSidebarContent(
    conversations: List<Conversation>,
    activeConversationId: String?,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onOpenIntroduction: () -> Unit,
    onStartNewChat: () -> Unit,
    onSelectConversation: (String) -> Unit,
    onRenameConversation: (Conversation) -> Unit,
    onDeleteConversation: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = NovaElectricBlue)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "AURA AI",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Dedicated "Introduction" option in the Three-Line Menu explaining what every button does
        OutlinedButton(
            onClick = onOpenIntroduction,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("sidebar_introduction_button")
        ) {
            Icon(Icons.Default.Description, contentDescription = null, tint = NovaElectricBlue)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Introduction (Button Guide)", fontWeight = FontWeight.SemiBold, color = NovaElectricBlue)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onStartNewChat,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("sidebar_new_chat_button")
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("New Chat", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("Search conversations...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))
        HorizontalDivider()
        Spacer(modifier = Modifier.height(8.dp))

        if (conversations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (searchQuery.isBlank()) "No saved conversations yet." else "No conversations match \"$searchQuery\".",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(conversations, key = { it.id }) { conv ->
                    val isSelected = conv.id == activeConversationId
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) NovaElectricBlue.copy(alpha = 0.16f) else Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectConversation(conv.id) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = conv.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (isSelected) NovaElectricBlue else MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (conv.lastMessagePreview.isNotBlank()) {
                                    Text(
                                        text = conv.lastMessagePreview,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton(
                                onClick = { onRenameConversation(conv) },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Rename conversation",
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            IconButton(
                                onClick = { onDeleteConversation(conv.id) },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete conversation",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
