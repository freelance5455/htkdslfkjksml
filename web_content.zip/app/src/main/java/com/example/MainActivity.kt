package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.screens.AutoWriterMainScreen
import com.example.ui.theme.AutoWriterTheme
import com.example.ui.viewmodel.AutoWriterViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AutoWriterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AutoWriterTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AutoWriterMainScreen(viewModel = viewModel)
                }
            }
        }
    }
}
