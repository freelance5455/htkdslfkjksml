package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.repository.AdminRepository
import com.example.data.repository.ArkPreferencesRepository
import com.example.data.repository.AuthManager
import com.example.data.repository.ChallengeRepository
import com.example.data.repository.DirectMessageRepository
import com.example.data.repository.FeedRepository
import com.example.data.repository.FollowRepository
import com.example.data.repository.GameRepository
import com.example.data.repository.GroupRepository
import com.example.data.repository.SocialRepository
import com.example.data.repository.StoryRepository
import com.example.data.repository.UserRepository
import com.example.data.repository.authStateFlow
import com.example.ui.components.ArkAuroraBackground
import com.example.ui.components.ArkPostLaunchLoadingScreen
import com.example.ui.components.ArkSplashScreen
import com.example.ui.components.LiquidGlassCard
import com.example.ui.navigation.ArkMainAppScaffold
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.OnboardingProfileScreen
import com.example.ui.theme.ArkTheme
import com.example.ui.theme.ArkThemeTokens
import com.example.ui.viewmodel.ArkAppViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val prefsRepo = ArkPreferencesRepository(applicationContext)

        setContent {
            val themeMode by prefsRepo.themeModeFlow.collectAsStateWithLifecycle(initialValue = "system")
            ArkTheme(themeMode = themeMode) {
                ArkRootHost(prefsRepo = prefsRepo)
            }
        }
    }
}

@Composable
private fun ArkRootHost(prefsRepo: ArkPreferencesRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val currentUser by Firebase.auth.authStateFlow().collectAsStateWithLifecycle(
        initialValue = Firebase.auth.currentUser
    )
    var launchScreenDone by remember { mutableStateOf(false) }
    var autoSignInChecked by remember { mutableStateOf(Firebase.auth.currentUser != null) }

    LaunchedEffect(launchScreenDone) {
        if (!launchScreenDone || autoSignInChecked) return@LaunchedEffect
        withFrameNanos { }
        withFrameNanos { }
        AuthManager.attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = { autoSignInChecked = true },
            onUnauthenticated = { autoSignInChecked = true },
            scope = scope
        )
    }

    val user = currentUser
    val viewModel: ArkAppViewModel? = if (user != null) {
        key(user.uid) {
            viewModel<ArkAppViewModel>(
                key = "ark_vm_${user.uid}",
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY])
                        val databaseId = app.getString(R.string.firestore_database_id)
                        val db = FirebaseFirestore.getInstance(databaseId)
                        ArkAppViewModel(
                            currentUserId = user.uid,
                            userEmail = user.email ?: "",
                            userRepo = UserRepository(db),
                            socialRepo = SocialRepository(db),
                            groupRepo = GroupRepository(db),
                            gameRepo = GameRepository(db),
                            challengeRepo = ChallengeRepository(db),
                            adminRepo = AdminRepository(db),
                            prefsRepo = prefsRepo,
                            feedRepo = FeedRepository(db),
                            storyRepo = StoryRepository(db),
                            followRepo = FollowRepository(db),
                            dmRepo = DirectMessageRepository(db)
                        )
                    }
                }
            )
        }
    } else {
        null
    }

    if (!launchScreenDone) {
        ArkSplashScreen(
            onLaunchComplete = { launchScreenDone = true }
        )
        return
    }

    if (!autoSignInChecked) {
        ArkPostLaunchLoadingScreen()
        return
    }

    if (user == null || viewModel == null) {
        AuthScreen(onAuthSuccess = { /* Reactive via authStateFlow */ })
        return
    }

    ArkAuthenticatedGate(
        viewModel = viewModel,
        onSignOut = {
            AuthManager.signOut(
                credentialManager = credentialManager,
                scope = scope
            )
        }
    )
}

@Composable
private fun ArkAuthenticatedGate(
    viewModel: ArkAppViewModel,
    onSignOut: () -> Unit
) {
    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        val msg = snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearMessage()
        }
    }

    when (val state = profileState) {
        UiState.Loading -> {
            ArkPostLaunchLoadingScreen()
        }

        is UiState.Error -> {
            val colors = ArkThemeTokens.colors
            ArkAuroraBackground {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    LiquidGlassCard(
                        modifier = Modifier.widthIn(max = 460.dp),
                        accentColor = colors.coral
                    ) {
                        Text(
                            text = "Connection Issue",
                            style = MaterialTheme.typography.headlineSmall,
                            color = colors.ink
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = state.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.ink2
                        )
                        Spacer(Modifier.height(16.dp))
                        OutlinedButton(
                            onClick = onSignOut,
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Text("Sign Out & Retry")
                        }
                    }
                }
            }
        }

        is UiState.Success -> {
            val profile = state.data
            if (profile == null) {
                Scaffold(
                    containerColor = Color.Transparent,
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    contentWindowInsets = WindowInsets(0, 0, 0, 0)
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        OnboardingProfileScreen(
                            onSubmit = { username, displayTag, bio, avatarPreset, ageBracket, parentalConsent, parentEmail ->
                                viewModel.createProfile(
                                    username = username,
                                    displayTag = displayTag,
                                    bio = bio,
                                    avatarPreset = avatarPreset,
                                    ageBracket = ageBracket,
                                    parentalConsentApproved = parentalConsent,
                                    parentEmailHint = parentEmail
                                )
                            }
                        )
                    }
                }
            } else {
                ArkMainAppScaffold(
                    profile = profile,
                    viewModel = viewModel,
                    snackbarHostState = snackbarHostState,
                    onSignOut = onSignOut
                )
            }
        }
    }
}
