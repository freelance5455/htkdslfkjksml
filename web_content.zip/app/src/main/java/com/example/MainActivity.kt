package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SimulationState
import com.example.ui.AnalyticsVerifierScreen
import com.example.ui.HistoryScreen
import com.example.ui.InspectionSheet
import com.example.ui.LogsScreen
import com.example.ui.SimulatorScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.TrafficSimulatorViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TrafficSimulatorViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val activeTab by viewModel.activeTab.collectAsState()
                val selectedVisit by viewModel.selectedVisit.collectAsState()
                val stats by viewModel.stats.collectAsState()
                val visits by viewModel.visits.collectAsState()
                var showHelpDialog by remember { mutableStateOf(false) }

                BackHandler(enabled = activeTab != 0) {
                    viewModel.setActiveTab(0)
                }

                Scaffold(
                    topBar = {
                        CenterAlignedTopAppBar(
                            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surface,
                                titleContentColor = MaterialTheme.colorScheme.onSurface
                            ),
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(CyberCyan.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Speed,
                                            contentDescription = null,
                                            tint = CyberCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "TrafficPulse",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp,
                                        letterSpacing = 0.5.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    // Status Pill
                                    Surface(
                                        color = when (stats.state) {
                                            SimulationState.RUNNING -> CyberCyan.copy(alpha = 0.15f)
                                            SimulationState.PAUSED -> WarningAmber.copy(alpha = 0.15f)
                                            SimulationState.COMPLETED -> SuccessGreen.copy(alpha = 0.15f)
                                            else -> MaterialTheme.colorScheme.surfaceVariant
                                        },
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(CircleShape)
                                                    .background(
                                                        when (stats.state) {
                                                            SimulationState.RUNNING -> CyberCyan
                                                            SimulationState.PAUSED -> WarningAmber
                                                            SimulationState.COMPLETED -> SuccessGreen
                                                            else -> Color.Gray
                                                        }
                                                    )
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = when (stats.state) {
                                                    SimulationState.RUNNING -> "ACTIVE"
                                                    SimulationState.PAUSED -> "PAUSED"
                                                    SimulationState.COMPLETED -> "DONE"
                                                    else -> "READY"
                                                },
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when (stats.state) {
                                                    SimulationState.RUNNING -> CyberCyan
                                                    SimulationState.PAUSED -> WarningAmber
                                                    SimulationState.COMPLETED -> SuccessGreen
                                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                }
                                            )
                                        }
                                    }
                                }
                            },
                            actions = {
                                IconButton(
                                    onClick = { showHelpDialog = true },
                                    modifier = Modifier.testTag("help_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Info,
                                        contentDescription = "Help & Information",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            modifier = Modifier
                                .navigationBarsPadding()
                                .testTag("bottom_nav_bar")
                        ) {
                            NavigationBarItem(
                                selected = activeTab == 0,
                                onClick = { viewModel.setActiveTab(0) },
                                icon = {
                                    Icon(
                                        imageVector = if (activeTab == 0) Icons.Filled.Speed else Icons.Outlined.Speed,
                                        contentDescription = "Runner"
                                    )
                                },
                                label = { Text("Runner", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CyberCyan.copy(alpha = 0.2f),
                                    selectedIconColor = CyberCyan
                                ),
                                modifier = Modifier.testTag("nav_runner")
                            )

                            NavigationBarItem(
                                selected = activeTab == 1,
                                onClick = { viewModel.setActiveTab(1) },
                                icon = {
                                    BadgedBox(
                                        badge = {
                                            if (visits.isNotEmpty()) {
                                                Badge(containerColor = CyberCyan, contentColor = Color(0xFF003548)) {
                                                    Text(visits.size.toString(), fontSize = 10.sp)
                                                }
                                            }
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (activeTab == 1) Icons.Filled.ViewList else Icons.Outlined.ViewList,
                                            contentDescription = "Live Logs"
                                        )
                                    }
                                },
                                label = { Text("Live Log", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CyberCyan.copy(alpha = 0.2f),
                                    selectedIconColor = CyberCyan
                                ),
                                modifier = Modifier.testTag("nav_logs")
                            )

                            NavigationBarItem(
                                selected = activeTab == 2,
                                onClick = { viewModel.setActiveTab(2) },
                                icon = {
                                    Icon(
                                        imageVector = if (activeTab == 2) Icons.Filled.Analytics else Icons.Outlined.Analytics,
                                        contentDescription = "Verifier"
                                    )
                                },
                                label = { Text("Verifier", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CyberCyan.copy(alpha = 0.2f),
                                    selectedIconColor = CyberCyan
                                ),
                                modifier = Modifier.testTag("nav_verifier")
                            )

                            NavigationBarItem(
                                selected = activeTab == 3,
                                onClick = { viewModel.setActiveTab(3) },
                                icon = {
                                    Icon(
                                        imageVector = if (activeTab == 3) Icons.Filled.History else Icons.Outlined.History,
                                        contentDescription = "History"
                                    )
                                },
                                label = { Text("History", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = CyberCyan.copy(alpha = 0.2f),
                                    selectedIconColor = CyberCyan
                                ),
                                modifier = Modifier.testTag("nav_history")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (activeTab) {
                            0 -> SimulatorScreen(viewModel = viewModel)
                            1 -> LogsScreen(viewModel = viewModel)
                            2 -> AnalyticsVerifierScreen(viewModel = viewModel)
                            3 -> HistoryScreen(viewModel = viewModel)
                        }
                    }

                    // Inspection Sheet Modal
                    selectedVisit?.let { visit ->
                        InspectionSheet(
                            visit = visit,
                            onDismiss = { viewModel.selectVisit(null) }
                        )
                    }

                    // Help / Guide Dialog
                    if (showHelpDialog) {
                        AlertDialog(
                            onDismissRequest = { showHelpDialog = false },
                            icon = {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = null,
                                    tint = CyberCyan
                                )
                            },
                            title = {
                                Text("About TrafficPulse", fontWeight = FontWeight.Bold)
                            },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "TrafficPulse is an automated web testing client built for website developers and site administrators to verify how servers handle unique visitors.",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Text(
                                        text = "• Isolated Sessions: Zero cookie reuse between visits; forces the web server to create new user sessions.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        text = "• Multi-Device Signatures: Rotates User-Agents across Desktop Chrome, Safari macOS, Mobile Android, and iPhone iOS.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        text = "• IP & Geo Diversity: Adds unique public IPs to X-Forwarded-For and Client-IP headers.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        text = "• Verifier Suite: Audits whether your server tracking, analytics tags, and unique-view counters incremented accurately.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            },
                            confirmButton = {
                                TextButton(onClick = { showHelpDialog = false }) {
                                    Text("Got It")
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
