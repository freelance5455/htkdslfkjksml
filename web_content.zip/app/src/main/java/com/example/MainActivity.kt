package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.repository.StyleAiRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOut
import com.example.ui.components.FloatingSalesAssistantOrb
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material3.FilterChip
import androidx.compose.ui.unit.dp
import com.example.ui.screens.DiscoverCatalogScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProductDetailAndPriceComparisonScreen
import com.example.ui.screens.VirtualTryOnScreen
import com.example.ui.screens.WardrobeAndProfileScreen
import com.example.ui.screens.WishlistScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.StyleAiViewModel
import com.example.util.IndianAiVoiceSalesman
import com.example.util.LoginPersonaPrefs
import com.example.util.configureAppCheck
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

enum class MainNavTab(val label: String) {
    HOME("Home"),
    DISCOVER("Discover"),
    TRY_ON("Virtual Try-On"),
    WARDROBE("My Wardrobe"),
    PROFILE("Profile")
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        LoginPersonaPrefs.loadVerifiedPhoneSession(context)
    }

    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val phoneSession by LoginPersonaPrefs.phoneSessionFlow.collectAsStateWithLifecycle()
    val user = currentUser

    if (user != null) {
        StyleAiAuthenticatedApp(
            currentUserId = user.uid,
            displayName = user.displayName ?: user.phoneNumber ?: "Style Connoisseur"
        )
    } else if (phoneSession != null) {
        val activePhoneSession = phoneSession!!
        StyleAiAuthenticatedApp(
            currentUserId = activePhoneSession.uid,
            displayName = activePhoneSession.displayName
        )
    } else {
        AuthScreen(onAuthSuccess = {})
    }
}

@Composable
fun StyleAiAuthenticatedApp(
    currentUserId: String,
    displayName: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val voiceSalesman = remember { IndianAiVoiceSalesman(context) }

    DisposableEffect(Unit) {
        onDispose {
            voiceSalesman.shutdown()
        }
    }

    var isVoiceMuted by rememberSaveable {
        mutableStateOf(LoginPersonaPrefs.isVoiceMuted(context))
    }
    // Rectangle selector bar is only open if user hasn't clicked OK yet; after clicking OK, the rectangle bar is closed and ONLY the circle speaks with wave lines inside the circle!
    var isRectangleSelectorOpen by rememberSaveable {
        mutableStateOf(!LoginPersonaPrefs.hasConfirmedGenderAtLogin(context))
    }

    val viewModel: StyleAiViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                StyleAiViewModel(
                    repository = StyleAiRepository(db),
                    currentUserId = currentUserId,
                    displayName = displayName
                )
            }
        }
    )

    val speakHelper: (String, String, String) -> Unit = { text, gender, lang ->
        voiceSalesman.speakSalesPitch(
            text = text,
            userGender = gender,
            preferredLanguage = lang,
            isMuted = isVoiceMuted
        )
    }

    LaunchedEffect(currentUserId) {
        viewModel.loadExistingPersonalPhoto(context)
        viewModel.initializeSessionWithLoginPersona(context, speakHelper)
    }

    var currentTab by rememberSaveable { mutableStateOf(MainNavTab.HOME) }
    var showingProductDetail by rememberSaveable { mutableStateOf(false) }

    val userProfileState by viewModel.userProfileState.collectAsStateWithLifecycle()
    val wishlistItemsState by viewModel.wishlistItemsState.collectAsStateWithLifecycle()
    val savedOutfitsState by viewModel.savedOutfitsState.collectAsStateWithLifecycle()
    val tryOnSessionsState by viewModel.tryOnSessionsState.collectAsStateWithLifecycle()
    val recentlyViewedState by viewModel.recentlyViewedState.collectAsStateWithLifecycle()

    val catalogProducts by viewModel.catalogProducts.collectAsStateWithLifecycle()
    val catalogFeedStatus by viewModel.catalogFeedStatus.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedOccasion by viewModel.selectedOccasion.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val maxPriceFilter by viewModel.maxPriceFilter.collectAsStateWithLifecycle()

    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()
    val selectedColor by viewModel.selectedColorVariant.collectAsStateWithLifecycle()
    val selectedSize by viewModel.selectedSizeVariant.collectAsStateWithLifecycle()

    val userPhotoBitmap by viewModel.userPhotoBitmap.collectAsStateWithLifecycle()
    val photoConsentAccepted by viewModel.photoConsentAccepted.collectAsStateWithLifecycle()

    val stylistUiState by viewModel.stylistUiState.collectAsStateWithLifecycle()
    val tryOnUiState by viewModel.tryOnUiState.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val chatUiState by viewModel.chatUiState.collectAsStateWithLifecycle()
    val statusBannerMessage by viewModel.statusBannerMessage.collectAsStateWithLifecycle()

    // Indian AI Salesperson Flows
    val userGender by viewModel.userGender.collectAsStateWithLifecycle()
    val preferredLanguage by viewModel.preferredLanguage.collectAsStateWithLifecycle()
    val salesmanPitchText by viewModel.salesmanPitchText.collectAsStateWithLifecycle()
    val salesmanActionLabel by viewModel.salesmanActionLabel.collectAsStateWithLifecycle()
    val salesmanTargetRoute by viewModel.salesmanTargetRoute.collectAsStateWithLifecycle()
    val isSalesmanSpeaking by voiceSalesman.isSpeaking.collectAsStateWithLifecycle()

    val activePersona = remember(userGender) {
        LoginPersonaPrefs.getOppositeGenderSalesmanPersona(userGender)
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(statusBannerMessage) {
        statusBannerMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    if (currentTab != MainNavTab.HOME && !showingProductDetail) {
        BackHandler {
            currentTab = MainNavTab.HOME
            viewModel.onSalesmanDirectScreenChange("HOME", selectedProduct, speakHelper)
        }
    }

    val currentScreenKey = if (showingProductDetail) "PRODUCT_DETAIL" else currentTab.name

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                NavigationBarItem(
                    selected = currentTab == MainNavTab.HOME && !showingProductDetail,
                    onClick = {
                        showingProductDetail = false
                        currentTab = MainNavTab.HOME
                        viewModel.onSalesmanDirectScreenChange("HOME", selectedProduct, speakHelper)
                    },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = currentTab == MainNavTab.DISCOVER || showingProductDetail,
                    onClick = {
                        showingProductDetail = false
                        currentTab = MainNavTab.DISCOVER
                        viewModel.onSalesmanDirectScreenChange("DISCOVER", selectedProduct, speakHelper)
                    },
                    icon = { Icon(Icons.Default.Explore, contentDescription = "Discover") },
                    label = { Text("Discover") },
                    modifier = Modifier.testTag("nav_discover")
                )
                NavigationBarItem(
                    selected = currentTab == MainNavTab.TRY_ON && !showingProductDetail,
                    onClick = {
                        showingProductDetail = false
                        currentTab = MainNavTab.TRY_ON
                        viewModel.onSalesmanDirectScreenChange("TRY_ON", selectedProduct, speakHelper)
                    },
                    icon = { Icon(Icons.Default.Checkroom, contentDescription = "Virtual Try-On") },
                    label = { Text("Try-On") },
                    modifier = Modifier.testTag("nav_tryon")
                )
                NavigationBarItem(
                    selected = currentTab == MainNavTab.WARDROBE && !showingProductDetail,
                    onClick = {
                        showingProductDetail = false
                        currentTab = MainNavTab.WARDROBE
                        viewModel.onSalesmanDirectScreenChange("WARDROBE", selectedProduct, speakHelper)
                    },
                    icon = { Icon(Icons.Default.Favorite, contentDescription = "Wishlist") },
                    label = { Text("Wishlist") },
                    modifier = Modifier.testTag("nav_wardrobe")
                )
                NavigationBarItem(
                    selected = currentTab == MainNavTab.PROFILE && !showingProductDetail,
                    onClick = {
                        showingProductDetail = false
                        currentTab = MainNavTab.PROFILE
                        viewModel.onSalesmanDirectScreenChange("PROFILE", selectedProduct, speakHelper)
                    },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                    label = { Text("Profile") },
                    modifier = Modifier.testTag("nav_profile")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (showingProductDetail) {
                ProductDetailAndPriceComparisonScreen(
                    product = selectedProduct,
                    selectedColor = selectedColor,
                    selectedSize = selectedSize,
                    onColorSelected = viewModel::selectColorVariant,
                    onSizeSelected = viewModel::selectSizeVariant,
                    onLaunchTryOn = {
                        showingProductDetail = false
                        currentTab = MainNavTab.TRY_ON
                        viewModel.onSalesmanDirectScreenChange("TRY_ON", selectedProduct, speakHelper)
                    },
                    onSaveToWardrobe = {
                        viewModel.saveProductToWardrobe(selectedProduct)
                    },
                    onBack = { showingProductDetail = false }
                )
            } else {
                when (currentTab) {
                    MainNavTab.HOME -> {
                        val profileData = (userProfileState as? com.example.ui.viewmodel.DataUiState.Success)?.data
                        HomeScreen(
                            userProfile = profileData,
                            userPhotoBitmap = userPhotoBitmap,
                            catalogProducts = catalogProducts,
                            stylistUiState = stylistUiState,
                            chatMessages = chatMessages,
                            chatUiState = chatUiState,
                            onNavigateToTryOn = {
                                currentTab = MainNavTab.TRY_ON
                                viewModel.onSalesmanDirectScreenChange("TRY_ON", selectedProduct, speakHelper)
                            },
                            onNavigateToDiscover = {
                                currentTab = MainNavTab.DISCOVER
                                viewModel.onSalesmanDirectScreenChange("DISCOVER", selectedProduct, speakHelper)
                            },
                            onSelectProductForDetail = { prod ->
                                viewModel.selectProduct(prod)
                                showingProductDetail = true
                                viewModel.onSalesmanDirectScreenChange("PRODUCT_DETAIL", prod, speakHelper)
                            },
                            onSelectProductForTryOn = { prod ->
                                viewModel.selectProduct(prod)
                                currentTab = MainNavTab.TRY_ON
                                viewModel.onSalesmanDirectScreenChange("TRY_ON", prod, speakHelper)
                            },
                            onSaveProduct = { prod, note ->
                                viewModel.saveProductToWardrobe(prod, note)
                            },
                            onGenerateRecommendations = viewModel::generatePersonalizedRecommendations,
                            onSendChatMessage = viewModel::sendChatStylistMessage
                        )
                    }

                    MainNavTab.DISCOVER -> {
                        DiscoverCatalogScreen(
                            products = catalogProducts,
                            feedStatus = catalogFeedStatus,
                            selectedCategory = selectedCategory,
                            selectedOccasion = selectedOccasion,
                            searchQuery = searchQuery,
                            maxPriceFilter = maxPriceFilter,
                            onCategoryChange = viewModel::updateCategoryFilter,
                            onOccasionChange = viewModel::updateOccasionFilter,
                            onSearchQueryChange = viewModel::updateSearchQuery,
                            onMaxPriceChange = viewModel::updateMaxPriceFilter,
                            onRefreshFeed = viewModel::refreshLiveCatalogFeed,
                            onSelectProductForDetail = { prod ->
                                viewModel.selectProduct(prod)
                                showingProductDetail = true
                                viewModel.onSalesmanDirectScreenChange("PRODUCT_DETAIL", prod, speakHelper)
                            },
                            onSelectProductForTryOn = { prod ->
                                viewModel.selectProduct(prod)
                                currentTab = MainNavTab.TRY_ON
                                viewModel.onSalesmanDirectScreenChange("TRY_ON", prod, speakHelper)
                            },
                            onSaveProduct = { prod ->
                                viewModel.saveProductToWardrobe(prod)
                            }
                        )
                    }

                    MainNavTab.TRY_ON -> {
                        VirtualTryOnScreen(
                            userProfileState = userProfileState,
                            userPhotoBitmap = userPhotoBitmap,
                            photoConsentAccepted = photoConsentAccepted,
                            selectedProduct = selectedProduct,
                            selectedColor = selectedColor,
                            selectedSize = selectedSize,
                            catalogProducts = catalogProducts,
                            tryOnUiState = tryOnUiState,
                            onPhotoConsentChanged = { granted ->
                                viewModel.setPhotoConsent(context, granted)
                            },
                            onPhotoCaptured = { bmp ->
                                viewModel.onPersonalPhotoCaptured(context, bmp)
                            },
                            onPhotoSelectedFromUri = { uri ->
                                viewModel.onPersonalPhotoSelectedFromUri(context, uri)
                            },
                            onDeletePhoto = {
                                viewModel.deletePersonalPhoto(context)
                            },
                            onSelectProduct = { prod ->
                                viewModel.selectProduct(prod)
                                viewModel.onSalesmanDirectScreenChange("TRY_ON", prod, speakHelper)
                            },
                            onSelectColor = viewModel::selectColorVariant,
                            onSelectSize = viewModel::selectSizeVariant,
                            onGenerateTryOn = {
                                viewModel.generateVirtualTryOn(context)
                            },
                            onSaveOutfitToWardrobe = { prod ->
                                viewModel.saveProductToWardrobe(prod)
                            },
                            onComparePrices = { prod ->
                                viewModel.selectProduct(prod)
                                showingProductDetail = true
                                viewModel.onSalesmanDirectScreenChange("PRODUCT_DETAIL", prod, speakHelper)
                            }
                        )
                    }

                    MainNavTab.WARDROBE -> {
                        var showWardrobeHistorySubTab by rememberSaveable { mutableStateOf(false) }
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                            ) {
                                FilterChip(
                                    selected = !showWardrobeHistorySubTab,
                                    onClick = { showWardrobeHistorySubTab = false },
                                    leadingIcon = {
                                        Icon(Icons.Default.Favorite, contentDescription = null)
                                    },
                                    label = { Text("My Wishlist") },
                                    modifier = Modifier.testTag("subtab_wishlist")
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                FilterChip(
                                    selected = showWardrobeHistorySubTab,
                                    onClick = { showWardrobeHistorySubTab = true },
                                    leadingIcon = {
                                        Icon(Icons.Default.Checkroom, contentDescription = null)
                                    },
                                    label = { Text("Wardrobe & Try-On History") },
                                    modifier = Modifier.testTag("subtab_wardrobe_history")
                                )
                            }

                            if (!showWardrobeHistorySubTab) {
                                WishlistScreen(
                                    wishlistItemsState = wishlistItemsState,
                                    catalogProducts = catalogProducts,
                                    selectedProduct = selectedProduct,
                                    onAddProductToWishlist = { prod ->
                                        viewModel.addProductToWishlist(prod)
                                    },
                                    onUpdateWishlistItemVariant = { itemId, color, size, notes ->
                                        viewModel.updateWishlistItemVariant(itemId, color, size, notes)
                                    },
                                    onRemoveWishlistItem = viewModel::removeWishlistItem,
                                    onTryOnWishlistItem = { prod, color, size ->
                                        viewModel.selectProduct(prod)
                                        viewModel.selectColorVariant(color)
                                        viewModel.selectSizeVariant(size)
                                        currentTab = MainNavTab.TRY_ON
                                        viewModel.onSalesmanDirectScreenChange("TRY_ON", prod, speakHelper)
                                    },
                                    onCompareWishlistItemPrices = { prod ->
                                        viewModel.selectProduct(prod)
                                        showingProductDetail = true
                                        viewModel.onSalesmanDirectScreenChange("PRODUCT_DETAIL", prod, speakHelper)
                                    },
                                    onExploreCatalog = {
                                        currentTab = MainNavTab.DISCOVER
                                        viewModel.onSalesmanDirectScreenChange("DISCOVER", selectedProduct, speakHelper)
                                    }
                                )
                            } else {
                                WardrobeAndProfileScreen(
                                    isProfileTab = false,
                                    userProfileState = userProfileState,
                                    savedOutfitsState = savedOutfitsState,
                                    tryOnSessionsState = tryOnSessionsState,
                                    recentlyViewedState = recentlyViewedState,
                                    onRemoveSavedOutfit = viewModel::removeOutfitFromWardrobe,
                                    onDeleteTryOnSession = viewModel::deleteTryOnSessionItem,
                                    onToggleMembershipTier = viewModel::toggleMembershipTier,
                                    onSaveBodyMeasurements = viewModel::saveBodyMeasurements,
                                    onSignOut = {
                                        signOut(context, credentialManager, {}, scope)
                                    },
                                    onDeleteAccountAndData = {
                                        viewModel.deleteAccountAndPersonalData(context) {
                                            signOut(context, credentialManager, {}, scope)
                                        }
                                    }
                                )
                            }
                        }
                    }

                    MainNavTab.PROFILE -> {
                        WardrobeAndProfileScreen(
                            isProfileTab = true,
                            userProfileState = userProfileState,
                            savedOutfitsState = savedOutfitsState,
                            tryOnSessionsState = tryOnSessionsState,
                            recentlyViewedState = recentlyViewedState,
                            onRemoveSavedOutfit = viewModel::removeOutfitFromWardrobe,
                            onDeleteTryOnSession = viewModel::deleteTryOnSessionItem,
                            onToggleMembershipTier = viewModel::toggleMembershipTier,
                            onSaveBodyMeasurements = viewModel::saveBodyMeasurements,
                            onSignOut = {
                                signOut(context, credentialManager, {}, scope)
                            },
                            onDeleteAccountAndData = {
                                viewModel.deleteAccountAndPersonalData(context) {
                                    signOut(context, credentialManager, {}, scope)
                                }
                            }
                        )
                    }
                }
            }

            // FLOATING CIRCULAR OPPOSITE-GENDER INDIAN AI SALESPERSON ON THE SIDE
            // After clicking OK, the rectangle bar is closed and ONLY the circle speaks in the wave line inside the circle!
            FloatingSalesAssistantOrb(
                userGender = userGender,
                preferredLanguage = preferredLanguage,
                persona = activePersona,
                currentPitchText = salesmanPitchText,
                currentActionLabel = salesmanActionLabel,
                isSpeaking = isSalesmanSpeaking,
                isVoiceMuted = isVoiceMuted,
                isRectangleSelectorOpen = isRectangleSelectorOpen,
                onConfirmOkAndCloseRectangle = { chosenGender, chosenLang ->
                    isRectangleSelectorOpen = false
                    viewModel.updateUserGenderAndLanguage(
                        context = context,
                        newGender = chosenGender,
                        newLanguage = chosenLang,
                        currentScreenKey = currentScreenKey,
                        onSpeakPitch = speakHelper
                    )
                },
                onOpenSelectorRectangle = {
                    isRectangleSelectorOpen = true
                },
                onExecuteSalesmanDirection = {
                    when (salesmanTargetRoute) {
                        "DISCOVER" -> {
                            showingProductDetail = false
                            currentTab = MainNavTab.DISCOVER
                            viewModel.onSalesmanDirectScreenChange("DISCOVER", selectedProduct, speakHelper)
                        }
                        "PRODUCT_DETAIL" -> {
                            showingProductDetail = true
                            viewModel.onSalesmanDirectScreenChange("PRODUCT_DETAIL", selectedProduct, speakHelper)
                        }
                        "TRY_ON" -> {
                            showingProductDetail = false
                            currentTab = MainNavTab.TRY_ON
                            viewModel.onSalesmanDirectScreenChange("TRY_ON", selectedProduct, speakHelper)
                        }
                        else -> {
                            showingProductDetail = false
                            currentTab = MainNavTab.DISCOVER
                            viewModel.onSalesmanDirectScreenChange("DISCOVER", selectedProduct, speakHelper)
                        }
                    }
                },
                onReplayPitch = {
                    speakHelper(salesmanPitchText, userGender, preferredLanguage)
                },
                onToggleMute = {
                    val nextMuted = !isVoiceMuted
                    isVoiceMuted = nextMuted
                    LoginPersonaPrefs.saveVoiceMuted(context, nextMuted)
                    if (nextMuted) {
                        voiceSalesman.stopSpeaking()
                    } else {
                        speakHelper(salesmanPitchText, userGender, preferredLanguage)
                    }
                },
                onChangeGenderAndLanguage = { newGender, newLang ->
                    isRectangleSelectorOpen = false
                    viewModel.updateUserGenderAndLanguage(
                        context = context,
                        newGender = newGender,
                        newLanguage = newLang,
                        currentScreenKey = currentScreenKey,
                        onSpeakPitch = speakHelper
                    )
                },
                onAskSalesmanQuestion = { question ->
                    viewModel.askSalesmanCustomPitch(question, speakHelper)
                },
                onQuickDirectToDeals = {
                    viewModel.updateMaxPriceFilter(1000)
                    showingProductDetail = false
                    currentTab = MainNavTab.DISCOVER
                    viewModel.onSalesmanDirectScreenChange("DISCOVER", catalogProducts.firstOrNull { it.priceInr <= 1000 } ?: selectedProduct, speakHelper)
                },
                onQuickDirectToTryOn = {
                    showingProductDetail = false
                    currentTab = MainNavTab.TRY_ON
                    viewModel.onSalesmanDirectScreenChange("TRY_ON", selectedProduct, speakHelper)
                },
                onQuickDirectToCompare = {
                    showingProductDetail = true
                    viewModel.onSalesmanDirectScreenChange("PRODUCT_DETAIL", selectedProduct, speakHelper)
                },
                onQuickDirectToWedding = {
                    viewModel.updateOccasionFilter("Wedding")
                    showingProductDetail = false
                    currentTab = MainNavTab.DISCOVER
                    viewModel.onSalesmanDirectScreenChange("DISCOVER", catalogProducts.firstOrNull { it.occasion.contains("Wedding", ignoreCase = true) } ?: selectedProduct, speakHelper)
                }
            )
        }
    }
}
