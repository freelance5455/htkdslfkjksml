package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.LabTab
import com.example.ui.components.CyberTopBar
import com.example.ui.screens.CameraPermissionLabScreen
import com.example.ui.screens.FakeLoginLabScreen
import com.example.ui.screens.MaliciousAppLabScreen
import com.example.ui.screens.OverviewScreen
import com.example.ui.screens.PhotoUploadLabScreen
import com.example.ui.screens.SourceAndSetupScreen
import com.example.ui.screens.WebSimulationScreen
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TKLinkTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TKLinkTheme {
                MainAppContent()
            }
        }
    }
}

@Composable
fun MainAppContent() {
    var currentTab by remember { mutableStateOf(LabTab.DASHBOARD) }
    var currentLanguage by remember { mutableStateOf(AppLanguage.EN) }

    // Android Guidelines: BackHandler inside sub-screens to return to Home/Dashboard
    if (currentTab != LabTab.DASHBOARD) {
        BackHandler {
            currentTab = LabTab.DASHBOARD
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = CyberBackground,
        topBar = {
            CyberTopBar(
                currentLanguage = currentLanguage,
                onToggleLanguage = {
                    currentLanguage = if (currentLanguage == AppLanguage.EN) AppLanguage.BN else AppLanguage.EN
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CyberSurface,
                modifier = Modifier.border(
                    width = 1.dp,
                    color = Color(0xFF1E293B)
                )
            ) {
                NavigationBarItem(
                    selected = currentTab == LabTab.DASHBOARD,
                    onClick = { currentTab = LabTab.DASHBOARD },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = "Dashboard",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "Overview" else "ড্যাশবোর্ড",
                            fontSize = 10.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        indicatorColor = NeonCyan.copy(alpha = 0.15f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_overview")
                )

                NavigationBarItem(
                    selected = currentTab == LabTab.PHOTO_UPLOAD,
                    onClick = { currentTab = LabTab.PHOTO_UPLOAD },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Photo Lab",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "Photos" else "ছবি ল্যাব",
                            fontSize = 10.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        indicatorColor = NeonCyan.copy(alpha = 0.15f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_photo_lab")
                )

                NavigationBarItem(
                    selected = currentTab == LabTab.FAKE_LOGIN,
                    onClick = { currentTab = LabTab.FAKE_LOGIN },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Login Lab",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "Login" else "লগইন",
                            fontSize = 10.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonPurple,
                        selectedTextColor = NeonPurple,
                        indicatorColor = NeonPurple.copy(alpha = 0.15f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_login_lab")
                )

                NavigationBarItem(
                    selected = currentTab == LabTab.CAMERA_PERMISSION,
                    onClick = { currentTab = LabTab.CAMERA_PERMISSION },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Camera Lab",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "Camera" else "ক্যামেরা",
                            fontSize = 10.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonCyan,
                        selectedTextColor = NeonCyan,
                        indicatorColor = NeonCyan.copy(alpha = 0.15f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_camera_lab")
                )

                NavigationBarItem(
                    selected = currentTab == LabTab.MALWARE_SCAN,
                    onClick = { currentTab = LabTab.MALWARE_SCAN },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.BugReport,
                            contentDescription = "Malware Lab",
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "Malware" else "ম্যালওয়্যার",
                            fontSize = 10.sp
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = NeonPurple,
                        selectedTextColor = NeonPurple,
                        indicatorColor = NeonPurple.copy(alpha = 0.15f),
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_malware_lab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                LabTab.DASHBOARD -> OverviewScreen(
                    currentLanguage = currentLanguage,
                    onNavigateTab = { currentTab = it }
                )
                LabTab.PHOTO_UPLOAD -> PhotoUploadLabScreen(
                    currentLanguage = currentLanguage
                )
                LabTab.FAKE_LOGIN -> FakeLoginLabScreen(
                    currentLanguage = currentLanguage
                )
                LabTab.CAMERA_PERMISSION -> CameraPermissionLabScreen(
                    currentLanguage = currentLanguage
                )
                LabTab.MALWARE_SCAN -> MaliciousAppLabScreen(
                    currentLanguage = currentLanguage
                )
                LabTab.SOURCE_SETUP -> SourceAndSetupScreen(
                    currentLanguage = currentLanguage
                )
                LabTab.WEB_VIEW -> WebSimulationScreen(
                    currentLanguage = currentLanguage
                )
            }
        }
    }
}
