package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.notification.DailyReminderManager
import com.example.ui.GuessTheImageApp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private var openDailyChallenge by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        openDailyChallenge = intent?.getBooleanExtra(DailyReminderManager.EXTRA_OPEN_DAILY, false) == true

        // Schedule or verify 5:00 PM daily reminder
        DailyReminderManager.scheduleDailyReminder(this)

        setContent {
            MyApplicationTheme {
                GuessTheImageApp(
                    openDailyOnLaunch = openDailyChallenge,
                    onDailyOpened = { openDailyChallenge = false }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(DailyReminderManager.EXTRA_OPEN_DAILY, false)) {
            openDailyChallenge = true
        }
    }
}
