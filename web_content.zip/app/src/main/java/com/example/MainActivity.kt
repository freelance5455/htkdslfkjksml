package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.firebase.configureAppCheck
import com.example.ui.VelvetApp
import com.example.ui.VelvetMainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: VelvetMainViewModel by viewModels()

    private val requestMicLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.refreshSystemStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Configure Firebase App Check with launch intent before any UI or ViewModel operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        val initialTab = intent?.getStringExtra("open_tab")
        val askMicOnLaunch = intent?.getBooleanExtra("request_mic", false) == true

        viewModel.requestMicPermissionCallback = {
            requestMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        if (askMicOnLaunch) {
            requestMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            VelvetApp(
                viewModel = viewModel,
                initialTab = initialTab,
                onRequestMicPermission = {
                    requestMicLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemStatus()
    }
}
