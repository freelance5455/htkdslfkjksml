package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AppBottomNav
import com.example.ui.components.NavTab
import com.example.ui.screens.*
import com.example.ui.theme.SmartCalcTheme
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.ScreenDestination

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            val isDarkTheme = when (uiState.themeMode) {
                "DARK" -> true
                "LIGHT" -> false
                else -> isSystemInDarkTheme()
            }

            val layoutDirection = if (uiState.language.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

            CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                SmartCalcTheme(darkTheme = isDarkTheme) {
                    BackHandler(enabled = uiState.currentScreen != ScreenDestination.Main) {
                        viewModel.navigateBack()
                    }

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        contentWindowInsets = WindowInsets(0, 0, 0, 0),
                        bottomBar = {
                            if (uiState.currentScreen == ScreenDestination.Main) {
                                AppBottomNav(
                                    currentTab = uiState.currentTab,
                                    language = uiState.language,
                                    onTabSelected = { viewModel.selectTab(it) }
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (uiState.currentScreen) {
                                ScreenDestination.Main -> {
                                    when (uiState.currentTab) {
                                        NavTab.HOME -> HomeScreen(
                                            uiState = uiState,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onSearchChange = { viewModel.setSearchQuery(it) },
                                            onCategorySelect = { viewModel.selectCategory(it) },
                                            onFavoriteToggle = { viewModel.toggleFavorite(it) },
                                            onOpenLanguage = { viewModel.navigateTo(ScreenDestination.LanguageSelect) }
                                        )
                                        NavTab.HISTORY -> HistoryScreen(
                                            uiState = uiState,
                                            onSelectHistory = { viewModel.loadFromHistory(it) },
                                            onDeleteHistory = { viewModel.deleteHistoryItem(it) },
                                            onToggleFavorite = { viewModel.toggleHistoryFavorite(it) },
                                            onClearAll = { viewModel.clearAllHistory() }
                                        )
                                        NavTab.FAVORITES -> FavoritesScreen(
                                            uiState = uiState,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onFavoriteToggle = { viewModel.toggleFavorite(it) }
                                        )
                                        NavTab.SETTINGS -> SettingsScreen(
                                            uiState = uiState,
                                            onSetThemeMode = { viewModel.setThemeMode(it) },
                                            onToggleHaptics = { viewModel.setHapticsEnabled(it) },
                                            onSetDecimalPrecision = { viewModel.setDecimalPrecision(it) },
                                            onToggleAngleMode = { viewModel.toggleAngleMode() },
                                            onOpenLanguage = { viewModel.navigateTo(ScreenDestination.LanguageSelect) }
                                        )
                                    }
                                }

                                ScreenDestination.StandardCalc -> CalculatorScreen(
                                    uiState = uiState,
                                    isScientificInitially = false,
                                    onInput = { viewModel.onCalcInput(it) },
                                    onClear = { viewModel.onCalcClear() },
                                    onBackspace = { viewModel.onCalcBackspace() },
                                    onEquals = { viewModel.onCalcEquals() },
                                    onToggleAngleMode = { viewModel.toggleAngleMode() },
                                    onToggleScientific = { viewModel.toggleScientificPanel() },
                                    onOpenHistory = { viewModel.selectTab(NavTab.HISTORY) },
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.ScientificCalc -> CalculatorScreen(
                                    uiState = uiState,
                                    isScientificInitially = true,
                                    onInput = { viewModel.onCalcInput(it) },
                                    onClear = { viewModel.onCalcClear() },
                                    onBackspace = { viewModel.onCalcBackspace() },
                                    onEquals = { viewModel.onCalcEquals() },
                                    onToggleAngleMode = { viewModel.toggleAngleMode() },
                                    onToggleScientific = { viewModel.toggleScientificPanel() },
                                    onOpenHistory = { viewModel.selectTab(NavTab.HISTORY) },
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.AgeCalc -> AgeCalculatorScreen(
                                    uiState = uiState,
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.GstCalc -> GstCalculatorScreen(
                                    uiState = uiState,
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.BmiCalc -> BmiCalculatorScreen(
                                    uiState = uiState,
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.UnitConverter -> UnitConverterScreen(
                                    uiState = uiState,
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.CurrencyConverter -> CurrencyConverterScreen(
                                    uiState = uiState,
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.DiscountCalc -> DiscountCalcScreen(
                                    uiState = uiState,
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.EmiCalc -> EmiCalcScreen(
                                    uiState = uiState,
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.TipCalc -> TipCalcScreen(
                                    uiState = uiState,
                                    onBack = { viewModel.navigateBack() }
                                )

                                ScreenDestination.LanguageSelect -> LanguageScreen(
                                    uiState = uiState,
                                    onSelectLanguage = {
                                        viewModel.setLanguage(it)
                                        viewModel.navigateBack()
                                    },
                                    onBack = { viewModel.navigateBack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
