package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.ChatScreen
import com.example.ui.theme.FaizSaathiTheme
import com.example.viewmodel.FaizViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: FaizViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()

            FaizSaathiTheme(darkTheme = isDarkTheme) {
                ChatScreen(viewModel = viewModel)
            }
        }
    }
}
