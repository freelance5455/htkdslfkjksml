package com.example

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

  private val fileChooserLauncher =
      registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val results: Array<Uri>? =
            if (result.resultCode == Activity.RESULT_OK) {
              val intentData = result.data
              when {
                intentData?.data != null -> arrayOf(intentData.data!!)
                intentData?.clipData != null -> {
                  val clip = intentData.clipData!!
                  Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                }
                else -> null
              }
            } else {
              null
            }
        fileUploadCallback?.onReceiveValue(results)
        fileUploadCallback = null
      }

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        val context = LocalContext.current
        val webView = remember {
          WebView(context).apply {
            layoutParams =
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(Color.parseColor("#121214"))

            settings.apply {
              javaScriptEnabled = true
              domStorageEnabled = true
              databaseEnabled = true
              allowFileAccess = true
              allowContentAccess = true
              loadsImagesAutomatically = true
              cacheMode = WebSettings.LOAD_DEFAULT
              useWideViewPort = true
              loadWithOverviewMode = true
              displayZoomControls = false
              builtInZoomControls = false
            }

            webViewClient =
                object : WebViewClient() {
                  override fun shouldOverrideUrlLoading(
                      view: WebView?,
                      request: WebResourceRequest?
                  ): Boolean {
                    val url = request?.url?.toString() ?: return false
                    if (url.startsWith("file://") || url.startsWith("data:")) {
                      return false
                    }
                    return try {
                      val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                      context.startActivity(intent)
                      true
                    } catch (e: Exception) {
                      false
                    }
                  }
                }

            webChromeClient =
                object : WebChromeClient() {
                  override fun onShowFileChooser(
                      webView: WebView?,
                      filePathCallback: ValueCallback<Array<Uri>>?,
                      fileChooserParams: FileChooserParams?
                  ): Boolean {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = filePathCallback

                    return try {
                      val intent =
                          fileChooserParams?.createIntent()
                              ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                                type = "image/*"
                                addCategory(Intent.CATEGORY_OPENABLE)
                              }
                      fileChooserLauncher.launch(intent)
                      true
                    } catch (e: Exception) {
                      fileUploadCallback?.onReceiveValue(null)
                      fileUploadCallback = null
                      false
                    }
                  }
                }

            loadUrl("file:///android_asset/index.html")
          }
        }

        DisposableEffect(webView) {
          val backCallback =
              object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                  if (webView.canGoBack()) {
                    webView.goBack()
                  } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                  }
                }
              }
          onBackPressedDispatcher.addCallback(backCallback)
          onDispose {
            backCallback.remove()
            webView.destroy()
          }
        }

        Box(
            modifier =
                Modifier.fillMaxSize()
                    .background(androidx.compose.ui.graphics.Color(0xFF12, 0xFF12, 0xFF14))
                    .statusBarsPadding()
                    .navigationBarsPadding()) {
              AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
            }
      }
    }
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

