package com.example.storage

import android.content.Context
import com.example.model.DailyRecord
import com.example.model.UserStats
import org.json.JSONObject

class GamePreferences(context: Context) {
    private val prefs = context.getSharedPreferences("guess_the_image_prefs", Context.MODE_PRIVATE)

    fun loadStats(): UserStats {
        val name = prefs.getString("player_name", null) ?: ("Player_" + (1000..9999).random())
        val avatar = prefs.getString("player_avatar", "🎮") ?: "🎮"
        val title = prefs.getString("player_title", "Novice Sleuth") ?: "Novice Sleuth"
        val theme = prefs.getString("profile_theme", "Amber") ?: "Amber"
        val xp = prefs.getInt("player_xp", 0)
        val score = prefs.getInt("score", 0)
        val coins = prefs.getInt("coins", 150)
        val currentLevel = prefs.getInt("current_level", 1)
        val streak = prefs.getInt("streak", 0)
        val highestStreak = prefs.getInt("highest_streak", 0)
        val solvedSet = prefs.getStringSet("solved_ids", emptySet()) ?: emptySet()
        val rawLevels = prefs.getStringSet("unlocked_levels", setOf("1")) ?: setOf("1")
        val unlockedLevels = rawLevels.mapNotNull { it.toIntOrNull() }.toSet().ifEmpty { setOf(1) }
        val totalGuesses = prefs.getInt("total_guesses", 0)
        val correctGuesses = if (prefs.contains("correct_guesses")) {
            prefs.getInt("correct_guesses", 0)
        } else {
            prefs.getInt("correctGuesses", 0)
        }
        val dailyStreak = prefs.getInt("daily_streak", 0)
        val highestDailyStreak = prefs.getInt("highest_daily_streak", dailyStreak)
        val lastDailyDate = prefs.getString("last_daily_date", null)
        val dailyHistoryJson = prefs.getString("daily_history", null)
        val claimedTasks = prefs.getStringSet("claimed_task_ids", emptySet()) ?: emptySet()
        val stage1Solves = prefs.getInt("stage1_solves", 0)
        val hintsUsed = prefs.getInt("hints_used", 0)
        val dailyCompletedCount = prefs.getInt("daily_completed_count", 0)

        val historyMap = mutableMapOf<String, DailyRecord>()
        if (dailyHistoryJson != null) {
            try {
                val json = JSONObject(dailyHistoryJson)
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val item = json.getJSONObject(key)
                    historyMap[key] = DailyRecord(
                        date = item.optString("date", key),
                        itemId = item.optString("itemId", ""),
                        solved = item.optBoolean("solved", false),
                        scoreEarned = item.optInt("scoreEarned", 0),
                        bonusPoints = item.optInt("bonusPoints", 0),
                        zoomStage = item.optInt("zoomStage", 1),
                        completedAt = item.optString("completedAt", "")
                    )
                }
            } catch (_: Exception) {}
        }

        return UserStats(
            playerName = name,
            avatar = avatar,
            playerTitle = title,
            profileTheme = theme,
            xp = xp,
            score = score,
            coins = coins,
            currentLevel = currentLevel,
            streak = streak,
            highestStreak = highestStreak,
            solvedIds = solvedSet,
            unlockedLevels = unlockedLevels,
            totalGuesses = totalGuesses,
            correctGuesses = correctGuesses,
            dailyStreak = dailyStreak,
            highestDailyStreak = highestDailyStreak,
            lastDailyDate = lastDailyDate,
            dailyHistory = historyMap,
            claimedTaskIds = claimedTasks,
            stage1Solves = stage1Solves,
            hintsUsed = hintsUsed,
            dailyCompletedCount = dailyCompletedCount
        )
    }

    fun saveStats(stats: UserStats, synchronous: Boolean = false): Boolean {
        val historyJson = JSONObject()
        stats.dailyHistory.forEach { (key, record) ->
            val obj = JSONObject()
            obj.put("date", record.date)
            obj.put("itemId", record.itemId)
            obj.put("solved", record.solved)
            obj.put("scoreEarned", record.scoreEarned)
            obj.put("bonusPoints", record.bonusPoints)
            obj.put("zoomStage", record.zoomStage)
            obj.put("completedAt", record.completedAt)
            historyJson.put(key, obj)
        }

        val editor = prefs.edit()
            .putString("player_name", stats.playerName)
            .putString("player_avatar", stats.avatar)
            .putString("player_title", stats.playerTitle)
            .putString("profile_theme", stats.profileTheme)
            .putInt("player_xp", stats.totalXp)
            .putInt("score", stats.score)
            .putInt("coins", stats.coins)
            .putInt("current_level", stats.currentLevel)
            .putInt("streak", stats.streak)
            .putInt("highest_streak", stats.highestStreak)
            .putStringSet("solved_ids", stats.solvedIds)
            .putStringSet("unlocked_levels", stats.unlockedLevels.map { it.toString() }.toSet())
            .putInt("total_guesses", stats.totalGuesses)
            .putInt("correct_guesses", stats.correctGuesses)
            .putInt("correctGuesses", stats.correctGuesses)
            .putInt("daily_streak", stats.dailyStreak)
            .putInt("highest_daily_streak", stats.highestDailyStreak)
            .putString("last_daily_date", stats.lastDailyDate)
            .putString("daily_history", historyJson.toString())
            .putStringSet("claimed_task_ids", stats.claimedTaskIds)
            .putInt("stage1_solves", stats.stage1Solves)
            .putInt("hints_used", stats.hintsUsed)
            .putInt("daily_completed_count", stats.dailyCompletedCount)

        return if (synchronous) {
            editor.commit()
        } else {
            editor.apply()
            true
        }
    }

    fun getSolvedIds(): Set<String> {
        return prefs.getStringSet("solved_ids", emptySet()) ?: emptySet()
    }

    fun markSolved(id: String) {
        val current = getSolvedIds().toMutableSet()
        current.add(id)
        prefs.edit().putStringSet("solved_ids", current).apply()
    }

    fun isDailyReminderEnabled(): Boolean {
        return prefs.getBoolean("daily_reminder_enabled", true)
    }

    fun setDailyReminderEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("daily_reminder_enabled", enabled).apply()
    }
}
