package com.example.utils

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateFormatters {
    private val isoFormat: SimpleDateFormat
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private val displayDateTimeFormat: SimpleDateFormat
        get() = SimpleDateFormat("yyyy/MM/dd - hh:mm a", Locale.forLanguageTag("ar"))

    private val fileTimestampFormat: SimpleDateFormat
        get() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    fun todayIso(): String = isoFormat.format(Date())

    fun millisToIso(millis: Long): String = isoFormat.format(Date(millis))

    fun isoToMillis(iso: String): Long? = runCatching {
        if (iso.isBlank()) null else isoFormat.parse(iso)?.time
    }.getOrNull()

    fun formatTimestampArabic(millis: Long): String = displayDateTimeFormat.format(Date(millis))

    fun fileTimestamp(): String = fileTimestampFormat.format(Date())
}

object CurrencyFormatters {
    private val decimalFormat: DecimalFormat by lazy {
        val symbols = DecimalFormatSymbols(Locale.US)
        DecimalFormat("#,##0.##", symbols)
    }

    fun formatMoney(amount: Double): String = decimalFormat.format(amount)

    fun formatMoneyWithCurrency(amount: Double): String = decimalFormat.format(amount)
}
