package com.example.alfatihaquiz

import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebSettings

class MainActivity: Activity(){
 override fun onCreate(savedInstanceState: Bundle?){
  super.onCreate(savedInstanceState)
  val w=WebView(this)
  w.settings.javaScriptEnabled=true
  w.settings.domStorageEnabled=true
  w.settings.cacheMode=WebSettings.LOAD_DEFAULT
  w.loadUrl("file:///android_asset/index.html")
  setContentView(w)
 }
}