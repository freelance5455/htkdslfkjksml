package com.example.keyboard.ui

import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.example.keyboard.KeyboardPalette
import java.io.File
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun KeyboardThemeBackground(
    palette: KeyboardPalette,
    aliveMotionEnabled: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clipToBounds()
            .background(palette.background)
    ) {
        // 1. Optional Imported Image Background
        val imgPath = palette.backgroundImagePath
        if (!imgPath.isNullOrBlank() && File(imgPath).exists()) {
            AsyncImage(
                model = File(imgPath),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
            // Soft readability veil
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        if (palette.isDark) Color.Black.copy(alpha = 0.28f)
                        else Color.White.copy(alpha = 0.16f)
                    )
            )
        }

        // 2. Optional Imported Looping Video Background
        val vidPath = palette.backgroundVideoPath
        if (!vidPath.isNullOrBlank() && File(vidPath).exists()) {
            LoopingBackgroundVideo(
                videoPath = vidPath,
                modifier = Modifier.matchParentSize()
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        if (palette.isDark) Color.Black.copy(alpha = 0.30f)
                        else Color.White.copy(alpha = 0.18f)
                    )
            )
        }

        // 3. Optional "Alive Leaf" gentle organic breathing & drifting botanical light
        if (palette.aliveLeafEffect && aliveMotionEnabled) {
            AliveLeafAmbientLayer(
                accent = palette.accent,
                modifier = Modifier.matchParentSize()
            )
        }

        content()
    }
}

@Composable
private fun LoopingBackgroundVideo(
    videoPath: String,
    modifier: Modifier = Modifier
) {
    val holder = remember(videoPath) {
        object {
            var player: MediaPlayer? = null
            var surface: Surface? = null

            fun release() {
                try {
                    player?.stop()
                } catch (_: Throwable) {
                }
                try {
                    player?.release()
                } catch (_: Throwable) {
                }
                player = null
                try {
                    surface?.release()
                } catch (_: Throwable) {
                }
                surface = null
            }
        }
    }

    DisposableEffect(videoPath) {
        onDispose { holder.release() }
    }

    AndroidView(
        modifier = modifier.clipToBounds(),
        factory = { ctx ->
            TextureView(ctx).apply {
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(
                        st: SurfaceTexture,
                        width: Int,
                        height: Int
                    ) {
                        try {
                            val s = Surface(st)
                            holder.surface = s
                            val mp = MediaPlayer().apply {
                                setDataSource(videoPath)
                                setSurface(s)
                                isLooping = true
                                setVolume(0f, 0f)
                                setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)
                                setOnPreparedListener { it.start() }
                                prepareAsync()
                            }
                            holder.player = mp
                        } catch (_: Throwable) {
                        }
                    }

                    override fun onSurfaceTextureSizeChanged(
                        st: SurfaceTexture,
                        width: Int,
                        height: Int
                    ) {}

                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                        holder.release()
                        return true
                    }

                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        }
    )
}

@Composable
private fun AliveLeafAmbientLayer(
    accent: Color,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "alive_leaf")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "leaf_drift"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        // Soft organic breathing glow
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = 0.14f), Color.Transparent),
                center = Offset(
                    x = w * (0.5f + 0.18f * cos(drift)),
                    y = h * (0.4f + 0.15f * sin(drift))
                ),
                radius = w * 0.7f
            )
        )

        // Delicate drifting minimalist leaf silhouettes
        val seeds = listOf(0.15f to 0.25f, 0.48f to 0.65f, 0.78f to 0.30f, 0.88f to 0.72f)
        seeds.forEachIndexed { idx, (sx, sy) ->
            val cx = w * ((sx + 0.04f * sin(drift + idx * 1.4f)).coerceIn(0.05f, 0.95f))
            val cy = h * ((sy + 0.06f * cos(drift + idx * 1.1f)).coerceIn(0.1f, 0.9f))
            val angle = (Math.toDegrees(drift.toDouble()).toFloat() * 0.25f) + idx * 42f

            rotate(degrees = angle, pivot = Offset(cx, cy)) {
                val leafPath = Path().apply {
                    moveTo(cx, cy - 16f)
                    quadraticTo(cx + 12f, cy, cx, cy + 16f)
                    quadraticTo(cx - 12f, cy, cx, cy - 16f)
                    close()
                }
                drawPath(
                    path = leafPath,
                    color = accent.copy(alpha = 0.13f)
                )
            }
        }
    }
}
