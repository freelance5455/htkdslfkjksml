package com.example.keyboard.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.KeyboardReturn
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ai.AiWriteTone
import com.example.data.KeycapStyle
import com.example.data.VelvetSettings
import com.example.keyboard.KeyboardLayouts
import com.example.keyboard.KeyboardPalette
import com.example.keyboard.SwipeDecoder
import com.example.keyboard.resolveKeyboardFontFamily
import com.example.keyboard.resolveKeyboardPalette
import kotlin.math.hypot
import kotlin.math.roundToInt

private val SymbolsRow1 = listOf('1', '2', '3', '4', '5', '6', '7', '8', '9', '0')
private val SymbolsRow2 = listOf('-', '/', ':', ';', '(', ')', '$', '&', '@', '"')
private val SymbolsRow3 = listOf('.', ',', '?', '!', '\'', '#', '%')

private val ExtSymbolsRow1 = listOf('[', ']', '{', '}', '#', '%', '^', '*', '+', '=')
private val ExtSymbolsRow2 = listOf('_', '\\', '|', '~', '<', '>', '€', '£', '¥', '•')
private val ExtSymbolsRow3 = listOf('.', ',', '?', '!', '\'', '`', '°')

@Composable
fun VelvetKeyboardView(
    controller: KeyboardSessionController,
    settings: VelvetSettings,
    showImeSwitcher: Boolean = false,
    showSettingsShortcut: Boolean = true,
    applyNavigationBarsPadding: Boolean = false,
    actionLabel: String = "Return",
    modifier: Modifier = Modifier
) {
    val systemDark = isSystemInDarkTheme()
    val palette = remember(settings, systemDark) {
        resolveKeyboardPalette(settings, systemDark)
    }
    val keyFontFamily = remember(settings.fontId) {
        resolveKeyboardFontFamily(settings.fontId)
    }
    val currentView = LocalView.current

    val panelMode by controller.panelMode.collectAsStateWithLifecycle()
    val shiftState by controller.shiftState.collectAsStateWithLifecycle()
    val predictions by controller.predictions.collectAsStateWithLifecycle()
    val toolsExpanded by controller.toolsExpanded.collectAsStateWithLifecycle()
    val voiceState by controller.voiceState.collectAsStateWithLifecycle()
    val voicePartialText by controller.voicePartialText.collectAsStateWithLifecycle()
    val voiceRmsLevel by controller.voiceRmsLevel.collectAsStateWithLifecycle()
    val isPolishing by controller.isPolishing.collectAsStateWithLifecycle()
    val aiAssistOpen by controller.aiAssistOpen.collectAsStateWithLifecycle()
    val toastMessage by controller.toastMessage.collectAsStateWithLifecycle()

    KeyboardThemeBackground(
        palette = palette,
        aliveMotionEnabled = settings.aliveMotionEnabled,
        modifier = modifier
            .fillMaxWidth()
            .clipToBounds()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (applyNavigationBarsPadding) {
                        Modifier.windowInsetsPadding(
                            WindowInsets.navigationBars.only(WindowInsetsSides.Bottom)
                        )
                    } else {
                        Modifier
                    }
                )
                .padding(bottom = 6.dp)
        ) {
            // Single Minimalist Gboard-Style Top Strip (Tools / Predictions / Inline Voice)
            GboardStyleTopStrip(
                palette = palette,
                fontFamily = keyFontFamily,
                settings = settings,
                panelMode = panelMode,
                toolsExpanded = toolsExpanded,
                aiAssistOpen = aiAssistOpen,
                predictions = predictions,
                voiceState = voiceState,
                voicePartialText = voicePartialText,
                voiceRmsLevel = voiceRmsLevel,
                isPolishing = isPolishing,
                toastMessage = toastMessage,
                showSettingsShortcut = showSettingsShortcut,
                onToggleTools = { controller.setToolsExpanded(!toolsExpanded) },
                onToggleEmoji = {
                    controller.setPanelMode(
                        if (panelMode == KeyboardPanelMode.EMOJI) KeyboardPanelMode.QWERTY
                        else KeyboardPanelMode.EMOJI
                    )
                },
                onToggleClipboard = {
                    controller.setPanelMode(
                        if (panelMode == KeyboardPanelMode.CLIPBOARD) KeyboardPanelMode.QWERTY
                        else KeyboardPanelMode.CLIPBOARD
                    )
                },
                onCycleFont = { controller.cycleFontQuick(settings.fontId) },
                onToggleDark = { controller.toggleDarkModeQuick(palette.isDark) },
                onToggleAiAssist = { controller.toggleAiAssist() },
                onSpeakText = { controller.speakCurrentText(settings) },
                onSelectPrediction = { word ->
                    controller.onPredictionSelected(word, settings, currentView)
                },
                onToggleInlineVoice = { controller.toggleInlineVoice(settings, currentView) },
                onCancelVoice = { controller.cancelInlineVoice() },
                onOpenSettings = { controller.openSettingsIfAvailable() }
            )

            // Compact 1-row Inline Velvet AI Grammar & Auto-Write Strip (keeps keys visible!)
            if (aiAssistOpen && voiceState == InlineVoiceState.Idle) {
                InlineVelvetAiRow(
                    palette = palette,
                    isBusy = isPolishing,
                    onFixGrammar = { controller.fixGrammarCurrentText(settings, currentView) },
                    onAutoWrite = { controller.autoGenerateFromCurrentText(settings, currentView) },
                    onMakeBetter = { controller.polishCurrentText(settings, currentView, AiWriteTone.NATURAL) },
                    onTonePro = { controller.polishCurrentText(settings, currentView, AiWriteTone.PROFESSIONAL) },
                    onToneCasual = { controller.polishCurrentText(settings, currentView, AiWriteTone.CASUAL) },
                    onToneShorter = { controller.polishCurrentText(settings, currentView, AiWriteTone.SHORTER) }
                )
            }

            // Main Panel (QWERTY / Symbols / Emoji / Clipboard)
            AnimatedContent(
                targetState = panelMode,
                transitionSpec = { fadeIn(tween(140)) togetherWith fadeOut(tween(120)) },
                label = "keyboard_panel_mode"
            ) { mode ->
                when (mode) {
                    KeyboardPanelMode.EMOJI -> {
                        EmojiKeyboardPanel(
                            palette = palette,
                            settings = settings,
                            onEmojiTap = { symbol ->
                                controller.onEmojiSelected(symbol, settings, currentView)
                            },
                            onAddCustomEmoji = { sym, lbl -> controller.addCustomEmoji(sym, lbl) },
                            onBackspace = { controller.onBackspace(settings, currentView) },
                            onReturnToQwerty = { controller.setPanelMode(KeyboardPanelMode.QWERTY) }
                        )
                    }

                    KeyboardPanelMode.CLIPBOARD -> {
                        ClipboardKeyboardPanel(
                            palette = palette,
                            clips = settings.clipboardHistory,
                            onPasteClip = { text ->
                                controller.onPasteClipboard(text, settings, currentView)
                            },
                            onTogglePin = { id -> controller.togglePinClip(id) },
                            onDeleteClip = { id -> controller.deleteClip(id) },
                            onClearUnpinned = { controller.clearUnpinnedClips() },
                            onSyncClipboard = { controller.syncSystemClipboard() },
                            onReturnToQwerty = { controller.setPanelMode(KeyboardPanelMode.QWERTY) }
                        )
                    }

                    KeyboardPanelMode.QWERTY -> {
                        QwertyKeyboardGrid(
                            palette = palette,
                            fontFamily = keyFontFamily,
                            settings = settings,
                            shiftState = shiftState,
                            showImeSwitcher = showImeSwitcher,
                            actionLabel = actionLabel,
                            onKeyTap = { ch -> controller.onKeyTap(ch, settings, currentView) },
                            onAccentTap = { ch -> controller.onAccentTap(ch, settings, currentView) },
                            onSwipeDecoded = { candidates ->
                                controller.onSwipeDecoded(candidates, settings, currentView)
                            },
                            onShiftTap = { controller.onShiftTap(settings, currentView) },
                            onBackspace = { controller.onBackspace(settings, currentView) },
                            onSwitchToSymbols = { controller.setPanelMode(KeyboardPanelMode.SYMBOLS) },
                            onCycleLanguage = {
                                controller.cycleLanguageQuick(settings, currentView)
                            },
                            onSpaceTap = { controller.onSpaceTap(settings, currentView) },
                            onReturnTap = { controller.onReturn(settings, currentView) }
                        )
                    }

                    KeyboardPanelMode.SYMBOLS, KeyboardPanelMode.SYMBOLS_EXT -> {
                        SymbolsKeyboardGrid(
                            palette = palette,
                            fontFamily = keyFontFamily,
                            settings = settings,
                            isExtended = mode == KeyboardPanelMode.SYMBOLS_EXT,
                            showImeSwitcher = showImeSwitcher,
                            actionLabel = actionLabel,
                            onKeyTap = { ch -> controller.onKeyTap(ch, settings, currentView) },
                            onToggleExtended = {
                                controller.setPanelMode(
                                    if (mode == KeyboardPanelMode.SYMBOLS) KeyboardPanelMode.SYMBOLS_EXT
                                    else KeyboardPanelMode.SYMBOLS
                                )
                            },
                            onBackspace = { controller.onBackspace(settings, currentView) },
                            onReturnToAbc = { controller.setPanelMode(KeyboardPanelMode.QWERTY) },
                            onCycleLanguage = {
                                controller.cycleLanguageQuick(settings, currentView)
                            },
                            onSpaceTap = { controller.onSpaceTap(settings, currentView) },
                            onReturnTap = { controller.onReturn(settings, currentView) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GboardStyleTopStrip(
    palette: KeyboardPalette,
    fontFamily: FontFamily,
    settings: VelvetSettings,
    panelMode: KeyboardPanelMode,
    toolsExpanded: Boolean,
    aiAssistOpen: Boolean,
    predictions: List<String>,
    voiceState: InlineVoiceState,
    voicePartialText: String,
    voiceRmsLevel: Float,
    isPolishing: Boolean,
    toastMessage: String?,
    showSettingsShortcut: Boolean,
    onToggleTools: () -> Unit,
    onToggleEmoji: () -> Unit,
    onToggleClipboard: () -> Unit,
    onCycleFont: () -> Unit,
    onToggleDark: () -> Unit,
    onToggleAiAssist: () -> Unit,
    onSpeakText: () -> Unit,
    onSelectPrediction: (String) -> Unit,
    onToggleInlineVoice: () -> Unit,
    onCancelVoice: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .background(palette.toolbarBg)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Inline Gboard-Style Voice Dictation Mode (no separate menu!)
        if (voiceState != InlineVoiceState.Idle) {
            val pulseScale by animateFloatAsState(
                targetValue = 1f + (voiceRmsLevel * 0.25f),
                animationSpec = tween(80),
                label = "mic_pulse"
            )
            val inf = rememberInfiniteTransition(label = "voice_dot")
            val dotAlpha by inf.animateFloat(
                initialValue = 0.4f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse),
                label = "dot_alpha"
            )

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(palette.specialKeyBg)
                    .clickable(onClick = onCancelVoice)
                    .testTag("inline_voice_cancel"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancel voice",
                    tint = palette.specialKeyText,
                    modifier = Modifier.size(16.dp)
                )
            }

            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(17.dp))
                    .background(palette.accent.copy(alpha = 0.14f))
                    .border(1.dp, palette.accent.copy(alpha = 0.45f), RoundedCornerShape(17.dp))
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (voiceState) {
                    InlineVoiceState.Listening -> {
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .scale(pulseScale)
                                .clip(CircleShape)
                                .background(palette.accent.copy(alpha = dotAlpha))
                        )
                        Text(
                            text = voicePartialText.ifBlank { "Listening (${settings.activeLanguage.shortCode})... speak & tap ✓" },
                            color = palette.keyText,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    InlineVoiceState.Processing -> {
                        CircularProgressIndicator(
                            color = palette.accent,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Velvet AI polishing speech...",
                            color = palette.keyText,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    is InlineVoiceState.Error -> {
                        Text(
                            text = voiceState.message,
                            color = palette.keyText,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    InlineVoiceState.Idle -> Unit
                }
            }

            // Done / Retry button
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .scale(if (voiceState == InlineVoiceState.Listening) pulseScale else 1f)
                    .clip(CircleShape)
                    .background(palette.accent)
                    .clickable(
                        enabled = voiceState != InlineVoiceState.Processing,
                        onClick = onToggleInlineVoice
                    )
                    .testTag("inline_voice_action"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (voiceState) {
                        InlineVoiceState.Listening -> Icons.Default.Check
                        is InlineVoiceState.Error -> Icons.Default.Mic
                        else -> Icons.Default.Stop
                    },
                    contentDescription = "Finish or retry voice",
                    tint = palette.onAccent,
                    modifier = Modifier.size(18.dp)
                )
            }
            return@Row
        }

        // Standard Gboard-Style Strip: Left toggle + Predictions OR Minimalist Tools + Right Mic
        if (settings.predictionsEnabled) {
            StripIconButton(
                palette = palette,
                active = toolsExpanded,
                onClick = onToggleTools,
                modifier = Modifier.testTag("strip_toggle_tools")
            ) {
                Icon(
                    imageVector = if (toolsExpanded) Icons.Default.ChevronLeft else Icons.Default.Apps,
                    contentDescription = "Toggle quick tools",
                    tint = palette.specialKeyText,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        if (!toastMessage.isNullOrBlank()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(30.dp)
                    .clip(CircleShape)
                    .background(palette.accent.copy(alpha = 0.16f))
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = toastMessage,
                    color = palette.accent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        } else if (toolsExpanded || !settings.predictionsEnabled) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StripIconButton(
                    palette = palette,
                    active = panelMode == KeyboardPanelMode.EMOJI,
                    onClick = onToggleEmoji,
                    modifier = Modifier.testTag("toolbar_emoji_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEmotions,
                        contentDescription = "Emoji library",
                        tint = if (panelMode == KeyboardPanelMode.EMOJI) palette.accent else palette.specialKeyText,
                        modifier = Modifier.size(19.dp)
                    )
                }

                StripIconButton(
                    palette = palette,
                    active = panelMode == KeyboardPanelMode.CLIPBOARD,
                    onClick = onToggleClipboard,
                    modifier = Modifier.testTag("toolbar_clipboard_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentPaste,
                        contentDescription = "Clipboard history",
                        tint = if (panelMode == KeyboardPanelMode.CLIPBOARD) palette.accent else palette.specialKeyText,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .height(28.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.predictionPillBg)
                        .clickable(onClick = onCycleFont)
                        .padding(horizontal = 9.dp)
                        .testTag("toolbar_font_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Aa",
                        color = palette.keyText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }

                StripIconButton(
                    palette = palette,
                    active = palette.isDark,
                    onClick = onToggleDark,
                    modifier = Modifier.testTag("toolbar_dark_button")
                ) {
                    Icon(
                        imageVector = if (palette.isDark) Icons.Default.Bedtime else Icons.Default.WbSunny,
                        contentDescription = "Toggle late-night dark mode",
                        tint = if (palette.isDark) palette.accent else palette.specialKeyText,
                        modifier = Modifier.size(18.dp)
                    )
                }

                StripIconButton(
                    palette = palette,
                    active = aiAssistOpen,
                    onClick = onToggleAiAssist,
                    modifier = Modifier.testTag("toolbar_ai_polish_button")
                ) {
                    if (isPolishing) {
                        CircularProgressIndicator(
                            color = palette.accent,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(14.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Velvet AI Grammar & Writer",
                            tint = palette.accent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                StripIconButton(
                    palette = palette,
                    active = false,
                    onClick = onSpeakText,
                    modifier = Modifier.testTag("toolbar_tts_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Read text aloud with AI voice",
                        tint = palette.specialKeyText,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (showSettingsShortcut) {
                    StripIconButton(
                        palette = palette,
                        active = false,
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("toolbar_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Keyboard settings",
                            tint = palette.specialKeyText,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        } else {
            // 3-Slot iOS QuickType Prediction Strip
            val s0 = predictions.getOrNull(0) ?: "I"
            val s1 = predictions.getOrNull(1) ?: "The"
            val s2 = predictions.getOrNull(2) ?: "Hey"

            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                PredictionSlot(
                    text = s1,
                    isPrimary = false,
                    palette = palette,
                    fontFamily = fontFamily,
                    onClick = { onSelectPrediction(s1) },
                    modifier = Modifier.weight(1f).testTag("prediction_slot_left")
                )
                PredictionSlot(
                    text = s0,
                    isPrimary = true,
                    palette = palette,
                    fontFamily = fontFamily,
                    onClick = { onSelectPrediction(s0) },
                    modifier = Modifier.weight(1.1f).testTag("prediction_slot_center")
                )
                PredictionSlot(
                    text = s2,
                    isPrimary = false,
                    palette = palette,
                    fontFamily = fontFamily,
                    onClick = { onSelectPrediction(s2) },
                    modifier = Modifier.weight(1f).testTag("prediction_slot_right")
                )
            }

            StripIconButton(
                palette = palette,
                active = aiAssistOpen,
                onClick = onToggleAiAssist,
                modifier = Modifier.testTag("strip_ai_polish_button")
            ) {
                if (isPolishing) {
                    CircularProgressIndicator(
                        color = palette.accent,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(14.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Velvet AI Grammar & Writer",
                        tint = palette.accent,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
        }

        // Gboard-style Always-Accessible Right Mic Button
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(palette.accent.copy(alpha = 0.16f))
                .clickable(onClick = onToggleInlineVoice)
                .testTag("toolbar_voice_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Velvet AI voice dictation",
                tint = palette.accent,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun InlineVelvetAiRow(
    palette: KeyboardPalette,
    isBusy: Boolean,
    onFixGrammar: () -> Unit,
    onAutoWrite: () -> Unit,
    onMakeBetter: () -> Unit,
    onTonePro: () -> Unit,
    onToneCasual: () -> Unit,
    onToneShorter: () -> Unit
) {
    val scroll = rememberScrollState()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp)
            .background(palette.toolbarBg)
            .horizontalScroll(scroll)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        AiActionChip("Fix Grammar", isBusy, palette, true, onFixGrammar, "ai_chip_grammar")
        AiActionChip("Auto-Write", isBusy, palette, true, onAutoWrite, "ai_chip_autowrite")
        AiActionChip("Make Better", isBusy, palette, false, onMakeBetter, "ai_chip_better")
        AiActionChip("Pro Tone", isBusy, palette, false, onTonePro, "ai_chip_pro")
        AiActionChip("Casual", isBusy, palette, false, onToneCasual, "ai_chip_casual")
        AiActionChip("Shorter", isBusy, palette, false, onToneShorter, "ai_chip_shorter")
    }
}

@Composable
private fun AiActionChip(
    label: String,
    disabled: Boolean,
    palette: KeyboardPalette,
    highlighted: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Box(
        modifier = Modifier
            .height(28.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (highlighted) palette.accent.copy(alpha = 0.22f)
                else palette.predictionPillBg
            )
            .border(
                width = 0.8.dp,
                color = if (highlighted) palette.accent.copy(alpha = 0.55f) else palette.keyBorder,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(enabled = !disabled, onClick = onClick)
            .padding(horizontal = 11.dp)
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (highlighted) palette.accent else palette.keyText,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

@Composable
private fun StripIconButton(
    palette: KeyboardPalette,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (active) palette.accent.copy(alpha = 0.18f) else palette.toolbarBg.copy(alpha = 0f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
private fun PredictionSlot(
    text: String,
    isPrimary: Boolean,
    palette: KeyboardPalette,
    fontFamily: FontFamily,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(30.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isPrimary) palette.predictionActiveBg else palette.predictionPillBg)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (isPrimary) palette.keyText else palette.mutedText,
            fontFamily = fontFamily,
            fontSize = 13.5.sp,
            fontWeight = if (isPrimary) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun QwertyKeyboardGrid(
    palette: KeyboardPalette,
    fontFamily: FontFamily,
    settings: VelvetSettings,
    shiftState: ShiftState,
    showImeSwitcher: Boolean,
    actionLabel: String,
    onKeyTap: (Char) -> Unit,
    onAccentTap: (Char) -> Unit,
    onSwipeDecoded: (List<String>) -> Unit,
    onShiftTap: () -> Unit,
    onBackspace: () -> Unit,
    onSwitchToSymbols: () -> Unit,
    onCycleLanguage: () -> Unit,
    onSpaceTap: () -> Unit,
    onReturnTap: () -> Unit
) {
    val layout = remember(settings.activeLanguage) {
        KeyboardLayouts.layoutFor(settings.activeLanguage)
    }
    val keyHeight = (44f * settings.keyHeightScale).coerceIn(38f, 58f).dp
    val keyShape = remember(palette.keycapStyle, palette.cornerRadiusDp) {
        keycapShapeFor(palette.keycapStyle, palette.cornerRadiusDp)
    }
    val touchSlop = LocalViewConfiguration.current.touchSlop
    val density = LocalDensity.current

    var gridBoundsInRoot by remember { mutableStateOf(Rect.Zero) }
    var gridSizePx by remember { mutableStateOf(IntSize.Zero) }
    val keyRectsLocal = remember(settings.activeLanguage) { mutableStateMapOf<Char, Rect>() }
    val keyCentersLocal = remember(settings.activeLanguage) { mutableStateMapOf<Char, Offset>() }

    val swipePoints = remember { mutableStateListOf<Offset>() }
    var activeSwipe by remember { mutableStateOf(false) }
    var pressedKey by remember { mutableStateOf<Char?>(null) }
    var activeAccentsForKey by remember { mutableStateOf<Pair<Char, List<Char>>?>(null) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 3.dp, vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .onSizeChanged { gridSizePx = it }
                    .onGloballyPositioned { coords ->
                        if (coords.isAttached) {
                            gridBoundsInRoot = coords.boundsInRoot()
                        }
                    }
                    .pointerInput(settings.swipeTypingEnabled, settings.activeLanguage) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val startPos = down.position
                            val startKey = keyRectsLocal.entries
                                .firstOrNull { it.value.contains(startPos) }?.key
                                ?: return@awaitEachGesture

                            down.consume()
                            activeAccentsForKey = null
                            pressedKey = startKey
                            swipePoints.clear()
                            swipePoints.add(startPos)
                            activeSwipe = false
                            var totalTravel = 0f
                            var lastPos = startPos
                            val downTime = System.currentTimeMillis()
                            var accentTriggered = false

                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull() ?: break
                                if (!change.pressed) {
                                    change.consume()
                                    break
                                }
                                val curr = change.position
                                val step = hypot(curr.x - lastPos.x, curr.y - lastPos.y)
                                totalTravel += step
                                lastPos = curr

                                if (!activeSwipe && totalTravel < touchSlop &&
                                    System.currentTimeMillis() - downTime > 380L
                                ) {
                                    val variants = KeyboardLayouts.accentVariants[startKey]
                                    if (!variants.isNullOrEmpty()) {
                                        activeAccentsForKey = startKey to variants
                                        accentTriggered = true
                                    }
                                }

                                if (!accentTriggered && settings.swipeTypingEnabled && totalTravel > touchSlop * 1.4f) {
                                    activeSwipe = true
                                    pressedKey = null
                                    if (step > 4f) {
                                        swipePoints.add(curr)
                                    }
                                } else if (!activeSwipe && !accentTriggered) {
                                    val hoverKey = keyRectsLocal.entries
                                        .firstOrNull { it.value.contains(curr) }?.key
                                    if (hoverKey != null) pressedKey = hoverKey
                                }
                                change.consume()
                            }

                            if (accentTriggered) {
                                // Keep accent popup visible for user to tap a variant
                            } else if (activeSwipe && swipePoints.size >= 3) {
                                val decoded = SwipeDecoder.decode(
                                    points = swipePoints.toList(),
                                    measuredKeyCenters = keyCentersLocal.toMap(),
                                    language = settings.activeLanguage,
                                    learnedWords = if (settings.adaptToSlangEnabled) settings.learnedWords else emptyMap()
                                )
                                if (decoded.isNotEmpty()) {
                                    onSwipeDecoded(decoded)
                                }
                            } else {
                                val finalKey = keyRectsLocal.entries
                                    .firstOrNull { it.value.contains(lastPos) }?.key ?: startKey
                                onKeyTap(finalKey)
                            }

                            pressedKey = null
                            activeSwipe = false
                            swipePoints.clear()
                        }
                    }
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Row 1
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        layout.row1.forEach { ch ->
                            LetterKeyCap(
                                ch = ch,
                                shiftState = shiftState,
                                isPressed = pressedKey == ch,
                                palette = palette,
                                fontFamily = fontFamily,
                                keyShape = keyShape,
                                compactText = layout.row1.size >= 10,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(keyHeight)
                                    .onGloballyPositioned { coords ->
                                        if (coords.isAttached && gridBoundsInRoot != Rect.Zero) {
                                            val b = coords.boundsInRoot()
                                            val local = b.translate(-gridBoundsInRoot.left, -gridBoundsInRoot.top)
                                            keyRectsLocal[ch] = local
                                            keyCentersLocal[ch] = local.center
                                        }
                                    }
                            )
                        }
                    }

                    // Row 2
                    val row2Pad = if (layout.row2.size >= 10) 0.dp else 12.dp
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = row2Pad),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        layout.row2.forEach { ch ->
                            LetterKeyCap(
                                ch = ch,
                                shiftState = shiftState,
                                isPressed = pressedKey == ch,
                                palette = palette,
                                fontFamily = fontFamily,
                                keyShape = keyShape,
                                compactText = layout.row2.size >= 10,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(keyHeight)
                                    .onGloballyPositioned { coords ->
                                        if (coords.isAttached && gridBoundsInRoot != Rect.Zero) {
                                            val b = coords.boundsInRoot()
                                            val local = b.translate(-gridBoundsInRoot.left, -gridBoundsInRoot.top)
                                            keyRectsLocal[ch] = local
                                            keyCentersLocal[ch] = local.center
                                        }
                                    }
                            )
                        }
                    }

                    // Row 3
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SpecialKeyCap(
                            palette = palette,
                            keyShape = keyShape,
                            highlighted = shiftState != ShiftState.OFF,
                            onClick = onShiftTap,
                            modifier = Modifier
                                .weight(1.35f)
                                .height(keyHeight)
                                .testTag("key_shift")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowUpward,
                                contentDescription = "Shift",
                                tint = when (shiftState) {
                                    ShiftState.CAPS_LOCK -> palette.accent
                                    ShiftState.SINGLE -> palette.keyText
                                    ShiftState.OFF -> palette.specialKeyText
                                },
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        layout.row3.forEach { ch ->
                            LetterKeyCap(
                                ch = ch,
                                shiftState = shiftState,
                                isPressed = pressedKey == ch,
                                palette = palette,
                                fontFamily = fontFamily,
                                keyShape = keyShape,
                                compactText = layout.row3.size >= 8,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(keyHeight)
                                    .onGloballyPositioned { coords ->
                                        if (coords.isAttached && gridBoundsInRoot != Rect.Zero) {
                                            val b = coords.boundsInRoot()
                                            val local = b.translate(-gridBoundsInRoot.left, -gridBoundsInRoot.top)
                                            keyRectsLocal[ch] = local
                                            keyCentersLocal[ch] = local.center
                                        }
                                    }
                            )
                        }

                        SpecialKeyCap(
                            palette = palette,
                            keyShape = keyShape,
                            highlighted = false,
                            onClick = onBackspace,
                            modifier = Modifier
                                .weight(1.35f)
                                .height(keyHeight)
                                .testTag("key_backspace")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                contentDescription = "Backspace",
                                tint = palette.specialKeyText,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Luminous Swipe Ribbon
                if (activeSwipe && swipePoints.size > 1) {
                    Canvas(modifier = Modifier.matchParentSize()) {
                        val path = Path().apply {
                            moveTo(swipePoints.first().x, swipePoints.first().y)
                            for (i in 1 until swipePoints.size) {
                                val prev = swipePoints[i - 1]
                                val curr = swipePoints[i]
                                quadraticTo(
                                    prev.x,
                                    prev.y,
                                    (prev.x + curr.x) / 2f,
                                    (prev.y + curr.y) / 2f
                                )
                            }
                        }
                        drawPath(
                            path = path,
                            color = palette.swipeTrail.copy(alpha = 0.25f),
                            style = Stroke(width = 20f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                        drawPath(
                            path = path,
                            color = palette.swipeTrail,
                            style = Stroke(width = 8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }
                }

                // iOS Key Preview Bubble (clamped inside horizontal bounds so edge keys never go off-screen)
                val activePopupChar = pressedKey
                val popupRect = activePopupChar?.let { keyRectsLocal[it] }
                if (settings.keyPopupEnabled && activePopupChar != null && popupRect != null && activeAccentsForKey == null) {
                    val label = if (shiftState != ShiftState.OFF) activePopupChar.uppercaseChar() else activePopupChar
                    val popupWidthPx = with(density) { 44.dp.toPx() }
                    val popupHeightPx = with(density) { 48.dp.toPx() }
                    val maxX = (gridSizePx.width - popupWidthPx - 2f).coerceAtLeast(2f)
                    val targetX = (popupRect.center.x - popupWidthPx / 2f).coerceIn(2f, maxX)
                    val targetY = (popupRect.top - popupHeightPx + 4f).coerceAtLeast(with(density) { -34.dp.toPx() })
                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    x = targetX.roundToInt(),
                                    y = targetY.roundToInt()
                                )
                            }
                            .size(width = 44.dp, height = 48.dp)
                            .shadow(8.dp, RoundedCornerShape(12.dp))
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.popupBg)
                            .border(1.dp, palette.keyBorder, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label.toString(),
                            color = palette.keyText,
                            fontFamily = fontFamily,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                    }
                }

                // Long-Press Accent Popover (measured & clamped inside grid width)
                val accentPair = activeAccentsForKey
                if (accentPair != null) {
                    val anchorRect = keyRectsLocal[accentPair.first] ?: Rect.Zero
                    var accentWidthPx by remember(accentPair.first) { mutableIntStateOf(0) }
                    val maxAccentWidthDp = with(density) {
                        ((gridSizePx.width - 16).coerceAtLeast(180)).toDp()
                    }
                    val maxX = (gridSizePx.width - accentWidthPx - 4f).coerceAtLeast(4f)
                    val clampedX = if (accentWidthPx > 0) {
                        (anchorRect.center.x - accentWidthPx / 2f).coerceIn(4f, maxX)
                    } else {
                        (anchorRect.left - 24f).coerceAtLeast(4f)
                    }
                    val popoverHeightPx = with(density) { 46.dp.toPx() }
                    val clampedY = (anchorRect.top - popoverHeightPx - 4f).coerceAtLeast(0f)

                    Row(
                        modifier = Modifier
                            .onSizeChanged { accentWidthPx = it.width }
                            .offset {
                                IntOffset(
                                    x = clampedX.roundToInt(),
                                    y = clampedY.roundToInt()
                                )
                            }
                            .widthIn(max = maxAccentWidthDp)
                            .shadow(10.dp, RoundedCornerShape(14.dp))
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.popupBg)
                            .border(1.dp, palette.accent.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        accentPair.second.forEach { variant ->
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        onAccentTap(variant)
                                        activeAccentsForKey = null
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (shiftState != ShiftState.OFF) variant.uppercase() else variant.toString(),
                                    color = palette.keyText,
                                    fontFamily = fontFamily,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close accents",
                            tint = palette.mutedText,
                            modifier = Modifier
                                .size(20.dp)
                                .clickable { activeAccentsForKey = null }
                        )
                    }
                }
            }

            BottomActionRow(
                palette = palette,
                fontFamily = fontFamily,
                keyShape = keyShape,
                keyHeight = keyHeight,
                leftSwitchLabel = "123",
                languageBadge = settings.activeLanguage.shortCode,
                showLanguageGlobe = settings.enabledLanguages.size > 1 || showImeSwitcher,
                actionLabel = actionLabel,
                onLeftSwitch = onSwitchToSymbols,
                onGlobeClick = onCycleLanguage,
                onSpaceClick = onSpaceTap,
                onPeriodClick = { onKeyTap('.') },
                onReturnClick = onReturnTap
            )
        }
    }
}

@Composable
private fun SymbolsKeyboardGrid(
    palette: KeyboardPalette,
    fontFamily: FontFamily,
    settings: VelvetSettings,
    isExtended: Boolean,
    showImeSwitcher: Boolean,
    actionLabel: String,
    onKeyTap: (Char) -> Unit,
    onToggleExtended: () -> Unit,
    onBackspace: () -> Unit,
    onReturnToAbc: () -> Unit,
    onCycleLanguage: () -> Unit,
    onSpaceTap: () -> Unit,
    onReturnTap: () -> Unit
) {
    val keyHeight = (44f * settings.keyHeightScale).coerceIn(38f, 58f).dp
    val keyShape = remember(palette.keycapStyle, palette.cornerRadiusDp) {
        keycapShapeFor(palette.keycapStyle, palette.cornerRadiusDp)
    }

    val r1 = if (isExtended) ExtSymbolsRow1 else SymbolsRow1
    val r2 = if (isExtended) ExtSymbolsRow2 else SymbolsRow2
    val r3 = if (isExtended) ExtSymbolsRow3 else SymbolsRow3

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 3.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            r1.forEach { ch ->
                TappableSymbolKey(
                    label = ch.toString(),
                    palette = palette,
                    fontFamily = fontFamily,
                    keyShape = keyShape,
                    onClick = { onKeyTap(ch) },
                    modifier = Modifier.weight(1f).height(keyHeight)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            r2.forEach { ch ->
                TappableSymbolKey(
                    label = ch.toString(),
                    palette = palette,
                    fontFamily = fontFamily,
                    keyShape = keyShape,
                    onClick = { onKeyTap(ch) },
                    modifier = Modifier.weight(1f).height(keyHeight)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            SpecialKeyCap(
                palette = palette,
                keyShape = keyShape,
                highlighted = isExtended,
                onClick = onToggleExtended,
                modifier = Modifier.weight(1.45f).height(keyHeight)
            ) {
                Text(
                    text = if (isExtended) "123" else "#+=",
                    color = palette.specialKeyText,
                    fontFamily = fontFamily,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            r3.forEach { ch ->
                TappableSymbolKey(
                    label = ch.toString(),
                    palette = palette,
                    fontFamily = fontFamily,
                    keyShape = keyShape,
                    onClick = { onKeyTap(ch) },
                    modifier = Modifier.weight(1f).height(keyHeight)
                )
            }

            SpecialKeyCap(
                palette = palette,
                keyShape = keyShape,
                highlighted = false,
                onClick = onBackspace,
                modifier = Modifier.weight(1.45f).height(keyHeight)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = palette.specialKeyText,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        BottomActionRow(
            palette = palette,
            fontFamily = fontFamily,
            keyShape = keyShape,
            keyHeight = keyHeight,
            leftSwitchLabel = "ABC",
            languageBadge = settings.activeLanguage.shortCode,
            showLanguageGlobe = settings.enabledLanguages.size > 1 || showImeSwitcher,
            actionLabel = actionLabel,
            onLeftSwitch = onReturnToAbc,
            onGlobeClick = onCycleLanguage,
            onSpaceClick = onSpaceTap,
            onPeriodClick = { onKeyTap('.') },
            onReturnClick = onReturnTap
        )
    }
}

@Composable
private fun BottomActionRow(
    palette: KeyboardPalette,
    fontFamily: FontFamily,
    keyShape: Shape,
    keyHeight: Dp,
    leftSwitchLabel: String,
    languageBadge: String,
    showLanguageGlobe: Boolean,
    actionLabel: String,
    onLeftSwitch: () -> Unit,
    onGlobeClick: () -> Unit,
    onSpaceClick: () -> Unit,
    onPeriodClick: () -> Unit,
    onReturnClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SpecialKeyCap(
            palette = palette,
            keyShape = keyShape,
            highlighted = false,
            onClick = onLeftSwitch,
            modifier = Modifier
                .weight(1.35f)
                .height(keyHeight)
                .testTag("key_mode_switch")
        ) {
            Text(
                text = leftSwitchLabel,
                color = palette.specialKeyText,
                fontFamily = fontFamily,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                softWrap = false
            )
        }

        if (showLanguageGlobe) {
            SpecialKeyCap(
                palette = palette,
                keyShape = keyShape,
                highlighted = false,
                onClick = onGlobeClick,
                modifier = Modifier
                    .weight(1.0f)
                    .height(keyHeight)
                    .testTag("key_language_globe")
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Switch keyboard language",
                    tint = palette.specialKeyText,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // Spacebar
        val spaceShadow = if (palette.keycapStyle == KeycapStyle.BORDERLESS) 0.dp else 1.5.dp
        Box(
            modifier = Modifier
                .weight(4.3f)
                .height(keyHeight)
                .shadow(spaceShadow, keyShape, ambientColor = palette.keyShadow)
                .clip(keyShape)
                .background(palette.keyBg)
                .border(0.6.dp, palette.keyBorder, keyShape)
                .clickable(onClick = onSpaceClick)
                .padding(horizontal = 6.dp)
                .testTag("key_space"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "$languageBadge • VelvetKey",
                color = palette.mutedText,
                fontFamily = fontFamily,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                softWrap = false
            )
        }

        TappableSymbolKey(
            label = ".",
            palette = palette,
            fontFamily = fontFamily,
            keyShape = keyShape,
            onClick = onPeriodClick,
            modifier = Modifier
                .weight(0.95f)
                .height(keyHeight)
                .testTag("key_period")
        )

        Box(
            modifier = Modifier
                .weight(1.75f)
                .height(keyHeight)
                .shadow(spaceShadow, keyShape, ambientColor = palette.keyShadow)
                .clip(keyShape)
                .background(palette.accent)
                .clickable(onClick = onReturnClick)
                .padding(horizontal = 4.dp)
                .testTag("key_return"),
            contentAlignment = Alignment.Center
        ) {
            if (actionLabel == "Return") {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardReturn,
                    contentDescription = "Return",
                    tint = palette.onAccent,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Text(
                    text = actionLabel,
                    color = palette.onAccent,
                    fontFamily = fontFamily,
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    softWrap = false
                )
            }
        }
    }
}

@Composable
private fun LetterKeyCap(
    ch: Char,
    shiftState: ShiftState,
    isPressed: Boolean,
    palette: KeyboardPalette,
    fontFamily: FontFamily,
    keyShape: Shape,
    compactText: Boolean = false,
    modifier: Modifier = Modifier
) {
    val label = if (shiftState != ShiftState.OFF) ch.uppercaseChar() else ch
    val tapScale by animateFloatAsState(
        targetValue = if (isPressed) 0.93f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
        label = "key_bounce"
    )
    val shadowElev = when {
        isPressed -> 0.dp
        palette.keycapStyle == KeycapStyle.BORDERLESS -> 0.dp
        palette.keycapStyle == KeycapStyle.ELEVATED_3D -> 3.dp
        else -> 1.2.dp
    }

    Box(
        modifier = modifier
            .scale(tapScale)
            .shadow(shadowElev, keyShape, ambientColor = palette.keyShadow)
            .clip(keyShape)
            .background(if (isPressed) palette.keyPressedBg else palette.keyBg)
            .border(
                width = if (palette.keycapStyle == KeycapStyle.FROSTED_GLASS) 1.dp else 0.6.dp,
                color = palette.keyBorder,
                shape = keyShape
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label.toString(),
            color = palette.keyText,
            fontFamily = fontFamily,
            fontSize = if (compactText) 18.5.sp else 20.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            softWrap = false
        )
    }
}

@Composable
private fun TappableSymbolKey(
    label: String,
    palette: KeyboardPalette,
    fontFamily: FontFamily,
    keyShape: Shape,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shadowElev = if (palette.keycapStyle == KeycapStyle.BORDERLESS) 0.dp else 1.2.dp
    Box(
        modifier = modifier
            .shadow(shadowElev, keyShape, ambientColor = palette.keyShadow)
            .clip(keyShape)
            .background(palette.keyBg)
            .border(0.6.dp, palette.keyBorder, keyShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = palette.keyText,
            fontFamily = fontFamily,
            fontSize = 18.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun SpecialKeyCap(
    palette: KeyboardPalette,
    keyShape: Shape,
    highlighted: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val shadowElev = if (palette.keycapStyle == KeycapStyle.BORDERLESS) 0.dp else 1.dp
    Box(
        modifier = modifier
            .shadow(shadowElev, keyShape, ambientColor = palette.keyShadow)
            .clip(keyShape)
            .background(if (highlighted) palette.keyBg else palette.specialKeyBg)
            .border(0.6.dp, palette.keyBorder, keyShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

private fun keycapShapeFor(style: KeycapStyle, radiusDp: Float): Shape = when (style) {
    KeycapStyle.PILL -> RoundedCornerShape(50)
    else -> RoundedCornerShape(radiusDp.dp)
}
