package com.example.keyboard

import com.example.data.KeyboardLanguage

data class LanguageKeyLayout(
    val row1: List<Char>,
    val row2: List<Char>,
    val row3: List<Char>,
    val isRtl: Boolean = false
)

object KeyboardLayouts {

    private val qwerty = LanguageKeyLayout(
        row1 = listOf('q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'),
        row2 = listOf('a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'),
        row3 = listOf('z', 'x', 'c', 'v', 'b', 'n', 'm')
    )

    private val spanish = LanguageKeyLayout(
        row1 = listOf('q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'),
        row2 = listOf('a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'ñ'),
        row3 = listOf('z', 'x', 'c', 'v', 'b', 'n', 'm')
    )

    private val french = LanguageKeyLayout(
        row1 = listOf('a', 'z', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'),
        row2 = listOf('q', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm'),
        row3 = listOf('w', 'x', 'c', 'v', 'b', 'n', 'é')
    )

    private val german = LanguageKeyLayout(
        row1 = listOf('q', 'w', 'e', 'r', 't', 'z', 'u', 'i', 'o', 'p'),
        row2 = listOf('a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'),
        row3 = listOf('y', 'x', 'c', 'v', 'b', 'n', 'm')
    )

    private val arabic = LanguageKeyLayout(
        row1 = listOf('ض', 'ص', 'ث', 'ق', 'ف', 'غ', 'ع', 'ه', 'خ', 'ح'),
        row2 = listOf('ش', 'س', 'ي', 'ب', 'ل', 'ا', 'ت', 'ن', 'م', 'ك'),
        row3 = listOf('ئ', 'ء', 'ؤ', 'ر', 'د', 'ى', 'ة', 'و', 'ز'),
        isRtl = true
    )

    fun layoutFor(language: KeyboardLanguage): LanguageKeyLayout = when (language) {
        KeyboardLanguage.EN, KeyboardLanguage.PT, KeyboardLanguage.IT -> qwerty
        KeyboardLanguage.ES -> spanish
        KeyboardLanguage.FR -> french
        KeyboardLanguage.DE -> german
        KeyboardLanguage.AR -> arabic
    }

    val accentVariants: Map<Char, List<Char>> = mapOf(
        'a' to listOf('á', 'à', 'â', 'ä', 'ã', 'å', 'æ'),
        'e' to listOf('é', 'è', 'ê', 'ë', '€'),
        'i' to listOf('í', 'ì', 'î', 'ï'),
        'o' to listOf('ó', 'ò', 'ô', 'ö', 'õ', 'ø', 'œ'),
        'u' to listOf('ú', 'ù', 'û', 'ü'),
        'n' to listOf('ñ', 'ń'),
        'c' to listOf('ç', 'ć', 'č'),
        's' to listOf('ß', 'ś', 'š'),
        'y' to listOf('ý', 'ÿ'),
        'z' to listOf('ž', 'ź', 'ż'),
        'ا' to listOf('أ', 'إ', 'آ'),
        'ه' to listOf('ة'),
        'ح' to listOf('ج'),
        'د' to listOf('ذ'),
        'ت' to listOf('ط'),
        'ز' to listOf('ظ')
    )
}
