package com.example.keyboard.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.VelvetSettings
import com.example.keyboard.EmojiCatalog
import com.example.keyboard.EmojiCategory
import com.example.keyboard.EmojiEntry
import com.example.keyboard.KeyboardPalette

@Composable
fun EmojiKeyboardPanel(
    palette: KeyboardPalette,
    settings: VelvetSettings,
    onEmojiTap: (String) -> Unit,
    onAddCustomEmoji: (symbol: String, label: String) -> Unit,
    onBackspace: () -> Unit,
    onReturnToQwerty: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf(EmojiCategory.IOS_CUSTOM) }
    var searchQuery by remember { mutableStateOf("") }
    var showAddInline by remember { mutableStateOf(false) }
    var newSymbol by remember { mutableStateOf("") }
    var newLabel by remember { mutableStateOf("") }

    val customEntries = remember(settings.customEmojis) {
        settings.customEmojis.map { EmojiEntry(it.symbol, it.label) }
    }

    val displayedEmojis = remember(selectedCategory, searchQuery, settings.recentEmojis, customEntries) {
        if (searchQuery.isNotBlank()) {
            EmojiCatalog.search(searchQuery, customEntries)
        } else {
            when (selectedCategory) {
                EmojiCategory.RECENTS -> settings.recentEmojis.map { EmojiEntry(it, "recent") }
                EmojiCategory.IOS_CUSTOM -> customEntries
                EmojiCategory.SMILEYS -> EmojiCatalog.smileys
                EmojiCategory.GESTURES -> EmojiCatalog.gestures
                EmojiCategory.ANIMALS -> EmojiCatalog.animals
                EmojiCategory.FOOD -> EmojiCatalog.food
                EmojiCategory.OBJECTS -> EmojiCatalog.objects
                EmojiCategory.SYMBOLS -> EmojiCatalog.symbols
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .height(if (showAddInline) 274.dp else 236.dp)
            .clipToBounds()
            .background(palette.background)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        // Search + Add iOS Emoji Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(36.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.predictionPillBg)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search emojis",
                    tint = palette.mutedText,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(modifier = Modifier.weight(1f)) {
                    if (searchQuery.isEmpty()) {
                        Text(
                            text = "Search emojis...",
                            color = palette.mutedText,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        singleLine = true,
                        textStyle = TextStyle(color = palette.keyText, fontSize = 13.sp),
                        cursorBrush = SolidColor(palette.accent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("keyboard_emoji_search")
                    )
                }
                if (searchQuery.isNotEmpty()) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Clear search",
                        tint = palette.mutedText,
                        modifier = Modifier
                            .size(16.dp)
                            .clickable { searchQuery = "" }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .height(36.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.accent.copy(alpha = 0.16f))
                    .border(1.dp, palette.accent.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
                    .clickable { showAddInline = !showAddInline }
                    .padding(horizontal = 10.dp)
                    .testTag("keyboard_add_emoji_toggle"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add custom emoji",
                        tint = palette.accent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "iOS+",
                        color = palette.accent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }

        if (showAddInline) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.keyBg)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(56.dp)
                        .height(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.predictionPillBg)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (newSymbol.isEmpty()) {
                        Text("Emoji", color = palette.mutedText, fontSize = 11.5.sp, maxLines = 1)
                    }
                    BasicTextField(
                        value = newSymbol,
                        onValueChange = { newSymbol = it },
                        singleLine = true,
                        textStyle = TextStyle(color = palette.keyText, fontSize = 16.sp),
                        cursorBrush = SolidColor(palette.accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.predictionPillBg)
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (newLabel.isEmpty()) {
                        Text(
                            text = "Tag (e.g. heart)",
                            color = palette.mutedText,
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    BasicTextField(
                        value = newLabel,
                        onValueChange = { newLabel = it },
                        singleLine = true,
                        textStyle = TextStyle(color = palette.keyText, fontSize = 13.sp),
                        cursorBrush = SolidColor(palette.accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Box(
                    modifier = Modifier
                        .height(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.accent)
                        .clickable {
                            if (newSymbol.isNotBlank()) {
                                onAddCustomEmoji(newSymbol, newLabel)
                                newSymbol = ""
                                newLabel = ""
                                showAddInline = false
                                selectedCategory = EmojiCategory.IOS_CUSTOM
                            }
                        }
                        .padding(horizontal = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Save",
                        color = palette.onAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Emoji Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 40.dp),
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 110.dp)
                .fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items(displayedEmojis) { entry ->
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onEmojiTap(entry.symbol) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = entry.symbol,
                        fontSize = 24.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Bottom Category Strip + ABC + Backspace
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(38.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .height(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.specialKeyBg)
                    .clickable(onClick = onReturnToQwerty)
                    .padding(horizontal = 12.dp)
                    .testTag("emoji_back_to_abc"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ABC",
                    color = palette.specialKeyText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                EmojiCategory.entries.forEach { cat ->
                    val isSelected = cat == selectedCategory && searchQuery.isBlank()
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) palette.accent.copy(alpha = 0.22f)
                                else palette.background
                            )
                            .clickable {
                                searchQuery = ""
                                selectedCategory = cat
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = cat.icon, fontSize = 16.sp)
                    }
                }
            }

            IconButton(
                onClick = onBackspace,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.specialKeyBg)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Backspace",
                    tint = palette.specialKeyText,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
