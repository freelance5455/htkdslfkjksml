package com.example.keyboard

import com.example.data.UnicodeOutputFont

object UnicodeFontMapper {

    fun transform(input: String, font: UnicodeOutputFont): String {
        if (font == UnicodeOutputFont.STANDARD || input.isEmpty()) return input
        val sb = StringBuilder(input.length * 2)
        for (ch in input) {
            sb.append(mapChar(ch, font))
        }
        return sb.toString()
    }

    private fun mapChar(ch: Char, font: UnicodeOutputFont): String {
        return when (font) {
            UnicodeOutputFont.STANDARD -> ch.toString()
            UnicodeOutputFont.SERIF_BOLD -> mapRange(
                ch = ch,
                upperStart = 0x1D400,
                lowerStart = 0x1D41A,
                digitStart = 0x1D7CE
            )
            UnicodeOutputFont.SCRIPT -> when (ch) {
                'B' -> "\uD835\uDCD1"
                'E' -> "\uD835\uDCD4"
                'F' -> "\uD835\uDCD5"
                'H' -> "\uD835\uDCD7"
                'I' -> "\uD835\uDCD8"
                'L' -> "\uD835\uDCDB"
                'M' -> "\uD835\uDCDC"
                'R' -> "\uD835\uDCE1"
                else -> mapRange(
                    ch = ch,
                    upperStart = 0x1D4D0,
                    lowerStart = 0x1D4EA,
                    digitStart = null
                )
            }
            UnicodeOutputFont.MONOSPACE -> mapRange(
                ch = ch,
                upperStart = 0x1D670,
                lowerStart = 0x1D68A,
                digitStart = 0x1D7F6
            )
            UnicodeOutputFont.SANS_BOLD -> mapRange(
                ch = ch,
                upperStart = 0x1D5D4,
                lowerStart = 0x1D5EE,
                digitStart = 0x1D7EC
            )
        }
    }

    private fun mapRange(
        ch: Char,
        upperStart: Int,
        lowerStart: Int,
        digitStart: Int?
    ): String {
        val codePoint = when (ch) {
            in 'A'..'Z' -> upperStart + (ch - 'A')
            in 'a'..'z' -> lowerStart + (ch - 'a')
            in '0'..'9' -> if (digitStart != null) digitStart + (ch - '0') else return ch.toString()
            else -> return ch.toString()
        }
        return String(Character.toChars(codePoint))
    }
}
