package com.example.keyboard

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import com.example.data.CustomThemePreset
import com.example.data.DarkModeOption
import com.example.data.KeyboardFontId
import com.example.data.KeycapStyle
import com.example.data.VelvetSettings
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.NunitoFamily
import com.example.ui.theme.PacificoFamily
import com.example.ui.theme.PlayfairDisplayFamily
import com.example.ui.theme.PlusJakartaSansFamily
import com.example.ui.theme.SpaceGroteskFamily

data class KeyboardPalette(
    val themeId: String,
    val themeName: String,
    val isDark: Boolean,
    val background: Color,
    val toolbarBg: Color,
    val keyBg: Color,
    val keyPressedBg: Color,
    val keyShadow: Color,
    val keyBorder: Color,
    val keyText: Color,
    val specialKeyBg: Color,
    val specialKeyText: Color,
    val accent: Color,
    val onAccent: Color,
    val predictionPillBg: Color,
    val predictionActiveBg: Color,
    val swipeTrail: Color,
    val mutedText: Color,
    val popupBg: Color,
    val keycapStyle: KeycapStyle,
    val cornerRadiusDp: Float,
    val keyOpacity: Float,
    val backgroundImagePath: String?,
    val backgroundVideoPath: String?,
    val aliveLeafEffect: Boolean
)

val BuiltInThemeLibrary: List<CustomThemePreset> = listOf(
    CustomThemePreset(
        id = "alive_leaf",
        name = "Alive Leaf",
        tagline = "Minimalist botanical glow with drifting organic light",
        isBuiltIn = true,
        isDarkBase = true,
        bgColorArgb = 0xFF0C1411,
        keyColorArgb = 0xFF172520,
        specialKeyColorArgb = 0xFF111C18,
        textColorArgb = 0xFFECFDF5,
        accentColorArgb = 0xFF34D399,
        keycapStyle = KeycapStyle.ROUNDED,
        cornerRadiusDp = 11f,
        keyOpacity = 0.90f,
        aliveLeafEffect = true
    ),
    CustomThemePreset(
        id = "minimalist_glass",
        name = "Minimalist Glass",
        tagline = "Clean borderless air-light layout",
        isBuiltIn = true,
        isDarkBase = false,
        bgColorArgb = 0xFFF2F4F8,
        keyColorArgb = 0xFFFFFFFF,
        specialKeyColorArgb = 0xFFE2E7F0,
        textColorArgb = 0xFF0F172A,
        accentColorArgb = 0xFF0EA5E9,
        keycapStyle = KeycapStyle.BORDERLESS,
        cornerRadiusDp = 12f,
        keyOpacity = 0.96f,
        aliveLeafEffect = false
    ),
    CustomThemePreset(
        id = "ios_frost",
        name = "iOS Frost",
        tagline = "Crisp Apple-inspired tactile keycaps",
        isBuiltIn = true,
        isDarkBase = false,
        bgColorArgb = 0xFFD1D5DB,
        keyColorArgb = 0xFFFFFFFF,
        specialKeyColorArgb = 0xFFACB3BF,
        textColorArgb = 0xFF0F172A,
        accentColorArgb = 0xFF007AFF,
        keycapStyle = KeycapStyle.ELEVATED_3D,
        cornerRadiusDp = 8f,
        keyOpacity = 1.0f,
        aliveLeafEffect = false
    ),
    CustomThemePreset(
        id = "midnight_velvet",
        name = "Midnight Velvet",
        tagline = "Ultra-low-glare OLED dark for late nights",
        isBuiltIn = true,
        isDarkBase = true,
        bgColorArgb = 0xFF05060A,
        keyColorArgb = 0xFF121622,
        specialKeyColorArgb = 0xFF0B0E17,
        textColorArgb = 0xFFF1F5F9,
        accentColorArgb = 0xFFF59E0B,
        keycapStyle = KeycapStyle.ROUNDED,
        cornerRadiusDp = 10f,
        keyOpacity = 0.95f,
        aliveLeafEffect = false
    ),
    CustomThemePreset(
        id = "matcha_pill",
        name = "Matcha Pill",
        tagline = "Full-pill organic sage & cream",
        isBuiltIn = true,
        isDarkBase = false,
        bgColorArgb = 0xFFE4ECE4,
        keyColorArgb = 0xFFFAFCFA,
        specialKeyColorArgb = 0xFFC5D8C6,
        textColorArgb = 0xFF1B3A26,
        accentColorArgb = 0xFF16A34A,
        keycapStyle = KeycapStyle.PILL,
        cornerRadiusDp = 22f,
        keyOpacity = 0.96f,
        aliveLeafEffect = true
    ),
    CustomThemePreset(
        id = "tokyo_neon",
        name = "Tokyo Neon",
        tagline = "Frosted cyber glass with electric cyan trail",
        isBuiltIn = true,
        isDarkBase = true,
        bgColorArgb = 0xFF080E1A,
        keyColorArgb = 0xFF132238,
        specialKeyColorArgb = 0xFF0D1728,
        textColorArgb = 0xFFE0F2FE,
        accentColorArgb = 0xFF22D3EE,
        keycapStyle = KeycapStyle.FROSTED_GLASS,
        cornerRadiusDp = 12f,
        keyOpacity = 0.85f,
        aliveLeafEffect = false
    ),
    CustomThemePreset(
        id = "terracotta_clay",
        name = "Terracotta Clay",
        tagline = "Warm coral & espresso minimalist warmth",
        isBuiltIn = true,
        isDarkBase = true,
        bgColorArgb = 0xFF1B1014,
        keyColorArgb = 0xFF2F1D24,
        specialKeyColorArgb = 0xFF23151A,
        textColorArgb = 0xFFFFF1F2,
        accentColorArgb = 0xFFFB7185,
        keycapStyle = KeycapStyle.ROUNDED,
        cornerRadiusDp = 12f,
        keyOpacity = 0.94f,
        aliveLeafEffect = false
    )
)

fun resolveKeyboardFontFamily(fontId: KeyboardFontId): FontFamily = when (fontId) {
    KeyboardFontId.PLUS_JAKARTA -> PlusJakartaSansFamily
    KeyboardFontId.SPACE_GROTESK -> SpaceGroteskFamily
    KeyboardFontId.PLAYFAIR -> PlayfairDisplayFamily
    KeyboardFontId.JETBRAINS_MONO -> JetBrainsMonoFamily
    KeyboardFontId.NUNITO -> NunitoFamily
    KeyboardFontId.PACIFICO -> PacificoFamily
}

fun resolveIsDark(option: DarkModeOption, systemIsDark: Boolean): Boolean = when (option) {
    DarkModeOption.SYSTEM -> systemIsDark
    DarkModeOption.LIGHT -> false
    DarkModeOption.LATE_NIGHT_DARK -> true
}

fun resolveKeyboardPalette(settings: VelvetSettings, systemIsDark: Boolean): KeyboardPalette {
    val allThemes = settings.customThemes + BuiltInThemeLibrary
    val preset = allThemes.firstOrNull { it.id == settings.activeThemeId } ?: BuiltInThemeLibrary.first()
    val forceDark = when (settings.darkModeOption) {
        DarkModeOption.SYSTEM -> preset.isDarkBase || (preset.id == "ios_frost" && systemIsDark)
        DarkModeOption.LIGHT -> if (preset.isBuiltIn && preset.id == "ios_frost") false else preset.isDarkBase
        DarkModeOption.LATE_NIGHT_DARK -> true
    }

    // If user explicitly flipped to Late-Night Dark on a light built-in preset, adapt cleanly to OLED dark
    val adaptLightToNight = forceDark && !preset.isDarkBase &&
        preset.backgroundImagePath == null && preset.backgroundVideoPath == null

    val bg = if (adaptLightToNight) Color(0xFF0A0C12) else Color(preset.bgColorArgb)
    val keyRaw = if (adaptLightToNight) Color(0xFF1C202B) else Color(preset.keyColorArgb)
    val specRaw = if (adaptLightToNight) Color(0xFF13161F) else Color(preset.specialKeyColorArgb)
    val txt = if (adaptLightToNight) Color(0xFFF1F5F9) else Color(preset.textColorArgb)
    val accent = Color(preset.accentColorArgb)

    val hasMedia = preset.backgroundImagePath != null || preset.backgroundVideoPath != null
    val effectiveAlpha = if (hasMedia) preset.keyOpacity.coerceIn(0.28f, 0.92f) else preset.keyOpacity

    val isDark = forceDark
    val keyBg = keyRaw.copy(alpha = effectiveAlpha)
    val specialBg = specRaw.copy(alpha = (effectiveAlpha * 0.95f).coerceIn(0.25f, 1f))
    val pressedBg = if (isDark) keyRaw.copy(alpha = (effectiveAlpha + 0.18f).coerceAtMost(1f))
    else Color(0xFFE2E8F0).copy(alpha = effectiveAlpha)

    val borderAlpha = when (preset.keycapStyle) {
        KeycapStyle.BORDERLESS -> 0f
        KeycapStyle.FROSTED_GLASS -> 0.35f
        KeycapStyle.PILL -> 0.18f
        else -> if (isDark) 0.22f else 0.35f
    }
    val keyBorder = if (preset.keycapStyle == KeycapStyle.FROSTED_GLASS) {
        Color.White.copy(alpha = borderAlpha)
    } else {
        txt.copy(alpha = borderAlpha)
    }

    val luminance = (0.299f * accent.red + 0.587f * accent.green + 0.114f * accent.blue)
    val onAccent = if (luminance > 0.6f) Color(0xFF091014) else Color.White

    return KeyboardPalette(
        themeId = preset.id,
        themeName = preset.name,
        isDark = isDark,
        background = bg,
        toolbarBg = bg.copy(alpha = if (hasMedia) 0.65f else 0.96f),
        keyBg = keyBg,
        keyPressedBg = pressedBg,
        keyShadow = if (preset.keycapStyle == KeycapStyle.BORDERLESS) Color.Transparent else Color.Black.copy(alpha = 0.28f),
        keyBorder = keyBorder,
        keyText = txt,
        specialKeyBg = specialBg,
        specialKeyText = txt.copy(alpha = 0.86f),
        accent = accent,
        onAccent = onAccent,
        predictionPillBg = specialBg.copy(alpha = 0.72f),
        predictionActiveBg = keyBg,
        swipeTrail = accent,
        mutedText = txt.copy(alpha = 0.60f),
        popupBg = if (isDark) Color(0xFF282E3D) else Color.White,
        keycapStyle = preset.keycapStyle,
        cornerRadiusDp = preset.cornerRadiusDp,
        keyOpacity = effectiveAlpha,
        backgroundImagePath = preset.backgroundImagePath,
        backgroundVideoPath = preset.backgroundVideoPath,
        aliveLeafEffect = preset.aliveLeafEffect || (settings.aliveMotionEnabled && preset.id == "alive_leaf")
    )
}
