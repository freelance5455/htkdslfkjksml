package com.example.keyboard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import com.example.data.VelvetSettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class ClipboardHistoryManager(
    context: Context,
    private val repo: VelvetSettingsRepository,
    private val scope: CoroutineScope
) {
    private val clipboard =
        context.applicationContext.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    private var listener: ClipboardManager.OnPrimaryClipChangedListener? = null

    fun startListening() {
        val cm = clipboard ?: return
        if (listener != null) return

        // Sync current primary clip immediately on start
        syncCurrentPrimaryClip()

        val newListener = ClipboardManager.OnPrimaryClipChangedListener {
            syncCurrentPrimaryClip()
        }
        listener = newListener
        try {
            cm.addPrimaryClipChangedListener(newListener)
        } catch (_: Exception) {
        }
    }

    fun stopListening() {
        val cm = clipboard ?: return
        val active = listener ?: return
        try {
            cm.removePrimaryClipChangedListener(active)
        } catch (_: Exception) {
        }
        listener = null
    }

    fun syncCurrentPrimaryClip() {
        val cm = clipboard ?: return
        try {
            val clip = cm.primaryClip ?: return
            if (clip.itemCount > 0) {
                val itemText = clip.getItemAt(0)?.text?.toString()
                if (!itemText.isNullOrBlank()) {
                    scope.launch {
                        repo.addClipboardClip(itemText)
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    fun copyToSystemClipboard(text: String) {
        val cm = clipboard ?: return
        try {
            cm.setPrimaryClip(ClipData.newPlainText("VelvetKey Clip", text))
            scope.launch {
                repo.addClipboardClip(text)
            }
        } catch (_: Exception) {
        }
    }
}
