package com.example.keyboard

import com.example.data.KeyboardLanguage

object WordDictionary {

    // Rich English conversational vocabulary + modern slang
    private val englishWords: List<String> = (
        "the be to of and a in that have i it for not on with he as you do at " +
        "this but his by from they we say her she or an will my one all would there their what " +
        "so up out if about who get which go me when make can like time no just him know take " +
        "people into year your good some could them see other than then now look only come its over " +
        "think also back after use two how our work first well way even new want because any these " +
        "give day most us are was were been has had did does doing made got going getting " +
        "hello hey hi yo sup thanks thank please sorry welcome morning night evening today tomorrow yesterday " +
        "great awesome amazing cool nice perfect love loved loving happy glad excited ready " +
        "sure okay ok yes yeah yep nope nah maybe probably definitely actually literally basically " +
        "really very much more less little big small long short high low right left true false " +
        "where why how who when while before during until since through around near " +
        "everyone everything someone something anyone anything nothing nobody everybody " +
        "friend friends family home house room office school work job project meeting call text " +
        "message email chat phone app keyboard screen swipe voice type typing write writing " +
        "send sent sending read reading reply replying check checking wait waiting talk talking " +
        "feel feeling thought think thinking believe hope hoping wish wishing need needed " +
        "want wanted try trying start started starting finish finished done stop stopping " +
        "coffee lunch dinner breakfast food water tea pizza cake snack hungry tired busy " +
        "music song video photo picture movie game book story news weather rain sun snow " +
        "monday tuesday wednesday thursday friday saturday sunday weekend week month year " +
        "world word work watch walk want water wave wear week well went were what when where " +
        "better best worse worst beautiful pretty gorgeous cute sweet funny hilarious smart " +
        "clever brilliant crazy wild weird strange calm peaceful quiet loud bright dark " +
        // Modern conversational slang & fast chat terms
        "ngl tbh idk imo lmk omw brb wyd wya iykyk frfr lowkey highkey deadass bet finna gonna " +
        "wanna gotta kinda sorta y'all bruh bro sis bestie fam squad vibe vibes vibing fire lit " +
        "goat slay periodt valid cap nocap sus cringe wildin chill chillin hype clutch flex " +
        "ghosted petty salty tea shade mood iconic obsessed aesthetic minimalist cozy " +
        "i'm you're he's she's it's we're they're don't doesn't didn't won't can't couldn't " +
        "wouldn't shouldn't isn't aren't wasn't weren't haven't hasn't hadn't i'll you'll " +
        "we'll they'll i've you've we've they've that's what's who's where's there's let's"
    ).split(" ").distinct()

    private val spanishWords: List<String> = (
        "de la que el en y a los del se las por un para con no una su al lo como más pero sus le " +
        "ya o este sí porque esta entre cuando muy sin sobre también me hasta hay donde quien desde " +
        "todo nos durante todos uno les ni contra otros ese eso ante ellos e esto mí antes algunos " +
        "qué unos yo otro otras otra él tanto esa estos mucho quienes nada muchos cual poco ella " +
        "estar estas algunas algo nosotros mi mis tú te ti tu tus ellas nosotras vosotros vosotras " +
        "hola buenos días tardes noches gracias por favor perdón claro vale bueno genial perfecto " +
        "amor amigo amiga familia casa trabajo comida café agua música foto mensaje teclado"
    ).split(" ").distinct()

    private val frenchWords: List<String> = (
        "de la le et les des en un du une que est pour qui dans ce il pas ne sur se plus " +
        "par avec tout faire son mettre autre on mais nous vous comme ou si leur bien sans " +
        "bonjour salut merci pardon oui non d'accord génial parfait amour ami famille maison " +
        "travail café eau musique message clavier super"
    ).split(" ").distinct()

    private val germanWords: List<String> = (
        "der die das und in zu den von mit ist auf für nicht ein eine als auch es an er so " +
        "wie oder aber wir sie ich du man noch nur was wenn nach bei um über war haben sein " +
        "hallo danke bitte ja nein gut super schön liebe freund familie haus arbeit kaffee musik"
    ).split(" ").distinct()

    private val portugueseWords: List<String> = (
        "de a o que e do da em um para é com não uma os no se na por mais as dos como mas " +
        "foi ao ele das tem à seu sua ou ser quando muito há nos já está eu também só pelo " +
        "olá oi tudo bem obrigado obrigada sim não claro legal ótimo perfeito amor amigo casa café"
    ).split(" ").distinct()

    private val italianWords: List<String> = (
        "di a da in con su per tra fra il lo la i gli le un uno una e che non si è ma o come " +
        "più per anche io tu lui lei noi voi loro ciao grazie prego scusa bene ottimo perfetto " +
        "amore amico famiglia casa lavoro caffè musica messaggio"
    ).split(" ").distinct()

    private val arabicWords: List<String> = (
        "في من على إلى عن مع هذا هذه هو هي نحن هم أنا أنت السلام عليكم مرحبا أهلا شكرا " +
        "عفوا نعم لا تمام ممتاز جميل جدا حبيبي صديقي بيت عمل قهوة ماء اليوم غدا إن شاء الله"
    ).split(" ").distinct()

    private val dictsByLang: Map<KeyboardLanguage, List<String>> = mapOf(
        KeyboardLanguage.EN to englishWords,
        KeyboardLanguage.ES to spanishWords,
        KeyboardLanguage.FR to frenchWords,
        KeyboardLanguage.DE to germanWords,
        KeyboardLanguage.PT to portugueseWords,
        KeyboardLanguage.IT to italianWords,
        KeyboardLanguage.AR to arabicWords
    )

    // Pre-indexed first-letter buckets for O(1) lookup and sub-2ms swipe decoding
    private val bucketsByLang: Map<KeyboardLanguage, Map<Char, List<String>>> =
        dictsByLang.mapValues { (_, list) ->
            list.groupBy { it.first() }
        }

    private val rankMapsByLang: Map<KeyboardLanguage, Map<String, Int>> =
        dictsByLang.mapValues { (_, list) ->
            list.mapIndexed { idx, w -> w to idx }.toMap()
        }

    private val bigramsEn: Map<String, List<String>> = mapOf(
        "i" to listOf("am", "think", "love", "need", "want", "have", "can", "will"),
        "i'm" to listOf("so", "lowkey", "going", "ready", "sorry", "here", "just"),
        "you" to listOf("are", "can", "have", "know", "want", "need", "doing"),
        "how" to listOf("are", "is", "do", "was", "did", "much"),
        "what" to listOf("is", "are", "do", "you", "about", "time"),
        "thank" to listOf("you", "god", "goodness"),
        "thanks" to listOf("so", "for", "a", "fam"),
        "good" to listOf("morning", "night", "luck", "vibes", "idea"),
        "lowkey" to listOf("fire", "want", "think", "love", "excited"),
        "ngl" to listOf("that", "this", "i'm", "it's", "you"),
        "tbh" to listOf("i", "that", "it's", "not", "yes"),
        "on" to listOf("my", "the", "time", "it"),
        "my" to listOf("way", "friend", "phone", "home")
    )

    fun wordsStartingWith(
        language: KeyboardLanguage,
        chars: Set<Char>,
        learnedWords: Map<String, Int> = emptyMap()
    ): List<String> {
        val buckets = bucketsByLang[language] ?: bucketsByLang[KeyboardLanguage.EN]!!
        val base = chars.flatMap { ch -> buckets[ch].orEmpty() }
        if (learnedWords.isEmpty()) return base
        val extra = learnedWords.keys.filter { w -> w.length >= 2 && w.first() in chars }
        return if (extra.isEmpty()) base else (extra + base).distinct()
    }

    fun rankOf(word: String, language: KeyboardLanguage, learnedWords: Map<String, Int> = emptyMap()): Int {
        val lower = word.lowercase()
        val learnedCount = learnedWords[lower] ?: 0
        if (learnedCount >= 2) {
            // Learned user slang rises to top priority
            return -learnedCount * 10
        }
        return rankMapsByLang[language]?.get(lower) ?: 9999
    }

    fun getPredictions(
        currentWord: String,
        previousWord: String?,
        language: KeyboardLanguage = KeyboardLanguage.EN,
        learnedWords: Map<String, Int> = emptyMap(),
        aiBoostWords: List<String> = emptyList()
    ): List<String> {
        val clean = currentWord.trim()
        val dict = dictsByLang[language] ?: englishWords

        if (clean.isEmpty()) {
            val prev = previousWord?.trim()?.lowercase()
            val topLearned = learnedWords.entries
                .sortedByDescending { it.value }
                .take(3)
                .map { it.key }
            val next = if (!prev.isNullOrEmpty() && language == KeyboardLanguage.EN) {
                bigramsEn[prev].orEmpty()
            } else {
                dict.take(6)
            }
            val merged = (aiBoostWords + next + topLearned + dict.take(5))
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .distinctBy { it.lowercase() }
            return merged.take(3)
        }

        val lower = clean.lowercase()
        val isCapitalized = clean.firstOrNull()?.isUpperCase() == true

        // 1. Check user's learned slang & personal vocabulary first
        val learnedMatches = learnedWords.entries
            .filter { it.key.startsWith(lower) }
            .sortedByDescending { it.value }
            .map { it.key }
            .take(3)

        // 2. Fast bucketed dictionary prefix matches
        val bucket = bucketsByLang[language]?.get(lower.first()).orEmpty()
        val prefixMatches = bucket
            .filter { it.startsWith(lower) }
            .take(6)

        // 3. Fuzzy correction if user mistyped a letter
        val fuzzyMatches = if (learnedMatches.size + prefixMatches.size < 3 && lower.length >= 2) {
            bucket
                .filter { kotlin.math.abs(it.length - lower.length) <= 1 }
                .map { it to editDistance(lower, it) }
                .filter { it.second <= 2 }
                .sortedWith(compareBy({ it.second }, { rankOf(it.first, language, learnedWords) }))
                .map { it.first }
                .take(3)
        } else {
            emptyList()
        }

        val combined = (learnedMatches + prefixMatches + fuzzyMatches)
            .distinct()
            .take(3)
            .map { match ->
                if (isCapitalized && match.isNotEmpty()) {
                    match.replaceFirstChar { it.uppercaseChar() }
                } else {
                    match
                }
            }

        return if (combined.isEmpty()) listOf(clean) else combined
    }

    private fun editDistance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val temp = dp[j]
                dp[j] = if (a[i - 1] == b[j - 1]) prev else 1 + minOf(prev, dp[j], dp[j - 1])
                prev = temp
            }
        }
        return dp[b.length]
    }
}
