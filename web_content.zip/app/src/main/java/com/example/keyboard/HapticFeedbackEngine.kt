package com.example.keyboard

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Build
import android.os.VibrationAttributes
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View
import com.example.data.HapticProfile

enum class HapticCue {
    KEY_TAP,
    MODIFIER_TAP,
    BACKSPACE,
    SWIPE_WORD_COMMIT,
    AI_SUCCESS
}

class HapticFeedbackEngine(context: Context) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private val audioManager: AudioManager? =
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    fun trigger(
        profile: HapticProfile,
        cue: HapticCue,
        view: View? = null,
        playSound: Boolean = false
    ) {
        if (playSound) {
            try {
                val fx = when (cue) {
                    HapticCue.BACKSPACE -> AudioManager.FX_KEYPRESS_DELETE
                    HapticCue.MODIFIER_TAP -> AudioManager.FX_KEYPRESS_SPACEBAR
                    else -> AudioManager.FX_KEYPRESS_STANDARD
                }
                audioManager?.playSoundEffect(fx, 0.35f)
            } catch (_: Exception) {
            }
        }

        if (profile == HapticProfile.OFF) return

        // Layer 1: Direct View haptic (works reliably inside InputMethodService windows & playgrounds)
        view?.let { targetView ->
            try {
                val constant = when (cue) {
                    HapticCue.KEY_TAP -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                        HapticFeedbackConstants.KEYBOARD_PRESS
                    } else {
                        HapticFeedbackConstants.KEYBOARD_TAP
                    }
                    HapticCue.MODIFIER_TAP, HapticCue.BACKSPACE -> HapticFeedbackConstants.KEYBOARD_TAP
                    HapticCue.SWIPE_WORD_COMMIT, HapticCue.AI_SUCCESS ->
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            HapticFeedbackConstants.CONFIRM
                        } else {
                            HapticFeedbackConstants.KEYBOARD_TAP
                        }
                }
                @Suppress("DEPRECATION")
                targetView.performHapticFeedback(
                    constant,
                    HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING
                )
            } catch (_: Exception) {
            }
        }

        // Layer 2: Precision hardware Vibrator with USAGE_TOUCH attributes (required on API 33+ IMEs)
        val vib = vibrator ?: return
        if (!vib.hasVibrator()) return

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = buildEffect(profile, cue)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val attrs = VibrationAttributes.Builder()
                        .setUsage(VibrationAttributes.USAGE_TOUCH)
                        .build()
                    vib.vibrate(effect, attrs)
                } else {
                    @Suppress("DEPRECATION")
                    val audioAttrs = AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .build()
                    @Suppress("DEPRECATION")
                    vib.vibrate(effect, audioAttrs)
                }
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(legacyDurationMs(profile, cue))
            }
        } catch (_: Exception) {
        }
    }

    @androidx.annotation.RequiresApi(Build.VERSION_CODES.O)
    private fun buildEffect(profile: HapticProfile, cue: HapticCue): VibrationEffect {
        val (durationMs, amplitude) = when (profile) {
            HapticProfile.OFF -> 0L to 0
            HapticProfile.SUBTLE -> when (cue) {
                HapticCue.KEY_TAP -> 8L to 55
                HapticCue.MODIFIER_TAP -> 11L to 75
                HapticCue.BACKSPACE -> 9L to 65
                HapticCue.SWIPE_WORD_COMMIT -> 14L to 90
                HapticCue.AI_SUCCESS -> 16L to 105
            }
            HapticProfile.IOS_CRISP -> when (cue) {
                HapticCue.KEY_TAP -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        return VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
                    }
                    11L to 110
                }
                HapticCue.MODIFIER_TAP -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        return VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                    }
                    15L to 145
                }
                HapticCue.BACKSPACE -> 12L to 125
                HapticCue.SWIPE_WORD_COMMIT -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        return VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                    }
                    16L to 150
                }
                HapticCue.AI_SUCCESS -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        return VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK)
                    }
                    20L to 165
                }
            }
            HapticProfile.MECHANICAL -> when (cue) {
                HapticCue.KEY_TAP -> 18L to 185
                HapticCue.MODIFIER_TAP -> 24L to 220
                HapticCue.BACKSPACE -> 20L to 200
                HapticCue.SWIPE_WORD_COMMIT -> 26L to 225
                HapticCue.AI_SUCCESS -> 30L to 240
            }
        }

        if (cue == HapticCue.AI_SUCCESS && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return VibrationEffect.createWaveform(
                longArrayOf(0L, durationMs, 36L, durationMs),
                intArrayOf(0, amplitude, 0, (amplitude * 1.1f).toInt().coerceAtMost(255)),
                -1
            )
        }

        return VibrationEffect.createOneShot(durationMs.coerceAtLeast(1L), amplitude.coerceIn(1, 255))
    }

    private fun legacyDurationMs(profile: HapticProfile, cue: HapticCue): Long {
        val base = when (profile) {
            HapticProfile.OFF -> 0L
            HapticProfile.SUBTLE -> 9L
            HapticProfile.IOS_CRISP -> 13L
            HapticProfile.MECHANICAL -> 20L
        }
        return if (cue == HapticCue.MODIFIER_TAP || cue == HapticCue.AI_SUCCESS) base + 5L else base
    }
}
