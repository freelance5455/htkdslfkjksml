package com.example.keyboard

import androidx.compose.ui.geometry.Offset
import com.example.data.KeyboardLanguage
import kotlin.math.acos
import kotlin.math.hypot

object SwipeDecoder {

    private val normalizedKeyPositions: Map<Char, Offset> = buildMap {
        val row1 = "qwertyuiop"
        val row2 = "asdfghjkl"
        val row3 = "zxcvbnm"
        row1.forEachIndexed { idx, ch -> put(ch, Offset(idx + 0.5f, 0.5f)) }
        row2.forEachIndexed { idx, ch -> put(ch, Offset(idx + 1.0f, 1.5f)) }
        row3.forEachIndexed { idx, ch -> put(ch, Offset(idx + 1.8f, 2.5f)) }
    }

    /**
     * Sub-2ms bucketed swipe decoder with turning-point corner matching,
     * multi-language layout support, and personal slang ranking boost.
     */
    fun decode(
        points: List<Offset>,
        measuredKeyCenters: Map<Char, Offset>,
        language: KeyboardLanguage = KeyboardLanguage.EN,
        learnedWords: Map<String, Int> = emptyMap()
    ): List<String> {
        if (points.size < 2) return emptyList()

        val keyCenters = if (measuredKeyCenters.size >= 20) {
            measuredKeyCenters
        } else {
            normalizedKeyPositions
        }

        val turningPoints = extractTurningPoints(points)
        val resampled = resample(points, 20)
        val startPoint = resampled.first()
        val endPoint = resampled.last()

        val startChars = nearestChars(startPoint, keyCenters, limit = 3)
        val endChars = nearestChars(endPoint, keyCenters, limit = 3)

        val firstKey = keyCenters.values.firstOrNull()
        val lastRow1Key = keyCenters.values.maxByOrNull { it.x }
        val keyUnit = if (firstKey != null && lastRow1Key != null) {
            (hypot(lastRow1Key.x - firstKey.x, 0f) / 9f).coerceAtLeast(1f)
        } else {
            1f
        }

        val bucketPool = WordDictionary.wordsStartingWith(language, startChars, learnedWords)
        val candidates = bucketPool.filter { word ->
            word.length >= 2 && word.last() in endChars
        }.ifEmpty {
            bucketPool.filter { it.length >= 2 }
        }

        val scored = candidates.mapNotNull { word ->
            val wordPts = word.mapNotNull { keyCenters[it] }
            if (wordPts.size != word.length) return@mapNotNull null

            val shapeScore = orderedPathDistance(resampled, wordPts) / keyUnit
            val cornerPenalty = if (turningPoints.isNotEmpty()) {
                turningPoints.sumOf { tp ->
                    wordPts.minOf { wp -> hypot(tp.x - wp.x, tp.y - wp.y).toDouble() }
                }.toFloat() / (turningPoints.size * keyUnit)
            } else {
                0f
            }
            val startDist = hypot(startPoint.x - wordPts.first().x, startPoint.y - wordPts.first().y) / keyUnit
            val endDist = hypot(endPoint.x - wordPts.last().x, endPoint.y - wordPts.last().y) / keyUnit
            val rank = WordDictionary.rankOf(word, language, learnedWords)
            val freqBonus = if (rank < 0) -0.25f else (rank.coerceAtMost(1500) / 1500f) * 0.25f

            val totalCost = shapeScore * 1.0f +
                cornerPenalty * 1.35f +
                startDist * 0.85f +
                endDist * 0.85f +
                freqBonus
            word to totalCost
        }.sortedBy { it.second }

        return scored.map { it.first }.distinct().take(3)
    }

    private fun extractTurningPoints(points: List<Offset>): List<Offset> {
        if (points.size < 3) return emptyList()
        val filtered = mutableListOf(points.first())
        for (i in 1 until points.size) {
            val prev = filtered.last()
            val curr = points[i]
            if (hypot(curr.x - prev.x, curr.y - prev.y) > 0.1f) {
                filtered.add(curr)
            }
        }
        if (filtered.size < 3) return emptyList()

        val corners = mutableListOf<Offset>()
        for (i in 1 until filtered.size - 1) {
            val v1x = filtered[i].x - filtered[i - 1].x
            val v1y = filtered[i].y - filtered[i - 1].y
            val v2x = filtered[i + 1].x - filtered[i].x
            val v2y = filtered[i + 1].y - filtered[i].y
            val len1 = hypot(v1x, v1y)
            val len2 = hypot(v2x, v2y)
            if (len1 > 0.05f && len2 > 0.05f) {
                val cosTheta = ((v1x * v2x + v1y * v2y) / (len1 * len2)).coerceIn(-1f, 1f)
                val angleDeg = Math.toDegrees(acos(cosTheta.toDouble()))
                if (angleDeg >= 32.0) {
                    corners.add(filtered[i])
                }
            }
        }
        return corners
    }

    private fun nearestChars(
        point: Offset,
        centers: Map<Char, Offset>,
        limit: Int
    ): Set<Char> {
        return centers.entries
            .sortedBy { hypot(point.x - it.value.x, point.y - it.value.y) }
            .take(limit)
            .map { it.key }
            .toSet()
    }

    private fun orderedPathDistance(path: List<Offset>, wordPts: List<Offset>): Float {
        var pathIdx = 0
        var forwardCost = 0f

        for (wPt in wordPts) {
            var bestIdx = pathIdx
            var bestDist = Float.MAX_VALUE
            val searchLimit = path.size - 1
            for (i in pathIdx..searchLimit) {
                val d = hypot(path[i].x - wPt.x, path[i].y - wPt.y)
                if (d < bestDist) {
                    bestDist = d
                    bestIdx = i
                }
            }
            forwardCost += bestDist
            pathIdx = bestIdx
        }

        val avgWordHit = forwardCost / wordPts.size.coerceAtLeast(1)

        var reverseCost = 0f
        for (p in path) {
            var minDist = Float.MAX_VALUE
            for (wPt in wordPts) {
                val d = hypot(p.x - wPt.x, p.y - wPt.y)
                if (d < minDist) minDist = d
            }
            reverseCost += minDist
        }
        val avgPathDeviation = reverseCost / path.size.coerceAtLeast(1)

        return avgWordHit * 0.65f + avgPathDeviation * 0.35f
    }

    private fun resample(points: List<Offset>, n: Int): List<Offset> {
        if (points.size <= 1) return points
        var totalLen = 0f
        for (i in 1 until points.size) {
            totalLen += hypot(points[i].x - points[i - 1].x, points[i].y - points[i - 1].y)
        }
        if (totalLen < 1e-3f) return List(n) { points.first() }

        val step = totalLen / (n - 1)
        val result = ArrayList<Offset>(n)
        result.add(points.first())

        var accumulated = 0f
        var prev = points.first()
        var idx = 1
        while (idx < points.size && result.size < n) {
            val curr = points[idx]
            val seg = hypot(curr.x - prev.x, curr.y - prev.y)
            if (accumulated + seg >= step) {
                val t = (step - accumulated) / seg.coerceAtLeast(1e-4f)
                val nx = prev.x + t * (curr.x - prev.x)
                val ny = prev.y + t * (curr.y - prev.y)
                val inserted = Offset(nx, ny)
                result.add(inserted)
                prev = inserted
                accumulated = 0f
            } else {
                accumulated += seg
                prev = curr
                idx++
            }
        }
        while (result.size < n) {
            result.add(points.last())
        }
        return result
    }
}
