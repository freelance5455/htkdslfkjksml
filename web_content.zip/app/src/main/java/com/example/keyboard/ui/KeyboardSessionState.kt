package com.example.keyboard.ui

import android.view.View
import com.example.ai.AiResult
import com.example.ai.AiWriteTone
import com.example.ai.CustomTtsSpeaker
import com.example.ai.VelvetAiEngine
import com.example.ai.VelvetVoiceEngine
import com.example.data.VelvetSettings
import com.example.data.VelvetSettingsRepository
import com.example.keyboard.ClipboardHistoryManager
import com.example.keyboard.HapticCue
import com.example.keyboard.HapticFeedbackEngine
import com.example.keyboard.UnicodeFontMapper
import com.example.keyboard.WordDictionary
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class KeyboardPanelMode {
    QWERTY,
    SYMBOLS,
    SYMBOLS_EXT,
    EMOJI,
    CLIPBOARD
}

enum class ShiftState {
    OFF,
    SINGLE,
    CAPS_LOCK
}

sealed interface InlineVoiceState {
    data object Idle : InlineVoiceState
    data object Listening : InlineVoiceState
    data object Processing : InlineVoiceState
    data class Error(val message: String) : InlineVoiceState
}

interface TextTargetAdapter {
    fun commitText(text: String)
    fun deleteBeforeCursor(count: Int)
    fun getTextBeforeCursor(maxChars: Int): String
    fun replaceAllText(newText: String)
    fun performAction(): Boolean
}

class KeyboardSessionController(
    private val scope: CoroutineScope,
    private val settingsRepo: VelvetSettingsRepository,
    private val haptics: HapticFeedbackEngine,
    private val aiEngine: VelvetAiEngine,
    private val voiceEngine: VelvetVoiceEngine,
    private val ttsSpeaker: CustomTtsSpeaker,
    private val clipboardManager: ClipboardHistoryManager,
    private val textTarget: TextTargetAdapter,
    private val onSwitchIme: (() -> Unit)? = null,
    private val onOpenSettings: (() -> Unit)? = null,
    private val onRequestMicPermission: (() -> Unit)? = null
) {
    private val _panelMode = MutableStateFlow(KeyboardPanelMode.QWERTY)
    val panelMode: StateFlow<KeyboardPanelMode> = _panelMode.asStateFlow()

    private val _shiftState = MutableStateFlow(ShiftState.SINGLE)
    val shiftState: StateFlow<ShiftState> = _shiftState.asStateFlow()

    private val _predictions = MutableStateFlow(listOf("I", "The", "Hey"))
    val predictions: StateFlow<List<String>> = _predictions.asStateFlow()

    private val _toolsExpanded = MutableStateFlow(true)
    val toolsExpanded: StateFlow<Boolean> = _toolsExpanded.asStateFlow()

    private val _lastSwipedWordLength = MutableStateFlow(0)
    private var lastSpaceTapMs = 0L
    private var lastShiftTapMs = 0L
    private var aiPredictionJob: Job? = null

    private val _voiceState = MutableStateFlow<InlineVoiceState>(InlineVoiceState.Idle)
    val voiceState: StateFlow<InlineVoiceState> = _voiceState.asStateFlow()

    val voicePartialText: StateFlow<String> = voiceEngine.partialText
    val voiceRmsLevel: StateFlow<Float> = voiceEngine.rmsLevel

    private val _isPolishing = MutableStateFlow(false)
    val isPolishing: StateFlow<Boolean> = _isPolishing.asStateFlow()

    private val _aiAssistOpen = MutableStateFlow(false)
    val aiAssistOpen: StateFlow<Boolean> = _aiAssistOpen.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun setPanelMode(mode: KeyboardPanelMode) {
        if (mode == KeyboardPanelMode.CLIPBOARD) {
            clipboardManager.syncCurrentPrimaryClip()
        }
        _panelMode.value = mode
    }

    fun setToolsExpanded(expanded: Boolean) {
        _toolsExpanded.value = expanded
    }

    fun toggleAiAssist() {
        _aiAssistOpen.value = !_aiAssistOpen.value
    }

    fun onKeyTap(rawChar: Char, settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.KEY_TAP, view, settings.keySoundEnabled)
        _lastSwipedWordLength.value = 0
        if (settings.predictionsEnabled) _toolsExpanded.value = false

        val effectiveChar = if (
            rawChar.isLetter() &&
            _shiftState.value != ShiftState.OFF &&
            _panelMode.value == KeyboardPanelMode.QWERTY
        ) {
            rawChar.uppercaseChar()
        } else {
            rawChar
        }

        val committed = UnicodeFontMapper.transform(
            effectiveChar.toString(),
            settings.unicodeOutputFont
        )
        textTarget.commitText(committed)

        if (_shiftState.value == ShiftState.SINGLE && rawChar.isLetter()) {
            _shiftState.value = ShiftState.OFF
        }
        refreshPredictions(settings)
    }

    fun onAccentTap(accentChar: Char, settings: VelvetSettings, view: View? = null) {
        onKeyTap(accentChar, settings, view)
    }

    fun onSwipeDecoded(candidates: List<String>, settings: VelvetSettings, view: View? = null) {
        val best = candidates.firstOrNull() ?: return
        haptics.trigger(settings.hapticProfile, HapticCue.SWIPE_WORD_COMMIT, view, settings.keySoundEnabled)
        if (settings.predictionsEnabled) _toolsExpanded.value = false

        val before = textTarget.getTextBeforeCursor(40)
        val needsLeadingSpace = before.isNotEmpty() && !before.last().isWhitespace()
        val casedWord = if (_shiftState.value != ShiftState.OFF) {
            best.replaceFirstChar { it.uppercaseChar() }
        } else {
            best
        }
        val styledWord = UnicodeFontMapper.transform(casedWord, settings.unicodeOutputFont)
        val prefix = if (needsLeadingSpace) " " else ""
        val insertion = "$prefix$styledWord "

        textTarget.commitText(insertion)
        _lastSwipedWordLength.value = insertion.length

        if (_shiftState.value == ShiftState.SINGLE) {
            _shiftState.value = ShiftState.OFF
        }

        _predictions.value = candidates.map { word ->
            if (casedWord.firstOrNull()?.isUpperCase() == true) {
                word.replaceFirstChar { it.uppercaseChar() }
            } else {
                word
            }
        }
        learnLastWordIfNeeded(best, settings)
        triggerAiNextWordIfEnabled(settings)
    }

    fun onPredictionSelected(word: String, settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        val before = textTarget.getTextBeforeCursor(80)
        val currentToken = extractCurrentWord(before)

        if (currentToken.isNotEmpty()) {
            textTarget.deleteBeforeCursor(currentToken.length)
        } else if (_lastSwipedWordLength.value > 0 && before.endsWith(" ")) {
            textTarget.deleteBeforeCursor(_lastSwipedWordLength.value)
        }

        val styled = UnicodeFontMapper.transform(word, settings.unicodeOutputFont)
        textTarget.commitText("$styled ")
        _lastSwipedWordLength.value = 0
        learnLastWordIfNeeded(word, settings)
        refreshPredictions(settings)
    }

    fun onSpaceTap(settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        _lastSwipedWordLength.value = 0

        val before = textTarget.getTextBeforeCursor(80)
        val finishedWord = extractCurrentWord(before)
        if (finishedWord.length >= 2) {
            learnLastWordIfNeeded(finishedWord, settings)
        }

        val now = System.currentTimeMillis()
        if (
            settings.doubleSpacePeriodEnabled &&
            now - lastSpaceTapMs < 360L &&
            before.length >= 2 &&
            before.endsWith(" ") &&
            !before[before.length - 2].isWhitespace() &&
            before[before.length - 2] != '.'
        ) {
            textTarget.deleteBeforeCursor(1)
            textTarget.commitText(". ")
            if (settings.autoCapitalizeEnabled && _shiftState.value == ShiftState.OFF) {
                _shiftState.value = ShiftState.SINGLE
            }
            lastSpaceTapMs = 0L
        } else {
            textTarget.commitText(" ")
            lastSpaceTapMs = now
        }
        refreshPredictions(settings)
    }

    fun onBackspace(settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.BACKSPACE, view, settings.keySoundEnabled)
        val swipedLen = _lastSwipedWordLength.value
        if (swipedLen > 0) {
            textTarget.deleteBeforeCursor(swipedLen)
            _lastSwipedWordLength.value = 0
        } else {
            textTarget.deleteBeforeCursor(1)
        }
        updateAutoShift(settings)
        refreshPredictions(settings)
    }

    fun onReturn(settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        _lastSwipedWordLength.value = 0
        val before = textTarget.getTextBeforeCursor(40)
        val finishedWord = extractCurrentWord(before)
        if (finishedWord.length >= 2) {
            learnLastWordIfNeeded(finishedWord, settings)
        }
        if (!textTarget.performAction()) {
            textTarget.commitText("\n")
        }
        updateAutoShift(settings)
        refreshPredictions(settings)
    }

    fun onShiftTap(settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        val now = System.currentTimeMillis()
        _shiftState.value = when (_shiftState.value) {
            ShiftState.OFF -> ShiftState.SINGLE
            ShiftState.SINGLE -> if (now - lastShiftTapMs < 350L) ShiftState.CAPS_LOCK else ShiftState.OFF
            ShiftState.CAPS_LOCK -> ShiftState.OFF
        }
        lastShiftTapMs = now
    }

    fun onEmojiSelected(symbol: String, settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.KEY_TAP, view, settings.keySoundEnabled)
        _lastSwipedWordLength.value = 0
        textTarget.commitText(symbol)
        scope.launch { settingsRepo.recordRecentEmoji(symbol) }
    }

    fun onPasteClipboard(text: String, settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        _lastSwipedWordLength.value = 0
        textTarget.commitText(text)
        _panelMode.value = KeyboardPanelMode.QWERTY
        refreshPredictions(settings)
    }

    fun togglePinClip(id: String) {
        scope.launch { settingsRepo.togglePinClipboard(id) }
    }

    fun deleteClip(id: String) {
        scope.launch { settingsRepo.deleteClipboardClip(id) }
    }

    fun clearUnpinnedClips() {
        scope.launch { settingsRepo.clearUnpinnedClipboard() }
    }

    fun syncSystemClipboard() {
        clipboardManager.syncCurrentPrimaryClip()
        showToast("Clipboard synced")
    }

    fun addCustomEmoji(symbol: String, label: String) {
        scope.launch {
            settingsRepo.addCustomEmoji(symbol, label)
            showToast("Added $symbol to iOS & Custom pack")
        }
    }

    fun toggleDarkModeQuick(currentDark: Boolean) {
        scope.launch {
            val next = if (currentDark) {
                com.example.data.DarkModeOption.LIGHT
            } else {
                com.example.data.DarkModeOption.LATE_NIGHT_DARK
            }
            settingsRepo.setDarkMode(next)
        }
    }

    fun cycleLanguageQuick(settings: VelvetSettings, view: View? = null) {
        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        val enabled = settings.enabledLanguages
        if (enabled.size <= 1) {
            onSwitchIme?.invoke()
            return
        }
        val idx = enabled.indexOf(settings.activeLanguage)
        val next = enabled[(idx + 1) % enabled.size]
        scope.launch {
            settingsRepo.setActiveLanguage(next)
            showToast(next.nativeName)
        }
    }

    fun cycleFontQuick(current: com.example.data.KeyboardFontId) {
        val entries = com.example.data.KeyboardFontId.entries
        val next = entries[(entries.indexOf(current) + 1) % entries.size]
        scope.launch {
            settingsRepo.setFont(next)
            showToast("Font: ${next.label}")
        }
    }

    fun switchImeIfAvailable() {
        onSwitchIme?.invoke()
    }

    fun openSettingsIfAvailable() {
        onOpenSettings?.invoke()
    }

    fun speakCurrentText(settings: VelvetSettings) {
        if (ttsSpeaker.isSpeaking.value || ttsSpeaker.isSynthesizing.value) {
            ttsSpeaker.stop()
            showToast("Speech stopped")
            return
        }
        val text = textTarget.getTextBeforeCursor(500).trim()
        if (text.isEmpty()) {
            showToast("Type or dictate text to read aloud")
            return
        }
        showToast("Generating AI voice...")
        ttsSpeaker.speak(
            scope = scope,
            text = text,
            language = settings.activeLanguage,
            onError = { err -> showToast(err) }
        )
    }

    // Inline Gboard-style Velvet AI Voice Dictation (no separate full-keyboard menu)
    fun toggleInlineVoice(settings: VelvetSettings, view: View? = null) {
        when (_voiceState.value) {
            InlineVoiceState.Idle, is InlineVoiceState.Error -> startInlineVoice(settings, view)
            InlineVoiceState.Listening -> finishInlineVoice(settings, view)
            InlineVoiceState.Processing -> Unit
        }
    }

    private fun startInlineVoice(settings: VelvetSettings, view: View?) {
        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        if (!voiceEngine.hasMicPermission()) {
            _voiceState.value = InlineVoiceState.Error("Mic permission needed")
            onRequestMicPermission?.invoke()
            return
        }

        _voiceState.value = InlineVoiceState.Listening
        voiceEngine.startListening(
            scope = scope,
            language = settings.activeLanguage,
            preferPureAiMic = settings.pureAiVoiceEnabled,
            onFinalRawTranscript = { raw ->
                processRawVoiceTranscript(raw, settings)
            },
            onFallbackAudioReady = { wavBytes ->
                processFallbackWavAudio(wavBytes, settings)
            },
            onError = { msg ->
                _voiceState.value = InlineVoiceState.Error(msg)
                showToast(msg)
            }
        )
    }

    private fun finishInlineVoice(settings: VelvetSettings, view: View?) {
        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        _voiceState.value = InlineVoiceState.Processing
        voiceEngine.finishListening(
            onFinalRawTranscript = { raw ->
                processRawVoiceTranscript(raw, settings)
            },
            onFallbackAudioReady = { wavBytes ->
                processFallbackWavAudio(wavBytes, settings)
            },
            onError = { msg ->
                _voiceState.value = InlineVoiceState.Error(msg)
                showToast(msg)
            }
        )
    }

    fun cancelInlineVoice() {
        voiceEngine.cancel()
        _voiceState.value = InlineVoiceState.Idle
    }

    private fun processRawVoiceTranscript(raw: String, settings: VelvetSettings) {
        _voiceState.value = InlineVoiceState.Processing
        val before = textTarget.getTextBeforeCursor(80)
        scope.launch {
            when (
                val res = aiEngine.refineVoiceTranscript(
                    rawTranscript = raw,
                    language = settings.activeLanguage,
                    removeStarters = settings.aiRemoveStartersEnabled,
                    autoPunctuate = settings.aiAutoPunctuationEnabled,
                    preserveSlang = settings.adaptToSlangEnabled
                )
            ) {
                is AiResult.Success -> {
                    val spacer = if (before.isNotEmpty() && !before.last().isWhitespace()) " " else ""
                    val styled = UnicodeFontMapper.transform(res.value, settings.unicodeOutputFont)
                    textTarget.commitText("$spacer$styled ")
                    haptics.trigger(settings.hapticProfile, HapticCue.AI_SUCCESS, null, false)
                    _voiceState.value = InlineVoiceState.Idle
                    refreshPredictions(settings)
                }
                is AiResult.Error -> {
                    // Fallback gracefully only on error by surfacing the real error
                    _voiceState.value = InlineVoiceState.Error(res.message)
                    showToast(res.message)
                }
            }
        }
    }

    private fun processFallbackWavAudio(wavBytes: ByteArray, settings: VelvetSettings) {
        _voiceState.value = InlineVoiceState.Processing
        val before = textTarget.getTextBeforeCursor(160)
        scope.launch {
            when (
                val res = aiEngine.transcribeAndEnhanceAudio(
                    wavBytes = wavBytes,
                    contextPrefix = before,
                    language = settings.activeLanguage,
                    removeStarters = settings.aiRemoveStartersEnabled,
                    autoPunctuate = settings.aiAutoPunctuationEnabled,
                    predictContinuation = settings.aiSmartPredictEnabled,
                    preserveSlang = settings.adaptToSlangEnabled
                )
            ) {
                is AiResult.Success -> {
                    val spacer = if (before.isNotEmpty() && !before.last().isWhitespace()) " " else ""
                    val styled = UnicodeFontMapper.transform(res.value, settings.unicodeOutputFont)
                    textTarget.commitText("$spacer$styled ")
                    haptics.trigger(settings.hapticProfile, HapticCue.AI_SUCCESS, null, false)
                    _voiceState.value = InlineVoiceState.Idle
                    refreshPredictions(settings)
                }
                is AiResult.Error -> {
                    _voiceState.value = InlineVoiceState.Error(res.message)
                    showToast(res.message)
                }
            }
        }
    }

    fun polishCurrentText(
        settings: VelvetSettings,
        view: View? = null,
        tone: AiWriteTone = AiWriteTone.NATURAL
    ) {
        if (_isPolishing.value) return
        val existing = textTarget.getTextBeforeCursor(800)
        if (existing.isBlank()) {
            showToast("Type or dictate text first")
            return
        }

        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        _isPolishing.value = true

        scope.launch {
            when (
                val res = aiEngine.polishText(
                    rawText = existing,
                    language = settings.activeLanguage,
                    removeStarters = settings.aiRemoveStartersEnabled,
                    autoPunctuate = settings.aiAutoPunctuationEnabled,
                    preserveSlang = settings.adaptToSlangEnabled,
                    tone = tone
                )
            ) {
                is AiResult.Success -> {
                    textTarget.replaceAllText(res.value)
                    haptics.trigger(settings.hapticProfile, HapticCue.AI_SUCCESS, view, false)
                    showToast("Improved (${tone.label})")
                    refreshPredictions(settings)
                }
                is AiResult.Error -> {
                    showToast(res.message)
                }
            }
            _isPolishing.value = false
        }
    }

    fun fixGrammarCurrentText(settings: VelvetSettings, view: View? = null) {
        if (_isPolishing.value) return
        val existing = textTarget.getTextBeforeCursor(800)
        if (existing.isBlank()) {
            showToast("Type some text first to check grammar")
            return
        }

        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        _isPolishing.value = true

        scope.launch {
            when (
                val res = aiEngine.fixGrammarAndClarity(
                    rawText = existing,
                    language = settings.activeLanguage,
                    preserveSlang = settings.adaptToSlangEnabled
                )
            ) {
                is AiResult.Success -> {
                    textTarget.replaceAllText(res.value)
                    haptics.trigger(settings.hapticProfile, HapticCue.AI_SUCCESS, view, false)
                    showToast("Grammar & clarity fixed")
                    refreshPredictions(settings)
                }
                is AiResult.Error -> {
                    showToast(res.message)
                }
            }
            _isPolishing.value = false
        }
    }

    fun autoGenerateFromCurrentText(
        settings: VelvetSettings,
        view: View? = null,
        tone: AiWriteTone = AiWriteTone.NATURAL
    ) {
        if (_isPolishing.value) return
        val seed = textTarget.getTextBeforeCursor(500).trim()
        if (seed.isBlank()) {
            showToast("Type a short prompt first, e.g. 'late 10m'")
            return
        }

        haptics.trigger(settings.hapticProfile, HapticCue.MODIFIER_TAP, view, settings.keySoundEnabled)
        _isPolishing.value = true

        scope.launch {
            when (
                val res = aiEngine.autoGenerateText(
                    promptOrDraft = seed,
                    language = settings.activeLanguage,
                    tone = tone
                )
            ) {
                is AiResult.Success -> {
                    textTarget.replaceAllText(res.value)
                    haptics.trigger(settings.hapticProfile, HapticCue.AI_SUCCESS, view, false)
                    showToast("Written by Velvet AI")
                    refreshPredictions(settings)
                }
                is AiResult.Error -> {
                    showToast(res.message)
                }
            }
            _isPolishing.value = false
        }
    }

    fun refreshPredictions(settings: VelvetSettings) {
        if (!settings.predictionsEnabled) return
        val before = textTarget.getTextBeforeCursor(120)
        val currentWord = extractCurrentWord(before)
        val previousWord = extractPreviousWord(before, currentWord)
        val learned = if (settings.adaptToSlangEnabled) settings.learnedWords else emptyMap()
        _predictions.value = WordDictionary.getPredictions(
            currentWord = currentWord,
            previousWord = previousWord,
            language = settings.activeLanguage,
            learnedWords = learned
        )

        if (currentWord.isEmpty() && settings.aiSmartPredictEnabled && before.trim().length >= 8) {
            triggerAiNextWordIfEnabled(settings)
        }
    }

    private fun triggerAiNextWordIfEnabled(settings: VelvetSettings) {
        if (!settings.predictionsEnabled || !settings.aiSmartPredictEnabled) return
        aiPredictionJob?.cancel()
        aiPredictionJob = scope.launch {
            delay(300L)
            val before = textTarget.getTextBeforeCursor(140)
            if (before.trim().length < 8) return@launch
            val topSlang = if (settings.adaptToSlangEnabled) {
                settings.learnedWords.entries.sortedByDescending { it.value }.take(10).map { it.key }
            } else emptyList()

            when (val res = aiEngine.predictNextWords(before, settings.activeLanguage, topSlang)) {
                is AiResult.Success -> {
                    if (res.value.isNotEmpty() && extractCurrentWord(textTarget.getTextBeforeCursor(80)).isEmpty()) {
                        val merged = (res.value + _predictions.value)
                            .distinctBy { it.lowercase() }
                            .take(3)
                        _predictions.value = merged
                    }
                }
                is AiResult.Error -> Unit
            }
        }
    }

    private fun learnLastWordIfNeeded(word: String, settings: VelvetSettings) {
        if (!settings.adaptToSlangEnabled) return
        val clean = word.trim().trimEnd('.', ',', '!', '?')
        if (clean.length < 2) return
        scope.launch { settingsRepo.recordTypedWord(clean) }
    }

    private fun updateAutoShift(settings: VelvetSettings) {
        if (!settings.autoCapitalizeEnabled || _shiftState.value == ShiftState.CAPS_LOCK) return
        val before = textTarget.getTextBeforeCursor(4)
        val shouldCap = before.isEmpty() ||
            before.endsWith("\n") ||
            before.endsWith(". ") ||
            before.endsWith("? ") ||
            before.endsWith("! ")
        _shiftState.value = if (shouldCap) ShiftState.SINGLE else ShiftState.OFF
    }

    private fun extractCurrentWord(textBefore: String): String {
        if (textBefore.isEmpty() || textBefore.last().isWhitespace()) return ""
        val idx = textBefore.indexOfLast { it.isWhitespace() }
        return if (idx == -1) textBefore else textBefore.substring(idx + 1)
    }

    private fun extractPreviousWord(textBefore: String, currentWord: String): String? {
        val withoutCurrent = if (currentWord.isNotEmpty()) {
            textBefore.dropLast(currentWord.length)
        } else {
            textBefore
        }.trimEnd()
        if (withoutCurrent.isEmpty()) return null
        val idx = withoutCurrent.indexOfLast { it.isWhitespace() }
        val token = if (idx == -1) withoutCurrent else withoutCurrent.substring(idx + 1)
        return token.trimEnd('.', ',', '!', '?')
    }

    private fun showToast(msg: String) {
        _toastMessage.value = msg
        scope.launch {
            delay(2200L)
            if (_toastMessage.value == msg) {
                _toastMessage.value = null
            }
        }
    }
}
