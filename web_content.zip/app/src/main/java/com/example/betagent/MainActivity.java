package com.example.betagent;
import android.app.*; import android.os.*; import android.webkit.*; import android.content.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); w.getSettings().setJavaScriptEnabled(true); w.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView v,String u){startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(u)));return true;}}); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
}