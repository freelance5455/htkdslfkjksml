package com.example.system

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.CareCategory
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val categoryKey = intent.getStringExtra(EXTRA_CATEGORY_KEY) ?: CareCategory.DRINK_WATER.key
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Haven Care Reminder"
        val body = intent.getStringExtra(EXTRA_BODY) ?: "Time for your daily wellness check-in."
        ReminderNotificationManager(context).showNotificationNow(categoryKey.hashCode(), title, body)
    }

    companion object {
        const val EXTRA_CATEGORY_KEY = "extra_category_key"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_BODY = "extra_body"
    }
}

class ReminderNotificationManager(private val context: Context) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notification_channel_care_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = context.getString(R.string.notification_channel_care_desc)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun showNotificationNow(notificationId: Int, title: String, body: String) {
        ensureChannel()
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            context,
            notificationId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingOpen)
            .build()

        try {
            notificationManager.notify(notificationId, notification)
        } catch (_: SecurityException) {
            // Notification permission not yet granted by user
        }
    }

    fun scheduleDailyReminder(category: CareCategory, hour: Int, minute: Int, enabled: Boolean) {
        ensureChannel()
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_CATEGORY_KEY, category.key)
            putExtra(ReminderReceiver.EXTRA_TITLE, reminderTitle(category))
            putExtra(ReminderReceiver.EXTRA_BODY, reminderBody(category))
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            category.ordinal + 100,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (!enabled) {
            alarmManager.cancel(pendingIntent)
            return
        }

        val triggerAt = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        alarmManager.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            triggerAt.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            pendingIntent
        )
    }

    private fun reminderTitle(category: CareCategory): String = when (category) {
        CareCategory.WAKE_UP -> "Time to Wake Up Gently"
        CareCategory.DRINK_WATER -> "Drink Water Reminder"
        CareCategory.EAT_MEAL -> "Nourish Yourself — Meal Time"
        CareCategory.PEE -> "Bathroom Check — Pee Break"
        CareCategory.POOP -> "Digestive Check — Poop Break"
        CareCategory.BATH -> "Fresh Bath / Shower Time"
        CareCategory.EXERCISE -> "Move Your Body — Exercise"
        CareCategory.FRESH_AIR -> "Step Outside for Fresh Air"
        CareCategory.SLEEP -> "Sleep Wind-Down Time"
    }

    private fun reminderBody(category: CareCategory): String = when (category) {
        CareCategory.WAKE_UP -> "Stretch, open a window, and log your morning wake-up in Haven."
        CareCategory.DRINK_WATER -> "Take a few sips of water right now to keep your brain and body hydrated."
        CareCategory.EAT_MEAL -> "Don't skip fuel—grab something nourishing and log your meal."
        CareCategory.PEE -> "Never hold it in at school or home—take a quick pee break."
        CareCategory.POOP -> "Check in with your tummy and stay regular without stress."
        CareCategory.BATH -> "Wash away the day's stress with a warm bath or shower."
        CareCategory.EXERCISE -> "Even 15–30 minutes of movement boosts mood and hormone balance."
        CareCategory.FRESH_AIR -> "Take 10 minutes outside in sunlight and fresh air."
        CareCategory.SLEEP -> "Turn other apps down in Haven and get 8–9 hours of rest."
    }

    companion object {
        private const val CHANNEL_ID = "haven_daily_care_channel"
    }
}
