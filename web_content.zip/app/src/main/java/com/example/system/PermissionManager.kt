package com.example.system

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import org.json.JSONObject

data class PermissionStatus(
    val permission: String,
    val isGranted: Boolean,
    val displayName: String,
    val description: String
)

/**
 * İzin Yöneticisi (PermissionManager).
 * Sadece gerçekten gerekli izinleri kullanıcıya açıklar ve durumlarını kontrol eder.
 */
class PermissionManager(private val context: Context) {

    fun getPermissionsStateJson(): String {
        val root = JSONObject()
        val list = listOf(
            PermissionStatus(
                permission = Manifest.permission.RECORD_AUDIO,
                isGranted = isGranted(Manifest.permission.RECORD_AUDIO),
                displayName = "Mikrofon",
                description = "Suesa ile sesli konuşmak ve sesinizi metne çevirmek için gereklidir."
            ),
            PermissionStatus(
                permission = Manifest.permission.CAMERA,
                isGranted = isGranted(Manifest.permission.CAMERA),
                displayName = "Kamera",
                description = "Fotoğraf çekerek görsel analiz yapabilmek için gereklidir."
            ),
            PermissionStatus(
                permission = Manifest.permission.READ_CONTACTS,
                isGranted = isGranted(Manifest.permission.READ_CONTACTS),
                displayName = "Rehber / Kişiler",
                description = "\"Ahmet'i ara\" dediğinizde kişiyi rehberinizde bulabilmek için gereklidir."
            ),
            PermissionStatus(
                permission = Manifest.permission.CALL_PHONE,
                isGranted = isGranted(Manifest.permission.CALL_PHONE),
                displayName = "Doğrudan Arama",
                description = "Komut verdiğinizde aramayı doğrudan başlatabilmek için gereklidir."
            )
        )

        for (item in list) {
            val itemObj = JSONObject().apply {
                put("granted", item.isGranted)
                put("displayName", item.displayName)
                put("description", item.description)
            }
            root.put(item.permission, itemObj)
        }
        return root.toString()
    }

    fun isGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }
}
