package com.example.system

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.ai.AppType
import com.example.ai.SettingType

data class ActionResult(
    val isSuccess: Boolean,
    val message: String,
    val requiresPermission: String? = null
)

/**
 * Android Telefon Sistem İşlemleri Yöneticisi (AndroidActionManager).
 * Suesa'nın sistem genelinde uygulamaları ve ayarları güvenle açmasını sağlar.
 */
class AndroidActionManager(private val context: Context) {

    fun executeAppAction(appType: AppType, customParam: String? = null): ActionResult {
        return try {
            when (appType) {
                AppType.GOOGLE -> openGoogle()
                AppType.YOUTUBE -> openYouTube()
                AppType.CHROME -> openChrome()
                AppType.WHATSAPP -> openWhatsApp()
                AppType.CAMERA -> openCamera()
                AppType.GALLERY -> openGallery()
                AppType.MESSAGES -> openMessages()
                AppType.DIALER -> openPhone()
                AppType.CLOCK_ALARM -> openClockOrAlarm()
                AppType.CALCULATOR -> openCalculator()
                AppType.SETTINGS -> openSetting(SettingType.GENERAL)
                AppType.CUSTOM -> {
                    if (!customParam.isNullOrBlank()) {
                        openApplicationByName(customParam)
                    } else {
                        ActionResult(false, "Açılacak uygulama adı belirtilmedi.")
                    }
                }
            }
        } catch (e: Exception) {
            ActionResult(false, "İşlem açılamadı: ${e.localizedMessage ?: "Bilinmeyen hata"}")
        }
    }

    fun openGoogle(): ActionResult {
        // 1. Google Arama Uygulaması
        val googlePackages = listOf(
            "com.google.android.googlequicksearchbox",
            "com.google.android.apps.searchlite"
        )
        for (pkg in googlePackages) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                return ActionResult(true, "Tamam.")
            }
        }

        // 2. Cihazda Google uygulaması yoksa tarayıcı ile Google'ı aç
        return try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(browserIntent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            ActionResult(false, "Google uygulaması telefonunda yüklü görünmüyor. Tarayıcıyla Google'ı açmamı ister misin?")
        }
    }

    fun openYouTube(query: String? = null): ActionResult {
        return try {
            val intent = if (!query.isNullOrBlank()) {
                Intent(Intent.ACTION_SEARCH).apply {
                    setPackage("com.google.android.youtube")
                    putExtra("query", query)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            } else {
                context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
            }
            context.startActivity(intent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(webIntent)
                ActionResult(true, "Tamam.")
            } catch (ex: Exception) {
                ActionResult(false, "YouTube uygulaması bulunamadı.")
            }
        }
    }

    fun openChrome(): ActionResult {
        val chromePkg = "com.android.chrome"
        val intent = context.packageManager.getLaunchIntentForPackage(chromePkg)
        if (intent != null) {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            return ActionResult(true, "Tamam.")
        }
        return try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(browserIntent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            ActionResult(false, "Chrome uygulaması telefonunda yüklü görünmüyor.")
        }
    }

    fun openWhatsApp(): ActionResult {
        val pkg = "com.whatsapp"
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) {
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            return ActionResult(true, "Tamam.")
        }
        return ActionResult(false, "WhatsApp uygulaması telefonunda yüklü görünmüyor.")
    }

    fun openCamera(): ActionResult {
        return try {
            val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            ActionResult(false, "Kamera başlatılamadı.")
        }
    }

    fun openGallery(): ActionResult {
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "image/*"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            ActionResult(false, "Galeri açılamadı.")
        }
    }

    fun openPhone(): ActionResult {
        return try {
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(dialIntent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            ActionResult(false, "Telefon uygulaması açılamadı.")
        }
    }

    fun openMessages(phoneNumber: String? = null, body: String? = null): ActionResult {
        return try {
            val uri = if (!phoneNumber.isNullOrBlank()) {
                Uri.parse("smsto:$phoneNumber")
            } else {
                Uri.parse("smsto:")
            }
            val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
                if (!body.isNullOrBlank()) putExtra("sms_body", body)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            ActionResult(false, "Mesajlar açılamadı.")
        }
    }

    fun openClockOrAlarm(): ActionResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            ActionResult(false, "Saat ve Alarmlar açılamadı.")
        }
    }

    fun openCalculator(): ActionResult {
        return try {
            val calcPackages = listOf(
                "com.google.android.calculator",
                "com.android.calculator2",
                "com.sec.android.app.popupcalculator",
                "com.miui.calculator"
            )
            for (pkg in calcPackages) {
                val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    context.startActivity(launchIntent)
                    return ActionResult(true, "Tamam.")
                }
            }
            ActionResult(false, "Cihazda hesap makinesi uygulaması bulunamadı.")
        } catch (e: Exception) {
            ActionResult(false, "Hesap makinesi başlatılamadı.")
        }
    }

    fun openSetting(settingType: SettingType): ActionResult {
        return try {
            val action = when (settingType) {
                SettingType.WIFI -> Settings.ACTION_WIFI_SETTINGS
                SettingType.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
                SettingType.SOUND -> Settings.ACTION_SOUND_SETTINGS
                SettingType.APPLICATIONS -> Settings.ACTION_APPLICATION_SETTINGS
                SettingType.GENERAL -> Settings.ACTION_SETTINGS
            }
            val intent = Intent(action).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Tamam.")
        } catch (e: Exception) {
            ActionResult(false, "Ayar ekranı açılamadı.")
        }
    }

    fun openDefaultAssistantSettings(): ActionResult {
        return try {
            val intent = Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            ActionResult(true, "Asistan ayarları açıldı.")
        } catch (e: Exception) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                ActionResult(true, "Varsayılan uygulama ayarları açıldı.")
            } catch (ex: Exception) {
                ActionResult(false, "Asistan ayar ekranı açılamadı.")
            }
        }
    }

    fun openApplicationByName(appName: String): ActionResult {
        val clean = appName.trim().lowercase()
        if (clean.contains("google") && !clean.contains("chrome")) return openGoogle()
        if (clean.contains("youtube")) return openYouTube()
        if (clean.contains("chrome")) return openChrome()
        if (clean.contains("whatsapp")) return openWhatsApp()
        if (clean.contains("kamera") || clean.contains("camera")) return openCamera()
        if (clean.contains("galeri") || clean.contains("gallery")) return openGallery()
        if (clean.contains("telefon") || clean.contains("arama")) return openPhone()
        if (clean.contains("mesaj") || clean.contains("sms")) return openMessages()
        if (clean.contains("saat") || clean.contains("alarm")) return openClockOrAlarm()
        if (clean.contains("ayar") || clean.contains("setting")) return openSetting(SettingType.GENERAL)

        val pkg = findInstalledApplicationPackage(clean)
        if (pkg != null) {
            val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) {
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(intent)
                return ActionResult(true, "Tamam.")
            }
        }
        return ActionResult(false, "$appName uygulaması telefonunda yüklü görünmüyor.")
    }

    private fun findInstalledApplicationPackage(query: String): String? {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        for (info in resolveInfos) {
            val label = info.loadLabel(pm).toString().lowercase()
            val pkg = info.activityInfo.packageName.lowercase()
            if (label.contains(query) || pkg.contains(query)) {
                return info.activityInfo.packageName
            }
        }
        return null
    }

    fun searchAndCall(target: String): ActionResult {
        val cleanTarget = target.trim()
        if (cleanTarget.matches(Regex("^[+0-9\\s\\-]{3,}$"))) {
            return initiateCall(cleanTarget)
        }

        val contactsPermission = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_CONTACTS
        )
        if (contactsPermission != PackageManager.PERMISSION_GRANTED) {
            return ActionResult(
                isSuccess = false,
                message = "\"$cleanTarget\" kişisini arayabilmem için Rehber izni gerekiyor.",
                requiresPermission = android.Manifest.permission.READ_CONTACTS
            )
        }

        val contactNumber = findContactNumberByName(cleanTarget)
        if (contactNumber != null) {
            return initiateCall(contactNumber)
        } else {
            return ActionResult(
                isSuccess = false,
                message = "Rehberinde \"$cleanTarget\" bulunamadı."
            )
        }
    }

    private fun findContactNumberByName(name: String): String? {
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$name%")

        resolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
            val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            if (cursor.moveToFirst() && numberIndex != -1) {
                return cursor.getString(numberIndex)
            }
        }
        return null
    }

    private fun initiateCall(phoneNumber: String): ActionResult {
        val callPermission = ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.CALL_PHONE
        )

        return try {
            if (callPermission == PackageManager.PERMISSION_GRANTED) {
                val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(callIntent)
                ActionResult(true, "$phoneNumber aranıyor...")
            } else {
                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(dialIntent)
                ActionResult(true, "$phoneNumber için arama ekranı açıldı.")
            }
        } catch (e: Exception) {
            ActionResult(false, "Arama başlatılamadı: ${e.message}")
        }
    }
}
