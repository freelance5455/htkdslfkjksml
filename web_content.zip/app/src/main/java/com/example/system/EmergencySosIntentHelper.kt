package com.example.system

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.local.EmergencyContactEntity
import com.example.data.model.PhoneCommandResult
import com.example.data.model.UserProfile
import java.net.URLEncoder

enum class SosTriggerAction {
    CALL_AUTHORITY,
    SEND_PRECONFIGURED_SMS,
    WHATSAPP_OR_SHARE
}

/**
 * Helper class that uses Android's Intent system to initiate emergency calls
 * or send pre-configured SMS / messenger alerts when an SOS trigger is activated.
 */
class EmergencySosIntentHelper(private val context: Context) {

    fun buildEmergencyDialIntent(phoneNumber: String): Intent {
        val cleaned = phoneNumber.trim().ifBlank { DEFAULT_EMERGENCY_NUMBER }
        return Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(cleaned)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun buildPreConfiguredSmsIntent(
        recipients: List<String>,
        messageBody: String
    ): Intent {
        val cleanedRecipients = recipients
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(separator = ";")
        val smsUri = Uri.parse("smsto:${Uri.encode(cleanedRecipients)}")
        return Intent(Intent.ACTION_SENDTO, smsUri).apply {
            putExtra("sms_body", messageBody)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun buildWhatsAppOrShareIntent(
        phoneNumber: String?,
        messageBody: String
    ): Intent {
        val digits = phoneNumber.orEmpty().filter { it.isDigit() }
        val waUrl = if (digits.isNotEmpty()) {
            "https://wa.me/$digits?text=${URLEncoder.encode(messageBody, "UTF-8")}"
        } else {
            "https://wa.me/?text=${URLEncoder.encode(messageBody, "UTF-8")}"
        }
        val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse(waUrl)).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (waIntent.resolveActivity(context.packageManager) != null) {
            waIntent
        } else {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, messageBody)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            Intent.createChooser(shareIntent, "Send SOS Alert").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        }
    }

    fun buildPreConfiguredSosMessage(
        profile: UserProfile,
        locationText: String,
        customReason: String = ""
    ): String = buildString {
        val userName = profile.name.ifBlank { "Haven Teen User" }
        append("SOS EMERGENCY ALERT from $userName (Age ${profile.age}): ")
        append(customReason.ifBlank { DEFAULT_SOS_BODY })
        append("\nLocation: $locationText")
        append("\nMedical ID: Blood ${profile.bloodType}, Allergies: ${profile.allergies}")
        if (profile.medicalNotes.isNotBlank()) {
            append(", Notes: ${profile.medicalNotes}")
        }
    }

    fun initiateEmergencyCall(authorityNumber: String): PhoneCommandResult {
        val cleaned = authorityNumber.trim().ifBlank { DEFAULT_EMERGENCY_NUMBER }
        return try {
            context.startActivity(buildEmergencyDialIntent(cleaned))
            PhoneCommandResult.Success("Emergency dialer opened for $cleaned.")
        } catch (e: Exception) {
            PhoneCommandResult.Info("No phone dialer app available on this device.")
        }
    }

    fun sendPreConfiguredSosSms(
        contacts: List<EmergencyContactEntity>,
        preConfiguredMessage: String
    ): PhoneCommandResult {
        val numbers = contacts.map { it.phone }.filter { it.isNotBlank() }
        return try {
            context.startActivity(buildPreConfiguredSmsIntent(numbers, preConfiguredMessage))
            val targetLabel = if (numbers.isEmpty()) "recipient" else "${numbers.size} trusted contact(s)"
            PhoneCommandResult.Success("Pre-configured SOS SMS ready for $targetLabel.")
        } catch (e: Exception) {
            PhoneCommandResult.Info("No SMS app available on this device.")
        }
    }

    fun activateSosTrigger(
        action: SosTriggerAction,
        profile: UserProfile,
        contacts: List<EmergencyContactEntity>,
        locationText: String,
        customMessage: String = ""
    ): PhoneCommandResult {
        val payload = buildPreConfiguredSosMessage(profile, locationText, customMessage)
        return when (action) {
            SosTriggerAction.CALL_AUTHORITY -> {
                initiateEmergencyCall(profile.emergencyAuthorityNumber)
            }
            SosTriggerAction.SEND_PRECONFIGURED_SMS -> {
                sendPreConfiguredSosSms(contacts, payload)
            }
            SosTriggerAction.WHATSAPP_OR_SHARE -> {
                val primaryPhone = contacts.firstOrNull()?.phone
                try {
                    context.startActivity(buildWhatsAppOrShareIntent(primaryPhone, payload))
                    PhoneCommandResult.Success("SOS alert opened in messenger.")
                } catch (e: Exception) {
                    sendPreConfiguredSosSms(contacts, payload)
                }
            }
        }
    }

    companion object {
        const val DEFAULT_EMERGENCY_NUMBER = "112"
        const val DEFAULT_SOS_BODY =
            "I need urgent help and my emergency call did not go through. Please check my location immediately."
    }
}
