package com.example.system

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.BuildConfig
import com.example.data.model.SubscriptionPlan
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

const val HAVEN_SUBSCRIBE_WEB_URL = "https://haven-rand-subscribe.lovable.app"

sealed interface SubscriptionWebSyncResult {
    data class ActiveOnWeb(
        val planId: String,
        val method: String,
        val reference: String,
        val expiresAtMillis: Long,
        val message: String
    ) : SubscriptionWebSyncResult

    data class NotSubscribedYet(val message: String) : SubscriptionWebSyncResult
    data class WebEndpointUnavailable(val message: String) : SubscriptionWebSyncResult
    data class OfflineOrError(val message: String) : SubscriptionWebSyncResult
}

class SubscriptionWebSyncService(private val context: Context) {

    fun isCustomSyncConfigured(): Boolean {
        val url = BuildConfig.SUBSCRIPTION_SYNC_URL
        return url.isNotBlank() && !url.startsWith("MY_") && url.startsWith("http")
    }

    fun buildSubscribeUri(
        subscriberIdentifier: String,
        plan: SubscriptionPlan,
        userName: String
    ): Uri {
        val cleanId = subscriberIdentifier.trim()
        val isEmail = cleanId.contains("@")
        return Uri.parse(HAVEN_SUBSCRIBE_WEB_URL).buildUpon()
            .appendQueryParameter("identifier", cleanId)
            .apply {
                if (isEmail) appendQueryParameter("email", cleanId)
                else if (cleanId.isNotBlank()) appendQueryParameter("phone", cleanId)
            }
            .appendQueryParameter("plan", plan.id)
            .appendQueryParameter("price", plan.priceLabel)
            .appendQueryParameter("name", userName.ifBlank { "Haven Member" })
            .appendQueryParameter("return_url", "haven://subscribe")
            .build()
    }

    fun openSubscribeWebsite(
        subscriberIdentifier: String,
        plan: SubscriptionPlan,
        userName: String,
        isDataFreeMode: Boolean
    ): Boolean {
        if (isDataFreeMode) return false
        return try {
            val uri = buildSubscribeUri(subscriberIdentifier, plan, userName)
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun syncWithWeb(
        subscriberIdentifier: String,
        confirmationCode: String = "",
        isDataFreeMode: Boolean
    ): SubscriptionWebSyncResult {
        val cleanId = subscriberIdentifier.trim()
        if (cleanId.isBlank()) {
            return SubscriptionWebSyncResult.OfflineOrError("Enter your email or phone number first.")
        }
        if (isDataFreeMode) {
            return SubscriptionWebSyncResult.OfflineOrError(
                "No-Data Limited Mode is ON. Turn off Data-Free Mode to sync with haven-rand-subscribe.lovable.app."
            )
        }

        val endpoints = buildList {
            if (isCustomSyncConfigured()) add(BuildConfig.SUBSCRIPTION_SYNC_URL.trim())
            add("$HAVEN_SUBSCRIBE_WEB_URL/api/subscription-status")
        }

        return withContext(Dispatchers.IO) {
            for (baseUrl in endpoints) {
                try {
                    val separator = if (baseUrl.contains("?")) "&" else "?"
                    val encodedId = URLEncoder.encode(cleanId, "UTF-8")
                    val encodedCode = URLEncoder.encode(confirmationCode.trim(), "UTF-8")
                    val fullUrl = "${baseUrl}${separator}identifier=$encodedId" +
                        if (cleanId.contains("@")) "&email=$encodedId" else "&phone=$encodedId" +
                        if (confirmationCode.isNotBlank()) "&code=$encodedCode" else ""

                    val conn = (URL(fullUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 7000
                        readTimeout = 7000
                        setRequestProperty("Accept", "application/json")
                    }
                    val status = conn.responseCode
                    val contentType = conn.contentType.orEmpty()
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    val body = stream?.use { BufferedReader(InputStreamReader(it)).readText() }.orEmpty()
                    conn.disconnect()

                    if (status in 200..299 && (contentType.contains("json", ignoreCase = true) || body.trimStart().startsWith("{"))) {
                        val json = JSONObject(body)
                        val statusStr = json.optString("status", "").lowercase()
                        val isActive = json.optBoolean("subscribed", false) ||
                            json.optBoolean("active", false) ||
                            statusStr in listOf("active", "paid", "subscribed", "plus")

                        if (isActive) {
                            val planId = json.optString("plan", SubscriptionPlan.MONTHLY.id)
                            val days = if (planId == SubscriptionPlan.WEEKLY.id) 7 else 30
                            val expiresAt = json.optLong("expiresAt", System.currentTimeMillis() + days * 86_400_000L)
                            val ref = json.optString("reference", confirmationCode.ifBlank { cleanId })
                            return@withContext SubscriptionWebSyncResult.ActiveOnWeb(
                                planId = planId,
                                method = "Haven Web Sync",
                                reference = ref,
                                expiresAtMillis = expiresAt,
                                message = "Subscription confirmed from haven-rand-subscribe.lovable.app! Fast AI, Voice Control & Phone AI unlocked ⚡"
                            )
                        } else {
                            return@withContext SubscriptionWebSyncResult.NotSubscribedYet(
                                "No active subscription recorded yet for this email/phone on haven-rand-subscribe.lovable.app."
                            )
                        }
                    }
                } catch (_: Exception) {
                    // Try next candidate or fall through cleanly
                }
            }

            SubscriptionWebSyncResult.WebEndpointUnavailable(
                "Complete your subscription on haven-rand-subscribe.lovable.app using your email or phone number, then enter your website confirmation code below (or return via app link) to unlock Haven Plus."
            )
        }
    }

    suspend fun notifyWebActivation(
        subscriberIdentifier: String,
        plan: SubscriptionPlan,
        reference: String
    ) {
        val targetUrl = if (isCustomSyncConfigured()) {
            BuildConfig.SUBSCRIPTION_SYNC_URL.trim()
        } else {
            "$HAVEN_SUBSCRIBE_WEB_URL/api/subscription-activate"
        }
        withContext(Dispatchers.IO) {
            try {
                val conn = (URL(targetUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 6000
                    readTimeout = 6000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }
                val payload = JSONObject().apply {
                    put("identifier", subscriberIdentifier.trim())
                    if (subscriberIdentifier.contains("@")) put("email", subscriberIdentifier.trim())
                    else put("phone", subscriberIdentifier.trim())
                    put("plan", plan.id)
                    put("reference", reference.trim())
                    put("subscribed", true)
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(payload.toString())
                    writer.flush()
                }
                conn.responseCode
                conn.disconnect()
            } catch (_: Exception) {
            }
        }
    }
}
