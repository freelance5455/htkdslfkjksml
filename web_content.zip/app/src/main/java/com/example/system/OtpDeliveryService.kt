package com.example.system

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.BuildConfig
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

enum class OtpChannel(val label: String) {
    GMAIL_OR_EMAIL("Gmail / Email"),
    GLOBAL_PHONE("Global Phone Number")
}

sealed interface OtpSendResult {
    data class DeliveredLive(val recipient: String, val aiNotice: String) : OtpSendResult
    data class OfflineOrUnconfigured(
        val recipient: String,
        val reason: String,
        val aiNotice: String
    ) : OtpSendResult
    data class Error(val message: String) : OtpSendResult
}

class OtpDeliveryService(private val context: Context) {

    fun isWebhookConfigured(): Boolean {
        val url = BuildConfig.OTP_WEBHOOK_URL
        val key = BuildConfig.OTP_WEBHOOK_KEY
        return url.isNotBlank() &&
            !url.startsWith("MY_") &&
            url.startsWith("http") &&
            key.isNotBlank() &&
            !key.startsWith("MY_")
    }

    suspend fun sendOtp(
        channel: OtpChannel,
        recipient: String,
        code: String,
        isDataFreeMode: Boolean,
        languageName: String
    ): OtpSendResult {
        val cleanRecipient = recipient.trim()
        if (cleanRecipient.isBlank()) {
            return OtpSendResult.Error("Please enter a valid ${channel.label}.")
        }

        val maskedTarget = maskRecipient(channel, cleanRecipient)
        val uiNotice = "Haven Personal AI ($languageName): 6-digit verification code prepared for $maskedTarget. Check your ${if (channel == OtpChannel.GMAIL_OR_EMAIL) "Gmail / email inbox" else "SMS messages"}."
        val deliveryBody = "Haven Personal AI ($languageName): Your verification code is $code. Keep it private—no ads, no third-party tracking."

        if (isDataFreeMode) {
            return OtpSendResult.OfflineOrUnconfigured(
                recipient = cleanRecipient,
                reason = "Limited Data-Free Mode is active: remote delivery is paused. Use SMS/Email app dispatch below or switch Data Mode on.",
                aiNotice = uiNotice
            )
        }

        if (!isWebhookConfigured()) {
            return OtpSendResult.OfflineOrUnconfigured(
                recipient = cleanRecipient,
                reason = "Opening your device ${if (channel == OtpChannel.GMAIL_OR_EMAIL) "Gmail/Email" else "SMS"} app to deliver to $maskedTarget (for silent server delivery, set OTP_WEBHOOK_URL & OTP_WEBHOOK_KEY in AI Studio Secrets).",
                aiNotice = uiNotice
            )
        }

        return withContext(Dispatchers.IO) {
            try {
                val url = URL(BuildConfig.OTP_WEBHOOK_URL)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 8000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer ${BuildConfig.OTP_WEBHOOK_KEY}")
                }
                val payload = JSONObject().apply {
                    put("channel", if (channel == OtpChannel.GMAIL_OR_EMAIL) "email" else "sms")
                    put("recipient", cleanRecipient)
                    put("otp", code)
                    put("subject", "Your Haven Verification Code")
                    put("message", deliveryBody)
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(payload.toString())
                    writer.flush()
                }
                val status = conn.responseCode
                conn.disconnect()
                if (status in 200..299) {
                    OtpSendResult.DeliveredLive(cleanRecipient, uiNotice)
                } else {
                    OtpSendResult.OfflineOrUnconfigured(
                        recipient = cleanRecipient,
                        reason = "OTP relay responded with HTTP $status. Dispatch via your device Gmail/SMS app below.",
                        aiNotice = uiNotice
                    )
                }
            } catch (e: Exception) {
                OtpSendResult.OfflineOrUnconfigured(
                    recipient = cleanRecipient,
                    reason = "Network unreachable (${e.message ?: "offline"}). Dispatch via your device Gmail/SMS app below.",
                    aiNotice = uiNotice
                )
            }
        }
    }

    fun launchDeviceEmailOtp(email: String, code: String): Boolean {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${Uri.encode(email.trim())}")).apply {
            putExtra(Intent.EXTRA_SUBJECT, "Haven Verification OTP: $code")
            putExtra(Intent.EXTRA_TEXT, "Your Haven AI verification code is: $code")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchDeviceSmsOtp(phoneNumber: String, code: String): Boolean {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phoneNumber.trim())}")).apply {
            putExtra("sms_body", "Haven Verification Code: $code")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    companion object {
        fun maskEmail(email: String): String {
            val trimmed = email.trim()
            val atIdx = trimmed.indexOf('@')
            if (atIdx <= 0) return "***"
            val local = trimmed.substring(0, atIdx)
            val domain = trimmed.substring(atIdx + 1)
            val maskedLocal = when {
                local.length <= 1 -> "*"
                local.length == 2 -> "${local.first()}*"
                else -> "${local.take(2)}${"*".repeat((local.length - 3).coerceAtLeast(2))}${local.last()}"
            }
            val dotIdx = domain.lastIndexOf('.')
            val maskedDomain = if (dotIdx > 1) {
                val host = domain.substring(0, dotIdx)
                val tld = domain.substring(dotIdx)
                val maskedHost = if (host.length <= 2) "${host.first()}*" else "${host.first()}${"*".repeat((host.length - 2).coerceAtLeast(2))}${host.last()}"
                "$maskedHost$tld"
            } else {
                domain
            }
            return "$maskedLocal@$maskedDomain"
        }

        fun maskPhone(phone: String): String {
            val clean = phone.trim()
            val digits = clean.filter { it.isDigit() }
            if (digits.length <= 4) return "****"
            val prefix = if (clean.startsWith("+")) "+${digits.take(2)} " else digits.take(3) + " "
            val lastPart = digits.takeLast(4)
            val hiddenLen = (digits.length - (if (clean.startsWith("+")) 6 else 7)).coerceAtLeast(3)
            return "$prefix${"*".repeat(hiddenLen)} $lastPart"
        }

        fun maskRecipient(channel: OtpChannel, recipient: String): String =
            if (channel == OtpChannel.GMAIL_OR_EMAIL) maskEmail(recipient) else maskPhone(recipient)
    }
}
