package com.example.system

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.model.PhoneCommandResult
import java.net.URLEncoder

class PhoneControlManager(private val context: Context) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val audioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun hasDndPolicyAccess(): Boolean =
        notificationManager.isNotificationPolicyAccessGranted

    fun openDndPolicySettings() {
        val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun setSleepQuietMode(enable: Boolean): PhoneCommandResult {
        return if (hasDndPolicyAccess()) {
            try {
                notificationManager.setInterruptionFilter(
                    if (enable) NotificationManager.INTERRUPTION_FILTER_ALARMS
                    else NotificationManager.INTERRUPTION_FILTER_ALL
                )
                if (enable) {
                    val maxMedia = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (maxMedia * 0.2f).toInt(), 0)
                }
                PhoneCommandResult.Success(
                    if (enable) "Sleep Quiet Mode ON: Other apps silenced (alarms allowed) & media lowered."
                    else "Sleep Quiet Mode OFF: Normal notifications restored."
                )
            } catch (e: SecurityException) {
                PhoneCommandResult.NeedsPermission(
                    "Grant Do Not Disturb access so Haven can silence other apps during sleep.",
                    "OPEN_DND_SETTINGS"
                )
            }
        } else {
            PhoneCommandResult.NeedsPermission(
                "Grant Do Not Disturb access in Settings so Haven can turn other apps down while you sleep.",
                "OPEN_DND_SETTINGS"
            )
        }
    }

    fun adjustVolume(increase: Boolean): PhoneCommandResult {
        val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return PhoneCommandResult.Success(
            if (increase) "Media volume raised." else "Media volume lowered."
        )
    }

    fun muteMediaVolume(): PhoneCommandResult {
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
        return PhoneCommandResult.Success("Media volume muted.")
    }

    fun setWakeUpAlarm(hour: Int, minute: Int, label: String = "Haven Wake Up"): PhoneCommandResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            PhoneCommandResult.Success("Opening alarm setup for %02d:%02d.".format(hour, minute))
        } catch (e: Exception) {
            PhoneCommandResult.Info("No clock app found to set alarm automatically.")
        }
    }

    fun startFreshAirTimer(minutes: Int = 15, label: String = "Haven Fresh Air Break"): PhoneCommandResult {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, minutes * 60)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            PhoneCommandResult.Success("Starting $minutes-minute fresh air timer.")
        } catch (e: Exception) {
            PhoneCommandResult.Info("Timer app unavailable on this device.")
        }
    }

    fun dialNumber(phone: String): PhoneCommandResult {
        val cleaned = phone.trim()
        if (cleaned.isBlank()) return PhoneCommandResult.Info("Enter a phone number first.")
        return try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleaned")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            PhoneCommandResult.Success("Opening dialer for $cleaned.")
        } catch (e: Exception) {
            PhoneCommandResult.Info("Dialer unavailable on this device.")
        }
    }

    fun sendSms(phone: String, message: String): PhoneCommandResult {
        val cleaned = phone.trim()
        return try {
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(cleaned)}")).apply {
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            PhoneCommandResult.Success("Opening SMS composer for $cleaned.")
        } catch (e: Exception) {
            PhoneCommandResult.Info("SMS app unavailable on this device.")
        }
    }

    fun sendWhatsAppOrShare(phone: String, message: String): PhoneCommandResult {
        val digits = phone.filter { it.isDigit() }
        return try {
            val waIntent = Intent(Intent.ACTION_VIEW).apply {
                val url = if (digits.isNotEmpty()) {
                    "https://wa.me/$digits?text=${URLEncoder.encode(message, "UTF-8")}"
                } else {
                    "https://wa.me/?text=${URLEncoder.encode(message, "UTF-8")}"
                }
                data = Uri.parse(url)
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (waIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(waIntent)
                PhoneCommandResult.Success("Opening WhatsApp message.")
            } else {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Send SOS Message").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
                PhoneCommandResult.Success("Opened system message share sheet.")
            }
        } catch (e: Exception) {
            sendSms(phone, message)
        }
    }

    fun sendBackupEmail(recipientEmail: String, subject: String, body: String): PhoneCommandResult {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                if (recipientEmail.isNotBlank()) {
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(recipientEmail.trim()))
                }
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            PhoneCommandResult.Success("Email backup composer opened.")
        } catch (e: Exception) {
            val fallback = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(Intent.createChooser(fallback, "Save Backup via Email").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
                PhoneCommandResult.Success("Backup share sheet opened.")
            } catch (ex: Exception) {
                PhoneCommandResult.Info("No email or share app configured on this device.")
            }
        }
    }

    fun openDeviceSoundSettings() {
        val intent = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    fun getBestLastKnownLocationText(): String {
        if (!hasLocationPermission()) {
            return "Location permission not granted yet"
        }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return "Location unavailable"
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )
        val bestLocation = providers.mapNotNull { provider ->
            try {
                if (lm.isProviderEnabled(provider)) lm.getLastKnownLocation(provider) else null
            } catch (_: Exception) {
                null
            }
        }.maxByOrNull { it.time }

        return if (bestLocation != null) {
            val lat = "%.5f".format(bestLocation.latitude)
            val lon = "%.5f".format(bestLocation.longitude)
            "GPS: $lat, $lon (https://maps.google.com/?q=$lat,$lon)"
        } else {
            "GPS active — waiting for fix (share street/landmark in message)"
        }
    }
}
