package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceRecognitionState(
    val isListening: Boolean = false,
    val partialTranscript: String = "",
    val rmsLevel: Float = 0f,
    val error: String? = null
)

class VoiceAssistantManager(
    private val context: Context,
    private val onFinalSpeechResult: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _voiceState = MutableStateFlow(VoiceRecognitionState())
    val voiceState: StateFlow<VoiceRecognitionState> = _voiceState.asStateFlow()

    private val _speakingMessageId = MutableStateFlow<Long?>(null)
    val speakingMessageId: StateFlow<Long?> = _speakingMessageId.asStateFlow()

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isTtsReady = true
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {
                            _speakingMessageId.value = null
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _speakingMessageId.value = null
                        }

                        override fun onStop(utteranceId: String?, interrupted: Boolean) {
                            _speakingMessageId.value = null
                        }
                    })
                }
            }
        } catch (_: Exception) {
            isTtsReady = false
        }
    }

    fun startListening(languageTag: String = "en-IN") {
        stopSpeaking()
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceState.value = VoiceRecognitionState(
                isListening = false,
                error = "Speech recognition service is not installed on this device."
            )
            return
        }

        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context.applicationContext)
                speechRecognizer?.setRecognitionListener(createRecognitionListener())
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }

            _voiceState.value = VoiceRecognitionState(
                isListening = true,
                partialTranscript = "",
                rmsLevel = 0.1f,
                error = null
            )
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            _voiceState.value = VoiceRecognitionState(
                isListening = false,
                error = "Could not start microphone listening: ${e.message}"
            )
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {
        }
        _voiceState.value = _voiceState.value.copy(isListening = false, rmsLevel = 0f)
    }

    fun clearVoiceError() {
        _voiceState.value = _voiceState.value.copy(error = null)
    }

    fun speakMessage(messageId: Long, rawMarkdownText: String, preferredLanguageTag: String = "en-IN") {
        if (!isTtsReady) return
        if (_speakingMessageId.value == messageId) {
            stopSpeaking()
            return
        }

        val cleanText = stripMarkdownForSpeech(rawMarkdownText)
        if (cleanText.isBlank()) return

        val containsDevanagari = cleanText.any { it in '\u0900'..'\u097F' }
        val targetLocale = when {
            containsDevanagari || preferredLanguageTag.startsWith("hi") -> Locale.forLanguageTag("hi-IN")
            preferredLanguageTag == "en-IN" -> Locale.forLanguageTag("en-IN")
            else -> Locale.US
        }

        try {
            val langResult = tts?.setLanguage(targetLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale.US)
            }
            tts?.setSpeechRate(1.02f)
            _speakingMessageId.value = messageId
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "msg_$messageId")
        } catch (_: Exception) {
            _speakingMessageId.value = null
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        _speakingMessageId.value = null
    }

    fun release() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {
        }
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (_: Exception) {
        }
    }

    private fun createRecognitionListener() = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _voiceState.value = _voiceState.value.copy(isListening = true, error = null)
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.08f, 1f)
            _voiceState.value = _voiceState.value.copy(rmsLevel = normalized)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            _voiceState.value = _voiceState.value.copy(isListening = false, rmsLevel = 0f)
        }

        override fun onError(error: Int) {
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap the microphone to try again."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required for voice input."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error during speech recognition."
                else -> null
            }
            _voiceState.value = VoiceRecognitionState(
                isListening = false,
                partialTranscript = "",
                rmsLevel = 0f,
                error = msg
            )
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val bestText = matches?.firstOrNull()?.trim().orEmpty()
            _voiceState.value = VoiceRecognitionState(isListening = false, partialTranscript = "", rmsLevel = 0f)
            if (bestText.isNotEmpty()) {
                onFinalSpeechResult(bestText)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (partial.isNotEmpty()) {
                _voiceState.value = _voiceState.value.copy(partialTranscript = partial)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    companion object {
        fun stripMarkdownForSpeech(markdown: String): String {
            return markdown
                // Replace code blocks with brief notice so TTS doesn't read raw syntax
                .replace(Regex("```[\\s\\S]*?```"), " Code block included in the chat. ")
                .replace(Regex("`([^`]+)`"), "$1")
                .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
                .replace(Regex("\\*([^*]+)\\*"), "$1")
                .replace(Regex("^#{1,6}\\s*", RegexOption.MULTILINE), "")
                .replace(Regex("\\[([^]]+)]\\([^)]+\\)"), "$1")
                .replace(Regex("^[-*•]\\s+", RegexOption.MULTILINE), "")
                .replace(Regex("\\s+"), " ")
                .trim()
                .take(3500)
        }
    }
}
