package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

interface VoiceEventListener {
    fun onSpeechRecognized(text: String, isFinal: Boolean)
    fun onListeningStateChanged(isListening: Boolean)
    fun onSpeakingStateChanged(isSpeaking: Boolean)
    fun onRmsChanged(rmsdB: Float)
    fun onError(message: String)
}

/**
 * Sesli Asistan Yöneticisi (VoiceManager).
 * Android'in yerel SpeechRecognizer (Konuşmayı Metne Çevirme)
 * ve TextToSpeech (Metni Sese Çevirme) API'lerini yönetir.
 */
class VoiceManager(
    private val context: Context,
    private val listener: VoiceEventListener
) {

    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false
    private var speechRecognizer: SpeechRecognizer? = null

    private var isListening = false
    private var isSpeaking = false

    var speechRate: Float = 1.0f

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val turkish = Locale.forLanguageTag("tr-TR")
                val langResult = textToSpeech?.setLanguage(turkish)
                if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech?.language = Locale.getDefault()
                }
                isTtsInitialized = true

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeaking = true
                        listener.onSpeakingStateChanged(true)
                    }

                    override fun onDone(utteranceId: String?) {
                        isSpeaking = false
                        listener.onSpeakingStateChanged(false)
                    }

                    override fun onError(utteranceId: String?) {
                        isSpeaking = false
                        listener.onSpeakingStateChanged(false)
                    }
                })
            }
        }
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            listener.onError("Cihazınızda ses tanıma hizmeti bulunmuyor.")
            return
        }

        stopSpeaking()
        stopListening()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    listener.onListeningStateChanged(true)
                }

                override fun onBeginningOfSpeech() {}

                override fun onRmsChanged(rmsdB: Float) {
                    listener.onRmsChanged(rmsdB)
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    isListening = false
                    listener.onListeningStateChanged(false)
                }

                override fun onError(error: Int) {
                    isListening = false
                    listener.onListeningStateChanged(false)
                    val errorMsg = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Ses kaydedilemedi."
                        SpeechRecognizer.ERROR_CLIENT -> "İstemci hatası."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon izni verilmedi. Ayarlardan izin verebilirsiniz."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "İnternet bağlantısı hatası."
                        SpeechRecognizer.ERROR_NO_MATCH -> "Ses anlaşılamadı. Lütfen tekrar deneyin."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Ses tanıyıcı meşgul."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Ses algılanamadı."
                        else -> "Ses tanıma hatası ($error)."
                    }
                    listener.onError(errorMsg)
                }

                override fun onResults(results: Bundle?) {
                    isListening = false
                    listener.onListeningStateChanged(false)
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val text = matches[0]
                        listener.onSpeechRecognized(text, isFinal = true)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        listener.onSpeechRecognized(matches[0], isFinal = false)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Suesa AI Dinliyor...")
        }

        try {
            speechRecognizer?.startListening(intent)
            isListening = true
            listener.onListeningStateChanged(true)
        } catch (e: Exception) {
            isListening = false
            listener.onListeningStateChanged(false)
            listener.onError("Ses dinleme başlatılamadı: ${e.message}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            // ignore
        } finally {
            speechRecognizer = null
            if (isListening) {
                isListening = false
                listener.onListeningStateChanged(false)
            }
        }
    }

    fun speak(text: String) {
        if (!isTtsInitialized || text.isBlank()) return
        stopSpeaking()

        val cleanText = text
            .replace(Regex("```[\\s\\S]*?```"), "kod parçası")
            .replace(Regex("[*#_`>]"), "")
            .replace(Regex("https?://\\S+"), "web bağlantısı")
            .trim()

        textToSpeech?.setSpeechRate(speechRate)
        val utteranceId = "SuesaSpeech_${System.currentTimeMillis()}"
        textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stopSpeaking() {
        if (isSpeaking) {
            textToSpeech?.stop()
            isSpeaking = false
            listener.onSpeakingStateChanged(false)
        }
    }

    fun isCurrentlyListening(): Boolean = isListening

    fun isCurrentlySpeaking(): Boolean = isSpeaking

    fun destroy() {
        stopSpeaking()
        textToSpeech?.shutdown()
        textToSpeech = null
        stopListening()
    }
}
