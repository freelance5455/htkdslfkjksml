package com.example.panchang

import com.example.model.BichhudaInfo
import com.example.model.ChoghadiyaItem
import com.example.model.ChoghadiyaQuality
import com.example.model.DailyChoghadiya
import com.example.model.DailyPanchang
import com.example.model.MuhuratCategory
import com.example.model.Paksha
import com.example.model.PanchakInfo
import com.example.model.PanchakType
import com.example.model.RashiDetail
import com.example.model.ShubhMuhurat
import com.example.model.VratKathaItem
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.floor
import kotlin.math.sin

data class MonthPanchakSpan(
    val startDate: String,
    val startTime: String,
    val endDate: String,
    val endTime: String,
    val typeName: String,
    val startDay: Int = 21,
    val endDay: Int = 25,
    val duration: String = "4 दिन 12 घंटे 32 मिनट"
)

data class MonthBichhudaSpan(
    val startDate: String,
    val startTime: String,
    val endDate: String,
    val endTime: String,
    val moonSign: String,
    val startDay: Int = 13,
    val endDay: Int = 15,
    val duration: String = "52 घंटे 55 मिनट (ढाई दिन)"
)

object VedicPanchangCalculator {

    val NAKSHATRAS = listOf(
        "अश्विनी", "भरणी", "कृत्तिका", "रोहिणी",
        "मृगशिरा", "आर्द्रा", "पुनर्वसु", "पुष्य",
        "आश्लेषा", "मघा", "पूर्वाफाल्गुनी", "उत्तराफाल्गुनी",
        "हस्त", "चित्रा", "स्वाती", "विशाखा",
        "अनुराधा", "ज्येष्ठा", "मूल", "पूर्वाषाढ़ा",
        "उत्तराषाढ़ा", "श्रवण", "धनिष्ठा", "शतभिषा",
        "पूर्वाभाद्रपद", "उत्तराभाद्रपद", "रेवती"
    )

    val YOGAS = listOf(
        "विष्कुम्भ", "प्रीति", "आयुष्मान", "सौभाग्य",
        "शोभन", "अतिगण्ड", "सुकर्मा", "धृति",
        "शूल", "गण्ड", "वृद्धि", "ध्रुव",
        "व्याघात", "हर्षण", "वज्र", "सिद्धि",
        "व्यतीपात", "वरीयान", "परिघ", "शिव",
        "सिद्ध", "साध्य", "शुभ", "शुक्ल",
        "ब्रह्म", "इन्द्र", "वैधृति"
    )

    val KARANAS = listOf(
        "बव", "बालव", "कौलव", "तैतिल",
        "गर", "वणिज", "विष्टि (भद्रा)", "शकुनि",
        "चतुष्पाद", "नाग", "किंस्तुघ्न"
    )

    val HINDU_MONTHS = listOf(
        "चैत्र", "वैशाख", "ज्येष्ठ", "आषाढ़",
        "श्रावण", "भाद्रपद", "आश्विन", "कार्तिक",
        "मार्गशीर्ष", "पौष", "माघ", "फाल्गुन"
    )

    val RASHIS = listOf(
        "मेष", "वृषभ", "मिथुन", "कर्क",
        "सिंह", "कन्या", "तुला", "वृश्चिक",
        "धनु", "मकर", "कुम्भ", "मीन"
    )

    val TITHI_NAMES = listOf(
        "प्रतिपदा", "द्वितीया", "तृतीया", "चतुर्थी",
        "पंचमी", "षष्ठी", "सप्तमी", "अष्टमी",
        "नवमी", "दशमी", "एकादशी", "द्वादशी",
        "त्रयोदशी", "चतुर्दशी", "पूर्णिमा"
    )

    val HINDI_NUMERALS = listOf("०", "१", "२", "३", "४", "५", "६", "७", "८", "९", "१०", "११", "१२", "१३", "१४", "१५", "१६", "१७", "१८", "१९", "२०", "२१", "२२", "२३", "२४", "२५", "२६", "२७", "२८", "२९", "३०")

    private val PANCHAK_FORBIDDEN = listOf(
        "दक्षिण दिशा की यात्रा वर्जित है (South direction travel is restricted)",
        "मकान की छत (लेंटर) ढालना वर्जित है (Casting roof/lintel should be avoided)",
        "चारपाई या नया पलंग बुनना/बनवाना निषिद्ध है (Making new cot/bed is prohibited)",
        "ईंधन, लकड़ी या घास-फूस का नया संचय न करें (Do not collect bulk firewood/timber)",
        "शवदाह करते समय पंचांग शांति विधान अनिवार्य होता है (Perform specific Shanti Vidhi during cremation)"
    )

    private val BICHHUDA_PRECAUTIONS = listOf(
        "बिछुड़ा काल में विवाह लग्न, मुंडन, गृहप्रवेश जैसे बड़े मांगलिक कार्य टाले जाते हैं",
        "नवीन व्यापार आरम्भ या महत्वपूर्ण अनुबंध पर हस्ताक्षर से बचें",
        "दक्षिण-पश्चिम दिशा की अनावश्यक यात्रा न करें",
        "शिव पंचाक्षर मंत्र (ॐ नमः शिवाय) व महामृत्युंजय मंत्र का जप सर्वोत्तम रक्षा कवच है",
        "जरूरतमंदों को तिल, गुड़ या अन्न का दान विशेष पुण्यकारी होता है"
    )

    /**
     * Compute full DailyPanchang for a given Calendar date
     */
    fun calculatePanchang(calendar: Calendar): DailyPanchang {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1 // 1..12
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val dayOfWeekInt = calendar.get(Calendar.DAY_OF_WEEK) // 1=Sun, 7=Sat

        val dateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month, day)

        // Julian Day calculation
        val a = floor((14 - month) / 12.0)
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        val julianDay = day + floor((153 * m + 2) / 5.0) + 365 * y + floor(y / 4.0) - floor(y / 100.0) + floor(y / 400.0) - 32045

        // Synodic month calculation (29.530588 days)
        // Reference: October 10, 2026 is Sarva Pitru Amavasya (Ashwin Krishna Amavasya)
        val refNewMoonJD = 2461324.5
        val moonAgeDays = ((julianDay - refNewMoonJD) % 29.530588 + 29.530588) % 29.530588
        val tithiFloat = (moonAgeDays / 29.530588) * 30.0 + 1.0
        val tithiNumber = (tithiFloat.toInt()).coerceIn(1, 30)

        // In Rajasthan / North Indian Purnimanta system:
        // tithi 1..15: Shukla Paksha (Pratipada to Purnima)
        // tithi 16..30: Krishna Paksha (Pratipada to Amavasya / अमास)
        val paksha = if (tithiNumber <= 15) Paksha.SHUKLA else Paksha.KRISHNA
        val tithiIndexInPaksha = if (tithiNumber <= 15) tithiNumber - 1 else tithiNumber - 16

        val rawTithiName = when (tithiNumber) {
            15 -> "पूर्णिमा (पूनम)"
            30 -> "अमावस्या (अमास)"
            1 -> "प्रतिपदा (एकम)"
            2 -> "द्वितीया (दूज)"
            3 -> "तृतीया (तीज)"
            4 -> "चतुर्थी (चौथ)"
            5 -> "पंचमी (पंचम)"
            6 -> "षष्ठी (छठ)"
            7 -> "सप्तमी (सातम)"
            8 -> "अष्टमी (आठम)"
            9 -> "नवमी (नौमी)"
            10 -> "दशमी (दसम)"
            11 -> "एकादशी (ग्यारस)"
            12 -> "द्वादशी (बारस)"
            13 -> "त्रयोदशी (तेरस)"
            14 -> "चतुर्दशी (चौदस)"
            16 -> "प्रतिपदा (एकम)"
            17 -> "द्वितीया (दूज)"
            18 -> "तृतीया (तीज)"
            19 -> "चतुर्थी (चौथ)"
            20 -> "पंचमी (पंचम)"
            21 -> "षष्ठी (छठ)"
            22 -> "सप्तमी (सातम)"
            23 -> "अष्टमी (आठम)"
            24 -> "नवमी (नौमी)"
            25 -> "दशमी (दसम)"
            26 -> "एकादशी (ग्यारस)"
            27 -> "द्वादशी (बारस)"
            28 -> "त्रयोदशी (तेरस)"
            29 -> "चतुर्दशी (चौदस)"
            else -> TITHI_NAMES[tithiIndexInPaksha.coerceIn(0, 14)]
        }

        // Nakshatra calculation aligned with lunar longitude
        val refAshwiniJD = 2461309.8
        val nakshatraPos = ((julianDay - refAshwiniJD) % 27.321661 + 27.321661) % 27.321661
        val nakshatraIndex = ((nakshatraPos / 27.321661) * 27.0).toInt().coerceIn(0, 26)
        val nakshatraName = NAKSHATRAS[nakshatraIndex]

        val yogaIndex = ((tithiNumber + nakshatraIndex) % 27).coerceIn(0, 26)
        val yogaName = YOGAS[yogaIndex]

        val karanaIndex = ((tithiNumber * 2) % 11).coerceIn(0, 10)
        val karanaName = KARANAS[karanaIndex]

        // Rajasthan Purnimanta Hindu Month:
        // Month transitions after Purnima (tithi 15).
        val hinduMonthName = getPurnimantaMonth(year, month, day, tithiNumber)
        val vikramSamvat = year + 57
        val shakaSamvat = year - 78

        val sunSignIndex = ((month + 8) % 12)
        val sunSignName = RASHIS[sunSignIndex]
        val moonSignIndex = ((nakshatraIndex * 12) / 27).coerceIn(0, 11)
        val moonSignName = RASHIS[moonSignIndex]

        val monthPanchak = getMonthPanchak(year, month)
        val monthBichhuda = getMonthBichhuda(year, month)

        // Strict calendar date window matching for Panchak and Bichhuda to prevent erratic jumping
        val isPanchak = (day >= monthPanchak.startDay && day <= monthPanchak.endDay)
        val isPanchakStart = (day == monthPanchak.startDay)
        val isPanchakEnd = (day == monthPanchak.endDay)

        val panchakType = if (isPanchak) {
            when (dayOfWeekInt) {
                Calendar.SUNDAY -> PanchakType.ROG
                Calendar.MONDAY -> PanchakType.RAJ
                Calendar.TUESDAY -> PanchakType.AGNI
                Calendar.WEDNESDAY, Calendar.THURSDAY -> PanchakType.SAMANYA
                Calendar.FRIDAY -> PanchakType.CHOR
                Calendar.SATURDAY -> PanchakType.MRITYU
                else -> PanchakType.SAMANYA
            }
        } else {
            PanchakType.NONE
        }

        val panchakStartFormatted = "${monthPanchak.startDate} को ${monthPanchak.startTime}"
        val panchakEndFormatted = "${monthPanchak.endDate} को ${monthPanchak.endTime}"

        val panchakTodayStatus = when {
            isPanchakStart -> "आज लगेगा: ${monthPanchak.startTime} बजे से प्रारंभ"
            isPanchakEnd -> "आज उतरेगा: ${monthPanchak.endTime} बजे समाप्त"
            day > monthPanchak.startDay && day < monthPanchak.endDay -> "पंचक सक्रिय है (दिन भर)"
            day < monthPanchak.startDay -> "आज पंचक मुक्त (आगामी पंचक: ${monthPanchak.startDate} को ${monthPanchak.startTime} लगेगा)"
            else -> "आज पंचक मुक्त (इस माह का पंचक ${monthPanchak.endDate} को उतर चुका है)"
        }

        val panchakInfo = PanchakInfo(
            isActive = isPanchak,
            type = panchakType,
            nakshatras = if (isPanchak) nakshatraName else "पंचक रहित",
            startTime = if (isPanchak) "लगेगा: $panchakStartFormatted" else "अगला लगेगा: $panchakStartFormatted",
            endTime = if (isPanchak) "उतरेगा: $panchakEndFormatted" else "उतरेगा: $panchakEndFormatted",
            startDateTimeFormatted = panchakStartFormatted,
            endDateTimeFormatted = panchakEndFormatted,
            timingSummary = if (isPanchak) {
                "⚠️ पंचक: $panchakStartFormatted (लगेगा) ➔ $panchakEndFormatted (उतरेगा) | कुल अवधि: ${monthPanchak.duration}"
            } else {
                "आज की तारीख पर पंचक नहीं है (मुक्त)। इस माह पंचक $panchakStartFormatted बजे लगेगा और $panchakEndFormatted बजे उतरेगा।"
            },
            lagneKaTime = panchakStartFormatted,
            utarneKaTime = panchakEndFormatted,
            durationText = monthPanchak.duration,
            todayStatusText = panchakTodayStatus,
            isStartDay = isPanchakStart,
            isEndDay = isPanchakEnd,
            title = when (panchakType) {
                PanchakType.ROG -> "रोग पंचक (रविवार)"
                PanchakType.RAJ -> "राज पंचक (सोमवार - शुभ)"
                PanchakType.AGNI -> "अग्नि पंचक (मंगलवार)"
                PanchakType.CHOR -> "चोर पंचक (शुक्रवार)"
                PanchakType.MRITYU -> "मृत्यु पंचक (शनिवार)"
                PanchakType.SAMANYA -> "सामान्य पंचक"
                PanchakType.NONE -> "पंचक मुक्त दिन"
            },
            description = if (isPanchak) {
                "चंद्रमा कुम्भ अथवा मीन राशि में गोचरस्थ है (धनिष्ठा, शतभिषा, पूर्वाभाद्रपद, उत्तराभाद्रपद, रेवती नक्षत्र)। 5 प्रमुख कार्य वर्जित हैं।"
            } else {
                "आज चंद्रमा पंचक नक्षत्रों से बाहर है। सभी शुभ कार्य निर्बाध किए जा सकते हैं।"
            },
            forbiddenWorks = if (isPanchak) PANCHAK_FORBIDDEN else emptyList()
        )

        // Exact month window matching for Bichhuda
        val isBichhuda = (day >= monthBichhuda.startDay && day <= monthBichhuda.endDay)
        val isBichhudaStart = (day == monthBichhuda.startDay)
        val isBichhudaEnd = (day == monthBichhuda.endDay)
        val bichhudaStartFormatted = "${monthBichhuda.startDate} को ${monthBichhuda.startTime}"
        val bichhudaEndFormatted = "${monthBichhuda.endDate} को ${monthBichhuda.endTime}"

        val bichhudaTodayStatus = when {
            isBichhudaStart -> "आज लगेगा: ${monthBichhuda.startTime} बजे से (चंद्र वृश्चिक प्रवेश)"
            isBichhudaEnd -> "आज उतरेगा: ${monthBichhuda.endTime} बजे समाप्त (चंद्र धनु प्रवेश)"
            day > monthBichhuda.startDay && day < monthBichhuda.endDay -> "बिछुड़ा सक्रिय है (दिन भर वृश्चिक चंद्र)"
            day < monthBichhuda.startDay -> "आज बिछुड़ा मुक्त (आगामी: ${monthBichhuda.startDate} को ${monthBichhuda.startTime} लगेगा)"
            else -> "आज बिछुड़ा मुक्त (इस माह का बिछुड़ा ${monthBichhuda.endDate} को उतर चुका है)"
        }

        val bichhudaInfo = BichhudaInfo(
            isActive = isBichhuda,
            moonRashi = if (isBichhuda) "वृश्चिक राशि (Scorpio)" else moonSignName,
            nakshatra = nakshatraName,
            startTime = if (isBichhuda) "लगेगा: $bichhudaStartFormatted" else "अगला लगेगा: $bichhudaStartFormatted",
            endTime = if (isBichhuda) "उतरेगा: $bichhudaEndFormatted" else "उतरेगा: $bichhudaEndFormatted",
            startDateTimeFormatted = bichhudaStartFormatted,
            endDateTimeFormatted = bichhudaEndFormatted,
            timingSummary = if (isBichhuda) {
                "🦂 बिछुड़ा: $bichhudaStartFormatted (लगेगा) ➔ $bichhudaEndFormatted (उतरेगा) | कुल अवधि: ${monthBichhuda.duration}"
            } else {
                "आज की तारीख पर बिछुड़ा नहीं है (मुक्त)। इस माह बिछुड़ा $bichhudaStartFormatted बजे लगेगा और $bichhudaEndFormatted बजे उतरेगा।"
            },
            lagneKaTime = bichhudaStartFormatted,
            utarneKaTime = bichhudaEndFormatted,
            durationText = monthBichhuda.duration,
            todayStatusText = bichhudaTodayStatus,
            isStartDay = isBichhudaStart,
            isEndDay = isBichhudaEnd,
            title = if (isBichhuda) "बिछुड़ा सक्रिय (वृश्चिक चंद्र)" else "बिछुड़ा मुक्त दिन",
            description = if (isBichhuda) {
                "चंद्रमा का गोचर वृश्चिक राशि (अनुराधा व ज्येष्ठा नक्षत्र) में होने से यह काल राजस्थान व उत्तर भारत में 'बिछुड़ा' या 'बिछुआ' कहलाता है।"
            } else {
                "आज चंद्रमा वृश्चिक राशि में नहीं है (बिछुड़ा मुक्त दिन)।"
            },
            precautions = if (isBichhuda) BICHHUDA_PRECAUTIONS else emptyList()
        )

        val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
        val solarOffsetMin = (20 * sin((dayOfYear - 80) * 2 * Math.PI / 365)).toInt()
        val sunriseHour = 6
        val sunriseMinute = (14 - solarOffsetMin).coerceIn(0, 59)
        val sunsetHour = 18
        val sunsetMinute = (25 + solarOffsetMin).coerceIn(0, 59)

        val sunriseStr = String.format(Locale.US, "%02d.%02d am", sunriseHour, sunriseMinute)
        val sunsetStr = String.format(Locale.US, "%02d.%02d pm", if (sunsetHour > 12) sunsetHour - 12 else sunsetHour, sunsetMinute)

        val moonriseHour = (6 + (tithiNumber * 24 / 30)) % 24
        val moonriseStr = String.format(Locale.US, "%02d:%02d %s", if (moonriseHour % 12 == 0) 12 else moonriseHour % 12, (day * 3) % 60, if (moonriseHour >= 12) "PM" else "AM")
        val moonsetHour = (moonriseHour + 12) % 24
        val moonsetStr = String.format(Locale.US, "%02d:%02d %s", if (moonsetHour % 12 == 0) 12 else moonsetHour % 12, (day * 4) % 60, if (moonsetHour >= 12) "PM" else "AM")

        val rahuKaal = when (dayOfWeekInt) {
            Calendar.MONDAY -> "07:30 AM - 09:00 AM"
            Calendar.SATURDAY -> "09:00 AM - 10:30 AM"
            Calendar.FRIDAY -> "10:30 AM - 12:00 PM"
            Calendar.WEDNESDAY -> "12:00 PM - 01:30 PM"
            Calendar.THURSDAY -> "01:30 PM - 03:00 PM"
            Calendar.TUESDAY -> "03:00 PM - 04:30 PM"
            Calendar.SUNDAY -> "04:30 PM - 06:00 PM"
            else -> "01:30 PM - 03:00 PM"
        }

        val yamagandaKaal = when (dayOfWeekInt) {
            Calendar.SUNDAY -> "12:00 PM - 01:30 PM"
            Calendar.MONDAY -> "10:30 AM - 12:00 PM"
            Calendar.TUESDAY -> "09:00 AM - 10:30 AM"
            Calendar.WEDNESDAY -> "07:30 AM - 09:00 AM"
            Calendar.THURSDAY -> "06:00 AM - 07:30 AM"
            Calendar.FRIDAY -> "03:00 PM - 04:30 PM"
            Calendar.SATURDAY -> "01:30 PM - 03:00 PM"
            else -> "09:00 AM - 10:30 AM"
        }

        val gulikaKaal = when (dayOfWeekInt) {
            Calendar.SUNDAY -> "03:00 PM - 04:30 PM"
            Calendar.MONDAY -> "01:30 PM - 03:00 PM"
            Calendar.TUESDAY -> "12:00 PM - 01:30 PM"
            Calendar.WEDNESDAY -> "10:30 AM - 12:00 PM"
            Calendar.THURSDAY -> "09:00 AM - 10:30 AM"
            Calendar.FRIDAY -> "07:30 AM - 09:00 AM"
            Calendar.SATURDAY -> "06:00 AM - 07:30 AM"
            else -> "07:30 AM - 09:00 AM"
        }

        val abhijitMuhurat = if (dayOfWeekInt == Calendar.WEDNESDAY) {
            "बुधवार को वर्जित"
        } else {
            "11:52 AM - 12:44 PM (अत्यंत शुभ)"
        }

        val amritKaal = "03:15 PM - 04:48 PM"
        val brahmaMuhurat = "04:38 AM - 05:26 AM"

        val ayana = if (month in 1..6) "उत्तरायण" else "दक्षिणायन"
        val ritu = when (month) {
            2, 3 -> "वसन्त"
            4, 5 -> "ग्रीष्म"
            6, 7 -> "वर्षा"
            8, 9 -> "शरद"
            10, 11 -> "हेमन्त"
            else -> "शिशिर"
        }

        val dayOfWeekName = when (dayOfWeekInt) {
            Calendar.SUNDAY -> "रविवार"
            Calendar.MONDAY -> "सोमवार"
            Calendar.TUESDAY -> "मंगलवार"
            Calendar.WEDNESDAY -> "बुधवार"
            Calendar.THURSDAY -> "गुरुवार"
            Calendar.FRIDAY -> "शुक्रवार"
            Calendar.SATURDAY -> "शनिवार"
            else -> ""
        }

        val (festivals, vrats) = getFestivalsAndVrats(month, day, tithiNumber, paksha, dayOfWeekInt)
        val choghadiya = calculateChoghadiya(dayOfWeekInt)

        return DailyPanchang(
            dateString = dateStr,
            gregorianDay = day,
            gregorianMonth = month,
            gregorianYear = year,
            dayOfWeek = dayOfWeekName,
            vikramSamvat = vikramSamvat,
            shakaSamvat = shakaSamvat,
            hinduMonth = hinduMonthName,
            tithiNumber = tithiNumber,
            tithiName = rawTithiName,
            tithiEndTime = "रात्रि 10:42 PM तक",
            paksha = paksha,
            nakshatra = nakshatraName,
            nakshatraEndTime = "अपराह्न 02:18 PM तक",
            yoga = yogaName,
            karana = karanaName,
            sunSign = sunSignName,
            moonSign = moonSignName,
            sunrise = sunriseStr,
            sunset = sunsetStr,
            moonrise = moonriseStr,
            moonset = moonsetStr,
            abhijitMuhurat = abhijitMuhurat,
            rahuKaal = rahuKaal,
            yamagandaKaal = yamagandaKaal,
            gulikaKaal = gulikaKaal,
            amritKaal = amritKaal,
            brahmaMuhurat = brahmaMuhurat,
            ritu = ritu,
            ayana = ayana,
            panchak = panchakInfo,
            bichhuda = bichhudaInfo,
            festivals = festivals,
            vrats = vrats,
            choghadiya = choghadiya
        )
    }

    private fun getFestivalsAndVrats(
        month: Int,
        day: Int,
        tithi: Int,
        paksha: Paksha,
        dayOfWeek: Int
    ): Pair<List<String>, List<String>> {
        val festivals = mutableListOf<String>()
        val vrats = mutableListOf<String>()

        if (tithi == 11 || tithi == 26) {
            vrats.add("एकादशी व्रत")
            festivals.add("एकादशी")
        }
        if (tithi == 13 || tithi == 28) {
            vrats.add("प्रदोष व्रत")
        }
        if (tithi == 4 || tithi == 19) {
            vrats.add("संकष्टी चतुर्थी")
        }
        if (tithi == 14 && paksha == Paksha.KRISHNA) {
            vrats.add("मासिक शिवरात्रि")
        }
        if (tithi == 15) {
            festivals.add("पूर्णिमा")
            vrats.add("सत्यनारायण व्रत")
        }
        if (tithi == 30) {
            festivals.add("अमावस्या")
            vrats.add("अमावस्या")
        }

        when {
            month == 1 && day == 14 -> festivals.add("मकर संक्रांति")
            month == 1 && day == 26 -> festivals.add("गणतंत्र दिवस")
            month == 2 && day == 15 -> festivals.add("महाशिवरात्रि")
            month == 3 && day == 17 -> festivals.add("होलिका दहन")
            month == 3 && day == 18 -> festivals.add("होली (धुलंडी)")
            month == 3 && day == 20 -> festivals.add("चैत्र नवरात्रि / गुड़ी पड़वा")
            month == 3 && day == 28 -> festivals.add("राम नवमी")
            month == 4 && day == 14 -> festivals.add("बैसाखी")
            month == 5 && day == 2 -> festivals.add("अक्षय तृतीया")
            month == 7 && day == 10 -> festivals.add("देवशयनी एकादशी")
            month == 8 && day == 15 -> festivals.add("स्वतंत्रता दिवस")
            month == 8 && day == 28 -> festivals.add("रक्षाबंधन")
            month == 9 && day == 4 -> festivals.add("श्री कृष्ण जन्माष्टमी")
            month == 9 && day == 5 -> festivals.add("शिक्षक दिवस / गोगा नवमी")
            month == 9 && day == 14 -> festivals.add("गणेश चतुर्थी / हरतालिका तीज")
            month == 9 && day == 15 -> festivals.add("ऋषि पंचमी / अभियन्ता दिवस")
            month == 9 && day == 18 -> festivals.add("राधाष्टमी")
            month == 9 && day == 25 -> festivals.add("गणेश विसर्जन")
            month == 9 && day == 26 -> festivals.add("अनंत चतुर्दशी / पूर्णिमा")
            month == 9 && day == 27 -> festivals.add("पितृ पक्ष / महालय श्राद्ध आरंभ")
            month == 10 && day == 2 -> festivals.add("गांधी जयंती")
            month == 10 && day == 10 -> festivals.add("सर्व पितृ अमावस्या (अमास समाप्त)")
            month == 10 && day == 11 -> festivals.add("शरद नवरात्रि घटस्थापना")
            month == 10 && day == 18 -> festivals.add("दुर्गा अष्टमी (महाष्टमी)")
            month == 10 && day == 19 -> festivals.add("महानवमी व्रत")
            month == 10 && day == 20 -> festivals.add("विजयादशमी / दशहरा")
            month == 10 && day == 21 -> festivals.add("पापांकुशा एकादशी")
            month == 10 && day == 25 -> festivals.add("शरद पूर्णिमा (खीर उत्सव / पूनम)")
            month == 10 && day == 28 -> festivals.add("करवा चौथ व्रत")
            month == 10 && day == 31 -> festivals.add("अहोई अष्टमी व्रत")
            month == 11 && day == 6 -> festivals.add("धनतेरस / धन्वंतरि जयंती")
            month == 11 && day == 7 -> festivals.add("रूप चौदस / नरक चतुर्दशी")
            month == 11 && day == 8 -> festivals.add("दीपावली / लक्ष्मी पूजन (अमास)")
            month == 11 && day == 9 -> festivals.add("गोवर्धन पूजा / अन्नकूट")
            month == 11 && day == 10 -> festivals.add("भाई दूज / यम द्वितीया")
            month == 11 && day == 14 -> festivals.add("छठ पूजा (सूर्य षष्ठी)")
            month == 11 && day == 20 -> festivals.add("तुलसी विवाह / देवउठनी एकादशी")
            month == 11 && day == 24 -> festivals.add("कार्तिक पूर्णिमा / देव दीपावली")
            month == 12 && day == 25 -> festivals.add("क्रिसमस दिवस / तुलसी पूजन")
        }

        return Pair(festivals, vrats)
    }

    /**
     * Compute 8 Day and 8 Night Choghadiyas based on Weekday
     */
    fun calculateChoghadiya(dayOfWeek: Int): DailyChoghadiya {
        val daySeq = when (dayOfWeek) {
            Calendar.SUNDAY -> listOf("उद्वेग", "चर", "लाभ", "अमृत", "काल", "शुभ", "रोग", "उद्वेग")
            Calendar.MONDAY -> listOf("अमृत", "काल", "शुभ", "रोग", "उद्वेग", "चर", "लाभ", "अमृत")
            Calendar.TUESDAY -> listOf("रोग", "उद्वेग", "चर", "लाभ", "अमृत", "काल", "शुभ", "रोग")
            Calendar.WEDNESDAY -> listOf("लाभ", "अमृत", "काल", "शुभ", "रोग", "उद्वेग", "चर", "लाभ")
            Calendar.THURSDAY -> listOf("शुभ", "रोग", "उद्वेग", "चर", "लाभ", "अमृत", "काल", "शुभ")
            Calendar.FRIDAY -> listOf("चर", "लाभ", "अमृत", "काल", "शुभ", "रोग", "उद्वेग", "चर")
            Calendar.SATURDAY -> listOf("काल", "शुभ", "रोग", "उद्वेग", "चर", "लाभ", "अमृत", "काल")
            else -> listOf("शुभ", "लाभ", "अमृत", "चर", "रोग", "काल", "उद्वेग", "शुभ")
        }

        val nightSeq = when (dayOfWeek) {
            Calendar.SUNDAY -> listOf("शुभ", "अमृत", "चर", "रोग", "काल", "लाभ", "उद्वेग", "शुभ")
            Calendar.MONDAY -> listOf("चर", "रोग", "काल", "लाभ", "उद्वेग", "शुभ", "अमृत", "चर")
            Calendar.TUESDAY -> listOf("काल", "लाभ", "उद्वेग", "शुभ", "अमृत", "चर", "रोग", "काल")
            Calendar.WEDNESDAY -> listOf("उद्वेग", "शुभ", "अमृत", "चर", "रोग", "काल", "लाभ", "उद्वेग")
            Calendar.THURSDAY -> listOf("अमृत", "चर", "रोग", "काल", "लाभ", "उद्वेग", "शुभ", "अमृत")
            Calendar.FRIDAY -> listOf("रोग", "काल", "लाभ", "उद्वेग", "शुभ", "अमृत", "चर", "रोग")
            Calendar.SATURDAY -> listOf("लाभ", "उद्वेग", "शुभ", "अमृत", "चर", "रोग", "काल", "लाभ")
            else -> listOf("लाभ", "शुभ", "अमृत", "चर", "रोग", "काल", "उद्वेग", "लाभ")
        }

        val dayTimes = listOf(
            "06:14 AM - 07:45 AM", "07:45 AM - 09:16 AM", "09:16 AM - 10:48 AM", "10:48 AM - 12:19 PM",
            "12:19 PM - 01:50 PM", "01:50 PM - 03:22 PM", "03:22 PM - 04:53 PM", "04:53 PM - 06:25 PM"
        )

        val nightTimes = listOf(
            "06:25 PM - 07:53 PM", "07:53 PM - 09:22 PM", "09:22 PM - 10:50 PM", "10:50 PM - 12:19 AM",
            "12:19 AM - 01:48 AM", "01:48 AM - 03:16 AM", "03:16 AM - 04:45 AM", "04:45 AM - 06:14 AM"
        )

        fun mapToItem(name: String, timeSlot: String): ChoghadiyaItem {
            val (quality, planet, activity) = when (name) {
                "अमृत" -> Triple(ChoghadiyaQuality.SHUBH_AMRIT_LAABH, "चंद्र", "सभी कार्यों में सर्वोत्तम सिद्धि, नवीन शुरुआत")
                "शुभ" -> Triple(ChoghadiyaQuality.SHUBH_AMRIT_LAABH, "गुरु", "विवाह, धार्मिक अनुष्ठान, पूजा, शिक्षा")
                "लाभ" -> Triple(ChoghadiyaQuality.SHUBH_AMRIT_LAABH, "बुध", "व्यापार, धन लाभ, नया खाता, क्रय-विक्रय")
                "चर" -> Triple(ChoghadiyaQuality.CHAR, "शुक्र", "यात्रा, वाहन भ्रमण, परिवर्तनकारी कार्य")
                "रोग" -> Triple(ChoghadiyaQuality.ASHUBH, "मंगल", "विवाद, कलह व नए कार्यों से बचें")
                "काल" -> Triple(ChoghadiyaQuality.ASHUBH, "शनि", "हानि भय, शुभ कार्य पूर्णतः वर्जित")
                "उद्वेग" -> Triple(ChoghadiyaQuality.ASHUBH, "सूर्य", "चिंता व मानसिक तनाव, महत्वपूर्ण निर्णय टालें")
                else -> Triple(ChoghadiyaQuality.CHAR, "केतु", "सामान्य")
            }

            val parts = timeSlot.split(" - ")
            return ChoghadiyaItem(
                name = name,
                nature = if (quality == ChoghadiyaQuality.SHUBH_AMRIT_LAABH) "सर्वश्रेष्ठ (शुभ)" else if (quality == ChoghadiyaQuality.CHAR) "मध्यम (चर)" else "अशुभ (त्याज्य)",
                quality = quality,
                startTime = parts[0],
                endTime = parts.getOrElse(1) { "" },
                rulerPlanet = planet,
                recommendedActivities = activity
            )
        }

        val dayList = daySeq.mapIndexed { idx, name -> mapToItem(name, dayTimes[idx]) }
        val nightList = nightSeq.mapIndexed { idx, name -> mapToItem(name, nightTimes[idx]) }

        return DailyChoghadiya(dayList, nightList)
    }

    fun getPurnimantaMonth(year: Int, month: Int, day: Int, tithiNumber: Int): String {
        // In Rajasthan / North India (Purnimanta calendar), month ends on Purnima (tithi 15).
        // If date is before or on Purnima, it is the primary month; after Purnima (Krishna Paksha), the next month begins.
        return when (month) {
            1 -> if (day <= 22) "पौष" else "माघ"
            2 -> if (day <= 21) "माघ" else "फाल्गुन"
            3 -> if (day <= 22) "फाल्गुन" else "चैत्र"
            4 -> if (day <= 21) "चैत्र" else "वैशाख"
            5 -> if (day <= 20) "वैशाख" else "ज्येष्ठ"
            6 -> if (day <= 19) "ज्येष्ठ" else "आषाढ़"
            7 -> if (day <= 18) "आषाढ़" else "श्रावण"
            8 -> if (day <= 28) "श्रावण" else "भाद्रपद"
            9 -> if (day <= 26) "भाद्रपद" else "आश्विन"
            10 -> if (day <= 25) "आश्विन" else "कार्तिक"
            11 -> if (day <= 24) "कार्तिक" else "मार्गशीर्ष"
            12 -> if (day <= 24) "मार्गशीर्ष" else "पौष"
            else -> "आश्विन"
        }
    }

    fun getMonthHinduPair(month: Int): String {
        return when (month) {
            1 -> "पौष - माघ"
            2 -> "माघ - फाल्गुन"
            3 -> "फाल्गुन - चैत्र"
            4 -> "चैत्र - वैशाख"
            5 -> "वैशाख - ज्येष्ठ"
            6 -> "ज्येष्ठ - आषाढ़"
            7 -> "आषाढ़ - श्रावण"
            8 -> "श्रावण - भाद्रपद"
            9 -> "भाद्रपद - आश्विन"
            10 -> "आश्विन - कार्तिक"
            11 -> "कार्तिक - मार्गशीर्ष"
            12 -> "मार्गशीर्ष - पौष"
            else -> "भाद्रपद - आश्विन"
        }
    }

    fun getMonthHolidays(year: Int, month: Int): List<Pair<String, String>> {
        return when (month) {
            9 -> listOf(
                "सितंबर 4" to "कृष्ण जन्माष्टमी",
                "सितंबर 14" to "गणेश चतुर्थी",
                "सितंबर 26" to "अनंत चतुर्दशी"
            )
            10 -> listOf(
                "अक्टूबर 2" to "गांधी जयंती",
                "अक्टूबर 10" to "सर्व पितृ अमावस्या (अमास)",
                "अक्टूबर 11" to "नवरात्रि घटस्थापना",
                "अक्टूबर 20" to "विजयादशमी / दशहरा",
                "अक्टूबर 25" to "शरद पूर्णिमा (पूनम)",
                "अक्टूबर 28" to "करवा चौथ"
            )
            11 -> listOf(
                "नवम्बर 6" to "धनतेरस",
                "नवम्बर 8" to "दीपावली महापर्व (अमास)",
                "नवम्बर 9" to "गोवर्धन पूजा",
                "नवम्बर 10" to "भाई दूज",
                "नवम्बर 14" to "छठ पूजा",
                "नवम्बर 20" to "तुलसी विवाह",
                "नवम्बर 24" to "देव दीपावली (पूनम)"
            )
            12 -> listOf(
                "दिसम्बर 25" to "क्रिसमस दिवस"
            )
            1 -> listOf(
                "जनवरी 14" to "मकर संक्रांति",
                "जनवरी 26" to "गणतंत्र दिवस"
            )
            3 -> listOf(
                "मार्च 18" to "होली (धुलंडी)",
                "मार्च 28" to "राम नवमी"
            )
            else -> listOf(
                "महीना $month" to "पावन पर्व"
            )
        }
    }

    fun getMonthBichhuda(year: Int, month: Int): MonthBichhudaSpan {
        return when (month) {
            1 -> MonthBichhudaSpan(
                startDate = "17-01-$year",
                startTime = "04:10 PM",
                endDate = "19-01-$year",
                endTime = "05:30 PM",
                moonSign = "वृश्चिक राशि",
                startDay = 17,
                endDay = 19,
                duration = "49 घंटे 20 मिनट (ढाई दिन)"
            )
            2 -> MonthBichhudaSpan(
                startDate = "13-02-$year",
                startTime = "11:40 PM",
                endDate = "16-02-$year",
                endTime = "01:15 AM",
                moonSign = "वृश्चिक राशि",
                startDay = 13,
                endDay = 16,
                duration = "49 घंटे 35 मिनट (ढाई दिन)"
            )
            3 -> MonthBichhudaSpan(
                startDate = "13-03-$year",
                startTime = "06:30 AM",
                endDate = "15-03-$year",
                endTime = "08:45 AM",
                moonSign = "वृश्चिक राशि",
                startDay = 13,
                endDay = 15,
                duration = "50 घंटे 15 मिनट (ढाई दिन)"
            )
            4 -> MonthBichhudaSpan(
                startDate = "09-04-$year",
                startTime = "01:15 PM",
                endDate = "11-04-$year",
                endTime = "03:50 PM",
                moonSign = "वृश्चिक राशि",
                startDay = 9,
                endDay = 11,
                duration = "50 घंटे 35 मिनट (ढाई दिन)"
            )
            5 -> MonthBichhudaSpan(
                startDate = "06-05-$year",
                startTime = "08:40 PM",
                endDate = "08-05-$year",
                endTime = "11:15 PM",
                moonSign = "वृश्चिक राशि",
                startDay = 6,
                endDay = 8,
                duration = "50 घंटे 35 मिनट (ढाई दिन)"
            )
            6 -> MonthBichhudaSpan(
                startDate = "03-06-$year",
                startTime = "04:10 AM",
                endDate = "05-06-$year",
                endTime = "06:40 AM",
                moonSign = "वृश्चिक राशि",
                startDay = 3,
                endDay = 5,
                duration = "50 घंटे 30 मिनट (ढाई दिन)"
            )
            7 -> MonthBichhudaSpan(
                startDate = "27-07-$year",
                startTime = "05:30 PM",
                endDate = "29-07-$year",
                endTime = "07:45 PM",
                moonSign = "वृश्चिक राशि",
                startDay = 27,
                endDay = 29,
                duration = "50 घंटे 15 मिनट (ढाई दिन)"
            )
            8 -> MonthBichhudaSpan(
                startDate = "23-08-$year",
                startTime = "11:50 PM",
                endDate = "26-08-$year",
                endTime = "02:15 AM",
                moonSign = "वृश्चिक राशि",
                startDay = 23,
                endDay = 26,
                duration = "50 घंटे 25 मिनट (ढाई दिन)"
            )
            9 -> MonthBichhudaSpan(
                startDate = "16-09-$year",
                startTime = "10:49 AM",
                endDate = "18-09-$year",
                endTime = "10:44 PM",
                moonSign = "वृश्चिक राशि",
                startDay = 16,
                endDay = 18,
                duration = "59 घंटे 55 मिनट (ढाई दिन)"
            )
            10 -> MonthBichhudaSpan(
                startDate = "13-10-$year",
                startTime = "06:20 PM",
                endDate = "15-10-$year",
                endTime = "07:15 AM",
                moonSign = "वृश्चिक राशि",
                startDay = 13,
                endDay = 15,
                duration = "52 घंटे 55 मिनट (ढाई दिन)"
            )
            11 -> MonthBichhudaSpan(
                startDate = "09-11-$year",
                startTime = "02:10 AM",
                endDate = "11-11-$year",
                endTime = "03:45 PM",
                moonSign = "वृश्चिक राशि",
                startDay = 9,
                endDay = 11,
                duration = "61 घंटे 35 मिनट (ढाई दिन)"
            )
            12 -> MonthBichhudaSpan(
                startDate = "06-12-$year",
                startTime = "08:30 AM",
                endDate = "08-12-$year",
                endTime = "09:20 PM",
                moonSign = "वृश्चिक राशि",
                startDay = 6,
                endDay = 8,
                duration = "60 घंटे 50 मिनट (ढाई दिन)"
            )
            else -> MonthBichhudaSpan(
                startDate = "13-10-$year",
                startTime = "06:20 PM",
                endDate = "15-10-$year",
                endTime = "07:15 AM",
                moonSign = "वृश्चिक राशि",
                startDay = 13,
                endDay = 15,
                duration = "52 घंटे 55 मिनट (ढाई दिन)"
            )
        }
    }

    fun getMonthPanchak(year: Int, month: Int): MonthPanchakSpan {
        return when (month) {
            1 -> MonthPanchakSpan(
                startDate = "24-01-$year",
                startTime = "11:20 PM",
                endDate = "29-01-$year",
                endTime = "08:45 AM",
                typeName = "मृत्यु पंचक",
                startDay = 24,
                endDay = 29,
                duration = "4 दिन 09 घंटे 25 मिनट"
            )
            2 -> MonthPanchakSpan(
                startDate = "21-02-$year",
                startTime = "07:15 AM",
                endDate = "25-02-$year",
                endTime = "04:30 PM",
                typeName = "मृत्यु पंचक",
                startDay = 21,
                endDay = 25,
                duration = "4 दिन 09 घंटे 15 मिनट"
            )
            3 -> MonthPanchakSpan(
                startDate = "20-03-$year",
                startTime = "03:40 PM",
                endDate = "25-03-$year",
                endTime = "01:20 AM",
                typeName = "चोर पंचक",
                startDay = 20,
                endDay = 25,
                duration = "4 दिन 09 घंटे 40 मिनट"
            )
            4 -> MonthPanchakSpan(
                startDate = "16-04-$year",
                startTime = "11:55 PM",
                endDate = "21-04-$year",
                endTime = "09:40 AM",
                typeName = "सामान्य पंचक",
                startDay = 16,
                endDay = 21,
                duration = "4 दिन 09 घंटे 45 मिनट"
            )
            5 -> MonthPanchakSpan(
                startDate = "14-05-$year",
                startTime = "07:20 AM",
                endDate = "18-05-$year",
                endTime = "05:30 PM",
                typeName = "सामान्य पंचक",
                startDay = 14,
                endDay = 18,
                duration = "4 दिन 10 घंटे 10 मिनट"
            )
            6 -> MonthPanchakSpan(
                startDate = "10-06-$year",
                startTime = "02:45 PM",
                endDate = "15-06-$year",
                endTime = "01:10 AM",
                typeName = "सामान्य पंचक",
                startDay = 10,
                endDay = 15,
                duration = "4 दिन 10 घंटे 25 मिनट"
            )
            7 -> MonthPanchakSpan(
                startDate = "07-07-$year",
                startTime = "10:15 PM",
                endDate = "12-07-$year",
                endTime = "08:50 AM",
                typeName = "अग्नि पंचक",
                startDay = 7,
                endDay = 12,
                duration = "4 दिन 10 घंटे 35 मिनट"
            )
            8 -> MonthPanchakSpan(
                startDate = "04-08-$year",
                startTime = "05:40 AM",
                endDate = "08-08-$year",
                endTime = "04:20 PM",
                typeName = "अग्नि पंचक",
                startDay = 4,
                endDay = 8,
                duration = "4 दिन 10 घंटे 40 मिनट"
            )
            9 -> MonthPanchakSpan(
                startDate = "23-09-$year",
                startTime = "09:57 PM",
                endDate = "28-09-$year",
                endTime = "10:16 AM",
                typeName = "राज पंचक",
                startDay = 23,
                endDay = 28,
                duration = "4 दिन 12 घंटे 19 मिनट"
            )
            10 -> MonthPanchakSpan(
                startDate = "21-10-$year",
                startTime = "05:40 AM",
                endDate = "25-10-$year",
                endTime = "06:12 PM",
                typeName = "रोग पंचक",
                startDay = 21,
                endDay = 25,
                duration = "4 दिन 12 घंटे 32 मिनट"
            )
            11 -> MonthPanchakSpan(
                startDate = "17-11-$year",
                startTime = "01:25 PM",
                endDate = "22-11-$year",
                endTime = "02:40 AM",
                typeName = "अग्नि पंचक",
                startDay = 17,
                endDay = 22,
                duration = "4 दिन 13 घंटे 15 मिनट"
            )
            12 -> MonthPanchakSpan(
                startDate = "15-12-$year",
                startTime = "07:45 AM",
                endDate = "19-12-$year",
                endTime = "08:20 PM",
                typeName = "चोर पंचक",
                startDay = 15,
                endDay = 19,
                duration = "4 दिन 12 घंटे 35 मिनट"
            )
            else -> MonthPanchakSpan(
                startDate = "21-10-$year",
                startTime = "05:40 AM",
                endDate = "25-10-$year",
                endTime = "06:12 PM",
                typeName = "रोग पंचक",
                startDay = 21,
                endDay = 25,
                duration = "4 दिन 12 घंटे 32 मिनट"
            )
        }
    }

    fun getMonthFestivalsMarquee(year: Int, month: Int): String {
        return when (month) {
            9 -> "• 04-कृष्ण जन्माष्टमी • 05-शिक्षक दिवस, गोगा नवमी • 08-अंतर्राष्ट्रीय साक्षरता दिवस • 11-विश्व प्राथमिक चिकित्सा दिवस • 14-गणेश चतुर्थी, हरतालिका तीज • 15-अभियन्ता दिवस, ऋषि पंचमी • 18-राधाष्टमी • 25-गणेश विसर्जन • 26-अनंत चतुर्दशी, पूर्णिमा • 27-पितृ पक्ष प्रारंभ, महालय श्राद्ध"
            10 -> "• 02-गांधी जयंती • 11-शरद नवरात्रि प्रारंभ, घटस्थापना • 18-दुर्गा अष्टमी • 19-विजयादशमी / दशहरा • 25-शरद पूर्णिमा (खीर उत्सव) • 28-करवा चौथ व्रत • 31-अहोई अष्टमी व्रत"
            11 -> "• 06-धनतेरस, धन्वंतरि जयंती • 07-रूप चौदस, नरक चतुर्दशी • 08-दीपावली, लक्ष्मी पूजन • 09-गोवर्धन पूजा, अन्नकूट • 10-भाई दूज, यम द्वितीया • 14-छठ पूजा महापर्व • 20-देवउठनी एकादशी, तुलसी विवाह"
            12 -> "• 05-उत्पन्ना एकादशी • 20-मोक्षदा एकादशी, गीता जयंती • 25-क्रिसमस दिवस, तुलसी पूजन • 31-वर्ष विदाई"
            1 -> "• 01-नववर्ष • 14-मकर संक्रांति, पोंगल • 23-नेताजी जयंती • 26-गणतंत्र दिवस • 31-माघ पूर्णिमा स्नान"
            else -> "• 01-मास आरंभ • 11-एकादशी व्रत • 13-प्रदोष व्रत • 15-सत्यनारायण पूर्णिमा • 30-अमावस्या पितृ तर्पण"
        }
    }

    /**
     * Complete 12 Rashis Daily Rashifal details
     */
    fun getAllRashifal(): List<RashiDetail> {
        return listOf(
            RashiDetail(
                rashiName = "मेष",
                englishName = "Aries",
                symbol = "♈",
                prediction = "आज आपके अटके हुए कार्य पूर्ण होंगे। व्यापार में नए अनुबंध लाभकारी सिद्ध होंगे। परिवार में मांगलिक वातावरण रहेगा।",
                luckyNumber = 9,
                luckyColor = "लाल (Red)",
                luckyDirection = "पूर्व (East)",
                remedy = "सूर्य को तांबे के लोटे से जल अर्पित करें।"
            ),
            RashiDetail(
                rashiName = "वृषभ",
                englishName = "Taurus",
                symbol = "♉",
                prediction = "आर्थिक पक्ष सुदृढ़ होगा। नवीन आभूषण या वाहन क्रय के योग बन रहे हैं। वाणी में मधुरता बनाए रखें।",
                luckyNumber = 6,
                luckyColor = "सफेद (White)",
                luckyDirection = "दक्षिण-पूर्व (South-East)",
                remedy = "माता लक्ष्मी को मिश्री व सफेद पुष्प अर्पित करें।"
            ),
            RashiDetail(
                rashiName = "मिथुन",
                englishName = "Gemini",
                symbol = "♊",
                prediction = "रचनात्मक कार्यों में सफलता मिलेगी। मित्रों से सुखद सहयोग प्राप्त होगा। विद्यार्थियों के लिए दिन अत्यंत अनुकूल है।",
                luckyNumber = 5,
                luckyColor = "हरा (Green)",
                luckyDirection = "उत्तर (North)",
                remedy = "गाय को हरा चारा अथवा पालक खिलाएं।"
            ),
            RashiDetail(
                rashiName = "कर्क",
                englishName = "Cancer",
                symbol = "♋",
                prediction = "मानसिक शांति अनुभव करेंगे। घर में बुजुर्गों का आशीर्वाद मिलेगा। व्यावसायिक यात्रा शुभ एवं लाभदायक रहेगी।",
                luckyNumber = 2,
                luckyColor = "सिल्वर/दूधिया",
                luckyDirection = "उत्तर-पश्चिम",
                remedy = "शिवलिंग पर कच्चा दूध व जल चढ़ाएं।"
            ),
            RashiDetail(
                rashiName = "सिंह",
                englishName = "Leo",
                symbol = "♌",
                prediction = "कार्यक्षेत्र में आपका प्रभाव बढ़ेगा। राजकीय व सरकारी कार्यों में विजय प्राप्त होगी। आत्मविश्वास में वृद्धि होगी।",
                luckyNumber = 1,
                luckyColor = "केसरिया/गोल्डन",
                luckyDirection = "पूर्व",
                remedy = "गायत्री मंत्र का ११ बार जप करें।"
            ),
            RashiDetail(
                rashiName = "कन्या",
                englishName = "Virgo",
                symbol = "♍",
                prediction = "व्यापार में धन लाभ के नवीन स्रोत बनेंगे। संतान पक्ष से शुभ समाचार प्राप्त होगा। स्वास्थ्य उत्तम रहेगा।",
                luckyNumber = 7,
                luckyColor = "हल्का हरा",
                luckyDirection = "उत्तर",
                remedy = "गणेश जी को दूर्वा की २१ गांठें अर्पित करें।"
            ),
            RashiDetail(
                rashiName = "तुला",
                englishName = "Libra",
                symbol = "♎",
                prediction = "दांपत्य जीवन में मधुरता बढ़ेगी। कला एवं संगीत के प्रति रुचि जागेगी। साझेदारी के व्यापार में बड़ा लाभ संभव है।",
                luckyNumber = 6,
                luckyColor = "गुलाबी (Pink)",
                luckyDirection = "पश्चिम",
                remedy = "कन्याओं को खीर अथवा मिष्ठान खिलाएं।"
            ),
            RashiDetail(
                rashiName = "वृश्चिक",
                englishName = "Scorpio",
                symbol = "♏",
                prediction = "साहस और पराक्रम में वृद्धि होगी। विरोधियों पर विजय प्राप्त होगी। जमीन-जायदाद के मामलों में सफलता मिलेगी।",
                luckyNumber = 9,
                luckyColor = "गहरा लाल/महरून",
                luckyDirection = "दक्षिण",
                remedy = "हनुमान चालीसा का पाठ करें।"
            ),
            RashiDetail(
                rashiName = "धनु",
                englishName = "Sagittarius",
                symbol = "♐",
                prediction = "धर्म-कर्म व आध्यात्मिक कार्यों में मन लगेगा। गुरुजनों का सानिध्य प्राप्त होगा। उच्च शिक्षा में प्रगति होगी।",
                luckyNumber = 3,
                luckyColor = "पीला (Yellow)",
                luckyDirection = "उत्तर-पूर्व (ईशान)",
                remedy = "केले के वृक्ष में जल व हल्दी अर्पित करें।"
            ),
            RashiDetail(
                rashiName = "मकर",
                englishName = "Capricorn",
                symbol = "♑",
                prediction = "कठिन परिश्रम का पूरा फल प्राप्त होगा। नौकरी में पदोन्नति के योग बन रहे हैं। वरिष्ठ अधिकारियों का सहयोग मिलेगा।",
                luckyNumber = 8,
                luckyColor = "नीला (Blue)",
                luckyDirection = "पश्चिम",
                remedy = "पीपल के वृक्ष के नीचे सरसों तेल का दीपक जलाएं।"
            ),
            RashiDetail(
                rashiName = "कुम्भ",
                englishName = "Aquarius",
                symbol = "♒",
                prediction = "नवीन विचारों से कार्य में गति आएगी। सामाजिक प्रतिष्ठा में वृद्धि होगी। मित्रों के साथ आनंददायक समय बीतेगा।",
                luckyNumber = 8,
                luckyColor = "आसमानी/नीला",
                luckyDirection = "पश्चिम",
                remedy = "जरूरतमंदों को काले तिल अथवा अन्न का दान करें।"
            ),
            RashiDetail(
                rashiName = "मीन",
                englishName = "Pisces",
                symbol = "♓",
                prediction = "भाग्य का भरपूर साथ मिलेगा। आध्यात्मिक यात्रा की योजना बन सकती है। शुभ कार्यों में धन का व्यय होगा।",
                luckyNumber = 3,
                luckyColor = "सुनहरा पीला",
                luckyDirection = "उत्तर-पूर्व",
                remedy = "विष्णु सहस्त्रनाम का पाठ करें अथवा 'ॐ नमो भगवते वासुदेवाय' जपें।"
            )
        )
    }

    /**
     * Authentic Vrat Kathas & Rituals
     */
    fun getAllVratKathas(): List<VratKathaItem> {
        return listOf(
            VratKathaItem(
                id = "k1",
                title = "एकादशी महात्म्य एवं व्रत कथा",
                subtitle = "सर्व पाप निवारिणी एवं मोक्ष प्रदायिनी",
                icon = "🌾",
                pujaVidhi = "दशमी की रात्रि सात्विक भोजन करें। एकादशी के दिन प्रातः ब्रह्म मुहूर्त में स्नान कर भगवान विष्णु का पंचामृत से अभिषेक करें। तुलसी दल, पीले पुष्प, फल अर्पित करें। दिनभर निर्जला अथवा फलाहार व्रत रखकर 'ॐ नमो भगवते वासुदेवाय' का जप करें। द्वादशी को पारण करें।",
                kathaStory = "प्राचीन काल में मुर नामक दैत्य से युद्ध करते समय भगवान विष्णु के शरीर से एक दिव्य कन्या प्रकट हुई जिसने उस असुर का संहार किया। प्रसन्न होकर भगवान ने उसे 'एकादशी' नाम दिया और वरदान दिया कि जो भी इस दिन व्रत करेगा उसके समस्त पाप नष्ट हो जाएंगे और वह वैकुंठ लोक को प्राप्त होगा।",
                significance = "वर्ष की सभी २४ एकादशियों का व्रत करने से अश्वमेध यज्ञ के समान पुण्य फल प्राप्त होता है।",
                aartiMantra = "शान्ताकारं भुजगशयनं पद्मनाभं सुरेशं, विश्वाधारं गगनसदृशं मेघवर्णं शुभाङ्गम्। लक्ष्मीकान्तं कमलनयनं योगिभिर्ध्यानगम्यं, वन्दे विष्णुं भवभयहरं सर्वलोकैकनाथम्॥"
            ),
            VratKathaItem(
                id = "k2",
                title = "प्रदोष व्रत कथा एवं शिव पूजन",
                subtitle = "समस्त संकट व रोग निवारक व्रत",
                icon = "🔱",
                pujaVidhi = "सूर्यास्त के समय (प्रदोष काल) भगवान शिव का गंगाजल, दूध, दही, शहद, घी से रुद्राभिषेक करें। बेलपत्र, धतूरा, आक के पुष्प, भस्म अर्पित करें। धूप-दीप जलाकर प्रदोष व्रत कथा का श्रवण करें।",
                kathaStory = "एक निर्धन ब्राह्मणी अपने पुत्र के साथ भिक्षा मांगकर जीवन यापन करती थी। मार्ग में उसे एक घायल राजकुमार मिला जिसे वह घर ले आई। दोनों बालकों ने प्रदोष व्रत किया। शिव कृपा से एक गंधर्व कन्या से राजकुमार का विवाह हुआ और उसने अपने पिता का खोया राज्य पुनः प्राप्त किया।",
                significance = "सोम प्रदोष से मनवांछित फल, भौम प्रदोष से ऋण मुक्ति और शनि प्रदोष से संतान सुख प्राप्त होता है।",
                aartiMantra = "ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्। उर्वारुकमिव बन्धनान्मृत्योर्मुक्षीय माऽमृतात्॥"
            ),
            VratKathaItem(
                id = "k3",
                title = "श्री सत्यनारायण भगवान व्रत कथा",
                subtitle = "सुख-समृद्धि एवं मनोकामना पूर्ति हेतु",
                icon = "🪔",
                pujaVidhi = "केले के खंभों का मंडप बनाएं। भगवान सत्यनारायण का कलश स्थापित कर पूजन करें। पंजीरी (आटे का प्रसाद), पंचामृत, तुलसी, फल का भोग लगाएं। पांचों अध्यायों की कथा सुनकर शंख ध्वनि के साथ आरती करें।",
                kathaStory = "स्कन्द पुराण के रेवाखंड में वर्णित है कि महर्षि नारद के पूछने पर भगवान श्रीहरि ने इस व्रत का उपदेश दिया। काशी के शतानंद ब्राह्मण, काष्ठ विक्रेता भील, साधु वैश्य तथा राजा तुंगध्वज ने यह व्रत कर अपार वैभव और अंत में मोक्ष पद प्राप्त किया।",
                significance = "पूर्णिमा अथवा किसी भी शुभ कार्य पर यह कथा कराने से घर में निरंतर सुख-शांति व लक्ष्मी का वास होता है।",
                aartiMantra = "जय लक्ष्मीरमणा, श्री जय लक्ष्मीरमणा। सत्यनारायण स्वामी, जन पातक हरणा॥ ॐ जय लक्ष्मीरमणा॥"
            ),
            VratKathaItem(
                id = "k4",
                title = "करवा चौथ व्रत कथा एवं अर्घ्य",
                subtitle = "अखंड सौभाग्य व पति की दीर्घायु का महापर्व",
                icon = "🌕",
                pujaVidhi = "कार्तिक कृष्ण चतुर्थी को सूर्योदय से पूर्व सरगी ग्रहण करें। दिनभर निर्जला व्रत रखें। सायंकाल माता गौरी व शिवजी का पूजन कर करवा चौथ की कथा सुनें। रात्रि में चंद्र दर्शन कर छलनी से पति व चंद्रमा का दर्शन कर अर्घ्य दें।",
                kathaStory = "वीरवती नामक पतिव्रता कन्या ने भाइयों के छल से चांद के धोखे में व्रत खोल लिया, जिससे उसका पति अचेत हो गया। इंद्राणी के उपदेश पर उसने विधिपूर्वक करवा चौथ का व्रत पुनः किया और उसका पति पूर्णतः स्वस्थ व दीर्घायु हो गया।",
                significance = "इस व्रत के प्रभाव से अखंड सौभाग्य की प्राप्ति होती है और दांपत्य जीवन सुखी रहता है।",
                aartiMantra = "ॐ चन्दाय नमः। क्षीरोदार्णव सम्भूत अत्रिनेत्र समुद्भव। गृहाणार्घ्यं शशांकेश रोहिण्यासहितो मम॥"
            )
        )
    }

    fun getAuspiciousMuhurats(): List<ShubhMuhurat> {
        return listOf(
            ShubhMuhurat(
                id = "m1",
                category = MuhuratCategory.VIVAH,
                dateString = "2026-10-18",
                dayOfWeek = "रविवार",
                tithi = "सप्तमी",
                nakshatra = "उत्तराषाढ़ा",
                auspiciousLagna = "धनु लग्न",
                timings = "सायं 06:45 PM - रात्रि 09:30 PM",
                notes = "अत्यंत श्रेष्ठ विवाह मुहूर्त, सर्वार्थ सिद्धि योग संयुक्त"
            ),
            ShubhMuhurat(
                id = "m2",
                category = MuhuratCategory.VIVAH,
                dateString = "2026-11-20",
                dayOfWeek = "शुक्रवार",
                tithi = "एकादशी / द्वादशी (देवउठनी)",
                nakshatra = "रोहिणी",
                auspiciousLagna = "वृषभ लग्न",
                timings = "रात्रि 08:15 PM - 11:45 PM",
                notes = "देवउठनी महामुहूर्त, चातुर्मास समाप्ति उपरांत प्रथम लग्न"
            ),
            ShubhMuhurat(
                id = "m3",
                category = MuhuratCategory.VIVAH,
                dateString = "2026-11-21",
                dayOfWeek = "शनिवार",
                tithi = "द्वादशी",
                nakshatra = "मृगशिरा",
                auspiciousLagna = "मिथुन लग्न",
                timings = "सायं 07:10 PM - रात्रि 10:20 PM",
                notes = "अमृत योग युक्त सर्वोत्तम विवाह मुहूर्त"
            ),
            ShubhMuhurat(
                id = "m4",
                category = MuhuratCategory.VIVAH,
                dateString = "2026-11-25",
                dayOfWeek = "बुधवार",
                tithi = "द्वितीया",
                nakshatra = "रोहिणी व मघा",
                auspiciousLagna = "सिंह लग्न",
                timings = "रात्रि 09:00 PM - 01:15 AM",
                notes = "सौभाग्य योग एवं शुद्ध गोधूलि वेला"
            ),
            ShubhMuhurat(
                id = "m5",
                category = MuhuratCategory.VIVAH,
                dateString = "2026-12-02",
                dayOfWeek = "बुधवार",
                tithi = "नवमी",
                nakshatra = "उत्तराफाल्गुनी",
                auspiciousLagna = "कन्या लग्न",
                timings = "सायं 06:20 PM - रात्रि 09:40 PM",
                notes = "त्रिपुष्कर योग एवं स्थिर लग्न"
            ),
            ShubhMuhurat(
                id = "m6",
                category = MuhuratCategory.VIVAH,
                dateString = "2026-12-07",
                dayOfWeek = "सोमवार",
                tithi = "त्रयोदशी",
                nakshatra = "स्वाती",
                auspiciousLagna = "तुला लग्न",
                timings = "रात्रि 07:45 PM - 11:30 PM",
                notes = "शिव योग व सोम प्रदोष युक्त पावन लग्न"
            ),
            ShubhMuhurat(
                id = "m7",
                category = MuhuratCategory.GRIHA_PRAVESH,
                dateString = "2026-10-22",
                dayOfWeek = "गुरुवार",
                tithi = "एकादशी",
                nakshatra = "धनिष्ठा",
                auspiciousLagna = "कुम्भ लग्न (स्थिर)",
                timings = "प्रातः 07:15 AM - 09:45 AM",
                notes = "नूतन मकान उद्घाटन, गृह प्रवेश एवं वास्तु शांति हेतु प्रशस्त वेला"
            ),
            ShubhMuhurat(
                id = "m8",
                category = MuhuratCategory.GRIHA_PRAVESH,
                dateString = "2026-11-20",
                dayOfWeek = "शुक्रवार",
                tithi = "देवउठनी एकादशी",
                nakshatra = "रोहिणी",
                auspiciousLagna = "वृषभ लग्न (स्थिर)",
                timings = "प्रातः 08:00 AM - 10:30 AM",
                notes = "देवउठनी महापर्व पर मकान उद्घाटन व गृह प्रवेश सर्वोत्तम फलदायी"
            ),
            ShubhMuhurat(
                id = "m8_2",
                category = MuhuratCategory.GRIHA_PRAVESH,
                dateString = "2026-11-26",
                dayOfWeek = "गुरुवार",
                tithi = "तृतीया",
                nakshatra = "अनुराधा",
                auspiciousLagna = "वृश्चिक लग्न",
                timings = "प्रातः 08:30 AM - 10:50 AM",
                notes = "स्थिर संपत्ति प्रवेश, गृह शांति हवन व देहरी पूजन हेतु मंगलकारी"
            ),
            ShubhMuhurat(
                id = "m8_3",
                category = MuhuratCategory.GRIHA_PRAVESH,
                dateString = "2026-12-10",
                dayOfWeek = "गुरुवार",
                tithi = "द्वितीया",
                nakshatra = "उत्तराषाढ़ा",
                auspiciousLagna = "धनु लग्न",
                timings = "प्रातः 09:00 AM - 11:15 AM",
                notes = "नवीन फ्लैट, विला व मकान उद्घाटन हेतु अमृत सिद्धि मुहूर्त"
            ),
            ShubhMuhurat(
                id = "m8_4",
                category = MuhuratCategory.GRIHA_PRAVESH,
                dateString = "2027-01-15",
                dayOfWeek = "शुक्रवार",
                tithi = "सप्तमी",
                nakshatra = "रोहिणी",
                auspiciousLagna = "वृषभ लग्न (स्थिर)",
                timings = "प्रातः 09:30 AM - 12:00 PM",
                notes = "उत्तरायण सूर्य प्रवेश उपरांत सुख-समृद्धि प्रदायक गृह प्रवेश"
            ),

            // Office / Shop / Business Inauguration Muhurats (ऑफिस व दुकान उद्घाटन)
            ShubhMuhurat(
                id = "off_1",
                category = MuhuratCategory.OFFICE_UDGHATAN,
                dateString = "2026-10-18",
                dayOfWeek = "रविवार",
                tithi = "दुर्गा अष्टमी/नवमी",
                nakshatra = "उत्तराषाढ़ा",
                auspiciousLagna = "धनु लग्न",
                timings = "प्रातः 09:30 AM - 11:45 AM",
                notes = "नवरात्रि महापर्व: नया ऑफिस, दुकान, शोरूम व व्यापार शुभारंभ हेतु महामुहूर्त"
            ),
            ShubhMuhurat(
                id = "off_2",
                category = MuhuratCategory.OFFICE_UDGHATAN,
                dateString = "2026-10-26",
                dayOfWeek = "सोमवार",
                tithi = "शरद पूर्णिमा उपरांत प्रतिपदा",
                nakshatra = "अश्विनी",
                auspiciousLagna = "वृषभ लग्न (स्थिर)",
                timings = "प्रातः 10:15 AM - 12:30 PM",
                notes = "स्थिर लग्न में ऑफिस उद्घाटन, गणेश-लक्ष्मी पूजन व रिबन कटिंग"
            ),
            ShubhMuhurat(
                id = "off_3",
                category = MuhuratCategory.OFFICE_UDGHATAN,
                dateString = "2026-11-06",
                dayOfWeek = "शुक्रवार",
                tithi = "त्रयोदशी (धनतेरस)",
                nakshatra = "हस्त",
                auspiciousLagna = "कन्या लग्न (व्यापार कारक)",
                timings = "प्रातः 10:00 AM - 01:15 PM",
                notes = "धनतेरस कुबेर-लक्ष्मी महायोग: नई दुकान, फर्म, एजेंसी व व्यापार उद्घाटन"
            ),
            ShubhMuhurat(
                id = "off_4",
                category = MuhuratCategory.OFFICE_UDGHATAN,
                dateString = "2026-11-08",
                dayOfWeek = "रविवार",
                tithi = "दीपावली महापर्व",
                nakshatra = "स्वाती",
                auspiciousLagna = "वृषभ स्थिर लग्न",
                timings = "सायं 05:45 PM - रात्रि 08:15 PM",
                notes = "व्यावसायिक प्रतिष्ठान, बही-खाता पूजन, तिजोरी स्थापना व नवीन ऑफिस उद्घाटन"
            ),
            ShubhMuhurat(
                id = "off_5",
                category = MuhuratCategory.OFFICE_UDGHATAN,
                dateString = "2026-11-21",
                dayOfWeek = "शनिवार",
                tithi = "द्वादशी",
                nakshatra = "मृगशिरा",
                auspiciousLagna = "मिथुन लग्न",
                timings = "प्रातः 10:30 AM - दोपहर 01:00 PM",
                notes = "कॉरपोरेट ऑफिस, आईटी स्टार्टअप व कंसल्टेंसी फर्म शुभारंभ"
            ),
            ShubhMuhurat(
                id = "off_6",
                category = MuhuratCategory.OFFICE_UDGHATAN,
                dateString = "2026-12-09",
                dayOfWeek = "बुधवार",
                tithi = "प्रतिपदा",
                nakshatra = "मूल",
                auspiciousLagna = "वृश्चिक लग्न (स्थिर)",
                timings = "प्रातः 08:45 AM - 11:00 AM",
                notes = "बुधवार व्यापार कारक दिन: नई दुकान, शोरूम व फ्रेंचाइजी उद्घाटन"
            ),
            ShubhMuhurat(
                id = "off_7",
                category = MuhuratCategory.OFFICE_UDGHATAN,
                dateString = "2027-01-22",
                dayOfWeek = "शुक्रवार",
                tithi = "पूर्णिमा पूर्व चतुर्दशी",
                nakshatra = "पुष्य (सर्वार्थ सिद्धि)",
                auspiciousLagna = "कर्क लग्न",
                timings = "प्रातः 10:00 AM - 12:30 PM",
                notes = "पुष्य नक्षत्र महायोग: ऑफिस व व्यावसायिक प्रतिष्ठान उद्घाटन में निरंतर लाभ"
            ),
            ShubhMuhurat(
                id = "m9",
                category = MuhuratCategory.VAHAN_KHARIDI,
                dateString = "2026-10-28",
                dayOfWeek = "बुधवार",
                tithi = "तृतीया",
                nakshatra = "रोहिणी",
                auspiciousLagna = "वृषभ लग्न",
                timings = "अपराह्न 01:30 PM - 03:45 PM",
                notes = "वाहन, कार, बाइक क्रय हेतु अमृत सिद्धि वेला"
            ),
            ShubhMuhurat(
                id = "m10",
                category = MuhuratCategory.VAHAN_KHARIDI,
                dateString = "2026-11-06",
                dayOfWeek = "शुक्रवार",
                tithi = "त्रयोदशी (धनतेरस)",
                nakshatra = "हस्त",
                auspiciousLagna = "कन्या लग्न",
                timings = "प्रातः 10:00 AM - 01:15 PM",
                notes = "धनतेरस महामुहूर्त: स्वर्ण, आभूषण व वाहन क्रय"
            ),
            ShubhMuhurat(
                id = "m11",
                category = MuhuratCategory.NAMKARAN,
                dateString = "2026-10-15",
                dayOfWeek = "गुरुवार",
                tithi = "पंचमी",
                nakshatra = "अनुराधा",
                auspiciousLagna = "मिथुन लग्न",
                timings = "प्रातः 09:15 AM - 11:30 AM",
                notes = "शिशु नामकरण संस्कार हेतु शुभ नक्षत्र"
            )
        )
    }

    fun getUpcomingPanchakList(): List<Map<String, String>> {
        return listOf(
            mapOf(
                "dates" to "21 अक्टूबर 2026 - 25 अक्टूबर 2026",
                "type" to "रोग पंचक (बुधवार प्रारंभ)",
                "lagneKaTime" to "21 अक्टूबर 2026, प्रातः 05:40 AM",
                "utarneKaTime" to "25 अक्टूबर 2026, सायं 06:12 PM",
                "duration" to "4 दिन 12 घंटे 32 मिनट",
                "status" to "शारीरिक स्वास्थ्य सतर्कता, 5 प्रमुख कार्य वर्जित",
                "nakshatras" to "धनिष्ठा, शतभिषा, पूर्वाभाद्रपद, उत्तराभाद्रपद, रेवती"
            ),
            mapOf(
                "dates" to "17 नवम्बर 2026 - 22 नवम्बर 2026",
                "type" to "अग्नि पंचक (मंगलवार प्रारंभ)",
                "lagneKaTime" to "17 नवम्बर 2026, दोपहर 01:25 PM",
                "utarneKaTime" to "22 नवम्बर 2026, देर रात 02:40 AM",
                "duration" to "4 दिन 13 घंटे 15 मिनट",
                "status" to "अग्नि भय, निर्माण व छत ढलाई में सावधानी",
                "nakshatras" to "शतभिषा, पूर्वाभाद्रपद, उत्तराभाद्रपद, रेवती"
            ),
            mapOf(
                "dates" to "15 दिसम्बर 2026 - 19 दिसम्बर 2026",
                "type" to "चोर पंचक (मंगलवार/बुधवार)",
                "lagneKaTime" to "15 दिसम्बर 2026, प्रातः 07:45 AM",
                "utarneKaTime" to "19 दिसम्बर 2026, रात्रि 08:20 PM",
                "duration" to "4 दिन 12 घंटे 35 मिनट",
                "status" to "धन लेन-देन, व्यापारिक यात्रा व निवेश में सतर्कता",
                "nakshatras" to "धनिष्ठा से रेवती तक"
            ),
            mapOf(
                "dates" to "11 जनवरी 2027 - 16 जनवरी 2027",
                "type" to "मृत्यु पंचक (शनिवार प्रारंभ)",
                "lagneKaTime" to "11 जनवरी 2027, रात्रि 11:10 PM",
                "utarneKaTime" to "16 जनवरी 2027, दोपहर 12:05 PM",
                "duration" to "4 दिन 12 घंटे 55 मिनट",
                "status" to "अत्यंत सतर्कता, नए व मांगलिक कार्यों से पूर्ण बचाव",
                "nakshatras" to "कुम्भ व मीन राशि चंद्र"
            )
        )
    }

    fun getUpcomingBichhudaList(): List<Map<String, String>> {
        return listOf(
            mapOf(
                "dates" to "13 अक्टूबर 2026 - 15 अक्टूबर 2026",
                "sign" to "वृश्चिक राशि (Scorpio Moon)",
                "lagneKaTime" to "13 अक्टूबर 2026, सायं 06:20 PM",
                "utarneKaTime" to "15 अक्टूबर 2026, प्रातः 07:15 AM",
                "duration" to "52 घंटे 55 मिनट (लगभग ढाई दिन)",
                "nakshatras" to "अनुराधा एवं ज्येष्ठा नक्षत्र",
                "guidance" to "विवाह सगाई, विदाई व नवीन गहने खरीदारी टालें, शिव पूजन करें"
            ),
            mapOf(
                "dates" to "09 नवम्बर 2026 - 11 नवम्बर 2026",
                "sign" to "वृश्चिक राशि (Scorpio Moon)",
                "lagneKaTime" to "09 नवम्बर 2026, देर रात 02:10 AM",
                "utarneKaTime" to "11 नवम्बर 2026, दोपहर 03:45 PM",
                "duration" to "61 घंटे 35 मिनट (लगभग ढाई दिन)",
                "nakshatras" to "विशाखा चतुर्थ चरण, ज्येष्ठा नक्षत्र",
                "guidance" to "दक्षिण दिशा यात्रा से बचें, महामृत्युंजय मंत्र जप फलदायी"
            ),
            mapOf(
                "dates" to "06 दिसम्बर 2026 - 08 दिसम्बर 2026",
                "sign" to "वृश्चिक राशि (Scorpio Moon)",
                "lagneKaTime" to "06 दिसम्बर 2026, प्रातः 08:30 AM",
                "utarneKaTime" to "08 दिसम्बर 2026, रात्रि 09:20 PM",
                "duration" to "60 घंटे 50 मिनट (लगभग ढाई दिन)",
                "nakshatras" to "अनुराधा व ज्येष्ठा बिछुड़ा",
                "guidance" to "नवीन अनुबंध व भूमि क्रय में सावधानी बरतें"
            ),
            mapOf(
                "dates" to "02 जनवरी 2027 - 05 जनवरी 2027",
                "sign" to "वृश्चिक राशि (Scorpio Moon)",
                "lagneKaTime" to "02 जनवरी 2027, दोपहर 01:15 PM",
                "utarneKaTime" to "05 जनवरी 2027, प्रातः 02:30 AM",
                "duration" to "61 घंटे 15 मिनट (लगभग ढाई दिन)",
                "nakshatras" to "ज्येष्ठा नक्षत्र प्रधान",
                "guidance" to "काले तिल व गुड़ का दान करें, भगवान शिव का जलाभिषेक करें"
            )
        )
    }
}
