package com.example.bybitcryptobot;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/** Планирование фоновых проверок через WorkManager (переживает закрытие приложения и перезагрузку). */
final class Scheduler {
    private static final String PERIODIC = "signal_scan_periodic";
    private static final String ONCE = "signal_scan_once";

    private Scheduler() {}

    private static Constraints net() {
        return new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
    }

    static void schedule(Context c) {
        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(SignalWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(net())
                .build();
        WorkManager.getInstance(c.getApplicationContext())
                .enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req);
    }

    static void runOnceNow(Context c) {
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(SignalWorker.class)
                .setConstraints(net())
                .build();
        WorkManager.getInstance(c.getApplicationContext())
                .enqueueUniqueWork(ONCE, ExistingWorkPolicy.REPLACE, req);
    }

    static void cancel(Context c) {
        WorkManager wm = WorkManager.getInstance(c.getApplicationContext());
        wm.cancelUniqueWork(PERIODIC);
        wm.cancelUniqueWork(ONCE);
    }
}
