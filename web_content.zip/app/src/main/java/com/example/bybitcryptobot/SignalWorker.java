package com.example.bybitcryptobot;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.ArrayList;
import java.util.List;

/** Фоновая проверка сигналов. Запускается системой каждые ~15 минут, даже если приложение закрыто. */
public class SignalWorker extends Worker {
    private static final long MAX_RUN_MS = 7 * 60_000L;

    public SignalWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        if (!Prefs.isEnabled(c)) return Result.success();
        try {
            List<SignalScanner.Signal> found = SignalScanner.scanAll(System.currentTimeMillis() + MAX_RUN_MS);
            List<SignalScanner.Signal> fresh = new ArrayList<>();
            for (SignalScanner.Signal s : found) {
                // не повторяем уведомление о том же сигнале на той же свече
                if (!Prefs.alreadyNotified(c, s.symbol, s.side, s.candleTime)) fresh.add(s);
            }
            Notifier.showSignals(c, fresh);
            for (SignalScanner.Signal s : fresh) Prefs.markNotified(c, s.symbol, s.side, s.candleTime);
            return Result.success();
        } catch (Exception e) {
            // нет сети / ошибка API — просто ждём следующего запуска
            return Result.success();
        }
    }
}
