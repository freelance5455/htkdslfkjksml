package com.example.bybitcryptobot;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Нативный порт сканера из index.html. Нужен, чтобы сигналы проверялись,
 * когда приложение закрыто и WebView не работает.
 * Логика (EMA20/EMA50, RSI, ATR, подтверждение 15м/30м/1ч) совпадает с JS-версией.
 */
final class SignalScanner {
    static final double MIN_TURNOVER_24H = 50_000d;
    private static final String[] HOSTS = {"https://api.bybit.com", "https://api.bytick.com"};
    private static final Set<String> STABLE = new HashSet<>(Arrays.asList(
            "USDC", "USDE", "USDT", "DAI", "FDUSD", "TUSD", "USDD", "USDP", "EUR", "USD1"));
    private static final int PARALLEL = 4;

    private SignalScanner() {}

    static final class Candle {
        long time;
        double open, high, low, close, volume;
    }

    static final class Analysis {
        double close, prevClose, e20, e20prev, e50, rsi, atr, volRatio;
        Candle candle;
    }

    static final class Signal {
        String symbol;
        String side; // BUY | SELL
        double entry, sl, tp, rsi, vol;
        int strength;
        long candleTime;
        double turnover;
    }

    // ---------- индикаторы ----------

    static double[] ema(double[] a, int p) {
        double k = 2.0 / (p + 1);
        double[] out = new double[a.length];
        double v = Double.NaN;
        for (int i = 0; i < a.length; i++) {
            v = Double.isNaN(v) ? a[i] : a[i] * k + v * (1 - k);
            out[i] = v;
        }
        return out;
    }

    static double[] rsi(double[] a, int p) {
        double[] out = new double[a.length];
        Arrays.fill(out, Double.NaN);
        if (a.length <= p) return out;
        double g = 0, l = 0;
        for (int i = 1; i <= p; i++) {
            double d = a[i] - a[i - 1];
            g += Math.max(d, 0);
            l += Math.max(-d, 0);
        }
        g /= p;
        l /= p;
        out[p] = l == 0 ? 100 : 100 - 100 / (1 + g / l);
        for (int i = p + 1; i < a.length; i++) {
            double d = a[i] - a[i - 1];
            g = (g * (p - 1) + Math.max(d, 0)) / p;
            l = (l * (p - 1) + Math.max(-d, 0)) / p;
            out[i] = l == 0 ? 100 : 100 - 100 / (1 + g / l);
        }
        return out;
    }

    static double[] atr(List<Candle> c, int p) {
        int n = c.size();
        double[] tr = new double[n];
        for (int i = 0; i < n; i++) {
            double prev = i > 0 ? c.get(i - 1).close : c.get(i).close;
            Candle x = c.get(i);
            tr[i] = Math.max(x.high - x.low, Math.max(Math.abs(x.high - prev), Math.abs(x.low - prev)));
        }
        double[] out = new double[n];
        Arrays.fill(out, Double.NaN);
        if (n <= p) return out;
        double v = 0;
        for (int i = 1; i <= p; i++) v += tr[i];
        v /= p;
        out[p] = v;
        for (int i = p + 1; i < n; i++) {
            v = (v * (p - 1) + tr[i]) / p;
            out[i] = v;
        }
        return out;
    }

    static Analysis analyze(JSONArray rows, int intervalMinutes) throws Exception {
        long now = System.currentTimeMillis();
        long intervalMs = intervalMinutes * 60_000L;
        List<Candle> c = new ArrayList<>();
        for (int i = 0; i < rows.length(); i++) {
            JSONArray r = rows.getJSONArray(i);
            Candle x = new Candle();
            x.time = Long.parseLong(r.getString(0));
            x.open = Double.parseDouble(r.getString(1));
            x.high = Double.parseDouble(r.getString(2));
            x.low = Double.parseDouble(r.getString(3));
            x.close = Double.parseDouble(r.getString(4));
            x.volume = Double.parseDouble(r.getString(5));
            if (x.time + intervalMs <= now) c.add(x); // только закрытые свечи
        }
        Collections.sort(c, (a, b) -> Long.compare(a.time, b.time));
        if (c.size() < 65) throw new Exception("not enough candles");

        int n = c.size() - 1, prev = n - 1;
        double[] closes = new double[c.size()];
        for (int i = 0; i < closes.length; i++) closes[i] = c.get(i).close;
        double[] e20 = ema(closes, 20), e50 = ema(closes, 50), rr = rsi(closes, 14), aa = atr(c, 14);

        int from = Math.max(0, n - 20);
        double sum = 0;
        for (int i = from; i < n; i++) sum += c.get(i).volume;
        double volAvg = sum / Math.min(20, n);

        Analysis a = new Analysis();
        a.close = closes[n];
        a.prevClose = closes[prev];
        a.e20 = e20[n];
        a.e20prev = e20[prev];
        a.e50 = e50[n];
        a.rsi = rr[n];
        a.atr = aa[n];
        a.volRatio = volAvg > 0 ? c.get(n).volume / volAvg : 0;
        a.candle = c.get(n);
        return a;
    }

    static String trend(Analysis a) {
        if (a.close > a.e20 && a.e20 > a.e50) return "UP";
        if (a.close < a.e20 && a.e20 < a.e50) return "DOWN";
        return "FLAT";
    }

    /** Возвращает сигнал или null, если условия не совпали (ЖДАТЬ). */
    static Signal signal(String symbol, Analysis a15, Analysis a30, Analysis a60) {
        String t15 = trend(a15), t30 = trend(a30), t60 = trend(a60);
        boolean buy = t15.equals("UP") && t30.equals("UP") && t60.equals("UP")
                && a15.rsi >= 52 && a15.rsi <= 68 && a15.volRatio >= 1.10
                && a15.close > a15.candle.open && a15.prevClose <= a15.e20prev;
        boolean sell = t15.equals("DOWN") && t30.equals("DOWN") && t60.equals("DOWN")
                && a15.rsi >= 32 && a15.rsi <= 48 && a15.volRatio >= 1.10
                && a15.close < a15.candle.open && a15.prevClose >= a15.e20prev;
        if (!buy && !sell) return null;

        double entry = a15.close;
        double atrv = (Double.isNaN(a15.atr) || a15.atr == 0) ? entry * 0.005 : a15.atr;
        double center = buy ? 60 : 40;
        double rsiScore = Math.max(0, 20 - Math.abs(a15.rsi - center) * 1.5);
        double volScore = Math.min(20, Math.max(0, a15.volRatio - 1) * 12);

        Signal s = new Signal();
        s.symbol = symbol;
        s.side = buy ? "BUY" : "SELL";
        s.entry = entry;
        s.sl = buy ? entry - 1.5 * atrv : entry + 1.5 * atrv;
        s.tp = buy ? entry + 3 * atrv : entry - 3 * atrv;
        s.rsi = a15.rsi;
        s.vol = a15.volRatio;
        s.strength = (int) Math.round(60 + rsiScore + volScore);
        s.candleTime = a15.candle.time;
        return s;
    }

    // ---------- сеть ----------

    private static JSONObject getJson(String path) throws Exception {
        Exception last = null;
        for (String host : HOSTS) {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(host + path).openConnection();
                conn.setConnectTimeout(10_000);
                conn.setReadTimeout(15_000);
                conn.setRequestProperty("Accept", "application/json");
                conn.setRequestProperty("User-Agent", "BybitScalper/2.1");
                int code = conn.getResponseCode();
                if (code != 200) throw new Exception("HTTP " + code);
                StringBuilder sb = new StringBuilder();
                try (InputStream in = conn.getInputStream();
                     BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"))) {
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                }
                JSONObject j = new JSONObject(sb.toString());
                if (j.optInt("retCode", -1) != 0) throw new Exception(j.optString("retMsg", "Bybit API error"));
                return j.getJSONObject("result");
            } catch (Exception e) {
                last = e;
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw last != null ? last : new Exception("network error");
    }

    private static Signal scanSymbol(String symbol) throws Exception {
        String base = "/v5/market/kline?category=linear&symbol=" + symbol + "&limit=100&interval=";
        Analysis a15 = analyze(getJson(base + "15").getJSONArray("list"), 15);
        Analysis a30 = analyze(getJson(base + "30").getJSONArray("list"), 30);
        Analysis a60 = analyze(getJson(base + "60").getJSONArray("list"), 60);
        return signal(symbol, a15, a30, a60);
    }

    /**
     * Сканирует все ликвидные USDT-перпетуалы и возвращает найденные сигналы
     * (сильнейшие первыми). Прекращает работу, когда время вышло (deadlineMs).
     */
    static List<Signal> scanAll(long deadlineMs) throws Exception {
        JSONArray tickers = getJson("/v5/market/tickers?category=linear").getJSONArray("list");
        final List<String> symbols = new ArrayList<>();
        final List<Double> turnovers = new ArrayList<>();
        List<JSONObject> universe = new ArrayList<>();
        for (int i = 0; i < tickers.length(); i++) {
            JSONObject t = tickers.getJSONObject(i);
            String sym = t.optString("symbol");
            if (!sym.endsWith("USDT")) continue;
            if (STABLE.contains(sym.substring(0, sym.length() - 4))) continue;
            if (t.optDouble("lastPrice", 0) <= 0) continue;
            if (t.optDouble("turnover24h", 0) < MIN_TURNOVER_24H) continue;
            universe.add(t);
        }
        Collections.sort(universe, (a, b) ->
                Double.compare(b.optDouble("turnover24h", 0), a.optDouble("turnover24h", 0)));
        for (JSONObject t : universe) {
            symbols.add(t.optString("symbol"));
            turnovers.add(t.optDouble("turnover24h", 0));
        }

        List<Signal> found = new ArrayList<>();
        ExecutorService pool = Executors.newFixedThreadPool(PARALLEL);
        try {
            for (int i = 0; i < symbols.size(); i += PARALLEL) {
                if (System.currentTimeMillis() > deadlineMs) break;
                List<Future<Signal>> batch = new ArrayList<>();
                for (int j = i; j < Math.min(i + PARALLEL, symbols.size()); j++) {
                    final String sym = symbols.get(j);
                    batch.add(pool.submit(new Callable<Signal>() {
                        @Override public Signal call() throws Exception { return scanSymbol(sym); }
                    }));
                }
                for (int k = 0; k < batch.size(); k++) {
                    try {
                        Signal s = batch.get(k).get();
                        if (s != null) {
                            s.turnover = turnovers.get(i + k);
                            found.add(s);
                        }
                    } catch (Exception ignored) {
                        // по этой монете нет данных — пропускаем
                    }
                }
                Thread.sleep(400); // не превышаем лимиты Bybit
            }
        } finally {
            pool.shutdownNow();
        }
        Collections.sort(found, (a, b) -> Integer.compare(b.strength, a.strength));
        return found;
    }
}
