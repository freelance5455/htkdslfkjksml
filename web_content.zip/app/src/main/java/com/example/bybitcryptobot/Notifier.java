package com.example.bybitcryptobot;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.List;
import java.util.Locale;

/** Показ уведомлений о сигналах. */
final class Notifier {
    static final String CHANNEL_ID = "signals";
    private static final int MAX_INDIVIDUAL = 5;
    private static final int SUMMARY_ID = 1;
    private static final int TEST_ID = 2;

    private Notifier() {}

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Торговые сигналы", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("LONG / SHORT сигналы Bybit Scalper");
        nm.createNotificationChannel(ch);
    }

    static boolean canNotify(Context c) {
        if (Build.VERSION.SDK_INT >= 33
                && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        return NotificationManagerCompat.from(c).areNotificationsEnabled();
    }

    private static PendingIntent openApp(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static PendingIntent disableIntent(Context c) {
        Intent i = new Intent(c, ActionReceiver.class).setAction(ActionReceiver.ACTION_DISABLE);
        return PendingIntent.getBroadcast(c, 1, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static String price(double v) {
        int d = v < 1 ? 7 : v < 100 ? 5 : 2;
        String s = String.format(Locale.US, "%." + d + "f", v);
        if (s.contains(".")) {
            s = s.replaceAll("0+$", "");
            if (s.endsWith(".")) s = s.substring(0, s.length() - 1);
        }
        return s;
    }

    @SuppressLint("MissingPermission")
    static void showSignals(Context c, List<SignalScanner.Signal> signals) {
        if (signals.isEmpty() || !canNotify(c)) return;
        ensureChannel(c);
        NotificationManagerCompat nm = NotificationManagerCompat.from(c);
        int shown = Math.min(MAX_INDIVIDUAL, signals.size());
        try {
            for (int i = 0; i < shown; i++) {
                SignalScanner.Signal s = signals.get(i);
                String label = s.side.equals("BUY") ? "LONG" : "SHORT";
                String title = label + " · " + s.symbol + " · " + s.strength + "/100";
                String text = "Вход " + price(s.entry) + " · SL " + price(s.sl) + " · TP " + price(s.tp);
                NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL_ID)
                        .setSmallIcon(R.drawable.ic_stat_signal)
                        .setContentTitle(title)
                        .setContentText(text)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(
                                text + "\nRSI 15м: " + String.format(Locale.US, "%.1f", s.rsi)
                                        + " · объём ×" + String.format(Locale.US, "%.2f", s.vol)))
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                        .setAutoCancel(true)
                        .setContentIntent(openApp(c))
                        .addAction(0, "Отключить уведомления", disableIntent(c));
                nm.notify(s.symbol, 100, b.build());
            }
            if (signals.size() > shown) {
                NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL_ID)
                        .setSmallIcon(R.drawable.ic_stat_signal)
                        .setContentTitle("Ещё сигналов: " + (signals.size() - shown))
                        .setContentText("Откройте приложение, чтобы увидеть все")
                        .setAutoCancel(true)
                        .setContentIntent(openApp(c));
                nm.notify(SUMMARY_ID, b.build());
            }
        } catch (SecurityException ignored) {
            // разрешение на уведомления отозвано
        }
    }

    @SuppressLint("MissingPermission")
    static boolean showTest(Context c) {
        if (!canNotify(c)) return false;
        ensureChannel(c);
        try {
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_stat_signal)
                    .setContentTitle("Тестовое уведомление")
                    .setContentText("Уведомления работают. Сигналы придут, даже если приложение закрыто.")
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .setContentIntent(openApp(c));
            NotificationManagerCompat.from(c).notify(TEST_ID, b.build());
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }
}
