package com.example.bybitcryptobot;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки и память о уже отправленных уведомлениях. */
final class Prefs {
    private static final String FILE = "scalper_prefs";
    private static final String KEY_ENABLED = "notifications_enabled";
    private static final String LAST_PREFIX = "last_";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static boolean isEnabled(Context c) {
        return sp(c).getBoolean(KEY_ENABLED, true);
    }

    static void setEnabled(Context c, boolean enabled) {
        sp(c).edit().putBoolean(KEY_ENABLED, enabled).apply();
    }

    /** true, если по этой монете для этой свечи этот сигнал уже отправлялся. */
    static boolean alreadyNotified(Context c, String symbol, String side, long candleTime) {
        String v = sp(c).getString(LAST_PREFIX + symbol, null);
        return (side + ":" + candleTime).equals(v);
    }

    static void markNotified(Context c, String symbol, String side, long candleTime) {
        sp(c).edit().putString(LAST_PREFIX + symbol, side + ":" + candleTime).apply();
    }
}
