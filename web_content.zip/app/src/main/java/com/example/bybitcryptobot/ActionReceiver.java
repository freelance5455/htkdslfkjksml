package com.example.bybitcryptobot;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationManagerCompat;

/** Кнопка «Отключить уведомления» прямо в уведомлении. */
public class ActionReceiver extends BroadcastReceiver {
    static final String ACTION_DISABLE = "com.example.bybitcryptobot.DISABLE_NOTIFICATIONS";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && ACTION_DISABLE.equals(intent.getAction())) {
            Prefs.setEnabled(context, false);
            Scheduler.cancel(context);
            NotificationManagerCompat.from(context).cancelAll();
        }
    }
}
