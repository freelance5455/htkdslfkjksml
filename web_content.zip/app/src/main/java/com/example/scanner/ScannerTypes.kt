package com.example.scanner

enum class DiagramOrientation(val raw: String) {
    WHITE_BOTTOM("white_bottom"),
    BLACK_BOTTOM("black_bottom");

    companion object {
        fun fromString(s: String?): DiagramOrientation =
            if (s == "black_bottom") BLACK_BOTTOM else WHITE_BOTTOM
    }
}

enum class SquareShade(val raw: String) {
    LIGHT("light"),
    DARK("dark")
}

enum class NccStatus {
    MATCH,    // >= 0.85
    CONFIRM,  // 0.70 .. < 0.85
    FALLBACK  // < 0.70
}

data class CropRect(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
)

data class PieceTemplate(
    val pieceCode: String, // e.g. "wK", "bP", "empty"
    val squareColor: SquareShade,
    val pixels: FloatArray, // length 1024 (32x32)
    val sampleCount: Int
)

data class NccMatchResult(
    val pieceCode: String,
    val score: Float,
    val status: NccStatus
)

data class TemplateCoverage(
    val totalLearned: Int,
    val totalRequired: Int = 26,
    val percentage: Int,
    val missingTemplates: List<String>
)

data class CrossCheckResult(
    val square: String,
    val row: Int,
    val col: Int,
    val boardPiece: String,
    val listPiece: String,
    val agreed: Boolean
)

data class ValidationResult(
    val isValid: Boolean,
    val errors: List<String>,
    val warnings: List<String>,
    val whiteKingCount: Int,
    val blackKingCount: Int,
    val whitePawnCount: Int,
    val blackPawnCount: Int,
    val whiteInCheck: Boolean,
    val blackInCheck: Boolean,
    val sideToMove: Char,
    val fen: String
)

data class SquareVote(
    val square: String,
    val row: Int,
    val col: Int,
    val votes: Map<String, Int>,
    val winner: String,
    val totalVotes: Int,
    val confidence: Float,
    val wasTie: Boolean
)

data class SuggestedRepair(
    val square: String,
    val row: Int,
    val col: Int,
    val fromPiece: String,
    val toPiece: String,
    val reason: String,
    val repairedFen: String
)

data class PassScanResult(
    val passName: String,
    val grid: Array<Array<String>>,
    val orientation: DiagramOrientation
)

data class DiagramScanResult(
    val fen: String,
    val sideToMove: Char,
    val orientation: DiagramOrientation,
    val grid: Array<Array<String>>, // 8x8 of "wK".."bP" or "empty"
    val confidence: Float,
    val isValid: Boolean,
    val validation: ValidationResult,
    val uncertainSquares: List<String>,
    val crossCheckResults: List<CrossCheckResult>,
    val votingMatrix: List<SquareVote>,
    val suggestedRepairs: List<SuggestedRepair>,
    val sourceMethod: String, // "offline_ncc", "offline_silhouette", "gemini_vision"
    val cropRect: CropRect,
    val elapsedMs: Long,
    val errorNote: String? = null
)

object PieceCodes {
    val ALL = listOf(
        "wK", "wQ", "wR", "wB", "wN", "wP",
        "bK", "bQ", "bR", "bB", "bN", "bP",
        "empty"
    )

    val CODE_TO_FEN = mapOf(
        "wK" to 'K', "wQ" to 'Q', "wR" to 'R', "wB" to 'B', "wN" to 'N', "wP" to 'P',
        "bK" to 'k', "bQ" to 'q', "bR" to 'r', "bB" to 'b', "bN" to 'n', "bP" to 'p'
    )

    val FEN_TO_CODE = CODE_TO_FEN.entries.associate { (k, v) -> v to k }

    fun normalize(raw: String?): String {
        if (raw.isNullOrBlank()) return "empty"
        val clean = raw.trim()
        if (clean in ALL) return clean
        val upper = clean.uppercase()
        if (upper in setOf("EMPTY", "-", "NONE", ".")) return "empty"
        if (clean.length == 2) {
            val c = clean[0].lowercaseChar()
            val t = clean[1].uppercaseChar()
            if ((c == 'w' || c == 'b') && t in charArrayOf('P', 'N', 'B', 'R', 'Q', 'K')) {
                return "$c$t"
            }
        }
        if (clean.length == 1) {
            FEN_TO_CODE[clean[0]]?.let { return it }
        }
        return "empty"
    }
}
