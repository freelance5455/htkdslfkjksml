package com.example.scanner

import android.graphics.Bitmap
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.ThinkingLevel
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.ai.type.thinkingConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private const val TAG = "DiagramScanner"

object DiagramRecognitionPipeline {

    private val diagramScanSchema = Schema.obj(
        properties = mapOf(
            "pieces" to Schema.array(
                items = Schema.string(),
                description = "List of non-empty pieces and squares, e.g. [\"wK g1\", \"bP d6\"]"
            ),
            "board" to Schema.array(
                items = Schema.array(items = Schema.string()),
                description = "8x8 board matrix where row 0 is rank 8 and row 7 is rank 1, using wK,wQ,wR,wB,wN,wP,bK,bQ,bR,bB,bN,bP, or empty"
            ),
            "orientation" to Schema.enumeration(
                values = listOf("white_bottom", "black_bottom", "unknown"),
                description = "Board orientation"
            ),
            "reasoning" to Schema.string(description = "Brief visual check notes")
        ),
        optionalProperties = listOf("reasoning")
    )

    // Lazy Firebase AI Logic model using gemini-4-argon with ThinkingLevel.HIGH (no maxOutputTokens)
    private val geminiVisionModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-4-argon",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = diagramScanSchema
                thinkingConfig = thinkingConfig {
                    thinkingLevel = ThinkingLevel.HIGH
                }
            }
        )
    }

    /**
     * Unified 4-Phase Recognition Pipeline:
     * 1. Frame detection & 640px clean/grid crop
     * 2. Local 32x32 Normalized Cross-Correlation (NCC) against learned book templates (<10ms offline)
     * 3. Optional Firebase AI Logic (gemini-4-argon + ThinkingLevel.HIGH) fallback when NCC < 0.70 & online
     * 4. Offline silhouette classifier fallback when offline & templates unlearned, followed by
     *    cross-check, legal repair, and deterministic FEN validation.
     */
    suspend fun recognize(
        sourceBitmap: Bitmap,
        manualCropRect: CropRect? = null,
        templates: Map<String, PieceTemplate> = emptyMap(),
        preferredSideToMove: Char = 'w',
        surroundingText: String = "",
        allowOnlineGeminiFallback: Boolean = false
    ): DiagramScanResult = withContext(Dispatchers.Default) {
        val startMs = System.currentTimeMillis()
        val detectedCrop = ScannerCrop.detectBoardFrameAndCrop(sourceBitmap, manualCropRect)
        val prepared = ScannerCrop.prepareDiagramImages(sourceBitmap, detectedCrop, 640)
        val cells32 = ScannerCrop.extractBoardCells32x32(prepared.cleanBitmap)

        val textHint = ScannerFenAndVoting.detectSideToMoveFromText(surroundingText)
        val candidateTurn = textHint ?: preferredSideToMove

        // Phase 3 Offline NCC Template Matching
        val coverage = ScannerNcc.calculateTemplateCoverage(templates)
        if (coverage.totalLearned >= 6) {
            val nccGrid = Array(8) { Array(8) { "empty" } }
            val uncertain = ArrayList<String>()
            var fallbackCount = 0
            var scoreSum = 0f

            for (r in 0..7) {
                for (c in 0..7) {
                    val shade = if ((r + c) % 2 == 1) SquareShade.DARK else SquareShade.LIGHT
                    val match = ScannerNcc.matchCellWithTemplates(cells32[r][c], shade, templates)
                    nccGrid[r][c] = match.pieceCode
                    scoreSum += match.score
                    val sq = ScannerFenAndVoting.gridToSquare(r, c, DiagramOrientation.WHITE_BOTTOM)
                    if (match.status == NccStatus.CONFIRM) {
                        uncertain.add(sq)
                    } else if (match.status == NccStatus.FALLBACK) {
                        fallbackCount++
                        uncertain.add(sq)
                    }
                }
            }

            val avgScore = scoreSum / 64f
            // If learned book templates cover this diagram cleanly (or online fallback is disabled)
            if (fallbackCount <= 8 || !allowOnlineGeminiFallback) {
                val repairedGrid = applyAutoRepairsIfNeeded(nccGrid, uncertain, candidateTurn, surroundingText)
                val validation = ScannerFenAndVoting.validateBoard(
                    grid = repairedGrid,
                    preferredSideToMove = candidateTurn,
                    orientation = DiagramOrientation.WHITE_BOTTOM,
                    surroundingText = surroundingText
                )
                val repairs = ScannerFenAndVoting.suggestFewestLegalRepairs(
                    repairedGrid, validation, uncertain, DiagramOrientation.WHITE_BOTTOM, candidateTurn
                )
                if (validation.isValid || fallbackCount <= 8) {
                    return@withContext DiagramScanResult(
                        fen = validation.fen,
                        sideToMove = validation.sideToMove,
                        orientation = DiagramOrientation.WHITE_BOTTOM,
                        grid = repairedGrid,
                        confidence = avgScore.coerceIn(0.5f, 0.99f),
                        isValid = validation.isValid,
                        validation = validation,
                        uncertainSquares = uncertain,
                        crossCheckResults = emptyList(),
                        votingMatrix = emptyList(),
                        suggestedRepairs = repairs,
                        sourceMethod = "offline_ncc",
                        cropRect = detectedCrop,
                        elapsedMs = System.currentTimeMillis() - startMs
                    )
                }
            }
        }

        // Phase 2/4: Online Gemini Vision Fallback via Firebase AI Logic (only when requested/allowed)
        var cloudErrorNote: String? = null
        if (allowOnlineGeminiFallback) {
            try {
                val cloudResult = runGeminiMultiPassScan(
                    cleanBitmap = prepared.cleanBitmap,
                    gridBitmap = prepared.gridBitmap,
                    surroundingText = surroundingText,
                    candidateTurn = candidateTurn,
                    cropRect = detectedCrop,
                    startMs = startMs
                )
                return@withContext cloudResult
            } catch (e: CancellationException) {
                throw e
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Gemini diagram scan timed out", e)
                cloudErrorNote = "Cloud scan timed out; used offline optical scanner."
            } catch (e: Exception) {
                Log.e(TAG, "Gemini diagram scan failed, falling back to offline silhouette scanner", e)
                cloudErrorNote = e.localizedMessage ?: "Cloud scan unavailable offline; used local scanner."
            }
        }

        // 100% Offline Zero-Shot Optical Silhouette Scanner (faithful port of chessVisionScanner.ts)
        val offlineGrid = scanCleanBitmapOfflineSilhouette(prepared.cleanBitmap)
        val validation = ScannerFenAndVoting.validateBoard(
            grid = offlineGrid,
            preferredSideToMove = candidateTurn,
            orientation = DiagramOrientation.WHITE_BOTTOM,
            surroundingText = surroundingText
        )
        val repairs = ScannerFenAndVoting.suggestFewestLegalRepairs(
            offlineGrid, validation, emptyList(), DiagramOrientation.WHITE_BOTTOM, candidateTurn
        )

        DiagramScanResult(
            fen = validation.fen,
            sideToMove = validation.sideToMove,
            orientation = DiagramOrientation.WHITE_BOTTOM,
            grid = offlineGrid,
            confidence = if (validation.isValid) 0.91f else 0.78f,
            isValid = validation.isValid,
            validation = validation,
            uncertainSquares = emptyList(),
            crossCheckResults = emptyList(),
            votingMatrix = emptyList(),
            suggestedRepairs = repairs,
            sourceMethod = "offline_silhouette",
            cropRect = detectedCrop,
            elapsedMs = System.currentTimeMillis() - startMs,
            errorNote = cloudErrorNote
        )
    }

    private suspend fun runGeminiMultiPassScan(
        cleanBitmap: Bitmap,
        gridBitmap: Bitmap,
        surroundingText: String,
        candidateTurn: Char,
        cropRect: CropRect,
        startMs: Long
    ): DiagramScanResult = withContext(Dispatchers.IO) {
        val prompt = """
            You are a high-accuracy chess diagram vision reader.
            Examine the two provided images of the exact same chess diagram:
            Image 1: Clean high-resolution square-cropped diagram (frame and outer coordinates stripped).
            Image 2: Diagnostic grid overlay with red square borders and coordinates (ranks 8 to 1, files a to h).
            Surrounding caption/text from page: "${surroundingText.ifBlank { "None" }}"
            RULES FOR EXTRACTION:
            1. Pieces list: Output an array of all non-empty pieces and their square, format: "<pieceCode> <square>" (e.g. "wK e1", "bP d5", "wQ d1", "bB f8").
            2. Board grid: Output an 8x8 matrix representing ranks 8 down to 1 (row 0 = rank 8, row 7 = rank 1), files a to h (col 0 = file a, col 7 = file h).
               Use standard piece codes: wK, wQ, wR, wB, wN, wP, bK, bQ, bR, bB, bN, bP, or "empty".
            3. Orientation: Determine if white is at the bottom ("white_bottom") or black is at the bottom ("black_bottom").
            4. Never generate or format a FEN string directly.
        """.trimIndent()

        // Pass 1: Clean + Red Diagnostic Grid
        val pass1Response = withTimeout(60_000L) {
            geminiVisionModel.generateContent(
                content {
                    image(cleanBitmap)
                    image(gridBitmap)
                    text(prompt)
                }
            )
        }
        val pass1Text = pass1Response.text ?: throw IllegalStateException("Empty response from Gemini Vision.")
        val pass1Json = JSONObject(pass1Text)
        val orientation = DiagramOrientation.fromString(pass1Json.optString("orientation", "white_bottom"))

        val piecesArr = pass1Json.optJSONArray("pieces")
        val rawPieces = buildList {
            if (piecesArr != null) {
                for (i in 0 until piecesArr.length()) add(piecesArr.getString(i))
            }
        }
        val boardArr = pass1Json.optJSONArray("board")
        val rawBoard = buildList {
            if (boardArr != null) {
                for (r in 0 until boardArr.length()) {
                    val rowArr = boardArr.optJSONArray(r)
                    add(
                        buildList {
                            if (rowArr != null) {
                                for (c in 0 until rowArr.length()) add(rowArr.getString(c))
                            }
                        }
                    )
                }
            }
        }

        val (pass1Grid, crossCheck, pass1Uncertain) =
            ScannerFenAndVoting.crossCheckBoardAndPieces(rawBoard, rawPieces, orientation)

        val passes = mutableListOf(PassScanResult("Pass 1 (Clean + Grid)", pass1Grid, orientation))

        // Pass 2 (Contrast Boosted) if cross-check found uncertain squares
        if (pass1Uncertain.isNotEmpty()) {
            try {
                val contrastBitmap = ScannerCrop.prepareContrastBoostedCrop(cleanBitmap)
                val pass2Resp = withTimeout(45_000L) {
                    geminiVisionModel.generateContent(
                        content {
                            image(contrastBitmap)
                            image(gridBitmap)
                            text(prompt)
                        }
                    )
                }
                pass2Resp.text?.let { p2Txt ->
                    val p2Json = JSONObject(p2Txt)
                    val p2PiecesArr = p2Json.optJSONArray("pieces")
                    val p2Pieces = buildList {
                        if (p2PiecesArr != null) for (i in 0 until p2PiecesArr.length()) add(p2PiecesArr.getString(i))
                    }
                    val p2BoardArr = p2Json.optJSONArray("board")
                    val p2Board = buildList {
                        if (p2BoardArr != null) {
                            for (r in 0 until p2BoardArr.length()) {
                                val rArr = p2BoardArr.optJSONArray(r)
                                add(buildList { if (rArr != null) for (c in 0 until rArr.length()) add(rArr.getString(c)) })
                            }
                        }
                    }
                    val (p2Grid, _, _) = ScannerFenAndVoting.crossCheckBoardAndPieces(p2Board, p2Pieces, orientation)
                    passes.add(PassScanResult("Pass 2 (Contrast Boost)", p2Grid, orientation))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Pass 2 contrast scan skipped: ${e.message}")
            }
        }

        val (votedGrid, votingMatrix, contentious) = ScannerFenAndVoting.tallyMajorityVotes(passes, orientation)
        val combinedUncertain = (pass1Uncertain + contentious).distinct()

        val validation = ScannerFenAndVoting.validateBoard(
            grid = votedGrid,
            preferredSideToMove = candidateTurn,
            orientation = orientation,
            surroundingText = surroundingText
        )
        val repairs = ScannerFenAndVoting.suggestFewestLegalRepairs(
            votedGrid, validation, combinedUncertain, orientation, candidateTurn
        )

        val conf = if (combinedUncertain.isEmpty() && validation.isValid) 0.98f
        else (1f - combinedUncertain.size / 64f).coerceIn(0.65f, 0.96f)

        DiagramScanResult(
            fen = validation.fen,
            sideToMove = validation.sideToMove,
            orientation = orientation,
            grid = votedGrid,
            confidence = conf,
            isValid = validation.isValid,
            validation = validation,
            uncertainSquares = combinedUncertain,
            crossCheckResults = crossCheck,
            votingMatrix = votingMatrix,
            suggestedRepairs = repairs,
            sourceMethod = "gemini_vision",
            cropRect = cropRect,
            elapsedMs = System.currentTimeMillis() - startMs
        )
    }

    private fun applyAutoRepairsIfNeeded(
        grid: Array<Array<String>>,
        uncertain: List<String>,
        turn: Char,
        surroundingText: String
    ): Array<Array<String>> {
        val check = ScannerFenAndVoting.validateBoard(grid, turn, surroundingText = surroundingText)
        if (check.isValid) return grid
        val repairs = ScannerFenAndVoting.suggestFewestLegalRepairs(grid, check, uncertain, sideToMove = turn)
        val copy = ScannerFenAndVoting.copyGrid(grid)
        for (rep in repairs) {
            copy[rep.row][rep.col] = rep.toPiece
        }
        return copy
    }

    /**
     * Faithful native Kotlin port of chessVisionScanner.ts (detectPieceInSquarePatch + king safeguard).
     * Runs 100% offline with zero network calls.
     */
    fun scanCleanBitmapOfflineSilhouette(cleanBitmap: Bitmap): Array<Array<String>> {
        val w = cleanBitmap.width
        val h = cleanBitmap.height
        val pixels = IntArray(w * h)
        cleanBitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val sqW = w / 8f
        val sqH = h / 8f
        val grid = Array(8) { Array(8) { "empty" } }

        for (r in 0..7) {
            for (c in 0..7) {
                val isDark = (r + c) % 2 == 1
                val startX = floor(c * sqW).toInt()
                val startY = floor(r * sqH).toInt()
                val patchW = floor(sqW).toInt()
                val patchH = floor(sqH).toInt()
                val fenChar = detectPieceInSquarePatch(pixels, w, h, startX, startY, patchW, patchH, isDark)
                grid[r][c] = fenChar?.let { PieceCodes.FEN_TO_CODE[it] } ?: "empty"
            }
        }

        // Ensure both sides have 1 King (exact safeguard from chessVisionScanner.ts)
        var hasWK = false
        var hasBK = false
        for (r in 0..7) {
            for (c in 0..7) {
                if (grid[r][c] == "wK") hasWK = true
                if (grid[r][c] == "bK") hasBK = true
            }
        }
        if (!hasWK) {
            var promoted = false
            for (r in 7 downTo 0) {
                for (c in 0..7) {
                    if (grid[r][c] == "wQ") {
                        grid[r][c] = "wK"
                        promoted = true
                        break
                    }
                }
                if (promoted) break
            }
            if (!promoted) {
                if (grid[7][6] == "empty") grid[7][6] = "wK"
                else if (grid[7][4] == "empty") grid[7][4] = "wK"
            }
        }
        if (!hasBK) {
            var promoted = false
            for (r in 0..7) {
                for (c in 0..7) {
                    if (grid[r][c] == "bQ") {
                        grid[r][c] = "bK"
                        promoted = true
                        break
                    }
                }
                if (promoted) break
            }
            if (!promoted) {
                if (grid[0][6] == "empty") grid[0][6] = "bK"
                else if (grid[0][4] == "empty") grid[0][4] = "bK"
            }
        }
        // Prevent pawns on rank 1 or 8
        for (c in 0..7) {
            if (grid[0][c] == "wP") grid[0][c] = "wB"
            if (grid[0][c] == "bP") grid[0][c] = "bB"
            if (grid[7][c] == "wP") grid[7][c] = "wB"
            if (grid[7][c] == "bP") grid[7][c] = "bB"
        }
        return grid
    }

    private fun detectPieceInSquarePatch(
        pixels: IntArray,
        canvasW: Int,
        canvasH: Int,
        startX: Int,
        startY: Int,
        patchW: Int,
        patchH: Int,
        isDarkSquare: Boolean
    ): Char? {
        val marginX = floor(patchW * 0.10f).toInt()
        val marginY = floor(patchH * 0.10f).toInt()
        val innerW = patchW - marginX * 2
        val innerH = patchH - marginY * 2
        if (innerW <= 4 || innerH <= 4) return null

        val corners = arrayOf(
            (startX + marginX) to (startY + marginY),
            (startX + patchW - marginX - 1) to (startY + marginY),
            (startX + marginX) to (startY + patchH - marginY - 1),
            (startX + patchW - marginX - 1) to (startY + patchH - marginY - 1)
        )
        var cornerLumSum = 0f
        var cornerCount = 0
        for ((cx, cy) in corners) {
            if (cx in 0 until canvasW && cy in 0 until canvasH) {
                val p = pixels[cy * canvasW + cx]
                val lum = 0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)
                cornerLumSum += lum
                cornerCount++
            }
        }
        val bgLum = if (cornerCount > 0) cornerLumSum / cornerCount else if (isDarkSquare) 180f else 250f

        val centerLeft = floor(innerW * 0.20f).toInt()
        val centerRight = floor(innerW * 0.80f).toInt()
        val centerTop = floor(innerH * 0.18f).toInt()
        val centerBottom = floor(innerH * 0.82f).toInt()

        var fgPixels = 0
        var centerFgPixels = 0
        var darkFgPixels = 0
        var lightInteriorPixels = 0
        var totalInner = 0
        var totalCenter = 0
        var minX = innerW
        var maxX = 0
        var minY = innerH
        var maxY = 0
        val colCounts = IntArray(innerW)

        for (y in 0 until innerH) {
            val py = startY + marginY + y
            if (py !in 0 until canvasH) continue
            val rowOff = py * canvasW
            for (x in 0 until innerW) {
                val px = startX + marginX + x
                if (px !in 0 until canvasW) continue
                val p = pixels[rowOff + px]
                val lum = 0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)
                totalInner++
                val inCenter = x in centerLeft..centerRight && y in centerTop..centerBottom
                if (inCenter) totalCenter++

                val isFg = if (isDarkSquare) {
                    lum < 110f || (bgLum < 175f && lum > 215f)
                } else {
                    lum < 165f
                }
                if (isFg) {
                    fgPixels++
                    if (inCenter) centerFgPixels++
                    colCounts[x]++
                    if (lum < 95f) darkFgPixels++
                    else if (lum > 185f) lightInteriorPixels++
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        val fgDensity = if (totalInner > 0) fgPixels.toFloat() / totalInner else 0f
        val centerDensity = if (totalCenter > 0) centerFgPixels.toFloat() / totalCenter else 0f

        if (fgDensity < 0.06f || centerDensity < 0.08f || minX >= maxX || minY >= maxY) return null
        if (isDarkSquare && centerDensity < 0.14f && lightInteriorPixels < 12) return null

        val pieceWidth = maxX - minX + 1
        val pieceHeight = maxY - minY + 1
        val heightRatio = pieceHeight.toFloat() / innerH
        val widthRatio = pieceWidth.toFloat() / innerW
        if (heightRatio < 0.25f || widthRatio < 0.25f) return null

        val isWhitePiece = lightInteriorPixels > darkFgPixels * 0.40f || (isDarkSquare && lightInteriorPixels > 14)

        // Optimized 1D column symmetry computation (mathematically identical to chessVisionScanner.ts)
        var symDiff = 0
        val halfW = pieceWidth / 2
        for (x in 0 until halfW) {
            val leftHas = if (colCounts[minX + x] > 0) 1 else 0
            val rightHas = if (colCounts[maxX - x] > 0) 1 else 0
            symDiff += abs(leftHas - rightHas)
        }
        val symmetryScore = if (halfW > 0) 1f - symDiff.toFloat() / halfW else 1f

        val topQuarterY = minY + floor(pieceHeight * 0.25f).toInt()
        var topWidth = 0
        for (x in minX..maxX) {
            var hasTop = false
            val px = startX + marginX + x
            if (px in 0 until canvasW) {
                for (y in minY..min(topQuarterY, innerH - 1)) {
                    val py = startY + marginY + y
                    if (py in 0 until canvasH) {
                        val p = pixels[py * canvasW + px]
                        val lum = 0.299f * ((p shr 16) and 0xFF) + 0.587f * ((p shr 8) and 0xFF) + 0.114f * (p and 0xFF)
                        if (if (isDarkSquare) (lum < 110f || (bgLum < 175f && lum > 215f)) else (lum < 165f)) {
                            hasTop = true
                            break
                        }
                    }
                }
            }
            if (hasTop) topWidth++
        }
        val topWidthRatio = topWidth.toFloat() / pieceWidth

        val baseChar = when {
            heightRatio < 0.58f && widthRatio < 0.60f -> 'P'
            symmetryScore < 0.73f && heightRatio < 0.84f -> 'N'
            topWidthRatio > 0.62f && heightRatio < 0.78f -> 'R'
            heightRatio >= 0.78f -> if (topWidthRatio > 0.54f) 'Q' else 'K'
            symmetryScore < 0.78f -> 'N'
            else -> 'B'
        }
        return if (isWhitePiece) baseChar else baseChar.lowercaseChar()
    }
}
