package com.example.scanner

import com.example.chess.CastlingRights
import com.example.chess.ChessEngineCore
import com.example.chess.PieceColor
import kotlin.math.abs

object ScannerFenAndVoting {

    fun gridToSquare(row: Int, col: Int, orientation: DiagramOrientation = DiagramOrientation.WHITE_BOTTOM): String {
        return if (orientation == DiagramOrientation.BLACK_BOTTOM) {
            val file = ('a'.code + (7 - col)).toChar()
            val rank = row + 1
            "$file$rank"
        } else {
            val file = ('a'.code + col).toChar()
            val rank = 8 - row
            "$file$rank"
        }
    }

    fun squareToGrid(square: String, orientation: DiagramOrientation = DiagramOrientation.WHITE_BOTTOM): Pair<Int, Int> {
        val clean = square.trim().lowercase()
        val fileIdx = (clean.getOrElse(0) { 'a' } - 'a').coerceIn(0, 7)
        val rankNum = (clean.getOrElse(1) { '1' } - '0').coerceIn(1, 8)
        return if (orientation == DiagramOrientation.BLACK_BOTTOM) {
            (rankNum - 1) to (7 - fileIdx)
        } else {
            (8 - rankNum) to fileIdx
        }
    }

    /**
     * Faithful port of parsePieceList and crossCheckBoardAndPieces from scanner/crosscheck.ts
     */
    fun parsePieceList(piecesList: List<String>): Map<String, String> {
        val map = HashMap<String, String>()
        val sqRegex = Regex("^[a-h][1-8]$")
        for (item in piecesList) {
            val parts = item.trim().split(Regex("\\s+"))
            if (parts.size < 2) continue
            var pieceStr = parts[0]
            var sqStr = parts[1].lowercase()
            if (sqRegex.matches(pieceStr.lowercase()) && !sqRegex.matches(sqStr)) {
                val tmp = pieceStr
                pieceStr = sqStr
                sqStr = tmp.lowercase()
            }
            if (sqRegex.matches(sqStr)) {
                val norm = PieceCodes.normalize(pieceStr)
                if (norm != "empty") {
                    map[sqStr] = norm
                }
            }
        }
        return map
    }

    fun crossCheckBoardAndPieces(
        rawBoard: List<List<String>>,
        rawPiecesList: List<String>,
        orientation: DiagramOrientation = DiagramOrientation.WHITE_BOTTOM
    ): Triple<Array<Array<String>>, List<CrossCheckResult>, List<String>> {
        val pieceMap = parsePieceList(rawPiecesList)
        val grid = Array(8) { Array(8) { "empty" } }
        val results = ArrayList<CrossCheckResult>(64)
        val uncertain = ArrayList<String>()

        for (r in 0..7) {
            for (c in 0..7) {
                val sq = gridToSquare(r, c, orientation)
                val boardCell = PieceCodes.normalize(rawBoard.getOrNull(r)?.getOrNull(c))
                val listCell = pieceMap[sq] ?: "empty"
                val agreed = boardCell == listCell
                grid[r][c] = if (agreed) boardCell else if (boardCell != "empty") boardCell else listCell
                if (!agreed) uncertain.add(sq)
                results.add(CrossCheckResult(sq, r, c, boardCell, listCell, agreed))
            }
        }
        return Triple(grid, results, uncertain)
    }

    /**
     * Faithful port of buildFenPlacement, buildFullFen, detectSideToMoveFromText, and validateBoard from scanner/fen.ts
     */
    fun buildFenPlacement(
        grid: Array<Array<String>>,
        orientation: DiagramOrientation = DiagramOrientation.WHITE_BOTTOM
    ): String {
        val rows = ArrayList<String>(8)
        for (rank in 8 downTo 1) {
            val sb = StringBuilder()
            var emptyCount = 0
            for (file in 0..7) {
                val sq = "${('a'.code + file).toChar()}$rank"
                val (r, c) = squareToGrid(sq, orientation)
                val code = grid.getOrNull(r)?.getOrNull(c) ?: "empty"
                val ch = PieceCodes.CODE_TO_FEN[code]
                if (ch != null) {
                    if (emptyCount > 0) {
                        sb.append(emptyCount)
                        emptyCount = 0
                    }
                    sb.append(ch)
                } else {
                    emptyCount++
                }
            }
            if (emptyCount > 0) sb.append(emptyCount)
            rows.add(sb.toString())
        }
        return rows.joinToString("/")
    }

    fun buildFullFen(
        grid: Array<Array<String>>,
        sideToMove: Char = 'w',
        castling: CastlingRights = CastlingRights.NONE,
        enPassant: String = "-",
        orientation: DiagramOrientation = DiagramOrientation.WHITE_BOTTOM
    ): String {
        val placement = buildFenPlacement(grid, orientation)
        val castlingStr = castling.toFenString()
        val ep = if (enPassant.isNotBlank() && enPassant != "-") enPassant else "-"
        return "$placement $sideToMove $castlingStr $ep 0 1"
    }

    fun detectSideToMoveFromText(text: String): Char? {
        if (text.isBlank()) return null
        val lower = text.lowercase()
        val whiteMatches = listOf(
            "white to move", "white to play", "white to mate",
            "white wins", "w to play", "w to move", "diagram: white", "white plays"
        )
        val blackMatches = listOf(
            "black to move", "black to play", "black to mate",
            "black wins", "b to play", "b to move", "diagram: black", "black plays",
            "1...", "..."
        )
        for (p in whiteMatches) if (lower.contains(p)) return 'w'
        for (p in blackMatches) if (lower.contains(p)) return 'b'
        return null
    }

    private fun areKingsAdjacent(grid: Array<Array<String>>): Boolean {
        var wk: Pair<Int, Int>? = null
        var bk: Pair<Int, Int>? = null
        for (r in 0..7) {
            for (c in 0..7) {
                if (grid[r][c] == "wK") wk = r to c
                if (grid[r][c] == "bK") bk = r to c
            }
        }
        val w = wk ?: return false
        val b = bk ?: return false
        return abs(w.first - b.first) <= 1 && abs(w.second - b.second) <= 1
    }

    fun validateBoard(
        grid: Array<Array<String>>,
        preferredSideToMove: Char = 'w',
        castling: CastlingRights = CastlingRights.NONE,
        enPassant: String = "-",
        orientation: DiagramOrientation = DiagramOrientation.WHITE_BOTTOM,
        surroundingText: String = ""
    ): ValidationResult {
        val errors = ArrayList<String>()
        val warnings = ArrayList<String>()

        var wkCount = 0
        var bkCount = 0
        var wpCount = 0
        var bpCount = 0

        for (r in 0..7) {
            for (c in 0..7) {
                val piece = grid[r][c]
                val sq = gridToSquare(r, c, orientation)
                val rank = sq[1] - '0'
                when (piece) {
                    "wK" -> wkCount++
                    "bK" -> bkCount++
                    "wP" -> {
                        wpCount++
                        if (rank == 1 || rank == 8) errors.add("Illegal White pawn on $sq (rank $rank).")
                    }
                    "bP" -> {
                        bpCount++
                        if (rank == 1 || rank == 8) errors.add("Illegal Black pawn on $sq (rank $rank).")
                    }
                }
            }
        }

        if (wkCount != 1) {
            errors.add(if (wkCount == 0) "Missing White King (must have exactly 1)." else "Found $wkCount White Kings (must have exactly 1).")
        }
        if (bkCount != 1) {
            errors.add(if (bkCount == 0) "Missing Black King (must have exactly 1)." else "Found $bkCount Black Kings (must have exactly 1).")
        }
        if (wpCount > 8) errors.add("Too many White pawns: $wpCount (max 8 allowed).")
        if (bpCount > 8) errors.add("Too many Black pawns: $bpCount (max 8 allowed).")

        if (wkCount == 1 && bkCount == 1 && areKingsAdjacent(grid)) {
            errors.add("Illegal position: Kings are adjacent.")
        }

        var resolvedTurn = preferredSideToMove
        var whiteInCheck = false
        var blackInCheck = false

        if (wkCount == 1 && bkCount == 1 && errors.isEmpty()) {
            val testBoard = Array(8) { r ->
                Array(8) { c ->
                    PieceCodes.CODE_TO_FEN[grid[r][c]]?.let { com.example.chess.ChessPiece.fromFenChar(it) }
                }
            }
            // Orientation adjustment via placement parse
            val rawFenW = buildFullFen(grid, 'w', castling, enPassant, orientation)
            val rawPos = parseUncheckedPosition(rawFenW)
            if (rawPos != null) {
                whiteInCheck = rawPos.isInCheck(PieceColor.WHITE)
                blackInCheck = rawPos.isInCheck(PieceColor.BLACK)
            }
            if (whiteInCheck && blackInCheck) {
                errors.add("Illegal position: Both White and Black are in check simultaneously.")
            } else if (whiteInCheck) {
                resolvedTurn = 'w'
            } else if (blackInCheck) {
                resolvedTurn = 'b'
            } else {
                detectSideToMoveFromText(surroundingText)?.let { resolvedTurn = it }
            }
        }

        val fullFen = buildFullFen(grid, resolvedTurn, castling, enPassant, orientation)
        var isValid = errors.isEmpty()
        if (isValid) {
            val parsed = ChessEngineCore.parseFen(fullFen)
            if (parsed == null) {
                errors.add("Illegal chess position: side not to move is in check or invalid setup.")
                isValid = false
            }
        }

        return ValidationResult(
            isValid = isValid,
            errors = errors,
            warnings = warnings,
            whiteKingCount = wkCount,
            blackKingCount = bkCount,
            whitePawnCount = wpCount,
            blackPawnCount = bpCount,
            whiteInCheck = whiteInCheck,
            blackInCheck = blackInCheck,
            sideToMove = resolvedTurn,
            fen = fullFen
        )
    }

    private fun parseUncheckedPosition(fen: String): com.example.chess.ChessPosition? {
        val parts = fen.trim().split(Regex("\\s+"))
        if (parts.isEmpty()) return null
        val ranks = parts[0].split('/')
        if (ranks.size != 8) return null
        val board = Array(8) { arrayOfNulls<com.example.chess.ChessPiece>(8) }
        for (r in 0..7) {
            var c = 0
            for (ch in ranks[r]) {
                if (ch.isDigit()) c += (ch - '0')
                else {
                    if (c !in 0..7) return null
                    board[r][c] = com.example.chess.ChessPiece.fromFenChar(ch) ?: return null
                    c++
                }
            }
            if (c != 8) return null
        }
        return com.example.chess.ChessPosition(
            board = board,
            turn = PieceColor.WHITE,
            castling = CastlingRights.NONE,
            enPassantTarget = null,
            halfMoveClock = 0,
            fullMoveNumber = 1
        )
    }

    /**
     * Faithful port of tallyMajorityVotes and suggestFewestLegalRepairs from scanner/voting.ts
     */
    fun tallyMajorityVotes(
        passes: List<PassScanResult>,
        orientation: DiagramOrientation = DiagramOrientation.WHITE_BOTTOM
    ): Triple<Array<Array<String>>, List<SquareVote>, List<String>> {
        val votingMatrix = ArrayList<SquareVote>(64)
        val contentious = ArrayList<String>()
        val grid = Array(8) { Array(8) { "empty" } }

        for (r in 0..7) {
            for (c in 0..7) {
                val sq = gridToSquare(r, c, orientation)
                val counts = LinkedHashMap<String, Int>()
                var total = 0
                for (p in passes) {
                    val code = p.grid.getOrNull(r)?.getOrNull(c) ?: "empty"
                    counts[code] = (counts[code] ?: 0) + 1
                    total++
                }
                var winner = "empty"
                var maxVotes = -1
                var wasTie = false
                for ((piece, cnt) in counts) {
                    if (cnt > maxVotes) {
                        maxVotes = cnt
                        winner = piece
                        wasTie = false
                    } else if (cnt == maxVotes) {
                        wasTie = true
                    }
                }
                val conf = if (total > 0) maxVotes.toFloat() / total else 0f
                if (wasTie || conf < 0.66f) contentious.add(sq)
                grid[r][c] = winner
                votingMatrix.add(SquareVote(sq, r, c, counts, winner, total, conf, wasTie))
            }
        }
        return Triple(grid, votingMatrix, contentious)
    }

    fun suggestFewestLegalRepairs(
        grid: Array<Array<String>>,
        validation: ValidationResult,
        uncertainSquares: List<String>,
        orientation: DiagramOrientation = DiagramOrientation.WHITE_BOTTOM,
        sideToMove: Char = 'w'
    ): List<SuggestedRepair> {
        if (validation.isValid) return emptyList()
        val suggestions = ArrayList<SuggestedRepair>()

        // Strategy 1: Pawns on rank 1 or 8 -> Bishop or Rook or empty
        for (r in 0..7) {
            for (c in 0..7) {
                val sq = gridToSquare(r, c, orientation)
                val rank = sq[1] - '0'
                val piece = grid[r][c]
                if ((piece == "wP" || piece == "bP") && (rank == 1 || rank == 8)) {
                    val replacement = if (piece == "wP") "wB" else "bB"
                    val copy = copyGrid(grid)
                    copy[r][c] = replacement
                    val check = validateBoard(copy, sideToMove, orientation = orientation)
                    suggestions.add(
                        SuggestedRepair(
                            square = sq,
                            row = r,
                            col = c,
                            fromPiece = piece,
                            toPiece = replacement,
                            reason = "Pawn cannot stand on rank $rank; likely a Bishop.",
                            repairedFen = check.fen
                        )
                    )
                }
            }
        }

        // Strategy 2: Missing White or Black King -> promote Queen/tall piece or home king square
        if (validation.whiteKingCount == 0) {
            val candidate = findBestKingRepairSquare(grid, isWhite = true, uncertainSquares, orientation)
            if (candidate != null) {
                val (r, c) = candidate
                val sq = gridToSquare(r, c, orientation)
                val copy = copyGrid(grid)
                val prev = copy[r][c]
                copy[r][c] = "wK"
                val check = validateBoard(copy, sideToMove, orientation = orientation)
                suggestions.add(
                    SuggestedRepair(sq, r, c, prev, "wK", "Restore missing White King on $sq.", check.fen)
                )
            }
        }
        if (validation.blackKingCount == 0) {
            val candidate = findBestKingRepairSquare(grid, isWhite = false, uncertainSquares, orientation)
            if (candidate != null) {
                val (r, c) = candidate
                val sq = gridToSquare(r, c, orientation)
                val copy = copyGrid(grid)
                val prev = copy[r][c]
                copy[r][c] = "bK"
                val check = validateBoard(copy, sideToMove, orientation = orientation)
                suggestions.add(
                    SuggestedRepair(sq, r, c, prev, "bK", "Restore missing Black King on $sq.", check.fen)
                )
            }
        }
        return suggestions
    }

    private fun findBestKingRepairSquare(
        grid: Array<Array<String>>,
        isWhite: Boolean,
        uncertainSquares: List<String>,
        orientation: DiagramOrientation
    ): Pair<Int, Int>? {
        val targetQueen = if (isWhite) "wQ" else "bQ"
        val uncertainSet = uncertainSquares.toSet()
        for (r in 0..7) {
            for (c in 0..7) {
                val sq = gridToSquare(r, c, orientation)
                if (grid[r][c] == targetQueen && sq in uncertainSet) return r to c
            }
        }
        for (r in 0..7) {
            for (c in 0..7) {
                if (grid[r][c] == targetQueen) return r to c
            }
        }
        val homeSq = if (isWhite) "g1" else "g8"
        val (hr, hc) = squareToGrid(homeSq, orientation)
        if (grid[hr][hc] == "empty") return hr to hc
        val eSq = if (isWhite) "e1" else "e8"
        return squareToGrid(eSq, orientation)
    }

    fun copyGrid(grid: Array<Array<String>>): Array<Array<String>> =
        Array(8) { r -> Array(8) { c -> grid[r][c] } }
}
