package com.example.scanner

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

object ScannerNcc {

    /**
     * Faithful port of computeNcc from scanner/ncc.ts.
     * Computes zero-mean, unit-variance Normalized Cross-Correlation in [-1.0, 1.0].
     */
    fun computeNcc(a: FloatArray, b: FloatArray): Float {
        val n = min(a.size, b.size)
        if (n == 0) return 0f

        var sumA = 0.0
        var sumB = 0.0
        for (i in 0 until n) {
            sumA += a[i]
            sumB += b[i]
        }
        val meanA = sumA / n
        val meanB = sumB / n

        var numerator = 0.0
        var varA = 0.0
        var varB = 0.0
        for (i in 0 until n) {
            val diffA = a[i] - meanA
            val diffB = b[i] - meanB
            numerator += diffA * diffB
            varA += diffA * diffA
            varB += diffB * diffB
        }

        // Near-uniform empty squares (light or smoothed dark/hatched, stdDev < 0.024 -> var < 0.60;
        // every chess piece has var > 10.0) should match empty templates by mean luminance rather than
        // amplifying sub-pixel hatch phase or JPEG quantization noise.
        if (varA < 0.60 || varB < 0.60) {
            if (varA < 0.60 && varB < 0.60) {
                val meanDiff = kotlin.math.abs(meanA - meanB)
                return if (meanDiff < 0.12) 0.96f else 0f
            }
            return 0f
        }

        val denominator = sqrt(varA * varB)
        if (denominator < 1e-7) return 0f
        return max(-1.0, min(1.0, numerator / denominator)).toFloat()
    }

    /**
     * Faithful port of matchCellWithTemplates from scanner/ncc.ts with exact thresholds:
     * - score >= 0.85 -> MATCH
     * - 0.70 <= score < 0.85 -> CONFIRM (amber)
     * - score < 0.70 -> FALLBACK
     */
    fun matchCellWithTemplates(
        cellPixels: FloatArray,
        squareColor: SquareShade,
        templates: Map<String, PieceTemplate>
    ): NccMatchResult {
        var bestScore = -1.0f
        var bestPiece = "empty"

        for (piece in PieceCodes.ALL) {
            val key = "${piece}_${squareColor.raw}"
            val tpl = templates[key] ?: continue
            if (tpl.pixels.size != cellPixels.size) continue
            val ncc = computeNcc(cellPixels, tpl.pixels)
            if (ncc > bestScore) {
                bestScore = ncc
                bestPiece = piece
            }
        }

        val status = when {
            bestScore >= 0.85f -> NccStatus.MATCH
            bestScore >= 0.70f -> NccStatus.CONFIRM
            else -> NccStatus.FALLBACK
        }

        return NccMatchResult(
            pieceCode = bestPiece,
            score = max(0f, bestScore),
            status = status
        )
    }

    /**
     * Faithful port of calculateTemplateCoverage from scanner/ncc.ts (26 total templates).
     */
    fun calculateTemplateCoverage(templates: Map<String, PieceTemplate>): TemplateCoverage {
        var totalLearned = 0
        val missing = ArrayList<String>()
        val shades = listOf(SquareShade.LIGHT, SquareShade.DARK)
        val totalRequired = PieceCodes.ALL.size * shades.size // 26

        for (p in PieceCodes.ALL) {
            for (s in shades) {
                val key = "${p}_${s.raw}"
                val tpl = templates[key]
                if (tpl != null && tpl.sampleCount > 0) {
                    totalLearned++
                } else {
                    missing.add(key)
                }
            }
        }
        val pct = ((totalLearned.toFloat() / totalRequired) * 100f).roundToInt()
        return TemplateCoverage(
            totalLearned = totalLearned,
            totalRequired = totalRequired,
            percentage = pct,
            missingTemplates = missing
        )
    }

    /**
     * Running average update of 32x32 grayscale templates from a confirmed diagram scan.
     */
    fun mergeRunningAverage(existing: PieceTemplate?, newPixels: FloatArray, pieceCode: String, shade: SquareShade): PieceTemplate {
        if (existing == null || existing.sampleCount <= 0 || existing.pixels.size != newPixels.size) {
            return PieceTemplate(
                pieceCode = pieceCode,
                squareColor = shade,
                pixels = newPixels.copyOf(),
                sampleCount = 1
            )
        }
        val count = existing.sampleCount
        val nextCount = count + 1
        val merged = FloatArray(newPixels.size) { i ->
            (existing.pixels[i] * count + newPixels[i]) / nextCount
        }
        return PieceTemplate(
            pieceCode = pieceCode,
            squareColor = shade,
            pixels = merged,
            sampleCount = nextCount
        )
    }
}
