package com.example.exnessgoldbot

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.*

data class SignalResult(
    val signal: String,
    val trend: String,
    val riskAmount: Double,
    val estimatedLots: Double,
    val sl: Double,
    val tp: Double,
    val reason: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhoneOnlyScreen(this) }
    }
}

private fun d(s: String): Double = s.replace(",", ".").toDoubleOrNull() ?: 0.0
private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)

private fun calculate(
    balance: Double, price: Double, ema20: Double, ema50: Double,
    rsi: Double, slDistance: Double, tpDistance: Double, riskPct: Double
): SignalResult {
    val riskAmount = balance * riskPct / 100.0
    val lots = if (slDistance > 0) riskAmount / (slDistance * 100.0) else 0.0
    val trend = when {
        ema20 > ema50 -> "BULLISH"
        ema20 < ema50 -> "BEARISH"
        else -> "NEUTRAL"
    }
    val signal = when {
        trend == "BULLISH" && rsi in 50.0..70.0 -> "BUY SETUP"
        trend == "BEARISH" && rsi in 30.0..50.0 -> "SELL SETUP"
        else -> "WAIT"
    }
    val sl = when {
        signal.startsWith("BUY") -> price - slDistance
        signal.startsWith("SELL") -> price + slDistance
        else -> price
    }
    val tp = when {
        signal.startsWith("BUY") -> price + tpDistance
        signal.startsWith("SELL") -> price - tpDistance
        else -> price
    }
    val reason = "EMA20=${fmt(ema20)}, EMA50=${fmt(ema50)}, RSI14=${fmt(rsi)}"
    return SignalResult(signal, trend, riskAmount, lots, sl, tp, reason)
}

@Composable
fun PhoneOnlyScreen(context: Context) {
    var balance by remember { mutableStateOf("1000") }
    var price by remember { mutableStateOf("2650") }
    var ema20 by remember { mutableStateOf("2650") }
    var ema50 by remember { mutableStateOf("2645") }
    var rsi by remember { mutableStateOf("55") }
    var slDistance by remember { mutableStateOf("5") }
    var tpDistance by remember { mutableStateOf("10") }
    var riskPct by remember { mutableStateOf("0.25") }
    var result by remember { mutableStateOf<SignalResult?>(null) }
    var journal by remember { mutableStateOf(listOf<String>()) }

    fun openExness() {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.exness.com/exness-trade-app/"))
        context.startActivity(intent)
    }

    fun addJournal() {
        val r = result ?: return
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        journal = (listOf("$now • ${r.signal} • SL ${fmt(r.sl)} • TP ${fmt(r.tp)} • ~${fmt(r.estimatedLots)} lots") + journal).take(30)
    }

    MaterialTheme {
        Scaffold { pad ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Exness Gold Bot", style = MaterialTheme.typography.headlineMedium)
                    Text("PHONE-ONLY • XAUUSD", style = MaterialTheme.typography.labelLarge)
                    Text("No VPS • No PC • No MT5 desktop")
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("1. Market & account inputs", style = MaterialTheme.typography.titleMedium)
                            NumField("Account balance (USD)", balance) { balance = it }
                            NumField("XAUUSD price", price) { price = it }
                            NumField("EMA 20", ema20) { ema20 = it }
                            NumField("EMA 50", ema50) { ema50 = it }
                            NumField("RSI 14", rsi) { rsi = it }
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("2. Risk settings", style = MaterialTheme.typography.titleMedium)
                            NumField("Stop-loss distance ($)", slDistance) { slDistance = it }
                            NumField("Take-profit distance ($)", tpDistance) { tpDistance = it }
                            NumField("Risk per trade (%)", riskPct) { riskPct = it }
                            Text("Default risk is 0.25%. Verify contract size and tick value in your Exness account before trading.")
                        }
                    }
                }
                item {
                    Button(
                        onClick = {
                            result = calculate(d(balance), d(price), d(ema20), d(ema50), d(rsi), d(slDistance), d(tpDistance), d(riskPct))
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("CALCULATE SIGNAL") }
                }
                item {
                    result?.let { r ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(r.signal, style = MaterialTheme.typography.headlineSmall)
                                Text("Trend: ${r.trend}")
                                Text("Risk amount: $${fmt(r.riskAmount)}")
                                Text("Estimated position: ${fmt(r.estimatedLots)} lots")
                                Text("SL: ${fmt(r.sl)}")
                                Text("TP: ${fmt(r.tp)}")
                                Text(r.reason)
                                Text("This is a calculation, not a broker order or financial guarantee.")
                            }
                        }
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { openExness() }, Modifier.weight(1f)) { Text("OPEN EXNESS") }
                        OutlinedButton(onClick = { addJournal() }, Modifier.weight(1f)) { Text("JOURNAL") }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Phone-only architecture", style = MaterialTheme.typography.titleMedium)
                            Text("APK → local strategy/risk engine → official Exness/MT5 mobile app for manual execution")
                            Text("The app does not store or request your Exness/MT5 master password.")
                        }
                    }
                }
                item { Text("Trade journal", style = MaterialTheme.typography.titleMedium) }
                items(journal) { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
private fun NumField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true
    )
}
