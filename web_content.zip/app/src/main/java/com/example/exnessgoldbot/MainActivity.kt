package com.example.exnessgoldbot

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ExnessGoldBotScreen(this) }
    }
}

private fun request(base: String, token: String, path: String, method: String = "GET", body: String? = null): String {
    val clean = base.trimEnd('/')
    val conn = URL(clean + path).openConnection() as HttpURLConnection
    conn.requestMethod = method
    conn.connectTimeout = 7000
    conn.readTimeout = 7000
    conn.setRequestProperty("X-API-Token", token)
    conn.setRequestProperty("Content-Type", "application/json")
    if (body != null) {
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toByteArray()) }
    }
    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
    return stream?.bufferedReader()?.use { it.readText() } ?: "HTTP ${conn.responseCode}"
}

@Composable
fun ExnessGoldBotScreen(context: Context) {
    val prefs = remember { context.getSharedPreferences("bridge", Context.MODE_PRIVATE) }
    var bridgeUrl by remember { mutableStateOf(prefs.getString("url", "https://YOUR-VPS-DOMAIN") ?: "") }
    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    var status by remember { mutableStateOf("Bridge not checked") }
    var mt5Status by remember { mutableStateOf("MT5: unknown") }
    val scope = rememberCoroutineScope()

    fun save() = prefs.edit().putString("url", bridgeUrl).putString("token", token).apply()
    fun call(path: String, method: String = "GET", body: String? = null) {
        save()
        scope.launch {
            status = "Connecting…"
            try {
                val text = withContext(Dispatchers.IO) { request(bridgeUrl, token, path, method, body) }
                val json = runCatching { JSONObject(text) }.getOrNull()
                if (path == "/status" && json != null) {
                    mt5Status = "MT5: ${if (json.optBoolean("connected")) "CONNECTED" else "OFFLINE"} • Equity ${json.optDouble("equity", 0.0)}"
                }
                status = text.take(180)
            } catch (e: Exception) { status = "Error: ${e.message}" }
        }
    }

    MaterialTheme {
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Exness Gold Bot", style = MaterialTheme.typography.headlineMedium)
            Text("Android → VPS Bridge → MT5 EA")
            OutlinedTextField(bridgeUrl, { bridgeUrl = it }, label = { Text("VPS HTTPS URL") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(token, { token = it }, label = { Text("Bridge API Token") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Bridge: $status")
                Text(mt5Status)
                Text("Symbol: XAUUSD")
                Text("Risk: 0.25% • Daily limit: 1% • Max trades/day: 3")
                Text("Demo-only EA execution by default")
            }}
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button({ call("/health") }, Modifier.weight(1f)) { Text("TEST") }
                Button({ call("/status") }, Modifier.weight(1f)) { Text("STATUS") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button({ call("/command", "POST", "{\"action\":\"START\",\"symbol\":\"XAUUSD\",\"risk_percent\":0.25,\"daily_loss_limit\":1.0,\"max_trades_per_day\":3}") }, Modifier.weight(1f)) { Text("START") }
                Button({ call("/command", "POST", "{\"action\":\"STOP\",\"symbol\":\"XAUUSD\"}") }, Modifier.weight(1f)) { Text("STOP") }
            }
            Button({ call("/command", "POST", "{\"action\":\"CLOSE_ALL\",\"symbol\":\"XAUUSD\"}") }, Modifier.fillMaxWidth()) { Text("QUEUE CLOSE ALL") }
            Text("Security: broker credentials stay on the VPS/MT5 side; the APK sends only bridge commands.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
