package com.example.generator

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.EnumMap

data class QrColorTheme(
    val id: String,
    val name: String,
    val foregroundColor: Int,
    val backgroundColor: Int
)

object QrGenerator {

    val THEMES = listOf(
        QrColorTheme("classic_dark", "Obsidian Dark", Color.parseColor("#00E5FF"), Color.parseColor("#080C14")),
        QrColorTheme("electric_violet", "Electric Violet", Color.parseColor("#A855F7"), Color.parseColor("#0D0B18")),
        QrColorTheme("emerald_mint", "Emerald Mint", Color.parseColor("#10B981"), Color.parseColor("#061712")),
        QrColorTheme("sunset_amber", "Sunset Amber", Color.parseColor("#F59E0B"), Color.parseColor("#1C1304")),
        QrColorTheme("monochrome_dark", "Monochrome", Color.parseColor("#F8FAFC"), Color.parseColor("#0F172A")),
        QrColorTheme("classic_light", "Clean Paper", Color.parseColor("#0F172A"), Color.parseColor("#FFFFFF"))
    )

    fun generateBitmap(
        content: String,
        size: Int = 600,
        foregroundColor: Int = Color.BLACK,
        backgroundColor: Int = Color.WHITE
    ): Bitmap? {
        if (content.isBlank()) return null

        return try {
            val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java).apply {
                put(EncodeHintType.CHARACTER_SET, "UTF-8")
                put(EncodeHintType.MARGIN, 2)
                put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H)
            }

            val writer = QRCodeWriter()
            val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, size, size, hints)
            val width = bitMatrix.width
            val height = bitMatrix.height
            val pixels = IntArray(width * height)

            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (bitMatrix.get(x, y)) foregroundColor else backgroundColor
                }
            }

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
