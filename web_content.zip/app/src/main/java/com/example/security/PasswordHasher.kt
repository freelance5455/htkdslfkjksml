package com.example.security

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Secure cryptographic helper for password and recovery-code hashing using PBKDF2WithHmacSHA256
 * with cryptographically secure random salts.
 */
object PasswordHasher {

    private const val ITERATION_COUNT = 10_000
    private const val KEY_LENGTH = 256
    private const val SALT_BYTE_SIZE = 16
    private const val ALGORITHM = "PBKDF2WithHmacSHA256"

    private val secureRandom = SecureRandom()
    private val RECOVERY_CHARS = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ".toCharArray()

    fun generateSalt(): String {
        val salt = ByteArray(SALT_BYTE_SIZE)
        secureRandom.nextBytes(salt)
        return Base64.encodeToString(salt, Base64.NO_WRAP)
    }

    fun hash(text: String, saltBase64: String): String {
        val salt = Base64.decode(saltBase64, Base64.NO_WRAP)
        val spec = PBEKeySpec(text.toCharArray(), salt, ITERATION_COUNT, KEY_LENGTH)
        val factory = SecretKeyFactory.getInstance(ALGORITHM)
        val hash = factory.generateSecret(spec).encoded
        return Base64.encodeToString(hash, Base64.NO_WRAP)
    }

    fun verify(text: String, saltBase64: String, expectedHashBase64: String): Boolean {
        val calculatedHash = hash(text, saltBase64)
        return MessageDigest.isEqual(
            calculatedHash.toByteArray(Charsets.UTF_8),
            expectedHashBase64.toByteArray(Charsets.UTF_8)
        )
    }

    /**
     * Generates a 16-character grouped recovery code formatted as XXXX-XXXX-XXXX-XXXX
     * using unambiguous uppercase alphanumeric characters.
     */
    fun generateRecoveryCode(): String {
        val builder = StringBuilder()
        for (i in 0 until 16) {
            val idx = secureRandom.nextInt(RECOVERY_CHARS.size)
            builder.append(RECOVERY_CHARS[idx])
            if (i % 4 == 3 && i != 15) {
                builder.append('-')
            }
        }
        return builder.toString()
    }

    /**
     * Normalizes user-entered recovery code by removing hyphens/spaces and converting to uppercase.
     */
    fun normalizeRecoveryCode(raw: String): String {
        return raw.replace("-", "").replace(" ", "").trim().uppercase()
    }

    /**
     * Formats normalized string into XXXX-XXXX-XXXX-XXXX
     */
    fun formatNormalizedCode(normalized: String): String {
        return normalized.chunked(4).joinToString("-")
    }
}
