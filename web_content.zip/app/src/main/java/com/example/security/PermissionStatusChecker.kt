package com.example.security

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import com.example.R
import com.example.admin.AntiTheftDeviceAdminReceiver
import com.example.service.AntiTheftAccessibilityService

data class SystemPermissionsState(
    val accessibilityEnabled: Boolean = false,
    val deviceAdminEnabled: Boolean = false,
    val overlayEnabled: Boolean = false,
) {
    val grantedCount: Int
        get() = listOf(accessibilityEnabled, deviceAdminEnabled, overlayEnabled).count { it }

    val allGranted: Boolean
        get() = accessibilityEnabled && deviceAdminEnabled && overlayEnabled
}

object PermissionStatusChecker {

    fun getPermissionsState(context: Context): SystemPermissionsState = SystemPermissionsState(
        accessibilityEnabled = isAccessibilityEnabled(context),
        deviceAdminEnabled = isDeviceAdminActive(context),
        overlayEnabled = isOverlayPermissionGranted(context),
    )

    fun isAccessibilityEnabled(context: Context): Boolean {
        val expectedComponent = ComponentName(context, AntiTheftAccessibilityService::class.java)
        val accessibilityManager =
            context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        val enabledServices = accessibilityManager
            ?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .orEmpty()

        val matchedInManager = enabledServices.any { info ->
            val serviceInfo = info.resolveInfo?.serviceInfo
            serviceInfo?.packageName == context.packageName &&
                serviceInfo.name == AntiTheftAccessibilityService::class.java.name
        }
        if (matchedInManager) return true

        val enabledSetting = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false

        val expectedFlat = expectedComponent.flattenToString()
        val expectedShort = expectedComponent.flattenToShortString()
        return enabledSetting.split(':').any { entry ->
            entry.equals(expectedFlat, ignoreCase = true) ||
                entry.equals(expectedShort, ignoreCase = true)
        }
    }

    fun isDeviceAdminActive(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
            ?: return false
        val component = ComponentName(context, AntiTheftDeviceAdminReceiver::class.java)
        return dpm.isAdminActive(component)
    }

    fun isOverlayPermissionGranted(context: Context): Boolean {
        return Settings.canDrawOverlays(context)
    }

    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        launchSafely(context, intent)
    }

    fun buildDeviceAdminIntent(context: Context): Intent {
        val component = ComponentName(context, AntiTheftDeviceAdminReceiver::class.java)
        return Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                context.getString(R.string.device_admin_explanation),
            )
        }
    }

    fun openOverlaySettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}"),
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        launchSafely(context, intent)
    }

    fun openAppDetailsSettings(context: Context) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${context.packageName}"),
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        launchSafely(context, intent)
    }

    private fun launchSafely(context: Context, intent: Intent) {
        runCatching {
            context.startActivity(intent)
        }.onFailure {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(fallback) }
        }
    }
}
