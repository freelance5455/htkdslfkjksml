package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "loans")
data class LoanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val lenderName: String,
    val description: String,
    val amount: Double,
    val date: String, // yyyy-MM-dd
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "loan_repayments")
data class LoanRepaymentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanId: Long? = null,
    val lenderName: String,
    val amount: Double,
    val description: String,
    val date: String, // yyyy-MM-dd
    val timestamp: Long = System.currentTimeMillis()
)
