package com.example.data.model

data class Question(
  val id: String,
  val subject: Subject,
  val topicId: String,
  val topicTitle: String,
  val questionText: String,
  val passageOrPremise: String? = null,
  val options: List<String>,
  val correctOptionIndex: Int,
  val stepByStepSolution: String,
  val dopingReflexTip: String,
  val trapExplanation: String,
  val difficulty: String = "Orta",
  val isSavedInErrorNotebook: Boolean = false,
  val isFavorite: Boolean = false
)
