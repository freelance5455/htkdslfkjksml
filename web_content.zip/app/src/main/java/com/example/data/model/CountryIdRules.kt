package com.example.data.model

enum class CountryIdProfile(
    val isoCode: String,
    val countryName: String,
    val dialCode: String,
    val idTypeName: String,
    val minLength: Int,
    val maxLength: Int,
    val numericOnly: Boolean,
    val formatHint: String
) {
    ZA(
        isoCode = "ZA",
        countryName = "South Africa",
        dialCode = "+27",
        idTypeName = "SA Smart ID / Birth ID (13 digits)",
        minLength = 13,
        maxLength = 13,
        numericOnly = true,
        formatHint = "13 digits (e.g. 1005145001081)"
    ),
    US(
        isoCode = "US",
        countryName = "United States",
        dialCode = "+1",
        idTypeName = "State / Student ID (9 digits)",
        minLength = 9,
        maxLength = 9,
        numericOnly = true,
        formatHint = "9 digits (e.g. 123456789)"
    ),
    UK(
        isoCode = "UK",
        countryName = "United Kingdom",
        dialCode = "+44",
        idTypeName = "Citizen / Student ID (9 chars)",
        minLength = 9,
        maxLength = 9,
        numericOnly = false,
        formatHint = "9 alphanumeric chars (e.g. UK984210A)"
    ),
    NG(
        isoCode = "NG",
        countryName = "Nigeria",
        dialCode = "+234",
        idTypeName = "National NIN (11 digits)",
        minLength = 11,
        maxLength = 11,
        numericOnly = true,
        formatHint = "11 digits (e.g. 12345678901)"
    ),
    KE(
        isoCode = "KE",
        countryName = "Kenya",
        dialCode = "+254",
        idTypeName = "National / Birth ID (8 digits)",
        minLength = 8,
        maxLength = 8,
        numericOnly = true,
        formatHint = "8 digits (e.g. 34567890)"
    ),
    IN(
        isoCode = "IN",
        countryName = "India",
        dialCode = "+91",
        idTypeName = "Aadhaar / Student ID (12 digits)",
        minLength = 12,
        maxLength = 12,
        numericOnly = true,
        formatHint = "12 digits (e.g. 123456789012)"
    ),
    BR(
        isoCode = "BR",
        countryName = "Brazil",
        dialCode = "+55",
        idTypeName = "CPF (11 digits)",
        minLength = 11,
        maxLength = 11,
        numericOnly = true,
        formatHint = "11 digits (e.g. 12345678901)"
    ),
    AU(
        isoCode = "AU",
        countryName = "Australia",
        dialCode = "+61",
        idTypeName = "Gov / Student ID (9-10 digits)",
        minLength = 9,
        maxLength = 10,
        numericOnly = true,
        formatHint = "9 or 10 digits"
    ),
    OTHER(
        isoCode = "GLOBAL",
        countryName = "Other Country",
        dialCode = "+",
        idTypeName = "National / Student ID (6-16 chars)",
        minLength = 6,
        maxLength = 16,
        numericOnly = false,
        formatHint = "6 to 16 characters"
    );

    fun validateId(raw: String): String? {
        val cleaned = raw.trim().replace(" ", "").replace("-", "")
        if (cleaned.isEmpty()) return "ID number is required for ${countryName}."
        if (numericOnly && !cleaned.all { it.isDigit() }) {
            return "${countryName} ${idTypeName} must contain numbers only."
        }
        if (cleaned.length < minLength || cleaned.length > maxLength) {
            return if (minLength == maxLength) {
                "${countryName} ID must be exactly $minLength characters (currently ${cleaned.length})."
            } else {
                "${countryName} ID must be $minLength-$maxLength characters (currently ${cleaned.length})."
            }
        }
        if (this == ZA) {
            val month = cleaned.substring(2, 4).toIntOrNull() ?: 0
            val day = cleaned.substring(4, 6).toIntOrNull() ?: 0
            if (month !in 1..12 || day !in 1..31) {
                return "SA 13-digit ID must start with a valid YYMMDD birth date."
            }
        }
        return null
    }

    companion object {
        fun fromIso(code: String): CountryIdProfile =
            entries.firstOrNull { it.isoCode.equals(code, ignoreCase = true) } ?: ZA

        fun inferFromLocation(location: String): CountryIdProfile {
            val l = location.lowercase()
            return when {
                "south africa" in l || "johannesburg" in l || "cape town" in l || "durban" in l ||
                    "pretoria" in l || "gauteng" in l || "soweto" in l || "polokwane" in l || "za" in l -> ZA
                "united states" in l || "usa" in l || "new york" in l || "california" in l -> US
                "united kingdom" in l || "london" in l || "england" in l || "uk" in l -> UK
                "nigeria" in l || "lagos" in l || "abuja" in l -> NG
                "kenya" in l || "nairobi" in l || "mombasa" in l -> KE
                "india" in l || "delhi" in l || "mumbai" in l -> IN
                "brazil" in l || "brasil" in l || "sao paulo" in l -> BR
                "australia" in l || "sydney" in l || "melbourne" in l -> AU
                else -> ZA
            }
        }
    }
}
