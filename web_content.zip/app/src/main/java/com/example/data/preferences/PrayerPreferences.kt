package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.PrayerOffsets
import com.example.data.model.PrayerType

enum class AppThemeMode {
    SYSTEM, DARK, LIGHT
}

class PrayerPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("prayer_times_prefs", Context.MODE_PRIVATE)

    var selectedCity: String
        get() = prefs.getString(KEY_CITY, "Oran") ?: "Oran"
        set(value) = prefs.edit().putString(KEY_CITY, value).apply()

    var isUsingGps: Boolean
        get() = prefs.getBoolean(KEY_USE_GPS, false)
        set(value) = prefs.edit().putBoolean(KEY_USE_GPS, value).apply()

    var gpsLatitude: Double
        get() = prefs.getFloat(KEY_GPS_LAT, 35.6976f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_GPS_LAT, value.toFloat()).apply()

    var gpsLongitude: Double
        get() = prefs.getFloat(KEY_GPS_LON, -0.6337f).toDouble()
        set(value) = prefs.edit().putFloat(KEY_GPS_LON, value.toFloat()).apply()

    var gpsCityName: String
        get() = prefs.getString(KEY_GPS_CITY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GPS_CITY, value).apply()

    var calculationMethodId: Int
        get() = prefs.getInt(KEY_CALC_METHOD, 3) // Algerian method 3 default
        set(value) = prefs.edit().putInt(KEY_CALC_METHOD, value).apply()

    var themeMode: AppThemeMode
        get() {
            val name = prefs.getString(KEY_THEME_MODE, AppThemeMode.DARK.name) ?: AppThemeMode.DARK.name
            return try {
                AppThemeMode.valueOf(name)
            } catch (e: Exception) {
                AppThemeMode.DARK
            }
        }
        set(value) = prefs.edit().putString(KEY_THEME_MODE, value.name).apply()

    var adhanAlertTypeKey: String
        get() = prefs.getString(KEY_ADHAN_ALERT, "full-afasy") ?: "full-afasy"
        set(value) = prefs.edit().putString(KEY_ADHAN_ALERT, value).apply()

    var reminderMinutes: Int
        get() = prefs.getInt(KEY_REMINDER_MINUTES, 0)
        set(value) = prefs.edit().putInt(KEY_REMINDER_MINUTES, value).apply()

    var isAdhanNotificationEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATION_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFICATION_ENABLED, value).apply()

    fun getOffsets(): PrayerOffsets {
        return PrayerOffsets(
            fajr = prefs.getInt("offset_Fajr", 0),
            sunrise = prefs.getInt("offset_Sunrise", 0),
            dhuhr = prefs.getInt("offset_Dhuhr", 0),
            asr = prefs.getInt("offset_Asr", 0),
            maghrib = prefs.getInt("offset_Maghrib", 0),
            isha = prefs.getInt("offset_Isha", 0)
        )
    }

    fun saveOffset(type: PrayerType, minutes: Int) {
        prefs.edit().putInt("offset_${type.key}", minutes).apply()
    }

    companion object {
        private const val KEY_CITY = "pref_selected_city"
        private const val KEY_USE_GPS = "pref_use_gps"
        private const val KEY_GPS_LAT = "pref_gps_lat"
        private const val KEY_GPS_LON = "pref_gps_lon"
        private const val KEY_GPS_CITY = "pref_gps_city"
        private const val KEY_CALC_METHOD = "pref_calc_method"
        private const val KEY_THEME_MODE = "pref_theme_mode"
        private const val KEY_ADHAN_ALERT = "pref_adhan_alert"
        private const val KEY_REMINDER_MINUTES = "pref_reminder_minutes"
        private const val KEY_NOTIFICATION_ENABLED = "pref_notification_enabled"
    }
}
