package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ThreadEntity::class, MessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class LuminaryDatabase : RoomDatabase() {
    abstract fun luminaryDao(): LuminaryDao

    companion object {
        @Volatile
        private var INSTANCE: LuminaryDatabase? = null

        fun getInstance(context: Context): LuminaryDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LuminaryDatabase::class.java,
                    "luminary_qna.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
