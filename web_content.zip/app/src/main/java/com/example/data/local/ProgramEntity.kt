package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "programs")
data class ProgramEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val unit: String,
    val date: String,
    val time: String = "",
    val location: String = "",
    val description: String = "",
    val photoUri: String = "",
    val videoUri: String = "",
    val status: String = "আসন্ন", // "আসন্ন" (Upcoming), "চলমান" (Ongoing), "সম্পন্ন" (Completed)
    val authorName: String = "উপজেলা শাখা",
    val createdAt: Long = System.currentTimeMillis()
)
