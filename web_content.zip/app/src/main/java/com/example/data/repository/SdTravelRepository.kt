package com.example.data.repository

import com.example.data.local.BookingEntity
import com.example.data.local.ClientEntity
import com.example.data.local.DocumentEntity
import com.example.data.local.PaymentEntity
import com.example.data.local.SdTravelDao
import com.example.data.model.BookingStatus
import com.example.data.model.ClientWithBookings
import com.example.data.model.DashboardStats
import com.example.data.model.PendingAttachment
import com.example.data.model.ReportPreview
import com.example.data.model.ReportType
import com.example.data.model.SearchFilter
import com.example.data.storage.DocumentStorage
import com.example.utils.CurrencyFormatters
import com.example.utils.DateFormatters
import kotlinx.coroutines.flow.Flow
import java.io.File

sealed class SaveResult {
    data class Success(val clientId: Long, val bookingId: Long) : SaveResult()
    data class ValidationError(val message: String) : SaveResult()
}

class SdTravelRepository(
    private val dao: SdTravelDao,
    private val documentStorage: DocumentStorage,
) {
    val allClientsWithBookings: Flow<List<ClientWithBookings>> = dao.getAllClientsWithBookingsFlow()

    fun observeClientWithBookings(clientId: Long): Flow<ClientWithBookings?> =
        dao.getClientWithBookingsFlow(clientId)

    suspend fun isClientCodeAvailable(code: String, excludingClientId: Long? = null): Boolean {
        val trimmed = code.trim()
        if (trimmed.isEmpty()) return false
        val existing = dao.getClientByCode(trimmed) ?: return true
        return excludingClientId != null && existing.id == excludingClientId
    }

    suspend fun createNewClientAndBooking(
        clientCode: String,
        fullName: String,
        phone: String,
        whatsapp: String,
        nationalId: String,
        passportNumber: String,
        birthDate: String,
        clientNotes: String,
        booking: BookingEntity,
        depositAmount: Double,
        attachments: List<PendingAttachment>,
    ): SaveResult {
        val trimmedCode = clientCode.trim()
        if (trimmedCode.isEmpty()) {
            return SaveResult.ValidationError("يجب إدخال كود العميل يدويًا")
        }
        if (fullName.trim().isEmpty()) {
            return SaveResult.ValidationError("يجب إدخال اسم العميل بالكامل")
        }
        if (!isClientCodeAvailable(trimmedCode)) {
            return SaveResult.ValidationError("كود العميل ($trimmedCode) مسجل مسبقًا، يمنع تكرار الأكواد")
        }

        val client = ClientEntity(
            clientCode = trimmedCode,
            fullName = fullName.trim(),
            phone = phone.trim(),
            whatsapp = whatsapp.trim(),
            nationalId = nationalId.trim(),
            passportNumber = passportNumber.trim(),
            birthDate = birthDate.trim(),
            notes = clientNotes.trim(),
        )

        val (clientId, bookingId) = dao.insertClientWithBookingAndDeposit(
            client = client,
            booking = booking,
            depositAmount = depositAmount,
            depositDate = DateFormatters.todayIso(),
        )

        attachments.forEach { att ->
            val temp = File(att.tempFilePath)
            if (temp.exists()) {
                val relPath = documentStorage.saveTempFilePermanently(temp, bookingId)
                dao.insertDocument(
                    DocumentEntity(
                        bookingId = bookingId,
                        docType = att.docType,
                        title = att.title,
                        relativePath = relPath,
                    )
                )
                temp.delete()
            }
        }

        return SaveResult.Success(clientId, bookingId)
    }

    suspend fun addBookingToExistingClient(
        clientId: Long,
        booking: BookingEntity,
        depositAmount: Double,
        attachments: List<PendingAttachment>,
    ): SaveResult {
        val bookingId = dao.insertBookingWithDeposit(
            booking = booking.copy(clientId = clientId),
            depositAmount = depositAmount,
            depositDate = DateFormatters.todayIso(),
        )
        attachments.forEach { att ->
            val temp = File(att.tempFilePath)
            if (temp.exists()) {
                val relPath = documentStorage.saveTempFilePermanently(temp, bookingId)
                dao.insertDocument(
                    DocumentEntity(
                        bookingId = bookingId,
                        docType = att.docType,
                        title = att.title,
                        relativePath = relPath,
                    )
                )
                temp.delete()
            }
        }
        return SaveResult.Success(clientId, bookingId)
    }

    suspend fun updateClient(client: ClientEntity): SaveResult {
        val trimmedCode = client.clientCode.trim()
        if (trimmedCode.isEmpty()) {
            return SaveResult.ValidationError("يجب إدخال كود العميل يدويًا")
        }
        if (client.fullName.trim().isEmpty()) {
            return SaveResult.ValidationError("يجب إدخال اسم العميل بالكامل")
        }
        if (!isClientCodeAvailable(trimmedCode, excludingClientId = client.id)) {
            return SaveResult.ValidationError("كود العميل ($trimmedCode) مستخدم لعميل آخر، لا يمكن التكرار")
        }
        dao.updateClient(
            client.copy(
                clientCode = trimmedCode,
                fullName = client.fullName.trim(),
                phone = client.phone.trim(),
                whatsapp = client.whatsapp.trim(),
                nationalId = client.nationalId.trim(),
                passportNumber = client.passportNumber.trim(),
                birthDate = client.birthDate.trim(),
                notes = client.notes.trim(),
            )
        )
        return SaveResult.Success(client.id, 0L)
    }

    suspend fun updateBooking(booking: BookingEntity) = dao.updateBooking(booking)

    suspend fun deleteBooking(bookingId: Long) {
        val docs = dao.getDocumentsForBookingOnce(bookingId)
        dao.deleteBookingById(bookingId)
        docs.forEach { documentStorage.deleteFile(it.relativePath) }
        documentStorage.deleteBookingFolder(bookingId)
    }

    suspend fun deleteClient(clientId: Long) {
        val clientWithBookings = dao.getClientWithBookingsOnce(clientId)
        clientWithBookings?.bookings?.forEach { b ->
            b.documents.forEach { documentStorage.deleteFile(it.relativePath) }
            documentStorage.deleteBookingFolder(b.booking.id)
        }
        dao.deleteClientById(clientId)
    }

    suspend fun addPayment(payment: PaymentEntity) = dao.insertPayment(payment)

    suspend fun updatePayment(payment: PaymentEntity) = dao.updatePayment(payment)

    suspend fun deletePayment(paymentId: Long) = dao.deletePaymentById(paymentId)

    suspend fun addDocumentFromTempFile(
        bookingId: Long,
        docType: com.example.data.model.DocumentType,
        title: String,
        tempFile: File,
    ) {
        val relPath = documentStorage.saveTempFilePermanently(tempFile, bookingId)
        dao.insertDocument(
            DocumentEntity(
                bookingId = bookingId,
                docType = docType,
                title = title,
                relativePath = relPath,
            )
        )
        tempFile.delete()
    }

    suspend fun replaceDocumentFile(existing: DocumentEntity, newTempFile: File) {
        val oldPath = existing.relativePath
        val newRelPath = documentStorage.saveTempFilePermanently(newTempFile, existing.bookingId)
        dao.updateDocument(existing.copy(relativePath = newRelPath))
        documentStorage.deleteFile(oldPath)
        newTempFile.delete()
    }

    suspend fun deleteDocument(document: DocumentEntity) {
        dao.deleteDocumentById(document.id)
        documentStorage.deleteFile(document.relativePath)
    }

    fun computeDashboardStats(clients: List<ClientWithBookings>, todayIso: String = DateFormatters.todayIso()): DashboardStats {
        val allBookings = clients.flatMap { it.bookings }
        val upcoming = allBookings.count {
            it.booking.status != BookingStatus.CANCELLED &&
                it.booking.tripDate.isNotBlank() &&
                it.booking.tripDate >= todayIso
        }
        val totalCollected = allBookings.sumOf { it.totalPaid }
        val totalRemaining = allBookings
            .filter { it.booking.status != BookingStatus.CANCELLED }
            .sumOf { it.remainingAmount.coerceAtLeast(0.0) }

        return DashboardStats(
            totalClients = clients.size,
            totalBookings = allBookings.size,
            upcomingTrips = upcoming,
            totalCollected = totalCollected,
            totalRemaining = totalRemaining,
            confirmedCount = allBookings.count { it.booking.status == BookingStatus.CONFIRMED },
            pendingCount = allBookings.count { it.booking.status == BookingStatus.PENDING },
            cancelledCount = allBookings.count { it.booking.status == BookingStatus.CANCELLED },
        )
    }

    fun filterClients(clients: List<ClientWithBookings>, filter: SearchFilter): List<ClientWithBookings> {
        if (!filter.hasAnyCriteria) return clients

        return clients.filter { item ->
            val c = item.client
            val matchesCode = filter.clientCode.isBlank() ||
                c.clientCode.contains(filter.clientCode.trim(), ignoreCase = true)
            val matchesName = filter.fullName.isBlank() ||
                c.fullName.contains(filter.fullName.trim(), ignoreCase = true)
            val matchesPhone = filter.phone.isBlank() ||
                c.phone.contains(filter.phone.trim(), ignoreCase = true) ||
                c.whatsapp.contains(filter.phone.trim(), ignoreCase = true)
            val matchesPassport = filter.passportNumber.isBlank() ||
                c.passportNumber.contains(filter.passportNumber.trim(), ignoreCase = true)

            if (!matchesCode || !matchesName || !matchesPhone || !matchesPassport) {
                return@filter false
            }

            val needsBookingMatch = filter.exactTripDate.isNotBlank() ||
                filter.companyName.isNotBlank() ||
                filter.status != null ||
                filter.tripDateFrom.isNotBlank() ||
                filter.tripDateTo.isNotBlank()

            if (!needsBookingMatch) return@filter true

            item.bookings.any { bwd ->
                val b = bwd.booking
                val mExactDate = filter.exactTripDate.isBlank() || b.tripDate == filter.exactTripDate.trim()
                val mCompany = filter.companyName.isBlank() || b.companyName.contains(filter.companyName.trim(), ignoreCase = true)
                val mStatus = filter.status == null || b.status == filter.status
                val mFrom = filter.tripDateFrom.isBlank() || (b.tripDate.isNotBlank() && b.tripDate >= filter.tripDateFrom.trim())
                val mTo = filter.tripDateTo.isBlank() || (b.tripDate.isNotBlank() && b.tripDate <= filter.tripDateTo.trim())
                mExactDate && mCompany && mStatus && mFrom && mTo
            }
        }
    }

    fun buildReport(
        type: ReportType,
        clients: List<ClientWithBookings>,
        fromDate: String,
        toDate: String,
        todayIso: String = DateFormatters.todayIso(),
    ): ReportPreview {
        fun inDateRange(date: String): Boolean {
            if (fromDate.isNotBlank() && (date.isBlank() || date < fromDate)) return false
            if (toDate.isNotBlank() && (date.isBlank() || date > toDate)) return false
            return true
        }

        val bookingPairs = clients.flatMap { c ->
            c.bookings.map { b -> c.client to b }
        }.filter { (_, b) -> inDateRange(b.booking.tripDate) }

        return when (type) {
            ReportType.ALL_CLIENTS -> {
                val filteredClients = if (fromDate.isBlank() && toDate.isBlank()) {
                    clients
                } else {
                    clients.filter { c -> c.bookings.any { inDateRange(it.booking.tripDate) } }
                }
                val rows = filteredClients.map { item ->
                    listOf(
                        item.client.clientCode,
                        item.client.fullName,
                        item.client.phone,
                        item.client.passportNumber.ifBlank { "-" },
                        item.bookings.size.toString(),
                        CurrencyFormatters.formatMoney(item.totalPaidAcrossBookings),
                        CurrencyFormatters.formatMoney(item.totalRemainingAcrossBookings),
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("الكود", "اسم العميل", "الهاتف", "الجواز", "الحجوزات", "المدفوع", "المتبقي"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "عدد العملاء" to filteredClients.size.toString(),
                        "إجمالي المدفوع" to CurrencyFormatters.formatMoney(filteredClients.sumOf { it.totalPaidAcrossBookings }),
                        "إجمالي المتبقي" to CurrencyFormatters.formatMoney(filteredClients.sumOf { it.totalRemainingAcrossBookings }),
                    ),
                )
            }

            ReportType.ALL_BOOKINGS -> {
                val rows = bookingPairs.map { (c, b) ->
                    listOf(
                        c.clientCode,
                        c.fullName,
                        b.booking.tripDate,
                        b.booking.tripType.arabicLabel,
                        b.booking.companyName.ifBlank { "-" },
                        b.booking.status.arabicLabel,
                        CurrencyFormatters.formatMoney(b.totalDue),
                        CurrencyFormatters.formatMoney(b.totalPaid),
                        CurrencyFormatters.formatMoney(b.remainingAmount),
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("الكود", "العميل", "تاريخ الرحلة", "النوع", "الشركة", "الحالة", "الإجمالي", "المدفوع", "المتبقي"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "عدد الحجوزات" to bookingPairs.size.toString(),
                        "إجمالي العقود" to CurrencyFormatters.formatMoney(bookingPairs.sumOf { it.second.totalDue }),
                        "المحصل" to CurrencyFormatters.formatMoney(bookingPairs.sumOf { it.second.totalPaid }),
                    ),
                )
            }

            ReportType.UPCOMING_TRIPS -> {
                val upcoming = bookingPairs
                    .filter { (_, b) -> b.booking.status != BookingStatus.CANCELLED && b.booking.tripDate >= todayIso }
                    .sortedBy { it.second.booking.tripDate }
                val rows = upcoming.map { (c, b) ->
                    listOf(
                        c.clientCode,
                        c.fullName,
                        c.phone,
                        b.booking.tripDate,
                        b.booking.returnDate.ifBlank { "-" },
                        b.booking.makkahHotel.ifBlank { "-" },
                        b.booking.status.arabicLabel,
                        CurrencyFormatters.formatMoney(b.remainingAmount),
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("الكود", "العميل", "الهاتف", "السفر", "العودة", "فندق مكة", "الحالة", "المتبقي"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "الرحلات القادمة" to upcoming.size.toString(),
                        "المتبقي تحصيله" to CurrencyFormatters.formatMoney(upcoming.sumOf { it.second.remainingAmount.coerceAtLeast(0.0) }),
                    ),
                )
            }

            ReportType.BY_TRIP_DATE -> {
                val sorted = bookingPairs.sortedBy { it.second.booking.tripDate }
                val rows = sorted.map { (c, b) ->
                    listOf(
                        b.booking.tripDate,
                        b.booking.returnDate.ifBlank { "-" },
                        c.clientCode,
                        c.fullName,
                        b.booking.tripType.arabicLabel,
                        b.booking.companyName.ifBlank { "-" },
                        b.booking.status.arabicLabel,
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("تاريخ الرحلة", "العودة", "الكود", "العميل", "البرنامج", "الشركة", "الحالة"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "عدد الحجوزات" to sorted.size.toString(),
                        "تواريخ مختلفة" to sorted.map { it.second.booking.tripDate }.distinct().size.toString(),
                    ),
                )
            }

            ReportType.BY_COMPANY -> {
                val grouped = bookingPairs.groupBy { it.second.booking.companyName.ifBlank { "غير محدد" } }
                val rows = grouped.entries.sortedByDescending { it.value.size }.map { (company, list) ->
                    listOf(
                        company,
                        list.size.toString(),
                        list.count { it.second.booking.status == BookingStatus.CONFIRMED }.toString(),
                        CurrencyFormatters.formatMoney(list.sumOf { it.second.totalDue }),
                        CurrencyFormatters.formatMoney(list.sumOf { it.second.totalPaid }),
                        CurrencyFormatters.formatMoney(list.sumOf { it.second.remainingAmount.coerceAtLeast(0.0) }),
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("شركة السياحة", "الحجوزات", "المؤكدة", "الإجمالي", "المحصل", "المتبقي"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "عدد الشركات" to grouped.size.toString(),
                        "إجمالي الحجوزات" to bookingPairs.size.toString(),
                    ),
                )
            }

            ReportType.COLLECTED_AMOUNTS -> {
                val paymentRows = clients.flatMap { c ->
                    c.bookings.flatMap { b ->
                        b.payments.filter { inDateRange(it.paymentDate) }.map { p ->
                            Triple(c.client, b.booking, p)
                        }
                    }
                }.sortedByDescending { it.third.paymentDate }

                val rows = paymentRows.map { (c, b, p) ->
                    listOf(
                        p.paymentDate,
                        c.clientCode,
                        c.fullName,
                        CurrencyFormatters.formatMoney(p.amount),
                        p.paymentMethod.arabicLabel,
                        if (p.isDeposit) "مقدم" else "دفعة",
                        p.notes.ifBlank { b.companyName.ifBlank { "-" } },
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("تاريخ الدفعة", "الكود", "العميل", "المبلغ", "الطريقة", "النوع", "ملاحظات"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "عدد الدفعات" to paymentRows.size.toString(),
                        "إجمالي المحصل" to CurrencyFormatters.formatMoney(paymentRows.sumOf { it.third.amount }),
                    ),
                )
            }

            ReportType.REMAINING_AMOUNTS -> {
                val active = bookingPairs.filter { it.second.booking.status != BookingStatus.CANCELLED }
                val rows = active.map { (c, b) ->
                    listOf(
                        c.clientCode,
                        c.fullName,
                        b.booking.tripDate,
                        CurrencyFormatters.formatMoney(b.totalDue),
                        CurrencyFormatters.formatMoney(b.totalPaid),
                        CurrencyFormatters.formatMoney(b.remainingAmount),
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("الكود", "العميل", "تاريخ الرحلة", "المستحق", "المدفوع", "المتبقي"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "الحجوزات النشطة" to active.size.toString(),
                        "إجمالي المتبقي" to CurrencyFormatters.formatMoney(active.sumOf { it.second.remainingAmount.coerceAtLeast(0.0) }),
                    ),
                )
            }

            ReportType.UNPAID_CLIENTS -> {
                val unpaid = bookingPairs.filter {
                    it.second.booking.status != BookingStatus.CANCELLED && it.second.remainingAmount > 0.01
                }.sortedByDescending { it.second.remainingAmount }
                val rows = unpaid.map { (c, b) ->
                    listOf(
                        c.clientCode,
                        c.fullName,
                        c.phone,
                        b.booking.tripDate,
                        CurrencyFormatters.formatMoney(b.totalDue),
                        CurrencyFormatters.formatMoney(b.totalPaid),
                        CurrencyFormatters.formatMoney(b.remainingAmount),
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("الكود", "العميل", "الهاتف", "الرحلة", "الإجمالي", "المدفوع", "المتبقي"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "حالات لم تسدد بالكامل" to unpaid.size.toString(),
                        "إجمالي المبالغ المستحقة" to CurrencyFormatters.formatMoney(unpaid.sumOf { it.second.remainingAmount }),
                    ),
                )
            }

            ReportType.CANCELLED_BOOKINGS -> {
                val cancelled = bookingPairs.filter { it.second.booking.status == BookingStatus.CANCELLED }
                val rows = cancelled.map { (c, b) ->
                    listOf(
                        c.clientCode,
                        c.fullName,
                        c.phone,
                        b.booking.tripDate,
                        b.booking.companyName.ifBlank { "-" },
                        CurrencyFormatters.formatMoney(b.totalDue),
                        CurrencyFormatters.formatMoney(b.totalPaid),
                        b.booking.notes.ifBlank { "-" },
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("الكود", "العميل", "الهاتف", "تاريخ الرحلة", "الشركة", "قيمة الحجز", "المدفوع", "ملاحظات"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "الحجوزات الملغاة" to cancelled.size.toString(),
                        "المدفوعات المسجلة" to CurrencyFormatters.formatMoney(cancelled.sumOf { it.second.totalPaid }),
                    ),
                )
            }

            ReportType.PROFIT_VARIANCE -> {
                val active = bookingPairs.filter { it.second.booking.status != BookingStatus.CANCELLED }
                val rows = active.map { (c, b) ->
                    listOf(
                        c.clientCode,
                        c.fullName,
                        b.booking.tripDate,
                        CurrencyFormatters.formatMoney(b.totalDue),
                        CurrencyFormatters.formatMoney(b.booking.costAmount),
                        CurrencyFormatters.formatMoney(b.profitAmount),
                        CurrencyFormatters.formatMoney(b.totalPaid - b.booking.costAmount),
                    )
                }
                ReportPreview(
                    reportType = type,
                    title = type.title,
                    headers = listOf("الكود", "العميل", "الرحلة", "سعر البيع", "التكلفة", "صافي الربح", "فرق المحصل والتكلفة"),
                    rows = rows,
                    summaryMetrics = listOf(
                        "إجمالي المبيعات" to CurrencyFormatters.formatMoney(active.sumOf { it.second.totalDue }),
                        "إجمالي التكلفة" to CurrencyFormatters.formatMoney(active.sumOf { it.second.booking.costAmount }),
                        "صافي الأرباح" to CurrencyFormatters.formatMoney(active.sumOf { it.second.profitAmount }),
                    ),
                )
            }
        }
    }
}
