package com.example.data.backup

import androidx.room.withTransaction
import com.example.data.database.AppDatabase

data class RestoreSummary(
    val subjectCount: Int,
    val sessionCount: Int,
    val examCount: Int,
    val noteCount: Int,
    val profileRestored: Boolean,
    val settingsRestored: Boolean
)

sealed class RestoreResult {
    data class Success(val summary: RestoreSummary) : RestoreResult()
    data class Error(val message: String) : RestoreResult()
}

class BackupManager(
    private val database: AppDatabase
) {
    suspend fun generateBackupJson(): String {
        val subjects = database.subjectDao().getAllSubjectsOnce().map { SubjectBackupItem.fromEntity(it) }
        val sessions = database.studySessionDao().getAllSessionsOnce().map { SessionBackupItem.fromEntity(it) }
        val exams = database.examDao().getAllExamsOnce().map { ExamBackupItem.fromEntity(it) }
        val notes = database.noteDao().getAllNotesOnce().map { NoteBackupItem.fromEntity(it) }
        val profile = database.profileDao().getProfile()?.let { ProfileBackupItem.fromEntity(it) }
        val settings = database.appSettingsDao().getSettings()?.let { SettingsBackupItem.fromEntity(it) }

        val payload = BackupPayload(
            version = 1,
            exportedAt = System.currentTimeMillis(),
            appName = "Daily Study Manager",
            profile = profile,
            settings = settings,
            subjects = subjects,
            sessions = sessions,
            exams = exams,
            notes = notes
        )

        return payload.toJsonString()
    }

    suspend fun restoreFromJson(jsonString: String): RestoreResult {
        return try {
            val payload = BackupPayload.fromJsonString(jsonString)

            database.withTransaction {
                // 1. Clear existing user content in child-first foreign-key order
                database.studySessionDao().deleteAll()
                database.examDao().deleteAll()
                database.noteDao().deleteAll()
                database.subjectDao().deleteAll()

                // 2. Re-insert restored subjects (parent table)
                val subjectEntities = payload.subjects.map { it.toEntity() }
                if (subjectEntities.isNotEmpty()) {
                    database.subjectDao().insertAll(subjectEntities)
                }

                // 3. Re-insert restored child entities
                val sessionEntities = payload.sessions.map { it.toEntity() }
                if (sessionEntities.isNotEmpty()) {
                    database.studySessionDao().insertAll(sessionEntities)
                }

                val examEntities = payload.exams.map { it.toEntity() }
                if (examEntities.isNotEmpty()) {
                    database.examDao().insertAll(examEntities)
                }

                val noteEntities = payload.notes.map { it.toEntity() }
                if (noteEntities.isNotEmpty()) {
                    database.noteDao().insertAll(noteEntities)
                }

                // 4. Restore profile & app settings
                payload.profile?.let {
                    database.profileDao().insertOrUpdate(it.toEntity(id = 1))
                }

                payload.settings?.let {
                    database.appSettingsDao().insertOrUpdate(it.toEntity(id = 1))
                }
            }

            RestoreResult.Success(
                RestoreSummary(
                    subjectCount = payload.subjects.size,
                    sessionCount = payload.sessions.size,
                    examCount = payload.exams.size,
                    noteCount = payload.notes.size,
                    profileRestored = payload.profile != null,
                    settingsRestored = payload.settings != null
                )
            )
        } catch (e: Exception) {
            RestoreResult.Error(e.message ?: "Failed to parse or restore backup file")
        }
    }
}
