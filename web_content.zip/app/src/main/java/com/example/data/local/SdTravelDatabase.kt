package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        ClientEntity::class,
        BookingEntity::class,
        PaymentEntity::class,
        DocumentEntity::class,
    ],
    version = 1,
    exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class SdTravelDatabase : RoomDatabase() {
    abstract fun sdTravelDao(): SdTravelDao

    companion object {
        private const val DB_NAME = "sd_travel_umrah.db"

        @Volatile
        private var INSTANCE: SdTravelDatabase? = null

        fun getInstance(context: Context): SdTravelDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SdTravelDatabase::class.java,
                    DB_NAME,
                ).build().also { INSTANCE = it }
            }
        }
    }
}
