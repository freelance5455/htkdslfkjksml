package com.example.data

import android.content.Context
import com.example.R
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class AdminRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val adminsCollection = db.collection("admins")
    private val ownerEmail = "bhandaribimal778@gmail.com"

    suspend fun checkIsAdmin(user: FirebaseUser?): Boolean {
        if (user == null) return false
        if (user.email.equals(ownerEmail, ignoreCase = true)) {
            // Ensure owner has an admin document registered
            try {
                val doc = adminsCollection.document(user.uid).get().await()
                if (!doc.exists()) {
                    adminsCollection.document(user.uid).set(
                        mapOf(
                            "role" to "admin",
                            "email" to (user.email ?: ownerEmail),
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, adminsCollection.path)
            }
            return true
        }

        return try {
            val doc = adminsCollection.document(user.uid).get().await()
            doc.exists() && doc.getString("role") == "admin"
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, adminsCollection.document(user.uid).path)
            false
        }
    }
}
