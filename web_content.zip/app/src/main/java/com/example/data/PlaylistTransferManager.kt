package com.example.data

import android.content.Context
import android.net.Uri
import com.example.data.model.PlaylistEntity
import com.example.data.model.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

data class PlaylistImportSummary(
    val playlistName: String,
    val description: String,
    val totalSongsInFile: Int,
    val matchedSongsCount: Int,
    val missingSongTitles: List<String>,
    val createdPlaylistId: Long?
)

class PlaylistTransferManager(
    private val context: Context,
    private val repository: MusicRepository
) {
    suspend fun exportPlaylistToJson(
        playlist: PlaylistEntity,
        songs: List<SongEntity>,
        destUri: Uri
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject().apply {
                put("formatVersion", 1)
                put("app", "LocalMusicPlayer")
                put("exportedAt", System.currentTimeMillis())
                put("playlistName", playlist.name)
                put("description", playlist.description)

                val songsArray = JSONArray()
                songs.forEach { song ->
                    val songObj = JSONObject().apply {
                        put("title", song.title)
                        put("artist", song.artist)
                        put("album", song.album)
                        put("durationMs", song.durationMs)
                        put("contentHash", song.contentHash)
                        put("fileName", song.originalFileName)
                    }
                    songsArray.put(songObj)
                }
                put("songs", songsArray)
            }

            context.contentResolver.openOutputStream(destUri)?.use { output ->
                OutputStreamWriter(output, Charsets.UTF_8).use { writer ->
                    writer.write(root.toString(2))
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun inspectPlaylistJson(uri: Uri): PlaylistImportSummary = withContext(Dispatchers.IO) {
        val jsonString = readTextFromUri(uri)
        val root = JSONObject(jsonString)
        val name = root.optString("playlistName", "Imported Playlist")
        val desc = root.optString("description", "")
        val songsArray = root.optJSONArray("songs") ?: JSONArray()

        val missingSongs = mutableListOf<String>()
        var matchedCount = 0

        for (i in 0 until songsArray.length()) {
            val songObj = songsArray.getJSONObject(i)
            val hash = songObj.optString("contentHash")
            val title = songObj.optString("title")
            val artist = songObj.optString("artist")

            val found = if (hash.isNotBlank()) {
                repository.getSongByHash(hash)
            } else null

            if (found != null) {
                matchedCount++
            } else {
                missingSongs.add("$title - $artist")
            }
        }

        PlaylistImportSummary(
            playlistName = name,
            description = desc,
            totalSongsInFile = songsArray.length(),
            matchedSongsCount = matchedCount,
            missingSongTitles = missingSongs,
            createdPlaylistId = null
        )
    }

    suspend fun completePlaylistImport(uri: Uri, playlistNameOverride: String? = null): PlaylistImportSummary =
        withContext(Dispatchers.IO) {
            val jsonString = readTextFromUri(uri)
            val root = JSONObject(jsonString)
            val rawName = root.optString("playlistName", "Imported Playlist")
            val finalName = (playlistNameOverride ?: rawName).trim()
            val desc = root.optString("description", "")
            val songsArray = root.optJSONArray("songs") ?: JSONArray()

            val playlistId = repository.createPlaylist(name = finalName, description = desc)
            val matchedSongIds = mutableListOf<Long>()
            val missingSongs = mutableListOf<String>()

            for (i in 0 until songsArray.length()) {
                val songObj = songsArray.getJSONObject(i)
                val hash = songObj.optString("contentHash")
                val title = songObj.optString("title")
                val artist = songObj.optString("artist")

                val found = if (hash.isNotBlank()) {
                    repository.getSongByHash(hash)
                } else null

                if (found != null) {
                    matchedSongIds.add(found.id)
                } else {
                    missingSongs.add("$title - $artist")
                }
            }

            if (matchedSongIds.isNotEmpty()) {
                repository.addSongsToPlaylist(playlistId, matchedSongIds)
            }

            PlaylistImportSummary(
                playlistName = finalName,
                description = desc,
                totalSongsInFile = songsArray.length(),
                matchedSongsCount = matchedSongIds.size,
                missingSongTitles = missingSongs,
                createdPlaylistId = playlistId
            )
        }

    private fun readTextFromUri(uri: Uri): String {
        val stringBuilder = StringBuilder()
        context.contentResolver.openInputStream(uri)?.use { stream ->
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                var line: String? = reader.readLine()
                while (line != null) {
                    stringBuilder.append(line).append('\n')
                    line = reader.readLine()
                }
            }
        }
        return stringBuilder.toString()
    }
}
