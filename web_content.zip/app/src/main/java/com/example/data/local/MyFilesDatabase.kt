package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "trash_entries")
data class TrashEntity(
    @PrimaryKey val id: String,
    val originalName: String,
    val trashedFilePath: String,
    val originalParentPath: String,
    val sizeBytes: Long,
    val isDirectory: Boolean,
    val mimeType: String,
    val deletedAtEpochMs: Long
)

@Entity(tableName = "favorite_entries")
data class FavoriteEntity(
    @PrimaryKey val path: String,
    val name: String,
    val isDirectory: Boolean,
    val addedAtEpochMs: Long
)

@Entity(tableName = "shortcut_entries")
data class ShortcutEntity(
    @PrimaryKey val path: String,
    val label: String,
    val isDirectory: Boolean,
    val createdAtEpochMs: Long
)

@Entity(tableName = "hidden_entries")
data class HiddenPathEntity(
    @PrimaryKey val path: String,
    val hiddenAtEpochMs: Long
)

@Entity(tableName = "saf_roots")
data class SafRootEntity(
    @PrimaryKey val id: String,
    val treeUriString: String,
    val displayName: String,
    val isCloudProvider: Boolean,
    val addedAtEpochMs: Long
)

@Dao
interface FileMetadataDao {
    @Query("SELECT * FROM trash_entries ORDER BY deletedAtEpochMs DESC")
    fun observeTrash(): Flow<List<TrashEntity>>

    @Query("SELECT * FROM trash_entries")
    suspend fun getAllTrash(): List<TrashEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrash(entity: TrashEntity)

    @Query("DELETE FROM trash_entries WHERE id = :id")
    suspend fun deleteTrashById(id: String)

    @Query("DELETE FROM trash_entries")
    suspend fun clearAllTrash()

    @Query("SELECT * FROM favorite_entries ORDER BY addedAtEpochMs DESC")
    fun observeFavorites(): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(entity: FavoriteEntity)

    @Query("DELETE FROM favorite_entries WHERE path = :path")
    suspend fun removeFavorite(path: String)

    @Query("SELECT * FROM shortcut_entries ORDER BY createdAtEpochMs DESC")
    fun observeShortcuts(): Flow<List<ShortcutEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShortcut(entity: ShortcutEntity)

    @Query("DELETE FROM shortcut_entries WHERE path = :path")
    suspend fun removeShortcut(path: String)

    @Query("SELECT * FROM hidden_entries")
    fun observeHiddenPaths(): Flow<List<HiddenPathEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun markHidden(entity: HiddenPathEntity)

    @Query("DELETE FROM hidden_entries WHERE path = :path")
    suspend fun unmarkHidden(path: String)

    @Query("SELECT * FROM saf_roots ORDER BY addedAtEpochMs ASC")
    fun observeSafRoots(): Flow<List<SafRootEntity>>

    @Query("SELECT * FROM saf_roots ORDER BY addedAtEpochMs ASC")
    suspend fun getSafRootsSnapshot(): List<SafRootEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSafRoot(entity: SafRootEntity)

    @Query("DELETE FROM saf_roots WHERE id = :id")
    suspend fun deleteSafRoot(id: String)
}

@Database(
    entities = [
        TrashEntity::class,
        FavoriteEntity::class,
        ShortcutEntity::class,
        HiddenPathEntity::class,
        SafRootEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MyFilesDatabase : RoomDatabase() {
    abstract fun metadataDao(): FileMetadataDao
}
