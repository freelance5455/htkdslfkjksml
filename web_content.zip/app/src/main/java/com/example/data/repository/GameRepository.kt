package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ArkGameType
import com.example.data.model.GameCatalog
import com.example.data.model.GameRoom
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlin.random.Random

class GameRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before playing games.")

    fun observePublicLobbies(): Flow<List<GameRoom>> = flow {
        val path = "gameRooms"
        emitAll(
            db.collection("gameRooms")
                .whereEqualTo("isPrivate", false)
                .limit(30)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        GameRoom::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).filter { it.status != "finished" }
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMyGameRooms(userId: String): Flow<List<GameRoom>> = flow {
        val path = "gameRooms"
        emitAll(
            db.collection("gameRooms")
                .whereArrayContains("playerUids", userId)
                .limit(20)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        GameRoom::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeRoom(roomId: String): Flow<GameRoom?> = flow {
        val path = "gameRooms/$roomId"
        emitAll(
            db.collection("gameRooms").document(roomId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            GameRoom::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else null
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) {
                        handleFirestoreError(ex, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createGameRoom(
        host: UserProfile,
        gameType: ArkGameType,
        isPrivate: Boolean,
        groupId: String? = null
    ): Result<String> = runCatching {
        val uid = requireUserId()
        require(uid == host.userId)
        val roomCode = generateRoomCode()
        val roomRef = db.collection("gameRooms").document()
        val codeRef = db.collection("roomCodes").document(roomCode)

        val roomPayload = mutableMapOf<String, Any>(
            "hostId" to uid,
            "hostUsername" to host.username,
            "gameType" to gameType.id,
            "roomCode" to roomCode,
            "status" to "waiting",
            "isPrivate" to isPrivate,
            "playerUids" to listOf(uid),
            "readyUids" to listOf(uid),
            "playerNames" to mapOf(uid to host.username),
            "scores" to mapOf(uid to 0L),
            "currentTurnUid" to uid,
            "roundNumber" to 0L,
            "maxRounds" to gameType.maxRounds,
            "promptText" to "Lobby open — invite friends with code $roomCode",
            "votes" to emptyMap<String, String>(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!groupId.isNullOrBlank()) {
            roomPayload["groupId"] = groupId
        }

        val codePayload = mapOf(
            "hostId" to uid,
            "roomId" to roomRef.id,
            "gameType" to gameType.id,
            "createdAt" to FieldValue.serverTimestamp()
        )

        val batch = db.batch()
        batch.set(roomRef, roomPayload)
        batch.set(codeRef, codePayload)
        try {
            batch.commit().await()
            roomRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, roomRef.path)
            throw e
        }
    }

    suspend fun joinRoomByCode(code: String, player: UserProfile): Result<String> = runCatching {
        requireUserId()
        val cleanCode = code.trim().uppercase()
        require(cleanCode.length in 4..12) { "Enter a valid room code." }
        val codeRef = db.collection("roomCodes").document(cleanCode)
        try {
            val snap = codeRef.get().await()
            require(snap.exists()) { "No game room found for code $cleanCode." }
            val roomId = snap.getString("roomId") ?: error("Missing roomId")
            joinRoomById(roomId, player).getOrThrow()
            roomId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, codeRef.path)
            throw e
        }
    }

    suspend fun joinRoomById(roomId: String, player: UserProfile): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(uid == player.userId)
        val roomRef = db.collection("gameRooms").document(roomId)
        try {
            db.runTransaction { tx ->
                val snap = tx.get(roomRef)
                require(snap.exists()) { "Room not found." }
                val players = (snap.get("playerUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                if (!players.contains(uid)) {
                    require(players.size < 16) { "Room is full (max 16 players)." }
                    val names = (snap.get("playerNames") as? Map<*, *>)
                        ?.entries?.associate { it.key.toString() to it.value.toString() }
                        ?.toMutableMap() ?: mutableMapOf()
                    val scores = (snap.get("scores") as? Map<*, *>)
                        ?.entries?.associate { it.key.toString() to ((it.value as? Number)?.toLong() ?: 0L) }
                        ?.toMutableMap() ?: mutableMapOf()

                    names[uid] = player.username
                    scores[uid] = 0L

                    tx.update(
                        roomRef,
                        mapOf(
                            "playerUids" to players + uid,
                            "playerNames" to names,
                            "scores" to scores,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, roomRef.path)
            throw e
        }
    }

    suspend fun toggleReady(room: GameRoom): Result<Unit> = runCatching {
        val uid = requireUserId()
        val nextReady = if (room.readyUids.contains(uid)) {
            room.readyUids.filterNot { it == uid }
        } else {
            room.readyUids + uid
        }
        val roomRef = db.collection("gameRooms").document(room.id)
        try {
            roomRef.update(
                mapOf(
                    "readyUids" to nextReady,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, roomRef.path)
            throw e
        }
    }

    suspend fun startOrAdvanceRound(room: GameRoom, nextRound: Long = room.roundNumber + 1L): Result<Unit> = runCatching {
        requireUserId()
        val gameType = ArkGameType.fromId(room.gameType)
        val roomRef = db.collection("gameRooms").document(room.id)

        if (nextRound > room.maxRounds) {
            val topEntry = room.scores.maxByOrNull { it.value }
            val winnerUid = topEntry?.key ?: room.hostId
            val winnerUsername = room.playerNames[winnerUid] ?: room.hostUsername
            try {
                roomRef.update(
                    mapOf(
                        "status" to "finished",
                        "winnerUid" to winnerUid,
                        "winnerUsername" to winnerUsername,
                        "promptText" to "Match Complete! Winner: @$winnerUsername",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, roomRef.path)
                throw e
            }
            return@runCatching
        }

        val nextTurnIdx = ((nextRound - 1L).toInt().coerceAtLeast(0)) % room.playerUids.size.coerceAtLeast(1)
        val turnUid = room.playerUids.getOrElse(nextTurnIdx) { room.hostId }
        val roundIdx = (nextRound - 1L).toInt().coerceAtLeast(0)

        val updates = mutableMapOf<String, Any>(
            "status" to "playing",
            "roundNumber" to nextRound,
            "currentTurnUid" to turnUid,
            "votes" to emptyMap<String, String>(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        when (gameType) {
            ArkGameType.TRUTH_OR_DARE -> {
                val isTruth = roundIdx % 2 == 0
                val prompt = if (isTruth) {
                    "TRUTH: " + GameCatalog.truthPrompts[roundIdx % GameCatalog.truthPrompts.size]
                } else {
                    "DARE: " + GameCatalog.darePrompts[roundIdx % GameCatalog.darePrompts.size]
                }
                updates["promptText"] = prompt
            }
            ArkGameType.NEVER_HAVE_I_EVER -> {
                updates["promptText"] = GameCatalog.neverHaveIEverPrompts[roundIdx % GameCatalog.neverHaveIEverPrompts.size]
                updates["optionA"] = "I Have"
                updates["optionB"] = "Never"
            }
            ArkGameType.WOULD_YOU_RATHER -> {
                val p = GameCatalog.wouldYouRatherPrompts[roundIdx % GameCatalog.wouldYouRatherPrompts.size]
                updates["promptText"] = "Would You Rather (${p.category})"
                updates["optionA"] = p.optionA
                updates["optionB"] = p.optionB
            }
            ArkGameType.MAFIA -> {
                val roles = room.secretRoles ?: buildMap {
                    room.playerUids.forEachIndexed { idx, pid ->
                        put(pid, GameCatalog.mafiaRoles[idx % GameCatalog.mafiaRoles.size])
                    }
                }
                updates["secretRoles"] = roles
                updates["promptText"] = if (nextRound % 2L == 1L) {
                    "Night Phase (Round $nextRound): Discuss clues & suspect secretly!"
                } else {
                    "Day Vote (Round $nextRound): Vote out who you suspect is Mafia!"
                }
            }
            ArkGameType.GUESS_THE_PERSON -> {
                val target = GameCatalog.guessThePersonPool[roundIdx % GameCatalog.guessThePersonPool.size]
                updates["promptText"] = "Mystery Persona #$nextRound — Pick the matching clue!"
                updates["options"] = GameCatalog.guessThePersonPool.shuffled().take(4).let { list ->
                    if (list.contains(target)) list else list.dropLast(1) + target
                }.shuffled()
                val opts = updates["options"] as List<*>
                updates["correctIndex"] = opts.indexOf(target).toLong()
            }
            ArkGameType.QUIZ_BATTLE -> {
                val q = GameCatalog.quizQuestions[roundIdx % GameCatalog.quizQuestions.size]
                updates["promptText"] = q.prompt
                updates["options"] = q.options
                updates["correctIndex"] = q.correctIndex.toLong()
            }
            ArkGameType.EMOJI_CHALLENGE -> {
                val e = GameCatalog.emojiPuzzles[roundIdx % GameCatalog.emojiPuzzles.size]
                updates["promptText"] = "${e.emojis}  (${e.category} • ${e.difficulty})"
                updates["options"] = e.options
                updates["correctIndex"] = e.options.indexOf(e.answer).toLong()
            }
            ArkGameType.WORD_CHAIN -> {
                val starter = if (nextRound == 1L) {
                    GameCatalog.wordChainStarters.random()
                } else {
                    room.promptText.uppercase()
                }
                updates["promptText"] = starter
            }
            ArkGameType.QUICK_REACTION -> {
                updates["promptText"] = "Tap as fast as possible when the Reactor turns Emerald!"
            }
            ArkGameType.MEMORY_CHALLENGE -> {
                val seqLen = (3 + roundIdx).coerceAtMost(7)
                val sequence = (1..seqLen).map { Random.nextInt(1, 5) }.joinToString("-")
                updates["promptText"] = sequence
            }
        }

        try {
            roomRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, roomRef.path)
            throw e
        }
    }

    suspend fun submitMoveOrVote(
        room: GameRoom,
        choice: String,
        pointsEarned: Long,
        nextWordChain: String? = null
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val roomRef = db.collection("gameRooms").document(room.id)
        try {
            db.runTransaction { tx ->
                val snap = tx.get(roomRef)
                val currentVotes = (snap.get("votes") as? Map<*, *>)
                    ?.entries?.associate { it.key.toString() to it.value.toString() }
                    ?.toMutableMap() ?: mutableMapOf()
                val currentScores = (snap.get("scores") as? Map<*, *>)
                    ?.entries?.associate { it.key.toString() to ((it.value as? Number)?.toLong() ?: 0L) }
                    ?.toMutableMap() ?: mutableMapOf()

                if (!currentVotes.containsKey(uid)) {
                    currentVotes[uid] = choice.take(120)
                    currentScores[uid] = (currentScores[uid] ?: 0L) + pointsEarned.coerceIn(0L, 100L)
                }

                val updates = mutableMapOf<String, Any>(
                    "votes" to currentVotes,
                    "scores" to currentScores,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (!nextWordChain.isNullOrBlank()) {
                    updates["promptText"] = nextWordChain.trim().uppercase().take(40)
                }
                tx.update(roomRef, updates)
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, roomRef.path)
            throw e
        }
    }

    suspend fun requestRematch(room: GameRoom): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(room.hostId == uid) { "Only the host can start a rematch." }
        val roomRef = db.collection("gameRooms").document(room.id)
        try {
            roomRef.update(
                mapOf(
                    "status" to "waiting",
                    "roundNumber" to 0L,
                    "votes" to emptyMap<String, String>(),
                    "winnerUid" to "",
                    "winnerUsername" to "",
                    "promptText" to "Rematch Lobby Ready!",
                    "readyUids" to listOf(uid),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, roomRef.path)
            throw e
        }
    }

    private fun generateRoomCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return buildString(6) {
            repeat(6) { append(chars[Random.nextInt(chars.length)]) }
        }
    }
}
