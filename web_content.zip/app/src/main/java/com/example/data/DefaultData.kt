package com.example.data

object DefaultData {

  fun getDefaultChapters(): List<Chapter> {
    val list = mutableListOf<Chapter>()

    // Physics (Kerala SCERT Class 12)
    val physicsChapters = listOf(
      "Electric Charges and Fields",
      "Electrostatic Potential and Capacitance",
      "Current Electricity",
      "Moving Charges and Magnetism",
      "Magnetism and Matter",
      "Electromagnetic Induction",
      "Alternating Current",
      "Electromagnetic Waves",
      "Ray Optics and Optical Instruments",
      "Wave Optics",
      "Dual Nature of Radiation and Matter",
      "Atoms",
      "Nuclei",
      "Semiconductor Electronics: Materials & Devices"
    )
    physicsChapters.forEachIndexed { i, title ->
      list.add(Chapter("phy_${i + 1}", Subject.PHYSICS, title, isCompleted = false))
    }

    // Chemistry (Kerala SCERT Class 12)
    val chemistryChapters = listOf(
      "Solutions",
      "Electrochemistry",
      "Chemical Kinetics",
      "The d- and f-Block Elements",
      "Coordination Compounds",
      "Haloalkanes and Haloarenes",
      "Alcohols, Phenols and Ethers",
      "Aldehydes, Ketones and Carboxylic Acids",
      "Amines",
      "Biomolecules"
    )
    chemistryChapters.forEachIndexed { i, title ->
      list.add(Chapter("chem_${i + 1}", Subject.CHEMISTRY, title, isCompleted = false))
    }

    // Mathematics (Kerala SCERT Class 12)
    val mathsChapters = listOf(
      "Relations and Functions",
      "Inverse Trigonometric Functions",
      "Matrices",
      "Determinants",
      "Continuity and Differentiability",
      "Application of Derivatives",
      "Integrals",
      "Application of Integrals",
      "Differential Equations",
      "Vector Algebra",
      "Three Dimensional Geometry",
      "Linear Programming",
      "Probability"
    )
    mathsChapters.forEachIndexed { i, title ->
      list.add(Chapter("math_${i + 1}", Subject.MATHEMATICS, title, isCompleted = false))
    }

    // Computer Science (Kerala DHSE Class 12 Textbook)
    val csChapters = listOf(
      "Structures and Pointers",
      "Concepts of Object Oriented Programming",
      "Data Structures and Operations",
      "Web Technology",
      "Web Designing using HTML",
      "Client Side Scripting using JavaScript",
      "Web Hosting",
      "Database Management Systems",
      "Structured Query Language (SQL)",
      "Server Side Scripting using PHP",
      "Advances in Computing"
    )
    csChapters.forEachIndexed { i, title ->
      list.add(Chapter("cs_${i + 1}", Subject.COMPUTER_SCIENCE, title, isCompleted = false))
    }

    return list
  }

  fun getQuestionBank(): List<QuizQuestion> {
    return listOf(
      // --- COMPUTER SCIENCE (Kerala DHSE Plus Two) ---
      QuizQuestion(
        id = "cs_q1",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Structures and Pointers",
        question = "Which operator is used to access structure members using a pointer to that structure in C++?",
        options = listOf("Dot operator (.)", "Arrow operator (->)", "Ampersand (&)", "Scope resolution (::)"),
        correctIndex = 1,
        explanation = "The arrow operator (->) is shorthand for dereferencing a pointer to a struct and accessing its member: (*ptr).member == ptr->member."
      ),
      QuizQuestion(
        id = "cs_q2",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Structures and Pointers",
        question = "What does the 'new' operator do in dynamic memory allocation?",
        options = listOf("Deletes allocated memory", "Allocates memory at compile time", "Allocates memory dynamically from the heap", "Copies pointers"),
        correctIndex = 2,
        explanation = "In C++, the 'new' operator allocates memory dynamically on the heap during runtime and returns a pointer to that allocated space."
      ),
      QuizQuestion(
        id = "cs_q3",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Concepts of Object Oriented Programming",
        question = "Which OOP feature allows a function or operator to have multiple forms with the same name?",
        options = listOf("Data Hiding", "Encapsulation", "Polymorphism", "Abstraction"),
        correctIndex = 2,
        explanation = "Polymorphism (meaning 'many forms') allows the same function name or operator to exhibit different behaviors depending on types/parameters."
      ),
      QuizQuestion(
        id = "cs_q4",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Data Structures and Operations",
        question = "A Stack data structure operates strictly on which principle?",
        options = listOf("FIFO (First In First Out)", "LIFO (Last In First Out)", "Random Access", "Round Robin"),
        correctIndex = 1,
        explanation = "A Stack follows Last-In First-Out (LIFO), where elements are pushed and popped exclusively from the top."
      ),
      QuizQuestion(
        id = "cs_q5",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Client Side Scripting using JavaScript",
        question = "Which method is used in JavaScript to display a popup message box with an OK button?",
        options = listOf("prompt()", "confirm()", "alert()", "console.print()"),
        correctIndex = 2,
        explanation = "The alert() method in JavaScript displays an alert dialog box with a specified message and an OK button."
      ),
      QuizQuestion(
        id = "cs_q6",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Structured Query Language (SQL)",
        question = "Which SQL clause is used to eliminate duplicate rows from the query output?",
        options = listOf("UNIQUE", "DISTINCT", "DIFFERENT", "REMOVE DUPLICATES"),
        correctIndex = 1,
        explanation = "The SELECT DISTINCT statement is used to return only distinct (different) values from a table."
      ),
      QuizQuestion(
        id = "cs_q7",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Structured Query Language (SQL)",
        question = "Which SQL command is a Data Definition Language (DDL) command?",
        options = listOf("SELECT", "INSERT", "CREATE", "UPDATE"),
        correctIndex = 2,
        explanation = "CREATE, ALTER, and DROP are DDL commands because they define or modify database schemas, whereas INSERT, UPDATE, and DELETE are DML."
      ),
      QuizQuestion(
        id = "cs_q8",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Server Side Scripting using PHP",
        question = "All PHP variable names must start with which symbol?",
        options = listOf("@", "$", "#", "&"),
        correctIndex = 1,
        explanation = "In PHP, variable identifiers must start with the dollar sign ($) followed by the name of the variable (e.g., \$student_name)."
      ),
      QuizQuestion(
        id = "cs_q9",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Database Management Systems",
        question = "What is a candidate key chosen by the database designer to uniquely identify each tuple in a relation called?",
        options = listOf("Foreign Key", "Alternate Key", "Primary Key", "Composite Key"),
        correctIndex = 2,
        explanation = "The Primary Key is the designated candidate key uniquely identifying each record in a relational database table."
      ),
      QuizQuestion(
        id = "cs_q10",
        subject = Subject.COMPUTER_SCIENCE,
        chapterTitle = "Web Technology",
        question = "Which protocol is responsible for translating human-friendly domain names (like kerala.gov.in) into IP addresses?",
        options = listOf("HTTP", "FTP", "DNS", "SMTP"),
        correctIndex = 2,
        explanation = "DNS (Domain Name System) functions as the phonebook of the internet, mapping hostnames to IP addresses."
      ),

      // --- PHYSICS (Kerala SCERT Class 12) ---
      QuizQuestion(
        id = "phy_q1",
        subject = Subject.PHYSICS,
        chapterTitle = "Electric Charges and Fields",
        question = "What is the SI unit of electric flux?",
        options = listOf("N / C", "N m² / C", "N / m²", "C / m²"),
        correctIndex = 1,
        explanation = "Electric flux Φ = E · A, where E is in N/C and Area is in m², giving N·m²/C (or Volt-meter, V·m)."
      ),
      QuizQuestion(
        id = "phy_q2",
        subject = Subject.PHYSICS,
        chapterTitle = "Current Electricity",
        question = "Kirchhoff's first law (Junction rule) at an electric junction is based on the conservation of which quantity?",
        options = listOf("Energy", "Charge", "Momentum", "Mass"),
        correctIndex = 1,
        explanation = "Kirchhoff's Junction Rule (Σ I = 0) is a direct consequence of the conservation of electric charge."
      ),
      QuizQuestion(
        id = "phy_q3",
        subject = Subject.PHYSICS,
        chapterTitle = "Current Electricity",
        question = "How does the resistance of a pure semiconductor change as temperature increases?",
        options = listOf("Increases linearly", "Decreases exponentially", "Remains constant", "First increases then decreases"),
        correctIndex = 1,
        explanation = "Semiconductors have a negative temperature coefficient of resistance; more electron-hole pairs are generated at higher temperatures, decreasing resistance."
      ),
      QuizQuestion(
        id = "phy_q4",
        subject = Subject.PHYSICS,
        chapterTitle = "Moving Charges and Magnetism",
        question = "What is the trajectory of a charged particle entering a uniform magnetic field perpendicular to its velocity?",
        options = listOf("Straight line", "Parabola", "Circle", "Hyperbola"),
        correctIndex = 2,
        explanation = "When velocity is perpendicular to B, the magnetic Lorentz force acts as a centripetal force perpendicular to velocity, producing uniform circular motion."
      ),
      QuizQuestion(
        id = "phy_q5",
        subject = Subject.PHYSICS,
        chapterTitle = "Electromagnetic Induction",
        question = "Lenz's Law gives the direction of induced current and is a manifestation of the law of conservation of:",
        options = listOf("Linear momentum", "Angular momentum", "Energy", "Electric charge"),
        correctIndex = 2,
        explanation = "Lenz's law states that induced EMF opposes the change in flux causing it. Work must be done against this opposition, satisfying conservation of energy."
      ),
      QuizQuestion(
        id = "phy_q6",
        subject = Subject.PHYSICS,
        chapterTitle = "Ray Optics and Optical Instruments",
        question = "Which phenomenon explains the sparkling brilliance of a cut diamond?",
        options = listOf("Diffraction", "Total Internal Reflection", "Polarization", "Interference"),
        correctIndex = 1,
        explanation = "Diamond has a very high refractive index (~2.42) and small critical angle (~24.4°), trapping light through multiple Total Internal Reflections."
      ),
      QuizQuestion(
        id = "phy_q7",
        subject = Subject.PHYSICS,
        chapterTitle = "Wave Optics",
        question = "In Young's Double Slit Experiment, what happens to fringe width if the distance between the slits (d) is doubled?",
        options = listOf("Doubled", "Halved", "Quadrupled", "Remains unchanged"),
        correctIndex = 1,
        explanation = "Fringe width β = λD / d. Since fringe width is inversely proportional to slit separation d, doubling d cuts the fringe width in half."
      ),
      QuizQuestion(
        id = "phy_q8",
        subject = Subject.PHYSICS,
        chapterTitle = "Dual Nature of Radiation and Matter",
        question = "According to Einstein's photoelectric equation, the maximum kinetic energy of emitted photoelectrons depends on:",
        options = listOf("Intensity of incident light", "Frequency of incident light", "Time of illumination", "Surface area"),
        correctIndex = 1,
        explanation = "KE_max = hν - Φ_0. Maximum kinetic energy depends linearly on the frequency of incident radiation (ν), not on intensity."
      ),
      QuizQuestion(
        id = "phy_q9",
        subject = Subject.PHYSICS,
        chapterTitle = "Semiconductor Electronics: Materials & Devices",
        question = "In an unbiased p-n junction, the barrier potential is caused by:",
        options = listOf("Free electrons in n-region", "Holes in p-region", "Immobile ions in the depletion layer", "Applied voltage"),
        correctIndex = 2,
        explanation = "Diffusion of majority carriers leaves behind uncompensated positive donor ions in n-side and negative acceptor ions in p-side, forming the barrier."
      ),
      QuizQuestion(
        id = "phy_q10",
        subject = Subject.PHYSICS,
        chapterTitle = "Atoms",
        question = "Which spectral series of the Hydrogen atom lies in the visible region of the electromagnetic spectrum?",
        options = listOf("Lyman series", "Balmer series", "Paschen series", "Brackett series"),
        correctIndex = 1,
        explanation = "The Balmer series (transitions ending at n=2) produces emission lines in the visible spectrum."
      ),

      // --- CHEMISTRY (Kerala SCERT Class 12) ---
      QuizQuestion(
        id = "chem_q1",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Solutions",
        question = "Which colligative property is preferred for determining the molar mass of biomolecules and polymers?",
        options = listOf("Relative lowering of vapour pressure", "Elevation of boiling point", "Depression of freezing point", "Osmotic pressure"),
        correctIndex = 3,
        explanation = "Osmotic pressure (π = CRT) can be measured at room temperature using molarity, and produces readable changes even for dilute solutions of large molecules."
      ),
      QuizQuestion(
        id = "chem_q2",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Electrochemistry",
        question = "The unit of molar conductivity (Λm) is:",
        options = listOf("S cm² mol⁻¹", "S cm⁻¹", "S m⁻¹", "ohm cm² mol"),
        correctIndex = 0,
        explanation = "Molar conductivity Λm = κ / C. Expressed with κ in S cm⁻¹ and C in mol/cm³, its SI unit is S cm² mol⁻¹."
      ),
      QuizQuestion(
        id = "chem_q3",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Chemical Kinetics",
        question = "For a first order chemical reaction, the half-life period (t₁/₂) is given by:",
        options = listOf("0.693 / k", "k / 0.693", "[A]₀ / 2k", "1 / (k[A]₀)"),
        correctIndex = 0,
        explanation = "For a first-order reaction, t₁/₂ = ln(2) / k = 0.693 / k. It is independent of the initial reactant concentration."
      ),
      QuizQuestion(
        id = "chem_q4",
        subject = Subject.CHEMISTRY,
        chapterTitle = "The d- and f-Block Elements",
        question = "Why are transition metal ions generally coloured in aqueous solutions?",
        options = listOf("High melting point", "d-d electronic transitions", "Presence of paired electrons", "Large atomic radius"),
        correctIndex = 1,
        explanation = "In transition metal complexes with degenerate d-orbitals split by crystal fields, absorption of visible light causes d-d transitions of unpaired electrons."
      ),
      QuizQuestion(
        id = "chem_q5",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Coordination Compounds",
        question = "What is the oxidation state of Cobalt in the complex ion [Co(NH₃)₆]³⁺?",
        options = listOf("+2", "+3", "+6", "0"),
        correctIndex = 1,
        explanation = "NH₃ is a neutral ligand (charge 0). Therefore, Co + 6(0) = +3 => Co = +3."
      ),
      QuizQuestion(
        id = "chem_q6",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Haloalkanes and Haloarenes",
        question = "Which mechanism involves complete inversion of configuration (Walden inversion)?",
        options = listOf("SN1 mechanism", "SN2 mechanism", "E1 mechanism", "Electrophilic substitution"),
        correctIndex = 1,
        explanation = "SN2 is a concerted, single-step reaction with backside nucleophilic attack causing umbrella-like Walden inversion."
      ),
      QuizQuestion(
        id = "chem_q7",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Alcohols, Phenols and Ethers",
        question = "Lucas reagent used to distinguish primary, secondary, and tertiary alcohols consists of:",
        options = listOf("Anhydrous ZnCl₂ + Conc. HCl", "Dilute H₂SO₄ + KMnO₄", "Cu at 573 K", "Na / Dry Ether"),
        correctIndex = 0,
        explanation = "Lucas reagent is a solution of anhydrous zinc chloride in concentrated hydrochloric acid. Tertiary alcohols react immediately forming turbidity."
      ),
      QuizQuestion(
        id = "chem_q8",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Aldehydes, Ketones and Carboxylic Acids",
        question = "Which reagent gives a silver mirror test with aldehydes but not with ketones?",
        options = listOf("Fehling's solution", "Tollens' reagent", "Benedict's solution", "Grignard reagent"),
        correctIndex = 1,
        explanation = "Tollens' reagent (ammoniacal silver nitrate) oxidizes aldehydes to carboxylate ions while reducing Ag⁺ to metallic silver."
      ),
      QuizQuestion(
        id = "chem_q9",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Amines",
        question = "The Carbylamine test is given exclusively by:",
        options = listOf("Primary aliphatic and aromatic amines", "Secondary amines only", "Tertiary amines only", "All amines"),
        correctIndex = 0,
        explanation = "When heated with chloroform and alcoholic KOH, only primary amines form foul-smelling isocyanides (carbylamines)."
      ),
      QuizQuestion(
        id = "chem_q10",
        subject = Subject.CHEMISTRY,
        chapterTitle = "Biomolecules",
        question = "Which vitamin is water soluble and cannot be stored in the human body?",
        options = listOf("Vitamin A", "Vitamin D", "Vitamin C", "Vitamin K"),
        correctIndex = 2,
        explanation = "Vitamins B and C are water-soluble and excreted readily through urine, so they require daily dietary replenishment."
      ),

      // --- MATHEMATICS (Kerala SCERT Class 12) ---
      QuizQuestion(
        id = "math_q1",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Matrices",
        question = "If A is a square matrix of order n, then |kA| equals:",
        options = listOf("k|A|", "k^n |A|", "k^(n-1) |A|", "n k |A|"),
        correctIndex = 1,
        explanation = "Multiplying matrix A by scalar k multiplies each of its n rows by k, so |kA| = k^n |A|."
      ),
      QuizQuestion(
        id = "math_q2",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Determinants",
        question = "A square matrix A is called singular if its determinant |A| is:",
        options = listOf("1", "0", "-1", "undefined"),
        correctIndex = 1,
        explanation = "A matrix is singular if and only if |A| = 0, meaning it has no inverse (A⁻¹ does not exist)."
      ),
      QuizQuestion(
        id = "math_q3",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Continuity and Differentiability",
        question = "What is the derivative of e^(cos x) with respect to x?",
        options = listOf("-sin x · e^(cos x)", "sin x · e^(cos x)", "-cos x · e^(sin x)", "e^(cos x)"),
        correctIndex = 0,
        explanation = "By chain rule: d/dx [e^(cos x)] = e^(cos x) · d/dx(cos x) = -sin x · e^(cos x)."
      ),
      QuizQuestion(
        id = "math_q4",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Integrals",
        question = "What is ∫ 1 / (1 + x²) dx?",
        options = listOf("ln(1 + x²) + C", "tan⁻¹(x) + C", "sin⁻¹(x) + C", "sec⁻¹(x) + C"),
        correctIndex = 1,
        explanation = "The standard integral of 1 / (1 + x²) is the inverse tangent function: tan⁻¹(x) + C."
      ),
      QuizQuestion(
        id = "math_q5",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Integrals",
        question = "Evaluate the definite integral ∫ from -1 to 1 of x³ dx:",
        options = listOf("1/4", "1/2", "0", "2"),
        correctIndex = 2,
        explanation = "f(x) = x³ is an odd function (f(-x) = -f(x)). The integral of any odd function over symmetric limits [-a, a] is identically 0."
      ),
      QuizQuestion(
        id = "math_q6",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Differential Equations",
        question = "What is the order of the differential equation (d²y/dx²)³ + (dy/dx)⁴ + y = 0?",
        options = listOf("2", "3", "4", "1"),
        correctIndex = 0,
        explanation = "The order of a differential equation is the highest order derivative appearing in it, which here is d²y/dx² (Order 2, Degree 3)."
      ),
      QuizQuestion(
        id = "math_q7",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Vector Algebra",
        question = "If two non-zero vectors a and b are perpendicular, their dot product a · b is:",
        options = listOf("1", "|a||b|", "0", "-1"),
        correctIndex = 2,
        explanation = "a · b = |a||b| cos(θ). Since θ = 90°, cos(90°) = 0, resulting in a · b = 0."
      ),
      QuizQuestion(
        id = "math_q8",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Three Dimensional Geometry",
        question = "If l, m, n are direction cosines of a directed line in 3D space, which identity holds?",
        options = listOf("l + m + n = 1", "l² + m² + n² = 1", "l² + m² + n² = 0", "l m n = 1"),
        correctIndex = 1,
        explanation = "For any line with direction angles α, β, γ: cos²α + cos²β + cos²γ = l² + m² + n² = 1."
      ),
      QuizQuestion(
        id = "math_q9",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Probability",
        question = "If P(A) = 0.6, P(B) = 0.3, and A and B are independent events, what is P(A ∩ B)?",
        options = listOf("0.9", "0.3", "0.18", "0.5"),
        correctIndex = 2,
        explanation = "For independent events, P(A ∩ B) = P(A) × P(B) = 0.6 × 0.3 = 0.18."
      ),
      QuizQuestion(
        id = "math_q10",
        subject = Subject.MATHEMATICS,
        chapterTitle = "Relations and Functions",
        question = "A relation R on set A is called an equivalence relation if it is:",
        options = listOf("Reflexive only", "Symmetric and Transitive only", "Reflexive, Symmetric, and Transitive", "Bijective and Injective"),
        correctIndex = 2,
        explanation = "An equivalence relation must satisfy all three fundamental properties: Reflexivity (aRa), Symmetry (aRb => bRa), and Transitivity (aRb & bRc => aRc)."
      )
    )
  }

  fun generateSenseiResponse(
    character: SenseiCharacter,
    query: String
  ): String {
    val q = query.lowercase()

    val (narutoAnswer, hinataAnswer) = when {
      q.contains("pointer") || q.contains("reference") || q.contains("address") -> Pair(
        "Whoa! Pointers are awesome, just like ninja telemetry! 🎯 In C++, a pointer holds the memory address of another variable. You declare it with `*` like `int *ptr = &x;`. Think of the `&` operator as getting the GPS coordinates of your ninja base, and `*ptr` as teleporting straight inside to grab the treasure! Don't let your pointers go wild or you'll get a segmentation fault! Believe it!",
        "Um, let me explain pointers gently... In Computer Science, variables live in memory like houses on a street. A regular variable stores a value, but a pointer variable stores the house number (address). When you write `int *ptr = &a;`, `&` finds the address of `a`, and `*ptr` peeks inside to see what's stored there. Take your time practicing with small code examples, you'll master it step by step!"
      )
      q.contains("shadow clone") || q.contains("recursion") -> Pair(
        "Haha! Shadow Clone Jutsu (Kage Bunshin) IS recursion in real life! 🔥 A recursive function calls itself to solve smaller pieces of a giant problem! Just remember: EVERY clone needs a BASE CASE (stopping condition), or else you'll summon infinite clones, run out of chakra, and cause a Stack Overflow! Keep that base case solid, dattebayo!",
        "Naruto is right! In algorithms, recursion is when a function calls a copy of itself to break a large task into smaller sub-problems. It always needs two parts: 1) The Base Case which stops the recursion, and 2) The Recursive Case which moves closer to the base case. A classic Plus Two example is `factorial(n) = n * factorial(n - 1)`. I know you can trace it carefully on paper."
      )
      q.contains("sql") || q.contains("database") || q.contains("ddl") || q.contains("dml") -> Pair(
        "Listen up! SQL is like commanding your squad! DDL (Data Definition Language) like `CREATE TABLE` and `ALTER TABLE` builds the ninja academy walls! DML (Data Manipulation Language) like `SELECT`, `INSERT`, and `UPDATE` moves ninjas in and out of the squads! Remember: `SELECT name FROM Shinobi WHERE rank = 'Hokage';`! Never forget your semicolon, dattebayo!",
        "Here is a simple breakdown for your DHSE Class 12 exams: DBMS stores structured data in tables. DDL commands (`CREATE`, `DROP`, `ALTER`) deal with the structure or schema of tables. DML commands (`SELECT`, `INSERT`, `UPDATE`, `DELETE`) deal with the data inside rows. A Primary key uniquely identifies each record and cannot be null. Please review the difference table before your exam!"
      )
      q.contains("kirchhoff") || q.contains("current") || q.contains("electricity") || q.contains("circuit") -> Pair(
        "Electricity jutsu! ⚡ Kirchhoff gave us two legendary rules! First: Junction Rule! What current enters a node must leave it! (Charge conservation! Just like chakra flowing through tenketsu!). Second: Loop Rule! The sum of all voltages around any closed circuit loop is ZERO! (Energy conservation!). Charge up your chakra and solve those loop equations! Believe it!",
        "In Physics Class 12, Kirchhoff's Laws are very important for solving bridge circuits: 1. Current Law (KCL): Sum of currents meeting at a junction is zero (conservation of charge). 2. Voltage Law (KVL): In any closed loop, the algebraic sum of EMFs equals the sum of IR drops (conservation of energy). Remember to assume a consistent clockwise or counter-clockwise sign convention."
      )
      q.contains("matrix") || q.contains("determinant") || q.contains("inverse") -> Pair(
        "Matrices are like tactical battle grids! 🥷 For a 2x2 matrix `[a, b; c, d]`, the determinant is `ad - bc`! To find the inverse `A⁻¹`, swap `a` and `d`, put minus signs on `b` and `c`, and divide the whole thing by `ad - bc`! But watch out: if `ad - bc = 0`, it's a singular matrix and you CANNOT invert it! Stay alert and calculate with full power!",
        "Let's solve matrix problems methodically: For matrix A, its inverse exists only if determinant `|A| ≠ 0`. Formula: `A⁻¹ = (1 / |A|) · adj(A)`. For 2x2: swap main diagonal elements, change the signs of off-diagonal elements, then divide by `|A|`. For 3x3: find cofactors carefully step by step, transpose to get `adj(A)`. Take a deep breath, you have this under control."
      )
      q.contains("nernst") || q.contains("electrochem") || q.contains("kinetics") || q.contains("solution") -> Pair(
        "Chemistry Jutsu! 🧪 The Nernst equation tells you the cell potential under non-standard conditions! `E_cell = E°_cell - (0.0591 / n) * log10(Q)` at 298 Kelvin! `n` is the number of moles of electrons transferred! Keep track of your anode and cathode oxidation states and you'll nail every exam problem! Dattebayo!",
        "In Class 12 Electrochemistry, the Nernst equation calculates electrode and cell potential at any concentration: `E = E° - (2.303 RT / nF) log [Anode ion] / [Cathode ion]`. At 298 K, `(2.303 RT / F)` simplifies to `0.0591`. Always write the balanced redox reaction first so you can correctly identify `n` and the powers of ion concentrations."
      )
      q.contains("optics") || q.contains("snell") || q.contains("refraction") || q.contains("prism") -> Pair(
        "Light travels like a lightning-fast flying raijin! 🌟 Snell's Law says `n1 * sin(θ1) = n2 * sin(θ2)`! And when light tries to escape from a dense medium to a rarer medium past the critical angle... BAM! Total Internal Reflection! That's why optical fibers carry internet data at lightspeed across the world! Keep your focus laser sharp!",
        "Ray optics requires neat ray diagrams with arrow marks. Remember Snell's law: refractive index `n = sin(i) / sin(r)`. For Total Internal Reflection: 1) Light must travel from optically denser to rarer medium, and 2) Angle of incidence must exceed critical angle `sin(c) = 1 / n`. Keep your compass and scale ready for neat exam figures."
      )
      q.contains("tip") || q.contains("score") || q.contains("exam") || q.contains("dhse") || q.contains("schedule") -> Pair(
        "Here's my Hokage study motto: Consistency beats raw talent every single time! 🔥 1) Do 45-minute focused bursts with our Study Dojo Timer! 2) Solve Plus Two previous year question papers (PYQs)! 3) Test yourself daily in our Quiz Dojo! Even if you fail a quiz today, get back up! A real ninja never gives up on their ninja way! Believe it!",
        "To score high in Kerala DHSE Plus Two exams: Focus on textbook derivations in Physics, named organic reactions in Chemistry, standard integrals & vectors in Maths, and SQL syntax & OOP in CS. Make brief 1-page summary sheets for formulas and revise them every morning. Drink water, rest well, and trust in your hard work. You can achieve great things!"
      )
      else -> Pair(
        "That's a great question! Whatever Kerala Plus Two topic you're training on, tackle it head-on! Break the chapter down into small jutsu techniques, practice with our timer, and drill quizzes until you master it! Ask me about C++ pointers, SQL queries, calculus, circuits, or chemistry anytime! Believe it!",
        "That sounds like an important question. When preparing for Plus Two exams, breaking concepts into fundamentals always helps. You can ask me about Physics laws, Chemistry reaction mechanisms, Maths formulas, or Computer Science algorithms. I am always right here to help you study gently step by step."
      )
    }

    return if (character == SenseiCharacter.NARUTO) narutoAnswer else hinataAnswer
  }
}
