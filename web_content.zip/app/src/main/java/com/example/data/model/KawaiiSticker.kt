package com.example.data.model

data class KawaiiSticker(
    val id: String,
    val name: String,
    val emoji: String,
    val tagline: String,
    val requiredMinutes: Int, // Focus minutes required to unlock
    val accentColorHex: String = "#F472B6",
    val bgTintHex: String = "#FFF0F5"
)

object StickerCatalog {
    val allStickers = listOf(
        KawaiiSticker(
            id = "bunny_pen",
            name = "Bunny Pen",
            emoji = "🐰",
            tagline = "Writes with extra cuteness & speed!",
            requiredMinutes = 0,
            accentColorHex = "#F472B6",
            bgTintHex = "#FFF0F5"
        ),
        KawaiiSticker(
            id = "sweet_calc",
            name = "Cute Calculator",
            emoji = "🧮",
            tagline = "Solves any math problem with a smile!",
            requiredMinutes = 25,
            accentColorHex = "#FDA4AF",
            bgTintHex = "#FFF0F5"
        ),
        KawaiiSticker(
            id = "star_eraser",
            name = "Pastel Eraser",
            emoji = "🧼",
            tagline = "Erases doubts and keeps focus crisp.",
            requiredMinutes = 50,
            accentColorHex = "#F472B6",
            bgTintHex = "#FDF2F8"
        ),
        KawaiiSticker(
            id = "pastel_scissors",
            name = "Ribbon Scissors",
            emoji = "✂️",
            tagline = "Snips away all distractions!",
            requiredMinutes = 75,
            accentColorHex = "#93C5FD",
            bgTintHex = "#EFF6FF"
        ),
        KawaiiSticker(
            id = "sprout_ruler",
            name = "Sprout Ruler",
            emoji = "📏",
            tagline = "Measures daily study growth millimeter by millimeter.",
            requiredMinutes = 100,
            accentColorHex = "#86EFAC",
            bgTintHex = "#F0FDF4"
        ),
        KawaiiSticker(
            id = "butterfly_clip",
            name = "Butterfly Clip",
            emoji = "📎",
            tagline = "Holds your best study ideas together.",
            requiredMinutes = 150,
            accentColorHex = "#F472B6",
            bgTintHex = "#FFF0F5"
        ),
        KawaiiSticker(
            id = "cozy_brush",
            name = "Blush Brush",
            emoji = "🖌️",
            tagline = "Paints bright thoughts into notes.",
            requiredMinutes = 200,
            accentColorHex = "#FDA4AF",
            bgTintHex = "#FFF0F5"
        ),
        KawaiiSticker(
            id = "star_pin",
            name = "Push Pin",
            emoji = "📌",
            tagline = "Pins down your key goals permanently.",
            requiredMinutes = 250,
            accentColorHex = "#F472B6",
            bgTintHex = "#FFF0F5"
        ),
        KawaiiSticker(
            id = "sky_capsule",
            name = "Focus Rocket",
            emoji = "🚀",
            tagline = "Zooms your grades to the stars!",
            requiredMinutes = 300,
            accentColorHex = "#93C5FD",
            bgTintHex = "#EFF6FF"
        ),
        KawaiiSticker(
            id = "blossom_stamp",
            name = "Cherry Blossom",
            emoji = "🌸",
            tagline = "A gentle reward for peaceful persistence.",
            requiredMinutes = 360,
            accentColorHex = "#F472B6",
            bgTintHex = "#FFF0F5"
        )
    )
}
