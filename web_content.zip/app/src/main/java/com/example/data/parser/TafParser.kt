package com.example.data.parser

import com.example.data.model.TafData
import com.example.data.model.TafForecastItem
import java.util.regex.Pattern

object TafParser {

  private val TIME_HEADER_PATTERN = Pattern.compile("\\b(\\d{6}Z)\\s+(\\d{4}/\\d{4})\\b")
  private val CHANGE_GROUP_PATTERN = Pattern.compile("\\b(FM\\d{6}|BECMG|TEMPO|PROB30|PROB40)\\b")

  fun parse(raw: String, icaoFallback: String = ""): TafData {
    val clean = raw.trim().replace("\n", " ").replace("\\s+".toRegex(), " ")
    val tokens = clean.split(" ")

    var icao = icaoFallback
    var issueTime = ""
    var validPeriod = ""

    for (i in 0 until minOf(tokens.size, 5)) {
      val token = tokens[i]
      if (token.length == 4 && token.all { it.isLetter() } && token != "TAF" && token != "COR") {
        icao = token
      }
    }

    val headerMatcher = TIME_HEADER_PATTERN.matcher(clean)
    if (headerMatcher.find()) {
      issueTime = headerMatcher.group(1) ?: ""
      validPeriod = headerMatcher.group(2) ?: ""
    }

    // Break down forecast groups
    val forecasts = mutableListOf<String>()
    val matcher = CHANGE_GROUP_PATTERN.matcher(clean)
    var lastIndex = 0
    var currentTag = "MAIN FORECAST"

    while (matcher.find()) {
      val start = matcher.start()
      if (start > lastIndex) {
        val segment = clean.substring(lastIndex, start).trim()
        if (segment.isNotBlank()) {
          forecasts.add("$currentTag: $segment")
        }
      }
      currentTag = matcher.group(1) ?: "CHANGE"
      lastIndex = matcher.end()
    }
    if (lastIndex < clean.length) {
      val rem = clean.substring(lastIndex).trim()
      if (rem.isNotBlank()) {
        forecasts.add("$currentTag: $rem")
      }
    }

    val validParts = validPeriod.split("/")
    val validFrom = if (validParts.isNotEmpty()) validParts[0] else ""
    val validTo = if (validParts.size > 1) validParts[1] else ""

    return TafData(
      icao = icao.ifBlank { icaoFallback },
      rawTaf = raw,
      issueTimeUtc = issueTime,
      validFromUtc = validFrom,
      validToUtc = validTo,
      forecastsSummary = forecasts.joinToString("\n\n")
    )
  }
}
