package com.example.data.service

import com.example.data.model.CalculationMethod
import com.example.data.model.HijriDate
import com.example.data.model.PrayerType
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

object OfflinePrayerCalculator {

    val AVAILABLE_METHODS = listOf(
        CalculationMethod(3, "وزارة الشؤون الدينية والأوقاف (الجزائر)", "Ministry of Religious Affairs, Algeria"),
        CalculationMethod(4, "جامعة أم القرى - مكة المكرمة", "Umm Al-Qura University, Makkah"),
        CalculationMethod(5, "الهيئة المصرية العامة للمساحة", "Egyptian General Authority of Survey"),
        CalculationMethod(2, "الجمعية الإسلامية لأمريكا الشمالية (ISNA)", "Islamic Society of North America"),
        CalculationMethod(1, "جامعة العلوم الإسلامية بكراتشي", "Univ. of Islamic Sciences, Karachi"),
        CalculationMethod(12, "اتحاد المنظمات الإسلامية بفرنسا", "UOIF, France")
    )

    fun calculatePrayerTimes(
        latitude: Double,
        longitude: Double,
        calendar: Calendar,
        methodId: Int = 3
    ): Map<PrayerType, Pair<Int, Int>> { // PrayerType -> Pair(hour, minute)
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val timeZone = calendar.timeZone.getOffset(calendar.timeInMillis) / 3600000.0

        val fajrAngle = when (methodId) {
            4 -> 18.5 // Umm Al-Qura
            5 -> 19.5 // Egyptian
            2 -> 15.0 // ISNA
            1 -> 18.0 // Karachi
            12 -> 12.0 // France
            else -> 18.0 // Algeria & MWL
        }

        val ishaAngle = when (methodId) {
            5 -> 17.5 // Egyptian
            2 -> 15.0 // ISNA
            1 -> 18.0 // Karachi
            12 -> 12.0 // France
            else -> 17.0 // Algeria / MWL
        }

        val jd = julianDay(year, month, day) - longitude / (15.0 * 24.0)

        // Solar coordinates
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(Math.toRadians(g)) + 0.020 * sin(Math.toRadians(2 * g)))
        val e = 23.439 - 0.00000036 * d
        val declination = Math.toDegrees(asin(sin(Math.toRadians(e)) * sin(Math.toRadians(l))))
        val ra = fixAngle(Math.toDegrees(atan2(cos(Math.toRadians(e)) * sin(Math.toRadians(l)), cos(Math.toRadians(l))))) / 15.0
        val eqt = q / 15.0 - ra

        // Solar noon (Dhuhr base)
        val noon = fixHour(12.0 + timeZone - longitude / 15.0 - eqt)

        // Sun angle helper
        fun sunAngleTime(angle: Double, isMorning: Boolean): Double {
            val cosH = (-sin(Math.toRadians(angle)) - sin(Math.toRadians(latitude)) * sin(Math.toRadians(declination))) /
                    (cos(Math.toRadians(latitude)) * cos(Math.toRadians(declination)))
            val clamped = cosH.coerceIn(-1.0, 1.0)
            val h = Math.toDegrees(acos(clamped)) / 15.0
            return if (isMorning) noon - h else noon + h
        }

        // Asr helper (Standard / Shafi, Maliki, Hanbali shadow ratio = 1)
        fun asrTime(): Double {
            val asrAngle = -Math.toDegrees(atan2(1.0, 1.0 + tan(Math.toRadians(abs(latitude - declination)))))
            val cosH = (-sin(Math.toRadians(asrAngle)) - sin(Math.toRadians(latitude)) * sin(Math.toRadians(declination))) /
                    (cos(Math.toRadians(latitude)) * cos(Math.toRadians(declination)))
            val clamped = cosH.coerceIn(-1.0, 1.0)
            val h = Math.toDegrees(acos(clamped)) / 15.0
            return noon + h
        }

        val fajrDecimal = sunAngleTime(fajrAngle, true)
        val sunriseDecimal = sunAngleTime(0.833, true)
        val dhuhrDecimal = noon + (1.0 / 60.0) // 1 min after zenith
        val asrDecimal = asrTime()
        val maghribDecimal = sunAngleTime(0.833, false) + (2.0 / 60.0) // 2 mins after sunset

        val ishaDecimal = if (methodId == 4) {
            maghribDecimal + 1.5 // Umm Al-Qura 90 mins after Maghrib
        } else {
            sunAngleTime(ishaAngle, false)
        }

        fun decimalToTime(time: Double): Pair<Int, Int> {
            val normalized = fixHour(time + 0.5 / 60.0) // round to nearest minute
            val h = floor(normalized).toInt() % 24
            val m = floor((normalized - floor(normalized)) * 60.0).toInt() % 60
            return Pair(h, m)
        }

        return mapOf(
            PrayerType.FAJR to decimalToTime(fajrDecimal),
            PrayerType.SUNRISE to decimalToTime(sunriseDecimal),
            PrayerType.DHUHR to decimalToTime(dhuhrDecimal),
            PrayerType.ASR to decimalToTime(asrDecimal),
            PrayerType.MAGHRIB to decimalToTime(maghribDecimal),
            PrayerType.ISHA to decimalToTime(ishaDecimal)
        )
    }

    fun calculateQiblaDirection(latitude: Double, longitude: Double): Double {
        val makkahLat = 21.4225
        val makkahLon = 39.8262

        val phi1 = Math.toRadians(latitude)
        val phi2 = Math.toRadians(makkahLat)
        val deltaLambda = Math.toRadians(makkahLon - longitude)

        val y = sin(deltaLambda)
        val x = cos(phi1) * tan(phi2) - sin(phi1) * cos(deltaLambda)
        val qibla = Math.toDegrees(atan2(y, x))
        return (qibla + 360.0) % 360.0
    }

    fun calculateHijriDate(calendar: Calendar): HijriDate {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        var jd = julianDay(year, month, day)

        // Astronomical Islamic calendar computation
        val l = (jd - 1948440 + 10632).toInt()
        val n = ((l - 1) / 10631)
        val l2 = l - 10631 * n + 354
        val j = ((10985 - l2) / 5316) * ((50 * l2) / 17719) + (l2 / 5670) * ((43 * l2) / 15238)
        val l3 = l2 - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29
        val hijriMonth = ((24 * l3) / 709)
        val hijriDay = l3 - ((709 * hijriMonth) / 24)
        val hijriYear = 30 * n + j - 30

        val hijriMonthsAr = listOf(
            "المحرّم", "صفر", "ربيع الأول", "ربيع الآخر",
            "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
            "رمضان", "شوّال", "ذو القعدة", "ذو الحجة"
        )
        val hijriMonthsEn = listOf(
            "Muharram", "Safar", "Rabi' al-Awwal", "Rabi' al-Thani",
            "Jumada al-Awwal", "Jumada al-Thani", "Rajab", "Sha'ban",
            "Ramadan", "Shawwal", "Dhu al-Qi'dah", "Dhu al-Hijjah"
        )

        val monthIndex = (hijriMonth - 1).coerceIn(0, 11)

        return HijriDate(
            day = hijriDay.toString(),
            monthAr = hijriMonthsAr[monthIndex],
            monthEn = hijriMonthsEn[monthIndex],
            year = hijriYear.toString(),
            designation = "هـ"
        )
    }

    private fun julianDay(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun fixAngle(a: Double): Double {
        var angle = a - 360.0 * floor(a / 360.0)
        if (angle < 0) angle += 360.0
        return angle
    }

    private fun fixHour(h: Double): Double {
        var hour = h - 24.0 * floor(h / 24.0)
        if (hour < 0) hour += 24.0
        return hour
    }
}
