package com.example.data.image

object VocabularyImageProvider {

    // Curated collection of high quality, direct photographic/illustrative assets
    private val IMAGE_PRESETS = mapOf(
        "lectura" to "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=800&auto=format&fit=crop&q=80",
        "libro" to "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=800&auto=format&fit=crop&q=80",
        "espacio" to "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
        "cosmos" to "https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=800&auto=format&fit=crop&q=80",
        "estrellas" to "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&auto=format&fit=crop&q=80",
        "serenidad" to "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80",
        "paz" to "https://images.unsplash.com/photo-1470246973918-29a93221c455?w=800&auto=format&fit=crop&q=80",
        "naturaleza" to "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=800&auto=format&fit=crop&q=80",
        "filosofia" to "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop&q=80",
        "antiguo" to "https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&auto=format&fit=crop&q=80",
        "ciencia" to "https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=800&auto=format&fit=crop&q=80",
        "montana" to "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80",
        "luz" to "https://images.unsplash.com/photo-1499209974431-9dddcece7f88?w=800&auto=format&fit=crop&q=80",
        "tiempo" to "https://images.unsplash.com/photo-1501139083538-0139583c060f?w=800&auto=format&fit=crop&q=80",
        "mente" to "https://images.unsplash.com/photo-1507842229451-2495b4de388b?w=800&auto=format&fit=crop&q=80",
        "fuego" to "https://images.unsplash.com/photo-1520690214124-2405c5217036?w=800&auto=format&fit=crop&q=80",
        "agua" to "https://images.unsplash.com/photo-1488188840666-e2308741a62f?w=800&auto=format&fit=crop&q=80",
        "camino" to "https://images.unsplash.com/photo-1476820865390-c52aeebb9891?w=800&auto=format&fit=crop&q=80",
        "nieve" to "https://images.unsplash.com/photo-1483921020237-2ff51e8e4b22?w=800&auto=format&fit=crop&q=80"
    )

    private val FALLBACK_POOL = listOf(
        "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&auto=format&fit=crop&q=80",
        "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&auto=format&fit=crop&q=80"
    )

    fun getImageForWord(word: String, category: String, keywordHint: String = ""): String {
        val lowerWord = word.lowercase()
        val lowerCategory = category.lowercase()
        val lowerHint = keywordHint.lowercase()

        // Match keyword hint
        for ((key, url) in IMAGE_PRESETS) {
            if (lowerHint.contains(key) || lowerWord.contains(key) || lowerCategory.contains(key)) {
                return url
            }
        }

        // Semantic matching based on word roots
        when {
            lowerWord.contains("astronom") || lowerWord.contains("cosmo") || lowerWord.contains("galaxia") ||
                    lowerWord.contains("perihelio") || lowerWord.contains("singular") || lowerWord.contains("radiac") -> {
                return IMAGE_PRESETS["espacio"]!!
            }
            lowerWord.contains("paz") || lowerWord.contains("sosiego") || lowerWord.contains("ataraxia") ||
                    lowerWord.contains("seren") || lowerWord.contains("ecuanim") || lowerWord.contains("calma") -> {
                return IMAGE_PRESETS["serenidad"]!!
            }
            lowerWord.contains("botica") || lowerWord.contains("pocima") || lowerWord.contains("medicin") ||
                    lowerWord.contains("experim") || lowerWord.contains("quimic") -> {
                return IMAGE_PRESETS["ciencia"]!!
            }
            lowerWord.contains("filosof") || lowerWord.contains("disquis") || lowerWord.contains("juicio") ||
                    lowerWord.contains("arbitrio") || lowerWord.contains("estoic") -> {
                return IMAGE_PRESETS["filosofia"]!!
            }
            lowerWord.contains("camino") || lowerWord.contains("vicisitud") || lowerWord.contains("voragine") ||
                    lowerWord.contains("travesia") -> {
                return IMAGE_PRESETS["camino"]!!
            }
            lowerWord.contains("letargo") || lowerWord.contains("sueno") || lowerWord.contains("dorm") ||
                    lowerWord.contains("noche") -> {
                return IMAGE_PRESETS["estrellas"]!!
            }
            lowerWord.contains("inmutable") || lowerWord.contains("roca") || lowerWord.contains("montana") ||
                    lowerWord.contains("inexpugn") -> {
                return IMAGE_PRESETS["montana"]!!
            }
            lowerWord.contains("efimero") || lowerWord.contains("flor") || lowerWord.contains("burbuja") -> {
                return IMAGE_PRESETS["naturaleza"]!!
            }
            lowerWord.contains("quimera") || lowerWord.contains("sueno") || lowerWord.contains("fantasia") -> {
                return IMAGE_PRESETS["luz"]!!
            }
        }

        // Deterministic hash based selection from fallback pool
        val index = (Math.abs(word.hashCode()) % FALLBACK_POOL.size)
        return FALLBACK_POOL[index]
    }
}
