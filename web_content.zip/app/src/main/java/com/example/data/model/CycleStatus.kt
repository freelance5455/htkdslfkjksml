package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cycle_status")
data class CycleStatus(
    @PrimaryKey val cycleKey: String, // e.g. "2026-09-1", "2026-09-2", "2026-09-3"
    val monthKey: String, // "2026-09"
    val cycleNumber: Int, // 1, 2, 3
    val status: String = "PENDING", // PENDING, INVOICED, PAID
    val paidAmount: Double = 0.0,
    val paymentDate: String? = null,
    val notes: String = ""
)
