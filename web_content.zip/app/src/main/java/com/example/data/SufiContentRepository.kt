package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader

class SufiContentRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("sufi_prefs", Context.MODE_PRIVATE)

    private val _entries = mutableListOf<SufiEntry>()
    val entries: List<SufiEntry> get() = _entries

    private val _savedIds = MutableStateFlow<Set<String>>(emptySet())
    val savedIds: StateFlow<Set<String>> = _savedIds.asStateFlow()

    private val _currentLanguage = MutableStateFlow(SufiLanguage.ENGLISH)
    val currentLanguage: StateFlow<SufiLanguage> = _currentLanguage.asStateFlow()

    private var lastSelectedId: String? = null

    init {
        loadLanguagePreference()
        loadSavedFavorites()
        loadDataset()
    }

    private fun loadLanguagePreference() {
        val savedLang = prefs.getString("pref_language", SufiLanguage.ENGLISH.name)
        _currentLanguage.value = try {
            SufiLanguage.valueOf(savedLang ?: SufiLanguage.ENGLISH.name)
        } catch (e: Exception) {
            SufiLanguage.ENGLISH
        }
    }

    fun setLanguage(language: SufiLanguage) {
        _currentLanguage.value = language
        prefs.edit().putString("pref_language", language.name).apply()
    }

    private fun loadSavedFavorites() {
        val set = prefs.getStringSet("saved_entries_ids", emptySet()) ?: emptySet()
        _savedIds.value = set
    }

    fun toggleSave(id: String) {
        val current = _savedIds.value.toMutableSet()
        if (current.contains(id)) {
            current.remove(id)
        } else {
            current.add(id)
        }
        _savedIds.value = current
        prefs.edit().putStringSet("saved_entries_ids", current).apply()
    }

    fun isSaved(id: String): Boolean = _savedIds.value.contains(id)

    fun getSavedEntries(): List<SufiEntry> {
        val saved = _savedIds.value
        return _entries.filter { saved.contains(it.id) }
    }

    fun getRandomEntry(): SufiEntry {
        if (_entries.isEmpty()) {
            return fallbackQuotes.first()
        }
        if (_entries.size == 1) return _entries.first()

        // Avoid showing the same entry twice in a row
        val candidateList = _entries.filter { it.id != lastSelectedId }
        val selected = if (candidateList.isNotEmpty()) {
            candidateList.random()
        } else {
            _entries.random()
        }
        lastSelectedId = selected.id
        return selected
    }

    private fun loadDataset() {
        _entries.clear()
        var loadedFromAssets = false

        try {
            context.assets.open("sufi_content.json").use { inputStream ->
                val reader = InputStreamReader(inputStream)
                val jsonString = reader.readText()
                val jsonArray = JSONArray(jsonString)

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val id = obj.optString("id", "entry_$i")
                    val type = obj.optString("type", "thought")
                    val en = obj.optString("en", "")
                    val ml = obj.optString("ml", "")
                    val author = if (obj.has("author")) obj.getString("author") else null
                    val theme = if (obj.has("theme")) obj.getString("theme") else null

                    if (en.isNotBlank() || ml.isNotBlank()) {
                        _entries.add(
                            SufiEntry(
                                id = id,
                                type = type,
                                en = if (en.isNotBlank()) en else ml,
                                ml = if (ml.isNotBlank()) ml else en,
                                author = author,
                                theme = theme
                            )
                        )
                    }
                }
                if (_entries.isNotEmpty()) {
                    loadedFromAssets = true
                }
            }
        } catch (e: Exception) {
            loadedFromAssets = false
        }

        if (!loadedFromAssets || _entries.isEmpty()) {
            // Load embedded comprehensive collection
            _entries.addAll(fallbackQuotes)
            _entries.addAll(fallbackThoughts)
        }
    }

    companion object {
        val fallbackQuotes = listOf(
            SufiEntry(
                id = "q_rumi_1",
                type = "quote",
                author = "Rumi",
                en = "The wound is the place where the Light enters you.",
                ml = "മുറിവാണ് വെളിച്ചം നിന്നിലേക്ക് പ്രവേശിക്കുന്ന ഇടം.",
                theme = "Wisdom"
            ),
            SufiEntry(
                id = "q_rumi_2",
                type = "quote",
                author = "Rumi",
                en = "Do not grieve. Anything you lose comes round in another form.",
                ml = "ദുഃഖിക്കരുത്; നിങ്ങൾ നഷ്ടപ്പെടുത്തിയതെല്ലാം മറ്റൊരു രൂപത്തിൽ നിങ്ങളിലേക്ക് മടങ്ങിവരും.",
                theme = "Patience"
            ),
            SufiEntry(
                id = "q_rumi_3",
                type = "quote",
                author = "Rumi",
                en = "Silence is the language of God, all else is poor translation.",
                ml = "മൗനമാണ് ദൈവത്തിന്റെ ഭാഷ, ബാക്കിയെല്ലാം കേവലം അപൂർണ്ണമായ തർജ്ജമകൾ മാത്രം.",
                theme = "Silence"
            ),
            SufiEntry(
                id = "q_rumi_4",
                type = "quote",
                author = "Rumi",
                en = "You are not a drop in the ocean. You are the entire ocean, in a drop.",
                ml = "നീ സമുദ്രത്തിലെ ഒരു തുള്ളിയല്ല; ഒരു തുള്ളിയിൽ അടങ്ങിയ മുഴുവൻ സമുദ്രവുമാണ്.",
                theme = "Unity"
            ),
            SufiEntry(
                id = "q_rumi_5",
                type = "quote",
                author = "Rumi",
                en = "Let the beauty of what you love be what you do.",
                ml = "നീ സ്നേഹിക്കുന്നതിന്റെ സൗന്ദര്യമായിരിക്കട്ടെ നിന്റെ കർമ്മങ്ങൾ.",
                theme = "Love"
            ),
            SufiEntry(
                id = "q_ibn_arabi_1",
                type = "quote",
                author = "Ibn Arabi",
                en = "My heart has become capable of every form: a pasture for gazelles, a cloister for monks, a temple for idols, and the Kaaba for the pilgrim.",
                ml = "എന്റെ ഹൃദയം സകല രൂപങ്ങളെയും ഉൾക്കൊള്ളാൻ പര്യാപ്തമായിരിക്കുന്നു: മാനുകൾക്ക് മേച്ചിൽപ്പുറവും, സന്യാസിമാർക്ക് ആശ്രമവും, തീർത്ഥാടകർക്ക് കഅബയുമായി.",
                theme = "Love"
            ),
            SufiEntry(
                id = "q_ibn_arabi_2",
                type = "quote",
                author = "Ibn Arabi",
                en = "If the believer understood the meaning of the saying 'the color of the water is the color of the receptacle', he would admit the validity of all beliefs.",
                ml = "പാത്രത്തിന്റെ നിറമാണ് ജലത്തിന്റെ നിറം എന്ന സത്യം മനസ്സിലാക്കിയാൽ, അവൻ എല്ലാ വിശ്വാസങ്ങളിലെയും ആത്മാർത്ഥതയെ ആദരിക്കും.",
                theme = "Unity"
            ),
            SufiEntry(
                id = "q_rabia_1",
                type = "quote",
                author = "Rabia al-Adawiyya",
                en = "If I adore You out of fear of Hell, burn me in Hell; if I adore You out of hope of Paradise, exclude me from Paradise. But if I adore You for Your own sake, do not withhold Your beauty.",
                ml = "നരകഭയത്താലാണ് ഞാൻ നിന്നെ സ്നേഹിക്കുന്നതെങ്കിൽ എന്നെ നരകത്തിലിടുക; സ്വർഗ്ഗമോഹത്താലാണെങ്കിൽ എന്നെ തടയുക. നിന്നെ മാത്രം കൊതിച്ചാണെങ്കിൽ നിന്റെ സൗന്ദര്യം എന്നിൽ നിന്ന് മറയ്ക്കരുതേ.",
                theme = "Surrender"
            ),
            SufiEntry(
                id = "q_rabia_2",
                type = "quote",
                author = "Rabia al-Adawiyya",
                en = "My peace is in solitude, and my beloved is forever with me.",
                ml = "ഏകാന്തതയിലാണ് എന്റെ ശാന്തി; എന്റെ പ്രിയൻ എന്നെന്നും എന്നോടൊപ്പമുണ്ട്.",
                theme = "Silence"
            ),
            SufiEntry(
                id = "q_ghazali_1",
                type = "quote",
                author = "Al-Ghazali",
                en = "To get what you love, you must first be patient with what you dislike.",
                ml = "നിങ്ങൾ കൊതിക്കുന്നത് നേടാൻ, നിങ്ങൾക്ക് അനിഷ്ടമായതിനെ ക്ഷമയോടെ നേരിടുക.",
                theme = "Patience"
            ),
            SufiEntry(
                id = "q_ghazali_2",
                type = "quote",
                author = "Al-Ghazali",
                en = "The real journey begins inside. When you clear the mirror of the heart, the world reflects the divine.",
                ml = "യഥാർത്ഥ യാത്ര ആരംഭിക്കുന്നത് ഉള്ളിലാണ്. ഹൃദയത്തിന്റെ കണ്ണാടി ശുദ്ധമാകുമ്പോൾ ലോകം ദൈവികതയെ പ്രതിഫലിപ്പിക്കുന്നു.",
                theme = "Ego"
            ),
            SufiEntry(
                id = "q_hafez_1",
                type = "quote",
                author = "Hafez",
                en = "Even after all this time, the Sun never says to the Earth, 'You owe me.' Look what happens with a love like that, it lights the whole sky.",
                ml = "ഇത്രയേറെ കാലമായിട്ടും സൂര്യൻ ഭൂമിയോട് 'നീയെനിക്ക് കടപ്പെട്ടിരിക്കുന്നു' എന്ന് പറഞ്ഞിട്ടില്ല. അത്തരം സ്നേഹം നോക്കൂ, അത് ആകാശമാകെ പ്രകാശിപ്പിക്കുന്നു.",
                theme = "Love"
            ),
            SufiEntry(
                id = "q_hafez_2",
                type = "quote",
                author = "Hafez",
                en = "Stay close to anything that makes you glad you are alive.",
                ml = "ജീവിച്ചിരിക്കുന്നതിൽ സന്തോഷം നൽകുന്ന എന്തിനോടും ചേർന്നുനിൽക്കുക.",
                theme = "Gratitude"
            ),
            SufiEntry(
                id = "q_attar_1",
                type = "quote",
                author = "Farid ud-Din Attar",
                en = "All the birds searched across the world for the King, only to discover at the journey's end that the King was within them all along.",
                ml = "പക്ഷികളെല്ലാം രാജാവിനെ തേടി ലോകമാകെ അലഞ്ഞു; യാത്രയുടെ ഒടുവിൽ അവർ കണ്ടെത്തി, രാജാവ് ഉള്ളിൽ തന്നെയുണ്ടായിരുന്നുവെന്ന്.",
                theme = "Wisdom"
            ),
            SufiEntry(
                id = "q_bayazid_1",
                type = "quote",
                author = "Bayazid Bastami",
                en = "I stood before the door of the Divine for thirty years, and when I looked closely, I saw that the door had been open all along.",
                ml = "മുപ്പത് വർഷം ഞാൻ ദൈവിക വാതിലിനു മുന്നിൽ കാത്തുനിന്നു; ഒടുവിൽ സൂക്ഷിച്ചു നോക്കിയപ്പോൾ കണ്ടു, ആ വാതിൽ എപ്പോഴും തുറന്നുതന്നെ കിടക്കുകയായിരുന്നു.",
                theme = "Presence"
            ),
            SufiEntry(
                id = "q_junayd_1",
                type = "quote",
                author = "Junayd al-Baghdadi",
                en = "Sufism is that God should make you die to yourself and live in Him.",
                ml = "നിന്റെ അഹംഭാവം മരിക്കുകയും, അവനിൽ നീ ജീവിക്കുകയും ചെയ്യുന്ന അവസ്ഥയാണ് സൂഫിസം.",
                theme = "Humility"
            ),
            SufiEntry(
                id = "q_jami_1",
                type = "quote",
                author = "Jami",
                en = "In the market of existence, buy nothing but love.",
                ml = "ജീവിതത്തിന്റെ ചന്തയിൽ നിന്ന് സ്നേഹമല്ലാതെ മറ്റൊന്നും വാങ്ങരുത്.",
                theme = "Love"
            ),
            SufiEntry(
                id = "q_saadi_1",
                type = "quote",
                author = "Saadi Shirazi",
                en = "Human beings are members of a whole, in related creation of one essence and soul. If one member is afflicted with pain, other members uneasy will remain.",
                ml = "മനുഷ്യരെല്ലാം ഒരേ ശരീരത്തിന്റെ ഭാഗങ്ങളാണ്; ഒരാൾക്ക് വേദനിക്കുമ്പോൾ ബാക്കിയുള്ളവർക്കും ശാന്തി നഷ്ടപ്പെടുന്നു.",
                theme = "Unity"
            ),
            SufiEntry(
                id = "q_shams_1",
                type = "quote",
                author = "Shams Tabrizi",
                en = "Whatever happens in your life, no matter how troubling things may seem, do not enter the neighborhood of despair. Even when all doors remain closed, God will open a new path only for you.",
                ml = "ജീവിതത്തിൽ എന്തു സംഭവിച്ചാലും നിരാശയുടെ വഴിയിലേക്ക് പോകരുത്. എല്ലാ വാതിലുകളും അടയുമ്പോഴും, ദൈവം നിങ്ങൾക്കായി മാത്രം ഒരു പുതിയ വഴി തുറക്കും.",
                theme = "Surrender"
            ),
            SufiEntry(
                id = "q_hallaj_1",
                type = "quote",
                author = "Mansur Al-Hallaj",
                en = "I saw my Lord with the eye of the heart. I said: Who art Thou? He said: Thou.",
                ml = "ഹൃദയത്തിന്റെ കണ്ണുകൊണ്ട് ഞാൻ എന്റെ നാഥനെ കണ്ടു. 'നീ ആരാണ്?' ഞാൻ ചോദിച്ചു; 'നീ തന്നെയാണ്' അവൻ മൊഴിഞ്ഞു.",
                theme = "Unity"
            )
        )

        val fallbackThoughts = listOf(
            // Love (ഇഷ്ഖ്)
            SufiEntry(
                id = "t_love_1",
                type = "thought",
                theme = "Love",
                en = "Love does not ask why the night is dark; it simply kindles a small flame.",
                ml = "രാത്രി എന്തിനാണ് ഇരുണ്ടതെന്ന് സ്നേഹം ചോദിക്കുന്നില്ല; അത് വെറുതെ ഒരു ചെറിയ ദീപം തെളിയിക്കുന്നു."
            ),
            SufiEntry(
                id = "t_love_2",
                type = "thought",
                theme = "Love",
                en = "When you love without demanding an echo, every wind brings you sweetness.",
                ml = "പ്രതിധ്വനി ആഗ്രഹിക്കാതെ സ്നേഹിക്കുമ്പോൾ, ഓരോ കാറ്റും നിന്നിലേക്ക് മാധുര്യം കൊണ്ടുവരുന്നു."
            ),
            SufiEntry(
                id = "t_love_3",
                type = "thought",
                theme = "Love",
                en = "The heart that is cracked is simply making room for a greater love.",
                ml = "വിണ്ടുകീറിയ ഹൃദയം, വലിയൊരു സ്നേഹത്തിനായി ഇടമൊരുക്കുക മാത്രമാണ് ചെയ്യുന്നത്."
            ),
            SufiEntry(
                id = "t_love_4",
                type = "thought",
                theme = "Love",
                en = "Do not seek love outside; seek only to dismantle the walls you built against it.",
                ml = "പുറത്ത് സ്നേഹം തിരയരുത്; സ്നേഹത്തിനെതിരെ നീ തീർത്ത മതിലുകൾ തകർക്കുക മാത്രം ചെയ്യുക."
            ),

            // Silence (മൗനം)
            SufiEntry(
                id = "t_silence_1",
                type = "thought",
                theme = "Silence",
                en = "In the deep quiet of your chest, an unwritten answer is waiting for the noise to subside.",
                ml = "നിന്റെ നെഞ്ചിലെ ആഴമേറിയ നിശബ്ദതയിൽ, ബഹളങ്ങൾ അടങ്ങാൻ കാത്തുനിൽക്കുന്ന ഒരു ഉത്തരമുണ്ട്."
            ),
            SufiEntry(
                id = "t_silence_2",
                type = "thought",
                theme = "Silence",
                en = "When words become too heavy to carry, lay them down in silence.",
                ml = "വാക്കുകൾ ചുമക്കാൻ ഭാരമാകുമ്പോൾ, അവയെ മൗനത്തിൽ ഇറക്കിവെക്കുക."
            ),
            SufiEntry(
                id = "t_silence_3",
                type = "thought",
                theme = "Silence",
                en = "Silence is not the absence of sound; it is the presence of everything that matters.",
                ml = "മൗനം ശബ്ദത്തിന്റെ അഭാവമല്ല; അത് അർത്ഥമുള്ള എല്ലാറ്റിന്റെയും സാന്നിധ്യമാണ്."
            ),
            SufiEntry(
                id = "t_silence_4",
                type = "thought",
                theme = "Silence",
                en = "Sit quietly for a moment. The storm outside cannot enter unless you invite it in.",
                ml = "ഒരു നിമിഷം ശാന്തമായിരിക്കൂ. പുറത്തെ കൊടുങ്കാറ്റിന് നിന്റെ ഉള്ളിലേക്ക് വരാനാകില്ല, നീ ക്ഷണിച്ചില്ലെങ്കിൽ."
            ),

            // Patience (ക്ഷമ / സബ്ർ)
            SufiEntry(
                id = "t_patience_1",
                type = "thought",
                theme = "Patience",
                en = "The seed does not rush the soil; in the dark, it quietly prepares its blossom.",
                ml = "വിത്ത് മണ്ണിനോട് ധൃതി കൂട്ടുന്നില്ല; ഇരുട്ടിൽ അത് പൂവണിയാൻ നിശബ്ദമായി ഒരുങ്ങുന്നു."
            ),
            SufiEntry(
                id = "t_patience_2",
                type = "thought",
                theme = "Patience",
                en = "Patience is not waiting passively; it is looking at the thorn and already seeing the rose.",
                ml = "ക്ഷമ എന്നത് വെറുതെ കാത്തിരിക്കലല്ല; മുള്ളിലേക്ക് നോക്കുമ്പോഴും റോസാപ്പൂവിനെ കാണാനുള്ള ദൃഷ്ടിയാണ്."
            ),
            SufiEntry(
                id = "t_patience_3",
                type = "thought",
                theme = "Patience",
                en = "This heavy hour too is a river; it does not stop, it carries you forward to dawn.",
                ml = "ഈ ഭാരമേറിയ നിമിഷവും ഒരു പുഴയാണ്; അത് നിൽക്കില്ല, പ്രഭാതത്തിലേക്ക് നിന്നെ അത് ഒഴുക്കിക്കൊണ്ടുപോകും."
            ),
            SufiEntry(
                id = "t_patience_4",
                type = "thought",
                theme = "Patience",
                en = "Trust the delay. What is meant for you will not pass you by.",
                ml = "താമസത്തെ വിശ്വസിക്കൂ. നിനക്കായി എഴുതപ്പെട്ടത് നിന്നെ വിട്ടുപോകില്ല."
            ),

            // Ego (നഫ്സ് / അഹംഭാവം)
            SufiEntry(
                id = "t_ego_1",
                type = "thought",
                theme = "Ego",
                en = "When you drop the burden of needing to prove yourself, your soul feels weightless.",
                ml = "സ്വയം തെളിയിക്കണമെന്ന വാശി ഉപേക്ഷിക്കുമ്പോൾ, ആത്മാവിന് ഭാരമില്ലാതാകുന്നു."
            ),
            SufiEntry(
                id = "t_ego_2",
                type = "thought",
                theme = "Ego",
                en = "The cup must empty itself before it can receive the wine of tranquility.",
                ml = "ശാന്തിയുടെ പാനീയം നിറയ്ക്കപ്പെടാൻ, കോപ്പ ആദ്യം സ്വയം ശൂന്യമാകണം."
            ),
            SufiEntry(
                id = "t_ego_3",
                type = "thought",
                theme = "Ego",
                en = "Do not fight your shadows; turn on the inner lamp and watch them dissolve.",
                ml = "നിഴലുകളോട് പോരാടരുത്; ഉള്ളിലെ ദീപം കൊളുത്തുമ്പോൾ അവ തനിയെ മാഞ്ഞുപോകും."
            ),

            // Presence (സാന്നിധ്യം / ഹുദൂർ)
            SufiEntry(
                id = "t_presence_1",
                type = "thought",
                theme = "Presence",
                en = "Take one gentle breath. This breath is all the world asks of you right now.",
                ml = "ഒരു ദീർഘശ്വാസമെടുക്കൂ. ഈ നിമിഷം ഈ ലോകം നിന്നോട് ആവശ്യപ്പെടുന്നത് ഇത്രമാത്രമാണ്."
            ),
            SufiEntry(
                id = "t_presence_2",
                type = "thought",
                theme = "Presence",
                en = "Yesterday is a folded scroll; tomorrow is an unlit lamp. Only this breath belongs to you.",
                ml = "ഇന്നലെ മടക്കിവെച്ച താളാണ്; നാളെ കൊളുത്താത്ത ദീപവും. ഈ ശ്വാസം മാത്രമാണ് നിന്റേത്."
            ),
            SufiEntry(
                id = "t_presence_3",
                type = "thought",
                theme = "Presence",
                en = "Be here completely. The universe is speaking only to the one who is listening now.",
                ml = "പൂർണ്ണമായും ഇവിടെയായിരിക്കൂ. ഇപ്പോൾ ശ്രദ്ധിക്കുന്നവനോട് മാത്രമാണ് പ്രപഞ്ചം സംസാരിക്കുന്നത്."
            ),

            // Gratitude (ശുക്ർ / കൃതജ്ഞത)
            SufiEntry(
                id = "t_gratitude_1",
                type = "thought",
                theme = "Gratitude",
                en = "Even in dry seasons, give thanks for the root that still drinks from unseen depths.",
                ml = "വരൾച്ചയിലും, അദൃശ്യമായ ആഴങ്ങളിൽ നിന്ന് നീരുറവ കുടിക്കുന്ന വേരുകൾക്കായി നന്ദി പറയുക."
            ),
            SufiEntry(
                id = "t_gratitude_2",
                type = "thought",
                theme = "Gratitude",
                en = "Gratitude is the gentle key that turns ordinary air into a garden of peace.",
                ml = "സാധാരണ വായുവിനെപ്പോലും ശാന്തിയുടെ പൂന്തോട്ടമാക്കി മാറ്റുന്ന താക്കോലാണ് കൃതജ്ഞത."
            ),
            SufiEntry(
                id = "t_gratitude_3",
                type = "thought",
                theme = "Gratitude",
                en = "When you thank life for the small light, the darkness loses its power over you.",
                ml = "ചെറിയൊരു വെളിച്ചത്തിനും നന്ദി പറയുമ്പോൾ, ഇരുട്ടിന് നിന്റെമേലുള്ള അധികാരം നഷ്ടപ്പെടുന്നു."
            ),

            // Humility (വിനയം)
            SufiEntry(
                id = "t_humility_1",
                type = "thought",
                theme = "Humility",
                en = "Water flows to the lowest ground, and that is why it gives life to all things.",
                ml = "വെള്ളം ഏറ്റവും താഴ്ന്ന ഇടങ്ങളിലേക്കാണ് ഒഴുകുന്നത്; അതുകൊണ്ടാണ് അത് സകലതിനും ജീവൻ നൽകുന്നത്."
            ),
            SufiEntry(
                id = "t_humility_2",
                type = "thought",
                theme = "Humility",
                en = "Bend like the reed in the stream; it bends with the current and never breaks.",
                ml = "പുഴയിലെ ഞാങ്ങണയെപ്പോലെ വളയുക; അത് ഒഴുക്കിനൊപ്പം വളയുന്നു, ഒരിക്കലും ഒടിയുന്നില്ല."
            ),
            SufiEntry(
                id = "t_humility_3",
                type = "thought",
                theme = "Humility",
                en = "The earth carries everyone gently without asking for praise.",
                ml = "പ്രശംസ ആഗ്രഹിക്കാതെയാണ് ഭൂമി എല്ലാവരെയും സ്നേഹത്തോടെ താങ്ങിനിർത്തുന്നത്."
            ),

            // Unity (തൗഹീദ് / ഏകാത്മത)
            SufiEntry(
                id = "t_unity_1",
                type = "thought",
                theme = "Unity",
                en = "Every river is heading to the same ocean, no matter the bends along the way.",
                ml = "എത്ര വളവുകൾ തിരിഞ്ഞാലും, എല്ലാ പുഴകളും ഒഴുകിയെത്തുന്നത് ഒരേ കടലിലേക്കാണ്."
            ),
            SufiEntry(
                id = "t_unity_2",
                type = "thought",
                theme = "Unity",
                en = "Look into another's sorrow, and you will see your own face softened by understanding.",
                ml = "മറ്റൊരാളുടെ കണ്ണീരിലേക്ക് നോക്കൂ; അവിടെ നീ കാണുന്നത് നിന്റെ സ്വന്തം വേദനയുടെ പ്രതിഫലനമാണ്."
            ),
            SufiEntry(
                id = "t_unity_3",
                type = "thought",
                theme = "Unity",
                en = "We are all notes in one grand melody; play your part with kindness.",
                ml = "നാം ഒരൊറ്റ വലിയ സംഗീതത്തിന്റെ ഭാഗങ്ങളാണ്; ദയയോടെ നിന്റെ സ്വരം മീട്ടുക."
            ),

            // Surrender (തവക്കുൽ / സമർപ്പണം)
            SufiEntry(
                id = "t_surrender_1",
                type = "thought",
                theme = "Surrender",
                en = "Let go of the oars for a moment; the current knows where to take you.",
                ml = "ഒരു നിമിഷം തുഴകൾ താഴെ വെക്കുക; നിന്നെ എങ്ങോട്ടാണ് കൊണ്ടുപോകേണ്ടതെന്ന് ഒഴുക്കിനറിയാം."
            ),
            SufiEntry(
                id = "t_surrender_2",
                type = "thought",
                theme = "Surrender",
                en = "When you release what is slipping away, your hands are free to receive what is arriving.",
                ml = "കൈവിട്ടുപോകുന്നതിനെ വിട്ടുകൊടുക്കുമ്പോൾ, കടന്നുവരുന്നതിനെ സ്വീകരിക്കാൻ നിന്റെ കൈകൾ സ്വതന്ത്രമാകുന്നു."
            ),
            SufiEntry(
                id = "t_surrender_3",
                type = "thought",
                theme = "Surrender",
                en = "Surrender is not defeat; it is the ultimate courage of placing your heart in gentle hands.",
                ml = "സമർപ്പണം പരാജയമല്ല; അത് സ്വന്തം ഹൃദയത്തെ കാരുണ്യത്തിന്റെ കൈകളിൽ ഏൽപ്പിക്കാനുള്ള ധൈര്യമാണ്."
            ),

            // Wisdom (ഹിക്മത്ത് / ജ്ഞാനം)
            SufiEntry(
                id = "t_wisdom_1",
                type = "thought",
                theme = "Wisdom",
                en = "The pain that awakens you is more precious than the comfort that puts you to sleep.",
                ml = "നിന്നെ ഉണർത്തുന്ന വേദന, നിന്നെ മയക്കിക്കിടത്തുന്ന സുഖത്തേക്കാൾ വിലയേറിയതാണ്."
            ),
            SufiEntry(
                id = "t_wisdom_2",
                type = "thought",
                theme = "Wisdom",
                en = "Do not be alarmed by the crumbling of what was frail; the eternal foundation remains.",
                ml = "തകരുന്നതിനെ ഓർത്ത് ഭയപ്പെടേണ്ട; ശാശ്വതമായ അടിത്തറ എപ്പോഴും ഉറച്ചുനിൽക്കുന്നുണ്ട്."
            ),
            SufiEntry(
                id = "t_wisdom_3",
                type = "thought",
                theme = "Wisdom",
                en = "Knowledge speaks, but wisdom listens to the quiet between the words.",
                ml = "അറിവ് സംസാരിക്കുന്നു; എന്നാൽ വാക്കുകൾക്കിടയിലെ മൗനത്തെ കേൾക്കുന്നതാണ് ജ്ഞാനം."
            ),
            SufiEntry(
                id = "t_wisdom_4",
                type = "thought",
                theme = "Wisdom",
                en = "Everything has meaning, even this stillness you are holding in your chest right now.",
                ml = "എല്ലാറ്റിനും ഒരു അർത്ഥമുണ്ട്; ഇപ്പോൾ നിന്റെ നെഞ്ചിൽ തങ്ങിനിൽക്കുന്ന ഈ നിശബ്ദതയ്ക്ക് പോലും."
            )
        )
    }
}
