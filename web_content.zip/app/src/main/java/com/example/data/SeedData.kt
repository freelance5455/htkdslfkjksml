package com.example.data

import com.example.data.model.StudentRowData
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SeedData {
    const val DEFAULT_SCHOOL_ID = "almustafa_hifz"
    const val BOOTSTRAPPED_ADMIN_EMAIL = "hafizhanzala106@gmail.com"
    const val DEFAULT_TITLE = "ڈیلی رپورٹ کلاس حفظ القرآن"
    const val DEFAULT_CENTRE = "المصطفیٰ اسلامک سنٹر ڈی سی کالونی گوجرانوالہ"
    const val DEFAULT_ADMIN_PIN = "1234"
    const val DEFAULT_C1_PIN = "1111"
    const val DEFAULT_C2_PIN = "2222"
    const val SEED_DATE = "2026-11-21"

    val URDU_DAYS = listOf("اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ")

    data class ClassSeed(
        val id: String,
        val name: String,
        val pin: String,
        val sortOrder: Long,
        val names: List<String>,
        val sp: List<String>,
        val restSp: String,
        val tl: List<String>,
        val td: List<String>
    )

    val CLASS_SEEDS = listOf(
        ClassSeed(
            id = "c1",
            name = "صدیق اکبر",
            pin = DEFAULT_C1_PIN,
            sortOrder = 0L,
            names = listOf(
                "صارم سہیل", "حذیفہ شفیق", "محمد احمد عابد", "حجل ذوالفقار", "حسنین شبیر",
                "محمد کلیم اللہ", "محمد عبدالرافع", "کامل فیاض", "علیان تنویر", "معصم ذیشان",
                "احمد", "احمد عمران", "محمد موسیٰ عثمان", "عاشر نعیم", "موسیٰ یاسین",
                "محمد عبدالہادی", "محمد ابوہریرہ", "ارحم مصدق", "اریب ظہور", "عبداللہ فاروق",
                "ریحان مستنصر"
            ),
            sp = listOf("25", "29", "23", "5", "4", "12", "11", "12", "11", "16", "23"),
            restSp = "منزل",
            tl = listOf("16", "08", "13", "18", "24", "18", "16", "16", "18", "", "14"),
            td = listOf("2026-11-19", "", "2026-11-07", "2026-10-26", "2026-10-23", "2026-12-01", "", "2026-11-29", "", "", "")
        ),
        ClassSeed(
            id = "c2",
            name = "فاروق اعظم",
            pin = DEFAULT_C2_PIN,
            sortOrder = 1L,
            names = listOf(
                "ابراہیم طاہر", "عبیدالرحمن", "زین خالد", "حیدر علی", "انس اویس",
                "سید عبداللہ زمان", "ذیشان عثمان", "احمد فواد", "احمد سلطان", "محمد بن زاہد",
                "عبداللہ عمران", "سید انس ثاقب", "محمد سعود", "عبدالرافع وسیم", "ابراہیم منیب",
                "عدنان فیصل", "احمد اعجاز", "طٰہٰ", "یحییٰ"
            ),
            sp = listOf("22", "23", "24", "28", "27", "26", "28", "28", "27", "29", "29", "29", "29", "28", "29"),
            restSp = "نظرہ",
            tl = listOf("18", "18", "20", "12", "12", "12", "10", "15", "12", "08", "12", "12", "08", "12", "08"),
            td = listOf(
                "2026-11-15", "2026-11-23", "2026-11-30", "2026-11-21", "2026-11-11",
                "2026-12-04", "2026-11-06", "2026-12-03", "2026-11-28", "2026-11-20",
                "2026-10-25", "2026-11-25", "2026-10-24", "2026-11-18", "2026-10-21"
            )
        )
    )

    fun seedRowsFor(seed: ClassSeed): Map<String, Map<String, Any>> {
        val rows = mutableMapOf<String, Map<String, Any>>()
        seed.names.forEachIndexed { idx, _ ->
            val stuNum = (idx + 1).toString()
            val row = StudentRowData(
                sp = if (idx < seed.sp.size) seed.sp[idx] else seed.restSp,
                tl = seed.tl.getOrElse(idx) { "" },
                td = seed.td.getOrElse(idx) { "" }
            ).toFirestoreMap()
            if (row.isNotEmpty()) {
                rows[stuNum] = row
            }
        }
        return rows
    }

    fun todayIso(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun urduDayForIso(dateIso: String): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val parsed = sdf.parse(dateIso) ?: return ""
            val cal = java.util.Calendar.getInstance()
            cal.time = parsed
            val dayOfWeek = cal.get(java.util.Calendar.DAY_OF_WEEK) // Sunday = 1 .. Saturday = 7
            URDU_DAYS.getOrElse(dayOfWeek - 1) { "" }
        } catch (_: Exception) {
            ""
        }
    }

    fun normalizeDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '\u0660'..'\u0669' -> sb.append(('0'.code + (ch.code - 0x0660)).toChar())
                in '\u06F0'..'\u06F9' -> sb.append(('0'.code + (ch.code - 0x06F0)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun parseNumeric(input: String): Double {
        return normalizeDigits(input).trim().toDoubleOrNull() ?: 0.0
    }
}
