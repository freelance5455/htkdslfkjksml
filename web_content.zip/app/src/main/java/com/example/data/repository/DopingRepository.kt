package com.example.data.repository

import android.content.Context
import com.example.data.model.ExamType
import com.example.data.model.Question
import com.example.data.model.StorageBreakdown
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.SubjectProgress
import com.example.data.model.TestCategory
import com.example.data.model.TopicLecture
import com.example.data.model.UserProgress
import com.example.data.storage.DopingStorageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class DopingRepository(context: Context? = null) {

  private val storageManager: DopingStorageManager? = context?.let { DopingStorageManager(it) }

  private val _userProgress = MutableStateFlow(
    storageManager?.loadUserProgress() ?: defaultUserProgress()
  )
  val userProgress: StateFlow<UserProgress> = _userProgress.asStateFlow()

  private val _tasks = MutableStateFlow(
    storageManager?.loadTasks() ?: initialTasks()
  )
  val tasks: StateFlow<List<StudyTask>> = _tasks.asStateFlow()

  private val _topics = MutableStateFlow(initialTopics())
  val topics: StateFlow<List<TopicLecture>> = _topics.asStateFlow()

  private val _questions = MutableStateFlow(initialQuestions())
  val questions: StateFlow<List<Question>> = _questions.asStateFlow()

  private val _subjectProgress = MutableStateFlow(
    storageManager?.loadSubjectProgress() ?: defaultSubjectProgress()
  )
  val subjectProgress: StateFlow<Map<Subject, SubjectProgress>> = _subjectProgress.asStateFlow()

  private val _storageBreakdown = MutableStateFlow(
    StorageBreakdown(
      isAllOfflineDownloaded = storageManager?.isOfflineDownloaded() ?: false
    )
  )
  val storageBreakdown: StateFlow<StorageBreakdown> = _storageBreakdown.asStateFlow()

  val testCategories: List<TestCategory> by lazy {
    buildTestCategories(_questions.value)
  }

  val coachingTips = listOf(
    "Koçun Tavsiyesi: Matematikte Fonksiyonlar konusunu bitirdikten sonra hemen 20 soru çöz. 24 saat sonra hafıza tekrarı yapmayı unutma!",
    "Hafıza Refleksi: Tarihteki kongreleri kronolojik olarak kodlamadan geçme. 'HAMAS' (Havza, Amasya, Erzurum, Sivas) sırasını gözünde canlandır.",
    "Bireysel Strateji: Deneme sınavlarında Türkçe paragraf sorularında önce soru kökünü, sonra şıkları tara. Bu sana her soruda 18 saniye kazandırır.",
    "Hata Kutusu Analizi: Hata defterinde bekleyen soruları çözerek netlerini +2 artırabilirsin!",
    "Takvim Planı: Akşam 20:00 için hatırlatıcı kurarak günlük paragraf ve formül tekrarını kaçırma."
  )

  fun setExam(exam: ExamType) {
    _userProgress.update {
      it.copy(
        selectedExam = exam,
        daysRemaining = exam.daysRemainingDefault,
        targetNet = exam.targetNetDefault
      )
    }
    storageManager?.saveUserProgress(_userProgress.value)
  }

  fun toggleTask(taskId: String) {
    _tasks.update { current ->
      current.map { task ->
        if (task.id == taskId) {
          val newCompleted = !task.isCompleted
          if (newCompleted) {
            _userProgress.update { up ->
              up.copy(
                todaySolvedQuestions = up.todaySolvedQuestions + task.targetQuestions,
                totalQuestionsSolved = up.totalQuestionsSolved + task.targetQuestions
              )
            }
          }
          task.copy(isCompleted = newCompleted)
        } else task
      }
    }
    storageManager?.saveTasks(_tasks.value)
    storageManager?.saveUserProgress(_userProgress.value)
  }

  fun addTask(
    title: String,
    subject: Subject,
    questions: Int,
    minutes: Int,
    priority: String,
    scheduledDate: String = "2026-11-12",
    reminderTime: String? = null,
    hasReminder: Boolean = false,
    notes: String = ""
  ) {
    val newTask = StudyTask(
      id = "task_${System.currentTimeMillis()}",
      title = title,
      subject = subject,
      targetQuestions = questions,
      targetMinutes = minutes,
      priority = priority,
      dayOfWeek = if (scheduledDate == "2026-11-12") "Bugün" else scheduledDate,
      scheduledDate = scheduledDate,
      reminderTime = reminderTime,
      hasReminder = hasReminder,
      notes = notes
    )
    _tasks.update { listOf(newTask) + it }
    storageManager?.saveTasks(_tasks.value)
  }

  fun toggleReminder(taskId: String) {
    _tasks.update { current ->
      current.map { task ->
        if (task.id == taskId) {
          val newHasReminder = !task.hasReminder
          task.copy(
            hasReminder = newHasReminder,
            reminderTime = if (newHasReminder && task.reminderTime == null) "19:00" else task.reminderTime
          )
        } else task
      }
    }
    storageManager?.saveTasks(_tasks.value)
  }

  fun deleteTask(taskId: String) {
    _tasks.update { current -> current.filterNot { it.id == taskId } }
    storageManager?.saveTasks(_tasks.value)
  }

  fun toggleTopicComplete(topicId: String) {
    _topics.update { list ->
      list.map { if (it.id == topicId) it.copy(isCompleted = !it.isCompleted) else it }
    }
    _userProgress.update { up ->
      val updated = up.completedTopicIds.toMutableSet()
      if (updated.contains(topicId)) updated.remove(topicId) else updated.add(topicId)
      up.copy(completedTopicIds = updated)
    }
    storageManager?.saveUserProgress(_userProgress.value)
  }

  fun toggleTopicFavorite(topicId: String) {
    _topics.update { list ->
      list.map { if (it.id == topicId) it.copy(isFavorite = !it.isFavorite) else it }
    }
    _userProgress.update { up ->
      val updated = up.favoriteTopicIds.toMutableSet()
      if (updated.contains(topicId)) updated.remove(topicId) else updated.add(topicId)
      up.copy(favoriteTopicIds = updated)
    }
    storageManager?.saveUserProgress(_userProgress.value)
  }

  fun recordQuestionAnswer(questionId: String, isCorrect: Boolean) {
    val question = _questions.value.find { it.id == questionId }
    val subject = question?.subject ?: Subject.MATEMATIK

    _userProgress.update { up ->
      val errorSet = up.errorNotebookQuestionIds.toMutableSet()
      if (!isCorrect) {
        errorSet.add(questionId)
      } else {
        errorSet.remove(questionId)
      }
      up.copy(
        totalQuestionsSolved = up.totalQuestionsSolved + 1,
        todaySolvedQuestions = up.todaySolvedQuestions + 1,
        totalCorrect = if (isCorrect) up.totalCorrect + 1 else up.totalCorrect,
        totalWrong = if (!isCorrect) up.totalWrong + 1 else up.totalWrong,
        errorNotebookQuestionIds = errorSet
      )
    }

    _subjectProgress.update { currentMap ->
      val currentSp = currentMap[subject] ?: SubjectProgress(subject = subject)
      val updatedSp = currentSp.copy(
        totalSolved = currentSp.totalSolved + 1,
        correctCount = if (isCorrect) currentSp.correctCount + 1 else currentSp.correctCount,
        wrongCount = if (!isCorrect) currentSp.wrongCount + 1 else currentSp.wrongCount,
        lastStudiedDate = "Bugün"
      )
      currentMap + (subject to updatedSp)
    }

    storageManager?.saveUserProgress(_userProgress.value)
    storageManager?.saveSubjectProgress(_subjectProgress.value)
  }

  fun toggleQuestionInErrorNotebook(questionId: String) {
    _userProgress.update { up ->
      val set = up.errorNotebookQuestionIds.toMutableSet()
      if (set.contains(questionId)) set.remove(questionId) else set.add(questionId)
      up.copy(errorNotebookQuestionIds = set)
    }
    storageManager?.saveUserProgress(_userProgress.value)
  }

  fun addStudyTime(minutes: Int) {
    _userProgress.update { up ->
      up.copy(
        todayStudiedMinutes = up.todayStudiedMinutes + minutes,
        totalStudyMinutes = up.totalStudyMinutes + minutes
      )
    }
    storageManager?.saveUserProgress(_userProgress.value)
  }

  fun toggleOfflineDownload() {
    val current = _storageBreakdown.value.isAllOfflineDownloaded
    val updated = !current
    _storageBreakdown.update {
      it.copy(
        isAllOfflineDownloaded = updated,
        offlineLecturesMb = if (updated) 1850 else 0
      )
    }
    storageManager?.setOfflineDownloaded(updated)
  }

  fun clearCache() {
    _storageBreakdown.update {
      it.copy(questionBankCacheMb = 20)
    }
    storageManager?.clearAppCache()
  }

  fun generateSmartCoachPlan(targetWeeklyHours: Int, examType: ExamType) {
    val newTasks = mutableListOf<StudyTask>()
    when (examType) {
      ExamType.YKS_TYT, ExamType.YKS_AYT -> {
        newTasks.add(StudyTask(id = "plan_1", title = "Matematik: Fonksiyonlar Hafıza Kartı + 25 Soru", subject = Subject.MATEMATIK, targetQuestions = 25, targetMinutes = 35, isCompleted = false, dayOfWeek = "Bugün", priority = "Yüksek", scheduledDate = "2026-11-12", reminderTime = "18:00", hasReminder = true))
        newTasks.add(StudyTask(id = "plan_2", title = "Edebiyat: Tanzimat 1. Dönem Şifreli Kodlamalar", subject = Subject.TURKCE_EDEBIYAT, targetQuestions = 20, targetMinutes = 30, isCompleted = false, dayOfWeek = "Bugün", priority = "Yüksek", scheduledDate = "2026-11-12", reminderTime = "20:00", hasReminder = true))
        newTasks.add(StudyTask(id = "plan_3", title = "Tarih: Kurtuluş Savaşı Kronolojisi Tekrarı", subject = Subject.TARIH, targetQuestions = 15, targetMinutes = 20, isCompleted = false, dayOfWeek = "Yarın", priority = "Orta", scheduledDate = "2026-11-13", reminderTime = "19:30", hasReminder = false))
        newTasks.add(StudyTask(id = "plan_4", title = "Biyoloji: Hücre Bölünmeleri İPMAT Kuralı", subject = Subject.BIYOLOJI, targetQuestions = 20, targetMinutes = 25, isCompleted = false, dayOfWeek = "Yarın", priority = "Orta", scheduledDate = "2026-11-13"))
        newTasks.add(StudyTask(id = "plan_5", title = "Coğrafya: Rüzgarlar ve Harita Şifreleri", subject = Subject.COGRAFYA, targetQuestions = 15, targetMinutes = 20, isCompleted = false, dayOfWeek = "Çarşamba", priority = "Orta", scheduledDate = "2026-11-14"))
        newTasks.add(StudyTask(id = "plan_6", title = "TYT Türkçe: 20 Paragraf Hız Denemesi", subject = Subject.TURKCE_EDEBIYAT, targetQuestions = 20, targetMinutes = 25, isCompleted = false, dayOfWeek = "Perşembe", priority = "Yüksek", scheduledDate = "2026-11-15"))
      }
      ExamType.LGS -> {
        newTasks.add(StudyTask(id = "plan_lgs_1", title = "Matematik: Çarpanlar ve Katlar EBOB-EKOK", subject = Subject.MATEMATIK, targetQuestions = 25, targetMinutes = 40, isCompleted = false, dayOfWeek = "Bugün", priority = "Yüksek", scheduledDate = "2026-11-12", reminderTime = "17:30", hasReminder = true))
        newTasks.add(StudyTask(id = "plan_lgs_2", title = "Fen Bilimleri: Mevsimler ve İklim", subject = Subject.BIYOLOJI, targetQuestions = 20, targetMinutes = 30, isCompleted = false, dayOfWeek = "Bugün", priority = "Yüksek", scheduledDate = "2026-11-12"))
        newTasks.add(StudyTask(id = "plan_lgs_3", title = "Türkçe: Cümlede Anlam & Mantık Muhakeme", subject = Subject.TURKCE_EDEBIYAT, targetQuestions = 20, targetMinutes = 30, isCompleted = false, dayOfWeek = "Yarın", priority = "Orta", scheduledDate = "2026-11-13"))
        newTasks.add(StudyTask(id = "plan_lgs_4", title = "İnkılap Tarihi: Bir Kahraman Doğuyor", subject = Subject.TARIH, targetQuestions = 15, targetMinutes = 20, isCompleted = false, dayOfWeek = "Yarın", priority = "Orta", scheduledDate = "2026-11-13"))
      }
      ExamType.KPSS -> {
        newTasks.add(StudyTask(id = "plan_kpss_1", title = "Tarih: Osmanlı Kuruluş ve Yükselme Dönemi", subject = Subject.TARIH, targetQuestions = 30, targetMinutes = 40, isCompleted = false, dayOfWeek = "Bugün", priority = "Yüksek", scheduledDate = "2026-11-12", reminderTime = "19:00", hasReminder = true))
        newTasks.add(StudyTask(id = "plan_kpss_2", title = "Coğrafya: Türkiye'nin Coğrafi Konumu & Platolar", subject = Subject.COGRAFYA, targetQuestions = 25, targetMinutes = 35, isCompleted = false, dayOfWeek = "Bugün", priority = "Yüksek", scheduledDate = "2026-11-12"))
        newTasks.add(StudyTask(id = "plan_kpss_3", title = "Matematik: Sayı ve Kesir Problemleri", subject = Subject.MATEMATIK, targetQuestions = 20, targetMinutes = 30, isCompleted = false, dayOfWeek = "Yarın", priority = "Orta", scheduledDate = "2026-11-13"))
        newTasks.add(StudyTask(id = "plan_kpss_4", title = "Vatandaşlık: Temel Hukuk Bilgisi", subject = Subject.TARIH, targetQuestions = 20, targetMinutes = 25, isCompleted = false, dayOfWeek = "Yarın", priority = "Orta", scheduledDate = "2026-11-13"))
      }
    }
    _tasks.value = newTasks
    storageManager?.saveTasks(newTasks)
  }

  fun getAchievementBadges(): List<com.example.data.model.AchievementBadge> {
    val up = _userProgress.value
    return listOf(
      com.example.data.model.AchievementBadge(
        id = "first_step",
        title = "İlk Adım",
        description = "İlk soruyu başarıyla çöz ve hazırlığa başla.",
        iconEmoji = "🏅",
        targetValue = 1,
        currentValue = up.totalQuestionsSolved,
        isUnlocked = up.totalQuestionsSolved >= 1
      ),
      com.example.data.model.AchievementBadge(
        id = "century",
        title = "100 Soru Kulübü",
        description = "100 soru barajını geçerek temelleri güçlendir.",
        iconEmoji = "💯",
        targetValue = 100,
        currentValue = up.totalQuestionsSolved,
        isUnlocked = up.totalQuestionsSolved >= 100
      ),
      com.example.data.model.AchievementBadge(
        id = "streak7",
        title = "7 Günlük Seri",
        description = "7 gün boyunca her gün düzenli ders çalış.",
        iconEmoji = "🔥",
        targetValue = 7,
        currentValue = up.streakDays,
        isUnlocked = up.streakDays >= 7
      ),
      com.example.data.model.AchievementBadge(
        id = "quarter_k",
        title = "250 Soru Ustası",
        description = "250 soru çözerek pratiklik kazan.",
        iconEmoji = "⚡",
        targetValue = 250,
        currentValue = up.totalQuestionsSolved,
        isUnlocked = up.totalQuestionsSolved >= 250
      ),
      com.example.data.model.AchievementBadge(
        id = "focus_champ",
        title = "Odak Şampiyonu",
        description = "Odaklanma sayacı ile 25 dk derin çalışma tamamla.",
        iconEmoji = "🎯",
        targetValue = 1,
        currentValue = 1,
        isUnlocked = true
      ),
      com.example.data.model.AchievementBadge(
        id = "grandmaster",
        title = "500 Soru Fatihi",
        description = "500 soru barajını aşarak şampiyonlar ligine gir.",
        iconEmoji = "👑",
        targetValue = 500,
        currentValue = up.totalQuestionsSolved,
        isUnlocked = up.totalQuestionsSolved >= 500
      )
    )
  }

  fun getDailySolvedTrend(): List<com.example.data.model.DailyTrendPoint> {
    val todayQuestions = _userProgress.value.todaySolvedQuestions
    return listOf(
      com.example.data.model.DailyTrendPoint("06 Kas", "2026-11-06", 28),
      com.example.data.model.DailyTrendPoint("07 Kas", "2026-11-07", 42),
      com.example.data.model.DailyTrendPoint("08 Kas", "2026-11-08", 35),
      com.example.data.model.DailyTrendPoint("09 Kas", "2026-11-09", 64),
      com.example.data.model.DailyTrendPoint("10 Kas", "2026-11-10", 48),
      com.example.data.model.DailyTrendPoint("11 Kas", "2026-11-11", 55),
      com.example.data.model.DailyTrendPoint("12 Kas", "2026-11-12", todayQuestions.coerceAtLeast(35))
    )
  }

  private fun defaultUserProgress(): UserProgress = UserProgress(
    selectedExam = ExamType.YKS_TYT,
    targetNet = 85.0,
    targetScore = 460,
    daysRemaining = 214,
    streakDays = 14,
    totalQuestionsSolved = 412,
    totalCorrect = 349,
    totalWrong = 63,
    totalStudyMinutes = 1850,
    dailyGoalMinutes = 90,
    todayStudiedMinutes = 55,
    todaySolvedQuestions = 35,
    dailyGoalQuestions = 60,
    errorNotebookQuestionIds = mutableSetOf("q_edeb_1", "q_tar_1", "q_biyo_1"),
    favoriteTopicIds = mutableSetOf("top_edeb_1", "top_mat_1"),
    completedTopicIds = mutableSetOf("top_tar_1", "top_cog_1")
  )

  private fun defaultSubjectProgress(): Map<Subject, SubjectProgress> = mapOf(
    Subject.MATEMATIK to SubjectProgress(Subject.MATEMATIK, totalSolved = 145, correctCount = 122, wrongCount = 23),
    Subject.TURKCE_EDEBIYAT to SubjectProgress(Subject.TURKCE_EDEBIYAT, totalSolved = 110, correctCount = 95, wrongCount = 15),
    Subject.TARIH to SubjectProgress(Subject.TARIH, totalSolved = 65, correctCount = 58, wrongCount = 7),
    Subject.COGRAFYA to SubjectProgress(Subject.COGRAFYA, totalSolved = 42, correctCount = 37, wrongCount = 5),
    Subject.BIYOLOJI to SubjectProgress(Subject.BIYOLOJI, totalSolved = 30, correctCount = 24, wrongCount = 6),
    Subject.KIMYA to SubjectProgress(Subject.KIMYA, totalSolved = 20, correctCount = 13, wrongCount = 7)
  )

  private fun initialTasks(): List<StudyTask> = listOf(
    StudyTask(
      id = "task_1",
      title = "Matematik: Özel Üçgenler ve Trigonometri Refleksleri",
      subject = Subject.MATEMATIK,
      targetQuestions = 25,
      completedQuestions = 25,
      targetMinutes = 40,
      completedMinutes = 40,
      isCompleted = true,
      dayOfWeek = "Bugün",
      priority = "Yüksek",
      topicRef = "top_mat_1",
      scheduledDate = "2026-11-12",
      reminderTime = "14:00",
      hasReminder = true,
      notes = "Trigonometri bölgelerdeki işaret kurallarını tekrar et."
    ),
    StudyTask(
      id = "task_2",
      title = "Edebiyat: Tanzimat 1. Dönem Şair Evlenmesi Şifresi",
      subject = Subject.TURKCE_EDEBIYAT,
      targetQuestions = 20,
      completedQuestions = 10,
      targetMinutes = 30,
      completedMinutes = 15,
      isCompleted = false,
      dayOfWeek = "Bugün",
      priority = "Yüksek",
      topicRef = "top_edeb_1",
      scheduledDate = "2026-11-12",
      reminderTime = "18:30",
      hasReminder = true,
      notes = "İlk tiyatro ve ilk edebi roman ayrımlarına dikkat."
    ),
    StudyTask(
      id = "task_3",
      title = "Tarih: Kurtuluş Savaşı Kongreleri 'HAMAS' Sıralaması",
      subject = Subject.TARIH,
      targetQuestions = 15,
      completedQuestions = 0,
      targetMinutes = 20,
      completedMinutes = 0,
      isCompleted = false,
      dayOfWeek = "Bugün",
      priority = "Orta",
      topicRef = "top_tar_1",
      scheduledDate = "2026-11-12",
      reminderTime = "20:00",
      hasReminder = false
    ),
    StudyTask(
      id = "task_4",
      title = "Biyoloji: Hücre Bölünmesi Aşamaları 'İPMAT' Formülü",
      subject = Subject.BIYOLOJI,
      targetQuestions = 20,
      completedQuestions = 0,
      targetMinutes = 25,
      completedMinutes = 0,
      isCompleted = false,
      dayOfWeek = "Yarın",
      priority = "Orta",
      topicRef = "top_biyo_1",
      scheduledDate = "2026-11-13",
      reminderTime = "16:00",
      hasReminder = true
    ),
    StudyTask(
      id = "task_5",
      title = "Coğrafya: Türkiye'nin Rüzgarları 'KAYIP SAKAL'",
      subject = Subject.COGRAFYA,
      targetQuestions = 15,
      completedQuestions = 0,
      targetMinutes = 20,
      completedMinutes = 0,
      isCompleted = false,
      dayOfWeek = "Yarın",
      priority = "Hafif",
      topicRef = "top_cog_1",
      scheduledDate = "2026-11-13"
    )
  )

  private fun buildTestCategories(allQuestions: List<Question>): List<TestCategory> {
    return listOf(
      TestCategory(
        id = "test_mat_1",
        subject = Subject.MATEMATIK,
        title = "Trigonometri ve Açı İndirgemeleri Testi",
        topicName = "Trigonometri",
        questionCount = 12,
        estimatedMinutes = 18,
        difficulty = "ÖSYM Çıkmış",
        solvedCount = 12,
        isCompleted = true,
        bestScore = "%92",
        questions = allQuestions.filter { it.subject == Subject.MATEMATIK }
      ),
      TestCategory(
        id = "test_edeb_1",
        subject = Subject.TURKCE_EDEBIYAT,
        title = "Tanzimat Edebiyatı Şifreli Kodlamalar Testi",
        topicName = "Tanzimat Edebiyatı",
        questionCount = 15,
        estimatedMinutes = 20,
        difficulty = "Orta",
        solvedCount = 10,
        isCompleted = false,
        bestScore = "%85",
        questions = allQuestions.filter { it.subject == Subject.TURKCE_EDEBIYAT }
      ),
      TestCategory(
        id = "test_tar_1",
        subject = Subject.TARIH,
        title = "Milli Mücadele ve Kongreler Testi",
        topicName = "Kurtuluş Savaşı",
        questionCount = 10,
        estimatedMinutes = 15,
        difficulty = "ÖSYM Tarzı",
        solvedCount = 10,
        isCompleted = true,
        bestScore = "%100",
        questions = allQuestions.filter { it.subject == Subject.TARIH }
      ),
      TestCategory(
        id = "test_cog_1",
        subject = Subject.COGRAFYA,
        title = "Türkiye İklimi ve Yerel Rüzgarlar Testi",
        topicName = "İklim ve Rüzgarlar",
        questionCount = 10,
        estimatedMinutes = 12,
        difficulty = "Kolay",
        solvedCount = 8,
        isCompleted = false,
        bestScore = "%90",
        questions = allQuestions.filter { it.subject == Subject.COGRAFYA }
      ),
      TestCategory(
        id = "test_biyo_1",
        subject = Subject.BIYOLOJI,
        title = "Mitoz & Mayoz Hücre Döngüsü Testi",
        topicName = "Hücre Bölünmeleri",
        questionCount = 12,
        estimatedMinutes = 16,
        difficulty = "Zor",
        solvedCount = 6,
        isCompleted = false,
        bestScore = "%75",
        questions = allQuestions.filter { it.subject == Subject.BIYOLOJI }
      ),
      TestCategory(
        id = "test_kim_1",
        subject = Subject.KIMYA,
        title = "Periyodik Sistem ve Halojenler Testi",
        topicName = "Periyodik Tablo",
        questionCount = 10,
        estimatedMinutes = 14,
        difficulty = "Orta",
        solvedCount = 10,
        isCompleted = true,
        bestScore = "%80",
        questions = allQuestions.filter { it.subject == Subject.KIMYA }
      )
    )
  }

  private fun initialTopics(): List<TopicLecture> = listOf(
    TopicLecture(
      id = "top_edeb_1",
      subject = Subject.TURKCE_EDEBIYAT,
      unitTitle = "Tanzimat Edebiyatı (1. Dönem)",
      title = "Şinasi, Namık Kemal ve Ziya Paşa Şifreleri",
      mnemonicCode = "ŞAİR ŞİNASİ İLKİ DENE",
      mnemonicStory = "Görsel Hikaye: Şinasi smokinini giymiş, elinde 'Tercüman-ı Ahval' gazetesiyle ilk kez sahneye çıkıp 'Şair Evlenmesi' tiyatrosunu başlatıyor! Yanında Namık Kemal dev bir Türk bayrağıyla 'Vatan Şairi' diye bağırıyor, Ziya Paşa ise 'Terkib-i Bent' yazarak onlara alkış tutuyor. Bu 3 isim 'Sanat toplum içindir' sloganı atan 1. Dönem kahramanlarıdır!",
      keyPoints = listOf(
        "Şinasi: İlk tiyatro (Şair Evlenmesi), ilk noktalama işaretleri, ilk özel gazete (Tercüman-ı Ahval).",
        "Namık Kemal: Vatan Şairi, ilk edebi roman (İntibah), ilk tarihi roman (Cezmi).",
        "Ziya Paşa: Terkib-i Bent, Terci-i Bent, Zafername, Harabat antolojisi.",
        "1. Dönem kuralı: Dilde sadeleşme hedeflendi ama tam uygulanamadı. Sanat toplum içindir."
      ),
      osymTips = "ÖSYM her yıl mutlaka 'ilk tiyatro / ilk roman' eşleştirmesini sorar. Şair Evlenmesi'nin görücü usulü evliliği eleştiren bir töre komedisi olduğunu sakın unutma!",
      exampleQuestion = "Aşağıdakilerden hangisi Şinasi'nin edebiyatımıza kazandırdığı 'ilkler' arasında yer almaz?",
      exampleSolution = "Şinasi ilk tiyatro (Şair Evlenmesi), ilk noktalama, ilk fabl çevirilerini yaptı. Ancak ilk edebi roman olan İntibah'ı yazan Namık Kemal'dir.",
      dopingReflex = "İlk tiyatro = Şinasi (Evlenme), İlk edebi roman = Namık Kemal (İntibah)!",
      durationMinutes = 14,
      isCompleted = false,
      isFavorite = true
    ),
    TopicLecture(
      id = "top_tar_1",
      subject = Subject.TARIH,
      unitTitle = "Kurtuluş Savaşı Hazırlık Dönemi",
      title = "Genelgeler ve Kongreler Kronolojisi",
      mnemonicCode = "HAMAS (Havza - Amasya - Erzurum - Sivas)",
      mnemonicStory = "Görsel Kodlama: Mustafa Kemal Paşa Samsun'a ayak bastıktan sonra dev bir askeri haritada adım adım ilerliyor: Önce 'HAVZA'da milli bilinci uyandırıp halkı mitinglere çağırıyor, sonra 'AMASYA'da 'Milletin bağımsızlığını yine milletin azim ve kararı kurtaracaktır' diyerek ihtilal bayrağını çekiyor! 'ERZURUM'da toplanış bölgesel, kararlar ulusal oluyor ve 'SİVAS'ta tüm cemiyetler Anadolu ve Rumeli Müdafaa-i Hukuk çatısında birleşiyor!",
      keyPoints = listOf(
        "Havza Genelgesi: İzmir'in işgali protesto edildi, milli bilinç ilk kez uyandı.",
        "Amasya Genelgesi: Kurtuluş Savaşı'nın amacı, gerekçesi ve yöntemi ilk kez açıklandı.",
        "Erzurum Kongresi: Toplanış bölgesel, alınan kararlar ulusal! Manda ve himaye ilk kez reddedildi.",
        "Sivas Kongresi: Her yönüyle ulusal! Manda ve himaye kesin olarak reddedildi, İrade-i Milliye gazetesi çıkarıldı."
      ),
      osymTips = "Amasya Genelgesi = Amaç, Gerekçe, Yöntem formülüdür. 'Milletin azim ve kararı' yöntemi, 'Vatanın bütünlüğü tehlikededir' gerekçeyi belirtir.",
      exampleQuestion = "Kurtuluş Savaşı'nın gerekçesi, amacı ve yöntemi ilk kez nerede belirtilmiştir?",
      exampleSolution = "Amasya Genelgesi'nde ilk kez milli egemenlik ve milli mücadele yöntemi açıkça ilan edilmiştir.",
      dopingReflex = "Gerekçe ve Yöntem = Amasya Genelgesi Refleksi!",
      durationMinutes = 18,
      isCompleted = true,
      isFavorite = false
    ),
    TopicLecture(
      id = "top_mat_1",
      subject = Subject.MATEMATIK,
      unitTitle = "Trigonometri",
      title = "Bölgelerdeki İşaretler ve Özel Açı Refleksi",
      mnemonicCode = "Bütün Sınıf Kara Tahtada Coştu",
      mnemonicStory = "Hafıza Şifresi: Koordinat düzleminde 4 bölgeyi hayal et:\n1. Bölge (0-90°): 'BÜTÜN' -> Hepsi Pozitif (+).\n2. Bölge (90-180°): 'SINIF' -> Yalnızca Sinüs Pozitif (+), diğerleri (-).\n3. Bölge (180-270°): 'KARA TAHTADA' -> Kotanjant ve Tanjant Pozitif (+), diğerleri (-).\n4. Bölge (270-360°): 'COŞTU' -> Yalnızca Cosinüs Pozitif (+), diğerleri (-)!",
      keyPoints = listOf(
        "1. Bölge: sin(+), cos(+), tan(+), cot(+)",
        "2. Bölge: sin(+), cos(-), tan(-), cot(-)",
        "3. Bölge: sin(-), cos(-), tan(+), cot(+)",
        "4. Bölge: sin(-), cos(+), tan(-), cot(-)",
        "İsim Değişimi: 90° ve 270° açılarda fonksiyon isim değiştirir (sin -> cos, tan -> cot). 180° ve 360° açılarda isim ASLA değişmez!"
      ),
      osymTips = "ÖSYM açı indirgemelerinde açı hangi bölgeye düşüyorsa o bölgedeki orijinal fonksiyonun işaretini sorar. İsim değişse bile ilk fonksiyonun işaretine bakılır!",
      exampleQuestion = "sin(210°) değerinin sonucu kaçtır?",
      exampleSolution = "210° = 180° + 30° -> 3. bölge. 3. bölgede sinüs eksi (-) işaretlidir. 180° de isim değişmez: -sin(30°) = -1/2.",
      dopingReflex = "3. bölgede Tahta (tan/cot) pozitif, sinüs negatif: Sonuç = -1/2!",
      durationMinutes = 16,
      isCompleted = false,
      isFavorite = true
    ),
    TopicLecture(
      id = "top_cog_1",
      subject = Subject.COGRAFYA,
      unitTitle = "İklim ve Rüzgarlar",
      title = "Türkiye'yi Etkileyen Yerel Rüzgarlar",
      mnemonicCode = "KAYIP SAKAL",
      mnemonicStory = "Görsel Şifre: Türkiye haritasının sol üstünden başlayıp saat yönünde ilerleyen bir kardan adam hayal et: K-A-Y-I-P soğuk rüzgarları, güneyden esen S-A-K-A-L ise sıcak çöl rüzgarlarını temsil eder!\nKuzeyden gelenler (Soğuk): Karayel (KB), Yıldız (K), Poyraz (KD).\nGüneyden gelenler (Sıcak): Samyeli (GD), Kıble (G), Lodos (GB).",
      keyPoints = listOf(
        "Karayel (KB): Soğuk ve kuru, kışın kar getirir.",
        "Yıldız (K): Karadeniz üzerinden gelir, serin ve yağışlı.",
        "Poyraz (KD): Kışın dondurucu kuru soğuk, yazın serinletir.",
        "Samyeli/Keşişleme (GD): Çöl kökenli, kurutucu, sıcaklığı çok artırır.",
        "Kıble (G): Akdeniz'den gelir, ılık ve nemli.",
        "Lodos (GB): Denizden gelir, ılık, soba zehirlenmelerine sebep olan rüzgardır."
      ),
      osymTips = "Lodos'un gözü yaşlıdır (yağış getirir) ve soba zehirlenmesi sorulduğunda akla ilk Lodos gelmelidir!",
      exampleQuestion = "Güneydoğu yönünden esen ve sıcaklığı aşırı derecede yükselterek tarım ürünlerini kurutan rüzgar hangisidir?",
      exampleSolution = "KAYIP SAKAL kodlamasında GD köşesinde 'Samyeli' (Keşişleme) yer alır. Basra kökenli çok sıcak rüzgardır.",
      dopingReflex = "GD = Samyeli (Kavurucu Çöl Sıcağı)!",
      durationMinutes = 12,
      isCompleted = true,
      isFavorite = false
    ),
    TopicLecture(
      id = "top_biyo_1",
      subject = Subject.BIYOLOJI,
      unitTitle = "Hücre Bölünmeleri",
      title = "Mitoz Bölünme Evreleri ve Kromozom Sayısı",
      mnemonicCode = "İPMAT (İnterfaz - Profaz - Metafaz - Anafaz - Telofaz)",
      mnemonicStory = "Hafıza Kodlaması: Hücre bir tiyatro sahnesidir!\nİ: İnterfaz (Hazırlık, DNA 2 katına çıkar)\nP: Profaz (Perde açılır, çekirdek zarı erir, kromozomlar belirginleşir)\nM: Metafaz (Merkez: Kromozomlar ekvatoral düzlemde yan yana dizilir)\nA: Anafaz (Ayrılma: Kardeş kromatitler kutuplara çekilir)\nT: Telofaz (Tamamlanma: Profazın tersi, çekirdek zarı tekrar oluşur).",
      keyPoints = listOf(
        "Karyokinez: Çekirdek bölünmesi (Profaz, Metafaz, Anafaz, Telofaz).",
        "Sitokinez: Sitoplazma bölünmesi (Hayvan hücrelerinde boğumlanma, bitki hücrelerinde ara lamel oluşumu).",
        "Metafaz: Karyotip analizinin en net yapıldığı evredir.",
        "Anafaz: Kardeş kromatitler ayrıldığı an kromozom sayısı geçici olarak 2 katına çıkar!"
      ),
      osymTips = "ÖSYM 'Kromozom sayısı hangi evrede geçici olarak 2 katına çıkar?' diye sorar. Cevap kardeş kromatitlerin ayrıldığı ANAFAZ evresidir!",
      exampleQuestion = "Kromozomların ekvatoral düzlemde en düzenli dizildiği ve mikroskop altında en net incelendiği evre hangisidir?",
      exampleSolution = "Metafaz (M = Merkez/Muntazam). Karyotip analizi bu evrede yapılır.",
      dopingReflex = "M = Metafaz = Merkezde tek sıra dizilim!",
      durationMinutes = 15,
      isCompleted = false,
      isFavorite = false
    ),
    TopicLecture(
      id = "top_kim_1",
      subject = Subject.KIMYA,
      unitTitle = "Periyodik Sistem",
      title = "Halojenler ve Soygazlar Kodlaması",
      mnemonicCode = "Felek Celal'in Burnunu Isırıp Attı (7A Halojenler)",
      mnemonicStory = "Hafıza Canlandırması: 7A Grubu elemanlarını ezberlemek için: 'Felek' (F - Flor), 'Celal'in' (Cl - Klor), 'Burnunu' (Br - Brom), 'Isırıp' (I - İyot), 'Attı' (At - Astatin). Hepsi tuz yapıcıdır, elektronegatiflikleri çok yüksektir!",
      keyPoints = listOf(
        "Flor (F): Periyodik tablonun en elektronegatif elementidir, bileşiklerinde sadece -1 alır.",
        "Halojenler doğada iki atomlu (diatomik: F2, Cl2, Br2, I2) halde bulunurlar.",
        "Grupta yukarıdan aşağıya doğru inildikçe kaynama noktası artar (F2 ve Cl2 gaz, Br2 sıvı, I2 katıdır)."
      ),
      osymTips = "Flor bileşiklerinde sadece -1 yükseltgenme basamağı alır, pozitif değer ASLA alamaz!",
      exampleQuestion = "Aşağıdaki elementlerden hangisi bileşiklerinde yalnızca -1 yükseltgenme basamağına sahiptir?",
      exampleSolution = "Flor (F) elektron çekme gücü en yüksek element olduğundan bileşiklerinde daima -1 alır.",
      dopingReflex = "Flor daima -1 alır, başkasına şans tanımaz!",
      durationMinutes = 11,
      isCompleted = false,
      isFavorite = false
    )
  )

  private fun initialQuestions(): List<Question> = listOf(
    Question(
      id = "q_edeb_1",
      subject = Subject.TURKCE_EDEBIYAT,
      topicId = "top_edeb_1",
      topicTitle = "Tanzimat Edebiyatı 1. Dönem",
      questionText = "Tanzimat 1. Dönem sanatçılarından biri olan yazarımız; ilk yerli tiyatro oyununu yazmış, ilk özel gazeteyi çıkarmış ve Türk şiirine ilk kez noktalama işaretlerini kazandırmıştır. Bu parçada sözü edilen edebi şahsiyet aşağıdakilerden hangisidir?",
      passageOrPremise = "Edebi Tür: Tiyatro & Gazetecilik\nDönem: Tanzimat 1. Dönem",
      options = listOf(
        "A) Namık Kemal",
        "B) İbrahim Şinasi",
        "C) Ziya Paşa",
        "D) Ahmet Mithat Efendi",
        "E) Recaizade Mahmut Ekrem"
      ),
      correctOptionIndex = 1,
      stepByStepSolution = "1. Adım: Soru kökündeki 'ilk yerli tiyatro' (Şair Evlenmesi), 'ilk özel gazete' (Tercüman-ı Ahval) ve 'noktalama işaretleri' anahtar kelimelerini belirle.\n2. Adım: Tanzimat 1. döneminde bu ilkleri gerçekleştiren kişi İbrahim Şinasi'dir.\n3. Adım: Namık Kemal vatan şairi ve ilk romanların yazarıdır. Ziya Paşa terkib-i bent ustasıdır.",
      dopingReflexTip = "Şinasi = İlklerin Adamı! (Tiyatro + Gazete + Noktalama)",
      trapExplanation = "Namık Kemal ile Şinasi sıkça karıştırılır. İlk tiyatro Şinasi'nindir, sahnelenen ilk tiyatro (Vatan yahut Silistre) ise Namık Kemal'e aittir!",
      difficulty = "ÖSYM Çıkmış Tarzı",
      isSavedInErrorNotebook = true
    ),
    Question(
      id = "q_tar_1",
      subject = Subject.TARIH,
      topicId = "top_tar_1",
      topicTitle = "Kurtuluş Savaşı Hazırlık Dönemi",
      questionText = "Kurtuluş Savaşı sürecinde yayımlanan Amasya Genelgesi'nde yer alan;\nI. Vatanın bütünlüğü, milletin bağımsızlığı tehlikededir.\nII. Milletin bağımsızlığını yine milletin azim ve kararı kurtaracaktır.\nmaddeleri sırasıyla Kurtuluş Savaşı'nın hangi unsurlarını ifade etmektedir?",
      passageOrPremise = "Amasya Genelgesi (22 Haziran 1919)",
      options = listOf(
        "A) Amaç - Sonuç",
        "B) Gerekçe - Yöntem ve Amaç",
        "C) Yöntem - Gerekçe",
        "D) İlke - İnkılap",
        "E) Taktik - Strateji"
      ),
      correctOptionIndex = 1,
      stepByStepSolution = "I. Madde: 'Vatan tehlikededir' ifadesi Kurtuluş Savaşı'nın neden yapıldığını yani 'GEREKÇESİNİ' açıklar.\nII. Madde: 'Milletin azim ve kararı kurtaracaktır' ifadesi bu savaşın nasıl yapılacağını yani 'YÖNTEMİNİ' ve bağımsızlık 'AMACINI' ortaya koyar.",
      dopingReflexTip = "Tehlike = GEREKÇE, Azim ve Karar = YÖNTEM!",
      trapExplanation = "Öğrenciler sıklıkla I. maddeyi amaç zanneder. Oysa tehlikede olmak savaşı başlatma nedenidir (gerekçedir).",
      difficulty = "Orta",
      isSavedInErrorNotebook = true
    ),
    Question(
      id = "q_mat_1",
      subject = Subject.MATEMATIK,
      topicId = "top_mat_1",
      topicTitle = "Trigonometri Bölgeler",
      questionText = "f(x) = cos(180° + x) + sin(90° + x) ifadesinin eşiti aşağıdakilerden hangisidir?",
      passageOrPremise = "Açı İndirgeme Formülleri",
      options = listOf(
        "A) 2 cos(x)",
        "B) 0",
        "C) -2 cos(x)",
        "D) 2 sin(x)",
        "E) -sin(x) + cos(x)"
      ),
      correctOptionIndex = 1,
      stepByStepSolution = "1. cos(180° + x): 3. bölgedir. 3. bölgede cos işareti negatiftir (-). 180°'de isim değişmez -> -cos(x).\n2. sin(90° + x): 2. bölgedir. 2. bölgede sin işareti pozitiftir (+). 90°'de isim cos(x) olur -> +cos(x).\n3. Toplam: -cos(x) + cos(x) = 0.",
      dopingReflexTip = "3. bölgede cos eksi, 2. bölgede sin artı ve isim değişir. İki zıt terim birbirini götürür: 0!",
      trapExplanation = "sin(90°+x)'in işaretini belirlerken değişen fonksiyonun değil, orijinal fonksiyon olan sinüsün 2. bölgedeki işaretine bakılır (+).",
      difficulty = "Orta",
      isSavedInErrorNotebook = false
    ),
    Question(
      id = "q_cog_1",
      subject = Subject.COGRAFYA,
      topicId = "top_cog_1",
      topicTitle = "Türkiye'nin Rüzgarları",
      questionText = "Türkiye'de kış mevsiminde güneybatı yönünden esen, sıcak ve nemli karakterli olan, deniz ulaşımını aksatan ve baca gazı zehirlenmelerine neden olan rüzgar hangisidir?",
      passageOrPremise = "Yerel Rüzgarlar Haritası",
      options = listOf(
        "A) Poyraz",
        "B) Karayel",
        "C) Lodos",
        "D) Samyeli",
        "E) Yıldız"
      ),
      correctOptionIndex = 2,
      stepByStepSolution = "KAYIP SAKAL kodlamasında güneybatı (sol alt) yönü Lodos'a denk gelir. Lodos denizden sıcak hava getirir, kar eritir ve soba gazı zehirlenmesine yol açar.",
      dopingReflexTip = "Güneybatı + Soba Zehirlenmesi = LODOS!",
      trapExplanation = "Samyeli ile karıştırmayın; Samyeli güneydoğudan (çölden) eser ve kurutucudur, Lodos ise denizden gelip nem ve fırtına getirir.",
      difficulty = "Kolay",
      isSavedInErrorNotebook = false
    ),
    Question(
      id = "q_biyo_1",
      subject = Subject.BIYOLOJI,
      topicId = "top_biyo_1",
      topicTitle = "Hücre Bölünmeleri",
      questionText = "2n = 46 kromozomlu bir insanın epitel hücresinin mitoz bölünmesi sırasında, kardeş kromatitlerin zıt kutuplara çekildiği ve geçici olarak kromozom sayısının iki katına çıktığı evre hangisidir?",
      passageOrPremise = "Hücre Döngüsü: Karyokinez Evreleri",
      options = listOf(
        "A) Profaz",
        "B) Metafaz",
        "C) Anafaz",
        "D) Telofaz",
        "E) İnterfaz"
      ),
      correctOptionIndex = 2,
      stepByStepSolution = "İPMAT sıralamasında: Kardeş kromatitler ayrıldığında her bir kromatit artık bağımsız bir kromozom sayılır. Bu ayrılma ANAFAZ evresinde gerçekleşir ve kromozom sayısı geçici olarak 92 olur.",
      dopingReflexTip = "Ayrılma = ANAFAZ = Geçici 2 kat kromozom!",
      trapExplanation = "Öğrenciler Metafaz ile karıştırır. Metafaz merkezde dizilmedir, Anafaz ise kutuplara ayrılmadır.",
      difficulty = "Zor",
      isSavedInErrorNotebook = true
    ),
    Question(
      id = "q_kim_1",
      subject = Subject.KIMYA,
      topicId = "top_kim_1",
      topicTitle = "Halojenler",
      questionText = "Periyodik tablonun 7A grubunda bulunan Flor (9F) elementi ile ilgili aşağıda verilen ifadelerden hangisi daima doğrudur?",
      passageOrPremise = "Elektronegatiflik ve Yükseltgenme Basamağı",
      options = listOf(
        "A) Bileşiklerinde -1 ile +7 arasında çeşitli değerlikler alabilir.",
        "B) Bileşiklerinde yalnızca -1 yükseltgenme basamağına sahiptir.",
        "C) Oda koşullarında tek atomlu gaz halinde bulunur.",
        "D) 7A grubundaki erime ve kaynama noktası en yüksek elementtir.",
        "E) Metallerle kovalent, ametallerle iyonik bağ yapar."
      ),
      correctOptionIndex = 1,
      stepByStepSolution = "Flor periyodik sistemin en elektronegatif elementidir. Kendisinden daha elektronegatif bir element bulunmadığından tüm bileşiklerinde istisnasız -1 değerlik alır.",
      dopingReflexTip = "Flor kraldır: Sadece ve sadece -1 alır!",
      trapExplanation = "Diğer halojenler (Cl, Br, I) -1 ile +7 arası alabilirken Flor ASLA pozitif değer alamaz.",
      difficulty = "Orta",
      isSavedInErrorNotebook = false
    ),
    Question(
      id = "q_mat_2",
      subject = Subject.MATEMATIK,
      topicId = "top_mat_1",
      topicTitle = "Özel Üçgenler",
      questionText = "Bir dik üçgende hipotenüse ait yükseklik h, hipotenüs uzunluğu ise p ve k olarak iki parçaya ayrılmaktadır. h² = p · k bağıntısı hangi ünlü geometrik teorem ile adlandırılır?",
      options = listOf(
        "A) Pisagor Bağıntısı",
        "B) Öklid Bağıntısı",
        "C) Thales Bağıntısı",
        "D) Menelaus Teoremi",
        "E) Carnot Teoremi"
      ),
      correctOptionIndex = 1,
      stepByStepSolution = "Dik açıdan inen dikme (dikten dik) Öklid bağıntısıdır. Yüksekliğin karesi taban parçalarının çarpımına eşittir: h² = p · k.",
      dopingReflexTip = "Dikten dik iniyorsa = ÖKLİD REFLEKSİ!",
      trapExplanation = "Pisagor kenarların kareleri toplamıdır (a² + b² = c²), yükseklik bağıntısı ise Öklid'dir.",
      difficulty = "Kolay",
      isSavedInErrorNotebook = false
    ),
    Question(
      id = "q_edeb_2",
      subject = Subject.TURKCE_EDEBIYAT,
      topicId = "top_edeb_1",
      topicTitle = "Divan & Tanzimat Karşılaştırması",
      questionText = "Aşağıdaki edebi türlerden hangisi Türk edebiyatına ilk kez Tanzimat Dönemi'nde Batı edebiyatından çevrilerek veya uyarlanarak girmiştir?",
      options = listOf(
        "A) Gazel",
        "B) Mesnevi",
        "C) Roman",
        "D) Kaside",
        "E) Şarkı"
      ),
      correctOptionIndex = 2,
      stepByStepSolution = "Gazel, Mesnevi, Kaside ve Şarkı Divan edebiyatı nazım şekilleridir. Roman, hikaye ve tiyatro ise Batı'dan ilk kez Tanzimat döneminde (Yusuf Kamil Paşa'nın Telemak çevirisi ve Şinasi'nin tiyatrosu ile) girmiştir.",
      dopingReflexTip = "Batı'dan İlk Gelen = Roman, Hikaye, Tiyatro!",
      trapExplanation = "Mesnevi olay anlatan bir tür olsa da Divan edebiyatına aittir, Batı tarzı modern roman değildir.",
      difficulty = "Orta",
      isSavedInErrorNotebook = false
    )
  )
}
