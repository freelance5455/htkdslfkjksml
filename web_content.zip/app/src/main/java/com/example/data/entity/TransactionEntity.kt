package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

object TransactionTypes {
    const val INCOME = "INCOME" // সাধারণ আয়
    const val EXPENSE = "EXPENSE" // সাধারণ খরচ
    const val DEPOSIT = "DEPOSIT" // জমা
    const val POND_INCOME = "POND_INCOME" // পুকুর থেকে বেতন (আয়)
    const val POND_FEED_EXPENSE = "POND_FEED_EXPENSE" // পুকুরে খাবার (খরচ)
    const val MADRASAH_SALARY_INCOME = "MADRASAH_SALARY_INCOME" // মাদরাসার বেতন
    const val MOSQUE_SALARY_INCOME = "MOSQUE_SALARY_INCOME" // মসজিদের বেতন
    const val OTHER = "OTHER"
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // INCOME, EXPENSE, DEPOSIT, POND_INCOME, POND_FEED_EXPENSE, etc.
    val categoryLabel: String,
    val amount: Double,
    val date: String, // yyyy-MM-dd
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)
