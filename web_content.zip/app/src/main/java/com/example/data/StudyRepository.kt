package com.example.data

import com.example.data.dao.StudySessionDao
import com.example.data.dao.SubjectDao
import com.example.data.model.StudySession
import com.example.data.model.Subject
import kotlinx.coroutines.flow.Flow

class StudyRepository(
    private val subjectDao: SubjectDao,
    private val sessionDao: StudySessionDao
) {
    val allSubjects: Flow<List<Subject>> = subjectDao.getAllSubjects()
    val allSessions: Flow<List<StudySession>> = sessionDao.getAllSessions()

    fun getSubject(id: Long): Flow<Subject?> = subjectDao.getSubjectById(id)

    suspend fun insertSubject(subject: Subject): Long = subjectDao.insertSubject(subject)

    suspend fun updateSubject(subject: Subject) = subjectDao.updateSubject(subject)

    suspend fun deleteSubject(subject: Subject) = subjectDao.deleteSubject(subject)

    fun getSessionsBetween(startTime: Long, endTime: Long): Flow<List<StudySession>> =
        sessionDao.getSessionsBetween(startTime, endTime)

    fun getSessionsForSubject(subjectId: Long): Flow<List<StudySession>> =
        sessionDao.getSessionsForSubject(subjectId)

    suspend fun insertSession(session: StudySession): Long = sessionDao.insertSession(session)

    suspend fun deleteSession(session: StudySession) = sessionDao.deleteSession(session)

    suspend fun deleteSessionById(id: Long) = sessionDao.deleteSessionById(id)
}
