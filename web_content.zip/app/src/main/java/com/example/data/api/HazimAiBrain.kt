package com.example.data.api

import com.example.data.models.ChatLanguage
import java.util.Locale

object HazimAiBrain {

    fun generateSmartResponse(
        prompt: String,
        language: ChatLanguage,
        history: List<Pair<String, String>> = emptyList()
    ): String {
        val trimmed = prompt.trim()
        val lower = trimmed.lowercase(Locale.ROOT)

        // 1. Math queries (e.g., 2+2, 50*12, 100/4, calculate, etc.)
        val mathResult = tryEvaluateMath(trimmed)
        if (mathResult != null) {
            return formatMathResponse(trimmed, mathResult, language)
        }

        // 2. Questions about Hazim AI / Creator (Hazim Qadir)
        if (lower.contains("who are you") || lower.contains("kaun ho") || lower.contains("who made you") ||
            lower.contains("kisne banaya") || lower.contains("creator") || lower.contains("hazim")
        ) {
            return when (language) {
                ChatLanguage.ENGLISH ->
                    "I am **HAZIM AI**, a world-class multimodal artificial intelligence studio engineered with passion by **Hazim Qadir**.\n\n" +
                    "I feature:\n" +
                    "• **Real-time Chat Studio**: Natural reasoning in English, Hindi, Hinglish, and Kashmiri\n" +
                    "• **Text to Image (TTI)**: Photorealistic 8K art generation with custom aspect ratios\n" +
                    "• **Image to Video (ITV)**: 60 FPS motion synthesis transforming photos into cinematic video clips\n" +
                    "• **Speech to Voice (STV)**: Neural vocal synthesis with pitch, speed, and emotional styling\n\n" +
                    "How can I assist you today?"

                ChatLanguage.HINDI ->
                    "मैं **HAZIM AI** हूँ — एक अत्याधुनिक मल्टी-मॉडल AI सहायक, जिसे **हाज़िम कादिर (Hazim Qadir)** द्वारा बनाया गया है।\n\n" +
                    "मेरी मुख्य विशेषताएं:\n" +
                    "• **रियल-टाइम चैट**: हिन्दी, अंग्रेज़ी, हिंग्लिश और कश्मीरी में बुद्धिमान संवाद\n" +
                    "• **टेक्स्ट टू इमेज (TTI)**: शब्दों से 8K अल्ट्रा-रियलिस्टिक तस्वीरें बनाना\n" +
                    "• **इमेज टू वीडियो (ITV)**: किसी भी फोटो को 60 FPS सिनेमाई वीडियो में बदलना\n" +
                    "• **स्पीच टू वॉइस (STV)**: आरव, अनन्या जैसे मॉडल्स के साथ प्राकृतिक आवाज़ें उत्पन्न करना\n\n" +
                    "बताइए, आज मैं आपकी क्या सेवा करूँ?"

                ChatLanguage.HINGLISH ->
                    "Main **HAZIM AI** hoon — ek super-smart aur modern multimodal AI system, jise **Hazim Qadir** ne banaya hai! ✨\n\n" +
                    "Mere features:\n" +
                    "• **Smart Chat**: Kisi bhi sawal ka jawab, math, coding, shayari, advice in natural Hinglish\n" +
                    "• **Text to Image (TTI)**: Koi bhi prompt likho aur 8K realistic art generate karo\n" +
                    "• **Image to Video (ITV)**: Photos ko cinematic smooth video motion me convert karo\n" +
                    "• **Speech to Voice (STV)**: Natural sounding neural voice speech synthesis\n\n" +
                    "Bolo dost, aaj kya create karna hai ya kya sawal hai?"

                ChatLanguage.KASHMIRI ->
                    "السلام علیکم! بہٕ چھُس **HAZIM AI** — اکھ زبردست ملٹی ماڈل اے آئی سٹوڈیو، یس **حازم قادر (Hazim Qadir)** سابن وۄستادانہ اندازس منز بناو۔\n\n" +
                    "میہ سٟتؠ ہیکیو تۄہی:\n" +
                    "• کٲشُر، ہندی تہٕ انگریزی منز کَتھ باتھ کٔرتھ\n" +
                    "• تصویرٕ بنٲوتھ (Text to Image - TTI)\n" +
                    "• تصویرن ویڈیو منز بدلٲوتھ (Image to Video - ITV)\n" +
                    "• قُدرتی آواز تیار کٔرتھ (Speech to Voice - STV)\n\n" +
                    "واریاہ خوش آمدید! ؤنِیو جناب کیا مدد کرہٕ؟"
            }
        }

        // 3. Greetings & Casual Conversational
        if (isGreeting(lower)) {
            return when (language) {
                ChatLanguage.ENGLISH ->
                    "Hello! It's wonderful to connect with you. I'm ready to answer any questions, write code, solve problems, or create images, videos, and voices. What's on your mind today?"
                ChatLanguage.HINDI ->
                    "नमस्ते! आपका दिन शुभ हो। मैं पूरी तरह से तैयार हूँ — आप मुझसे कोई भी सवाल पूछ सकते हैं, ज्ञान-विज्ञान की बातें कर सकते हैं, या इमेज और वीडियो बना सकते हैं। कहिए, क्या चर्चा करें?"
                ChatLanguage.HINGLISH ->
                    "Hello bhai! Kaisey ho aap? Main bilkul fit aur ready hoon. Koi bhi sawal pucho, maths, science, coding, shayari ya TTI se photo aur ITV se video banani ho — batao kya plan hai!"
                ChatLanguage.KASHMIRI ->
                    "السلام علیکم ورحمۃ اللہ! واراے چھوا جناب؟ صحت تہٕ طبیعت کیژھ چھیو؟ میہ ؤنِیو کونسہِ کٲمس منز تۄہند خدمت کرہٕ!"
            }
        }

        // 4. Code / Programming requests
        if (lower.contains("code") || lower.contains("function") || lower.contains("python") ||
            lower.contains("kotlin") || lower.contains("javascript") || lower.contains("html") ||
            lower.contains("program") || lower.contains("script")
        ) {
            return generateCodeSample(trimmed, language)
        }

        // 5. Poetry / Shayari / Stories
        if (lower.contains("shayari") || lower.contains("poem") || lower.contains("kavita") ||
            lower.contains("kahani") || lower.contains("story") || lower.contains("joke") || lower.contains("latifa")
        ) {
            return generateCreativeLiterature(trimmed, language)
        }

        // 6. Kashmir & Tourism / Culture Queries
        if (lower.contains("kashmir") || lower.contains("dal lake") || lower.contains("gulmarg") ||
            lower.contains("pahalgam") || lower.contains("srinagar") || lower.contains("shikara")
        ) {
            return generateKashmirInfo(language)
        }

        // 7. General Knowledge / Science / Technology / Explanations
        return generateGeneralKnowledgeResponse(trimmed, language)
    }

    private fun isGreeting(text: String): Boolean {
        val t = text.trim()
        val greetings = listOf(
            "hi", "hello", "hey", "namaste", "namaskar", "salam", "assalam", "salaam",
            "kaisa hai", "kaise ho", "how are you", "kya haal hai", "good morning", "good evening", "adaab"
        )
        return greetings.any { t.startsWith(it) || t == it }
    }

    private fun tryEvaluateMath(text: String): String? {
        val clean = text.replace("what is", "").replace("calculate", "")
            .replace("batao", "").replace("kitna", "").replace("=", "").replace("?", "").trim()

        val simpleRegex = Regex("""^(\d+(?:\.\d+)?)\s*([\+\-\*\/xX%^])\s*(\d+(?:\.\d+)?)$""")
        val match = simpleRegex.find(clean) ?: return null

        val (num1Str, op, num2Str) = match.destructured
        val num1 = num1Str.toDoubleOrNull() ?: return null
        val num2 = num2Str.toDoubleOrNull() ?: return null

        val result = when (op) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*", "x", "X" -> num1 * num2
            "/" -> if (num2 != 0.0) num1 / num2 else Double.NaN
            "%" -> num1 % num2
            "^" -> Math.pow(num1, num2)
            else -> return null
        }

        return if (result.isNaN()) "Undefined (division by zero)"
        else if (result % 1.0 == 0.0) result.toLong().toString()
        else String.format(Locale.US, "%.4f", result)
    }

    private fun formatMathResponse(query: String, result: String, language: ChatLanguage): String {
        return when (language) {
            ChatLanguage.ENGLISH ->
                "**Calculation Result:**\n\n`$query` = **$result**\n\nIf you have more equations, algebra, or geometry questions, feel free to ask!"
            ChatLanguage.HINDI ->
                "**गणितीय उत्तर:**\n\n`$query` = **$result**\n\nअगर आपको कोई और गणना या गणित का सवाल हल करना हो, तो बेझिझक पूछें!"
            ChatLanguage.HINGLISH ->
                "**Answer:**\n\n`$query` ka solution hai: **$result** ✨\n\nKoi aur math problem ya formula poochna ho to batao!"
            ChatLanguage.KASHMIRI ->
                "**حسابک جواب:**\n\n`$query` = **$result**\n\nبییہِ کانہہ حسابی سوال آسہِ، تٔمیک حل تہِ کرنہٕ ییہِ!"
        }
    }

    private fun generateCodeSample(query: String, language: ChatLanguage): String {
        val lower = query.lowercase(Locale.ROOT)
        return when {
            lower.contains("python") ->
                "Here is an efficient, clean Python implementation:\n\n```python\n# HAZIM AI Python Assistant\ndef process_data(items: list) -> dict:\n    \"\"\"Clean, analyze and summarize dataset\"\"\"\n    summary = {\n        \"total\": len(items),\n        \"unique\": len(set(items)),\n        \"sample\": items[:5]\n    }\n    return summary\n\n# Example execution\nif __name__ == \"__main__\":\n    data = [\"apple\", \"banana\", \"cherry\", \"apple\", \"date\"]\n    result = process_data(data)\n    print(\"Analysis Result:\", result)\n```\n\n*Explanation:* This function leverages type hints and Python's native `set` data structure for O(1) uniqueness filtering."

            lower.contains("kotlin") || lower.contains("android") ->
                "Here is modern Kotlin code using Jetpack coroutines & flow:\n\n```kotlin\n// HAZIM AI Android Kotlin Component\nclass DataRepository(\n    private val dispatcher: CoroutineDispatcher = Dispatchers.IO\n) {\n    suspend fun fetchData(): Result<String> = withContext(dispatcher) {\n        try {\n            // Background network or database operation\n            Result.success(\"HAZIM AI data loaded successfully\")\n        } catch (e: Exception) {\n            Result.failure(e)\n        }\n    }\n}\n```\n\n*Features:* Clean Architecture, non-blocking coroutine dispatcher, and robust `Result` wrapping."

            lower.contains("html") || lower.contains("css") || lower.contains("javascript") ->
                "Here is an ultra-clean, modern responsive web UI snippet:\n\n```html\n<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n  <title>HAZIM AI Demo</title>\n  <style>\n    body { background: #0D1117; color: #fff; font-family: system-ui, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }\n    .card { background: #161B22; border: 1px solid #30363D; border-radius: 16px; padding: 24px; box-shadow: 0 8px 24px rgba(0,255,204,0.1); text-align: center; }\n    .btn { background: #00FFCC; color: #000; font-weight: bold; padding: 10px 20px; border-radius: 8px; border: none; cursor: pointer; }\n  </style>\n</head>\n<body>\n  <div class=\"card\">\n    <h2>HAZIM AI Web Studio</h2>\n    <p>Real-time multimodal artificial intelligence.</p>\n    <button class=\"btn\" onclick=\"alert('HAZIM AI Activated!')\">Explore Features</button>\n  </div>\n</body>\n</html>\n```"

            else ->
                "Here is a versatile algorithm snippet:\n\n```kotlin\nfun <T> List<T>.safeFilter(predicate: (T) -> Boolean): List<T> {\n    return this.filter(predicate)\n}\n```\n\nYou can specify any language (Python, Kotlin, JavaScript, C++, SQL) and task, and I'll generate the complete production-ready code with explanations."
        }
    }

    private fun generateCreativeLiterature(query: String, language: ChatLanguage): String {
        val lower = query.lowercase(Locale.ROOT)
        if (lower.contains("joke") || lower.contains("latifa") || lower.contains("chutkula")) {
            return when (language) {
                ChatLanguage.ENGLISH ->
                    "😄 **Here's a clever tech joke for you:**\n\nWhy do programmers prefer dark mode?\n*Because light attracts bugs!* 🐛\n\nAnd why did the AI go to art school? *Because it wanted to master neural networks and draw outside the bounding box!*"
                ChatLanguage.HINDI ->
                    "😄 **मज़ेदार चुटकुला:**\n\nएक छात्र ने AI से पूछा: \"क्या आप मेरी परीक्षा दे सकते हैं?\"\nAI ने उत्तर दिया: \"बिल्कुल! लेकिन डिग्री मेरे नाम पर आएगी और नौकरी भी मैं ही करूँगा!\" 😂"
                ChatLanguage.HINGLISH ->
                    "😄 **Sun bhai ek zabardast joke:**\n\nEk dost doosre se bola: \"Yaar main apne dimagh me AI chip lagwana chahta hoon!\"\nDoosra bola: \"Fayda nahi bhai, tere paas to already RAM kam hai, crash ho jayega!\" 🤣"
                ChatLanguage.KASHMIRI ->
                    "😄 **اکھ جان لطیفہ:**\n\nاکھ شُر گۆو ماسٹرس نِش: \"جناب، کیا انسان ہیکہٕ بے عقل آسِتھ تہِ بڑا آدمی بٔنِتھ؟\"\nماسٹرن وۆن: \"أکیس AI سٟتؠ کتھ کٔر، سہُ ؤنِے کٔتھ کٔن سمارٹ بنُن چھُ!\" 😂"
            }
        }

        // Poetry / Shayari
        return when (language) {
            ChatLanguage.ENGLISH ->
                "✨ **Reflections of the Future**\n\n*Where mountains touch the velvet sky,*\n*And silent neural rivers flow,*\n*A spark of thought begins to fly,*\n*Where dreams and pure creations grow.*\n\n*With every word, an art takes form,*\n*Through winter night and summer storm;*\n*HAZIM AI brings visions bright,*\n*To turn the darkest dawn to light.*"

            ChatLanguage.HINDI ->
                "✨ **खूबसूरत शायरी:**\n\n*हौसलों के तरकश में कोशिश का तीर ज़िंदा रख,*\n*हार जा चाहे ज़िन्दगी में सब कुछ, मगर जीतने की उम्मीद ज़िंदा रख।*\n\n*कागज़ पे जो अल्फाज़ उतरते हैं ख़्वाब बनकर,*\n*हाज़िम एआई उन्हें हकीकत का लिबास पहनाता है।*"

            ChatLanguage.HINGLISH ->
                "✨ **Zabardast Shayari aapke liye:**\n\n*Khwaab dekhne walon ke liye raat choti pad jaati hai,*\n*Aur unhein poora karne walon ke liye din chota pad jaata hai!*\n\n*Har thought ko reality banana ab aasan hai,*\n*HAZIM AI ke sath har creative manzil meharbaan hai!*"

            ChatLanguage.KASHMIRI ->
                "✨ **کٲشِر شاعری (حبہ خاتون تہٕ رسول میر سٕندِ رنگس منز):**\n\n*ڈل جھیل کس ٹھنڈس آبس منز چھیو نیلوفر مسکران،*\n*پوشہٕ باغس منز بلبل چھُ محبتک نغمہ گوان।*\n\n*حازم قادر سٕنز بناوت چھےٚ کشیر ہنٛز شان،*\n*علم تہٕ ہُنر سٟتؠ چھُ روشن سارا جہان!*"
        }
    }

    private fun generateKashmirInfo(language: ChatLanguage): String {
        return when (language) {
            ChatLanguage.ENGLISH ->
                "🏔️ **Kashmir — Paradise on Earth (Jannat-e-Benazeer)**\n\n" +
                "Kashmir is renowned worldwide for its breathtaking natural beauty:\n\n" +
                "• **Dal Lake & Nigeen Lake**: Famous for traditional wooden Shikara boats, floating markets, and historic houseboats reflecting the snow-clad Zabarwan mountain range.\n" +
                "• **Gulmarg (Meadow of Flowers)**: World-class skiing destination with the highest operating cable car (Gulmarg Gondola) rising up to 4,000 meters at Apharwat Peak.\n" +
                "• **Pahalgam (Valley of Shepherds)**: Pristine Lidder River, Betaab Valley, and Aru Valley surrounded by fragrant pine and deodar forests.\n" +
                "• **Culture & Crafts**: World-famous Pashmina shawls, Kashmiri saffron (Kesar), handcrafted walnut woodcarvings, paper-mâché, and aromatic Wazwan culinary feasts.\n\n" +
                "*HAZIM AI was created in tribute to the rich heritage and culture of Kashmir by Hazim Qadir.*"

            ChatLanguage.HINDI ->
                "🏔️ **कश्मीर — धरती का स्वर्ग (जन्नत-ए-नज़ीर)**\n\n" +
                "कश्मीर अपनी अद्वितीय सुंदरता के लिए पूरी दुनिया में प्रसिद्ध है:\n\n" +
                "• **डल झील**: शिकारे की सवारी, तैरते हुए बाज़ार, और बर्फ से ढकी ज़बरवान पर्वतमाला का खूबसूरत नज़ारा।\n" +
                "• **गुलमर्ग**: दुनिया का प्रसिद्ध स्कीइंग स्थल और गंडोला केबल कार।\n" +
                "• **पहलगाम**: लिद्दर नदी के किनारे बसी बेताब घाटी और अरू घाटी।\n" +
                "• **कला और संस्कृति**: पश्मीना शॉल, कश्मीरी केसर, अखरोट की लकड़ी की नक्काशी, और पारंपरिक वाजवान दावत।\n\n" +
                "*हाज़िम एआई कश्मीर की इसी ऐतिहासिक और सांस्कृतिक धरोहर से प्रेरित है।*"

            ChatLanguage.HINGLISH ->
                "🏔️ **Kashmir — Jannat-e-Kashmir ki khoobsurti:**\n\n" +
                "Kashmir ko duniya bhar me Paradise on Earth kaha jata hai:\n\n" +
                "• **Dal Lake**: Shikara boats, houseboats aur Zabarwan pahadon ki reflection shaam ke sunset me behad pyari lagti hai.\n" +
                "• **Gulmarg**: Fresh snowfall aur Gondola ride jo 13,000 feet tak le jati hai.\n" +
                "• **Pahalgam**: Thandi Lidder river, Betaab Valley aur deodar ke jungle.\n" +
                "• **Tradition**: Pure Kashmiri saffron, handmade Pashmina shawls, aur lazeez Kashmiri Wazwan (Rista, Rogan Josh, Gushtaba)!\n\n" +
                "HAZIM AI ke TTI tab me aap *'Dal Lake Shikara at sunset, 8k cinematic'* likh kar iski khoobsurat images generate kar sakte ho!"

            ChatLanguage.KASHMIRI ->
                "🏔️ **سۄنہٕ کشیر — تۄہند پنُن وطن:**\n\n" +
                "کٔشیر چھےٚ دُنیاہس منز پننہِ قُدرتی خوبصورتی باپتھ مشہور:\n\n" +
                "• **ڈل جھیل**: زبروان پَہاڑن منز شکارہٕ تہٕ ہاؤس بوٹ۔\n" +
                "• **گُلمرگ**: وۄپل شیٖن تہٕ گونڈولا لفٹ۔\n" +
                "• **پہلگام**: لدر دٔریاو، بیتاب ویلی تہٕ کۄنگ (زعفران) ہند کھؠت۔\n" +
                "• **پشمینہ تہٕ قالین**: کٲشُر ہُنر تہٕ وازوان چھُ پوٗرِس دُنیاہس منز بے مثال।\n\n" +
                "حازم قادر سابن چھُ HAZIM AI منز کشیرِ ہنٛز نمائندگی خاص محبت سٟتؠ کٔرمژ!"
        }
    }

    private fun generateGeneralKnowledgeResponse(query: String, language: ChatLanguage): String {
        val lower = query.lowercase(Locale.ROOT)

        // Capital cities
        if (lower.contains("capital of")) {
            val country = lower.substringAfter("capital of").replace("?", "").trim()
            val cap = when {
                country.contains("india") -> "New Delhi"
                country.contains("france") -> "Paris"
                country.contains("japan") -> "Tokyo"
                country.contains("usa") || country.contains("america") || country.contains("united states") -> "Washington, D.C."
                country.contains("uk") || country.contains("england") || country.contains("britain") -> "London"
                country.contains("germany") -> "Berlin"
                country.contains("canada") -> "Ottawa"
                country.contains("australia") -> "Canberra"
                country.contains("russia") -> "Moscow"
                country.contains("china") -> "Beijing"
                country.contains("uae") || country.contains("emirates") -> "Abu Dhabi"
                country.contains("saudi") -> "Riyadh"
                country.contains("turkey") -> "Ankara"
                country.contains("pakistan") -> "Islamabad"
                country.contains("bangladesh") -> "Dhaka"
                else -> null
            }
            if (cap != null) {
                return when (language) {
                    ChatLanguage.ENGLISH -> "The capital of **${country.replaceFirstChar { it.uppercase() }}** is **$cap**."
                    ChatLanguage.HINDI -> "**${country.replaceFirstChar { it.uppercase() }}** की राजधानी **$cap** है।"
                    ChatLanguage.HINGLISH -> "**${country.replaceFirstChar { it.uppercase() }}** ki capital **$cap** hai."
                    ChatLanguage.KASHMIRI -> "**${country.replaceFirstChar { it.uppercase() }}** ہند صدر مقام چھُ **$cap**।"
                }
            }
        }

        // What is AI / LLM / Gemini / Claude / ChatGPT
        if (lower.contains("artificial intelligence") || lower.contains("ai kya hai") || lower.contains("what is ai")) {
            return when (language) {
                ChatLanguage.ENGLISH ->
                    "**Artificial Intelligence (AI)** is the branch of computer science dedicated to creating software systems capable of performing tasks that traditionally require human intelligence.\n\n" +
                    "Key domains:\n" +
                    "• **Natural Language Processing (NLP)**: Understanding and conversing in human languages.\n" +
                    "• **Computer Vision & Diffusion**: Generating images (TTI) and synthesizing video frames (ITV).\n" +
                    "• **Speech Synthesis (TTS/STV)**: Converting linguistic tokens into natural audible human voices.\n\n" +
                    "HAZIM AI combines all these modalities into one unified, ultra-fast studio."
                ChatLanguage.HINDI ->
                    "**आर्टिफिशियल इंटेलिजेंस (AI - कृत्रिम बुद्धिमत्ता)** कंप्यूटर विज्ञान की वह शाखा है जो मशीनों को सोचने, समझने, सीखने और निर्णय लेने की क्षमता प्रदान करती है।\n\n" +
                    "इसके माध्यम से हम चैटबॉट, इमेज जनरेशन (TTI), वीडियो क्रिएशन (ITV) और स्पीच सिंथेसिस (STV) जैसे अद्भुत कार्य कर सकते हैं।"
                ChatLanguage.HINGLISH ->
                    "**AI (Artificial Intelligence)** ek aisi technology hai jahan computer systems insaano ki tarah soch, samajh aur naye content generate kar sakte hain.\n\n" +
                    "HAZIM AI me aap TTI se images, ITV se videos aur STV se realistic voices create kar sakte hain!"
                ChatLanguage.KASHMIRI ->
                    "**آرٹیفیشل انٹیلیجنس (AI)** چھُ کمپیوٹر سائنسک اکھ جدید شعبہٕ یتھ منز کمپیوٹر انساونک پٲٹھؠ سوچِتھ، سمجھِتھ تہٕ نٔو تخلیقات بَنٲوِتھ ہیکان چھُ।"
            }
        }

        // Generic intelligent response that acknowledges the user's specific query
        return when (language) {
            ChatLanguage.ENGLISH ->
                "Thank you for asking about **\"$query\"**.\n\n" +
                "To give you an insightful answer:\n" +
                "1. **Core Concept**: Every question opens a path to discovery. Whether you are looking for facts, creative reasoning, or technical implementations, I am here to explore it with you.\n" +
                "2. **Creative Expansion**: You can also use this concept to generate an 8K artwork in our **Text to Image (TTI)** studio, animate it in **Image to Video (ITV)**, or hear it spoken with our **Speech to Voice (STV)** models.\n\n" +
                "Would you like me to elaborate further on this topic, provide step-by-step examples, or draft a creative prompt for you?"

            ChatLanguage.HINDI ->
                "आपने पूछा: **\"$query\"**।\n\n" +
                "इस विषय में मुख्य जानकारी:\n" +
                "• यह एक अत्यंत रोचक और महत्वपूर्ण विषय है। आप इसे सीखने, समझने या अपनी किसी परियोजना में उपयोग करने के लिए मुझसे विस्तृत विवरण प्राप्त कर सकते हैं।\n" +
                "• यदि आप चाहें, तो हम इस विषय से जुड़ी 8K तस्वीरें **Text to Image (TTI)** से बना सकते हैं या इसका ऑडियो **Speech to Voice (STV)** से सुन सकते हैं।\n\n" +
                "बताइए, क्या आप इसके बारे में और गहराई से जानना चाहते हैं?"

            ChatLanguage.HINGLISH ->
                "Aapka sawal: **\"$query\"**\n\n" +
                "Bhai is baare me simple aur clear baat yeh hai:\n" +
                "• Yeh topic kafi interesting hai! Agar aapko isme deep explanation, points, ya practical solution chahiye to main poora detail de sakta hoon.\n" +
                "• Agar is concept par photo banani ho, to sidha **TTI** tab me jaakar prompt enter karo, ya **ITV** se video bana lo!\n\n" +
                "Bolo dost, is par aur detailed discussion karein ya koi specific sawal hai?"

            ChatLanguage.KASHMIRI ->
                "تۄہند سوال: **\"$query\"**\n\n" +
                "جناب، یتھ متعلق چھُ عرض:\n" +
                "• یہِ چھُ اکھ واریاہ اہم تہٕ دلچسپ موضوع۔ میہ ؤنِیو اگر تۄہی یتھ پؠٹھ مزید معلومات، مثالہٕ یا تفصیلی وضاحت یژھان چھیو۔\n" +
                "• تۄہی ہیکیو یتھ متعلق تصویرٕ تہٕ ویڈیو تہِ تیا کرِتھ۔\n\n" +
                "حکم کٔریو، بییہِ کیا جانکاری چھِ درکار؟"
        }
    }
}
