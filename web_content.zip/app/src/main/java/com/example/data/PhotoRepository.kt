package com.example.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import com.example.model.CapturedPhoto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PhotoRepository(private val context: Context) {

    private val _photos = MutableStateFlow<List<CapturedPhoto>>(emptyList())
    val photos: StateFlow<List<CapturedPhoto>> = _photos.asStateFlow()

    private val photosDir: File
        get() {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
                ?: File(context.filesDir, "photos")
            val subDir = File(dir, "ChromaSnap")
            if (!subDir.exists()) {
                subDir.mkdirs()
            }
            return subDir
        }

    private val metadataFile: File
        get() = File(photosDir, "photos_metadata.json")

    init {
        loadPhotos()
    }

    fun loadPhotos() {
        try {
            val loaded = mutableListOf<CapturedPhoto>()
            if (metadataFile.exists()) {
                val jsonStr = metadataFile.readText()
                val jsonArray = JSONArray(jsonStr)
                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val filePath = obj.optString("filePath")
                    val file = File(filePath)
                    if (file.exists()) {
                        loaded.add(
                            CapturedPhoto(
                                id = obj.optString("id"),
                                filePath = filePath,
                                timestamp = obj.optLong("timestamp"),
                                triggerName = obj.optString("triggerName", "Auto Capture"),
                                triggerColorHex = obj.optString("triggerColorHex", "#10B981"),
                                matchConfidence = obj.optDouble("matchConfidence", 0.0).toFloat(),
                                isAutoCaptured = obj.optBoolean("isAutoCaptured", true),
                                width = obj.optInt("width", 0),
                                height = obj.optInt("height", 0)
                            )
                        )
                    }
                }
            } else {
                // Discover any JPEG files in the directory
                val files = photosDir.listFiles { f -> f.extension.equals("jpg", ignoreCase = true) }
                files?.sortedByDescending { it.lastModified() }?.forEach { f ->
                    loaded.add(
                        CapturedPhoto(
                            filePath = f.absolutePath,
                            timestamp = f.lastModified(),
                            triggerName = "ChromaSnap Photo",
                            triggerColorHex = "#10B981",
                            matchConfidence = 100f,
                            isAutoCaptured = true
                        )
                    )
                }
            }
            _photos.value = loaded.sortedByDescending { it.timestamp }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun persistMetadata() {
        try {
            val jsonArray = JSONArray()
            for (p in _photos.value) {
                val obj = JSONObject().apply {
                    put("id", p.id)
                    put("filePath", p.filePath)
                    put("timestamp", p.timestamp)
                    put("triggerName", p.triggerName)
                    put("triggerColorHex", p.triggerColorHex)
                    put("matchConfidence", p.matchConfidence.toDouble())
                    put("isAutoCaptured", p.isAutoCaptured)
                    put("width", p.width)
                    put("height", p.height)
                }
                jsonArray.put(obj)
            }
            metadataFile.writeText(jsonArray.toString(2))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun savePhotoFile(
        sourceFile: File,
        triggerName: String,
        triggerColorHex: String,
        confidence: Float,
        isAutoCaptured: Boolean
    ): CapturedPhoto = withContext(Dispatchers.IO) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val targetFile = File(photosDir, "IMG_${timeStamp}.jpg")
        sourceFile.copyTo(targetFile, overwrite = true)

        var w = 0
        var h = 0
        try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(targetFile.absolutePath, options)
            w = options.outWidth
            h = options.outHeight
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val photo = CapturedPhoto(
            filePath = targetFile.absolutePath,
            timestamp = System.currentTimeMillis(),
            triggerName = triggerName,
            triggerColorHex = triggerColorHex,
            matchConfidence = confidence,
            isAutoCaptured = isAutoCaptured,
            width = w,
            height = h
        )

        val updated = listOf(photo) + _photos.value
        _photos.value = updated
        persistMetadata()
        photo
    }

    suspend fun saveBitmap(
        bitmap: Bitmap,
        triggerName: String,
        triggerColorHex: String,
        confidence: Float,
        isAutoCaptured: Boolean
    ): CapturedPhoto = withContext(Dispatchers.IO) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val targetFile = File(photosDir, "IMG_${timeStamp}.jpg")
        FileOutputStream(targetFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }

        val photo = CapturedPhoto(
            filePath = targetFile.absolutePath,
            timestamp = System.currentTimeMillis(),
            triggerName = triggerName,
            triggerColorHex = triggerColorHex,
            matchConfidence = confidence,
            isAutoCaptured = isAutoCaptured,
            width = bitmap.width,
            height = bitmap.height
        )

        val updated = listOf(photo) + _photos.value
        _photos.value = updated
        persistMetadata()
        photo
    }

    suspend fun deletePhoto(photo: CapturedPhoto) = withContext(Dispatchers.IO) {
        try {
            val file = File(photo.filePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        _photos.value = _photos.value.filter { it.id != photo.id }
        persistMetadata()
    }

    suspend fun clearAll() = withContext(Dispatchers.IO) {
        for (p in _photos.value) {
            try {
                val f = File(p.filePath)
                if (f.exists()) f.delete()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        _photos.value = emptyList()
        persistMetadata()
    }

    fun getShareUri(photo: CapturedPhoto): Uri {
        val file = File(photo.filePath)
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.provider",
            file
        )
    }

    fun createShareIntent(photo: CapturedPhoto): Intent {
        val uri = getShareUri(photo)
        return Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
