package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ChatEntity::class, MessageEntity::class, LocalModelEntity::class],
    version = 1,
    exportSchema = false
)
abstract class XireDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun messageDao(): MessageDao
    abstract fun localModelDao(): LocalModelDao

    companion object {
        @Volatile
        private var INSTANCE: XireDatabase? = null

        fun getInstance(context: Context): XireDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    XireDatabase::class.java,
                    "xire_local.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
