package com.example.data.model

data class UserProgress(
  val selectedExam: ExamType = ExamType.YKS_TYT,
  val targetNet: Double = 85.0,
  val targetScore: Int = 450,
  val daysRemaining: Int = 214,
  val streakDays: Int = 12,
  val totalQuestionsSolved: Int = 348,
  val totalCorrect: Int = 292,
  val totalWrong: Int = 56,
  val totalStudyMinutes: Int = 1420,
  val dailyGoalMinutes: Int = 90,
  val todayStudiedMinutes: Int = 45,
  val todaySolvedQuestions: Int = 28,
  val dailyGoalQuestions: Int = 50,
  val errorNotebookQuestionIds: Set<String> = setOf("q_edeb_1", "q_tar_1", "q_biyo_1"),
  val favoriteTopicIds: Set<String> = setOf("top_edeb_1", "top_mat_1"),
  val completedTopicIds: Set<String> = setOf("top_tar_1")
)
