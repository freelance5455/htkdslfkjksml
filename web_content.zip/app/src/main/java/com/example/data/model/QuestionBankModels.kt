package com.example.data.model

data class SubjectProgress(
  val subject: Subject,
  val totalSolved: Int = 0,
  val correctCount: Int = 0,
  val wrongCount: Int = 0,
  val lastStudiedDate: String = "Bugün"
) {
  val net: Double
    get() = correctCount - (wrongCount * 0.25)

  val successRate: Int
    get() = if (totalSolved > 0) ((correctCount.toDouble() / totalSolved) * 100).toInt() else 0
}

data class TestCategory(
  val id: String,
  val subject: Subject,
  val title: String,
  val topicName: String,
  val questionCount: Int,
  val estimatedMinutes: Int,
  val difficulty: String = "Orta",
  val solvedCount: Int = 0,
  val isCompleted: Boolean = false,
  val bestScore: String = "%0",
  val questions: List<Question> = emptyList()
)

data class StorageBreakdown(
  val totalCapacityGb: Int = 64,
  val offlineLecturesMb: Int = 1420,
  val questionBankCacheMb: Int = 380,
  val systemAndAppsGb: Double = 18.2,
  val isAllOfflineDownloaded: Boolean = false
) {
  val appTotalUsedMb: Int
    get() = offlineLecturesMb + questionBankCacheMb

  val freeStorageGb: Double
    get() = (totalCapacityGb - systemAndAppsGb - (appTotalUsedMb / 1024.0)).coerceAtLeast(0.0)
}
