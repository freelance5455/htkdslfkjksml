package com.example.data.remote

import com.example.data.model.SubscriptionTier
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

data class StripeCheckoutSessionResult(
    val sessionId: String,
    val checkoutUrl: String,
    val tier: SubscriptionTier
)

data class StripeSubscriptionVerification(
    val sessionId: String,
    val subscriptionId: String,
    val status: String, // "ACTIVE", "TRIALING", "CHECKOUT_PENDING", "CANCELED", "PAST_DUE"
    val customerEmail: String,
    val currentPeriodEndEpochSec: Long
)

class StripeSubscriptionService {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(25, TimeUnit.SECONDS)
            .build()
    }

    suspend fun createSubscriptionCheckoutSession(
        stripeSecretKey: String,
        tier: SubscriptionTier,
        customerEmail: String?,
        userId: String
    ): Result<StripeCheckoutSessionResult> = withContext(Dispatchers.IO) {
        val cleanKey = stripeSecretKey.trim()
        if (cleanKey.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException(
                    "Stripe Secret Key is not configured. Enter your Stripe Secret Key (sk_live_... or sk_test_...) in the Billing & API Hub first."
                )
            )
        }
        if (tier == SubscriptionTier.FREE) {
            return@withContext Result.failure(
                IllegalArgumentException("Select a paid tier (Pro Monthly or Studio Annual) to start a Stripe Checkout session.")
            )
        }

        try {
            val formBuilder = FormBody.Builder()
                .add("mode", "subscription")
                .add("success_url", "https://omniprompt.studio/billing/success?session_id={CHECKOUT_SESSION_ID}")
                .add("cancel_url", "https://omniprompt.studio/billing/cancel")
                .add("client_reference_id", userId)
                .add("line_items[0][quantity]", "1")
                .add("line_items[0][price_data][currency]", "usd")
                .add("line_items[0][price_data][unit_amount]", tier.unitAmountCents.toString())
                .add("line_items[0][price_data][recurring][interval]", tier.billingInterval)
                .add("line_items[0][price_data][product_data][name]", tier.displayName)
                .add(
                    "line_items[0][price_data][product_data][description]",
                    "OmniPrompt Studio (${tier.monthlyGenerationLimit} monthly AI app & website syntheses)"
                )
                .add("metadata[userId]", userId)
                .add("metadata[planId]", tier.planId)

            if (!customerEmail.isNullOrBlank() && customerEmail.contains("@")) {
                formBuilder.add("customer_email", customerEmail.trim())
            }

            val request = Request.Builder()
                .url("https://api.stripe.com/v1/checkout/sessions")
                .header("Authorization", "Bearer $cleanKey")
                .post(formBuilder.build())
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(bodyStr).optJSONObject("error")?.optString("message")
                    } catch (_: Exception) {
                        null
                    } ?: "HTTP ${response.code}"
                    throw IllegalStateException("Stripe API error: $errMsg")
                }

                val obj = JSONObject(bodyStr)
                val sessionId = obj.getString("id")
                val checkoutUrl = obj.optString("url", "")
                if (checkoutUrl.isBlank()) {
                    throw IllegalStateException("Stripe did not return a hosted checkout URL.")
                }

                Result.success(
                    StripeCheckoutSessionResult(
                        sessionId = sessionId,
                        checkoutUrl = checkoutUrl,
                        tier = tier
                    )
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun verifyCheckoutSession(
        stripeSecretKey: String,
        sessionId: String
    ): Result<StripeSubscriptionVerification> = withContext(Dispatchers.IO) {
        val cleanKey = stripeSecretKey.trim()
        val cleanSessionId = sessionId.trim()
        if (cleanKey.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("Stripe Secret Key is required to verify the checkout session.")
            )
        }
        if (cleanSessionId.isEmpty()) {
            return@withContext Result.failure(
                IllegalArgumentException("Checkout Session ID is empty.")
            )
        }

        try {
            val url = "https://api.stripe.com/v1/checkout/sessions/$cleanSessionId?expand[]=subscription"
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $cleanKey")
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(bodyStr).optJSONObject("error")?.optString("message")
                    } catch (_: Exception) {
                        null
                    } ?: "HTTP ${response.code}"
                    throw IllegalStateException("Stripe verification failed: $errMsg")
                }

                val root = JSONObject(bodyStr)
                val paymentStatus = root.optString("payment_status", "")
                val sessionStatus = root.optString("status", "")
                val customerEmail = root.optJSONObject("customer_details")?.optString("email", "")
                    ?.ifBlank { root.optString("customer_email", "") }
                    .orEmpty()

                val subObj = root.optJSONObject("subscription")
                val subscriptionId = subObj?.optString("id", "")
                    ?: root.optString("subscription", "")
                val subRawStatus = subObj?.optString("status", "") ?: ""
                val periodEnd = subObj?.optLong("current_period_end", 0L) ?: 0L

                val mappedStatus = when {
                    subRawStatus.equals("active", ignoreCase = true) ||
                        paymentStatus.equals("paid", ignoreCase = true) -> "ACTIVE"
                    subRawStatus.equals("trialing", ignoreCase = true) -> "TRIALING"
                    subRawStatus.equals("past_due", ignoreCase = true) -> "PAST_DUE"
                    subRawStatus.equals("canceled", ignoreCase = true) ||
                        sessionStatus.equals("expired", ignoreCase = true) -> "CANCELED"
                    else -> "CHECKOUT_PENDING"
                }

                Result.success(
                    StripeSubscriptionVerification(
                        sessionId = cleanSessionId,
                        subscriptionId = subscriptionId,
                        status = mappedStatus,
                        customerEmail = customerEmail,
                        currentPeriodEndEpochSec = periodEnd
                    )
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun cancelSubscriptionAtPeriodEnd(
        stripeSecretKey: String,
        subscriptionId: String
    ): Result<StripeSubscriptionVerification> = withContext(Dispatchers.IO) {
        val cleanKey = stripeSecretKey.trim()
        val cleanSubId = subscriptionId.trim()
        if (cleanKey.isEmpty() || cleanSubId.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("Valid Stripe Secret Key and Subscription ID are required to cancel.")
            )
        }

        try {
            val formBody = FormBody.Builder()
                .add("cancel_at_period_end", "true")
                .build()

            val request = Request.Builder()
                .url("https://api.stripe.com/v1/subscriptions/$cleanSubId")
                .header("Authorization", "Bearer $cleanKey")
                .post(formBody)
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(bodyStr).optJSONObject("error")?.optString("message")
                    } catch (_: Exception) {
                        null
                    } ?: "HTTP ${response.code}"
                    throw IllegalStateException("Stripe cancel error: $errMsg")
                }

                val root = JSONObject(bodyStr)
                val periodEnd = root.optLong("current_period_end", 0L)
                Result.success(
                    StripeSubscriptionVerification(
                        sessionId = "",
                        subscriptionId = cleanSubId,
                        status = "CANCELED",
                        customerEmail = "",
                        currentPeriodEndEpochSec = periodEnd
                    )
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
