package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AirportDao {
  @Query("SELECT * FROM airports ORDER BY countryEn = 'Iran' DESC, nameEn ASC")
  fun getAllAirports(): Flow<List<Airport>>

  @Query("SELECT * FROM airports WHERE icao = :icao LIMIT 1")
  suspend fun getAirportByIcao(icao: String): Airport?

  @Query("""
    SELECT * FROM airports 
    WHERE icao LIKE '%' || :query || '%' 
       OR iata LIKE '%' || :query || '%' 
       OR nameEn LIKE '%' || :query || '%' 
       OR nameFa LIKE '%' || :query || '%' 
       OR cityEn LIKE '%' || :query || '%' 
       OR cityFa LIKE '%' || :query || '%' 
       OR countryEn LIKE '%' || :query || '%' 
       OR countryFa LIKE '%' || :query || '%'
    ORDER BY countryEn = 'Iran' DESC, nameEn ASC
  """)
  fun searchAirports(query: String): Flow<List<Airport>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAll(airports: List<Airport>)

  @Query("SELECT COUNT(*) FROM airports")
  suspend fun getCount(): Int
}

@Dao
interface FavoriteDao {
  @Query("SELECT * FROM favorites ORDER BY sortOrder ASC, addedTimestamp DESC")
  fun getAllFavorites(): Flow<List<FavoriteAirport>>

  @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE icao = :icao)")
  fun isFavorite(icao: String): Flow<Boolean>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun addFavorite(fav: FavoriteAirport)

  @Query("DELETE FROM favorites WHERE icao = :icao")
  suspend fun removeFavorite(icao: String)

  @Query("SELECT * FROM recent_airports ORDER BY lastViewedTimestamp DESC LIMIT 15")
  fun getRecentAirports(): Flow<List<RecentAirport>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun recordRecentView(recent: RecentAirport)
}

@Dao
interface WeatherCacheDao {
  @Query("SELECT * FROM cached_metar WHERE icao = :icao")
  suspend fun getCachedMetar(icao: String): MetarData?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveMetar(metar: MetarData)

  @Query("SELECT * FROM cached_taf WHERE icao = :icao")
  suspend fun getCachedTaf(icao: String): TafData?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveTaf(taf: TafData)

  @Query("SELECT * FROM cached_sigmet ORDER BY validFromEpochSec DESC")
  fun getAllCachedSigmets(): Flow<List<SigmetData>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveSigmets(sigmets: List<SigmetData>)
}

@Dao
interface SnowtamDao {
  @Query("SELECT * FROM stored_snowtam WHERE icao = :icao ORDER BY receivedTimestampEpochMs DESC")
  fun getSnowtamsForAirport(icao: String): Flow<List<SnowtamData>>

  @Query("SELECT * FROM stored_snowtam WHERE icao = :icao ORDER BY receivedTimestampEpochMs DESC LIMIT 1")
  suspend fun getLatestSnowtam(icao: String): SnowtamData?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSnowtam(snowtam: SnowtamData): Long

  @Query("DELETE FROM stored_snowtam WHERE id = :id")
  suspend fun deleteSnowtam(id: Long)
}
