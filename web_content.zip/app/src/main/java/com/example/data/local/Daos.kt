package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonDao {
    @Query("SELECT * FROM lessons")
    fun observeAll(): Flow<List<LessonEntity>>

    @Query("SELECT * FROM lessons")
    suspend fun getAllSnapshot(): List<LessonEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(lesson: LessonEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lessons: List<LessonEntity>)

    @Query("DELETE FROM lessons WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("UPDATE lessons SET attended = 0")
    suspend fun resetAllAttendance()

    @Query("DELETE FROM lessons")
    suspend fun deleteAll()
}

@Dao
interface TrackDao {
    @Transaction
    @Query("SELECT * FROM tracks ORDER BY sortOrder ASC")
    fun observeTracksWithLessons(): Flow<List<TrackWithLessons>>

    @Transaction
    @Query("SELECT * FROM tracks ORDER BY sortOrder ASC")
    suspend fun getTracksWithLessonsSnapshot(): List<TrackWithLessons>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrack(track: TrackEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTracks(tracks: List<TrackEntity>)

    @Query("DELETE FROM tracks WHERE id = :id")
    suspend fun deleteTrackById(id: String)

    @Query("DELETE FROM tracks")
    suspend fun deleteAllTracks()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrackLesson(lesson: TrackLessonEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrackLessons(lessons: List<TrackLessonEntity>)

    @Query("DELETE FROM track_lessons WHERE id = :id")
    suspend fun deleteTrackLessonById(id: String)

    @Query("SELECT COALESCE(MAX(sortOrder), -1) + 1 FROM track_lessons WHERE trackId = :trackId")
    suspend fun nextLessonSortOrder(trackId: String): Int

    @Query("SELECT COALESCE(MAX(sortOrder), -1) + 1 FROM tracks")
    suspend fun nextTrackSortOrder(): Int
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    suspend fun getAllSnapshot(): List<TaskEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(tasks: List<TaskEntity>)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM tasks WHERE completed = 1")
    suspend fun deleteCompleted()

    @Query("DELETE FROM tasks")
    suspend fun deleteAll()
}
