package com.example.data.firebase

import com.example.data.model.AdInquiry
import com.example.data.model.UserProfile
import com.example.data.model.Wallet
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalRequest
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class AuthAndWalletRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    fun observeUserProfile(userId: String): Flow<UserProfile?> =
        db.collection("users").document(userId)
            .snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.GET, "users/$userId", userId)
            }

    suspend fun ensureUserAndWalletInitialized(
        userId: String,
        displayName: String,
        email: String
    ): Result<UserProfile> {
        val userPath = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user changed; refusing cross-user initialization." }

            val userRef = db.collection("users").document(uid)
            val walletRef = db.collection("wallets").document(uid)
            val counterRef = db.collection("counters").document("bidder_seq")

            val resultProfile = db.runTransaction { tx ->
                val userSnap = tx.get(userRef)
                val walletSnap = tx.get(walletRef)
                val counterSnap = if (!userSnap.exists()) tx.get(counterRef) else null

                val profile = if (userSnap.exists()) {
                    userSnap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?: UserProfile(userId = uid, displayName = displayName, email = email)
                } else {
                    val assignedNum = if (counterSnap != null && counterSnap.exists()) {
                        val next = counterSnap.getLong("nextNumber") ?: 1002L
                        tx.update(
                            counterRef,
                            mapOf(
                                "nextNumber" to next + 1L,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                        next
                    } else {
                        tx.set(
                            counterRef,
                            mapOf(
                                "nextNumber" to 1002L,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                        1001L
                    }

                    val safeName = displayName.trim().ifBlank { "True A Member" }.take(80)
                    val safeEmail = email.trim().ifBlank { "$uid@truea.app" }.take(120)
                    val bidderNumber = "TA-$assignedNum"

                    val payload = mapOf(
                        "userId" to uid,
                        "displayName" to safeName,
                        "email" to safeEmail,
                        "bidderNumber" to bidderNumber,
                        "accountStatus" to "ACTIVE",
                        "role" to "USER",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    tx.set(userRef, payload)
                    UserProfile(
                        id = uid,
                        userId = uid,
                        displayName = safeName,
                        email = safeEmail,
                        bidderNumber = bidderNumber,
                        accountStatus = "ACTIVE",
                        role = "USER"
                    )
                }

                if (!walletSnap.exists()) {
                    val walletPayload = mapOf(
                        "userId" to uid,
                        "availableBalance" to 0L,
                        "pendingWithdrawal" to 0L,
                        "totalDeposited" to 0L,
                        "totalEarned" to 0L,
                        "totalCommissionPaid" to 0L,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    tx.set(walletRef, walletPayload)
                }
                profile
            }.await()

            Result.success(resultProfile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userPath)
            Result.failure(e)
        }
    }

    suspend fun updateUserProfile(
        userId: String,
        displayName: String,
        phone: String,
        bankName: String,
        accountNumber: String,
        accountName: String
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch." }
            val cleanName = displayName.trim()
            require(cleanName.length in 1..80) { "Display name must be between 1 and 80 characters." }
            require(phone.trim().length <= 30) { "Phone number is too long." }
            require(bankName.trim().length <= 80) { "Bank name is too long." }
            require(accountNumber.trim().length <= 20) { "Account number is too long." }
            require(accountName.trim().length <= 80) { "Account name is too long." }

            db.collection("users").document(uid).update(
                mapOf(
                    "displayName" to cleanName,
                    "phone" to phone.trim(),
                    "bankName" to bankName.trim(),
                    "accountNumber" to accountNumber.trim(),
                    "accountName" to accountName.trim(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeWallet(userId: String): Flow<Wallet?> =
        db.collection("wallets").document(userId)
            .snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(Wallet::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.GET, "wallets/$userId", userId)
            }

    fun observeWalletTransactions(userId: String): Flow<List<WalletTransaction>> =
        db.collection("wallet_transactions")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(WalletTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "wallet_transactions", userId)
            }

    fun observeMyWithdrawals(userId: String): Flow<List<WithdrawalRequest>> =
        db.collection("withdrawals")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(WithdrawalRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "withdrawals", userId)
            }

    suspend fun depositFunds(userId: String, amount: Long, methodLabel: String): Result<Unit> {
        val walletPath = "wallets/$userId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch." }
            require(amount >= 500L) { "Minimum deposit is ₦500." }

            val walletRef = db.collection("wallets").document(uid)
            val txRef = db.collection("wallet_transactions").document()
            val refCode = "TA-DEP-${UUID.randomUUID().toString().take(6).uppercase()}"

            db.runTransaction { tx ->
                val walletSnap = tx.get(walletRef)
                val currentBalance = walletSnap.getLong("availableBalance") ?: 0L
                val totalDeposited = walletSnap.getLong("totalDeposited") ?: 0L

                tx.update(
                    walletRef,
                    mapOf(
                        "availableBalance" to currentBalance + amount,
                        "totalDeposited" to totalDeposited + amount,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.set(
                    txRef,
                    mapOf(
                        "userId" to uid,
                        "type" to "DEPOSIT",
                        "amount" to amount,
                        "feeAmount" to 0L,
                        "description" to "Wallet top-up via $methodLabel".take(240),
                        "status" to "COMPLETED",
                        "referenceCode" to refCode,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, walletPath)
            Result.failure(e)
        }
    }

    suspend fun requestWithdrawal(
        userId: String,
        profile: UserProfile,
        amount: Long,
        bankName: String,
        accountNumber: String,
        accountName: String
    ): Result<Unit> {
        val withdrawalPath = "withdrawals"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch." }
            require(profile.accountStatus == "ACTIVE") { "Account is currently suspended." }
            require(amount >= 1000L) { "Minimum withdrawal is ₦1,000." }
            require(bankName.trim().length in 2..80) { "Enter a valid bank name." }
            require(accountNumber.trim().length in 6..20) { "Enter a valid bank account number." }
            require(accountName.trim().length in 2..80) { "Enter the bank account holder name." }

            val walletRef = db.collection("wallets").document(uid)
            val wdRef = db.collection("withdrawals").document()
            val txRef = db.collection("wallet_transactions").document()
            val refCode = "TA-WDR-${UUID.randomUUID().toString().take(6).uppercase()}"

            db.runTransaction { tx ->
                val walletSnap = tx.get(walletRef)
                val available = walletSnap.getLong("availableBalance") ?: 0L
                val pending = walletSnap.getLong("pendingWithdrawal") ?: 0L
                require(available >= amount) { "Insufficient available wallet balance." }

                tx.update(
                    walletRef,
                    mapOf(
                        "availableBalance" to available - amount,
                        "pendingWithdrawal" to pending + amount,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.set(
                    wdRef,
                    mapOf(
                        "userId" to uid,
                        "userDisplayName" to profile.displayName.ifBlank { "Member" }.take(80),
                        "bidderNumber" to profile.bidderNumber.ifBlank { "TA-0000" }.take(20),
                        "amount" to amount,
                        "bankName" to bankName.trim(),
                        "accountNumber" to accountNumber.trim(),
                        "accountName" to accountName.trim(),
                        "status" to "PENDING",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.set(
                    txRef,
                    mapOf(
                        "userId" to uid,
                        "type" to "WITHDRAWAL_REQUEST",
                        "amount" to amount,
                        "feeAmount" to 0L,
                        "description" to "Bank withdrawal request to ${bankName.trim()} (${accountNumber.trim()})".take(240),
                        "status" to "PENDING",
                        "referenceCode" to refCode,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, withdrawalPath)
            Result.failure(e)
        }
    }

    suspend fun submitAdInquiry(
        userId: String,
        businessName: String,
        proposedBudget: Long,
        message: String
    ): Result<Unit> {
        val path = "ad_inquiries"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch." }
            require(businessName.trim().length in 2..80) { "Business name must be 2–80 characters." }
            require(proposedBudget >= 0L) { "Budget must be ₦0 or more." }
            require(message.trim().length in 5..500) { "Message must be 5–500 characters." }

            db.collection("ad_inquiries").document().set(
                mapOf(
                    "userId" to uid,
                    "businessName" to businessName.trim(),
                    "proposedBudget" to proposedBudget,
                    "message" to message.trim(),
                    "status" to "PENDING",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    fun observeMyAdInquiries(userId: String): Flow<List<AdInquiry>> =
        db.collection("ad_inquiries")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(AdInquiry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "ad_inquiries", userId)
            }

    private fun logAndRethrowFlowError(
        error: Throwable,
        op: OperationType,
        path: String,
        expectedUid: String
    ): Nothing {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
        throw error
    }
}
