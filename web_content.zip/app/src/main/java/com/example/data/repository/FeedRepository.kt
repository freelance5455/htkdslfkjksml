package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ArkFeedIds
import com.example.data.model.ArkGroup
import com.example.data.model.ArkPost
import com.example.data.model.FollowEdge
import com.example.data.model.FriendEdge
import com.example.data.model.HiddenPost
import com.example.data.model.MediaChunk
import com.example.data.model.MutedUser
import com.example.data.model.PostBookmark
import com.example.data.model.PostComment
import com.example.data.model.PostDraft
import com.example.data.model.PostReaction
import com.example.data.model.UserProfile
import com.example.util.ImageCompressionHelper
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.io.File
import java.util.Date

data class FeedPageResult(
    val posts: List<ArkPost>,
    val lastDocument: DocumentSnapshot?,
    val hasMore: Boolean
)

class FeedRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing feed.")

    fun observeLatestHomePosts(userId: String, limitCount: Long = 20L): Flow<List<ArkPost>> = flow {
        val path = "posts"
        emitAll(
            db.collection("posts")
                .whereArrayContains("visibleToUids", userId)
                .limit(limitCount)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun fetchFeedPage(
        userId: String,
        pageSize: Long = 10L,
        lastDocument: DocumentSnapshot? = null
    ): Result<FeedPageResult> = runCatching {
        var query = db.collection("posts")
            .whereArrayContains("visibleToUids", userId)
            .limit(pageSize)
        if (lastDocument != null) {
            query = query.startAfter(lastDocument)
        }
        val snap = try {
            query.get().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "posts")
            throw e
        }
        val items = snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        FeedPageResult(
            posts = items,
            lastDocument = snap.documents.lastOrNull(),
            hasMore = snap.documents.size >= pageSize.toInt()
        )
    }

    suspend fun fetchExplorePage(
        pageSize: Long = 18L,
        lastDocument: DocumentSnapshot? = null
    ): Result<FeedPageResult> = runCatching {
        var query = db.collection("posts")
            .whereEqualTo("visibility", "public")
            .limit(pageSize)
        if (lastDocument != null) {
            query = query.startAfter(lastDocument)
        }
        val snap = try {
            query.get().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, "posts")
            throw e
        }
        val items = snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        FeedPageResult(
            posts = items,
            lastDocument = snap.documents.lastOrNull(),
            hasMore = snap.documents.size >= pageSize.toInt()
        )
    }

    fun observeExplorePostsByHashtag(hashtag: String, limitCount: Long = 25L): Flow<List<ArkPost>> = flow {
        val cleanTag = hashtag.trim().lowercase().removePrefix("#")
        if (cleanTag.isBlank()) {
            emit(emptyList())
            return@flow
        }
        emitAll(
            db.collection("posts")
                .whereEqualTo("visibility", "public")
                .whereArrayContains("hashtags", cleanTag)
                .limit(limitCount)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch {
                    emit(emptyList())
                }
        )
    }

    suspend fun searchExplorePosts(query: String): List<ArkPost> {
        val clean = query.trim().lowercase()
        return runCatching {
            if (clean.startsWith("#") && clean.length > 1) {
                val tag = clean.removePrefix("#")
                val snap = db.collection("posts")
                    .whereEqualTo("visibility", "public")
                    .whereArrayContains("hashtags", tag)
                    .limit(25)
                    .get()
                    .await()
                return@runCatching snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            val snap = db.collection("posts")
                .whereEqualTo("visibility", "public")
                .limit(40)
                .get()
                .await()
            val all = snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            if (clean.isBlank()) all
            else all.filter { p ->
                p.caption.contains(clean, ignoreCase = true) ||
                    p.authorUsername.contains(clean, ignoreCase = true) ||
                    p.hashtags.any { it.contains(clean, ignoreCase = true) } ||
                    (p.locationLabel?.contains(clean, ignoreCase = true) == true) ||
                    p.category.contains(clean, ignoreCase = true)
            }
        }.getOrDefault(emptyList())
    }

    fun observeUserPosts(authorId: String, limitCount: Long = 30L): Flow<List<ArkPost>> = flow {
        val path = "posts"
        emitAll(
            db.collection("posts")
                .whereEqualTo("authorId", authorId)
                .limit(limitCount)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeProfilePostsForViewer(targetUid: String, viewerUid: String, limitCount: Long = 30L): Flow<List<ArkPost>> {
        if (targetUid == viewerUid) return observeUserPosts(targetUid, limitCount)
        val publicFlow = db.collection("posts")
            .whereEqualTo("authorId", targetUid)
            .whereEqualTo("visibility", "public")
            .limit(limitCount)
            .snapshots()
            .map { it.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { emit(emptyList()) }

        val sharedFlow = db.collection("posts")
            .whereEqualTo("authorId", targetUid)
            .whereArrayContains("visibleToUids", viewerUid)
            .limit(limitCount)
            .snapshots()
            .map { it.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { emit(emptyList()) }

        return combine(publicFlow, sharedFlow) { pub, shared ->
            (pub + shared).distinctBy { it.id }.sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    fun observeTaggedPosts(targetUid: String, viewerUid: String, limitCount: Long = 30L): Flow<List<ArkPost>> {
        if (targetUid == viewerUid) {
            return db.collection("posts")
                .whereArrayContains("approvedTagUids", targetUid)
                .limit(limitCount)
                .snapshots()
                .map { snap ->
                    snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { emit(emptyList()) }
        }
        val pubTagged = db.collection("posts")
            .whereEqualTo("visibility", "public")
            .whereArrayContains("approvedTagUids", targetUid)
            .limit(limitCount)
            .snapshots()
            .map { it.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { emit(emptyList()) }

        val sharedTagged = db.collection("posts")
            .whereArrayContains("visibleToUids", viewerUid)
            .limit(limitCount)
            .snapshots()
            .map { snap ->
                snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.approvedTagUids.contains(targetUid) }
            }
            .catch { emit(emptyList()) }

        return combine(pubTagged, sharedTagged) { pub, shared ->
            (pub + shared).distinctBy { it.id }.sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    fun observePendingTagRequests(userId: String): Flow<List<ArkPost>> = db.collection("posts")
        .whereArrayContains("pendingTagUids", userId)
        .limit(20)
        .snapshots()
        .map { snap ->
            snap.toObjects(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
        .catch { emit(emptyList()) }

    suspend fun approvePostTag(postId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val ref = db.collection("posts").document(postId)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            val approved = ((snap.get("approvedTagUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()).toMutableSet()
            val pending = ((snap.get("pendingTagUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()).toMutableSet()
            val tagged = ((snap.get("taggedUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()).toMutableSet()
            pending.remove(uid)
            approved.add(uid)
            tagged.add(uid)
            tx.update(
                ref,
                mapOf(
                    "approvedTagUids" to approved.take(10),
                    "pendingTagUids" to pending.take(10),
                    "taggedUids" to tagged.take(10),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()
    }

    suspend fun declineOrRemovePostTag(postId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val ref = db.collection("posts").document(postId)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            val approved = ((snap.get("approvedTagUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()).toMutableSet()
            val pending = ((snap.get("pendingTagUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()).toMutableSet()
            val tagged = ((snap.get("taggedUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()).toMutableSet()
            pending.remove(uid)
            approved.remove(uid)
            tagged.remove(uid)
            tx.update(
                ref,
                mapOf(
                    "approvedTagUids" to approved.take(10),
                    "pendingTagUids" to pending.take(10),
                    "taggedUids" to tagged.take(10),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()
    }

    suspend fun createPost(
        author: UserProfile,
        postType: String,
        category: String,
        caption: String,
        imageBase64List: List<String>,
        visibility: String,
        friends: List<FriendEdge>,
        selectedGroups: List<ArkGroup>,
        followers: List<FollowEdge> = emptyList(),
        locationLabel: String? = null,
        altTexts: List<String> = emptyList(),
        taggedUids: List<String> = emptyList(),
        pollQuestion: String? = null,
        pollOptions: List<String>? = null,
        pollDurationHours: Int = 24,
        videoThumbnailBase64: String? = null,
        videoDurationMs: Long = 0L,
        videoChunksBase64: List<String> = emptyList(),
        metaGameName: String? = null,
        metaScoreLabel: String? = null,
        metaWinner: String? = null,
        metaBadge: String? = null,
        sharedFromPostId: String? = null,
        sharedFromUsername: String? = null
    ): Result<String> = runCatching {
        val uid = requireUserId()
        require(uid == author.userId) { "Author mismatch." }
        require(!author.isRestricted) { "Your account is restricted from creating posts." }
        if (visibility == "public") {
            require(author.ageBracket != "under_13") { "Public posts are disabled for under-13 accounts." }
            require(!author.isPrivateAccount) { "Switch off Private Account in Settings to publish Public posts." }
        }

        val cleanCaption = caption.trim().take(600)
        val parsedHashtags = ArkFeedIds.extractHashtags(cleanCaption)
        val cleanType = postType.takeIf {
            it in setOf("photo", "video", "text", "poll", "game_result", "challenge_result", "group_memory")
        } ?: "text"
        val cleanCategory = category.takeIf { it in ArkFeedIds.feedCategories } ?: "Friends"
        val cleanVisibility = visibility.takeIf {
            it in setOf("public", "followers", "friends", "group", "only_me")
        } ?: "friends"

        val visibleUids = linkedSetOf(uid)
        when (cleanVisibility) {
            "only_me" -> Unit
            "group" -> {
                selectedGroups.forEach { grp -> visibleUids.addAll(grp.memberUids) }
            }
            "friends" -> {
                friends.forEach { visibleUids.add(it.friendUid) }
                selectedGroups.forEach { grp -> visibleUids.addAll(grp.memberUids) }
            }
            "followers", "public" -> {
                followers.forEach { visibleUids.add(it.peerUid) }
                friends.forEach { visibleUids.add(it.friendUid) }
                selectedGroups.forEach { grp -> visibleUids.addAll(grp.memberUids) }
            }
        }
        val cleanTagged = taggedUids.filter { it.isNotBlank() && it != uid }.distinct().take(10)
        val approvedTags = mutableListOf<String>()
        val pendingTags = mutableListOf<String>()
        for (tagUid in cleanTagged) {
            val requiresApproval = runCatching {
                db.collection("users").document(tagUid).get().await().getBoolean("requireTagApproval") == true
            }.getOrDefault(false)
            if (requiresApproval) pendingTags.add(tagUid) else approvedTags.add(tagUid)
        }

        val cappedUids = visibleUids.take(200)
        val cleanImages = imageBase64List.filter { it.isNotBlank() }.take(4)
        val cleanAlts = altTexts.take(4).map { it.trim().take(140) }
        val cleanLocation = locationLabel?.trim()?.take(60)?.takeIf { it.isNotBlank() }

        val cleanChunks = videoChunksBase64.filter { it.isNotBlank() && it.length <= 700_000 }.take(16)
        val postId = ArkFeedIds.newChronoDocId("p")
        val postRef = db.collection("posts").document(postId)
        val authorRef = db.collection("users").document(uid)
        val payload = hashMapOf<String, Any>(
            "authorId" to uid,
            "authorUsername" to author.username.take(30).ifBlank { "player" },
            "authorAvatar" to author.avatarPreset.take(40),
            "postType" to cleanType,
            "category" to cleanCategory,
            "caption" to cleanCaption,
            "hashtags" to parsedHashtags,
            "altTexts" to cleanAlts,
            "taggedUids" to cleanTagged,
            "approvedTagUids" to approvedTags,
            "pendingTagUids" to pendingTags,
            "imageBase64List" to cleanImages,
            "videoDurationMs" to videoDurationMs.coerceIn(0L, 60_000L),
            "videoChunkCount" to cleanChunks.size.toLong(),
            "visibility" to cleanVisibility,
            "visibleToUids" to cappedUids,
            "groupIds" to selectedGroups.map { it.id }.take(10),
            "groupNames" to selectedGroups.map { it.name.take(40) }.take(10),
            "commentsDisabled" to false,
            "likeCount" to 0L,
            "reactionCounts" to emptyMap<String, Long>(),
            "commentCount" to 0L,
            "shareCount" to 0L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (cleanLocation != null) payload["locationLabel"] = cleanLocation
        if (!author.avatarImageBase64.isNullOrBlank() && author.avatarImageBase64.length <= 80_000) {
            payload["authorAvatarBase64"] = author.avatarImageBase64
        }
        if (!videoThumbnailBase64.isNullOrBlank()) {
            payload["videoThumbnailBase64"] = videoThumbnailBase64.take(90_000)
        }
        if (cleanType == "poll") {
            val cleanOpts = (pollOptions ?: emptyList()).map { it.trim().take(80) }.filter { it.isNotBlank() }.take(4)
            require(cleanOpts.size >= 2) { "Polls require at least 2 options." }
            val q = pollQuestion?.trim()?.take(200).orEmpty()
            require(q.isNotBlank()) { "Poll question cannot be empty." }
            payload["pollQuestion"] = q
            payload["pollOptions"] = cleanOpts
            payload["pollVoteCounts"] = emptyMap<String, Long>()
            payload["pollExpiresAt"] = Timestamp(Date(System.currentTimeMillis() + pollDurationHours * 3_600_000L))
        }
        if (!metaGameName.isNullOrBlank()) payload["metaGameName"] = metaGameName.take(80)
        if (!metaScoreLabel.isNullOrBlank()) payload["metaScoreLabel"] = metaScoreLabel.take(120)
        if (!metaWinner.isNullOrBlank()) payload["metaWinner"] = metaWinner.take(60)
        if (!metaBadge.isNullOrBlank()) payload["metaBadge"] = metaBadge.take(60)
        if (!sharedFromPostId.isNullOrBlank()) payload["sharedFromPostId"] = sharedFromPostId.take(128)
        if (!sharedFromUsername.isNullOrBlank()) payload["sharedFromUsername"] = sharedFromUsername.take(30)

        val currentPostsCount = (runCatching { authorRef.get().await().getLong("postsCount") }.getOrNull() ?: author.postsCount).coerceAtLeast(0L)
        val firstChunks = cleanChunks.take(9)
        val restChunks = if (cleanChunks.size > 9) cleanChunks.drop(9) else emptyList()
        val batch = db.batch()
        batch.set(postRef, payload)
        batch.update(
            authorRef,
            mapOf(
                "postsCount" to currentPostsCount + 1L,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        firstChunks.forEachIndexed { idx, chunk ->
            val chunkRef = postRef.collection("media").document("chunk_$idx")
            batch.set(
                chunkRef,
                mapOf(
                    "index" to idx.toLong(),
                    "dataBase64" to chunk,
                    "authorId" to uid,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
        }
        try {
            batch.commit().await()
            if (restChunks.isNotEmpty()) {
                val batch2 = db.batch()
                restChunks.forEachIndexed { relIdx, chunk ->
                    val idx = relIdx + 9
                    val chunkRef = postRef.collection("media").document("chunk_$idx")
                    batch2.set(
                        chunkRef,
                        mapOf(
                            "index" to idx.toLong(),
                            "dataBase64" to chunk,
                            "authorId" to uid,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                try {
                    batch2.commit().await()
                } catch (e: Exception) {
                    runCatching {
                        val cleanupBatch = db.batch()
                        firstChunks.indices.forEach { idx ->
                            cleanupBatch.delete(postRef.collection("media").document("chunk_$idx"))
                        }
                        cleanupBatch.delete(postRef)
                        cleanupBatch.update(
                            authorRef,
                            mapOf("postsCount" to currentPostsCount, "updatedAt" to FieldValue.serverTimestamp())
                        )
                        cleanupBatch.commit().await()
                    }
                    throw e
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, postRef.path)
            throw e
        }
        postId
    }

    suspend fun updatePostCaption(postId: String, newCaption: String): Result<Unit> = runCatching {
        requireUserId()
        val ref = db.collection("posts").document(postId)
        val cleanCaption = newCaption.trim().take(600)
        try {
            ref.update(
                mapOf(
                    "caption" to cleanCaption,
                    "hashtags" to ArkFeedIds.extractHashtags(cleanCaption),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            throw e
        }
    }

    suspend fun toggleCommentsDisabled(postId: String, disabled: Boolean): Result<Unit> = runCatching {
        requireUserId()
        val ref = db.collection("posts").document(postId)
        try {
            ref.update(
                mapOf(
                    "commentsDisabled" to disabled,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            throw e
        }
    }

    suspend fun deletePost(postId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val postRef = db.collection("posts").document(postId)
        val userRef = db.collection("users").document(uid)
        try {
            val mediaDocs = runCatching { postRef.collection("media").get().await() }.getOrNull()
            val batch = db.batch()
            mediaDocs?.documents?.forEach { batch.delete(it.reference) }
            batch.delete(postRef)
            batch.commit().await()
            runCatching {
                db.runTransaction { tx ->
                    val snap = tx.get(userRef)
                    val cur = snap.getLong("postsCount") ?: 0L
                    if (cur > 0L) {
                        tx.update(userRef, mapOf("postsCount" to (cur - 1L), "updatedAt" to FieldValue.serverTimestamp()))
                    }
                }.await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, postRef.path)
            throw e
        }
    }

    suspend fun fetchLikers(postId: String): List<PostReaction> = runCatching {
        db.collection("posts").document(postId).collection("reactions")
            .limit(80)
            .get()
            .await()
            .toObjects(PostReaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedByDescending { it.createdAt?.seconds ?: 0L }
    }.getOrDefault(emptyList())

    suspend fun getMyReaction(postId: String): String? {
        val uid = auth.currentUser?.uid ?: return null
        return runCatching {
            val snap = db.collection("posts").document(postId).collection("reactions").document(uid).get().await()
            if (snap.exists()) snap.getString("reaction") else null
        }.getOrNull()
    }

    suspend fun toggleReaction(postId: String, username: String, reactionKey: String): Result<String?> = runCatching {
        val uid = requireUserId()
        val cleanReaction = reactionKey.takeIf { r -> ArkFeedIds.reactionOptions.any { it.first == r } } ?: "love"
        val postRef = db.collection("posts").document(postId)
        val reactRef = postRef.collection("reactions").document(uid)

        try {
            db.runTransaction { tx ->
                val postSnap = tx.get(postRef)
                val reactSnap = tx.get(reactRef)
                val currentLikeCount = postSnap.getLong("likeCount") ?: 0L
                val rawMap = postSnap.get("reactionCounts") as? Map<*, *>
                val counts = mutableMapOf<String, Long>()
                rawMap?.forEach { (k, v) ->
                    if (k is String && v is Number) counts[k] = v.toLong().coerceAtLeast(0L)
                }

                val prevReaction = if (reactSnap.exists()) reactSnap.getString("reaction") else null
                when {
                    prevReaction == cleanReaction -> {
                        tx.delete(reactRef)
                        val prevC = counts[cleanReaction] ?: 0L
                        if (prevC <= 1L) counts.remove(cleanReaction) else counts[cleanReaction] = prevC - 1L
                        tx.update(
                            postRef,
                            mapOf(
                                "likeCount" to (currentLikeCount - 1L).coerceAtLeast(0L),
                                "reactionCounts" to counts,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                        null
                    }
                    prevReaction != null -> {
                        tx.set(
                            reactRef,
                            mapOf(
                                "userId" to uid,
                                "username" to username.take(30),
                                "reaction" to cleanReaction,
                                "createdAt" to FieldValue.serverTimestamp()
                            )
                        )
                        val oldC = counts[prevReaction] ?: 0L
                        if (oldC <= 1L) counts.remove(prevReaction) else counts[prevReaction] = oldC - 1L
                        counts[cleanReaction] = (counts[cleanReaction] ?: 0L) + 1L
                        tx.update(
                            postRef,
                            mapOf(
                                "likeCount" to currentLikeCount,
                                "reactionCounts" to counts,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                        cleanReaction
                    }
                    else -> {
                        tx.set(
                            reactRef,
                            mapOf(
                                "userId" to uid,
                                "username" to username.take(30),
                                "reaction" to cleanReaction,
                                "createdAt" to FieldValue.serverTimestamp()
                            )
                        )
                        counts[cleanReaction] = (counts[cleanReaction] ?: 0L) + 1L
                        tx.update(
                            postRef,
                            mapOf(
                                "likeCount" to currentLikeCount + 1L,
                                "reactionCounts" to counts,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        )
                        cleanReaction
                    }
                }
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, postRef.path)
            throw e
        }
    }

    fun observeComments(postId: String): Flow<List<PostComment>> = flow {
        val path = "posts/$postId/comments"
        emitAll(
            db.collection("posts").document(postId).collection("comments")
                .limit(100)
                .snapshots()
                .map { snap ->
                    snap.toObjects(PostComment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun addComment(
        post: ArkPost,
        author: UserProfile,
        text: String,
        parentCommentId: String? = null,
        replyToUsername: String? = null
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(!post.commentsDisabled) { "Comments are turned off by the post owner." }
        val cleanText = text.trim().take(400)
        require(cleanText.isNotBlank()) { "Comment cannot be empty." }

        val postRef = db.collection("posts").document(post.id)
        val commentId = ArkFeedIds.newForwardDocId("c")
        val commentRef = postRef.collection("comments").document(commentId)
        val payload = hashMapOf<String, Any>(
            "postId" to post.id,
            "authorId" to uid,
            "authorUsername" to author.username.take(30).ifBlank { "player" },
            "authorAvatar" to author.avatarPreset.take(40),
            "text" to cleanText,
            "likeCount" to 0L,
            "isEdited" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (!parentCommentId.isNullOrBlank()) payload["parentCommentId"] = parentCommentId.take(128)
        if (!replyToUsername.isNullOrBlank()) payload["replyToUsername"] = replyToUsername.take(30)

        try {
            db.runTransaction { tx ->
                val pSnap = tx.get(postRef)
                val count = pSnap.getLong("commentCount") ?: 0L
                tx.set(commentRef, payload)
                tx.update(
                    postRef,
                    mapOf(
                        "commentCount" to count + 1L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, commentRef.path)
            throw e
        }
    }

    suspend fun updateComment(postId: String, commentId: String, newText: String): Result<Unit> = runCatching {
        requireUserId()
        val cleanText = newText.trim().take(400)
        require(cleanText.isNotBlank()) { "Comment cannot be empty." }
        val ref = db.collection("posts").document(postId).collection("comments").document(commentId)
        try {
            ref.update(mapOf("text" to cleanText, "isEdited" to true)).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            throw e
        }
    }

    suspend fun toggleCommentLike(postId: String, commentId: String): Result<Boolean> = runCatching {
        val uid = requireUserId()
        val commentRef = db.collection("posts").document(postId).collection("comments").document(commentId)
        val likeRef = commentRef.collection("likes").document(uid)
        try {
            db.runTransaction { tx ->
                val cSnap = tx.get(commentRef)
                val lSnap = tx.get(likeRef)
                val count = cSnap.getLong("likeCount") ?: 0L
                if (lSnap.exists()) {
                    tx.delete(likeRef)
                    tx.update(commentRef, mapOf("likeCount" to (count - 1L).coerceAtLeast(0L)))
                    false
                } else {
                    tx.set(likeRef, mapOf("userId" to uid, "createdAt" to FieldValue.serverTimestamp()))
                    tx.update(commentRef, mapOf("likeCount" to count + 1L))
                    true
                }
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, commentRef.path)
            throw e
        }
    }

    suspend fun deleteComment(postId: String, commentId: String): Result<Unit> = runCatching {
        requireUserId()
        val postRef = db.collection("posts").document(postId)
        val commentRef = postRef.collection("comments").document(commentId)
        try {
            db.runTransaction { tx ->
                val pSnap = tx.get(postRef)
                val count = pSnap.getLong("commentCount") ?: 0L
                tx.delete(commentRef)
                tx.update(
                    postRef,
                    mapOf(
                        "commentCount" to (count - 1L).coerceAtLeast(0L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, commentRef.path)
            throw e
        }
    }

    suspend fun getMyPollVote(postId: String): Int? {
        val uid = auth.currentUser?.uid ?: return null
        return runCatching {
            val snap = db.collection("posts").document(postId).collection("pollVotes").document(uid).get().await()
            if (snap.exists()) snap.getLong("optionIndex")?.toInt() else null
        }.getOrNull()
    }

    suspend fun votePoll(postId: String, optionIndex: Int): Result<Unit> = runCatching {
        val uid = requireUserId()
        val postRef = db.collection("posts").document(postId)
        val voteRef = postRef.collection("pollVotes").document(uid)
        try {
            db.runTransaction { tx ->
                val pSnap = tx.get(postRef)
                val vSnap = tx.get(voteRef)
                if (vSnap.exists()) throw IllegalStateException("You have already voted on this poll.")
                val opts = (pSnap.get("pollOptions") as? List<*>) ?: emptyList<Any>()
                require(optionIndex in opts.indices) { "Invalid poll option." }
                val rawVotes = pSnap.get("pollVoteCounts") as? Map<*, *>
                val counts = mutableMapOf<String, Long>()
                rawVotes?.forEach { (k, v) ->
                    if (k is String && v is Number) counts[k] = v.toLong().coerceAtLeast(0L)
                }
                val key = optionIndex.toString()
                counts[key] = (counts[key] ?: 0L) + 1L

                tx.set(
                    voteRef,
                    mapOf(
                        "userId" to uid,
                        "optionIndex" to optionIndex.toLong(),
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.update(
                    postRef,
                    mapOf(
                        "pollVoteCounts" to counts,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, postRef.path)
            throw e
        }
    }

    suspend fun incrementShareCount(postId: String): Result<Unit> = runCatching {
        requireUserId()
        val ref = db.collection("posts").document(postId)
        try {
            db.runTransaction { tx ->
                val snap = tx.get(ref)
                val current = snap.getLong("shareCount") ?: 0L
                tx.update(ref, mapOf("shareCount" to current + 1L, "updatedAt" to FieldValue.serverTimestamp()))
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            throw e
        }
    }

    fun observeBookmarks(userId: String): Flow<List<PostBookmark>> = flow {
        val path = "users/$userId/bookmarks"
        emitAll(
            db.collection("users").document(userId).collection("bookmarks")
                .limit(60)
                .snapshots()
                .map { snap -> snap.toObjects(PostBookmark::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun toggleBookmark(postId: String): Result<Boolean> = runCatching {
        val uid = requireUserId()
        val ref = db.collection("users").document(uid).collection("bookmarks").document(postId)
        try {
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.delete().await()
                false
            } else {
                ref.set(mapOf("userId" to uid, "postId" to postId, "savedAt" to FieldValue.serverTimestamp())).await()
                true
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, ref.path)
            throw e
        }
    }

    suspend fun fetchPostsByIds(postIds: List<String>): List<ArkPost> {
        val results = mutableListOf<ArkPost>()
        for (pid in postIds.take(30)) {
            runCatching {
                val snap = db.collection("posts").document(pid).get().await()
                if (snap.exists()) {
                    snap.toObject(ArkPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.let { results.add(it) }
                }
            }
        }
        return results
    }

    fun observeDrafts(userId: String): Flow<List<PostDraft>> = flow {
        val path = "users/$userId/drafts"
        emitAll(
            db.collection("users").document(userId).collection("drafts")
                .limit(30)
                .snapshots()
                .map { snap -> snap.toObjects(PostDraft::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun saveDraft(
        draftId: String?,
        postType: String,
        category: String,
        caption: String,
        imageBase64List: List<String>,
        visibility: String,
        pollQuestion: String,
        pollOptions: List<String>,
        locationLabel: String = "",
        altTexts: List<String> = emptyList()
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val id = draftId?.takeIf { it.isNotBlank() } ?: ArkFeedIds.newChronoDocId("d")
        val ref = db.collection("users").document(uid).collection("drafts").document(id)
        val payload = mapOf(
            "userId" to uid,
            "postType" to postType.takeIf { it in setOf("photo", "video", "text", "poll", "group_memory") }.orEmpty().ifBlank { "text" },
            "category" to category.take(40),
            "caption" to caption.take(600),
            "imageBase64List" to imageBase64List.take(4),
            "visibility" to visibility.takeIf { it in setOf("public", "followers", "friends", "group", "only_me") }.orEmpty().ifBlank { "friends" },
            "pollQuestion" to pollQuestion.take(200),
            "pollOptions" to pollOptions.take(4),
            "locationLabel" to locationLabel.take(60),
            "altTexts" to altTexts.take(4),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            ref.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, ref.path)
            throw e
        }
        id
    }

    suspend fun deleteDraft(draftId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val ref = db.collection("users").document(uid).collection("drafts").document(draftId)
        ref.delete().await()
    }

    fun observeMutedUsers(userId: String): Flow<List<MutedUser>> = flow {
        val path = "users/$userId/mutedUsers"
        emitAll(
            db.collection("users").document(userId).collection("mutedUsers")
                .snapshots()
                .map { snap -> snap.toObjects(MutedUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun muteUser(mutedUid: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val ref = db.collection("users").document(uid).collection("mutedUsers").document(mutedUid)
        ref.set(mapOf("userId" to uid, "mutedUid" to mutedUid, "createdAt" to FieldValue.serverTimestamp())).await()
    }

    suspend fun unmuteUser(mutedUid: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        db.collection("users").document(uid).collection("mutedUsers").document(mutedUid).delete().await()
    }

    fun observeHiddenPosts(userId: String): Flow<List<HiddenPost>> = flow {
        val path = "users/$userId/hiddenPosts"
        emitAll(
            db.collection("users").document(userId).collection("hiddenPosts")
                .snapshots()
                .map { snap -> snap.toObjects(HiddenPost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun hidePost(postId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val ref = db.collection("users").document(uid).collection("hiddenPosts").document(postId)
        ref.set(mapOf("userId" to uid, "postId" to postId, "createdAt" to FieldValue.serverTimestamp())).await()
    }

    suspend fun fetchPostVideoFile(context: Context, postId: String): File? {
        return runCatching {
            val snap = db.collection("posts").document(postId).collection("media").get().await()
            val chunks = snap.toObjects(MediaChunk::class.java)
            ImageCompressionHelper.reconstructVideoToCache(context, "post_$postId", chunks)
        }.getOrNull()
    }
}
