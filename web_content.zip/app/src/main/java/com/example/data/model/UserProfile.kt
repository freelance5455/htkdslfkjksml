package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfile(
    @PrimaryKey val id: Int = 1,
    val agentName: String = "Delivery Partner",
    val defaultRate: Double = 14.0,
    val vehicleNumber: String = "",
    val agencyCompany: String = "",
    val phone: String = "",
    val currencySymbol: String = "₹"
)
