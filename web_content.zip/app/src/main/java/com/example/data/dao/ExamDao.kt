package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ExamEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamDao {

    @Query("SELECT * FROM exams ORDER BY date ASC")
    fun getAllExamsFlow(): Flow<List<ExamEntity>>

    @Query("SELECT * FROM exams WHERE isArchived = 0 ORDER BY date ASC")
    fun getActiveExamsFlow(): Flow<List<ExamEntity>>

    @Query("SELECT * FROM exams WHERE isArchived = 1 ORDER BY date DESC")
    fun getArchivedExamsFlow(): Flow<List<ExamEntity>>

    @Query("SELECT * FROM exams WHERE id = :id LIMIT 1")
    suspend fun getExamById(id: Long): ExamEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExam(exam: ExamEntity): Long

    @Update
    suspend fun updateExam(exam: ExamEntity)

    @Query("UPDATE exams SET isArchived = 1 WHERE id = :id")
    suspend fun archiveExam(id: Long)

    @Query("UPDATE exams SET isArchived = 0 WHERE id = :id")
    suspend fun restoreExam(id: Long)

    @Query("DELETE FROM exams WHERE id = :id")
    suspend fun deleteExam(id: Long)

    @Query("SELECT * FROM exams ORDER BY id ASC")
    suspend fun getAllExamsOnce(): List<ExamEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(exams: List<ExamEntity>)

    @Query("DELETE FROM exams")
    suspend fun deleteAll()
}
