package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.AppSettingsEntity
import com.example.data.entity.LoanEntity
import com.example.data.entity.LoanRepaymentEntity
import com.example.data.entity.SalaryEntity
import com.example.data.entity.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FinanceDao {

    // --- Transactions ---
    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)

    @Query("DELETE FROM transactions")
    suspend fun clearAllTransactions()

    // --- Loans ---
    @Query("SELECT * FROM loans ORDER BY date DESC, id DESC")
    fun getAllLoans(): Flow<List<LoanEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoan(loan: LoanEntity): Long

    @Update
    suspend fun updateLoan(loan: LoanEntity)

    @Query("DELETE FROM loans WHERE id = :id")
    suspend fun deleteLoanById(id: Long)

    @Query("DELETE FROM loans")
    suspend fun clearAllLoans()

    // --- Loan Repayments ---
    @Query("SELECT * FROM loan_repayments ORDER BY date DESC, id DESC")
    fun getAllRepayments(): Flow<List<LoanRepaymentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepayment(repayment: LoanRepaymentEntity): Long

    @Update
    suspend fun updateRepayment(repayment: LoanRepaymentEntity)

    @Query("DELETE FROM loan_repayments WHERE id = :id")
    suspend fun deleteRepaymentById(id: Long)

    @Query("DELETE FROM loan_repayments")
    suspend fun clearAllRepayments()

    // --- Salaries ---
    @Query("SELECT * FROM salaries ORDER BY year DESC, monthIndex ASC")
    fun getAllSalaries(): Flow<List<SalaryEntity>>

    @Query("SELECT * FROM salaries WHERE institution = :institution AND year = :year AND monthIndex = :monthIndex LIMIT 1")
    suspend fun getSalaryByMonth(institution: String, year: Int, monthIndex: Int): SalaryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSalary(salary: SalaryEntity): Long

    @Update
    suspend fun updateSalary(salary: SalaryEntity)

    @Query("DELETE FROM salaries WHERE id = :id")
    suspend fun deleteSalaryById(id: Long)

    @Query("DELETE FROM salaries")
    suspend fun clearAllSalaries()

    // --- Settings ---
    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<AppSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: AppSettingsEntity)
}
