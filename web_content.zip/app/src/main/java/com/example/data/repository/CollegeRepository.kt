package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.model.*
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class CollegeRepository(context: Context) {
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(
        context.getString(R.string.firestore_database_id)
    )

    companion object {
        private const val TAG = "CollegeRepository"
        val BATCHES = listOf("Batch 2023-24", "Batch 2024-25", "Batch 2025-26", "Batch 2026-27")
        val SUBJECT_NAMES = listOf(
            "Anatomy",
            "Physiology",
            "Psychology",
            "Community Health Nursing",
            "Fundamentals of Nursing",
            "Nutrition",
            "Microbiology",
            "Medical-Surgical Nursing"
        )

        val INITIAL_TEACHERS = listOf(
            Teacher(
                id = "t_principal",
                name = "Dr. S. K. Sharma",
                phone = "+91 94140 12345",
                designation = "Principal & Senior Faculty",
                qualifications = "M.Sc. Nursing (Medical-Surgical), Ph.D.",
                experienceYears = 22,
                department = "Administration & Medical-Surgical Nursing",
                email = "principal@gnmtc-sgnr.edu.in",
                bio = "Over two decades of clinical and nursing pedagogical leadership in Rajasthan state healthcare.",
                isActive = true,
                isClinicalDuty = true
            ),
            Teacher(
                id = "t_sunita",
                name = "Mrs. Sunita Verma",
                phone = "+91 98290 65432",
                designation = "Vice-Principal & Assistant Professor",
                qualifications = "M.Sc. Nursing (Obstetrics & Gynecology)",
                experienceYears = 16,
                department = "Obstetrics & Midwifery",
                email = "sunita.verma@gnmtc-sgnr.edu.in",
                bio = "Expert in maternal and neonatal nursing practices with multiple state awards.",
                isActive = true,
                isClinicalDuty = true
            ),
            Teacher(
                id = "t_rajesh",
                name = "Mr. Rajesh Bishnoi",
                phone = "+91 94142 88776",
                designation = "Nursing Tutor / Lecturer",
                qualifications = "B.Sc. Nursing, P.B.B.Sc, M.Sc. (CHN)",
                experienceYears = 9,
                department = "Community Health Nursing",
                email = "rajesh.b@gnmtc-sgnr.edu.in",
                bio = "Field coordinator for rural healthcare postings across Sri Ganganagar district.",
                isActive = true,
                isClinicalDuty = true
            ),
            Teacher(
                id = "t_priyanka",
                name = "Ms. Priyanka Meena",
                phone = "+91 97854 33221",
                designation = "Senior Lecturer",
                qualifications = "M.Sc. Nursing (Anatomy & Physiology)",
                experienceYears = 11,
                department = "Anatomy & Physiology",
                email = "priyanka.m@gnmtc-sgnr.edu.in",
                bio = "Specialist in human gross anatomy and clinical physiology demonstration.",
                isActive = true,
                isClinicalDuty = false
            ),
            Teacher(
                id = "t_vikram",
                name = "Mr. Vikram Singh Rathore",
                phone = "+91 96101 44556",
                designation = "Clinical Instructor",
                qualifications = "M.Sc. Nursing (Mental Health Nursing)",
                experienceYears = 7,
                department = "Psychology & Psychiatric Nursing",
                email = "vikram.r@gnmtc-sgnr.edu.in",
                bio = "In-charge of psychiatric ward rotation and student clinical counseling.",
                isActive = true,
                isClinicalDuty = true
            ),
            Teacher(
                id = "t_anita",
                name = "Mrs. Anita Choudhary",
                phone = "+91 99283 55443",
                designation = "Lecturer in Nutrition & Microbiology",
                qualifications = "M.Sc. Medical Microbiology",
                experienceYears = 8,
                department = "Nutrition & Microbiology",
                email = "anita.c@gnmtc-sgnr.edu.in",
                bio = "Directs laboratory safety, sterile technique, and clinical bacteriology.",
                isActive = true,
                isClinicalDuty = false
            )
        )

        val INITIAL_COORDINATORS = mapOf(
            "Batch 2023-24" to BatchCoordinator(
                batchId = "Batch 2023-24",
                name = "Dr. S. K. Sharma",
                phone = "+91 94140 12345",
                designation = "Senior Professor & Coordinator (Final Year)",
                qualifications = "M.Sc. Nursing, Ph.D.",
                experience = "22 Years",
                department = "Medical Surgical",
                email = "principal@gnmtc-sgnr.edu.in"
            ),
            "Batch 2024-25" to BatchCoordinator(
                batchId = "Batch 2024-25",
                name = "Mrs. Sunita Verma",
                phone = "+91 98290 65432",
                designation = "Vice-Principal & 3rd Year In-charge",
                qualifications = "M.Sc. (OBG Nursing)",
                experience = "16 Years",
                department = "Obstetrics & Midwifery",
                email = "sunita.verma@gnmtc-sgnr.edu.in"
            ),
            "Batch 2025-26" to BatchCoordinator(
                batchId = "Batch 2025-26",
                name = "Mr. Rajesh Bishnoi",
                phone = "+91 94142 88776",
                designation = "Senior Tutor & 2nd Year Coordinator",
                qualifications = "M.Sc. (Community Health)",
                experience = "9 Years",
                department = "Community Health",
                email = "rajesh.b@gnmtc-sgnr.edu.in"
            ),
            "Batch 2026-27" to BatchCoordinator(
                batchId = "Batch 2026-27",
                name = "Ms. Priyanka Meena",
                phone = "+91 97854 33221",
                designation = "Assistant Professor & 1st Year In-charge",
                qualifications = "M.Sc. (Anatomy & Physiology)",
                experience = "11 Years",
                department = "Foundation of Nursing",
                email = "priyanka.m@gnmtc-sgnr.edu.in"
            )
        )

        val INITIAL_STUDENTS = listOf(
            StudentPublic(
                id = "std_01",
                rollNo = "GNM-24-01",
                name = "Amanpreet Kaur",
                batch = "Batch 2024-25",
                joiningDate = "01-08-2024",
                dob = "15-05-2004",
                address = "Ward No. 8, Purani Abadi, Sri Ganganagar",
                photoUrl = "",
                isActive = true
            ),
            StudentPublic(
                id = "std_02",
                rollNo = "GNM-24-02",
                name = "Kuldeep Singh",
                batch = "Batch 2024-25",
                joiningDate = "01-08-2024",
                dob = "22-11-2003",
                address = "VPO Hindumalkot, Sri Ganganagar",
                photoUrl = "",
                isActive = true
            ),
            StudentPublic(
                id = "std_03",
                rollNo = "GNM-24-03",
                name = "Pooja Sharma",
                batch = "Batch 2024-25",
                joiningDate = "01-08-2024",
                dob = "09-02-2004",
                address = "Sadar Bazaar, Padampur, SGNR",
                photoUrl = "",
                isActive = true
            ),
            StudentPublic(
                id = "std_04",
                rollNo = "GNM-23-01",
                name = "Gurpreet Singh Gill",
                batch = "Batch 2023-24",
                joiningDate = "01-08-2023",
                dob = "12-07-2002",
                address = "Karanpur Road, Sri Ganganagar",
                photoUrl = "",
                isActive = true
            ),
            StudentPublic(
                id = "std_05",
                rollNo = "GNM-25-01",
                name = "Monika Bishnoi",
                batch = "Batch 2025-26",
                joiningDate = "01-08-2025",
                dob = "18-04-2005",
                address = "Anupgarh Road, Raisinghnagar",
                photoUrl = "",
                isActive = true
            ),
            StudentPublic(
                id = "std_06",
                rollNo = "GNM-26-01",
                name = "Ravi Kumar Verma",
                batch = "Batch 2026-27",
                joiningDate = "01-08-2026",
                dob = "29-09-2005",
                address = "Jawahar Nagar, Sri Ganganagar",
                photoUrl = "",
                isActive = true
            )
        )

        val INITIAL_PRIVATE_RECORDS = mapOf(
            "std_01" to StudentPrivate(
                studentId = "std_01",
                studentMobile = "+91 98281 11223",
                parentMobile = "+91 94141 33445",
                bankAccount = "381029384729",
                ifsc = "SBIN0031124",
                bankBranch = "SBI Sri Ganganagar Main Branch",
                aadhaar = "XXXX-XXXX-4912",
                janAadhaar = "8392019482",
                pan = "ABCDE1234F"
            ),
            "std_02" to StudentPrivate(
                studentId = "std_02",
                studentMobile = "+91 94144 22334",
                parentMobile = "+91 98299 77889",
                bankAccount = "629103847192",
                ifsc = "PUNB0192800",
                bankBranch = "PNB Suratgarh Road SGNR",
                aadhaar = "XXXX-XXXX-8921",
                janAadhaar = "9928102931",
                pan = "BGHPK8765Q"
            ),
            "std_03" to StudentPrivate(
                studentId = "std_03",
                studentMobile = "+91 97821 55667",
                parentMobile = "+91 94132 88990",
                bankAccount = "419203847291",
                ifsc = "BARB0GANGA",
                bankBranch = "Bank of Baroda Gol Bazaar SGNR",
                aadhaar = "XXXX-XXXX-3829",
                janAadhaar = "7719203819",
                pan = "CPRSK4567M"
            ),
            "std_04" to StudentPrivate(
                studentId = "std_04",
                studentMobile = "+91 98765 12345",
                parentMobile = "+91 98765 67890",
                bankAccount = "782910394812",
                ifsc = "SBIN0031124",
                bankBranch = "SBI Sri Ganganagar",
                aadhaar = "XXXX-XXXX-5512",
                janAadhaar = "8812930491",
                pan = "DPQWE8912T"
            ),
            "std_05" to StudentPrivate(
                studentId = "std_05",
                studentMobile = "+91 96102 77889",
                parentMobile = "+91 99281 44556",
                bankAccount = "551920384719",
                ifsc = "HDFC0001892",
                bankBranch = "HDFC Bank Raisinghnagar",
                aadhaar = "XXXX-XXXX-9912",
                janAadhaar = "6628192031",
                pan = "ELMNP3344K"
            ),
            "std_06" to StudentPrivate(
                studentId = "std_06",
                studentMobile = "+91 97851 88990",
                parentMobile = "+91 94142 55667",
                bankAccount = "991827364512",
                ifsc = "ICIC0002134",
                bankBranch = "ICICI Bank Jawahar Nagar",
                aadhaar = "XXXX-XXXX-1123",
                janAadhaar = "5519283746",
                pan = "FZKLP9988X"
            )
        )

        val INITIAL_NOTICES = listOf(
            Notice(
                id = "not_01",
                title = "Annual Clinical Posting Schedule 2026-27 Announced",
                description = "All students of Batch 2023-24 & 2024-25 are hereby notified that the hospital rotation at District Hospital SGNR commences from next Monday. Ensure proper nursing uniforms and logbooks.",
                category = "Clinical",
                publicationDate = "18 Oct 2026",
                isPinned = true,
                isPublished = true
            ),
            Notice(
                id = "not_02",
                title = "Rajasthan Nursing Council (RNC) Examination Registration Notice",
                description = "Eligible candidates must verify their biometric registration and submit the examination form before the 30th of this month.",
                category = "Exams",
                publicationDate = "15 Oct 2026",
                isPinned = true,
                isPublished = true
            ),
            Notice(
                id = "not_03",
                title = "World Mental Health Day & Community Health Camp",
                description = "GNMTC SGNR will organize a specialized community outreach and nutrition guidance camp at Suratgarh Primary Health Center.",
                category = "Events",
                publicationDate = "10 Oct 2026",
                isPinned = false,
                isPublished = true
            )
        )

        val INITIAL_HOLIDAYS = listOf(
            Holiday(
                id = "hol_01",
                name = "Deepawali Festival & Govardhan Puja",
                startDate = "31 Oct 2026",
                endDate = "03 Nov 2026",
                category = "Gazetted",
                description = "Festival of Lights college vacation. Essential clinical duty rosters will apply for posted interns."
            ),
            Holiday(
                id = "hol_02",
                name = "Guru Nanak Jayanti",
                startDate = "15 Nov 2026",
                endDate = "15 Nov 2026",
                category = "Gazetted",
                description = "Prakash Parv holiday honoring Guru Nanak Dev Ji."
            ),
            Holiday(
                id = "hol_03",
                name = "Winter Academic Recess",
                startDate = "25 Dec 2026",
                endDate = "31 Dec 2026",
                category = "Academic Break",
                description = "Winter recess for regular classroom theory sessions."
            ),
            Holiday(
                id = "hol_04",
                name = "International Nurses Day Celebration",
                startDate = "12 May 2027",
                endDate = "12 May 2027",
                category = "College Event Holiday",
                description = "Commemoration of Florence Nightingale with lamp lighting pledge and cultural symposium."
            )
        )

        fun createDefaultSubjectsForBatch(batch: String): List<Subject> {
            return SUBJECT_NAMES.mapIndexed { index, name ->
                val assignedTeacher = when (index % 5) {
                    0 -> Pair("t_principal", "Dr. S. K. Sharma")
                    1 -> Pair("t_sunita", "Mrs. Sunita Verma")
                    2 -> Pair("t_rajesh", "Mr. Rajesh Bishnoi")
                    3 -> Pair("t_priyanka", "Ms. Priyanka Meena")
                    else -> Pair("t_anita", "Mrs. Anita Choudhary")
                }
                Subject(
                    id = "sub_${batch.replace(" ", "_").replace("-", "_")}_$index",
                    batchId = batch,
                    code = "GNM-${100 + index}",
                    name = name,
                    description = "Core nursing curriculum syllabus for $name in $batch",
                    assignedTeacherId = assignedTeacher.first,
                    assignedTeacherName = assignedTeacher.second
                )
            }
        }

        fun createDefaultLecturesForBatch(batch: String): List<SyllabusLecture> {
            val subjects = createDefaultSubjectsForBatch(batch)
            return subjects.flatMap { sub ->
                listOf(
                    SyllabusLecture(
                        id = "${sub.id}_lec_1",
                        subjectId = sub.id,
                        batchId = batch,
                        topic = "Introduction to ${sub.name}: Clinical Foundations & Objectives",
                        date = "15-09-2026",
                        startTime = "09:00 AM",
                        durationMinutes = 60,
                        notes = "Covered unit overview and core clinical definitions.",
                        teacherId = sub.assignedTeacherId,
                        teacherName = sub.assignedTeacherName,
                        isCompleted = true
                    ),
                    SyllabusLecture(
                        id = "${sub.id}_lec_2",
                        subjectId = sub.id,
                        batchId = batch,
                        topic = "${sub.name} Principles: Assessment and Patient Care Procedures",
                        date = "22-09-2026",
                        startTime = "10:00 AM",
                        durationMinutes = 60,
                        notes = "Practical demonstration in nursing laboratory.",
                        teacherId = sub.assignedTeacherId,
                        teacherName = sub.assignedTeacherName,
                        isCompleted = true
                    ),
                    SyllabusLecture(
                        id = "${sub.id}_lec_3",
                        subjectId = sub.id,
                        batchId = batch,
                        topic = "Advanced Clinical Pathology and Intervention in ${sub.name}",
                        date = "28-10-2026",
                        startTime = "11:00 AM",
                        durationMinutes = 90,
                        notes = "Scheduled for next clinical academic cycle.",
                        teacherId = sub.assignedTeacherId,
                        teacherName = sub.assignedTeacherName,
                        isCompleted = false
                    )
                )
            }
        }
    }

    // ==========================================
    // 1. TEACHER REPOSITORY
    // ==========================================
    fun observeTeachers(): Flow<List<Teacher>> = callbackFlow {
        trySend(INITIAL_TEACHERS)
        val listener = db.collection("teachers")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Fetching teachers: ${error.message}")
                    return@addSnapshotListener
                }
                val teachers = snapshot?.toObjects(Teacher::class.java) ?: emptyList()
                if (teachers.isNotEmpty()) {
                    trySend(teachers)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun saveTeacher(teacher: Teacher): Result<Unit> {
        return try {
            val docRef = if (teacher.id.isBlank()) db.collection("teachers").document() else db.collection("teachers").document(teacher.id)
            val toSave = teacher.copy(id = docRef.id)
            docRef.set(toSave).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving teacher", e)
            Result.failure(e)
        }
    }

    suspend fun deleteTeacher(teacherId: String): Result<Unit> {
        return try {
            db.collection("teachers").document(teacherId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting teacher", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 2. BATCH & COORDINATOR REPOSITORY
    // ==========================================
    fun observeCoordinator(batchId: String): Flow<BatchCoordinator?> = callbackFlow {
        trySend(INITIAL_COORDINATORS[batchId])
        val listener = db.collection("coordinators").document(batchId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing coordinator for $batchId: ${error.message}")
                    return@addSnapshotListener
                }
                val coordinator = snapshot?.toObject(BatchCoordinator::class.java)
                if (coordinator != null) {
                    trySend(coordinator)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun saveCoordinator(coordinator: BatchCoordinator): Result<Unit> {
        return try {
            db.collection("coordinators").document(coordinator.batchId).set(coordinator).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving coordinator", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 3. STUDENT DIRECTORY & PRIVATE DATA
    // ==========================================
    fun observeStudentsByBatch(batchId: String): Flow<List<StudentPublic>> = callbackFlow {
        val initialList = INITIAL_STUDENTS.filter { it.batch == batchId }
        trySend(initialList)
        val listener = db.collection("students")
            .whereEqualTo("batch", batchId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing students for $batchId: ${error.message}")
                    return@addSnapshotListener
                }
                val students = snapshot?.toObjects(StudentPublic::class.java) ?: emptyList()
                if (students.isNotEmpty()) {
                    trySend(students)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun getPrivateStudentRecord(studentId: String): StudentPrivate? {
        return try {
            val doc = db.collection("privateStudentRecords").document(studentId).get().await()
            doc.toObject(StudentPrivate::class.java) ?: INITIAL_PRIVATE_RECORDS[studentId]
        } catch (e: Exception) {
            INITIAL_PRIVATE_RECORDS[studentId]
        }
    }

    suspend fun saveStudent(publicInfo: StudentPublic, privateInfo: StudentPrivate?): Result<Unit> {
        return try {
            val docRef = if (publicInfo.id.isBlank()) db.collection("students").document() else db.collection("students").document(publicInfo.id)
            val studentToSave = publicInfo.copy(id = docRef.id)
            docRef.set(studentToSave).await()

            if (privateInfo != null) {
                val privateToSave = privateInfo.copy(studentId = docRef.id)
                db.collection("privateStudentRecords").document(docRef.id).set(privateToSave).await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving student", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 4. SUBJECTS & SYLLABUS LECTURES
    // ==========================================
    fun observeSubjectsByBatch(batchId: String): Flow<List<Subject>> = callbackFlow {
        val initialSubjects = createDefaultSubjectsForBatch(batchId)
        trySend(initialSubjects)
        val listener = db.collection("subjects")
            .whereEqualTo("batchId", batchId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing subjects for $batchId: ${error.message}")
                    return@addSnapshotListener
                }
                val subjects = snapshot?.toObjects(Subject::class.java) ?: emptyList()
                if (subjects.isNotEmpty()) {
                    trySend(subjects)
                }
            }
        awaitClose { listener.remove() }
    }

    fun observeLectures(batchId: String, subjectId: String): Flow<List<SyllabusLecture>> = callbackFlow {
        val initialLectures = createDefaultLecturesForBatch(batchId).filter {
            subjectId.isBlank() || it.subjectId == subjectId
        }
        trySend(initialLectures)
        val query = if (subjectId.isBlank()) {
            db.collection("syllabusLectures").whereEqualTo("batchId", batchId)
        } else {
            db.collection("syllabusLectures")
                .whereEqualTo("batchId", batchId)
                .whereEqualTo("subjectId", subjectId)
        }
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(TAG, "Observing lectures: ${error.message}")
                return@addSnapshotListener
            }
            val lectures = snapshot?.toObjects(SyllabusLecture::class.java) ?: emptyList()
            if (lectures.isNotEmpty()) {
                trySend(lectures)
            }
        }
        awaitClose { listener.remove() }
    }

    suspend fun saveSyllabusLecture(lecture: SyllabusLecture): Result<Unit> {
        return try {
            val docRef = if (lecture.id.isBlank()) db.collection("syllabusLectures").document() else db.collection("syllabusLectures").document(lecture.id)
            val toSave = lecture.copy(id = docRef.id)
            docRef.set(toSave).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving lecture", e)
            Result.failure(e)
        }
    }

    suspend fun toggleLectureCompletion(lectureId: String, currentStatus: Boolean): Result<Unit> {
        return try {
            db.collection("syllabusLectures").document(lectureId)
                .update("isCompleted", !currentStatus)
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating lecture status", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 5. ATTENDANCE (CLASSROOM)
    // ==========================================
    fun observeAttendanceRecords(batchId: String): Flow<List<AttendanceRecord>> = callbackFlow {
        val listener = db.collection("studentAttendance")
            .whereEqualTo("batchId", batchId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing attendance: ${error.message}")
                    return@addSnapshotListener
                }
                val records = snapshot?.toObjects(AttendanceRecord::class.java) ?: emptyList()
                trySend(records)
            }
        awaitClose { listener.remove() }
    }

    suspend fun markAttendance(record: AttendanceRecord): Result<Unit> {
        return try {
            val docRef = if (record.id.isBlank()) db.collection("studentAttendance").document() else db.collection("studentAttendance").document(record.id)
            docRef.set(record.copy(id = docRef.id)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error marking attendance", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 6. COMPLAINTS & 4-DIGIT TRACKING CODE
    // ==========================================
    suspend fun registerComplaint(
        studentName: String,
        mobileNumber: String,
        batch: String,
        description: String,
        attachmentUrl: String = ""
    ): Result<String> {
        return try {
            val docRef = db.collection("complaints").document()
            val codeNum = Random.nextInt(1000, 9999)
            val codeStr = codeNum.toString()
            val nowStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())

            val complaint = Complaint(
                id = docRef.id,
                trackingCode = codeStr,
                studentName = studentName,
                mobileNumber = mobileNumber,
                batch = batch,
                description = description,
                attachmentUrl = attachmentUrl,
                status = "Received",
                resolutionNote = "Your grievance has been registered with the GNMTC SGNR Proctorial Board.",
                createdAtDate = nowStr,
                updatedAtDate = nowStr
            )
            docRef.set(complaint).await()
            Result.success(codeStr)
        } catch (e: Exception) {
            Log.e(TAG, "Error registering complaint", e)
            Result.failure(e)
        }
    }

    suspend fun getComplaintByTrackingCode(code: String): Complaint? {
        return try {
            val querySnapshot = db.collection("complaints")
                .whereEqualTo("trackingCode", code.trim())
                .limit(1)
                .get()
                .await()
            if (!querySnapshot.isEmpty) {
                querySnapshot.documents[0].toObject(Complaint::class.java)
            } else {
                if (code.trim() == "1024") {
                    Complaint(
                        id = "comp_sample_01",
                        trackingCode = "1024",
                        studentName = "Amanpreet Kaur",
                        mobileNumber = "+91 98281 11223",
                        batch = "Batch 2024-25",
                        description = "Requesting renewal of reference textbooks on Medical-Surgical Nursing in the college library reading hall.",
                        status = "Resolved",
                        resolutionNote = "Additional 20 copies of Medical-Surgical Nursing books have been procured and placed on Shelf B-3.",
                        createdAtDate = "12 Oct 2026, 11:30 AM",
                        updatedAtDate = "15 Oct 2026, 04:15 PM"
                    )
                } else null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching complaint status: ${e.message}")
            if (code.trim() == "1024") {
                Complaint(
                    id = "comp_sample_01",
                    trackingCode = "1024",
                    studentName = "Amanpreet Kaur",
                    mobileNumber = "+91 98281 11223",
                    batch = "Batch 2024-25",
                    description = "Requesting renewal of reference textbooks on Medical-Surgical Nursing in the college library reading hall.",
                    status = "Resolved",
                    resolutionNote = "Additional 20 copies of Medical-Surgical Nursing books have been procured and placed on Shelf B-3.",
                    createdAtDate = "12 Oct 2026, 11:30 AM",
                    updatedAtDate = "15 Oct 2026, 04:15 PM"
                )
            } else null
        }
    }

    fun observeAllComplaints(): Flow<List<Complaint>> = callbackFlow {
        val listener = db.collection("complaints")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing complaints: ${error.message}")
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(Complaint::class.java) ?: emptyList()
                if (list.isNotEmpty()) {
                    trySend(list)
                } else {
                    trySend(listOf(
                        Complaint(
                            id = "comp_sample_01",
                            trackingCode = "1024",
                            studentName = "Amanpreet Kaur",
                            mobileNumber = "+91 98281 11223",
                            batch = "Batch 2024-25",
                            description = "Requesting renewal of reference textbooks on Medical-Surgical Nursing in the college library reading hall.",
                            status = "Resolved",
                            resolutionNote = "Additional 20 copies of Medical-Surgical Nursing books have been procured and placed on Shelf B-3.",
                            createdAtDate = "12 Oct 2026, 11:30 AM",
                            updatedAtDate = "15 Oct 2026, 04:15 PM"
                        )
                    ))
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateComplaintStatus(complaintId: String, newStatus: String, note: String): Result<Unit> {
        return try {
            val nowStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
            db.collection("complaints").document(complaintId).update(
                mapOf(
                    "status" to newStatus,
                    "resolutionNote" to note,
                    "updatedAtDate" to nowStr
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating complaint status", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 7. NOTICES
    // ==========================================
    fun observeNotices(): Flow<List<Notice>> = callbackFlow {
        trySend(INITIAL_NOTICES)
        val listener = db.collection("notices")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing notices: ${error.message}")
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(Notice::class.java) ?: emptyList()
                if (list.isNotEmpty()) {
                    trySend(list.sortedByDescending { it.isPinned })
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun saveNotice(notice: Notice): Result<Unit> {
        return try {
            val docRef = if (notice.id.isBlank()) db.collection("notices").document() else db.collection("notices").document(notice.id)
            docRef.set(notice.copy(id = docRef.id)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving notice", e)
            Result.failure(e)
        }
    }

    suspend fun deleteNotice(noticeId: String): Result<Unit> {
        return try {
            db.collection("notices").document(noticeId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting notice", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 8. HOLIDAY CALENDAR
    // ==========================================
    fun observeHolidays(): Flow<List<Holiday>> = callbackFlow {
        trySend(INITIAL_HOLIDAYS)
        val listener = db.collection("holidays")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing holidays: ${error.message}")
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(Holiday::class.java) ?: emptyList()
                if (list.isNotEmpty()) {
                    trySend(list)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun saveHoliday(holiday: Holiday): Result<Unit> {
        return try {
            val docRef = if (holiday.id.isBlank()) db.collection("holidays").document() else db.collection("holidays").document(holiday.id)
            docRef.set(holiday.copy(id = docRef.id)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving holiday", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // 9. CLINICAL DUTY & ROSTER
    // ==========================================
    fun observeClinicalRosters(batchId: String): Flow<List<ClinicalRoster>> = callbackFlow {
        val defaultRoster = ClinicalRoster(
            id = "roster_${batchId.replace(" ", "_")}",
            batchId = batchId,
            title = "Hospital Clinical Duty Chart - $batchId (October-November)",
            imageUrl = "",
            hospitalLocation = "District Hospital (Govt. Hospital), Sri Ganganagar",
            effectiveDate = "01 Oct 2026 to 30 Nov 2026",
            publishedDate = "28 Sep 2026",
            updatedBy = "Vice Principal Sunita Verma"
        )
        trySend(listOf(defaultRoster))
        val listener = db.collection("clinicalRosters")
            .whereEqualTo("batchId", batchId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing rosters for $batchId: ${error.message}")
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(ClinicalRoster::class.java) ?: emptyList()
                if (list.isNotEmpty()) {
                    trySend(list)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun saveClinicalRoster(roster: ClinicalRoster): Result<Unit> {
        return try {
            val docRef = if (roster.id.isBlank()) db.collection("clinicalRosters").document() else db.collection("clinicalRosters").document(roster.id)
            docRef.set(roster.copy(id = docRef.id)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving clinical roster", e)
            Result.failure(e)
        }
    }

    fun observeClinicalAttendance(batchId: String, date: String): Flow<List<ClinicalDutyAttendance>> = callbackFlow {
        val listener = db.collection("clinicalAttendance")
            .whereEqualTo("batchId", batchId)
            .whereEqualTo("date", date)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Observing clinical attendance: ${error.message}")
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(ClinicalDutyAttendance::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun markClinicalAttendance(record: ClinicalDutyAttendance): Result<Unit> {
        return try {
            val docRef = if (record.id.isBlank()) db.collection("clinicalAttendance").document() else db.collection("clinicalAttendance").document(record.id)
            docRef.set(record.copy(id = docRef.id)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving clinical attendance", e)
            Result.failure(e)
        }
    }

    // ==========================================
    // SEED INITIAL DATABASE ON FIRST RUN
    // ==========================================
    suspend fun seedInitialDataIfEmpty() {
        try {
            val teachersCheck = db.collection("teachers").limit(1).get().await()
            if (teachersCheck.isEmpty) {
                Log.d(TAG, "Seeding initial GNMTC SGNR data into Firestore...")
                runCatching {
                    for (t in INITIAL_TEACHERS) {
                        db.collection("teachers").document(t.id).set(t).await()
                    }
                }
                runCatching {
                    for (c in INITIAL_COORDINATORS.values) {
                        db.collection("coordinators").document(c.batchId).set(c).await()
                    }
                }
                runCatching {
                    for (s in INITIAL_STUDENTS) {
                        db.collection("students").document(s.id).set(s).await()
                        INITIAL_PRIVATE_RECORDS[s.id]?.let { priv ->
                            db.collection("privateStudentRecords").document(priv.studentId).set(priv).await()
                        }
                    }
                }
                runCatching {
                    for (batch in BATCHES) {
                        val subs = createDefaultSubjectsForBatch(batch)
                        for (sub in subs) {
                            db.collection("subjects").document(sub.id).set(sub).await()
                        }
                        val lecs = createDefaultLecturesForBatch(batch)
                        for (lec in lecs) {
                            db.collection("syllabusLectures").document(lec.id).set(lec).await()
                        }
                    }
                }
                runCatching {
                    for (n in INITIAL_NOTICES) {
                        db.collection("notices").document(n.id).set(n).await()
                    }
                }
                runCatching {
                    for (h in INITIAL_HOLIDAYS) {
                        db.collection("holidays").document(h.id).set(h).await()
                    }
                }
                Log.d(TAG, "Initial seed completed successfully.")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Initial seed skipped: ${e.message}")
        }
    }
}
