package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.arkDataStore: DataStore<Preferences> by preferencesDataStore(name = "ark_prefs")

class ArkPreferencesRepository(private val context: Context) {
    private val themeModeKey = stringPreferencesKey("theme_mode")

    val themeModeFlow: Flow<String> = context.arkDataStore.data.map { prefs ->
        prefs[themeModeKey] ?: "system"
    }

    suspend fun setThemeMode(mode: String) {
        context.arkDataStore.edit { prefs ->
            prefs[themeModeKey] = mode
        }
    }
}
