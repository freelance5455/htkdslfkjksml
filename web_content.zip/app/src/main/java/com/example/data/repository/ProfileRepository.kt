package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.dao.ProfileDao
import com.example.data.model.ProfileEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ProfileRepository(
    private val profileDao: ProfileDao,
    private val internalFilesDir: File
) {
    val profileFlow: Flow<ProfileEntity?> = profileDao.getProfileFlow()

    suspend fun getProfile(): ProfileEntity? = profileDao.getProfile()

    suspend fun updateProfileText(name: String?, instituteName: String?) {
        val current = profileDao.getProfile() ?: ProfileEntity(id = 1)
        val trimmedName = name?.trim()?.ifEmpty { null }
        val trimmedInstitute = instituteName?.trim()?.ifEmpty { null }
        val updated = current.copy(
            name = trimmedName,
            instituteName = trimmedInstitute
        )
        profileDao.insertOrUpdate(updated)
    }

    suspend fun savePhoto(context: Context, sourceUri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val destinationFile = File(internalFilesDir, "profile_avatar.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { inputStream ->
                FileOutputStream(destinationFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            val localPath = destinationFile.absolutePath
            val current = profileDao.getProfile() ?: ProfileEntity(id = 1)
            val updated = current.copy(photoUri = localPath)
            profileDao.insertOrUpdate(updated)
            localPath
        } catch (e: Exception) {
            null
        }
    }

    suspend fun removePhoto() = withContext(Dispatchers.IO) {
        val avatarFile = File(internalFilesDir, "profile_avatar.jpg")
        if (avatarFile.exists()) {
            avatarFile.delete()
        }
        val current = profileDao.getProfile() ?: ProfileEntity(id = 1)
        val updated = current.copy(photoUri = null)
        profileDao.insertOrUpdate(updated)
    }
}
