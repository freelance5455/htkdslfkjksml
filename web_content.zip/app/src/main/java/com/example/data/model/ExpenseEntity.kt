package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class RecurrenceFrequency {
    ONE_TIME,
    DAILY,
    WEEKLY,
    MONTHLY,
    QUARTERLY,
    YEARLY
}

val EXPENSE_CATEGORIES = listOf(
    "Bank charges",
    "Platform charges",
    "Salaries",
    "Rent",
    "Electricity",
    "Internet and mobile bills",
    "Software subscriptions",
    "Marketing",
    "Accounting and compliance",
    "Other operating expenses"
)

val PAYMENT_METHODS = listOf(
    "Cash",
    "UPI",
    "Net Banking",
    "Credit Card",
    "Debit Card",
    "Other"
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String,
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val paymentMethod: String = "UPI",
    val isPaid: Boolean = true,
    val notes: String = "",
    val recurrence: String = RecurrenceFrequency.ONE_TIME.name,
    val startDate: Long = System.currentTimeMillis(),
    val endDate: Long? = null,
    val isRecurringActive: Boolean = true,
    val linkedTransactionId: String? = null
)
