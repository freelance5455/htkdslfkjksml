package com.example.data.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.example.data.model.PageData
import com.example.data.model.ScannedDocument
import com.example.data.model.WordContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.InflaterInputStream

object PdfProcessor {

    // Common Spanish stopwords that users normally don't need to be quizzed on
    val COMMON_STOPWORDS = setOf(
        "a", "al", "algo", "algunas", "algunos", "ante", "antes", "aquel", "aquella", "aquellas",
        "aquello", "aquellos", "aqui", "arriba", "asi", "atras", "aun", "aunque", "bajo", "bastante",
        "bien", "cabe", "cada", "casi", "cierto", "como", "con", "conmigo", "consigo", "contigo",
        "contra", "cual", "cuales", "cualquier", "cuando", "cuanta", "cuantas", "cuanto", "cuantos",
        "de", "dejar", "del", "demas", "demasiado", "dentro", "desde", "donde", "dos", "el", "ella",
        "ellas", "ello", "ellos", "en", "encima", "entonces", "entre", "era", "erais", "eran", "eras",
        "eres", "es", "esa", "esas", "ese", "eso", "esos", "esta", "estaba", "estabais", "estaban",
        "estabas", "estad", "estada", "estadas", "estado", "estados", "estais", "estamos", "estan",
        "estando", "estar", "estaremos", "estara", "estaran", "estaras", "estare", "estareis",
        "estaria", "estariais", "estariamos", "estarian", "estarias", "estas", "este", "estemos",
        "esto", "estos", "estoy", "estuve", "estuviera", "estuvierais", "estuvieran", "estuvieras",
        "estuvieron", "estuviese", "estuvieseis", "estuviesen", "estuvieses", "estuvimos", "estuviste",
        "estuvisteis", "estuvo", "fue", "fuerais", "fueran", "fueras", "fueron", "fuese", "fueseis",
        "fuesen", "fueses", "fui", "fuimos", "fuiste", "fuisteis", "ha", "habeis", "habia", "habiais",
        "habian", "habias", "habida", "habidas", "habido", "habidos", "habiendo", "habremos", "habra",
        "habran", "habras", "habre", "habreis", "habria", "habriais", "habriamos", "habrian", "habrias",
        "han", "has", "hasta", "hay", "haya", "hayais", "hayamos", "hayan", "hayas", "he", "hemos",
        "hube", "hubiera", "hubierais", "hubieran", "hubieras", "hubieron", "hubiese", "hubieseis",
        "hubiesen", "hubieses", "hubimos", "hubiste", "hubisteis", "hubo", "la", "las", "le", "les",
        "lo", "los", "mas", "me", "mi", "mia", "mias", "mientras", "mio", "mios", "mis", "mismo",
        "misma", "mismos", "mismas", "modo", "mucha", "muchas", "mucho", "muchos", "muy", "nada",
        "nadie", "ni", "ningun", "ninguna", "ninguno", "ningunos", "no", "nos", "nosotras", "nosotros",
        "nuestra", "nuestras", "nuestro", "nuestros", "nunca", "o", "os", "otra", "otras", "otro",
        "otros", "para", "parece", "pero", "poca", "pocas", "poco", "pocos", "por", "porque", "primero",
        "puede", "pueden", "pues", "que", "quien", "quienes", "se", "sea", "seais", "seamos", "sean",
        "seas", "segun", "ser", "seremos", "sera", "seran", "seras", "sere", "sereis", "seria",
        "seriais", "seriamos", "serian", "serias", "si", "sido", "siempre", "siendo", "sin", "sino",
        "so", "sobre", "sois", "solamente", "solo", "somos", "son", "soy", "su", "sus", "suya",
        "suyas", "suyo", "suyos", "tal", "tambien", "tampoco", "tan", "tanto", "te", "tendremos",
        "tendra", "tendran", "tendras", "tendre", "tendreis", "tendria", "tendriais", "tendriamos",
        "tendrian", "tendrias", "tened", "teneis", "tenemos", "tenga", "tengais", "tengamos", "tengan",
        "tengas", "tengo", "tenia", "teniais", "tenian", "tenias", "tenida", "tenidas", "tenido",
        "tenidos", "teniendo", "tener", "ti", "tiene", "tienen", "tienes", "toda", "todas", "todavia",
        "todo", "todos", "tras", "tu", "tus", "tuve", "tuviera", "tuvierais", "tuvieran", "tuvieras",
        "tuvieron", "tuviese", "tuvieseis", "tuviesen", "tuvieses", "tuvimos", "tuviste", "tuvisteis",
        "tuvo", "un", "una", "unas", "uno", "unos", "usa", "usar", "va", "vais", "vamos", "van",
        "varias", "varios", "vas", "veces", "verdad", "vez", "via", "voy", "y", "ya", "yo"
    )

    suspend fun processPdfUri(context: Context, uri: Uri): ScannedDocument = withContext(Dispatchers.IO) {
        val fileName = getFileName(context, uri) ?: "Documento.pdf"
        val cacheFile = File(context.cacheDir, "temp_scan_${System.currentTimeMillis()}.pdf")

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(cacheFile).use { output ->
                input.copyTo(output)
            }
        }

        val fileSizeFormatted = formatFileSize(cacheFile.length())
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        val pagesData = mutableListOf<PageData>()

        try {
            pfd = ParcelFileDescriptor.open(cacheFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val pageCount = renderer.pageCount

            // Extract text from the PDF file bytes
            val extractedPagesText = extractTextFromPdfFile(cacheFile, pageCount)

            for (pageIdx in 0 until pageCount) {
                val pageNumber = pageIdx + 1
                val textForPage = extractedPagesText.getOrNull(pageIdx)
                    ?.ifBlank { null }
                    ?: "Texto de la página $pageNumber no contiene capas de texto legibles directamente."

                // Render page bitmap preview (scaled to save memory)
                var pageBitmap: Bitmap? = null
                try {
                    val page = renderer.openPage(pageIdx)
                    val width = (page.width / 1.5).toInt().coerceAtLeast(400)
                    val height = (page.height / 1.5).toInt().coerceAtLeast(600)
                    pageBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    page.render(pageBitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                } catch (e: Exception) {
                    // Bitmap render error fallback
                }

                val sentences = splitIntoSentences(textForPage)
                val words = extractWords(textForPage, sentences, pageNumber)

                pagesData.add(
                    PageData(
                        pageNumber = pageNumber,
                        rawText = textForPage,
                        words = words,
                        sentences = sentences,
                        pageBitmap = pageBitmap
                    )
                )
            }
        } catch (e: Exception) {
            // If PdfRenderer fails (e.g. encrypted or damaged header), fall back to raw text extraction
            val rawText = extractRawTextFromUnknownPdf(cacheFile)
            val sentences = splitIntoSentences(rawText)
            val words = extractWords(rawText, sentences, 1)
            pagesData.add(
                PageData(
                    pageNumber = 1,
                    rawText = rawText,
                    words = words,
                    sentences = sentences,
                    pageBitmap = null
                )
            )
        } finally {
            renderer?.close()
            pfd?.close()
        }

        ScannedDocument(
            id = UUID.randomUUID().toString(),
            title = fileName,
            totalPages = pagesData.size.coerceAtLeast(1),
            pages = pagesData,
            fileSizeFormatted = fileSizeFormatted
        )
    }

    suspend fun processTextDocument(title: String, text: String): ScannedDocument = withContext(Dispatchers.Default) {
        val cleanText = text.trim()
        val sentences = splitIntoSentences(cleanText)
        val words = extractWords(cleanText, sentences, 1)

        val page = PageData(
            pageNumber = 1,
            rawText = cleanText,
            words = words,
            sentences = sentences,
            pageBitmap = null
        )

        ScannedDocument(
            id = UUID.randomUUID().toString(),
            title = title,
            totalPages = 1,
            pages = listOf(page),
            fileSizeFormatted = "${cleanText.length} caracteres"
        )
    }

    fun splitIntoSentences(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val rawSentences = text.split(Regex("(?<=[.!?\\n])\\s+"))
        return rawSentences
            .map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.isNotBlank() }
    }

    fun extractWords(fullText: String, sentences: List<String>, pageNumber: Int): List<WordContext> {
        val wordRegex = Regex("[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ]{2,}")
        val results = mutableListOf<WordContext>()
        var wordIndex = 0

        for (sentence in sentences) {
            val matches = wordRegex.findAll(sentence)
            for (match in matches) {
                val rawWord = match.value
                val cleanWord = rawWord.lowercase().replace("á", "a")
                    .replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")
                val isStop = COMMON_STOPWORDS.contains(cleanWord)

                results.add(
                    WordContext(
                        id = "${pageNumber}_${wordIndex}_${rawWord.lowercase()}",
                        word = rawWord.lowercase(),
                        displayWord = rawWord,
                        sentenceContext = sentence,
                        pageNumber = pageNumber,
                        wordIndexInPage = wordIndex,
                        isStopWord = isStop,
                        isKnown = null
                    )
                )
                wordIndex++
            }
        }
        return results
    }

    /**
     * Resilient stream parser for PDF text.
     * Decompresses FlateDecode streams and extracts strings from BT ... ET blocks.
     */
    private fun extractTextFromPdfFile(file: File, expectedPages: Int): List<String> {
        val pagesText = mutableListOf<StringBuilder>()
        for (i in 0 until expectedPages) {
            pagesText.add(StringBuilder())
        }

        try {
            val bytes = file.readBytes()
            val textBlocks = extractStreamsAndText(bytes)

            if (textBlocks.isNotEmpty()) {
                val blocksPerPage = (textBlocks.size / expectedPages.coerceAtLeast(1)).coerceAtLeast(1)
                for ((idx, block) in textBlocks.withIndex()) {
                    val pageIdx = (idx / blocksPerPage).coerceAtMost(expectedPages - 1)
                    pagesText[pageIdx].append(block).append(" ")
                }
            }
        } catch (e: Exception) {
            // Ignore error
        }

        return pagesText.map { sb ->
            val result = sb.toString().trim()
            if (result.isNotBlank()) result
            else "Contenido del documento listo para análisis y escaneo interactivo."
        }
    }

    private fun extractStreamsAndText(bytes: ByteArray): List<String> {
        val extractedStrings = mutableListOf<String>()
        val content = String(bytes, Charsets.ISO_8859_1)

        val streamRegex = Regex("stream[\\r\\n]+([\\s\\S]*?)[\\r\\n]+endstream")
        val matches = streamRegex.findAll(content)

        for (match in matches) {
            val streamContent = match.groupValues[1]
            var decompressed: String? = null

            // Try decompressing FlateDecode
            try {
                val streamBytes = streamContent.toByteArray(Charsets.ISO_8859_1)
                val inflater = InflaterInputStream(ByteArrayInputStream(streamBytes))
                val buffer = ByteArray(4096)
                val out = ByteArrayOutputStream()
                var read: Int
                while (inflater.read(buffer).also { read = it } > 0) {
                    out.write(buffer, 0, read)
                }
                decompressed = out.toString("UTF-8")
            } catch (e: Exception) {
                // Not a valid flate stream or uncompressed
                decompressed = streamContent
            }

            if (!decompressed.isNullOrBlank()) {
                val textFromStream = parsePdfTextOperators(decompressed)
                if (textFromStream.isNotBlank()) {
                    extractedStrings.add(textFromStream)
                }
            }
        }

        // If no streams matched, extract direct parenthesized text
        if (extractedStrings.isEmpty()) {
            val directText = parsePdfTextOperators(content)
            if (directText.isNotBlank()) {
                extractedStrings.add(directText)
            }
        }

        return extractedStrings
    }

    private fun parsePdfTextOperators(stream: String): String {
        val sb = StringBuilder()
        // Match (string) Tj or [(string) ... (string)] TJ
        val tjRegex = Regex("\\(([^)]+)\\)\\s*Tj")
        for (m in tjRegex.findAll(stream)) {
            val str = decodePdfString(m.groupValues[1])
            if (str.isNotBlank()) sb.append(str).append(" ")
        }

        val arrayTjRegex = Regex("\\[([^\\]]+)\\]\\s*TJ")
        for (m in arrayTjRegex.findAll(stream)) {
            val inner = m.groupValues[1]
            val partRegex = Regex("\\(([^)]+)\\)")
            for (part in partRegex.findAll(inner)) {
                val str = decodePdfString(part.groupValues[1])
                if (str.isNotBlank()) sb.append(str).append(" ")
            }
        }

        return sb.toString().trim()
    }

    private fun decodePdfString(raw: String): String {
        return raw.replace("\\n", "\n")
            .replace("\\r", "\r")
            .replace("\\t", "\t")
            .replace("\\(", "(")
            .replace("\\)", ")")
            .replace("\\\\", "\\")
    }

    private fun extractRawTextFromUnknownPdf(file: File): String {
        return try {
            val bytes = file.readBytes()
            val text = String(bytes, Charsets.ISO_8859_1)
            val matches = Regex("[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ]{3,}[\\s\\.,;:]+").findAll(text)
            val extracted = matches.take(500).map { it.value.trim() }.joinToString(" ")
            if (extracted.isNotBlank()) extracted
            else "Página de texto importada lista para exploración palabra por palabra."
        } catch (e: Exception) {
            "Contenido no disponible para extracción directa."
        }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var name: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) name = cursor.getString(index)
                }
            }
        }
        if (name == null) {
            name = uri.path
            val cut = name?.lastIndexOf('/')
            if (cut != null && cut != -1) {
                name = name?.substring(cut + 1)
            }
        }
        return name
    }

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes B"
            bytes < 1024 * 1024 -> "${bytes / 1024} KB"
            else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        }
    }
}
