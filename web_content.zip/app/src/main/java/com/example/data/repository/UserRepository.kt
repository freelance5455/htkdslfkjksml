package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.NotificationItem
import com.example.data.model.UserPrivateSettings
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class UserRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            UserProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else null
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid != null) {
                        handleFirestoreError(ex, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observePrivateSettings(userId: String): Flow<UserPrivateSettings?> = flow {
        val path = "users/$userId/private/settings"
        emitAll(
            db.collection("users").document(userId)
                .collection("private").document("settings")
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            UserPrivateSettings::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else null
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeLeaderboard(limitCount: Long = 50L): Flow<List<UserProfile>> = flow {
        val path = "users"
        emitAll(
            db.collection("users")
                .whereEqualTo("optOutLeaderboard", false)
                .limit(limitCount)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        UserProfile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.points }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeNotifications(userId: String): Flow<List<NotificationItem>> = flow {
        val path = "users/$userId/notifications"
        emitAll(
            db.collection("users").document(userId).collection("notifications")
                .limit(40)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        NotificationItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun checkUsernameAvailable(username: String, currentUid: String): Result<Boolean> = runCatching {
        val clean = username.trim().lowercase().replace(Regex("[^a-z0-9_]"), "")
        require(clean.length in 3..24) { "Username must be 3-24 lowercase letters, numbers, or underscores." }
        val snap = db.collection("users")
            .whereEqualTo("username", clean)
            .limit(3)
            .get()
            .await()
        snap.documents.none { it.id != currentUid }
    }

    suspend fun fetchUserProfileOnce(userId: String): UserProfile? = runCatching {
        val snap = db.collection("users").document(userId).get().await()
        if (snap.exists()) {
            snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } else null
    }.getOrNull()

    suspend fun searchUsersExplore(query: String, currentUid: String): Result<List<UserProfile>> = runCatching {
        requireUserId()
        val clean = query.trim().lowercase().removePrefix("@")
        if (clean.isBlank()) {
            val snap = db.collection("users").limit(25).get().await()
            return@runCatching snap.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .filter { it.userId != currentUid && !it.isRestricted }
                .sortedByDescending { it.followersCount + (if (!it.isPrivateAccount) 5L else 0L) }
        }
        val prefixSnap = db.collection("users")
            .orderBy("username")
            .startAt(clean)
            .endAt(clean + "\uf8ff")
            .limit(20)
            .get()
            .await()
        prefixSnap.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .filter { it.userId != currentUid && !it.isRestricted }
    }

    suspend fun fetchRecommendedCreators(currentUid: String, excludeUids: Set<String>): List<UserProfile> {
        return runCatching {
            val snap = db.collection("users").limit(30).get().await()
            snap.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .filter { it.userId != currentUid && !it.isRestricted && !excludeUids.contains(it.userId) }
                .sortedWith(
                    compareByDescending<UserProfile> { !it.isPrivateAccount }
                        .thenByDescending { it.followersCount }
                        .thenByDescending { it.postsCount }
                )
                .take(15)
        }.getOrDefault(emptyList())
    }

    suspend fun createProfile(
        username: String,
        displayTag: String,
        bio: String,
        avatarPreset: String,
        ageBracket: String,
        parentalConsentApproved: Boolean,
        email: String,
        parentEmailHint: String = "",
        fullName: String = ""
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val cleanUsername = username.trim().lowercase().replace(Regex("[^a-z0-9_]"), "")
        require(cleanUsername.length in 3..24) { "Username must be 3-24 lowercase letters, numbers, or underscores." }

        val userDoc = db.collection("users").document(uid)
        val payload = hashMapOf<String, Any>(
            "userId" to uid,
            "username" to cleanUsername,
            "displayTag" to displayTag.trim().take(30).ifBlank { cleanUsername },
            "fullName" to fullName.trim().take(40),
            "bio" to bio.trim().take(160),
            "website" to "",
            "avatarPreset" to avatarPreset.ifBlank { "prism_cyan" },
            "profileTheme" to "liquid_light",
            "level" to 1L,
            "xp" to 50L,
            "points" to 50L,
            "gamesPlayed" to 0L,
            "challengesCompleted" to 0L,
            "friendsCount" to 0L,
            "groupsCount" to 0L,
            "postsCount" to 0L,
            "followersCount" to 0L,
            "followingCount" to 0L,
            "badges" to listOf("ARK Pioneer"),
            "isPrivateAccount" to true,
            "allowFriendRequests" to if (ageBracket == "under_13") "group_members" else "everyone",
            "allowMessagesFrom" to if (ageBracket == "under_13") "friends" else "followers",
            "requireTagApproval" to false,
            "hiddenStoryFromUids" to emptyList<String>(),
            "showOnlineStatus" to true,
            "optOutLeaderboard" to false,
            "isOnline" to true,
            "ageBracket" to ageBracket,
            "parentalConsentApproved" to parentalConsentApproved,
            "isRestricted" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        val settingsRef = userDoc.collection("private").document("settings")
        val settingsPayload = hashMapOf<String, Any>(
            "userId" to uid,
            "email" to email.take(120),
            "quietHoursEnabled" to false,
            "quietStartHour" to 22L,
            "quietEndHour" to 7L,
            "notifyFriendRequests" to true,
            "notifyGroupInvites" to true,
            "notifyGameInvites" to true,
            "notifyChallenges" to true,
            "notifyAchievements" to true,
            "parentEmailHint" to parentEmailHint.take(120),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        val notifRef = userDoc.collection("notifications").document()
        val welcomeNotif = hashMapOf<String, Any>(
            "userId" to uid,
            "senderId" to uid,
            "senderUsername" to cleanUsername,
            "type" to "achievement",
            "title" to "Welcome to ARK!",
            "body" to "You unlocked the ARK Pioneer badge and +50 starter points.",
            "isRead" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )

        val batch = db.batch()
        batch.set(userDoc, payload)
        batch.set(settingsRef, settingsPayload)
        batch.set(notifRef, welcomeNotif)
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, userDoc.path)
            throw e
        }
    }

    suspend fun updateProfileCustomization(
        displayTag: String,
        bio: String,
        avatarPreset: String,
        profileTheme: String,
        avatarImageBase64: String? = null
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val updates = mutableMapOf<String, Any>(
            "displayTag" to displayTag.trim().take(30).ifBlank { "Player" },
            "bio" to bio.trim().take(160),
            "avatarPreset" to avatarPreset,
            "profileTheme" to profileTheme,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!avatarImageBase64.isNullOrBlank()) {
            updates["avatarImageBase64"] = avatarImageBase64
        }
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun updateProfileDetails(
        username: String,
        fullName: String,
        displayTag: String,
        bio: String,
        website: String,
        avatarPreset: String,
        profileTheme: String,
        avatarImageBase64: String? = null
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val cleanUsername = username.trim().lowercase().replace(Regex("[^a-z0-9_]"), "")
        require(cleanUsername.length in 3..24) { "Username must be 3-24 lowercase letters, numbers, or underscores." }
        val available = checkUsernameAvailable(cleanUsername, uid).getOrThrow()
        require(available) { "Username @$cleanUsername is already taken." }

        val cleanWebsite = website.trim().take(120)
        val docRef = db.collection("users").document(uid)
        val updates = mutableMapOf<String, Any>(
            "username" to cleanUsername,
            "fullName" to fullName.trim().take(40),
            "displayTag" to displayTag.trim().take(30).ifBlank { cleanUsername },
            "bio" to bio.trim().take(160),
            "website" to cleanWebsite,
            "avatarPreset" to avatarPreset,
            "profileTheme" to profileTheme,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!avatarImageBase64.isNullOrBlank()) {
            updates["avatarImageBase64"] = avatarImageBase64
        }
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun updatePrivacyPreferences(
        isPrivateAccount: Boolean,
        allowFriendRequests: String,
        showOnlineStatus: Boolean,
        optOutLeaderboard: Boolean,
        allowMessagesFrom: String = "followers",
        requireTagApproval: Boolean = false,
        hiddenStoryFromUids: List<String> = emptyList()
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val safeMsgPref = allowMessagesFrom.takeIf { it in setOf("everyone", "followers", "friends", "nobody") } ?: "followers"
        val updates = mapOf(
            "isPrivateAccount" to isPrivateAccount,
            "allowFriendRequests" to allowFriendRequests,
            "allowMessagesFrom" to safeMsgPref,
            "requireTagApproval" to requireTagApproval,
            "hiddenStoryFromUids" to hiddenStoryFromUids.distinct().take(100),
            "showOnlineStatus" to showOnlineStatus,
            "optOutLeaderboard" to optOutLeaderboard,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun updateNotificationPreferences(settings: UserPrivateSettings): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("private").document("settings")
        val payload = mapOf(
            "userId" to uid,
            "email" to settings.email.take(120),
            "quietHoursEnabled" to settings.quietHoursEnabled,
            "quietStartHour" to settings.quietStartHour,
            "quietEndHour" to settings.quietEndHour,
            "notifyFriendRequests" to settings.notifyFriendRequests,
            "notifyGroupInvites" to settings.notifyGroupInvites,
            "notifyGameInvites" to settings.notifyGameInvites,
            "notifyChallenges" to settings.notifyChallenges,
            "notifyAchievements" to settings.notifyAchievements,
            "parentEmailHint" to settings.parentEmailHint.take(120),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.set(payload, SetOptions.merge()).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun awardProgress(
        userId: String,
        pointsDelta: Long,
        xpDelta: Long,
        incrementGames: Boolean = false,
        incrementChallenges: Boolean = false,
        newBadge: String? = null
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(uid == userId) { "Can only award progress for authenticated user." }
        val boundedPoints = pointsDelta.coerceIn(0L, 250L)
        val boundedXp = xpDelta.coerceIn(0L, 250L)
        val docRef = db.collection("users").document(uid)
        try {
            db.runTransaction { tx ->
                val snap = tx.get(docRef)
                val currentPoints = snap.getLong("points") ?: 0L
                val currentXp = snap.getLong("xp") ?: 0L
                val currentGames = snap.getLong("gamesPlayed") ?: 0L
                val currentChallenges = snap.getLong("challengesCompleted") ?: 0L
                val currentBadges = (snap.get("badges") as? List<*>)?.filterIsInstance<String>() ?: emptyList()

                val nextPoints = currentPoints + boundedPoints
                val nextXp = currentXp + boundedXp
                val nextLevel = ((nextXp / 200L) + 1L).coerceAtMost(500L)
                val updatedBadges = if (newBadge != null && !currentBadges.contains(newBadge) && currentBadges.size < 30) {
                    currentBadges + newBadge
                } else {
                    currentBadges
                }

                tx.update(
                    docRef,
                    mapOf(
                        "points" to nextPoints,
                        "xp" to nextXp,
                        "level" to nextLevel,
                        "gamesPlayed" to if (incrementGames) currentGames + 1L else currentGames,
                        "challengesCompleted" to if (incrementChallenges) currentChallenges + 1L else currentChallenges,
                        "badges" to updatedBadges,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun sendNotification(
        recipientUid: String,
        senderUsername: String,
        type: String,
        title: String,
        body: String,
        refId: String? = null
    ) {
        val senderUid = requireUserId()
        val notifRef = db.collection("users").document(recipientUid).collection("notifications").document()
        val payload = mutableMapOf<String, Any>(
            "userId" to recipientUid,
            "senderId" to senderUid,
            "senderUsername" to senderUsername.take(30).ifBlank { "player" },
            "type" to type,
            "title" to title.take(100),
            "body" to body.take(240),
            "isRead" to false,
            "createdAt" to FieldValue.serverTimestamp()
        )
        if (!refId.isNullOrBlank()) {
            payload["refId"] = refId.take(128)
        }
        try {
            notifRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, notifRef.path)
        }
    }

    suspend fun markNotificationRead(notificationId: String) {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("notifications").document(notificationId)
        try {
            docRef.update("isRead", true).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
        }
    }

    suspend fun markAllNotificationsRead(userId: String) {
        val uid = requireUserId()
        if (uid != userId) return
        val col = db.collection("users").document(uid).collection("notifications")
        try {
            val unread = col.whereEqualTo("isRead", false).limit(50).get().await()
            if (unread.isEmpty) return
            val batch = db.batch()
            unread.documents.forEach { doc -> batch.update(doc.reference, "isRead", true) }
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, col.path)
        }
    }

    suspend fun deleteAccountAndUserData(): Result<Unit> = runCatching {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)
        try {
            val subCollections = listOf(
                "private", "notifications", "friends", "followers", "following",
                "blocked", "restricted", "challengeProgress", "bookmarks", "drafts",
                "mutedUsers", "hiddenPosts"
            )
            val refsToDelete = mutableListOf<com.google.firebase.firestore.DocumentReference>()
            for (sub in subCollections) {
                runCatching { userDoc.collection(sub).get().await() }.getOrNull()?.documents?.forEach {
                    refsToDelete.add(it.reference)
                }
            }
            refsToDelete.chunked(400).forEach { chunk ->
                val b = db.batch()
                chunk.forEach { b.delete(it) }
                b.commit().await()
            }
            userDoc.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, userDoc.path)
            throw e
        }
    }
}
