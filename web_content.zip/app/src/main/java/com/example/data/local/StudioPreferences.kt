package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class StudioPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("edito_x_studio_prefs", Context.MODE_PRIVATE)

    var upiId: String
        get() = prefs.getString(KEY_UPI_ID, DEFAULT_UPI_ID) ?: DEFAULT_UPI_ID
        set(value) = prefs.edit().putString(KEY_UPI_ID, value).apply()

    var payeeName: String
        get() = prefs.getString(KEY_PAYEE_NAME, DEFAULT_PAYEE_NAME) ?: DEFAULT_PAYEE_NAME
        set(value) = prefs.edit().putString(KEY_PAYEE_NAME, value).apply()

    var studioContact: String
        get() = prefs.getString(KEY_STUDIO_CONTACT, DEFAULT_CONTACT) ?: DEFAULT_CONTACT
        set(value) = prefs.edit().putString(KEY_STUDIO_CONTACT, value).apply()

    var telegramBotToken: String
        get() = prefs.getString(KEY_TELEGRAM_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_TELEGRAM_TOKEN, value).apply()

    var telegramChatId: String
        get() = prefs.getString(KEY_TELEGRAM_CHAT_ID, "") ?: ""
        set(value) = prefs.edit().putString(KEY_TELEGRAM_CHAT_ID, value).apply()

    companion object {
        private const val KEY_UPI_ID = "key_upi_id"
        private const val KEY_PAYEE_NAME = "key_payee_name"
        private const val KEY_STUDIO_CONTACT = "key_studio_contact"
        private const val KEY_TELEGRAM_TOKEN = "key_telegram_token"
        private const val KEY_TELEGRAM_CHAT_ID = "key_telegram_chat_id"

        const val DEFAULT_UPI_ID = "8018948884@paytm"
        const val DEFAULT_PAYEE_NAME = "EditoXAIStudio"
        const val DEFAULT_CONTACT = "8018948884"
    }
}
