package com.example.data.model

import android.graphics.Bitmap

data class ApkInfo(
    val fileName: String,
    val filePath: String,
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdkVersion: Int,
    val targetSdkVersion: Int,
    val fileSizeBytes: Long,
    val formattedSize: String,
    val iconBitmap: Bitmap? = null,
    val permissions: List<String> = emptyList(),
    val conversionTimestamp: Long = System.currentTimeMillis(),
    val sourceType: String = "ZIP"
)

enum class ConversionStage {
    IDLE,
    READING,
    EXTRACTING,
    PACKAGING,
    SIGNING,
    VERIFYING,
    COMPLETE,
    ERROR
}

data class ConversionProgress(
    val stage: ConversionStage = ConversionStage.IDLE,
    val progress: Float = 0f,
    val message: String = "",
    val currentFile: String = ""
)

data class SampleItem(
    val id: String,
    val title: String,
    val description: String,
    val assetName: String,
    val type: String
)
