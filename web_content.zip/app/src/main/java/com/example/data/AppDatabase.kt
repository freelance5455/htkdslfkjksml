package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.KeystoreDao
import com.example.data.dao.NotificationDao
import com.example.data.dao.ProjectDao
import com.example.data.model.KeystoreEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.ProjectEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [ProjectEntity::class, KeystoreEntity::class, NotificationEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun keystoreDao(): KeystoreDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "appbundle_pro.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            scope.launch {
                                populateInitialData(getDatabase(context, scope))
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun populateInitialData(db: AppDatabase) {
            // Seed Default Debug Keystore
            db.keystoreDao().insertKeystore(
                KeystoreEntity(
                    alias = "androiddebugkey",
                    storePassword = "android",
                    keyPassword = "android",
                    keyType = "RSA_2048",
                    validityYears = 30,
                    sha256Fingerprint = "5E:8F:16:06:2E:A3:CD:2C:4A:0D:54:78:76:BA:A6:F3:8C:AB:F6:25:FB:FA:E6:FE:5E:2B:A2:BF:E5:A2:38:07",
                    sha1Fingerprint = "61:ED:37:7E:85:D3:86:A8:DF:EE:6B:86:4B:D8:5B:0B:FA:A5:AF:81",
                    md5Fingerprint = "B3:70:E6:83:A0:F3:57:07:95:90:3A:D8:FD:4C:E6:36",
                    organization = "Android Debug Authority",
                    countryCode = "US",
                    isDefault = true
                )
            )

            // Seed Sample Production Keystore
            db.keystoreDao().insertKeystore(
                KeystoreEntity(
                    alias = "release_key",
                    storePassword = "password123",
                    keyPassword = "password123",
                    keyType = "RSA_4096",
                    validityYears = 25,
                    sha256Fingerprint = "8A:1B:77:43:5D:89:33:41:2F:90:88:CE:54:12:F6:A3:DE:44:B1:C0:78:E9:51:7A:B4:63:71:0D:33:9A:FF:28",
                    sha1Fingerprint = "47:2A:90:E1:8B:24:D3:FF:55:09:A1:CB:4F:98:71:E6:43:B5:D0:61",
                    md5Fingerprint = "88:21:4F:90:AB:12:D4:56:88:FE:A1:20:9C:B5:44:11",
                    organization = "BundleCraft Enterprise Inc.",
                    countryCode = "SA",
                    isDefault = false
                )
            )

            // Seed Sample Projects
            val now = System.currentTimeMillis()
            db.projectDao().insertProject(
                ProjectEntity(
                    name = "تطبيق المتجر الذكي (Smart Store)",
                    type = "APK_TO_AAB",
                    sourceFileName = "smart_store_v2.apk",
                    sourceFileSize = 38 * 1024 * 1024L, // 38 MB
                    outputFileName = "smart_store_v2_release.aab",
                    outputFileSize = 21 * 1024 * 1024L, // 21 MB
                    status = "COMPLETED",
                    createdAt = now - 3600000 * 24 * 2,
                    updatedAt = now - 3600000 * 24 * 2,
                    compressionRatio = 44.7f,
                    dexCount = 2,
                    signingKeyAlias = "release_key",
                    optimizationScore = 96,
                    isCloudSynced = true,
                    cloudSyncTimestamp = now - 3600000 * 24 * 2,
                    logMessages = "[INFO] بدء فحص حزمة smart_store_v2.apk\n[INFO] تفكيك ملفات DEX والموارد\n[SUCCESS] تم تحويل هيكل الحزمة إلى AAB بنجاح\n[SUCCESS] تم التوقيع بمفتاح release_key\n[SUCCESS] تم تطبيق محاذاة Zipalign (4-byte alignment)",
                    packageName = "com.store.smartapp",
                    versionName = "2.4.1",
                    targetSdk = 34,
                    isDebuggable = false,
                    has64BitSupport = true,
                    notes = "حزمة جاهزة للرفع إلى Google Play Console بدون أية تحذيرات."
                )
            )

            db.projectDao().insertProject(
                ProjectEntity(
                    name = "بوابة الويب التفاعلية (Web Portal)",
                    type = "ZIP_TO_APK",
                    sourceFileName = "webapp_dist.zip",
                    sourceFileSize = 14 * 1024 * 1024L,
                    outputFileName = "webapp_dist_signed.apk",
                    outputFileSize = 9 * 1024 * 1024L,
                    status = "COMPLETED",
                    createdAt = now - 3600000 * 6,
                    updatedAt = now - 3600000 * 6,
                    compressionRatio = 35.7f,
                    dexCount = 1,
                    signingKeyAlias = "androiddebugkey",
                    optimizationScore = 91,
                    isCloudSynced = true,
                    cloudSyncTimestamp = now - 3600000 * 6,
                    logMessages = "[INFO] بدء استخراج ملفات الويب والأصول من ZIP\n[INFO] بناء ملف AndroidManifest.xml المخصص\n[SUCCESS] تجميع الحزمة وصنع حزمة APK صالحة للتثبيت\n[SUCCESS] التوقيع التلقائي بـ Debug Key",
                    packageName = "com.webportal.standalone",
                    versionName = "1.0.0",
                    targetSdk = 34,
                    isDebuggable = false,
                    has64BitSupport = true,
                    notes = "تحويل أرشيف الويب المضغوط إلى تطبيق أندرويد مستقل مع WebView."
                )
            )

            // Seed Welcome Notification
            db.notificationDao().insertNotification(
                NotificationEntity(
                    title = "مرحباً بك في AppBundle Pro!",
                    message = "تم تهيئة بيئة العمل بنجاح مع دعم التوقيع التلقائي والتحويل من APK إلى AAB ومن ZIP إلى APK ومزامنة السحابة.",
                    timestamp = now,
                    isRead = false,
                    type = "INFO"
                )
            )
        }
    }
}
