package com.example.data

import com.example.model.LevelInfo

val GAME_LEVELS = listOf(
    LevelInfo(
        levelNumber = 1,
        title = "Starter Icons",
        theme = "Legendary Logos",
        requiredScore = 0,
        requiredSolved = 0,
        badge = "🔥",
        description = "Iconic global symbols every internet citizen knows. Get ready to zoom in!"
    ),
    LevelInfo(
        levelNumber = 2,
        title = "Tech & Mobile Titans",
        theme = "Digital Ecosystems",
        requiredScore = 1800,
        requiredSolved = 4,
        badge = "📱",
        description = "The hardware and operating systems powering billions of handhelds."
    ),
    LevelInfo(
        levelNumber = 3,
        title = "Creator Legends",
        theme = "Top YouTubers",
        requiredScore = 4500,
        requiredSolved = 8,
        badge = "🎬",
        description = "Channel emblems of YouTube icons who command hundreds of millions of views."
    ),
    LevelInfo(
        levelNumber = 4,
        title = "Supercars & Autos",
        theme = "Horsepower Badges",
        requiredScore = 9000,
        requiredSolved = 13,
        badge = "🏎️",
        description = "Prancing stallions, raging bulls, and iconic emblems forged in steel."
    ),
    LevelInfo(
        levelNumber = 5,
        title = "Fashion & Streetwear",
        theme = "Runway & Culture",
        requiredScore = 16000,
        requiredSolved = 18,
        badge = "✨",
        description = "Luxury houses and hype streetwear brands recognizable from a single stitch."
    ),
    LevelInfo(
        levelNumber = 6,
        title = "Apps & Gaming Arena",
        theme = "Virtual Worlds",
        requiredScore = 25000,
        requiredSolved = 24,
        badge = "🎮",
        description = "Blocky universes, social feeds, and digital realms that dominate gaming."
    ),
    LevelInfo(
        levelNumber = 7,
        title = "Global Powerhouses",
        theme = "Titans of Industry",
        requiredScore = 36000,
        requiredSolved = 30,
        badge = "🌐",
        description = "Giants of aerospace, streaming, retail, and beverages shaping modern commerce."
    ),
    LevelInfo(
        levelNumber = 8,
        title = "Cyber Empires & Socials",
        theme = "Network Giants",
        requiredScore = 50000,
        requiredSolved = 37,
        badge = "⚡",
        description = "Instant messaging networks, developer hubs, and social empires with extreme zoom crops."
    ),
    LevelInfo(
        levelNumber = 9,
        title = "Apex Hypercars & Horology",
        theme = "Pinnacle Luxury",
        requiredScore = 68000,
        requiredSolved = 44,
        badge = "💎",
        description = "Bespoke Swiss timepieces, 300mph French hypercars, and British hand-crafted pedigree."
    ),
    LevelInfo(
        levelNumber = 10,
        title = "Grandmaster Mystery Hall",
        theme = "Extreme Zoom Mythic",
        requiredScore = 90000,
        requiredSolved = 52,
        badge = "👑",
        description = "Microscopic crops, abstract geometric curves, and ultra-high magnification for master detectives."
    )
)
