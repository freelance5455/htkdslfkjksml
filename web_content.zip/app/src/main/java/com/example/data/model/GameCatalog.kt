package com.example.data.model

data class QuizQuestion(
    val prompt: String,
    val options: List<String>,
    val correctIndex: Int
)

data class EmojiPuzzle(
    val emojis: String,
    val category: String,
    val difficulty: String,
    val answer: String,
    val options: List<String>
)

data class WouldYouRatherPrompt(
    val category: String,
    val optionA: String,
    val optionB: String
)

data class SeedChallenge(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val difficulty: String,
    val frequency: String,
    val rewardPoints: Long,
    val isGroupChallenge: Boolean,
    val expiresLabel: String
)

object GameCatalog {
    val truthPrompts = listOf(
        "What is the funniest nickname your friends have ever given you?",
        "Which skill or hobby do you secretly wish you could master overnight?",
        "What is the most memorable festival or school trip moment you've had?",
        "If you could host a dream dinner with any 3 creators or scientists, who would you pick?",
        "What is a harmless habit you have when studying or gaming late?",
        "Which song from your playlist always boosts your mood instantly?"
    )

    val darePrompts = listOf(
        "Speak only in rhymes for your next two turns in the squad!",
        "Send a genuine hype compliment to the friend on your left (or top of the room).",
        "Do your best 10-second cricket commentary for someone drinking water!",
        "Invent a brand-new futuristic superhero name and catchphrase right now.",
        "Balance a pen or notebook on your head for 15 seconds while smiling!",
        "Tell a 20-second motivational speech about finishing homework on time!"
    )

    val neverHaveIEverPrompts = listOf(
        "Never have I ever stayed up past midnight finishing a creative project or game.",
        "Never have I ever laughed so hard in class that I forgot what was funny.",
        "Never have I ever tried cooking a midnight snack and invented a weird recipe.",
        "Never have I ever cheered for a last-ball cricket thriller until my voice went hoarse.",
        "Never have I ever forgotten my notebook at home and improvised brilliantly.",
        "Never have I ever joined a spontaneous group plan that turned into the best day."
    )

    val wouldYouRatherPrompts = listOf(
        WouldYouRatherPrompt("Campus Life", "Have unlimited chai & samosas for a year", "Have zero exam stress forever"),
        WouldYouRatherPrompt("Tech & Future", "Explore Mars with your best friends", "Build a viral indie game studio in Bengaluru"),
        WouldYouRatherPrompt("Superpowers", "Speak every language fluently", "Master any musical instrument in one day"),
        WouldYouRatherPrompt("Adventure", "Road-trip from Ladakh to Kanyakumari", "Attend every world gaming championship VIP"),
        WouldYouRatherPrompt("Daily Vibes", "Always wake up fully energized in 4 hours", "Never lose anything important again"),
        WouldYouRatherPrompt("Squad", "Win a national hackathon with your group", "Direct a blockbuster short film with your group")
    )

    val mafiaRoles = listOf("Mafia", "Detective", "Doctor", "Villager")

    val guessThePersonPool = listOf(
        "ISRO Rocket Scientist",
        "MS Dhoni (Cricket Captain)",
        "Marie Curie (Physics Pioneer)",
        "A.R. Rahman (Music Composer)",
        "Kalpana Chawla (Astronaut)",
        "Iron Man (Tony Stark)"
    )

    val quizQuestions = listOf(
        QuizQuestion(
            "Which ISRO mission made India the first country to land near the lunar south pole?",
            listOf("Mangalyaan", "Chandrayaan-3", "Aditya-L1", "Gaganyaan"),
            1
        ),
        QuizQuestion(
            "Which city is widely known as the Silicon Valley of India?",
            listOf("Hyderabad", "Pune", "Bengaluru", "Chennai"),
            2
        ),
        QuizQuestion(
            "What does 'HTTP' stand for on the web?",
            listOf("HyperText Transfer Protocol", "High Tech Transmission Path", "Hybrid Text Transport Port", "Host Transfer Type Protocol"),
            0
        ),
        QuizQuestion(
            "Which Indian chess grandmaster became the youngest World Chess Champion in 2024?",
            listOf("R. Praggnanandhaa", "D. Gukesh", "Arjun Erigaisi", "Viswanathan Anand"),
            1
        ),
        QuizQuestion(
            "Which planet in our solar system rotates on its side at nearly 98 degrees?",
            listOf("Neptune", "Saturn", "Uranus", "Mars"),
            2
        ),
        QuizQuestion(
            "In computing, how many bits make 1 byte?",
            listOf("4 bits", "8 bits", "16 bits", "32 bits"),
            1
        )
    )

    val emojiPuzzles = listOf(
        EmojiPuzzle("🚀🌕🇮🇳", "Science & Space", "Easy", "Chandrayaan", listOf("Chandrayaan", "Interstellar", "Apollo 11", "Star Wars")),
        EmojiPuzzle("🏏🏆🦁💛", "Sports", "Easy", "Chennai Super Kings", listOf("Mumbai Indians", "Chennai Super Kings", "Royal Challengers", "Team India")),
        EmojiPuzzle("🎸🎤🌟💔", "Movies", "Medium", "Rockstar", listOf("Rockstar", "Aashiqui 2", "Gully Boy", "Tamasha")),
        EmojiPuzzle("⚡👓🪄🏰", "Characters", "Easy", "Harry Potter", listOf("Doctor Strange", "Harry Potter", "Percy Jackson", "Merlin")),
        EmojiPuzzle("🧠💡🤖📱", "Objects & Tech", "Medium", "Artificial Intelligence", listOf("Smartwatch", "Artificial Intelligence", "Virtual Reality", "Quantum Chip")),
        EmojiPuzzle("🎓🎒🤝🏆", "Campus", "Easy", "3 Idiots", listOf("Chhichhore", "3 Idiots", "Student of the Year", "Taare Zameen Par"))
    )

    val wordChainStarters = listOf("SPARK", "COSMOS", "CRICKET", "NEBULA", "AURORA", "PRISM")

    val safeSeedChallenges = listOf(
        SeedChallenge(
            id = "ch_daily_compliment",
            title = "Genuine Squad Hype",
            description = "Send a thoughtful, genuine compliment to a friend recognizing something awesome they did this week.",
            category = "Friendship",
            difficulty = "Easy",
            frequency = "Daily",
            rewardPoints = 40L,
            isGroupChallenge = false,
            expiresLabel = "Resets in 18h"
        ),
        SeedChallenge(
            id = "ch_daily_sketch",
            title = "5-Minute Doodle Sprint",
            description = "Sketch a futuristic gadget or mascot on paper or tablet, then share what it does with your group.",
            category = "Creativity",
            difficulty = "Easy",
            frequency = "Daily",
            rewardPoints = 50L,
            isGroupChallenge = false,
            expiresLabel = "Resets in 18h"
        ),
        SeedChallenge(
            id = "ch_daily_fact",
            title = "Teach One Mind-Blowing Fact",
            description = "Learn one fascinating science, history, or tech fact today and explain it in 2 sentences to your squad.",
            category = "Knowledge",
            difficulty = "Easy",
            frequency = "Daily",
            rewardPoints = 45L,
            isGroupChallenge = false,
            expiresLabel = "Resets in 18h"
        ),
        SeedChallenge(
            id = "ch_weekly_puzzle",
            title = "Squad Brainwave Relay",
            description = "Team up with your group to solve a riddle or complete a 5-round Quiz Battle together.",
            category = "Teamwork",
            difficulty = "Medium",
            frequency = "Weekly",
            rewardPoints = 100L,
            isGroupChallenge = true,
            expiresLabel = "4 days left"
        ),
        SeedChallenge(
            id = "ch_school_study",
            title = "Pomodoro Focus Buddy",
            description = "Complete one distraction-free 25-minute study or skill-building sprint and log your takeaway.",
            category = "School-Friendly",
            difficulty = "Medium",
            frequency = "Daily",
            rewardPoints = 60L,
            isGroupChallenge = false,
            expiresLabel = "Resets in 18h"
        ),
        SeedChallenge(
            id = "ch_brain_memory",
            title = "Pattern Master Run",
            description = "Beat Level 3 in Memory Challenge or solve a 6-word Word Chain streak without hints.",
            category = "Brain",
            difficulty = "Epic",
            frequency = "Weekly",
            rewardPoints = 120L,
            isGroupChallenge = false,
            expiresLabel = "5 days left"
        ),
        SeedChallenge(
            id = "ch_fun_playlist",
            title = "Group Mood Playlist",
            description = "Ask 3 friends for their current favorite upbeat song and build a shared study/chill playlist.",
            category = "Fun",
            difficulty = "Easy",
            frequency = "Group",
            rewardPoints = 55L,
            isGroupChallenge = true,
            expiresLabel = "Ends Sunday"
        )
    )
}
