package com.example.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Encapsulates the 4 text documents synced to Google Drive in the dedicated folder:
 * 1. History (last 100 viewed items)
 * 2. Algorithm keeping (tag affinity scoring)
 * 3. Liked posts
 * 4. Favourite posts (segregated by platform)
 */
data class SyncDocuments(
    val historyDoc: String,
    val algorithmDoc: String,
    val likedPostsDoc: String,
    val favoritePostsDoc: String,
    val lastSyncTime: Long = System.currentTimeMillis()
) {
    companion object {
        private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

        fun buildHistoryText(history: List<MediaItem>): String {
            val sb = StringBuilder()
            sb.append("=== YIFFY MEDIA VIEWING HISTORY (LAST 100 ITEMS) ===\n")
            sb.append("Generated at: ${dateFormat.format(Date())}\n")
            sb.append("Total entries: ${history.size}\n\n")

            history.take(100).forEachIndexed { index, item ->
                val timeStr = dateFormat.format(Date(item.timestamp))
                sb.append(String.format(Locale.US, "#%03d [%s] [%s] %s\n", index + 1, item.source.name, item.type.name, item.title))
                sb.append("     Author: ${item.author}\n")
                sb.append("     Viewed: $timeStr\n")
                sb.append("     URL: ${item.mediaUrl}\n")
                if (item.tags.isNotEmpty()) {
                    sb.append("     Tags: ${item.tags.take(8).joinToString(", ")}\n")
                }
                sb.append("\n")
            }
            return sb.toString()
        }

        fun buildAlgorithmText(tagWeights: Map<String, Float>, sourceWeights: Map<String, Float>): String {
            val sb = StringBuilder()
            sb.append("=== YIFFY SCROLL RECOMMENDATION ALGORITHM PROFILE ===\n")
            sb.append("Updated: ${dateFormat.format(Date())}\n")
            sb.append("Description: Weight vector scoring affinities based on user watch time, likes, and skips.\n\n")

            sb.append("--- SOURCE AFFINITY WEIGHTS ---\n")
            sourceWeights.entries.sortedByDescending { it.value }.forEach { (source, weight) ->
                sb.append(String.format(Locale.US, "%-15s : %.2f\n", source, weight))
            }

            sb.append("\n--- TOP TAG AFFINITIES (FEED INFLUENCE) ---\n")
            tagWeights.entries.sortedByDescending { it.value }.take(50).forEach { (tag, weight) ->
                val bar = "#".repeat((weight.coerceIn(0f, 10f) * 2).toInt())
                sb.append(String.format(Locale.US, "%-20s : %5.2f  [%s]\n", tag, weight, bar))
            }
            return sb.toString()
        }

        fun buildLikedPostsText(liked: List<MediaItem>): String {
            val sb = StringBuilder()
            sb.append("=== YIFFY LIKED POSTS CATALOG ===\n")
            sb.append("Generated at: ${dateFormat.format(Date())}\n")
            sb.append("Total liked: ${liked.size}\n\n")

            liked.forEachIndexed { index, item ->
                val timeStr = dateFormat.format(Date(item.timestamp))
                sb.append("[${index + 1}] [${item.source.name}] [${item.type.name}] ${item.title}\n")
                sb.append("    Creator: ${item.author} | Liked at: $timeStr\n")
                sb.append("    Link: ${item.mediaUrl}\n")
                sb.append("    Tags: ${item.tags.take(6).joinToString(", ")}\n\n")
            }
            return sb.toString()
        }

        fun buildFavoritesText(favorites: List<MediaItem>): String {
            val sb = StringBuilder()
            sb.append("=== YIFFY FAVORITE POSTS (SEGREGATED BY PLATFORM) ===\n")
            sb.append("Generated at: ${dateFormat.format(Date())}\n")
            sb.append("Total favorites: ${favorites.size}\n\n")

            val grouped = favorites.groupBy { it.source }
            MediaSource.entries.forEach { source ->
                val items = grouped[source].orEmpty()
                sb.append("=========================================\n")
                sb.append(">>> PLATFORM: ${source.displayName.uppercase()} (${items.size} favorites)\n")
                sb.append("=========================================\n")
                if (items.isEmpty()) {
                    sb.append("  (No favorites recorded for this platform yet)\n\n")
                } else {
                    items.forEachIndexed { i, item ->
                        sb.append("  ${i + 1}. [${item.type.name}] ${item.title}\n")
                        sb.append("     By: ${item.author} | URL: ${item.mediaUrl}\n")
                        sb.append("     Tags: ${item.tags.take(5).joinToString(", ")}\n")
                    }
                    sb.append("\n")
                }
            }
            return sb.toString()
        }
    }
}
