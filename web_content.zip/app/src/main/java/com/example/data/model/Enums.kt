package com.example.data.model

enum class TripType(val arabicLabel: String) {
    EIGHT_DAYS("8 أيام"),
    FOURTEEN_DAYS("14 يومًا"),
    CUSTOM("برنامج مخصص");

    companion object {
        fun fromLabel(value: String): TripType =
            entries.firstOrNull { it.name == value || it.arabicLabel == value } ?: EIGHT_DAYS
    }
}

enum class BookingStatus(val arabicLabel: String) {
    CONFIRMED("مؤكد"),
    PENDING("قيد الانتظار"),
    COMPLETED("مكتمل"),
    CANCELLED("ملغي");

    companion object {
        fun fromName(value: String): BookingStatus =
            entries.firstOrNull { it.name == value || it.arabicLabel == value } ?: PENDING
    }
}

enum class PaymentMethod(val arabicLabel: String) {
    CASH("نقدي"),
    TRANSFER("تحويل"),
    OTHER("أخرى");

    companion object {
        fun fromName(value: String): PaymentMethod =
            entries.firstOrNull { it.name == value || it.arabicLabel == value } ?: CASH
    }
}

enum class DocumentType(val arabicLabel: String) {
    PASSPORT("صورة جواز السفر"),
    NATIONAL_ID("صورة البطاقة الشخصية"),
    VISA("صورة التأشيرة"),
    FLIGHT_TICKET("صورة تذكرة الطيران"),
    PAYMENT_RECEIPT("إيصالات الدفع"),
    OTHER("صور أخرى");

    companion object {
        fun fromName(value: String): DocumentType =
            entries.firstOrNull { it.name == value || it.arabicLabel == value } ?: OTHER
    }
}

enum class ReportType(val id: Int, val title: String, val subtitle: String) {
    ALL_CLIENTS(1, "تقرير جميع العملاء", "بيانات العملاء المسجلين وعدد حجوزاتهم"),
    ALL_BOOKINGS(2, "تقرير جميع الحجوزات", "تفاصيل جميع حجوزات العمرة وحالاتها"),
    UPCOMING_TRIPS(3, "تقرير الرحلات القادمة", "الرحلات المجدولة من تاريخ اليوم فأعلى"),
    BY_TRIP_DATE(4, "تقرير الحجوزات حسب تاريخ الرحلة", "مرتبة زمنيًا حسب تاريخ السفر"),
    BY_COMPANY(5, "تقرير الحجوزات حسب شركة السياحة", "إحصائيات وتفاصيل كل شركة سياحة"),
    COLLECTED_AMOUNTS(6, "تقرير المبالغ المحصلة", "سجل جميع الدفعات والمقدمات المحصلة"),
    REMAINING_AMOUNTS(7, "تقرير المبالغ المتبقية", "أرصدة الحجوزات والمبالغ المستحقة"),
    UNPAID_CLIENTS(8, "تقرير العملاء غير المسددين بالكامل", "العملاء الذين عليهم مبالغ متبقية"),
    CANCELLED_BOOKINGS(9, "تقرير الحجوزات الملغاة", "الحجوزات الملغاة وتفاصيلها المالية"),
    PROFIT_VARIANCE(10, "تقرير الأرباح والفروق المالية", "مقارنة السعر والتكلفة وصافي الربح");
}
