package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgramDao {
    @Query("SELECT * FROM programs ORDER BY id DESC")
    fun getAllPrograms(): Flow<List<ProgramEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgram(program: ProgramEntity): Long

    @Delete
    suspend fun deleteProgram(program: ProgramEntity)

    @Query("DELETE FROM programs")
    suspend fun clearAllPrograms()

    @Query("SELECT COUNT(*) FROM programs")
    suspend fun getCount(): Int
}
