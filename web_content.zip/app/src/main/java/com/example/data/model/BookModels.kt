package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Book(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val subtitle: String = "",
    val synopsis: String = "",
    val genre: String = "Roman",
    val tone: String = "Edebi ve Derin",
    val creationMethod: String = "ai", // "ai" or "manual"
    val coverTheme: String = "crimson", // "crimson", "midnight", "emerald", "parchment", "obsidian"
    val chapterCount: Long = 0L,
    val totalWordCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val isAiCreated: Boolean
        get() = creationMethod == "ai"
}

@IgnoreExtraProperties
data class Chapter(
    @DocumentId val id: String = "",
    val userId: String = "",
    val bookId: String = "",
    val chapterNumber: Long = 1L,
    val title: String = "",
    val summary: String = "",
    val content: String = "",
    val wordCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class AiGeneratedChapterDraft(
    val chapterNumber: Int,
    val title: String,
    val summary: String,
    val content: String
)

data class AiGeneratedBookDraft(
    val title: String,
    val subtitle: String,
    val synopsis: String,
    val chapters: List<AiGeneratedChapterDraft>
)

enum class BookCoverTheme(val id: String, val labelTr: String, val subtitleTr: String) {
    CRIMSON("crimson", "Klasik Bordo", "Altın yaldızlı bordo cilt"),
    MIDNIGHT("midnight", "Gece Mavisi", "Derin lacivert ve kehribar"),
    EMERALD("emerald", "Zümrüt Kütüphane", "Antik yeşil ve krem varak"),
    PARCHMENT("parchment", "Antik Parşömen", "Sıcak fildişi ve mürekkep"),
    OBSIDIAN("obsidian", "Obsidyen Siyah", "Modern koyu antrasit cilt");

    companion object {
        fun fromId(id: String): BookCoverTheme =
            entries.find { it.id == id } ?: CRIMSON
    }
}

object LiteraryCatalog {
    val genres = listOf(
        "Roman",
        "Bilim Kurgu",
        "Fantastik",
        "Polisiye ve Gerilim",
        "Tarihi Kurgu",
        "Felsefe ve Deneme",
        "Kişisel Gelişim",
        "Çocuk ve Gençlik"
    )

    val tones = listOf(
        "Edebi ve Derin",
        "Akıcı ve Sürükleyici",
        "Gizemli ve Atmosferik",
        "Sıcak ve İlham Verici",
        "Mizahi ve İronik",
        "Öğretici ve Yalın"
    )

    val quickTopicIdeas = listOf(
        "İstanbul'un altında unutulmuş antik bir kütüphaneyi keşfeden genç bir tarihçinin hikayesi",
        "Rüyaların kaydedilip takas edilebildiği yakın gelecekte bir hafıza dedektifinin macerası",
        "Ege'de küçük bir sahil kasabasında açılan gizemli sahafta kesişen üç farklı hayat",
        "Modern dünyada odaklanma, derin çalışma ve içsel dinginlik üzerine felsefi bir rehber"
    )
}

fun countWords(text: String): Long {
    val trimmed = text.trim()
    if (trimmed.isEmpty()) return 0L
    return trimmed.split(Regex("\\s+")).size.toLong()
}
