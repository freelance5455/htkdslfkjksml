package com.example.data.streak

import java.time.LocalDate
import java.time.YearMonth

/**
 * Result data class containing all computed streak metrics, frozen days, and monthly freeze counts.
 */
data class StreakResult(
    val currentStreak: Int,
    val longestStreak: Int,
    val studiedDates: Set<LocalDate>,       // Days with at least 10 minutes studied
    val partialDates: Set<LocalDate>,       // Days with > 0 and < 10 minutes studied
    val frozenDates: Set<LocalDate>,        // Days where a 1-day freeze was applied
    val freezesUsedThisMonth: Int,
    val freezesRemainingThisMonth: Int,
    val isStudiedToday: Boolean
)

/**
 * Pure streak calculation engine implementing PRD Section 5.3 specifications:
 * - A day counts toward the streak if total study duration >= 10 minutes.
 * - Current streak & longest streak tracking.
 * - 2 automatic streak freezes per calendar month for a single missed day.
 * - Frozen days keep streak alive but do not add to the count.
 * - Two missed days in a row, or a missed day with no freeze left, resets the current streak to 0.
 * - Unused freezes do not carry over to the next month.
 */
object StreakCalculator {

    const val MINIMUM_MINUTES_FOR_STREAK = 10
    const val MAX_FREEZES_PER_MONTH = 2

    fun calculateStreak(
        studyMinutesByDate: Map<LocalDate, Int>,
        referenceDate: LocalDate = LocalDate.now()
    ): StreakResult {
        val studiedDates = mutableSetOf<LocalDate>()
        val partialDates = mutableSetOf<LocalDate>()

        for ((date, minutes) in studyMinutesByDate) {
            if (minutes >= MINIMUM_MINUTES_FOR_STREAK) {
                studiedDates.add(date)
            } else if (minutes > 0) {
                partialDates.add(date)
            }
        }

        val isStudiedToday = studiedDates.contains(referenceDate)
        val refMonth = YearMonth.from(referenceDate)

        if (studiedDates.isEmpty() && !isStudiedToday) {
            return StreakResult(
                currentStreak = 0,
                longestStreak = 0,
                studiedDates = studiedDates,
                partialDates = partialDates,
                frozenDates = emptySet(),
                freezesUsedThisMonth = 0,
                freezesRemainingThisMonth = MAX_FREEZES_PER_MONTH,
                isStudiedToday = false
            )
        }

        val earliestDate = studiedDates.minOrNull() ?: referenceDate
        if (earliestDate.isAfter(referenceDate)) {
            return StreakResult(
                currentStreak = 0,
                longestStreak = 0,
                studiedDates = studiedDates,
                partialDates = partialDates,
                frozenDates = emptySet(),
                freezesUsedThisMonth = 0,
                freezesRemainingThisMonth = MAX_FREEZES_PER_MONTH,
                isStudiedToday = false
            )
        }

        var currentStreak = 0
        var longestStreak = 0
        var consecutiveMissed = 0
        val freezesUsedByMonth = mutableMapOf<YearMonth, Int>()
        val frozenDates = mutableSetOf<LocalDate>()

        // Process all completed past days up to yesterday
        var cursor = earliestDate
        val yesterday = referenceDate.minusDays(1)

        while (!cursor.isAfter(yesterday)) {
            if (studiedDates.contains(cursor)) {
                currentStreak++
                if (currentStreak > longestStreak) {
                    longestStreak = currentStreak
                }
                consecutiveMissed = 0
            } else {
                consecutiveMissed++
                if (consecutiveMissed == 1) {
                    val ym = YearMonth.from(cursor)
                    val usedInMonth = freezesUsedByMonth.getOrDefault(ym, 0)
                    if (currentStreak > 0 && usedInMonth < MAX_FREEZES_PER_MONTH) {
                        // Automatic 1-day streak freeze applied
                        freezesUsedByMonth[ym] = usedInMonth + 1
                        frozenDates.add(cursor)
                        // Keeps streak alive, does NOT increment count
                    } else {
                        // No freeze left in month or no active streak -> streak reset to 0
                        currentStreak = 0
                    }
                } else {
                    // Two or more missed days in a row -> streak resets to 0
                    currentStreak = 0
                }
            }
            cursor = cursor.plusDays(1)
        }

        // Now evaluate today (referenceDate)
        if (isStudiedToday) {
            val yesterdayWasAlive = studiedDates.contains(yesterday) || frozenDates.contains(yesterday)
            if (yesterdayWasAlive && currentStreak > 0) {
                currentStreak++
            } else {
                currentStreak = 1
            }
            if (currentStreak > longestStreak) {
                longestStreak = currentStreak
            }
        } else {
            // Today is in progress. If yesterday was not alive (e.g. 2+ missed days or out of freezes),
            // the streak is already 0.
            val yesterdayWasAlive = studiedDates.contains(yesterday) || frozenDates.contains(yesterday)
            if (!yesterdayWasAlive && cursor != referenceDate) {
                currentStreak = 0
            }
        }

        val freezesUsedThisMonth = freezesUsedByMonth.getOrDefault(refMonth, 0)
        val freezesRemainingThisMonth = (MAX_FREEZES_PER_MONTH - freezesUsedThisMonth).coerceAtLeast(0)

        return StreakResult(
            currentStreak = currentStreak,
            longestStreak = longestStreak,
            studiedDates = studiedDates,
            partialDates = partialDates,
            frozenDates = frozenDates,
            freezesUsedThisMonth = freezesUsedThisMonth,
            freezesRemainingThisMonth = freezesRemainingThisMonth,
            isStudiedToday = isStudiedToday
        )
    }
}
