package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val username: String = "",
    val displayTag: String = "",
    val fullName: String = "",
    val bio: String = "",
    val website: String = "",
    val avatarPreset: String = "prism_cyan",
    val avatarImageBase64: String? = null,
    val profileTheme: String = "obsidian_glass",
    val level: Long = 1L,
    val xp: Long = 0L,
    val points: Long = 0L,
    val gamesPlayed: Long = 0L,
    val challengesCompleted: Long = 0L,
    val friendsCount: Long = 0L,
    val groupsCount: Long = 0L,
    val postsCount: Long = 0L,
    val followersCount: Long = 0L,
    val followingCount: Long = 0L,
    val badges: List<String> = emptyList(),
    @get:PropertyName("isPrivateAccount") val isPrivateAccount: Boolean = true,
    val allowFriendRequests: String = "everyone",
    val allowMessagesFrom: String = "followers",
    val requireTagApproval: Boolean = false,
    val hiddenStoryFromUids: List<String> = emptyList(),
    val showOnlineStatus: Boolean = true,
    val optOutLeaderboard: Boolean = false,
    @get:PropertyName("isOnline") val isOnline: Boolean = true,
    val ageBracket: String = "teen_13_17",
    val parentalConsentApproved: Boolean = true,
    @get:PropertyName("isRestricted") val isRestricted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FollowEdge(
    @DocumentId val id: String = "",
    val userId: String = "",
    val peerUid: String = "",
    val peerUsername: String = "",
    val peerFullName: String = "",
    val peerAvatar: String = "prism_cyan",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FollowRequest(
    @DocumentId val id: String = "",
    val fromUid: String = "",
    val fromUsername: String = "",
    val fromFullName: String = "",
    val fromAvatar: String = "prism_cyan",
    val toUid: String = "",
    val toUsername: String = "",
    val status: String = "pending",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class RestrictedUser(
    @DocumentId val id: String = "",
    val userId: String = "",
    val restrictedUid: String = "",
    val restrictedUsername: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserPrivateSettings(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val quietHoursEnabled: Boolean = false,
    val quietStartHour: Long = 22L,
    val quietEndHour: Long = 7L,
    val notifyFriendRequests: Boolean = true,
    val notifyGroupInvites: Boolean = true,
    val notifyGameInvites: Boolean = true,
    val notifyChallenges: Boolean = true,
    val notifyAchievements: Boolean = true,
    val parentEmailHint: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class NotificationItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val senderId: String = "",
    val senderUsername: String = "",
    val type: String = "achievement",
    val title: String = "",
    val body: String = "",
    val refId: String? = null,
    @get:PropertyName("isRead") val isRead: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FriendRequest(
    @DocumentId val id: String = "",
    val fromUid: String = "",
    val fromUsername: String = "",
    val fromAvatar: String = "prism_cyan",
    val toUid: String = "",
    val toUsername: String = "",
    val status: String = "pending",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class FriendEdge(
    @DocumentId val id: String = "",
    val userId: String = "",
    val friendUid: String = "",
    val friendUsername: String = "",
    val friendAvatar: String = "prism_cyan",
    val friendLevel: Long = 1L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class BlockedUser(
    @DocumentId val id: String = "",
    val userId: String = "",
    val blockedUid: String = "",
    val blockedUsername: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ArkGroup(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val name: String = "",
    val description: String = "",
    val inviteCode: String = "",
    val theme: String = "aurora",
    @get:PropertyName("isPrivate") val isPrivate: Boolean = true,
    val allowMediaDownloads: Boolean = true,
    val memberUids: List<String> = emptyList(),
    val adminUids: List<String> = emptyList(),
    val memberCount: Long = 1L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class GroupMessage(
    @DocumentId val id: String = "",
    val groupId: String = "",
    val memberUids: List<String> = emptyList(),
    val senderId: String = "",
    val senderUsername: String = "",
    val senderAvatar: String = "prism_cyan",
    val text: String = "",
    val imageBase64: String? = null,
    val replyToId: String? = null,
    val replyToPreview: String? = null,
    val reactions: Map<String, Long> = emptyMap(),
    @get:PropertyName("isDeleted") val isDeleted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class GroupMedia(
    @DocumentId val id: String = "",
    val groupId: String = "",
    val memberUids: List<String> = emptyList(),
    val uploaderId: String = "",
    val uploaderUsername: String = "",
    val albumName: String = "Memories",
    val caption: String = "",
    val imageBase64: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class GameRoom(
    @DocumentId val id: String = "",
    val hostId: String = "",
    val hostUsername: String = "",
    val gameType: String = "quiz_battle",
    val roomCode: String = "",
    val groupId: String? = null,
    val status: String = "waiting",
    @get:PropertyName("isPrivate") val isPrivate: Boolean = false,
    val playerUids: List<String> = emptyList(),
    val readyUids: List<String> = emptyList(),
    val playerNames: Map<String, String> = emptyMap(),
    val scores: Map<String, Long> = emptyMap(),
    val currentTurnUid: String = "",
    val roundNumber: Long = 0L,
    val maxRounds: Long = 5L,
    val promptText: String = "",
    val optionA: String? = null,
    val optionB: String? = null,
    val options: List<String>? = null,
    val correctIndex: Long? = null,
    val votes: Map<String, String> = emptyMap(),
    val secretRoles: Map<String, String>? = null,
    val winnerUid: String? = null,
    val winnerUsername: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ArkChallenge(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "Friendship",
    val difficulty: String = "Easy",
    val frequency: String = "Daily",
    val rewardPoints: Long = 50L,
    @get:PropertyName("isGroupChallenge") val isGroupChallenge: Boolean = false,
    @get:PropertyName("isActive") val isActive: Boolean = true,
    val expiresLabel: String = "Ends tonight",
    val createdBy: String = "system",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ChallengeProgress(
    @DocumentId val id: String = "",
    val userId: String = "",
    val challengeId: String = "",
    val status: String = "in_progress",
    val reflectionNote: String? = null,
    val pointsAwarded: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class GroupEvent(
    @DocumentId val id: String = "",
    val creatorId: String = "",
    val groupId: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "Game Night",
    @get:PropertyName("isPublic") val isPublic: Boolean = false,
    val memberUids: List<String> = emptyList(),
    val scheduledLabel: String = "Tonight • 8:00 PM",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ModerationReport(
    @DocumentId val id: String = "",
    val reporterId: String = "",
    val targetType: String = "user",
    val targetId: String = "",
    val reason: String = "",
    val details: String? = null,
    val status: String = "open",
    val reviewedBy: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class ArkGameType(
    val id: String,
    val title: String,
    val tagline: String,
    val rules: String,
    val maxRounds: Long,
    val minPlayers: Int
) {
    TRUTH_OR_DARE(
        id = "truth_or_dare",
        title = "Truth or Dare",
        tagline = "Safe, funny & school-friendly turns",
        rules = "Take turns picking Truth or Dare! Complete the safe prompt to earn +30 pts, or skip gracefully.",
        maxRounds = 6,
        minPlayers = 1
    ),
    NEVER_HAVE_I_EVER(
        id = "never_have_i_ever",
        title = "Never Have I Ever",
        tagline = "Discover fun squad stories",
        rules = "Read the statement and tap 'I Have' or 'Never'. Earn +20 pts per round for honest squad vibes.",
        maxRounds = 6,
        minPlayers = 1
    ),
    WOULD_YOU_RATHER(
        id = "would_you_rather",
        title = "Would You Rather",
        tagline = "Two wild choices, live group poll",
        rules = "Pick Option A or Option B! Watch live group percentages animate and see who matches your vibe.",
        maxRounds = 6,
        minPlayers = 1
    ),
    MAFIA(
        id = "mafia",
        title = "Mafia",
        tagline = "Secret roles, discussion & voting",
        rules = "Secret roles (Mafia, Detective, Villager) are assigned. Discuss in chat and vote out the suspect!",
        maxRounds = 4,
        minPlayers = 2
    ),
    GUESS_THE_PERSON(
        id = "guess_the_person",
        title = "Guess The Person",
        tagline = "20-question mystery persona duel",
        rules = "A mystery character/personality is chosen. Ask Yes/No clues and lock in your guess to score +50 pts!",
        maxRounds = 5,
        minPlayers = 1
    ),
    QUIZ_BATTLE(
        id = "quiz_battle",
        title = "Quiz Battle",
        tagline = "Fast-paced trivia & leaderboard",
        rules = "Answer multiple-choice trivia across India, Tech, Science & Pop Culture before the round advances!",
        maxRounds = 6,
        minPlayers = 1
    ),
    EMOJI_CHALLENGE(
        id = "emoji_challenge",
        title = "Emoji Challenge",
        tagline = "Decode movies, objects & legends",
        rules = "Crack the emoji puzzle across Bollywood, Cricket, Sci-Fi & Everyday Objects for +40 pts each!",
        maxRounds = 6,
        minPlayers = 1
    ),
    WORD_CHAIN(
        id = "word_chain",
        title = "Word Chain",
        tagline = "Connect words by the last letter",
        rules = "Submit a valid word starting with the last letter of the current word. No repeats! +25 pts per link.",
        maxRounds = 8,
        minPlayers = 1
    ),
    QUICK_REACTION(
        id = "quick_reaction",
        title = "Quick Reaction",
        tagline = "Millisecond reflex arena",
        rules = "Wait for the Liquid Glass core to flash Emerald, then tap instantly! Fastest millisecond score wins.",
        maxRounds = 4,
        minPlayers = 1
    ),
    MEMORY_CHALLENGE(
        id = "memory_challenge",
        title = "Memory Challenge",
        tagline = "Sequence & pattern recall",
        rules = "Watch the illuminated sequence and repeat it accurately across escalating levels. Solo & squad scoring!",
        maxRounds = 5,
        minPlayers = 1
    );

    companion object {
        fun fromId(id: String): ArkGameType = entries.firstOrNull { it.id == id } ?: QUIZ_BATTLE
    }
}
