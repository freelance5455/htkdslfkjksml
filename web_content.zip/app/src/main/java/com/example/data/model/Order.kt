package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val clientName: String,
    val clientContact: String,
    val serviceType: String,
    val fileLink: String? = null,
    val budget: String = "",
    val deadline: String = "",
    val notes: String? = null,
    val paymentStatus: String = STATUS_PENDING_PAYMENT,
    val createdAt: Long = System.currentTimeMillis()
) {
    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            return sdf.format(Date(createdAt))
        }

    val budgetAmount: Double
        get() = budget.replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: 0.0

    companion object {
        const val STATUS_PENDING = "Pending"
        const val STATUS_PENDING_PAYMENT = "Pending Payment"
        const val STATUS_PAID_UPI = "Paid via UPI"
        const val STATUS_IN_PROGRESS = "In Progress"
        const val STATUS_COMPLETED = "Completed"
        const val STATUS_DELIVERED = "Delivered"

        val TOGGLE_STATUSES = listOf(
            STATUS_PENDING,
            STATUS_IN_PROGRESS,
            STATUS_COMPLETED
        )

        val ALL_STATUSES = listOf(
            STATUS_PENDING,
            STATUS_IN_PROGRESS,
            STATUS_COMPLETED,
            STATUS_PENDING_PAYMENT,
            STATUS_PAID_UPI,
            STATUS_DELIVERED
        )

        fun getNextToggleStatus(currentStatus: String): String {
            return when (currentStatus) {
                STATUS_PENDING, STATUS_PENDING_PAYMENT, STATUS_PAID_UPI -> STATUS_IN_PROGRESS
                STATUS_IN_PROGRESS -> STATUS_COMPLETED
                STATUS_COMPLETED, STATUS_DELIVERED -> STATUS_PENDING
                else -> STATUS_PENDING
            }
        }

        val SERVICE_TYPES = listOf(
            "Photo Editing",
            "Video Editing",
            "Logo Designing",
            "Thumbnail Design",
            "Reel / Short Editing",
            "AI VFX & Color Grading"
        )
    }
}
