package com.example.data.model

enum class QuizDirection {
    WORD_TO_MEANING, // Directo: Palabra -> Significado
    MEANING_TO_WORD  // Al Revés / Inverso: Significado / Imagen / Frase -> ¿Qué palabra es?
}

data class QuizQuestion(
    val id: String,
    val direction: QuizDirection,
    val targetWord: String,
    val displayWord: String,
    val simpleSynonym: String,
    val colloquialMeaning: String,
    val imageUrl: String,
    val originalSentence: String,
    val sentenceWithBlank: String,
    val options: List<String>,
    val correctIndex: Int
)

data class RhythmResult(
    val isPerfectRhythm: Boolean,
    val message: String,
    val bonusPoints: Int,
    val multiplier: Float
)

data class BadgeItem(
    val id: String,
    val title: String,
    val description: String,
    val iconEmoji: String,
    val isUnlocked: Boolean = false,
    val unlockedAt: Long = 0L
)

data class DailyChallenge(
    val id: String,
    val title: String,
    val description: String,
    val targetCount: Int,
    val currentCount: Int,
    val rewardPoints: Int,
    val isCompleted: Boolean = false
)
