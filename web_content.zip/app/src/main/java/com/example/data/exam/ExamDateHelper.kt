package com.example.data.exam

import java.time.LocalDate
import java.time.temporal.ChronoUnit

object ExamDateHelper {

    fun calculateDaysLeft(examDate: LocalDate, today: LocalDate = LocalDate.now()): Long {
        return ChronoUnit.DAYS.between(today, examDate)
    }

    fun formatDaysLeft(daysLeft: Long): String {
        return when {
            daysLeft == 0L -> "Today"
            daysLeft == 1L -> "1 day left"
            daysLeft > 1L -> "$daysLeft days left"
            daysLeft == -1L -> "Passed (1 day ago)"
            else -> "Passed (${-daysLeft} days ago)"
        }
    }

    /**
     * Past exams move to an archive list (PRD section 5.5: "On the exam day it shows 'Today', and past exams are archived.")
     */
    fun isExamPast(examDate: LocalDate, today: LocalDate = LocalDate.now()): Boolean {
        return calculateDaysLeft(examDate, today) < 0L
    }

    /**
     * Checks if a notification reminder should be triggered today for 30, 7, or 1 day countdown.
     */
    fun getEligibleReminders(
        examDate: LocalDate,
        today: LocalDate = LocalDate.now(),
        remind30: Boolean,
        remind7: Boolean,
        remind1: Boolean
    ): List<Int> {
        val daysLeft = calculateDaysLeft(examDate, today)
        val eligible = mutableListOf<Int>()
        if (daysLeft == 30L && remind30) eligible.add(30)
        if (daysLeft == 7L && remind7) eligible.add(7)
        if (daysLeft == 1L && remind1) eligible.add(1)
        return eligible
    }
}
