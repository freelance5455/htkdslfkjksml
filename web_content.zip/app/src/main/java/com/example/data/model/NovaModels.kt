package com.example.data.model

import android.graphics.Bitmap
import android.net.Uri
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "New Conversation",
    val lastMessagePreview: String = "",
    val messageCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val conversationId: String = "",
    val role: String = "user", // "user" (RIGHT) or "assistant" (LEFT)
    val content: String = "",
    val attachmentSummary: String? = null,
    val generatedImageBase64: String? = null,
    val citations: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserMemory(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fact: String = "",
    val category: String = "Preference",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

enum class AttachmentType {
    IMAGE,
    DOCUMENT,
    CODE
}

data class PendingAttachment(
    val id: String,
    val uri: Uri?,
    val fileName: String,
    val mimeType: String,
    val fileSizeBytes: Long,
    val type: AttachmentType,
    val bitmapPreview: Bitmap? = null,
    val base64Data: String? = null,
    val extractedText: String? = null
)

enum class AnswerLength(val label: String, val instruction: String) {
    CONCISE("Concise", "Provide a concise, direct, and high-signal answer (2-4 sentences unless code is requested)."),
    BALANCED("Balanced", "Provide a clear, well-structured, and balanced explanation with helpful examples."),
    DETAILED("Comprehensive", "Provide an in-depth, comprehensive, step-by-step response with thorough explanations and examples.")
}

enum class AssistantMode(val label: String, val systemPromptAddon: String) {
    GENERAL("General AI", "Act as NOVA AI, an intelligent, warm, and capable personal assistant fluent in English, Hindi, and Hinglish."),
    CODING("Coding Expert", "Focus on clean, production-grade software engineering, debugging, architecture, and well-commented code blocks."),
    RESEARCH("Web Research", "Focus on verifiable facts, structured multi-angle analysis, clear source attributions, and distinguishing verified facts from general model knowledge."),
    CREATIVE("Writing & Studio", "Focus on articulate writing, translation, tone adaptation, brainstorming, and visual concept creation."),
    IMAGE_GEN("Image Studio", "Generate or transform visual concepts using the image generation model.")
}

enum class VoiceLanguage(val label: String, val bcp47Tag: String) {
    AUTO_HINGLISH("Hindi / Hinglish & English (in-IN)", "en-IN"),
    HINDI("Hindi (hi-IN)", "hi-IN"),
    ENGLISH_US("English (en-US)", "en-US")
}

data class DeviceInfoSnapshot(
    val batteryPercentage: Int,
    val isCharging: Boolean,
    val chargingSource: String,
    val availableStorageGb: String,
    val totalStorageGb: String,
    val isInternetConnected: Boolean,
    val networkTransport: String,
    val isWifiEnabled: Boolean,
    val isBluetoothEnabled: Boolean,
    val currentTimeFormatted: String,
    val currentDateFormatted: String,
    val deviceModel: String,
    val androidVersion: String
)

data class ContactItem(
    val id: String,
    val displayName: String,
    val phoneNumber: String
)
