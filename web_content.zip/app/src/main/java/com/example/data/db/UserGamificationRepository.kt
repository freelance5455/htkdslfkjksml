package com.example.data.db

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.BadgeItem
import com.example.data.model.DailyChallenge
import com.example.data.model.QuizDirection
import com.example.data.model.RhythmResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class GameStatsState(
    val totalScore: Int = 0,
    val level: Int = 1,
    val levelTitle: String = "Novato del Léxico",
    val nextLevelScore: Int = 300,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val comboMultiplier: Float = 1.0f,
    val perfectRhythmCount: Int = 0,
    val reverseModeCorrectCount: Int = 0,
    val badges: List<BadgeItem> = emptyList(),
    val challenges: List<DailyChallenge> = emptyList()
)

class UserGamificationRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("lexico_gamification", Context.MODE_PRIVATE)

    private val _gameStats = MutableStateFlow(loadInitialStats())
    val gameStats: StateFlow<GameStatsState> = _gameStats.asStateFlow()

    private fun loadInitialStats(): GameStatsState {
        val score = prefs.getInt("total_score", 0)
        val bestStreak = prefs.getInt("best_streak", 0)
        val perfectRhythmCount = prefs.getInt("perfect_rhythm_count", 0)
        val reverseCorrectCount = prefs.getInt("reverse_correct_count", 0)
        val unlockedBadgeIds = prefs.getStringSet("unlocked_badges", emptySet()) ?: emptySet()

        val badges = getInitialBadges().map {
            if (unlockedBadgeIds.contains(it.id)) it.copy(isUnlocked = true) else it
        }

        val levelInfo = calculateLevel(score)

        return GameStatsState(
            totalScore = score,
            level = levelInfo.first,
            levelTitle = levelInfo.second,
            nextLevelScore = levelInfo.third,
            currentStreak = 0,
            bestStreak = bestStreak,
            comboMultiplier = 1.0f,
            perfectRhythmCount = perfectRhythmCount,
            reverseModeCorrectCount = reverseCorrectCount,
            badges = badges,
            challenges = buildChallenges(reverseCorrectCount, perfectRhythmCount, score)
        )
    }

    fun calculateRhythm(elapsedTimeMs: Long): RhythmResult {
        // Rhythm sweet spot: between 2.0s and 6.0s (deliberate and confident rhythm!)
        return when {
            elapsedTimeMs in 2000L..6000L -> {
                RhythmResult(
                    isPerfectRhythm = true,
                    message = "¡RITMO PERFECTO! 🎵⚡",
                    bonusPoints = 120,
                    multiplier = 1.5f
                )
            }
            elapsedTimeMs < 2000L -> {
                RhythmResult(
                    isPerfectRhythm = true,
                    message = "¡VELOCIDAD RELÁMPAGO! ⚡",
                    bonusPoints = 80,
                    multiplier = 1.25f
                )
            }
            else -> {
                RhythmResult(
                    isPerfectRhythm = false,
                    message = "¡Bien respondido! 🎯",
                    bonusPoints = 20,
                    multiplier = 1.0f
                )
            }
        }
    }

    fun recordQuizAnswer(
        isCorrect: Boolean,
        direction: QuizDirection,
        elapsedTimeMs: Long
    ): Pair<Int, RhythmResult?> {
        val current = _gameStats.value
        if (!isCorrect) {
            // Reset streak and combo
            _gameStats.update {
                it.copy(
                    currentStreak = 0,
                    comboMultiplier = 1.0f
                )
            }
            return Pair(0, null)
        }

        val rhythm = calculateRhythm(elapsedTimeMs)
        val newStreak = current.currentStreak + 1
        val newBestStreak = maxOf(current.bestStreak, newStreak)

        // Growing multiplier based on rhythm and streak: up to x3.0!
        val newMultiplier = minOf(3.0f, current.comboMultiplier + if (rhythm.isPerfectRhythm) 0.5f else 0.2f)

        val basePoints = if (direction == QuizDirection.MEANING_TO_WORD) 150 else 100
        val earnedPoints = ((basePoints + rhythm.bonusPoints) * newMultiplier).toInt()
        val newTotalScore = current.totalScore + earnedPoints

        val newPerfectCount = current.perfectRhythmCount + (if (rhythm.isPerfectRhythm) 1 else 0)
        val newReverseCount = current.reverseModeCorrectCount + (if (direction == QuizDirection.MEANING_TO_WORD) 1 else 0)

        // Save to persistent preferences
        prefs.edit()
            .putInt("total_score", newTotalScore)
            .putInt("best_streak", newBestStreak)
            .putInt("perfect_rhythm_count", newPerfectCount)
            .putInt("reverse_correct_count", newReverseCount)
            .apply()

        // Check badge unlocks
        val updatedBadges = current.badges.map { badge ->
            val shouldUnlock = when (badge.id) {
                "primer_acierto" -> true
                "ritmo_maestro" -> newPerfectCount >= 3
                "maestro_inverso" -> newReverseCount >= 5
                "racha_fuego" -> newStreak >= 5
                "centurion" -> newTotalScore >= 1000
                else -> false
            }
            if (shouldUnlock && !badge.isUnlocked) {
                badge.copy(isUnlocked = true, unlockedAt = System.currentTimeMillis())
            } else badge
        }

        val unlockedIds = updatedBadges.filter { it.isUnlocked }.map { it.id }.toSet()
        prefs.edit().putStringSet("unlocked_badges", unlockedIds).apply()

        val levelInfo = calculateLevel(newTotalScore)

        _gameStats.update {
            it.copy(
                totalScore = newTotalScore,
                level = levelInfo.first,
                levelTitle = levelInfo.second,
                nextLevelScore = levelInfo.third,
                currentStreak = newStreak,
                bestStreak = newBestStreak,
                comboMultiplier = newMultiplier,
                perfectRhythmCount = newPerfectCount,
                reverseModeCorrectCount = newReverseCount,
                badges = updatedBadges,
                challenges = buildChallenges(newReverseCount, newPerfectCount, newTotalScore)
            )
        }

        return Pair(earnedPoints, rhythm)
    }

    private fun calculateLevel(score: Int): Triple<Int, String, Int> {
        return when {
            score < 300 -> Triple(1, "Novato del Léxico", 300)
            score < 800 -> Triple(2, "Explorador de Palabras", 800)
            score < 1600 -> Triple(3, "Lector Aventajado", 1600)
            score < 3000 -> Triple(4, "Maestro del Vocabulario", 3000)
            else -> Triple(5, "Sabio de la Lengua", 5000)
        }
    }

    private fun getInitialBadges(): List<BadgeItem> {
        return listOf(
            BadgeItem("primer_acierto", "Primera Victoria", "Descifra tu primera palabra correctamente", "🌱"),
            BadgeItem("ritmo_maestro", "Ritmo Imparable", "Acierta 3 palabras en el ritmo perfecto", "🎵"),
            BadgeItem("maestro_inverso", "Mente Bidireccional", "Adivina 5 palabras a partir de su significado (Al Revés)", "🔄"),
            BadgeItem("racha_fuego", "Racha Llameante", "Consigue una racha de 5 aciertos seguidos", "🔥"),
            BadgeItem("centurion", "Club de los 1,000", "Acumula 1,000 puntos de Léxico", "👑")
        )
    }

    private fun buildChallenges(reverseCount: Int, rhythmCount: Int, score: Int): List<DailyChallenge> {
        return listOf(
            DailyChallenge(
                id = "challenge_reverse",
                title = "Al Revés: ¿A qué palabra se refiere?",
                description = "Identifica la palabra a partir de su significado o imagen",
                targetCount = 5,
                currentCount = reverseCount.coerceAtMost(5),
                rewardPoints = 250,
                isCompleted = reverseCount >= 5
            ),
            DailyChallenge(
                id = "challenge_rhythm",
                title = "Maestría del Ritmo",
                description = "Responde en la zona de ritmo perfecto para multiplicar puntos",
                targetCount = 3,
                currentCount = rhythmCount.coerceAtMost(3),
                rewardPoints = 300,
                isCompleted = rhythmCount >= 3
            ),
            DailyChallenge(
                id = "challenge_score",
                title = "Cosecha de Sabiduría",
                description = "Alcanza al menos 500 puntos en sesiones de estudio",
                targetCount = 500,
                currentCount = score.coerceAtMost(500),
                rewardPoints = 400,
                isCompleted = score >= 500
            )
        )
    }
}
