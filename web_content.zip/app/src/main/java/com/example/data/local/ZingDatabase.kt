package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        VideoEntity::class,
        CommentEntity::class,
        NotificationEntity::class,
        PayoutEntity::class,
        ReportEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ZingDatabase : RoomDatabase() {
    abstract fun zingDao(): ZingDao

    companion object {
        @Volatile
        private var INSTANCE: ZingDatabase? = null

        fun getDatabase(context: Context): ZingDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ZingDatabase::class.java,
                    "zing_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
