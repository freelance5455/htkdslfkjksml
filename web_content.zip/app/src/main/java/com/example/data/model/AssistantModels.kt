package com.example.data.model

import android.graphics.Bitmap
import androidx.compose.ui.graphics.vector.ImageVector

enum class AssistantState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    EXECUTING
}

enum class MessageSender {
    USER,
    XTRA,
    SYSTEM
}

enum class VoiceLanguage(val code: String, val displayName: String) {
    ENGLISH("en-US", "English"),
    HINDI("hi-IN", "Hindi (हिंदी)"),
    HINGLISH("en-IN", "Hinglish")
}

enum class ActionType {
    CALL_PHONE,
    SEND_SMS,
    WHATSAPP,
    TOGGLE_TORCH,
    LAUNCH_APP,
    RUN_ROUTINE,
    SET_TIMER,
    SET_ALARM,
    ADJUST_VOLUME,
    SYSTEM_SETTING
}

data class ActionConfirmation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val actionType: ActionType,
    val title: String,
    val description: String,
    val targetName: String = "",
    val targetValue: String = "",
    val extraData: Map<String, String> = emptyMap(),
    val onConfirm: () -> Unit = {},
    val onCancel: () -> Unit = {}
)

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val imageBitmap: Bitmap? = null,
    val actionConfirmation: ActionConfirmation? = null,
    val actionSuccessMessage: String? = null
)

data class DeviceStatus(
    val batteryPercent: Int = 85,
    val isCharging: Boolean = false,
    val isWifiConnected: Boolean = true,
    val isNetworkAvailable: Boolean = true,
    val isTorchOn: Boolean = false,
    val mediaVolumePercent: Int = 60,
    val screenBrightnessPercent: Int = 75,
    val deviceModel: String = "",
    val androidVersion: String = "",
    val manufacturer: String = "",
    val memoryUsageText: String = ""
)

data class RoutineStep(
    val description: String,
    val actionType: ActionType,
    val param: String = ""
)

data class AutomationRoutine(
    val id: String,
    val name: String,
    val description: String,
    val voiceTrigger: String,
    val iconName: String,
    val isBuiltIn: Boolean = false,
    val isEnabled: Boolean = true,
    val steps: List<RoutineStep> = emptyList()
)

data class AppInfo(
    val label: String,
    val packageName: String
)

data class WeatherInfo(
    val city: String = "Current Location",
    val tempC: Double = 26.5,
    val condition: String = "Clear Sky",
    val humidityPercent: Int = 54,
    val windSpeedKmh: Double = 12.0,
    val highTemp: Double = 30.0,
    val lowTemp: Double = 21.0
)

data class ContactItem(
    val id: String,
    val name: String,
    val phoneNumber: String
)

data class SmsItem(
    val sender: String,
    val body: String,
    val date: Long
)

data class CallLogItem(
    val number: String,
    val name: String?,
    val type: String,
    val date: Long
)

data class VisionAnalysisResult(
    val summary: String,
    val detectedText: String = "",
    val objectLabels: List<String> = emptyList(),
    val suggestions: List<String> = emptyList()
)
