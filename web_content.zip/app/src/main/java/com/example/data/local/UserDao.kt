package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    fun getUserFlow(uid: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE uid = :uid LIMIT 1")
    suspend fun getUser(uid: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(user: UserEntity)

    @Query("UPDATE users SET coins = coins + :addedCoins, dailyCoins = dailyCoins + :addedCoins, weeklyCoins = weeklyCoins + :addedCoins WHERE uid = :uid")
    suspend fun addCoins(uid: String, addedCoins: Long)

    @Query("UPDATE users SET gems = gems + :addedGems WHERE uid = :uid")
    suspend fun addGems(uid: String, addedGems: Long)

    @Query("UPDATE users SET gems = gems - :deductedGems WHERE uid = :uid AND gems >= :deductedGems")
    suspend fun deductGems(uid: String, deductedGems: Long): Int

    @Query("UPDATE users SET coins = coins - :deductedCoins WHERE uid = :uid AND coins >= :deductedCoins")
    suspend fun deductCoins(uid: String, deductedCoins: Long): Int

    @Query("DELETE FROM users WHERE uid = :uid")
    suspend fun deleteUser(uid: String)

    @Query("DELETE FROM users")
    suspend fun clearAll()
}
