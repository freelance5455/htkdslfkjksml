package com.example.data.remote

import android.util.Log
import com.example.data.model.AiModelOption
import com.example.data.model.AiProvider
import com.example.data.model.SandboxSpec
import com.example.data.model.SandboxWidget
import com.example.data.model.StudioProject
import com.example.data.model.WebsiteLayoutPreset
import com.example.data.model.WebsiteSectionSpec
import com.example.data.model.WebsiteSpec
import com.example.data.model.WebsiteThemePalette
import com.example.data.repository.ApiHubConfig
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "MultiModelAiService"

data class GenerationTelemetry(
    val provider: AiProvider,
    val modelId: String,
    val routeDescription: String,
    val latencyMs: Long,
    val statusMessage: String
)

data class GeneratedStudioBundle(
    val project: StudioProject,
    val telemetry: GenerationTelemetry
)

class MultiModelAiService {

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    private val studioOutputSchema by lazy {
        val widgetSchema = Schema.obj(
            properties = mapOf(
                "id" to Schema.string(description = "Unique snake_case identifier for the widget"),
                "type" to Schema.enumeration(
                    values = listOf(
                        "SLIDER",
                        "NUMBER_INPUT",
                        "TEXT_INPUT",
                        "TOGGLE",
                        "SEGMENTED",
                        "CHECKLIST",
                        "METRIC_CARD"
                    ),
                    description = "Interactive widget type rendered in the Live Sandbox"
                ),
                "label" to Schema.string(description = "Concise widget label"),
                "subtitle" to Schema.string(description = "Helper description or formula role"),
                "defaultValue" to Schema.string(description = "Initial realistic value (no dummy lorem ipsum)"),
                "minValue" to Schema.double(description = "Minimum value if SLIDER, else 0"),
                "maxValue" to Schema.double(description = "Maximum value if SLIDER, else 100"),
                "unit" to Schema.string(description = "Measurement unit such as %, ms, USD, kg, min"),
                "options" to Schema.array(
                    items = Schema.string(),
                    description = "Options if SEGMENTED or initial items if CHECKLIST"
                )
            )
        )

        Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Clean, professional Android app title (max 60 chars)"),
                "summary" to Schema.string(description = "Concise architecture summary of the generated utility"),
                "tagline" to Schema.string(description = "One-line functional subtitle for the Live Sandbox header"),
                "themeAccentHex" to Schema.string(description = "Hex color string like #38BDF8, #818CF8, or #34D399"),
                "primaryFormulaLabel" to Schema.string(description = "Label for the primary computed metric in the sandbox"),
                "primaryFormulaUnit" to Schema.string(description = "Unit for the primary computed metric"),
                "formulaMode" to Schema.enumeration(
                    values = listOf("MULTIPLY", "ADD", "RATIO", "COMPOUND", "CUSTOM_SCORE"),
                    description = "How numeric inputs combine in the live sandbox calculation"
                ),
                "widgets" to Schema.array(
                    items = widgetSchema,
                    description = "4 to 6 interactive widgets that make the Live Sandbox immediately functional"
                ),
                "kotlinCode" to Schema.string(description = "Complete, self-contained Kotlin Jetpack Compose MainActivity.kt source code"),
                "manifestXml" to Schema.string(description = "Complete AndroidManifest.xml source"),
                "buildGradleKts" to Schema.string(description = "Complete app/build.gradle.kts configuration")
            )
        )
    }

    private val websiteOutputSchema by lazy {
        val sectionSchema = Schema.obj(
            properties = mapOf(
                "id" to Schema.string(description = "Unique snake_case section id"),
                "sectionType" to Schema.enumeration(
                    values = listOf(
                        "HERO",
                        "FEATURE_GRID",
                        "INTERACTIVE_CALCULATOR",
                        "PRICING_MATRIX",
                        "FAQ_ACCORDION",
                        "CTA_BANNER"
                    ),
                    description = "Website section type"
                ),
                "heading" to Schema.string(description = "Section heading"),
                "subheading" to Schema.string(description = "Section subheading or value proposition"),
                "badge" to Schema.string(description = "Short section badge label"),
                "items" to Schema.array(
                    items = Schema.string(),
                    description = "3 to 5 bullet items, feature cards, pricing tiers, or Q&A pairs for this section"
                )
            )
        )

        Schema.obj(
            properties = mapOf(
                "siteTitle" to Schema.string(description = "Clean, professional website brand/product title"),
                "summary" to Schema.string(description = "2-sentence overview of the website architecture"),
                "tagline" to Schema.string(description = "Concise value proposition subtitle"),
                "seoMetaDescription" to Schema.string(description = "SEO meta description (120-160 chars)"),
                "navLinks" to Schema.array(items = Schema.string(), description = "3 to 5 top navigation labels"),
                "heroHeadline" to Schema.string(description = "Primary hero headline"),
                "heroSubheadline" to Schema.string(description = "Supporting hero subheadline"),
                "heroCtaLabel" to Schema.string(description = "Primary call-to-action button label"),
                "calculatorLabel" to Schema.string(description = "Interactive web calculator metric label"),
                "calculatorUnit" to Schema.string(description = "Interactive web calculator unit (e.g. USD/mo, ms, %, hrs)"),
                "calculatorMultiplier" to Schema.double(description = "Numeric multiplier for the live web calculator"),
                "sections" to Schema.array(
                    items = sectionSchema,
                    description = "4 to 6 structured website sections"
                ),
                "indexHtml" to Schema.string(description = "Complete semantic HTML5 document (index.html) with responsive viewport meta tag"),
                "stylesCss" to Schema.string(description = "Complete mobile-first CSS3 stylesheet (styles.css) with overflow-x: hidden and max-width: 100%"),
                "scriptJs" to Schema.string(description = "Complete interactive Vanilla ES6 JavaScript (app.js) powering calculators and UI interactions")
            )
        )
    }

    private val promptEnhancerSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "enhancedPrompt" to Schema.string(
                    description = "Expanded, detailed specification prompt including inputs, formulas, and UI layout."
                )
            )
        )
    }

    private val pingSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "status" to Schema.string(description = "Must be OK"),
                "modelEcho" to Schema.string(description = "Short confirmation message from the model")
            )
        )
    }

    private val geminiArgonModel by lazy {
        Firebase.ai.generativeModel(
            modelName = AiModelOption.GEMINI_4_ARGON.firebaseModelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = studioOutputSchema
            }
        )
    }

    private val geminiFlashModel by lazy {
        Firebase.ai.generativeModel(
            modelName = AiModelOption.GEMINI_3_5_FLASH.firebaseModelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = studioOutputSchema
            }
        )
    }

    private val geminiWebArgonModel by lazy {
        Firebase.ai.generativeModel(
            modelName = AiModelOption.GEMINI_4_ARGON.firebaseModelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = websiteOutputSchema
            }
        )
    }

    private val geminiWebFlashModel by lazy {
        Firebase.ai.generativeModel(
            modelName = AiModelOption.GEMINI_3_5_FLASH.firebaseModelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = websiteOutputSchema
            }
        )
    }

    private val geminiEnhancerModel by lazy {
        Firebase.ai.generativeModel(
            modelName = AiModelOption.GEMINI_3_5_FLASH.firebaseModelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = promptEnhancerSchema
            }
        )
    }

    private val geminiPingModel by lazy {
        Firebase.ai.generativeModel(
            modelName = AiModelOption.GEMINI_3_5_FLASH.firebaseModelName,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = pingSchema
            }
        )
    }

    suspend fun synthesizeAppFromPrompt(
        prompt: String,
        config: ApiHubConfig,
        userId: String
    ): Result<GeneratedStudioBundle> {
        val startMs = System.currentTimeMillis()
        val systemInstruction = buildSystemPrompt(prompt, config)
        return executeStudioSynthesis(
            instruction = systemInstruction,
            originalPrompt = prompt,
            config = config,
            userId = userId,
            startMs = startMs
        )
    }

    suspend fun synthesizeWebsiteFromPrompt(
        prompt: String,
        layoutPreset: WebsiteLayoutPreset,
        themePalette: WebsiteThemePalette,
        config: ApiHubConfig,
        userId: String
    ): Result<GeneratedStudioBundle> {
        val startMs = System.currentTimeMillis()
        val instruction = buildWebsiteSystemPrompt(prompt, layoutPreset, themePalette)
        return executeWebsiteSynthesis(
            instruction = instruction,
            originalPrompt = prompt,
            layoutPreset = layoutPreset,
            themePalette = themePalette,
            config = config,
            userId = userId,
            startMs = startMs
        )
    }

    suspend fun refineWebsiteProject(
        existingProject: StudioProject,
        refinementInstruction: String,
        config: ApiHubConfig
    ): Result<GeneratedStudioBundle> {
        val startMs = System.currentTimeMillis()
        val existingSpec = WebsiteSpec.fromJsonString(existingProject.sandboxSpecJson, existingProject.title)
        val layoutPreset = WebsiteLayoutPreset.fromId(existingSpec.layoutPresetId)
        val themePalette = WebsiteThemePalette.fromId(existingSpec.themePaletteId)
        val combinedPrompt = "${existingProject.prompt}\nWebsite Refinement: $refinementInstruction".take(4000)

        val instruction = """
            Refine and upgrade this existing responsive Website based on the user's instruction.
            Existing Site Title: "${existingProject.title}"
            Existing Spec JSON: ${existingProject.sandboxSpecJson}
            Existing index.html:
            ${existingProject.kotlinCode.take(8000)}
            Existing styles.css:
            ${existingProject.manifestXml.take(4000)}

            Refinement Instruction:
            "$refinementInstruction"

            Layout Preset: ${layoutPreset.label}
            Theme Palette: ${themePalette.label} (bg: ${themePalette.bgHex}, surface: ${themePalette.surfaceHex}, primary: ${themePalette.primaryHex}, text: ${themePalette.textHex})

            Strict requirements:
            1. Apply the requested refinement to BOTH the structured "sections" array AND the "indexHtml", "stylesCss", and "scriptJs" code.
            2. Maintain zero dummy data (no lorem ipsum) and strict mobile viewport compliance (box-sizing: border-box, overflow-x: hidden, max-width: 100%).
            3. Return a valid JSON object with the exact keys: "siteTitle", "summary", "tagline", "seoMetaDescription", "navLinks", "heroHeadline", "heroSubheadline", "heroCtaLabel", "calculatorLabel", "calculatorUnit", "calculatorMultiplier", "sections", "indexHtml", "stylesCss", "scriptJs".
        """.trimIndent()

        return executeWebsiteSynthesis(
            instruction = instruction,
            originalPrompt = combinedPrompt,
            layoutPreset = layoutPreset,
            themePalette = themePalette,
            config = config,
            userId = existingProject.userId,
            startMs = startMs,
            existingProjectId = existingProject.id,
            existingPinned = existingProject.isPinned
        )
    }

    suspend fun refineExistingProject(
        existingProject: StudioProject,
        refinementInstruction: String,
        config: ApiHubConfig
    ): Result<GeneratedStudioBundle> {
        if (existingProject.isWebsiteProject()) {
            return refineWebsiteProject(existingProject, refinementInstruction, config)
        }

        val startMs = System.currentTimeMillis()
        val combinedPrompt = "${existingProject.prompt}\nRefinement: $refinementInstruction".take(4000)
        val systemInstruction = """
            Refine and upgrade this existing Android Jetpack Compose application based on the user's instruction.
            Existing Title: "${existingProject.title}"
            Existing Summary: "${existingProject.summary}"
            Existing Sandbox Spec JSON: ${existingProject.sandboxSpecJson}
            Existing Kotlin Code:
            ${existingProject.kotlinCode.take(12000)}

            Refinement Instruction:
            "$refinementInstruction"

            Architecture Preset: ${config.architecturePreset.label} — ${config.architecturePreset.promptDirective}
            Strict requirements:
            1. Apply the requested refinement to BOTH the interactive "widgets" array in the sandbox specification AND the "kotlinCode".
            2. Maintain zero dummy data and strict vertical viewport wrapping (Modifier.fillMaxWidth(), 16.dp padding).
            3. Return a valid JSON object with the exact keys: "title", "summary", "tagline", "themeAccentHex", "primaryFormulaLabel", "primaryFormulaUnit", "formulaMode", "widgets", "kotlinCode", "manifestXml", "buildGradleKts".
        """.trimIndent()

        return executeStudioSynthesis(
            instruction = systemInstruction,
            originalPrompt = combinedPrompt,
            config = config,
            userId = existingProject.userId,
            startMs = startMs,
            existingProjectId = existingProject.id,
            existingPinned = existingProject.isPinned
        )
    }

    suspend fun enhancePromptSpecification(
        rawIdea: String,
        config: ApiHubConfig,
        isWebsiteTarget: Boolean = false
    ): Result<String> {
        val targetDomain = if (isWebsiteTarget) {
            "responsive HTML5/CSS3/JS Website with interactive calculator, hero, feature grid, and technical specifications"
        } else {
            "Android Jetpack Compose specification (${config.architecturePreset.label}) including interactive inputs, live calculation formula, and Material 3 layout"
        }
        val instruction = """
            Expand the following brief concept into a structured, production-grade $targetDomain prompt (3 to 5 sentences).
            Maintain real-world domain copy with zero lorem ipsum.
            Brief Idea: "$rawIdea"
            Return JSON: {"enhancedPrompt": "..."}
        """.trimIndent()

        return try {
            val rawJson = withTimeout(45_000L) {
                when (config.selectedProvider) {
                    AiProvider.OPENAI -> {
                        val key = config.openAiApiKey.trim()
                        if (key.isEmpty()) throw IllegalStateException("Configure your OpenAI API key in API Hub first.")
                        callOpenAiApi(key, config.selectedModel.modelId, instruction, config.temperature, 1024)
                    }
                    AiProvider.ANTHROPIC -> {
                        val key = config.anthropicApiKey.trim()
                        if (key.isEmpty()) throw IllegalStateException("Configure your Anthropic API key in API Hub first.")
                        callAnthropicApi(key, config.selectedModel.modelId, instruction, config.temperature, 1024)
                    }
                    AiProvider.GEMINI -> {
                        val customKey = config.geminiCustomApiKey.trim()
                        if (!config.useFirebaseAiForGemini && customKey.isNotEmpty()) {
                            callGeminiRestApi(customKey, config.selectedModel.firebaseModelName, instruction, config.temperature)
                        } else {
                            geminiEnhancerModel.generateContent(instruction).text
                                ?: throw IllegalStateException("Empty response from Gemini.")
                        }
                    }
                }
            }
            val cleaned = extractCleanJsonObject(rawJson)
            val enhanced = JSONObject(cleaned).optString("enhancedPrompt", "").trim()
            if (enhanced.isBlank()) {
                Result.failure(IllegalStateException("Could not parse enhanced specification."))
            } else {
                Result.success(enhanced)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Prompt enhancement failed", e)
            Result.failure(e)
        }
    }

    suspend fun testEndpointConnection(config: ApiHubConfig): Result<GenerationTelemetry> {
        val startMs = System.currentTimeMillis()
        val pingPrompt = """Return JSON: {"status": "OK", "modelEcho": "Endpoint verified"}"""
        return try {
            val (rawJson, routeLabel) = withTimeout(30_000L) {
                when (config.selectedProvider) {
                    AiProvider.OPENAI -> {
                        val key = config.openAiApiKey.trim()
                        if (key.isEmpty()) throw IllegalStateException("OpenAI API key is empty.")
                        callOpenAiApi(key, config.selectedModel.modelId, pingPrompt, 0.0f, 128) to
                            "OpenAI Endpoint (${config.selectedModel.displayName})"
                    }
                    AiProvider.ANTHROPIC -> {
                        val key = config.anthropicApiKey.trim()
                        if (key.isEmpty()) throw IllegalStateException("Anthropic API key is empty.")
                        callAnthropicApi(key, config.selectedModel.modelId, pingPrompt, 0.0f, 128) to
                            "Anthropic Endpoint (${config.selectedModel.displayName})"
                    }
                    AiProvider.GEMINI -> {
                        val customKey = config.geminiCustomApiKey.trim()
                        if (!config.useFirebaseAiForGemini && customKey.isNotEmpty()) {
                            callGeminiRestApi(customKey, config.selectedModel.firebaseModelName, pingPrompt, 0.0f) to
                                "Gemini REST Endpoint (${config.selectedModel.displayName})"
                        } else if (!config.useFirebaseAiForGemini && customKey.isEmpty()) {
                            throw IllegalStateException("Custom Gemini key mode is active, but no key was entered.")
                        } else {
                            val resp = geminiPingModel.generateContent(pingPrompt).text.orEmpty()
                            resp to "Firebase AI Logic (${config.selectedModel.displayName})"
                        }
                    }
                }
            }
            val elapsedMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
            val echo = try {
                JSONObject(extractCleanJsonObject(rawJson)).optString("modelEcho", "Handshake OK")
            } catch (_: Exception) {
                "Handshake OK"
            }
            Result.success(
                GenerationTelemetry(
                    provider = config.selectedProvider,
                    modelId = config.selectedModel.modelId,
                    routeDescription = routeLabel,
                    latencyMs = elapsedMs,
                    statusMessage = "Diagnostic Ping OK ($echo) in ${elapsedMs}ms via $routeLabel"
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Endpoint diagnostic failed", e)
            Result.failure(e)
        }
    }

    private suspend fun executeWebsiteSynthesis(
        instruction: String,
        originalPrompt: String,
        layoutPreset: WebsiteLayoutPreset,
        themePalette: WebsiteThemePalette,
        config: ApiHubConfig,
        userId: String,
        startMs: Long,
        existingProjectId: String = "",
        existingPinned: Boolean = false
    ): Result<GeneratedStudioBundle> {
        return try {
            val (rawJson, routeLabel) = withTimeout(60_000L) {
                when (config.selectedProvider) {
                    AiProvider.OPENAI -> {
                        val key = config.openAiApiKey.trim()
                        if (key.isEmpty()) {
                            throw IllegalStateException(
                                "OpenAI API key is not configured. Open the API Hub tab to enter your personal OpenAI key, or switch to Google Gemini."
                            )
                        }
                        val json = callOpenAiApi(
                            apiKey = key,
                            modelId = config.selectedModel.modelId,
                            prompt = instruction,
                            temperature = config.temperature,
                            maxTokens = config.maxOutputTokens
                        )
                        json to "OpenAI REST API (${config.selectedModel.displayName})"
                    }

                    AiProvider.ANTHROPIC -> {
                        val key = config.anthropicApiKey.trim()
                        if (key.isEmpty()) {
                            throw IllegalStateException(
                                "Anthropic API key is not configured. Open the API Hub tab to enter your personal Claude key, or switch to Google Gemini."
                            )
                        }
                        val json = callAnthropicApi(
                            apiKey = key,
                            modelId = config.selectedModel.modelId,
                            prompt = instruction,
                            temperature = config.temperature,
                            maxTokens = config.maxOutputTokens
                        )
                        json to "Anthropic Messages API (${config.selectedModel.displayName})"
                    }

                    AiProvider.GEMINI -> {
                        val customKey = config.geminiCustomApiKey.trim()
                        if (!config.useFirebaseAiForGemini && customKey.isNotEmpty()) {
                            val json = callGeminiRestApi(
                                apiKey = customKey,
                                modelId = config.selectedModel.firebaseModelName,
                                prompt = instruction,
                                temperature = config.temperature
                            )
                            json to "Google Gemini REST API (${config.selectedModel.displayName})"
                        } else if (!config.useFirebaseAiForGemini && customKey.isEmpty()) {
                            throw IllegalStateException(
                                "Custom Gemini API key mode is selected, but no key was entered. Enter a Gemini key in API Hub or enable Firebase AI Logic mode."
                            )
                        } else {
                            val activeModel = if (config.selectedModel == AiModelOption.GEMINI_4_ARGON) {
                                geminiWebArgonModel
                            } else {
                                geminiWebFlashModel
                            }
                            val response = activeModel.generateContent(instruction)
                            val text = response.text
                                ?: throw IllegalStateException("Gemini model returned an empty response.")
                            text to "Firebase AI Logic (${config.selectedModel.displayName})"
                        }
                    }
                }
            }

            val elapsedMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
            val project = parseGeneratedWebsiteProject(
                rawJson = rawJson,
                originalPrompt = originalPrompt,
                layoutPreset = layoutPreset,
                themePalette = themePalette,
                config = config,
                userId = userId
            ).copy(
                id = existingProjectId,
                isPinned = existingPinned
            )

            Result.success(
                GeneratedStudioBundle(
                    project = project,
                    telemetry = GenerationTelemetry(
                        provider = config.selectedProvider,
                        modelId = config.selectedModel.modelId,
                        routeDescription = routeLabel,
                        latencyMs = elapsedMs,
                        statusMessage = "Built website '${project.title}' in ${elapsedMs}ms via $routeLabel"
                    )
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Website synthesis timed out", e)
            Result.failure(
                IllegalStateException("Website synthesis timed out after 60 seconds. Please simplify your prompt or try a faster model.")
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Website synthesis failed for ${config.selectedProvider}", e)
            Result.failure(e)
        }
    }

    private suspend fun executeStudioSynthesis(
        instruction: String,
        originalPrompt: String,
        config: ApiHubConfig,
        userId: String,
        startMs: Long,
        existingProjectId: String = "",
        existingPinned: Boolean = false
    ): Result<GeneratedStudioBundle> {
        return try {
            val (rawJson, routeLabel) = withTimeout(60_000L) {
                when (config.selectedProvider) {
                    AiProvider.OPENAI -> {
                        val key = config.openAiApiKey.trim()
                        if (key.isEmpty()) {
                            throw IllegalStateException(
                                "OpenAI API key is not configured. Open the API Hub tab to enter your personal OpenAI key, or switch to Google Gemini."
                            )
                        }
                        val json = callOpenAiApi(
                            apiKey = key,
                            modelId = config.selectedModel.modelId,
                            prompt = instruction,
                            temperature = config.temperature,
                            maxTokens = config.maxOutputTokens
                        )
                        json to "OpenAI REST API (${config.selectedModel.displayName})"
                    }

                    AiProvider.ANTHROPIC -> {
                        val key = config.anthropicApiKey.trim()
                        if (key.isEmpty()) {
                            throw IllegalStateException(
                                "Anthropic API key is not configured. Open the API Hub tab to enter your personal Claude key, or switch to Google Gemini."
                            )
                        }
                        val json = callAnthropicApi(
                            apiKey = key,
                            modelId = config.selectedModel.modelId,
                            prompt = instruction,
                            temperature = config.temperature,
                            maxTokens = config.maxOutputTokens
                        )
                        json to "Anthropic Messages API (${config.selectedModel.displayName})"
                    }

                    AiProvider.GEMINI -> {
                        val customKey = config.geminiCustomApiKey.trim()
                        if (!config.useFirebaseAiForGemini && customKey.isNotEmpty()) {
                            val json = callGeminiRestApi(
                                apiKey = customKey,
                                modelId = config.selectedModel.firebaseModelName,
                                prompt = instruction,
                                temperature = config.temperature
                            )
                            json to "Google Gemini REST API (${config.selectedModel.displayName})"
                        } else if (!config.useFirebaseAiForGemini && customKey.isEmpty()) {
                            throw IllegalStateException(
                                "Custom Gemini API key mode is selected, but no key was entered. Enter a Gemini key in API Hub or enable Firebase AI Logic mode."
                            )
                        } else {
                            val activeModel = if (config.selectedModel == AiModelOption.GEMINI_4_ARGON) {
                                geminiArgonModel
                            } else {
                                geminiFlashModel
                            }
                            val response = activeModel.generateContent(instruction)
                            val text = response.text
                                ?: throw IllegalStateException("Gemini model returned an empty response.")
                            text to "Firebase AI Logic (${config.selectedModel.displayName})"
                        }
                    }
                }
            }

            val elapsedMs = (System.currentTimeMillis() - startMs).coerceAtLeast(1L)
            val project = parseGeneratedProject(
                rawJson = rawJson,
                originalPrompt = originalPrompt,
                config = config,
                userId = userId
            ).copy(
                id = existingProjectId,
                isPinned = existingPinned
            )
            Result.success(
                GeneratedStudioBundle(
                    project = project,
                    telemetry = GenerationTelemetry(
                        provider = config.selectedProvider,
                        modelId = config.selectedModel.modelId,
                        routeDescription = routeLabel,
                        latencyMs = elapsedMs,
                        statusMessage = "Synthesized ${project.title} in ${elapsedMs}ms via $routeLabel"
                    )
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI synthesis timed out", e)
            Result.failure(
                IllegalStateException("Synthesis timed out after 60 seconds. Please simplify your prompt or try a faster model.")
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI synthesis failed for ${config.selectedProvider}", e)
            Result.failure(e)
        }
    }

    private suspend fun callOpenAiApi(
        apiKey: String,
        modelId: String,
        prompt: String,
        temperature: Float,
        maxTokens: Int
    ): String = withContext(Dispatchers.IO) {
        val requestJson = JSONObject().apply {
            put("model", modelId)
            put("response_format", JSONObject().put("type", "json_object"))
            put(
                "messages",
                JSONArray().apply {
                    put(
                        JSONObject()
                            .put("role", "system")
                            .put("content", "You are an expert Android & Full-Stack Web architect. Always respond with raw, valid JSON matching the requested schema.")
                    )
                    put(
                        JSONObject()
                            .put("role", "user")
                            .put("content", prompt)
                    )
                }
            )
            put("temperature", temperature.toDouble())
            put("max_tokens", maxTokens)
        }

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        httpClient.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errMsg = try {
                    JSONObject(bodyStr).optJSONObject("error")?.optString("message")
                } catch (_: Exception) {
                    null
                } ?: "HTTP ${response.code}"
                throw IllegalStateException("OpenAI API error: $errMsg")
            }
            val root = JSONObject(bodyStr)
            val content = root.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
            extractCleanJsonObject(content)
        }
    }

    private suspend fun callAnthropicApi(
        apiKey: String,
        modelId: String,
        prompt: String,
        temperature: Float,
        maxTokens: Int
    ): String = withContext(Dispatchers.IO) {
        val requestJson = JSONObject().apply {
            put("model", modelId)
            put("max_tokens", maxTokens)
            put("temperature", temperature.toDouble())
            put(
                "system",
                "You are an expert Android & Full-Stack Web architect. Output ONLY a single valid JSON object without markdown code fences or commentary."
            )
            put(
                "messages",
                JSONArray().apply {
                    put(
                        JSONObject()
                            .put("role", "user")
                            .put("content", prompt)
                    )
                }
            )
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .header("content-type", "application/json")
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        httpClient.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errMsg = try {
                    JSONObject(bodyStr).optJSONObject("error")?.optString("message")
                } catch (_: Exception) {
                    null
                } ?: "HTTP ${response.code}"
                throw IllegalStateException("Anthropic API error: $errMsg")
            }
            val root = JSONObject(bodyStr)
            val contentArr = root.getJSONArray("content")
            val text = contentArr.getJSONObject(0).getString("text")
            extractCleanJsonObject(text)
        }
    }

    private suspend fun callGeminiRestApi(
        apiKey: String,
        modelId: String,
        prompt: String,
        temperature: Float
    ): String = withContext(Dispatchers.IO) {
        val requestJson = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            put(
                "generationConfig",
                JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("temperature", temperature.toDouble())
            )
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody("application/json".toMediaType()))
            .build()

        httpClient.newCall(request).execute().use { response ->
            val bodyStr = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val errMsg = try {
                    JSONObject(bodyStr).optJSONObject("error")?.optString("message")
                } catch (_: Exception) {
                    null
                } ?: "HTTP ${response.code}"
                throw IllegalStateException("Gemini REST API error: $errMsg")
            }
            val root = JSONObject(bodyStr)
            val text = root.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
            extractCleanJsonObject(text)
        }
    }

    private fun extractCleanJsonObject(raw: String): String {
        val trimmed = raw.trim()
        val firstBrace = trimmed.indexOf('{')
        val lastBrace = trimmed.lastIndexOf('}')
        if (firstBrace != -1 && lastBrace > firstBrace) {
            return trimmed.substring(firstBrace, lastBrace + 1)
        }
        return trimmed
    }

    private fun buildWebsiteSystemPrompt(
        userPrompt: String,
        layoutPreset: WebsiteLayoutPreset,
        themePalette: WebsiteThemePalette
    ): String {
        return """
            Synthesize a complete, production-grade responsive Website (HTML5 + CSS3 + ES6 JavaScript) for the following specification:
            "$userPrompt"

            Website Layout Preset: ${layoutPreset.label} — ${layoutPreset.promptDirective}
            Color Palette: ${themePalette.label}
            - Background: ${themePalette.bgHex}
            - Card Surface: ${themePalette.surfaceHex}
            - Primary Accent: ${themePalette.primaryHex}
            - Secondary Accent: ${themePalette.secondaryHex}
            - Text Color: ${themePalette.textHex}

            Strict requirements:
            1. NO DUMMY DATA: Never use lorem ipsum, fake user lists, or placeholder names. Use real domain copy, realistic metrics, and working calculator formulas.
            2. ZERO HORIZONTAL OVERFLOW: The website must strictly fit within mobile and desktop viewports (`box-sizing: border-box; max-width: 100%; overflow-x: hidden; word-wrap: break-word;`).
            3. Return a valid JSON object with these exact keys:
               - "siteTitle": String (brand or web app title, max 50 chars)
               - "summary": String (2-sentence architectural summary)
               - "tagline": String (short value proposition)
               - "seoMetaDescription": String (SEO meta description, 120-160 chars)
               - "navLinks": Array of 4 navigation link strings
               - "heroHeadline": String (compelling hero headline)
               - "heroSubheadline": String (supporting technical subheadline)
               - "heroCtaLabel": String (CTA button label)
               - "calculatorLabel": String (label for the embedded interactive web calculator)
               - "calculatorUnit": String (unit for the calculator output, e.g. "USD/mo", "ms", "reqs/s", "%")
               - "calculatorMultiplier": Number (multiplier used in the interactive calculator)
               - "sections": Array of 4 to 5 section objects:
                 {"id": "snake_case_id", "sectionType": "HERO"|"FEATURE_GRID"|"INTERACTIVE_CALCULATOR"|"PRICING_MATRIX"|"FAQ_ACCORDION"|"CTA_BANNER", "heading": "String", "subheading": "String", "badge": "String", "items": ["String"]}
               - "indexHtml": Complete semantic HTML5 document (`<!DOCTYPE html>...`) with `<meta name="viewport" content="width=device-width, initial-scale=1.0">`, `<header>`, `<main>`, `<section>`, interactive range/number inputs for the calculator, and `<footer>`.
               - "stylesCss": Complete responsive CSS3 stylesheet using the specified color palette (`${themePalette.bgHex}`, `${themePalette.surfaceHex}`, `${themePalette.primaryHex}`) and vertical mobile-first layout (`max-width: 100%; overflow-x: hidden;`).
               - "scriptJs": Complete Vanilla ES6 JavaScript wiring up the interactive calculator inputs and CTA buttons inside `indexHtml`.
        """.trimIndent()
    }

    private fun buildSystemPrompt(userPrompt: String, config: ApiHubConfig): String {
        return """
            Synthesize a complete, production-grade Android Jetpack Compose mini-application for the following user specification:
            "$userPrompt"

            Architecture Pattern: ${config.architecturePreset.label} — ${config.architecturePreset.promptDirective}

            Strict requirements:
            1. NO DUMMY DATA: Never use lorem ipsum, fake user lists, or placeholder names. Use real-world domain labels, formulas, units, and functional defaults.
            2. Return a JSON object with these exact keys:
               - "title": String (concise app name, max 60 chars)
               - "summary": String (2-sentence architectural overview)
               - "tagline": String (short functional subtitle)
               - "themeAccentHex": String (hex color such as "#38BDF8", "#818CF8", "#34D399", "#F59E0B")
               - "primaryFormulaLabel": String (name of the primary live computed output in the sandbox)
               - "primaryFormulaUnit": String (unit of the primary output, e.g., "USD", "ms", "kcal", "%", "pts")
               - "formulaMode": String (one of "MULTIPLY", "ADD", "RATIO", "COMPOUND", "CUSTOM_SCORE")
               - "widgets": Array of 4 to 6 interactive widget objects, each having:
                 {"id": "snake_case_id", "type": "SLIDER"|"NUMBER_INPUT"|"TEXT_INPUT"|"TOGGLE"|"SEGMENTED"|"CHECKLIST"|"METRIC_CARD", "label": "String", "subtitle": "String", "defaultValue": "String", "minValue": Number, "maxValue": Number, "unit": "String", "options": ["String"]}
               - "kotlinCode": Complete Kotlin Jetpack Compose MainActivity.kt implementing the requested tool with Material 3 components, Modifier.fillMaxWidth(), 16.dp horizontal padding, and zero horizontal overflow.
               - "manifestXml": Complete AndroidManifest.xml for the generated project.
               - "buildGradleKts": Complete app/build.gradle.kts for the generated project.
        """.trimIndent()
    }

    private fun parseGeneratedWebsiteProject(
        rawJson: String,
        originalPrompt: String,
        layoutPreset: WebsiteLayoutPreset,
        themePalette: WebsiteThemePalette,
        config: ApiHubConfig,
        userId: String
    ): StudioProject {
        val cleaned = extractCleanJsonObject(rawJson)
        val obj = JSONObject(cleaned)
        val siteTitle = obj.optString("siteTitle", obj.optString("title", "Custom Web Platform"))
            .trim()
            .ifBlank { "Custom Web Platform" }
        val summary = obj.optString(
            "summary",
            "Responsive ${layoutPreset.label} synthesized with semantic HTML5, mobile-first CSS3, and interactive ES6 JavaScript."
        ).trim()
        val tagline = obj.optString("tagline", layoutPreset.subtitle).trim()
        val seoMeta = obj.optString("seoMetaDescription", summary).trim()
        val heroHeadline = obj.optString("heroHeadline", siteTitle).trim()
        val heroSubheadline = obj.optString("heroSubheadline", tagline).trim()
        val heroCtaLabel = obj.optString("heroCtaLabel", "Calculate Now").trim()
        val calcLabel = obj.optString("calculatorLabel", "Projected Output").trim()
        val calcUnit = obj.optString("calculatorUnit", "USD").trim()
        val calcMult = obj.optDouble("calculatorMultiplier", 15.0).toFloat()

        val navArr = obj.optJSONArray("navLinks") ?: JSONArray()
        val navLinks = mutableListOf<String>()
        for (i in 0 until navArr.length()) {
            val link = navArr.optString(i).trim()
            if (link.isNotEmpty()) navLinks.add(link)
        }
        if (navLinks.isEmpty()) {
            navLinks.addAll(listOf("Overview", "Features", "Calculator", "Specs"))
        }

        val sectionsArr = obj.optJSONArray("sections") ?: JSONArray()
        val parsedSections = mutableListOf<WebsiteSectionSpec>()
        for (i in 0 until sectionsArr.length()) {
            val s = sectionsArr.optJSONObject(i) ?: continue
            val itemsArr = s.optJSONArray("items") ?: JSONArray()
            val items = mutableListOf<String>()
            for (j in 0 until itemsArr.length()) {
                val item = itemsArr.optString(j).trim()
                if (item.isNotEmpty()) items.add(item)
            }
            parsedSections.add(
                WebsiteSectionSpec(
                    id = s.optString("id", "sec_$i"),
                    sectionType = s.optString("sectionType", "FEATURE_GRID"),
                    heading = s.optString("heading", "Module ${i + 1}"),
                    subheading = s.optString("subheading", ""),
                    badge = s.optString("badge", "SECTION ${i + 1}"),
                    items = items
                )
            )
        }

        val websiteSpec = WebsiteSpec(
            siteTitle = siteTitle,
            tagline = tagline,
            layoutPresetId = layoutPreset.id,
            themePaletteId = themePalette.id,
            primaryColorHex = themePalette.primaryHex,
            secondaryColorHex = themePalette.secondaryHex,
            seoMetaDescription = seoMeta,
            navLinks = navLinks,
            heroHeadline = heroHeadline,
            heroSubheadline = heroSubheadline,
            heroCtaLabel = heroCtaLabel,
            calculatorLabel = calcLabel,
            calculatorUnit = calcUnit,
            calculatorMultiplier = calcMult,
            sections = parsedSections
        )

        val defaultCss = """
            * { box-sizing: border-box; margin: 0; padding: 0; }
            html, body {
              width: 100%;
              max-width: 100%;
              overflow-x: hidden;
              background-color: ${themePalette.bgHex};
              color: ${themePalette.textHex};
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              line-height: 1.5;
            }
            header, main, footer { width: 100%; max-width: 100%; padding: 16px; }
            .card {
              background: ${themePalette.surfaceHex};
              border: 1px solid ${themePalette.primaryHex}33;
              border-radius: 12px;
              padding: 16px;
              margin-bottom: 14px;
            }
            .accent { color: ${themePalette.primaryHex}; }
            .btn {
              display: inline-block;
              width: 100%;
              text-align: center;
              background: ${themePalette.primaryHex};
              color: #0B0F17;
              font-weight: 700;
              padding: 12px 16px;
              border-radius: 8px;
              border: none;
              cursor: pointer;
              margin-top: 10px;
            }
            input[type="range"], input[type="number"] {
              width: 100%;
              margin-top: 8px;
            }
        """.trimIndent()

        val stylesCss = obj.optString("stylesCss", "").trim().ifBlank { defaultCss }

        val defaultHtml = buildString {
            appendLine("<!DOCTYPE html>")
            appendLine("<html lang=\"en\">")
            appendLine("<head>")
            appendLine("  <meta charset=\"UTF-8\">")
            appendLine("  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">")
            appendLine("  <meta name=\"description\" content=\"${seoMeta.replace("\"", "'")}\">")
            appendLine("  <title>$siteTitle</title>")
            appendLine("  <link rel=\"stylesheet\" href=\"styles.css\">")
            appendLine("</head>")
            appendLine("<body>")
            appendLine("  <header class=\"card\">")
            appendLine("    <h1 class=\"accent\">$heroHeadline</h1>")
            appendLine("    <p>$heroSubheadline</p>")
            appendLine("  </header>")
            appendLine("  <main>")
            appendLine("    <section class=\"card\" id=\"calculator\">")
            appendLine("      <h2>$calcLabel</h2>")
            appendLine("      <label for=\"calcInput\">Adjust Input Scale</label>")
            appendLine("      <input id=\"calcInput\" type=\"range\" min=\"1\" max=\"200\" value=\"25\" />")
            appendLine("      <p>Result: <strong id=\"calcOutput\" class=\"accent\">${25 * calcMult} $calcUnit</strong></p>")
            appendLine("    </section>")
            parsedSections.forEach { sec ->
                appendLine("    <section class=\"card\">")
                appendLine("      <h3>${sec.heading}</h3>")
                appendLine("      <p>${sec.subheading}</p>")
                if (sec.items.isNotEmpty()) {
                    appendLine("      <ul>")
                    sec.items.forEach { item -> appendLine("        <li>$item</li>") }
                    appendLine("      </ul>")
                }
                appendLine("    </section>")
            }
            appendLine("  </main>")
            appendLine("  <footer><small>$siteTitle • Built with OmniPrompt Website Maker</small></footer>")
            appendLine("  <script src=\"app.js\"></script>")
            appendLine("</body>")
            appendLine("</html>")
        }

        val indexHtml = obj.optString("indexHtml", "").trim().ifBlank { defaultHtml }

        val defaultJs = """
            document.addEventListener('DOMContentLoaded', () => {
              const slider = document.getElementById('calcInput');
              const output = document.getElementById('calcOutput');
              const multiplier = $calcMult;
              if (slider && output) {
                slider.addEventListener('input', (e) => {
                  const val = parseFloat(e.target.value || '0');
                  output.textContent = (val * multiplier).toFixed(1) + ' $calcUnit';
                });
              }
            });
        """.trimIndent()

        val scriptJs = obj.optString("scriptJs", "").trim().ifBlank { defaultJs }

        return StudioProject(
            userId = userId,
            title = siteTitle,
            prompt = originalPrompt,
            provider = config.selectedProvider.id,
            modelId = config.selectedModel.modelId,
            summary = summary,
            sandboxSpecJson = websiteSpec.toJsonString(),
            kotlinCode = indexHtml,
            manifestXml = stylesCss,
            buildGradleKts = scriptJs,
            isPinned = false
        )
    }

    private fun parseGeneratedProject(
        rawJson: String,
        originalPrompt: String,
        config: ApiHubConfig,
        userId: String
    ): StudioProject {
        val cleaned = extractCleanJsonObject(rawJson)
        val obj = JSONObject(cleaned)
        val title = obj.optString("title", "Custom Utility App").trim().ifBlank { "Custom Utility App" }
        val summary = obj.optString("summary", "Generated Android Jetpack Compose application.").trim()
        val tagline = obj.optString("tagline", "Interactive Native Compose Sandbox").trim()
        val themeAccentHex = obj.optString("themeAccentHex", "#38BDF8").trim()
        val primaryFormulaLabel = obj.optString("primaryFormulaLabel", "Computed Output").trim()
        val primaryFormulaUnit = obj.optString("primaryFormulaUnit", "units").trim()
        val formulaMode = obj.optString("formulaMode", "MULTIPLY").trim()

        val widgetsArr = obj.optJSONArray("widgets") ?: JSONArray()
        val parsedWidgets = mutableListOf<SandboxWidget>()
        for (i in 0 until widgetsArr.length()) {
            val w = widgetsArr.optJSONObject(i) ?: continue
            val optsArr = w.optJSONArray("options") ?: JSONArray()
            val opts = mutableListOf<String>()
            for (j in 0 until optsArr.length()) {
                val item = optsArr.optString(j).trim()
                if (item.isNotEmpty()) opts.add(item)
            }
            parsedWidgets.add(
                SandboxWidget(
                    id = w.optString("id", "widget_$i"),
                    type = w.optString("type", "SLIDER"),
                    label = w.optString("label", "Parameter ${i + 1}"),
                    subtitle = w.optString("subtitle", ""),
                    defaultValue = w.optString("defaultValue", "10"),
                    minValue = w.optDouble("minValue", 0.0).toFloat(),
                    maxValue = w.optDouble("maxValue", 100.0).toFloat().coerceAtLeast(1f),
                    unit = w.optString("unit", ""),
                    options = opts
                )
            )
        }

        val sandboxSpec = SandboxSpec(
            appTitle = title,
            tagline = tagline,
            themeAccentHex = themeAccentHex,
            primaryFormulaLabel = primaryFormulaLabel,
            primaryFormulaUnit = primaryFormulaUnit,
            formulaMode = formulaMode,
            widgets = parsedWidgets
        )

        val kotlinCode = obj.optString("kotlinCode", "").ifBlank {
            "// Generated by ${config.selectedModel.displayName}\npackage com.example\n"
        }
        val manifestXml = obj.optString("manifestXml", "").ifBlank {
            """
            <?xml version="1.0" encoding="utf-8"?>
            <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                <application android:label="$title" android:supportsRtl="true">
                    <activity android:name=".MainActivity" android:exported="true" />
                </application>
            </manifest>
            """.trimIndent()
        }
        val buildGradleKts = obj.optString("buildGradleKts", "").ifBlank {
            """
            plugins {
                id("com.android.application")
                id("org.jetbrains.kotlin.plugin.compose")
            }
            android {
                namespace = "com.example.generated"
                compileSdk = 36
            }
            """.trimIndent()
        }

        return StudioProject(
            userId = userId,
            title = title,
            prompt = originalPrompt,
            provider = config.selectedProvider.id,
            modelId = config.selectedModel.modelId,
            summary = summary,
            sandboxSpecJson = sandboxSpec.toJsonString(),
            kotlinCode = kotlinCode,
            manifestXml = manifestXml,
            buildGradleKts = buildGradleKts,
            isPinned = false
        )
    }
}
