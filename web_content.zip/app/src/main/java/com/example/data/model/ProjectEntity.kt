package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val scriptText: String,
    val voiceName: String = "",
    val voiceLocale: String = "en-US",
    val speechSpeed: Float = 1.0f,
    val pitch: Float = 1.0f,
    val pauseBetweenSentencesMs: Int = 250,
    val audioFilePath: String? = null,
    val audioDurationMs: Long = 0L,
    val wordCount: Int = 0,
    val characterCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
