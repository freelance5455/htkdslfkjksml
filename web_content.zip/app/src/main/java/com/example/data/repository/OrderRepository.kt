package com.example.data.repository

import com.example.data.local.OrderDao
import com.example.data.local.StudioPreferences
import com.example.data.model.Order
import com.example.data.remote.TelegramNotifier
import kotlinx.coroutines.flow.Flow

class OrderRepository(
    private val orderDao: OrderDao,
    private val preferences: StudioPreferences,
    private val telegramNotifier: TelegramNotifier = TelegramNotifier()
) {
    val allOrders: Flow<List<Order>> = orderDao.getAllOrders()

    fun getOrderById(id: Long): Flow<Order?> = orderDao.getOrderById(id)

    fun getOrdersByStatus(status: String): Flow<List<Order>> = orderDao.getOrdersByStatus(status)

    fun searchOrders(query: String): Flow<List<Order>> = orderDao.searchOrders(query)

    suspend fun createOrder(order: Order): Long {
        val orderId = orderDao.insertOrder(order)
        val fullOrder = order.copy(id = orderId)
        
        // Dispatch Telegram alert in background if configured
        try {
            telegramNotifier.sendTelegramAlert(
                order = fullOrder,
                botToken = preferences.telegramBotToken,
                chatId = preferences.telegramChatId
            )
        } catch (_: Exception) {
            // Ignore alert failures to avoid blocking order creation
        }
        
        return orderId
    }

    suspend fun updateOrder(order: Order) = orderDao.updateOrder(order)

    suspend fun updateOrderStatus(id: Long, status: String) = orderDao.updateOrderStatus(id, status)

    suspend fun deleteOrder(order: Order) = orderDao.deleteOrder(order)

    suspend fun deleteOrderById(id: Long) = orderDao.deleteOrderById(id)

    fun getPreferences(): StudioPreferences = preferences

    suspend fun sendTelegramAlertDirectly(order: Order): Result<String> {
        return telegramNotifier.sendTelegramAlert(
            order = order,
            botToken = preferences.telegramBotToken,
            chatId = preferences.telegramChatId
        )
    }

    fun formatOrderShareText(order: Order): String = telegramNotifier.formatOrderMessage(order)
}
