package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.Bookmark
import com.example.data.model.BrowserTab
import com.example.data.model.SearchHistory
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class BrowserRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Devam etmek için Google hesabınızla giriş yapmalısınız.")
    }

    // --- BROWSER TABS ---

    fun observeTabs(userId: String = auth.currentUser?.uid.orEmpty()): Flow<List<BrowserTab>> = flow {
        val path = "browser_tabs"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        BrowserTab::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareByDescending<BrowserTab> { it.isPinned }
                            .thenBy { (it.createdAt ?: Timestamp(0, 0)).seconds }
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createTab(
        title: String = "Yeni Sekme",
        url: String = "bratcher://index.html",
        lastQuery: String = "",
        isPinned: Boolean = false
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val path = "browser_tabs"
        val payload = mapOf(
            "userId" to uid,
            "title" to title.take(200).ifBlank { "Yeni Sekme" },
            "url" to url.take(2000).ifBlank { "bratcher://index.html" },
            "lastQuery" to lastQuery.take(500),
            "isPinned" to isPinned,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            val docRef = db.collection(path).add(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            throw e
        }
    }

    suspend fun updateTab(
        tabId: String,
        title: String,
        url: String,
        lastQuery: String,
        isPinned: Boolean
    ): Result<Unit> = runCatching {
        requireUserId()
        require(tabId.isNotBlank()) { "Tab ID cannot be blank" }
        val docRef = db.collection("browser_tabs").document(tabId)
        val updates = mapOf(
            "title" to title.take(200).ifBlank { "Yeni Sekme" },
            "url" to url.take(2000).ifBlank { "bratcher://index.html" },
            "lastQuery" to lastQuery.take(500),
            "isPinned" to isPinned,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            docRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteTab(tabId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("browser_tabs").document(tabId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- BOOKMARKS & SECURE VAULT ---

    fun observeBookmarks(userId: String = auth.currentUser?.uid.orEmpty()): Flow<List<Bookmark>> = flow {
        val path = "bookmarks"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Bookmark::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { (it.updatedAt ?: it.createdAt ?: Timestamp(0, 0)).seconds }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun getBookmarkById(bookmarkId: String): Result<Bookmark?> = runCatching {
        val docRef = db.collection("bookmarks").document(bookmarkId)
        try {
            val snapshot = docRef.get().await()
            snapshot.toObject(Bookmark::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun addBookmark(
        title: String,
        url: String,
        category: String = "Genel",
        note: String = ""
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val path = "bookmarks"
        val payload = mapOf(
            "userId" to uid,
            "title" to title.take(200).ifBlank { "Kayıtlı Sayfa" },
            "url" to url.take(2000).ifBlank { "bratcher://index.html" },
            "category" to category.take(60).ifBlank { "Genel" },
            "note" to note.take(4000),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            val docRef = db.collection(path).add(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            throw e
        }
    }

    suspend fun deleteBookmark(bookmarkId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("bookmarks").document(bookmarkId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    // --- SEARCH & RESEARCH HISTORY ---

    fun observeHistory(userId: String = auth.currentUser?.uid.orEmpty()): Flow<List<SearchHistory>> = flow {
        val path = "search_history"
        emitAll(
            db.collection(path)
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        SearchHistory::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { (it.updatedAt ?: it.createdAt ?: Timestamp(0, 0)).seconds }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun recordSearch(
        query: String,
        url: String,
        geminiResponse: String = ""
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val path = "search_history"
        val payload = mapOf(
            "userId" to uid,
            "query" to query.take(500).ifBlank { url.take(500) },
            "url" to url.take(2000).ifBlank { "bratcher://index.html" },
            "geminiResponse" to geminiResponse.take(8000),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            val docRef = db.collection(path).add(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            throw e
        }
    }

    suspend fun updateHistoryGeminiResponse(
        historyId: String,
        geminiResponse: String
    ): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("search_history").document(historyId)
        try {
            docRef.update(
                mapOf(
                    "geminiResponse" to geminiResponse.take(8000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteHistoryItem(historyId: String): Result<Unit> = runCatching {
        requireUserId()
        val docRef = db.collection("search_history").document(historyId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun clearAllUserData(): Result<Unit> = runCatching {
        val uid = requireUserId()
        for (collectionName in listOf("browser_tabs", "bookmarks", "search_history")) {
            try {
                val snapshot = db.collection(collectionName)
                    .whereEqualTo("userId", uid)
                    .get()
                    .await()
                for (doc in snapshot.documents) {
                    doc.reference.delete().await()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, collectionName)
                throw e
            }
        }
    }
}
