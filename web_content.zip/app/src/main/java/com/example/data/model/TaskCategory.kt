package com.example.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
data class TaskCategory(
    @DocumentId val id: String = "",
    val name: String = "",
    val iconType: String = "star",
    val order: Long = 1L,
    val isEnabled: Boolean = true
)
