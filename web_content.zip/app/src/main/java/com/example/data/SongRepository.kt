package com.example.data

import android.content.Context
import com.example.model.EqualizerDefaults
import com.example.model.EqualizerPreset
import com.example.model.Song
import com.example.model.SongSortOption
import com.example.model.SyncDeviceProfile
import com.example.model.SyncStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class SongRepository(private val context: Context) {

    private val initialSongs = listOf(
        Song(
            id = "s-1",
            title = "Midnight Cyber Skyline",
            artist = "Neon Mirage",
            album = "Chasing Tachyon",
            genre = "Synthwave",
            year = 2024,
            durationSec = 224,
            customTags = listOf("NightDrive", "Cyberpunk", "Audiophile"),
            isFavorite = true,
            bpm = 118,
            primaryColorHex = 0xFF00F0FF,
            secondaryColorHex = 0xFFA855F7,
            codec = "FLAC",
            bitDepth = 24,
            sampleRateHz = 96000,
            bitrateKbps = 2814,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = 101, count = 80)
        ),
        Song(
            id = "s-2",
            title = "Quantum Echoes",
            artist = "Aether Void",
            album = "Parallel Dimensions",
            genre = "Electronic",
            year = 2025,
            durationSec = 198,
            customTags = listOf("Workout", "BassHeavy", "DSD"),
            isFavorite = false,
            bpm = 132,
            primaryColorHex = 0xFFEC4899,
            secondaryColorHex = 0xFF3B82F6,
            codec = "DSD",
            bitDepth = 32,
            sampleRateHz = 192000,
            bitrateKbps = 5644,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = 202, count = 80)
        ),
        Song(
            id = "s-3",
            title = "Rainy Café Reverie",
            artist = "Luna & The Keys",
            album = "Velvet Afternoons",
            genre = "Lo-Fi",
            year = 2023,
            durationSec = 175,
            customTags = listOf("Chill", "Study", "Warmth"),
            isFavorite = true,
            bpm = 84,
            primaryColorHex = 0xFFF59E0B,
            secondaryColorHex = 0xFF10B981,
            codec = "FLAC",
            bitDepth = 24,
            sampleRateHz = 48000,
            bitrateKbps = 1536,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = 303, count = 80)
        ),
        Song(
            id = "s-4",
            title = "Supernova Solstice",
            artist = "Solaris Collective",
            album = "Stellar Winds",
            genre = "Ambient",
            year = 2022,
            durationSec = 312,
            customTags = listOf("Sleep", "Atmospheric", "Space"),
            isFavorite = false,
            bpm = 72,
            primaryColorHex = 0xFF8B5CF6,
            secondaryColorHex = 0xFF00D2FF,
            codec = "ALAC",
            bitDepth = 24,
            sampleRateHz = 96000,
            bitrateKbps = 2450,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = 404, count = 80)
        ),
        Song(
            id = "s-5",
            title = "Thunderbird Highway",
            artist = "Crimson Overdrive",
            album = "Desert V8",
            genre = "Rock",
            year = 2021,
            durationSec = 246,
            customTags = listOf("Workout", "RoadTrip", "Guitars"),
            isFavorite = false,
            bpm = 140,
            primaryColorHex = 0xFFFF5E36,
            secondaryColorHex = 0xFFFF0844,
            codec = "FLAC",
            bitDepth = 24,
            sampleRateHz = 96000,
            bitrateKbps = 2950,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = 505, count = 80)
        ),
        Song(
            id = "s-6",
            title = "Blue Note Serenade",
            artist = "Miles Dexter Quintet",
            album = "Harlem Midnight",
            genre = "Jazz",
            year = 2019,
            durationSec = 280,
            customTags = listOf("Vintage", "DirectMaster", "Brass"),
            isFavorite = true,
            bpm = 96,
            primaryColorHex = 0xFFFFD700,
            secondaryColorHex = 0xFFFF8C00,
            codec = "WAV",
            bitDepth = 24,
            sampleRateHz = 192000,
            bitrateKbps = 4608,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = 606, count = 80)
        ),
        Song(
            id = "s-7",
            title = "Nocturne in D-Minor",
            artist = "Aria Rostova",
            album = "Aurora Sonatas",
            genre = "Classical",
            year = 2020,
            durationSec = 265,
            customTags = listOf("Focus", "ConcertHall", "Acoustic"),
            isFavorite = false,
            bpm = 68,
            primaryColorHex = 0xFF56CCF2,
            secondaryColorHex = 0xFF2F80ED,
            codec = "FLAC",
            bitDepth = 24,
            sampleRateHz = 96000,
            bitrateKbps = 2700,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = 707, count = 80)
        ),
        Song(
            id = "s-8",
            title = "Sub-Zero Drift",
            artist = "Ghost Runner",
            album = "Hyperdrift 2088",
            genre = "Synthwave",
            year = 2026,
            durationSec = 210,
            customTags = listOf("PowerampMaster", "Cyberpunk", "Bass"),
            isFavorite = true,
            bpm = 126,
            primaryColorHex = 0xFF00FF66,
            secondaryColorHex = 0xFF00D2FF,
            codec = "FLAC",
            bitDepth = 24,
            sampleRateHz = 96000,
            bitrateKbps = 3120,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = 808, count = 80)
        )
    )

    private val _songs = MutableStateFlow<List<Song>>(initialSongs)
    val songs = _songs.asStateFlow()

    private val _activeSong = MutableStateFlow<Song?>(initialSongs.first())
    val activeSong = _activeSong.asStateFlow()

    // Equalizer Presets
    private val _equalizerPresets = MutableStateFlow<List<EqualizerPreset>>(EqualizerDefaults.BUILT_IN_PRESETS)
    val equalizerPresets = _equalizerPresets.asStateFlow()

    // Default to Poweramp Bass & Treble preset
    private val _currentEqualizer = MutableStateFlow<EqualizerPreset>(EqualizerDefaults.BUILT_IN_PRESETS[1])
    val currentEqualizer = _currentEqualizer.asStateFlow()

    // Visualizer
    private val _selectedVisualizerId = MutableStateFlow(1)
    val selectedVisualizerId = _selectedVisualizerId.asStateFlow()

    // Cross-Platform Sync
    private val _syncProfile = MutableStateFlow(
        SyncDeviceProfile(
            deviceId = UUID.randomUUID().toString().take(8).uppercase(),
            pairingCode = "POWER-8492-SYNC",
            deviceName = "Poweramp Hi-Res Edition"
        )
    )
    val syncProfile = _syncProfile.asStateFlow()

    val allDistinctTags: List<String>
        get() = _songs.value.flatMap { it.customTags }.distinct().sorted()

    fun selectSong(song: Song) {
        _activeSong.value = song
        _songs.value = _songs.value.map {
            if (it.id == song.id) it.copy(playCount = it.playCount + 1) else it
        }
    }

    fun toggleFavorite(songId: String) {
        _songs.value = _songs.value.map {
            if (it.id == songId) it.copy(isFavorite = !it.isFavorite) else it
        }
        if (_activeSong.value?.id == songId) {
            _activeSong.value = _songs.value.find { it.id == songId }
        }
    }

    fun setSongTags(songId: String, newTags: List<String>) {
        _songs.value = _songs.value.map {
            if (it.id == songId) it.copy(customTags = newTags) else it
        }
        if (_activeSong.value?.id == songId) {
            _activeSong.value = _songs.value.find { it.id == songId }
        }
    }

    fun addSongTag(songId: String, tag: String) {
        val trimmed = tag.trim().replace("#", "")
        if (trimmed.isEmpty()) return
        _songs.value = _songs.value.map {
            if (it.id == songId && !it.customTags.contains(trimmed)) {
                it.copy(customTags = it.customTags + trimmed)
            } else it
        }
    }

    fun removeSongTag(songId: String, tag: String) {
        _songs.value = _songs.value.map {
            if (it.id == songId) {
                it.copy(customTags = it.customTags.filter { t -> t != tag })
            } else it
        }
    }

    fun addImportedSong(title: String, artist: String, uri: String, durationSec: Int) {
        val newSong = Song(
            id = UUID.randomUUID().toString(),
            title = title,
            artist = artist.ifEmpty { "Local Audio" },
            album = "Imported Hi-Res Audio",
            genre = "Hi-Res Master",
            year = 2026,
            durationSec = if (durationSec > 0) durationSec else 210,
            audioUri = uri,
            customTags = listOf("Imported", "Lossless"),
            isFavorite = false,
            primaryColorHex = 0xFF00F0FF,
            secondaryColorHex = 0xFFA855F7,
            codec = "FLAC",
            bitDepth = 24,
            sampleRateHz = 96000,
            bitrateKbps = 2400,
            isHiRes = true,
            waveformPoints = Song.generateWaveformPeaks(seed = System.currentTimeMillis().toInt() and 0xFFFF, count = 80)
        )
        _songs.value = listOf(newSong) + _songs.value
        _activeSong.value = newSong
    }

    fun setEqualizerPreset(preset: EqualizerPreset) {
        _currentEqualizer.value = preset
    }

    fun updateEqualizerPreset(preset: EqualizerPreset) {
        _currentEqualizer.value = preset
    }

    fun update10Bands(
        b31: Float, b62: Float, b125: Float, b250: Float, b500: Float,
        b1k: Float, b2k: Float, b4k: Float, b8k: Float, b16k: Float,
        preamp: Float? = null,
        bassTone: Float? = null,
        trebleTone: Float? = null,
        bassBoost: Float? = null,
        virt: Float? = null,
        stereoWidener: Float? = null,
        balance: Float? = null
    ) {
        val cur = _currentEqualizer.value
        _currentEqualizer.value = cur.copy(
            band31Hz = b31,
            band62Hz = b62,
            band125Hz = b125,
            band250Hz = b250,
            band500Hz = b500,
            band1kHz = b1k,
            band2kHz = b2k,
            band4kHz = b4k,
            band8kHz = b8k,
            band16kHz = b16k,
            preampDb = preamp ?: cur.preampDb,
            bassTone = bassTone ?: cur.bassTone,
            trebleTone = trebleTone ?: cur.trebleTone,
            bassBoost = bassBoost ?: cur.bassBoost,
            virtualizer3D = virt ?: cur.virtualizer3D,
            stereoWidener = stereoWidener ?: cur.stereoWidener,
            balance = balance ?: cur.balance,
            name = if (cur.isCustom) cur.name else "Custom (${cur.name})"
        )
    }

    fun updateToneKnobs(bass: Float, treble: Float) {
        val cur = _currentEqualizer.value
        _currentEqualizer.value = cur.copy(
            bassTone = bass,
            trebleTone = treble,
            name = if (cur.isCustom) cur.name else "Custom (${cur.name})"
        )
    }

    fun updatePreamp(preampDb: Float) {
        val cur = _currentEqualizer.value
        _currentEqualizer.value = cur.copy(
            preampDb = preampDb,
            name = if (cur.isCustom) cur.name else "Custom (${cur.name})"
        )
    }

    fun toggleLimiter() {
        val cur = _currentEqualizer.value
        _currentEqualizer.value = cur.copy(limiterEnabled = !cur.limiterEnabled)
    }

    fun toggleDvc() {
        val cur = _currentEqualizer.value
        _currentEqualizer.value = cur.copy(dvcEnabled = !cur.dvcEnabled)
    }

    fun saveCustomPreset(presetName: String) {
        val cur = _currentEqualizer.value
        val newCustom = cur.copy(
            id = UUID.randomUUID().toString(),
            name = presetName,
            isCustom = true
        )
        _equalizerPresets.value = _equalizerPresets.value + newCustom
        _currentEqualizer.value = newCustom
    }

    fun deleteCustomPreset(presetId: String) {
        _equalizerPresets.value = _equalizerPresets.value.filter { it.id != presetId }
        if (_currentEqualizer.value.id == presetId) {
            _currentEqualizer.value = EqualizerDefaults.BUILT_IN_PRESETS.first()
        }
    }

    fun selectVisualizer(id: Int) {
        _selectedVisualizerId.value = id.coerceIn(1, 150)
    }

    fun selectRandomVisualizer() {
        val randomId = (1..150).random()
        _selectedVisualizerId.value = randomId
    }

    fun getFilteredAndSortedSongs(
        searchQuery: String,
        selectedGenre: String?,
        selectedTag: String?,
        sortOption: SongSortOption
    ): List<Song> {
        val query = searchQuery.trim().lowercase()
        return _songs.value
            .filter { song ->
                val matchesQuery = query.isEmpty() ||
                        song.title.lowercase().contains(query) ||
                        song.artist.lowercase().contains(query) ||
                        song.album.lowercase().contains(query) ||
                        song.genre.lowercase().contains(query) ||
                        song.codec.lowercase().contains(query) ||
                        song.year.toString().contains(query) ||
                        song.customTags.any { it.lowercase().contains(query) }

                val matchesGenre = selectedGenre == null || song.genre.equals(selectedGenre, ignoreCase = true)
                val matchesTag = selectedTag == null || song.customTags.any { it.equals(selectedTag, ignoreCase = true) }

                matchesQuery && matchesGenre && matchesTag
            }
            .let { list ->
                when (sortOption) {
                    SongSortOption.TITLE_ASC -> list.sortedBy { it.title.lowercase() }
                    SongSortOption.TITLE_DESC -> list.sortedByDescending { it.title.lowercase() }
                    SongSortOption.ARTIST -> list.sortedBy { it.artist.lowercase() }
                    SongSortOption.ALBUM -> list.sortedBy { it.album.lowercase() }
                    SongSortOption.GENRE -> list.sortedBy { it.genre.lowercase() }
                    SongSortOption.YEAR_NEWEST -> list.sortedByDescending { it.year }
                    SongSortOption.YEAR_OLDEST -> list.sortedBy { it.year }
                    SongSortOption.CUSTOM_TAGS -> list.sortedByDescending { it.customTags.size }
                    SongSortOption.DURATION -> list.sortedByDescending { it.durationSec }
                    SongSortOption.MOST_PLAYED -> list.sortedByDescending { it.playCount }
                    SongSortOption.FAVORITES -> list.sortedByDescending { it.isFavorite }
                }
            }
    }

    fun exportSyncBundleJson(): String {
        val json = JSONObject()
        json.put("version", 2)
        json.put("exportedAt", System.currentTimeMillis())
        json.put("pairingCode", _syncProfile.value.pairingCode)
        json.put("deviceName", _syncProfile.value.deviceName)
        json.put("activeVisualizerId", _selectedVisualizerId.value)
        json.put("activeEqualizerPreset", _currentEqualizer.value.name)

        val tagObj = JSONObject()
        _songs.value.forEach { song ->
            val tagsArr = JSONArray()
            song.customTags.forEach { tagsArr.put(it) }
            tagObj.put(song.id, tagsArr)
        }
        json.put("songTags", tagObj)

        val favsArr = JSONArray()
        _songs.value.filter { it.isFavorite }.forEach { favsArr.put(it.id) }
        json.put("favoriteIds", favsArr)

        val customPresetsArr = JSONArray()
        _equalizerPresets.value.filter { it.isCustom }.forEach { p ->
            val pObj = JSONObject()
            pObj.put("id", p.id)
            pObj.put("name", p.name)
            pObj.put("b31", p.band31Hz.toDouble())
            pObj.put("b62", p.band62Hz.toDouble())
            pObj.put("b125", p.band125Hz.toDouble())
            pObj.put("b250", p.band250Hz.toDouble())
            pObj.put("b500", p.band500Hz.toDouble())
            pObj.put("b1k", p.band1kHz.toDouble())
            pObj.put("b2k", p.band2kHz.toDouble())
            pObj.put("b4k", p.band4kHz.toDouble())
            pObj.put("b8k", p.band8kHz.toDouble())
            pObj.put("b16k", p.band16kHz.toDouble())
            pObj.put("preamp", p.preampDb.toDouble())
            pObj.put("bassTone", p.bassTone.toDouble())
            pObj.put("trebleTone", p.trebleTone.toDouble())
            customPresetsArr.put(pObj)
        }
        json.put("customPresets", customPresetsArr)

        return json.toString(2)
    }

    fun importSyncBundleJson(jsonString: String): Boolean {
        return try {
            val json = JSONObject(jsonString)
            if (json.has("activeVisualizerId")) {
                _selectedVisualizerId.value = json.getInt("activeVisualizerId").coerceIn(1, 150)
            }

            if (json.has("favoriteIds")) {
                val favArr = json.getJSONArray("favoriteIds")
                val favSet = mutableSetOf<String>()
                for (i in 0 until favArr.length()) favSet.add(favArr.getString(i))
                _songs.value = _songs.value.map { it.copy(isFavorite = favSet.contains(it.id)) }
            }

            if (json.has("songTags")) {
                val tagsObj = json.getJSONObject("songTags")
                _songs.value = _songs.value.map { song ->
                    if (tagsObj.has(song.id)) {
                        val arr = tagsObj.getJSONArray(song.id)
                        val tagsList = mutableListOf<String>()
                        for (i in 0 until arr.length()) tagsList.add(arr.getString(i))
                        song.copy(customTags = (song.customTags + tagsList).distinct())
                    } else song
                }
            }

            if (json.has("customPresets")) {
                val pArr = json.getJSONArray("customPresets")
                val importedPresets = mutableListOf<EqualizerPreset>()
                for (i in 0 until pArr.length()) {
                    val p = pArr.getJSONObject(i)
                    importedPresets.add(
                        EqualizerPreset(
                            id = p.optString("id", UUID.randomUUID().toString()),
                            name = p.getString("name"),
                            band31Hz = p.optDouble("b31", 0.0).toFloat(),
                            band62Hz = p.optDouble("b62", 0.0).toFloat(),
                            band125Hz = p.optDouble("b125", 0.0).toFloat(),
                            band250Hz = p.optDouble("b250", 0.0).toFloat(),
                            band500Hz = p.optDouble("b500", 0.0).toFloat(),
                            band1kHz = p.optDouble("b1k", 0.0).toFloat(),
                            band2kHz = p.optDouble("b2k", 0.0).toFloat(),
                            band4kHz = p.optDouble("b4k", 0.0).toFloat(),
                            band8kHz = p.optDouble("b8k", 0.0).toFloat(),
                            band16kHz = p.optDouble("b16k", 0.0).toFloat(),
                            preampDb = p.optDouble("preamp", 0.0).toFloat(),
                            bassTone = p.optDouble("bassTone", 0.0).toFloat(),
                            trebleTone = p.optDouble("trebleTone", 0.0).toFloat(),
                            isCustom = true
                        )
                    )
                }
                val existingIds = _equalizerPresets.value.map { it.id }.toSet()
                _equalizerPresets.value = _equalizerPresets.value + importedPresets.filter { it.id !in existingIds }
            }

            _syncProfile.value = _syncProfile.value.copy(
                status = SyncStatus.SYNCED,
                lastSyncTimestamp = System.currentTimeMillis(),
                statusMessage = "Library, tags, and Poweramp EQ successfully synced"
            )
            true
        } catch (e: Exception) {
            _syncProfile.value = _syncProfile.value.copy(
                status = SyncStatus.FAILED,
                statusMessage = "Invalid sync bundle format"
            )
            false
        }
    }

    fun triggerCloudSyncSimulation(onComplete: (Boolean) -> Unit) {
        _syncProfile.value = _syncProfile.value.copy(
            status = SyncStatus.SYNCING,
            statusMessage = "Connecting to high-res audio cloud cluster..."
        )
    }

    fun completeCloudSyncSimulation() {
        _syncProfile.value = _syncProfile.value.copy(
            status = SyncStatus.SYNCED,
            lastSyncTimestamp = System.currentTimeMillis(),
            statusMessage = "Seamlessly synced with desktop & web clients"
        )
    }

    fun updateServerUrl(url: String) {
        _syncProfile.value = _syncProfile.value.copy(cloudServerUrl = url)
    }

    fun updatePairingCode(code: String) {
        _syncProfile.value = _syncProfile.value.copy(pairingCode = code.uppercase())
    }
}
