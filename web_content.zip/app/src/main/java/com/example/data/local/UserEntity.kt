package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val uid: String,
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String? = null,
    val coins: Long = 0L,
    val gems: Long = 0L,
    val dailyCoins: Long = 0L,
    val weeklyCoins: Long = 0L,
    val lastDailyDate: String = "",
    val lastWeeklyDate: String = "",
    val isBlocked: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)
