package com.example.data.model

data class IngredientDetail(
    val name: String,
    val portion: String,
    val calories: Int
)

data class FoodAnalysisResult(
    val dishName: String,
    val englishName: String,
    val calories: Int,
    val servingSize: String,
    val proteinGrams: Float,
    val carbsGrams: Float,
    val fatGrams: Float,
    val fiberGrams: Float,
    val healthScore: Int, // 1 to 100
    val burnOffMinsWalking: Int,
    val burnOffMinsRunning: Int,
    val burnOffMinsCycling: Int,
    val advice: String,
    val ingredients: List<IngredientDetail>,
    val isAiLive: Boolean = false,
    val aiNotice: String = "برای فعال‌سازی ارتباط زنده با Gemini API، سرویس Firebase را تایید نمایید. داده‌های فعلی با موتور تخمین هوشمند پردازش شده‌اند."
)

enum class MealType(val persianTitle: String, val englishTitle: String) {
    BREAKFAST("صبحانه", "Breakfast"),
    LUNCH("ناهار", "Lunch"),
    DINNER("شام", "Dinner"),
    SNACK("میان‌وعده", "Snack")
}

data class SampleFoodPreset(
    val id: String,
    val title: String,
    val subtitle: String,
    val calories: Int,
    val emoji: String,
    val defaultMealType: MealType
)
