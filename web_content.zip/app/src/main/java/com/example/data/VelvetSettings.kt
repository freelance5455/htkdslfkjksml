package com.example.data

enum class KeyboardLanguage(
    val id: String,
    val shortCode: String,
    val displayName: String,
    val nativeName: String,
    val bcp47Tag: String
) {
    EN("en", "EN", "English (US)", "English", "en-US"),
    ES("es", "ES", "Spanish", "Español", "es-ES"),
    FR("fr", "FR", "French", "Français", "fr-FR"),
    DE("de", "DE", "German", "Deutsch", "de-DE"),
    PT("pt", "PT", "Portuguese", "Português", "pt-BR"),
    IT("it", "IT", "Italian", "Italiano", "it-IT"),
    AR("ar", "AR", "Arabic", "العربية", "ar-SA");

    companion object {
        fun fromId(id: String?): KeyboardLanguage =
            entries.firstOrNull { it.id == id } ?: EN
    }
}

enum class KeycapStyle(val id: String, val label: String) {
    ROUNDED("rounded", "Rounded"),
    PILL("pill", "Full Pill"),
    BORDERLESS("borderless", "Minimal Flat"),
    FROSTED_GLASS("frosted_glass", "Frosted Glass"),
    ELEVATED_3D("elevated_3d", "Tactile 3D");

    companion object {
        fun fromId(id: String?): KeycapStyle =
            entries.firstOrNull { it.id == id } ?: ROUNDED
    }
}

enum class DarkModeOption(val id: String, val label: String) {
    SYSTEM("system", "Auto"),
    LIGHT("light", "Daylight"),
    LATE_NIGHT_DARK("late_night_dark", "Late-Night");

    companion object {
        fun fromId(id: String?): DarkModeOption =
            entries.firstOrNull { it.id == id } ?: SYSTEM
    }
}

enum class KeyboardFontId(val id: String, val label: String, val sample: String) {
    PLUS_JAKARTA("plus_jakarta", "Jakarta Sans", "Minimalist"),
    SPACE_GROTESK("space_grotesk", "Space Grotesk", "Modern Geo"),
    PLAYFAIR("playfair", "Playfair Serif", "Editorial"),
    JETBRAINS_MONO("jetbrains_mono", "JetBrains Mono", "Code Mono"),
    NUNITO("nunito", "Nunito Soft", "Rounded"),
    PACIFICO("pacifico", "Pacifico Script", "Handwritten");

    companion object {
        fun fromId(id: String?): KeyboardFontId =
            entries.firstOrNull { it.id == id } ?: PLUS_JAKARTA
    }
}

enum class UnicodeOutputFont(val id: String, val label: String, val preview: String) {
    STANDARD("standard", "Standard", "Hello"),
    SERIF_BOLD("serif_bold", "Serif Bold", "𝐇𝐞𝐥𝐥𝐨"),
    SCRIPT("script", "Cursive", "𝓗𝓮𝓵𝓵𝓸"),
    MONOSPACE("monospace", "Typewriter", "𝙷𝚎𝚕𝚕𝚘"),
    SANS_BOLD("sans_bold", "Bold Sans", "𝗛𝗲𝗹𝗹𝗼");

    companion object {
        fun fromId(id: String?): UnicodeOutputFont =
            entries.firstOrNull { it.id == id } ?: STANDARD
    }
}

enum class HapticProfile(val id: String, val label: String, val description: String) {
    OFF("off", "Off", "Silent typing without vibration"),
    SUBTLE("subtle", "Subtle Tap", "Whisper-light micro pulse"),
    IOS_CRISP("ios_crisp", "iOS Taptic", "Crisp Taptic Engine keystroke pulse"),
    MECHANICAL("mechanical", "Mechanical", "Deep pronounced tactile thock");

    companion object {
        fun fromId(id: String?): HapticProfile =
            entries.firstOrNull { it.id == id } ?: IOS_CRISP
    }
}

data class CustomThemePreset(
    val id: String,
    val name: String,
    val tagline: String = "Custom community theme",
    val isBuiltIn: Boolean = false,
    val isDarkBase: Boolean = true,
    val bgColorArgb: Long = 0xFF0E1412,
    val keyColorArgb: Long = 0xFF1A2521,
    val specialKeyColorArgb: Long = 0xFF131C19,
    val textColorArgb: Long = 0xFFECFDF5,
    val accentColorArgb: Long = 0xFF34D399,
    val keycapStyle: KeycapStyle = KeycapStyle.ROUNDED,
    val cornerRadiusDp: Float = 10f,
    val keyOpacity: Float = 0.92f,
    val backgroundImagePath: String? = null,
    val backgroundVideoPath: String? = null,
    val aliveLeafEffect: Boolean = false
)

data class ClipboardEntry(
    val id: String,
    val text: String,
    val timestampMs: Long,
    val isPinned: Boolean = false
)

data class CustomEmojiItem(
    val symbol: String,
    val label: String,
    val isPreinstalledIos: Boolean = false
)

data class VelvetSettings(
    val activeThemeId: String = "alive_leaf",
    val customThemes: List<CustomThemePreset> = emptyList(),
    val darkModeOption: DarkModeOption = DarkModeOption.SYSTEM,
    val fontId: KeyboardFontId = KeyboardFontId.PLUS_JAKARTA,
    val unicodeOutputFont: UnicodeOutputFont = UnicodeOutputFont.STANDARD,
    val hapticProfile: HapticProfile = HapticProfile.IOS_CRISP,
    val keySoundEnabled: Boolean = false,
    val enabledLanguages: List<KeyboardLanguage> = listOf(KeyboardLanguage.EN, KeyboardLanguage.ES),
    val activeLanguage: KeyboardLanguage = KeyboardLanguage.EN,
    val swipeTypingEnabled: Boolean = true,
    val predictionsEnabled: Boolean = true,
    val adaptToSlangEnabled: Boolean = true,
    val aliveMotionEnabled: Boolean = true,
    val aiRemoveStartersEnabled: Boolean = true,
    val aiAutoPunctuationEnabled: Boolean = true,
    val aiSmartPredictEnabled: Boolean = true,
    val pureAiVoiceEnabled: Boolean = false,
    val keyPopupEnabled: Boolean = true,
    val autoCapitalizeEnabled: Boolean = true,
    val doubleSpacePeriodEnabled: Boolean = true,
    val clipboardHistoryEnabled: Boolean = true,
    val keyHeightScale: Float = 1.0f,
    val clipboardHistory: List<ClipboardEntry> = emptyList(),
    val learnedWords: Map<String, Int> = emptyMap(),
    val customEmojis: List<CustomEmojiItem> = DefaultIosEmojis,
    val recentEmojis: List<String> = listOf("🥹", "🫶", "✨", "🔥", "😂", "❤️", "🫡", "🫠")
)

val DefaultIosEmojis = listOf(
    CustomEmojiItem("🥹", "Holding back tears", isPreinstalledIos = true),
    CustomEmojiItem("🫶", "Heart hands", isPreinstalledIos = true),
    CustomEmojiItem("🫠", "Melting face", isPreinstalledIos = true),
    CustomEmojiItem("🫡", "Saluting face", isPreinstalledIos = true),
    CustomEmojiItem("🫣", "Peeking eye", isPreinstalledIos = true),
    CustomEmojiItem("🫢", "Hand over mouth", isPreinstalledIos = true),
    CustomEmojiItem("🫨", "Shaking face", isPreinstalledIos = true),
    CustomEmojiItem("😮‍💨", "Exhaling sigh", isPreinstalledIos = true),
    CustomEmojiItem("🪩", "Mirror ball", isPreinstalledIos = true),
    CustomEmojiItem("🫧", "Bubbles", isPreinstalledIos = true),
    CustomEmojiItem("🩷", "Pink heart", isPreinstalledIos = true),
    CustomEmojiItem("🩵", "Light blue heart", isPreinstalledIos = true),
    CustomEmojiItem("🩶", "Grey heart", isPreinstalledIos = true),
    CustomEmojiItem("🪽", "Wing", isPreinstalledIos = true),
    CustomEmojiItem("🐦‍🔥", "Phoenix", isPreinstalledIos = true),
    CustomEmojiItem("🪻", "Hyacinth", isPreinstalledIos = true),
    CustomEmojiItem("🌿", "Living leaf", isPreinstalledIos = true),
    CustomEmojiItem("✨", "Sparkles", isPreinstalledIos = true)
)
