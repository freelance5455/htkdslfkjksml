package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val preview: String,
    val updatedAt: Long
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: String,
    val sender: String, // "user" or "suesa"
    val text: String,
    val attachmentsSummaryJson: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface SuesaDao {
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC LIMIT 50")
    fun getAllConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    suspend fun getMessagesSnapshot(conversationId: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConversation(conversation: ConversationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("DELETE FROM conversations WHERE id = :conversationId")
    suspend fun deleteConversation(conversationId: String)

    @Query("DELETE FROM messages WHERE conversationId = :conversationId")
    suspend fun deleteMessagesForConversation(conversationId: String)
}

@Database(
    entities = [ConversationEntity::class, MessageEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SuesaDatabase : RoomDatabase() {
    abstract fun suesaDao(): SuesaDao

    companion object {
        @Volatile
        private var INSTANCE: SuesaDatabase? = null

        fun getInstance(context: Context): SuesaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SuesaDatabase::class.java,
                    "suesa_ai_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class SuesaRepository(private val dao: SuesaDao) {
    val allConversations: Flow<List<ConversationEntity>> = dao.getAllConversations()

    fun observeMessages(conversationId: String): Flow<List<MessageEntity>> =
        dao.getMessagesForConversation(conversationId)

    suspend fun getMessagesSnapshot(conversationId: String): List<MessageEntity> =
        dao.getMessagesSnapshot(conversationId)

    suspend fun saveMessageAndUpdateConversation(
        conversationId: String,
        sender: String,
        text: String,
        attachmentsSummaryJson: String = "",
        existingTitle: String? = null
    ) {
        val now = System.currentTimeMillis()
        dao.insertMessage(
            MessageEntity(
                conversationId = conversationId,
                sender = sender,
                text = text,
                attachmentsSummaryJson = attachmentsSummaryJson,
                timestamp = now
            )
        )
        val snapshot = dao.getMessagesSnapshot(conversationId)
        val firstUserText = snapshot.firstOrNull { it.sender == "user" }?.text
        val computedTitle = (existingTitle?.takeIf { it != "Yeni sohbet" && it.isNotBlank() }
            ?: firstUserText?.replace(Regex("\\s+"), " ")?.trim()?.take(42))
            ?.ifBlank { "Yeni sohbet" } ?: "Yeni sohbet"
        val preview = text.replace(Regex("\\s+"), " ").trim().take(180)
        dao.upsertConversation(
            ConversationEntity(
                id = conversationId,
                title = computedTitle,
                preview = preview,
                updatedAt = now
            )
        )
    }

    suspend fun ensureConversation(conversationId: String) {
        val existing = dao.getMessagesSnapshot(conversationId)
        if (existing.isEmpty()) {
            dao.upsertConversation(
                ConversationEntity(
                    id = conversationId,
                    title = "Yeni sohbet",
                    preview = "Henüz mesaj yok.",
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun deleteConversation(conversationId: String) {
        dao.deleteMessagesForConversation(conversationId)
        dao.deleteConversation(conversationId)
    }
}
