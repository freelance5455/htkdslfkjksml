package com.example.data

import android.content.Context
import com.example.R
import com.example.model.CartItem
import com.example.model.DefaultCatalog
import com.example.model.Order
import com.example.model.OrderItem
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.model.ShopSettings
import com.example.model.UserProfile
import com.example.model.WishlistItem
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class NovaBazarRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun userDoc(userId: String) = db.collection("users").document(userId)

    fun observeProducts(userId: String): Flow<List<Product>> = flow {
        val path = "users/$userId/products"
        emitAll(
            userDoc(userId).collection("products")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Product::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeOrders(userId: String): Flow<List<Order>> = flow {
        val path = "users/$userId/orders"
        emitAll(
            userDoc(userId).collection("orders")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        Order::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeCart(userId: String): Flow<List<CartItem>> = flow {
        val path = "users/$userId/cart"
        emitAll(
            userDoc(userId).collection("cart")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        CartItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeWishlist(userId: String): Flow<List<WishlistItem>> = flow {
        val path = "users/$userId/wishlist"
        emitAll(
            userDoc(userId).collection("wishlist")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        WishlistItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.LIST, path, userId)
                    throw error
                }
        )
    }

    fun observeShopSettings(userId: String): Flow<ShopSettings> = flow {
        val path = "users/$userId/settings/shop"
        emitAll(
            userDoc(userId).collection("settings").document("shop")
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            ShopSettings::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        ) ?: ShopSettings()
                    } else {
                        ShopSettings()
                    }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    fun observeUserProfile(userId: String): Flow<UserProfile> = flow {
        val path = "users/$userId/profile/info"
        emitAll(
            userDoc(userId).collection("profile").document("info")
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            UserProfile::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        ) ?: UserProfile()
                    } else {
                        UserProfile()
                    }
                }
                .catch { error ->
                    unwrapAndLogFlowError(error, OperationType.GET, path, userId)
                    throw error
                }
        )
    }

    private fun unwrapAndLogFlowError(
        error: Throwable,
        operationType: OperationType,
        path: String,
        expectedUid: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
    }

    suspend fun ensureInitialSeed(userId: String): Result<Unit> {
        val settingsPath = "users/$userId/settings/shop"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val settingsRef = userDoc(uid).collection("settings").document("shop")
            val settingsSnap = settingsRef.get().await()
            val alreadySeeded = settingsSnap.exists() && (settingsSnap.getBoolean("seeded") == true)
            if (alreadySeeded) {
                return Result.success(Unit)
            }

            val batch = db.batch()
            if (!settingsSnap.exists()) {
                val defaultSettings = mapOf(
                    "shopName" to "NOVA BAZAR",
                    "phone" to "01764458050",
                    "facebookUrl" to "https://www.facebook.com/share/1EFrX218aV/",
                    "adminPin" to "6708",
                    "dhakaDeliveryFee" to 60L,
                    "outsideDeliveryFee" to 120L,
                    "seeded" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                batch.set(settingsRef, defaultSettings)
            } else {
                batch.update(
                    settingsRef,
                    mapOf(
                        "seeded" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            val existingProducts = userDoc(uid).collection("products").limit(1).get().await()
            if (existingProducts.isEmpty) {
                DefaultCatalog.starterProducts.forEach { (docId, p) ->
                    val ref = userDoc(uid).collection("products").document(docId)
                    batch.set(
                        ref,
                        mapOf(
                            "name" to p.name,
                            "category" to p.category,
                            "price" to p.price,
                            "oldPrice" to p.oldPrice,
                            "emoji" to p.emoji,
                            "description" to p.description,
                            "featured" to p.featured,
                            "rating" to p.rating,
                            "soldCount" to p.soldCount,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, settingsPath)
            Result.failure(e)
        }
    }

    suspend fun saveProduct(
        userId: String,
        existingProduct: Product?,
        name: String,
        category: String,
        price: Long,
        oldPrice: Long,
        emoji: String,
        description: String,
        imageBase64: String?,
        featured: Boolean
    ): Result<Unit> {
        val cleanName = name.trim().take(120)
        val cleanCat = category.trim().take(50)
        val cleanEmoji = emoji.trim().ifEmpty { "📦" }.take(16)
        val cleanDesc = description.trim().take(1000)
        val cleanImage = imageBase64?.takeIf { it.isNotBlank() }

        require(cleanName.isNotEmpty()) { "পণ্যের নাম লিখুন" }
        require(cleanCat.isNotEmpty()) { "ক্যাটাগরি লিখুন" }
        require(price in 1L..10_000_000L) { "দাম ১ থেকে ১,০০,০০,০০০ টাকার মধ্যে হতে হবে" }
        require(oldPrice in 0L..10_000_000L) { "আগের দাম সঠিক নয়" }
        if (cleanImage != null) {
            require(cleanImage.length <= 160_000) { "ছবিটি অনুমোদিত আকারের চেয়ে বড়, অনুগ্রহ করে ছোট ছবি দিন" }
        }

        val isUpdate = existingProduct != null && existingProduct.id.isNotBlank()
        val docId = if (isUpdate) existingProduct.id else "prod_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "users/$userId/products/$docId"

        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val docRef = userDoc(uid).collection("products").document(docId)

            if (isUpdate) {
                val updates = mutableMapOf<String, Any>(
                    "name" to cleanName,
                    "category" to cleanCat,
                    "price" to price,
                    "oldPrice" to oldPrice,
                    "emoji" to cleanEmoji,
                    "description" to cleanDesc,
                    "featured" to featured,
                    "rating" to existingProduct.rating,
                    "soldCount" to existingProduct.soldCount,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (cleanImage != null) {
                    updates["imageBase64"] = cleanImage
                } else if (existingProduct.imageBase64 != null) {
                    updates["imageBase64"] = FieldValue.delete()
                }
                docRef.update(updates).await()
            } else {
                val payload = buildMap<String, Any> {
                    put("name", cleanName)
                    put("category", cleanCat)
                    put("price", price)
                    put("oldPrice", oldPrice)
                    put("emoji", cleanEmoji)
                    put("description", cleanDesc)
                    if (cleanImage != null) put("imageBase64", cleanImage)
                    put("featured", featured)
                    put("rating", 4.8)
                    put("soldCount", 0L)
                    put("createdAt", FieldValue.serverTimestamp())
                    put("updatedAt", FieldValue.serverTimestamp())
                }
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, if (isUpdate) OperationType.UPDATE else OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteProduct(userId: String, productId: String): Result<Unit> {
        val path = "users/$userId/products/$productId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            require(productId.isNotBlank()) { "Invalid product ID" }
            userDoc(uid).collection("products").document(productId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun setCartQuantity(userId: String, productId: String, newQty: Long): Result<Unit> {
        val path = "users/$userId/cart/$productId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            require(productId.isNotBlank()) { "Invalid product ID" }
            val ref = userDoc(uid).collection("cart").document(productId)
            if (newQty <= 0L) {
                ref.delete().await()
            } else {
                val clamped = newQty.coerceIn(1L, 99L)
                val snap = ref.get().await()
                if (snap.exists()) {
                    ref.update(
                        mapOf(
                            "qty" to clamped,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                } else {
                    ref.set(
                        mapOf(
                            "productId" to productId,
                            "qty" to clamped,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                }
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleWishlist(userId: String, productId: String, currentlyWishlisted: Boolean): Result<Unit> {
        val path = "users/$userId/wishlist/$productId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            require(productId.isNotBlank()) { "Invalid product ID" }
            val ref = userDoc(uid).collection("wishlist").document(productId)
            if (currentlyWishlisted) {
                ref.delete().await()
            } else {
                ref.set(
                    mapOf(
                        "productId" to productId,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun placeOrder(
        userId: String,
        customerName: String,
        phone: String,
        address: String,
        note: String,
        deliveryZone: String,
        deliveryFee: Long,
        items: List<OrderItem>,
        clearCartAfterOrder: Boolean
    ): Result<String> {
        val cleanName = customerName.trim().take(80)
        val cleanPhone = phone.trim().take(20)
        val cleanAddress = address.trim().take(300)
        val cleanNote = note.trim().take(300)
        require(cleanName.isNotEmpty()) { "গ্রাহকের নাম লিখুন" }
        require(cleanPhone.matches(Regex("^01[0-9]{9}$"))) { "সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (01XXXXXXXXX)" }
        require(cleanAddress.length >= 3) { "সম্পূর্ণ ঠিকানা লিখুন" }
        require(items.isNotEmpty() && items.size <= 50) { "কার্টে অন্তত একটি পণ্য থাকতে হবে" }

        val orderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val orderNumber = "NB${System.currentTimeMillis().toString().takeLast(8)}"
        val path = "users/$userId/orders/$orderId"

        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }

            val subtotal = items.sumOf { it.price * it.qty }
            val total = subtotal + deliveryFee
            val serializedItems = items.map { item ->
                mapOf(
                    "productId" to item.productId,
                    "name" to item.name,
                    "price" to item.price,
                    "qty" to item.qty,
                    "emoji" to item.emoji
                )
            }

            val batch = db.batch()
            val orderRef = userDoc(uid).collection("orders").document(orderId)
            batch.set(
                orderRef,
                mapOf(
                    "orderNumber" to orderNumber,
                    "customerName" to cleanName,
                    "phone" to cleanPhone,
                    "address" to cleanAddress,
                    "note" to cleanNote,
                    "deliveryZone" to deliveryZone,
                    "deliveryFee" to deliveryFee,
                    "subtotal" to subtotal,
                    "total" to total,
                    "status" to OrderStatus.NEW.label,
                    "paymentMethod" to "Cash on Delivery",
                    "items" to serializedItems,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            if (clearCartAfterOrder) {
                val cartSnap = userDoc(uid).collection("cart").get().await()
                cartSnap.documents.forEach { doc ->
                    batch.delete(doc.reference)
                }
            }

            batch.commit().await()
            Result.success(orderNumber)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateOrderStatus(
        userId: String,
        orderId: String,
        newStatus: OrderStatus
    ): Result<Unit> {
        val path = "users/$userId/orders/$orderId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            require(orderId.isNotBlank()) { "Invalid order ID" }
            userDoc(uid).collection("orders").document(orderId)
                .update(
                    mapOf(
                        "status" to newStatus.label,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateShopSettings(
        userId: String,
        shopName: String,
        phone: String,
        facebookUrl: String,
        adminPin: String,
        dhakaFee: Long,
        outsideFee: Long
    ): Result<Unit> {
        val cleanName = shopName.trim().take(60)
        val cleanPhone = phone.trim().take(20)
        val cleanFb = facebookUrl.trim().take(250)
        val cleanPin = adminPin.trim().take(20)
        require(cleanName.isNotEmpty()) { "দোকানের নাম লিখুন" }
        require(cleanPhone.matches(Regex("^01[0-9]{9}$"))) { "সঠিক ১১ ডিজিটের ফোন নম্বর দিন (01XXXXXXXXX)" }
        require(cleanPin.length >= 4) { "অ্যাডমিন পিন কমপক্ষে ৪ অক্ষরের হতে হবে" }
        require(dhakaFee in 0L..5000L && outsideFee in 0L..5000L) { "ডেলিভারি চার্জ ০ থেকে ৫০০০ টাকার মধ্যে হতে হবে" }

        val path = "users/$userId/settings/shop"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val ref = userDoc(uid).collection("settings").document("shop")
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "shopName" to cleanName,
                        "phone" to cleanPhone,
                        "facebookUrl" to cleanFb,
                        "adminPin" to cleanPin,
                        "dhakaDeliveryFee" to dhakaFee,
                        "outsideDeliveryFee" to outsideFee,
                        "seeded" to true,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(
                    mapOf(
                        "shopName" to cleanName,
                        "phone" to cleanPhone,
                        "facebookUrl" to cleanFb,
                        "adminPin" to cleanPin,
                        "dhakaDeliveryFee" to dhakaFee,
                        "outsideDeliveryFee" to outsideFee,
                        "seeded" to true,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun saveUserProfile(
        userId: String,
        fullName: String,
        phone: String,
        defaultAddress: String,
        preferredZone: String
    ): Result<Unit> {
        val cleanName = fullName.trim().ifEmpty { "NOVA BAZAR User" }.take(80)
        val cleanPhone = phone.trim().take(20)
        val cleanAddr = defaultAddress.trim().take(300)
        val cleanZone = if (preferredZone == "ঢাকার বাইরে") "ঢাকার বাইরে" else "ঢাকা সিটি"
        val path = "users/$userId/profile/info"

        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch" }
            val ref = userDoc(uid).collection("profile").document("info")
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "fullName" to cleanName,
                        "phone" to cleanPhone,
                        "defaultAddress" to cleanAddr,
                        "preferredZone" to cleanZone,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(
                    mapOf(
                        "fullName" to cleanName,
                        "phone" to cleanPhone,
                        "defaultAddress" to cleanAddr,
                        "preferredZone" to cleanZone,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }
}
