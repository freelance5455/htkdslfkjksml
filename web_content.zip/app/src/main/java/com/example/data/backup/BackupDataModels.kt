package com.example.data.backup

import com.example.data.model.AppSettingsEntity
import com.example.data.model.ExamEntity
import com.example.data.model.NoteEntity
import com.example.data.model.ProfileEntity
import com.example.data.model.StudySessionEntity
import com.example.data.model.SubjectEntity
import org.json.JSONArray
import org.json.JSONObject

/**
 * Portable Backup Payload for Daily Study Manager (PRD Section 7).
 *
 * Security Guarantee:
 * Sensitive credentials (passwords, password salts, recovery codes, recovery salts)
 * are STRICTLY EXCLUDED from export to protect user security against offline dictionary attacks.
 */
data class BackupPayload(
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val appName: String = "Daily Study Manager",
    val profile: ProfileBackupItem? = null,
    val settings: SettingsBackupItem? = null,
    val subjects: List<SubjectBackupItem> = emptyList(),
    val sessions: List<SessionBackupItem> = emptyList(),
    val exams: List<ExamBackupItem> = emptyList(),
    val notes: List<NoteBackupItem> = emptyList()
) {
    fun toJsonString(indentSpaces: Int = 2): String {
        val root = JSONObject()
        root.put("version", version)
        root.put("exportedAt", exportedAt)
        root.put("appName", appName)

        profile?.let { p ->
            val pObj = JSONObject()
            pObj.putOpt("name", p.name)
            pObj.putOpt("photoUri", p.photoUri)
            pObj.putOpt("instituteName", p.instituteName)
            root.put("profile", pObj)
        }

        settings?.let { s ->
            val sObj = JSONObject()
            sObj.put("themeMode", s.themeMode)
            root.put("settings", sObj)
        }

        val subjArr = JSONArray()
        subjects.forEach { s ->
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("name", s.name)
            obj.put("colorHex", s.colorHex)
            obj.put("iconName", s.iconName)
            if (s.weeklyTargetHours != null) {
                obj.put("weeklyTargetHours", s.weeklyTargetHours.toDouble())
            }
            obj.put("isArchived", s.isArchived)
            obj.put("createdAt", s.createdAt)
            subjArr.put(obj)
        }
        root.put("subjects", subjArr)

        val sessArr = JSONArray()
        sessions.forEach { s ->
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("subjectId", s.subjectId)
            obj.put("date", s.date)
            obj.put("startTime", s.startTime)
            obj.put("durationMinutes", s.durationMinutes)
            obj.putOpt("topic", s.topic)
            obj.putOpt("remark", s.remark)
            obj.put("createdAt", s.createdAt)
            sessArr.put(obj)
        }
        root.put("sessions", sessArr)

        val examArr = JSONArray()
        exams.forEach { e ->
            val obj = JSONObject()
            obj.put("id", e.id)
            obj.put("name", e.name)
            obj.put("date", e.date)
            if (e.subjectId != null) {
                obj.put("subjectId", e.subjectId)
            }
            obj.put("remind30Days", e.remind30Days)
            obj.put("remind7Days", e.remind7Days)
            obj.put("remind1Day", e.remind1Day)
            obj.put("isArchived", e.isArchived)
            obj.put("createdAt", e.createdAt)
            examArr.put(obj)
        }
        root.put("exams", examArr)

        val noteArr = JSONArray()
        notes.forEach { n ->
            val obj = JSONObject()
            obj.put("id", n.id)
            obj.put("title", n.title)
            obj.put("contentJson", n.contentJson)
            obj.put("plainTextPreview", n.plainTextPreview)
            if (n.subjectId != null) {
                obj.put("subjectId", n.subjectId)
            }
            obj.put("isPinned", n.isPinned)
            obj.put("fontFamily", n.fontFamily)
            obj.put("fontSize", n.fontSize)
            obj.put("textAlign", n.textAlign)
            obj.put("createdAt", n.createdAt)
            obj.put("updatedAt", n.updatedAt)
            noteArr.put(obj)
        }
        root.put("notes", noteArr)

        return root.toString(indentSpaces)
    }

    companion object {
        fun fromJsonString(jsonStr: String): BackupPayload {
            val root = JSONObject(jsonStr)
            val version = root.optInt("version", 1)
            val exportedAt = root.optLong("exportedAt", System.currentTimeMillis())
            val appName = root.optString("appName", "Daily Study Manager")

            val profile = if (root.has("profile") && !root.isNull("profile")) {
                val pObj = root.getJSONObject("profile")
                ProfileBackupItem(
                    name = if (pObj.has("name") && !pObj.isNull("name")) pObj.getString("name") else null,
                    photoUri = if (pObj.has("photoUri") && !pObj.isNull("photoUri")) pObj.getString("photoUri") else null,
                    instituteName = if (pObj.has("instituteName") && !pObj.isNull("instituteName")) pObj.getString("instituteName") else null
                )
            } else null

            val settings = if (root.has("settings") && !root.isNull("settings")) {
                val sObj = root.getJSONObject("settings")
                SettingsBackupItem(
                    themeMode = sObj.optString("themeMode", AppSettingsEntity.THEME_NORMAL)
                )
            } else null

            val subjectsList = mutableListOf<SubjectBackupItem>()
            val subjArr = root.optJSONArray("subjects")
            if (subjArr != null) {
                for (i in 0 until subjArr.length()) {
                    val obj = subjArr.getJSONObject(i)
                    subjectsList.add(
                        SubjectBackupItem(
                            id = obj.optLong("id", 0L),
                            name = obj.getString("name"),
                            colorHex = obj.optString("colorHex", "#2563EB"),
                            iconName = obj.optString("iconName", "school"),
                            weeklyTargetHours = if (obj.has("weeklyTargetHours") && !obj.isNull("weeklyTargetHours")) {
                                obj.getDouble("weeklyTargetHours").toFloat()
                            } else null,
                            isArchived = obj.optBoolean("isArchived", false),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            val sessionsList = mutableListOf<SessionBackupItem>()
            val sessArr = root.optJSONArray("sessions")
            if (sessArr != null) {
                for (i in 0 until sessArr.length()) {
                    val obj = sessArr.getJSONObject(i)
                    sessionsList.add(
                        SessionBackupItem(
                            id = obj.optLong("id", 0L),
                            subjectId = obj.getLong("subjectId"),
                            date = obj.getString("date"),
                            startTime = obj.getString("startTime"),
                            durationMinutes = obj.getInt("durationMinutes"),
                            topic = if (obj.has("topic") && !obj.isNull("topic")) obj.getString("topic") else null,
                            remark = if (obj.has("remark") && !obj.isNull("remark")) obj.getString("remark") else null,
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            val examsList = mutableListOf<ExamBackupItem>()
            val examArr = root.optJSONArray("exams")
            if (examArr != null) {
                for (i in 0 until examArr.length()) {
                    val obj = examArr.getJSONObject(i)
                    examsList.add(
                        ExamBackupItem(
                            id = obj.optLong("id", 0L),
                            name = obj.getString("name"),
                            date = obj.getString("date"),
                            subjectId = if (obj.has("subjectId") && !obj.isNull("subjectId")) obj.getLong("subjectId") else null,
                            remind30Days = obj.optBoolean("remind30Days", false),
                            remind7Days = obj.optBoolean("remind7Days", true),
                            remind1Day = obj.optBoolean("remind1Day", true),
                            isArchived = obj.optBoolean("isArchived", false),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            val notesList = mutableListOf<NoteBackupItem>()
            val noteArr = root.optJSONArray("notes")
            if (noteArr != null) {
                for (i in 0 until noteArr.length()) {
                    val obj = noteArr.getJSONObject(i)
                    notesList.add(
                        NoteBackupItem(
                            id = obj.optLong("id", 0L),
                            title = obj.getString("title"),
                            contentJson = obj.getString("contentJson"),
                            plainTextPreview = obj.optString("plainTextPreview", ""),
                            subjectId = if (obj.has("subjectId") && !obj.isNull("subjectId")) obj.getLong("subjectId") else null,
                            isPinned = obj.optBoolean("isPinned", false),
                            fontFamily = obj.optString("fontFamily", "sans"),
                            fontSize = obj.optInt("fontSize", 16),
                            textAlign = obj.optString("textAlign", "left"),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            return BackupPayload(
                version = version,
                exportedAt = exportedAt,
                appName = appName,
                profile = profile,
                settings = settings,
                subjects = subjectsList,
                sessions = sessionsList,
                exams = examsList,
                notes = notesList
            )
        }
    }
}

data class ProfileBackupItem(
    val name: String?,
    val photoUri: String?,
    val instituteName: String?
) {
    fun toEntity(id: Int = 1): ProfileEntity {
        return ProfileEntity(
            id = id,
            name = name,
            photoUri = photoUri,
            instituteName = instituteName
        )
    }

    companion object {
        fun fromEntity(entity: ProfileEntity): ProfileBackupItem {
            return ProfileBackupItem(
                name = entity.name,
                photoUri = entity.photoUri,
                instituteName = entity.instituteName
            )
        }
    }
}

data class SettingsBackupItem(
    val themeMode: String
) {
    fun toEntity(id: Int = 1): AppSettingsEntity {
        return AppSettingsEntity(
            id = id,
            themeMode = themeMode
        )
    }

    companion object {
        fun fromEntity(entity: AppSettingsEntity): SettingsBackupItem {
            return SettingsBackupItem(
                themeMode = entity.themeMode
            )
        }
    }
}

data class SubjectBackupItem(
    val id: Long,
    val name: String,
    val colorHex: String,
    val iconName: String,
    val weeklyTargetHours: Float?,
    val isArchived: Boolean,
    val createdAt: Long
) {
    fun toEntity(): SubjectEntity {
        return SubjectEntity(
            id = id,
            name = name,
            colorHex = colorHex,
            iconName = iconName,
            weeklyTargetHours = weeklyTargetHours,
            isArchived = isArchived,
            createdAt = createdAt
        )
    }

    companion object {
        fun fromEntity(entity: SubjectEntity): SubjectBackupItem {
            return SubjectBackupItem(
                id = entity.id,
                name = entity.name,
                colorHex = entity.colorHex,
                iconName = entity.iconName,
                weeklyTargetHours = entity.weeklyTargetHours,
                isArchived = entity.isArchived,
                createdAt = entity.createdAt
            )
        }
    }
}

data class SessionBackupItem(
    val id: Long,
    val subjectId: Long,
    val date: String,
    val startTime: String,
    val durationMinutes: Int,
    val topic: String?,
    val remark: String?,
    val createdAt: Long
) {
    fun toEntity(): StudySessionEntity {
        return StudySessionEntity(
            id = id,
            subjectId = subjectId,
            date = date,
            startTime = startTime,
            durationMinutes = durationMinutes,
            topic = topic,
            remark = remark,
            createdAt = createdAt
        )
    }

    companion object {
        fun fromEntity(entity: StudySessionEntity): SessionBackupItem {
            return SessionBackupItem(
                id = entity.id,
                subjectId = entity.subjectId,
                date = entity.date,
                startTime = entity.startTime,
                durationMinutes = entity.durationMinutes,
                topic = entity.topic,
                remark = entity.remark,
                createdAt = entity.createdAt
            )
        }
    }
}

data class ExamBackupItem(
    val id: Long,
    val name: String,
    val date: String,
    val subjectId: Long?,
    val remind30Days: Boolean,
    val remind7Days: Boolean,
    val remind1Day: Boolean,
    val isArchived: Boolean,
    val createdAt: Long
) {
    fun toEntity(): ExamEntity {
        return ExamEntity(
            id = id,
            name = name,
            date = date,
            subjectId = subjectId,
            remind30Days = remind30Days,
            remind7Days = remind7Days,
            remind1Day = remind1Day,
            isArchived = isArchived,
            createdAt = createdAt
        )
    }

    companion object {
        fun fromEntity(entity: ExamEntity): ExamBackupItem {
            return ExamBackupItem(
                id = entity.id,
                name = entity.name,
                date = entity.date,
                subjectId = entity.subjectId,
                remind30Days = entity.remind30Days,
                remind7Days = entity.remind7Days,
                remind1Day = entity.remind1Day,
                isArchived = entity.isArchived,
                createdAt = entity.createdAt
            )
        }
    }
}

data class NoteBackupItem(
    val id: Long,
    val title: String,
    val contentJson: String,
    val plainTextPreview: String,
    val subjectId: Long?,
    val isPinned: Boolean,
    val fontFamily: String,
    val fontSize: Int,
    val textAlign: String,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toEntity(): NoteEntity {
        return NoteEntity(
            id = id,
            title = title,
            contentJson = contentJson,
            plainTextPreview = plainTextPreview,
            subjectId = subjectId,
            isPinned = isPinned,
            fontFamily = fontFamily,
            fontSize = fontSize,
            textAlign = textAlign,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    companion object {
        fun fromEntity(entity: NoteEntity): NoteBackupItem {
            return NoteBackupItem(
                id = entity.id,
                title = entity.title,
                contentJson = entity.contentJson,
                plainTextPreview = entity.plainTextPreview,
                subjectId = entity.subjectId,
                isPinned = entity.isPinned,
                fontFamily = entity.fontFamily,
                fontSize = entity.fontSize,
                textAlign = entity.textAlign,
                createdAt = entity.createdAt,
                updatedAt = entity.updatedAt
            )
        }
    }
}
