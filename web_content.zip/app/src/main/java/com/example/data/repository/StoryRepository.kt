package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ArkFeedIds
import com.example.data.model.ArkGroup
import com.example.data.model.ArkStory
import com.example.data.model.FollowEdge
import com.example.data.model.FriendEdge
import com.example.data.model.HighlightSlide
import com.example.data.model.MediaChunk
import com.example.data.model.StoryHighlight
import com.example.data.model.StoryReaction
import com.example.data.model.StoryViewer
import com.example.data.model.UserProfile
import com.example.util.ImageCompressionHelper
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.io.File
import java.util.Date

class StoryRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing stories.")

    fun observeActiveStories(userId: String): Flow<List<ArkStory>> = flow {
        val path = "stories"
        emitAll(
            db.collection("stories")
                .whereArrayContains("visibleToUids", userId)
                .limit(50)
                .snapshots()
                .map { snap ->
                    val now = Timestamp.now()
                    snap.toObjects(ArkStory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .filter { st ->
                            val exp = st.expiresAt
                            val notExpired = exp == null || exp.seconds > now.seconds
                            val notHidden = !st.hiddenFromUids.contains(userId) || st.authorId == userId
                            notExpired && notHidden
                        }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun createStory(
        author: UserProfile,
        mediaType: String,
        imageBase64: String,
        caption: String,
        visibility: String,
        friends: List<FriendEdge>,
        selectedGroups: List<ArkGroup>,
        followers: List<FollowEdge> = emptyList(),
        hiddenFromUids: List<String> = author.hiddenStoryFromUids,
        videoDurationMs: Long = 0L,
        videoChunksBase64: List<String> = emptyList()
    ): Result<String> = runCatching {
        val uid = requireUserId()
        require(uid == author.userId) { "Author mismatch." }
        require(!author.isRestricted) { "Your account is restricted from sharing stories." }
        if (visibility == "public") {
            require(author.ageBracket != "under_13") { "Public stories are disabled for under-13 accounts." }
            require(!author.isPrivateAccount) { "Switch off Private Account in Settings to post Public stories." }
        }
        require(imageBase64.isNotBlank()) { "Story visual is required." }

        val cleanVisibility = visibility.takeIf { it in setOf("public", "followers", "friends", "group") } ?: "friends"
        val cleanType = if (mediaType == "video") "video" else "image"
        val cleanHidden = hiddenFromUids.filter { it != uid }.distinct().take(100)

        val visibleUids = linkedSetOf(uid)
        when (cleanVisibility) {
            "group" -> selectedGroups.forEach { visibleUids.addAll(it.memberUids) }
            "friends" -> {
                friends.forEach { visibleUids.add(it.friendUid) }
                selectedGroups.forEach { visibleUids.addAll(it.memberUids) }
            }
            else -> {
                followers.forEach { visibleUids.add(it.peerUid) }
                friends.forEach { visibleUids.add(it.friendUid) }
                selectedGroups.forEach { visibleUids.addAll(it.memberUids) }
            }
        }
        cleanHidden.forEach { if (it != uid) visibleUids.remove(it) }

        val cleanChunks = videoChunksBase64.filter { it.isNotBlank() && it.length <= 700_000 }.take(16)
        val storyId = ArkFeedIds.newChronoDocId("st")
        val storyRef = db.collection("stories").document(storyId)
        val expiresAt = Timestamp(Date(System.currentTimeMillis() + 86_400_000L))
        val payload = mapOf(
            "authorId" to uid,
            "authorUsername" to author.username.take(30).ifBlank { "player" },
            "authorAvatar" to author.avatarPreset.take(40),
            "mediaType" to cleanType,
            "imageBase64" to imageBase64.take(90_000),
            "videoDurationMs" to videoDurationMs.coerceIn(0L, 45_000L),
            "videoChunkCount" to cleanChunks.size.toLong(),
            "caption" to caption.trim().take(140),
            "visibility" to cleanVisibility,
            "visibleToUids" to visibleUids.take(200),
            "hiddenFromUids" to cleanHidden,
            "viewerCount" to 0L,
            "reactionCounts" to emptyMap<String, Long>(),
            "createdAt" to FieldValue.serverTimestamp(),
            "expiresAt" to expiresAt
        )

        val firstChunks = cleanChunks.take(9)
        val restChunks = if (cleanChunks.size > 9) cleanChunks.drop(9) else emptyList()
        val batch = db.batch()
        batch.set(storyRef, payload)
        firstChunks.forEachIndexed { idx, chunk ->
            val chunkRef = storyRef.collection("media").document("chunk_$idx")
            batch.set(
                chunkRef,
                mapOf(
                    "index" to idx.toLong(),
                    "dataBase64" to chunk,
                    "authorId" to uid,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
        }
        try {
            batch.commit().await()
            if (restChunks.isNotEmpty()) {
                val batch2 = db.batch()
                restChunks.forEachIndexed { relIdx, chunk ->
                    val idx = relIdx + 9
                    val chunkRef = storyRef.collection("media").document("chunk_$idx")
                    batch2.set(
                        chunkRef,
                        mapOf(
                            "index" to idx.toLong(),
                            "dataBase64" to chunk,
                            "authorId" to uid,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                try {
                    batch2.commit().await()
                } catch (e: Exception) {
                    runCatching {
                        val cleanupBatch = db.batch()
                        firstChunks.indices.forEach { idx ->
                            cleanupBatch.delete(storyRef.collection("media").document("chunk_$idx"))
                        }
                        cleanupBatch.delete(storyRef)
                        cleanupBatch.commit().await()
                    }
                    throw e
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, storyRef.path)
            throw e
        }
        storyId
    }

    suspend fun markStoryViewed(story: ArkStory, viewer: UserProfile): Result<Unit> = runCatching {
        val uid = requireUserId()
        if (uid == story.authorId) return@runCatching
        val storyRef = db.collection("stories").document(story.id)
        val viewerRef = storyRef.collection("viewers").document(uid)
        try {
            db.runTransaction { tx ->
                val vSnap = tx.get(viewerRef)
                if (!vSnap.exists()) {
                    val sSnap = tx.get(storyRef)
                    val currentCount = sSnap.getLong("viewerCount") ?: 0L
                    tx.set(
                        viewerRef,
                        mapOf(
                            "viewerUid" to uid,
                            "viewerUsername" to viewer.username.take(30).ifBlank { "player" },
                            "viewerAvatar" to viewer.avatarPreset.take(40),
                            "viewedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    tx.update(storyRef, mapOf("viewerCount" to currentCount + 1L))
                }
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, viewerRef.path)
            throw e
        }
    }

    suspend fun reactToStory(storyId: String, username: String, reactionKey: String): Result<String> = runCatching {
        val uid = requireUserId()
        val cleanReaction = reactionKey.takeIf { r -> ArkFeedIds.reactionOptions.any { it.first == r } } ?: "love"
        val storyRef = db.collection("stories").document(storyId)
        val reactRef = storyRef.collection("reactions").document(uid)
        try {
            db.runTransaction { tx ->
                val sSnap = tx.get(storyRef)
                val rSnap = tx.get(reactRef)
                val rawMap = sSnap.get("reactionCounts") as? Map<*, *>
                val counts = mutableMapOf<String, Long>()
                rawMap?.forEach { (k, v) -> if (k is String && v is Number) counts[k] = v.toLong().coerceAtLeast(0L) }
                val prev = if (rSnap.exists()) rSnap.getString("reaction") else null
                if (prev != null) {
                    val oldC = counts[prev] ?: 0L
                    if (oldC <= 1L) counts.remove(prev) else counts[prev] = oldC - 1L
                }
                counts[cleanReaction] = (counts[cleanReaction] ?: 0L) + 1L
                tx.set(
                    reactRef,
                    mapOf(
                        "userId" to uid,
                        "username" to username.take(30).ifBlank { "player" },
                        "reaction" to cleanReaction,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.update(storyRef, mapOf("reactionCounts" to counts))
                cleanReaction
            }.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, storyRef.path)
            throw e
        }
    }

    fun observeStoryReactions(storyId: String): Flow<List<StoryReaction>> =
        db.collection("stories").document(storyId).collection("reactions")
            .limit(80)
            .snapshots()
            .map { snap -> snap.toObjects(StoryReaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { emit(emptyList()) }

    fun observeStoryViewers(storyId: String): Flow<List<StoryViewer>> = flow {
        emitAll(
            db.collection("stories").document(storyId).collection("viewers")
                .limit(100)
                .snapshots()
                .map { snap -> snap.toObjects(StoryViewer::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    emit(emptyList())
                }
        )
    }

    suspend fun deleteStory(storyId: String): Result<Unit> = runCatching {
        requireUserId()
        val storyRef = db.collection("stories").document(storyId)
        try {
            val mediaDocs = runCatching { storyRef.collection("media").get().await() }.getOrNull()
            val batch = db.batch()
            mediaDocs?.documents?.forEach { batch.delete(it.reference) }
            batch.delete(storyRef)
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, storyRef.path)
            throw e
        }
    }

    suspend fun fetchStoryVideoFile(context: Context, storyId: String): File? {
        return runCatching {
            val snap = db.collection("stories").document(storyId).collection("media").get().await()
            val chunks = snap.toObjects(MediaChunk::class.java)
            ImageCompressionHelper.reconstructVideoToCache(context, "story_$storyId", chunks)
        }.getOrNull()
    }

    fun observeUserHighlights(ownerId: String, viewerUid: String): Flow<List<StoryHighlight>> {
        if (ownerId == viewerUid) {
            return db.collection("highlights")
                .whereEqualTo("ownerId", ownerId)
                .limit(20)
                .snapshots()
                .map { snap ->
                    snap.toObjects(StoryHighlight::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { emit(emptyList()) }
        }
        val pubFlow = db.collection("highlights")
            .whereEqualTo("ownerId", ownerId)
            .whereEqualTo("visibility", "public")
            .limit(20)
            .snapshots()
            .map { it.toObjects(StoryHighlight::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { emit(emptyList()) }

        val sharedFlow = db.collection("highlights")
            .whereEqualTo("ownerId", ownerId)
            .whereArrayContains("visibleToUids", viewerUid)
            .limit(20)
            .snapshots()
            .map { it.toObjects(StoryHighlight::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { emit(emptyList()) }

        return combine(pubFlow, sharedFlow) { pub, shared ->
            (pub + shared).distinctBy { it.id }.sortedByDescending { it.updatedAt?.seconds ?: 0L }
        }
    }

    suspend fun createHighlight(
        owner: UserProfile,
        title: String,
        story: ArkStory,
        followers: List<FollowEdge>,
        friends: List<FriendEdge>
    ): Result<String> = runCatching {
        val uid = requireUserId()
        require(uid == owner.userId)
        val cleanTitle = title.trim().take(30).ifBlank { "Highlights" }
        val cleanVis = if (!owner.isPrivateAccount && story.visibility == "public") "public" else "followers"
        val visibleUids = linkedSetOf(uid)
        followers.forEach { visibleUids.add(it.peerUid) }
        friends.forEach { visibleUids.add(it.friendUid) }

        val slide = mapOf(
            "storyId" to story.id,
            "mediaType" to story.mediaType,
            "imageBase64" to story.imageBase64.take(90_000),
            "caption" to story.caption.take(140),
            "addedAtMillis" to System.currentTimeMillis()
        )
        val id = ArkFeedIds.newChronoDocId("hl")
        val ref = db.collection("highlights").document(id)
        val payload = mapOf(
            "ownerId" to uid,
            "title" to cleanTitle,
            "coverImageBase64" to story.imageBase64.take(90_000),
            "slides" to listOf(slide),
            "visibility" to cleanVis,
            "visibleToUids" to visibleUids.take(200),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        ref.set(payload).await()
        id
    }

    suspend fun addStoryToHighlight(highlight: StoryHighlight, story: ArkStory): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(uid == highlight.ownerId)
        val existingSlides = highlight.slides.filter { it.storyId != story.id }
        val newSlide = HighlightSlide(
            storyId = story.id,
            mediaType = story.mediaType,
            imageBase64 = story.imageBase64.take(90_000),
            caption = story.caption.take(140),
            addedAtMillis = System.currentTimeMillis()
        )
        val serializedSlides = (existingSlides + newSlide).takeLast(15).map { s ->
            mapOf(
                "storyId" to s.storyId,
                "mediaType" to s.mediaType,
                "imageBase64" to s.imageBase64,
                "caption" to s.caption,
                "addedAtMillis" to s.addedAtMillis
            )
        }
        db.collection("highlights").document(highlight.id)
            .update(mapOf("slides" to serializedSlides, "updatedAt" to FieldValue.serverTimestamp()))
            .await()
    }

    suspend fun renameHighlight(highlightId: String, newTitle: String): Result<Unit> = runCatching {
        requireUserId()
        val clean = newTitle.trim().take(30)
        require(clean.isNotBlank()) { "Highlight title cannot be empty." }
        db.collection("highlights").document(highlightId)
            .update(mapOf("title" to clean, "updatedAt" to FieldValue.serverTimestamp()))
            .await()
    }

    suspend fun deleteHighlight(highlightId: String): Result<Unit> = runCatching {
        requireUserId()
        db.collection("highlights").document(highlightId).delete().await()
    }
}
