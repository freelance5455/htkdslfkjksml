package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.FashionProduct
import com.example.data.model.RecentlyViewedProduct
import com.example.data.model.SavedOutfit
import com.example.data.model.TryOnSession
import com.example.data.model.UserProfile
import com.example.data.model.WishlistItem
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StyleAiRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> {
        val docRef = db.collection("users").document(userId)
        return docRef.snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.GET, docRef.path)
                throw error
            }
    }

    suspend fun createOrInitializeProfile(
        displayName: String,
        userGender: String = "MALE",
        preferredLanguage: String = "Auto Local"
    ): Result<UserProfile> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val normalizedGender = if (userGender.uppercase() == "FEMALE") "FEMALE" else "MALE"
        val safeLanguage = preferredLanguage.trim().ifBlank { "Auto Local" }.take(40)
        return try {
            val existing = docRef.get().await()
            if (existing.exists()) {
                val profile = existing.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                Result.success(
                    profile ?: UserProfile(
                        id = uid,
                        userId = uid,
                        displayName = displayName,
                        userGender = normalizedGender,
                        preferredLanguage = safeLanguage
                    )
                )
            } else {
                val safeName = displayName.trim().ifBlank { "Style Enthusiast" }.take(100)
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to safeName,
                    "userGender" to normalizedGender,
                    "preferredLanguage" to safeLanguage,
                    "heightCm" to 172L,
                    "weightKg" to 68L,
                    "preferredTopSize" to "M",
                    "preferredBottomSize" to "32",
                    "bodyFitPreference" to "Tailored Fit",
                    "preferredStyle" to "Luxury Minimalist",
                    "preferredOccasion" to "Casual",
                    "preferredColors" to "Obsidian Black, Ivory White, Charcoal",
                    "budgetMaxInr" to 5000L,
                    "preferredRetailers" to "Myntra, AJIO, Amazon, Flipkart",
                    "membershipTier" to "FREE",
                    "tryOnCountUsed" to 0L,
                    "recommendationsUsed" to 0L,
                    "photoConsentGranted" to false,
                    "hasUploadedPhoto" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
                Result.success(
                    UserProfile(
                        id = uid,
                        userId = uid,
                        displayName = safeName,
                        userGender = normalizedGender,
                        preferredLanguage = safeLanguage
                    )
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateGenderAndLanguage(
        userGender: String,
        preferredLanguage: String
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        val normalizedGender = if (userGender.uppercase() == "FEMALE") "FEMALE" else "MALE"
        val safeLanguage = preferredLanguage.trim().ifBlank { "Auto Local" }.take(40)
        return try {
            val updates = mapOf(
                "userGender" to normalizedGender,
                "preferredLanguage" to safeLanguage,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateBodyMeasurements(
        heightCm: Int,
        weightKg: Int,
        preferredTopSize: String,
        preferredBottomSize: String,
        bodyFitPreference: String
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        return try {
            val updates = mapOf(
                "heightCm" to heightCm.toLong().coerceIn(100L, 250L),
                "weightKg" to weightKg.toLong().coerceIn(30L, 250L),
                "preferredTopSize" to preferredTopSize.trim().ifBlank { "M" }.take(20),
                "preferredBottomSize" to preferredBottomSize.trim().ifBlank { "32" }.take(20),
                "bodyFitPreference" to bodyFitPreference.trim().ifBlank { "Tailored Fit" }.take(40),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateStylingPreferences(
        preferredStyle: String,
        preferredOccasion: String,
        preferredColors: String,
        budgetMaxInr: Long,
        preferredRetailers: String
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        return try {
            val updates = mapOf(
                "preferredStyle" to preferredStyle.take(60).ifBlank { "Casual" },
                "preferredOccasion" to preferredOccasion.take(60).ifBlank { "Everyday" },
                "preferredColors" to preferredColors.take(200).ifBlank { "Black, White" },
                "budgetMaxInr" to budgetMaxInr.coerceIn(200L, 500000L),
                "preferredRetailers" to preferredRetailers.take(200).ifBlank { "Myntra, AJIO, Amazon, Flipkart" },
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updatePhotoState(consentGranted: Boolean, hasUploadedPhoto: Boolean): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        return try {
            val updates = mapOf(
                "photoConsentGranted" to consentGranted,
                "hasUploadedPhoto" to hasUploadedPhoto,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateMembershipTier(tier: String): Result<Unit> {
        val uid = requireUserId()
        val validTier = if (tier == "PREMIUM") "PREMIUM" else "FREE"
        val docRef = db.collection("users").document(uid)
        return try {
            val updates = mapOf(
                "membershipTier" to validTier,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun incrementUsageCounters(tryOnDelta: Long = 0L, recommendationDelta: Long = 0L): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)
        return try {
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (tryOnDelta != 0L) {
                updates["tryOnCountUsed"] = FieldValue.increment(tryOnDelta)
            }
            if (recommendationDelta != 0L) {
                updates["recommendationsUsed"] = FieldValue.increment(recommendationDelta)
            }
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeWishlistItems(userId: String): Flow<List<WishlistItem>> {
        val colRef = db.collection("users").document(userId).collection("wishlist_items")
        return colRef
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(WishlistItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    suspend fun addItemToWishlist(
        productId: String,
        title: String,
        brand: String,
        category: String,
        occasion: String,
        selectedColor: String,
        selectedSize: String,
        priceInr: Int,
        originalPriceInr: Int,
        imageUrl: String,
        productUrl: String,
        retailer: String,
        notes: String
    ): Result<String> {
        val uid = requireUserId()
        val safeDocId = "wish_${productId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(100).ifBlank { System.currentTimeMillis().toString() }}"
        val docRef = db.collection("users").document(uid).collection("wishlist_items").document(safeDocId)
        return try {
            val payload = mapOf(
                "userId" to uid,
                "productId" to productId.take(120).ifBlank { "prod_1" },
                "title" to title.take(150).ifBlank { "Curated Clothing Item" },
                "brand" to brand.take(80).ifBlank { "StyleAI Atelier" },
                "category" to category.take(60).ifBlank { "Shirts" },
                "occasion" to occasion.take(60).ifBlank { "Casual" },
                "selectedColor" to selectedColor.take(60).ifBlank { "Obsidian Black" },
                "selectedSize" to selectedSize.take(20).ifBlank { "M" },
                "priceInr" to priceInr.toLong().coerceIn(0L, 1000000L),
                "originalPriceInr" to originalPriceInr.toLong().coerceIn(0L, 1000000L),
                "imageUrl" to imageUrl.take(600).ifBlank { "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f" },
                "productUrl" to productUrl.take(600).ifBlank { "https://www.myntra.com" },
                "retailer" to retailer.take(60).ifBlank { "Myntra" },
                "notes" to notes.take(600).ifBlank { "Saved to personal Wishlist for virtual try-on and price tracking." },
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(safeDocId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateWishlistItemVariant(
        itemId: String,
        selectedColor: String,
        selectedSize: String,
        notes: String
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("wishlist_items").document(itemId)
        return try {
            val updates = mapOf(
                "selectedColor" to selectedColor.take(60).ifBlank { "Obsidian Black" },
                "selectedSize" to selectedSize.take(20).ifBlank { "M" },
                "notes" to notes.take(600).ifBlank { "Saved to personal Wishlist." },
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun removeWishlistItem(itemId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("wishlist_items").document(itemId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeSavedOutfits(userId: String): Flow<List<SavedOutfit>> {
        val colRef = db.collection("users").document(userId).collection("saved_outfits")
        return colRef
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(SavedOutfit::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    suspend fun saveOutfitToWardrobe(
        outfitId: String,
        title: String,
        category: String,
        occasion: String,
        brand: String,
        color: String,
        priceInr: Int,
        imageUrl: String,
        productUrl: String,
        retailer: String,
        stylistNote: String,
        matchingShoes: String,
        matchingAccessories: String
    ): Result<String> {
        val uid = requireUserId()
        val safeDocId = outfitId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(100).ifBlank { "outfit_${System.currentTimeMillis()}" }
        val docRef = db.collection("users").document(uid).collection("saved_outfits").document(safeDocId)
        return try {
            val payload = mapOf(
                "userId" to uid,
                "title" to title.take(120).ifBlank { "Curated Look" },
                "category" to category.take(60).ifBlank { "Complete outfit combinations" },
                "occasion" to occasion.take(60).ifBlank { "Casual" },
                "brand" to brand.take(80).ifBlank { "StyleAI Atelier" },
                "color" to color.take(60).ifBlank { "Obsidian Black" },
                "priceInr" to priceInr.toLong().coerceIn(0L, 1000000L),
                "imageUrl" to imageUrl.take(600).ifBlank { "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f" },
                "productUrl" to productUrl.take(600).ifBlank { "https://www.myntra.com" },
                "retailer" to retailer.take(60).ifBlank { "Myntra" },
                "stylistNote" to stylistNote.take(600).ifBlank { "Selected for balanced proportions and versatility." },
                "matchingShoes" to matchingShoes.take(200).ifBlank { "Minimalist Leather Sneakers" },
                "matchingAccessories" to matchingAccessories.take(200).ifBlank { "Brushed Steel Chronograph" },
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(safeDocId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun removeSavedOutfit(outfitId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("saved_outfits").document(outfitId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeTryOnSessions(userId: String): Flow<List<TryOnSession>> {
        val colRef = db.collection("users").document(userId).collection("tryon_sessions")
        return colRef
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(TryOnSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    suspend fun saveTryOnSession(
        sessionId: String,
        outfitId: String,
        outfitTitle: String,
        outfitCategory: String,
        selectedColor: String,
        selectedSize: String,
        aiFitNotes: String,
        localPreviewFilename: String
    ): Result<String> {
        val uid = requireUserId()
        val safeSessionId = sessionId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(100).ifBlank { "tryon_${System.currentTimeMillis()}" }
        val docRef = db.collection("users").document(uid).collection("tryon_sessions").document(safeSessionId)
        return try {
            val payload = mapOf(
                "userId" to uid,
                "outfitId" to outfitId.take(120).ifBlank { "prod_1" },
                "outfitTitle" to outfitTitle.take(120).ifBlank { "Selected Garment" },
                "outfitCategory" to outfitCategory.take(60).ifBlank { "Shirts" },
                "selectedColor" to selectedColor.take(60).ifBlank { "Black" },
                "selectedSize" to selectedSize.take(20).ifBlank { "M" },
                "aiFitNotes" to aiFitNotes.take(1000).ifBlank { "Natural drape and proportional shoulder alignment." },
                "localPreviewFilename" to localPreviewFilename.take(200).ifBlank { "tryon_preview.png" },
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(safeSessionId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteTryOnSession(sessionId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("tryon_sessions").document(sessionId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    fun observeRecentlyViewed(userId: String): Flow<List<RecentlyViewedProduct>> {
        val colRef = db.collection("users").document(userId).collection("recently_viewed")
        return colRef
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(RecentlyViewedProduct::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.seconds ?: it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) handleFirestoreError(error, OperationType.LIST, colRef.path)
                throw error
            }
    }

    suspend fun recordRecentlyViewed(product: FashionProduct): Result<Unit> {
        val uid = requireUserId()
        val safeDocId = product.id.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(100)
        val docRef = db.collection("users").document(uid).collection("recently_viewed").document(safeDocId)
        return try {
            val payload = mapOf(
                "userId" to uid,
                "productId" to product.id.take(120),
                "productName" to product.name.take(150),
                "brand" to product.brand.take(80),
                "category" to product.category.take(60),
                "priceInr" to product.priceInr.toLong().coerceIn(0L, 1000000L),
                "imageUrl" to product.imageUrl.take(600),
                "retailer" to product.primaryRetailer.take(60),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteAllUserData(): Result<Unit> {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)
        return try {
            val wishlistSnap = userDoc.collection("wishlist_items").whereEqualTo("userId", uid).get().await()
            for (doc in wishlistSnap.documents) {
                doc.reference.delete().await()
            }
            val savedSnap = userDoc.collection("saved_outfits").whereEqualTo("userId", uid).get().await()
            for (doc in savedSnap.documents) {
                doc.reference.delete().await()
            }
            val tryOnSnap = userDoc.collection("tryon_sessions").whereEqualTo("userId", uid).get().await()
            for (doc in tryOnSnap.documents) {
                doc.reference.delete().await()
            }
            val recentSnap = userDoc.collection("recently_viewed").whereEqualTo("userId", uid).get().await()
            for (doc in recentSnap.documents) {
                doc.reference.delete().await()
            }
            userDoc.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, userDoc.path)
            Result.failure(e)
        }
    }
}
