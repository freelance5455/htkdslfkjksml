package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.StudySessionDao
import com.example.data.dao.SubjectDao
import com.example.data.model.StudySession
import com.example.data.model.Subject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

@Database(
    entities = [Subject::class, StudySession::class],
    version = 1,
    exportSchema = false
)
abstract class StudyDatabase : RoomDatabase() {

    abstract fun subjectDao(): SubjectDao
    abstract fun studySessionDao(): StudySessionDao

    companion object {
        @Volatile
        private var INSTANCE: StudyDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): StudyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    StudyDatabase::class.java,
                    "study_timer_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch {
                        populateInitialData(database.subjectDao(), database.studySessionDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(subjectDao: SubjectDao, sessionDao: StudySessionDao) {
            if (subjectDao.getCount() > 0) return

            val subjects = listOf(
                Subject(1, "Mathematics", "🧮", "#F472B6", 60),
                Subject(2, "Computer Science", "💻", "#18181B", 90),
                Subject(3, "Creative Writing", "🐰", "#FDA4AF", 45),
                Subject(4, "Biology & Health", "🌸", "#DB2777", 45),
                Subject(5, "Design & Notes", "✂️", "#6B7280", 60)
            )
            subjectDao.insertAll(subjects)

            // Seed sample past sessions so stats, weekly charts, and history look alive
            val now = System.currentTimeMillis()
            val oneHour = 3600 * 1000L
            val oneDay = 24 * oneHour

            val sampleSessions = listOf(
                // Today's sessions
                StudySession(
                    id = 1,
                    subjectId = 1,
                    subjectName = "Mathematics",
                    subjectColorHex = "#F472B6",
                    subjectIcon = "🧮",
                    durationSeconds = 25 * 60,
                    sessionType = "FOCUS",
                    timestamp = now - (2 * oneHour),
                    notes = "Algebra problem set with cute calculator"
                ),
                StudySession(
                    id = 2,
                    subjectId = 2,
                    subjectName = "Computer Science",
                    subjectColorHex = "#18181B",
                    subjectIcon = "💻",
                    durationSeconds = 25 * 60,
                    sessionType = "FOCUS",
                    timestamp = now - (4 * oneHour),
                    notes = "Data structures review"
                ),
                StudySession(
                    id = 3,
                    subjectId = 3,
                    subjectName = "Creative Writing",
                    subjectColorHex = "#FDA4AF",
                    subjectIcon = "🐰",
                    durationSeconds = 30 * 60,
                    sessionType = "FOCUS",
                    timestamp = now - (5 * oneHour),
                    notes = "Bunny pen journal notes"
                ),
                // Yesterday's sessions
                StudySession(
                    id = 4,
                    subjectId = 4,
                    subjectName = "Biology & Health",
                    subjectColorHex = "#DB2777",
                    subjectIcon = "🌸",
                    durationSeconds = 45 * 60,
                    sessionType = "FOCUS",
                    timestamp = now - oneDay - (3 * oneHour),
                    notes = "Cell biology flashcards"
                ),
                StudySession(
                    id = 5,
                    subjectId = 5,
                    subjectName = "Design & Notes",
                    subjectColorHex = "#6B7280",
                    subjectIcon = "✂️",
                    durationSeconds = 30 * 60,
                    sessionType = "FOCUS",
                    timestamp = now - oneDay - (6 * oneHour),
                    notes = "Sticker board planning"
                ),
                // 2 days ago
                StudySession(
                    id = 6,
                    subjectId = 1,
                    subjectName = "Mathematics",
                    subjectColorHex = "#F472B6",
                    subjectIcon = "🧮",
                    durationSeconds = 50 * 60,
                    sessionType = "FOCUS",
                    timestamp = now - (2 * oneDay) - (2 * oneHour),
                    notes = "Calculus practice"
                ),
                StudySession(
                    id = 7,
                    subjectId = 2,
                    subjectName = "Computer Science",
                    subjectColorHex = "#18181B",
                    subjectIcon = "💻",
                    durationSeconds = 25 * 60,
                    sessionType = "FOCUS",
                    timestamp = now - (2 * oneDay) - (5 * oneHour),
                    notes = "Kotlin algorithms"
                ),
                // 3 days ago
                StudySession(
                    id = 8,
                    subjectId = 3,
                    subjectName = "Creative Writing",
                    subjectColorHex = "#FDA4AF",
                    subjectIcon = "🐰",
                    durationSeconds = 40 * 60,
                    sessionType = "FOCUS",
                    timestamp = now - (3 * oneDay) - (4 * oneHour),
                    notes = "Poetry & essay draft"
                )
            )
            sessionDao.insertAll(sampleSessions)
        }
    }
}
