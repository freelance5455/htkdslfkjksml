package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.CalculationHistory
import com.example.ui.localization.AppLanguage
import org.json.JSONArray
import org.json.JSONObject

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("smart_calc_prefs", Context.MODE_PRIVATE)

    // Language
    var language: AppLanguage
        get() {
            val code = prefs.getString("key_language", "en") ?: "en"
            return AppLanguage.values().firstOrNull { it.code == code } ?: AppLanguage.ENGLISH
        }
        set(value) {
            prefs.edit().putString("key_language", value.code).apply()
        }

    // Theme: "SYSTEM", "LIGHT", "DARK"
    var themeMode: String
        get() = prefs.getString("key_theme", "SYSTEM") ?: "SYSTEM"
        set(value) = prefs.edit().putString("key_theme", value).apply()

    // Haptics
    var hapticsEnabled: Boolean
        get() = prefs.getBoolean("key_haptics", true)
        set(value) = prefs.edit().putBoolean("key_haptics", value).apply()

    // Decimal precision
    var decimalPrecision: Int
        get() = prefs.getInt("key_precision", 4)
        set(value) = prefs.edit().putInt("key_precision", value).apply()

    // Angle mode
    var isDegreeMode: Boolean
        get() = prefs.getBoolean("key_degree_mode", true)
        set(value) = prefs.edit().putBoolean("key_degree_mode", value).apply()

    // Favorites
    fun getFavoriteToolIds(): Set<String> {
        return prefs.getStringSet("key_favorites", setOf("standard_calc", "scientific_calc", "age_calc", "gst_calc")) ?: emptySet()
    }

    fun toggleFavorite(toolId: String): Set<String> {
        val current = getFavoriteToolIds().toMutableSet()
        if (current.contains(toolId)) {
            current.remove(toolId)
        } else {
            current.add(toolId)
        }
        prefs.edit().putStringSet("key_favorites", current).apply()
        return current
    }

    // Calculation History
    fun getHistory(): List<CalculationHistory> {
        val raw = prefs.getString("key_history", "[]") ?: "[]"
        val list = mutableListOf<CalculationHistory>()
        try {
            val jsonArray = JSONArray(raw)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    CalculationHistory(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        expression = obj.optString("expression", ""),
                        result = obj.optString("result", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        isFavorite = obj.optBoolean("isFavorite", false)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun addHistory(expression: String, result: String): List<CalculationHistory> {
        val current = getHistory().toMutableList()
        val newItem = CalculationHistory(
            id = System.currentTimeMillis().toString(),
            expression = expression,
            result = result,
            timestamp = System.currentTimeMillis()
        )
        current.add(0, newItem)
        // Keep max 100 entries
        val trimmed = if (current.size > 100) current.take(100) else current
        saveHistory(trimmed)
        return trimmed
    }

    fun clearHistory() {
        prefs.edit().putString("key_history", "[]").apply()
    }

    fun deleteHistoryItem(id: String): List<CalculationHistory> {
        val current = getHistory().filterNot { it.id == id }
        saveHistory(current)
        return current
    }

    fun toggleHistoryFavorite(id: String): List<CalculationHistory> {
        val current = getHistory().map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
        saveHistory(current)
        return current
    }

    private fun saveHistory(list: List<CalculationHistory>) {
        val jsonArray = JSONArray()
        list.forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("expression", item.expression)
            obj.put("result", item.result)
            obj.put("timestamp", item.timestamp)
            obj.put("isFavorite", item.isFavorite)
            jsonArray.put(obj)
        }
        prefs.edit().putString("key_history", jsonArray.toString()).apply()
    }
}
