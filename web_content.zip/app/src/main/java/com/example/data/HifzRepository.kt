package com.example.data

import android.content.Context
import com.example.R
import com.example.data.model.DailyReport
import com.example.data.model.DailyReportSnapshot
import com.example.data.model.HifzClass
import com.example.data.model.Invite
import com.example.data.model.School
import com.example.data.model.SchoolMember
import com.example.data.model.Student
import com.example.data.model.StudentRowData
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.persistentCacheSettings
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object FirestoreClientFactory {
    @Volatile
    private var configured = false

    fun getInstance(context: Context): FirebaseFirestore {
        val dbId = context.applicationContext.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(dbId)
        if (!configured) {
            synchronized(this) {
                if (!configured) {
                    try {
                        val settings = FirebaseFirestoreSettings.Builder()
                            .setLocalCacheSettings(
                                persistentCacheSettings {
                                    setSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                                }
                            )
                            .build()
                        db.firestoreSettings = settings
                    } catch (_: Exception) {
                        // Already started in this process; persistent cache is active by default
                    }
                    configured = true
                }
            }
        }
        return db
    }
}

class HifzRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(FirestoreClientFactory.getInstance(context))

    private fun requireUserId(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("User must be signed in with Google.")

    private fun currentUserEmail(): String =
        (auth.currentUser?.email ?: "").trim().lowercase(Locale.US)

    private fun currentUserName(): String =
        (auth.currentUser?.displayName ?: "").trim().take(100)

    fun observeUserProfile(uid: String): Flow<UserProfile?> {
        val path = "user_profiles/$uid"
        return db.collection("user_profiles").document(uid)
            .snapshots(MetadataChanges.INCLUDE)
            .map { it.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                logIfSignedIn(error, OperationType.GET, path, uid)
                throw error
            }
    }

    fun observeSchool(schoolId: String): Flow<School?> {
        val uid = auth.currentUser?.uid
        val path = "schools/$schoolId"
        return db.collection("schools").document(schoolId)
            .snapshots(MetadataChanges.INCLUDE)
            .map { it.toObject(School::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                if (uid != null) logIfSignedIn(error, OperationType.GET, path, uid)
                throw error
            }
    }

    fun observeMember(schoolId: String, uid: String): Flow<SchoolMember?> {
        val path = "schools/$schoolId/members/$uid"
        return db.collection("schools").document(schoolId)
            .collection("members").document(uid)
            .snapshots(MetadataChanges.INCLUDE)
            .map { it.toObject(SchoolMember::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                logIfSignedIn(error, OperationType.GET, path, uid)
                throw error
            }
    }

    fun observeClasses(schoolId: String): Flow<List<HifzClass>> {
        val uid = auth.currentUser?.uid
        val path = "schools/$schoolId/classes"
        return db.collection("schools").document(schoolId)
            .collection("classes")
            .orderBy("sortOrder", Query.Direction.ASCENDING)
            .snapshots(MetadataChanges.INCLUDE)
            .map { snap ->
                snap.toObjects(HifzClass::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                if (uid != null) logIfSignedIn(error, OperationType.LIST, path, uid)
                throw error
            }
    }

    fun observeSingleClass(schoolId: String, classId: String): Flow<HifzClass?> {
        val uid = auth.currentUser?.uid
        val path = "schools/$schoolId/classes/$classId"
        return db.collection("schools").document(schoolId)
            .collection("classes").document(classId)
            .snapshots(MetadataChanges.INCLUDE)
            .map { it.toObject(HifzClass::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                if (uid != null) logIfSignedIn(error, OperationType.GET, path, uid)
                throw error
            }
    }

    fun observeStudents(schoolId: String, classId: String): Flow<List<Student>> {
        val uid = auth.currentUser?.uid
        val path = "schools/$schoolId/classes/$classId/students"
        return db.collection("schools").document(schoolId)
            .collection("classes").document(classId)
            .collection("students")
            .orderBy("sortOrder", Query.Direction.ASCENDING)
            .snapshots(MetadataChanges.INCLUDE)
            .map { snap ->
                snap.toObjects(Student::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                if (uid != null) logIfSignedIn(error, OperationType.LIST, path, uid)
                throw error
            }
    }

    fun observeDailyReport(schoolId: String, classId: String, dateIso: String): Flow<DailyReportSnapshot> =
        callbackFlow {
            val uid = auth.currentUser?.uid
            val path = "schools/$schoolId/classes/$classId/daily_reports/$dateIso"
            val ref = db.collection("schools").document(schoolId)
                .collection("classes").document(classId)
                .collection("daily_reports").document(dateIso)
            val reg = ref.addSnapshotListener(MetadataChanges.INCLUDE) { snap, error ->
                if (error != null) {
                    if (uid != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(error, OperationType.GET, path)
                    }
                    close(error)
                    return@addSnapshotListener
                }
                if (snap != null) {
                    val report = if (snap.exists()) {
                        snap.toObject(DailyReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    } else null
                    trySend(
                        DailyReportSnapshot(
                            report = report,
                            hasPendingWrites = snap.metadata.hasPendingWrites(),
                            fromCache = snap.metadata.isFromCache
                        )
                    )
                }
            }
            awaitClose { reg.remove() }
        }

    fun observeMonthReports(schoolId: String, classId: String, yearMonth: String): Flow<List<DailyReport>> {
        val uid = auth.currentUser?.uid
        val path = "schools/$schoolId/classes/$classId/daily_reports"
        val start = "$yearMonth-01"
        val end = "$yearMonth-31"
        return db.collection("schools").document(schoolId)
            .collection("classes").document(classId)
            .collection("daily_reports")
            .whereGreaterThanOrEqualTo("date", start)
            .whereLessThanOrEqualTo("date", end)
            .snapshots(MetadataChanges.INCLUDE)
            .map { snap ->
                snap.toObjects(DailyReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.date }
            }
            .catch { error ->
                if (uid != null) logIfSignedIn(error, OperationType.LIST, path, uid)
                throw error
            }
    }

    fun observeAllReportDates(schoolId: String, classId: String): Flow<List<String>> {
        val uid = auth.currentUser?.uid
        val path = "schools/$schoolId/classes/$classId/daily_reports"
        return db.collection("schools").document(schoolId)
            .collection("classes").document(classId)
            .collection("daily_reports")
            .snapshots(MetadataChanges.INCLUDE)
            .map { snap ->
                snap.documents.mapNotNull { it.getString("date") ?: it.id }.sortedDescending()
            }
            .catch { error ->
                if (uid != null) logIfSignedIn(error, OperationType.LIST, path, uid)
                throw error
            }
    }

    fun observeInvites(schoolId: String): Flow<List<Invite>> {
        val uid = auth.currentUser?.uid
        val path = "schools/$schoolId/invites"
        return db.collection("schools").document(schoolId)
            .collection("invites")
            .snapshots(MetadataChanges.INCLUDE)
            .map { snap ->
                snap.toObjects(Invite::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                if (uid != null) logIfSignedIn(error, OperationType.LIST, path, uid)
                throw error
            }
    }

    suspend fun getMyPendingInvite(schoolId: String): Invite? {
        val email = currentUserEmail()
        if (email.isBlank()) return null
        val path = "schools/$schoolId/invites/$email"
        return try {
            val snap = db.collection("schools").document(schoolId)
                .collection("invites").document(email).get().await()
            if (snap.exists()) snap.toObject(Invite::class.java) else null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            null
        }
    }

    suspend fun getAdminPin(schoolId: String): String? {
        val path = "schools/$schoolId/admin_secrets/admin"
        return try {
            val snap = db.document(path).get().await()
            snap.getString("pin")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            null
        }
    }

    suspend fun getClassPins(schoolId: String): Map<String, String> {
        val path = "schools/$schoolId/class_secrets"
        return try {
            val snap = db.collection(path).get().await()
            snap.documents.mapNotNull { doc ->
                val cid = doc.getString("classId") ?: doc.id
                val pin = doc.getString("pin") ?: return@mapNotNull null
                cid to pin
            }.toMap()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            emptyMap()
        }
    }

    suspend fun ensureBootstrappedAdminSchool(): Result<String> {
        val schoolId = SeedData.DEFAULT_SCHOOL_ID
        val path = "schools/$schoolId"
        return try {
            val uid = requireUserId()
            val schoolRef = db.collection("schools").document(schoolId)
            val snap = schoolRef.get().await()
            if (!snap.exists()) {
                createAndSeedSchool(schoolId = schoolId, ownerUid = uid)
            } else {
                // Ensure bootstrapped admin has member doc and user_profile
                val memberRef = schoolRef.collection("members").document(uid)
                val memberSnap = memberRef.get().await()
                val batch = db.batch()
                if (!memberSnap.exists()) {
                    batch.set(
                        memberRef,
                        mapOf(
                            "userId" to uid,
                            "email" to currentUserEmail(),
                            "displayName" to currentUserName(),
                            "role" to "admin",
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                batch.update(
                    schoolRef,
                    mapOf(
                        "memberUids" to FieldValue.arrayUnion(uid),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                writeUserProfileInBatch(batch, uid, schoolId)
                batch.commit().await()
            }
            Result.success(schoolId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun createCustomSchoolWorkspace(schoolId: String): Result<String> {
        val cleanId = schoolId.trim().lowercase(Locale.US).replace(Regex("[^a-z0-9_\\-]"), "_")
        if (cleanId.isBlank()) return Result.failure(IllegalArgumentException("Invalid school code"))
        val path = "schools/$cleanId"
        return try {
            val uid = requireUserId()
            val existing = db.document(path).get().await()
            if (existing.exists()) {
                return Result.failure(IllegalStateException("School code already exists. Please join it with a PIN."))
            }
            createAndSeedSchool(cleanId, uid)
            Result.success(cleanId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    private suspend fun createAndSeedSchool(schoolId: String, ownerUid: String) {
        val batch = db.batch()
        val schoolRef = db.collection("schools").document(schoolId)

        batch.set(
            schoolRef,
            mapOf(
                "ownerUid" to ownerUid,
                "title" to SeedData.DEFAULT_TITLE,
                "centre" to SeedData.DEFAULT_CENTRE,
                "activeClassId" to "c1",
                "nextClassNum" to 3L,
                "memberUids" to listOf(ownerUid),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            schoolRef.collection("admin_secrets").document("admin"),
            mapOf(
                "pin" to SeedData.DEFAULT_ADMIN_PIN,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )
        batch.set(
            schoolRef.collection("members").document(ownerUid),
            mapOf(
                "userId" to ownerUid,
                "email" to currentUserEmail(),
                "displayName" to currentUserName(),
                "role" to "admin",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )

        SeedData.CLASS_SEEDS.forEach { seed ->
            val classRef = schoolRef.collection("classes").document(seed.id)
            batch.set(
                classRef,
                mapOf(
                    "name" to seed.name,
                    "sortOrder" to seed.sortOrder,
                    "nextStudentId" to (seed.names.size + 1).toLong(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                schoolRef.collection("class_secrets").document(seed.id),
                mapOf(
                    "classId" to seed.id,
                    "pin" to seed.pin,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            seed.names.forEachIndexed { idx, name ->
                val stuNum = (idx + 1).toLong()
                batch.set(
                    classRef.collection("students").document("s$stuNum"),
                    mapOf(
                        "studentNum" to stuNum,
                        "name" to name,
                        "sortOrder" to idx.toLong(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.set(
                classRef.collection("daily_reports").document(SeedData.SEED_DATE),
                mapOf(
                    "date" to SeedData.SEED_DATE,
                    "classId" to seed.id,
                    "sotd" to "",
                    "rows" to SeedData.seedRowsFor(seed),
                    "updatedByUid" to ownerUid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        writeUserProfileInBatch(batch, ownerUid, schoolId)
        batch.commit().await()
    }

    private suspend fun writeUserProfileInBatch(
        batch: com.google.firebase.firestore.WriteBatch,
        uid: String,
        schoolId: String
    ) {
        val profileRef = db.collection("user_profiles").document(uid)
        val existingProfile = try {
            profileRef.get().await()
        } catch (_: Exception) {
            null
        }
        if (existingProfile != null && existingProfile.exists()) {
            batch.update(
                profileRef,
                mapOf(
                    "email" to currentUserEmail(),
                    "displayName" to currentUserName(),
                    "activeSchoolId" to schoolId,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        } else {
            batch.set(
                profileRef,
                mapOf(
                    "userId" to uid,
                    "email" to currentUserEmail(),
                    "displayName" to currentUserName(),
                    "activeSchoolId" to schoolId,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
    }

    suspend fun joinSchoolWithPin(
        schoolId: String,
        role: String,
        classId: String,
        pin: String
    ): Result<Unit> {
        val path = "schools/$schoolId/members"
        return try {
            val uid = requireUserId()
            require(pin.isNotBlank()) { "PIN is required" }
            val schoolRef = db.collection("schools").document(schoolId)
            val memberRef = schoolRef.collection("members").document(uid)
            val existingMember = try { memberRef.get().await() } catch (_: Exception) { null }
            val batch = db.batch()
            val payload = mutableMapOf<String, Any>(
                "userId" to uid,
                "email" to currentUserEmail(),
                "displayName" to currentUserName(),
                "role" to role,
                "accessPin" to pin.trim(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (role == "class") {
                require(classId.isNotBlank()) { "Class ID is required" }
                payload["classId"] = classId.trim()
            }
            if (existingMember != null && existingMember.exists()) {
                batch.update(memberRef, payload)
            } else {
                payload["createdAt"] = FieldValue.serverTimestamp()
                batch.set(memberRef, payload)
            }
            batch.update(
                schoolRef,
                mapOf(
                    "memberUids" to FieldValue.arrayUnion(uid),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            writeUserProfileInBatch(batch, uid, schoolId)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun joinSchoolWithInvite(schoolId: String, invite: Invite): Result<Unit> {
        val path = "schools/$schoolId/members"
        return try {
            val uid = requireUserId()
            val schoolRef = db.collection("schools").document(schoolId)
            val memberRef = schoolRef.collection("members").document(uid)
            val batch = db.batch()
            val payload = mutableMapOf<String, Any>(
                "userId" to uid,
                "email" to currentUserEmail(),
                "displayName" to currentUserName(),
                "role" to invite.role,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (invite.role == "class" && invite.classId.isNotBlank()) {
                payload["classId"] = invite.classId
            }
            batch.set(memberRef, payload)
            batch.update(
                schoolRef,
                mapOf(
                    "memberUids" to FieldValue.arrayUnion(uid),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            writeUserProfileInBatch(batch, uid, schoolId)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun saveDailyReport(
        schoolId: String,
        classId: String,
        dateIso: String,
        sotd: String,
        rows: Map<String, StudentRowData>,
        documentAlreadyExists: Boolean
    ): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId/daily_reports/$dateIso"
        return try {
            val uid = requireUserId()
            val docRef = db.document(path)
            val serializedRows = rows.mapValues { (_, row) -> row.toFirestoreMap() }
                .filterValues { it.isNotEmpty() }

            if (documentAlreadyExists) {
                try {
                    docRef.update(
                        mapOf(
                            "sotd" to sotd,
                            "rows" to serializedRows,
                            "updatedByUid" to uid,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).await()
                } catch (e: FirebaseFirestoreException) {
                    if (e.code == FirebaseFirestoreException.Code.NOT_FOUND) {
                        docRef.set(
                            mapOf(
                                "date" to dateIso,
                                "classId" to classId,
                                "sotd" to sotd,
                                "rows" to serializedRows,
                                "updatedByUid" to uid,
                                "createdAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                    } else {
                        throw e
                    }
                }
            } else {
                docRef.set(
                    mapOf(
                        "date" to dateIso,
                        "classId" to classId,
                        "sotd" to sotd,
                        "rows" to serializedRows,
                        "updatedByUid" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateSchoolHeading(schoolId: String, title: String, centre: String): Result<Unit> {
        val path = "schools/$schoolId"
        return try {
            requireUserId()
            val cleanTitle = title.trim().take(120)
            require(cleanTitle.isNotEmpty()) { "Title cannot be empty" }
            db.document(path).update(
                mapOf(
                    "title" to cleanTitle,
                    "centre" to centre.trim().take(160),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateActiveClass(schoolId: String, classId: String): Result<Unit> {
        val path = "schools/$schoolId"
        return try {
            requireUserId()
            db.document(path).update(
                mapOf(
                    "activeClassId" to classId,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun addClass(schoolId: String, name: String, nextNum: Long, sortOrder: Long): Result<String> {
        val classId = "c$nextNum"
        val path = "schools/$schoolId/classes/$classId"
        return try {
            requireUserId()
            val cleanName = name.trim().take(80)
            require(cleanName.isNotEmpty()) { "Class name cannot be empty" }
            val schoolRef = db.collection("schools").document(schoolId)
            val batch = db.batch()
            batch.set(
                schoolRef.collection("classes").document(classId),
                mapOf(
                    "name" to cleanName,
                    "sortOrder" to sortOrder,
                    "nextStudentId" to 1L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                schoolRef.collection("class_secrets").document(classId),
                mapOf(
                    "classId" to classId,
                    "pin" to "0000",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                schoolRef,
                mapOf(
                    "nextClassNum" to (nextNum + 1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(classId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun renameClass(schoolId: String, classId: String, name: String): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId"
        return try {
            requireUserId()
            val clean = name.trim().take(80)
            require(clean.isNotEmpty()) { "Class name cannot be empty" }
            db.document(path).update(
                mapOf(
                    "name" to clean,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateClassPin(schoolId: String, classId: String, pin: String): Result<Unit> {
        val path = "schools/$schoolId/class_secrets/$classId"
        return try {
            requireUserId()
            val clean = pin.trim().take(20)
            require(clean.isNotEmpty()) { "PIN cannot be empty" }
            val ref = db.document(path)
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "pin" to clean,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(
                    mapOf(
                        "classId" to classId,
                        "pin" to clean,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateAdminPin(schoolId: String, newPin: String): Result<Unit> {
        val path = "schools/$schoolId/admin_secrets/admin"
        return try {
            requireUserId()
            val clean = newPin.trim().take(20)
            require(clean.length >= 4) { "Admin PIN must be at least 4 characters" }
            val ref = db.document(path)
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.update(
                    mapOf(
                        "pin" to clean,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.set(
                    mapOf(
                        "pin" to clean,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteClass(schoolId: String, classId: String): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId"
        return try {
            requireUserId()
            val classRef = db.document(path)
            val students = classRef.collection("students").get().await()
            val reports = classRef.collection("daily_reports").get().await()
            val batch = db.batch()
            students.documents.forEach { batch.delete(it.reference) }
            reports.documents.forEach { batch.delete(it.reference) }
            batch.delete(db.collection("schools").document(schoolId).collection("class_secrets").document(classId))
            batch.delete(classRef)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun addStudent(
        schoolId: String,
        classId: String,
        name: String,
        nextStudentNum: Long,
        sortOrder: Long,
        fatherName: String = "",
        guardianPhone: String = "",
        currentPara: String = "",
        notes: String = ""
    ): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId/students"
        return try {
            requireUserId()
            val clean = name.trim().take(100)
            require(clean.isNotEmpty()) { "Student name cannot be empty" }
            val classRef = db.collection("schools").document(schoolId)
                .collection("classes").document(classId)
            val studentPayload = mutableMapOf<String, Any>(
                "studentNum" to nextStudentNum,
                "name" to clean,
                "fatherName" to fatherName.trim().take(100),
                "guardianPhone" to guardianPhone.trim().take(30),
                "currentPara" to currentPara.trim().take(20),
                "notes" to notes.trim().take(300),
                "sortOrder" to sortOrder,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val batch = db.batch()
            batch.set(
                classRef.collection("students").document("s$nextStudentNum"),
                studentPayload
            )
            batch.update(
                classRef,
                mapOf(
                    "nextStudentId" to (nextStudentNum + 1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun renameStudent(schoolId: String, classId: String, studentId: String, name: String): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId/students/$studentId"
        return try {
            requireUserId()
            val clean = name.trim().take(100)
            require(clean.isNotEmpty()) { "Student name cannot be empty" }
            db.document(path).update(
                mapOf(
                    "name" to clean,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateStudentProfile(
        schoolId: String,
        classId: String,
        studentId: String,
        name: String,
        fatherName: String,
        guardianPhone: String,
        currentPara: String,
        notes: String
    ): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId/students/$studentId"
        return try {
            requireUserId()
            val cleanName = name.trim().take(100)
            require(cleanName.isNotEmpty()) { "Student name cannot be empty" }
            db.document(path).update(
                mapOf(
                    "name" to cleanName,
                    "fatherName" to fatherName.trim().take(100),
                    "guardianPhone" to guardianPhone.trim().take(30),
                    "currentPara" to currentPara.trim().take(20),
                    "notes" to notes.trim().take(300),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun swapStudentsOrder(
        schoolId: String,
        classId: String,
        first: Student,
        second: Student
    ): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId/students"
        return try {
            requireUserId()
            val col = db.collection(path)
            val batch = db.batch()
            batch.update(
                col.document(first.id),
                mapOf("sortOrder" to second.sortOrder, "updatedAt" to FieldValue.serverTimestamp())
            )
            batch.update(
                col.document(second.id),
                mapOf("sortOrder" to first.sortOrder, "updatedAt" to FieldValue.serverTimestamp())
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteStudent(schoolId: String, classId: String, studentId: String): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId/students/$studentId"
        return try {
            requireUserId()
            db.document(path).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteDailyReport(schoolId: String, classId: String, dateIso: String): Result<Unit> {
        val path = "schools/$schoolId/classes/$classId/daily_reports/$dateIso"
        return try {
            requireUserId()
            db.document(path).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun addInvite(schoolId: String, email: String, role: String, classId: String): Result<Unit> {
        val cleanEmail = email.trim().lowercase(Locale.US)
        val path = "schools/$schoolId/invites/$cleanEmail"
        return try {
            val uid = requireUserId()
            require(cleanEmail.contains("@") && cleanEmail.contains(".")) { "Enter a valid Gmail address" }
            val payload = mutableMapOf<String, Any>(
                "email" to cleanEmail,
                "role" to role,
                "createdBy" to uid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (role == "class" && classId.isNotBlank()) {
                payload["classId"] = classId
            }
            db.document(path).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun removeInvite(schoolId: String, email: String): Result<Unit> {
        val path = "schools/$schoolId/invites/$email"
        return try {
            requireUserId()
            db.document(path).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    suspend fun exportBackupJson(schoolId: String, school: School, classes: List<HifzClass>): Result<String> {
        val path = "schools/$schoolId"
        return try {
            requireUserId()
            val pins = getClassPins(schoolId)
            val classesArr = JSONArray()
            val rostersObj = JSONObject()
            val daysObj = JSONObject()

            classes.forEach { cls ->
                classesArr.put(JSONObject().apply {
                    put("id", cls.id)
                    put("name", cls.name)
                    put("pin", pins[cls.id] ?: "0000")
                })
                val stuSnap = db.collection("schools").document(schoolId)
                    .collection("classes").document(cls.id)
                    .collection("students").orderBy("sortOrder", Query.Direction.ASCENDING).get().await()
                val stuListArr = JSONArray()
                stuSnap.documents.forEach { d ->
                    stuListArr.put(JSONObject().apply {
                        put("id", d.getLong("studentNum") ?: 0L)
                        put("name", d.getString("name") ?: "")
                    })
                }
                rostersObj.put(cls.id, JSONObject().apply {
                    put("list", stuListArr)
                    put("next", cls.nextStudentId)
                })

                val repSnap = db.collection("schools").document(schoolId)
                    .collection("classes").document(cls.id)
                    .collection("daily_reports").get().await()
                val classDays = JSONObject()
                repSnap.documents.forEach { rd ->
                    val dateKey = rd.getString("date") ?: rd.id
                    val rowsMap = rd.get("rows") as? Map<*, *> ?: emptyMap<String, Any>()
                    val rowsJson = JSONObject()
                    rowsMap.forEach { (k, v) ->
                        val rowMap = v as? Map<*, *> ?: return@forEach
                        val rObj = JSONObject()
                        rowMap.forEach { (rk, rv) -> if (rv != null) rObj.put(rk.toString(), rv) }
                        rowsJson.put(k.toString(), rObj)
                    }
                    classDays.put(dateKey, JSONObject().apply {
                        put("sotd", rd.getString("sotd") ?: "")
                        put("rows", rowsJson)
                    })
                }
                daysObj.put(cls.id, classDays)
            }

            val root = JSONObject().apply {
                put("v", 2)
                put("meta", JSONObject().apply {
                    put("title", school.title)
                    put("centre", school.centre)
                    put("active", school.activeClassId)
                    put("next", school.nextClassNum)
                    put("classes", classesArr)
                })
                put("rosters", rostersObj)
                put("days", daysObj)
            }
            Result.success(root.toString(2))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    private fun logIfSignedIn(error: Throwable, op: OperationType, path: String, uid: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val ex = firestoreError ?: (error as? Exception)
        if (ex != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(ex, op, path)
        }
    }
}
