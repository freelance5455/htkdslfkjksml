package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AdminConfig
import com.example.data.model.BedrockPlayer
import com.example.data.model.ServerState
import com.example.data.model.ServerStatusData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ChaufalandRepository(context: Context) {

  private val prefs: SharedPreferences =
    context.getSharedPreferences("chaufaland_prefs", Context.MODE_PRIVATE)

  private val client: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(8, TimeUnit.SECONDS)
    .readTimeout(10, TimeUnit.SECONDS)
    .build()

  companion object {
    const val KEY_GAMERTAG = "saved_gamertag"
    const val KEY_SERVER_TYPE = "admin_server_type"
    const val KEY_EXAROTON_TOKEN = "admin_exaroton_token"
    const val KEY_EXAROTON_SERVER_ID = "admin_exaroton_server_id"
    const val KEY_SECONDARY_IP = "admin_secondary_ip"
    const val KEY_SECONDARY_IS_BEDROCK = "admin_secondary_is_bedrock"
    const val KEY_WS_BRIDGE_URL = "admin_ws_bridge_url"
  }

  fun getGamerTag(): String {
    return prefs.getString(KEY_GAMERTAG, "") ?: ""
  }

  fun saveGamerTag(tag: String) {
    prefs.edit().putString(KEY_GAMERTAG, tag.trim()).apply()
  }

  fun getAdminConfig(): AdminConfig {
    return AdminConfig(
      serverType = prefs.getString(KEY_SERVER_TYPE, "exaroton") ?: "exaroton",
      exarotonToken = prefs.getString(KEY_EXAROTON_TOKEN, "") ?: "",
      exarotonServerId = prefs.getString(KEY_EXAROTON_SERVER_ID, "") ?: "",
      secondaryServerIp = prefs.getString(KEY_SECONDARY_IP, "chaufaland.aternos.me:19132") ?: "chaufaland.aternos.me:19132",
      isSecondaryBedrock = prefs.getBoolean(KEY_SECONDARY_IS_BEDROCK, true),
      wsBridgeUrl = prefs.getString(KEY_WS_BRIDGE_URL, "ws://10.0.2.2:3000/ws/minecraft") ?: "ws://10.0.2.2:3000/ws/minecraft"
    )
  }

  fun saveAdminConfig(cfg: AdminConfig) {
    prefs.edit()
      .putString(KEY_SERVER_TYPE, cfg.serverType)
      .putString(KEY_EXAROTON_TOKEN, cfg.exarotonToken)
      .putString(KEY_EXAROTON_SERVER_ID, cfg.exarotonServerId)
      .putString(KEY_SECONDARY_IP, cfg.secondaryServerIp)
      .putBoolean(KEY_SECONDARY_IS_BEDROCK, cfg.isSecondaryBedrock)
      .putString(KEY_WS_BRIDGE_URL, cfg.wsBridgeUrl)
      .apply()
  }

  suspend fun fetchExarotonServerStatus(token: String, serverId: String): Result<ServerStatusData> =
    withContext(Dispatchers.IO) {
      if (token.isBlank() || serverId.isBlank()) {
        return@withContext Result.failure(Exception("Token o ID de Exaroton no configurado en el Panel Admin."))
      }

      try {
        val request = Request.Builder()
          .url("https://api.exaroton.com/v1/servers/$serverId")
          .header("Authorization", "Bearer $token")
          .build()

        client.newCall(request).execute().use { response ->
          val bodyStr = response.body?.string() ?: ""
          if (!response.isSuccessful) {
            return@withContext Result.failure(Exception("Error Exaroton (${response.code}): $bodyStr"))
          }

          val root = JSONObject(bodyStr)
          val data = root.optJSONObject("data") ?: root

          val statusCode = data.optInt("status", 0)
          val state = when (statusCode) {
            0 -> ServerState.OFFLINE
            1 -> ServerState.ONLINE
            2 -> ServerState.STARTING
            3 -> ServerState.STOPPING
            4 -> ServerState.RESTARTING
            else -> ServerState.UNKNOWN
          }

          val host = data.optString("address", "exaroton.me")
          val motd = data.optString("motd", "Chaufaland Exaroton Server")

          val playersObj = data.optJSONObject("players")
          val onlineCount = playersObj?.optInt("count", 0) ?: 0
          val maxCount = playersObj?.optInt("max", 20) ?: 20
          val namesList = mutableListOf<String>()
          val listArr = playersObj?.optJSONArray("list")
          if (listArr != null) {
            for (i in 0 until listArr.length()) {
              namesList.add(listArr.optString(i))
            }
          }

          Result.success(
            ServerStatusData(
              state = state,
              tps = if (state == ServerState.ONLINE) 20.0 else 0.0,
              onlinePlayers = onlineCount,
              maxPlayers = maxCount,
              playerNames = namesList,
              motd = motd,
              serverType = "exaroton",
              serverHost = host
            )
          )
        }
      } catch (e: Exception) {
        Result.failure(e)
      }
    }

  suspend fun fetchMcsrvstatStatus(ip: String, isBedrock: Boolean): Result<ServerStatusData> =
    withContext(Dispatchers.IO) {
      if (ip.isBlank()) {
        return@withContext Result.failure(Exception("IP de servidor no especificada."))
      }

      try {
        val url = if (isBedrock) {
          "https://api.mcsrvstat.us/bedrock/2/$ip"
        } else {
          "https://api.mcsrvstat.us/2/$ip"
        }

        val request = Request.Builder().url(url).build()

        client.newCall(request).execute().use { response ->
          val bodyStr = response.body?.string() ?: ""
          if (!response.isSuccessful) {
            return@withContext Result.failure(Exception("Error mcsrvstat.us: ${response.code}"))
          }

          val json = JSONObject(bodyStr)
          val isOnline = json.optBoolean("online", false)
          val state = if (isOnline) ServerState.ONLINE else ServerState.OFFLINE

          val motdObj = json.optJSONObject("motd")
          val cleanMotd = motdObj?.optJSONArray("clean")?.optString(0)
            ?: json.optString("hostname", ip)

          val playersObj = json.optJSONObject("players")
          val online = playersObj?.optInt("online", 0) ?: 0
          val max = playersObj?.optInt("max", 20) ?: 20
          val list = mutableListOf<String>()
          val listArr = playersObj?.optJSONArray("list")
          if (listArr != null) {
            for (i in 0 until listArr.length()) {
              list.add(listArr.optString(i))
            }
          }

          Result.success(
            ServerStatusData(
              state = state,
              tps = if (isOnline) 20.0 else 0.0,
              onlinePlayers = online,
              maxPlayers = max,
              playerNames = list,
              motd = cleanMotd,
              serverType = "aternos",
              serverHost = ip
            )
          )
        }
      } catch (e: Exception) {
        Result.failure(e)
      }
    }

  suspend fun executeExarotonAction(token: String, serverId: String, action: String): Result<String> =
    withContext(Dispatchers.IO) {
      try {
        val request = Request.Builder()
          .url("https://api.exaroton.com/v1/servers/$serverId/$action")
          .header("Authorization", "Bearer $token")
          .post("{}".toRequestBody("application/json".toMediaType()))
          .build()

        client.newCall(request).execute().use { response ->
          val bodyStr = response.body?.string() ?: ""
          if (response.isSuccessful) {
            Result.success("Comando '$action' enviado al servidor")
          } else {
            Result.failure(Exception("Error Exaroton: $bodyStr"))
          }
        }
      } catch (e: Exception) {
        Result.failure(e)
      }
    }

  suspend fun sendExarotonCommand(token: String, serverId: String, command: String): Result<String> =
    withContext(Dispatchers.IO) {
      try {
        val json = JSONObject().put("command", command)
        val request = Request.Builder()
          .url("https://api.exaroton.com/v1/servers/$serverId/command")
          .header("Authorization", "Bearer $token")
          .post(json.toString().toRequestBody("application/json".toMediaType()))
          .build()

        client.newCall(request).execute().use { response ->
          val bodyStr = response.body?.string() ?: ""
          if (response.isSuccessful) {
            Result.success("Comando ejecutado")
          } else {
            Result.failure(Exception("Error al enviar comando: $bodyStr"))
          }
        }
      } catch (e: Exception) {
        Result.failure(e)
      }
    }

  suspend fun fetchBedrockBridgePlayers(bridgeUrl: String): Result<List<BedrockPlayer>> =
    withContext(Dispatchers.IO) {
      try {
        // HTTP fallback para obtener jugadores del bridge
        val httpUrl = bridgeUrl
          .replace("ws://", "http://")
          .replace("wss://", "https://")
          .replace("/ws/minecraft", "/api/minecraft/players")
          .replace("/ws-addon", "/api/minecraft/players")

        val request = Request.Builder().url(httpUrl).build()
        client.newCall(request).execute().use { response ->
          if (!response.isSuccessful) return@withContext Result.success(emptyList())
          val bodyStr = response.body?.string() ?: ""
          val json = JSONObject(bodyStr)
          val playersArray = json.optJSONArray("players") ?: return@withContext Result.success(emptyList())
          val list = mutableListOf<BedrockPlayer>()
          for (i in 0 until playersArray.length()) {
            val item = playersArray.getJSONObject(i)
            list.add(
              BedrockPlayer(
                gamerTag = item.optString("gamertag"),
                x = item.optDouble("x", 0.0),
                y = item.optDouble("y", 0.0),
                z = item.optDouble("z", 0.0),
                dimension = item.optString("dimension", "overworld"),
                health = item.optInt("health", 20)
              )
            )
          }
          Result.success(list)
        }
      } catch (e: Exception) {
        Result.success(emptyList())
      }
    }
}
