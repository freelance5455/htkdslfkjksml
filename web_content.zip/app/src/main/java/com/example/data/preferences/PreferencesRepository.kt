package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.engine.AngleMode
import com.example.engine.FormattingOptions
import com.example.engine.NumberGroupingStyle
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.math.BigDecimal

private val Context.aetherDataStore: DataStore<Preferences> by preferencesDataStore(name = "aether_calc_prefs")

data class UserPreferences(
  val themeMode: AppThemeMode = AppThemeMode.OLED_DARK,
  val hapticEnabled: Boolean = true,
  val groupingStyle: NumberGroupingStyle = NumberGroupingStyle.COMMA,
  val decimalPrecision: Int = -1, // -1 = Auto
  val angleMode: AngleMode = AngleMode.DEG,
  val memoryValue: BigDecimal? = null,
) {
  val formattingOptions: FormattingOptions
    get() = FormattingOptions(grouping = groupingStyle, decimalPrecision = decimalPrecision)
}

interface PreferencesDataSource {
  val preferences: Flow<UserPreferences>

  suspend fun setThemeMode(mode: AppThemeMode)

  suspend fun setHapticEnabled(enabled: Boolean)

  suspend fun setGroupingStyle(style: NumberGroupingStyle)

  suspend fun setDecimalPrecision(precision: Int)

  suspend fun setAngleMode(mode: AngleMode)

  suspend fun setMemoryValue(value: BigDecimal?)
}

class PreferencesRepository(private val context: Context) : PreferencesDataSource {

  private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val HAPTIC_ENABLED = booleanPreferencesKey("haptic_enabled")
    val GROUPING_STYLE = stringPreferencesKey("grouping_style")
    val DECIMAL_PRECISION = intPreferencesKey("decimal_precision")
    val ANGLE_MODE = stringPreferencesKey("angle_mode")
    val MEMORY_VALUE = stringPreferencesKey("memory_value")
  }

  override val preferences: Flow<UserPreferences> =
    context.aetherDataStore.data.map { prefs ->
      val theme =
        prefs[Keys.THEME_MODE]?.let { name -> AppThemeMode.entries.find { it.name == name } }
          ?: AppThemeMode.OLED_DARK
      val haptics = prefs[Keys.HAPTIC_ENABLED] ?: true
      val grouping =
        prefs[Keys.GROUPING_STYLE]?.let { name -> NumberGroupingStyle.entries.find { it.name == name } }
          ?: NumberGroupingStyle.COMMA
      val precision = prefs[Keys.DECIMAL_PRECISION] ?: -1
      val angle =
        prefs[Keys.ANGLE_MODE]?.let { name -> AngleMode.entries.find { it.name == name } }
          ?: AngleMode.DEG
      val memory = prefs[Keys.MEMORY_VALUE]?.toBigDecimalOrNull()
      UserPreferences(
        themeMode = theme,
        hapticEnabled = haptics,
        groupingStyle = grouping,
        decimalPrecision = precision,
        angleMode = angle,
        memoryValue = memory,
      )
    }

  override suspend fun setThemeMode(mode: AppThemeMode) {
    context.aetherDataStore.edit { it[Keys.THEME_MODE] = mode.name }
  }

  override suspend fun setHapticEnabled(enabled: Boolean) {
    context.aetherDataStore.edit { it[Keys.HAPTIC_ENABLED] = enabled }
  }

  override suspend fun setGroupingStyle(style: NumberGroupingStyle) {
    context.aetherDataStore.edit { it[Keys.GROUPING_STYLE] = style.name }
  }

  override suspend fun setDecimalPrecision(precision: Int) {
    context.aetherDataStore.edit { it[Keys.DECIMAL_PRECISION] = precision }
  }

  override suspend fun setAngleMode(mode: AngleMode) {
    context.aetherDataStore.edit { it[Keys.ANGLE_MODE] = mode.name }
  }

  override suspend fun setMemoryValue(value: BigDecimal?) {
    context.aetherDataStore.edit { prefs ->
      if (value == null) {
        prefs.remove(Keys.MEMORY_VALUE)
      } else {
        prefs[Keys.MEMORY_VALUE] = value.toPlainString()
      }
    }
  }
}
