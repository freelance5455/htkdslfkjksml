package com.example.data.export

import android.content.Context
import com.example.data.model.ReportPreview
import com.example.utils.DateFormatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ExcelExporter(private val context: Context) {

    private val exportsDir: File
        get() = File(context.filesDir, "exports").apply { if (!exists()) mkdirs() }

    suspend fun exportReportToXlsx(
        report: ReportPreview,
        fromDate: String,
        toDate: String,
    ): File = withContext(Dispatchers.IO) {
        val fileName = "SD_TRAVEL_Report_${report.reportType.id}_${DateFormatters.fileTimestamp()}.xlsx"
        val outFile = File(exportsDir, fileName)

        val sharedStrings = mutableListOf<String>()
        val stringIndexMap = LinkedHashMap<String, Int>()

        fun intern(text: String): Int {
            return stringIndexMap.getOrPut(text) {
                val idx = sharedStrings.size
                sharedStrings.add(text)
                idx
            }
        }

        val rowsXml = StringBuilder()
        var currentRow = 1

        // Title row
        val titleIdx = intern("SD TRAVEL - ${report.title}")
        rowsXml.append("""<row r="$currentRow" ht="26" customHeight="1"><c r="A$currentRow" t="s" s="1"><v>$titleIdx</v></c></row>""")
        currentRow++

        // Filter subtitle row
        val periodText = buildString {
            append("تاريخ التصدير: ${DateFormatters.todayIso()}")
            if (fromDate.isNotBlank() || toDate.isNotBlank()) {
                append(" | الفترة: ")
                append(fromDate.ifBlank { "البداية" })
                append(" إلى ")
                append(toDate.ifBlank { "النهاية" })
            }
        }
        val periodIdx = intern(periodText)
        rowsXml.append("""<row r="$currentRow" ht="20" customHeight="1"><c r="A$currentRow" t="s" s="2"><v>$periodIdx</v></c></row>""")
        currentRow++

        // Summary metrics row if present
        if (report.summaryMetrics.isNotEmpty()) {
            val summaryText = report.summaryMetrics.joinToString("  |  ") { "${it.first}: ${it.second}" }
            val sumIdx = intern(summaryText)
            rowsXml.append("""<row r="$currentRow" ht="20" customHeight="1"><c r="A$currentRow" t="s" s="2"><v>$sumIdx</v></c></row>""")
            currentRow++
        }

        currentRow++ // blank spacer row

        // Column headers row
        val colCount = report.headers.size.coerceAtLeast(1)
        val colWidths = IntArray(colCount) { idx ->
            report.headers.getOrNull(idx)?.length?.plus(6)?.coerceIn(14, 38) ?: 16
        }

        rowsXml.append("""<row r="$currentRow" ht="24" customHeight="1">""")
        report.headers.forEachIndexed { colIdx, header ->
            val cellRef = "${columnLetter(colIdx)}$currentRow"
            val strIdx = intern(header)
            rowsXml.append("""<c r="$cellRef" t="s" s="1"><v>$strIdx</v></c>""")
        }
        rowsXml.append("</row>")
        currentRow++

        // Data rows
        report.rows.forEachIndexed { rowOffset, rowValues ->
            val styleIdx = if (rowOffset % 2 == 0) 3 else 4
            rowsXml.append("""<row r="$currentRow" ht="20" customHeight="1">""")
            for (colIdx in 0 until colCount) {
                val cellVal = rowValues.getOrNull(colIdx).orEmpty()
                colWidths[colIdx] = maxOf(colWidths[colIdx], (cellVal.length + 4).coerceAtMost(42))
                val cellRef = "${columnLetter(colIdx)}$currentRow"
                val strIdx = intern(cellVal)
                rowsXml.append("""<c r="$cellRef" t="s" s="$styleIdx"><v>$strIdx</v></c>""")
            }
            rowsXml.append("</row>")
            currentRow++
        }

        val colsXml = buildString {
            append("<cols>")
            colWidths.forEachIndexed { idx, width ->
                val colNum = idx + 1
                append("""<col min="$colNum" max="$colNum" width="$width" customWidth="1"/>""")
            }
            append("</cols>")
        }

        val sheetXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetViews>
    <sheetView workbookViewId="0" rightToLeft="1"/>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="20"/>
  $colsXml
  <sheetData>$rowsXml</sheetData>
</worksheet>"""

        val sharedStringsXml = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            append("""<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${sharedStrings.size}" uniqueCount="${sharedStrings.size}">""")
            sharedStrings.forEach { text ->
                append("<si><t xml:space=\"preserve\">${escapeXml(text)}</t></si>")
            }
            append("</sst>")
        }

        ZipOutputStream(FileOutputStream(outFile)).use { zip ->
            writeZipEntry(zip, "[Content_Types].xml", CONTENT_TYPES_XML)
            writeZipEntry(zip, "_rels/.rels", RELS_XML)
            writeZipEntry(zip, "xl/workbook.xml", WORKBOOK_XML)
            writeZipEntry(zip, "xl/_rels/workbook.xml.rels", WORKBOOK_RELS_XML)
            writeZipEntry(zip, "xl/styles.xml", STYLES_XML)
            writeZipEntry(zip, "xl/sharedStrings.xml", sharedStringsXml)
            writeZipEntry(zip, "xl/worksheets/sheet1.xml", sheetXml)
        }

        outFile
    }

    private fun writeZipEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun columnLetter(index: Int): String {
        var i = index
        val sb = StringBuilder()
        while (i >= 0) {
            sb.insert(0, ('A'.code + (i % 26)).toChar())
            i = (i / 26) - 1
        }
        return sb.toString()
    }

    private fun escapeXml(input: String): String = buildString(input.length) {
        for (ch in input) {
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> if (ch.code >= 0x20 || ch == '\n' || ch == '\r' || ch == '\t') append(ch)
            }
        }
    }

    companion object {
        private const val CONTENT_TYPES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
  <Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>"""

        private const val RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

        private const val WORKBOOK_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="تقرير SD TRAVEL" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>"""

        private const val WORKBOOK_RELS_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>"""

        private const val STYLES_XML = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="3">
    <font><sz val="11"/><name val="Arial"/></font>
    <font><b/><sz val="12"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
    <font><b/><sz val="11"/><color rgb="FF0B1F3A"/><name val="Arial"/></font>
  </fonts>
  <fills count="5">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF0B1F3A"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFFDF6DF"/></patternFill></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FFF4F6F9"/></patternFill></fill>
  </fills>
  <borders count="2">
    <border><left/><right/><top/><bottom/><diagonal/></border>
    <border>
      <left style="thin"><color rgb="FFDCE2EC"/></left>
      <right style="thin"><color rgb="FFDCE2EC"/></right>
      <top style="thin"><color rgb="FFDCE2EC"/></top>
      <bottom style="thin"><color rgb="FFDCE2EC"/></bottom>
      <diagonal/>
    </border>
  </borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="5">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2"/></xf>
    <xf numFmtId="0" fontId="2" fillId="3" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2"/></xf>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2" wrapText="1"/></xf>
    <xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center" readingOrder="2" wrapText="1"/></xf>
  </cellXfs>
</styleSheet>"""
    }
}
