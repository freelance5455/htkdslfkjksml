package com.example.data

import kotlinx.coroutines.flow.Flow

class ScanRepository(private val scanDao: ScanDao) {

    val allScans: Flow<List<ScanItem>> = scanDao.getAllScans()
    val favoriteScans: Flow<List<ScanItem>> = scanDao.getFavoriteScans()

    fun search(query: String): Flow<List<ScanItem>> = scanDao.searchScans(query)

    suspend fun insert(item: ScanItem): Long = scanDao.insertScan(item)

    suspend fun toggleFavorite(id: Long, currentFavorite: Boolean) {
        scanDao.updateFavorite(id, !currentFavorite)
    }

    suspend fun delete(id: Long) {
        scanDao.deleteScan(id)
    }

    suspend fun clearHistory() {
        scanDao.clearAll()
    }
}
