package com.example.data.firebase

import com.example.data.model.Auction
import com.example.data.model.Bid
import com.example.data.model.BusinessAd
import com.example.data.model.UserBidRecord
import com.example.data.model.UserProfile
import com.example.util.FEATURED_AUCTION_FEE_NAIRA
import com.example.util.PLATFORM_COMMISSION_RATE
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.Date
import java.util.UUID

class AuctionRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    fun observeAllAuctions(): Flow<List<Auction>> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("auctions")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Auction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(
                        compareByDescending<Auction> { it.featured }
                            .thenByDescending { it.createdAt?.toDate()?.time ?: 0L }
                    )
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "auctions", expectedUid)
            }
    }

    fun observeAuction(auctionId: String): Flow<Auction?> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("auctions").document(auctionId)
            .snapshots()
            .map { snapshot ->
                if (!snapshot.exists()) null
                else snapshot.toObject(Auction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.GET, "auctions/$auctionId", expectedUid)
            }
    }

    fun observeAuctionBids(auctionId: String): Flow<List<Bid>> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("auctions").document(auctionId).collection("bids")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Bid::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.amount }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "auctions/$auctionId/bids", expectedUid)
            }
    }

    fun observeUserBidRecords(userId: String): Flow<List<UserBidRecord>> =
        db.collection("users").document(userId).collection("bid_records")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(UserBidRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "users/$userId/bid_records", userId)
            }

    fun observeActiveBusinessAds(): Flow<List<BusinessAd>> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("business_ads")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(BusinessAd::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .filter { it.status == "ACTIVE" }
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "business_ads", expectedUid)
            }
    }

    suspend fun createAuction(
        profile: UserProfile,
        title: String,
        description: String,
        category: String,
        imageItems: List<String>,
        startingBid: Long,
        minIncrement: Long,
        durationHours: Long,
        featureListing: Boolean
    ): Result<String> {
        val path = "auctions"
        return try {
            val uid = requireUserId()
            check(uid == profile.userId) { "Signed-in user mismatch." }
            require(profile.accountStatus == "ACTIVE") { "Account is suspended." }
            val cleanTitle = title.trim()
            val cleanDesc = description.trim()
            require(cleanTitle.length in 3..120) { "Title must be 3–120 characters." }
            require(cleanDesc.length in 5..1500) { "Description must be 5–1500 characters." }
            require(startingBid >= 100L) { "Starting bid must be at least ₦100." }
            require(minIncrement >= 100L) { "Minimum increment must be at least ₦100." }
            require(durationHours >= 1L) { "Duration must be at least 1 hour." }

            val safeImages = imageItems.take(4)
            val endsAt = Timestamp(Date(System.currentTimeMillis() + durationHours * 3600_000L))
            val auctionRef = db.collection("auctions").document()
            val walletRef = db.collection("wallets").document(uid)
            val txRef = db.collection("wallet_transactions").document()
            val refCode = "TA-FEA-${UUID.randomUUID().toString().take(6).uppercase()}"

            db.runTransaction { tx ->
                if (featureListing) {
                    val walletSnap = tx.get(walletRef)
                    val balance = walletSnap.getLong("availableBalance") ?: 0L
                    require(balance >= FEATURED_AUCTION_FEE_NAIRA) {
                        "Insufficient wallet balance for ₦2,000 Featured Auction fee. Please fund your wallet first."
                    }
                    tx.update(
                        walletRef,
                        mapOf(
                            "availableBalance" to balance - FEATURED_AUCTION_FEE_NAIRA,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    tx.set(
                        txRef,
                        mapOf(
                            "userId" to uid,
                            "auctionId" to auctionRef.id,
                            "type" to "FEATURED_FEE",
                            "amount" to FEATURED_AUCTION_FEE_NAIRA,
                            "feeAmount" to FEATURED_AUCTION_FEE_NAIRA,
                            "description" to "Featured Auction placement for $cleanTitle".take(240),
                            "status" to "COMPLETED",
                            "referenceCode" to refCode,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )
                }

                tx.set(
                    auctionRef,
                    mapOf(
                        "sellerId" to uid,
                        "sellerName" to profile.displayName.ifBlank { "Seller" }.take(80),
                        "sellerBidderNumber" to profile.bidderNumber.ifBlank { "TA-0000" }.take(20),
                        "title" to cleanTitle,
                        "description" to cleanDesc,
                        "category" to category.trim().ifBlank { "Collectibles" }.take(40),
                        "imageItems" to safeImages,
                        "startingBid" to startingBid,
                        "minIncrement" to minIncrement,
                        "currentBid" to 0L,
                        "bidCount" to 0L,
                        "highestBidderId" to "",
                        "highestBidderNumber" to "",
                        "featured" to featureListing,
                        "featuredFeePaid" to if (featureListing) FEATURED_AUCTION_FEE_NAIRA else 0L,
                        "commissionRate" to PLATFORM_COMMISSION_RATE,
                        "commissionAmount" to 0L,
                        "sellerPayout" to 0L,
                        "status" to "ACTIVE",
                        "endsAt" to endsAt,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            Result.success(auctionRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun upgradeAuctionToFeatured(userId: String, auctionId: String, title: String): Result<Unit> {
        val path = "auctions/$auctionId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch." }
            val auctionRef = db.collection("auctions").document(auctionId)
            val walletRef = db.collection("wallets").document(uid)
            val txRef = db.collection("wallet_transactions").document()
            val refCode = "TA-FEA-${UUID.randomUUID().toString().take(6).uppercase()}"

            db.runTransaction { tx ->
                val auctionSnap = tx.get(auctionRef)
                val walletSnap = tx.get(walletRef)
                require(auctionSnap.exists()) { "Auction no longer exists." }
                require(auctionSnap.getString("sellerId") == uid) { "Only the seller can feature this auction." }
                require(auctionSnap.getString("status") == "ACTIVE") { "Only active auctions can be featured." }
                require(auctionSnap.getBoolean("featured") != true) { "Auction is already featured." }

                val balance = walletSnap.getLong("availableBalance") ?: 0L
                require(balance >= FEATURED_AUCTION_FEE_NAIRA) {
                    "Insufficient balance for ₦2,000 Featured fee. Please fund your wallet."
                }

                tx.update(
                    walletRef,
                    mapOf(
                        "availableBalance" to balance - FEATURED_AUCTION_FEE_NAIRA,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.update(
                    auctionRef,
                    mapOf(
                        "featured" to true,
                        "featuredFeePaid" to FEATURED_AUCTION_FEE_NAIRA,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.set(
                    txRef,
                    mapOf(
                        "userId" to uid,
                        "auctionId" to auctionId,
                        "type" to "FEATURED_FEE",
                        "amount" to FEATURED_AUCTION_FEE_NAIRA,
                        "feeAmount" to FEATURED_AUCTION_FEE_NAIRA,
                        "description" to "Featured upgrade for $title".take(240),
                        "status" to "COMPLETED",
                        "referenceCode" to refCode,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun placeBid(
        auctionId: String,
        bidderProfile: UserProfile,
        amount: Long
    ): Result<Unit> {
        val path = "auctions/$auctionId"
        return try {
            val uid = requireUserId()
            check(uid == bidderProfile.userId) { "Signed-in user mismatch." }
            require(bidderProfile.accountStatus == "ACTIVE") { "Suspended accounts cannot place bids." }
            require(amount >= 100L) { "Bid must be at least ₦100." }

            val auctionRef = db.collection("auctions").document(auctionId)
            val bidRef = auctionRef.collection("bids").document()
            val bidRecordRef = db.collection("users").document(uid)
                .collection("bid_records").document(auctionId)

            db.runTransaction { tx ->
                val auctionSnap = tx.get(auctionRef)
                val recordSnap = tx.get(bidRecordRef)
                require(auctionSnap.exists()) { "Auction does not exist." }

                val status = auctionSnap.getString("status") ?: "ENDED"
                val sellerId = auctionSnap.getString("sellerId") ?: ""
                val endsAt = auctionSnap.getTimestamp("endsAt")
                val bidCount = auctionSnap.getLong("bidCount") ?: 0L
                val currentBid = auctionSnap.getLong("currentBid") ?: 0L
                val startingBid = auctionSnap.getLong("startingBid") ?: 0L
                val minIncrement = auctionSnap.getLong("minIncrement") ?: 100L
                val title = auctionSnap.getString("title") ?: "Auction Lot"
                @Suppress("UNCHECKED_CAST")
                val images = auctionSnap.get("imageItems") as? List<String> ?: emptyList()

                require(status == "ACTIVE") { "Auction is not currently accepting bids." }
                require(endsAt != null && endsAt.toDate().time > System.currentTimeMillis()) {
                    "Auction countdown has ended."
                }
                require(sellerId != uid) { "Sellers cannot bid on their own lots." }

                val minRequired = if (bidCount == 0L) startingBid else currentBid + minIncrement
                require(amount >= minRequired) { "Bid must be at least ₦$minRequired." }

                tx.update(
                    auctionRef,
                    mapOf(
                        "currentBid" to amount,
                        "bidCount" to bidCount + 1L,
                        "highestBidderId" to uid,
                        "highestBidderNumber" to bidderProfile.bidderNumber,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.set(
                    bidRef,
                    mapOf(
                        "auctionId" to auctionId,
                        "bidderId" to uid,
                        "bidderNumber" to bidderProfile.bidderNumber,
                        "amount" to amount,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )

                val firstImage = images.firstOrNull() ?: "preset:chronograph"
                if (recordSnap.exists()) {
                    val prevCount = recordSnap.getLong("bidCount") ?: 0L
                    val prevMax = recordSnap.getLong("myHighestBid") ?: 0L
                    tx.update(
                        bidRecordRef,
                        mapOf(
                            "auctionTitle" to title.take(120),
                            "imageItem" to firstImage,
                            "myHighestBid" to maxOf(prevMax, amount),
                            "bidCount" to prevCount + 1L,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    tx.set(
                        bidRecordRef,
                        mapOf(
                            "auctionId" to auctionId,
                            "auctionTitle" to title.take(120),
                            "imageItem" to firstImage,
                            "myHighestBid" to amount,
                            "bidCount" to 1L,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun cancelAuctionBeforeBids(userId: String, auctionId: String): Result<Unit> {
        val path = "auctions/$auctionId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "Signed-in user mismatch." }
            db.collection("auctions").document(auctionId).update(
                mapOf(
                    "status" to "CANCELLED",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun settleWonAuction(winnerUid: String, auctionId: String): Result<Unit> {
        val path = "auctions/$auctionId"
        return try {
            val uid = requireUserId()
            check(uid == winnerUid) { "Only the winning bidder can authorize payment." }

            val auctionRef = db.collection("auctions").document(auctionId)
            val buyerWalletRef = db.collection("wallets").document(uid)
            val buyerTxRef = db.collection("wallet_transactions").document()
            val sellerTxRef = db.collection("wallet_transactions").document()
            val refPrefix = UUID.randomUUID().toString().take(6).uppercase()

            db.runTransaction { tx ->
                val auctionSnap = tx.get(auctionRef)
                require(auctionSnap.exists()) { "Auction not found." }
                val sellerId = auctionSnap.getString("sellerId") ?: ""
                val highestBidderId = auctionSnap.getString("highestBidderId") ?: ""
                val status = auctionSnap.getString("status") ?: ""
                val bidCount = auctionSnap.getLong("bidCount") ?: 0L
                val currentBid = auctionSnap.getLong("currentBid") ?: 0L
                val title = auctionSnap.getString("title") ?: "Auction Lot"

                require(highestBidderId == uid) { "Only the highest bidder can settle this lot." }
                require(bidCount > 0L && currentBid > 0L) { "No winning bids on this lot." }
                require(status == "ACTIVE" || status == "ENDED") { "Lot is already $status." }

                val sellerWalletRef = db.collection("wallets").document(sellerId)
                val buyerWalletSnap = tx.get(buyerWalletRef)
                val sellerWalletSnap = tx.get(sellerWalletRef)

                val buyerAvailable = buyerWalletSnap.getLong("availableBalance") ?: 0L
                require(buyerAvailable >= currentBid) {
                    "Insufficient wallet balance (need ₦$currentBid). Please fund your wallet first."
                }
                require(sellerWalletSnap.exists()) { "Seller wallet not initialized." }

                val sellerAvailable = sellerWalletSnap.getLong("availableBalance") ?: 0L
                val sellerEarned = sellerWalletSnap.getLong("totalEarned") ?: 0L
                val sellerCommPaid = sellerWalletSnap.getLong("totalCommissionPaid") ?: 0L

                val commissionAmount = (currentBid * PLATFORM_COMMISSION_RATE) / 100L
                val sellerPayout = currentBid - commissionAmount

                tx.update(
                    auctionRef,
                    mapOf(
                        "status" to "SETTLED",
                        "commissionAmount" to commissionAmount,
                        "sellerPayout" to sellerPayout,
                        "settledAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.update(
                    buyerWalletRef,
                    mapOf(
                        "availableBalance" to buyerAvailable - currentBid,
                        "lastSettledAuctionId" to auctionId,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.update(
                    sellerWalletRef,
                    mapOf(
                        "availableBalance" to sellerAvailable + sellerPayout,
                        "totalEarned" to sellerEarned + sellerPayout,
                        "totalCommissionPaid" to sellerCommPaid + commissionAmount,
                        "lastSettledAuctionId" to auctionId,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.set(
                    buyerTxRef,
                    mapOf(
                        "userId" to uid,
                        "counterpartyId" to sellerId,
                        "auctionId" to auctionId,
                        "type" to "AUCTION_PAYMENT",
                        "amount" to currentBid,
                        "feeAmount" to 0L,
                        "description" to "Escrow settlement for $title".take(240),
                        "status" to "COMPLETED",
                        "referenceCode" to "TA-PAY-$refPrefix",
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                tx.set(
                    sellerTxRef,
                    mapOf(
                        "userId" to sellerId,
                        "counterpartyId" to uid,
                        "auctionId" to auctionId,
                        "type" to "SELLER_PAYOUT",
                        "amount" to sellerPayout,
                        "feeAmount" to commissionAmount,
                        "description" to "Payout for $title (3% commission: ₦$commissionAmount)".take(240),
                        "status" to "COMPLETED",
                        "referenceCode" to "TA-SET-$refPrefix",
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private fun logAndRethrowFlowError(
        error: Throwable,
        op: OperationType,
        path: String,
        expectedUid: String?
    ): Nothing {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && expectedUid != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
        throw error
    }
}
