package com.example.data.models

enum class ChatLanguage(val displayName: String, val code: String, val scriptSample: String) {
    ENGLISH("English", "en", "Hello! How can I assist you today?"),
    HINDI("हिन्दी", "hi", "नमस्ते! आज मैं आपकी क्या सहायता कर सकता हूँ?"),
    HINGLISH("Hinglish", "hinglish", "Kaisey ho dost! Aaj kya naya create karna chahte ho?"),
    KASHMIRI("کٲشُر (कॉशुर)", "ks", "السلام علیکم! کیا کرِہ ژہ مدَتھ؟ (Assalam-o-Alaikum! Kya kari tsi madad?)")
}

enum class MessageSender {
    USER, AI
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val imageUrl: String? = null,
    val language: ChatLanguage = ChatLanguage.HINGLISH
)

data class ChatSession(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val timestamp: Long = System.currentTimeMillis(),
    val messages: List<ChatMessage> = emptyList()
)

enum class MediaType {
    IMAGE, VIDEO, AUDIO
}

data class MediaItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val prompt: String,
    val type: MediaType,
    val mediaUrl: String,
    val thumbnailUrl: String = mediaUrl,
    val videoMotionType: String? = null,
    val voiceName: String? = null,
    val language: String? = null,
    val durationSeconds: Int? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class VoiceProfile(
    val id: String,
    val name: String,
    val language: ChatLanguage,
    val gender: String,
    val description: String,
    val defaultPitch: Float = 1.0f,
    val defaultSpeed: Float = 1.0f,
    val sampleText: String
)

data class UserAccount(
    val isLoggedIn: Boolean = true,
    val name: String = "Hazim Qadir",
    val email: String = "hazimqadir7@gmail.com",
    val avatarUrl: String? = null,
    val authProvider: String = "Google",
    val isPro: Boolean = true
)

enum class ScreenDestination {
    CHAT,
    TEXT_TO_IMAGE,
    IMAGE_TO_VIDEO,
    SPEECH_TO_VOICE,
    GALLERY,
    PROFILE
}
