package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "study_sessions",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("subjectId"), Index("date")]
)
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val date: String,             // ISO-8601 Date string "YYYY-MM-DD"
    val startTime: String,        // 24-hour time "HH:mm"
    val durationMinutes: Int,     // Total study duration in minutes
    val topic: String? = null,    // Optional topic / chapter name
    val remark: String? = null,   // Optional short notes or remarks
    val createdAt: Long = System.currentTimeMillis()
)
