package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.model.ClientWithBookings
import kotlinx.coroutines.flow.Flow

@Dao
interface SdTravelDao {

    @Transaction
    @Query("SELECT * FROM clients ORDER BY createdAt DESC")
    fun getAllClientsWithBookingsFlow(): Flow<List<ClientWithBookings>>

    @Transaction
    @Query("SELECT * FROM clients WHERE id = :clientId LIMIT 1")
    fun getClientWithBookingsFlow(clientId: Long): Flow<ClientWithBookings?>

    @Transaction
    @Query("SELECT * FROM clients WHERE id = :clientId LIMIT 1")
    suspend fun getClientWithBookingsOnce(clientId: Long): ClientWithBookings?

    @Query("SELECT * FROM clients WHERE LOWER(TRIM(clientCode)) = LOWER(TRIM(:code)) LIMIT 1")
    suspend fun getClientByCode(code: String): ClientEntity?

    @Query("SELECT * FROM clients WHERE id = :id LIMIT 1")
    suspend fun getClientById(id: Long): ClientEntity?

    @Query("SELECT * FROM clients ORDER BY createdAt DESC")
    suspend fun getAllClientsOnce(): List<ClientEntity>

    @Query("SELECT * FROM bookings ORDER BY tripDate ASC")
    suspend fun getAllBookingsOnce(): List<BookingEntity>

    @Query("SELECT * FROM payments ORDER BY paymentDate DESC")
    suspend fun getAllPaymentsOnce(): List<PaymentEntity>

    @Query("SELECT * FROM documents ORDER BY createdAt DESC")
    suspend fun getAllDocumentsOnce(): List<DocumentEntity>

    @Query("SELECT * FROM documents WHERE bookingId = :bookingId")
    suspend fun getDocumentsForBookingOnce(bookingId: Long): List<DocumentEntity>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertClient(client: ClientEntity): Long

    @Update
    suspend fun updateClient(client: ClientEntity)

    @Query("DELETE FROM clients WHERE id = :clientId")
    suspend fun deleteClientById(clientId: Long)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertBooking(booking: BookingEntity): Long

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Query("DELETE FROM bookings WHERE id = :bookingId")
    suspend fun deleteBookingById(bookingId: Long)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertPayment(payment: PaymentEntity): Long

    @Update
    suspend fun updatePayment(payment: PaymentEntity)

    @Query("DELETE FROM payments WHERE id = :paymentId")
    suspend fun deletePaymentById(paymentId: Long)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertDocument(document: DocumentEntity): Long

    @Update
    suspend fun updateDocument(document: DocumentEntity)

    @Query("DELETE FROM documents WHERE id = :documentId")
    suspend fun deleteDocumentById(documentId: Long)

    @Transaction
    suspend fun insertClientWithBookingAndDeposit(
        client: ClientEntity,
        booking: BookingEntity,
        depositAmount: Double,
        depositDate: String,
    ): Pair<Long, Long> {
        val clientId = insertClient(client)
        val bookingId = insertBooking(booking.copy(clientId = clientId))
        if (depositAmount > 0.0) {
            insertPayment(
                PaymentEntity(
                    bookingId = bookingId,
                    amount = depositAmount,
                    paymentDate = depositDate,
                    isDeposit = true,
                    notes = "مقدم الحجز",
                )
            )
        }
        return clientId to bookingId
    }

    @Transaction
    suspend fun insertBookingWithDeposit(
        booking: BookingEntity,
        depositAmount: Double,
        depositDate: String,
    ): Long {
        val bookingId = insertBooking(booking)
        if (depositAmount > 0.0) {
            insertPayment(
                PaymentEntity(
                    bookingId = bookingId,
                    amount = depositAmount,
                    paymentDate = depositDate,
                    isDeposit = true,
                    notes = "مقدم الحجز",
                )
            )
        }
        return bookingId
    }
}
