package com.example.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserAccount(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val photoUrl: String? = null,
    val role: String = "user",
    val credits: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  val isAdmin: Boolean
    get() = role == "admin" || email.equals(BOOTSTRAPPED_ADMIN_EMAIL, ignoreCase = true)

  companion object {
    const val BOOTSTRAPPED_ADMIN_EMAIL = "mia85478667@gmail.com"
  }
}

@IgnoreExtraProperties
data class CreditTransaction(
    @DocumentId val id: String = "",
    val targetUid: String = "",
    val targetEmail: String = "",
    val adminUid: String = "",
    val adminEmail: String = "",
    val type: String = "admin_grant",
    val amount: Long = 0L,
    val balanceAfter: Long = 0L,
    val reason: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)

@IgnoreExtraProperties
data class AdminEntry(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val grantedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
)
