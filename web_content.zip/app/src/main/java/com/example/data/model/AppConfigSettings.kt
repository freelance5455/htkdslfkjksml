package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class AppConfigSettings(
    val superOfferUnlockGems: Long = 2L,
    val superOfferUnlockCoins: Long = 200L,
    val isSuperOfferEnabled: Boolean = true,
    val minWithdrawalCoins: Long = 100L,
    val conversionRateText: String = "100 Coins = ₹10",
    val welcomeBonusCoins: Long = 50L,
    val welcomeBonusGems: Long = 5L,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
