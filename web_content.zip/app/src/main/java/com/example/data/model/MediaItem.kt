package com.example.data.model

enum class MediaSource(val displayName: String, val badgeColorHex: Long) {
    PORNHUB("Pornhub", 0xFFFF9900),
    E621("e621", 0xFF00549E),
    RULE34("Rule34", 0xFFAAE5A4),
    BLUESKY("Bluesky", 0xFF1185FE),
    TWITTER("Twitter", 0xFF1DA1F2),
    REDDIT("Reddit", 0xFFFF4500),
    MYREADINGMANGA("MyReadingManga", 0xFF9C27B0),
    EHENTAI("E-Hentai", 0xFFED3554);

    companion object {
        fun fromString(name: String?): MediaSource {
            return entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: E621
        }
    }
}

enum class MediaType(val label: String) {
    VIDEO("Video"),
    PICTURE("Picture"),
    COMIC("Comic"),
    MISC("Misc");

    companion object {
        fun fromString(name: String?): MediaType {
            return entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: VIDEO
        }
    }
}

enum class GenderFilter(val label: String, val badgeColorHex: Long) {
    ANY("Any", 0xFF8A4FFF),
    FEMALE_ONLY("Female Only", 0xFFFF2E7E),
    MALE_ONLY("Male Only", 0xFF00E5FF),
    TRANS_HERM("Trans / Herm", 0xFFFFB300);

    companion object {
        fun fromString(name: String?): GenderFilter {
            return entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: ANY
        }
    }
}

enum class TagType {
    ARTIST,
    CHARACTER,
    COPYRIGHT,
    GENERAL,
    META
}

data class TagItem(
    val name: String,
    val type: TagType = TagType.GENERAL,
    val count: Int = 0
)

data class MediaItem(
    val id: String,
    val source: MediaSource,
    val type: MediaType,
    val title: String,
    val author: String,
    val authorAvatarUrl: String = "",
    val mediaUrl: String,
    val previewUrl: String,
    val caption: String = "",
    val tags: List<String> = emptyList(),
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val isLiked: Boolean = false,
    val isFavorited: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0,
    val comicPages: List<String> = emptyList() // For comics/manga reader
)

data class CommentItem(
    val id: String,
    val postId: String,
    val author: String,
    val authorAvatar: String = "",
    val content: String,
    val createdAt: Long = System.currentTimeMillis(),
    val likesCount: Int = 0,
    val platform: MediaSource = MediaSource.E621
)

data class ComicSeries(
    val id: String,
    val source: MediaSource,
    val title: String,
    val author: String,
    val coverUrl: String,
    val pagesCount: Int,
    val tags: List<String>,
    val pages: List<String>,
    val description: String = ""
)
