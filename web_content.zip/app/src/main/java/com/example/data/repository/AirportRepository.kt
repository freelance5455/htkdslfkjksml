package com.example.data.repository

import com.example.data.local.AirportDao
import com.example.data.local.FavoriteDao
import com.example.data.model.Airport
import com.example.data.model.FavoriteAirport
import com.example.data.model.RecentAirport
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class AirportRepository(
  private val airportDao: AirportDao,
  private val favoriteDao: FavoriteDao
) {

  val allAirports: Flow<List<Airport>> = airportDao.getAllAirports()
  val favorites: Flow<List<FavoriteAirport>> = favoriteDao.getAllFavorites()
  val recents: Flow<List<RecentAirport>> = favoriteDao.getRecentAirports()

  suspend fun initializeAirportsIfNeeded() {
    if (airportDao.getCount() == 0) {
      airportDao.insertAll(INITIAL_AIRPORTS)
      // Set default initial favorites: Tehran IKA (OIIE), Mehrabad (OIII), Mashhad (OIMM), Shiraz (OISS), Isfahan (OIFM)
      favoriteDao.addFavorite(FavoriteAirport("OIIE", sortOrder = 0))
      favoriteDao.addFavorite(FavoriteAirport("OIII", sortOrder = 1))
      favoriteDao.addFavorite(FavoriteAirport("OIMM", sortOrder = 2))
      favoriteDao.addFavorite(FavoriteAirport("OISS", sortOrder = 3))
      favoriteDao.addFavorite(FavoriteAirport("OIFM", sortOrder = 4))
    }
  }

  fun searchAirports(query: String): Flow<List<Airport>> {
    return airportDao.searchAirports(query.trim())
  }

  suspend fun getAirport(icao: String): Airport? {
    return airportDao.getAirportByIcao(icao.uppercase())
  }

  fun isFavorite(icao: String): Flow<Boolean> = favoriteDao.isFavorite(icao.uppercase())

  suspend fun toggleFavorite(icao: String) {
    val upper = icao.uppercase()
    val isFav = favoriteDao.isFavorite(upper).first()
    if (isFav) {
      favoriteDao.removeFavorite(upper)
    } else {
      favoriteDao.addFavorite(FavoriteAirport(upper))
    }
  }

  suspend fun recordRecentView(icao: String) {
    favoriteDao.recordRecentView(RecentAirport(icao.uppercase(), System.currentTimeMillis()))
  }

  companion object {
    val INITIAL_AIRPORTS = listOf(
      // --- IRANIAN AIRPORTS (Priority) ---
      Airport("OIIE", "IKA", "Tehran Imam Khomeini Intl", "فرودگاه بین‌المللی امام خمینی", "Tehran", "تهران", "Iran", "ایران", 35.416, 51.152, 3305, "Asia/Tehran", fir = "OIIX"),
      Airport("OIII", "THR", "Tehran Mehrabad Intl", "فرودگاه بین‌المللی مهرآباد", "Tehran", "تهران", "Iran", "ایران", 35.689, 51.313, 3962, "Asia/Tehran", fir = "OIIX"),
      Airport("OIMM", "MHD", "Mashhad Shahid Hashemi Nejad Intl", "فرودگاه بین‌المللی شهید هاشمی‌نژاد مشهد", "Mashhad", "مشهد", "Iran", "ایران", 36.235, 59.641, 3263, "Asia/Tehran", fir = "OIIX"),
      Airport("OISS", "SYZ", "Shiraz Shahid Dastghaib Intl", "فرودگاه بین‌المللی شهید دستغیب شیراز", "Shiraz", "شیراز", "Iran", "ایران", 29.539, 52.589, 4921, "Asia/Tehran", fir = "OIIX"),
      Airport("OIFM", "IFN", "Isfahan Shahid Beheshti Intl", "فرودگاه بین‌المللی شهید بهشتی اصفهان", "Isfahan", "اصفهان", "Iran", "ایران", 32.751, 51.861, 5059, "Asia/Tehran", fir = "OIIX"),
      Airport("OITT", "TBZ", "Tabriz Shahid Madani Intl", "فرودگاه بین‌المللی شهید مدنی تبریز", "Tabriz", "تبریز", "Iran", "ایران", 38.133, 46.235, 4459, "Asia/Tehran", fir = "OIIX"),
      Airport("OIKB", "BND", "Bandar Abbas Intl", "فرودگاه بین‌المللی بندرعباس", "Bandar Abbas", "بندرعباس", "Iran", "ایران", 27.218, 56.378, 22, "Asia/Tehran", fir = "OIIX"),
      Airport("OIAW", "AWZ", "Ahvaz General Soleimani Intl", "فرودگاه بین‌المللی شهید سلیمانی اهواز", "Ahvaz", "اهواز", "Iran", "ایران", 31.337, 48.762, 66, "Asia/Tehran", fir = "OIIX"),
      Airport("OIBK", "KIH", "Kish Island Intl", "فرودگاه بین‌المللی کیش", "Kish Island", "کیش", "Iran", "ایران", 26.526, 53.980, 101, "Asia/Tehran", fir = "OIIX"),
      Airport("OIZH", "ZAH", "Zahedan Intl", "فرودگاه بین‌المللی زاهدان", "Zahedan", "زاهدان", "Iran", "ایران", 29.476, 60.906, 4525, "Asia/Tehran", fir = "OIIX"),
      Airport("OIBB", "BUZ", "Bushehr Intl", "فرودگاه بین‌المللی بوشهر", "Bushehr", "بوشهر", "Iran", "ایران", 28.945, 50.835, 68, "Asia/Tehran", fir = "OIIX"),
      Airport("OIKK", "KER", "Kerman Ayatollah Hashemi Intl", "فرودگاه بین‌المللی آیت‌الله هاشمی رفسنجانی کرمان", "Kerman", "کرمان", "Iran", "ایران", 30.274, 56.964, 5741, "Asia/Tehran", fir = "OIIX"),
      Airport("OITY", "AZD", "Yazd Shahid Sadooghi Intl", "فرودگاه بین‌المللی شهید صدوقی یزد", "Yazd", "یزد", "Iran", "ایران", 31.905, 54.276, 4055, "Asia/Tehran", fir = "OIIX"),
      Airport("OIGG", "RAS", "Rasht Sardar Jangal", "فرودگاه سردار جنگل رشت", "Rasht", "رشت", "Iran", "ایران", 37.325, 49.626, -40, "Asia/Tehran", fir = "OIIX"),
      Airport("OINZ", "SRY", "Sari Dasht-e Naz", "فرودگاه دشت ناز ساری", "Sari", "ساری", "Iran", "ایران", 36.665, 53.193, 35, "Asia/Tehran", fir = "OIIX"),
      Airport("OICC", "KSH", "Kermanshah Shahid Ashrafi", "فرودگاه شهید اشرفی اصفهانی کرمانشاه", "Kermanshah", "کرمانشاه", "Iran", "ایران", 34.346, 47.158, 4305, "Asia/Tehran", fir = "OIIX"),
      Airport("OITL", "ADU", "Ardabil Airport", "فرودگاه اردبیل", "Ardabil", "اردبیل", "Iran", "ایران", 38.326, 48.424, 4281, "Asia/Tehran", fir = "OIIX"),
      Airport("OITR", "OMH", "Urmia Shahid Bakeri Intl", "فرودگاه بین‌المللی شهید باکری ارومیه", "Urmia", "ارومیه", "Iran", "ایران", 37.668, 45.069, 4344, "Asia/Tehran", fir = "OIIX"),
      Airport("OIBP", "PGU", "Persian Gulf Asaluyeh", "فرودگاه بین‌المللی خلیج فارس عسلویه", "Asaluyeh", "عسلویه", "Iran", "ایران", 27.379, 52.738, 28, "Asia/Tehran", fir = "OIIX"),
      Airport("OISL", "LRR", "Larestan Intl", "فرودگاه بین‌المللی لارستان", "Lar", "لار", "Iran", "ایران", 27.673, 54.382, 3004, "Asia/Tehran", fir = "OIIX"),
      Airport("OIZC", "ZBR", "Chahbahar Konarak", "فرودگاه کنارک چابهار", "Chahbahar", "چابهار", "Iran", "ایران", 25.443, 60.382, 43, "Asia/Tehran", fir = "OIIX"),
      Airport("OIAA", "ABD", "Abadan Ayatollah Jami", "فرودگاه بین‌المللی آیت‌الله جمی آبادان", "Abadan", "آبادان", "Iran", "ایران", 30.372, 48.228, 10, "Asia/Tehran", fir = "OIIX"),
      Airport("OIHH", "HDM", "Hamedan Airport", "فرودگاه همدان", "Hamedan", "همدان", "Iran", "ایران", 34.869, 48.552, 5768, "Asia/Tehran", fir = "OIIX"),
      Airport("OIHR", "CQD", "Shahrekord Airport", "فرودگاه شهرکرد", "Shahrekord", "شهرکرد", "Iran", "ایران", 32.296, 50.843, 6723, "Asia/Tehran", fir = "OIIX"),
      Airport("OITS", "SDG", "Sanandaj Airport", "فرودگاه سنندج", "Sanandaj", "سنندج", "Iran", "ایران", 35.247, 47.014, 4505, "Asia/Tehran", fir = "OIIX"),
      Airport("OIZI", "IIL", "Ilam Airport", "فرودگاه شهدای ایلام", "Ilam", "ایلام", "Iran", "ایران", 33.587, 46.405, 4390, "Asia/Tehran", fir = "OIIX"),
      Airport("OIMB", "XBJ", "Birjand Intl", "فرودگاه بین‌المللی بیرجند", "Birjand", "بیرجند", "Iran", "ایران", 32.898, 59.268, 4951, "Asia/Tehran", fir = "OIIX"),
      Airport("OIMN", "BJB", "Bojnord Airport", "فرودگاه شهدای بجنورد", "Bojnord", "بجنورد", "Iran", "ایران", 37.493, 57.308, 3507, "Asia/Tehran", fir = "OIIX"),
      Airport("OINE", "NSH", "Noshahr Airport", "فرودگاه نوشهر", "Noshahr", "نوشهر", "Iran", "ایران", 36.663, 51.464, -62, "Asia/Tehran", fir = "OIIX"),
      Airport("OINR", "RZR", "Ramsar Airport", "فرودگاه شهدای رامسر", "Ramsar", "رامسر", "Iran", "ایران", 36.909, 50.679, -69, "Asia/Tehran", fir = "OIIX"),
      Airport("OING", "GBT", "Gorgan Airport", "فرودگاه بین‌المللی گرگان", "Gorgan", "گرگان", "Iran", "ایران", 36.909, 54.401, 41, "Asia/Tehran", fir = "OIIX"),
      Airport("OIKM", "BXR", "Bam Airport", "فرودگاه بم", "Bam", "بم", "Iran", "ایران", 29.084, 58.450, 3232, "Asia/Tehran", fir = "OIIX"),
      Airport("OIKR", "RJN", "Rafsanjan Airport", "فرودگاه رفسنجان", "Rafsanjan", "رفسنجان", "Iran", "ایران", 30.298, 56.008, 5282, "Asia/Tehran", fir = "OIIX"),
      Airport("OIZB", "ACZ", "Zabol Airport", "فرودگاه زابل", "Zabol", "زابل", "Iran", "ایران", 31.098, 61.544, 1627, "Asia/Tehran", fir = "OIIX"),

      // --- REGIONAL & INTERNATIONAL HUBS ---
      Airport("OMDB", "DXB", "Dubai International", "فرودگاه بین‌المللی دبی", "Dubai", "دبی", "United Arab Emirates", "امارات متحده عربی", 25.253, 55.365, 62, "Asia/Dubai", fir = "OMAE"),
      Airport("OTHH", "DOH", "Hamad International", "فرودگاه بین‌المللی حمد دوحه", "Doha", "دوحه", "Qatar", "قطر", 25.273, 51.608, 13, "Asia/Qatar", fir = "OTBD"),
      Airport("OKBK", "KWI", "Kuwait International", "فرودگاه بین‌المللی کویت", "Kuwait City", "کویت", "Kuwait", "کویت", 29.227, 47.979, 206, "Asia/Kuwait", fir = "OKAC"),
      Airport("OBBI", "BAH", "Bahrain International", "فرودگاه بین‌المللی بحرین", "Manama", "منامه", "Bahrain", "بحرین", 26.270, 50.633, 6, "Asia/Bahrain", fir = "OBBB"),
      Airport("OOMS", "MCT", "Muscat International", "فرودگاه بین‌المللی مسقط", "Muscat", "مسقط", "Oman", "عمان", 23.593, 58.282, 48, "Asia/Muscat", fir = "OOMM"),
      Airport("ORBI", "BGW", "Baghdad International", "فرودگاه بین‌المللی بغداد", "Baghdad", "بغداد", "Iraq", "عراق", 33.263, 44.234, 114, "Asia/Baghdad", fir = "ORBB"),
      Airport("LTFM", "IST", "Istanbul Airport", "فرودگاه بین‌المللی استانبول", "Istanbul", "استانبول", "Turkey", "ترکیه", 41.275, 28.751, 325, "Europe/Istanbul", fir = "LTBB"),
      Airport("LTAC", "ESB", "Ankara Esenboga Intl", "فرودگاه بین‌المللی اسن‌بوغا آنکارا", "Ankara", "آنکارا", "Turkey", "ترکیه", 40.128, 32.995, 3125, "Europe/Istanbul", fir = "LTAA"),
      Airport("EGLL", "LHR", "London Heathrow", "فرودگاه هیترو لندن", "London", "لندن", "United Kingdom", "بریتانیا", 51.470, -0.454, 83, "Europe/London", fir = "EGTT"),
      Airport("LFPG", "CDG", "Paris Charles de Gaulle", "فرودگاه شارل دوگل پاریس", "Paris", "پاریس", "France", "فرانسه", 49.009, 2.547, 392, "Europe/Paris", fir = "LFFF"),
      Airport("EDDF", "FRA", "Frankfurt Airport", "فرودگاه فرانکفورت", "Frankfurt", "فرانکفورت", "Germany", "آلمان", 50.037, 8.562, 364, "Europe/Berlin", fir = "EDGG"),
      Airport("KJFK", "JFK", "John F. Kennedy Intl", "فرودگاه جان اف کندی نیویورک", "New York", "نیویورک", "United States", "ایالات متحده", 40.639, -73.778, 13, "America/New_York", fir = "KZNY"),
      Airport("KLAX", "LAX", "Los Angeles Intl", "فرودگاه بین‌المللی لس‌آنجلس", "Los Angeles", "لس‌آنجلس", "United States", "ایالات متحده", 33.942, -118.408, 128, "America/Los_Angeles", fir = "KZLA"),
      Airport("RJTT", "HND", "Tokyo Haneda", "فرودگاه هانه‌دا توکیو", "Tokyo", "توکیو", "Japan", "ژاپن", 35.549, 139.779, 35, "Asia/Tokyo", fir = "RPHI"),
      Airport("WSSS", "SIN", "Singapore Changi", "فرودگاه چانگی سنگاپور", "Singapore", "سنگاپور", "Singapore", "سنگاپور", 1.364, 103.991, 22, "Asia/Singapore", fir = "WSJC")
    )
  }
}
