package com.example.data.model

data class ScriptPreset(
    val title: String,
    val category: String,
    val description: String,
    val script: String
)

object ScriptPresets {
    val presets = listOf(
        ScriptPreset(
            title = "The Mariana Abyss",
            category = "YouTube Documentary",
            description = "High engagement narrative script with pauses and pacing.",
            script = """Welcome back to Apex Discovery. Deep beneath the western Pacific Ocean lies a realm perpetual darkness and crushing pressure.

At nearly eleven thousand meters below the surface, the Challenger Deep within the Mariana Trench remains one of the most enigmatic frontiers on our planet.

For centuries, oceanographers presumed these abyssal depths were devoid of complex life. The hydrostatic pressure exceeds one thousand atmospheres—equivalent to the weight of fifty jumbo jets stacked upon a single human being.

Yet, robotic submersibles have revealed an alien world flourishing in the cold abyss. Translucent snailfish dart past hydrothermal chimneys, sustained not by sunlight, but by chemosynthesis. 

What other secrets are waiting in the quiet blackness of the ocean floor? Let us plunge deeper into the unknown."""
        ),
        ScriptPreset(
            title = "The Clockmaker of Prague",
            category = "Audiobook / Story",
            description = "Atmospheric fiction story with classical narrator tone.",
            script = """Chapter One: The Mechanical Heart.

The cobblestones of Prague were slick with evening drizzle when Master Mikuláš lit the lantern above his workshop door. Inside, a hundred pendulums swung in polyrhythmic cadence, ticking away seconds that no man could ever reclaim.

On his workbench lay the astrolabe for the astronomical clock of the Old Town Square. Every gear was forged from virgin bronze, each gear tooth filed by hand with mathematical precision.

"Time is not a straight road," Mikuláš whispered to his young apprentice, holding a balance wheel to the candlelight. "It is an intricate circle. If a single cog slips, yesterday collides with tomorrow."

A sudden knock rattled the heavy oak door. Three sharp taps, followed by silence. Outside in the mist, a cloaked traveler stood waiting with a parchment sealed in crimson wax."""
        ),
        ScriptPreset(
            title = "Quantum Computing Demystified",
            category = "Educational",
            description = "Clear pedagogical script explaining qubits and superposition.",
            script = """Welcome to Modern Tech Explained. Today, we are breaking down quantum computers into simple, intuitive concepts.

Traditional computers process information using classical bits. A bit is like a light switch—it can exist in one of two states: zero or one. Every movie you stream, every website you browse, is encoded in billions of these binary switches.

Quantum computers, however, leverage quantum mechanics using qubits. Thanks to a phenomenon called superposition, a qubit doesn't have to be just zero or one. It can represent both states simultaneously.

Furthermore, through quantum entanglement, qubits can correlate with one another across distances, scaling computational power exponentially rather than linearly. 

While a quantum machine will not replace your smartphone, it will revolutionize drug discovery, molecular simulation, and cryptography."""
        ),
        ScriptPreset(
            title = "Serengeti: The Endless Plain",
            category = "Nature Narration",
            description = "Poetic wildlife documentary narration style.",
            script = """At dawn, the golden grasslands of the Serengeti awaken beneath a vast African sky. The air is cool, carrying the scent of wild thyme and damp earth.

More than one million wildebeest and zebras move as a singular organism across the horizon. Driven by an ancient instinct, they follow the rains in search of fresh pasture.

Every crossing is perilous. At the Mara River, crocodiles wait patiently in the murky currents, their prehistoric silhouettes barely breaking the surface.

This is the timeless circle of life—a balance forged across millennia, where courage and endurance define survival."""
        )
    )
}
