package com.example.data.notes

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.sp
import com.example.R
import org.json.JSONArray
import org.json.JSONObject

enum class NoteFontFamily(val key: String, val displayName: String) {
    SANS("sans", "Sans"),
    SERIF("serif", "Serif"),
    MONOSPACE("monospace", "Monospace"),
    HANDWRITING("handwriting", "Handwriting (Caveat)");

    fun toComposeFontFamily(): FontFamily {
        return when (this) {
            SANS -> FontFamily.SansSerif
            SERIF -> FontFamily.Serif
            MONOSPACE -> FontFamily.Monospace
            HANDWRITING -> FontFamily(Font(R.font.caveat))
        }
    }

    companion object {
        fun fromKey(key: String?): NoteFontFamily {
            return entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: SANS
        }
    }
}

enum class NoteAlignment(val key: String, val displayName: String) {
    LEFT("left", "Left"),
    CENTER("center", "Center"),
    RIGHT("right", "Right");

    fun toComposeTextAlign(): TextAlign {
        return when (this) {
            LEFT -> TextAlign.Left
            CENTER -> TextAlign.Center
            RIGHT -> TextAlign.Right
        }
    }

    companion object {
        fun fromKey(key: String?): NoteAlignment {
            return entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: LEFT
        }
    }
}

enum class BlockType(val key: String, val displayName: String) {
    PARAGRAPH("p", "Text"),
    HEADING_1("h1", "Heading 1"),
    HEADING_2("h2", "Heading 2"),
    HEADING_3("h3", "Heading 3"),
    BULLET("bullet", "Bullet List"),
    NUMBERED("numbered", "Numbered List"),
    CHECKLIST("checklist", "Checklist");

    companion object {
        fun fromKey(key: String?): BlockType {
            return entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: PARAGRAPH
        }
    }
}

data class RichSpan(
    val start: Int,
    val end: Int,
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val isUnderline: Boolean = false,
    val isStrikethrough: Boolean = false,
    val textColorHex: String? = null,
    val highlightColorHex: String? = null,
    val fontSizeSp: Int? = null
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("start", start)
        obj.put("end", end)
        if (isBold) obj.put("bold", true)
        if (isItalic) obj.put("italic", true)
        if (isUnderline) obj.put("underline", true)
        if (isStrikethrough) obj.put("strike", true)
        textColorHex?.let { obj.put("textColor", it) }
        highlightColorHex?.let { obj.put("highlightColor", it) }
        fontSizeSp?.let { obj.put("fontSize", it) }
        return obj
    }

    fun toSpanStyle(): SpanStyle {
        val decorations = mutableListOf<TextDecoration>()
        if (isUnderline) decorations.add(TextDecoration.Underline)
        if (isStrikethrough) decorations.add(TextDecoration.LineThrough)

        val combinedDecoration = when {
            decorations.size > 1 -> TextDecoration.combine(decorations)
            decorations.size == 1 -> decorations.first()
            else -> TextDecoration.None
        }

        val color = parseHexColor(textColorHex)
        val bg = parseHexColor(highlightColorHex)

        return SpanStyle(
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            fontStyle = if (isItalic) FontStyle.Italic else FontStyle.Normal,
            textDecoration = combinedDecoration,
            color = color,
            background = bg,
            fontSize = fontSizeSp?.sp ?: androidx.compose.ui.unit.TextUnit.Unspecified
        )
    }

    private fun parseHexColor(hex: String?): Color {
        if (hex.isNullOrBlank()) return Color.Unspecified
        return try {
            val clean = hex.removePrefix("#")
            val colorLong = clean.toLong(16)
            if (clean.length == 6) {
                Color(colorLong or 0x00000000FF000000)
            } else {
                Color(colorLong)
            }
        } catch (_: Exception) {
            Color.Unspecified
        }
    }

    companion object {
        fun fromJson(obj: JSONObject): RichSpan {
            return RichSpan(
                start = obj.optInt("start", 0),
                end = obj.optInt("end", 0),
                isBold = obj.optBoolean("bold", false),
                isItalic = obj.optBoolean("italic", false),
                isUnderline = obj.optBoolean("underline", false),
                isStrikethrough = obj.optBoolean("strike", false),
                textColorHex = if (obj.has("textColor")) obj.getString("textColor") else null,
                highlightColorHex = if (obj.has("highlightColor")) obj.getString("highlightColor") else null,
                fontSizeSp = if (obj.has("fontSize")) obj.getInt("fontSize") else null
            )
        }
    }
}

data class LineBlock(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String = "",
    val type: BlockType = BlockType.PARAGRAPH,
    val isChecked: Boolean = false, // for checklists
    val spans: List<RichSpan> = emptyList()
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("text", text)
        obj.put("type", type.key)
        if (type == BlockType.CHECKLIST) {
            obj.put("checked", isChecked)
        }
        if (spans.isNotEmpty()) {
            val arr = JSONArray()
            spans.forEach { arr.put(it.toJson()) }
            obj.put("spans", arr)
        }
        return obj
    }

    fun toAnnotatedString(baseFontSizeSp: Int): AnnotatedString {
        return buildAnnotatedString {
            append(text)
            // Apply line-level styles for headings or checklist strike
            when (type) {
                BlockType.HEADING_1 -> {
                    addStyle(
                        SpanStyle(
                            fontWeight = FontWeight.Bold,
                            fontSize = (baseFontSizeSp * 1.5).coerceIn(16.0, 42.0).sp
                        ),
                        0,
                        text.length
                    )
                }
                BlockType.HEADING_2 -> {
                    addStyle(
                        SpanStyle(
                            fontWeight = FontWeight.Bold,
                            fontSize = (baseFontSizeSp * 1.3).coerceIn(14.0, 38.0).sp
                        ),
                        0,
                        text.length
                    )
                }
                BlockType.HEADING_3 -> {
                    addStyle(
                        SpanStyle(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = (baseFontSizeSp * 1.15).coerceIn(12.0, 36.0).sp
                        ),
                        0,
                        text.length
                    )
                }
                BlockType.CHECKLIST -> {
                    if (isChecked && text.isNotEmpty()) {
                        addStyle(
                            SpanStyle(
                                textDecoration = TextDecoration.LineThrough,
                                color = Color.Gray
                            ),
                            0,
                            text.length
                        )
                    }
                }
                else -> {}
            }

            // Apply fine-grained inline spans
            spans.forEach { span ->
                val safeStart = span.start.coerceIn(0, text.length)
                val safeEnd = span.end.coerceIn(safeStart, text.length)
                if (safeEnd > safeStart) {
                    addStyle(span.toSpanStyle(), safeStart, safeEnd)
                }
            }
        }
    }

    companion object {
        fun fromJson(obj: JSONObject): LineBlock {
            val type = BlockType.fromKey(obj.optString("type", BlockType.PARAGRAPH.key))
            val spansList = mutableListOf<RichSpan>()
            val arr = obj.optJSONArray("spans")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    spansList.add(RichSpan.fromJson(arr.getJSONObject(i)))
                }
            }
            return LineBlock(
                id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                text = obj.optString("text", ""),
                type = type,
                isChecked = obj.optBoolean("checked", false),
                spans = spansList
            )
        }
    }
}

data class RichNoteDocument(
    val fontFamily: String = NoteFontFamily.SANS.key,
    val fontSize: Int = 16,
    val alignment: NoteAlignment = NoteAlignment.LEFT,
    val blocks: List<LineBlock> = listOf(LineBlock())
) {
    fun toJson(): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("fontFamily", fontFamily)
        root.put("fontSize", fontSize)
        root.put("alignment", alignment.key)
        val arr = JSONArray()
        blocks.forEach { arr.put(it.toJson()) }
        root.put("blocks", arr)
        return root.toString()
    }

    fun toPlainText(): String {
        return blocks.joinToString("\n") { block ->
            when (block.type) {
                BlockType.BULLET -> "• ${block.text}"
                BlockType.NUMBERED -> block.text
                BlockType.CHECKLIST -> if (block.isChecked) "[✓] ${block.text}" else "[ ] ${block.text}"
                BlockType.HEADING_1 -> "# ${block.text}"
                BlockType.HEADING_2 -> "## ${block.text}"
                BlockType.HEADING_3 -> "### ${block.text}"
                else -> block.text
            }
        }
    }

    fun toPreviewText(maxLength: Int = 120): String {
        val raw = blocks.filter { it.text.isNotBlank() }
            .joinToString(" ") { it.text.trim() }
        return if (raw.length <= maxLength) raw else raw.take(maxLength).trimEnd() + "..."
    }

    companion object {
        fun fromJson(jsonStr: String?): RichNoteDocument {
            if (jsonStr.isNullOrBlank()) return RichNoteDocument()
            return try {
                val root = JSONObject(jsonStr)
                val fontFamily = root.optString("fontFamily", NoteFontFamily.SANS.key)
                val fontSize = root.optInt("fontSize", 16).coerceIn(10, 36)
                val alignment = NoteAlignment.fromKey(root.optString("alignment", NoteAlignment.LEFT.key))

                val blocksList = mutableListOf<LineBlock>()
                val arr = root.optJSONArray("blocks")
                if (arr != null && arr.length() > 0) {
                    for (i in 0 until arr.length()) {
                        blocksList.add(LineBlock.fromJson(arr.getJSONObject(i)))
                    }
                } else {
                    blocksList.add(LineBlock())
                }

                RichNoteDocument(
                    fontFamily = fontFamily,
                    fontSize = fontSize,
                    alignment = alignment,
                    blocks = blocksList
                )
            } catch (e: Exception) {
                fromPlainText(jsonStr)
            }
        }

        fun fromPlainText(text: String): RichNoteDocument {
            val lines = text.lines()
            val blocks = if (lines.isEmpty()) {
                listOf(LineBlock())
            } else {
                lines.map { LineBlock(text = it) }
            }
            return RichNoteDocument(blocks = blocks)
        }
    }
}
