package com.example.data.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.ExamType
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.SubjectProgress
import com.example.data.model.UserProgress
import org.json.JSONArray
import org.json.JSONObject

class DopingStorageManager(context: Context) {

  private val prefs: SharedPreferences =
    context.getSharedPreferences("doping_hafiza_prefs", Context.MODE_PRIVATE)

  // --- Study Tasks Persistence ---
  fun saveTasks(tasks: List<StudyTask>) {
    val array = JSONArray()
    for (task in tasks) {
      val obj = JSONObject().apply {
        put("id", task.id)
        put("title", task.title)
        put("subject", task.subject.name)
        put("targetQuestions", task.targetQuestions)
        put("completedQuestions", task.completedQuestions)
        put("targetMinutes", task.targetMinutes)
        put("completedMinutes", task.completedMinutes)
        put("isCompleted", task.isCompleted)
        put("dayOfWeek", task.dayOfWeek)
        put("priority", task.priority)
        put("topicRef", task.topicRef ?: "")
        put("scheduledDate", task.scheduledDate)
        put("reminderTime", task.reminderTime ?: "")
        put("hasReminder", task.hasReminder)
        put("notes", task.notes)
      }
      array.put(obj)
    }
    prefs.edit().putString("saved_tasks_json", array.toString()).apply()
  }

  fun loadTasks(): List<StudyTask>? {
    val json = prefs.getString("saved_tasks_json", null) ?: return null
    return try {
      val array = JSONArray(json)
      val list = mutableListOf<StudyTask>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val subjectName = obj.optString("subject", Subject.MATEMATIK.name)
        val subject = try { Subject.valueOf(subjectName) } catch (e: Exception) { Subject.MATEMATIK }
        val reminderTimeStr = obj.optString("reminderTime", "")
        list.add(
          StudyTask(
            id = obj.getString("id"),
            title = obj.getString("title"),
            subject = subject,
            targetQuestions = obj.optInt("targetQuestions", 20),
            completedQuestions = obj.optInt("completedQuestions", 0),
            targetMinutes = obj.optInt("targetMinutes", 30),
            completedMinutes = obj.optInt("completedMinutes", 0),
            isCompleted = obj.optBoolean("isCompleted", false),
            dayOfWeek = obj.optString("dayOfWeek", "Bugün"),
            priority = obj.optString("priority", "Yüksek"),
            topicRef = obj.optString("topicRef", "").ifEmpty { null },
            scheduledDate = obj.optString("scheduledDate", "2026-11-12"),
            reminderTime = reminderTimeStr.ifEmpty { null },
            hasReminder = obj.optBoolean("hasReminder", false),
            notes = obj.optString("notes", "")
          )
        )
      }
      if (list.isEmpty()) null else list
    } catch (e: Exception) {
      null
    }
  }

  // --- User Progress Persistence ---
  fun saveUserProgress(progress: UserProgress) {
    val obj = JSONObject().apply {
      put("selectedExam", progress.selectedExam.name)
      put("targetNet", progress.targetNet)
      put("targetScore", progress.targetScore)
      put("daysRemaining", progress.daysRemaining)
      put("streakDays", progress.streakDays)
      put("totalQuestionsSolved", progress.totalQuestionsSolved)
      put("totalCorrect", progress.totalCorrect)
      put("totalWrong", progress.totalWrong)
      put("totalStudyMinutes", progress.totalStudyMinutes)
      put("dailyGoalMinutes", progress.dailyGoalMinutes)
      put("todayStudiedMinutes", progress.todayStudiedMinutes)
      put("todaySolvedQuestions", progress.todaySolvedQuestions)
      put("dailyGoalQuestions", progress.dailyGoalQuestions)

      val errors = JSONArray()
      progress.errorNotebookQuestionIds.forEach { errors.put(it) }
      put("errorNotebook", errors)

      val favs = JSONArray()
      progress.favoriteTopicIds.forEach { favs.put(it) }
      put("favorites", favs)

      val comp = JSONArray()
      progress.completedTopicIds.forEach { comp.put(it) }
      put("completed", comp)
    }
    prefs.edit().putString("saved_user_progress_json", obj.toString()).apply()
  }

  fun loadUserProgress(): UserProgress? {
    val json = prefs.getString("saved_user_progress_json", null) ?: return null
    return try {
      val obj = JSONObject(json)
      val exam = try {
        ExamType.valueOf(obj.optString("selectedExam", ExamType.YKS_TYT.name))
      } catch (e: Exception) { ExamType.YKS_TYT }

      val errors = mutableSetOf<String>()
      val errArr = obj.optJSONArray("errorNotebook")
      if (errArr != null) {
        for (i in 0 until errArr.length()) errors.add(errArr.getString(i))
      }

      val favs = mutableSetOf<String>()
      val favArr = obj.optJSONArray("favorites")
      if (favArr != null) {
        for (i in 0 until favArr.length()) favs.add(favArr.getString(i))
      }

      val comp = mutableSetOf<String>()
      val compArr = obj.optJSONArray("completed")
      if (compArr != null) {
        for (i in 0 until compArr.length()) comp.add(compArr.getString(i))
      }

      UserProgress(
        selectedExam = exam,
        targetNet = obj.optDouble("targetNet", 85.0),
        targetScore = obj.optInt("targetScore", 450),
        daysRemaining = obj.optInt("daysRemaining", 214),
        streakDays = obj.optInt("streakDays", 14),
        totalQuestionsSolved = obj.optInt("totalQuestionsSolved", 412),
        totalCorrect = obj.optInt("totalCorrect", 349),
        totalWrong = obj.optInt("totalWrong", 63),
        totalStudyMinutes = obj.optInt("totalStudyMinutes", 1850),
        dailyGoalMinutes = obj.optInt("dailyGoalMinutes", 90),
        todayStudiedMinutes = obj.optInt("todayStudiedMinutes", 55),
        todaySolvedQuestions = obj.optInt("todaySolvedQuestions", 35),
        dailyGoalQuestions = obj.optInt("dailyGoalQuestions", 60),
        errorNotebookQuestionIds = errors,
        favoriteTopicIds = favs,
        completedTopicIds = comp
      )
    } catch (e: Exception) {
      null
    }
  }

  // --- Subject Progress Persistence ---
  fun saveSubjectProgress(progressMap: Map<Subject, SubjectProgress>) {
    val array = JSONArray()
    for ((subject, sp) in progressMap) {
      val obj = JSONObject().apply {
        put("subject", subject.name)
        put("totalSolved", sp.totalSolved)
        put("correctCount", sp.correctCount)
        put("wrongCount", sp.wrongCount)
        put("lastStudiedDate", sp.lastStudiedDate)
      }
      array.put(obj)
    }
    prefs.edit().putString("saved_subject_progress", array.toString()).apply()
  }

  fun loadSubjectProgress(): Map<Subject, SubjectProgress>? {
    val json = prefs.getString("saved_subject_progress", null) ?: return null
    return try {
      val array = JSONArray(json)
      val map = mutableMapOf<Subject, SubjectProgress>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val s = try { Subject.valueOf(obj.getString("subject")) } catch (e: Exception) { null }
        if (s != null) {
          map[s] = SubjectProgress(
            subject = s,
            totalSolved = obj.optInt("totalSolved", 0),
            correctCount = obj.optInt("correctCount", 0),
            wrongCount = obj.optInt("wrongCount", 0),
            lastStudiedDate = obj.optString("lastStudiedDate", "Bugün")
          )
        }
      }
      if (map.isEmpty()) null else map
    } catch (e: Exception) {
      null
    }
  }

  // --- 64 GB Storage & Offline Content Simulation ---
  fun isOfflineDownloaded(): Boolean = prefs.getBoolean("is_offline_downloaded", false)

  fun setOfflineDownloaded(downloaded: Boolean) {
    prefs.edit().putBoolean("is_offline_downloaded", downloaded).apply()
  }

  fun clearAppCache() {
    prefs.edit().remove("question_cache_size").apply()
  }
}
