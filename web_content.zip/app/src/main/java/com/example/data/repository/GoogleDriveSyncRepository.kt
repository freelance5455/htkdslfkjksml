package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.SyncDocuments
import com.example.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GoogleDriveSyncRepository(
    private val context: Context,
    private val mediaRepository: MediaRepository,
    private val preferencesRepository: UserPreferencesRepository
) {
    suspend fun performGoogleAccountSync(userEmail: String): Result<SyncDocuments> = withContext(Dispatchers.IO) {
        try {
            val syncDocs = mediaRepository.generateSyncDocuments()

            // Save text files locally inside sync export cache
            val syncDir = File(context.filesDir, "GoogleDrive_Yiffy_Sync")
            if (!syncDir.exists()) syncDir.mkdirs()

            File(syncDir, "History.txt").writeText(syncDocs.historyDoc)
            File(syncDir, "Algorithm_keeping.txt").writeText(syncDocs.algorithmDoc)
            File(syncDir, "Liked_posts.txt").writeText(syncDocs.likedPostsDoc)
            File(syncDir, "Favorite_posts.txt").writeText(syncDocs.favoritePostsDoc)

            // Update user preferences status
            preferencesRepository.setGoogleAccount(
                email = userEmail.ifBlank { "feltedleopard@gmail.com" },
                connected = true
            )

            Result.success(syncDocs)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getLocalSyncDirectory(): File = withContext(Dispatchers.IO) {
        val syncDir = File(context.filesDir, "GoogleDrive_Yiffy_Sync")
        if (!syncDir.exists()) syncDir.mkdirs()
        syncDir
    }

    suspend fun readDocumentContent(fileName: String): String = withContext(Dispatchers.IO) {
        val syncDir = File(context.filesDir, "GoogleDrive_Yiffy_Sync")
        val file = File(syncDir, fileName)
        if (file.exists()) {
            file.readText()
        } else {
            // Generate on the fly if not yet synced
            val docs = mediaRepository.generateSyncDocuments()
            when (fileName) {
                "History.txt" -> docs.historyDoc
                "Algorithm_keeping.txt" -> docs.algorithmDoc
                "Liked_posts.txt" -> docs.likedPostsDoc
                "Favorite_posts.txt" -> docs.favoritePostsDoc
                else -> "Document not found."
            }
        }
    }

    fun shareDocument(fileName: String, content: String): Intent {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TITLE, fileName)
            putExtra(Intent.EXTRA_SUBJECT, "Yiffy Google Drive Sync - $fileName")
            putExtra(Intent.EXTRA_TEXT, content)
            type = "text/plain"
        }
        return Intent.createChooser(sendIntent, "Share or Export $fileName")
    }
}
