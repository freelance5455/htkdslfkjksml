package com.example.data.remote

import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put

/**
 * Lightweight embedded HTTP backend server running on 127.0.0.1:3000 inside the Android app.
 * Provides:
 * - GET /api/health
 * - POST /api/chat
 * This allows any local WebView or companion HTML-to-APK interface on the same Android device
 * to connect automatically to http://127.0.0.1:3000 without manual URL entry.
 */
object LocalBackendServer {
    private const val TAG = "RaynoxLocalServer"
    private const val DEFAULT_PORT = 3000

    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun startIfNeeded() {
        if (!running.compareAndSet(false, true)) return
        scope.launch {
            try {
                val socket = ServerSocket(DEFAULT_PORT, 50, InetAddress.getByName("127.0.0.1"))
                serverSocket = socket
                Log.i(TAG, "Local Raynox Backend listening on http://127.0.0.1:$DEFAULT_PORT")
                while (running.get() && !socket.isClosed) {
                    val client = try {
                        socket.accept()
                    } catch (_: Exception) {
                        break
                    }
                    scope.launch { handleClient(client) }
                }
            } catch (e: Exception) {
                Log.w(TAG, "LocalBackendServer could not bind port $DEFAULT_PORT: ${e.message}")
                running.set(false)
            }
        }
    }

    private suspend fun handleClient(socket: Socket) {
        socket.use { client ->
            client.soTimeout = 60_000
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8))
            val out = client.getOutputStream()

            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0].uppercase()
            val fullTarget = parts[1]
            val path = fullTarget.substringBefore("?")
            val query = fullTarget.substringAfter("?", "")

            var contentLength = 0
            while (true) {
                val headerLine = reader.readLine() ?: break
                if (headerLine.isEmpty()) break
                if (headerLine.startsWith("Content-Length:", ignoreCase = true)) {
                    contentLength = headerLine.substringAfter(":").trim().toIntOrNull() ?: 0
                }
            }

            if (method == "OPTIONS") {
                writeJsonResponse(out, 204, "")
                return
            }

            if (method == "GET" && (path == "/api/health" || path == "/health")) {
                val model = parseQueryParam(query, "model") ?: GeminiClient.MODEL_RAYNOX_CORE
                val startMs = System.currentTimeMillis()
                val ping = GeminiClient.pingHealthCheck(model)
                val latencyMs = System.currentTimeMillis() - startMs

                if (ping.isSuccess) {
                    val body = buildJsonObject {
                        put("ok", true)
                        put("status", "connected")
                        put("provider", "Google Gemini")
                        put("model", model)
                        put("latencyMs", latencyMs)
                        put("authRequired", false)
                    }.toString()
                    writeJsonResponse(out, 200, body)
                } else {
                    val err = ping.exceptionOrNull()?.message ?: "Gemini API unreachable"
                    val body = buildJsonObject {
                        put("ok", false)
                        put("status", "not_connected")
                        put("error", err)
                    }.toString()
                    writeJsonResponse(out, 503, body)
                }
                return
            }

            if (method == "POST" && path == "/api/chat") {
                val bodyChars = CharArray(contentLength.coerceIn(0, 2 * 1024 * 1024))
                var readTotal = 0
                while (readTotal < bodyChars.size) {
                    val r = reader.read(bodyChars, readTotal, bodyChars.size - readTotal)
                    if (r == -1) break
                    readTotal += r
                }
                val rawJson = String(bodyChars, 0, readTotal)
                handleChatPost(out, rawJson)
                return
            }

            val notFound = buildJsonObject {
                put("ok", false)
                put("error", "Not found: $path")
            }.toString()
            writeJsonResponse(out, 404, notFound)
        }
    }

    private suspend fun handleChatPost(out: OutputStream, rawJson: String) {
        val apiKey = GeminiClient.getEffectiveApiKey()
        if (apiKey.isBlank()) {
            val err = buildJsonObject {
                put("ok", false)
                put("error", "GEMINI_API_KEY is not configured.")
            }.toString()
            writeJsonResponse(out, 503, err)
            return
        }

        val jsonObj: JsonObject = try {
            GeminiClient.json.parseToJsonElement(rawJson).jsonObject
        } catch (_: Exception) {
            val err = buildJsonObject {
                put("ok", false)
                put("error", "Invalid JSON request body.")
            }.toString()
            writeJsonResponse(out, 400, err)
            return
        }

        val message = (jsonObj["message"] as? JsonPrimitive)?.contentOrNull?.trim().orEmpty()
        val model = (jsonObj["model"] as? JsonPrimitive)?.contentOrNull?.trim()
            ?.takeIf { it.isNotEmpty() } ?: GeminiClient.MODEL_RAYNOX_CORE
        val userName = (jsonObj["userName"] as? JsonPrimitive)?.contentOrNull?.trim().orEmpty()
        val customInstructions = (jsonObj["customInstructions"] as? JsonPrimitive)?.contentOrNull?.trim().orEmpty()

        if (message.isEmpty()) {
            val err = buildJsonObject {
                put("ok", false)
                put("error", "Message cannot be empty.")
            }.toString()
            writeJsonResponse(out, 400, err)
            return
        }

        val contents = mutableListOf<Content>()
        val historyArr = jsonObj["history"] as? JsonArray
        historyArr?.takeLast(20)?.forEach { el ->
            val obj = el as? JsonObject ?: return@forEach
            val roleRaw = (obj["role"] as? JsonPrimitive)?.contentOrNull ?: "user"
            val textRaw = (obj["content"] as? JsonPrimitive)?.contentOrNull?.trim().orEmpty()
            if (textRaw.isNotEmpty()) {
                val role = if (roleRaw == "user") "user" else "model"
                contents.add(Content(role = role, parts = listOf(Part(text = textRaw))))
            }
        }

        if (contents.lastOrNull()?.parts?.firstOrNull()?.text != message) {
            contents.add(Content(role = "user", parts = listOf(Part(text = message))))
        }

        val request = GenerateContentRequest(
            contents = contents,
            systemInstruction = GeminiClient.buildSystemInstruction(userName, customInstructions),
            generationConfig = GenerationConfig(temperature = 0.7f, topP = 0.95f, topK = 40)
        )

        try {
            val response = GeminiClient.api.generateContent(
                model = model,
                apiKey = apiKey,
                request = request
            )
            val reply = response.candidates?.firstOrNull()?.content?.parts
                ?.mapNotNull { it.text }
                ?.joinToString("")
                ?.trim()
                .orEmpty()

            if (reply.isNotEmpty()) {
                val resJson = buildJsonObject {
                    put("ok", true)
                    put("reply", reply)
                    put("model", model)
                }.toString()
                writeJsonResponse(out, 200, resJson)
            } else {
                val err = buildJsonObject {
                    put("ok", false)
                    put("error", "Empty response from AI model.")
                }.toString()
                writeJsonResponse(out, 502, err)
            }
        } catch (e: Exception) {
            val err = buildJsonObject {
                put("ok", false)
                put("error", e.message ?: "AI request failed.")
            }.toString()
            writeJsonResponse(out, 502, err)
        }
    }

    private fun parseQueryParam(query: String, key: String): String? {
        if (query.isBlank()) return null
        return query.split("&").mapNotNull { pair ->
            val idx = pair.indexOf("=")
            if (idx == -1) null
            else {
                val k = pair.substring(0, idx)
                val v = pair.substring(idx + 1)
                if (k == key) URLDecoder.decode(v, "UTF-8") else null
            }
        }.firstOrNull()
    }

    private fun writeJsonResponse(out: OutputStream, statusCode: Int, jsonBody: String) {
        val statusText = when (statusCode) {
            200 -> "OK"
            204 -> "No Content"
            400 -> "Bad Request"
            404 -> "Not Found"
            502 -> "Bad Gateway"
            503 -> "Service Unavailable"
            else -> "Error"
        }
        val bodyBytes = jsonBody.toByteArray(StandardCharsets.UTF_8)
        val headers = buildString {
            append("HTTP/1.1 $statusCode $statusText\r\n")
            append("Content-Type: application/json; charset=utf-8\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n")
            append("Access-Control-Allow-Headers: Content-Type, Authorization, Accept\r\n")
            append("Content-Length: ${bodyBytes.size}\r\n")
            append("Connection: close\r\n")
            append("\r\n")
        }
        out.write(headers.toByteArray(StandardCharsets.UTF_8))
        if (bodyBytes.isNotEmpty()) {
            out.write(bodyBytes)
        }
        out.flush()
    }
}
