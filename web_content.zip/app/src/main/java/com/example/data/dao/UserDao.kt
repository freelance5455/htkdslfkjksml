package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY id ASC LIMIT 1")
    fun getUserFlow(): Flow<UserEntity?>

    @Query("SELECT * FROM users ORDER BY id ASC LIMIT 1")
    suspend fun getUser(): UserEntity?

    @Query("SELECT * FROM users WHERE username = :username COLLATE NOCASE LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT COUNT(*) FROM users")
    suspend fun getUserCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(user: UserEntity)

    @Query("UPDATE users SET failedAttempts = :attempts, cooldownUntilTimestamp = :cooldownUntil WHERE id = 1")
    suspend fun updateCooldown(attempts: Int, cooldownUntil: Long)

    @Query("UPDATE users SET lastManualLoginTimestamp = :timestamp, failedAttempts = 0, cooldownUntilTimestamp = 0 WHERE id = 1")
    suspend fun recordSuccessfulLogin(timestamp: Long)

    @Query("UPDATE users SET lastManualLoginTimestamp = 0 WHERE id = 1")
    suspend fun clearSession()

    @Query("UPDATE users SET passwordHash = :passwordHash, passwordSalt = :passwordSalt, recoveryCodeHash = :recoveryCodeHash, recoveryCodeSalt = :recoveryCodeSalt, lastManualLoginTimestamp = :lastLogin, failedAttempts = 0, cooldownUntilTimestamp = 0 WHERE id = 1")
    suspend fun updateCredentialsAndRecovery(
        passwordHash: String,
        passwordSalt: String,
        recoveryCodeHash: String,
        recoveryCodeSalt: String,
        lastLogin: Long
    )

    @Query("DELETE FROM users")
    suspend fun deleteAll()
}
