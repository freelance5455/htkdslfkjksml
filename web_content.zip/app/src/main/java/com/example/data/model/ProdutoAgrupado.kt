package com.example.data.model

import com.example.util.ValidadeInfo
import com.example.util.ValidadeNivel
import com.example.util.ValidadeUtil

data class ProdutoAgrupado(
    val codigo: String,
    val nome: String,
    val marca: String,
    val precoVenda: Double,
    val custo: Double,
    val estoqueTotal: Int,
    val lotes: List<Perfume>, // Todos os lotes cadastrados deste produto
    val loteMaisCritico: Perfume?, // Lote com vencimento mais próximo
    val statusMaisCritico: ValidadeInfo?
) {
    val totalLotes: Int get() = lotes.size
    val temLoteVencido: Boolean get() = lotes.any {
        ValidadeUtil.calcularValidade(it.validade).nivel == ValidadeNivel.VENCIDO
    }
    val temLoteAlerta: Boolean get() = lotes.any {
        ValidadeUtil.calcularValidade(it.validade).nivel == ValidadeNivel.A_VENCER_6_MESES
    }
}

data class MesVendasResumo(
    val chaveAnoMes: String, // ex: "2026-10"
    val rotuloFormatado: String, // ex: "Outubro / 2026"
    val totalFaturado: Double,
    val totalLucro: Double,
    val totalItensVendidos: Int,
    val totalTransacoes: Int
)
