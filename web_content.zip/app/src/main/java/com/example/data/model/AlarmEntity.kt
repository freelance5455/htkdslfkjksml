package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val hour: Int,
    val minute: Int,
    val label: String = "Alarm",
    val isEnabled: Boolean = true,
    /**
     * Comma-separated day integers (1 = Monday ... 7 = Sunday).
     * Empty string "" means one-time alarm.
     */
    val daysOfWeek: String = "",
    val vibrate: Boolean = true,
    val soundTone: String = "Digital Pulse",
    val customAudioPath: String? = null,
    val customAudioTitle: String? = null,
    val snoozeDurationMinutes: Int = 10,
    val isSnoozed: Boolean = false,
    val snoozeTimeMillis: Long = 0L,
    val linkedCalendarEventTitle: String? = null
) {
    val isRepeating: Boolean
        get() = daysOfWeek.isNotBlank()

    fun getDaysList(): List<Int> {
        if (daysOfWeek.isBlank()) return emptyList()
        return daysOfWeek.split(",").mapNotNull { it.trim().toIntOrNull() }
    }

    fun formattedTime(is24Hour: Boolean = false): String {
        return if (is24Hour) {
            String.format("%02d:%02d", hour, minute)
        } else {
            val h = if (hour % 12 == 0) 12 else hour % 12
            val amPm = if (hour < 12) "AM" else "PM"
            String.format("%d:%02d %s", h, minute, amPm)
        }
    }

    fun formattedDays(): String {
        val days = getDaysList()
        if (days.isEmpty()) return "Once"
        if (days.size == 7) return "Every day"
        if (days == listOf(1, 2, 3, 4, 5)) return "Weekdays"
        if (days == listOf(6, 7)) return "Weekends"

        val names = mapOf(
            1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu",
            5 to "Fri", 6 to "Sat", 7 to "Sun"
        )
        return days.mapNotNull { names[it] }.joinToString(", ")
    }
}
