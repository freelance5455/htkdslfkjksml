package com.example.data.converter

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.X509Certificate
import java.util.Base64
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Handles APK signing (v1 JAR signature scheme) using standard Java cryptography and PKCS#7.
 */
object ApkSignerUtil {

    private fun derLength(len: Int): ByteArray {
        return when {
            len < 128 -> byteArrayOf(len.toByte())
            len < 256 -> byteArrayOf(0x81.toByte(), len.toByte())
            else -> byteArrayOf(0x82.toByte(), (len shr 8).toByte(), (len and 0xFF).toByte())
        }
    }

    private fun derSequence(vararg items: ByteArray): ByteArray {
        val totalLen = items.sumOf { it.size }
        val out = ByteArrayOutputStream()
        out.write(0x30)
        out.write(derLength(totalLen))
        for (item in items) out.write(item)
        return out.toByteArray()
    }

    private fun derSet(vararg items: ByteArray): ByteArray {
        val totalLen = items.sumOf { it.size }
        val out = ByteArrayOutputStream()
        out.write(0x31)
        out.write(derLength(totalLen))
        for (item in items) out.write(item)
        return out.toByteArray()
    }

    private fun derTagged(tag: Int, bytes: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(0xA0 or tag)
        out.write(derLength(bytes.size))
        out.write(bytes)
        return out.toByteArray()
    }

    private fun derInteger(bi: BigInteger): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(0x02)
        val bytes = bi.toByteArray()
        out.write(derLength(bytes.size))
        out.write(bytes)
        return out.toByteArray()
    }

    private fun derOid(oidStr: String): ByteArray {
        val parts = oidStr.split(".").map { it.toInt() }
        val out = ByteArrayOutputStream()
        out.write(parts[0] * 40 + parts[1])
        for (i in 2 until parts.size) {
            var v = parts[i]
            val stack = mutableListOf<Int>()
            stack.add(v and 0x7F)
            v = v shr 7
            while (v > 0) {
                stack.add((v and 0x7F) or 0x80)
                v = v shr 7
            }
            for (j in stack.indices.reversed()) {
                out.write(stack[j])
            }
        }
        val encoded = out.toByteArray()
        val res = ByteArrayOutputStream()
        res.write(0x06)
        res.write(derLength(encoded.size))
        res.write(encoded)
        return res.toByteArray()
    }

    private fun derNull(): ByteArray = byteArrayOf(0x05, 0x00)

    private fun derOctetString(bytes: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(0x04)
        out.write(derLength(bytes.size))
        out.write(bytes)
        return out.toByteArray()
    }

    private fun buildPkcs7Block(signatureBytes: ByteArray, cert: X509Certificate): ByteArray {
        val sha256Oid = derSequence(derOid("2.16.840.1.101.3.4.2.1"), derNull())
        val digestAlgorithms = derSet(sha256Oid)
        val dataOid = derSequence(derOid("1.2.840.113549.1.7.1"))

        val issuerBytes = cert.issuerX500Principal.encoded
        val serialBytes = derInteger(cert.serialNumber)
        val issuerAndSerial = derSequence(issuerBytes, serialBytes)

        val rsaEncryptionOid = derSequence(derOid("1.2.840.113549.1.1.1"), derNull())
        val encryptedDigest = derOctetString(signatureBytes)

        val signerInfo = derSequence(
            derInteger(BigInteger.valueOf(1)),
            issuerAndSerial,
            sha256Oid,
            rsaEncryptionOid,
            encryptedDigest
        )
        val signerInfos = derSet(signerInfo)

        val certBytes = cert.encoded
        val certsTagged = derTagged(0, certBytes)

        val signedData = derSequence(
            derInteger(1.toBigInteger()),
            digestAlgorithms,
            dataOid,
            certsTagged,
            signerInfos
        )

        val signedDataOid = derOid("1.2.840.113549.1.7.2")
        return derSequence(
            signedDataOid,
            derTagged(0, signedData)
        )
    }

    fun signApk(
        context: Context,
        unsignedApk: File,
        signedApk: File
    ) {
        val ks = KeyStore.getInstance("PKCS12")
        context.assets.open("template/template.keystore").use { stream ->
            ks.load(stream, "android".toCharArray())
        }
        val privKey = ks.getKey("testkey", "android".toCharArray()) as PrivateKey
        val cert = ks.getCertificate("testkey") as X509Certificate

        val digest = MessageDigest.getInstance("SHA-256")
        val manifestSb = StringBuilder()
        manifestSb.append("Manifest-Version: 1.0\r\n")
        manifestSb.append("Created-By: 1.0 (APK Converter)\r\n\r\n")

        val entryDigests = mutableMapOf<String, String>()

        // 1. Read entries and compute digests
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(unsignedApk.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            val buf = ByteArray(8192)
            while (entry != null) {
                val name = entry.name
                if (!name.startsWith("META-INF/")) {
                    val baos = ByteArrayOutputStream()
                    var r: Int
                    while (zis.read(buf).also { r = it } != -1) {
                        baos.write(buf, 0, r)
                    }
                    val data = baos.toByteArray()
                    entries[name] = data

                    digest.reset()
                    val hash = digest.digest(data)
                    val base64Hash = Base64.getEncoder().encodeToString(hash)
                    entryDigests[name] = base64Hash

                    manifestSb.append("Name: $name\r\n")
                    manifestSb.append("SHA-256-Digest: $base64Hash\r\n\r\n")
                }
                entry = zis.nextEntry
            }
        }

        val manifestBytes = manifestSb.toString().toByteArray(Charsets.UTF_8)
        digest.reset()
        val manifestHash = Base64.getEncoder().encodeToString(digest.digest(manifestBytes))

        // 2. Build CERT.SF
        val sfSb = StringBuilder()
        sfSb.append("Signature-Version: 1.0\r\n")
        sfSb.append("Created-By: 1.0 (APK Converter)\r\n")
        sfSb.append("SHA-256-Digest-Manifest: $manifestHash\r\n\r\n")

        for ((name, _) in entryDigests) {
            val manifestSection = "Name: $name\r\nSHA-256-Digest: ${entryDigests[name]}\r\n\r\n"
            digest.reset()
            val sectionHash = Base64.getEncoder().encodeToString(digest.digest(manifestSection.toByteArray(Charsets.UTF_8)))
            sfSb.append("Name: $name\r\n")
            sfSb.append("SHA-256-Digest: $sectionHash\r\n\r\n")
        }

        val sfBytes = sfSb.toString().toByteArray(Charsets.UTF_8)

        // 3. Sign CERT.SF
        val signer = Signature.getInstance("SHA256withRSA")
        signer.initSign(privKey)
        signer.update(sfBytes)
        val signature = signer.sign()

        val rsaBytes = buildPkcs7Block(signature, cert)

        // 4. Write Signed APK
        ZipOutputStream(signedApk.outputStream().buffered()).use { zos ->
            // Write META-INF files first
            val mfEntry = ZipEntry("META-INF/MANIFEST.MF")
            zos.putNextEntry(mfEntry)
            zos.write(manifestBytes)
            zos.closeEntry()

            val sfEntry = ZipEntry("META-INF/CERT.SF")
            zos.putNextEntry(sfEntry)
            zos.write(sfBytes)
            zos.closeEntry()

            val rsaEntry = ZipEntry("META-INF/CERT.RSA")
            zos.putNextEntry(rsaEntry)
            zos.write(rsaBytes)
            zos.closeEntry()

            // Write all other entries
            for ((name, data) in entries) {
                val ze = ZipEntry(name)
                zos.putNextEntry(ze)
                zos.write(data)
                zos.closeEntry()
            }
        }
    }
}
