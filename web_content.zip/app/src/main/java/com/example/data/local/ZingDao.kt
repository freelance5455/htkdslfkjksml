package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ZingDao {

    // --- Videos ---
    @Query("SELECT * FROM videos WHERE isTakenDown = 0 ORDER BY timestamp DESC")
    fun getAllVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos ORDER BY timestamp DESC")
    fun getAllVideosAdmin(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE creatorId = :creatorId AND isTakenDown = 0 ORDER BY timestamp DESC")
    fun getVideosByCreator(creatorId: String): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE isLiked = 1 AND isTakenDown = 0 ORDER BY timestamp DESC")
    fun getLikedVideos(): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE (caption LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' OR creatorHandle LIKE '%' || :query || '%') AND isTakenDown = 0")
    fun searchVideos(query: String): Flow<List<VideoEntity>>

    @Query("SELECT * FROM videos WHERE id = :id LIMIT 1")
    suspend fun getVideoById(id: String): VideoEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: VideoEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideos(videos: List<VideoEntity>)

    @Update
    suspend fun updateVideo(video: VideoEntity)

    @Query("UPDATE videos SET isLiked = :isLiked, likesCount = :likesCount WHERE id = :id")
    suspend fun updateLike(id: String, isLiked: Boolean, likesCount: Int)

    @Query("UPDATE videos SET viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun incrementViews(id: String)

    @Query("UPDATE videos SET commentsCount = commentsCount + 1 WHERE id = :id")
    suspend fun incrementCommentsCount(id: String)

    @Query("UPDATE videos SET giftCoins = giftCoins + :coins, adRevenue = adRevenue + :revenueIncrement WHERE id = :id")
    suspend fun rewardVideo(id: String, coins: Int, revenueIncrement: Double)

    @Query("UPDATE videos SET isReported = 1 WHERE id = :id")
    suspend fun markVideoReported(id: String)

    @Query("UPDATE videos SET isTakenDown = :isTakenDown WHERE id = :id")
    suspend fun setVideoTakeDown(id: String, isTakenDown: Boolean)

    @Query("DELETE FROM videos WHERE id = :id")
    suspend fun deleteVideo(id: String)

    // --- Users ---
    @Query("SELECT * FROM users ORDER BY followersCount DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserById(id: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserSync(id: String): UserEntity?

    @Query("SELECT * FROM users WHERE username LIKE '%' || :query || '%' OR displayName LIKE '%' || :query || '%'")
    fun searchUsers(query: String): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserEntity>)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET isFollowing = :isFollowing, followersCount = followersCount + :delta WHERE id = :id")
    suspend fun updateFollowStatus(id: String, isFollowing: Boolean, delta: Int)

    @Query("UPDATE users SET isBlocked = :isBlocked WHERE id = :id")
    suspend fun updateUserBlocked(id: String, isBlocked: Boolean)

    @Query("UPDATE users SET walletBalance = walletBalance + :amount WHERE id = :id")
    suspend fun addEarnings(id: String, amount: Double)

    @Query("UPDATE users SET coinBalance = coinBalance - :coins WHERE id = :id")
    suspend fun deductCoins(id: String, coins: Int)

    // --- Comments ---
    @Query("SELECT * FROM comments WHERE videoId = :videoId ORDER BY timestamp DESC")
    fun getCommentsForVideo(videoId: String): Flow<List<CommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComments(comments: List<CommentEntity>)

    @Query("UPDATE comments SET isLiked = :isLiked, likesCount = :likesCount WHERE id = :id")
    suspend fun updateCommentLike(id: String, isLiked: Boolean, likesCount: Int)

    // --- Notifications ---
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationRead(id: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllNotificationsRead()

    // --- Payouts ---
    @Query("SELECT * FROM payouts ORDER BY requestDate DESC")
    fun getAllPayouts(): Flow<List<PayoutEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayout(payout: PayoutEntity)

    @Query("UPDATE payouts SET status = :status WHERE id = :id")
    suspend fun updatePayoutStatus(id: String, status: String)

    // --- Reports ---
    @Query("SELECT * FROM reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<ReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity)

    @Query("UPDATE reports SET status = :status WHERE id = :id")
    suspend fun updateReportStatus(id: String, status: String)
}
