package com.example.data.firebase

import com.example.data.model.AdInquiry
import com.example.data.model.BusinessAd
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalRequest
import com.example.util.PLATFORM_COMMISSION_RATE
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.Date
import java.util.UUID

class AdminRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("Admin must be signed in with Google.")

    fun observeAllUsers(): Flow<List<UserProfile>> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("users")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "users", expectedUid)
            }
    }

    fun observeAllWithdrawals(): Flow<List<WithdrawalRequest>> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("withdrawals")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(WithdrawalRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "withdrawals", expectedUid)
            }
    }

    fun observeAllBusinessAds(): Flow<List<BusinessAd>> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("business_ads")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(BusinessAd::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "business_ads", expectedUid)
            }
    }

    fun observeAllAdInquiries(): Flow<List<AdInquiry>> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("ad_inquiries")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(AdInquiry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "ad_inquiries", expectedUid)
            }
    }

    fun observeAllTransactions(): Flow<List<WalletTransaction>> {
        val expectedUid = auth.currentUser?.uid
        return db.collection("wallet_transactions")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(WalletTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.toDate()?.time ?: 0L }
            }
            .catch { error ->
                logAndRethrowFlowError(error, OperationType.LIST, "wallet_transactions", expectedUid)
            }
    }

    suspend fun updateAuctionStatus(auctionId: String, newStatus: String): Result<Unit> =
        runSafeWrite(OperationType.UPDATE, "auctions/$auctionId") {
            requireUserId()
            db.collection("auctions").document(auctionId).update(
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun toggleAuctionFeatured(auctionId: String, featured: Boolean): Result<Unit> =
        runSafeWrite(OperationType.UPDATE, "auctions/$auctionId") {
            requireUserId()
            db.collection("auctions").document(auctionId).update(
                mapOf(
                    "featured" to featured,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun deleteAuction(auctionId: String): Result<Unit> =
        runSafeWrite(OperationType.DELETE, "auctions/$auctionId") {
            requireUserId()
            db.collection("auctions").document(auctionId).delete().await()
        }

    suspend fun toggleUserStatus(userId: String, newStatus: String): Result<Unit> =
        runSafeWrite(OperationType.UPDATE, "users/$userId") {
            requireUserId()
            db.collection("users").document(userId).update(
                mapOf(
                    "accountStatus" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

    suspend fun processWithdrawal(
        withdrawalId: String,
        approve: Boolean,
        adminNote: String
    ): Result<Unit> = runSafeWrite(OperationType.UPDATE, "withdrawals/$withdrawalId") {
        requireUserId()
        val wdRef = db.collection("withdrawals").document(withdrawalId)
        val txRef = db.collection("wallet_transactions").document()
        val refCode = "TA-ADM-${UUID.randomUUID().toString().take(6).uppercase()}"

        db.runTransaction { tx ->
            val wdSnap = tx.get(wdRef)
            require(wdSnap.exists()) { "Withdrawal request not found." }
            require(wdSnap.getString("status") == "PENDING") { "Withdrawal is already processed." }
            val targetUserId = wdSnap.getString("userId") ?: ""
            val amount = wdSnap.getLong("amount") ?: 0L
            val bankName = wdSnap.getString("bankName") ?: ""

            val walletRef = db.collection("wallets").document(targetUserId)
            val walletSnap = tx.get(walletRef)
            val available = walletSnap.getLong("availableBalance") ?: 0L
            val pending = walletSnap.getLong("pendingWithdrawal") ?: 0L

            val newPending = (pending - amount).coerceAtLeast(0L)
            val newAvailable = if (approve) available else available + amount
            val newStatus = if (approve) "APPROVED" else "DECLINED"

            tx.update(
                wdRef,
                mapOf(
                    "status" to newStatus,
                    "adminNote" to adminNote.trim().take(200),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            tx.update(
                walletRef,
                mapOf(
                    "availableBalance" to newAvailable,
                    "pendingWithdrawal" to newPending,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            tx.set(
                txRef,
                mapOf(
                    "userId" to targetUserId,
                    "type" to if (approve) "WITHDRAWAL_APPROVED" else "WITHDRAWAL_DECLINED",
                    "amount" to amount,
                    "feeAmount" to 0L,
                    "description" to if (approve) {
                        "Disbursed withdrawal to $bankName".take(240)
                    } else {
                        "Withdrawal declined & refunded: ${adminNote.ifBlank { "Verification issue" }}".take(240)
                    },
                    "status" to if (approve) "COMPLETED" else "DECLINED",
                    "referenceCode" to refCode,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
        }.await()
    }

    suspend fun saveBusinessAd(
        adId: String?,
        businessName: String,
        tagline: String,
        ctaLabel: String,
        category: String,
        negotiatedFee: Long,
        status: String
    ): Result<Unit> = runSafeWrite(OperationType.WRITE, "business_ads") {
        val adminUid = requireUserId()
        require(businessName.trim().length in 2..80) { "Business name must be 2–80 characters." }
        require(tagline.trim().length in 4..160) { "Tagline must be 4–160 characters." }
        require(ctaLabel.trim().length in 2..32) { "CTA label must be 2–32 characters." }

        if (adId.isNullOrBlank()) {
            db.collection("business_ads").document().set(
                mapOf(
                    "businessName" to businessName.trim(),
                    "tagline" to tagline.trim(),
                    "ctaLabel" to ctaLabel.trim(),
                    "category" to category.trim().ifBlank { "Partner" }.take(40),
                    "negotiatedFee" to negotiatedFee.coerceAtLeast(0L),
                    "status" to status,
                    "createdBy" to adminUid,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            db.collection("business_ads").document(adId).update(
                mapOf(
                    "businessName" to businessName.trim(),
                    "tagline" to tagline.trim(),
                    "ctaLabel" to ctaLabel.trim(),
                    "category" to category.trim().ifBlank { "Partner" }.take(40),
                    "negotiatedFee" to negotiatedFee.coerceAtLeast(0L),
                    "status" to status,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    suspend fun deleteBusinessAd(adId: String): Result<Unit> =
        runSafeWrite(OperationType.DELETE, "business_ads/$adId") {
            requireUserId()
            db.collection("business_ads").document(adId).delete().await()
        }

    suspend fun updateAdInquiryStatus(
        inquiryId: String,
        status: String,
        adminNote: String
    ): Result<Unit> = runSafeWrite(OperationType.UPDATE, "ad_inquiries/$inquiryId") {
        requireUserId()
        db.collection("ad_inquiries").document(inquiryId).update(
            mapOf(
                "status" to status,
                "adminNote" to adminNote.trim().take(200),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun seedShowcaseMarketplace(): Result<Unit> = runSafeWrite(OperationType.WRITE, "auctions") {
        val adminUid = requireUserId()
        val curatorId = "curator_truea"
        val curatorWalletRef = db.collection("wallets").document(curatorId)
        val existingCuratorWallet = curatorWalletRef.get().await()

        val batch = db.batch()
        if (!existingCuratorWallet.exists()) {
            batch.set(
                curatorWalletRef,
                mapOf(
                    "userId" to curatorId,
                    "availableBalance" to 0L,
                    "pendingWithdrawal" to 0L,
                    "totalDeposited" to 0L,
                    "totalEarned" to 0L,
                    "totalCommissionPaid" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }

        val nowMs = System.currentTimeMillis()
        val demo1Ref = db.collection("auctions").document("demo_lot_chronograph")
        batch.set(
            demo1Ref,
            mapOf(
                "sellerId" to curatorId,
                "sellerName" to "True A Curator",
                "sellerBidderNumber" to "TA-1000",
                "title" to "Emerald Dial Automatic Chronograph",
                "description" to "Swiss mechanical chronograph with sapphire exhibition caseback, brushed steel bracelet, and verified provenance certificate.",
                "category" to "Watches",
                "imageItems" to listOf("preset:chronograph"),
                "startingBid" to 250000L,
                "minIncrement" to 10000L,
                "currentBid" to 0L,
                "bidCount" to 0L,
                "highestBidderId" to "",
                "highestBidderNumber" to "",
                "featured" to true,
                "featuredFeePaid" to 2000L,
                "commissionRate" to PLATFORM_COMMISSION_RATE,
                "commissionAmount" to 0L,
                "sellerPayout" to 0L,
                "status" to "ACTIVE",
                "endsAt" to Timestamp(Date(nowMs + 18 * 3600_000L)),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )

        val demo2Ref = db.collection("auctions").document("demo_lot_sculpture")
        batch.set(
            demo2Ref,
            mapOf(
                "sellerId" to curatorId,
                "sellerName" to "True A Curator",
                "sellerBidderNumber" to "TA-1000",
                "title" to "Bronze & Emerald Marble Vessel",
                "description" to "Handcrafted contemporary gallery vessel carved from green serpentine marble and cast bronze. Signed edition 1 of 1.",
                "category" to "Art",
                "imageItems" to listOf("preset:sculpture"),
                "startingBid" to 120000L,
                "minIncrement" to 5000L,
                "currentBid" to 0L,
                "bidCount" to 0L,
                "highestBidderId" to "",
                "highestBidderNumber" to "",
                "featured" to true,
                "featuredFeePaid" to 2000L,
                "commissionRate" to PLATFORM_COMMISSION_RATE,
                "commissionAmount" to 0L,
                "sellerPayout" to 0L,
                "status" to "ACTIVE",
                "endsAt" to Timestamp(Date(nowMs + 42 * 3600_000L)),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )

        val demo3Ref = db.collection("auctions").document("demo_lot_settled")
        batch.set(
            demo3Ref,
            mapOf(
                "sellerId" to curatorId,
                "sellerName" to "True A Curator",
                "sellerBidderNumber" to "TA-1000",
                "title" to "Collector Velvet Showcase Vault",
                "description" to "Archive reference sale illustrating True A transparent 3% commission calculation (₦500,000 sale -> ₦15,000 commission, ₦485,000 payout).",
                "category" to "Collectibles",
                "imageItems" to listOf("preset:hero"),
                "startingBid" to 350000L,
                "minIncrement" to 25000L,
                "currentBid" to 500000L,
                "bidCount" to 6L,
                "highestBidderId" to "archive_bidder",
                "highestBidderNumber" to "TA-1008",
                "featured" to false,
                "featuredFeePaid" to 0L,
                "commissionRate" to PLATFORM_COMMISSION_RATE,
                "commissionAmount" to 15000L,
                "sellerPayout" to 485000L,
                "status" to "SETTLED",
                "endsAt" to Timestamp(Date(nowMs - 3600_000L)),
                "settledAt" to FieldValue.serverTimestamp(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )

        val adRef = db.collection("business_ads").document("demo_ad_vault")
        batch.set(
            adRef,
            mapOf(
                "businessName" to "Eko Armored Vault & Logistics",
                "tagline" to "Insured same-day pickup & provenance inspection across Lagos and Abuja.",
                "ctaLabel" to "Negotiate Ad",
                "category" to "Verified Partner",
                "negotiatedFee" to 75000L,
                "status" to "ACTIVE",
                "createdBy" to adminUid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        )

        batch.commit().await()
    }

    private suspend inline fun runSafeWrite(
        op: OperationType,
        path: String,
        crossinline block: suspend () -> Unit
    ): Result<Unit> {
        return try {
            block()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, op, path)
            Result.failure(e)
        }
    }

    private fun logAndRethrowFlowError(
        error: Throwable,
        op: OperationType,
        path: String,
        expectedUid: String?
    ): Nothing {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && expectedUid != null && auth.currentUser?.uid == expectedUid) {
            handleFirestoreError(exceptionToLog, op, path)
        }
        throw error
    }
}
