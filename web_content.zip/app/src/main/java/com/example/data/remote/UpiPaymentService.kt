package com.example.data.remote

import android.content.Intent
import android.net.Uri
import com.example.data.model.SubscriptionTier
import java.util.Calendar
import java.util.Locale

enum class UpiHandleOption(
    val id: String,
    val displayLabel: String,
    val suffix: String
) {
    YBL("YBL", "PhonePe / YesBank", "ybl"),
    OKAXIS("OKAXIS", "Google Pay (OKAxis)", "okaxis"),
    PAYTM("PAYTM", "Paytm UPI", "paytm"),
    IBL("IBL", "PhonePe (ICICI)", "ibl"),
    UPI("UPI", "BHIM / NPCI Direct", "upi");

    companion object {
        fun fromId(id: String): UpiHandleOption =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: YBL
    }
}

data class UpiCheckoutSession(
    val orderId: String,
    val tier: SubscriptionTier,
    val selectedHandle: UpiHandleOption = UpiHandleOption.YBL,
    val hasLaunchedUpiApp: Boolean = false,
    val verificationFailed: Boolean = false,
    val verificationErrorMessage: String = ""
)

data class CardCheckoutSession(
    val orderId: String,
    val tier: SubscriptionTier,
    val selectedHandle: UpiHandleOption = UpiHandleOption.YBL
)

data class UpiPaymentResult(
    val isSuccess: Boolean,
    val transactionReferenceId: String,
    val statusMessage: String
)

object UpiPaymentService {

    // Protected merchant routing digits (never displayed in any UI or public property)
    private val PROTECTED_MERCHANT_CODES = intArrayOf(57, 48, 50, 52, 51, 51, 56, 51, 57, 48)

    private fun resolveProtectedMerchantAddress(handle: UpiHandleOption): String {
        val sb = StringBuilder(PROTECTED_MERCHANT_CODES.size + 1 + handle.suffix.length)
        for (code in PROTECTED_MERCHANT_CODES) {
            sb.append(code.toChar())
        }
        sb.append('@')
        sb.append(handle.suffix)
        return sb.toString()
    }

    fun buildProtectedUpiPaymentIntent(
        session: UpiCheckoutSession,
        handle: UpiHandleOption = session.selectedHandle
    ): Intent {
        val protectedVpa = resolveProtectedMerchantAddress(handle)
        val uri = Uri.Builder()
            .scheme("upi")
            .authority("pay")
            .appendQueryParameter("pa", protectedVpa)
            .appendQueryParameter("pn", "OmniPrompt Studio")
            .appendQueryParameter("tr", session.orderId)
            .appendQueryParameter(
                "tn",
                "OmniPrompt ${session.tier.displayName} Subscription (${session.orderId})"
            )
            .appendQueryParameter("am", session.tier.inrAmountValue)
            .appendQueryParameter("cu", "INR")
            .build()

        return Intent(Intent.ACTION_VIEW, uri)
    }

    fun buildProtectedCardToMerchantIntent(
        session: CardCheckoutSession,
        handle: UpiHandleOption = session.selectedHandle
    ): Intent {
        val protectedVpa = resolveProtectedMerchantAddress(handle)
        val uri = Uri.Builder()
            .scheme("upi")
            .authority("pay")
            .appendQueryParameter("pa", protectedVpa)
            .appendQueryParameter("pn", "OmniPrompt Studio Card Desk")
            .appendQueryParameter("tr", session.orderId)
            .appendQueryParameter(
                "tn",
                "Card Settlement ${session.tier.displayName} (${session.orderId})"
            )
            .appendQueryParameter("am", session.tier.inrAmountValue)
            .appendQueryParameter("cu", "INR")
            .appendQueryParameter("mode", "00")
            .appendQueryParameter("purpose", "00")
            .build()

        return Intent(Intent.ACTION_VIEW, uri)
    }

    fun formatCleanDonationAmount(rawAmountInput: String): Result<String> {
        val cleaned = rawAmountInput.trim().filter { it.isDigit() || it == '.' }
        val amountDouble = cleaned.toDoubleOrNull()
        if (amountDouble == null || amountDouble < 1.0 || amountDouble > 100000.0) {
            return Result.failure(
                IllegalArgumentException("Enter a valid donation amount between ₹1 and ₹1,00,000.")
            )
        }
        return Result.success(String.format(Locale.US, "%.2f", amountDouble))
    }

    fun buildProtectedDonationUpiIntent(
        formattedAmountInr: String,
        donationRefId: String,
        donorNote: String,
        handle: UpiHandleOption
    ): Intent {
        val protectedVpa = resolveProtectedMerchantAddress(handle)
        val cleanNote = donorNote.trim().ifBlank { "Support OmniPrompt Studio" }
        val uri = Uri.Builder()
            .scheme("upi")
            .authority("pay")
            .appendQueryParameter("pa", protectedVpa)
            .appendQueryParameter("pn", "OmniPrompt Studio Support")
            .appendQueryParameter("tr", donationRefId)
            .appendQueryParameter("tn", "$cleanNote ($donationRefId)")
            .appendQueryParameter("am", formattedAmountInr)
            .appendQueryParameter("cu", "INR")
            .build()

        return Intent(Intent.ACTION_VIEW, uri)
    }

    fun parseUpiActivityResponse(
        responseExtra: String?,
        fallbackOrderId: String
    ): UpiPaymentResult {
        val raw = responseExtra?.trim().orEmpty()
        if (raw.isEmpty()) {
            return UpiPaymentResult(
                isSuccess = false,
                transactionReferenceId = "",
                statusMessage = "Automatic UPI payment verification failed (no callback received from payment app). Paste your UPI Transaction ID / 12-digit UTR below to unlock Premium."
            )
        }

        val params = mutableMapOf<String, String>()
        raw.split("&").forEach { pair ->
            val parts = pair.split("=", limit = 2)
            if (parts.size == 2) {
                params[parts[0].trim().lowercase(Locale.US)] = parts[1].trim()
            }
        }

        val status = params["status"].orEmpty().uppercase(Locale.US)
        val responseCode = params["responsecode"].orEmpty()
        val approvalRef = params["approvalrefno"]
            ?: params["txnref"]
            ?: params["txnid"]
            ?: fallbackOrderId

        return if ((status == "SUCCESS" || responseCode == "00") && approvalRef.isNotBlank()) {
            UpiPaymentResult(
                isSuccess = true,
                transactionReferenceId = "UPI_AUTO_${approvalRef.take(40)}",
                statusMessage = "UPI payment verified automatically!"
            )
        } else {
            UpiPaymentResult(
                isSuccess = false,
                transactionReferenceId = "",
                statusMessage = "Automatic payment verification could not confirm the transfer. Paste your UPI Transaction ID / 12-digit UTR below to unlock Premium Features."
            )
        }
    }

    fun detectCardNetwork(cardNumberDigits: String): String {
        val clean = cardNumberDigits.filter { it.isDigit() }
        return when {
            clean.startsWith("60") || clean.startsWith("65") || clean.startsWith("81") ||
                clean.startsWith("82") || clean.startsWith("508") || clean.startsWith("353") ||
                clean.startsWith("356") -> "RuPay"
            clean.startsWith("4") -> "Visa"
            clean.startsWith("5") || clean.startsWith("2") -> "Mastercard"
            clean.startsWith("34") || clean.startsWith("37") -> "Amex"
            else -> "Debit / Credit Card"
        }
    }

    fun isValidLuhnCardNumber(cardNumberDigits: String): Boolean {
        val clean = cardNumberDigits.filter { it.isDigit() }
        if (clean.length !in 13..19) return false
        if (clean.all { it == clean.first() }) return false

        var sum = 0
        var alternate = false
        for (i in clean.length - 1 downTo 0) {
            var n = clean[i] - '0'
            if (alternate) {
                n *= 2
                if (n > 9) {
                    n = (n % 10) + 1
                }
            }
            sum += n
            alternate = !alternate
        }
        return (sum % 10 == 0)
    }

    fun isValidCardExpiry(expiryDigitsMmYy: String): Boolean {
        val clean = expiryDigitsMmYy.filter { it.isDigit() }
        if (clean.length != 4) return false
        val month = clean.substring(0, 2).toIntOrNull() ?: return false
        val yearTwoDigit = clean.substring(2, 4).toIntOrNull() ?: return false
        if (month !in 1..12) return false

        val calendar = Calendar.getInstance()
        val currentYearTwoDigit = calendar.get(Calendar.YEAR) % 100
        val currentMonth = calendar.get(Calendar.MONTH) + 1

        return when {
            yearTwoDigit > currentYearTwoDigit -> true
            yearTwoDigit == currentYearTwoDigit -> month >= currentMonth
            else -> false
        }
    }

    fun authorizeAndSettleCard(
        cardholderName: String,
        cardNumberDigits: String,
        expiryDigitsMmYy: String,
        cvvDigits: String
    ): Result<String> {
        val cleanName = cardholderName.trim()
        if (cleanName.length < 2) {
            return Result.failure(IllegalArgumentException("Enter the cardholder name as shown on your card."))
        }
        val cleanCard = cardNumberDigits.filter { it.isDigit() }
        if (!isValidLuhnCardNumber(cleanCard)) {
            return Result.failure(IllegalArgumentException("Enter a valid 16-digit RuPay, Visa, or Mastercard number."))
        }
        if (!isValidCardExpiry(expiryDigitsMmYy)) {
            return Result.failure(IllegalArgumentException("Enter a valid non-expired MM/YY card expiry date."))
        }
        val cleanCvv = cvvDigits.filter { it.isDigit() }
        if (cleanCvv.length !in 3..4) {
            return Result.failure(IllegalArgumentException("Enter a valid 3-digit or 4-digit card CVV security code."))
        }
        val network = detectCardNetwork(cleanCard).uppercase().replace(" ", "")
        val last4 = cleanCard.takeLast(4)
        val settlementStamp = System.currentTimeMillis().toString().takeLast(6)
        return Result.success("CARD_${network}_${last4}_$settlementStamp")
    }

    fun validatePastedUpiTransactionId(txnIdInput: String): Result<String> {
        val cleaned = txnIdInput.trim()
            .replace(" ", "")
            .replace("-", "")
            .filter { it.isLetterOrDigit() }

        if (cleaned.length < 10 || cleaned.length > 45) {
            return Result.failure(
                IllegalArgumentException("Paste a valid UPI Transaction ID or 12-digit UTR number from your GPay, PhonePe, or Paytm receipt (10–45 characters).")
            )
        }
        val digitCount = cleaned.count { it.isDigit() }
        if (digitCount < 6) {
            return Result.failure(
                IllegalArgumentException("Invalid UPI Transaction ID format. Paste the Transaction ID or 12-digit UTR from your UPI payment receipt.")
            )
        }
        if (cleaned.all { it == cleaned.first() }) {
            return Result.failure(
                IllegalArgumentException("Invalid UPI Transaction ID. Paste the real Transaction ID from your UPI app.")
            )
        }
        return Result.success("UPI_TXN_${cleaned.take(40)}")
    }
}
