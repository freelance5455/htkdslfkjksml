package com.example.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest

data class ImportProgress(
    val current: Int,
    val total: Int,
    val currentFileName: String
)

data class ImportResult(
    val totalProcessed: Int,
    val importedCount: Int,
    val duplicateCount: Int,
    val failedCount: Int,
    val failureReasons: List<String>
)

data class StorageStats(
    val songsCount: Int,
    val musicFilesSizeBytes: Long,
    val artworkFilesSizeBytes: Long,
    val orphanedFilesCount: Int,
    val orphanedFilesSizeBytes: Long
)

class MusicFileManager(
    private val context: Context,
    private val repository: MusicRepository
) {
    private val musicDir: File get() = File(context.filesDir, "music").apply { if (!exists()) mkdirs() }
    private val artworkDir: File get() = File(context.filesDir, "artwork").apply { if (!exists()) mkdirs() }

    suspend fun importAudioFiles(
        uris: List<Uri>,
        onProgress: (ImportProgress) -> Unit
    ): ImportResult = withContext(Dispatchers.IO) {
        var importedCount = 0
        var duplicateCount = 0
        var failedCount = 0
        val failureReasons = mutableListOf<String>()

        uris.forEachIndexed { index, uri ->
            val fileName = queryFileName(uri) ?: "Audio_${System.currentTimeMillis()}"
            onProgress(ImportProgress(index + 1, uris.size, fileName))

            try {
                // 1. Calculate SHA-256 hash to detect duplicates reliably
                val hash = calculateSha256(uri)
                if (hash.isEmpty()) {
                    failedCount++
                    failureReasons.add("$fileName: Unable to read file content")
                    return@forEachIndexed
                }

                // 2. Check if already exists in library
                val existingSong = repository.getSongByHash(hash)
                if (existingSong != null) {
                    duplicateCount++
                    return@forEachIndexed
                }

                // 3. Determine file extension
                val extension = getExtension(fileName)
                val destFile = File(musicDir, "${hash}.$extension")

                // 4. Copy to app-managed storage if not already physically present
                if (!destFile.exists()) {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(destFile).use { output ->
                            input.copyTo(output)
                        }
                    } ?: throw IllegalStateException("Cannot open input stream for $fileName")
                }

                // 5. Extract metadata with MediaMetadataRetriever
                val metadata = extractMetadata(destFile, fileName, hash)

                // 6. Insert into database
                repository.insertSong(metadata)
                importedCount++

            } catch (e: Exception) {
                failedCount++
                failureReasons.add("$fileName: ${e.localizedMessage ?: "Unknown error"}")
            }
        }

        ImportResult(
            totalProcessed = uris.size,
            importedCount = importedCount,
            duplicateCount = duplicateCount,
            failedCount = failedCount,
            failureReasons = failureReasons
        )
    }

    private fun extractMetadata(file: File, originalFileName: String, contentHash: String): SongEntity {
        val retriever = MediaMetadataRetriever()
        var title: String? = null
        var artist: String? = null
        var album: String? = null
        var genre: String? = null
        var year: String? = null
        var durationMs = 0L
        var embeddedArtworkPath: String? = null

        try {
            retriever.setDataSource(file.absolutePath)
            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
            album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            genre = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE)
            year = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR)
                ?: retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DATE)

            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durationStr?.toLongOrNull() ?: 0L

            // Check for embedded album artwork
            val picture = retriever.embeddedPicture
            if (picture != null && picture.isNotEmpty()) {
                val artFile = File(artworkDir, "art_${contentHash.take(16)}.jpg")
                if (!artFile.exists()) {
                    FileOutputStream(artFile).use { it.write(picture) }
                }
                embeddedArtworkPath = artFile.absolutePath
            }
        } catch (_: Exception) {
            // Fallback gracefully on corrupt or partial headers
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        val cleanedTitle = if (!title.isNullOrBlank()) {
            title.trim()
        } else {
            originalFileName.substringBeforeLast(".").trim()
        }

        val cleanedArtist = if (!artist.isNullOrBlank()) artist.trim() else "Unknown Artist"
        val cleanedAlbum = if (!album.isNullOrBlank()) album.trim() else "Unknown Album"

        return SongEntity(
            contentHash = contentHash,
            title = cleanedTitle,
            artist = cleanedArtist,
            album = cleanedAlbum,
            genre = genre?.trim() ?: "",
            year = year?.trim() ?: "",
            durationMs = durationMs,
            filePath = file.absolutePath,
            originalFileName = originalFileName,
            fileSizeBytes = file.length(),
            mimeType = getMimeType(originalFileName),
            customArtworkPath = embeddedArtworkPath,
            isFavorite = false,
            playCount = 0,
            dateAddedTimestamp = System.currentTimeMillis()
        )
    }

    private fun queryFileName(uri: Uri): String? {
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            return cursor.getString(nameIndex)
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return uri.lastPathSegment
    }

    private fun calculateSha256(uri: Uri): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val buffer = ByteArray(16384)
            context.contentResolver.openInputStream(uri)?.use { stream ->
                var read: Int
                while (stream.read(buffer).also { read = it } != -1) {
                    digest.update(buffer, 0, read)
                }
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            ""
        }
    }

    private fun getExtension(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "")
        return if (ext.isNotBlank()) ext.lowercase() else "mp3"
    }

    private fun getMimeType(fileName: String): String {
        return when (getExtension(fileName)) {
            "mp3" -> "audio/mpeg"
            "m4a", "aac" -> "audio/mp4"
            "wav" -> "audio/wav"
            "ogg" -> "audio/ogg"
            "flac" -> "audio/flac"
            else -> "audio/*"
        }
    }

    suspend fun saveCustomArtwork(imageUri: Uri, prefix: String = "art"): String? = withContext(Dispatchers.IO) {
        try {
            val artFile = File(artworkDir, "${prefix}_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(imageUri)?.use { input ->
                FileOutputStream(artFile).use { output ->
                    input.copyTo(output)
                }
            }
            artFile.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    suspend fun deleteArtworkFile(path: String?) = withContext(Dispatchers.IO) {
        if (!path.isNullOrBlank()) {
            try {
                val file = File(path)
                if (file.exists() && file.parentFile?.absolutePath == artworkDir.absolutePath) {
                    file.delete()
                }
            } catch (_: Exception) {}
        }
    }

    suspend fun getStorageStats(songsCount: Int): StorageStats = withContext(Dispatchers.IO) {
        val musicFiles = musicDir.listFiles() ?: emptyArray()
        val musicBytes = musicFiles.sumOf { it.length() }

        val artFiles = artworkDir.listFiles() ?: emptyArray()
        val artBytes = artFiles.sumOf { it.length() }

        val referencedPaths = repository.getAllSongFilePaths().toSet()
        val orphanedMusicFiles = musicFiles.filter { it.absolutePath !in referencedPaths }

        StorageStats(
            songsCount = songsCount,
            musicFilesSizeBytes = musicBytes,
            artworkFilesSizeBytes = artBytes,
            orphanedFilesCount = orphanedMusicFiles.size,
            orphanedFilesSizeBytes = orphanedMusicFiles.sumOf { it.length() }
        )
    }

    suspend fun cleanOrphanedFiles(): Int = withContext(Dispatchers.IO) {
        val musicFiles = musicDir.listFiles() ?: emptyArray()
        val referencedPaths = repository.getAllSongFilePaths().toSet()
        val orphans = musicFiles.filter { it.absolutePath !in referencedPaths }
        var deletedCount = 0
        orphans.forEach {
            if (it.delete()) deletedCount++
        }

        // Clean unreferenced artwork too
        val artworkFiles = artworkDir.listFiles() ?: emptyArray()
        val referencedArt = repository.getAllArtworkPaths().toSet()
        artworkFiles.forEach {
            if (it.absolutePath !in referencedArt) {
                it.delete()
            }
        }

        deletedCount
    }
}
