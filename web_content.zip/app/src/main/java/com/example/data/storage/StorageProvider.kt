package com.example.data.storage

import com.example.data.model.ConflictAction
import com.example.data.model.ConflictPrompt
import com.example.data.model.FileCategory
import com.example.data.model.FileNode
import com.example.data.model.StorageAnalysisReport
import com.example.data.model.StorageVolumeInfo
import com.example.data.model.TransferProgress
import java.io.InputStream

/**
 * Unified StorageProvider contract supporting device workspace storage,
 * persisted Storage Access Framework (SAF) directory trees, and USB/OTG volumes.
 *
 * Native/Capacitor Plugin Mapping Reference:
 * - listRoots / getStorageInfo -> Android StatFs + StorageManager + UsbManager (or @capacitor/filesystem + USB OTG plugin)
 * - list / stat / mkdir / rename / delete -> java.io.File & androidx.documentfile.provider.DocumentFile
 * - copy / move -> Buffered stream transfer with conflict resolution callback & byte progress
 */
interface StorageProvider {
    suspend fun listRoots(): List<StorageVolumeInfo>

    suspend fun list(path: String, showHidden: Boolean): List<FileNode>

    suspend fun read(path: String): ByteArray

    fun openReadStream(path: String): InputStream?

    suspend fun write(parentPath: String, fileName: String, bytes: ByteArray, mimeType: String, overwrite: Boolean = true): FileNode

    suspend fun copy(
        sourcePaths: List<String>,
        destinationDirPath: String,
        onProgress: (TransferProgress) -> Unit,
        onConflict: suspend (ConflictPrompt) -> ConflictAction,
        isCancelled: () -> Boolean
    ): Int

    suspend fun move(
        sourcePaths: List<String>,
        destinationDirPath: String,
        onProgress: (TransferProgress) -> Unit,
        onConflict: suspend (ConflictPrompt) -> ConflictAction,
        isCancelled: () -> Boolean
    ): Int

    suspend fun deleteToTrash(paths: List<String>): Int

    suspend fun deletePermanently(paths: List<String>): Int

    suspend fun rename(path: String, newName: String): FileNode

    suspend fun mkdir(parentPath: String, folderName: String): FileNode

    suspend fun stat(path: String): FileNode?

    suspend fun getStorageInfo(): List<StorageVolumeInfo>

    suspend fun compressToZip(
        sourcePaths: List<String>,
        destinationDirPath: String,
        zipFileName: String,
        onProgress: (TransferProgress) -> Unit
    ): FileNode

    suspend fun extractZip(
        zipPath: String,
        destinationDirPath: String,
        onProgress: (TransferProgress) -> Unit
    ): FileNode

    suspend fun queryByCategory(category: FileCategory, showHidden: Boolean): List<FileNode>

    suspend fun queryRecentFiles(limit: Int = 20): List<FileNode>

    suspend fun analyzeStorage(): StorageAnalysisReport
}
