package com.example.data.notes

class UndoRedoManager(
    private val maxHistorySize: Int = 50
) {
    data class Snapshot(
        val title: String,
        val document: RichNoteDocument,
        val timestamp: Long = System.currentTimeMillis()
    )

    private val history = mutableListOf<Snapshot>()
    private var currentIndex = -1

    fun initialize(title: String, document: RichNoteDocument) {
        history.clear()
        history.add(Snapshot(title = title, document = document))
        currentIndex = 0
    }

    fun pushSnapshot(title: String, document: RichNoteDocument, force: Boolean = false) {
        if (currentIndex >= 0 && currentIndex < history.size) {
            val current = history[currentIndex]
            // Skip if identical to current snapshot
            if (current.title == title && current.document == document) {
                return
            }

            // Debounce small consecutive keystrokes within 500ms unless forced
            val timeDiff = System.currentTimeMillis() - current.timestamp
            if (!force && timeDiff < 500 && current.title == title && current.document.blocks.size == document.blocks.size) {
                // Replace current top snapshot with newer version
                history[currentIndex] = Snapshot(title = title, document = document)
                return
            }
        }

        // If we are not at the end of the history stack, truncate forward redo history
        if (currentIndex < history.size - 1) {
            val keepCount = currentIndex + 1
            while (history.size > keepCount) {
                history.removeAt(history.size - 1)
            }
        }

        history.add(Snapshot(title = title, document = document))

        // Trim history if exceeds maxHistorySize
        if (history.size > maxHistorySize) {
            history.removeAt(0)
        }

        currentIndex = history.size - 1
    }

    fun canUndo(): Boolean = currentIndex > 0

    fun canRedo(): Boolean = currentIndex < history.size - 1

    fun undo(): Pair<String, RichNoteDocument>? {
        if (!canUndo()) return null
        currentIndex--
        val snapshot = history[currentIndex]
        return Pair(snapshot.title, snapshot.document)
    }

    fun redo(): Pair<String, RichNoteDocument>? {
        if (!canRedo()) return null
        currentIndex++
        val snapshot = history[currentIndex]
        return Pair(snapshot.title, snapshot.document)
    }

    fun clear() {
        history.clear()
        currentIndex = -1
    }
}
