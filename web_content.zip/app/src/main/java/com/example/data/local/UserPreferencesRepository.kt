package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppLanguage
import com.example.data.model.GenderOption
import com.example.data.model.SexualityOption
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "haven_user_prefs")

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val NAME = stringPreferencesKey("name")
        val AGE = intPreferencesKey("age")
        val AGE_VERIFIED = booleanPreferencesKey("age_verified")
        val GENDER = stringPreferencesKey("gender")
        val SEXUALITY = stringPreferencesKey("sexuality")
        val BACKUP_EMAIL = stringPreferencesKey("backup_email")
        val LANGUAGE = stringPreferencesKey("language")
        val DATA_FREE_MODE = booleanPreferencesKey("data_free_mode")
        val BIOMETRIC_LOCK = booleanPreferencesKey("biometric_lock")
        val SLEEP_QUIET_MODE = booleanPreferencesKey("sleep_quiet_mode")
        val EMERGENCY_NUMBER = stringPreferencesKey("emergency_number")
        val BLOOD_TYPE = stringPreferencesKey("blood_type")
        val ALLERGIES = stringPreferencesKey("allergies")
        val MEDICAL_NOTES = stringPreferencesKey("medical_notes")
        val LAST_PERIOD_EPOCH_DAY = longPreferencesKey("last_period_epoch_day")
        val CYCLE_LENGTH_DAYS = intPreferencesKey("cycle_length_days")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
    }

    val userProfile: Flow<UserProfile> = context.dataStore.data.map { prefs ->
        val genderKey = prefs[Keys.GENDER] ?: GenderOption.GIRL.key
        val sexualityKey = prefs[Keys.SEXUALITY] ?: SexualityOption.PREFER_NOT_TO_SAY.key
        UserProfile(
            name = prefs[Keys.NAME] ?: "",
            age = prefs[Keys.AGE] ?: 16,
            ageVerified = prefs[Keys.AGE_VERIFIED] ?: false,
            gender = GenderOption.entries.firstOrNull { it.key == genderKey } ?: GenderOption.GIRL,
            sexuality = SexualityOption.entries.firstOrNull { it.key == sexualityKey }
                ?: SexualityOption.PREFER_NOT_TO_SAY,
            backupEmail = prefs[Keys.BACKUP_EMAIL] ?: "",
            language = AppLanguage.fromCode(prefs[Keys.LANGUAGE] ?: AppLanguage.EN.code),
            isDataFreeMode = prefs[Keys.DATA_FREE_MODE] ?: false,
            biometricLockEnabled = prefs[Keys.BIOMETRIC_LOCK] ?: false,
            sleepQuietModeActive = prefs[Keys.SLEEP_QUIET_MODE] ?: false,
            emergencyAuthorityNumber = prefs[Keys.EMERGENCY_NUMBER] ?: "112",
            bloodType = prefs[Keys.BLOOD_TYPE] ?: "O+",
            allergies = prefs[Keys.ALLERGIES] ?: "None listed",
            medicalNotes = prefs[Keys.MEDICAL_NOTES] ?: "",
            lastPeriodEpochDay = prefs[Keys.LAST_PERIOD_EPOCH_DAY] ?: 0L,
            cycleLengthDays = prefs[Keys.CYCLE_LENGTH_DAYS] ?: 28,
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false
        )
    }

    suspend fun saveProfile(profile: UserProfile) {
        context.dataStore.edit { prefs ->
            prefs[Keys.NAME] = profile.name
            prefs[Keys.AGE] = profile.age
            prefs[Keys.AGE_VERIFIED] = profile.ageVerified
            prefs[Keys.GENDER] = profile.gender.key
            prefs[Keys.SEXUALITY] = profile.sexuality.key
            prefs[Keys.BACKUP_EMAIL] = profile.backupEmail
            prefs[Keys.LANGUAGE] = profile.language.code
            prefs[Keys.DATA_FREE_MODE] = profile.isDataFreeMode
            prefs[Keys.BIOMETRIC_LOCK] = profile.biometricLockEnabled
            prefs[Keys.SLEEP_QUIET_MODE] = profile.sleepQuietModeActive
            prefs[Keys.EMERGENCY_NUMBER] = profile.emergencyAuthorityNumber
            prefs[Keys.BLOOD_TYPE] = profile.bloodType
            prefs[Keys.ALLERGIES] = profile.allergies
            prefs[Keys.MEDICAL_NOTES] = profile.medicalNotes
            prefs[Keys.LAST_PERIOD_EPOCH_DAY] = profile.lastPeriodEpochDay
            prefs[Keys.CYCLE_LENGTH_DAYS] = profile.cycleLengthDays
            prefs[Keys.ONBOARDING_COMPLETED] = profile.onboardingCompleted
        }
    }

    suspend fun updateDataFreeMode(enabled: Boolean) {
        context.dataStore.edit { it[Keys.DATA_FREE_MODE] = enabled }
    }

    suspend fun updateSleepQuietMode(active: Boolean) {
        context.dataStore.edit { it[Keys.SLEEP_QUIET_MODE] = active }
    }

    suspend fun updateLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun updateBiometricLock(enabled: Boolean) {
        context.dataStore.edit { it[Keys.BIOMETRIC_LOCK] = enabled }
    }

    suspend fun updateLastPeriodDay(epochDay: Long) {
        context.dataStore.edit { it[Keys.LAST_PERIOD_EPOCH_DAY] = epochDay }
    }
}
