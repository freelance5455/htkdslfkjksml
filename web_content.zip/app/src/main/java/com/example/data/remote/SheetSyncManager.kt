package com.example.data.remote

import com.example.data.local.MemberEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SheetSyncManager {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    suspend fun syncMember(webhookUrl: String, member: MemberEntity): Result<String> {
        return withContext(Dispatchers.IO) {
            if (webhookUrl.isBlank()) {
                return@withContext Result.failure(IllegalArgumentException("গুগল শিট URL খালি রয়েছে"))
            }

            try {
                val json = JSONObject().apply {
                    put("id", member.id)
                    put("type", member.type)
                    put("union", member.union)
                    put("ward", member.ward)
                    if (member.type == "leader") {
                        put("sovapotiName", member.sovapotiName)
                        put("sovapotiMobile", member.sovapotiMobile)
                        put("sovapotiFb", member.sovapotiFb)
                        put("secretaryName", member.secretaryName)
                        put("secretaryMobile", member.secretaryMobile)
                        put("secretaryFb", member.secretaryFb)
                        put("otherDesignation", member.otherDesignation)
                        put("otherName", member.otherName)
                        put("otherMobile", member.otherMobile)
                        put("otherFb", member.otherFb)
                    } else {
                        put("name", member.workerName)
                        put("designation", member.workerDesignation)
                        put("mobile", member.workerMobile)
                        put("fb", member.workerFb)
                    }
                    put("createdAt", member.createdAt)
                    put("timestamp", member.timestamp)
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body = json.toString().toRequestBody(mediaType)
                val request = Request.Builder()
                    .url(webhookUrl.trim())
                    .post(body)
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful || response.code == 302 || response.code == 200) {
                    Result.success("গুগল শিটে ডাটা পাঠানো হয়েছে")
                } else {
                    Result.failure(Exception("সার্ভার রেসপন্স কোড: ${response.code}"))
                }
            } catch (e: Exception) {
                Result.failure(Exception("কানেকশন ত্রুটি: ${e.localizedMessage ?: "নেটওয়ার্ক সমস্যা"}"))
            }
        }
    }

    suspend fun testConnection(webhookUrl: String): Result<String> {
        return withContext(Dispatchers.IO) {
            if (webhookUrl.isBlank()) {
                return@withContext Result.failure(IllegalArgumentException("URL খালি রয়েছে"))
            }
            try {
                val json = JSONObject().apply {
                    put("test", true)
                    put("name", "Test Connection")
                    put("timestamp", System.currentTimeMillis())
                }
                val mediaType = "application/json; charset=utf-8".toMediaType()
                val body = json.toString().toRequestBody(mediaType)
                val request = Request.Builder()
                    .url(webhookUrl.trim())
                    .post(body)
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful || response.code == 302 || response.code == 200) {
                    Result.success("কানেকশন সফল! গুগল শিট কার্যকর রয়েছে।")
                } else {
                    Result.failure(Exception("রেসপন্স কোড: ${response.code}"))
                }
            } catch (e: Exception) {
                Result.failure(Exception("কানেকশন ব্যর্থ: ${e.localizedMessage}"))
            }
        }
    }
}
