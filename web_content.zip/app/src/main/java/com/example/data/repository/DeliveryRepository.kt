package com.example.data.repository

import com.example.data.db.DeliveryDao
import com.example.data.model.CycleStatus
import com.example.data.model.DeliveryEntry
import com.example.data.model.GpsTrackPoint
import com.example.data.model.TrackingSession
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class DeliveryRepository(private val dao: DeliveryDao) {

    val allEntries: Flow<List<DeliveryEntry>> = dao.getAllEntries()
    val userProfile: Flow<UserProfile?> = dao.getUserProfile()
    val activeSession: Flow<TrackingSession?> = dao.getActiveSession()

    fun getEntriesForMonth(monthKey: String): Flow<List<DeliveryEntry>> =
        dao.getEntriesForMonth(monthKey)

    suspend fun getEntriesForMonthSync(monthKey: String): List<DeliveryEntry> =
        dao.getEntriesForMonthSync(monthKey)

    fun getEntryForDate(dateString: String): Flow<DeliveryEntry?> =
        dao.getEntryForDate(dateString)

    suspend fun getEntryForDateSync(dateString: String): DeliveryEntry? =
        dao.getEntryForDateSync(dateString)

    fun getCycleStatusesForMonth(monthKey: String): Flow<List<CycleStatus>> =
        dao.getCycleStatusesForMonth(monthKey)

    fun getTrackPoints(sessionId: Long): Flow<List<GpsTrackPoint>> =
        dao.getTrackPoints(sessionId)

    suspend fun saveDeliveryEntry(
        dateString: String,
        deliveriesCount: Int,
        ratePerDelivery: Double,
        notes: String = "",
        latitude: Double? = null,
        longitude: Double? = null,
        locationTag: String? = null,
        existingId: Long = 0
    ): Long {
        val (cycleNumber, monthKey, dayOfMonth) = parseCycleInfo(dateString)
        val total = deliveriesCount * ratePerDelivery
        val entry = DeliveryEntry(
            id = existingId,
            dateString = dateString,
            deliveriesCount = deliveriesCount,
            ratePerDelivery = ratePerDelivery,
            totalEarnings = total,
            cycleNumber = cycleNumber,
            monthKey = monthKey,
            dayOfMonth = dayOfMonth,
            notes = notes,
            latitude = latitude,
            longitude = longitude,
            locationTag = locationTag
        )
        return dao.insertEntry(entry)
    }

    suspend fun deleteEntry(entry: DeliveryEntry) {
        dao.deleteEntry(entry)
    }

    suspend fun deleteEntryById(id: Long) {
        dao.deleteEntryById(id)
    }

    suspend fun updateCycleStatus(
        monthKey: String,
        cycleNumber: Int,
        status: String,
        paidAmount: Double = 0.0,
        notes: String = ""
    ) {
        val key = "$monthKey-$cycleNumber"
        val existing = dao.getCycleStatusByKeySync(key)
        val paymentDate = if (status == "PAID") {
            SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        } else existing?.paymentDate

        val cycleStatus = CycleStatus(
            cycleKey = key,
            monthKey = monthKey,
            cycleNumber = cycleNumber,
            status = status,
            paidAmount = if (status == "PAID" && paidAmount > 0) paidAmount else (existing?.paidAmount ?: 0.0),
            paymentDate = paymentDate,
            notes = notes
        )
        dao.upsertCycleStatus(cycleStatus)
    }

    suspend fun saveUserProfile(profile: UserProfile) {
        dao.saveUserProfile(profile)
    }

    suspend fun getUserProfileSync(): UserProfile {
        return dao.getUserProfileSync() ?: UserProfile()
    }

    suspend fun startTrackingSession(): Long {
        val session = TrackingSession(
            startTime = System.currentTimeMillis(),
            isActive = true
        )
        return dao.insertSession(session)
    }

    suspend fun stopTrackingSession(sessionId: Long, totalDistanceKm: Double, taggedCount: Int) {
        val session = TrackingSession(
            id = sessionId,
            startTime = System.currentTimeMillis(),
            endTime = System.currentTimeMillis(),
            totalDistanceKm = totalDistanceKm,
            deliveriesTagged = taggedCount,
            isActive = false
        )
        dao.updateSession(session)
    }

    suspend fun addTrackPoint(point: GpsTrackPoint): Long {
        return dao.insertTrackPoint(point)
    }

    companion object {
        fun parseCycleInfo(dateString: String): Triple<Int, String, Int> {
            return try {
                val parts = dateString.split("-")
                val year = parts[0]
                val month = parts[1]
                val day = parts[2].toInt()
                val monthKey = "$year-$month"
                val cycleNumber = when (day) {
                    in 1..10 -> 1
                    in 11..20 -> 2
                    else -> 3
                }
                Triple(cycleNumber, monthKey, day)
            } catch (e: Exception) {
                val cal = Calendar.getInstance()
                val day = cal.get(Calendar.DAY_OF_MONTH)
                val cycle = when (day) {
                    in 1..10 -> 1
                    in 11..20 -> 2
                    else -> 3
                }
                val monthKey = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(cal.time)
                Triple(cycle, monthKey, day)
            }
        }

        fun getCycleForDay(dayOfMonth: Int): Int {
            return when (dayOfMonth) {
                in 1..10 -> 1
                in 11..20 -> 2
                else -> 3
            }
        }

        fun getCycleDateRangeLabel(cycleNumber: Int, monthKey: String): String {
            return when (cycleNumber) {
                1 -> "1st - 10th"
                2 -> "11th - 20th"
                3 -> "21st - End of Month"
                else -> ""
            }
        }
    }
}
