package com.example.data.model

data class TopicLecture(
  val id: String,
  val subject: Subject,
  val unitTitle: String,
  val title: String,
  val mnemonicCode: String,
  val mnemonicStory: String,
  val keyPoints: List<String>,
  val osymTips: String,
  val exampleQuestion: String,
  val exampleSolution: String,
  val dopingReflex: String,
  val durationMinutes: Int = 15,
  val isCompleted: Boolean = false,
  val isFavorite: Boolean = false
)
