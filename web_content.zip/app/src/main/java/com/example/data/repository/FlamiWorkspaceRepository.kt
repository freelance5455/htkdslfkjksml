package com.example.data.repository

import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.ContextualMemory
import com.example.data.model.SearchHit
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow

interface FlamiWorkspaceRepository {
    fun observeUserProfile(): Flow<UserProfile?>

    suspend fun ensureUserProfile(
        displayName: String,
        defaultLanguage: String = "auto"
    ): Result<UserProfile>

    suspend fun updateUserPreferences(
        preferredLanguage: String? = null,
        modelMode: String? = null,
        ttsEnabled: Boolean? = null,
        ttsRate: Double? = null,
        memoryEnabled: Boolean? = null,
        displayName: String? = null
    ): Result<Unit>

    fun observeChats(): Flow<List<ChatSession>>

    suspend fun createChat(title: String, initialPreview: String = ""): Result<String>

    suspend fun renameChat(chatId: String, newTitle: String): Result<Unit>

    suspend fun togglePinChat(chatId: String, pinned: Boolean): Result<Unit>

    suspend fun deleteChat(chatId: String): Result<Unit>

    fun observeMessages(chatId: String): Flow<List<ChatMessage>>

    suspend fun getMessagesOnce(chatId: String): Result<List<ChatMessage>>

    suspend fun addMessage(
        chatId: String,
        role: String,
        text: String,
        hasImage: Boolean = false,
        imageNote: String? = null,
        languageCode: String? = null,
        isError: Boolean = false,
        updateChatPreview: Boolean = true
    ): Result<String>

    suspend fun updateMessage(
        chatId: String,
        messageId: String,
        newText: String,
        isError: Boolean = false,
        updateChatPreview: Boolean = true
    ): Result<Unit>

    suspend fun searchMessages(query: String, chats: List<ChatSession>): Result<List<SearchHit>>

    fun observeMemories(): Flow<List<ContextualMemory>>

    suspend fun addMemory(
        fact: String,
        category: String = "general",
        sourceChatId: String? = null
    ): Result<String>

    suspend fun updateMemory(memory: ContextualMemory): Result<Unit>

    suspend fun deleteMemory(memoryId: String): Result<Unit>
}
