package com.example.data.model

enum class PrayerType(
    val key: String,
    val arabicName: String,
    val englishName: String,
    val isSalat: Boolean = true
) {
    FAJR("Fajr", "الفجر", "Fajr", true),
    SUNRISE("Sunrise", "الشروق", "Sunrise", false),
    DHUHR("Dhuhr", "الظهر", "Dhuhr", true),
    ASR("Asr", "العصر", "Asr", true),
    MAGHRIB("Maghrib", "المغرب", "Maghrib", true),
    ISHA("Isha", "العشاء", "Isha", true);

    companion object {
        fun fromKey(key: String): PrayerType? {
            return entries.firstOrNull { it.key.equals(key, ignoreCase = true) }
        }
    }
}

data class PrayerTimeItemData(
    val type: PrayerType,
    val formattedTime: String,
    val epochMillis: Long,
    val offsetMinutes: Int = 0,
    val isNext: Boolean = false,
    val isPassed: Boolean = false
)

data class HijriDate(
    val day: String,
    val monthAr: String,
    val monthEn: String,
    val year: String,
    val designation: String = "هـ"
) {
    val formatted: String
        get() = "$day $monthAr $year $designation"
}

data class GregorianDate(
    val formatted: String,
    val dayNameAr: String,
    val day: Int,
    val monthNameAr: String,
    val year: Int
)

data class PrayerDataState(
    val locationName: String = "وهران، الجزائر",
    val latitude: Double = 35.6976,
    val longitude: Double = -0.6337,
    val gregorianDate: GregorianDate = GregorianDate(
        formatted = "اليوم",
        dayNameAr = "",
        day = 1,
        monthNameAr = "",
        year = 2026
    ),
    val hijriDate: HijriDate = HijriDate("1", "رمضان", "Ramadan", "1448"),
    val prayerList: List<PrayerTimeItemData> = emptyList(),
    val nextPrayer: PrayerTimeItemData? = null,
    val countdownFormatted: String = "--:--:--",
    val countdownSecondsRemaining: Long = 0,
    val islamicEvents: List<IslamicEvent> = emptyList(),
    val ramadanCountdown: RamadanCountdownState = RamadanCountdownState(),
    val qiblaAngle: Double = 0.0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

data class CityInfo(
    val nameAr: String,
    val nameEn: String,
    val countryAr: String,
    val countryEn: String,
    val latitude: Double,
    val longitude: Double
)

data class CalculationMethod(
    val id: Int,
    val nameAr: String,
    val nameEn: String
)

data class PrayerOffsets(
    val fajr: Int = 0,
    val sunrise: Int = 0,
    val dhuhr: Int = 0,
    val asr: Int = 0,
    val maghrib: Int = 0,
    val isha: Int = 0
) {
    fun getOffset(type: PrayerType): Int {
        return when (type) {
            PrayerType.FAJR -> fajr
            PrayerType.SUNRISE -> sunrise
            PrayerType.DHUHR -> dhuhr
            PrayerType.ASR -> asr
            PrayerType.MAGHRIB -> maghrib
            PrayerType.ISHA -> isha
        }
    }

    fun withOffset(type: PrayerType, newOffset: Int): PrayerOffsets {
        return when (type) {
            PrayerType.FAJR -> copy(fajr = newOffset)
            PrayerType.SUNRISE -> copy(sunrise = newOffset)
            PrayerType.DHUHR -> copy(dhuhr = newOffset)
            PrayerType.ASR -> copy(asr = newOffset)
            PrayerType.MAGHRIB -> copy(maghrib = newOffset)
            PrayerType.ISHA -> copy(isha = newOffset)
        }
    }
}

data class IslamicEvent(
    val name: String,
    val hijri: String,
    val dateIso: String,
    val targetEpochMillis: Long,
    val daysRemaining: Long
)

enum class AdhkarCategory(val title: String) {
    MORNING("أذكار الصباح"),
    EVENING("أذكار المساء"),
    POST_PRAYER("بعد الصلاة"),
    SLEEP("أذكار النوم")
}

data class DhikrItem(
    val id: Int,
    val category: AdhkarCategory,
    val text: String,
    val maxCount: Int,
    val remainingCount: Int
)

data class RamadanCountdownState(
    val days: Long = 0,
    val hours: Long = 0,
    val minutes: Long = 0,
    val seconds: Long = 0,
    val targetDescription: String = "رمضان 1448 هـ (المتوقع: فبراير 2027 م)"
)

enum class AdhanAlertType(
    val key: String,
    val titleAr: String,
    val audioUrl: String? = null
) {
    FULL_ABDULBASIT(
        "full-abdulbasit",
        "أذان كامل بصوت الشيخ عبد الباسط عبد الصمد",
        "https://cdn.islamic.network/prayer-times/audio/adhan/abdulbasit.mp3"
    ),
    FULL_AFASY(
        "full-afasy",
        "أذان كامل بصوت مشاري العفاسي",
        "https://cdn.islamic.network/prayer-times/audio/adhan/mishary.mp3"
    ),
    FULL_MAKKAH(
        "full-makkah",
        "أذان الحرم المكي الشريف",
        "https://cdn.islamic.network/prayer-times/audio/adhan/makkah.mp3"
    ),
    BEEP(
        "beep",
        "تنبيه قصير فقط (إشعار)"
    ),
    SILENT(
        "silent",
        "صامت"
    );

    companion object {
        fun fromKey(key: String): AdhanAlertType {
            return entries.firstOrNull { it.key == key } ?: FULL_AFASY
        }
    }
}

enum class ReminderTime(
    val minutes: Int,
    val titleAr: String
) {
    EXACT(0, "في وقت الصلاة بالضبط"),
    BEFORE_5(5, "قبل الصلاة بـ 5 دقائق"),
    BEFORE_10(10, "قبل الصلاة بـ 10 دقائق"),
    BEFORE_15(15, "قبل الصلاة بـ 15 دقيقة");

    companion object {
        fun fromMinutes(minutes: Int): ReminderTime {
            return entries.firstOrNull { it.minutes == minutes } ?: EXACT
        }
    }
}
