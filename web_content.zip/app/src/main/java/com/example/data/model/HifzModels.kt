package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val activeSchoolId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class School(
    @DocumentId val id: String = "",
    val ownerUid: String = "",
    val title: String = "",
    val centre: String = "",
    val activeClassId: String = "c1",
    val nextClassNum: Long = 3L,
    val memberUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SchoolMember(
    @DocumentId val id: String = "",
    val userId: String = "",
    val email: String = "",
    val displayName: String = "",
    val role: String = "class",
    val classId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class HifzClass(
    @DocumentId val id: String = "",
    val name: String = "",
    val sortOrder: Long = 0L,
    val nextStudentId: Long = 1L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Student(
    @DocumentId val id: String = "",
    val studentNum: Long = 0L,
    val name: String = "",
    val fatherName: String = "",
    val guardianPhone: String = "",
    val currentPara: String = "",
    val notes: String = "",
    val sortOrder: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Invite(
    @DocumentId val id: String = "",
    val email: String = "",
    val role: String = "class",
    val classId: String = "",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class DailyReport(
    @DocumentId val id: String = "",
    val date: String = "",
    val classId: String = "",
    val sotd: String = "",
    val rows: Map<String, Map<String, Any?>> = emptyMap(),
    val updatedByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun parsedRows(): Map<String, StudentRowData> =
        rows.mapValues { (_, map) -> StudentRowData.fromMap(map) }
}

data class StudentRowData(
    val a1: Boolean = false,
    val a2: Boolean = false,
    val sp: String = "",
    val sl: String = "",
    val sq: String = "",
    val sq1: String = "",
    val sq2: String = "",
    val sq3: String = "",
    val sq4: String = "",
    val sqm: String = "",
    val sqs: String = "",
    val mp: String = "",
    val q1: String = "",
    val q2: String = "",
    val q3: String = "",
    val q4: String = "",
    val mm: String = "",
    val ms: String = "",
    val tl: String = "",
    val td: String = ""
) {
    val isPresent: Boolean get() = a1 || a2

    fun toFirestoreMap(): Map<String, Any> {
        val m = mutableMapOf<String, Any>()
        if (a1) m["a1"] = true
        if (a2) m["a2"] = true
        if (sp.isNotEmpty()) m["sp"] = sp
        if (sl.isNotEmpty()) m["sl"] = sl
        if (sq.isNotEmpty()) m["sq"] = sq
        if (sq1.isNotEmpty()) m["sq1"] = sq1
        if (sq2.isNotEmpty()) m["sq2"] = sq2
        if (sq3.isNotEmpty()) m["sq3"] = sq3
        if (sq4.isNotEmpty()) m["sq4"] = sq4
        if (sqm.isNotEmpty()) m["sqm"] = sqm
        if (sqs.isNotEmpty()) m["sqs"] = sqs
        if (mp.isNotEmpty()) m["mp"] = mp
        if (q1.isNotEmpty()) m["q1"] = q1
        if (q2.isNotEmpty()) m["q2"] = q2
        if (q3.isNotEmpty()) m["q3"] = q3
        if (q4.isNotEmpty()) m["q4"] = q4
        if (mm.isNotEmpty()) m["mm"] = mm
        if (ms.isNotEmpty()) m["ms"] = ms
        if (tl.isNotEmpty()) m["tl"] = tl
        if (td.isNotEmpty()) m["td"] = td
        return m
    }

    fun getField(key: String): String = when (key) {
        "sp" -> sp; "sl" -> sl; "sq" -> sq
        "sq1" -> sq1; "sq2" -> sq2; "sq3" -> sq3; "sq4" -> sq4
        "sqm" -> sqm; "sqs" -> sqs
        "mp" -> mp; "q1" -> q1; "q2" -> q2; "q3" -> q3; "q4" -> q4
        "mm" -> mm; "ms" -> ms; "tl" -> tl; "td" -> td
        else -> ""
    }

    fun withTextField(key: String, value: String): StudentRowData = when (key) {
        "sp" -> copy(sp = value)
        "sl" -> copy(sl = value)
        "sq" -> copy(sq = value)
        "sq1" -> copy(sq1 = value)
        "sq2" -> copy(sq2 = value)
        "sq3" -> copy(sq3 = value)
        "sq4" -> copy(sq4 = value)
        "sqm" -> copy(sqm = value)
        "sqs" -> copy(sqs = value)
        "mp" -> copy(mp = value)
        "q1" -> copy(q1 = value)
        "q2" -> copy(q2 = value)
        "q3" -> copy(q3 = value)
        "q4" -> copy(q4 = value)
        "mm" -> copy(mm = value)
        "ms" -> copy(ms = value)
        "tl" -> copy(tl = value)
        "td" -> copy(td = value)
        else -> this
    }

    companion object {
        fun fromMap(map: Map<*, *>?): StudentRowData {
            if (map == null) return StudentRowData()
            fun str(k: String): String = (map[k] as? String) ?: (map[k]?.toString() ?: "")
            fun bool(k: String): Boolean = (map[k] as? Boolean) ?: false
            return StudentRowData(
                a1 = bool("a1"),
                a2 = bool("a2"),
                sp = str("sp"),
                sl = str("sl"),
                sq = str("sq"),
                sq1 = str("sq1"),
                sq2 = str("sq2"),
                sq3 = str("sq3"),
                sq4 = str("sq4"),
                sqm = str("sqm"),
                sqs = str("sqs"),
                mp = str("mp"),
                q1 = str("q1"),
                q2 = str("q2"),
                q3 = str("q3"),
                q4 = str("q4"),
                mm = str("mm"),
                ms = str("ms"),
                tl = str("tl"),
                td = str("td")
            )
        }
    }
}

data class MonthlyStudentSummary(
    val studentNum: Long,
    val name: String,
    val presentDays: Int,
    val absentDays: Int,
    val totalSabaqLines: Double,
    val dailyAvgLines: Double,
    val sabqiMistakes: Double,
    val manzilMistakes: Double,
    val latestSabaqPara: String,
    val sotdCount: Int
)

data class MonthlySummaryResult(
    val yearMonth: String,
    val classId: String,
    val className: String,
    val recordedSheetsCount: Int,
    val workingDaysCount: Int,
    val students: List<MonthlyStudentSummary>
)

data class ClassReportStatus(
    val classId: String,
    val className: String,
    val hasReport: Boolean,
    val updatedTimeText: String,
    val presentCount: Int,
    val totalStudents: Int
)

data class DailyReportSnapshot(
    val report: DailyReport?,
    val hasPendingWrites: Boolean,
    val fromCache: Boolean
)
