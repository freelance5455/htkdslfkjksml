package com.example.data.parser

import com.example.data.model.SnowtamData
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.regex.Pattern

object SnowtamParser {

  private val SERIAL_PATTERN = Pattern.compile("(?i)(?:SNOWTAM|SW[A-Z]{2})\\s*(\\d{4})")
  private val ICAO_PATTERN = Pattern.compile("\\b([A-Z]{4})\\b")
  private val RWY_PATTERN = Pattern.compile("\\b(\\d{2}[LCR]?)\\b")
  private val RWYCC_PATTERN = Pattern.compile("\\b([0-6])/([0-6])/([0-6])\\b")
  private val COVERAGE_PATTERN = Pattern.compile("\\b(\\d{1,3}|NR)/(\\d{1,3}|NR)/(\\d{1,3}|NR)\\b")
  private val DEPTH_PATTERN = Pattern.compile("\\b(\\d{1,3}|NR)/(\\d{1,3}|NR)/(\\d{1,3}|NR)\\b")

  fun parse(
    raw: String,
    icaoFallback: String = "",
    sourceName: String = "ICAO GRF / Doc 10066",
    isSample: Boolean = false
  ): SnowtamData {
    val clean = raw.trim().replace("\r\n", "\n")
    val upper = clean.uppercase(Locale.US)

    // Serial
    var serial = ""
    val serMatcher = SERIAL_PATTERN.matcher(clean)
    if (serMatcher.find()) {
      serial = serMatcher.group(1) ?: ""
    }

    // Aerodrome ICAO
    var icao = icaoFallback
    val icaoMatcher = ICAO_PATTERN.matcher(upper)
    while (icaoMatcher.find()) {
      val code = icaoMatcher.group(1) ?: ""
      if (code != "SNOW" && code != "FICON" && code != "RWY" && code != "GRF" && code.length == 4) {
        if (icao.isBlank()) icao = code
      }
    }

    // Observation / Issue Time
    val timeMatcher = Pattern.compile("\\b(\\d{6,8})\\b").matcher(clean)
    var issueTimeUtc = ""
    while (timeMatcher.find()) {
      val t = timeMatcher.group(1) ?: ""
      if (t.length == 8 || t.length == 6) {
        issueTimeUtc = t
        break
      }
    }
    if (issueTimeUtc.isBlank()) {
      issueTimeUtc = SimpleDateFormat("ddHHmm'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
      }.format(Date())
    }

    // Runway designator
    var rwy = ""
    val rwyBeforeRwyccMatcher = Pattern.compile("\\b(0[1-9]|[12][0-9]|3[0-6])[LCR]?\\b(?=\\s+[0-6]/[0-6]/[0-6])").matcher(clean)
    if (rwyBeforeRwyccMatcher.find()) {
      rwy = rwyBeforeRwyccMatcher.group(0) ?: ""
    } else {
      val rwyExplicitMatcher = Pattern.compile("(?i)(?:RWY|RUNWAY)\\s*([0-3][0-9][LCR]?)").matcher(clean)
      if (rwyExplicitMatcher.find()) {
        rwy = rwyExplicitMatcher.group(1) ?: ""
      }
    }
    if (rwy.isBlank()) rwy = "29R"

    // RWYCC: 3 thirds (e.g. 5/5/5 or 3/2/3)
    var rwycc1: Int? = null
    var rwycc2: Int? = null
    var rwycc3: Int? = null
    var lowestRwycc: Int? = null

    val rwyccMatcher = RWYCC_PATTERN.matcher(clean)
    if (rwyccMatcher.find()) {
      rwycc1 = rwyccMatcher.group(1)?.toIntOrNull()
      rwycc2 = rwyccMatcher.group(2)?.toIntOrNull()
      rwycc3 = rwyccMatcher.group(3)?.toIntOrNull()
      if (rwycc1 != null && rwycc2 != null && rwycc3 != null) {
        lowestRwycc = minOf(rwycc1, rwycc2, rwycc3)
      }
    }

    // Contaminant Type
    val contaminantTypes = listOf(
      "DRY SNOW", "WET SNOW", "COMPACTED SNOW", "SLUSH", "ICE", "FROST",
      "WET", "STANDING WATER", "WATER ON TOP OF COMPACTED SNOW", "DRY"
    )
    var foundContaminant = ""
    for (ct in contaminantTypes) {
      if (upper.contains(ct)) {
        foundContaminant = ct
        break
      }
    }
    if (foundContaminant.isBlank() && upper.contains("SNOW")) {
      foundContaminant = "SNOW"
    }

    // Coverage & Depth
    var cov1: Int? = null
    var cov2: Int? = null
    var cov3: Int? = null
    var dep1: Int? = null
    var dep2: Int? = null
    var dep3: Int? = null

    // Find occurrences of 3-element fractions after RWYCC
    val slashMatchers = Pattern.compile("\\b(\\d{1,3})/(\\d{1,3})/(\\d{1,3})\\b").matcher(clean)
    var slashCount = 0
    while (slashMatchers.find()) {
      slashCount++
      if (slashCount == 2) {
        cov1 = slashMatchers.group(1)?.toIntOrNull()
        cov2 = slashMatchers.group(2)?.toIntOrNull()
        cov3 = slashMatchers.group(3)?.toIntOrNull()
      } else if (slashCount == 3) {
        dep1 = slashMatchers.group(1)?.toIntOrNull()
        dep2 = slashMatchers.group(2)?.toIntOrNull()
        dep3 = slashMatchers.group(3)?.toIntOrNull()
      }
    }

    val receivedUtc = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    return SnowtamData(
      icao = icao.ifBlank { icaoFallback.ifBlank { "OIIE" } },
      serialNumber = serial,
      issueTimeUtc = issueTimeUtc,
      rawSnowtam = raw,
      runwayDesignator = rwy,
      rwyccPart1 = rwycc1,
      rwyccPart2 = rwycc2,
      rwyccPart3 = rwycc3,
      lowestRwycc = lowestRwycc,
      contaminantType = foundContaminant,
      coveragePercentPart1 = cov1,
      coveragePercentPart2 = cov2,
      coveragePercentPart3 = cov3,
      depthMmPart1 = dep1,
      depthMmPart2 = dep2,
      depthMmPart3 = dep3,
      source = sourceName,
      receivedTimeUtc = receivedUtc,
      isSampleOrManual = isSample
    )
  }
}
