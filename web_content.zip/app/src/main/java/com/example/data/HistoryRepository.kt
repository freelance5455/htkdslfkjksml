package com.example.data

import kotlinx.coroutines.flow.Flow

class HistoryRepository(private val dao: CalcHistoryDao) {
    val allHistory: Flow<List<CalcHistoryEntity>> = dao.getAllHistory()

    suspend fun insert(entry: CalcHistoryEntity) {
        dao.insert(entry)
    }

    suspend fun deleteById(id: Int) {
        dao.deleteById(id)
    }

    suspend fun clearAll() {
        dao.clearAll()
    }
}
