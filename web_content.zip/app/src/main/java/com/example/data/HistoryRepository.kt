package com.example.data

import android.content.Context
import com.example.model.TestRunHistory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class HistoryRepository(private val context: Context) {

    private val _history = MutableStateFlow<List<TestRunHistory>>(emptyList())
    val history: StateFlow<List<TestRunHistory>> = _history.asStateFlow()

    private val historyFile: File by lazy {
        File(context.filesDir, "traffic_runs_history.json")
    }

    suspend fun loadHistory() = withContext(Dispatchers.IO) {
        if (!historyFile.exists()) {
            // Seed a few useful developer preset history records
            val defaults = listOf(
                TestRunHistory(
                    id = "preset-1",
                    timestamp = System.currentTimeMillis() - 3600000,
                    url = "https://httpbin.org/get",
                    method = "GET",
                    totalVisits = 35,
                    successCount = 35,
                    failureCount = 0,
                    avgLatencyMs = 210,
                    totalBytes = 142000,
                    completedDurationMs = 12400
                ),
                TestRunHistory(
                    id = "preset-2",
                    timestamp = System.currentTimeMillis() - 86400000,
                    url = "https://example.com",
                    method = "GET",
                    totalVisits = 10,
                    successCount = 10,
                    failureCount = 0,
                    avgLatencyMs = 145,
                    totalBytes = 12560,
                    completedDurationMs = 3800
                )
            )
            _history.value = defaults
            saveToFile(defaults)
            return@withContext
        }

        try {
            val content = historyFile.readText()
            val jsonArray = JSONArray(content)
            val list = mutableListOf<TestRunHistory>()
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    TestRunHistory(
                        id = obj.getString("id"),
                        timestamp = obj.getLong("timestamp"),
                        url = obj.getString("url"),
                        method = obj.getString("method"),
                        totalVisits = obj.getInt("totalVisits"),
                        successCount = obj.getInt("successCount"),
                        failureCount = obj.getInt("failureCount"),
                        avgLatencyMs = obj.getLong("avgLatencyMs"),
                        totalBytes = obj.getLong("totalBytes"),
                        completedDurationMs = obj.getLong("completedDurationMs")
                    )
                )
            }
            _history.value = list
        } catch (e: Exception) {
            _history.value = emptyList()
        }
    }

    suspend fun saveRun(run: TestRunHistory) = withContext(Dispatchers.IO) {
        val updated = listOf(run) + _history.value.filter { it.id != run.id }.take(49)
        _history.value = updated
        saveToFile(updated)
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        _history.value = emptyList()
        if (historyFile.exists()) {
            historyFile.delete()
        }
    }

    private fun saveToFile(list: List<TestRunHistory>) {
        try {
            val array = JSONArray()
            list.forEach { run ->
                val obj = JSONObject().apply {
                    put("id", run.id)
                    put("timestamp", run.timestamp)
                    put("url", run.url)
                    put("method", run.method)
                    put("totalVisits", run.totalVisits)
                    put("successCount", run.successCount)
                    put("failureCount", run.failureCount)
                    put("avgLatencyMs", run.avgLatencyMs)
                    put("totalBytes", run.totalBytes)
                    put("completedDurationMs", run.completedDurationMs)
                }
                array.put(obj)
            }
            historyFile.writeText(array.toString())
        } catch (_: Exception) {
        }
    }
}
