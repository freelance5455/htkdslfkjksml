package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

object ArkFeedIds {
    private val chars = "abcdefghjkmnpqrstuvwxyz23456789"

    fun newChronoDocId(prefix: String = "p"): String {
        val revTs = (9_999_999_999_999L - System.currentTimeMillis())
            .coerceAtLeast(0L)
            .toString()
            .padStart(13, '0')
        val rand = (1..6).map { chars.random() }.joinToString("")
        return "${prefix}_${revTs}_${rand}"
    }

    fun newForwardDocId(prefix: String = "c"): String {
        val ts = System.currentTimeMillis().toString().padStart(13, '0')
        val rand = (1..6).map { chars.random() }.joinToString("")
        return "${prefix}_${ts}_${rand}"
    }

    fun extractHashtags(text: String): List<String> {
        val regex = Regex("#([a-zA-Z0-9_]{2,30})")
        return regex.findAll(text)
            .map { it.groupValues[1].lowercase() }
            .distinct()
            .take(15)
            .toList()
    }

    fun extractMentions(text: String): List<String> {
        val regex = Regex("@([a-zA-Z0-9_]{3,24})")
        return regex.findAll(text)
            .map { it.groupValues[1].lowercase() }
            .distinct()
            .take(10)
            .toList()
    }

    fun conversationIdFor(uidA: String, uidB: String): String =
        if (uidA <= uidB) "${uidA}_${uidB}" else "${uidB}_${uidA}"

    val feedCategories = listOf(
        "Gaming",
        "Creativity",
        "Photography",
        "Friends",
        "Challenges",
        "Entertainment"
    )

    val reactionOptions = listOf(
        "like" to "👍",
        "love" to "❤️",
        "fire" to "🔥",
        "laugh" to "😂",
        "trophy" to "🏆",
        "clap" to "👏"
    )

    fun reactionEmoji(key: String?): String =
        reactionOptions.firstOrNull { it.first == key }?.second ?: "❤️"
}

@IgnoreExtraProperties
data class ArkPost(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorUsername: String = "",
    val authorAvatar: String = "prism_cyan",
    val authorAvatarBase64: String? = null,
    val postType: String = "photo",
    val category: String = "Friends",
    val caption: String = "",
    val hashtags: List<String> = emptyList(),
    val locationLabel: String? = null,
    val altTexts: List<String> = emptyList(),
    val taggedUids: List<String> = emptyList(),
    val approvedTagUids: List<String> = emptyList(),
    val pendingTagUids: List<String> = emptyList(),
    val imageBase64List: List<String> = emptyList(),
    val videoThumbnailBase64: String? = null,
    val videoDurationMs: Long = 0L,
    val videoChunkCount: Long = 0L,
    val visibility: String = "friends",
    val visibleToUids: List<String> = emptyList(),
    val groupIds: List<String> = emptyList(),
    val groupNames: List<String> = emptyList(),
    val commentsDisabled: Boolean = false,
    val likeCount: Long = 0L,
    val reactionCounts: Map<String, Long> = emptyMap(),
    val commentCount: Long = 0L,
    val shareCount: Long = 0L,
    val pollQuestion: String? = null,
    val pollOptions: List<String>? = null,
    val pollVoteCounts: Map<String, Long>? = null,
    val pollExpiresAt: Timestamp? = null,
    val metaGameName: String? = null,
    val metaScoreLabel: String? = null,
    val metaWinner: String? = null,
    val metaBadge: String? = null,
    val sharedFromPostId: String? = null,
    val sharedFromUsername: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PostReaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val username: String = "",
    val reaction: String = "love",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PostComment(
    @DocumentId val id: String = "",
    val postId: String = "",
    val authorId: String = "",
    val authorUsername: String = "",
    val authorAvatar: String = "prism_cyan",
    val text: String = "",
    val parentCommentId: String? = null,
    val replyToUsername: String? = null,
    val likeCount: Long = 0L,
    @get:PropertyName("isEdited") val isEdited: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PollVote(
    @DocumentId val id: String = "",
    val userId: String = "",
    val optionIndex: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class MediaChunk(
    @DocumentId val id: String = "",
    val index: Long = 0L,
    val dataBase64: String = "",
    val authorId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ArkStory(
    @DocumentId val id: String = "",
    val authorId: String = "",
    val authorUsername: String = "",
    val authorAvatar: String = "prism_cyan",
    val mediaType: String = "image",
    val imageBase64: String = "",
    val videoDurationMs: Long = 0L,
    val videoChunkCount: Long = 0L,
    val caption: String = "",
    val visibility: String = "friends",
    val visibleToUids: List<String> = emptyList(),
    val hiddenFromUids: List<String> = emptyList(),
    val viewerCount: Long = 0L,
    val reactionCounts: Map<String, Long> = emptyMap(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    val expiresAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StoryReaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val username: String = "",
    val reaction: String = "love",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class HighlightSlide(
    val storyId: String = "",
    val mediaType: String = "image",
    val imageBase64: String = "",
    val caption: String = "",
    val addedAtMillis: Long = 0L
)

@IgnoreExtraProperties
data class StoryHighlight(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val title: String = "",
    val coverImageBase64: String = "",
    val slides: List<HighlightSlide> = emptyList(),
    val visibility: String = "followers",
    val visibleToUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StoryViewer(
    @DocumentId val id: String = "",
    val viewerUid: String = "",
    val viewerUsername: String = "",
    val viewerAvatar: String = "prism_cyan",
    @ServerTimestamp val viewedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PostBookmark(
    @DocumentId val id: String = "",
    val userId: String = "",
    val postId: String = "",
    @ServerTimestamp val savedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PostDraft(
    @DocumentId val id: String = "",
    val userId: String = "",
    val postType: String = "photo",
    val category: String = "Friends",
    val caption: String = "",
    val imageBase64List: List<String> = emptyList(),
    val visibility: String = "friends",
    val pollQuestion: String = "",
    val pollOptions: List<String> = emptyList(),
    val locationLabel: String = "",
    val altTexts: List<String> = emptyList(),
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class MutedUser(
    @DocumentId val id: String = "",
    val userId: String = "",
    val mutedUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class HiddenPost(
    @DocumentId val id: String = "",
    val userId: String = "",
    val postId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class DirectConversation(
    @DocumentId val id: String = "",
    val participantUids: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val participantAvatars: Map<String, String> = emptyMap(),
    val status: String = "active",
    val requesterUid: String = "",
    val lastMessageText: String = "",
    val lastSenderUid: String = "",
    val unreadCounts: Map<String, Long> = emptyMap(),
    val typingUids: Map<String, Long> = emptyMap(),
    val readAtMillis: Map<String, Long> = emptyMap(),
    @ServerTimestamp val lastMessageAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class DirectMessage(
    @DocumentId val id: String = "",
    val conversationId: String = "",
    val participantUids: List<String> = emptyList(),
    val senderId: String = "",
    val senderUsername: String = "",
    val text: String = "",
    val imageBase64: String? = null,
    val videoThumbnailBase64: String? = null,
    val videoDurationMs: Long = 0L,
    val videoChunkCount: Long = 0L,
    val replyToId: String? = null,
    val replyToPreview: String? = null,
    val reactions: Map<String, String> = emptyMap(),
    @get:PropertyName("isDeleted") val isDeleted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
