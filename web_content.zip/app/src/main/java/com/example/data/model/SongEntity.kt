package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "songs",
    indices = [
        Index(value = ["contentHash"], unique = true),
        Index(value = ["isFavorite"]),
        Index(value = ["dateAddedTimestamp"]),
        Index(value = ["lastPlayedTimestamp"])
    ]
)
data class SongEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val contentHash: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String = "",
    val year: String = "",
    val durationMs: Long = 0L,
    val filePath: String,
    val originalFileName: String,
    val fileSizeBytes: Long = 0L,
    val mimeType: String = "audio/*",
    val customArtworkPath: String? = null,
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val lastPlayedTimestamp: Long? = null,
    val dateAddedTimestamp: Long = System.currentTimeMillis()
)
