package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for local offline Member & Committee records.
 */
@Dao
interface MemberDao {
    @Query("SELECT * FROM members ORDER BY timestamp DESC")
    fun getAllMembers(): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members WHERE type = :type ORDER BY timestamp DESC")
    fun getMembersByType(type: String): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members WHERE id = :id")
    fun getMemberById(id: Long): Flow<MemberEntity?>

    @Query("SELECT * FROM members WHERE `union` = :union ORDER BY timestamp DESC")
    fun getMembersByUnion(union: String): Flow<List<MemberEntity>>

    @Query("SELECT * FROM members WHERE type = :type AND `union` = :union ORDER BY timestamp DESC")
    fun getMembersByTypeAndUnion(type: String, union: String): Flow<List<MemberEntity>>

    @Query("SELECT COUNT(*) FROM members")
    fun getTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM members WHERE type = 'leader'")
    fun getLeaderCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM members WHERE type = 'worker'")
    fun getWorkerCount(): Flow<Int>

    @Query("SELECT * FROM members WHERE syncedToSheet = 0 ORDER BY timestamp DESC")
    fun getUnsyncedMembers(): Flow<List<MemberEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(member: MemberEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(members: List<MemberEntity>)

    @Update
    suspend fun update(member: MemberEntity)

    @Delete
    suspend fun delete(member: MemberEntity)

    @Query("DELETE FROM members WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM members")
    suspend fun clearAll()

    @Query("UPDATE members SET syncedToSheet = :synced WHERE id = :id")
    suspend fun markSynced(id: Long, synced: Boolean = true)
}
