package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MoonChessDao {

    // ---- Books ----
    @Query("SELECT * FROM books ORDER BY lastReadTime DESC")
    fun observeBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :bookId LIMIT 1")
    suspend fun getBookById(bookId: String): BookEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBook(book: BookEntity)

    @Query("UPDATE books SET lastReadPage = :page, zoom = :zoom, lastReadTime = :timestamp WHERE id = :bookId")
    suspend fun updateReadingProgress(bookId: String, page: Int, zoom: Float, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM books WHERE id = :bookId")
    suspend fun deleteBook(bookId: String)

    // ---- Page Annotations ----
    @Query("SELECT * FROM page_annotations WHERE bookId = :bookId")
    fun observeBookAnnotations(bookId: String): Flow<List<PageAnnotationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPageAnnotation(annotation: PageAnnotationEntity)

    @Query("DELETE FROM page_annotations WHERE bookId = :bookId AND pageNumber = :pageNumber")
    suspend fun clearPageAnnotations(bookId: String, pageNumber: Int)

    // ---- Learned 32x32 NCC Piece Templates ----
    @Query("SELECT * FROM piece_templates WHERE bookId = :bookId")
    suspend fun getBookTemplates(bookId: String): List<PieceTemplateEntity>

    @Query("SELECT * FROM piece_templates WHERE bookId = :bookId")
    fun observeBookTemplates(bookId: String): Flow<List<PieceTemplateEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTemplates(templates: List<PieceTemplateEntity>)

    // ---- Diagram Catalog ----
    @Query("SELECT * FROM catalog_diagrams WHERE bookId = :bookId ORDER BY pageNumber ASC, createdAt ASC")
    fun observeCatalogDiagrams(bookId: String): Flow<List<CatalogDiagramEntity>>

    @Query("SELECT * FROM catalog_diagrams WHERE bookId = :bookId ORDER BY pageNumber ASC")
    suspend fun getCatalogDiagramsSnapshot(bookId: String): List<CatalogDiagramEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCatalogDiagram(diagram: CatalogDiagramEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCatalogDiagrams(diagrams: List<CatalogDiagramEntity>)

    @Query("DELETE FROM catalog_diagrams WHERE id = :id")
    suspend fun deleteCatalogDiagram(id: String)

    // ---- PMS Positions ----
    @Query("SELECT * FROM pms_positions ORDER BY createdAt DESC")
    fun observePmsPositions(): Flow<List<PmsPositionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPmsPosition(pos: PmsPositionEntity)

    @Query("DELETE FROM pms_positions WHERE id = :id")
    suspend fun deletePmsPosition(id: String)

    // ---- Imported Games ----
    @Query("SELECT * FROM imported_games ORDER BY importedAt DESC")
    fun observeImportedGames(): Flow<List<ImportedGameEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertImportedGames(games: List<ImportedGameEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertImportedGame(game: ImportedGameEntity)

    @Query("UPDATE imported_games SET pgn = :pgn WHERE id = :gameId")
    suspend fun updateGamePgn(gameId: String, pgn: String)

    @Query("DELETE FROM imported_games WHERE id = :gameId")
    suspend fun deleteImportedGame(gameId: String)

    // ---- Study Notes (User-Authored Only; Starts Empty) ----
    @Query("SELECT * FROM study_notes ORDER BY isPinned DESC, updatedAt DESC")
    fun observeNotes(): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNote(note: NoteEntity)

    @Query("DELETE FROM study_notes WHERE id = :id")
    suspend fun deleteNote(id: String)

    // ---- Chess Principles: Opening / Middlegame / Endgame (User-Authored Only; Starts Empty) ----
    @Query("SELECT * FROM chess_principles ORDER BY updatedAt DESC")
    fun observePrinciples(): Flow<List<PrincipleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPrinciple(principle: PrincipleEntity)

    @Query("DELETE FROM chess_principles WHERE id = :id")
    suspend fun deletePrinciple(id: String)

    // ---- Settings ----
    @Query("SELECT value FROM app_settings WHERE key = :key LIMIT 1")
    suspend fun getSetting(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: AppSettingEntity)
}
