package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Dedicated Room Entity for storing organizational committee data locally for offline support.
 */
@Entity(
    tableName = "committees",
    indices = [
        Index(value = ["unit"]),
        Index(value = ["timestamp"])
    ]
)
data class CommitteeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val unit: String, // e.g. "চারঘাট উপজেলা ছাত্রলীগ"
    val sovapotiName: String = "",
    val sovapotiMobile: String = "",
    val sovapotiFb: String = "",
    val secretaryName: String = "",
    val secretaryMobile: String = "",
    val secretaryFb: String = "",
    val otherDesignation: String = "",
    val otherName: String = "",
    val otherMobile: String = "",
    val otherFb: String = "",
    val createdAt: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val syncedToSheet: Boolean = false
)
