package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val targetDate: String, // YYYY-MM-DD
    val timeHour: Int = 7,
    val timeMinute: Int = 0,
    val category: String = "PERSONAL", // EKADASHI, PURNIMA, AMAVASYA, PANCHAK, BICHHUDA, VIVAH, PERSONAL
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY targetDate ASC, timeHour ASC, timeMinute ASC")
    fun getAllReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun getReminderById(id: Long): ReminderEntity?

    @Query("SELECT * FROM reminders WHERE targetDate = :date AND isEnabled = 1")
    fun getRemindersForDate(date: String): Flow<List<ReminderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: ReminderEntity): Long

    @Update
    suspend fun updateReminder(reminder: ReminderEntity)

    @Delete
    suspend fun deleteReminder(reminder: ReminderEntity)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteReminderById(id: Long)
}

@Database(entities = [ReminderEntity::class], version = 1, exportSchema = false)
abstract class PanchangDatabase : RoomDatabase() {
    abstract fun reminderDao(): ReminderDao

    companion object {
        @Volatile
        private var INSTANCE: PanchangDatabase? = null

        fun getDatabase(context: Context): PanchangDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PanchangDatabase::class.java,
                    "panchang_database"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class ReminderRepository(private val reminderDao: ReminderDao) {
    val allReminders: Flow<List<ReminderEntity>> = reminderDao.getAllReminders()

    fun getRemindersForDate(date: String): Flow<List<ReminderEntity>> =
        reminderDao.getRemindersForDate(date)

    suspend fun insert(reminder: ReminderEntity): Long =
        reminderDao.insertReminder(reminder)

    suspend fun update(reminder: ReminderEntity) =
        reminderDao.updateReminder(reminder)

    suspend fun delete(reminder: ReminderEntity) =
        reminderDao.deleteReminder(reminder)

    suspend fun deleteById(id: Long) =
        reminderDao.deleteReminderById(id)
}
