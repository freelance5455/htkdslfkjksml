package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.GenderFilter
import com.example.data.model.MediaSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "yiffy_user_prefs")

data class UserPreferences(
    val genderFilter: GenderFilter = GenderFilter.ANY,
    val malesOnly: Boolean = false,
    val enabledSources: Set<String> = MediaSource.entries.map { it.name }.toSet(),
    val uiScale: Float = 1.0f,
    val downloadFolder: String = ".yiffy_media",
    val googleAccountEmail: String = "",
    val isGoogleConnected: Boolean = false,
    val e621Login: String = "",
    val e621ApiKey: String = "",
    val rule34ApiKey: String = "",
    val redditClientId: String = "",
    val redditClientSecret: String = "",
    val blueskyHandle: String = "",
    val blueskyAppPassword: String = "",
    val twitterBearerToken: String = "",
    val userName: String = "NeonFox",
    val userBio: String = "Minimalist media explorer with automated booru algorithms",
    // Configurable queries per platform
    val redditSubreddits: String = "furry,yiff,anthro,furryartschool",
    val e621DefaultTags: String = "order:score score:>10",
    val rule34DefaultTags: String = "sort:score:desc",
    val pornhubSearchQuery: String = "furry animation"
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val GENDER_FILTER = stringPreferencesKey("gender_filter")
        val MALES_ONLY = booleanPreferencesKey("males_only")
        val ENABLED_SOURCES = stringSetPreferencesKey("enabled_sources")
        val UI_SCALE = floatPreferencesKey("ui_scale")
        val DOWNLOAD_FOLDER = stringPreferencesKey("download_folder")
        val GOOGLE_EMAIL = stringPreferencesKey("google_email")
        val IS_GOOGLE_CONNECTED = booleanPreferencesKey("is_google_connected")

        val E621_LOGIN = stringPreferencesKey("e621_login")
        val E621_API_KEY = stringPreferencesKey("e621_api_key")
        val RULE34_API_KEY = stringPreferencesKey("rule34_api_key")
        val REDDIT_CLIENT_ID = stringPreferencesKey("reddit_client_id")
        val REDDIT_CLIENT_SECRET = stringPreferencesKey("reddit_client_secret")
        val BLUESKY_HANDLE = stringPreferencesKey("bluesky_handle")
        val BLUESKY_APP_PASSWORD = stringPreferencesKey("bluesky_app_password")
        val TWITTER_TOKEN = stringPreferencesKey("twitter_token")

        val USER_NAME = stringPreferencesKey("user_name")
        val USER_BIO = stringPreferencesKey("user_bio")

        val REDDIT_SUBREDDITS = stringPreferencesKey("reddit_subreddits")
        val E621_DEFAULT_TAGS = stringPreferencesKey("e621_default_tags")
        val RULE34_DEFAULT_TAGS = stringPreferencesKey("rule34_default_tags")
        val PORNHUB_SEARCH_QUERY = stringPreferencesKey("pornhub_search_query")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        val savedMalesOnly = prefs[Keys.MALES_ONLY] ?: false
        val savedGenderRaw = prefs[Keys.GENDER_FILTER]
        val activeGender = if (savedGenderRaw != null) {
            GenderFilter.fromString(savedGenderRaw)
        } else if (savedMalesOnly) {
            GenderFilter.FEMALE_ONLY
        } else {
            GenderFilter.ANY
        }

        UserPreferences(
            genderFilter = activeGender,
            malesOnly = activeGender == GenderFilter.FEMALE_ONLY,
            enabledSources = prefs[Keys.ENABLED_SOURCES] ?: MediaSource.entries.map { it.name }.toSet(),
            uiScale = prefs[Keys.UI_SCALE] ?: 1.0f,
            downloadFolder = prefs[Keys.DOWNLOAD_FOLDER] ?: ".yiffy_media",
            googleAccountEmail = prefs[Keys.GOOGLE_EMAIL] ?: "",
            isGoogleConnected = prefs[Keys.IS_GOOGLE_CONNECTED] ?: false,
            e621Login = prefs[Keys.E621_LOGIN] ?: "",
            e621ApiKey = prefs[Keys.E621_API_KEY] ?: "",
            rule34ApiKey = prefs[Keys.RULE34_API_KEY] ?: "",
            redditClientId = prefs[Keys.REDDIT_CLIENT_ID] ?: "",
            redditClientSecret = prefs[Keys.REDDIT_CLIENT_SECRET] ?: "",
            blueskyHandle = prefs[Keys.BLUESKY_HANDLE] ?: "",
            blueskyAppPassword = prefs[Keys.BLUESKY_APP_PASSWORD] ?: "",
            twitterBearerToken = prefs[Keys.TWITTER_TOKEN] ?: "",
            userName = prefs[Keys.USER_NAME] ?: "NeonFox",
            userBio = prefs[Keys.USER_BIO] ?: "Minimalist media explorer with automated booru algorithms",
            redditSubreddits = prefs[Keys.REDDIT_SUBREDDITS] ?: "furry,yiff,anthro,furryartschool",
            e621DefaultTags = prefs[Keys.E621_DEFAULT_TAGS] ?: "order:score score:>10",
            rule34DefaultTags = prefs[Keys.RULE34_DEFAULT_TAGS] ?: "sort:score:desc",
            pornhubSearchQuery = prefs[Keys.PORNHUB_SEARCH_QUERY] ?: "furry animation"
        )
    }

    suspend fun setGenderFilter(filter: GenderFilter) {
        context.dataStore.edit {
            it[Keys.GENDER_FILTER] = filter.name
            it[Keys.MALES_ONLY] = (filter == GenderFilter.FEMALE_ONLY)
        }
    }

    suspend fun setMalesOnly(enabled: Boolean) {
        setGenderFilter(if (enabled) GenderFilter.FEMALE_ONLY else GenderFilter.ANY)
    }

    suspend fun toggleSource(sourceName: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.ENABLED_SOURCES] ?: MediaSource.entries.map { it.name }.toSet()
            val updated = if (current.contains(sourceName)) {
                if (current.size > 1) current - sourceName else current
            } else {
                current + sourceName
            }
            prefs[Keys.ENABLED_SOURCES] = updated
        }
    }

    suspend fun setUiScale(scale: Float) {
        context.dataStore.edit { it[Keys.UI_SCALE] = scale.coerceIn(0.80f, 1.30f) }
    }

    suspend fun setDownloadFolder(path: String) {
        context.dataStore.edit { it[Keys.DOWNLOAD_FOLDER] = path.ifBlank { ".yiffy_media" } }
    }

    suspend fun setGoogleAccount(email: String, connected: Boolean) {
        context.dataStore.edit {
            it[Keys.GOOGLE_EMAIL] = email
            it[Keys.IS_GOOGLE_CONNECTED] = connected
        }
    }

    suspend fun saveApiKeys(
        e621Login: String,
        e621ApiKey: String,
        rule34ApiKey: String,
        redditClientId: String,
        redditClientSecret: String,
        blueskyHandle: String,
        blueskyAppPassword: String,
        twitterBearerToken: String
    ) {
        context.dataStore.edit {
            it[Keys.E621_LOGIN] = e621Login
            it[Keys.E621_API_KEY] = e621ApiKey
            it[Keys.RULE34_API_KEY] = rule34ApiKey
            it[Keys.REDDIT_CLIENT_ID] = redditClientId
            it[Keys.REDDIT_CLIENT_SECRET] = redditClientSecret
            it[Keys.BLUESKY_HANDLE] = blueskyHandle
            it[Keys.BLUESKY_APP_PASSWORD] = blueskyAppPassword
            it[Keys.TWITTER_TOKEN] = twitterBearerToken
        }
    }

    suspend fun saveSourceQueryConfigs(
        redditSubreddits: String,
        e621DefaultTags: String,
        rule34DefaultTags: String,
        pornhubQuery: String
    ) {
        context.dataStore.edit {
            it[Keys.REDDIT_SUBREDDITS] = redditSubreddits.ifBlank { "furry,yiff,anthro,furryartschool" }
            it[Keys.E621_DEFAULT_TAGS] = e621DefaultTags.ifBlank { "order:score score:>10" }
            it[Keys.RULE34_DEFAULT_TAGS] = rule34DefaultTags.ifBlank { "sort:score:desc" }
            it[Keys.PORNHUB_SEARCH_QUERY] = pornhubQuery.ifBlank { "furry animation" }
        }
    }

    suspend fun updateProfile(name: String, bio: String) {
        context.dataStore.edit {
            it[Keys.USER_NAME] = name
            it[Keys.USER_BIO] = bio
        }
    }
}
