package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

import com.example.data.remote.GeminiClient

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "raynox_user_prefs")

data class UserSettings(
    val themeMode: String = "DARK", // "DARK", "LIGHT", "SYSTEM"
    val selectedModel: String = GeminiClient.MODEL_RAYNOX_CORE,
    val voiceLanguage: String = "en-IN", // "en-IN", "hi-IN", "en-US"
    val autoSpeakResponses: Boolean = false,
    val userName: String = "",
    val customInstructions: String = "",
    val wakeWordEnabled: Boolean = false
)

class UserPreferencesRepository(private val context: Context) {
    companion object {
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_SELECTED_MODEL = stringPreferencesKey("selected_model")
        private val KEY_VOICE_LANGUAGE = stringPreferencesKey("voice_language")
        private val KEY_AUTO_SPEAK = booleanPreferencesKey("auto_speak_responses")
        private val KEY_USER_NAME = stringPreferencesKey("user_name")
        private val KEY_CUSTOM_INSTRUCTIONS = stringPreferencesKey("custom_instructions")
        private val KEY_WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            themeMode = prefs[KEY_THEME_MODE] ?: "DARK",
            selectedModel = prefs[KEY_SELECTED_MODEL] ?: GeminiClient.MODEL_RAYNOX_CORE,
            voiceLanguage = prefs[KEY_VOICE_LANGUAGE] ?: "en-IN",
            autoSpeakResponses = prefs[KEY_AUTO_SPEAK] ?: false,
            userName = prefs[KEY_USER_NAME] ?: "",
            customInstructions = prefs[KEY_CUSTOM_INSTRUCTIONS] ?: "",
            wakeWordEnabled = prefs[KEY_WAKE_WORD_ENABLED] ?: false
        )
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode }
    }

    suspend fun setSelectedModel(model: String) {
        context.dataStore.edit { it[KEY_SELECTED_MODEL] = model }
    }

    suspend fun setVoiceLanguage(language: String) {
        context.dataStore.edit { it[KEY_VOICE_LANGUAGE] = language }
    }

    suspend fun setAutoSpeak(enabled: Boolean) {
        context.dataStore.edit { it[KEY_AUTO_SPEAK] = enabled }
    }

    suspend fun updateProfile(name: String, customInstructions: String) {
        context.dataStore.edit {
            it[KEY_USER_NAME] = name.trim()
            it[KEY_CUSTOM_INSTRUCTIONS] = customInstructions.trim()
        }
    }

    suspend fun setWakeWordEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_WAKE_WORD_ENABLED] = enabled }
    }
}
