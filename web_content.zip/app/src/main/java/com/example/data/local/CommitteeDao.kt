package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object for local offline Committee management.
 */
@Dao
interface CommitteeDao {
    @Query("SELECT * FROM committees ORDER BY timestamp DESC")
    fun getAllCommittees(): Flow<List<CommitteeEntity>>

    @Query("SELECT * FROM committees WHERE unit = :unit ORDER BY timestamp DESC")
    fun getCommitteesByUnit(unit: String): Flow<List<CommitteeEntity>>

    @Query("SELECT * FROM committees WHERE id = :id")
    fun getCommitteeById(id: Long): Flow<CommitteeEntity?>

    @Query("SELECT * FROM committees WHERE syncedToSheet = 0 ORDER BY timestamp DESC")
    fun getUnsyncedCommittees(): Flow<List<CommitteeEntity>>

    @Query("SELECT COUNT(*) FROM committees")
    fun getCommitteeCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(committee: CommitteeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(committees: List<CommitteeEntity>)

    @Update
    suspend fun update(committee: CommitteeEntity)

    @Delete
    suspend fun delete(committee: CommitteeEntity)

    @Query("DELETE FROM committees WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM committees")
    suspend fun clearAll()

    @Query("UPDATE committees SET syncedToSheet = :synced WHERE id = :id")
    suspend fun markSynced(id: Long, synced: Boolean = true)
}
