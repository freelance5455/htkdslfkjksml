package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CycleStatus
import com.example.data.model.DeliveryEntry
import com.example.data.model.GpsTrackPoint
import com.example.data.model.TrackingSession
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow

@Dao
interface DeliveryDao {

    // Delivery Entries
    @Query("SELECT * FROM delivery_entries ORDER BY dateString DESC, id DESC")
    fun getAllEntries(): Flow<List<DeliveryEntry>>

    @Query("SELECT * FROM delivery_entries WHERE monthKey = :monthKey ORDER BY dateString ASC")
    fun getEntriesForMonth(monthKey: String): Flow<List<DeliveryEntry>>

    @Query("SELECT * FROM delivery_entries WHERE monthKey = :monthKey ORDER BY dateString ASC")
    suspend fun getEntriesForMonthSync(monthKey: String): List<DeliveryEntry>

    @Query("SELECT * FROM delivery_entries WHERE dateString = :dateString LIMIT 1")
    fun getEntryForDate(dateString: String): Flow<DeliveryEntry?>

    @Query("SELECT * FROM delivery_entries WHERE dateString = :dateString LIMIT 1")
    suspend fun getEntryForDateSync(dateString: String): DeliveryEntry?

    @Query("SELECT * FROM delivery_entries WHERE monthKey = :monthKey AND cycleNumber = :cycleNumber ORDER BY dateString ASC")
    fun getEntriesForCycle(monthKey: String, cycleNumber: Int): Flow<List<DeliveryEntry>>

    @Query("SELECT * FROM delivery_entries WHERE dateString BETWEEN :startDate AND :endDate ORDER BY dateString ASC")
    suspend fun getEntriesBetweenDatesSync(startDate: String, endDate: String): List<DeliveryEntry>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: DeliveryEntry): Long

    @Update
    suspend fun updateEntry(entry: DeliveryEntry)

    @Delete
    suspend fun deleteEntry(entry: DeliveryEntry)

    @Query("DELETE FROM delivery_entries WHERE id = :id")
    suspend fun deleteEntryById(id: Long)

    // Cycle Statuses
    @Query("SELECT * FROM cycle_status WHERE monthKey = :monthKey")
    fun getCycleStatusesForMonth(monthKey: String): Flow<List<CycleStatus>>

    @Query("SELECT * FROM cycle_status WHERE cycleKey = :cycleKey LIMIT 1")
    suspend fun getCycleStatusByKeySync(cycleKey: String): CycleStatus?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCycleStatus(cycleStatus: CycleStatus)

    // User Profile
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getUserProfileSync(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUserProfile(profile: UserProfile)

    // GPS Tracking
    @Query("SELECT * FROM tracking_sessions WHERE isActive = 1 ORDER BY startTime DESC LIMIT 1")
    fun getActiveSession(): Flow<TrackingSession?>

    @Query("SELECT * FROM tracking_sessions WHERE isActive = 1 ORDER BY startTime DESC LIMIT 1")
    suspend fun getActiveSessionSync(): TrackingSession?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: TrackingSession): Long

    @Update
    suspend fun updateSession(session: TrackingSession)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrackPoint(point: GpsTrackPoint): Long

    @Query("SELECT * FROM gps_track_points WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun getTrackPoints(sessionId: Long): Flow<List<GpsTrackPoint>>

    @Query("SELECT * FROM gps_track_points WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    suspend fun getTrackPointsSync(sessionId: Long): List<GpsTrackPoint>
}
