package com.example.data

import android.content.Context
import com.example.R
import com.example.model.*
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.Date
import java.util.UUID

class MarketplaceRepository(private val db: FirebaseFirestore) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    private fun isCurrentUserAdmin(): Boolean {
        val user = auth.currentUser ?: return false
        return user.isEmailVerified && user.email.equals(MarketplaceConstants.ADMIN_EMAIL, ignoreCase = true)
    }

    private fun <T> Flow<T>.guardStream(uid: String, path: String): Flow<T> = catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<com.google.firebase.firestore.FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, OperationType.LIST, path)
        }
        throw error
    }

    // --- USER PROFILE ---
    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val uid = requireUserId()
        require(uid == userId)
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { it.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardStream(uid, "users/$userId")
        )
    }

    suspend fun ensureUserProfile(defaultLanguage: String = "sw"): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        val path = "users/$uid"
        return try {
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val user = auth.currentUser!!
                val payload = mapOf(
                    "userId" to uid,
                    "fullName" to (user.displayName?.take(100)?.ifBlank { "Mteja Smart Jones" } ?: "Mteja Smart Jones"),
                    "email" to (user.email ?: ""),
                    "phone" to "",
                    "region" to "Dar es Salaam",
                    "address" to "",
                    "preferredLanguage" to defaultLanguage,
                    "activeRole" to "customer",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun updateUserProfile(
        fullName: String,
        phone: String,
        region: String,
        address: String,
        preferredLanguage: String
    ): Result<Unit> {
        val uid = requireUserId()
        val path = "users/$uid"
        return try {
            require(fullName.trim().length in 1..100) { "Full name required (1-100 chars)" }
            db.collection("users").document(uid).update(
                mapOf(
                    "fullName" to fullName.trim().take(100),
                    "phone" to phone.trim().take(25),
                    "region" to region.trim().take(60),
                    "address" to address.trim().take(200),
                    "preferredLanguage" to if (preferredLanguage == "en") "en" else "sw",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- PROVIDERS & SERVICES ---
    fun observeAllProviders(): Flow<List<SecurityProvider>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("providers")
                .snapshots()
                .map { snap ->
                    snap.toObjects(SecurityProvider::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.ratingAvg }
                }
                .guardStream(uid, "providers")
        )
    }

    fun observeAllServices(): Flow<List<SecurityServiceListing>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("services")
                .snapshots()
                .map { snap ->
                    snap.toObjects(SecurityServiceListing::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(uid, "services")
        )
    }

    suspend fun registerProvider(
        companyName: String,
        description: String,
        categories: List<ServiceCategory>,
        locations: List<String>,
        startingPriceTzs: Long,
        businessRegNumber: String,
        securityLicenseNumber: String,
        contactPhone: String,
        revenueModel: RevenueModel,
        logoBase64: String?,
        galleryBase64: List<String>
    ): Result<String> {
        val uid = requireUserId()
        val providerId = "prov_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "providers/$providerId"
        return try {
            require(companyName.trim().length in 2..120) { "Company name must be 2-120 characters" }
            require(description.trim().length in 10..1000) { "Description must be 10-1000 characters" }
            require(categories.isNotEmpty()) { "Select at least 1 security category" }
            require(locations.isNotEmpty()) { "Select at least 1 service location" }
            require(businessRegNumber.trim().length in 2..60) { "Valid BRELA registration required" }
            require(securityLicenseNumber.trim().length in 2..60) { "Valid security license required" }
            require(contactPhone.trim().length in 6..25) { "Valid phone number required" }

            val payload = mutableMapOf<String, Any?>(
                "ownerId" to uid,
                "companyName" to companyName.trim().take(120),
                "description" to description.trim().take(1000),
                "categories" to categories.take(10).map { it.name },
                "locations" to locations.take(20),
                "startingPriceTzs" to startingPriceTzs.coerceAtLeast(0L),
                "businessRegNumber" to businessRegNumber.trim().take(60),
                "securityLicenseNumber" to securityLicenseNumber.trim().take(60),
                "contactPhone" to contactPhone.trim().take(25),
                "logoBase64" to logoBase64?.take(240000),
                "galleryBase64" to galleryBase64.take(3).map { it.take(240000) },
                "verificationStatus" to VerificationStatus.PENDING.name,
                "verifiedBadge" to false,
                "featured" to false,
                "revenueModel" to revenueModel.name,
                "subscriptionStatus" to SubscriptionStatus.INACTIVE.name,
                "ratingAvg" to 0.0,
                "ratingCount" to 0L,
                "completedOrdersCount" to 0L,
                "totalEarningsTzs" to 0L,
                "commissionOwedTzs" to 0L,
                "commissionCollectedTzs" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            val batch = db.batch()
            batch.set(db.collection("providers").document(providerId), payload)
            batch.update(
                db.collection("users").document(uid),
                mapOf(
                    "providerId" to providerId,
                    "activeRole" to "provider",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            writeAuditLog("PROVIDER_REGISTERED", "PROVIDER", providerId, "Registered ${companyName.trim()}")
            Result.success(providerId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun switchProviderRevenueModel(providerId: String, newModel: RevenueModel): Result<Unit> {
        requireUserId()
        val path = "providers/$providerId"
        return try {
            db.collection("providers").document(providerId).update(
                mapOf(
                    "revenueModel" to newModel.name,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            writeAuditLog("REVENUE_MODEL_CHANGED", "PROVIDER", providerId, "Switched to ${newModel.name}")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun createServiceListing(
        provider: SecurityProvider,
        category: ServiceCategory,
        title: String,
        description: String,
        priceTzs: Long,
        priceUnit: String,
        location: String,
        offerBadge: String?,
        discountPercent: Long
    ): Result<Unit> {
        val uid = requireUserId()
        val serviceId = "srv_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "services/$serviceId"
        return try {
            require(provider.ownerId == uid) { "Only company owner can list services" }
            require(title.trim().length in 3..120) { "Title must be 3-120 characters" }
            require(description.trim().length in 5..600) { "Description must be 5-600 characters" }
            require(priceTzs >= 1000L) { "Minimum service price is TZS 1,000" }

            val payload = mutableMapOf<String, Any?>(
                "providerId" to provider.id,
                "ownerId" to uid,
                "companyName" to provider.companyName,
                "providerVerified" to provider.verifiedBadge,
                "category" to category.name,
                "title" to title.trim().take(120),
                "description" to description.trim().take(600),
                "priceTzs" to priceTzs,
                "priceUnit" to priceUnit.trim().ifBlank { "fixed" }.take(40),
                "location" to location.trim().take(80),
                "offerBadge" to offerBadge?.trim()?.takeIf { it.isNotBlank() }?.take(40),
                "discountPercent" to discountPercent.coerceIn(0L, 80L),
                "active" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            db.collection("services").document(serviceId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteServiceListing(serviceId: String): Result<Unit> {
        requireUserId()
        val path = "services/$serviceId"
        return try {
            db.collection("services").document(serviceId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- ORDERS & 10-STAGE LIFECYCLE ---
    fun observeCustomerOrders(uid: String): Flow<List<SecurityOrder>> = flow {
        val currentUid = requireUserId()
        require(currentUid == uid)
        emitAll(
            db.collection("orders")
                .whereEqualTo("customerId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(SecurityOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(currentUid, "orders")
        )
    }

    fun observeProviderOrders(uid: String): Flow<List<SecurityOrder>> = flow {
        val currentUid = requireUserId()
        require(currentUid == uid)
        emitAll(
            db.collection("orders")
                .whereEqualTo("providerOwnerId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(SecurityOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(currentUid, "orders")
        )
    }

    suspend fun submitOrderRequest(
        customerName: String,
        customerPhone: String,
        provider: SecurityProvider,
        service: SecurityServiceListing?,
        category: ServiceCategory,
        serviceTitle: String,
        location: String,
        requirementDescription: String,
        attachmentPreviews: List<String>
    ): Result<String> {
        val uid = requireUserId()
        val orderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "orders/$orderId"
        return try {
            require(provider.isEligibleToReceiveOrders()) {
                "Provider monthly subscription has expired; renewal required before accepting orders."
            }
            require(requirementDescription.trim().length in 5..1000) {
                "Requirement description must be 5-1000 characters"
            }

            val rate = if (provider.revenueEnum() == RevenueModel.COMMISSION) {
                MarketplaceConstants.COMMISSION_RATE_PERCENT
            } else 0L

            val payload = mutableMapOf<String, Any?>(
                "customerId" to uid,
                "customerName" to customerName.trim().ifBlank { "Mteja" }.take(100),
                "customerPhone" to customerPhone.trim().take(25),
                "providerId" to provider.id,
                "providerOwnerId" to provider.ownerId,
                "providerName" to provider.companyName,
                "serviceId" to service?.id,
                "serviceCategory" to category.name,
                "serviceTitle" to serviceTitle.trim().take(120),
                "location" to location.trim().take(100),
                "requirementDescription" to requirementDescription.trim().take(1000),
                "attachmentPreviews" to attachmentPreviews.take(2),
                "quotedAmountTzs" to (service?.priceTzs ?: 0L),
                "commissionModel" to provider.revenueModel,
                "commissionRatePercent" to rate,
                "commissionAmountTzs" to 0L,
                "paymentStatus" to PaymentStatus.UNPAID.name,
                "status" to OrderStatus.REQUESTED.name,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>

            db.collection("orders").document(orderId).set(payload).await()
            writeAuditLog("ORDER_CREATED", "ORDER", orderId, "Requested $serviceTitle from ${provider.companyName}")
            Result.success(orderId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun markOrderReceived(orderId: String): Result<Unit> =
        updateOrderFields(orderId, mapOf("status" to OrderStatus.PROVIDER_RECEIVED.name))

    suspend fun submitQuotation(orderId: String, amountTzs: Long, notes: String): Result<Unit> {
        requireUserId()
        if (amountTzs < 1000L) return Result.failure(IllegalArgumentException("Quotation must be at least TZS 1,000"))
        return updateOrderFields(
            orderId,
            mapOf(
                "status" to OrderStatus.QUOTATION_SUBMITTED.name,
                "quotedAmountTzs" to amountTzs,
                "quotationNotes" to notes.trim().take(500)
            )
        ).also {
            if (it.isSuccess) writeAuditLog("QUOTATION_SUBMITTED", "ORDER", orderId, "Quoted ${TzsFormatter.format(amountTzs)}")
        }
    }

    suspend fun acceptQuotation(orderId: String): Result<Unit> =
        updateOrderFields(orderId, mapOf("status" to OrderStatus.QUOTATION_ACCEPTED.name))

    suspend fun markServiceDelivered(orderId: String): Result<Unit> =
        updateOrderFields(orderId, mapOf("status" to OrderStatus.SERVICE_DELIVERED.name))

    suspend fun confirmCompletionAndClose(order: SecurityOrder): Result<Unit> {
        requireUserId()
        val path = "orders/${order.id}"
        return try {
            require(order.paymentEnum() == PaymentStatus.VERIFIED) {
                "Payment must be verified before confirming completion."
            }
            val commission = CommissionCalculator.calculateCommission(order.quotedAmountTzs, order.revenueEnum())
            val batch = db.batch()
            batch.update(
                db.collection("orders").document(order.id),
                mapOf(
                    "status" to OrderStatus.CLOSED.name,
                    "commissionAmountTzs" to commission,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                db.collection("providers").document(order.providerId),
                mapOf(
                    "completedOrdersCount" to FieldValue.increment(1L),
                    "totalEarningsTzs" to FieldValue.increment(order.quotedAmountTzs),
                    "commissionOwedTzs" to FieldValue.increment(commission),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            writeAuditLog(
                "ORDER_CLOSED_COMMISSION_CALC",
                "ORDER",
                order.id,
                "Closed order; 5% commission = ${TzsFormatter.format(commission)}"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun cancelOrder(orderId: String, reason: String): Result<Unit> =
        updateOrderFields(
            orderId,
            mapOf(
                "status" to OrderStatus.CANCELLED.name,
                "cancellationReason" to reason.trim().ifBlank { "Cancelled" }.take(400)
            )
        )

    suspend fun disputeOrder(orderId: String, reason: String): Result<Unit> =
        updateOrderFields(
            orderId,
            mapOf(
                "status" to OrderStatus.DISPUTED.name,
                "disputeReason" to reason.trim().ifBlank { "Dispute opened" }.take(400)
            )
        )

    suspend fun rateClosedOrder(order: SecurityOrder, provider: SecurityProvider?, stars: Int, comment: String): Result<Unit> {
        requireUserId()
        val path = "orders/${order.id}"
        return try {
            val safeStars = stars.coerceIn(1, 5).toLong()
            val batch = db.batch()
            batch.update(
                db.collection("orders").document(order.id),
                mapOf(
                    "ratingStars" to safeStars,
                    "ratingComment" to comment.trim().take(400),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (provider != null) {
                val newCount = provider.ratingCount + 1L
                val newAvg = ((provider.ratingAvg * provider.ratingCount) + safeStars) / newCount.toDouble()
                batch.update(
                    db.collection("providers").document(provider.id),
                    mapOf(
                        "ratingAvg" to newAvg.coerceIn(0.0, 5.0),
                        "ratingCount" to newCount,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    private suspend fun updateOrderFields(orderId: String, fields: Map<String, Any>): Result<Unit> {
        requireUserId()
        val path = "orders/$orderId"
        return try {
            val payload = fields.toMutableMap().apply {
                put("updatedAt", FieldValue.serverTimestamp())
            }
            db.collection("orders").document(orderId).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- ORDER CHAT ---
    fun observeOrderMessages(orderId: String): Flow<List<OrderMessage>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("orders").document(orderId).collection("messages")
                .whereArrayContains("participantIds", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(OrderMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(uid, "orders/$orderId/messages")
        )
    }

    suspend fun sendOrderMessage(order: SecurityOrder, senderName: String, text: String): Result<Unit> {
        val uid = requireUserId()
        val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "orders/${order.id}/messages/$msgId"
        return try {
            val trimmed = text.trim()
            require(trimmed.isNotEmpty()) { "Message cannot be empty" }
            val payload = mapOf(
                "orderId" to order.id,
                "senderId" to uid,
                "senderName" to senderName.trim().ifBlank { "User" }.take(100),
                "participantIds" to listOf(order.customerId, order.providerOwnerId).distinct(),
                "text" to trimmed.take(1000),
                "createdAt" to FieldValue.serverTimestamp()
            )
            db.collection("orders").document(order.id).collection("messages").document(msgId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    // --- AIRTEL MONEY TANZANIA PAYMENTS (0788016987) ---
    fun observeCustomerPayments(uid: String): Flow<List<PaymentTransaction>> = flow {
        val currentUid = requireUserId()
        require(currentUid == uid)
        emitAll(
            db.collection("payments")
                .whereEqualTo("payerId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(PaymentTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(currentUid, "payments")
        )
    }

    fun observeProviderPayments(uid: String): Flow<List<PaymentTransaction>> = flow {
        val currentUid = requireUserId()
        require(currentUid == uid)
        emitAll(
            db.collection("payments")
                .whereEqualTo("providerOwnerId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(PaymentTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(currentUid, "payments")
        )
    }

    suspend fun initiateOrderAirtelPayment(
        order: SecurityOrder,
        payerName: String,
        payerPhone: String
    ): Result<PaymentTransaction> {
        val uid = requireUserId()
        val paymentId = "pay_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "payments/$paymentId"
        return try {
            require(order.paymentEnum() != PaymentStatus.VERIFIED && order.paymentEnum() != PaymentStatus.PENDING_CALLBACK) {
                "Duplicate payment blocked: order already paid or awaiting Airtel Money callback."
            }
            require(order.quotedAmountTzs >= 1000L) { "Order quotation amount invalid" }
            require(payerPhone.trim().length in 9..20) { "Enter valid Airtel Money phone number" }

            val commission = CommissionCalculator.calculateCommission(order.quotedAmountTzs, order.revenueEnum())
            val net = (order.quotedAmountTzs - commission).coerceAtLeast(0L)
            val txRef = "SJS-AM-${System.currentTimeMillis().toString().takeLast(8)}"
            val receipt = "RCT-${UUID.randomUUID().toString().uppercase().take(8)}"
            val isProd = AirtelGatewayConfig.isProductionBackendConfigured
            val mode = if (isProd) "PRODUCTION_API" else "SANDBOX"

            val payload = mapOf(
                "payerId" to uid,
                "payerName" to payerName.trim().ifBlank { "Customer" }.take(100),
                "payerPhone" to payerPhone.trim().take(20),
                "recipientNumber" to MarketplaceConstants.ADMIN_AIRTEL_NUMBER,
                "providerId" to order.providerId,
                "providerOwnerId" to order.providerOwnerId,
                "orderId" to order.id,
                "paymentType" to "ORDER_PAYMENT",
                "amountTzs" to order.quotedAmountTzs,
                "commissionTzs" to commission,
                "providerNetTzs" to net,
                "transactionRef" to txRef,
                "receiptNumber" to receipt,
                "status" to PaymentStatus.PENDING_CALLBACK.name,
                "mode" to mode,
                "gatewayMessage" to if (isProd) {
                    "Initiating Airtel Money Tanzania USSD push to ${MarketplaceConstants.ADMIN_AIRTEL_NUMBER}"
                } else {
                    "SANDBOX MODE: Awaiting webhook verification callback (Target ${MarketplaceConstants.ADMIN_AIRTEL_NUMBER})"
                },
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(db.collection("payments").document(paymentId), payload)
            batch.update(
                db.collection("orders").document(order.id),
                mapOf(
                    "status" to OrderStatus.PAYMENT_INITIATED.name,
                    "paymentStatus" to PaymentStatus.PENDING_CALLBACK.name,
                    "paymentReference" to txRef,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()

            if (isProd) {
                val idToken = auth.currentUser?.getIdToken(false)?.await()?.token
                val api = AirtelGatewayConfig.createApiOrNull()
                if (api != null && !idToken.isNullOrBlank()) {
                    api.initiateCollection(
                        bearerToken = "Bearer $idToken",
                        request = AirtelInitiateRequest(
                            paymentId = paymentId,
                            payerPhone = payerPhone.trim(),
                            amountTzs = order.quotedAmountTzs,
                            orderId = order.id,
                            paymentType = "ORDER_PAYMENT"
                        )
                    )
                }
            }

            writeAuditLog("PAYMENT_INITIATED", "PAYMENT", paymentId, "$mode payment $txRef (${TzsFormatter.format(order.quotedAmountTzs)})")
            val created = db.collection("payments").document(paymentId).get().await()
                .toObject(PaymentTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: PaymentTransaction(id = paymentId, transactionRef = txRef, receiptNumber = receipt, amountTzs = order.quotedAmountTzs)
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun initiateSubscriptionAirtelPayment(
        provider: SecurityProvider,
        payerName: String,
        payerPhone: String
    ): Result<PaymentTransaction> {
        val uid = requireUserId()
        val paymentId = "sub_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "payments/$paymentId"
        return try {
            require(payerPhone.trim().length in 9..20) { "Enter valid Airtel Money phone number" }
            val fee = MarketplaceConstants.MONTHLY_SUBSCRIPTION_FEE_TZS
            val txRef = "SJS-SUB-${System.currentTimeMillis().toString().takeLast(8)}"
            val receipt = "RCT-${UUID.randomUUID().toString().uppercase().take(8)}"
            val isProd = AirtelGatewayConfig.isProductionBackendConfigured
            val mode = if (isProd) "PRODUCTION_API" else "SANDBOX"

            val payload = mapOf(
                "payerId" to uid,
                "payerName" to payerName.trim().ifBlank { provider.companyName }.take(100),
                "payerPhone" to payerPhone.trim().take(20),
                "recipientNumber" to MarketplaceConstants.ADMIN_AIRTEL_NUMBER,
                "providerId" to provider.id,
                "providerOwnerId" to provider.ownerId,
                "paymentType" to "PROVIDER_SUBSCRIPTION",
                "amountTzs" to fee,
                "commissionTzs" to fee,
                "providerNetTzs" to 0L,
                "transactionRef" to txRef,
                "receiptNumber" to receipt,
                "status" to PaymentStatus.PENDING_CALLBACK.name,
                "mode" to mode,
                "gatewayMessage" to if (isProd) {
                    "Initiating TZS 20,000 subscription push to ${MarketplaceConstants.ADMIN_AIRTEL_NUMBER}"
                } else {
                    "SANDBOX MODE: TZS 20,000 monthly subscription awaiting callback"
                },
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("payments").document(paymentId).set(payload).await()
            val created = db.collection("payments").document(paymentId).get().await()
                .toObject(PaymentTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: PaymentTransaction(id = paymentId, transactionRef = txRef, receiptNumber = receipt, amountTzs = fee)
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    /**
     * Completes verification for Sandbox test payments OR Admin-verified transactions.
     * Production API payments can never be self-verified by regular clients (enforced in firestore.rules).
     */
    suspend fun verifyPaymentCallback(payment: PaymentTransaction): Result<Unit> {
        requireUserId()
        val path = "payments/${payment.id}"
        return try {
            require(payment.mode == "SANDBOX" || isCurrentUserAdmin()) {
                "Production Airtel Money payments require server-side webhook or Admin verification."
            }
            require(payment.statusEnum() != PaymentStatus.VERIFIED) {
                "Duplicate verification prevented: payment already verified."
            }

            val batch = db.batch()
            batch.update(
                db.collection("payments").document(payment.id),
                mapOf(
                    "status" to PaymentStatus.VERIFIED.name,
                    "gatewayMessage" to if (payment.mode == "SANDBOX") {
                        "SANDBOX VERIFIED: Simulated Airtel webhook confirmed to ${MarketplaceConstants.ADMIN_AIRTEL_NUMBER}"
                    } else {
                        "ADMIN VERIFIED: Confirmed Airtel Money settlement to ${MarketplaceConstants.ADMIN_AIRTEL_NUMBER}"
                    },
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            if (payment.paymentType == "ORDER_PAYMENT" && !payment.orderId.isNullOrBlank()) {
                batch.update(
                    db.collection("orders").document(payment.orderId),
                    mapOf(
                        "paymentStatus" to PaymentStatus.VERIFIED.name,
                        "status" to OrderStatus.PAYMENT_CONFIRMED.name,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else if (payment.paymentType == "PROVIDER_SUBSCRIPTION") {
                val expiresAt = Timestamp(Date(System.currentTimeMillis() + MarketplaceConstants.SUBSCRIPTION_DAYS * 24L * 60L * 60L * 1000L))
                batch.update(
                    db.collection("providers").document(payment.providerId),
                    mapOf(
                        "revenueModel" to RevenueModel.MONTHLY_SUBSCRIPTION.name,
                        "subscriptionStatus" to SubscriptionStatus.ACTIVE.name,
                        "subscriptionExpiresAt" to expiresAt,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            writeAuditLog("PAYMENT_VERIFIED", "PAYMENT", payment.id, "Verified ${payment.transactionRef} (${payment.mode})")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    // --- COMPLAINTS ---
    fun observeCustomerComplaints(uid: String): Flow<List<Complaint>> = flow {
        val currentUid = requireUserId()
        require(currentUid == uid)
        emitAll(
            db.collection("complaints")
                .whereEqualTo("customerId", uid)
                .snapshots()
                .map { snap ->
                    snap.toObjects(Complaint::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(currentUid, "complaints")
        )
    }

    suspend fun submitComplaint(
        customerName: String,
        subject: String,
        description: String,
        orderId: String? = null,
        providerId: String? = null
    ): Result<Unit> {
        val uid = requireUserId()
        val id = "cmp_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val path = "complaints/$id"
        return try {
            require(subject.trim().length in 3..120) { "Subject must be 3-120 characters" }
            require(description.trim().length in 10..1000) { "Description must be 10-1000 characters" }
            val payload = mutableMapOf<String, Any?>(
                "customerId" to uid,
                "customerName" to customerName.trim().ifBlank { "Customer" }.take(100),
                "orderId" to orderId,
                "providerId" to providerId,
                "subject" to subject.trim().take(120),
                "description" to description.trim().take(1000),
                "status" to ComplaintStatus.OPEN.name,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null } as Map<String, Any>
            db.collection("complaints").document(id).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    // --- ADMIN STREAMS & ACTIONS ---
    fun observeAdminUsers(): Flow<List<UserProfile>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("users").snapshots()
                .map { it.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardStream(uid, "users")
        )
    }

    fun observeAdminOrders(): Flow<List<SecurityOrder>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("orders").snapshots()
                .map {
                    it.toObjects(SecurityOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { o -> o.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(uid, "orders")
        )
    }

    fun observeAdminPayments(): Flow<List<PaymentTransaction>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("payments").snapshots()
                .map {
                    it.toObjects(PaymentTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { p -> p.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(uid, "payments")
        )
    }

    fun observeAdminComplaints(): Flow<List<Complaint>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("complaints").snapshots()
                .map {
                    it.toObjects(Complaint::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { c -> c.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(uid, "complaints")
        )
    }

    fun observeAdminAuditLogs(): Flow<List<AuditLog>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("audit_logs").snapshots()
                .map {
                    it.toObjects(AuditLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { l -> l.createdAt ?: Timestamp(0, 0) }
                }
                .guardStream(uid, "audit_logs")
        )
    }

    suspend fun verifyProviderByAdmin(
        providerId: String,
        status: VerificationStatus,
        verifiedBadge: Boolean,
        featured: Boolean
    ): Result<Unit> {
        requireUserId()
        val path = "providers/$providerId"
        return try {
            db.collection("providers").document(providerId).update(
                mapOf(
                    "verificationStatus" to status.name,
                    "verifiedBadge" to verifiedBadge,
                    "featured" to featured,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            val linkedServices = db.collection("services").whereEqualTo("providerId", providerId).get().await()
            if (!linkedServices.isEmpty) {
                val batch = db.batch()
                linkedServices.documents.forEach { doc ->
                    batch.update(
                        doc.reference,
                        mapOf("providerVerified" to verifiedBadge, "updatedAt" to FieldValue.serverTimestamp())
                    )
                }
                batch.commit().await()
            }
            writeAuditLog("PROVIDER_VERIFICATION_UPDATED", "PROVIDER", providerId, "${status.name} (badge=$verifiedBadge)")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun markCommissionCollectedByAdmin(provider: SecurityProvider, amountTzs: Long): Result<Unit> {
        requireUserId()
        val path = "providers/${provider.id}"
        return try {
            val collect = amountTzs.coerceIn(0L, provider.commissionOwedTzs)
            db.collection("providers").document(provider.id).update(
                mapOf(
                    "commissionOwedTzs" to (provider.commissionOwedTzs - collect).coerceAtLeast(0L),
                    "commissionCollectedTzs" to (provider.commissionCollectedTzs + collect),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            writeAuditLog("COMMISSION_COLLECTED", "PROVIDER", provider.id, "Collected ${TzsFormatter.format(collect)}")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun resolveComplaintByAdmin(complaintId: String, status: ComplaintStatus, notes: String): Result<Unit> {
        requireUserId()
        val path = "complaints/$complaintId"
        return try {
            db.collection("complaints").document(complaintId).update(
                mapOf(
                    "status" to status.name,
                    "adminNotes" to notes.trim().take(500),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            writeAuditLog("COMPLAINT_UPDATED", "COMPLAINT", complaintId, "Status -> ${status.name}")
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun bootstrapStarterCatalogByAdmin(): Result<Unit> {
        val uid = requireUserId()
        return AdminSeedHelper.seedVerifiedMarketplaceCatalog(db, uid, auth.currentUser?.email ?: "")
    }

    private suspend fun writeAuditLog(action: String, targetType: String, targetId: String, summary: String) {
        val user = auth.currentUser ?: return
        val logId = "log_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        try {
            db.collection("audit_logs").document(logId).set(
                mapOf(
                    "actorId" to user.uid,
                    "actorEmail" to (user.email ?: "unknown"),
                    "action" to action.take(80),
                    "targetType" to targetType.take(40),
                    "targetId" to targetId.take(128),
                    "summary" to summary.take(400),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (_: Exception) {
            // Non-blocking audit write
        }
    }
}
