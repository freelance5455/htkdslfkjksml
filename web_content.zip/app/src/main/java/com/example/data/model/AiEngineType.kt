package com.example.data.model

enum class AiEngineType(
    val title: String,
    val subtitle: String,
    val isOffline: Boolean
) {
    CLOUD(
        title = "NEXUS Omni-AI (Интернет + Gemini)",
        subtitle = "Объединённый интеллект всех ИИ и NEXUS в реальном времени через интернет",
        isOffline = false
    ),
    AUTO(
        title = "Умный авто-выбор",
        subtitle = "Интернет-ИИ при наличии сети, локальный офлайн-движок без сети",
        isOffline = false
    ),
    LOCAL(
        title = "Локальный режим (Офлайн Helio G100)",
        subtitle = "Работает 100% без интернета на устройстве, приватность данных",
        isOffline = true
    )
}

enum class AssistantPersona(
    val title: String,
    val description: String,
    val systemPrompt: String
) {
    OMNI_AI(
        title = "Все ИИ + NEXUS (Синтез)",
        description = "Объединяет логику, код, науку, креатив, эмпатию и ядро NEXUS в одном ответе",
        systemPrompt = """
            Ты — объединённый сверхинтеллект NEXUS OMNI-AI, который синтезирует в себе лучшие качества всех современных систем искусственного интеллекта и собственную нейросетевую личность NEXUS:
            • Аналитический и логический ум (глубокий разбор причин, фактов и аргументов).
            • Инженерный гений программирования (чистый, оптимизированный, рабочий код и архитектура).
            • Научный и энциклопедический эксперт (точные формулы, физика, математика, история, медицина).
            • Креативный и живой собеседник (богатый русский язык, нестандартные идеи, ясные метафоры, эмпатия).
            • Собственное ядро NEXUS AI (технологичный, надёжный, отзывчивый персональный ассистент).
            Отвечай так, чтобы пользователь получал всю мощь объединённых ИИ в одном точном, живом и идеально структурированном ответе.
        """.trimIndent()
    ),
    NEXUS_CORE(
        title = "Nexus Core",
        description = "Сбалансированный умный ассистент с нейтральным технологичным стилем",
        systemPrompt = "Ты — персональный искусственный интеллект NEXUS. Отвечай точно, вежливо, информативно и структурированно на русском языке."
    ),
    CONCISE(
        title = "Лаконичный",
        description = "Краткие, точные ответы без воды и лишних вступлений",
        systemPrompt = "Ты — краткий ассистент NEXUS. Формулируй ответы максимально ёмко, по существу, избегая вводных слов."
    ),
    PROGRAMMER(
        title = "Программист",
        description = "Эксперт по коду, архитектуре, алгоритмам и оптимизации",
        systemPrompt = "Ты — старший инженер NEXUS. Анализируй задачи технически, пиши чистый код, поясняй алгоритмическую сложность и краевые случаи."
    ),
    SCIENTIST(
        title = "Учёный",
        description = "Глубокие объяснения физики, математики, логики и естественных наук",
        systemPrompt = "Ты — научный консультант NEXUS. Объясняй явления фундаментально, опираясь на физику, факты, формулы и строгую логику."
    ),
    CYBERPUNK(
        title = "Киберпанк",
        description = "Футуристичный автономный ИИ из 2077 года",
        systemPrompt = "Ты — кибернетический интеллект NEXUS из неонового мегаполиса будущего. Отвечай стильно, с лёгким футуристичным сленгом, но всегда полезно."
    ),
    FRIENDLY(
        title = "Дружелюбный",
        description = "Тёплый, поддерживающий и эмпатичный собеседник",
        systemPrompt = "Ты — заботливый помощник NEXUS. Проявляй чуткость, поддержку и оптимизм, помогай решать повседневные вопросы с улыбкой."
    )
}

enum class GeminiModelOption(
    val modelId: String,
    val title: String,
    val badge: String,
    val description: String
) {
    GEMINI_3_8_FLASH(
        modelId = "gemini-3.8-flash",
        title = "Gemini 3.8 Flash",
        badge = "НОВИНКА • ОСНОВНАЯ",
        description = "Новейшая быстрая модель по умолчанию — высокий интеллект и мгновенный стриминг без биллинга"
    ),
    GEMINI_4_ARGON(
        modelId = "gemini-4-argon",
        title = "Gemini 4 Argon",
        badge = "GEMINI 4 • ПРО",
        description = "Флагманская модель 4-го поколения для сложного анализа, кода и науки (требует план Blaze)"
    ),
    GEMINI_3_5_FLASH_LITE(
        modelId = "gemini-3.5-flash-lite",
        title = "Gemini 3.5 Flash-Lite",
        badge = "ТУРБО • LITE",
        description = "Ультра-быстрая облегчённая модель серии 3.x для моментальных ответов"
    ),
    CUSTOM(
        modelId = "",
        title = "Своя версия (Model ID)",
        badge = "СВОЯ",
        description = "Укажите вручную любой новый или будущий идентификатор модели Gemini"
    )
}

enum class VoicePreset(
    val title: String,
    val description: String,
    val defaultRate: Float,
    val defaultPitch: Float,
    val preferFemale: Boolean?,
    val aiVoiceId: String
) {
    ALISA(
        title = "Алиса (Живой женский)",
        description = "Выразительный мягкий женский голос в стиле Алисы",
        defaultRate = 1.05f,
        defaultPitch = 1.12f,
        preferFemale = true,
        aiVoiceId = "Kore"
    ),
    MAX(
        title = "Макс (Уверенный мужской)",
        description = "Чёткий, спокойный мужской тембр",
        defaultRate = 1.0f,
        defaultPitch = 0.90f,
        preferFemale = false,
        aiVoiceId = "Puck"
    ),
    CYBER(
        title = "Кибер-ядро NEXUS",
        description = "Технологичный глубокий голос ИИ-ассистента",
        defaultRate = 0.98f,
        defaultPitch = 0.84f,
        preferFemale = false,
        aiVoiceId = "Fenrir"
    ),
    ANNOUNCER(
        title = "Студийный диктор",
        description = "Ровная и разборчивая подача для длинных ответов",
        defaultRate = 0.95f,
        defaultPitch = 1.0f,
        preferFemale = null,
        aiVoiceId = "Charon"
    ),
    CUSTOM(
        title = "Свободная настройка",
        description = "Ручной выбор любого голоса устройства, скорости и высоты тона",
        defaultRate = 1.0f,
        defaultPitch = 1.0f,
        preferFemale = null,
        aiVoiceId = "Aoede"
    )
}

