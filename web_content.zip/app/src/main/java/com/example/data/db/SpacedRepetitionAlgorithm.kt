package com.example.data.db

enum class ReviewQuality {
    AGAIN, // Difícil / No me acordé
    GOOD,  // Regular / Me costó
    EASY   // Fácil / Me acordé perfecto
}

data class SrsCalculationResult(
    val nextIntervalMinutes: Long,
    val nextReviewTimestamp: Long,
    val newRepetitionCount: Int,
    val newEaseFactor: Double,
    val timesForgotten: Int,
    val timesRemembered: Int
)

object SpacedRepetitionAlgorithm {

    const val INITIAL_INTERVAL_MINUTES = 15L // Initial review interval required: 15 minutes

    fun calculateInitial(now: Long = System.currentTimeMillis()): Pair<Long, Long> {
        val intervalMinutes = INITIAL_INTERVAL_MINUTES
        val nextReview = now + (intervalMinutes * 60 * 1000L)
        return Pair(intervalMinutes, nextReview)
    }

    fun processReview(
        quality: ReviewQuality,
        currentRepetitions: Int,
        currentIntervalMinutes: Long,
        currentEaseFactor: Double,
        currentForgotten: Int,
        currentRemembered: Int,
        now: Long = System.currentTimeMillis()
    ): SrsCalculationResult {
        return when (quality) {
            ReviewQuality.AGAIN -> {
                // Reset interval back to 15 minutes
                val nextInterval = INITIAL_INTERVAL_MINUTES
                val newEase = maxOf(1.3, currentEaseFactor - 0.2)
                SrsCalculationResult(
                    nextIntervalMinutes = nextInterval,
                    nextReviewTimestamp = now + (nextInterval * 60 * 1000L),
                    newRepetitionCount = 0,
                    newEaseFactor = newEase,
                    timesForgotten = currentForgotten + 1,
                    timesRemembered = currentRemembered
                )
            }
            ReviewQuality.GOOD -> {
                val nextInterval = when (currentRepetitions) {
                    0 -> 60L    // 1 hour
                    1 -> 240L   // 4 hours
                    2 -> 1440L  // 1 day (24h)
                    3 -> 4320L  // 3 days
                    else -> (currentIntervalMinutes * currentEaseFactor).toLong().coerceAtLeast(currentIntervalMinutes + 1440L)
                }
                SrsCalculationResult(
                    nextIntervalMinutes = nextInterval,
                    nextReviewTimestamp = now + (nextInterval * 60 * 1000L),
                    newRepetitionCount = currentRepetitions + 1,
                    newEaseFactor = currentEaseFactor,
                    timesForgotten = currentForgotten,
                    timesRemembered = currentRemembered + 1
                )
            }
            ReviewQuality.EASY -> {
                val nextInterval = when (currentRepetitions) {
                    0 -> 120L   // 2 hours
                    1 -> 720L   // 12 hours
                    2 -> 2880L  // 2 days
                    3 -> 8640L  // 6 days
                    else -> (currentIntervalMinutes * currentEaseFactor * 1.3).toLong().coerceAtLeast(currentIntervalMinutes + 2880L)
                }
                val newEase = minOf(3.0, currentEaseFactor + 0.15)
                SrsCalculationResult(
                    nextIntervalMinutes = nextInterval,
                    nextReviewTimestamp = now + (nextInterval * 60 * 1000L),
                    newRepetitionCount = currentRepetitions + 1,
                    newEaseFactor = newEase,
                    timesForgotten = currentForgotten,
                    timesRemembered = currentRemembered + 1
                )
            }
        }
    }

    fun formatRemainingTime(nextReviewTimestamp: Long, now: Long = System.currentTimeMillis()): String {
        val diffMs = nextReviewTimestamp - now
        if (diffMs <= 0) return "¡Listo para repasar ahora!"

        val diffMinutes = diffMs / (60 * 1000L)
        return when {
            diffMinutes < 60 -> "En $diffMinutes min"
            diffMinutes < 1440 -> {
                val hours = diffMinutes / 60
                val mins = diffMinutes % 60
                if (mins > 0) "En ${hours}h ${mins}m" else "En ${hours}h"
            }
            else -> {
                val days = diffMinutes / 1440
                if (days == 1L) "En 1 día" else "En $days días"
            }
        }
    }
}
