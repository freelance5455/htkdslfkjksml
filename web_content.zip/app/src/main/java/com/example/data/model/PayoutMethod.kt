package com.example.data.model

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties

@IgnoreExtraProperties
data class PayoutMethod(
    @DocumentId val id: String = "",
    val title: String = "",
    val subtitle: String = "",
    val iconType: String = "upi",
    val minCoins: Long = 100L,
    val cashAmount: String = "₹10",
    val currency: String = "₹",
    val inputLabel: String = "Enter UPI ID",
    val inputPlaceholder: String = "yourid@upi",
    val order: Long = 1L,
    val isEnabled: Boolean = true
)
