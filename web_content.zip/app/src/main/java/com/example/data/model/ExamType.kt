package com.example.data.model

enum class ExamType(
  val displayName: String,
  val subtitle: String,
  val daysRemainingDefault: Int,
  val targetNetDefault: Double,
  val description: String
) {
  YKS_TYT(
    displayName = "YKS (TYT)",
    subtitle = "Temel Yeterlilik Testi",
    daysRemainingDefault = 214,
    targetNetDefault = 85.0,
    description = "Türkçe, Temel Matematik, Fen ve Sosyal Bilimler konuları"
  ),
  YKS_AYT(
    displayName = "YKS (AYT)",
    subtitle = "Alan Yeterlilik Testi",
    daysRemainingDefault = 215,
    targetNetDefault = 65.0,
    description = "Edebiyat, İleri Matematik, Fizik, Kimya, Biyoloji, Tarih-Coğrafya"
  ),
  LGS(
    displayName = "LGS",
    subtitle = "Liselere Geçiş Sistemi",
    daysRemainingDefault = 198,
    targetNetDefault = 80.0,
    description = "8. Sınıf müfredatı: Türkçe, Matematik, Fen, İnkılap, Din, İngilizce"
  ),
  KPSS(
    displayName = "KPSS",
    subtitle = "Kamu Personel Seçme",
    daysRemainingDefault = 245,
    targetNetDefault = 90.0,
    description = "Genel Yetenek ve Genel Kültür konuları"
  )
}
