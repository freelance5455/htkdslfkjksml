package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.ContextualMemory
import com.example.data.model.SearchHit
import com.example.data.model.UserProfile
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Date
import java.util.UUID

/**
 * Device-local workspace store used before the user signs in or creates a Google account.
 * Never accesses Firestore while unauthenticated; when the user chooses to sign in later,
 * [migrateToCloudIfAny] moves any guest chats and memories into their Firestore account.
 */
class LocalGuestStore(context: Context) : FlamiWorkspaceRepository {

    private val appContext = context.applicationContext
    private val storeFile = File(appContext.filesDir, "flami_guest_store.json")
    private val mutex = Mutex()

    private data class GuestSnapshot(
        val profile: UserProfile = UserProfile(
            id = GUEST_UID,
            userId = GUEST_UID,
            displayName = "FLAMI Guest",
            preferredLanguage = "auto"
        ),
        val chats: List<ChatSession> = emptyList(),
        val messagesByChat: Map<String, List<ChatMessage>> = emptyMap(),
        val memories: List<ContextualMemory> = emptyList()
    )

    private val state = MutableStateFlow(loadFromDisk())

    override fun observeUserProfile(): Flow<UserProfile?> = state.map { it.profile }

    override suspend fun ensureUserProfile(
        displayName: String,
        defaultLanguage: String
    ): Result<UserProfile> = mutex.withLock {
        val current = state.value.profile
        val updated = if (current.userId.isBlank()) {
            UserProfile(
                id = GUEST_UID,
                userId = GUEST_UID,
                displayName = displayName.ifBlank { "FLAMI Guest" },
                preferredLanguage = defaultLanguage.takeIf { it in FlamiRepository.SUPPORTED_LANG_CODES } ?: "auto"
            )
        } else {
            current
        }
        if (updated != current) {
            updateAndPersist { it.copy(profile = updated) }
        }
        Result.success(updated)
    }

    override suspend fun updateUserPreferences(
        preferredLanguage: String?,
        modelMode: String?,
        ttsEnabled: Boolean?,
        ttsRate: Double?,
        memoryEnabled: Boolean?,
        displayName: String?
    ): Result<Unit> = mutex.withLock {
        updateAndPersist { snap ->
            val p = snap.profile
            snap.copy(
                profile = p.copy(
                    preferredLanguage = preferredLanguage?.takeIf { it in FlamiRepository.SUPPORTED_LANG_CODES } ?: p.preferredLanguage,
                    modelMode = modelMode?.takeIf { it in FlamiRepository.SUPPORTED_MODEL_MODES } ?: p.modelMode,
                    ttsEnabled = ttsEnabled ?: p.ttsEnabled,
                    ttsRate = ttsRate?.coerceIn(0.5, 2.0) ?: p.ttsRate,
                    memoryEnabled = memoryEnabled ?: p.memoryEnabled,
                    displayName = displayName?.trim()?.take(120) ?: p.displayName,
                    updatedAt = nowTimestamp()
                )
            )
        }
        Result.success(Unit)
    }

    override fun observeChats(): Flow<List<ChatSession>> = state.map { snap ->
        snap.chats.sortedWith(
            compareByDescending<ChatSession> { it.isPinned }
                .thenByDescending { it.updatedAt?.seconds ?: 0L }
                .thenByDescending { it.updatedAt?.nanoseconds ?: 0 }
        )
    }

    override suspend fun createChat(title: String, initialPreview: String): Result<String> = mutex.withLock {
        val id = UUID.randomUUID().toString()
        val now = nowTimestamp()
        val session = ChatSession(
            id = id,
            userId = GUEST_UID,
            title = title.trim().take(140).ifBlank { "New Chat" },
            lastMessagePreview = initialPreview.trim().take(400),
            messageCount = 0L,
            isPinned = false,
            createdAt = now,
            updatedAt = now
        )
        updateAndPersist { snap ->
            snap.copy(chats = listOf(session) + snap.chats)
        }
        Result.success(id)
    }

    override suspend fun renameChat(chatId: String, newTitle: String): Result<Unit> = mutex.withLock {
        val safeTitle = newTitle.trim().take(140)
        if (safeTitle.isBlank()) return@withLock Result.failure(IllegalArgumentException("Title blank"))
        val now = nowTimestamp()
        updateAndPersist { snap ->
            snap.copy(
                chats = snap.chats.map {
                    if (it.id == chatId) it.copy(title = safeTitle, updatedAt = now) else it
                }
            )
        }
        Result.success(Unit)
    }

    override suspend fun togglePinChat(chatId: String, pinned: Boolean): Result<Unit> = mutex.withLock {
        val now = nowTimestamp()
        updateAndPersist { snap ->
            snap.copy(
                chats = snap.chats.map {
                    if (it.id == chatId) it.copy(isPinned = pinned, updatedAt = now) else it
                }
            )
        }
        Result.success(Unit)
    }

    override suspend fun deleteChat(chatId: String): Result<Unit> = mutex.withLock {
        updateAndPersist { snap ->
            snap.copy(
                chats = snap.chats.filterNot { it.id == chatId },
                messagesByChat = snap.messagesByChat - chatId
            )
        }
        Result.success(Unit)
    }

    override fun observeMessages(chatId: String): Flow<List<ChatMessage>> =
        state.map { it.messagesByChat[chatId].orEmpty() }

    override suspend fun getMessagesOnce(chatId: String): Result<List<ChatMessage>> =
        Result.success(state.value.messagesByChat[chatId].orEmpty())

    override suspend fun addMessage(
        chatId: String,
        role: String,
        text: String,
        hasImage: Boolean,
        imageNote: String?,
        languageCode: String?,
        isError: Boolean,
        updateChatPreview: Boolean
    ): Result<String> = mutex.withLock {
        val id = UUID.randomUUID().toString()
        val now = nowTimestamp()
        val safeText = text.take(100000)
        val msg = ChatMessage(
            id = id,
            userId = GUEST_UID,
            chatId = chatId,
            role = role,
            text = safeText,
            hasImage = hasImage,
            imageNote = imageNote?.take(250)?.takeIf { it.isNotBlank() },
            languageCode = languageCode?.take(16)?.takeIf { it.isNotBlank() },
            isError = isError,
            createdAt = now,
            updatedAt = now
        )
        updateAndPersist { snap ->
            val currentList = snap.messagesByChat[chatId].orEmpty()
            val newMap = snap.messagesByChat.toMutableMap()
            newMap[chatId] = currentList + msg
            val updatedChats = if (updateChatPreview) {
                val preview = safeText.replace('\n', ' ').trim().take(200)
                snap.chats.map { chat ->
                    if (chat.id == chatId) {
                        chat.copy(
                            lastMessagePreview = preview,
                            messageCount = chat.messageCount + 1L,
                            updatedAt = now
                        )
                    } else chat
                }
            } else snap.chats
            snap.copy(chats = updatedChats, messagesByChat = newMap)
        }
        Result.success(id)
    }

    override suspend fun updateMessage(
        chatId: String,
        messageId: String,
        newText: String,
        isError: Boolean,
        updateChatPreview: Boolean
    ): Result<Unit> = mutex.withLock {
        val now = nowTimestamp()
        val safeText = newText.take(100000)
        updateAndPersist { snap ->
            val currentList = snap.messagesByChat[chatId].orEmpty()
            val updatedList = currentList.map { msg ->
                if (msg.id == messageId) {
                    msg.copy(text = safeText, isError = isError, updatedAt = now)
                } else msg
            }
            val newMap = snap.messagesByChat.toMutableMap()
            newMap[chatId] = updatedList
            val updatedChats = if (updateChatPreview) {
                val preview = safeText.replace('\n', ' ').trim().take(200)
                snap.chats.map { chat ->
                    if (chat.id == chatId) {
                        chat.copy(lastMessagePreview = preview, updatedAt = now)
                    } else chat
                }
            } else snap.chats
            snap.copy(chats = updatedChats, messagesByChat = newMap)
        }
        Result.success(Unit)
    }

    override suspend fun searchMessages(query: String, chats: List<ChatSession>): Result<List<SearchHit>> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return Result.success(emptyList())
        val snap = state.value
        val hits = mutableListOf<SearchHit>()
        for (chat in chats.take(30)) {
            val msgs = snap.messagesByChat[chat.id].orEmpty()
            for (msg in msgs.asReversed()) {
                if (msg.text.lowercase().contains(q) || chat.title.lowercase().contains(q)) {
                    hits.add(SearchHit(chatId = chat.id, chatTitle = chat.title, message = msg))
                }
            }
        }
        return Result.success(hits)
    }

    override fun observeMemories(): Flow<List<ContextualMemory>> = state.map { snap ->
        snap.memories.sortedByDescending { it.updatedAt?.seconds ?: 0L }
    }

    override suspend fun addMemory(
        fact: String,
        category: String,
        sourceChatId: String?
    ): Result<String> = mutex.withLock {
        val safeFact = fact.trim().take(500)
        if (safeFact.isBlank()) return@withLock Result.failure(IllegalArgumentException("Memory fact blank"))
        val safeCat = category.takeIf { it in FlamiRepository.SUPPORTED_MEMORY_CATEGORIES } ?: "general"
        val id = UUID.randomUUID().toString()
        val now = nowTimestamp()
        val mem = ContextualMemory(
            id = id,
            userId = GUEST_UID,
            fact = safeFact,
            category = safeCat,
            isActive = true,
            sourceChatId = sourceChatId?.take(128)?.takeIf { it.isNotBlank() },
            createdAt = now,
            updatedAt = now
        )
        updateAndPersist { snap -> snap.copy(memories = listOf(mem) + snap.memories) }
        Result.success(id)
    }

    override suspend fun updateMemory(memory: ContextualMemory): Result<Unit> = mutex.withLock {
        val now = nowTimestamp()
        updateAndPersist { snap ->
            snap.copy(
                memories = snap.memories.map {
                    if (it.id == memory.id) memory.copy(updatedAt = now) else it
                }
            )
        }
        Result.success(Unit)
    }

    override suspend fun deleteMemory(memoryId: String): Result<Unit> = mutex.withLock {
        updateAndPersist { snap ->
            snap.copy(memories = snap.memories.filterNot { it.id == memoryId })
        }
        Result.success(Unit)
    }

    /**
     * Migrates local guest chats, messages, and contextual memories into Cloud Firestore once
     * the user signs in or creates an account, then clears the local guest store.
     */
    suspend fun migrateToCloudIfAny(cloudRepo: FlamiRepository) = withContext(Dispatchers.IO) {
        val snap = mutex.withLock { state.value }
        if (snap.chats.isEmpty() && snap.memories.isEmpty()) return@withContext

        try {
            cloudRepo.updateUserPreferences(
                preferredLanguage = snap.profile.preferredLanguage,
                modelMode = snap.profile.modelMode,
                ttsEnabled = snap.profile.ttsEnabled,
                ttsRate = snap.profile.ttsRate,
                memoryEnabled = snap.profile.memoryEnabled
            )

            val chatIdMap = mutableMapOf<String, String>()
            for (chat in snap.chats.asReversed()) {
                val createdId = cloudRepo.createChat(chat.title, chat.lastMessagePreview).getOrNull()
                if (!createdId.isNullOrBlank()) {
                    chatIdMap[chat.id] = createdId
                    if (chat.isPinned) {
                        cloudRepo.togglePinChat(createdId, true)
                    }
                    val msgs = snap.messagesByChat[chat.id].orEmpty()
                    for (msg in msgs) {
                        cloudRepo.addMessage(
                            chatId = createdId,
                            role = msg.role,
                            text = msg.text,
                            hasImage = msg.hasImage,
                            imageNote = msg.imageNote,
                            languageCode = msg.languageCode,
                            isError = msg.isError,
                            updateChatPreview = true
                        )
                    }
                }
            }

            for (mem in snap.memories) {
                val mappedSource = mem.sourceChatId?.let { chatIdMap[it] }
                cloudRepo.addMemory(
                    fact = mem.fact,
                    category = mem.category,
                    sourceChatId = mappedSource
                )
            }

            mutex.withLock {
                state.value = GuestSnapshot()
                if (storeFile.exists()) storeFile.delete()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Guest-to-cloud migration deferred: ${e.message}")
        }
    }

    private suspend fun updateAndPersist(transform: (GuestSnapshot) -> GuestSnapshot) {
        val next = transform(state.value)
        state.value = next
        withContext(Dispatchers.IO) {
            saveToDisk(next)
        }
    }

    private fun saveToDisk(snap: GuestSnapshot) {
        try {
            val root = JSONObject()
            val pObj = JSONObject().apply {
                put("preferredLanguage", snap.profile.preferredLanguage)
                put("modelMode", snap.profile.modelMode)
                put("ttsEnabled", snap.profile.ttsEnabled)
                put("ttsRate", snap.profile.ttsRate)
                put("memoryEnabled", snap.profile.memoryEnabled)
            }
            root.put("profile", pObj)

            val chatsArr = JSONArray()
            for (chat in snap.chats) {
                chatsArr.put(
                    JSONObject().apply {
                        put("id", chat.id)
                        put("title", chat.title)
                        put("lastMessagePreview", chat.lastMessagePreview)
                        put("messageCount", chat.messageCount)
                        put("isPinned", chat.isPinned)
                        put("createdAtMs", (chat.createdAt?.seconds ?: 0L) * 1000L)
                        put("updatedAtMs", (chat.updatedAt?.seconds ?: 0L) * 1000L)
                    }
                )
            }
            root.put("chats", chatsArr)

            val msgsObj = JSONObject()
            for ((chatId, msgs) in snap.messagesByChat) {
                val arr = JSONArray()
                for (m in msgs) {
                    arr.put(
                        JSONObject().apply {
                            put("id", m.id)
                            put("role", m.role)
                            put("text", m.text)
                            put("hasImage", m.hasImage)
                            put("imageNote", m.imageNote ?: JSONObject.NULL)
                            put("languageCode", m.languageCode ?: JSONObject.NULL)
                            put("isError", m.isError)
                            put("createdAtMs", (m.createdAt?.seconds ?: 0L) * 1000L)
                        }
                    )
                }
                msgsObj.put(chatId, arr)
            }
            root.put("messagesByChat", msgsObj)

            val memArr = JSONArray()
            for (mem in snap.memories) {
                memArr.put(
                    JSONObject().apply {
                        put("id", mem.id)
                        put("fact", mem.fact)
                        put("category", mem.category)
                        put("isActive", mem.isActive)
                        put("sourceChatId", mem.sourceChatId ?: JSONObject.NULL)
                        put("updatedAtMs", (mem.updatedAt?.seconds ?: 0L) * 1000L)
                    }
                )
            }
            root.put("memories", memArr)

            storeFile.writeText(root.toString())
        } catch (e: Exception) {
            Log.w(TAG, "Failed to save guest store: ${e.message}")
        }
    }

    private fun loadFromDisk(): GuestSnapshot {
        if (!storeFile.exists()) return GuestSnapshot()
        return try {
            val root = JSONObject(storeFile.readText())
            val pObj = root.optJSONObject("profile")
            val profile = UserProfile(
                id = GUEST_UID,
                userId = GUEST_UID,
                displayName = "FLAMI Guest",
                preferredLanguage = pObj?.optString("preferredLanguage", "auto") ?: "auto",
                modelMode = pObj?.optString("modelMode", "balanced") ?: "balanced",
                ttsEnabled = pObj?.optBoolean("ttsEnabled", true) ?: true,
                ttsRate = pObj?.optDouble("ttsRate", 1.0) ?: 1.0,
                memoryEnabled = pObj?.optBoolean("memoryEnabled", true) ?: true
            )

            val chats = mutableListOf<ChatSession>()
            val chatsArr = root.optJSONArray("chats") ?: JSONArray()
            for (i in 0 until chatsArr.length()) {
                val c = chatsArr.getJSONObject(i)
                chats.add(
                    ChatSession(
                        id = c.getString("id"),
                        userId = GUEST_UID,
                        title = c.optString("title", "New Chat"),
                        lastMessagePreview = c.optString("lastMessagePreview", ""),
                        messageCount = c.optLong("messageCount", 0L),
                        isPinned = c.optBoolean("isPinned", false),
                        createdAt = msToTimestamp(c.optLong("createdAtMs", 0L)),
                        updatedAt = msToTimestamp(c.optLong("updatedAtMs", 0L))
                    )
                )
            }

            val messagesMap = mutableMapOf<String, List<ChatMessage>>()
            val msgsObj = root.optJSONObject("messagesByChat") ?: JSONObject()
            val keys = msgsObj.keys()
            while (keys.hasNext()) {
                val chatId = keys.next()
                val arr = msgsObj.optJSONArray(chatId) ?: continue
                val list = mutableListOf<ChatMessage>()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    list.add(
                        ChatMessage(
                            id = m.getString("id"),
                            userId = GUEST_UID,
                            chatId = chatId,
                            role = m.optString("role", "user"),
                            text = m.optString("text", ""),
                            hasImage = m.optBoolean("hasImage", false),
                            imageNote = m.optString("imageNote").takeIf { it.isNotBlank() && it != "null" },
                            languageCode = m.optString("languageCode").takeIf { it.isNotBlank() && it != "null" },
                            isError = m.optBoolean("isError", false),
                            createdAt = msToTimestamp(m.optLong("createdAtMs", 0L))
                        )
                    )
                }
                messagesMap[chatId] = list
            }

            val memories = mutableListOf<ContextualMemory>()
            val memArr = root.optJSONArray("memories") ?: JSONArray()
            for (i in 0 until memArr.length()) {
                val mem = memArr.getJSONObject(i)
                memories.add(
                    ContextualMemory(
                        id = mem.getString("id"),
                        userId = GUEST_UID,
                        fact = mem.optString("fact", ""),
                        category = mem.optString("category", "general"),
                        isActive = mem.optBoolean("isActive", true),
                        sourceChatId = mem.optString("sourceChatId").takeIf { it.isNotBlank() && it != "null" },
                        updatedAt = msToTimestamp(mem.optLong("updatedAtMs", 0L))
                    )
                )
            }

            GuestSnapshot(
                profile = profile,
                chats = chats,
                messagesByChat = messagesMap,
                memories = memories
            )
        } catch (e: Exception) {
            Log.w(TAG, "Failed to load guest store: ${e.message}")
            GuestSnapshot()
        }
    }

    private fun nowTimestamp(): Timestamp = Timestamp(Date())

    private fun msToTimestamp(ms: Long): Timestamp? =
        if (ms > 0L) Timestamp(Date(ms)) else null

    companion object {
        const val GUEST_UID = "guest_local"
        private const val TAG = "LocalGuestStore"
    }
}
