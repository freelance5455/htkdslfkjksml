package com.example.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class ImportedThemeMedia(
    val filePath: String,
    val isVideo: Boolean
)

object ThemeMediaStorage {

    suspend fun copyPickedMediaToAppStorage(
        context: Context,
        uri: Uri
    ): ImportedThemeMedia? = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            val mimeType = resolver.getType(uri).orEmpty().lowercase()
            val isVideo = mimeType.startsWith("video/")
            val ext = when {
                mimeType.contains("mp4") -> "mp4"
                mimeType.contains("webm") -> "webm"
                mimeType.contains("png") -> "png"
                mimeType.contains("webp") -> "webp"
                isVideo -> "mp4"
                else -> "jpg"
            }

            val dir = File(context.filesDir, "custom_themes").apply { mkdirs() }
            val outFile = File(dir, "theme_${UUID.randomUUID()}.$ext")
            resolver.openInputStream(uri)?.use { input ->
                outFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null

            if (!outFile.exists() || outFile.length() == 0L) return@withContext null
            ImportedThemeMedia(filePath = outFile.absolutePath, isVideo = isVideo)
        } catch (_: Exception) {
            null
        }
    }
}
