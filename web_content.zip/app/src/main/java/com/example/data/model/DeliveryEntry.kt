package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "delivery_entries")
data class DeliveryEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String, // "yyyy-MM-dd" e.g. "2026-09-11"
    val deliveriesCount: Int, // e.g. 50
    val ratePerDelivery: Double, // e.g. 18.0
    val totalEarnings: Double = deliveriesCount * ratePerDelivery, // e.g. 900.0
    val cycleNumber: Int, // 1 (1-10), 2 (11-20), 3 (21-end)
    val monthKey: String, // "yyyy-MM" e.g. "2026-09"
    val dayOfMonth: Int, // 1..31
    val notes: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val locationTag: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
