package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.db.AppDatabase
import com.example.data.db.InformationRecord
import com.example.data.db.PdfDocumentRecord
import com.example.data.db.VaultFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class VaultRepository(private val context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val infoDao = db.informationDao()
    private val fileDao = db.vaultFileDao()
    private val pdfDao = db.pdfDao()

    // ------------------------------------------------------------------------
    // Information Records
    // ------------------------------------------------------------------------
    val records: Flow<List<InformationRecord>> = infoDao.getAllRecords()

    val nextTransactionNumber: Flow<Long> = infoDao.observeMaxTransactionNumber().map { max ->
        max + 1
    }

    suspend fun getNextTransactionNumber(): Long = withContext(Dispatchers.IO) {
        infoDao.getMaxTransactionNumber() + 1
    }

    suspend fun saveInformationRecord(
        name: String,
        age: String,
        place: String,
        address: String,
        phone1: String,
        phone2: String,
        emailPrefix: String
    ): InformationRecord = withContext(Dispatchers.IO) {
        val nextTx = infoDao.getMaxTransactionNumber() + 1
        val cleanEmail = if (emailPrefix.contains("@")) {
            emailPrefix.trim()
        } else {
            "${emailPrefix.trim()}@gmail.com"
        }

        val record = InformationRecord(
            transactionNumber = nextTx,
            name = name.trim(),
            age = age.trim(),
            place = place.trim(),
            address = address.trim(),
            phone1 = phone1.trim(),
            phone2 = phone2.trim(),
            email = cleanEmail
        )
        val id = infoDao.insertRecord(record)
        record.copy(id = id)
    }

    suspend fun updateInformationRecord(record: InformationRecord) = withContext(Dispatchers.IO) {
        infoDao.updateRecord(record)
    }

    suspend fun deleteInformationRecord(record: InformationRecord) = withContext(Dispatchers.IO) {
        infoDao.deleteRecord(record)
    }

    // ------------------------------------------------------------------------
    // Vault Files
    // ------------------------------------------------------------------------
    fun getFilesByCategory(category: String): Flow<List<VaultFile>> =
        fileDao.getFilesByCategory(category)

    fun getAllFiles(): Flow<List<VaultFile>> = fileDao.getAllFiles()

    suspend fun importFile(uri: Uri, category: String): VaultFile = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        var originalName = "file_${System.currentTimeMillis()}"
        var sizeBytes = 0L

        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) originalName = cursor.getString(nameIndex) ?: originalName
                if (sizeIndex != -1) sizeBytes = cursor.getLong(sizeIndex)
            }
        }

        val mimeType = contentResolver.getType(uri) ?: "application/octet-stream"

        val sanitizedCategory = category.replace("[^a-zA-Z0-9]".toRegex(), "_")
        val categoryDir = File(context.filesDir, "vault_files/$sanitizedCategory")
        if (!categoryDir.exists()) {
            categoryDir.mkdirs()
        }

        val extension = originalName.substringAfterLast('.', "")
        val baseName = originalName.substringBeforeLast('.')
        var targetFile = File(categoryDir, originalName)
        var count = 1
        while (targetFile.exists()) {
            val suffix = if (extension.isNotEmpty()) ".$extension" else ""
            targetFile = File(categoryDir, "${baseName}_$count$suffix")
            count++
        }

        contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(targetFile).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalStateException("Could not open input stream for $uri")

        val actualSize = if (sizeBytes > 0) sizeBytes else targetFile.length()

        val vaultFile = VaultFile(
            fileName = targetFile.name,
            category = category,
            filePath = targetFile.absolutePath,
            mimeType = mimeType,
            sizeBytes = actualSize
        )
        val id = fileDao.insertFile(vaultFile)
        vaultFile.copy(id = id)
    }

    suspend fun renameVaultFile(file: VaultFile, newName: String): VaultFile = withContext(Dispatchers.IO) {
        val currentFile = File(file.filePath)
        val dir = currentFile.parentFile ?: context.filesDir
        val extension = currentFile.extension
        val cleanName = if (extension.isNotEmpty() && !newName.endsWith(".$extension")) {
            "$newName.$extension"
        } else {
            newName
        }
        val destination = File(dir, cleanName)
        if (currentFile.exists()) {
            currentFile.renameTo(destination)
        }
        val updated = file.copy(
            fileName = cleanName,
            filePath = destination.absolutePath
        )
        fileDao.updateFile(updated)
        updated
    }

    suspend fun deleteVaultFile(file: VaultFile) = withContext(Dispatchers.IO) {
        val diskFile = File(file.filePath)
        if (diskFile.exists()) {
            diskFile.delete()
        }
        fileDao.deleteFile(file)
    }

    // ------------------------------------------------------------------------
    // PDFs
    // ------------------------------------------------------------------------
    val allPdfs: Flow<List<PdfDocumentRecord>> = pdfDao.getAllPdfs()

    suspend fun registerPdf(title: String, file: File, pageCount: Int): PdfDocumentRecord =
        withContext(Dispatchers.IO) {
            val record = PdfDocumentRecord(
                title = title,
                fileName = file.name,
                filePath = file.absolutePath,
                pageCount = pageCount,
                sizeBytes = file.length()
            )
            val id = pdfDao.insertPdf(record)
            record.copy(id = id)
        }

    suspend fun deletePdf(pdf: PdfDocumentRecord) = withContext(Dispatchers.IO) {
        val file = File(pdf.filePath)
        if (file.exists()) {
            file.delete()
        }
        pdfDao.deletePdf(pdf)
    }
}
