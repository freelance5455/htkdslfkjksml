package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.FollowEdge
import com.example.data.model.FollowRequest
import com.example.data.model.RestrictedUser
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FollowRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing follow graph.")

    fun observeFollowers(userId: String): Flow<List<FollowEdge>> = flow {
        val path = "users/$userId/followers"
        emitAll(
            db.collection("users").document(userId).collection("followers")
                .snapshots()
                .map { snap ->
                    snap.toObjects(FollowEdge::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.peerUsername }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    emit(emptyList())
                }
        )
    }

    fun observeFollowing(userId: String): Flow<List<FollowEdge>> = flow {
        val path = "users/$userId/following"
        emitAll(
            db.collection("users").document(userId).collection("following")
                .snapshots()
                .map { snap ->
                    snap.toObjects(FollowEdge::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.peerUsername }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    emit(emptyList())
                }
        )
    }

    suspend fun fetchFollowersOnce(userId: String): List<FollowEdge> = runCatching {
        db.collection("users").document(userId).collection("followers")
            .limit(100)
            .get()
            .await()
            .toObjects(FollowEdge::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedBy { it.peerUsername }
    }.getOrDefault(emptyList())

    suspend fun fetchFollowingOnce(userId: String): List<FollowEdge> = runCatching {
        db.collection("users").document(userId).collection("following")
            .limit(100)
            .get()
            .await()
            .toObjects(FollowEdge::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedBy { it.peerUsername }
    }.getOrDefault(emptyList())

    fun observeIncomingFollowRequests(userId: String): Flow<List<FollowRequest>> = flow {
        val path = "followRequests"
        emitAll(
            db.collection("followRequests")
                .whereEqualTo("toUid", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FollowRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .filter { it.status == "pending" }
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeOutgoingFollowRequests(userId: String): Flow<List<FollowRequest>> = flow {
        val path = "followRequests"
        emitAll(
            db.collection("followRequests")
                .whereEqualTo("fromUid", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(FollowRequest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .filter { it.status == "pending" }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeRestrictedUsers(userId: String): Flow<List<RestrictedUser>> = flow {
        val path = "users/$userId/restricted"
        emitAll(
            db.collection("users").document(userId).collection("restricted")
                .snapshots()
                .map { snap -> snap.toObjects(RestrictedUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    /**
     * Returns "following" if immediate follow succeeded (public account) or "requested" (private account).
     */
    suspend fun followOrRequestUser(
        currentUser: UserProfile,
        targetUser: UserProfile
    ): Result<String> = runCatching {
        val uid = requireUserId()
        require(uid == currentUser.userId)
        require(targetUser.userId != uid) { "You cannot follow yourself." }

        val myBlockedRef = db.collection("users").document(uid).collection("blocked").document(targetUser.userId)
        if (myBlockedRef.get().await().exists()) {
            throw IllegalStateException("Unblock @${targetUser.username} before following.")
        }

        val myFollowingRef = db.collection("users").document(uid).collection("following").document(targetUser.userId)
        if (myFollowingRef.get().await().exists()) {
            return@runCatching "following"
        }

        val safeMyUsername = currentUser.username.trim().take(30).ifBlank { "player" }
        val safeMyFullName = currentUser.fullName.trim().take(40)
        val safeMyAvatar = currentUser.avatarPreset.trim().take(40).ifBlank { "prism_cyan" }
        val safeTargetUsername = targetUser.username.trim().take(30).ifBlank { "player" }
        val safeTargetFullName = targetUser.fullName.trim().take(40)
        val safeTargetAvatar = targetUser.avatarPreset.trim().take(40).ifBlank { "prism_cyan" }

        val reqId = "${uid}_${targetUser.userId}"
        val reqRef = db.collection("followRequests").document(reqId)

        if (!targetUser.isPrivateAccount) {
            val targetFollowerRef = db.collection("users").document(targetUser.userId).collection("followers").document(uid)
            val myUserRef = db.collection("users").document(uid)
            val targetUserRef = db.collection("users").document(targetUser.userId)
            val existingTargetSnap = targetUserRef.get().await()
            val existingMySnap = myUserRef.get().await()
            val targetFollowersCount = (existingTargetSnap.getLong("followersCount") ?: 0L).coerceAtLeast(0L)
            val myFollowingCount = (existingMySnap.getLong("followingCount") ?: 0L).coerceAtLeast(0L)

            val batch = db.batch()
            batch.set(
                targetFollowerRef,
                mapOf(
                    "userId" to targetUser.userId,
                    "peerUid" to uid,
                    "peerUsername" to safeMyUsername,
                    "peerFullName" to safeMyFullName,
                    "peerAvatar" to safeMyAvatar,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                myFollowingRef,
                mapOf(
                    "userId" to uid,
                    "peerUid" to targetUser.userId,
                    "peerUsername" to safeTargetUsername,
                    "peerFullName" to safeTargetFullName,
                    "peerAvatar" to safeTargetAvatar,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                targetUserRef,
                mapOf(
                    "followersCount" to targetFollowersCount + 1L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                myUserRef,
                mapOf(
                    "followingCount" to myFollowingCount + 1L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            try {
                batch.commit().await()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, targetFollowerRef.path)
                throw e
            }
            "following"
        } else {
            val existingSnap = reqRef.get().await()
            if (existingSnap.exists()) {
                when (existingSnap.getString("status")) {
                    "pending" -> return@runCatching "requested"
                    else -> {
                        reqRef.update(
                            mapOf(
                                "status" to "pending",
                                "fromUsername" to safeMyUsername,
                                "fromFullName" to safeMyFullName,
                                "fromAvatar" to safeMyAvatar,
                                "toUsername" to safeTargetUsername,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                        return@runCatching "requested"
                    }
                }
            }
            reqRef.set(
                mapOf(
                    "fromUid" to uid,
                    "fromUsername" to safeMyUsername,
                    "fromFullName" to safeMyFullName,
                    "fromAvatar" to safeMyAvatar,
                    "toUid" to targetUser.userId,
                    "toUsername" to safeTargetUsername,
                    "status" to "pending",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            "requested"
        }
    }

    suspend fun acceptFollowRequest(request: FollowRequest, currentUser: UserProfile): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(uid == request.toUid)
        val reqRef = db.collection("followRequests").document(request.id)
        val myFollowerRef = db.collection("users").document(uid).collection("followers").document(request.fromUid)
        val theirFollowingRef = db.collection("users").document(request.fromUid).collection("following").document(uid)
        val myUserRef = db.collection("users").document(uid)
        val theirUserRef = db.collection("users").document(request.fromUid)

        val followerAlready = myFollowerRef.get().await().exists()
        val followingAlready = theirFollowingRef.get().await().exists()
        val mySnap = myUserRef.get().await()
        val theirSnap = theirUserRef.get().await()
        val currentFollowers = (mySnap.getLong("followersCount") ?: 0L).coerceAtLeast(0L)
        val currentTheirFollowing = (theirSnap.getLong("followingCount") ?: 0L).coerceAtLeast(0L)

        val batch = db.batch()
        batch.update(reqRef, mapOf("status" to "accepted", "updatedAt" to FieldValue.serverTimestamp()))
        if (!followerAlready) {
            batch.set(
                myFollowerRef,
                mapOf(
                    "userId" to uid,
                    "peerUid" to request.fromUid,
                    "peerUsername" to request.fromUsername.take(30).ifBlank { "player" },
                    "peerFullName" to request.fromFullName.take(40),
                    "peerAvatar" to request.fromAvatar.take(40).ifBlank { "prism_cyan" },
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                myUserRef,
                mapOf(
                    "followersCount" to currentFollowers + 1L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        if (!followingAlready) {
            batch.set(
                theirFollowingRef,
                mapOf(
                    "userId" to request.fromUid,
                    "peerUid" to uid,
                    "peerUsername" to currentUser.username.take(30).ifBlank { "player" },
                    "peerFullName" to currentUser.fullName.take(40),
                    "peerAvatar" to currentUser.avatarPreset.take(40).ifBlank { "prism_cyan" },
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                theirUserRef,
                mapOf(
                    "followingCount" to currentTheirFollowing + 1L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
        }
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, reqRef.path)
            throw e
        }
    }

    suspend fun rejectFollowRequest(requestId: String): Result<Unit> = runCatching {
        requireUserId()
        val reqRef = db.collection("followRequests").document(requestId)
        reqRef.update(mapOf("status" to "rejected", "updatedAt" to FieldValue.serverTimestamp())).await()
    }

    suspend fun cancelFollowRequest(requestId: String): Result<Unit> = runCatching {
        requireUserId()
        val reqRef = db.collection("followRequests").document(requestId)
        reqRef.update(mapOf("status" to "cancelled", "updatedAt" to FieldValue.serverTimestamp())).await()
    }

    suspend fun unfollowUser(targetUid: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val myFollowingRef = db.collection("users").document(uid).collection("following").document(targetUid)
        val targetFollowerRef = db.collection("users").document(targetUid).collection("followers").document(uid)
        val myUserRef = db.collection("users").document(uid)
        val targetUserRef = db.collection("users").document(targetUid)

        val followingExists = myFollowingRef.get().await().exists()
        val followerExists = targetFollowerRef.get().await().exists()
        val myFollowingCount = (myUserRef.get().await().getLong("followingCount") ?: 0L).coerceAtLeast(0L)
        val targetFollowersCount = (targetUserRef.get().await().getLong("followersCount") ?: 0L).coerceAtLeast(0L)

        val batch = db.batch()
        if (followingExists) {
            batch.delete(myFollowingRef)
            if (myFollowingCount > 0L) {
                batch.update(
                    myUserRef,
                    mapOf(
                        "followingCount" to myFollowingCount - 1L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }
        if (followerExists) {
            batch.delete(targetFollowerRef)
            if (targetFollowersCount > 0L) {
                batch.update(
                    targetUserRef,
                    mapOf(
                        "followersCount" to targetFollowersCount - 1L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }
        batch.commit().await()
    }

    suspend fun removeFollower(followerUid: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val myFollowerRef = db.collection("users").document(uid).collection("followers").document(followerUid)
        val theirFollowingRef = db.collection("users").document(followerUid).collection("following").document(uid)
        val myUserRef = db.collection("users").document(uid)
        val theirUserRef = db.collection("users").document(followerUid)

        val myFollowerExists = myFollowerRef.get().await().exists()
        val theirFollowingExists = theirFollowingRef.get().await().exists()
        val myFollowersCount = (myUserRef.get().await().getLong("followersCount") ?: 0L).coerceAtLeast(0L)
        val theirFollowingCount = (theirUserRef.get().await().getLong("followingCount") ?: 0L).coerceAtLeast(0L)

        val batch = db.batch()
        if (myFollowerExists) {
            batch.delete(myFollowerRef)
            if (myFollowersCount > 0L) {
                batch.update(
                    myUserRef,
                    mapOf(
                        "followersCount" to myFollowersCount - 1L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }
        if (theirFollowingExists) {
            batch.delete(theirFollowingRef)
            if (theirFollowingCount > 0L) {
                batch.update(
                    theirUserRef,
                    mapOf(
                        "followingCount" to theirFollowingCount - 1L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
        }
        batch.commit().await()
    }

    suspend fun restrictUser(targetUid: String, targetUsername: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val ref = db.collection("users").document(uid).collection("restricted").document(targetUid)
        ref.set(
            mapOf(
                "userId" to uid,
                "restrictedUid" to targetUid,
                "restrictedUsername" to targetUsername.take(30),
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun unrestrictUser(targetUid: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        db.collection("users").document(uid).collection("restricted").document(targetUid).delete().await()
    }
}
