package com.example.data.model

enum class ServerState(val displayName: String) {
  OFFLINE("Apagado"),
  ONLINE("En Línea"),
  STARTING("Iniciando"),
  STOPPING("Deteniendo"),
  RESTARTING("Reiniciando"),
  UNKNOWN("Desconocido")
}

data class ServerStatusData(
  val state: ServerState = ServerState.OFFLINE,
  val tps: Double = 20.0,
  val ramUsedMb: Int = 0,
  val ramMaxMb: Int = 4096,
  val cpuPercent: Int = 0,
  val onlinePlayers: Int = 0,
  val maxPlayers: Int = 20,
  val playerNames: List<String> = emptyList(),
  val motd: String = "Servidor Oficial CHAUFALAND",
  val serverType: String = "exaroton",
  val serverHost: String = ""
)

data class VoiceChannel(
  val id: String,
  val name: String,
  val icon: String = "🔊"
)

data class VoiceUser(
  val gamerTag: String,
  val channelId: String,
  val isMuted: Boolean = false,
  val isSpeaking: Boolean = false
)

data class BedrockPlayer(
  val gamerTag: String,
  val x: Double,
  val y: Double,
  val z: Double,
  val dimension: String = "overworld", // overworld, nether, the_end
  val health: Int = 20
)

data class AdminConfig(
  val serverType: String = "exaroton", // "exaroton" | "aternos"
  val exarotonToken: String = "",
  val exarotonServerId: String = "",
  val secondaryServerIp: String = "chaufaland.aternos.me:19132",
  val isSecondaryBedrock: Boolean = true,
  val wsBridgeUrl: String = "ws://10.0.2.2:3000/ws/minecraft"
)
