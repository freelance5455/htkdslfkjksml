package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class UserRole(val label: String, val hindiLabel: String) {
    STUDENT("Student", "विद्यार्थी"),
    TEACHER("Teacher", "शिक्षक / फैकल्टी"),
    ADMIN("Administrator", "महाविद्यालय प्रशासक")
}

data class CurrentUserSession(
    val userId: String = "",
    val role: UserRole = UserRole.STUDENT,
    val name: String = "Guest Student",
    val phone: String = "+91 98765 43210",
    val email: String = "student@gnmtc-sgnr.edu.in",
    val batch: String = "Batch 2024-25"
)

@IgnoreExtraProperties
data class Teacher(
    @DocumentId val id: String = "",
    val name: String = "",
    val photoUrl: String = "",
    val phone: String = "",
    val designation: String = "",
    val qualifications: String = "",
    val experienceYears: Int = 0,
    val department: String = "",
    val email: String = "",
    val bio: String = "",
    val isActive: Boolean = true,
    val isClinicalDuty: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class StudentPublic(
    @DocumentId val id: String = "",
    val rollNo: String = "",
    val name: String = "",
    val batch: String = "",
    val joiningDate: String = "",
    val dob: String = "",
    val address: String = "",
    val photoUrl: String = "",
    val isActive: Boolean = true
)

@IgnoreExtraProperties
data class StudentPrivate(
    @DocumentId val studentId: String = "",
    val studentMobile: String = "",
    val parentMobile: String = "",
    val bankAccount: String = "",
    val ifsc: String = "",
    val bankBranch: String = "",
    val aadhaar: String = "",
    val janAadhaar: String = "",
    val pan: String = ""
)

@IgnoreExtraProperties
data class BatchCoordinator(
    @DocumentId val batchId: String = "",
    val name: String = "",
    val photoUrl: String = "",
    val phone: String = "",
    val designation: String = "",
    val qualifications: String = "",
    val experience: String = "",
    val department: String = "",
    val email: String = ""
)

@IgnoreExtraProperties
data class Subject(
    @DocumentId val id: String = "",
    val batchId: String = "",
    val code: String = "",
    val name: String = "",
    val description: String = "",
    val assignedTeacherId: String = "",
    val assignedTeacherName: String = ""
)

@IgnoreExtraProperties
data class SyllabusLecture(
    @DocumentId val id: String = "",
    val subjectId: String = "",
    val batchId: String = "",
    val topic: String = "",
    val date: String = "",
    val startTime: String = "",
    val durationMinutes: Int = 60,
    val notes: String = "",
    val teacherId: String = "",
    val teacherName: String = "",
    val isCompleted: Boolean = false
)

@IgnoreExtraProperties
data class AttendanceRecord(
    @DocumentId val id: String = "",
    val batchId: String = "",
    val subjectId: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val date: String = "",
    val status: String = "PRESENT", // PRESENT, ABSENT, LEAVE
    val markedBy: String = ""
)

data class AttendanceSummary(
    val studentId: String,
    val studentName: String,
    val totalClasses: Int,
    val presentCount: Int,
    val absentCount: Int,
    val percentage: Float
)

@IgnoreExtraProperties
data class Complaint(
    @DocumentId val id: String = "",
    val trackingCode: String = "",
    val studentName: String = "",
    val mobileNumber: String = "",
    val batch: String = "",
    val description: String = "",
    val attachmentUrl: String = "",
    val status: String = "Received", // Received, Under Review, In Progress, Resolved, Rejected
    val resolutionNote: String = "",
    val createdAtDate: String = "",
    val updatedAtDate: String = ""
)

@IgnoreExtraProperties
data class Notice(
    @DocumentId val id: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "General", // Academic, Clinical, Exams, Events, General
    val publicationDate: String = "",
    val expiryDate: String = "",
    val attachmentUrl: String = "",
    val isPinned: Boolean = false,
    val isPublished: Boolean = true
)

@IgnoreExtraProperties
data class Holiday(
    @DocumentId val id: String = "",
    val name: String = "",
    val startDate: String = "",
    val endDate: String = "",
    val category: String = "Gazetted", // Gazetted, Restricted, Academic Break
    val description: String = ""
)

@IgnoreExtraProperties
data class ClinicalRoster(
    @DocumentId val id: String = "",
    val batchId: String = "",
    val title: String = "",
    val imageUrl: String = "",
    val hospitalLocation: String = "",
    val effectiveDate: String = "",
    val publishedDate: String = "",
    val updatedBy: String = ""
)

@IgnoreExtraProperties
data class ClinicalDutyAttendance(
    @DocumentId val id: String = "",
    val batchId: String = "",
    val studentId: String = "",
    val studentName: String = "",
    val date: String = "",
    val hospitalLocation: String = "District Hospital SGNR",
    val status: String = "PRESENT", // PRESENT, ABSENT
    val markedBy: String = ""
)
