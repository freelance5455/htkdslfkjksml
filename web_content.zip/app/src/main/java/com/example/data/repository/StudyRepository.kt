package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.local.LessonEntity
import com.example.data.local.PreferencesManager
import com.example.data.local.TaskEntity
import com.example.data.local.TrackEntity
import com.example.data.local.TrackLessonEntity
import com.example.data.local.TrackWithLessons
import com.example.data.model.FocusStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

class StudyRepository(
    private val db: AppDatabase,
    private val prefs: PreferencesManager
) {
    private val lessonDao = db.lessonDao()
    private val trackDao = db.trackDao()
    private val taskDao = db.taskDao()

    val lessons: Flow<List<LessonEntity>> = lessonDao.observeAll()

    val tracks: Flow<List<TrackWithLessons>> = trackDao.observeTracksWithLessons().map { list ->
        list.map { item ->
            item.copy(lessons = item.lessons.sortedBy { it.sortOrder })
        }
    }

    val tasks: Flow<List<TaskEntity>> = taskDao.observeAll()
    val isDarkTheme: Flow<Boolean> = prefs.isDarkTheme
    val examDate: Flow<String> = prefs.examDate
    val focusStats: Flow<FocusStats> = prefs.focusStats

    suspend fun seedInitialDataIfNeeded() {
        if (prefs.isSeeded()) return
        db.withTransaction {
            if (lessonDao.getAllSnapshot().isEmpty() &&
                trackDao.getTracksWithLessonsSnapshot().isEmpty() &&
                taskDao.getAllSnapshot().isEmpty()
            ) {
                lessonDao.upsertAll(
                    listOf(
                        LessonEntity("1", "فيزياء", "السبت", "center", "أ/ محمد عبد المعبود", "16:00", "سنتر الأمل", "#4f46e5", false),
                        LessonEntity("2", "كيمياء", "الأحد", "online", "أ/ سامح إبراهيم", "17:30", "أونلاين", "#059669", false),
                        LessonEntity("3", "لغة عربية", "الإثنين", "center", "أ/ رضا الفاروق", "15:00", "سنتر النجاح", "#d97706", false)
                    )
                )
                trackDao.upsertTracks(
                    listOf(
                        TrackEntity("t1", "الفيزياء - الفيزياء الكهربية", "أ/ محمد عبد المعبود", "#4f46e5", 0),
                        TrackEntity("t2", "اللغة العربية - النحو والبلاغة", "أ/ رضا الفاروق", "#10b981", 1)
                    )
                )
                trackDao.upsertTrackLessons(
                    listOf(
                        TrackLessonEntity("l1", "t1", "الدرس الأول: التيار الكهربي وقانون أوم", "تم الشرح + حل كتاب الامتحان", true, 0),
                        TrackLessonEntity("l2", "t1", "الدرس الثاني: قانونا كيرشوف", "تطبيق المسائل", true, 1),
                        TrackLessonEntity("l3", "t1", "الدرس الثالث: المجال المغناطيسي", "مراجعة القوانين", false, 2),
                        TrackLessonEntity("l21", "t2", "الوحدة الأولى: الألف والهمزات", "تم الإتقان", true, 0),
                        TrackLessonEntity("l22", "t2", "الوحدة الثانية: المشتقات وإعمالها", "حل 100 سؤال", false, 1)
                    )
                )
                val now = System.currentTimeMillis()
                taskDao.upsertAll(
                    listOf(
                        TaskEntity("tk1", "حل واجب الكيمياء - الدرس الثاني", "كيمياء", "high", "", false, now),
                        TaskEntity("tk2", "حفظ كلمات الوحدة الثالثة بالإنجليزية", "إنجليزي", "normal", "", true, now - 1000)
                    )
                )
            }
        }
        prefs.markSeeded()
    }

    // Lessons
    suspend fun saveLesson(lesson: LessonEntity) = lessonDao.upsert(lesson)
    suspend fun deleteLesson(id: String) = lessonDao.deleteById(id)
    suspend fun resetWeeklyAttendance() = lessonDao.resetAllAttendance()

    // Tracks
    suspend fun saveTrack(id: String?, name: String, teacher: String, colorHex: String) {
        if (id != null) {
            val existing = trackDao.getTracksWithLessonsSnapshot().firstOrNull { it.track.id == id }?.track
            val order = existing?.sortOrder ?: trackDao.nextTrackSortOrder()
            trackDao.upsertTrack(TrackEntity(id, name, teacher, colorHex, order))
        } else {
            val order = trackDao.nextTrackSortOrder()
            trackDao.upsertTrack(TrackEntity("t_${System.currentTimeMillis()}", name, teacher, colorHex, order))
        }
    }

    suspend fun deleteTrack(id: String) = trackDao.deleteTrackById(id)

    suspend fun saveTrackLesson(trackId: String, lessonId: String?, title: String, note: String) {
        if (lessonId != null) {
            val existing = trackDao.getTracksWithLessonsSnapshot()
                .firstOrNull { it.track.id == trackId }
                ?.lessons
                ?.firstOrNull { it.id == lessonId }
            trackDao.upsertTrackLesson(
                TrackLessonEntity(
                    id = lessonId,
                    trackId = trackId,
                    title = title,
                    note = note,
                    completed = existing?.completed ?: false,
                    sortOrder = existing?.sortOrder ?: trackDao.nextLessonSortOrder(trackId)
                )
            )
        } else {
            val order = trackDao.nextLessonSortOrder(trackId)
            trackDao.upsertTrackLesson(
                TrackLessonEntity(
                    id = "l_${System.currentTimeMillis()}",
                    trackId = trackId,
                    title = title,
                    note = note,
                    completed = false,
                    sortOrder = order
                )
            )
        }
    }

    suspend fun addBulkTrackLessons(trackId: String, titles: List<String>) {
        var order = trackDao.nextLessonSortOrder(trackId)
        val baseTime = System.currentTimeMillis()
        val entities = titles.mapIndexed { idx, title ->
            TrackLessonEntity(
                id = "l_${baseTime}_$idx",
                trackId = trackId,
                title = title,
                note = "",
                completed = false,
                sortOrder = order++
            )
        }
        trackDao.upsertTrackLessons(entities)
    }

    suspend fun toggleTrackLesson(lesson: TrackLessonEntity) {
        trackDao.upsertTrackLesson(lesson.copy(completed = !lesson.completed))
    }

    suspend fun deleteTrackLesson(id: String) = trackDao.deleteTrackLessonById(id)

    // Tasks
    suspend fun saveTask(task: TaskEntity) = taskDao.upsert(task)
    suspend fun toggleTask(task: TaskEntity) = taskDao.upsert(task.copy(completed = !task.completed))
    suspend fun deleteTask(id: String) = taskDao.deleteById(id)
    suspend fun clearCompletedTasks() = taskDao.deleteCompleted()

    // Preferences
    suspend fun setDarkTheme(isDark: Boolean) = prefs.setDarkTheme(isDark)
    suspend fun setExamDate(dateIso: String) = prefs.setExamDate(dateIso)
    suspend fun recordFocusSession(minutes: Int) = prefs.recordFocusSession(minutes)

    // Reset all
    suspend fun resetAllData() {
        db.withTransaction {
            lessonDao.deleteAll()
            trackDao.deleteAllTracks()
            taskDao.deleteAll()
        }
    }

    // Compatible JSON Export/Import (matches HTML backup schema v5)
    suspend fun exportBackupJson(): String {
        val allLessons = lessonDao.getAllSnapshot()
        val allTracks = trackDao.getTracksWithLessonsSnapshot()
        val allTasks = taskDao.getAllSnapshot()
        val currentExamDate = prefs.examDate.first()

        val isoFormatter = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply {
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val root = JSONObject().apply {
            put("version", 5)
            put("exportedAt", isoFormatter.format(java.util.Date()))
            put("examDate", currentExamDate)
            put("lessons", JSONArray().apply {
                allLessons.forEach { l ->
                    put(JSONObject().apply {
                        put("id", l.id)
                        put("subject", l.subject)
                        put("day", l.day)
                        put("mode", l.mode)
                        put("teacher", l.teacher)
                        put("time", l.time)
                        put("location", l.location)
                        put("color", l.colorHex)
                        put("attended", l.attended)
                    })
                }
            })
            put("tracks", JSONArray().apply {
                allTracks.forEach { t ->
                    put(JSONObject().apply {
                        put("id", t.track.id)
                        put("name", t.track.name)
                        put("teacher", t.track.teacher)
                        put("color", t.track.colorHex)
                        put("lessons", JSONArray().apply {
                            t.lessons.sortedBy { it.sortOrder }.forEach { tl ->
                                put(JSONObject().apply {
                                    put("id", tl.id)
                                    put("title", tl.title)
                                    put("note", tl.note)
                                    put("completed", tl.completed)
                                })
                            }
                        })
                    })
                }
            })
            put("tasks", JSONArray().apply {
                allTasks.forEach { tk ->
                    put(JSONObject().apply {
                        put("id", tk.id)
                        put("title", tk.title)
                        put("subject", tk.subject)
                        put("priority", tk.priority)
                        put("due", tk.dueDate)
                        put("completed", tk.completed)
                    })
                }
            })
        }
        return root.toString(2)
    }

    suspend fun importBackupJson(rawJson: String): Result<Unit> = runCatching {
        val root = JSONObject(rawJson)
        val newLessons = mutableListOf<LessonEntity>()
        val newTracks = mutableListOf<TrackEntity>()
        val newTrackLessons = mutableListOf<TrackLessonEntity>()
        val newTasks = mutableListOf<TaskEntity>()

        root.optJSONArray("lessons")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                newLessons += LessonEntity(
                    id = o.optString("id", "ls_${System.currentTimeMillis()}_$i"),
                    subject = o.optString("subject", ""),
                    day = o.optString("day", "السبت"),
                    mode = o.optString("mode", "center"),
                    teacher = o.optString("teacher", ""),
                    time = o.optString("time", ""),
                    location = o.optString("location", ""),
                    colorHex = o.optString("color", "#4f46e5"),
                    attended = o.optBoolean("attended", false)
                )
            }
        }

        root.optJSONArray("tracks")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val trackId = o.optString("id", "t_${System.currentTimeMillis()}_$i")
                newTracks += TrackEntity(
                    id = trackId,
                    name = o.optString("name", ""),
                    teacher = o.optString("teacher", ""),
                    colorHex = o.optString("color", "#10b981"),
                    sortOrder = i
                )
                o.optJSONArray("lessons")?.let { lArr ->
                    for (j in 0 until lArr.length()) {
                        val lo = lArr.getJSONObject(j)
                        newTrackLessons += TrackLessonEntity(
                            id = lo.optString("id", "tl_${System.currentTimeMillis()}_${i}_$j"),
                            trackId = trackId,
                            title = lo.optString("title", ""),
                            note = lo.optString("note", ""),
                            completed = lo.optBoolean("completed", false),
                            sortOrder = j
                        )
                    }
                }
            }
        }

        val now = System.currentTimeMillis()
        root.optJSONArray("tasks")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                newTasks += TaskEntity(
                    id = o.optString("id", "tk_${now}_$i"),
                    title = o.optString("title", ""),
                    subject = o.optString("subject", ""),
                    priority = o.optString("priority", "normal"),
                    dueDate = o.optString("due", ""),
                    completed = o.optBoolean("completed", false),
                    createdAt = now - i
                )
            }
        }

        val importedExamDate = root.optString("examDate", "")
        if (importedExamDate.matches(Regex("^\\d{4}-\\d{2}-\\d{2}$"))) {
            prefs.setExamDate(importedExamDate)
        }

        db.withTransaction {
            if (root.has("lessons")) {
                lessonDao.deleteAll()
                lessonDao.upsertAll(newLessons)
            }
            if (root.has("tracks")) {
                trackDao.deleteAllTracks()
                trackDao.upsertTracks(newTracks)
                trackDao.upsertTrackLessons(newTrackLessons)
            }
            if (root.has("tasks")) {
                taskDao.deleteAll()
                taskDao.upsertAll(newTasks)
            }
        }
    }
}
