package com.example.data.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.data.models.ChatLanguage
import com.example.data.models.ChatMessage
import com.example.data.models.ChatSession
import com.example.data.models.MediaItem
import com.example.data.models.MediaType
import com.example.data.models.MessageSender
import com.example.data.models.UserAccount
import org.json.JSONArray
import org.json.JSONObject

class AccountDataStorage(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("hazim_ai_accounts_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_ACTIVE_USER = "key_active_user"
        private const val PREFIX_SESSIONS = "sessions_"
        private const val PREFIX_GALLERY = "gallery_"
        private const val KEY_CUSTOM_ACCOUNTS = "key_custom_accounts"
    }

    fun getKnownAccounts(provider: String): List<UserAccount> {
        val baseAccounts = when (provider) {
            "Google" -> listOf(
                UserAccount(
                    isLoggedIn = true,
                    name = "Hazim Qadir",
                    email = "hazimqadir7@gmail.com",
                    authProvider = "Google",
                    avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80",
                    isPro = true
                ),
                UserAccount(
                    isLoggedIn = true,
                    name = "Hazim Developer",
                    email = "hazim.developer@gmail.com",
                    authProvider = "Google",
                    avatarUrl = "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=200&q=80",
                    isPro = true
                )
            )
            "Facebook" -> listOf(
                UserAccount(
                    isLoggedIn = true,
                    name = "Hazim Qadir",
                    email = "hazim.fb@facebook.com",
                    authProvider = "Facebook",
                    avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80",
                    isPro = true
                )
            )
            "Microsoft" -> listOf(
                UserAccount(
                    isLoggedIn = true,
                    name = "Hazim Qadir",
                    email = "hazim@outlook.com",
                    authProvider = "Microsoft",
                    avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80",
                    isPro = true
                )
            )
            else -> emptyList()
        }

        val customList = getCustomAccounts().filter { it.authProvider.equals(provider, ignoreCase = true) }
        return (baseAccounts + customList).distinctBy { it.email }
    }

    fun saveActiveUser(account: UserAccount) {
        val json = JSONObject().apply {
            put("name", account.name)
            put("email", account.email)
            put("authProvider", account.authProvider)
            put("avatarUrl", account.avatarUrl)
            put("isPro", account.isPro)
            put("isLoggedIn", account.isLoggedIn)
        }
        prefs.edit().putString(KEY_ACTIVE_USER, json.toString()).apply()
        addCustomAccount(account)
    }

    fun getActiveUser(): UserAccount {
        val raw = prefs.getString(KEY_ACTIVE_USER, null) ?: return UserAccount(
            isLoggedIn = true,
            name = "Hazim Qadir",
            email = "hazimqadir7@gmail.com",
            authProvider = "Google",
            avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80",
            isPro = true
        )

        return try {
            val json = JSONObject(raw)
            UserAccount(
                name = json.optString("name", "Hazim Qadir"),
                email = json.optString("email", "hazimqadir7@gmail.com"),
                authProvider = json.optString("authProvider", "Google"),
                avatarUrl = json.optString("avatarUrl", ""),
                isPro = json.optBoolean("isPro", true),
                isLoggedIn = json.optBoolean("isLoggedIn", true)
            )
        } catch (e: Exception) {
            UserAccount(
                isLoggedIn = true,
                name = "Hazim Qadir",
                email = "hazimqadir7@gmail.com",
                authProvider = "Google",
                isPro = true
            )
        }
    }

    fun addCustomAccount(account: UserAccount) {
        if (account.email.isBlank()) return
        val current = getCustomAccounts().toMutableList()
        val index = current.indexOfFirst { it.email == account.email }
        if (index >= 0) {
            current[index] = account
        } else {
            current.add(account)
        }

        val arr = JSONArray()
        current.forEach { acc ->
            arr.put(JSONObject().apply {
                put("name", acc.name)
                put("email", acc.email)
                put("authProvider", acc.authProvider)
                put("avatarUrl", acc.avatarUrl)
                put("isPro", acc.isPro)
                put("isLoggedIn", true)
            })
        }
        prefs.edit().putString(KEY_CUSTOM_ACCOUNTS, arr.toString()).apply()
    }

    private fun getCustomAccounts(): List<UserAccount> {
        val raw = prefs.getString(KEY_CUSTOM_ACCOUNTS, null) ?: return emptyList()
        val list = mutableListOf<UserAccount>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                list.add(
                    UserAccount(
                        name = json.optString("name"),
                        email = json.optString("email"),
                        authProvider = json.optString("authProvider"),
                        avatarUrl = json.optString("avatarUrl"),
                        isPro = json.optBoolean("isPro", true),
                        isLoggedIn = true
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    // Save Chat Sessions for Account
    fun saveChatSessionsForUser(email: String, sessions: List<ChatSession>) {
        if (email.isBlank()) return
        val arr = JSONArray()
        sessions.forEach { session ->
            val sessionJson = JSONObject().apply {
                put("id", session.id)
                put("title", session.title)
                put("timestamp", session.timestamp)
                val msgsArr = JSONArray()
                session.messages.forEach { msg ->
                    msgsArr.put(JSONObject().apply {
                        put("id", msg.id)
                        put("sender", msg.sender.name)
                        put("text", msg.text)
                        put("timestamp", msg.timestamp)
                        put("language", msg.language.name)
                    })
                }
                put("messages", msgsArr)
            }
            arr.put(sessionJson)
        }
        prefs.edit().putString(PREFIX_SESSIONS + email, arr.toString()).apply()
    }

    // Load Chat Sessions for Account
    fun loadChatSessionsForUser(email: String): List<ChatSession>? {
        val raw = prefs.getString(PREFIX_SESSIONS + email, null) ?: return null
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<ChatSession>()
            for (i in 0 until arr.length()) {
                val sJson = arr.getJSONObject(i)
                val msgsArr = sJson.optJSONArray("messages") ?: JSONArray()
                val msgs = mutableListOf<ChatMessage>()
                for (j in 0 until msgsArr.length()) {
                    val mJson = msgsArr.getJSONObject(j)
                    val sender = try {
                        MessageSender.valueOf(mJson.getString("sender"))
                    } catch (e: Exception) {
                        MessageSender.AI
                    }
                    val lang = try {
                        ChatLanguage.valueOf(mJson.optString("language", "HINGLISH"))
                    } catch (e: Exception) {
                        ChatLanguage.HINGLISH
                    }
                    msgs.add(
                        ChatMessage(
                            id = mJson.optString("id"),
                            sender = sender,
                            text = mJson.optString("text"),
                            timestamp = mJson.optLong("timestamp"),
                            language = lang
                        )
                    )
                }
                list.add(
                    ChatSession(
                        id = sJson.getString("id"),
                        title = sJson.getString("title"),
                        timestamp = sJson.optLong("timestamp"),
                        messages = msgs
                    )
                )
            }
            if (list.isEmpty()) null else list
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Save Gallery Items for Account
    fun saveGalleryForUser(email: String, items: List<MediaItem>) {
        if (email.isBlank()) return
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("prompt", item.prompt)
                put("type", item.type.name)
                put("mediaUrl", item.mediaUrl)
                put("thumbnailUrl", item.thumbnailUrl)
                put("videoMotionType", item.videoMotionType)
                put("voiceName", item.voiceName)
                put("language", item.language)
                put("durationSeconds", item.durationSeconds ?: -1)
                put("timestamp", item.timestamp)
            })
        }
        prefs.edit().putString(PREFIX_GALLERY + email, arr.toString()).apply()
    }

    // Load Gallery Items for Account
    fun loadGalleryForUser(email: String): List<MediaItem>? {
        val raw = prefs.getString(PREFIX_GALLERY + email, null) ?: return null
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<MediaItem>()
            for (i in 0 until arr.length()) {
                val json = arr.getJSONObject(i)
                val type = try {
                    MediaType.valueOf(json.getString("type"))
                } catch (e: Exception) {
                    MediaType.IMAGE
                }
                val duration = json.optInt("durationSeconds", -1)
                list.add(
                    MediaItem(
                        id = json.getString("id"),
                        title = json.getString("title"),
                        prompt = json.getString("prompt"),
                        type = type,
                        mediaUrl = json.getString("mediaUrl"),
                        thumbnailUrl = json.optString("thumbnailUrl"),
                        videoMotionType = json.optString("videoMotionType"),
                        voiceName = json.optString("voiceName"),
                        language = json.optString("language"),
                        durationSeconds = if (duration >= 0) duration else null,
                        timestamp = json.optLong("timestamp")
                    )
                )
            }
            if (list.isEmpty()) null else list
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
