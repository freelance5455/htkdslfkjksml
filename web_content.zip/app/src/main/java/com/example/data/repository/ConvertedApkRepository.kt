package com.example.data.repository

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import com.example.data.model.ApkInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DecimalFormat

class ConvertedApkRepository(private val context: Context) {

    private val outputDir = File(context.filesDir, "converted_apks").apply { mkdirs() }

    suspend fun getConvertedApks(): List<ApkInfo> = withContext(Dispatchers.IO) {
        val files = outputDir.listFiles { file -> file.isFile && file.extension.equals("apk", ignoreCase = true) }
            ?: return@withContext emptyList()

        files.sortedByDescending { it.lastModified() }.map { file ->
            parseApkFile(file)
        }
    }

    suspend fun deleteApk(filePath: String): Boolean = withContext(Dispatchers.IO) {
        val file = File(filePath)
        if (file.exists() && file.parentFile?.absolutePath == outputDir.absolutePath) {
            file.delete()
        } else {
            false
        }
    }

    suspend fun clearAllApks(): Boolean = withContext(Dispatchers.IO) {
        outputDir.listFiles()?.forEach { it.delete() }
        true
    }

    private fun parseApkFile(apkFile: File): ApkInfo {
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES
        }

        val packageInfo = try {
            pm.getPackageArchiveInfo(apkFile.absolutePath, flags)
        } catch (_: Exception) {
            null
        }

        val appInfo = packageInfo?.applicationInfo
        val label = if (appInfo != null) {
            appInfo.sourceDir = apkFile.absolutePath
            appInfo.publicSourceDir = apkFile.absolutePath
            try {
                appInfo.loadLabel(pm).toString()
            } catch (_: Exception) {
                null
            }
        } else null

        val appName = label ?: apkFile.nameWithoutExtension.removePrefix("Converted_")
        val packageName = packageInfo?.packageName ?: "com.converted.app"
        val versionName = packageInfo?.versionName ?: "1.0"
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo?.longVersionCode ?: 1L
        } else {
            @Suppress("DEPRECATION")
            packageInfo?.versionCode?.toLong() ?: 1L
        }

        val iconBitmap = if (appInfo != null) {
            try {
                drawableToBitmap(appInfo.loadIcon(pm))
            } catch (_: Exception) {
                null
            }
        } else null

        val permissions = packageInfo?.requestedPermissions?.toList() ?: emptyList()
        val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            appInfo?.minSdkVersion ?: 21
        } else {
            21
        }
        val targetSdk = appInfo?.targetSdkVersion ?: 29

        return ApkInfo(
            fileName = apkFile.name,
            filePath = apkFile.absolutePath,
            appName = appName,
            packageName = packageName,
            versionName = versionName,
            versionCode = versionCode,
            minSdkVersion = minSdk,
            targetSdkVersion = targetSdk,
            fileSizeBytes = apkFile.length(),
            formattedSize = formatBytes(apkFile.length()),
            iconBitmap = iconBitmap,
            permissions = permissions,
            conversionTimestamp = apkFile.lastModified(),
            sourceType = "APK"
        )
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val format = DecimalFormat("#,##0.#")
        return "${format.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }
}
