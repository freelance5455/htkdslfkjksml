package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class Subject(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val icon: String = "📚",
    val colorHex: String = "#F59E0B",
    val dailyGoalMinutes: Int = 60,
    val createdAt: Long = System.currentTimeMillis()
)
