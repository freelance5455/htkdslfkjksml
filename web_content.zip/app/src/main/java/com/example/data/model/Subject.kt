package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class Subject(
  val id: String,
  val title: String,
  val iconEmoji: String,
  val primaryColor: Color,
  val accentColor: Color,
  val description: String
) {
  MATEMATIK(
    id = "matematik",
    title = "Matematik & Geometri",
    iconEmoji = "📐",
    primaryColor = Color(0xFF3B82F6),
    accentColor = Color(0xFF93C5FD),
    description = "Formül şifreleri, pratik çözüm teknikleri ve görsel geometri kuralları"
  ),
  TURKCE_EDEBIYAT(
    id = "turkce_edebiyat",
    title = "Türkçe & Edebiyat",
    iconEmoji = "📚",
    primaryColor = Color(0xFFEC4899),
    accentColor = Color(0xFFFBCFE8),
    description = "Yazar-eser şifreleri, akılda kalıcı hikayeler ve paragraf refleksleri"
  ),
  TARIH(
    id = "tarih",
    title = "Tarih",
    iconEmoji = "🏛️",
    primaryColor = Color(0xFF8B5CF6),
    accentColor = Color(0xFFDDD6FE),
    description = "Kronolojik görsel şifreler, kongre akrostişleri ve antlaşma kodlamaları"
  ),
  COGRAFYA(
    id = "cografya",
    title = "Coğrafya",
    iconEmoji = "🌍",
    primaryColor = Color(0xFF10B981),
    accentColor = Color(0xFFA7F3D0),
    description = "Harita hafıza teknikleri, rüzgar kodlamaları ve yer şekilleri şifreleri"
  ),
  BIYOLOJI(
    id = "biyoloji",
    title = "Biyoloji",
    iconEmoji = "🧬",
    primaryColor = Color(0xFF06B6D4),
    accentColor = Color(0xFFCFFAFE),
    description = "Hücre şifreleri, sistemlerin görsel animasyon hafıza kartları"
  ),
  KIMYA(
    id = "kimya",
    title = "Kimya",
    iconEmoji = "🧪",
    primaryColor = Color(0xFFF59E0B),
    accentColor = Color(0xFFFDE68A),
    description = "Periyodik tablo kodlamaları, tepkime refleksleri ve gaz yasaları"
  ),
  FIZIK(
    id = "fizik",
    title = "Fizik",
    iconEmoji = "⚡",
    primaryColor = Color(0xFF6366F1),
    accentColor = Color(0xFFC7D2FE),
    description = "Kuvvet, hareket, elektrik formüllerinin hafıza canlandırmaları"
  )
}
