package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.AiGeneratedChapterDraft
import com.example.data.model.Book
import com.example.data.model.Chapter
import com.example.data.model.countWords
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class BookRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Devam etmek için Google hesabınızla giriş yapmalısınız.")
    }

    fun observeBooks(userId: String): Flow<List<Book>> {
        val path = "users/$userId/books"
        return db.collection("users").document(userId).collection("books")
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Book::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.updatedAt?.seconds ?: it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, path)
                }
                throw error
            }
    }

    fun observeBook(userId: String, bookId: String): Flow<Book?> {
        val path = "users/$userId/books/$bookId"
        return db.collection("users").document(userId).collection("books").document(bookId)
            .snapshots()
            .map { snapshot ->
                if (snapshot.exists()) {
                    snapshot.toObject(Book::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                } else {
                    null
                }
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.GET, path)
                }
                throw error
            }
    }

    fun observeChapters(userId: String, bookId: String): Flow<List<Chapter>> {
        val path = "users/$userId/books/$bookId/chapters"
        return db.collection("users").document(userId)
            .collection("books").document(bookId)
            .collection("chapters")
            .whereEqualTo("userId", userId)
            .whereEqualTo("bookId", bookId)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Chapter::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.chapterNumber }
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, path)
                }
                throw error
            }
    }

    suspend fun getBookById(userId: String, bookId: String): Book? {
        val docRef = db.collection("users").document(userId).collection("books").document(bookId)
        return try {
            val snapshot = docRef.get().await()
            snapshot.toObject(Book::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            throw e
        }
    }

    suspend fun createBookWithChapters(
        title: String,
        subtitle: String,
        synopsis: String,
        genre: String,
        tone: String,
        creationMethod: String,
        coverTheme: String,
        chapters: List<AiGeneratedChapterDraft>
    ): String {
        val uid = requireUserId()
        val bookId = "book_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val bookRef = db.collection("users").document(uid).collection("books").document(bookId)

        val safeTitle = title.trim().ifEmpty { "İsimsiz Kitap" }.take(150)
        val safeSubtitle = subtitle.trim().take(250)
        val safeSynopsis = synopsis.trim().take(1500)
        val safeGenre = genre.trim().ifEmpty { "Roman" }.take(80)
        val safeTone = tone.trim().ifEmpty { "Edebi ve Derin" }.take(80)
        val safeMethod = if (creationMethod == "manual") "manual" else "ai"
        val safeTheme = if (coverTheme in listOf("crimson", "midnight", "emerald", "parchment", "obsidian")) {
            coverTheme
        } else {
            "crimson"
        }

        val boundedChapters = chapters.take(500)
        val totalWords = boundedChapters.sumOf { countWords(it.content) }.coerceIn(0L, 10000000L)
        val chapterCount = boundedChapters.size.toLong().coerceIn(0L, 500L)

        try {
            // Create the parent book document first
            val bookPayload = mapOf(
                "userId" to uid,
                "title" to safeTitle,
                "subtitle" to safeSubtitle,
                "synopsis" to safeSynopsis,
                "genre" to safeGenre,
                "tone" to safeTone,
                "creationMethod" to safeMethod,
                "coverTheme" to safeTheme,
                "chapterCount" to chapterCount,
                "totalWordCount" to totalWords,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            bookRef.set(bookPayload).await()

            // Commit chapters in safe chunks of 80 to handle 80-240+ chapters smoothly without batch payload limits
            val indexedChapters = boundedChapters.mapIndexed { idx, draft -> idx to draft }
            for (chunk in indexedChapters.chunked(80)) {
                val batch = db.batch()
                for ((index, draft) in chunk) {
                    val chapterId = "ch_${index + 1}_${UUID.randomUUID().toString().replace("-", "").take(10)}"
                    val chapterRef = bookRef.collection("chapters").document(chapterId)
                    val safeChapterTitle = draft.title.trim().ifEmpty { "${index + 1}. Bölüm" }.take(150)
                    val safeSummary = draft.summary.trim().take(800)
                    val safeContent = draft.content.trim().ifEmpty { "Bölüm metni." }.take(120000)
                    val words = countWords(safeContent).coerceIn(0L, 200000L)

                    val chapterPayload = mapOf(
                        "userId" to uid,
                        "bookId" to bookId,
                        "chapterNumber" to (index + 1).toLong().coerceIn(1L, 500L),
                        "title" to safeChapterTitle,
                        "summary" to safeSummary,
                        "content" to safeContent,
                        "wordCount" to words,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    batch.set(chapterRef, chapterPayload)
                }
                batch.commit().await()
            }

            return bookId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, bookRef.path)
            throw e
        }
    }

    suspend fun updateBookMetadata(
        bookId: String,
        title: String,
        subtitle: String,
        synopsis: String,
        genre: String,
        tone: String,
        coverTheme: String
    ) {
        val uid = requireUserId()
        val bookRef = db.collection("users").document(uid).collection("books").document(bookId)
        try {
            val updates = mapOf(
                "title" to title.trim().ifEmpty { "İsimsiz Kitap" }.take(150),
                "subtitle" to subtitle.trim().take(250),
                "synopsis" to synopsis.trim().take(1500),
                "genre" to genre.trim().ifEmpty { "Roman" }.take(80),
                "tone" to tone.trim().ifEmpty { "Edebi ve Derin" }.take(80),
                "coverTheme" to coverTheme,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            bookRef.update(updates).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, bookRef.path)
            throw e
        }
    }

    suspend fun addChapterToBook(
        book: Book,
        chapterNumber: Int,
        title: String,
        summary: String,
        content: String
    ): String {
        val uid = requireUserId()
        val bookRef = db.collection("users").document(uid).collection("books").document(book.id)
        val chapterId = "ch_${chapterNumber}_${UUID.randomUUID().toString().replace("-", "").take(10)}"
        val chapterRef = bookRef.collection("chapters").document(chapterId)

        val safeTitle = title.trim().ifEmpty { "$chapterNumber. Bölüm" }.take(150)
        val safeSummary = summary.trim().take(800)
        val safeContent = content.trim().ifEmpty { "Bölüm metni." }.take(120000)
        val words = countWords(safeContent).coerceIn(0L, 200000L)

        try {
            val batch = db.batch()
            val chapterPayload = mapOf(
                "userId" to uid,
                "bookId" to book.id,
                "chapterNumber" to chapterNumber.toLong().coerceIn(1L, 500L),
                "title" to safeTitle,
                "summary" to safeSummary,
                "content" to safeContent,
                "wordCount" to words,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            batch.set(chapterRef, chapterPayload)

            val newChapterCount = (book.chapterCount + 1L).coerceIn(0L, 500L)
            val newTotalWords = (book.totalWordCount + words).coerceIn(0L, 10000000L)
            batch.update(
                bookRef,
                mapOf(
                    "chapterCount" to newChapterCount,
                    "totalWordCount" to newTotalWords,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            return chapterId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, chapterRef.path)
            throw e
        }
    }

    suspend fun updateChapter(
        book: Book,
        chapter: Chapter,
        newTitle: String,
        newSummary: String,
        newContent: String
    ) {
        val uid = requireUserId()
        val bookRef = db.collection("users").document(uid).collection("books").document(book.id)
        val chapterRef = bookRef.collection("chapters").document(chapter.id)

        val safeTitle = newTitle.trim().ifEmpty { "${chapter.chapterNumber}. Bölüm" }.take(150)
        val safeSummary = newSummary.trim().take(800)
        val safeContent = newContent.trim().ifEmpty { "Bölüm metni." }.take(120000)
        val newWordCount = countWords(safeContent).coerceIn(0L, 200000L)
        val wordDiff = newWordCount - chapter.wordCount
        val updatedTotalWords = (book.totalWordCount + wordDiff).coerceIn(0L, 10000000L)

        try {
            val batch = db.batch()
            batch.update(
                chapterRef,
                mapOf(
                    "title" to safeTitle,
                    "summary" to safeSummary,
                    "content" to safeContent,
                    "wordCount" to newWordCount,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.update(
                bookRef,
                mapOf(
                    "totalWordCount" to updatedTotalWords,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, chapterRef.path)
            throw e
        }
    }

    suspend fun deleteBook(bookId: String, chapterIds: List<String> = emptyList()) {
        val uid = requireUserId()
        val bookRef = db.collection("users").document(uid).collection("books").document(bookId)
        try {
            for (chunk in chapterIds.chunked(150)) {
                val batch = db.batch()
                chunk.forEach { chId ->
                    batch.delete(bookRef.collection("chapters").document(chId))
                }
                batch.commit().await()
            }
            bookRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, bookRef.path)
            throw e
        }
    }
}
