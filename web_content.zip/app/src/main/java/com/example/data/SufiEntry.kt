package com.example.data

data class SufiEntry(
    val id: String,
    val type: String, // "quote" or "thought"
    val en: String,
    val ml: String,
    val author: String? = null,
    val theme: String? = null
) {
    val isQuote: Boolean get() = type.equals("quote", ignoreCase = true)
}

enum class SufiLanguage(val code: String, val displayName: String, val nativeLabel: String) {
    MALAYALAM("ml", "Malayalam", "മലയാളം"),
    ENGLISH("en", "English", "English"),
    DUAL("dual", "Dual", "രണ്ടും / Both")
}
