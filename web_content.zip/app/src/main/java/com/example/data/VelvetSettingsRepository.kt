package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private val Context.velvetDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "velvetkey_settings"
)

class VelvetSettingsRepository private constructor(private val context: Context) {

    private object Keys {
        val ACTIVE_THEME_ID = stringPreferencesKey("active_theme_id")
        val CUSTOM_THEMES_JSON = stringPreferencesKey("custom_themes_json")
        val DARK_MODE = stringPreferencesKey("dark_mode")
        val FONT_ID = stringPreferencesKey("font_id")
        val UNICODE_FONT = stringPreferencesKey("unicode_font")
        val HAPTIC_PROFILE = stringPreferencesKey("haptic_profile")
        val KEY_SOUND = booleanPreferencesKey("key_sound")
        val ENABLED_LANGUAGES_JSON = stringPreferencesKey("enabled_languages_json")
        val ACTIVE_LANGUAGE = stringPreferencesKey("active_language")
        val SWIPE_ENABLED = booleanPreferencesKey("swipe_enabled")
        val PREDICTIONS_ENABLED = booleanPreferencesKey("predictions_enabled")
        val ADAPT_SLANG = booleanPreferencesKey("adapt_slang")
        val ALIVE_MOTION = booleanPreferencesKey("alive_motion")
        val AI_REMOVE_STARTERS = booleanPreferencesKey("ai_remove_starters")
        val AI_AUTO_PUNCTUATION = booleanPreferencesKey("ai_auto_punctuation")
        val AI_SMART_PREDICT = booleanPreferencesKey("ai_smart_predict")
        val PURE_AI_VOICE = booleanPreferencesKey("pure_ai_voice")
        val KEY_POPUP = booleanPreferencesKey("key_popup")
        val AUTO_CAP = booleanPreferencesKey("auto_cap")
        val DOUBLE_SPACE_PERIOD = booleanPreferencesKey("double_space_period")
        val CLIPBOARD_ENABLED = booleanPreferencesKey("clipboard_enabled")
        val KEY_HEIGHT_SCALE = floatPreferencesKey("key_height_scale")
        val CLIPBOARD_JSON = stringPreferencesKey("clipboard_json")
        val LEARNED_WORDS_JSON = stringPreferencesKey("learned_words_json")
        val CUSTOM_EMOJIS_JSON = stringPreferencesKey("custom_emojis_json")
        val RECENT_EMOJIS_JSON = stringPreferencesKey("recent_emojis_json")
    }

    val settingsFlow: Flow<VelvetSettings> = context.velvetDataStore.data.map { prefs ->
        val enabledLangs = parseLanguages(prefs[Keys.ENABLED_LANGUAGES_JSON])
        val activeLang = KeyboardLanguage.fromId(prefs[Keys.ACTIVE_LANGUAGE])
            .let { if (it in enabledLangs) it else enabledLangs.first() }

        VelvetSettings(
            activeThemeId = prefs[Keys.ACTIVE_THEME_ID] ?: "alive_leaf",
            customThemes = parseCustomThemes(prefs[Keys.CUSTOM_THEMES_JSON]),
            darkModeOption = DarkModeOption.fromId(prefs[Keys.DARK_MODE]),
            fontId = KeyboardFontId.fromId(prefs[Keys.FONT_ID]),
            unicodeOutputFont = UnicodeOutputFont.fromId(prefs[Keys.UNICODE_FONT]),
            hapticProfile = HapticProfile.fromId(prefs[Keys.HAPTIC_PROFILE]),
            keySoundEnabled = prefs[Keys.KEY_SOUND] ?: false,
            enabledLanguages = enabledLangs,
            activeLanguage = activeLang,
            swipeTypingEnabled = prefs[Keys.SWIPE_ENABLED] ?: true,
            predictionsEnabled = prefs[Keys.PREDICTIONS_ENABLED] ?: true,
            adaptToSlangEnabled = prefs[Keys.ADAPT_SLANG] ?: true,
            aliveMotionEnabled = prefs[Keys.ALIVE_MOTION] ?: true,
            aiRemoveStartersEnabled = prefs[Keys.AI_REMOVE_STARTERS] ?: true,
            aiAutoPunctuationEnabled = prefs[Keys.AI_AUTO_PUNCTUATION] ?: true,
            aiSmartPredictEnabled = prefs[Keys.AI_SMART_PREDICT] ?: true,
            pureAiVoiceEnabled = prefs[Keys.PURE_AI_VOICE] ?: false,
            keyPopupEnabled = prefs[Keys.KEY_POPUP] ?: true,
            autoCapitalizeEnabled = prefs[Keys.AUTO_CAP] ?: true,
            doubleSpacePeriodEnabled = prefs[Keys.DOUBLE_SPACE_PERIOD] ?: true,
            clipboardHistoryEnabled = prefs[Keys.CLIPBOARD_ENABLED] ?: true,
            keyHeightScale = (prefs[Keys.KEY_HEIGHT_SCALE] ?: 1.0f).coerceIn(0.85f, 1.2f),
            clipboardHistory = parseClipboard(prefs[Keys.CLIPBOARD_JSON]),
            learnedWords = parseLearnedWords(prefs[Keys.LEARNED_WORDS_JSON]),
            customEmojis = parseCustomEmojis(prefs[Keys.CUSTOM_EMOJIS_JSON]),
            recentEmojis = parseRecentEmojis(prefs[Keys.RECENT_EMOJIS_JSON])
        )
    }

    suspend fun setActiveThemeId(themeId: String) {
        context.velvetDataStore.edit { it[Keys.ACTIVE_THEME_ID] = themeId }
    }

    suspend fun saveCustomTheme(preset: CustomThemePreset, setAsActive: Boolean = true) {
        context.velvetDataStore.edit { prefs ->
            val current = parseCustomThemes(prefs[Keys.CUSTOM_THEMES_JSON]).toMutableList()
            current.removeAll { it.id == preset.id }
            current.add(0, preset)
            prefs[Keys.CUSTOM_THEMES_JSON] = encodeCustomThemes(current)
            if (setAsActive) {
                prefs[Keys.ACTIVE_THEME_ID] = preset.id
            }
        }
    }

    suspend fun deleteCustomTheme(themeId: String) {
        context.velvetDataStore.edit { prefs ->
            val current = parseCustomThemes(prefs[Keys.CUSTOM_THEMES_JSON]).toMutableList()
            current.removeAll { it.id == themeId }
            prefs[Keys.CUSTOM_THEMES_JSON] = encodeCustomThemes(current)
            if (prefs[Keys.ACTIVE_THEME_ID] == themeId) {
                prefs[Keys.ACTIVE_THEME_ID] = "alive_leaf"
            }
        }
    }

    suspend fun setDarkMode(option: DarkModeOption) {
        context.velvetDataStore.edit { it[Keys.DARK_MODE] = option.id }
    }

    suspend fun setFont(fontId: KeyboardFontId) {
        context.velvetDataStore.edit { it[Keys.FONT_ID] = fontId.id }
    }

    suspend fun setUnicodeOutputFont(font: UnicodeOutputFont) {
        context.velvetDataStore.edit { it[Keys.UNICODE_FONT] = font.id }
    }

    suspend fun setHapticProfile(profile: HapticProfile) {
        context.velvetDataStore.edit { it[Keys.HAPTIC_PROFILE] = profile.id }
    }

    suspend fun setKeySoundEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.KEY_SOUND] = enabled }
    }

    suspend fun setActiveLanguage(language: KeyboardLanguage) {
        context.velvetDataStore.edit { prefs ->
            val langs = parseLanguages(prefs[Keys.ENABLED_LANGUAGES_JSON]).toMutableList()
            if (language !in langs) {
                langs.add(language)
                prefs[Keys.ENABLED_LANGUAGES_JSON] = encodeLanguages(langs)
            }
            prefs[Keys.ACTIVE_LANGUAGE] = language.id
        }
    }

    suspend fun toggleLanguageEnabled(language: KeyboardLanguage) {
        context.velvetDataStore.edit { prefs ->
            val langs = parseLanguages(prefs[Keys.ENABLED_LANGUAGES_JSON]).toMutableList()
            if (language in langs) {
                if (langs.size > 1) {
                    langs.remove(language)
                    if (prefs[Keys.ACTIVE_LANGUAGE] == language.id) {
                        prefs[Keys.ACTIVE_LANGUAGE] = langs.first().id
                    }
                }
            } else {
                langs.add(language)
            }
            prefs[Keys.ENABLED_LANGUAGES_JSON] = encodeLanguages(langs)
        }
    }

    suspend fun setSwipeTypingEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.SWIPE_ENABLED] = enabled }
    }

    suspend fun setPredictionsEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.PREDICTIONS_ENABLED] = enabled }
    }

    suspend fun setAdaptToSlangEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.ADAPT_SLANG] = enabled }
    }

    suspend fun setAliveMotionEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.ALIVE_MOTION] = enabled }
    }

    suspend fun setAiRemoveStartersEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.AI_REMOVE_STARTERS] = enabled }
    }

    suspend fun setAiAutoPunctuationEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.AI_AUTO_PUNCTUATION] = enabled }
    }

    suspend fun setAiSmartPredictEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.AI_SMART_PREDICT] = enabled }
    }

    suspend fun setPureAiVoiceEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.PURE_AI_VOICE] = enabled }
    }

    suspend fun setKeyPopupEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.KEY_POPUP] = enabled }
    }

    suspend fun setAutoCapitalizeEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.AUTO_CAP] = enabled }
    }

    suspend fun setDoubleSpacePeriodEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.DOUBLE_SPACE_PERIOD] = enabled }
    }

    suspend fun setClipboardHistoryEnabled(enabled: Boolean) {
        context.velvetDataStore.edit { it[Keys.CLIPBOARD_ENABLED] = enabled }
    }

    suspend fun setKeyHeightScale(scale: Float) {
        context.velvetDataStore.edit { it[Keys.KEY_HEIGHT_SCALE] = scale.coerceIn(0.85f, 1.2f) }
    }

    suspend fun addClipboardClip(rawText: String) {
        val clean = rawText.trim()
        if (clean.isEmpty()) return
        context.velvetDataStore.edit { prefs ->
            if (prefs[Keys.CLIPBOARD_ENABLED] == false) return@edit
            val current = parseClipboard(prefs[Keys.CLIPBOARD_JSON]).toMutableList()
            val existingPinned = current.firstOrNull { it.text == clean }?.isPinned ?: false
            current.removeAll { it.text == clean }
            current.add(
                0,
                ClipboardEntry(
                    id = UUID.randomUUID().toString(),
                    text = clean,
                    timestampMs = System.currentTimeMillis(),
                    isPinned = existingPinned
                )
            )
            val pinned = current.filter { it.isPinned }
            val unpinned = current.filterNot { it.isPinned }.take(24)
            prefs[Keys.CLIPBOARD_JSON] = encodeClipboard(pinned + unpinned)
        }
    }

    suspend fun togglePinClipboard(id: String) {
        context.velvetDataStore.edit { prefs ->
            val current = parseClipboard(prefs[Keys.CLIPBOARD_JSON]).map { entry ->
                if (entry.id == id) entry.copy(isPinned = !entry.isPinned) else entry
            }
            prefs[Keys.CLIPBOARD_JSON] = encodeClipboard(current)
        }
    }

    suspend fun deleteClipboardClip(id: String) {
        context.velvetDataStore.edit { prefs ->
            val current = parseClipboard(prefs[Keys.CLIPBOARD_JSON]).filterNot { it.id == id }
            prefs[Keys.CLIPBOARD_JSON] = encodeClipboard(current)
        }
    }

    suspend fun clearUnpinnedClipboard() {
        context.velvetDataStore.edit { prefs ->
            val pinned = parseClipboard(prefs[Keys.CLIPBOARD_JSON]).filter { it.isPinned }
            prefs[Keys.CLIPBOARD_JSON] = encodeClipboard(pinned)
        }
    }

    suspend fun recordTypedWord(word: String) {
        val clean = word.trim().lowercase()
        if (clean.length < 2 || clean.length > 24) return
        if (!clean.all { it.isLetter() || it == '\'' }) return
        context.velvetDataStore.edit { prefs ->
            if (prefs[Keys.ADAPT_SLANG] == false) return@edit
            val map = parseLearnedWords(prefs[Keys.LEARNED_WORDS_JSON]).toMutableMap()
            map[clean] = (map[clean] ?: 0) + 1
            // Keep top 250 most-used personal words/slang
            val trimmed = if (map.size > 250) {
                map.entries.sortedByDescending { it.value }.take(250).associate { it.key to it.value }
            } else {
                map
            }
            prefs[Keys.LEARNED_WORDS_JSON] = encodeLearnedWords(trimmed)
        }
    }

    suspend fun clearLearnedSlang() {
        context.velvetDataStore.edit { it.remove(Keys.LEARNED_WORDS_JSON) }
    }

    suspend fun addCustomEmoji(symbol: String, label: String) {
        val cleanSymbol = symbol.trim()
        if (cleanSymbol.isEmpty()) return
        val cleanLabel = label.trim().ifEmpty { "Custom iOS Emoji" }
        context.velvetDataStore.edit { prefs ->
            val current = parseCustomEmojis(prefs[Keys.CUSTOM_EMOJIS_JSON]).toMutableList()
            current.removeAll { it.symbol == cleanSymbol }
            current.add(0, CustomEmojiItem(cleanSymbol, cleanLabel, isPreinstalledIos = false))
            prefs[Keys.CUSTOM_EMOJIS_JSON] = encodeCustomEmojis(current)
        }
    }

    suspend fun removeCustomEmoji(symbol: String) {
        context.velvetDataStore.edit { prefs ->
            val current = parseCustomEmojis(prefs[Keys.CUSTOM_EMOJIS_JSON]).toMutableList()
            current.removeAll { it.symbol == symbol && !it.isPreinstalledIos }
            prefs[Keys.CUSTOM_EMOJIS_JSON] = encodeCustomEmojis(current)
        }
    }

    suspend fun recordRecentEmoji(symbol: String) {
        context.velvetDataStore.edit { prefs ->
            val current = parseRecentEmojis(prefs[Keys.RECENT_EMOJIS_JSON]).toMutableList()
            current.remove(symbol)
            current.add(0, symbol)
            prefs[Keys.RECENT_EMOJIS_JSON] = JSONArray(current.take(24)).toString()
        }
    }

    private fun parseLanguages(raw: String?): List<KeyboardLanguage> {
        if (raw.isNullOrBlank()) return listOf(KeyboardLanguage.EN, KeyboardLanguage.ES)
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    add(KeyboardLanguage.fromId(arr.getString(i)))
                }
            }.distinct().ifEmpty { listOf(KeyboardLanguage.EN) }
        } catch (_: Exception) {
            listOf(KeyboardLanguage.EN, KeyboardLanguage.ES)
        }
    }

    private fun encodeLanguages(list: List<KeyboardLanguage>): String {
        return JSONArray(list.map { it.id }).toString()
    }

    private fun parseCustomThemes(raw: String?): List<CustomThemePreset> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        CustomThemePreset(
                            id = o.getString("id"),
                            name = o.getString("name"),
                            tagline = o.optString("tagline", "Custom theme"),
                            isBuiltIn = false,
                            isDarkBase = o.optBoolean("isDarkBase", true),
                            bgColorArgb = o.optLong("bg", 0xFF0E1412),
                            keyColorArgb = o.optLong("key", 0xFF1A2521),
                            specialKeyColorArgb = o.optLong("special", 0xFF131C19),
                            textColorArgb = o.optLong("text", 0xFFECFDF5),
                            accentColorArgb = o.optLong("accent", 0xFF34D399),
                            keycapStyle = KeycapStyle.fromId(o.optString("style")),
                            cornerRadiusDp = o.optDouble("radius", 10.0).toFloat(),
                            keyOpacity = o.optDouble("opacity", 0.92).toFloat(),
                            backgroundImagePath = o.optString("imgPath").takeIf { it.isNotBlank() },
                            backgroundVideoPath = o.optString("vidPath").takeIf { it.isNotBlank() },
                            aliveLeafEffect = o.optBoolean("aliveLeaf", false)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun encodeCustomThemes(list: List<CustomThemePreset>): String {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(
                JSONObject().apply {
                    put("id", t.id)
                    put("name", t.name)
                    put("tagline", t.tagline)
                    put("isDarkBase", t.isDarkBase)
                    put("bg", t.bgColorArgb)
                    put("key", t.keyColorArgb)
                    put("special", t.specialKeyColorArgb)
                    put("text", t.textColorArgb)
                    put("accent", t.accentColorArgb)
                    put("style", t.keycapStyle.id)
                    put("radius", t.cornerRadiusDp.toDouble())
                    put("opacity", t.keyOpacity.toDouble())
                    put("imgPath", t.backgroundImagePath.orEmpty())
                    put("vidPath", t.backgroundVideoPath.orEmpty())
                    put("aliveLeaf", t.aliveLeafEffect)
                }
            )
        }
        return arr.toString()
    }

    private fun parseClipboard(raw: String?): List<ClipboardEntry> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        ClipboardEntry(
                            id = o.getString("id"),
                            text = o.getString("text"),
                            timestampMs = o.optLong("ts", 0L),
                            isPinned = o.optBoolean("pin", false)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun encodeClipboard(list: List<ClipboardEntry>): String {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(
                JSONObject().apply {
                    put("id", c.id)
                    put("text", c.text)
                    put("ts", c.timestampMs)
                    put("pin", c.isPinned)
                }
            )
        }
        return arr.toString()
    }

    private fun parseLearnedWords(raw: String?): Map<String, Int> {
        if (raw.isNullOrBlank()) return emptyMap()
        return try {
            val obj = JSONObject(raw)
            buildMap {
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    put(k, obj.optInt(k, 1))
                }
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun encodeLearnedWords(map: Map<String, Int>): String {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        return obj.toString()
    }

    private fun parseCustomEmojis(raw: String?): List<CustomEmojiItem> {
        if (raw.isNullOrBlank()) return DefaultIosEmojis
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(
                        CustomEmojiItem(
                            symbol = obj.getString("symbol"),
                            label = obj.optString("label", "Custom"),
                            isPreinstalledIos = obj.optBoolean("ios", false)
                        )
                    )
                }
            }.ifEmpty { DefaultIosEmojis }
        } catch (_: Exception) {
            DefaultIosEmojis
        }
    }

    private fun encodeCustomEmojis(list: List<CustomEmojiItem>): String {
        val array = JSONArray()
        list.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("symbol", item.symbol)
                    put("label", item.label)
                    put("ios", item.isPreinstalledIos)
                }
            )
        }
        return array.toString()
    }

    private fun parseRecentEmojis(raw: String?): List<String> {
        if (raw.isNullOrBlank()) {
            return listOf("🥹", "🫶", "✨", "🔥", "😂", "❤️", "🫡", "🫠")
        }
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    add(array.getString(i))
                }
            }
        } catch (_: Exception) {
            listOf("🥹", "🫶", "✨", "🔥", "😂", "❤️", "🫡", "🫠")
        }
    }

    companion object {
        @Volatile
        private var instance: VelvetSettingsRepository? = null

        fun getInstance(context: Context): VelvetSettingsRepository {
            return instance ?: synchronized(this) {
                instance ?: VelvetSettingsRepository(context.applicationContext).also {
                    instance = it
                }
            }
        }
    }
}
