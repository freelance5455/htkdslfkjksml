package com.example.data.local

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class ZingRepository(private val dao: ZingDao) {

    val allVideos: Flow<List<VideoEntity>> = dao.getAllVideos()
    val allVideosAdmin: Flow<List<VideoEntity>> = dao.getAllVideosAdmin()
    val allUsers: Flow<List<UserEntity>> = dao.getAllUsers()
    val allNotifications: Flow<List<NotificationEntity>> = dao.getAllNotifications()
    val allPayouts: Flow<List<PayoutEntity>> = dao.getAllPayouts()
    val allReports: Flow<List<ReportEntity>> = dao.getAllReports()
    val likedVideos: Flow<List<VideoEntity>> = dao.getLikedVideos()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            seedInitialDataIfNeeded()
        }
    }

    private suspend fun seedInitialDataIfNeeded() {
        val existing = dao.getAllVideos().firstOrNull()
        if (existing.isNullOrEmpty()) {
            // Seed Users
            val users = listOf(
                UserEntity(
                    id = "u_current",
                    username = "aarav_creatives",
                    displayName = "Aarav Sharma",
                    avatarUrl = "avatar_aarav",
                    bio = "Creator & Video Alchemist ✨ Creating high-voltage short vibes | 500K on Zing | Delhi, India 🇮🇳",
                    isVerified = true,
                    followersCount = 148200,
                    followingCount = 312,
                    totalLikes = 2840000,
                    isBlocked = false,
                    isFollowing = false,
                    role = "creator",
                    walletBalance = 48250.0,
                    coinBalance = 1200
                ),
                UserEntity(
                    id = "u_sneha",
                    username = "sneha_beats",
                    displayName = "Sneha Patel",
                    avatarUrl = "avatar_sneha",
                    bio = "Choreographer 💃 Daily dance trends, Bollywood fusion & tutorials | Collabs: sneha@zing.io",
                    isVerified = true,
                    followersCount = 320000,
                    followingCount = 180,
                    totalLikes = 5400000,
                    isBlocked = false,
                    isFollowing = true,
                    role = "creator",
                    walletBalance = 89400.0,
                    coinBalance = 2400
                ),
                UserEntity(
                    id = "u_rohit",
                    username = "tech_rohit",
                    displayName = "Rohit Verma",
                    avatarUrl = "avatar_rohit",
                    bio = "Tech gadgets, AI workflows & futuristic hacks in 30s ⚡ Engineer turned creator.",
                    isVerified = true,
                    followersCount = 89000,
                    followingCount = 95,
                    totalLikes = 1200000,
                    isBlocked = false,
                    isFollowing = false,
                    role = "creator",
                    walletBalance = 24100.0,
                    coinBalance = 800
                ),
                UserEntity(
                    id = "u_ananya",
                    username = "chef_ananya",
                    displayName = "Ananya Sen",
                    avatarUrl = "avatar_ananya",
                    bio = "Street food secrets, midnight recipes & viral kitchen magic 🍜 Kolkata food lover.",
                    isVerified = true,
                    followersCount = 215000,
                    followingCount = 220,
                    totalLikes = 3900000,
                    isBlocked = false,
                    isFollowing = true,
                    role = "creator",
                    walletBalance = 62800.0,
                    coinBalance = 1600
                ),
                UserEntity(
                    id = "u_admin",
                    username = "zing_admin",
                    displayName = "Zing Safety & Admin",
                    avatarUrl = "ic_launcher_zing",
                    bio = "Official Zing Community Moderation, Safety & Creator Program Operations 🛡️",
                    isVerified = true,
                    followersCount = 1000000,
                    followingCount = 10,
                    totalLikes = 0,
                    isBlocked = false,
                    isFollowing = false,
                    role = "admin",
                    walletBalance = 0.0,
                    coinBalance = 99999
                )
            )
            dao.insertUsers(users)

            // Seed Videos
            val videos = listOf(
                VideoEntity(
                    id = "v_1",
                    creatorId = "u_sneha",
                    creatorName = "Sneha Patel",
                    creatorHandle = "sneha_beats",
                    creatorAvatar = "avatar_sneha",
                    caption = "Neon Cyber Groove! 🔥 Practiced this drop 50 times, did we nail the timing? Drop your vibe rating in comments! #dance #viral #neonvibes #trending",
                    soundTitle = "Electro Pulse - Sneha Beats Original",
                    videoUri = "",
                    posterResName = "reel_bg_dance",
                    bgGradientStart = 0xFF1D063A,
                    bgGradientEnd = 0xFF540E5E,
                    likesCount = 142800,
                    commentsCount = 3420,
                    sharesCount = 18500,
                    viewsCount = 890000,
                    isLiked = false,
                    isSaved = true,
                    timestamp = System.currentTimeMillis() - 3600000 * 4,
                    tags = "dance,viral,neonvibes,trending",
                    category = "Dance",
                    adRevenue = 342.50,
                    giftCoins = 1850
                ),
                VideoEntity(
                    id = "v_2",
                    creatorId = "u_current",
                    creatorName = "Aarav Sharma",
                    creatorHandle = "aarav_creatives",
                    creatorAvatar = "avatar_aarav",
                    caption = "Cinematic phone lighting trick with flash & color gel paper! ⚡ Try this on your next reel! #tech #creatorhacks #cinematic #zing",
                    soundTitle = "Midnight Chill Wave - Aarav Mix",
                    videoUri = "",
                    posterResName = "",
                    bgGradientStart = 0xFF0D1B2A,
                    bgGradientEnd = 0xFF1B263B,
                    likesCount = 89200,
                    commentsCount = 1240,
                    sharesCount = 14200,
                    viewsCount = 520000,
                    isLiked = true,
                    isSaved = false,
                    timestamp = System.currentTimeMillis() - 3600000 * 12,
                    tags = "tech,creatorhacks,cinematic,zing",
                    category = "Tech",
                    adRevenue = 280.00,
                    giftCoins = 940
                ),
                VideoEntity(
                    id = "v_3",
                    creatorId = "u_ananya",
                    creatorName = "Ananya Sen",
                    creatorHandle = "chef_ananya",
                    creatorAvatar = "avatar_ananya",
                    caption = "5-minute spicy Cheesy Butter Garlic Noodles that went viral on Zing! 🧀🍜 Recipe in comments! #foodie #streetfood #quickrecipe #zingeats",
                    soundTitle = "Lo-Fi Kitchen Chill - Ananya Audio",
                    videoUri = "",
                    posterResName = "",
                    bgGradientStart = 0xFF2E0C0F,
                    bgGradientEnd = 0xFF591C1F,
                    likesCount = 210500,
                    commentsCount = 4890,
                    sharesCount = 39000,
                    viewsCount = 1240000,
                    isLiked = false,
                    isSaved = true,
                    timestamp = System.currentTimeMillis() - 3600000 * 24,
                    tags = "foodie,streetfood,quickrecipe,zingeats",
                    category = "Food",
                    adRevenue = 490.80,
                    giftCoins = 3100
                ),
                VideoEntity(
                    id = "v_4",
                    creatorId = "u_rohit",
                    creatorName = "Rohit Verma",
                    creatorHandle = "tech_rohit",
                    creatorAvatar = "avatar_rohit",
                    caption = "Top 3 hidden Android gestures that will save you hours every week! 📱 Number 2 blew my mind! #techtips #androidhacks #viral #productivity",
                    soundTitle = "Synthwave Speed - Tech Rohit",
                    videoUri = "",
                    posterResName = "",
                    bgGradientStart = 0xFF0B192C,
                    bgGradientEnd = 0xFF1E3E62,
                    likesCount = 65400,
                    commentsCount = 920,
                    sharesCount = 8100,
                    viewsCount = 410000,
                    isLiked = false,
                    isSaved = false,
                    timestamp = System.currentTimeMillis() - 3600000 * 48,
                    tags = "techtips,androidhacks,viral,productivity",
                    category = "Tech",
                    adRevenue = 195.40,
                    giftCoins = 620
                )
            )
            dao.insertVideos(videos)

            // Seed Comments
            val comments = listOf(
                CommentEntity(
                    id = "c_1",
                    videoId = "v_1",
                    userId = "u_current",
                    userName = "Aarav Sharma",
                    userAvatar = "avatar_aarav",
                    text = "That reverse spin at 0:08 was insane!! 🔥💯",
                    likesCount = 342,
                    isLiked = true
                ),
                CommentEntity(
                    id = "c_2",
                    videoId = "v_1",
                    userId = "u_rohit",
                    userName = "Rohit Verma",
                    userAvatar = "avatar_rohit",
                    text = "The neon stage lighting paired with the beat drop is pure art 🚀",
                    likesCount = 189,
                    isLiked = false
                ),
                CommentEntity(
                    id = "c_3",
                    videoId = "v_2",
                    userId = "u_ananya",
                    userName = "Ananya Sen",
                    userAvatar = "avatar_ananya",
                    text = "Gonna try this lighting trick for my next cooking reel! Super helpful 🙏",
                    likesCount = 94,
                    isLiked = false
                )
            )
            dao.insertComments(comments)

            // Seed Notifications
            val notifications = listOf(
                NotificationEntity(
                    id = "n_1",
                    userId = "u_current",
                    actorName = "Sneha Patel",
                    actorAvatar = "avatar_sneha",
                    title = "New Gift Received! 🎁",
                    message = "sent you a Super Rocket gift (500 Coins) on your latest reel!",
                    type = "GIFT",
                    timestamp = System.currentTimeMillis() - 1800000,
                    isRead = false
                ),
                NotificationEntity(
                    id = "n_2",
                    userId = "u_current",
                    actorName = "Zing Creator Rewards",
                    actorAvatar = "ic_launcher_zing",
                    title = "Monetization Payout Processed 💰",
                    message = "Your ad revenue share of ₹15,000.00 has been transferred to your UPI account.",
                    type = "MONETIZATION",
                    timestamp = System.currentTimeMillis() - 3600000 * 6,
                    isRead = false
                ),
                NotificationEntity(
                    id = "n_3",
                    userId = "u_current",
                    actorName = "Rohit Verma",
                    actorAvatar = "avatar_rohit",
                    title = "Started following you",
                    message = "started following your creative journey.",
                    type = "FOLLOW",
                    timestamp = System.currentTimeMillis() - 3600000 * 18,
                    isRead = true
                )
            )
            dao.insertNotifications(notifications)

            // Seed Payouts
            val payouts = listOf(
                PayoutEntity(
                    id = "p_1",
                    userId = "u_current",
                    amount = 15000.0,
                    payoutMethod = "UPI",
                    accountDetails = "aarav@oksbi",
                    status = "COMPLETED",
                    requestDate = System.currentTimeMillis() - 86400000L * 3
                ),
                PayoutEntity(
                    id = "p_2",
                    userId = "u_current",
                    amount = 12500.0,
                    payoutMethod = "Bank Transfer",
                    accountDetails = "HDFC Bank ****4892",
                    status = "COMPLETED",
                    requestDate = System.currentTimeMillis() - 86400000L * 10
                ),
                PayoutEntity(
                    id = "p_3",
                    userId = "u_current",
                    amount = 8250.0,
                    payoutMethod = "UPI",
                    accountDetails = "aarav@oksbi",
                    status = "PROCESSING",
                    requestDate = System.currentTimeMillis() - 86400000L * 1
                )
            )
            payouts.forEach { dao.insertPayout(it) }

            // Seed Reports (for Admin test)
            val reports = listOf(
                ReportEntity(
                    id = "r_1",
                    reporterId = "u_sneha",
                    targetVideoId = "v_4",
                    targetUserId = "u_rohit",
                    targetCaption = "Top 3 hidden Android gestures...",
                    reason = "Misleading Clickbait",
                    status = "PENDING_REVIEW",
                    timestamp = System.currentTimeMillis() - 7200000
                )
            )
            reports.forEach { dao.insertReport(it) }
        }
    }

    // Video Operations
    fun getVideosByCreator(creatorId: String): Flow<List<VideoEntity>> = dao.getVideosByCreator(creatorId)
    fun searchVideos(query: String): Flow<List<VideoEntity>> = dao.searchVideos(query)
    fun getComments(videoId: String): Flow<List<CommentEntity>> = dao.getCommentsForVideo(videoId)

    suspend fun insertVideo(video: VideoEntity) = dao.insertVideo(video)
    suspend fun toggleLike(video: VideoEntity) {
        val newIsLiked = !video.isLiked
        val newCount = if (newIsLiked) video.likesCount + 1 else maxOf(0, video.likesCount - 1)
        dao.updateLike(video.id, newIsLiked, newCount)
    }

    suspend fun addComment(videoId: String, user: UserEntity, text: String) {
        val comment = CommentEntity(
            id = "c_${System.currentTimeMillis()}",
            videoId = videoId,
            userId = user.id,
            userName = user.displayName,
            userAvatar = user.avatarUrl,
            text = text,
            likesCount = 0,
            isLiked = false,
            timestamp = System.currentTimeMillis()
        )
        dao.insertComment(comment)
        dao.incrementCommentsCount(videoId)
    }

    suspend fun toggleCommentLike(comment: CommentEntity) {
        val newIsLiked = !comment.isLiked
        val newCount = if (newIsLiked) comment.likesCount + 1 else maxOf(0, comment.likesCount - 1)
        dao.updateCommentLike(comment.id, newIsLiked, newCount)
    }

    suspend fun sendGift(videoId: String, senderId: String, coins: Int, giftName: String) {
        val revenue = coins * 0.15 // 15% revenue share to creator
        dao.rewardVideo(videoId, coins, revenue)
        dao.deductCoins(senderId, coins)
    }

    suspend fun toggleFollow(creatorId: String, currentStatus: Boolean) {
        val newStatus = !currentStatus
        val delta = if (newStatus) 1 else -1
        dao.updateFollowStatus(creatorId, newStatus, delta)
    }

    suspend fun blockUser(userId: String, isBlocked: Boolean) {
        dao.updateUserBlocked(userId, isBlocked)
    }

    suspend fun reportContent(reporterId: String, videoId: String?, userId: String?, caption: String, reason: String) {
        val report = ReportEntity(
            id = "r_${System.currentTimeMillis()}",
            reporterId = reporterId,
            targetVideoId = videoId,
            targetUserId = userId,
            targetCaption = caption,
            reason = reason,
            status = "PENDING_REVIEW",
            timestamp = System.currentTimeMillis()
        )
        dao.insertReport(report)
        videoId?.let { dao.markVideoReported(it) }
    }

    suspend fun requestPayout(userId: String, amount: Double, method: String, accountDetails: String) {
        val payout = PayoutEntity(
            id = "p_${System.currentTimeMillis()}",
            userId = userId,
            amount = amount,
            payoutMethod = method,
            accountDetails = accountDetails,
            status = "PENDING",
            requestDate = System.currentTimeMillis()
        )
        dao.insertPayout(payout)
    }

    // Admin Operations
    suspend fun resolveReport(reportId: String, action: String) {
        dao.updateReportStatus(reportId, action)
    }

    suspend fun setVideoTakeDown(videoId: String, isTakenDown: Boolean) {
        dao.setVideoTakeDown(videoId, isTakenDown)
    }

    suspend fun updatePayoutStatus(payoutId: String, status: String) {
        dao.updatePayoutStatus(payoutId, status)
    }

    suspend fun updateUser(user: UserEntity) {
        dao.updateUser(user)
    }

    suspend fun markAllNotificationsRead() {
        dao.markAllNotificationsRead()
    }
}
