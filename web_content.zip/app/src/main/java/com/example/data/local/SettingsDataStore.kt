package com.example.data.local

import android.content.Context
import android.provider.Settings
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.BrowserViewMode
import com.example.data.model.SortField
import com.example.ui.theme.AccentPreset
import com.example.ui.theme.AnimationMode
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "my_files_settings")

data class UserSettingsState(
    val onboardingCompleted: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val amoledBlack: Boolean = false,
    val accentPreset: AccentPreset = AccentPreset.BLUE,
    val dynamicSeedArgb: Int = 0xFF0381FE.toInt(),
    val animationMode: AnimationMode = AnimationMode.MEDIUM,
    val reducedMotionSuggested: Boolean = false,
    val viewMode: BrowserViewMode = BrowserViewMode.LIST,
    val sortField: SortField = SortField.DATE,
    val sortAscending: Boolean = false,
    val showHiddenFiles: Boolean = false,
    val showFileExtensions: Boolean = true,
    val autoEmptyTrash30Days: Boolean = true,
    val languageLabel: String = "English (United States)"
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val AMOLED_BLACK = booleanPreferencesKey("amoled_black")
        val ACCENT_PRESET = stringPreferencesKey("accent_preset")
        val DYNAMIC_SEED_ARGB = intPreferencesKey("dynamic_seed_argb")
        val ANIMATION_MODE = stringPreferencesKey("animation_mode")
        val VIEW_MODE = stringPreferencesKey("view_mode")
        val SORT_FIELD = stringPreferencesKey("sort_field")
        val SORT_ASCENDING = booleanPreferencesKey("sort_ascending")
        val SHOW_HIDDEN = booleanPreferencesKey("show_hidden_files")
        val SHOW_EXTENSIONS = booleanPreferencesKey("show_file_extensions")
        val AUTO_EMPTY_TRASH = booleanPreferencesKey("auto_empty_trash_30d")
        val LANGUAGE = stringPreferencesKey("language_label")
    }

    private fun isSystemReducedMotion(): Boolean {
        return try {
            val scale = Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1f
            )
            scale == 0f
        } catch (_: Exception) {
            false
        }
    }

    val settingsFlow: Flow<UserSettingsState> = context.dataStore.data.map { prefs ->
        val sysReduced = isSystemReducedMotion()
        val storedAnim = prefs[Keys.ANIMATION_MODE]?.let {
            runCatching { AnimationMode.valueOf(it) }.getOrNull()
        } ?: if (sysReduced) AnimationMode.OFF else AnimationMode.MEDIUM

        UserSettingsState(
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            themeMode = prefs[Keys.THEME_MODE]?.let {
                runCatching { ThemeMode.valueOf(it) }.getOrNull()
            } ?: ThemeMode.SYSTEM,
            amoledBlack = prefs[Keys.AMOLED_BLACK] ?: false,
            accentPreset = prefs[Keys.ACCENT_PRESET]?.let {
                runCatching { AccentPreset.valueOf(it) }.getOrNull()
            } ?: AccentPreset.BLUE,
            dynamicSeedArgb = prefs[Keys.DYNAMIC_SEED_ARGB] ?: 0xFF0381FE.toInt(),
            animationMode = storedAnim,
            reducedMotionSuggested = sysReduced,
            viewMode = prefs[Keys.VIEW_MODE]?.let {
                runCatching { BrowserViewMode.valueOf(it) }.getOrNull()
            } ?: BrowserViewMode.LIST,
            sortField = prefs[Keys.SORT_FIELD]?.let {
                runCatching { SortField.valueOf(it) }.getOrNull()
            } ?: SortField.DATE,
            sortAscending = prefs[Keys.SORT_ASCENDING] ?: false,
            showHiddenFiles = prefs[Keys.SHOW_HIDDEN] ?: false,
            showFileExtensions = prefs[Keys.SHOW_EXTENSIONS] ?: true,
            autoEmptyTrash30Days = prefs[Keys.AUTO_EMPTY_TRASH] ?: true,
            languageLabel = prefs[Keys.LANGUAGE] ?: "English (United States)"
        )
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setAmoledBlack(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AMOLED_BLACK] = enabled }
    }

    suspend fun setAccentPreset(preset: AccentPreset) {
        context.dataStore.edit { it[Keys.ACCENT_PRESET] = preset.name }
    }

    suspend fun setDynamicSeedArgb(argb: Int) {
        context.dataStore.edit {
            it[Keys.DYNAMIC_SEED_ARGB] = argb
            it[Keys.ACCENT_PRESET] = AccentPreset.DYNAMIC_IMAGE.name
        }
    }

    suspend fun setAnimationMode(mode: AnimationMode) {
        context.dataStore.edit { it[Keys.ANIMATION_MODE] = mode.name }
    }

    suspend fun setViewMode(mode: BrowserViewMode) {
        context.dataStore.edit { it[Keys.VIEW_MODE] = mode.name }
    }

    suspend fun setSort(field: SortField, ascending: Boolean) {
        context.dataStore.edit {
            it[Keys.SORT_FIELD] = field.name
            it[Keys.SORT_ASCENDING] = ascending
        }
    }

    suspend fun setShowHiddenFiles(show: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_HIDDEN] = show }
    }

    suspend fun setShowFileExtensions(show: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_EXTENSIONS] = show }
    }

    suspend fun setAutoEmptyTrash(enabled: Boolean) {
        context.dataStore.edit { it[Keys.AUTO_EMPTY_TRASH] = enabled }
    }

    suspend fun setLanguage(label: String) {
        context.dataStore.edit { it[Keys.LANGUAGE] = label }
    }
}
