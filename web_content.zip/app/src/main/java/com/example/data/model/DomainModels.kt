package com.example.data.model

enum class GenderOption(val key: String, val label: String) {
    GIRL("girl", "Girl"),
    BOY("boy", "Boy"),
    NON_BINARY("non_binary", "Non-binary / Other")
}

enum class SexualityOption(val key: String, val label: String) {
    STRAIGHT("straight", "Straight"),
    GAY("gay", "Gay"),
    LESBIAN("lesbian", "Lesbian"),
    BISEXUAL("bisexual", "Bisexual"),
    PANSEXUAL("pansexual", "Pansexual"),
    ASEXUAL("asexual", "Asexual"),
    QUESTIONING("questioning", "Questioning"),
    PREFER_NOT_TO_SAY("prefer_not", "Prefer not to say")
}

enum class AppLanguage(val code: String, val nativeName: String, val flagLabel: String) {
    EN("en", "English", "EN"),
    ZU("zu", "isiZulu", "ZU"),
    XH("xh", "isiXhosa", "XH"),
    AF("af", "Afrikaans", "AF"),
    NSO("nso", "Sepedi", "NSO"),
    TN("tn", "Setswana", "TN"),
    ST("st", "Sesotho", "ST"),
    TS("ts", "Xitsonga", "TS"),
    SS("ss", "siSwati", "SS"),
    VE("ve", "Tshivenda", "VE"),
    NR("nr", "isiNdebele", "NR"),
    ES("es", "Español", "ES"),
    FR("fr", "Français", "FR"),
    PT("pt", "Português", "PT"),
    SW("sw", "Kiswahili", "SW"),
    AR("ar", "العربية", "AR"),
    HI("hi", "हिन्दी", "HI"),
    ZH("zh", "中文", "ZH"),
    JA("ja", "日本語", "JA");

    companion object {
        fun fromCode(code: String): AppLanguage =
            entries.firstOrNull { it.code == code } ?: EN
    }
}

enum class CareCategory(
    val key: String,
    val defaultHour: Int,
    val defaultMinute: Int,
    val dailyTarget: Int,
    val unit: String
) {
    WAKE_UP("wake_up", 6, 30, 1, "check"),
    DRINK_WATER("drink_water", 9, 0, 8, "glasses"),
    EAT_MEAL("eat_meal", 12, 30, 3, "meals"),
    PEE("pee", 11, 0, 5, "breaks"),
    POOP("poop", 8, 30, 1, "check"),
    BATH("bath", 19, 30, 1, "shower"),
    EXERCISE("exercise", 16, 30, 30, "mins"),
    FRESH_AIR("fresh_air", 15, 0, 15, "mins"),
    SLEEP("sleep", 21, 30, 1, "wind-down");

    companion object {
        fun fromKey(key: String): CareCategory =
            entries.firstOrNull { it.key == key } ?: DRINK_WATER
    }
}

enum class MoodType(val key: String, val label: String) {
    HAPPY("happy", "Happy"),
    CALM("calm", "Calm"),
    ANXIOUS("anxious", "Anxious"),
    SAD("sad", "Sad"),
    OVERWHELMED("overwhelmed", "Overwhelmed"),
    ENERGIZED("energized", "Energized"),
    LOVED("loved", "Loved");

    companion object {
        fun fromKey(key: String): MoodType =
            entries.firstOrNull { it.key == key } ?: CALM
    }
}

const val SUBSCRIPTION_AIRTIME_NUMBER = "0717127044"

enum class SubscriptionPlan(val id: String, val label: String, val priceLabel: String, val durationDays: Int) {
    WEEKLY("weekly", "Weekly Pass", "R5 / 7 days", 7),
    MONTHLY("monthly", "Monthly Plus", "R15 / 30 days", 30)
}

data class UserProfile(
    val name: String = "",
    val age: Int = 16,
    val ageVerified: Boolean = false,
    val countryCode: String = "ZA",
    val idNumber: String = "",
    val birthday: String = "",
    val isStudent: Boolean = true,
    val gradeLevel: String = "Grade 10",
    val locationText: String = "",
    val phoneNumber: String = "",
    val profilePhotoPath: String = "",
    val humanVerified: Boolean = false,
    val emailOtpVerified: Boolean = false,
    val isLoggedIn: Boolean = false,
    val gender: GenderOption = GenderOption.GIRL,
    val sexuality: SexualityOption = SexualityOption.PREFER_NOT_TO_SAY,
    val backupEmail: String = "",
    val language: AppLanguage = AppLanguage.EN,
    val isDataFreeMode: Boolean = false,
    val biometricLockEnabled: Boolean = false,
    val pinCode: String = "",
    val sleepQuietModeActive: Boolean = false,
    val emergencyAuthorityNumber: String = "112",
    val bloodType: String = "O+",
    val allergies: String = "None listed",
    val medicalNotes: String = "",
    val lastPeriodEpochDay: Long = 0L,
    val cycleLengthDays: Int = 28,
    val onboardingCompleted: Boolean = false,
    val isSubscribed: Boolean = false,
    val subscriptionPlanId: String = "",
    val subscriptionMethod: String = "",
    val subscriptionReference: String = "",
    val subscriptionExpiresAtMillis: Long = 0L
) {
    val hasActiveSubscription: Boolean
        get() = isSubscribed && (subscriptionExpiresAtMillis == 0L || System.currentTimeMillis() < subscriptionExpiresAtMillis)
}

enum class AiResultType(val label: String, val badge: String) {
    EMOTIONAL_SUPPORT("Emotional Support", "Heart & Calm"),
    ACTION_PLAN("Smart Action Plan", "Step-by-Step"),
    PHONE_COMMAND("Phone Control", "Device Action"),
    MOTIVATION_VERSE("Motivation & Verse", "Daily Boost")
}

data class AiSpaceResult(
    val id: String,
    val prompt: String,
    val resultType: AiResultType,
    val title: String,
    val body: String,
    val actionTaken: String = "",
    val isDataLimited: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class HavenAward(
    val id: String,
    val title: String,
    val description: String,
    val points: Int,
    val unlocked: Boolean
)

data class ChatMessage(
    val id: String,
    val isFromUser: Boolean,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPlaceholderSample: Boolean = false
)

sealed interface PhoneCommandResult {
    data class Success(val feedback: String) : PhoneCommandResult
    data class NeedsPermission(val feedback: String, val actionHint: String) : PhoneCommandResult
    data class Info(val feedback: String) : PhoneCommandResult
}
