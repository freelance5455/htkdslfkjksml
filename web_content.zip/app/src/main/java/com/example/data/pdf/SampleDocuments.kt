package com.example.data.pdf

object SampleDocuments {

    const val TEXT_LITERATURE = """
En aquella aldea remota, el anciano boticario guardaba una pócima inmutable que desafiaba el paso de las eras. Los lugareños, sumidos en un constante letargo estacional, acudían a su botica buscando sosiego para sus tribulaciones cotidianas. A pesar de las vicisitudes del invierno más gélido, el boticario mantenía una ecuanimidad imperturbable frente a los rumores del pueblo. En sus cuadernos de anotaciones, redactaba largas disquisiciones sobre la naturaleza efímera del dolor y la dicha. Su mirada taciturna ocultaba una mente despierta que jamás sucumbió a la desidia ni al desasosiego.
"""

    const val TEXT_SCIENCE = """
La exploración astrofísica moderna se enfrenta al enigma de la singularidad en los confines del cosmos. Cuando una estrella masiva colapsa, la atracción gravitacional sobrepasa cualquier barrera conocida, generando un horizonte de sucesos inexpugnable. Fenómenos efímeros como los estallidos de rayos gamma despiden radiación con una intensidad colosal, alterando la magnetosfera planetaria. El perihelio de los cometas más erráticos revela perturbaciones que desvelan la presencia de masa oscura en los márgenes de nuestra galaxia, desafiando postulados de la física relativista.
"""

    const val TEXT_PHILOSOPHY = """
El filósofo estoico sostenía que la verdadera libertad reside en alcanzar la ataraxia, ese estado de imperturbabilidad donde los temores infundados se disipan. Quien vive esclavo de vanas quimeras sucumbe a una vorágine de pasiones perniciosas. Al discernir con lucidez entre lo que depende de nuestro arbitrio y los azares del destino fortuito, el ser humano conquista una serenidad inexpugnable. No son los hechos exteriores los que turban el alma, sino los juicios precipitados y la soberbia que nos ciega.
"""

    data class SampleDocInfo(
        val title: String,
        val subtitle: String,
        val category: String,
        val text: String
    )

    val SAMPLES = listOf(
        SampleDocInfo(
            title = "Crónicas del Boticario Solitario",
            subtitle = "Literatura clásica y narrativa descriptiva",
            category = "Literatura",
            text = TEXT_LITERATURE.trim()
        ),
        SampleDocInfo(
            title = "Misterios del Cosmos y Gravedad",
            subtitle = "Astrofísica, espacio y relatividad",
            category = "Ciencia",
            text = TEXT_SCIENCE.trim()
        ),
        SampleDocInfo(
            title = "Manual de Serenidad Estoica",
            subtitle = "Filosofía clásica y fortaleza mental",
            category = "Filosofía",
            text = TEXT_PHILOSOPHY.trim()
        )
    )
}
