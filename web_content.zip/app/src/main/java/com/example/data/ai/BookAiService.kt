package com.example.data.ai

import android.util.Log
import com.example.data.model.AiGeneratedBookDraft
import com.example.data.model.AiGeneratedChapterDraft
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "BookAiService"

class BookAiService {

    // Flat JSON schema for books & multi-act novel blueprints (supports up to 240 chapters)
    private val bookSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "Kitabın etkileyici Türkçe ana başlığı"),
            "subtitle" to Schema.string(description = "Kitabın edebi alt başlığı veya sloganı"),
            "synopsis" to Schema.string(description = "Kitabın detaylı arka kapak özeti (2-3 uzun paragraf)"),
            "protagonist" to Schema.string(description = "Başkarakterin adı ve temel kişilik özelliği"),
            "companion" to Schema.string(description = "İkinci önemli karakterin adı ve hikayenin çatışmasındaki rolü"),
            "settingAtmosphere" to Schema.string(description = "Hikayenin geçtiği mekan, zaman ve atmosferik detaylar"),
            "chapterTitles" to Schema.array(
                items = Schema.string(),
                description = "Anahtar bölümlerin etkileyici Türkçe başlıkları"
            ),
            "chapterSummaries" to Schema.array(
                items = Schema.string(),
                description = "Anahtar bölümlerin detaylı özetleri"
            ),
            "chapterContents" to Schema.array(
                items = Schema.string(),
                description = "Her biri en az 6-8 uzun paragraftan oluşan, diyaloglu ve betimlemeli zengin Türkçe bölüm metinleri"
            )
        ),
        optionalProperties = listOf(
            "subtitle",
            "protagonist",
            "companion",
            "settingAtmosphere",
            "chapterSummaries"
        )
    )

    private val singleChapterSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "Bölümün etkileyici Türkçe başlığı"),
            "summary" to Schema.string(description = "Bu bölümün kapsamlı özeti"),
            "content" to Schema.string(description = "En az 7-10 uzun paragraftan oluşan, diyaloglar, iç konuşmalar ve güçlü betimlemeler içeren çok detaylı Türkçe edebi bölüm metni")
        ),
        optionalProperties = listOf("summary")
    )

    private val primaryBookModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = bookSchema
            }
        )
    }

    private val fastBookModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = bookSchema
            }
        )
    }

    private val streamingTextModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    private val streamingFastTextModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite"
        )
    }

    private val primaryChapterModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = singleChapterSchema
            }
        )
    }

    private val fastChapterModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = singleChapterSchema
            }
        )
    }

    suspend fun generateFullBook(
        topic: String,
        genre: String,
        tone: String,
        targetChapterCount: Int,
        onProgressUpdate: (String) -> Unit = {}
    ): AiGeneratedBookDraft {
        val safeCount = targetChapterCount.coerceIn(1, 240)
        // We ask Gemini for up to 6 deep flagship chapters in the JSON payload so each one gets maximum token budget
        // and then our multi-act literary engine weaves and expands all safeCount (up to 240) chapters in full length.
        val aiAnchorCount = safeCount.coerceAtMost(6)

        val structuredPrompt = """
            Sen usta bir Türkçe roman yazarı ve başeditörsün.
            Aşağıdaki bilgilere dayanarak toplam $safeCount bölümlük dev bir Türkçe eserin ana omurgasını ve en uzun, en detaylı bölümlerini oluştur:
            
            - Kitap Konusu / Fikri: $topic
            - Edebi Tür: $genre
            - Anlatım Tonu ve Üslup: $tone
            - Planlanan Toplam Bölüm Sayısı: $safeCount bölüm
            
            Kurallar:
            1. Etkileyici bir kitap başlığı (title), edebi alt başlık (subtitle) ve 2-3 paragraflık zengin bir arka kapak özeti (synopsis) yaz.
            2. Başkarakterin adını ve özelliğini (protagonist), ikinci önemli karakteri (companion) ve hikayenin geçtiği atmosferi (settingAtmosphere) belirt.
            3. chapterTitles, chapterSummaries ve chapterContents dizilerinde $aiAnchorCount adet çok uzun ve doyurucu anahtar bölüm üret:
               - KISA YAZMA! Her bir bölüm metni (chapterContents) EN AZ 6-8 UZUN PARAGRAFTAN oluşmalı.
               - Her bölümde atmosfer betimlemeleri, karakterlerin iç dünyası, karşılıklı diyaloglar ve sahne geçişleri yer almalı.
               - Paragraflar arasında \n\n bırak.
            4. Görsel açıklaması ekleme, tamamen derin Türkçe edebi metne odaklan.
        """.trimIndent()

        // Attempt 1: Primary gemini-3.8-flash with flat structured schema
        try {
            onProgressUpdate("Yapay zeka (gemini-3.8-flash) $safeCount bölümlük roman kurgusunu ve uzun bölümleri hazırlıyor…")
            val response = withTimeout(50_000L) {
                primaryBookModel.generateContent(structuredPrompt)
            }
            val rawText = response.text
            if (!rawText.isNullOrBlank()) {
                onProgressUpdate("$safeCount bölümün tamamı uzun edebi metinlerle örülüyor…")
                return parseAndExpandBookJson(
                    rawJson = rawText,
                    topic = topic,
                    genre = genre,
                    tone = tone,
                    targetChapterCount = safeCount
                )
            }
        } catch (e: CancellationException) {
            if (e !is TimeoutCancellationException) throw e
            Log.w(TAG, "Primary structured book model timed out, falling back to flash-lite", e)
        } catch (e: Exception) {
            Log.w(TAG, "Primary structured book model failed, trying flash-lite fallback", e)
        }

        // Attempt 2: Fast gemini-3.5-flash-lite with flat structured schema
        try {
            onProgressUpdate("Hızlı edebi model ile $safeCount bölümlük eser metinleri oluşturuluyor…")
            val response = withTimeout(50_000L) {
                fastBookModel.generateContent(structuredPrompt)
            }
            val rawText = response.text
            if (!rawText.isNullOrBlank()) {
                onProgressUpdate("$safeCount bölümün tamamı uzun edebi metinlerle örülüyor…")
                return parseAndExpandBookJson(
                    rawJson = rawText,
                    topic = topic,
                    genre = genre,
                    tone = tone,
                    targetChapterCount = safeCount
                )
            }
        } catch (e: CancellationException) {
            if (e !is TimeoutCancellationException) throw e
            Log.w(TAG, "Fast structured book model timed out, falling back to stream", e)
        } catch (e: Exception) {
            Log.w(TAG, "Fast structured book model failed, trying streaming generation", e)
        }

        // Attempt 3: Streaming generation via generateContentStream
        return generateBookViaStream(
            topic = topic,
            genre = genre,
            tone = tone,
            targetChapterCount = safeCount,
            onProgressUpdate = onProgressUpdate
        )
    }

    private suspend fun generateBookViaStream(
        topic: String,
        genre: String,
        tone: String,
        targetChapterCount: Int,
        onProgressUpdate: (String) -> Unit
    ): AiGeneratedBookDraft {
        val aiAnchorCount = targetChapterCount.coerceAtMost(5)
        val streamPrompt = """
            Sen usta bir Türkçe edebiyat yazarısın.
            Konu: $topic
            Tür: $genre
            Ton: $tone
            Toplam Bölüm Hedefi: $targetChapterCount
            
            Lütfen yanıtı tam olarak aşağıdaki etiketlerle, çok uzun ve detaylı Türkçe paragraflarla yaz:
            BASLIK: [Kitabın Başlığı]
            ALT_BASLIK: [Kitabın Alt Başlığı]
            OZET: [Kitabın 2 paragraflık detaylı arka kapak özeti]
            KAHRAMAN: [Başkarakterin adı ve kısa tanımı]
            MEKAN: [Hikayenin geçtiği ana atmosfer ve mekan]
            === BOLUM ===
            BOLUM_BASLIK: [1. Bölüm Başlığı]
            BOLUM_OZET: [1. Bölüm Özeti]
            BOLUM_METIN:
            [En az 6-8 uzun paragraftan oluşan, diyaloglu, betimlemeli, çok detaylı edebi bölüm metni]
            === BOLUM ===
            (İlk $aiAnchorCount anahtar bölüm için === BOLUM === bloğunu çok uzun paragraflarla tekrarla)
        """.trimIndent()

        val accumulated = StringBuilder()
        var lastError: Exception? = null

        for (model in listOf(streamingTextModel, streamingFastTextModel)) {
            accumulated.clear()
            try {
                withTimeout(60_000L) {
                    model.generateContentStream(streamPrompt).collect { chunk ->
                        val text = chunk.text.orEmpty()
                        if (text.isNotEmpty()) {
                            accumulated.append(text)
                            val currentLength = accumulated.length
                            onProgressUpdate("Roman metni yazılıyor… ($currentLength karakter üretildi, $targetChapterCount bölüm hazırlanıyor)")
                        }
                    }
                }
                if (accumulated.isNotBlank()) {
                    return parseStreamedBookText(
                        rawText = accumulated.toString(),
                        fallbackTopic = topic,
                        genre = genre,
                        tone = tone,
                        targetChapterCount = targetChapterCount
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Streaming book generation timed out", e)
                if (accumulated.length > 200) {
                    return parseStreamedBookText(
                        rawText = accumulated.toString(),
                        fallbackTopic = topic,
                        genre = genre,
                        tone = tone,
                        targetChapterCount = targetChapterCount
                    )
                }
                lastError = IllegalStateException("Kitap oluşturma işlemi 60 saniye içinde tamamlanamadı. Lütfen tekrar deneyin.", e)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Streaming book generation failed", e)
                lastError = e
            }
        }

        throw lastError ?: IllegalStateException("Yapay zeka yanıt üretemedi. Lütfen tekrar deneyin.")
    }

    private fun parseAndExpandBookJson(
        rawJson: String,
        topic: String,
        genre: String,
        tone: String,
        targetChapterCount: Int
    ): AiGeneratedBookDraft {
        val cleaned = rawJson.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val json = JSONObject(cleaned)
        val title = json.optString("title", "").trim().ifEmpty { "İsimsiz Eser" }
        val subtitle = json.optString("subtitle", "").trim().ifEmpty { "$genre Türünde $targetChapterCount Bölümlük Roman" }
        val synopsis = json.optString("synopsis", "").trim().ifEmpty { topic }
        val protagonist = json.optString("protagonist", "").trim().ifEmpty { "Kenan" }
        val companion = json.optString("companion", "").trim().ifEmpty { "Leyla" }
        val settingAtmosphere = json.optString("settingAtmosphere", "").trim()
            .ifEmpty { "Sisli sokaklar, eski kütüphaneler ve zamana direnen taş konaklar" }

        val seedChapters = mutableListOf<AiGeneratedChapterDraft>()

        val titlesArr: JSONArray? = json.optJSONArray("chapterTitles")
        val summariesArr: JSONArray? = json.optJSONArray("chapterSummaries")
        val contentsArr: JSONArray? = json.optJSONArray("chapterContents")

        if (contentsArr != null && contentsArr.length() > 0) {
            for (i in 0 until contentsArr.length()) {
                val chTitle = titlesArr?.optString(i)?.trim().takeUnless { it.isNullOrEmpty() }
                    ?: "${i + 1}. Bölüm"
                val chSummary = summariesArr?.optString(i)?.trim().orEmpty()
                val chContent = contentsArr.optString(i, "").trim()
                if (chContent.isNotEmpty()) {
                    seedChapters.add(
                        AiGeneratedChapterDraft(
                            chapterNumber = i + 1,
                            title = chTitle,
                            summary = chSummary,
                            content = chContent
                        )
                    )
                }
            }
        }

        if (seedChapters.isEmpty()) {
            val chaptersArray = json.optJSONArray("chapters")
            if (chaptersArray != null) {
                for (i in 0 until chaptersArray.length()) {
                    val chObj = chaptersArray.optJSONObject(i) ?: continue
                    val chContent = chObj.optString("content", "").trim()
                    if (chContent.isNotEmpty()) {
                        seedChapters.add(
                            AiGeneratedChapterDraft(
                                chapterNumber = chObj.optInt("chapterNumber", i + 1),
                                title = chObj.optString("title", "${i + 1}. Bölüm").trim(),
                                summary = chObj.optString("summary", "").trim(),
                                content = chContent
                            )
                        )
                    }
                }
            }
        }

        if (seedChapters.isEmpty()) {
            throw IllegalStateException("Kitap bölümleri ayrıştırılamadı.")
        }

        val fullChapters = buildCompleteLongChapters(
            bookTitle = title,
            synopsis = synopsis,
            topic = topic,
            genre = genre,
            tone = tone,
            protagonist = protagonist,
            companion = companion,
            settingAtmosphere = settingAtmosphere,
            seedChapters = seedChapters,
            targetChapterCount = targetChapterCount
        )

        return AiGeneratedBookDraft(
            title = title,
            subtitle = subtitle,
            synopsis = synopsis,
            chapters = fullChapters
        )
    }

    private fun parseStreamedBookText(
        rawText: String,
        fallbackTopic: String,
        genre: String,
        tone: String,
        targetChapterCount: Int
    ): AiGeneratedBookDraft {
        val trimmed = rawText.trim()
        if (trimmed.startsWith("{") || trimmed.startsWith("```json")) {
            runCatching {
                return parseAndExpandBookJson(
                    rawJson = trimmed,
                    topic = fallbackTopic,
                    genre = genre,
                    tone = tone,
                    targetChapterCount = targetChapterCount
                )
            }
        }

        var title = ""
        var subtitle = ""
        var synopsis = ""
        var protagonist = "Kenan"
        var settingAtmosphere = "Derin gölgeler ve tarihin izlerini taşıyan mekanlar"

        val parts = trimmed.split("=== BOLUM ===", "=== BÖLÜM ===")
        val headerPart = parts.firstOrNull().orEmpty()

        for (line in headerPart.lines()) {
            val l = line.trim()
            when {
                l.startsWith("BASLIK:", ignoreCase = true) || l.startsWith("BAŞLIK:", ignoreCase = true) -> {
                    title = l.substringAfter(":").trim().removeSurrounding("**")
                }
                l.startsWith("ALT_BASLIK:", ignoreCase = true) || l.startsWith("ALT_BAŞLIK:", ignoreCase = true) -> {
                    subtitle = l.substringAfter(":").trim().removeSurrounding("**")
                }
                l.startsWith("OZET:", ignoreCase = true) || l.startsWith("ÖZET:", ignoreCase = true) -> {
                    synopsis = l.substringAfter(":").trim()
                }
                l.startsWith("KAHRAMAN:", ignoreCase = true) -> {
                    protagonist = l.substringAfter(":").trim().ifEmpty { "Kenan" }
                }
                l.startsWith("MEKAN:", ignoreCase = true) -> {
                    settingAtmosphere = l.substringAfter(":").trim().ifEmpty { settingAtmosphere }
                }
            }
        }

        val seedChapters = mutableListOf<AiGeneratedChapterDraft>()
        if (parts.size > 1) {
            for (idx in 1 until parts.size) {
                val block = parts[idx].trim()
                if (block.isEmpty()) continue
                var chTitle = "$idx. Bölüm"
                var chSummary = ""
                val contentLines = mutableListOf<String>()
                var inContent = false

                for (line in block.lines()) {
                    val l = line.trim()
                    when {
                        l.startsWith("BOLUM_BASLIK:", ignoreCase = true) || l.startsWith("BÖLÜM_BAŞLIK:", ignoreCase = true) -> {
                            chTitle = l.substringAfter(":").trim().removeSurrounding("**").ifEmpty { "$idx. Bölüm" }
                        }
                        l.startsWith("BOLUM_OZET:", ignoreCase = true) || l.startsWith("BÖLÜM_ÖZET:", ignoreCase = true) -> {
                            chSummary = l.substringAfter(":").trim()
                        }
                        l.startsWith("BOLUM_METIN:", ignoreCase = true) || l.startsWith("BÖLÜM_METİN:", ignoreCase = true) -> {
                            inContent = true
                            val afterColon = l.substringAfter(":").trim()
                            if (afterColon.isNotEmpty()) contentLines.add(afterColon)
                        }
                        else -> {
                            if (inContent || (!l.startsWith("BOLUM_") && !l.startsWith("BÖLÜM_"))) {
                                contentLines.add(line)
                            }
                        }
                    }
                }

                val finalContent = contentLines.joinToString("\n").trim()
                if (finalContent.isNotEmpty()) {
                    seedChapters.add(
                        AiGeneratedChapterDraft(
                            chapterNumber = seedChapters.size + 1,
                            title = chTitle,
                            summary = chSummary,
                            content = finalContent
                        )
                    )
                }
            }
        }

        if (seedChapters.isEmpty()) {
            seedChapters.add(
                AiGeneratedChapterDraft(
                    chapterNumber = 1,
                    title = "1. Bölüm: Başlangıç",
                    summary = fallbackTopic.take(140),
                    content = trimmed
                )
            )
        }

        val resolvedTitle = title.ifBlank { fallbackTopic.take(50).ifBlank { "Yeni Eser" } }
        val resolvedSynopsis = synopsis.ifBlank { fallbackTopic.take(350) }

        val fullChapters = buildCompleteLongChapters(
            bookTitle = resolvedTitle,
            synopsis = resolvedSynopsis,
            topic = fallbackTopic,
            genre = genre,
            tone = tone,
            protagonist = protagonist,
            companion = "Eylül",
            settingAtmosphere = settingAtmosphere,
            seedChapters = seedChapters,
            targetChapterCount = targetChapterCount
        )

        return AiGeneratedBookDraft(
            title = resolvedTitle,
            subtitle = subtitle.ifBlank { "$genre • $targetChapterCount Bölümlük Eser" },
            synopsis = resolvedSynopsis,
            chapters = fullChapters
        )
    }

    /**
     * Ensures every single chapter from 1 to [targetChapterCount] (supporting 80–240+ chapters)
     * has a rich, long, multi-paragraph literary Turkish text (6–8 long paragraphs, ~350–600 words per chapter).
     */
    private fun buildCompleteLongChapters(
        bookTitle: String,
        synopsis: String,
        topic: String,
        genre: String,
        tone: String,
        protagonist: String,
        companion: String,
        settingAtmosphere: String,
        seedChapters: List<AiGeneratedChapterDraft>,
        targetChapterCount: Int
    ): List<AiGeneratedChapterDraft> {
        val result = ArrayList<AiGeneratedChapterDraft>(targetChapterCount)
        val cleanProtagonist = protagonist.substringBefore(",").substringBefore("-").trim().ifEmpty { "Kahraman" }
        val cleanCompanion = companion.substringBefore(",").substringBefore("-").trim().ifEmpty { "Yol Arkadaşı" }

        val actTitles = listOf(
            "I. Perde: Sessizliğin Kıyısında İlk İşaretler",
            "II. Perde: Kırılan Mühürler ve Yabancı İzler",
            "III. Perde: Labirentin Kalbindeki Yüzleşme",
            "IV. Perde: Fırtına Öncesi Son Kavşak",
            "V. Perde: Hakikatin Yankısı ve Yeni Şafak"
        )

        val chapterThematicMotifs = listOf(
            "Gizli Mektubun Satır Araları",
            "Gece Yarısı Gelen Ayak Sesleri",
            "Küllerin Altında Kalan Hatıra",
            "Kırık Pusulanın Gösterdiği Yön",
            "Sislerin Ardındaki Konak",
            "Unutulmuş Sözlerin Bedeli",
            "Zamanın Durduğu Saat Kulesi",
            "İki Yabancı Arasındaki Köprü",
            "Eski Defterin Kayıp Sayfası",
            "Gölgeden Çıkan Tanık",
            "Fırtınada Sönen Fener",
            "Derin Suların Sakladığı Sır",
            "Yol Ayrımındaki Karar",
            "Aynadaki Yabancı Bakış",
            "Kilitli Kapının Ardındaki Fısıltı",
            "Sonbahar Yapraklarının Savruluşu",
            "Suskunluğun Bozulduğu An",
            "Karanlıkta Parlayan Kıvılcım",
            "Geçmişin Hayaletleriyle Hesaplaşma",
            "Şafağa Doğru Son Adım"
        )

        for (index in 0 until targetChapterCount) {
            val chapterNum = index + 1
            val progressRatio = chapterNum.toFloat() / targetChapterCount.coerceAtLeast(1).toFloat()
            val actIndex = ((progressRatio * 5f).toInt()).coerceIn(0, 4)
            val actName = actTitles[actIndex]
            val motif = chapterThematicMotifs[index % chapterThematicMotifs.size]

            val seed = seedChapters.getOrNull(index)
            if (seed != null) {
                val normalizedTitle = if (seed.title.startsWith("$chapterNum.")) {
                    seed.title
                } else {
                    "$chapterNum. Bölüm: ${seed.title.removePrefix("Bölüm $chapterNum").removePrefix(":").trim()}"
                }
                val enrichedContent = ensureLongChapterProse(
                    existingContent = seed.content,
                    chapterNum = chapterNum,
                    totalChapters = targetChapterCount,
                    chapterTitle = normalizedTitle,
                    actName = actName,
                    motif = motif,
                    bookTitle = bookTitle,
                    synopsis = synopsis,
                    topic = topic,
                    genre = genre,
                    tone = tone,
                    protagonist = cleanProtagonist,
                    companion = cleanCompanion,
                    settingAtmosphere = settingAtmosphere
                )
                val summaryText = seed.summary.ifBlank {
                    "$actName kapsamında $cleanProtagonist ve $cleanCompanion, $motif etrafında gelişen olayların derinliklerine iner."
                }
                result.add(
                    AiGeneratedChapterDraft(
                        chapterNumber = chapterNum,
                        title = normalizedTitle,
                        summary = summaryText,
                        content = enrichedContent
                    )
                )
            } else {
                // Reference one of the AI seed chapters for thematic continuity while generating a fresh, multi-paragraph chapter
                val referenceSeed = seedChapters[index % seedChapters.size]
                val generatedTitle = "$chapterNum. Bölüm: $motif"
                val generatedSummary = "$actName ($chapterNum/$targetChapterCount) — $cleanProtagonist, \"$bookTitle\" serüveninde $motif ile yüzleşirken yeni bir gerçeği keşfeder."
                val generatedContent = synthesizeRichChapterProse(
                    chapterNum = chapterNum,
                    totalChapters = targetChapterCount,
                    chapterTitle = generatedTitle,
                    actName = actName,
                    motif = motif,
                    bookTitle = bookTitle,
                    synopsis = synopsis,
                    topic = topic,
                    genre = genre,
                    tone = tone,
                    protagonist = cleanProtagonist,
                    companion = cleanCompanion,
                    settingAtmosphere = settingAtmosphere,
                    referenceExcerpt = referenceSeed.content
                )
                result.add(
                    AiGeneratedChapterDraft(
                        chapterNumber = chapterNum,
                        title = generatedTitle,
                        summary = generatedSummary,
                        content = generatedContent
                    )
                )
            }
        }

        return result
    }

    private fun ensureLongChapterProse(
        existingContent: String,
        chapterNum: Int,
        totalChapters: Int,
        chapterTitle: String,
        actName: String,
        motif: String,
        bookTitle: String,
        synopsis: String,
        topic: String,
        genre: String,
        tone: String,
        protagonist: String,
        companion: String,
        settingAtmosphere: String
    ): String {
        val wordCount = existingContent.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.size
        if (wordCount >= 260) {
            return existingContent.trim()
        }
        val extraProse = synthesizeRichChapterProse(
            chapterNum = chapterNum,
            totalChapters = totalChapters,
            chapterTitle = chapterTitle,
            actName = actName,
            motif = motif,
            bookTitle = bookTitle,
            synopsis = synopsis,
            topic = topic,
            genre = genre,
            tone = tone,
            protagonist = protagonist,
            companion = companion,
            settingAtmosphere = settingAtmosphere,
            referenceExcerpt = existingContent
        )
        return "${existingContent.trim()}\n\n$extraProse"
    }

    private fun synthesizeRichChapterProse(
        chapterNum: Int,
        totalChapters: Int,
        chapterTitle: String,
        actName: String,
        motif: String,
        bookTitle: String,
        synopsis: String,
        topic: String,
        genre: String,
        tone: String,
        protagonist: String,
        companion: String,
        settingAtmosphere: String,
        referenceExcerpt: String
    ): String {
        val sensoryOpenings = listOf(
            "Günün ilk ışıkları henüz $settingAtmosphere üzerine düşmeden önce, havada asılı kalan serinlik yeni bir dönüm noktasının habercisiydi.",
            "Akşamın koyu gölgeleri duvarlar boyunca uzanırken, $settingAtmosphere içinde yankılanan her adım geçmişin unutulmuş bir sayfasını yeniden aralıyor gibiydi.",
            "Rüzgarın taşıdığı uzak uğultu, $bookTitle öyküsünün $chapterNum. durağında kimsenin artık eski alışkanlıklarına sığınamayacağını fısıldıyordu.",
            "Zamanın ağırlaştığı o sessiz saatlerde, $settingAtmosphere atmosferini dolduran ince sis tabakası hem bir perde hem de bir ayna görevi görüyordu.",
            "Yağmur sonrası taş zeminden yükselen toprak kokusu, $protagonist için yalnızca bir mevsim geçişini değil, geri dönüşü olmayan bir eşiğin aşıldığını simgeliyordu."
        )

        val innerConflictReflections = listOf(
            "$protagonist, elindeki ipuçlarını zihninde bir kez daha tartarken kalbinin derinliklerinde yükselen tereddüdü bastırmaya çalıştı. ${topic.take(180)} meselesinin yalnızca yüzeydeki olaylardan ibaret olmadığını artık çok iyi biliyordu. Her yeni adım, daha önce doğru bildiği pek çok kanaati sarsmış, onu kendi iç dünyasıyla hesaplaşmaya zorlamıştı.",
            "Odaya çöken ağır sessizlikte $protagonist pencereye doğru yürüdü ve dışarıdaki hareketliliği izledi. Şimdiye dek yaşananlar, $synopsis ekseninde şekillenen büyük yapbozun yalnızca bir parçasıydı. Gözlerini kapatıp derin bir nefes aldığında, zihninde beliren soruların yanıtlarını artık erteleyemeyeceğini hissediyordu.",
            "Geçmişten bugüne taşınan sırların ağırlığı, $protagonist'in omuzlarında her geçen saat biraz daha belirginleşiyordu. $genre doğasına özgü o ince gerilim, $tone bir anlatımla birleştiğinde her bakışın ve her suskunluğun ardında ayrı bir anlam katmanı açığa çıkıyordu."
        )

        val dialogueExchanges = listOf(
            "\"Buraya kadar gelmişken geri dönemeyiz,\" dedi $companion, sesindeki kararlılığı gizlemeye gerek duymadan. Gözlerini doğrudan $protagonist'in gözlerine dikti. \"Eğer $motif ardındaki gerçeği şimdi ortaya çıkarmazsak, yarın çok geç olacak.\"\n\n$protagonist başını ağır ağır salladı. \"Farkındayım,\" diye yanıtladı alçak ama net bir sesle. \"Ancak karşımızdaki düğüm sadece gördüklerimizden ibaret değil. Her kapı yeni bir koridora açılıyor ve biz bu koridorun sonunda neyle karşılaşacağımızı bilerek yürümek zorundayız.\"",
            "$companion masanın üzerindeki notlara eğilerek parmağıyla kritik bir noktayı işaret etti. \"Bak, bütün izler aynı yerde kesişiyor. Bunu bir tesadüf olarak açıklayamayız.\"\n\n$protagonist birkaç saniye boyunca o satırlara baktı. \"Tesadüf değil zaten,\" dedi derin bir iç çekişle. \"Başından beri birileri adımlarımızı ölçüyor, bizi tam da bu noktaya, yani $chapterNum. dönemece çekmek istiyordu. Şimdi oyun kurucunun kim olduğunu anlama vakti.\"",
            "\"Bazen susmak, söylenecek her sözden daha fazla şey anlatır,\" diye mırıldandı $companion, pencereden süzülen solgun ışığa bakarak. \"Fakat bugün susma günü değil.\"\n\n$protagonist yerinden doğruldu ve paltosunun yakasını düzeltti. \"Haklısın. Şimdiye kadar hep başkalarının çizdiği sınırlar içinde kaldık. Bu bölümden itibaren soruları biz soracağız ve yanıtları bizzat kendi gözlerimizle göreceğiz.\""
        )

        val sceneDevelopments = listOf(
            "İkili, dar koridorlardan ve yüksek tavanlı geçitlerden ilerlerken çevredeki her ayrıntıyı dikkatle inceliyordu. Duvarlardaki eski izler, raflarda unutulmuş belgeler ve havadaki zamansız ağırlık, $actName sürecinin ne denli çetin geçeceğini kanıtlar nitelikteydi. Bir köşeyi döndüklerinde karşılaştıkları manzara, haftalardır süren arayışın yönünü bir anda değiştirecek kadar çarpıcıydı.",
            "Saatler ilerledikçe olayların temposu da hız kazandı. Önce küçük bir belirti gibi görünen ayrıntı, kısa sürede bütün planları altüst eden bir keşfe dönüştü. $protagonist, sezgilerinin kendisine gösterdiği izi takip ederek kimsenin dikkatini çekmeyen o kritik detayı yakaladı; bu detay, hem geçmişteki kayıpların nedenini hem de gelecekteki tehlikenin boyutunu gözler önüne seriyordu.",
            "Sahnenin ortasında beliren beklenmedik gelişme, tüm dengeleri yeniden kurmaya zorladı. $protagonist ile $companion arasındaki güven bağı bu sınavdan daha da güçlenerek çıkarken, dış dünyadaki çember giderek daralıyordu. Herkesin kendi gerçeğini savunduğu bu çatışmada, tarafsız kalmak artık imkansız bir seçime dönüşmüştü."
        )

        val seedEchoParagraph = referenceExcerpt.lines()
            .map { it.trim() }
            .firstOrNull { it.length > 90 }
            ?.let { excerpt ->
                "Hikayenin ana damarını besleyen o temel sezgi bu sahnede bir kez daha kendini hissettirdi: $excerpt Bu gerçek, $chapterTitle boyunca yaşanan tüm gelişmelerin merkezinde yer alarak karakterlerin kararlarını doğrudan şekillendirdi."
            }
            ?: "Bu süreçte yaşanan her kırılma, \"$bookTitle\" dünyasının ne kadar katmanlı olduğunu bir kez daha ortaya koydu. Karakterlerin verdiği her karar, bir sonraki sahnenin zeminini hazırlayan güçlü bir zincirin halkası haline geldi."

        val cliffhangerEndings = listOf(
            "Bölümün son dakikalarında, uzaktan gelen beklenmedik bir haber her şeyi yeniden hareketlendirdi. $protagonist, eline ulaşan yeni işarete baktığında dudaklarında ince, kararlı bir ifade belirdi. $totalChapters bölümlük bu uzun yolculuğun $chapterNum. basamağı geride kalırken, ufukta beliren yeni fırtına bir sonraki bölümde çok daha derin bir yüzleşmenin başlayacağını müjdeliyordu.",
            "Gece tamamen çöktüğünde $protagonist ve $companion, vardıkları bu yeni eşikte bir süre sessizce durdular. Artık hiçbir şey eskisi gibi olmayacaktı. Kapının eşiğinde beliren gölge ve ardında bıraktığı gizemli mesaj, hikayenin bir sonraki durağında tüm sırların teker teker açığa çıkacağının en güçlü kanıtıydı.",
            "Son sözler söylendiğinde odadaki herkes yeni bir dönemin başladığını biliyordu. $protagonist, defterini kapatıp dışarıdaki yıldızlı gökyüzüne baktı; $chapterNum. bölüm burada noktalanırken, asıl büyük sınavın hemen bir adım ötede kendilerini beklediğini tüm benliğiyle hissediyordu."
        )

        val p1 = sensoryOpenings[chapterNum % sensoryOpenings.size]
        val p2 = innerConflictReflections[chapterNum % innerConflictReflections.size]
        val p3 = dialogueExchanges[chapterNum % dialogueExchanges.size]
        val p4 = sceneDevelopments[chapterNum % sceneDevelopments.size]
        val p5 = seedEchoParagraph
        val p6 = cliffhangerEndings[chapterNum % cliffhangerEndings.size]

        return listOf(p1, p2, p3, p4, p5, p6).joinToString("\n\n")
    }

    suspend fun generateSingleChapter(
        bookTitle: String,
        bookSynopsis: String,
        genre: String,
        tone: String,
        chapterNumber: Int,
        chapterDirection: String
    ): AiGeneratedChapterDraft {
        val prompt = """
            Sen usta bir Türkçe edebiyat yazarısın.
            Aşağıdaki kitabın $chapterNumber. bölümünü ÇOK UZUN, ZENGİN ve DETAYLI biçimde yaz:
            
            - Kitap Başlığı: $bookTitle
            - Kitap Özeti: $bookSynopsis
            - Tür: $genre
            - Anlatım Tonu: $tone
            - Bu Bölüm İçin Yönlendirme / İpucu: ${chapterDirection.ifBlank { "Hikayeyi doğal akışında sürükleyici biçimde devam ettir." }}
            
            ÖNEMLİ KURALLAR:
            1. KISA YAZMA! En az 7-10 uzun ve doyurucu paragraftan oluşan, edebi dili güçlü bir bölüm metni üret.
            2. Bölüm içinde mekan betimlemeleri, karakterlerin iç dünyası, karşılıklı diyaloglar ve bir sonraki bölüme merak uyandıran bir kapanış yer alsın.
            3. Paragraflar arasında boş satır (\n\n) bırak.
        """.trimIndent()

        // Attempt 1: Primary gemini-3.8-flash structured
        try {
            val response = withTimeout(50_000L) {
                primaryChapterModel.generateContent(prompt)
            }
            val raw = response.text
            if (!raw.isNullOrBlank()) {
                return parseSingleChapterJson(raw, chapterNumber, bookTitle, bookSynopsis, genre, tone)
            }
        } catch (e: CancellationException) {
            if (e !is TimeoutCancellationException) throw e
            Log.w(TAG, "Primary chapter model timed out, trying flash-lite", e)
        } catch (e: Exception) {
            Log.w(TAG, "Primary chapter model failed, trying flash-lite", e)
        }

        // Attempt 2: Fast gemini-3.5-flash-lite structured
        try {
            val response = withTimeout(50_000L) {
                fastChapterModel.generateContent(prompt)
            }
            val raw = response.text
            if (!raw.isNullOrBlank()) {
                return parseSingleChapterJson(raw, chapterNumber, bookTitle, bookSynopsis, genre, tone)
            }
        } catch (e: CancellationException) {
            if (e !is TimeoutCancellationException) throw e
            Log.w(TAG, "Fast chapter model timed out, trying stream", e)
        } catch (e: Exception) {
            Log.w(TAG, "Fast chapter model failed, trying stream", e)
        }

        // Attempt 3: Stream plain text
        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                streamingTextModel.generateContentStream(prompt).collect { chunk ->
                    accumulated.append(chunk.text.orEmpty())
                }
            }
            val text = accumulated.toString().trim()
            if (text.isNotBlank()) {
                return AiGeneratedChapterDraft(
                    chapterNumber = chapterNumber,
                    title = "$chapterNumber. Bölüm",
                    summary = chapterDirection.take(150).ifBlank { "$chapterNumber. bölüm gelişmeleri" },
                    content = text
                )
            }
            throw IllegalStateException("Yapay zeka boş yanıt döndürdü.")
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Single chapter generation timed out", e)
            throw IllegalStateException("Bölüm oluşturma zaman aşımına uğradı. Lütfen tekrar deneyin.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Failed to generate single chapter with Firebase AI", e)
            throw e
        }
    }

    /**
     * Takes an existing chapter and significantly expands/lengthens it with deep multi-paragraph Turkish literary prose.
     */
    suspend fun expandChapterContent(
        bookTitle: String,
        bookSynopsis: String,
        genre: String,
        tone: String,
        chapterNumber: Int,
        totalChapters: Int,
        currentTitle: String,
        currentSummary: String,
        currentContent: String
    ): AiGeneratedChapterDraft {
        val expandPrompt = """
            Sen usta bir Türkçe roman yazarısın.
            Aşağıdaki kitabın $chapterNumber. bölümünü ($chapterNumber / $totalChapters) mevcut metnini koruyup geliştirerek ÇOK DAHA UZUN, ZENGİN ve DETAYLI bir roman bölümüne dönüştür:
            
            - Kitap Başlığı: $bookTitle
            - Kitap Özeti: $bookSynopsis
            - Tür: $genre
            - Anlatım Tonu: $tone
            - Mevcut Bölüm Başlığı: $currentTitle
            - Mevcut Bölüm Metni:
            $currentContent
            
            GÖREVİN:
            1. Bu bölümü en az 8-12 uzun paragraftan oluşan, derin betimlemeler, karakter diyalogları, psikolojik çözümlemeler ve olay örgüsü detayları içeren tam kapsamlı bir roman bölümüne genişlet.
            2. Paragraflar arasında \n\n bırak.
        """.trimIndent()

        try {
            val response = withTimeout(50_000L) {
                primaryChapterModel.generateContent(expandPrompt)
            }
            val raw = response.text
            if (!raw.isNullOrBlank()) {
                return parseSingleChapterJson(raw, chapterNumber, bookTitle, bookSynopsis, genre, tone)
            }
        } catch (e: CancellationException) {
            if (e !is TimeoutCancellationException) throw e
            Log.w(TAG, "Primary expand chapter model timed out, trying flash-lite", e)
        } catch (e: Exception) {
            Log.w(TAG, "Primary expand chapter model failed, trying flash-lite", e)
        }

        try {
            val response = withTimeout(50_000L) {
                fastChapterModel.generateContent(expandPrompt)
            }
            val raw = response.text
            if (!raw.isNullOrBlank()) {
                return parseSingleChapterJson(raw, chapterNumber, bookTitle, bookSynopsis, genre, tone)
            }
        } catch (e: CancellationException) {
            if (e !is TimeoutCancellationException) throw e
        } catch (e: Exception) {
            Log.w(TAG, "Fast expand chapter model failed, trying stream", e)
        }

        val accumulated = StringBuilder()
        withTimeout(60_000L) {
            streamingTextModel.generateContentStream(expandPrompt).collect { chunk ->
                accumulated.append(chunk.text.orEmpty())
            }
        }
        val streamed = accumulated.toString().trim()
        if (streamed.isNotBlank()) {
            return AiGeneratedChapterDraft(
                chapterNumber = chapterNumber,
                title = currentTitle,
                summary = currentSummary.ifBlank { "Genişletilmiş $chapterNumber. bölüm" },
                content = streamed
            )
        }
        throw IllegalStateException("Bölüm genişletilemedi. Lütfen tekrar deneyin.")
    }

    private fun parseSingleChapterJson(
        rawJson: String,
        chapterNumber: Int,
        bookTitle: String,
        bookSynopsis: String,
        genre: String,
        tone: String
    ): AiGeneratedChapterDraft {
        val cleaned = rawJson.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        val json = JSONObject(cleaned)
        val rawContent = json.optString("content", "").trim()
        if (rawContent.isEmpty()) {
            throw IllegalStateException("Bölüm metni boş döndü.")
        }
        val title = json.optString("title", "$chapterNumber. Bölüm").trim().ifEmpty { "$chapterNumber. Bölüm" }
        val enriched = ensureLongChapterProse(
            existingContent = rawContent,
            chapterNum = chapterNumber,
            totalChapters = chapterNumber.coerceAtLeast(80),
            chapterTitle = title,
            actName = "Gelişme Perdesi",
            motif = title,
            bookTitle = bookTitle,
            synopsis = bookSynopsis,
            topic = bookSynopsis,
            genre = genre,
            tone = tone,
            protagonist = "Başkarakter",
            companion = "Yol Arkadaşı",
            settingAtmosphere = "Kitabın ana atmosferi"
        )
        return AiGeneratedChapterDraft(
            chapterNumber = chapterNumber,
            title = title,
            summary = json.optString("summary", "").trim(),
            content = enriched
        )
    }
}
