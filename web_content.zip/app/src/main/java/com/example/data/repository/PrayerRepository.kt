package com.example.data.repository

import android.content.Context
import com.example.data.model.CityInfo
import com.example.data.model.GregorianDate
import com.example.data.model.HijriDate
import com.example.data.model.IslamicEvent
import com.example.data.model.PrayerDataState
import com.example.data.model.PrayerOffsets
import com.example.data.model.PrayerTimeItemData
import com.example.data.model.PrayerType
import com.example.data.model.RamadanCountdownState
import com.example.data.preferences.PrayerPreferences
import com.example.data.service.AladhanApiService
import com.example.data.service.OfflinePrayerCalculator
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PrayerRepository(private val context: Context) {

    private val preferences = PrayerPreferences(context)
    private val apiService = AladhanApiService()

    val supportedCities = listOf(
        CityInfo("وهران", "Oran", "الجزائر", "Algeria", 35.6976, -0.6337),
        CityInfo("الجزائر العاصمة", "Algiers", "الجزائر", "Algeria", 36.7538, 3.0588),
        CityInfo("قسنطينة", "Constantine", "الجزائر", "Algeria", 36.3650, 6.6147),
        CityInfo("معسكر", "Mascara", "الجزائر", "Algeria", 35.3966, 0.1403),
        CityInfo("تلمسان", "Tlemcen", "الجزائر", "Algeria", 34.8783, -1.3150),
        CityInfo("سطيف", "Setif", "الجزائر", "Algeria", 36.1911, 5.4137),
        CityInfo("عنابة", "Annaba", "الجزائر", "Algeria", 36.9000, 7.7667),
        CityInfo("البليدة", "Blida", "الجزائر", "Algeria", 36.4700, 2.8300),
        CityInfo("باتنة", "Batna", "الجزائر", "Algeria", 35.5558, 6.1742),
        CityInfo("بسكرة", "Biskra", "الجزائر", "Algeria", 34.8504, 5.7280),
        CityInfo("سيدي بلعباس", "Sidi Bel Abbes", "الجزائر", "Algeria", 35.1899, -0.6308),
        CityInfo("مستغانم", "Mostaganem", "الجزائر", "Algeria", 35.9311, 0.0892),
        CityInfo("غرداية", "Ghardaia", "الجزائر", "Algeria", 32.4909, 3.6735),
        CityInfo("ورقلة", "Ouargla", "الجزائر", "Algeria", 31.9493, 5.3250),
        CityInfo("تيزي وزو", "Tizi Ouzou", "الجزائر", "Algeria", 36.7118, 4.0459),
        CityInfo("بجاية", "Bejaia", "الجزائر", "Algeria", 36.7559, 5.0843),
        CityInfo("الشلف", "Chlef", "الجزائر", "Algeria", 36.1654, 1.3345),
        CityInfo("أدرار", "Adrar", "الجزائر", "Algeria", 27.8743, -0.2939),
        CityInfo("مكة المكرمة", "Makkah", "السعودية", "Saudi Arabia", 21.4225, 39.8262),
        CityInfo("المدينة المنورة", "Madinah", "السعودية", "Saudi Arabia", 24.5247, 39.5692),
        CityInfo("القدس الشريف", "Jerusalem", "فلسطين", "Palestine", 31.7683, 35.2137),
        CityInfo("القاهرة", "Cairo", "مصر", "Egypt", 30.0444, 31.2357),
        CityInfo("الرباط", "Rabat", "المغرب", "Morocco", 34.0209, -6.8416),
        CityInfo("تونس", "Tunis", "تونس", "Tunisia", 36.8065, 10.1815),
        CityInfo("دبي", "Dubai", "الإمارات", "UAE", 25.2048, 55.2708),
        CityInfo("باريس", "Paris", "فرنسا", "France", 48.8566, 2.3522)
    )

    fun findCityByName(cityName: String): CityInfo {
        return supportedCities.firstOrNull {
            it.nameEn.equals(cityName, ignoreCase = true) || it.nameAr == cityName
        } ?: supportedCities.first()
    }

    fun findNearestCity(lat: Double, lon: Double): CityInfo {
        return supportedCities.minByOrNull { city ->
            val dLat = Math.toRadians(city.latitude - lat)
            val dLon = Math.toRadians(city.longitude - lon)
            val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(Math.toRadians(lat)) * Math.cos(Math.toRadians(city.latitude)) *
                    Math.sin(dLon / 2) * Math.sin(dLon / 2)
            val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
            6371.0 * c
        } ?: supportedCities.first()
    }

    suspend fun getPrayerData(
        calendar: Calendar = Calendar.getInstance(),
        offsets: PrayerOffsets = preferences.getOffsets()
    ): PrayerDataState {
        val isUsingGps = preferences.isUsingGps
        val methodId = preferences.calculationMethodId
        val selectedCityName = preferences.selectedCity

        val city = findCityByName(selectedCityName)
        val lat = if (isUsingGps) preferences.gpsLatitude else city.latitude
        val lon = if (isUsingGps) preferences.gpsLongitude else city.longitude
        val locationLabel = if (isUsingGps) {
            val detected = preferences.gpsCityName
            if (detected.isNotBlank()) detected else "موقعي الحالي (GPS)"
        } else {
            "${city.nameAr}، ${city.countryAr}"
        }

        // Gregorian Date formatted in Arabic
        val dayOfWeekArabic = when (calendar.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SUNDAY -> "الأحد"
            Calendar.MONDAY -> "الاثنين"
            Calendar.TUESDAY -> "الثلاثاء"
            Calendar.WEDNESDAY -> "الأربعاء"
            Calendar.THURSDAY -> "الخميس"
            Calendar.FRIDAY -> "الجمعة"
            Calendar.SATURDAY -> "السبت"
            else -> ""
        }

        val arabicMonths = listOf(
            "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
            "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
        )
        val monthName = arabicMonths[calendar.get(Calendar.MONTH)]
        val gregorianFormatted = "$dayOfWeekArabic، ${calendar.get(Calendar.DAY_OF_MONTH)} $monthName ${calendar.get(Calendar.YEAR)} م"
        val gregorianDate = GregorianDate(
            formatted = gregorianFormatted,
            dayNameAr = dayOfWeekArabic,
            day = calendar.get(Calendar.DAY_OF_MONTH),
            monthNameAr = monthName,
            year = calendar.get(Calendar.YEAR)
        )

        // Offline astronomical calculation (always available as fallback & initial base)
        val offlineTimings = OfflinePrayerCalculator.calculatePrayerTimes(lat, lon, calendar, methodId)
        var finalTimings = offlineTimings
        var hijriDate: HijriDate = OfflinePrayerCalculator.calculateHijriDate(calendar)

        // Attempt online sync from Aladhan API for maximum accuracy
        try {
            val onlineResult = if (isUsingGps) {
                apiService.fetchTimingsByCoordinates(lat, lon, methodId)
            } else {
                apiService.fetchTimingsByCity(city.nameEn, city.countryEn, methodId)
            }

            onlineResult.onSuccess { res ->
                if (res.timings.isNotEmpty()) {
                    finalTimings = res.timings
                }
                if (res.hijriDate != null) {
                    hijriDate = res.hijriDate
                }
            }
        } catch (ignored: Exception) {
            // Offline fallback is already set
        }

        // Build list of prayer items applying offsets
        val nowMillis = System.currentTimeMillis()
        val prayerItemList = mutableListOf<PrayerTimeItemData>()

        for (prayer in PrayerType.entries) {
            val baseTime = finalTimings[prayer] ?: Pair(0, 0)
            val offset = offsets.getOffset(prayer)

            // Adjust by offset minutes
            val calPrayer = Calendar.getInstance().apply {
                timeInMillis = calendar.timeInMillis
                set(Calendar.HOUR_OF_DAY, baseTime.first)
                set(Calendar.MINUTE, baseTime.second)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, offset)
            }

            val adjustedHour = calPrayer.get(Calendar.HOUR_OF_DAY)
            val adjustedMinute = calPrayer.get(Calendar.MINUTE)
            val formattedTime = String.format(Locale.US, "%02d:%02d", adjustedHour, adjustedMinute)

            prayerItemList.add(
                PrayerTimeItemData(
                    type = prayer,
                    formattedTime = formattedTime,
                    epochMillis = calPrayer.timeInMillis,
                    offsetMinutes = offset,
                    isPassed = calPrayer.timeInMillis < nowMillis
                )
            )
        }

        // Determine next prayer
        var nextPrayerItem: PrayerTimeItemData? = null
        for (item in prayerItemList) {
            if (item.epochMillis > nowMillis) {
                nextPrayerItem = item
                break
            }
        }

        // If all prayers today have passed, next is tomorrow's Fajr
        val tomorrowFajrMillis: Long
        if (nextPrayerItem == null) {
            val tomorrowCal = Calendar.getInstance().apply {
                timeInMillis = calendar.timeInMillis
                add(Calendar.DAY_OF_YEAR, 1)
            }
            val tomorrowTimings = OfflinePrayerCalculator.calculatePrayerTimes(lat, lon, tomorrowCal, methodId)
            val fajrTime = tomorrowTimings[PrayerType.FAJR] ?: Pair(5, 0)
            val fajrOffset = offsets.getOffset(PrayerType.FAJR)

            val calFajrTomorrow = Calendar.getInstance().apply {
                timeInMillis = tomorrowCal.timeInMillis
                set(Calendar.HOUR_OF_DAY, fajrTime.first)
                set(Calendar.MINUTE, fajrTime.second)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                add(Calendar.MINUTE, fajrOffset)
            }
            tomorrowFajrMillis = calFajrTomorrow.timeInMillis
            val formatted = String.format(
                Locale.US, "%02d:%02d",
                calFajrTomorrow.get(Calendar.HOUR_OF_DAY),
                calFajrTomorrow.get(Calendar.MINUTE)
            )

            nextPrayerItem = PrayerTimeItemData(
                type = PrayerType.FAJR,
                formattedTime = formatted,
                epochMillis = tomorrowFajrMillis,
                offsetMinutes = fajrOffset,
                isNext = true,
                isPassed = false
            )
        }

        val finalizedList = prayerItemList.map { item ->
            if (item.type == nextPrayerItem?.type && item.epochMillis == nextPrayerItem?.epochMillis) {
                item.copy(isNext = true)
            } else {
                item
            }
        }

        val remainingSeconds = ((nextPrayerItem.epochMillis - nowMillis) / 1000).coerceAtLeast(0)
        val hours = remainingSeconds / 3600
        val mins = (remainingSeconds % 3600) / 60
        val secs = remainingSeconds % 60
        val countdown = String.format(Locale.US, "%02d:%02d:%02d", hours, mins, secs)

        val qibla = OfflinePrayerCalculator.calculateQiblaDirection(lat, lon)

        return PrayerDataState(
            locationName = locationLabel,
            latitude = lat,
            longitude = lon,
            gregorianDate = gregorianDate,
            hijriDate = hijriDate,
            prayerList = finalizedList,
            nextPrayer = nextPrayerItem,
            countdownFormatted = countdown,
            countdownSecondsRemaining = remainingSeconds,
            islamicEvents = getIslamicEvents(nowMillis),
            ramadanCountdown = calculateRamadanCountdown(nowMillis),
            qiblaAngle = qibla,
            isLoading = false
        )
    }

    fun getIslamicEvents(nowMillis: Long = System.currentTimeMillis()): List<IslamicEvent> {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val rawEvents = listOf(
            Triple("شهر رمضان المبارك", "1 رمضان 1448 هـ", "2027-02-08"),
            Triple("عيد الفطر المبارك", "1 شوال 1448 هـ", "2027-03-10"),
            Triple("يوم عرفة", "9 ذو الحجة 1448 هـ", "2027-05-16"),
            Triple("عيد الأضحى المبارك", "10 ذو الحجة 1448 هـ", "2027-05-17"),
            Triple("رأس السنة الهجرية", "1 محرم 1449 هـ", "2027-06-06")
        )

        return rawEvents.map { (name, hijri, dateIso) ->
            val targetCal = Calendar.getInstance().apply {
                val parsed = try { sdf.parse(dateIso) } catch (e: Exception) { null }
                if (parsed != null) time = parsed
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val targetMillis = targetCal.timeInMillis
            val diff = targetMillis - nowMillis
            val daysRemaining = Math.max(0L, Math.ceil(diff.toDouble() / (1000 * 60 * 60 * 24)).toLong())
            IslamicEvent(
                name = name,
                hijri = hijri,
                dateIso = dateIso,
                targetEpochMillis = targetMillis,
                daysRemaining = daysRemaining
            )
        }
    }

    fun calculateRamadanCountdown(nowMillis: Long = System.currentTimeMillis()): RamadanCountdownState {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val ramadanDate = Calendar.getInstance().apply {
            val parsed = try { sdf.parse("2027-02-08") } catch (e: Exception) { null }
            if (parsed != null) time = parsed
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val diff = (ramadanDate - nowMillis).coerceAtLeast(0)
        val totalSecs = diff / 1000
        val days = totalSecs / (24 * 3600)
        val hours = (totalSecs % (24 * 3600)) / 3600
        val mins = (totalSecs % 3600) / 60
        val secs = totalSecs % 60

        return RamadanCountdownState(
            days = days,
            hours = hours,
            minutes = mins,
            seconds = secs,
            targetDescription = "رمضان 1448 هـ (المتوقع: فبراير 2027 م)"
        )
    }
}
