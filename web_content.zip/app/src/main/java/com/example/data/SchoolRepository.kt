package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.R
import com.example.domain.SchoolBackupBundle
import com.example.model.AttendanceRecord
import com.example.model.AttendanceStatus
import com.example.model.ObservationRule
import com.example.model.SchoolClass
import com.example.model.SchoolConfig
import com.example.model.Student
import com.example.model.Subject
import com.example.model.TeacherAssignment
import com.example.model.TeacherRole
import com.example.model.defaultReportLabels
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class SchoolRepository(
    private val db: FirebaseFirestore,
    private val appContext: Context,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        appContext = context.applicationContext,
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun userRoot(uid: String) = db.collection("users").document(uid)

    private inline fun <T> observeSubcollection(
        collectionName: String,
        crossinline mapper: (com.google.firebase.firestore.QuerySnapshot) -> T,
    ): Flow<T> = flow {
        val uid = requireUserId()
        val path = "users/$uid/$collectionName"
        emitAll(
            userRoot(uid).collection(collectionName)
                .snapshots()
                .map { snapshot -> mapper(snapshot) }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeConfig(): Flow<SchoolConfig> = observeSubcollection("school_configs") { snapshot ->
        snapshot.documents.firstOrNull()
            ?.toObject(SchoolConfig::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            ?: SchoolConfig(id = "default")
    }

    fun observeClasses(): Flow<List<SchoolClass>> = observeSubcollection("classes") { snapshot ->
        snapshot.toObjects(SchoolClass::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedBy { it.sortOrder }
    }

    fun observeSubjects(): Flow<List<Subject>> = observeSubcollection("subjects") { snapshot ->
        snapshot.toObjects(Subject::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedBy { it.sortOrder }
    }

    fun observeStudents(): Flow<List<Student>> = observeSubcollection("students") { snapshot ->
        snapshot.toObjects(Student::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            .sortedBy { it.name }
    }

    fun observeAttendance(): Flow<List<AttendanceRecord>> = observeSubcollection("attendance") { snapshot ->
        snapshot.toObjects(AttendanceRecord::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
    }

    fun observeTeacherAssignments(): Flow<List<TeacherAssignment>> =
        observeSubcollection("teacher_assignments") { snapshot ->
            snapshot.toObjects(TeacherAssignment::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedBy { it.teacherName }
        }

    fun observeObservationRules(): Flow<List<ObservationRule>> =
        observeSubcollection("observation_rules") { snapshot ->
            snapshot.toObjects(ObservationRule::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .sortedByDescending { it.minPct }
        }

    suspend fun saveSchoolConfig(config: SchoolConfig): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/school_configs/default"
        return try {
            val uid = requireUserId()
            val docRef = userRoot(uid).collection("school_configs").document("default")
            docPath = docRef.path
            val existingSnap = docRef.get().await()
            val sanitizedSchoolName = config.schoolName.trim().ifBlank { "TRIZZIE SCHOOL" }.take(120)
            val safeLabels = config.labels.entries.take(30).associate { (k, v) -> k.take(40) to v.take(60) }
            val commonFields = mapOf(
                "country" to config.country.take(100),
                "schoolName" to sanitizedSchoolName,
                "poBox" to config.poBox.take(80),
                "tel" to config.tel.take(40),
                "ministry" to config.ministry.take(100),
                "academicYear" to config.academicYear.take(40),
                "term" to config.term.take(40),
                "reportTitle" to config.reportTitle.take(60),
                "teacherName" to config.teacherName.take(80),
                "showLogo" to config.showLogo,
                "logoFileName" to config.logoFileName.take(120),
                "logoSizeDp" to config.logoSizeDp.coerceIn(30L, 160L),
                "logoCircular" to config.logoCircular,
                "signatureFileName" to config.signatureFileName.take(120),
                "signatureSizeDp" to config.signatureSizeDp.coerceIn(20L, 120L),
                "borderColorHex" to config.borderColorHex.trim().take(9).let { if (it.length < 4) "#1F2937" else it },
                "headerBgHex" to config.headerBgHex.trim().take(9).let { if (it.length < 4) "#F8FAFC" else it },
                "reportFont" to if (config.reportFont == "sans") "sans" else "serif",
                "positionFormat" to if (config.positionFormat == "fraction") "fraction" else "number_only",
                "decimalPlaces" to config.decimalPlaces.coerceIn(0L, 2L),
                "conductMax" to config.conductMax.take(20),
                "manualStudentCount" to config.manualStudentCount.take(20),
                "passMark" to config.passMark.coerceIn(0L, 100L),
                "autoApplyObservations" to config.autoApplyObservations,
                "labels" to safeLabels,
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (existingSnap.exists()) {
                docRef.update(commonFields).await()
            } else {
                docRef.set(
                    commonFields + mapOf(
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun createClass(name: String, sortOrder: Long, copyFromSubjects: List<Subject>): Result<String> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/classes"
        return try {
            val uid = requireUserId()
            val trimmed = name.trim().uppercase().take(60)
            require(trimmed.isNotBlank()) { "Class name cannot be empty." }
            val classRef = userRoot(uid).collection("classes").document()
            docPath = classRef.path
            val batch = db.batch()
            batch.set(
                classRef,
                mapOf(
                    "userId" to uid,
                    "name" to trimmed,
                    "sortOrder" to sortOrder.coerceIn(0L, 10000L),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            )
            val subjectsToAdd = copyFromSubjects.ifEmpty {
                listOf(Subject(name = "MATHEMATICS", maxTest = 100L, maxExam = 0L, sortOrder = 0L))
            }
            subjectsToAdd.forEachIndexed { idx, sub ->
                val subRef = userRoot(uid).collection("subjects").document()
                batch.set(
                    subRef,
                    mapOf(
                        "userId" to uid,
                        "classId" to classRef.id,
                        "name" to sub.name.trim().uppercase().take(80).ifBlank { "SUBJECT" },
                        "maxTest" to sub.maxTest.coerceIn(0L, 1000L),
                        "maxExam" to sub.maxExam.coerceIn(0L, 1000L),
                        "sortOrder" to idx.toLong(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }
            batch.commit().await()
            Result.success(classRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun renameClass(classId: String, newName: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/classes/$classId"
        return try {
            val uid = requireUserId()
            val trimmed = newName.trim().uppercase().take(60)
            require(classId.isNotBlank() && trimmed.isNotBlank())
            val docRef = userRoot(uid).collection("classes").document(classId)
            docPath = docRef.path
            docRef.update(mapOf("name" to trimmed, "updatedAt" to FieldValue.serverTimestamp())).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteClass(classId: String, subjectIds: List<String>, studentIds: List<String>): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/classes/$classId"
        return try {
            val uid = requireUserId()
            require(classId.isNotBlank())
            val batch = db.batch()
            val classRef = userRoot(uid).collection("classes").document(classId)
            docPath = classRef.path
            batch.delete(classRef)
            subjectIds.forEach { sId ->
                batch.delete(userRoot(uid).collection("subjects").document(sId))
            }
            studentIds.forEach { stId ->
                batch.delete(userRoot(uid).collection("students").document(stId))
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertSubject(subject: Subject): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/subjects"
        return try {
            val uid = requireUserId()
            val name = subject.name.trim().uppercase().take(80)
            require(name.isNotBlank() && subject.classId.isNotBlank())
            val col = userRoot(uid).collection("subjects")
            if (subject.id.isBlank()) {
                val docRef = col.document()
                docPath = docRef.path
                docRef.set(
                    mapOf(
                        "userId" to uid,
                        "classId" to subject.classId,
                        "name" to name,
                        "maxTest" to subject.maxTest.coerceIn(0L, 1000L),
                        "maxExam" to subject.maxExam.coerceIn(0L, 1000L),
                        "sortOrder" to subject.sortOrder.coerceIn(0L, 10000L),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                val docRef = col.document(subject.id)
                docPath = docRef.path
                docRef.update(
                    mapOf(
                        "name" to name,
                        "maxTest" to subject.maxTest.coerceIn(0L, 1000L),
                        "maxExam" to subject.maxExam.coerceIn(0L, 1000L),
                        "sortOrder" to subject.sortOrder.coerceIn(0L, 10000L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun applySubjectWeightsPreset(subjects: List<Subject>, maxTest: Long, maxExam: Long): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/subjects"
        return try {
            val uid = requireUserId()
            val batch = db.batch()
            subjects.forEach { sub ->
                val ref = userRoot(uid).collection("subjects").document(sub.id)
                docPath = ref.path
                batch.update(
                    ref,
                    mapOf(
                        "maxTest" to maxTest.coerceIn(0L, 1000L),
                        "maxExam" to maxExam.coerceIn(0L, 1000L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteSubject(subjectId: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/subjects/$subjectId"
        return try {
            val uid = requireUserId()
            val docRef = userRoot(uid).collection("subjects").document(subjectId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun addStudent(student: Student): Result<String> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/students"
        return try {
            val uid = requireUserId()
            val trimmedName = student.name.trim().uppercase().take(100)
            require(trimmedName.isNotBlank() && student.classId.isNotBlank())
            val docRef = userRoot(uid).collection("students").document()
            docPath = docRef.path
            docRef.set(
                mapOf(
                    "userId" to uid,
                    "classId" to student.classId,
                    "name" to trimmedName,
                    "studentIdNo" to student.studentIdNo.trim().take(40),
                    "conduct" to student.conduct.trim().take(20),
                    "latesCount" to student.latesCount.coerceIn(0L, 1000L),
                    "absencesCount" to student.absencesCount.coerceIn(0L, 1000L),
                    "observation" to student.observation.take(240),
                    "testScores" to student.testScores,
                    "examScores" to student.examScores,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun bulkAddStudents(classId: String, names: List<String>): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/students"
        return try {
            val uid = requireUserId()
            val cleaned = names.map { it.trim().uppercase().take(100) }.filter { it.isNotBlank() }
            if (cleaned.isEmpty()) return Result.success(Unit)
            val batch = db.batch()
            cleaned.forEach { name ->
                val ref = userRoot(uid).collection("students").document()
                docPath = ref.path
                batch.set(
                    ref,
                    mapOf(
                        "userId" to uid,
                        "classId" to classId,
                        "name" to name,
                        "studentIdNo" to "",
                        "conduct" to "",
                        "latesCount" to 0L,
                        "absencesCount" to 0L,
                        "observation" to "",
                        "testScores" to emptyMap<String, Double>(),
                        "examScores" to emptyMap<String, Double>(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun updateStudent(student: Student): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/students/${student.id}"
        return try {
            val uid = requireUserId()
            require(student.id.isNotBlank())
            val trimmedName = student.name.trim().uppercase().take(100)
            require(trimmedName.isNotBlank())
            val docRef = userRoot(uid).collection("students").document(student.id)
            docPath = docRef.path
            docRef.update(
                mapOf(
                    "classId" to student.classId,
                    "name" to trimmedName,
                    "studentIdNo" to student.studentIdNo.trim().take(40),
                    "conduct" to student.conduct.trim().take(20),
                    "latesCount" to student.latesCount.coerceIn(0L, 1000L),
                    "absencesCount" to student.absencesCount.coerceIn(0L, 1000L),
                    "observation" to student.observation.take(240),
                    "testScores" to student.testScores,
                    "examScores" to student.examScores,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteStudent(studentId: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/students/$studentId"
        return try {
            val uid = requireUserId()
            val docRef = userRoot(uid).collection("students").document(studentId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun clearStudentsInClass(studentIds: List<String>): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/students"
        return try {
            val uid = requireUserId()
            val batch = db.batch()
            studentIds.forEach { stId ->
                val ref = userRoot(uid).collection("students").document(stId)
                docPath = ref.path
                batch.delete(ref)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun setAttendanceStatus(
        classId: String,
        studentId: String,
        dateKey: String,
        status: AttendanceStatus,
        note: String,
    ): Result<Unit> {
        val docId = "${classId}_${dateKey}_${studentId}"
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/attendance/$docId"
        return try {
            val uid = requireUserId()
            require(dateKey.length == 10 && classId.isNotBlank() && studentId.isNotBlank())
            val docRef = userRoot(uid).collection("attendance").document(docId)
            docPath = docRef.path
            val existing = docRef.get().await()
            val payload = mapOf(
                "classId" to classId,
                "studentId" to studentId,
                "dateKey" to dateKey,
                "status" to status.name,
                "note" to note.take(200),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (existing.exists()) {
                docRef.update(payload).await()
            } else {
                docRef.set(
                    payload + mapOf(
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun markAllPresent(
        classId: String,
        students: List<Student>,
        existingRecordsForDate: Map<String, AttendanceRecord>,
        dateKey: String,
    ): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/attendance"
        return try {
            val uid = requireUserId()
            require(dateKey.length == 10 && classId.isNotBlank())
            val batch = db.batch()
            students.forEach { stu ->
                val docId = "${classId}_${dateKey}_${stu.id}"
                val ref = userRoot(uid).collection("attendance").document(docId)
                docPath = ref.path
                val existing = existingRecordsForDate[stu.id]
                if (existing != null) {
                    batch.update(
                        ref,
                        mapOf(
                            "status" to AttendanceStatus.PRESENT.name,
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    )
                } else {
                    batch.set(
                        ref,
                        mapOf(
                            "userId" to uid,
                            "classId" to classId,
                            "studentId" to stu.id,
                            "dateKey" to dateKey,
                            "status" to AttendanceStatus.PRESENT.name,
                            "note" to "",
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp(),
                        )
                    )
                }
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun syncAttendanceCountsToStudents(
        students: List<Student>,
        attendanceRecords: List<AttendanceRecord>,
    ): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/students"
        return try {
            val uid = requireUserId()
            val byStudent = attendanceRecords.groupBy { it.studentId }
            val batch = db.batch()
            students.forEach { stu ->
                val records = byStudent[stu.id].orEmpty()
                val lates = records.count { it.status == AttendanceStatus.LATE.name }.toLong()
                val absences = records.count { it.status == AttendanceStatus.ABSENT.name }.toLong()
                val ref = userRoot(uid).collection("students").document(stu.id)
                docPath = ref.path
                batch.update(
                    ref,
                    mapOf(
                        "latesCount" to lates.coerceIn(0L, 1000L),
                        "absencesCount" to absences.coerceIn(0L, 1000L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertTeacherAssignment(assignment: TeacherAssignment): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/teacher_assignments"
        return try {
            val uid = requireUserId()
            val teacherName = assignment.teacherName.trim().take(100)
            require(teacherName.isNotBlank() && assignment.classId.isNotBlank())
            val safeRole = TeacherRole.fromRaw(assignment.roleType).name
            val col = userRoot(uid).collection("teacher_assignments")
            val fields = mapOf(
                "teacherName" to teacherName,
                "teacherEmail" to assignment.teacherEmail.trim().take(120),
                "teacherPhone" to assignment.teacherPhone.trim().take(40),
                "classId" to assignment.classId,
                "className" to assignment.className.trim().take(60).ifBlank { "CLASS" },
                "subjectId" to assignment.subjectId,
                "subjectName" to assignment.subjectName.trim().take(80),
                "roleType" to safeRole,
                "weeklyHours" to assignment.weeklyHours.coerceIn(0L, 80L),
                "scheduleNote" to assignment.scheduleNote.trim().take(200),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (assignment.id.isBlank()) {
                val docRef = col.document()
                docPath = docRef.path
                docRef.set(
                    fields + mapOf(
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                val docRef = col.document(assignment.id)
                docPath = docRef.path
                docRef.update(fields).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteTeacherAssignment(assignmentId: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/teacher_assignments/$assignmentId"
        return try {
            val uid = requireUserId()
            val docRef = userRoot(uid).collection("teacher_assignments").document(assignmentId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun upsertObservationRule(rule: ObservationRule): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/observation_rules"
        return try {
            val uid = requireUserId()
            val comment = rule.commentText.trim().take(200)
            require(comment.isNotBlank())
            val col = userRoot(uid).collection("observation_rules")
            val fields = mapOf(
                "minPct" to rule.minPct.coerceIn(0L, 100L),
                "commentText" to comment,
                "updatedAt" to FieldValue.serverTimestamp(),
            )
            if (rule.id.isBlank()) {
                val docRef = col.document()
                docPath = docRef.path
                docRef.set(
                    fields + mapOf(
                        "userId" to uid,
                        "createdAt" to FieldValue.serverTimestamp(),
                    )
                ).await()
            } else {
                val docRef = col.document(rule.id)
                docPath = docRef.path
                docRef.update(fields).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteObservationRule(ruleId: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/observation_rules/$ruleId"
        return try {
            val uid = requireUserId()
            val docRef = userRoot(uid).collection("observation_rules").document(ruleId)
            docPath = docRef.path
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    suspend fun applyObservationUpdates(updates: List<Pair<String, String>>): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/students"
        return try {
            val uid = requireUserId()
            val batch = db.batch()
            updates.forEach { (stuId, obs) ->
                val ref = userRoot(uid).collection("students").document(stuId)
                docPath = ref.path
                batch.update(
                    ref,
                    mapOf(
                        "observation" to obs.take(240),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun seedDemoDataIfEmpty(todayDateKey: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/classes"
        return try {
            val uid = requireUserId()
            val existingClasses = userRoot(uid).collection("classes").limit(1).get().await()
            if (!existingClasses.isEmpty) return Result.success(Unit)

            val batch = db.batch()
            val configRef = userRoot(uid).collection("school_configs").document("default")
            val defaultConfig = SchoolConfig()
            batch.set(
                configRef,
                mapOf(
                    "userId" to uid,
                    "country" to defaultConfig.country,
                    "schoolName" to defaultConfig.schoolName,
                    "poBox" to defaultConfig.poBox,
                    "tel" to defaultConfig.tel,
                    "ministry" to defaultConfig.ministry,
                    "academicYear" to defaultConfig.academicYear,
                    "term" to defaultConfig.term,
                    "reportTitle" to defaultConfig.reportTitle,
                    "teacherName" to "Tr. Jean Bosco",
                    "showLogo" to true,
                    "logoFileName" to "",
                    "logoSizeDp" to 82L,
                    "logoCircular" to true,
                    "signatureFileName" to "",
                    "signatureSizeDp" to 48L,
                    "borderColorHex" to "#1F2937",
                    "headerBgHex" to "#F8FAFC",
                    "reportFont" to "serif",
                    "positionFormat" to "number_only",
                    "decimalPlaces" to 1L,
                    "conductMax" to "",
                    "manualStudentCount" to "",
                    "passMark" to 50L,
                    "autoApplyObservations" to false,
                    "labels" to defaultReportLabels(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            )

            val classRef = userRoot(uid).collection("classes").document("class_p4")
            docPath = classRef.path
            batch.set(
                classRef,
                mapOf(
                    "userId" to uid,
                    "name" to "P4",
                    "sortOrder" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
            )

            val demoSubjects = listOf(
                Triple("sub_math", "MATHEMATICS", 0L),
                Triple("sub_set", "SET+ICT", 1L),
                Triple("sub_srs", "SRS+RELIGIOUS", 2L),
                Triple("sub_eng", "ENGLISH", 3L),
                Triple("sub_kin", "KINYARWANDA", 4L),
                Triple("sub_fre", "FRENCH+KISWAHILI", 5L),
            )
            demoSubjects.forEach { (id, name, order) ->
                batch.set(
                    userRoot(uid).collection("subjects").document(id),
                    mapOf(
                        "userId" to uid,
                        "classId" to classRef.id,
                        "name" to name,
                        "maxTest" to 100L,
                        "maxExam" to 0L,
                        "sortOrder" to order,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }

            data class DemoStu(
                val id: String,
                val name: String,
                val idNo: String,
                val conduct: String,
                val lates: Long,
                val absences: Long,
                val obs: String,
                val scores: Map<String, Double>,
            )

            val demoStudents = listOf(
                DemoStu("stu_1", "MUGISHA KEVIN", "WIS-P4-001", "39", 0L, 0L, "Excellent performance. Keep it up!", mapOf("sub_math" to 92.0, "sub_set" to 88.0, "sub_srs" to 90.0, "sub_eng" to 86.0, "sub_kin" to 94.0, "sub_fre" to 84.0)),
                DemoStu("stu_2", "UWASE ALINE", "WIS-P4-002", "40", 0L, 0L, "Excellent performance. Keep it up!", mapOf("sub_math" to 88.0, "sub_set" to 84.0, "sub_srs" to 85.0, "sub_eng" to 90.0, "sub_kin" to 91.0, "sub_fre" to 82.0)),
                DemoStu("stu_3", "IRADUKUNDA ERIC", "WIS-P4-003", "38", 0L, 0L, "Very good work. Aim even higher.", mapOf("sub_math" to 80.0, "sub_set" to 76.0, "sub_srs" to 78.0, "sub_eng" to 74.0, "sub_kin" to 82.0, "sub_fre" to 75.0)),
                DemoStu("stu_4", "INEZA GRACE", "WIS-P4-004", "37", 1L, 0L, "Very good work. Aim even higher.", mapOf("sub_math" to 76.0, "sub_set" to 72.0, "sub_srs" to 74.0, "sub_eng" to 78.0, "sub_kin" to 80.0, "sub_fre" to 70.0)),
                DemoStu("stu_5", "HIRWA AUDREY", "WIS-P4-005", "35", 0L, 0L, "Good You can do better", mapOf("sub_math" to 72.0, "sub_set" to 56.0, "sub_srs" to 62.0, "sub_eng" to 72.0, "sub_kin" to 85.0, "sub_fre" to 56.0)),
                DemoStu("stu_6", "NIYONZIMA PATRICK", "WIS-P4-006", "36", 0L, 0L, "Good You can do better", mapOf("sub_math" to 72.0, "sub_set" to 64.0, "sub_srs" to 66.0, "sub_eng" to 65.0, "sub_kin" to 74.0, "sub_fre" to 62.0)),
                DemoStu("stu_7", "UMUTONI CLAIRE", "WIS-P4-007", "38", 0L, 0L, "Good You can do better", mapOf("sub_math" to 65.0, "sub_set" to 60.0, "sub_srs" to 68.0, "sub_eng" to 70.0, "sub_kin" to 76.0, "sub_fre" to 60.0)),
                DemoStu("stu_8", "HABIMANA JEAN", "WIS-P4-008", "34", 2L, 1L, "Fair effort. Needs more revision.", mapOf("sub_math" to 58.0, "sub_set" to 54.0, "sub_srs" to 60.0, "sub_eng" to 56.0, "sub_kin" to 72.0, "sub_fre" to 52.0)),
            )

            demoStudents.forEach { st ->
                batch.set(
                    userRoot(uid).collection("students").document(st.id),
                    mapOf(
                        "userId" to uid,
                        "classId" to classRef.id,
                        "name" to st.name,
                        "studentIdNo" to st.idNo,
                        "conduct" to st.conduct,
                        "latesCount" to st.lates,
                        "absencesCount" to st.absences,
                        "observation" to st.obs,
                        "testScores" to st.scores,
                        "examScores" to emptyMap<String, Double>(),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }

            // Seed demo attendance for today
            demoStudents.forEach { st ->
                val status = when {
                    st.absences > 0L -> AttendanceStatus.ABSENT.name
                    st.lates > 0L -> AttendanceStatus.LATE.name
                    else -> AttendanceStatus.PRESENT.name
                }
                val attId = "${classRef.id}_${todayDateKey}_${st.id}"
                batch.set(
                    userRoot(uid).collection("attendance").document(attId),
                    mapOf(
                        "userId" to uid,
                        "classId" to classRef.id,
                        "studentId" to st.id,
                        "dateKey" to todayDateKey,
                        "status" to status,
                        "note" to "",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }

            // Seed demo teacher assignments
            val demoTeachers = listOf(
                TeacherAssignment(
                    id = "ta_1",
                    teacherName = "Tr. Jean Bosco",
                    teacherEmail = "jbosco@trizzieschool.edu",
                    teacherPhone = "0788123456",
                    classId = classRef.id,
                    className = "P4",
                    subjectId = "sub_math",
                    subjectName = "MATHEMATICS",
                    roleType = TeacherRole.CLASS_TEACHER.name,
                    weeklyHours = 8L,
                    scheduleNote = "Mon–Fri • 08:00–09:30 & Homeroom",
                ),
                TeacherAssignment(
                    id = "ta_2",
                    teacherName = "Tr. Solange Mukamana",
                    teacherEmail = "smukamana@trizzieschool.edu",
                    teacherPhone = "0788654321",
                    classId = classRef.id,
                    className = "P4",
                    subjectId = "sub_eng",
                    subjectName = "ENGLISH",
                    roleType = TeacherRole.SUBJECT_TEACHER.name,
                    weeklyHours = 6L,
                    scheduleNote = "Mon, Wed, Fri • 10:00–12:00",
                ),
                TeacherAssignment(
                    id = "ta_3",
                    teacherName = "Tr. Patrick Niyonzima",
                    teacherEmail = "pniyonzima@trizzieschool.edu",
                    teacherPhone = "0783445566",
                    classId = classRef.id,
                    className = "P4",
                    subjectId = "sub_set",
                    subjectName = "SET+ICT",
                    roleType = TeacherRole.SUBJECT_TEACHER.name,
                    weeklyHours = 5L,
                    scheduleNote = "Tue, Thu • Computer Lab",
                ),
            )
            demoTeachers.forEach { ta ->
                batch.set(
                    userRoot(uid).collection("teacher_assignments").document(ta.id),
                    mapOf(
                        "userId" to uid,
                        "teacherName" to ta.teacherName,
                        "teacherEmail" to ta.teacherEmail,
                        "teacherPhone" to ta.teacherPhone,
                        "classId" to ta.classId,
                        "className" to ta.className,
                        "subjectId" to ta.subjectId,
                        "subjectName" to ta.subjectName,
                        "roleType" to ta.roleType,
                        "weeklyHours" to ta.weeklyHours,
                        "scheduleNote" to ta.scheduleNote,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }

            // Seed demo observation rules
            val demoRules = listOf(
                Triple("rule_1", 85L, "Excellent performance. Keep it up!"),
                Triple("rule_2", 70L, "Very good work. Aim even higher."),
                Triple("rule_3", 60L, "Good You can do better"),
                Triple("rule_4", 50L, "Fair effort. Needs more revision."),
                Triple("rule_5", 0L, "Below average. Extra effort required."),
            )
            demoRules.forEach { (id, minPct, text) ->
                batch.set(
                    userRoot(uid).collection("observation_rules").document(id),
                    mapOf(
                        "userId" to uid,
                        "minPct" to minPct,
                        "commentText" to text,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                )
            }

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }

    // Local branding image storage (avoids exceeding 1MB Firestore doc limit)
    suspend fun savePickedBrandingImage(uri: Uri, targetFileName: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val dir = File(appContext.filesDir, "branding").apply { mkdirs() }
            val input = appContext.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalStateException("Unable to open image"))
            val decoded = input.use { BitmapFactory.decodeStream(it) }
                ?: return@withContext Result.failure(IllegalStateException("Invalid image format"))

            val maxDim = 512f
            val scale = minOf(maxDim / decoded.width, maxDim / decoded.height, 1f)
            val scaled = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    decoded,
                    (decoded.width * scale).toInt().coerceAtLeast(1),
                    (decoded.height * scale).toInt().coerceAtLeast(1),
                    true,
                )
            } else {
                decoded
            }
            val destFile = File(dir, targetFileName)
            FileOutputStream(destFile).use { out ->
                scaled.compress(Bitmap.CompressFormat.PNG, 95, out)
            }
            Result.success(targetFileName)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun loadBrandingBitmap(fileName: String): Bitmap? {
        if (fileName.isBlank()) return null
        val file = File(File(appContext.filesDir, "branding"), fileName)
        if (!file.exists()) return null
        return BitmapFactory.decodeFile(file.absolutePath)
    }

    fun exportBackupJson(bundle: SchoolBackupBundle): String {
        val root = JSONObject()
        val cfg = bundle.config
        root.put("config", JSONObject().apply {
            put("country", cfg.country)
            put("schoolName", cfg.schoolName)
            put("poBox", cfg.poBox)
            put("tel", cfg.tel)
            put("ministry", cfg.ministry)
            put("academicYear", cfg.academicYear)
            put("term", cfg.term)
            put("reportTitle", cfg.reportTitle)
            put("teacherName", cfg.teacherName)
            put("showLogo", cfg.showLogo)
            put("logoSizeDp", cfg.logoSizeDp)
            put("logoCircular", cfg.logoCircular)
            put("signatureSizeDp", cfg.signatureSizeDp)
            put("borderColorHex", cfg.borderColorHex)
            put("headerBgHex", cfg.headerBgHex)
            put("reportFont", cfg.reportFont)
            put("positionFormat", cfg.positionFormat)
            put("decimalPlaces", cfg.decimalPlaces)
            put("conductMax", cfg.conductMax)
            put("manualStudentCount", cfg.manualStudentCount)
            put("passMark", cfg.passMark)
            put("autoApplyObservations", cfg.autoApplyObservations)
            put("labels", JSONObject(cfg.labels))
        })
        root.put("classes", JSONArray().apply {
            bundle.classes.forEach { c ->
                put(JSONObject().apply {
                    put("id", c.id)
                    put("name", c.name)
                    put("sortOrder", c.sortOrder)
                })
            }
        })
        root.put("subjects", JSONArray().apply {
            bundle.subjects.forEach { s ->
                put(JSONObject().apply {
                    put("id", s.id)
                    put("classId", s.classId)
                    put("name", s.name)
                    put("maxTest", s.maxTest)
                    put("maxExam", s.maxExam)
                    put("sortOrder", s.sortOrder)
                })
            }
        })
        root.put("students", JSONArray().apply {
            bundle.students.forEach { st ->
                put(JSONObject().apply {
                    put("id", st.id)
                    put("classId", st.classId)
                    put("name", st.name)
                    put("studentIdNo", st.studentIdNo)
                    put("conduct", st.conduct)
                    put("latesCount", st.latesCount)
                    put("absencesCount", st.absencesCount)
                    put("observation", st.observation)
                    put("testScores", JSONObject(st.testScores))
                    put("examScores", JSONObject(st.examScores))
                })
            }
        })
        root.put("teacherAssignments", JSONArray().apply {
            bundle.teacherAssignments.forEach { ta ->
                put(JSONObject().apply {
                    put("id", ta.id)
                    put("teacherName", ta.teacherName)
                    put("teacherEmail", ta.teacherEmail)
                    put("teacherPhone", ta.teacherPhone)
                    put("classId", ta.classId)
                    put("className", ta.className)
                    put("subjectId", ta.subjectId)
                    put("subjectName", ta.subjectName)
                    put("roleType", ta.roleType)
                    put("weeklyHours", ta.weeklyHours)
                    put("scheduleNote", ta.scheduleNote)
                })
            }
        })
        root.put("observationRules", JSONArray().apply {
            bundle.observationRules.forEach { r ->
                put(JSONObject().apply {
                    put("id", r.id)
                    put("minPct", r.minPct)
                    put("commentText", r.commentText)
                })
            }
        })
        return root.toString(2)
    }

    suspend fun importBackupJson(rawJson: String): Result<Unit> {
        var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}"
        return try {
            val uid = requireUserId()
            val root = JSONObject(rawJson)
            val ops = mutableListOf<(com.google.firebase.firestore.WriteBatch) -> Unit>()

            val cfgObj = root.optJSONObject("config")
            if (cfgObj != null) {
                val labelsObj = cfgObj.optJSONObject("labels")
                val labelsMap = mutableMapOf<String, String>()
                labelsObj?.keys()?.forEach { k ->
                    labelsMap[k.take(40)] = labelsObj.optString(k).take(60)
                }
                val cfgRef = userRoot(uid).collection("school_configs").document("default")
                docPath = cfgRef.path
                val existingCfg = cfgRef.get().await()
                val cfgFields = mapOf(
                    "country" to cfgObj.optString("country", "REPUBLIC OF RWANDA").take(100),
                    "schoolName" to cfgObj.optString("schoolName", "TRIZZIE SCHOOL").take(120).ifBlank { "TRIZZIE SCHOOL" },
                    "poBox" to cfgObj.optString("poBox", "").take(80),
                    "tel" to cfgObj.optString("tel", "").take(40),
                    "ministry" to cfgObj.optString("ministry", "").take(100),
                    "academicYear" to cfgObj.optString("academicYear", "2026/2027").take(40),
                    "term" to cfgObj.optString("term", "1st Term").take(40),
                    "reportTitle" to cfgObj.optString("reportTitle", "REPORT CARD").take(60),
                    "teacherName" to cfgObj.optString("teacherName", "").take(80),
                    "showLogo" to cfgObj.optBoolean("showLogo", true),
                    "logoFileName" to "",
                    "logoSizeDp" to cfgObj.optLong("logoSizeDp", 82L).coerceIn(30L, 160L),
                    "logoCircular" to cfgObj.optBoolean("logoCircular", true),
                    "signatureFileName" to "",
                    "signatureSizeDp" to cfgObj.optLong("signatureSizeDp", 48L).coerceIn(20L, 120L),
                    "borderColorHex" to cfgObj.optString("borderColorHex", "#1F2937").trim().take(9).let { if (it.length < 4) "#1F2937" else it },
                    "headerBgHex" to cfgObj.optString("headerBgHex", "#F8FAFC").trim().take(9).let { if (it.length < 4) "#F8FAFC" else it },
                    "reportFont" to if (cfgObj.optString("reportFont") == "sans") "sans" else "serif",
                    "positionFormat" to if (cfgObj.optString("positionFormat") == "fraction") "fraction" else "number_only",
                    "decimalPlaces" to cfgObj.optLong("decimalPlaces", 1L).coerceIn(0L, 2L),
                    "conductMax" to cfgObj.optString("conductMax", "").take(20),
                    "manualStudentCount" to cfgObj.optString("manualStudentCount", "").take(20),
                    "passMark" to cfgObj.optLong("passMark", 50L).coerceIn(0L, 100L),
                    "autoApplyObservations" to cfgObj.optBoolean("autoApplyObservations", false),
                    "labels" to (labelsMap.ifEmpty { defaultReportLabels() }),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                ops.add { batch ->
                    if (existingCfg.exists()) {
                        batch.update(cfgRef, cfgFields)
                    } else {
                        batch.set(cfgRef, cfgFields + mapOf("userId" to uid, "createdAt" to FieldValue.serverTimestamp()))
                    }
                }
            }

            val existingClassIds = userRoot(uid).collection("classes").get().await().documents.map { it.id }.toSet()
            val classesArr = root.optJSONArray("classes")
            if (classesArr != null) {
                for (i in 0 until classesArr.length()) {
                    val c = classesArr.getJSONObject(i)
                    val cid = c.optString("id").ifBlank { "imp_c_$i" }.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(128)
                    val ref = userRoot(uid).collection("classes").document(cid)
                    val fields = mapOf(
                        "name" to c.optString("name", "CLASS").trim().take(60).ifBlank { "CLASS" },
                        "sortOrder" to c.optLong("sortOrder", i.toLong()).coerceIn(0L, 10000L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                    ops.add { batch ->
                        if (cid in existingClassIds) {
                            batch.update(ref, fields)
                        } else {
                            batch.set(ref, fields + mapOf("userId" to uid, "createdAt" to FieldValue.serverTimestamp()))
                        }
                    }
                }
            }

            val existingSubjectIds = userRoot(uid).collection("subjects").get().await().documents.map { it.id }.toSet()
            val subjectsArr = root.optJSONArray("subjects")
            if (subjectsArr != null) {
                for (i in 0 until subjectsArr.length()) {
                    val s = subjectsArr.getJSONObject(i)
                    val sid = s.optString("id").ifBlank { "imp_s_$i" }.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(128)
                    val ref = userRoot(uid).collection("subjects").document(sid)
                    val classId = s.optString("classId").replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "class_p4" }.take(128)
                    val fields = mapOf(
                        "classId" to classId,
                        "name" to s.optString("name", "SUBJECT").trim().take(80).ifBlank { "SUBJECT" },
                        "maxTest" to s.optLong("maxTest", 100L).coerceIn(0L, 1000L),
                        "maxExam" to s.optLong("maxExam", 0L).coerceIn(0L, 1000L),
                        "sortOrder" to s.optLong("sortOrder", i.toLong()).coerceIn(0L, 10000L),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                    ops.add { batch ->
                        if (sid in existingSubjectIds) {
                            batch.update(ref, fields)
                        } else {
                            batch.set(ref, fields + mapOf("userId" to uid, "createdAt" to FieldValue.serverTimestamp()))
                        }
                    }
                }
            }

            val existingStudentIds = userRoot(uid).collection("students").get().await().documents.map { it.id }.toSet()
            val studentsArr = root.optJSONArray("students")
            if (studentsArr != null) {
                for (i in 0 until studentsArr.length()) {
                    val st = studentsArr.getJSONObject(i)
                    val stid = st.optString("id").ifBlank { "imp_st_$i" }.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(128)
                    val testScores = mutableMapOf<String, Double>()
                    st.optJSONObject("testScores")?.let { obj ->
                        obj.keys().asSequence().take(40).forEach { k -> testScores[k] = obj.optDouble(k, 0.0) }
                    }
                    val examScores = mutableMapOf<String, Double>()
                    st.optJSONObject("examScores")?.let { obj ->
                        obj.keys().asSequence().take(40).forEach { k -> examScores[k] = obj.optDouble(k, 0.0) }
                    }
                    val ref = userRoot(uid).collection("students").document(stid)
                    val classId = st.optString("classId").replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "class_p4" }.take(128)
                    val fields = mapOf(
                        "classId" to classId,
                        "name" to st.optString("name", "STUDENT").trim().take(100).ifBlank { "STUDENT" },
                        "studentIdNo" to st.optString("studentIdNo", "").take(40),
                        "conduct" to st.optString("conduct", "").take(20),
                        "latesCount" to st.optLong("latesCount", 0L).coerceIn(0L, 1000L),
                        "absencesCount" to st.optLong("absencesCount", 0L).coerceIn(0L, 1000L),
                        "observation" to st.optString("observation", "").take(240),
                        "testScores" to testScores,
                        "examScores" to examScores,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                    ops.add { batch ->
                        if (stid in existingStudentIds) {
                            batch.update(ref, fields)
                        } else {
                            batch.set(ref, fields + mapOf("userId" to uid, "createdAt" to FieldValue.serverTimestamp()))
                        }
                    }
                }
            }

            val existingTeacherIds = userRoot(uid).collection("teacher_assignments").get().await().documents.map { it.id }.toSet()
            val teachersArr = root.optJSONArray("teacherAssignments")
            if (teachersArr != null) {
                for (i in 0 until teachersArr.length()) {
                    val ta = teachersArr.getJSONObject(i)
                    val taId = ta.optString("id").ifBlank { "imp_ta_$i" }.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(128)
                    val ref = userRoot(uid).collection("teacher_assignments").document(taId)
                    val classId = ta.optString("classId", "class_p4").replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "class_p4" }.take(128)
                    val fields = mapOf(
                        "teacherName" to ta.optString("teacherName", "Teacher").trim().take(100).ifBlank { "Teacher" },
                        "teacherEmail" to ta.optString("teacherEmail", "").take(120),
                        "teacherPhone" to ta.optString("teacherPhone", "").take(40),
                        "classId" to classId,
                        "className" to ta.optString("className", "P4").trim().take(60).ifBlank { "P4" },
                        "subjectId" to ta.optString("subjectId", "").replace(Regex("[^a-zA-Z0-9_-]"), "_").take(128),
                        "subjectName" to ta.optString("subjectName", "").take(80),
                        "roleType" to TeacherRole.fromRaw(ta.optString("roleType")).name,
                        "weeklyHours" to ta.optLong("weeklyHours", 4L).coerceIn(0L, 80L),
                        "scheduleNote" to ta.optString("scheduleNote", "").take(200),
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                    ops.add { batch ->
                        if (taId in existingTeacherIds) {
                            batch.update(ref, fields)
                        } else {
                            batch.set(ref, fields + mapOf("userId" to uid, "createdAt" to FieldValue.serverTimestamp()))
                        }
                    }
                }
            }

            val existingRuleIds = userRoot(uid).collection("observation_rules").get().await().documents.map { it.id }.toSet()
            val rulesArr = root.optJSONArray("observationRules")
            if (rulesArr != null) {
                for (i in 0 until rulesArr.length()) {
                    val r = rulesArr.getJSONObject(i)
                    val rid = r.optString("id").ifBlank { "imp_rule_$i" }.replace(Regex("[^a-zA-Z0-9_-]"), "_").take(128)
                    val ref = userRoot(uid).collection("observation_rules").document(rid)
                    val comment = r.optString("commentText", "Keep working hard.").trim().take(200).ifBlank { "Keep working hard." }
                    val fields = mapOf(
                        "minPct" to r.optLong("minPct", 0L).coerceIn(0L, 100L),
                        "commentText" to comment,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    )
                    ops.add { batch ->
                        if (rid in existingRuleIds) {
                            batch.update(ref, fields)
                        } else {
                            batch.set(ref, fields + mapOf("userId" to uid, "createdAt" to FieldValue.serverTimestamp()))
                        }
                    }
                }
            }

            ops.chunked(450).forEach { chunk ->
                val batch = db.batch()
                chunk.forEach { applyOp -> applyOp(batch) }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docPath)
            Result.failure(e)
        }
    }
}
