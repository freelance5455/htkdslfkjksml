package com.example.data.parser

import com.example.data.model.CloudLayer
import com.example.data.model.MetarData
import java.util.regex.Pattern

object MetarParser {

  private val WIND_PATTERN = Pattern.compile("\\b(\\d{3}|VRB)(\\d{2,3})(?:G(\\d{2,3}))?KT\\b")
  private val WIND_VAR_PATTERN = Pattern.compile("\\b(\\d{3})V(\\d{3})\\b")
  private val VIS_METERS_PATTERN = Pattern.compile("\\b(\\d{4})\\b")
  private val VIS_SM_PATTERN = Pattern.compile("\\b(?:(\\d+)\\s+)?(\\d+/\\d+|\\d+)SM\\b")
  private val TEMP_DEW_PATTERN = Pattern.compile("\\b(M?\\d{2})/(M?\\d{2})\\b")
  private val QNH_HPA_PATTERN = Pattern.compile("\\bQ(\\d{4})\\b")
  private val QNH_INHG_PATTERN = Pattern.compile("\\bA(\\d{4})\\b")
  private val CLOUD_PATTERN = Pattern.compile("\\b(FEW|SCT|BKN|OVC|VV)(\\d{3})(CB|TCU)?\\b")
  private val RVR_PATTERN = Pattern.compile("\\b(R\\d{2}[LCR]?/[MP]?\\d{4}[VNDU]?)\\b")
  private val PRESENT_WX_PATTERN = Pattern.compile("\\b([+-]?(?:VC)?(?:MI|PR|BC|DR|BL|SH|TS|FZ)?(?:DZ|RA|SN|SG|IC|PL|GR|GS|UP|BR|FG|FU|VA|DU|SA|HZ|PY|PO|SQ|FC|SS|DS))\\b")

  fun parse(raw: String, icaoFallback: String = ""): MetarData {
    val clean = raw.trim().replace("\n", " ").replace("\\s+".toRegex(), " ")
    val isSpeci = clean.startsWith("SPECI") || clean.contains(" SPECI ")

    val tokens = clean.split(" ")
    var icao = icaoFallback
    var obsTimeUtc = ""

    for (i in 0 until minOf(tokens.size, 4)) {
      val token = tokens[i]
      if (token.length == 4 && token.all { it.isLetter() } && token != "METAR" && token != "SPECI") {
        icao = token
      } else if (token.endsWith("Z") && token.length == 7 && token.substring(0, 6).all { it.isDigit() }) {
        obsTimeUtc = token
      }
    }

    try {
      // Wind
      var windDirDeg: Int? = null
      var windSpeedKt: Int? = null
      var windGustKt: Int? = null
      var isWindCalm = false
      var isWindVariable = false

      val windMatcher = WIND_PATTERN.matcher(clean)
      if (windMatcher.find()) {
        val dirStr = windMatcher.group(1)
        val spdStr = windMatcher.group(2)
        val gustStr = windMatcher.group(3)

        if (dirStr == "VRB") {
          isWindVariable = true
        } else {
          windDirDeg = dirStr?.toIntOrNull()
        }

        windSpeedKt = spdStr?.toIntOrNull()
        if (windSpeedKt == 0) isWindCalm = true
        windGustKt = gustStr?.toIntOrNull()
      }

      var windVarFrom: Int? = null
      var windVarTo: Int? = null
      val windVarMatcher = WIND_VAR_PATTERN.matcher(clean)
      if (windVarMatcher.find()) {
        windVarFrom = windVarMatcher.group(1)?.toIntOrNull()
        windVarTo = windVarMatcher.group(2)?.toIntOrNull()
      }

      // CAVOK
      val isCavok = clean.contains("CAVOK")

      // Visibility
      var visMeters: Int? = null
      var visSm: String? = null
      if (isCavok) {
        visMeters = 9999
        visSm = "6+"
      } else {
        val visMatcher = VIS_METERS_PATTERN.matcher(clean)
        while (visMatcher.find()) {
          val num = visMatcher.group(1)?.toIntOrNull()
          if (num != null && (num in 0..9999) && !clean.contains("Q$num") && !clean.contains("A$num")) {
            // Check it's not the time token
            if (obsTimeUtc.startsWith(num.toString())) continue
            visMeters = num
            break
          }
        }
        val smMatcher = VIS_SM_PATTERN.matcher(clean)
        if (smMatcher.find()) {
          visSm = smMatcher.group(0)
        }
      }

      // Temperature & Dew point
      var tempC: Double? = null
      var dewpC: Double? = null
      val tdMatcher = TEMP_DEW_PATTERN.matcher(clean)
      if (tdMatcher.find()) {
        val tStr = tdMatcher.group(1)
        val dStr = tdMatcher.group(2)
        tempC = parseTemp(tStr)
        dewpC = parseTemp(dStr)
      }

      // Altimeter QNH
      var altHpa: Double? = null
      var altInHg: Double? = null
      val qnhMatcher = QNH_HPA_PATTERN.matcher(clean)
      if (qnhMatcher.find()) {
        altHpa = qnhMatcher.group(1)?.toDoubleOrNull()
      }
      val inHgMatcher = QNH_INHG_PATTERN.matcher(clean)
      if (inHgMatcher.find()) {
        val rawInHg = inHgMatcher.group(1)?.toDoubleOrNull()
        if (rawInHg != null) {
          altInHg = rawInHg / 100.0
          if (altHpa == null) {
            altHpa = (altInHg * 33.8639)
          }
        }
      }

      // Clouds & Ceiling
      val clouds = mutableListOf<CloudLayer>()
      val cloudMatcher = CLOUD_PATTERN.matcher(clean)
      var lowestCeilingFt: Int? = null
      while (cloudMatcher.find()) {
        val cov = cloudMatcher.group(1) ?: "CLR"
        val baseHund = cloudMatcher.group(2)?.toIntOrNull() ?: 0
        val baseFt = baseHund * 100
        val type = cloudMatcher.group(3)
        clouds.add(CloudLayer(cover = cov, baseFt = baseFt, type = type))
        if ((cov == "BKN" || cov == "OVC" || cov == "VV") && (lowestCeilingFt == null || baseFt < lowestCeilingFt)) {
          lowestCeilingFt = baseFt
        }
      }

      val cloudSummary = if (isCavok) {
        "CAVOK (دید بالای ۱۰ کیلومتر و بدون ابر زیر ۱۵۰۰ متر)"
      } else if (clouds.isEmpty()) {
        if (clean.contains("CLR") || clean.contains("SKC") || clean.contains("NSC")) "صاف / بدون ابر قابل توجه (NSC/SKC)" else "بدون گزارش ابر"
      } else {
        clouds.joinToString(", ") { "${it.cover} ${it.baseFt}ft${if (it.type != null) " ${it.type}" else ""}" }
      }

      // RVR
      var rvrStr: String? = null
      val rvrMatcher = RVR_PATTERN.matcher(clean)
      if (rvrMatcher.find()) {
        rvrStr = rvrMatcher.group(1)
      }

      // Present Weather
      val wxList = mutableListOf<String>()
      val wxMatcher = PRESENT_WX_PATTERN.matcher(clean)
      while (wxMatcher.find()) {
        val wx = wxMatcher.group(1)
        if (wx != null && wx != "METAR" && wx != "SPECI" && wx != "TEMPO" && wx != "BECMG") {
          wxList.add(wx)
        }
      }
      val presentWeather = if (wxList.isNotEmpty()) wxList.joinToString(" ") else null

      // Trend
      val trend = when {
        clean.contains("NOSIG") -> "NOSIG"
        clean.contains("BECMG") -> "BECMG"
        clean.contains("TEMPO") -> "TEMPO"
        else -> null
      }

      // Flight Category
      val category = computeFlightCategory(visMeters, visSm, lowestCeilingFt, isCavok)

      return MetarData(
        icao = icao.ifBlank { icaoFallback },
        rawMetar = raw,
        isSpeci = isSpeci,
        obsTimeUtc = obsTimeUtc,
        windDirDeg = windDirDeg,
        windSpeedKt = windSpeedKt,
        windGustKt = windGustKt,
        windVariableFromDeg = windVarFrom,
        windVariableToDeg = windVarTo,
        isWindCalm = isWindCalm,
        isWindVariable = isWindVariable,
        visibilityMeters = visMeters,
        visibilitySm = visSm,
        isCavok = isCavok,
        rvr = rvrStr,
        presentWeather = presentWeather,
        tempC = tempC,
        dewPointC = dewpC,
        altimeterHpa = altHpa,
        altimeterInHg = altInHg,
        ceilingFt = lowestCeilingFt,
        flightCategory = category,
        cloudsSummary = cloudSummary,
        trend = trend,
        parsingFailed = false
      )
    } catch (_: Exception) {
      return MetarData(
        icao = icao.ifBlank { icaoFallback },
        rawMetar = raw,
        isSpeci = isSpeci,
        obsTimeUtc = obsTimeUtc,
        flightCategory = "UNKNOWN",
        parsingFailed = true
      )
    }
  }

  private fun parseTemp(str: String?): Double? {
    if (str == null) return null
    return if (str.startsWith("M")) {
      -(str.substring(1).toDoubleOrNull() ?: 0.0)
    } else {
      str.toDoubleOrNull()
    }
  }

  private fun computeFlightCategory(
    visMeters: Int?,
    visSm: String?,
    ceilingFt: Int?,
    isCavok: Boolean
  ): String {
    if (isCavok) return "VFR"

    val effectiveVisMeters = visMeters ?: when {
      visSm?.contains("6+") == true || visSm?.contains("10") == true -> 10000
      visSm?.contains("5") == true -> 8000
      visSm?.contains("3") == true -> 5000
      visSm?.contains("1") == true -> 1600
      visSm?.contains("1/2") == true -> 800
      else -> null
    }

    val ceiling = ceilingFt ?: 10000 // If no ceiling, assume high
    val vis = effectiveVisMeters ?: 10000

    return when {
      ceiling < 500 || vis < 1600 -> "LIFR"
      ceiling < 1000 || vis < 5000 -> "IFR"
      ceiling <= 3000 || vis <= 8000 -> "MVFR"
      else -> "VFR"
    }
  }
}
