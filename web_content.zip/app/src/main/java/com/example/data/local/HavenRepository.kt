package com.example.data.local

import com.example.data.model.CareCategory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class HavenRepository(private val dao: HavenDao) {

    fun observeCareLogsForDay(epochDay: Long): Flow<List<CareLogEntity>> =
        dao.observeCareLogsForDay(epochDay)

    fun observeAllCareLogs(): Flow<List<CareLogEntity>> =
        dao.observeAllCareLogs()

    suspend fun logCare(category: CareCategory, epochDay: Long, count: Int = 1, note: String = "") {
        dao.insertCareLog(
            CareLogEntity(
                categoryKey = category.key,
                dateEpochDay = epochDay,
                countAdded = count,
                note = note
            )
        )
    }

    fun observeDiaryEntries(): Flow<List<DiaryEntryEntity>> = dao.observeDiaryEntries()

    suspend fun saveDiaryEntry(
        title: String,
        content: String,
        moodKey: String,
        energyScore: Int,
        isVoiceTyped: Boolean,
        detectedCue: String = "",
        aiSupportResponse: String = ""
    ) {
        dao.insertDiaryEntry(
            DiaryEntryEntity(
                title = title,
                content = content,
                moodKey = moodKey,
                energyScore = energyScore,
                isVoiceTyped = isVoiceTyped,
                detectedCue = detectedCue,
                aiSupportResponse = aiSupportResponse
            )
        )
    }

    suspend fun deleteDiaryEntry(id: Int) = dao.deleteDiaryEntry(id)

    fun observeCycleLogs(): Flow<List<CycleLogEntity>> = dao.observeCycleLogs()

    suspend fun logCycleDay(
        epochDay: Long,
        flowLevel: String,
        crampsLevel: Int,
        symptoms: String,
        notes: String
    ) {
        dao.insertCycleLog(
            CycleLogEntity(
                dateEpochDay = epochDay,
                flowLevel = flowLevel,
                crampsLevel = crampsLevel,
                symptoms = symptoms,
                notes = notes
            )
        )
    }

    fun observeVitalityLogs(): Flow<List<VitalityLogEntity>> = dao.observeVitalityLogs()

    suspend fun logVitality(
        epochDay: Long,
        workoutMinutes: Int,
        workoutType: String,
        proteinMeals: Int,
        hydrationAndZincDone: Boolean,
        sleepHours: Float,
        notes: String
    ) {
        dao.insertVitalityLog(
            VitalityLogEntity(
                dateEpochDay = epochDay,
                workoutMinutes = workoutMinutes,
                workoutType = workoutType,
                proteinMeals = proteinMeals,
                hydrationAndZincDone = hydrationAndZincDone,
                sleepHours = sleepHours,
                notes = notes
            )
        )
    }

    fun observeHormoneChecks(): Flow<List<HormoneCheckEntity>> = dao.observeHormoneChecks()

    suspend fun saveHormoneCheck(check: HormoneCheckEntity) = dao.insertHormoneCheck(check)

    fun observeEmergencyContacts(): Flow<List<EmergencyContactEntity>> = dao.observeEmergencyContacts()

    suspend fun addEmergencyContact(name: String, phone: String, relationship: String) {
        dao.insertEmergencyContact(
            EmergencyContactEntity(
                name = name,
                phone = phone,
                relationship = relationship
            )
        )
    }

    suspend fun deleteEmergencyContact(id: Int) = dao.deleteEmergencyContact(id)

    fun observeSosMessages(): Flow<List<SosMessageEntity>> = dao.observeSosMessages()

    suspend fun logSosMessage(message: SosMessageEntity) = dao.insertSosMessage(message)

    fun observeReminderSchedules(): Flow<List<ReminderScheduleEntity>> = dao.observeReminderSchedules()

    suspend fun upsertReminderSchedule(schedule: ReminderScheduleEntity) =
        dao.upsertReminderSchedule(schedule)

    suspend fun ensureDefaultReminders() {
        val existing = dao.observeReminderSchedules().first()
        if (existing.isEmpty()) {
            CareCategory.entries.forEach { category ->
                dao.upsertReminderSchedule(
                    ReminderScheduleEntity(
                        categoryKey = category.key,
                        hour = category.defaultHour,
                        minute = category.defaultMinute,
                        enabled = true
                    )
                )
            }
        }
    }
}
