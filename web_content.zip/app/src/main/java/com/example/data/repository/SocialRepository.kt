package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.BlockedUser
import com.example.data.model.FriendEdge
import com.example.data.model.FriendRequest
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class SocialRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing social features.")

    fun observeFriends(userId: String): Flow<List<FriendEdge>> = flow {
        val path = "users/$userId/friends"
        emitAll(
            db.collection("users").document(userId).collection("friends")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FriendEdge::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.friendUsername }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeIncomingRequests(userId: String): Flow<List<FriendRequest>> = flow {
        val path = "friendRequests"
        emitAll(
            db.collection("friendRequests")
                .whereEqualTo("toUid", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FriendRequest::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).filter { it.status == "pending" }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeOutgoingRequests(userId: String): Flow<List<FriendRequest>> = flow {
        val path = "friendRequests"
        emitAll(
            db.collection("friendRequests")
                .whereEqualTo("fromUid", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        FriendRequest::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).filter { it.status == "pending" }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeBlockedUsers(userId: String): Flow<List<BlockedUser>> = flow {
        val path = "users/$userId/blocked"
        emitAll(
            db.collection("users").document(userId).collection("blocked")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        BlockedUser::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun searchUserByUsername(query: String): Result<List<UserProfile>> = runCatching {
        val uid = requireUserId()
        val clean = query.trim().lowercase()
        if (clean.isBlank()) return@runCatching emptyList()
        val path = "users"
        try {
            val exactSnap = db.collection("users")
                .whereEqualTo("username", clean)
                .limit(10)
                .get()
                .await()
            exactSnap.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                .filter { it.userId != uid && it.allowFriendRequests != "nobody" }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            throw e
        }
    }

    suspend fun sendFriendRequest(fromUser: UserProfile, toUser: UserProfile): Result<String> = runCatching {
        val uid = requireUserId()
        require(uid == fromUser.userId)
        require(toUser.userId != uid) { "You cannot add yourself." }
        require(toUser.allowFriendRequests != "nobody") { "This user does not accept friend requests." }

        val safeFromUsername = fromUser.username.trim().take(30).ifBlank { "player" }
        val safeFromAvatar = fromUser.avatarPreset.trim().take(40).ifBlank { "prism_cyan" }
        val safeToUsername = toUser.username.trim().take(30).ifBlank { "player" }

        val reqId = "${uid}_${toUser.userId}"
        val reqRef = db.collection("friendRequests").document(reqId)
        val reverseReqRef = db.collection("friendRequests").document("${toUser.userId}_${uid}")
        val myBlockedRef = db.collection("users").document(uid).collection("blocked").document(toUser.userId)
        val myFriendRef = db.collection("users").document(uid).collection("friends").document(toUser.userId)

        try {
            if (myBlockedRef.get().await().exists()) {
                throw IllegalStateException("Unblock @$safeToUsername before sending a friend request.")
            }
            if (myFriendRef.get().await().exists()) {
                throw IllegalStateException("You are already friends with @$safeToUsername.")
            }

            val reverseSnap = reverseReqRef.get().await()
            if (reverseSnap.exists() && reverseSnap.getString("status") == "pending") {
                throw IllegalStateException("@$safeToUsername already sent you a friend request! Tap Accept to connect.")
            }

            val existingSnap = reqRef.get().await()
            if (existingSnap.exists()) {
                when (existingSnap.getString("status")) {
                    "pending" -> return@runCatching reqId
                    "rejected", "cancelled", "accepted" -> {
                        reqRef.update(
                            mapOf(
                                "status" to "pending",
                                "fromUsername" to safeFromUsername,
                                "fromAvatar" to safeFromAvatar,
                                "toUsername" to safeToUsername,
                                "updatedAt" to FieldValue.serverTimestamp()
                            )
                        ).await()
                        return@runCatching reqId
                    }
                }
            }

            val payload = mapOf(
                "fromUid" to uid,
                "fromUsername" to safeFromUsername,
                "fromAvatar" to safeFromAvatar,
                "toUid" to toUser.userId,
                "toUsername" to safeToUsername,
                "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            reqRef.set(payload).await()
            reqId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, reqRef.path)
            throw e
        }
    }

    suspend fun acceptFriendRequest(request: FriendRequest, currentUser: UserProfile): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(uid == request.toUid)
        val reqRef = db.collection("friendRequests").document(request.id)
        val myFriendRef = db.collection("users").document(uid).collection("friends").document(request.fromUid)
        val theirFriendRef = db.collection("users").document(request.fromUid).collection("friends").document(uid)
        val myUserRef = db.collection("users").document(uid)

        val safeFromUsername = request.fromUsername.trim().take(30).ifBlank { "player" }
        val safeFromAvatar = request.fromAvatar.trim().take(40).ifBlank { "prism_cyan" }
        val safeMyUsername = currentUser.username.trim().take(30).ifBlank { "player" }
        val safeMyAvatar = currentUser.avatarPreset.trim().take(40).ifBlank { "prism_cyan" }
        val safeMyLevel = currentUser.level.coerceAtLeast(1L)

        try {
            val myFriendExists = myFriendRef.get().await().exists()
            val theirFriendExists = theirFriendRef.get().await().exists()

            val batch = db.batch()
            batch.update(reqRef, mapOf("status" to "accepted", "updatedAt" to FieldValue.serverTimestamp()))
            if (!myFriendExists) {
                batch.set(
                    myFriendRef,
                    mapOf(
                        "userId" to uid,
                        "friendUid" to request.fromUid,
                        "friendUsername" to safeFromUsername,
                        "friendAvatar" to safeFromAvatar,
                        "friendLevel" to 1L,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    myUserRef,
                    mapOf(
                        "friendsCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.update(
                    myFriendRef,
                    mapOf(
                        "friendUsername" to safeFromUsername,
                        "friendAvatar" to safeFromAvatar
                    )
                )
            }

            if (!theirFriendExists) {
                batch.set(
                    theirFriendRef,
                    mapOf(
                        "userId" to request.fromUid,
                        "friendUid" to uid,
                        "friendUsername" to safeMyUsername,
                        "friendAvatar" to safeMyAvatar,
                        "friendLevel" to safeMyLevel,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            } else {
                batch.update(
                    theirFriendRef,
                    mapOf(
                        "friendUsername" to safeMyUsername,
                        "friendAvatar" to safeMyAvatar,
                        "friendLevel" to safeMyLevel
                    )
                )
            }
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, reqRef.path)
            throw e
        }
    }

    suspend fun rejectFriendRequest(requestId: String): Result<Unit> = runCatching {
        requireUserId()
        val reqRef = db.collection("friendRequests").document(requestId)
        try {
            reqRef.update(mapOf("status" to "rejected", "updatedAt" to FieldValue.serverTimestamp())).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, reqRef.path)
            throw e
        }
    }

    suspend fun cancelFriendRequest(requestId: String): Result<Unit> = runCatching {
        requireUserId()
        val reqRef = db.collection("friendRequests").document(requestId)
        try {
            reqRef.update(mapOf("status" to "cancelled", "updatedAt" to FieldValue.serverTimestamp())).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, reqRef.path)
            throw e
        }
    }

    suspend fun removeFriend(friendUid: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val myRef = db.collection("users").document(uid).collection("friends").document(friendUid)
        val theirRef = db.collection("users").document(friendUid).collection("friends").document(uid)
        val batch = db.batch()
        batch.delete(myRef)
        batch.delete(theirRef)
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, myRef.path)
            throw e
        }
    }

    suspend fun blockUser(targetUid: String, targetUsername: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val blockRef = db.collection("users").document(uid).collection("blocked").document(targetUid)
        val myFriendRef = db.collection("users").document(uid).collection("friends").document(targetUid)
        val theirFriendRef = db.collection("users").document(targetUid).collection("friends").document(uid)
        val incomingReqRef = db.collection("friendRequests").document("${targetUid}_${uid}")
        val outgoingReqRef = db.collection("friendRequests").document("${uid}_${targetUid}")
        try {
            val incomingSnap = incomingReqRef.get().await()
            val outgoingSnap = outgoingReqRef.get().await()

            val batch = db.batch()
            batch.set(
                blockRef,
                mapOf(
                    "userId" to uid,
                    "blockedUid" to targetUid,
                    "blockedUsername" to targetUsername.take(30),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.delete(myFriendRef)
            batch.delete(theirFriendRef)
            if (incomingSnap.exists() && incomingSnap.getString("status") == "pending") {
                batch.update(
                    incomingReqRef,
                    mapOf("status" to "rejected", "updatedAt" to FieldValue.serverTimestamp())
                )
            }
            if (outgoingSnap.exists() && outgoingSnap.getString("status") == "pending") {
                batch.update(
                    outgoingReqRef,
                    mapOf("status" to "cancelled", "updatedAt" to FieldValue.serverTimestamp())
                )
            }
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, blockRef.path)
            throw e
        }
    }

    suspend fun unblockUser(targetUid: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val blockRef = db.collection("users").document(uid).collection("blocked").document(targetUid)
        try {
            blockRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, blockRef.path)
            throw e
        }
    }

    suspend fun submitReport(
        targetType: String,
        targetId: String,
        reason: String,
        details: String = ""
    ): Result<String> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("reports").document()
        val payload = mutableMapOf<String, Any>(
            "reporterId" to uid,
            "targetType" to targetType,
            "targetId" to targetId.take(128),
            "reason" to reason.take(100),
            "status" to "open",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (details.isNotBlank()) {
            payload["details"] = details.take(300)
        }
        try {
            docRef.set(payload).await()
            docRef.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }
}
