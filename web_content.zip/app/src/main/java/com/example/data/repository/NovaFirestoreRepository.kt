package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.UserMemory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class NovaFirestoreRepository(
    private val db: FirebaseFirestore?,
    private val auth: FirebaseAuth? = try { FirebaseAuth.getInstance() } catch (_: Exception) { null }
) {
    constructor(context: Context) : this(
        try {
            com.google.firebase.FirebaseApp.initializeApp(context.applicationContext)
            FirebaseFirestore.getInstance(
                context.applicationContext.getString(R.string.firestore_database_id)
            )
        } catch (_: Exception) {
            null
        },
        try {
            FirebaseAuth.getInstance()
        } catch (_: Exception) {
            null
        }
    )

    fun isFirebaseAuthenticated(): Boolean = db != null && auth?.currentUser != null

    private fun requireDb(): FirebaseFirestore {
        return db ?: throw IllegalStateException("Firestore instance is not initialized.")
    }

    private fun requireUserId(): String {
        return auth?.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Firebase Auth before accessing Firestore.")
    }

    // --- CONVERSATIONS ---

    fun observeConversations(userId: String): Flow<List<Conversation>> = flow {
        val firestore = db ?: run {
            emit(emptyList())
            return@flow
        }
        val path = "users/$userId/conversations"
        emitAll(
            firestore.collection("users").document(userId).collection("conversations")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }.sortedByDescending { (it.updatedAt ?: it.createdAt)?.seconds ?: 0L }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun getUserConversations(): Result<List<Conversation>> {
        return try {
            val uid = requireUserId()
            val path = "users/$uid/conversations"
            try {
                val snapshot = requireDb().collection("users").document(uid).collection("conversations")
                    .whereEqualTo("userId", uid)
                    .get()
                    .await()
                val list = snapshot.documents.mapNotNull { doc ->
                    doc.toObject(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                }.sortedByDescending { (it.updatedAt ?: it.createdAt)?.seconds ?: 0L }
                Result.success(list)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.LIST, path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getConversationById(ownerUid: String, conversationId: String): Result<Conversation?> {
        val path = "users/$ownerUid/conversations/$conversationId"
        return try {
            val doc = requireDb().collection("users").document(ownerUid)
                .collection("conversations").document(conversationId)
                .get()
                .await()
            Result.success(doc.toObject(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun createConversation(title: String, firstPreview: String = ""): Result<String> {
        return try {
            val uid = requireUserId()
            val cleanTitle = title.trim().ifEmpty { "New Chat" }.take(200)
            val cleanPreview = firstPreview.trim().take(500)
            val colRef = requireDb().collection("users").document(uid).collection("conversations")
            val docRef = colRef.document()
            val payload = mapOf(
                "userId" to uid,
                "title" to cleanTitle,
                "lastMessagePreview" to cleanPreview,
                "messageCount" to 0L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            try {
                docRef.set(payload).await()
                Result.success(docRef.id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, docRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun renameConversation(conversationId: String, newTitle: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            val cleanTitle = newTitle.trim().ifEmpty { "Conversation" }.take(200)
            val docRef = requireDb().collection("users").document(uid).collection("conversations").document(conversationId)
            try {
                docRef.update(
                    mapOf(
                        "title" to cleanTitle,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateConversationSummary(
        conversationId: String,
        title: String? = null,
        lastMessagePreview: String,
        messageCount: Long
    ): Result<Unit> {
        return try {
            val uid = requireUserId()
            val docRef = requireDb().collection("users").document(uid).collection("conversations").document(conversationId)
            val updates = mutableMapOf<String, Any>(
                "lastMessagePreview" to lastMessagePreview.take(500),
                "messageCount" to messageCount.coerceAtLeast(0L),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!title.isNullOrBlank()) {
                updates["title"] = title.trim().take(200)
            }
            try {
                docRef.update(updates).await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteConversation(conversationId: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            val convRef = requireDb().collection("users").document(uid).collection("conversations").document(conversationId)
            try {
                val msgs = convRef.collection("messages")
                    .whereEqualTo("userId", uid)
                    .get()
                    .await()
                for (msg in msgs.documents) {
                    msg.reference.delete().await()
                }
                convRef.delete().await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, convRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun clearAllConversations(): Result<Unit> {
        return try {
            val uid = requireUserId()
            val colRef = requireDb().collection("users").document(uid).collection("conversations")
            try {
                val convs = colRef.whereEqualTo("userId", uid).get().await()
                for (conv in convs.documents) {
                    deleteConversation(conv.id)
                }
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, colRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- MESSAGES ---

    fun observeMessages(userId: String, conversationId: String): Flow<List<ChatMessage>> = flow {
        val path = "users/$userId/conversations/$conversationId/messages"
        emitAll(
            requireDb().collection("users").document(userId)
                .collection("conversations").document(conversationId)
                .collection("messages")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }.sortedWith(compareBy({ it.createdAt?.seconds ?: Long.MAX_VALUE }, { it.createdAt?.nanoseconds ?: 0 }))
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun addMessage(
        conversationId: String,
        role: String,
        content: String,
        attachmentSummary: String? = null,
        generatedImageBase64: String? = null,
        citations: String? = null
    ): Result<String> {
        return try {
            val uid = requireUserId()
            val colRef = requireDb().collection("users").document(uid)
                .collection("conversations").document(conversationId)
                .collection("messages")
            val docRef = colRef.document()

            val rawMap = mutableMapOf<String, Any?>(
                "userId" to uid,
                "conversationId" to conversationId,
                "role" to if (role == "assistant") "assistant" else "user",
                "content" to content.take(50000),
                "attachmentSummary" to attachmentSummary?.take(2000),
                "generatedImageBase64" to generatedImageBase64?.take(750000),
                "citations" to citations?.take(4000),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val filteredPayload = rawMap.filterValues { it != null }.mapValues { it.value!! }

            try {
                docRef.set(filteredPayload).await()
                Result.success(docRef.id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, docRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateMessageContent(
        conversationId: String,
        messageId: String,
        newContent: String,
        generatedImageBase64: String? = null,
        citations: String? = null
    ): Result<Unit> {
        return try {
            val uid = requireUserId()
            val docRef = requireDb().collection("users").document(uid)
                .collection("conversations").document(conversationId)
                .collection("messages").document(messageId)
            val updates = mutableMapOf<String, Any>(
                "content" to newContent.take(50000),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (generatedImageBase64 != null) {
                updates["generatedImageBase64"] = generatedImageBase64.take(750000)
            }
            if (citations != null) {
                updates["citations"] = citations.take(4000)
            }
            try {
                docRef.update(updates).await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.UPDATE, docRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteMessage(conversationId: String, messageId: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            val docRef = requireDb().collection("users").document(uid)
                .collection("conversations").document(conversationId)
                .collection("messages").document(messageId)
            try {
                docRef.delete().await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, docRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // --- USER MEMORIES ---

    fun observeMemories(userId: String): Flow<List<UserMemory>> = flow {
        val path = "users/$userId/memories"
        emitAll(
            requireDb().collection("users").document(userId).collection("memories")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(UserMemory::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    }.sortedByDescending { (it.updatedAt ?: it.createdAt)?.seconds ?: 0L }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun addMemory(fact: String, category: String = "Preference"): Result<String> {
        return try {
            val uid = requireUserId()
            val cleanFact = fact.trim().take(1000)
            if (cleanFact.isEmpty()) return Result.failure(IllegalArgumentException("Memory fact cannot be empty"))
            val cleanCategory = category.trim().ifEmpty { "Preference" }.take(80)
            val colRef = requireDb().collection("users").document(uid).collection("memories")
            val docRef = colRef.document()
            val payload = mapOf(
                "userId" to uid,
                "fact" to cleanFact,
                "category" to cleanCategory,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            try {
                docRef.set(payload).await()
                Result.success(docRef.id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.CREATE, docRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteMemory(memoryId: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            val docRef = requireDb().collection("users").document(uid).collection("memories").document(memoryId)
            try {
                docRef.delete().await()
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, docRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun clearAllMemories(): Result<Unit> {
        return try {
            val uid = requireUserId()
            val colRef = requireDb().collection("users").document(uid).collection("memories")
            try {
                val snap = colRef.whereEqualTo("userId", uid).get().await()
                for (doc in snap.documents) {
                    doc.reference.delete().await()
                }
                Result.success(Unit)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.DELETE, colRef.path)
                Result.failure(e)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
