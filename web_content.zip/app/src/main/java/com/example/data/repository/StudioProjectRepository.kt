package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.StudioProject
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserSubscription
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class StudioProjectRepository(
    private val db: FirebaseFirestore
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth get() = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeProjects(userId: String = auth.currentUser?.uid.orEmpty()): Flow<List<StudioProject>> {
        if (userId.isBlank()) {
            return flowOf(emptyList())
        }
        val path = COLLECTION_PROJECTS
        return db.collection(COLLECTION_PROJECTS)
            .whereEqualTo("userId", userId)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.mapNotNull { doc ->
                    doc.toObject(
                        StudioProject::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }.sortedWith(
                    compareByDescending<StudioProject> { it.isPinned }
                        .thenByDescending { it.createdAt?.seconds ?: 0L }
                )
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, path)
                }
                throw error
            }
    }

    fun observeUserSubscription(userId: String = auth.currentUser?.uid.orEmpty()): Flow<UserSubscription> {
        if (userId.isBlank()) {
            return flowOf(UserSubscription())
        }
        val path = "$COLLECTION_SUBSCRIPTIONS/$userId"
        return db.collection(COLLECTION_SUBSCRIPTIONS)
            .document(userId)
            .snapshots()
            .map { doc ->
                if (doc.exists()) {
                    doc.toObject(
                        UserSubscription::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ) ?: UserSubscription(userId = userId)
                } else {
                    UserSubscription(
                        userId = userId,
                        planId = SubscriptionTier.FREE.planId,
                        status = "FREE_TIER",
                        monthlyGenerationsUsed = 0,
                        monthlyGenerationLimit = SubscriptionTier.FREE.monthlyGenerationLimit
                    )
                }
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.GET, path)
                }
                emit(UserSubscription(userId = userId))
            }
    }

    suspend fun saveUserSubscription(subscription: UserSubscription): Result<Unit> {
        val uid = requireUserId()
        val path = "$COLLECTION_SUBSCRIPTIONS/$uid"
        return try {
            val payload = mapOf(
                "userId" to uid,
                "planId" to subscription.planId,
                "status" to subscription.status,
                "stripeSessionId" to subscription.stripeSessionId.take(200),
                "stripeSubscriptionId" to subscription.stripeSubscriptionId.take(200),
                "stripeCustomerEmail" to subscription.stripeCustomerEmail.take(200),
                "monthlyGenerationsUsed" to subscription.monthlyGenerationsUsed.coerceIn(0, 100000),
                "monthlyGenerationLimit" to subscription.monthlyGenerationLimit.coerceIn(1, 100000),
                "currentPeriodEndEpochSec" to subscription.currentPeriodEndEpochSec.coerceAtLeast(0L),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection(COLLECTION_SUBSCRIPTIONS)
                .document(uid)
                .set(payload)
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    suspend fun incrementMonthlyGenerationCount(current: UserSubscription): Result<Unit> {
        val uid = requireUserId()
        val updated = current.copy(
            userId = uid,
            monthlyGenerationsUsed = (current.monthlyGenerationsUsed + 1).coerceAtMost(100000)
        )
        return saveUserSubscription(updated)
    }

    suspend fun getUserProjects(): Result<List<StudioProject>> {
        val path = COLLECTION_PROJECTS
        return try {
            val uid = requireUserId()
            val snapshot = db.collection(COLLECTION_PROJECTS)
                .whereEqualTo("userId", uid)
                .get()
                .await()
            val items = snapshot.documents.mapNotNull { doc ->
                doc.toObject(
                    StudioProject::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
            Result.success(items)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun getProjectById(projectId: String): Result<StudioProject> {
        val path = "$COLLECTION_PROJECTS/$projectId"
        return try {
            val doc = db.collection(COLLECTION_PROJECTS)
                .document(projectId)
                .get()
                .await()
            val project = doc.toObject(
                StudioProject::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: throw NoSuchElementException("Project not found: $projectId")
            Result.success(project)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun createProject(project: StudioProject): Result<String> {
        val docId = project.id.ifBlank { "proj_${UUID.randomUUID().toString().replace("-", "").take(20)}" }
        val path = "$COLLECTION_PROJECTS/$docId"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "userId" to uid,
                "title" to project.title.take(120).ifBlank { "Untitled Studio Project" },
                "prompt" to project.prompt.take(4000).ifBlank { "Custom studio prompt" },
                "provider" to project.provider,
                "modelId" to project.modelId.take(80),
                "summary" to project.summary.take(2000).ifBlank { "Generated Android Compose application." },
                "sandboxSpecJson" to project.sandboxSpecJson.take(60000).ifBlank { "{}" },
                "kotlinCode" to project.kotlinCode.take(100000).ifBlank { "// Kotlin source" },
                "manifestXml" to project.manifestXml.take(20000).ifBlank { "<manifest/>" },
                "buildGradleKts" to project.buildGradleKts.take(20000).ifBlank { "plugins {}" },
                "isPinned" to project.isPinned,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection(COLLECTION_PROJECTS)
                .document(docId)
                .set(payload)
                .await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateProject(project: StudioProject): Result<Unit> {
        require(project.id.isNotBlank()) { "Project ID must not be blank for update" }
        val path = "$COLLECTION_PROJECTS/${project.id}"
        return try {
            requireUserId()
            val updates = mapOf(
                "title" to project.title.take(120).ifBlank { "Untitled Studio Project" },
                "prompt" to project.prompt.take(4000).ifBlank { "Custom studio prompt" },
                "provider" to project.provider,
                "modelId" to project.modelId.take(80),
                "summary" to project.summary.take(2000).ifBlank { "Generated Android Compose application." },
                "sandboxSpecJson" to project.sandboxSpecJson.take(60000).ifBlank { "{}" },
                "kotlinCode" to project.kotlinCode.take(100000).ifBlank { "// Kotlin source" },
                "manifestXml" to project.manifestXml.take(20000).ifBlank { "<manifest/>" },
                "buildGradleKts" to project.buildGradleKts.take(20000).ifBlank { "plugins {}" },
                "isPinned" to project.isPinned,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection(COLLECTION_PROJECTS)
                .document(project.id)
                .update(updates)
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun togglePin(project: StudioProject): Result<Unit> {
        require(project.id.isNotBlank()) { "Project ID must not be blank for update" }
        val path = "$COLLECTION_PROJECTS/${project.id}"
        return try {
            requireUserId()
            db.collection(COLLECTION_PROJECTS)
                .document(project.id)
                .update(
                    mapOf(
                        "isPinned" to !project.isPinned,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteProject(projectId: String): Result<Unit> {
        require(projectId.isNotBlank()) { "Project ID must not be blank for delete" }
        val path = "$COLLECTION_PROJECTS/$projectId"
        return try {
            requireUserId()
            db.collection(COLLECTION_PROJECTS)
                .document(projectId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    companion object {
        const val COLLECTION_PROJECTS = "studio_projects"
        const val COLLECTION_SUBSCRIPTIONS = "user_subscriptions"
    }
}
