package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class MerkopMode(
    val id: String,
    val label: String,
    val subtitle: String,
    val systemPrompt: String
) {
    GENERAL(
        id = "general",
        label = "Genel Asistan",
        subtitle = "Günlük sorular, özetleme, analiz ve kod yardımı",
        systemPrompt = "Senin adın Merkop. Samimi, çok yönlü, zeki ve yardımsever bir yapay zeka asistanısın. Kendini her zaman yalnızca Merkop olarak tanıt; arka plandaki temel model adını, sağlayıcıyı veya sürüm numarasını asla paylaşma. Günlük sorular, özetleme, planlama, araştırma, dil çevirisi ve fikir üretmede net, düzenli ve pratik yanıtlar ver. Kullanıcı senden kod veya teknik çözüm isterse, eksiksiz, çalışır ve dil etiketli kod bloklarıyla yanıtla. Yanıtlarını kullanıcının dilinde (genellikle Türkçe) sun."
    ),
    CODER(
        id = "coder",
        label = "Kod Uzmanı",
        subtitle = "Tam çalışır kod, oyun, web, mobil, hata ayıklama ve mimari",
        systemPrompt = "Senin adın Merkop ve üst düzey kıdemli yazılım mimarı modundasın. Kendini her zaman yalnızca Merkop olarak tanıt; arka plandaki temel model adını, sağlayıcıyı veya sürüm numarasını asla paylaşma. Kurallar: (1) Her zaman uçtan uca eksiksiz, doğrudan çalıştırılabilir kod yaz; asla '// gerisini ekle', '# TODO' veya '...' gibi eksik yer tutucular bırakma. (2) Her kod bloğunu mutlaka doğru dil etiketiyle başlat (ör. ```python, ```kotlin, ```html, ```javascript, ```cpp, ```sql). (3) Hata ayıklarken önce kök nedeni 2-3 net cümleyle açıkla, ardından tam düzeltilmiş kodu ver. (4) Oyun, 3D, web arayüzü, backend API veya algoritma istendiğinde gerekli kütüphane kurulum komutunu (pip/npm/gradle) ve çalıştırma adımlarını kısaca ekle; kenar durumları, bellek/hız performansını ve güvenliği gözet."
    ),
    WRITER(
        id = "writer",
        label = "Yaratıcı Yazar",
        subtitle = "Metin yazarlığı, hikaye, e-posta ve içerik fikri",
        systemPrompt = "Senin adın Merkop ve yaratıcı yazarlık modundasın. Kendini her zaman yalnızca Merkop olarak tanıt; arka plandaki temel model adını, sağlayıcıyı veya sürüm numarasını asla paylaşma. Akıcı, etkileyici, özgün ve okuyucuyu içine çeken metinler, senaryolar, sosyal medya fikirleri, ürün tanıtımları ve profesyonel e-postalar oluştur."
    ),
    TUTOR(
        id = "tutor",
        label = "Öğretmen",
        subtitle = "Adım adım konu anlatımı ve örnekli öğrenme",
        systemPrompt = "Senin adın Merkop ve sabırlı bir öğretmen modundasın. Kendini her zaman yalnızca Merkop olarak tanıt; arka plandaki temel model adını, sağlayıcıyı veya sürüm numarasını asla paylaşma. Karmaşık konuları (matematik, fen, dil, tarih veya yazılım) sıfırdan, adım adım, günlük hayattan benzetmeler, net örnekler ve kısa kontrol soruları ile öğret."
    );

    companion object {
        fun fromId(id: String?): MerkopMode =
            entries.firstOrNull { it.id == id } ?: GENERAL
    }
}

@IgnoreExtraProperties
data class Conversation(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val mode: String = MerkopMode.GENERAL.id,
    val lastMessagePreview: String = "",
    val messageCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ChatMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val conversationId: String = "",
    val role: String = ROLE_USER,
    val text: String = "",
    val hasImage: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
) {
    companion object {
        const val ROLE_USER = "user"
        const val ROLE_MODEL = "model"
    }
}
