package com.example.data.model

data class SubjectWithStats(
    val subject: SubjectEntity,
    val totalMinutesStudied: Int,
    val lastStudiedDate: String?,
    val thisWeekMinutesStudied: Int
)
