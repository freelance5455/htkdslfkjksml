package com.example.data.ai

import com.example.data.model.AppLanguage
import com.example.data.model.ChatMessage
import com.example.data.model.GenderOption
import com.example.data.model.MoodType
import com.example.data.model.UserProfile
import kotlinx.coroutines.delay

data class AiReply(
    val text: String,
    val isPlaceholderSample: Boolean
)

data class DiaryCueAnalysis(
    val detectedCue: String,
    val suggestedMood: MoodType,
    val supportiveResponse: String,
    val isPlaceholderSample: Boolean
)

interface AiRepository {
    suspend fun chatWithPillowOfStrength(
        userMessage: String,
        currentMood: MoodType,
        profile: UserProfile,
        history: List<ChatMessage>
    ): AiReply

    suspend fun analyzeDiaryEntryAndSupport(
        content: String,
        selectedMood: MoodType,
        profile: UserProfile
    ): DiaryCueAnalysis

    suspend fun analyzeHormoneBalance(
        energy: Int,
        moodBalance: Int,
        skinClarity: Int,
        sleepQuality: Int,
        stressCalm: Int,
        profile: UserProfile
    ): AiReply

    suspend fun askTutorTshenoloMaseko(
        question: String,
        subject: String,
        profile: UserProfile
    ): AiReply
}

/**
 * Offline / Sample AI implementation used when Firebase AI Logic is not enabled
 * or when the user chooses Data-Free (Offline) mode.
 */
class LocalPlaceholderAiRepository : AiRepository {

    override suspend fun chatWithPillowOfStrength(
        userMessage: String,
        currentMood: MoodType,
        profile: UserProfile,
        history: List<ChatMessage>
    ): AiReply {
        delay(300)
        val lower = userMessage.lowercase()
        val displayName = profile.name.ifBlank { "friend" }
        val langPrefix = languageBadge(profile.language)

        val coreBody = when {
            listOf("hurt", "suicide", "kill", "unsafe", "abuse", "danger", "scared").any { it in lower } ->
                "Hey $displayName, you are not alone and your safety comes first right now. Please tap the SOS tab immediately to call local emergency authorities or message your trusted contacts with your location. You deserve real care and protection."
            listOf("period", "cramp", "bleed", "cycle", "pms").any { it in lower } ->
                "I hear you, $displayName. Cramps and cycle mood shifts are very real during your teen years. Try warm hydration, gentle stretching, and logging your flow in the Wellness tab so we can spot patterns together."
            listOf("stress", "school", "exam", "anxious", "panic", "overwhelmed").any { it in lower } ->
                "Take one slow breath with me, $displayName: inhale 4 seconds, hold 4 seconds, exhale 6 seconds. Step outside for 5 minutes of fresh air and drink a glass of water—your nervous system resets faster when your body is cared for."
            listOf("sleep", "tired", "insomnia", "night").any { it in lower } ->
                "Your teen brain grows and repairs deeply during sleep. Toggle 'Sleep Quiet Mode' on the Today tab to turn other apps down, dim your screen, and rest gently."
            listOf("lonely", "sad", "cry", "nobody", "friend").any { it in lower } ->
                "I'm right here as your pillow of strength, $displayName. Feeling ${currentMood.label.lowercase()} is okay—you don't have to pretend everything is fine. Want to record a quick voice diary entry so you can let it out?"
            else ->
                "Thank you for trusting me with how you feel, $displayName. Feeling ${currentMood.label.lowercase()} makes sense when you're navigating teen life. Remember: drink water, take a fresh-air break, and check your daily care checklist—small steps protect your peace."
        }

        return AiReply(text = "$langPrefix$coreBody", isPlaceholderSample = true)
    }

    override suspend fun analyzeDiaryEntryAndSupport(
        content: String,
        selectedMood: MoodType,
        profile: UserProfile
    ): DiaryCueAnalysis {
        delay(220)
        val lower = content.lowercase()
        val displayName = profile.name.ifBlank { "friend" }

        val (cue, mood, reply) = when {
            listOf("scared", "unsafe", "hurt", "panic", "terrified").any { it in lower } -> Triple(
                "High Distress / Safety Cue",
                MoodType.ANXIOUS,
                "I hear fear and heavy distress in what you shared, $displayName. Please pause and breathe—and if you feel unsafe right now, tap the SOS tab to call authority or message your trusted contacts immediately."
            )
            listOf("exam", "homework", "school", "test", "fail", "overwhelmed", "too much", "pressure").any { it in lower } -> Triple(
                "Academic / Overwhelm Cue",
                MoodType.OVERWHELMED,
                "You're carrying a lot of school pressure right now, $displayName. Break it into just one small 15-minute step, drink a glass of water, and ask tutor Tshenolo Maseko in the Learn tab if you need homework help."
            )
            listOf("alone", "lonely", "cry", "sad", "miss", "left out", "empty").any { it in lower } -> Triple(
                "Sadness / Connection Cue",
                MoodType.SAD,
                "Thank you for speaking this out loud instead of holding it inside, $displayName. Feeling lonely or sad hurts, but you matter deeply. Consider texting a trusted friend or leaning on Pillow of Strength tonight."
            )
            listOf("anxious", "worried", "nervous", "heart racing", "stress").any { it in lower } -> Triple(
                "Anxiety / Nervous System Cue",
                MoodType.ANXIOUS,
                "Your entry shows signs of nervous tension. Try box breathing (4s in, 4s hold, 4s out) and step into fresh air for 10 minutes—your body deserves calm."
            )
            listOf("happy", "grateful", "proud", "excited", "good", "blessed", "love").any { it in lower } -> Triple(
                "Gratitude / Positive Momentum Cue",
                MoodType.HAPPY,
                "I love hearing that brightness in your voice, $displayName! Saving positive days like this helps remind you of your strength whenever harder days come."
            )
            else -> Triple(
                "Reflective (${selectedMood.label}) Cue",
                selectedMood,
                "I've saved your thoughts safely, $displayName. Checking in with your voice helps track your emotional rhythm over time—be gentle with yourself today."
            )
        }

        return DiaryCueAnalysis(
            detectedCue = cue,
            suggestedMood = mood,
            supportiveResponse = "${languageBadge(profile.language)}$reply",
            isPlaceholderSample = true
        )
    }

    override suspend fun analyzeHormoneBalance(
        energy: Int,
        moodBalance: Int,
        skinClarity: Int,
        sleepQuality: Int,
        stressCalm: Int,
        profile: UserProfile
    ): AiReply {
        delay(250)
        val average = (energy + moodBalance + skinClarity + sleepQuality + stressCalm) / 5.0
        val genderContext = when (profile.gender) {
            GenderOption.GIRL -> "During teen years, estrogen and progesterone rhythm naturally shifts across your menstrual cycle, affecting skin, energy, and mood."
            GenderOption.BOY -> "During teen years, healthy testosterone, growth hormone, and cortisol balance depend strongly on 8–9 hours of sleep, strength exercise, hydration, and whole nutrition."
            GenderOption.NON_BINARY -> "Teen endocrine balance (cortisol, melatonin, thyroid, and reproductive hormones) responds closely to sleep regularity, hydration, and stress recovery."
        }
        val recommendation = when {
            sleepQuality <= 2 -> "Priority tip: Your sleep score is low—cortisol stays elevated without rest. Turn on Sleep Quiet Mode tonight."
            stressCalm <= 2 -> "Priority tip: Stress looks heavy today. Try 10 minutes of fresh air, deep breathing, and talking in Pillow of Strength."
            average >= 4.0 -> "Your overall teen hormone & wellness rhythm looks steady! Keep up your water, meals, and bathroom regularity."
            else -> "Your body is asking for gentle recovery today: aim for 2 glasses of water, a balanced meal, and light movement."
        }

        return AiReply(
            text = "[Sample Offline Guidance — Firebase AI Not Enabled]\n$genderContext\n\n$recommendation\n\n(Educational wellness guidance only—consult a doctor for lab testing.)",
            isPlaceholderSample = true
        )
    }

    override suspend fun askTutorTshenoloMaseko(
        question: String,
        subject: String,
        profile: UserProfile
    ): AiReply {
        delay(250)
        val lower = question.lowercase()
        val name = profile.name.ifBlank { "scholar" }
        val prefix = "[Tshenolo Maseko • 24hr Tutor — Offline Sample Mode]\n"

        val answer = when {
            subject == "Math" || listOf("algebra", "equation", "fraction", "percent", "math", "solve").any { it in lower } ->
                "Great question, $name! When solving math step-by-step: (1) Write down what you know and what the unknown variable x stands for, (2) Simplify both sides cleanly, and (3) Plug your final answer back in to verify. Share the exact equation if you want to walk through each line!"
            subject == "Science" || listOf("cell", "atom", "biology", "physics", "chemistry", "hormone", "energy").any { it in lower } ->
                "Let's break that Science concept down simply, $name: think about cause and effect. Every system—from cells to ecosystems to human hormones—stays balanced through inputs, energy transfer, and feedback loops. Try summarizing the idea in one plain sentence first!"
            subject == "Bible Study" || listOf("bible", "verse", "psalm", "god", "jesus", "prayer", "faith").any { it in lower } ->
                "I'm glad you asked, $name. A helpful way to study any Bible passage is the S.O.A.P. method: Scripture (read the verse), Observation (who is speaking and why?), Application (what does this encourage me to do today?), and Prayer (talk honestly about it)."
            subject == "Study Tips" || listOf("study", "exam", "focus", "memory", "procrastinat").any { it in lower } ->
                "Use the 25/5 Pomodoro rhythm, $name: put your phone in Sleep Quiet Mode for 25 minutes of single-task focus, then take 5 minutes to drink water and get fresh air. Active self-quizzing beats re-reading every time!"
            else ->
                "Hey $name, I'm here 24/7 whenever you're studying! Let's tackle '$question' in $subject together: start by splitting the topic into 3 small parts—definition, one real-world example, and one practice question you can explain in your own words."
        }

        return AiReply(text = "$prefix$answer", isPlaceholderSample = true)
    }

    private fun languageBadge(language: AppLanguage): String = when (language) {
        AppLanguage.ES -> "[Modo Muestra Sin Conexión] "
        AppLanguage.FR -> "[Mode Échantillon Hors Ligne] "
        AppLanguage.PT -> "[Modo Exemplo Offline] "
        AppLanguage.ZU -> "[Imodi Yesampula Engaxhunyiwe] "
        AppLanguage.XH -> "[Imowudi Yesampuli Engaxhunywanga] "
        AppLanguage.AF -> "[Vanlyn Voorbeeldmodus] "
        AppLanguage.NSO -> "[Mokgwa wa Sampole ya Offline] "
        AppLanguage.TN -> "[Mokgwa wa Sekao sa Offline] "
        AppLanguage.ST -> "[Mokgwa wa Mohlala wa Offline] "
        AppLanguage.TS -> "[Xikombiso xo Pfumala Inthanete] "
        AppLanguage.SS -> "[Imodi Yesampula Lengaphandle Kwedatha] "
        AppLanguage.VE -> "[Maitele a Tsumbo a Offline] "
        AppLanguage.NR -> "[Ubujamo Besibonelo Ngaphandle Kwedatha] "
        AppLanguage.SW -> "[Hali ya Mfano Nje ya Mtandao] "
        AppLanguage.AR -> "[وضع العينة دون اتصال] "
        AppLanguage.HI -> "[ऑफ़लाइन सैंपल मोड] "
        AppLanguage.ZH -> "[离线示例模式] "
        AppLanguage.JA -> "[オフラインサンプルモード] "
        AppLanguage.EN -> "[Sample Offline Mode] "
    }
}
