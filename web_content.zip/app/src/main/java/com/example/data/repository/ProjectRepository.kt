package com.example.data.repository

import com.example.data.local.ProjectDao
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MilestoneEntity
import com.example.data.model.ProjectCategory
import com.example.data.model.ProjectEntity
import com.example.data.model.ProjectStatus
import com.example.data.model.ProjectTemplateType
import com.example.data.model.SubtaskEntity
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.ThemeMode
import com.example.data.preferences.ThemePreferences
import com.example.util.formatDurationPersian
import com.example.util.formatRelativeDateFa
import com.example.util.toPersianDigits
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

class ProjectRepository(
    private val dao: ProjectDao,
    private val themePreferences: ThemePreferences
) {
    val projects: Flow<List<ProjectEntity>> = dao.observeAllProjects()
    val tasks: Flow<List<TaskEntity>> = dao.observeAllTasks()
    val subtasks: Flow<List<SubtaskEntity>> = dao.observeAllSubtasks()
    val milestones: Flow<List<MilestoneEntity>> = dao.observeAllMilestones()
    val focusSessions: Flow<List<FocusSessionEntity>> = dao.observeAllFocusSessions()
    val themeMode: Flow<ThemeMode> = themePreferences.themeMode
    val ownerName: Flow<String> = themePreferences.ownerName
    val forceDesktopLayout: Flow<Boolean> = themePreferences.forceDesktopLayout

    suspend fun setThemeMode(mode: ThemeMode) {
        themePreferences.setThemeMode(mode)
    }

    suspend fun setOwnerName(name: String) {
        themePreferences.setOwnerName(name)
    }

    suspend fun setForceDesktopLayout(enabled: Boolean) {
        themePreferences.setForceDesktopLayout(enabled)
    }

    suspend fun duplicateTask(task: TaskEntity): Long {
        val copy = task.copy(
            id = 0L,
            title = "${task.title} (کپی)",
            status = TaskStatus.TODO.name,
            focusMinutesSpent = 0,
            createdAtMillis = System.currentTimeMillis(),
            completedAtMillis = null
        )
        return dao.insertTask(copy)
    }

    suspend fun insertProject(project: ProjectEntity): Long = dao.insertProject(project)

    suspend fun updateProject(project: ProjectEntity) {
        dao.updateProject(project.copy(updatedAtMillis = System.currentTimeMillis()))
    }

    suspend fun deleteProject(projectId: Long) = dao.deleteProjectById(projectId)

    suspend fun insertTask(task: TaskEntity): Long = dao.insertTask(task)

    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)

    suspend fun deleteTask(taskId: Long) = dao.deleteTaskById(taskId)

    suspend fun insertSubtask(subtask: SubtaskEntity): Long = dao.insertSubtask(subtask)

    suspend fun updateSubtask(subtask: SubtaskEntity) = dao.updateSubtask(subtask)

    suspend fun deleteSubtask(subtask: SubtaskEntity) = dao.deleteSubtask(subtask)

    suspend fun insertMilestone(milestone: MilestoneEntity): Long = dao.insertMilestone(milestone)

    suspend fun updateMilestone(milestone: MilestoneEntity) = dao.updateMilestone(milestone)

    suspend fun deleteMilestone(milestone: MilestoneEntity) = dao.deleteMilestone(milestone)

    suspend fun logFocusSession(taskId: Long?, projectId: Long?, minutes: Int) {
        dao.insertFocusSession(
            FocusSessionEntity(
                taskId = taskId,
                projectId = projectId,
                durationMinutes = minutes,
                completedAtMillis = System.currentTimeMillis()
            )
        )
        if (taskId != null) {
            dao.addFocusMinutesToTask(taskId, minutes)
        }
    }

    suspend fun createProjectFromTemplate(template: ProjectTemplateType): Long {
        val now = System.currentTimeMillis()
        val dayMs = 86_400_000L

        val projectId = dao.insertProject(
            ProjectEntity(
                title = template.titleFa,
                description = template.subtitleFa,
                notes = "یادداشت پروژه ${template.titleFa}:\n• اهداف کلیدی را در بخش نقاط عطف دنبال کنید.\n• برای تسک‌های مهم از تایمر تمرکز استفاده کنید.",
                category = template.category.name,
                status = ProjectStatus.ACTIVE.name,
                colorIndex = template.colorIndex,
                isPinned = true,
                targetDateMillis = now + 14 * dayMs,
                createdAtMillis = now,
                updatedAtMillis = now
            )
        )

        when (template) {
            ProjectTemplateType.STARTUP_PRODUCT -> {
                dao.insertMilestone(MilestoneEntity(projectId = projectId, title = "تکمیل طراحی پروتوتایپ", targetDateMillis = now + 3 * dayMs, isCompleted = true))
                dao.insertMilestone(MilestoneEntity(projectId = projectId, title = "تحویل نسخه آزمایشی (Beta)", targetDateMillis = now + 10 * dayMs))
                val t1 = dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "طراحی صفحه اصلی و داشبورد کاربری",
                        description = "ساخت کامپوننت‌های تعاملی با تمرکز بر سرعت و زیبایی",
                        status = TaskStatus.IN_PROGRESS.name,
                        priority = TaskPriority.URGENT.name,
                        dueDateMillis = now + dayMs,
                        estimatedMinutes = 90,
                        storyPoints = 5,
                        assigneeName = "تیم طراحی",
                        bookmarked = true,
                        tag = "UI/UX"
                    )
                )
                dao.insertSubtask(SubtaskEntity(taskId = t1, title = "نهایی‌سازی پالت رنگ و فونت", isCompleted = true))
                dao.insertSubtask(SubtaskEntity(taskId = t1, title = "پیاده‌سازی انیمیشن نمودارها", isCompleted = false))
                dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "پیاده‌سازی سیستم ذخیره‌سازی و خروجی",
                        status = TaskStatus.TODO.name,
                        priority = TaskPriority.HIGH.name,
                        dueDateMillis = now + 3 * dayMs,
                        estimatedMinutes = 120,
                        storyPoints = 8,
                        assigneeName = "تیم فنی",
                        tag = "Backend"
                    )
                )
                dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "تحلیل نیازمندی‌های کاربران اولیه",
                        status = TaskStatus.DONE.name,
                        priority = TaskPriority.MEDIUM.name,
                        dueDateMillis = now - dayMs,
                        estimatedMinutes = 45,
                        focusMinutesSpent = 45,
                        storyPoints = 3,
                        assigneeName = "خودم",
                        tag = "محصول",
                        completedAtMillis = now - dayMs
                    )
                )
            }

            ProjectTemplateType.SOCIAL_CAMPAIGN -> {
                dao.insertMilestone(MilestoneEntity(projectId = projectId, title = "تصویب تقویم محتوای ماهانه", targetDateMillis = now + 4 * dayMs))
                dao.insertMilestone(MilestoneEntity(projectId = projectId, title = "انتشار ریلز معرفی محصول", targetDateMillis = now + 9 * dayMs))
                dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "نگارش سناریوی ۵ ویدیوی کوتاه",
                        status = TaskStatus.IN_PROGRESS.name,
                        priority = TaskPriority.URGENT.name,
                        dueDateMillis = now,
                        estimatedMinutes = 60,
                        storyPoints = 5,
                        assigneeName = "تیم محتوا",
                        bookmarked = true,
                        tag = "سناریو"
                    )
                )
                dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "طراحی کاورهای یکپارچه اینستاگرام",
                        status = TaskStatus.TODO.name,
                        priority = TaskPriority.HIGH.name,
                        dueDateMillis = now + 2 * dayMs,
                        estimatedMinutes = 90,
                        storyPoints = 3,
                        assigneeName = "گرافیست",
                        tag = "گرافیک"
                    )
                )
            }

            ProjectTemplateType.ACADEMIC_RESEARCH -> {
                dao.insertMilestone(MilestoneEntity(projectId = projectId, title = "مرور ادبیات و منابع علمی", targetDateMillis = now + 5 * dayMs))
                dao.insertMilestone(MilestoneEntity(projectId = projectId, title = "ارسال پیش‌نویس نهایی", targetDateMillis = now + 14 * dayMs))
                dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "استخراج ۱۰ مقاله مرجع جدید",
                        status = TaskStatus.IN_PROGRESS.name,
                        priority = TaskPriority.HIGH.name,
                        dueDateMillis = now + dayMs,
                        estimatedMinutes = 90,
                        storyPoints = 5,
                        assigneeName = "خودم",
                        bookmarked = true,
                        tag = "پژوهش"
                    )
                )
                dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "تدوین ساختار فصل روش‌شناسی",
                        status = TaskStatus.TODO.name,
                        priority = TaskPriority.MEDIUM.name,
                        dueDateMillis = now + 4 * dayMs,
                        estimatedMinutes = 60,
                        storyPoints = 3,
                        assigneeName = "خودم",
                        tag = "نگارش"
                    )
                )
            }

            ProjectTemplateType.BUSINESS_SALES -> {
                dao.insertMilestone(MilestoneEntity(projectId = projectId, title = "تکمیل قیف فروش فصل", targetDateMillis = now + 6 * dayMs))
                dao.insertMilestone(MilestoneEntity(projectId = projectId, title = "عقد ۵ قرارداد کلیدی", targetDateMillis = now + 20 * dayMs))
                dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "آماده‌سازی پروپوزال مشتریان سازمانی",
                        status = TaskStatus.IN_PROGRESS.name,
                        priority = TaskPriority.URGENT.name,
                        dueDateMillis = now + dayMs,
                        estimatedMinutes = 75,
                        storyPoints = 5,
                        assigneeName = "فروش",
                        bookmarked = true,
                        tag = "پروپوزال"
                    )
                )
                dao.insertTask(
                    TaskEntity(
                        projectId = projectId,
                        title = "پیگیری تماس‌های جلسه دمو",
                        status = TaskStatus.TODO.name,
                        priority = TaskPriority.HIGH.name,
                        dueDateMillis = now + 2 * dayMs,
                        estimatedMinutes = 45,
                        storyPoints = 2,
                        assigneeName = "خودم",
                        tag = "CRM"
                    )
                )
            }
        }
        return projectId
    }

    suspend fun seedStarterWorkspace() {
        createProjectFromTemplate(ProjectTemplateType.STARTUP_PRODUCT)
        createProjectFromTemplate(ProjectTemplateType.SOCIAL_CAMPAIGN)
        dao.insertFocusSession(FocusSessionEntity(durationMinutes = 25, completedAtMillis = System.currentTimeMillis()))
    }

    suspend fun buildMarkdownReport(projectId: Long? = null): String {
        val allProjects = dao.observeAllProjects().first()
        val allTasks = dao.observeAllTasks().first()
        val allSubtasks = dao.observeAllSubtasks().first()
        val allMilestones = dao.observeAllMilestones().first()
        val allSessions = dao.observeAllFocusSessions().first()

        val targetProjects = if (projectId == null) allProjects else allProjects.filter { it.id == projectId }
        val sb = StringBuilder()
        sb.appendLine("# گزارش جامع مدیریت پروژه — پروژه‌یار")
        sb.appendLine()
        sb.appendLine("- تعداد پروژه‌ها: ${targetProjects.size.toPersianDigits()}")
        val relevantTasks = allTasks.filter { t -> targetProjects.any { it.id == t.projectId } }
        val doneCount = relevantTasks.count { it.status == TaskStatus.DONE.name }
        sb.appendLine("- مجموع تسک‌ها: ${relevantTasks.size.toPersianDigits()} (تکمیل‌شده: ${doneCount.toPersianDigits()})")
        val totalFocus = allSessions.sumOf { it.durationMinutes }
        sb.appendLine("- مجموع زمان تمرکز ثبت‌شده: ${formatDurationPersian(totalFocus)}")
        sb.appendLine()

        targetProjects.forEach { proj ->
            val pTasks = allTasks.filter { it.projectId == proj.id }
            val pMilestones = allMilestones.filter { it.projectId == proj.id }
            val cat = ProjectCategory.fromName(proj.category)
            val status = ProjectStatus.fromName(proj.status)

            sb.appendLine("---")
            sb.appendLine("## 📁 ${proj.title}")
            sb.appendLine("**دسته:** ${cat.labelFa} | **وضعیت:** ${status.labelFa} | **موعد:** ${formatRelativeDateFa(proj.targetDateMillis)}")
            if (proj.budgetLabel.isNotBlank()) {
                sb.appendLine("**بودجه / هدف:** ${proj.budgetLabel}")
            }
            if (proj.description.isNotBlank()) {
                sb.appendLine()
                sb.appendLine(proj.description)
            }
            if (proj.notes.isNotBlank()) {
                sb.appendLine()
                sb.appendLine("### یادداشت‌ها")
                sb.appendLine(proj.notes)
            }
            if (pMilestones.isNotEmpty()) {
                sb.appendLine()
                sb.appendLine("### 🚩 نقاط عطف")
                pMilestones.forEach { m ->
                    val mark = if (m.isCompleted) "[x]" else "[ ]"
                    sb.appendLine("- $mark ${m.title}")
                }
            }
            if (pTasks.isNotEmpty()) {
                sb.appendLine()
                sb.appendLine("### ✅ تسک‌ها")
                pTasks.forEach { t ->
                    val mark = if (t.status == TaskStatus.DONE.name) "[x]" else "[ ]"
                    val pLabel = TaskPriority.fromName(t.priority).labelFa
                    val sLabel = TaskStatus.fromName(t.status).labelFa
                    val assignee = if (t.assigneeName.isNotBlank()) " | مسئول: ${t.assigneeName}" else ""
                    sb.appendLine("- $mark **${t.title}** ($sLabel • اولویت: $pLabel • امتیاز: ${t.storyPoints.toPersianDigits()}$assignee)")
                    allSubtasks.filter { it.taskId == t.id }.forEach { sub ->
                        val sMark = if (sub.isCompleted) "[x]" else "[ ]"
                        sb.appendLine("  - $sMark ${sub.title}")
                    }
                }
            }
            sb.appendLine()
        }
        return sb.toString()
    }

    suspend fun exportWorkspaceJson(): String {
        val allProjects = dao.observeAllProjects().first()
        val allTasks = dao.observeAllTasks().first()
        val allSubtasks = dao.observeAllSubtasks().first()
        val allMilestones = dao.observeAllMilestones().first()

        val root = JSONObject()
        root.put("app", "ProzheYar")
        root.put("version", 2)
        root.put("exportedAt", System.currentTimeMillis())

        val projectsArray = JSONArray()
        allProjects.forEach { proj ->
            val pJson = JSONObject().apply {
                put("title", proj.title)
                put("description", proj.description)
                put("notes", proj.notes)
                put("budgetLabel", proj.budgetLabel)
                put("category", proj.category)
                put("status", proj.status)
                put("colorIndex", proj.colorIndex)
                put("isPinned", proj.isPinned)
                put("targetDateMillis", proj.targetDateMillis ?: JSONObject.NULL)
            }
            val milestonesArr = JSONArray()
            allMilestones.filter { it.projectId == proj.id }.forEach { m ->
                milestonesArr.put(
                    JSONObject().apply {
                        put("title", m.title)
                        put("isCompleted", m.isCompleted)
                        put("targetDateMillis", m.targetDateMillis ?: JSONObject.NULL)
                    }
                )
            }
            pJson.put("milestones", milestonesArr)

            val tasksArr = JSONArray()
            allTasks.filter { it.projectId == proj.id }.forEach { t ->
                val tJson = JSONObject().apply {
                    put("title", t.title)
                    put("description", t.description)
                    put("status", t.status)
                    put("priority", t.priority)
                    put("dueDateMillis", t.dueDateMillis ?: JSONObject.NULL)
                    put("estimatedMinutes", t.estimatedMinutes)
                    put("focusMinutesSpent", t.focusMinutesSpent)
                    put("storyPoints", t.storyPoints)
                    put("assigneeName", t.assigneeName)
                    put("bookmarked", t.bookmarked)
                    put("tag", t.tag)
                }
                val subArr = JSONArray()
                allSubtasks.filter { it.taskId == t.id }.forEach { s ->
                    subArr.put(
                        JSONObject().apply {
                            put("title", s.title)
                            put("isCompleted", s.isCompleted)
                        }
                    )
                }
                tJson.put("subtasks", subArr)
                tasksArr.put(tJson)
            }
            pJson.put("tasks", tasksArr)
            projectsArray.put(pJson)
        }
        root.put("projects", projectsArray)
        return root.toString(2)
    }

    suspend fun importWorkspaceJson(rawJson: String): Int {
        val root = JSONObject(rawJson)
        val projectsArray = root.getJSONArray("projects")
        var importedCount = 0
        for (i in 0 until projectsArray.length()) {
            val pJson = projectsArray.getJSONObject(i)
            val title = pJson.optString("title", "").trim()
            if (title.isBlank()) continue
            val targetDate = if (pJson.isNull("targetDateMillis")) null else pJson.optLong("targetDateMillis")
            val newProjectId = dao.insertProject(
                ProjectEntity(
                    title = title,
                    description = pJson.optString("description", ""),
                    notes = pJson.optString("notes", ""),
                    budgetLabel = pJson.optString("budgetLabel", ""),
                    category = pJson.optString("category", ProjectCategory.DEVELOPMENT.name),
                    status = pJson.optString("status", ProjectStatus.ACTIVE.name),
                    colorIndex = pJson.optInt("colorIndex", 0),
                    isPinned = pJson.optBoolean("isPinned", false),
                    targetDateMillis = targetDate
                )
            )
            importedCount++

            val milestonesArr = pJson.optJSONArray("milestones")
            if (milestonesArr != null) {
                for (mIdx in 0 until milestonesArr.length()) {
                    val mJson = milestonesArr.getJSONObject(mIdx)
                    val mDate = if (mJson.isNull("targetDateMillis")) null else mJson.optLong("targetDateMillis")
                    dao.insertMilestone(
                        MilestoneEntity(
                            projectId = newProjectId,
                            title = mJson.optString("title", ""),
                            isCompleted = mJson.optBoolean("isCompleted", false),
                            targetDateMillis = mDate
                        )
                    )
                }
            }

            val tasksArr = pJson.optJSONArray("tasks")
            if (tasksArr != null) {
                for (tIdx in 0 until tasksArr.length()) {
                    val tJson = tasksArr.getJSONObject(tIdx)
                    val dueDate = if (tJson.isNull("dueDateMillis")) null else tJson.optLong("dueDateMillis")
                    val statusStr = tJson.optString("status", TaskStatus.TODO.name)
                    val newTaskId = dao.insertTask(
                        TaskEntity(
                            projectId = newProjectId,
                            title = tJson.optString("title", ""),
                            description = tJson.optString("description", ""),
                            status = statusStr,
                            priority = tJson.optString("priority", TaskPriority.MEDIUM.name),
                            dueDateMillis = dueDate,
                            estimatedMinutes = tJson.optInt("estimatedMinutes", 45),
                            focusMinutesSpent = tJson.optInt("focusMinutesSpent", 0),
                            storyPoints = tJson.optInt("storyPoints", 3),
                            assigneeName = tJson.optString("assigneeName", ""),
                            bookmarked = tJson.optBoolean("bookmarked", false),
                            tag = tJson.optString("tag", ""),
                            completedAtMillis = if (statusStr == TaskStatus.DONE.name) System.currentTimeMillis() else null
                        )
                    )
                    val subArr = tJson.optJSONArray("subtasks")
                    if (subArr != null) {
                        for (sIdx in 0 until subArr.length()) {
                            val sJson = subArr.getJSONObject(sIdx)
                            dao.insertSubtask(
                                SubtaskEntity(
                                    taskId = newTaskId,
                                    title = sJson.optString("title", ""),
                                    isCompleted = sJson.optBoolean("isCompleted", false)
                                )
                            )
                        }
                    }
                }
            }
        }
        return importedCount
    }
}
