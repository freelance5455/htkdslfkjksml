package com.example.data.repository

import com.example.data.dao.ProjectDao
import com.example.data.model.ProjectEntity
import kotlinx.coroutines.flow.Flow
import java.io.File

class ProjectRepository(private val projectDao: ProjectDao) {

    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

    fun getProject(id: Long): Flow<ProjectEntity?> = projectDao.getProjectById(id)

    suspend fun getProjectSync(id: Long): ProjectEntity? = projectDao.getProjectByIdSync(id)

    suspend fun saveOrUpdateProject(project: ProjectEntity): Long {
        return if (project.id == 0L) {
            projectDao.insertProject(project.copy(createdAt = System.currentTimeMillis(), updatedAt = System.currentTimeMillis()))
        } else {
            projectDao.updateProject(project.copy(updatedAt = System.currentTimeMillis()))
            project.id
        }
    }

    suspend fun deleteProject(project: ProjectEntity) {
        // Remove associated audio file if it exists
        project.audioFilePath?.let { path ->
            val file = File(path)
            if (file.exists()) {
                file.delete()
            }
        }
        projectDao.deleteProject(project)
    }

    suspend fun deleteAudioForProject(project: ProjectEntity) {
        project.audioFilePath?.let { path ->
            val file = File(path)
            if (file.exists()) {
                file.delete()
            }
        }
        projectDao.updateProject(
            project.copy(
                audioFilePath = null,
                audioDurationMs = 0L,
                updatedAt = System.currentTimeMillis()
            )
        )
    }
}
