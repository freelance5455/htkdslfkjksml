package com.example.data.db

import com.example.data.model.WordDefinition
import kotlinx.coroutines.flow.Flow

class SrsRepository(private val dao: SrsWordDao) {

    fun getPrioritizedWords(currentTime: Long = System.currentTimeMillis()): Flow<List<SrsWordEntity>> {
        return dao.getPrioritizedWords(currentTime)
    }

    fun getAllWords(): Flow<List<SrsWordEntity>> {
        return dao.getAllWords()
    }

    fun getDueWords(currentTime: Long = System.currentTimeMillis()): Flow<List<SrsWordEntity>> {
        return dao.getDueWords(currentTime)
    }

    suspend fun saveNewLearnedWords(
        definitions: List<WordDefinition>,
        sourceDoc: String,
        now: Long = System.currentTimeMillis()
    ) {
        val (initialInterval, initialNextReview) = SpacedRepetitionAlgorithm.calculateInitial(now)

        val entities = definitions.map { def ->
            val normalizedId = def.word.lowercase().trim()
            val existing = dao.getWordById(normalizedId)

            if (existing != null) {
                // If already in database, keep its current SRS progress, update definition/sentence if newer
                existing.copy(
                    displayWord = def.displayWord,
                    simpleSynonym = def.simpleSynonym,
                    colloquialMeaning = def.colloquialMeaning,
                    imageUrl = def.imageUrl,
                    originalSentence = def.originalSentence,
                    dailyLifeExample = def.dailyLifeExample,
                    sourceDocument = sourceDoc
                )
            } else {
                SrsWordEntity(
                    id = normalizedId,
                    word = def.word,
                    displayWord = def.displayWord,
                    simpleSynonym = def.simpleSynonym,
                    colloquialMeaning = def.colloquialMeaning,
                    imageUrl = def.imageUrl,
                    originalSentence = def.originalSentence,
                    dailyLifeExample = def.dailyLifeExample,
                    category = def.category,
                    sourceDocument = sourceDoc,
                    pageNumber = def.pageNumber,
                    learnedTimestamp = now,
                    lastReviewedTimestamp = 0L,
                    nextReviewTimestamp = initialNextReview, // Exactly 15 minutes after learning
                    intervalMinutes = initialInterval,
                    repetitionCount = 0,
                    easeFactor = 2.5,
                    timesForgotten = 0,
                    timesRemembered = 0,
                    isMemorized = false
                )
            }
        }
        dao.insertWords(entities)
    }

    suspend fun recordReview(
        wordId: String,
        quality: ReviewQuality,
        now: Long = System.currentTimeMillis()
    ): SrsWordEntity? {
        val word = dao.getWordById(wordId) ?: return null

        val result = SpacedRepetitionAlgorithm.processReview(
            quality = quality,
            currentRepetitions = word.repetitionCount,
            currentIntervalMinutes = word.intervalMinutes,
            currentEaseFactor = word.easeFactor,
            currentForgotten = word.timesForgotten,
            currentRemembered = word.timesRemembered,
            now = now
        )

        val updated = word.copy(
            lastReviewedTimestamp = now,
            nextReviewTimestamp = result.nextReviewTimestamp,
            intervalMinutes = result.nextIntervalMinutes,
            repetitionCount = result.newRepetitionCount,
            easeFactor = result.newEaseFactor,
            timesForgotten = result.timesForgotten,
            timesRemembered = result.timesRemembered,
            isMemorized = result.newRepetitionCount >= 3
        )

        dao.updateWord(updated)
        return updated
    }

    /**
     * Testing and demonstration helper:
     * Advances simulated time on cards so user can immediately test what happens after 15 minutes!
     */
    suspend fun advanceTimeToMakeCardsDue(minutes: Long = 15L) {
        val shiftMs = minutes * 60 * 1000L
        // We simulate that nextReviewTimestamp arrived
        val all = dao.getWordById("inmutable") // check
        // We can do this in ViewModel by offsetting the simulated current time or shifting records
    }

    suspend fun toggleMemorized(wordId: String) {
        val word = dao.getWordById(wordId) ?: return
        dao.updateWord(word.copy(isMemorized = !word.isMemorized))
    }

    suspend fun deleteWord(wordId: String) {
        dao.deleteWordById(wordId)
    }
}
