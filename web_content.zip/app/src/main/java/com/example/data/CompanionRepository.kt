package com.example.data

import android.content.Context
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class CompanionRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUserId: String): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        check(uid == expectedUserId) { "Signed-in user changed; refusing cross-user write." }
        return uid
    }

    fun observeUserPrefs(userId: String): Flow<UserCompanionPrefs?> = flow {
        val uid = requireUserId(userId)
        val docRef = db.collection("users").document(uid)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            UserCompanionPrefs::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else {
                        null
                    }
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path)
                    }
                    throw error
                }
        )
    }

    fun observeLearnedMoves(userId: String): Flow<List<LearnedMoveDoc>> = flow {
        val uid = requireUserId(userId)
        val colRef = db.collection("users").document(uid).collection("learnedMoves")
        emitAll(
            colRef.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        LearnedMoveDoc::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, colRef.path)
                    }
                    throw error
                }
        )
    }

    suspend fun ensureUserProfile(userId: String, displayName: String): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            val safeName = displayName.trim().take(80).ifBlank { "Friend" }
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to safeName,
                    "backgroundId" to StageBackground.SAKURA_SHRINE.id,
                    "dressColor" to "orig",
                    "jpMode" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updatePreferences(
        userId: String,
        displayName: String? = null,
        backgroundId: String? = null,
        dressColor: String? = null,
        jpMode: Boolean? = null
    ): Result<Unit> {
        val path = "users/$userId"
        return try {
            val uid = requireUserId(userId)
            val updates = mutableMapOf<String, Any>(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!displayName.isNullOrBlank()) {
                updates["displayName"] = displayName.trim().take(80)
            }
            if (!backgroundId.isNullOrBlank()) {
                require(StageBackground.entries.any { it.id == backgroundId }) {
                    "Unsupported backgroundId: $backgroundId"
                }
                updates["backgroundId"] = backgroundId
            }
            if (!dressColor.isNullOrBlank()) {
                updates["dressColor"] = dressColor.trim().take(24)
            }
            if (jpMode != null) {
                updates["jpMode"] = jpMode
            }
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val initial = mapOf(
                    "userId" to uid,
                    "displayName" to (displayName?.trim()?.take(80)?.ifBlank { "Friend" } ?: "Friend"),
                    "backgroundId" to (backgroundId ?: StageBackground.SAKURA_SHRINE.id),
                    "dressColor" to (dressColor?.trim()?.take(24) ?: "orig"),
                    "jpMode" to (jpMode ?: true),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(initial).await()
            } else {
                docRef.update(updates).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun saveLearnedMove(
        userId: String,
        rawName: String,
        steps: List<String>
    ): Result<Unit> {
        val cleanName = rawName.trim().lowercase()
            .replace(Regex("[^a-z0-9_]"), "")
            .take(40)
        val path = "users/$userId/learnedMoves/$cleanName"
        return try {
            val uid = requireUserId(userId)
            require(cleanName.isNotBlank()) { "Move name cannot be blank" }
            val cleanSteps = steps.map { it.trim().take(240) }.filter { it.isNotEmpty() }.take(6)
            require(cleanSteps.isNotEmpty()) { "Move must contain at least one pose step" }

            val docRef = db.collection("users").document(uid)
                .collection("learnedMoves").document(cleanName)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val payload = mapOf(
                    "userId" to uid,
                    "name" to cleanName,
                    "steps" to cleanSteps,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            } else {
                docRef.update(
                    mapOf(
                        "steps" to cleanSteps,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }
}
