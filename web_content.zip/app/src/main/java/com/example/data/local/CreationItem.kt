package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "creations")
data class CreationItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "image" or "video"
    val prompt: String,
    val mediaUri: String,
    val inputImageUri: String? = null,
    val status: String = "completed", // "generating", "completed", "failed"
    val aspectRatio: String = "1:1",
    val style: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
