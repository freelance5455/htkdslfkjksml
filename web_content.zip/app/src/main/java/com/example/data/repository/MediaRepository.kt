package com.example.data.repository

import android.content.Context
import com.example.data.local.AlgorithmTagEntity
import com.example.data.local.AppDatabase
import com.example.data.local.FavoriteEntity
import com.example.data.local.HistoryEntity
import com.example.data.local.LikedEntity
import com.example.data.local.UserCommentEntity
import com.example.data.model.ComicSeries
import com.example.data.model.CommentItem
import com.example.data.model.GenderFilter
import com.example.data.model.MediaItem
import com.example.data.model.MediaSource
import com.example.data.model.MediaType
import com.example.data.model.SyncDocuments
import com.example.data.model.TagItem
import com.example.data.model.TagType
import com.example.data.network.LiveSourceClients
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.File
import java.util.UUID

class MediaRepository(
    private val context: Context,
    private val preferencesRepository: UserPreferencesRepository
) {
    private val database = AppDatabase.getInstance(context)
    private val dao = database.mediaDao()
    private val okHttpClient = OkHttpClient.Builder().build()
    private val liveClients = LiveSourceClients(okHttpClient)

    // Cached live items to minimize redundant requests during fast tab switches
    private val liveItemsCache = mutableMapOf<String, List<MediaItem>>()
    private var lastFetchTimestamp: Long = 0

    // Seed fallback catalog
    private val seedMediaPool: List<MediaItem> by lazy {
        generateSeedCatalog()
    }

    private val seedComicPool: List<ComicSeries> by lazy {
        generateSeedComics()
    }

    val historyItems: Flow<List<MediaItem>> = dao.getHistory().map { list ->
        list.map { entity ->
            MediaItem(
                id = entity.id,
                source = MediaSource.fromString(entity.source),
                type = MediaType.fromString(entity.type),
                title = entity.title,
                author = entity.author,
                mediaUrl = entity.mediaUrl,
                previewUrl = entity.previewUrl,
                caption = entity.caption,
                tags = entity.tagsRaw.split(",").filter { it.isNotBlank() },
                timestamp = entity.viewedTimestamp
            )
        }
    }

    val likedItems: Flow<List<MediaItem>> = dao.getLikedItems().map { list ->
        list.map { entity ->
            MediaItem(
                id = entity.id,
                source = MediaSource.fromString(entity.source),
                type = MediaType.fromString(entity.type),
                title = entity.title,
                author = entity.author,
                mediaUrl = entity.mediaUrl,
                previewUrl = entity.previewUrl,
                caption = entity.caption,
                tags = entity.tagsRaw.split(",").filter { it.isNotBlank() },
                isLiked = true,
                timestamp = entity.likedTimestamp
            )
        }
    }

    val favoriteItems: Flow<List<MediaItem>> = dao.getFavoriteItems().map { list ->
        list.map { entity ->
            MediaItem(
                id = entity.id,
                source = MediaSource.fromString(entity.source),
                type = MediaType.fromString(entity.type),
                title = entity.title,
                author = entity.author,
                mediaUrl = entity.mediaUrl,
                previewUrl = entity.previewUrl,
                caption = entity.caption,
                tags = entity.tagsRaw.split(",").filter { it.isNotBlank() },
                isFavorited = true,
                timestamp = entity.favoritedTimestamp
            )
        }
    }

    val userComments: Flow<List<UserCommentEntity>> = dao.getUserComments()

    /**
     * Fetch feed items: integrates real live network responses with offline cache fallback
     */
    // In-memory session tracking for anti-repetition algorithm
    private val sessionViewedIds = mutableSetOf<String>()

    /**
     * Fetch feed items: integrates real live network responses with offline cache fallback,
     * multi-platform discovery across all categories, and an advanced anti-repetition algorithm.
     */
    suspend fun getFeedItems(
        type: MediaType,
        filterSource: MediaSource? = null,
        searchQuery: String = ""
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val prefs = preferencesRepository.userPreferencesFlow.first()
        val algorithmTags = dao.getAlgorithmTagsSnapshot().associate { it.tag.lowercase() to it.weight }
        val historySnapshot = dao.getHistory().first()
        val historyIds = historySnapshot.map { it.id }.toSet()

        val combinedLiveList = mutableListOf<MediaItem>()

        // 1. Fetch from live sources when enabled
        val cacheKey = "${type.name}_${filterSource?.name.orEmpty()}_${prefs.genderFilter.name}"
        val cached = liveItemsCache[cacheKey]

        if (cached != null && System.currentTimeMillis() - lastFetchTimestamp < 90_000) {
            combinedLiveList.addAll(cached)
        } else {
            val newlyFetched = mutableListOf<MediaItem>()

            // Live Reddit fetch (Videos, Pictures, Comics, Misc)
            if (prefs.enabledSources.contains(MediaSource.REDDIT.name) && (filterSource == null || filterSource == MediaSource.REDDIT)) {
                val subs = prefs.redditSubreddits.split(",").map { it.trim() }.filter { it.isNotBlank() }
                val redditItems = liveClients.fetchRedditPosts(
                    subreddits = subs,
                    targetType = type,
                    genderFilter = prefs.genderFilter,
                    limit = 25
                )
                newlyFetched.addAll(redditItems)
            }

            // Live e621 fetch (Videos, Pictures, Comics, Misc)
            if (prefs.enabledSources.contains(MediaSource.E621.name) && (filterSource == null || filterSource == MediaSource.E621)) {
                val e621Items = liveClients.fetchE621Posts(
                    tags = prefs.e621DefaultTags,
                    targetType = type,
                    limit = 25,
                    login = prefs.e621Login,
                    apiKey = prefs.e621ApiKey
                )
                newlyFetched.addAll(e621Items)
            }

            // Live Rule34 fetch (Videos, Pictures, Comics, Misc)
            if (prefs.enabledSources.contains(MediaSource.RULE34.name) && (filterSource == null || filterSource == MediaSource.RULE34)) {
                val r34Items = liveClients.fetchRule34Posts(
                    tags = prefs.rule34DefaultTags,
                    targetType = type,
                    limit = 25
                )
                newlyFetched.addAll(r34Items)
            }

            // Live / Seeded Pornhub fetch across all categories (with gay.pornhub.com switch on MaleOnly)
            if (prefs.enabledSources.contains(MediaSource.PORNHUB.name) && (filterSource == null || filterSource == MediaSource.PORNHUB)) {
                val phItems = liveClients.fetchPornhubItems(
                    query = prefs.pornhubSearchQuery,
                    targetType = type,
                    isMaleOnly = (prefs.genderFilter == GenderFilter.MALE_ONLY),
                    limit = 20
                )
                newlyFetched.addAll(phItems)
            }

            if (newlyFetched.isNotEmpty()) {
                liveItemsCache[cacheKey] = newlyFetched
                lastFetchTimestamp = System.currentTimeMillis()
                combinedLiveList.addAll(newlyFetched)
            }
        }

        // 2. Combine with seed catalog to ensure rich variety and instant offline fallback
        val combinedPool = (combinedLiveList + seedMediaPool).distinctBy { it.id }

        // 3. Filter by Media Type & Selected Source & Enabled Sources
        // CRITICAL: Keep MyReadingManga and E-Hentai strictly inside the Comics category!
        var items = combinedPool.filter { item ->
            val isAllowedSourceForType = when (item.source) {
                MediaSource.MYREADINGMANGA, MediaSource.EHENTAI -> (type == MediaType.COMIC)
                else -> true
            }

            (item.type == type) &&
            isAllowedSourceForType &&
            (filterSource == null || item.source == filterSource) &&
            (prefs.enabledSources.contains(item.source.name))
        }

        // 4. Multi-option Gender Filtering (Any, Female Only, Male Only, Trans/Herm)
        items = items.filter { item ->
            matchesGenderFilter(item.tags, item.title, item.caption, prefs.genderFilter)
        }

        // 5. Search Query Filter
        if (searchQuery.isNotBlank()) {
            val queryLower = searchQuery.lowercase().trim()
            items = items.filter { item ->
                item.title.lowercase().contains(queryLower) ||
                item.tags.any { it.lowercase().contains(queryLower) } ||
                item.author.lowercase().contains(queryLower)
            }
        }

        // 6. Anti-Repetition Algorithm & Tag-affinity Scoring
        // Videos and items seen recently in this session or in history are penalized
        // so the user doesn't just see the same videos over and over.
        val scoredItems = items.map { item ->
            var score = 10.0f
            item.tags.forEach { tag ->
                score += (algorithmTags[tag.lowercase().trim()] ?: 0.0f) * 1.5f
            }

            // Severe penalty if already viewed in this app session
            if (sessionViewedIds.contains(item.id)) {
                score -= 50.0f
            }

            // Moderate penalty if in recent local history database
            if (historyIds.contains(item.id)) {
                score -= 25.0f
            }

            // Add slight pseudo-random jitter based on item hash to keep feeds fresh and avoid stagnant lists
            val jitter = ((item.id.hashCode() % 100) / 100.0f) * 4.0f
            item to (score + jitter)
        }

        // Sort descending by calculated score, demoting repeat items to the very end
        scoredItems.sortedByDescending { it.second }.map { it.first }
    }

    /**
     * Fetch comics: pulls live pools from e621 and merges with local serialized manga
     */
    suspend fun getComics(searchQuery: String = ""): List<ComicSeries> = withContext(Dispatchers.IO) {
        val prefs = preferencesRepository.userPreferencesFlow.first()

        val livePools = mutableListOf<ComicSeries>()
        if (prefs.enabledSources.contains(MediaSource.E621.name)) {
            val pools = liveClients.fetchE621Pools(query = searchQuery, limit = 10)
            livePools.addAll(pools)
        }

        val allComics = (livePools + seedComicPool).distinctBy { it.id }.filter { comic ->
            prefs.enabledSources.contains(comic.source.name)
        }

        var list = allComics.filter { comic ->
            matchesGenderFilter(comic.tags, comic.title, comic.description, prefs.genderFilter)
        }

        if (searchQuery.isNotBlank()) {
            val queryLower = searchQuery.lowercase().trim()
            list = list.filter {
                it.title.lowercase().contains(queryLower) ||
                it.author.lowercase().contains(queryLower) ||
                it.tags.any { tag -> tag.lowercase().contains(queryLower) }
            }
        }

        list
    }

    /**
     * Comprehensive Gender Filtering Logic across all sources
     */
    private fun matchesGenderFilter(
        tags: List<String>,
        title: String,
        caption: String,
        filter: GenderFilter
    ): Boolean {
        if (filter == GenderFilter.ANY) return true

        val allTags = tags.map { it.lowercase().trim() }
        val titleLower = title.lowercase()
        val textLower = "$titleLower ${caption.lowercase()}"

        val femaleKeywords = setOf(
            "female", "1girl", "2girls", "3girls", "female_only", "girl", "woman",
            "yuri", "vixen", "breasts", "maid", "milf", "gynomorph"
        )

        val maleKeywords = setOf(
            "male", "1boy", "2boys", "3boys", "male_only", "boy", "man", "men",
            "yaoi", "bara", "male/male", "dilf", "shota", "muscular_male", "stallion", "father", "husband"
        )

        val transHermKeywords = setOf(
            "trans", "transgender", "herm", "intersex", "gynomorph", "andromorph",
            "dickgirl", "shemale", "futanari", "futanari/female", "futanari/male", "hermaphrodite"
        )

        val hasFemale = allTags.any { t -> femaleKeywords.any { t.contains(it) } } ||
                femaleKeywords.any { textLower.contains(it) }

        val hasMale = allTags.any { t -> maleKeywords.any { t.contains(it) } } ||
                maleKeywords.any { textLower.contains(it) }

        val hasTrans = allTags.any { t -> transHermKeywords.any { t.contains(it) } } ||
                transHermKeywords.any { textLower.contains(it) }

        return when (filter) {
            GenderFilter.ANY -> true
            GenderFilter.FEMALE_ONLY -> (hasFemale || (!hasMale && !hasTrans)) && !hasMale
            GenderFilter.MALE_ONLY -> hasMale && !hasFemale
            GenderFilter.TRANS_HERM -> hasTrans
        }
    }

    suspend fun recordView(item: MediaItem) = withContext(Dispatchers.IO) {
        sessionViewedIds.add(item.id)
        dao.insertHistory(
            HistoryEntity(
                id = item.id,
                source = item.source.name,
                type = item.type.name,
                title = item.title,
                author = item.author,
                mediaUrl = item.mediaUrl,
                previewUrl = item.previewUrl,
                caption = item.caption,
                tagsRaw = item.tags.joinToString(","),
                viewedTimestamp = System.currentTimeMillis()
            )
        )
        dao.pruneHistoryTo100()
        boostTagWeights(item.tags, 0.5f)
    }

    suspend fun toggleLike(item: MediaItem): Boolean = withContext(Dispatchers.IO) {
        val currentlyLiked = dao.isLiked(item.id)
        val newLiked = !currentlyLiked
        if (newLiked) {
            dao.insertLiked(
                LikedEntity(
                    id = item.id,
                    source = item.source.name,
                    type = item.type.name,
                    title = item.title,
                    author = item.author,
                    mediaUrl = item.mediaUrl,
                    previewUrl = item.previewUrl,
                    caption = item.caption,
                    tagsRaw = item.tags.joinToString(","),
                    likedTimestamp = System.currentTimeMillis()
                )
            )
            boostTagWeights(item.tags, 3.0f)
            syncLikeToRemoteApi(item)
        } else {
            dao.removeLiked(item.id)
            boostTagWeights(item.tags, -1.5f)
        }
        newLiked
    }

    suspend fun toggleFavorite(item: MediaItem): Boolean = withContext(Dispatchers.IO) {
        val currentlyFavorited = dao.isFavorited(item.id)
        val newFav = !currentlyFavorited
        if (newFav) {
            dao.insertFavorite(
                FavoriteEntity(
                    id = item.id,
                    source = item.source.name,
                    type = item.type.name,
                    title = item.title,
                    author = item.author,
                    mediaUrl = item.mediaUrl,
                    previewUrl = item.previewUrl,
                    caption = item.caption,
                    tagsRaw = item.tags.joinToString(","),
                    favoritedTimestamp = System.currentTimeMillis()
                )
            )
            boostTagWeights(item.tags, 5.0f)
        } else {
            dao.removeFavorite(item.id)
        }
        newFav
    }

    suspend fun isLiked(id: String): Boolean = withContext(Dispatchers.IO) {
        dao.isLiked(id)
    }

    suspend fun isFavorited(id: String): Boolean = withContext(Dispatchers.IO) {
        dao.isFavorited(id)
    }

    suspend fun addComment(postId: String, postTitle: String, source: MediaSource, text: String) = withContext(Dispatchers.IO) {
        dao.insertUserComment(
            UserCommentEntity(
                id = UUID.randomUUID().toString(),
                postId = postId,
                postTitle = postTitle,
                source = source.name,
                commentText = text,
                createdTimestamp = System.currentTimeMillis()
            )
        )
    }

    fun getCommentsForPost(postId: String, source: MediaSource): List<CommentItem> {
        return listOf(
            CommentItem(
                id = "c1_$postId",
                postId = postId,
                author = "FurryLover_99",
                content = "The lighting in this animation is absolutely incredible! Love the details.",
                createdAt = System.currentTimeMillis() - 3600000,
                likesCount = 42,
                platform = source
            ),
            CommentItem(
                id = "c2_$postId",
                postId = postId,
                author = "CyberHyena",
                content = "Does anyone know the original creator's Patreon or Bluesky handle?",
                createdAt = System.currentTimeMillis() - 7200000,
                likesCount = 18,
                platform = source
            ),
            CommentItem(
                id = "c3_$postId",
                postId = postId,
                author = "GlitchVixen",
                content = "That smooth transition at 0:15 was pure art! Subscribed.",
                createdAt = System.currentTimeMillis() - 14400000,
                likesCount = 9,
                platform = source
            ),
            CommentItem(
                id = "c4_$postId",
                postId = postId,
                author = "EchoWolf",
                content = "Check the tags sheet for the full character and copyright lore.",
                createdAt = System.currentTimeMillis() - 28800000,
                likesCount = 31,
                platform = source
            )
        )
    }

    fun categorizeTags(tags: List<String>): List<TagItem> {
        return tags.map { tag ->
            val clean = tag.trim().lowercase()
            val type = when {
                clean.startsWith("artist:") || clean in setOf("tokifuji", "kemonono", "miles_df", "falvie", "vallhund") -> TagType.ARTIST
                clean.startsWith("char:") || clean in setOf("judy_hopps", "nick_wilde", "haida", "retsuko", "legoshi", "loona") -> TagType.CHARACTER
                clean.startsWith("copy:") || clean in setOf("zootopia", "aggretsuko", "beastars", "helluva_boss", "pokemon") -> TagType.COPYRIGHT
                clean.startsWith("meta:") || clean in setOf("high_res", "digital_media", "animated", "webm", "mp4") -> TagType.META
                else -> TagType.GENERAL
            }
            TagItem(name = clean.removePrefix("artist:").removePrefix("char:").removePrefix("copy:").removePrefix("meta:"), type = type)
        }
    }

    private suspend fun boostTagWeights(tags: List<String>, delta: Float) {
        val existing = dao.getAlgorithmTagsSnapshot().associateBy { it.tag.lowercase() }
        tags.forEach { tag ->
            val cleanTag = tag.trim().lowercase()
            if (cleanTag.isNotBlank()) {
                val currentWeight = existing[cleanTag]?.weight ?: 1.0f
                val occurrences = (existing[cleanTag]?.occurrences ?: 0) + 1
                val newWeight = (currentWeight + delta).coerceIn(0.1f, 100.0f)
                dao.upsertAlgorithmTag(
                    AlgorithmTagEntity(
                        tag = cleanTag,
                        weight = newWeight,
                        occurrences = occurrences,
                        lastUpdated = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    private suspend fun syncLikeToRemoteApi(item: MediaItem) {
        val prefs = preferencesRepository.userPreferencesFlow.first()
        when (item.source) {
            MediaSource.E621 -> {
                if (prefs.e621Login.isNotBlank() && prefs.e621ApiKey.isNotBlank()) {
                    // Authenticated e621 vote API
                }
            }
            MediaSource.RULE34 -> {
                if (prefs.rule34ApiKey.isNotBlank()) {
                    // Authenticated Rule34 favorite
                }
            }
            MediaSource.BLUESKY -> {
                if (prefs.blueskyHandle.isNotBlank()) {
                    // ATProto like record
                }
            }
            MediaSource.REDDIT -> {
                if (prefs.redditClientId.isNotBlank()) {
                    // Reddit OAuth2 /api/vote
                }
            }
            MediaSource.TWITTER -> {
                if (prefs.twitterBearerToken.isNotBlank()) {
                    // Twitter v2 likes
                }
            }
            else -> Unit
        }
    }

    suspend fun generateSyncDocuments(): SyncDocuments = withContext(Dispatchers.IO) {
        val history = dao.getHistory().first().map { entity ->
            MediaItem(
                id = entity.id,
                source = MediaSource.fromString(entity.source),
                type = MediaType.fromString(entity.type),
                title = entity.title,
                author = entity.author,
                mediaUrl = entity.mediaUrl,
                previewUrl = entity.previewUrl,
                caption = entity.caption,
                tags = entity.tagsRaw.split(",").filter { it.isNotBlank() },
                timestamp = entity.viewedTimestamp
            )
        }

        val liked = dao.getLikedItems().first().map { entity ->
            MediaItem(
                id = entity.id,
                source = MediaSource.fromString(entity.source),
                type = MediaType.fromString(entity.type),
                title = entity.title,
                author = entity.author,
                mediaUrl = entity.mediaUrl,
                previewUrl = entity.previewUrl,
                caption = entity.caption,
                tags = entity.tagsRaw.split(",").filter { it.isNotBlank() },
                timestamp = entity.likedTimestamp
            )
        }

        val favorites = dao.getFavoriteItems().first().map { entity ->
            MediaItem(
                id = entity.id,
                source = MediaSource.fromString(entity.source),
                type = MediaType.fromString(entity.type),
                title = entity.title,
                author = entity.author,
                mediaUrl = entity.mediaUrl,
                previewUrl = entity.previewUrl,
                caption = entity.caption,
                tags = entity.tagsRaw.split(",").filter { it.isNotBlank() },
                timestamp = entity.favoritedTimestamp
            )
        }

        val algorithmTags = dao.getAlgorithmTagsSnapshot().associate { it.tag to it.weight }
        val sourceWeights = MediaSource.entries.associate { it.displayName to (1.0f + (it.ordinal * 0.2f)) }

        SyncDocuments(
            historyDoc = SyncDocuments.buildHistoryText(history),
            algorithmDoc = SyncDocuments.buildAlgorithmText(algorithmTags, sourceWeights),
            likedPostsDoc = SyncDocuments.buildLikedPostsText(liked),
            favoritePostsDoc = SyncDocuments.buildFavoritesText(favorites),
            lastSyncTime = System.currentTimeMillis()
        )
    }

    suspend fun saveToLocalHiddenFolder(item: MediaItem, customFolder: String): String = withContext(Dispatchers.IO) {
        val baseDir = File(context.filesDir, customFolder.ifBlank { ".yiffy_media" })
        if (!baseDir.exists()) baseDir.mkdirs()

        val platformDir = File(baseDir, item.source.name.lowercase())
        if (!platformDir.exists()) platformDir.mkdirs()

        val fileName = "${item.id}_${System.currentTimeMillis()}.${if (item.type == MediaType.VIDEO) "mp4" else "jpg"}"
        val targetFile = File(platformDir, fileName)
        if (!targetFile.exists()) {
            targetFile.writeText("Yiffy media payload for [${item.title}] from [${item.source}] URL: ${item.mediaUrl}")
        }

        dao.insertDownloaded(
            com.example.data.local.DownloadedEntity(
                id = item.id,
                localFilePath = targetFile.absolutePath,
                source = item.source.name,
                type = item.type.name,
                title = item.title,
                author = item.author,
                previewUrl = item.previewUrl,
                fileSize = targetFile.length(),
                downloadedTimestamp = System.currentTimeMillis()
            )
        )
        targetFile.absolutePath
    }

    private fun generateSeedCatalog(): List<MediaItem> {
        return listOf(
            MediaItem(
                id = "vid_ph_01",
                source = MediaSource.PORNHUB,
                type = MediaType.VIDEO,
                title = "Neon Nights Velvet Cyber Foxes",
                author = "FurryVelvetOfficial",
                mediaUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                previewUrl = "https://picsum.photos/seed/yiffy_v1/720/1280",
                caption = "Full 4K immersive loop with cyberpunk neon aesthetics! Enjoy the smooth animations.",
                tags = listOf("female", "fox", "synthwave", "solo", "animated", "neon", "high_res"),
                likesCount = 14200,
                commentsCount = 389,
                durationSeconds = 45
            ),
            MediaItem(
                id = "vid_e6_01",
                source = MediaSource.E621,
                type = MediaType.VIDEO,
                title = "Loona Moonlight Serenade Animation",
                author = "Kemonono_Studio",
                mediaUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                previewUrl = "https://picsum.photos/seed/yiffy_v2/720/1280",
                caption = "High framerate 60fps render featuring Loona under the Blood Moon. Full audio enabled.",
                tags = listOf("char:loona", "copy:helluva_boss", "artist:kemonono", "canine", "female", "solo", "animated", "digital_media"),
                likesCount = 28400,
                commentsCount = 812,
                durationSeconds = 62
            ),
            MediaItem(
                id = "vid_r34_01",
                source = MediaSource.RULE34,
                type = MediaType.VIDEO,
                title = "Judy Hopps Rainforest District Beat",
                author = "Tokifuji_Vault",
                mediaUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                previewUrl = "https://picsum.photos/seed/yiffy_v3/720/1280",
                caption = "Dancing through the rain in Zootopia! 3D model physics test with custom fur shaders.",
                tags = listOf("char:judy_hopps", "copy:zootopia", "artist:tokifuji", "lagomorph", "female", "solo", "animated"),
                likesCount = 19850,
                commentsCount = 421,
                durationSeconds = 30
            ),
            MediaItem(
                id = "pic_e6_01",
                source = MediaSource.E621,
                type = MediaType.PICTURE,
                title = "Solar Flare Vulpine Goddess",
                author = "Falvie",
                mediaUrl = "https://picsum.photos/seed/e621_pic1/1080/1920",
                previewUrl = "https://picsum.photos/seed/e621_pic1/720/1280",
                caption = "Painted live during Eurofurence charity stream! Digital acrylic brushes on canvas.",
                tags = listOf("artist:falvie", "fox", "female", "anthro", "fur", "glowing", "digital_painting"),
                likesCount = 34500,
                commentsCount = 612
            ),
            MediaItem(
                id = "pic_r34_01",
                source = MediaSource.RULE34,
                type = MediaType.PICTURE,
                title = "Crimson Vixen Sunset Pinup",
                author = "Miles_DF",
                mediaUrl = "https://picsum.photos/seed/r34_pic1/1080/1920",
                previewUrl = "https://picsum.photos/seed/r34_pic1/720/1280",
                caption = "Sunset photoshoot at the Golden Sands beach pavilion. Crisp rim lighting.",
                tags = listOf("artist:miles_df", "female", "fox", "bikini", "sunset", "detailed_background"),
                likesCount = 22100,
                commentsCount = 504
            ),
            MediaItem(
                id = "pic_bsky_01",
                source = MediaSource.BLUESKY,
                type = MediaType.PICTURE,
                title = "Haida & Retsuko Karaoke Night Out",
                author = "AggroBeats.bsky.social",
                authorAvatarUrl = "https://picsum.photos/seed/bsky_av1/100/100",
                mediaUrl = "https://picsum.photos/seed/bsky_pic1/1080/1920",
                previewUrl = "https://picsum.photos/seed/bsky_pic1/720/1280",
                caption = "Late night death metal screaming session! Don't let the boss hear us. #Aggretsuko #Art",
                tags = listOf("copy:aggretsuko", "char:retsuko", "char:haida", "female", "male", "hyena", "red_panda"),
                likesCount = 8900,
                commentsCount = 143
            ),
            MediaItem(
                id = "pic_tw_01",
                source = MediaSource.TWITTER,
                type = MediaType.PICTURE,
                title = "Cyberpunk Fox Runner 2099",
                author = "@NeonClawsArt",
                authorAvatarUrl = "https://picsum.photos/seed/tw_av1/100/100",
                mediaUrl = "https://picsum.photos/seed/tw_pic1/1080/1920",
                previewUrl = "https://picsum.photos/seed/tw_pic1/720/1280",
                caption = "New character commission completed! Ready to jack into the neural matrix.",
                tags = listOf("cyberpunk", "female", "fox", "scifi", "glowing_eyes", "leather_jacket"),
                likesCount = 17600,
                commentsCount = 295
            ),
            MediaItem(
                id = "pic_rd_01",
                source = MediaSource.REDDIT,
                type = MediaType.PICTURE,
                title = "Legoshi & Haru Spring Festival Date",
                author = "u/WolfAndRabbit",
                authorAvatarUrl = "https://picsum.photos/seed/rd_av1/100/100",
                mediaUrl = "https://picsum.photos/seed/reddit_pic1/1080/1920",
                previewUrl = "https://picsum.photos/seed/reddit_pic1/720/1280",
                caption = "Posted to r/beastars: Painted our favorite duo under cherry blossoms! OC fanart.",
                tags = listOf("copy:beastars", "char:legoshi", "char:haru", "male", "female", "wolf", "rabbit"),
                likesCount = 15300,
                commentsCount = 378
            ),
            MediaItem(
                id = "misc_tw_01",
                source = MediaSource.TWITTER,
                type = MediaType.MISC,
                title = "Midnight sketches and sneak peeks",
                author = "@VixenIllustrates",
                authorAvatarUrl = "https://picsum.photos/seed/tw_av2/100/100",
                mediaUrl = "https://picsum.photos/seed/misc_pic1/1080/1920",
                previewUrl = "https://picsum.photos/seed/misc_pic1/720/1280",
                caption = "WIP preview of Chapter 4! What do you think about the dynamic action poses? Drop suggestions below! 🐾✨",
                tags = listOf("wip", "female", "sketch", "comic_preview", "anthro"),
                likesCount = 6420,
                commentsCount = 129
            ),
            MediaItem(
                id = "misc_bsky_02",
                source = MediaSource.BLUESKY,
                type = MediaType.MISC,
                title = "Convention artist alley setup ready!",
                author = "FenrisPaws.bsky.social",
                authorAvatarUrl = "https://picsum.photos/seed/bsky_av2/100/100",
                mediaUrl = "https://picsum.photos/seed/misc_pic2/1080/1920",
                previewUrl = "https://picsum.photos/seed/misc_pic2/720/1280",
                caption = "Table B14 is stocked with foil prints, enamel pins, and sticker sheets! Come say hi if you're attending!",
                tags = listOf("convention", "artist_alley", "merch", "prints", "fox"),
                likesCount = 4910,
                commentsCount = 88
            ),
            MediaItem(
                id = "misc_rd_02",
                source = MediaSource.REDDIT,
                type = MediaType.MISC,
                title = "Community redraw challenge submissions",
                author = "u/FurryArtSchoolMod",
                authorAvatarUrl = "https://picsum.photos/seed/rd_av2/100/100",
                mediaUrl = "https://picsum.photos/seed/misc_pic3/1080/1920",
                previewUrl = "https://picsum.photos/seed/misc_pic3/720/1280",
                caption = "r/FurryArtSchool monthly challenge results are up! Over 400 entries submitted this round.",
                tags = listOf("community", "challenge", "art_showcase", "digital_art"),
                likesCount = 8240,
                commentsCount = 312
            )
        )
    }

    private fun generateSeedComics(): List<ComicSeries> {
        return listOf(
            ComicSeries(
                id = "comic_e6_pool_01",
                source = MediaSource.E621,
                title = "The Neon Den Chronicles",
                author = "Tokifuji",
                coverUrl = "https://picsum.photos/seed/comic_cover1/800/1200",
                pagesCount = 12,
                tags = listOf("artist:tokifuji", "female", "fox", "scifi", "pool", "comic"),
                description = "An e621 continuous pool following the escapades of a detective fox in Neo-Tokyo.",
                pages = (1..12).map { "https://picsum.photos/seed/comic_e6_p$it/900/1400" }
            ),
            ComicSeries(
                id = "comic_mrm_01",
                source = MediaSource.MYREADINGMANGA,
                title = "Wild Winds Across the Highlands",
                author = "Yukihiro_Art",
                coverUrl = "https://picsum.photos/seed/comic_cover2/800/1200",
                pagesCount = 16,
                tags = listOf("fantasy", "anthro", "wolves", "adventure", "manga"),
                description = "MyReadingManga serialized anthology of nomadic beast clans guarding ancient mountain passes.",
                pages = (1..16).map { "https://picsum.photos/seed/comic_mrm_p$it/900/1400" }
            ),
            ComicSeries(
                id = "comic_eh_01",
                source = MediaSource.EHENTAI,
                title = "Velvet Moon Doujin Volume 1",
                author = "Studio_Lupus",
                coverUrl = "https://picsum.photos/seed/comic_cover3/800/1200",
                pagesCount = 18,
                tags = listOf("doujinshi", "female", "canine", "magic", "ehentai"),
                description = "E-Hentai gallery translated tankoubon release featuring magical vixen summoners.",
                pages = (1..18).map { "https://picsum.photos/seed/comic_eh_p$it/900/1400" }
            ),
            ComicSeries(
                id = "comic_e6_pool_02",
                source = MediaSource.E621,
                title = "Subway Serenade: Judy & Friends",
                author = "Kemonono",
                coverUrl = "https://picsum.photos/seed/comic_cover4/800/1200",
                pagesCount = 8,
                tags = listOf("copy:zootopia", "char:judy_hopps", "female", "comic", "pool"),
                description = "Short comedic slice-of-life pool detailing daily subway commutes.",
                pages = (1..8).map { "https://picsum.photos/seed/comic_e6_p2_$it/900/1400" }
            )
        )
    }
}
