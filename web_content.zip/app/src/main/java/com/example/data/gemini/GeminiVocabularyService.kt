package com.example.data.gemini

import com.example.BuildConfig
import com.example.data.image.VocabularyImageProvider
import com.example.data.model.WordContext
import com.example.data.model.WordDefinition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

object GeminiVocabularyService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    // Offline built-in colloquial dictionary for instant response and zero-failure mode
    private val OFFLINE_DICTIONARY = mapOf(
        "inmutable" to PredefinedDef(
            simple = "Que no cambia",
            colloquial = "Como esa receta de la abuela que nunca se modifica, pase lo que pase.",
            context = "Indica algo tan firme y eterno que el tiempo no le hace ni cosquillas.",
            example = "El horario de apertura del supermercado es inmutable.",
            category = "Cualidad",
            keyword = "montana"
        ),
        "sosiego" to PredefinedDef(
            simple = "Tranquilidad",
            colloquial = "Paz mental total, como tomarte un té caliente en el sofá sin pendientes en el trabajo.",
            context = "En el texto representa la calma y serenidad que la gente buscaba desesperadamente.",
            example = "Por fin encontré sosiego cuando apagué las notificaciones del teléfono.",
            category = "Emoción",
            keyword = "serenidad"
        ),
        "ataraxia" to PredefinedDef(
            simple = "Paz mental absoluta",
            colloquial = "El 'modo zen' supremo: nada te altera, nada te enoja, todo te resbala con calma.",
            context = "En filosofía es el estado donde ningún miedo ni problema te quita el sueño.",
            example = "Logró la ataraxia cuando dejó de discutir por tonterías en internet.",
            category = "Filosofía",
            keyword = "serenidad"
        ),
        "letargo" to PredefinedDef(
            simple = "Flojera / Sueño pesado",
            colloquial = "Estar en modo avión biológico, aplatanado y con cero ganas de moverte.",
            context = "Describe a los habitantes del pueblo adormecidos por el frío invierno.",
            example = "La siesta me dejó en un letargo que me duró hasta la noche.",
            category = "Estado",
            keyword = "estrellas"
        ),
        "vicisitudes" to PredefinedDef(
            simple = "Altibajos de la vida",
            colloquial = "Las vueltas locas que da la vida: hoy arriba, mañana abajo, pero remando.",
            context = "Hace referencia a todos los problemas e imprevistos que trajo el invierno.",
            example = "Superamos todas las vicisitudes del viaje y llegamos sanos y salvos.",
            category = "Vida",
            keyword = "camino"
        ),
        "ecuanimidad" to PredefinedDef(
            simple = "Cabeza fría",
            colloquial = "Mantener la calma y no perder los estribos cuando todo el mundo está gritando.",
            context = "El boticario no se dejaba influir por el pánico de los demás vecinos.",
            example = "El árbitro manejó el partido con total ecuanimidad.",
            category = "Cualidad",
            keyword = "mente"
        ),
        "disquisicion" to PredefinedDef(
            simple = "Reflexión profunda",
            colloquial = "Echarse una buena pensada o filosofar largo y tendido sobre la vida.",
            context = "Escribía análisis minuciosos y profundos en su libreta de notas.",
            example = "Tuvimos una disquisición sobre si la pizza con piña es un pecado.",
            category = "Pensamiento",
            keyword = "filosofia"
        ),
        "taciturno" to PredefinedDef(
            simple = "Callado / Serio",
            colloquial = "Alguien que habla poco y parece andar siempre en su propio mundo interior.",
            context = "Describe al boticario como un hombre reservado y pensativo.",
            example = "Mateo anduvo taciturno toda la tarde porque extrañaba a su perro.",
            category = "Personalidad",
            keyword = "antiguo"
        ),
        "desidia" to PredefinedDef(
            simple = "Dejadez / Pereza",
            colloquial = "Dejar todo para mañana y que te dé flojera hasta parpadear.",
            context = "El personaje nunca cayó en el abandono ni en el descuido de su labor.",
            example = "Por pura desidia no renovó la suscripción a tiempo.",
            category = "Hábito",
            keyword = "tiempo"
        ),
        "desasosiego" to PredefinedDef(
            simple = "Intranquilidad",
            colloquial = "Ese nudo en la panza de no poder estar quieto porque algo te preocupa.",
            context = "El malestar o zozobra que sufría la gente del pueblo.",
            example = "Sentía un gran desasosiego esperando los resultados del examen.",
            category = "Emoción",
            keyword = "fuego"
        ),
        "singularidad" to PredefinedDef(
            simple = "Punto único extremo",
            colloquial = "Un punto tan denso y apretado en el espacio que rompe todas las reglas conocidas.",
            context = "En astrofísica es el corazón de un agujero negro donde la física se vuelve loca.",
            example = "El origen del universo comenzó en una singularidad diminuta.",
            category = "Ciencia",
            keyword = "espacio"
        ),
        "inexpugnable" to PredefinedDef(
            simple = "Imposible de vencer",
            colloquial = "Como una fortaleza con muros de diez metros: nadie puede entrar ni romperlo.",
            context = "El horizonte de un agujero negro del que ni la luz puede escapar jamás.",
            example = "Su defensa en el juego de ajedrez era totalmente inexpugnable.",
            category = "Cualidad",
            keyword = "montana"
        ),
        "efimero" to PredefinedDef(
            simple = "Pasajero / Dura poco",
            colloquial = "Dura lo que un suspiro, como una pompa de jabón o el sueldo el día de pago.",
            context = "En el cosmos se refiere a explosiones fugaces de rayos gamma.",
            example = "La fama en redes sociales suele ser muy efímera.",
            category = "Tiempo",
            keyword = "naturaleza"
        ),
        "perihelio" to PredefinedDef(
            simple = "Punto más cercano al Sol",
            colloquial = "El momento en que un planeta o cometa pasa más pegadito al Sol y le da calor.",
            context = "Describe la órbita de los cometas cuando se aproximan a nuestra estrella.",
            example = "La Tierra alcanza su perihelio a principios de enero.",
            category = "Astronomía",
            keyword = "espacio"
        ),
        "quimera" to PredefinedDef(
            simple = "Fantasía irreal",
            colloquial = "Hacerte ilusiones con castillos en el aire que nunca van a pasar.",
            context = "En filosofía se refiere a perseguir sueños vanos que sólo causan frustración.",
            example = "Creer que te harás millonario de la noche a la mañana es una quimera.",
            category = "Mente",
            keyword = "luz"
        ),
        "voragine" to PredefinedDef(
            simple = "Remolino caótico",
            colloquial = "Estar metido en un torbellino donde todo pasa rápido y no te da tiempo ni de respirar.",
            context = "La marea descontrolada de emociones que nublan el juicio de la persona.",
            example = "La vorágine de la ciudad en hora pico es agotadora.",
            category = "Situación",
            keyword = "agua"
        ),
        "arbitrio" to PredefinedDef(
            simple = "Tu propia decisión",
            colloquial = "Lo que tú eliges hacer con tus propias manos y voluntad, nadie más.",
            context = "En el estoicismo es aquello que sí está bajo tu control personal.",
            example = "Elegir ser amable o grosero queda a tu propio arbitrio.",
            category = "Decisión",
            keyword = "camino"
        ),
        "discernir" to PredefinedDef(
            simple = "Distinguir claramente",
            colloquial = "Saber separar el trigo de la paja; darte cuenta de qué vale la pena y qué no.",
            context = "Capacidad de darse cuenta con inteligencia de lo importante.",
            example = "Es vital discernir entre noticias reales y chismes falsos.",
            category = "Inteligencia",
            keyword = "filosofia"
        )
    )

    private data class PredefinedDef(
        val simple: String,
        val colloquial: String,
        val context: String,
        val example: String,
        val category: String,
        val keyword: String
    )

    /**
     * Explains a list of unknown words in colloquial, everyday terms and in context.
     * Uses Gemini 3.5 Flash via REST if available, with robust offline dictionary fallback.
     */
    suspend fun explainUnknownWords(
        unknownWords: List<WordContext>,
        materialTopic: String = "Lectura general"
    ): List<WordDefinition> = withContext(Dispatchers.IO) {
        if (unknownWords.isEmpty()) return@withContext emptyList()

        // Deduplicate words (keep first occurrence and its context)
        val distinctWords = unknownWords.distinctBy { it.word.lowercase() }

        val apiKey = BuildConfig.GEMINI_API_KEY
        var geminiResults: Map<String, GeminiWordResult>? = null

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                geminiResults = queryGeminiBatch(distinctWords, materialTopic, apiKey)
            } catch (e: Exception) {
                // Fall back to offline dictionary
            }
        }

        // Build final list of WordDefinition
        val definitions = mutableListOf<WordDefinition>()
        var number = 1

        for (wordCtx in distinctWords) {
            val key = wordCtx.word.lowercase()
                .replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o").replace("ú", "u")

            val geminiDef = geminiResults?.get(key) ?: geminiResults?.get(wordCtx.word.lowercase())
            val offlineDef = OFFLINE_DICTIONARY[key]

            val simpleSynonym: String
            val colloquialMeaning: String
            val contextualExplanation: String
            val dailyLifeExample: String
            val category: String
            val imageKeyword: String

            if (geminiDef != null) {
                simpleSynonym = geminiDef.simpleSynonym
                colloquialMeaning = geminiDef.colloquialMeaning
                contextualExplanation = geminiDef.contextualExplanation
                dailyLifeExample = geminiDef.dailyLifeExample
                category = geminiDef.category
                imageKeyword = geminiDef.imageKeyword
            } else if (offlineDef != null) {
                simpleSynonym = offlineDef.simple
                colloquialMeaning = offlineDef.colloquial
                contextualExplanation = "${offlineDef.context} (En el texto: \"${wordCtx.sentenceContext.take(80)}...\")"
                dailyLifeExample = offlineDef.example
                category = offlineDef.category
                imageKeyword = offlineDef.keyword
            } else {
                // Heuristic contextual explanation
                simpleSynonym = "Término clave de la frase"
                colloquialMeaning = "Palabra poco común o técnica que significa algo que sucede de manera particular en esta oración."
                contextualExplanation = "En este material se utiliza para expresar: \"${wordCtx.sentenceContext}\"."
                dailyLifeExample = "Cuando leas un texto similar, recuerda que '${wordCtx.displayWord}' aporta precisión y elegancia a la idea."
                category = "Vocabulario"
                imageKeyword = "lectura"
            }

            val imageUrl = VocabularyImageProvider.getImageForWord(
                word = wordCtx.word,
                category = category,
                keywordHint = imageKeyword
            )

            definitions.add(
                WordDefinition(
                    id = UUID.randomUUID().toString(),
                    number = number,
                    word = wordCtx.word,
                    displayWord = wordCtx.displayWord,
                    simpleSynonym = simpleSynonym,
                    colloquialMeaning = colloquialMeaning,
                    contextualExplanation = contextualExplanation,
                    originalSentence = wordCtx.sentenceContext,
                    dailyLifeExample = dailyLifeExample,
                    category = category,
                    imageUrl = imageUrl,
                    pageNumber = wordCtx.pageNumber
                )
            )
            number++
        }

        definitions
    }

    private data class GeminiWordResult(
        val simpleSynonym: String,
        val colloquialMeaning: String,
        val contextualExplanation: String,
        val dailyLifeExample: String,
        val category: String,
        val imageKeyword: String
    )

    private fun queryGeminiBatch(
        words: List<WordContext>,
        materialTopic: String,
        apiKey: String
    ): Map<String, GeminiWordResult> {
        val wordItemsJson = StringBuilder()
        wordItemsJson.append("[")
        for ((idx, w) in words.withIndex()) {
            val escapedSentence = JSONObject.quote(w.sentenceContext)
            val escapedWord = JSONObject.quote(w.displayWord)
            wordItemsJson.append("""{"word":$escapedWord,"context":$escapedSentence}""")
            if (idx < words.size - 1) wordItemsJson.append(",")
        }
        wordItemsJson.append("]")

        val prompt = """
Eres un profesor amigable y ocurrente que explica palabras difíciles de forma ultra coloquial, divertida y simple a cualquier persona.
El usuario leyó un texto sobre "$materialTopic" y marcó que NO CONOCE las siguientes palabras:
$wordItemsJson

Para cada palabra, debes devolver un JSON ARRAY exacto donde cada objeto tenga:
1. "word": la palabra en minúsculas (ej: "letargo").
2. "simpleSynonym": una sola palabra o frase súper sencilla que ya todo el mundo conoce (ej: "Flojera extrema", "Paz mental").
3. "colloquialMeaning": explicación muy coloquial, divertida, sin tecnicismos ("como si te lo explicara un amigo con un refresco").
4. "contextualExplanation": qué significa exactamente en el contexto de la frase de donde se extrajo.
5. "dailyLifeExample": un ejemplo cómico o cotidiano de la vida diaria para acordarse siempre.
6. "category": una categoría corta (ej: "Emoción", "Naturaleza", "Ciencia", "Acción").
7. "imageKeyword": una palabra en inglés o español para buscar una foto ilustrativa (ej: "nature", "stars", "sleep", "ancient book").

Devuelve ÚNICAMENTE el JSON array válido sin texto adicional ni bloques markdown.
""".trim()

        val requestJson = JSONObject().apply {
            val contentsArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            }
            put("contents", contentsArray)

            val genConfig = JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            }
            put("generationConfig", genConfig)
        }

        val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            return emptyMap()
        }

        val responseBodyString = response.body?.string() ?: return emptyMap()
        val jsonRoot = JSONObject(responseBodyString)
        val candidates = jsonRoot.optJSONArray("candidates") ?: return emptyMap()
        val firstCandidate = candidates.optJSONObject(0) ?: return emptyMap()
        val content = firstCandidate.optJSONObject("content") ?: return emptyMap()
        val parts = content.optJSONArray("parts") ?: return emptyMap()
        val textPart = parts.optJSONObject(0)?.optString("text") ?: return emptyMap()

        val resultsMap = mutableMapOf<String, GeminiWordResult>()
        try {
            val cleanedText = textPart.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val array = JSONArray(cleanedText)
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val word = item.optString("word").lowercase()
                val simple = item.optString("simpleSynonym", "Sinónimo sencillo")
                val colloquial = item.optString("colloquialMeaning", "Explicación simple y clara.")
                val context = item.optString("contextualExplanation", "Significado en la frase.")
                val example = item.optString("dailyLifeExample", "Ejemplo práctico.")
                val category = item.optString("category", "General")
                val keyword = item.optString("imageKeyword", "libro")

                resultsMap[word] = GeminiWordResult(
                    simpleSynonym = simple,
                    colloquialMeaning = colloquial,
                    contextualExplanation = context,
                    dailyLifeExample = example,
                    category = category,
                    imageKeyword = keyword
                )
            }
        } catch (e: Exception) {
            // parsing error fallback
        }

        return resultsMap
    }
}
