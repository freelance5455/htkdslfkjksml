package com.example.data.repository

import android.graphics.Bitmap
import android.util.Log
import com.example.data.model.ChatMessage
import com.example.data.model.MerkopMode
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

class MerkopAiRepository {

    private class PrimaryStallException : CancellationException("Primary first-chunk stalled")

    private val modelCache = ConcurrentHashMap<Triple<MerkopMode, String, Boolean>, GenerativeModel>()

    private fun getModel(
        mode: MerkopMode,
        modelName: String,
        deepCoding: Boolean = false
    ): GenerativeModel {
        val cacheKey = Triple(mode, modelName, deepCoding)
        return modelCache.getOrPut(cacheKey) {
            val config = generationConfig {
                temperature = when {
                    mode == MerkopMode.CODER && deepCoding -> 0.15f
                    mode == MerkopMode.CODER -> 0.2f
                    mode == MerkopMode.WRITER -> 0.9f
                    mode == MerkopMode.TUTOR -> 0.55f
                    else -> 0.65f
                }
                topP = if (mode == MerkopMode.CODER) 0.9f else 0.95f
                maxOutputTokens = 8192
            }
            val promptText = if (mode == MerkopMode.CODER && deepCoding) {
                mode.systemPrompt + " DERİN KODLAMA MODU: Karmaşık mimari, 3D/oyun fiziği, algoritma veya çok dosyalı proje istendiğinde önce kısa bir teknik plan yap, tüm kenar durumları ve hata yakalamaları eksiksiz yaz, hiçbir fonksiyonu kısaltma."
            } else {
                mode.systemPrompt
            }
            Firebase.ai.generativeModel(
                modelName = modelName,
                generationConfig = config,
                systemInstruction = content { text(promptText) }
            )
        }
    }

    fun streamReply(
        mode: MerkopMode,
        history: List<ChatMessage>,
        userPrompt: String,
        attachedImage: Bitmap?,
        deepCoding: Boolean = false,
        attachedModels3d: List<com.example.util.Model3dAsset> = emptyList()
    ): Flow<String> = flow {
        val chatHistory = buildSanitizedHistory(history)
        val modelContext = com.example.util.Model3dHelper.buildModels3dPromptContext(attachedModels3d)
        val effectivePrompt = if (modelContext.isNotBlank()) "$userPrompt\n$modelContext" else userPrompt
        val userContent = content(role = "user") {
            if (attachedImage != null) {
                image(attachedImage)
            }
            text(effectivePrompt)
        }

        val modelsToTry = listOf(PRIMARY_MODEL_NAME, FALLBACK_MODEL_NAME)
        var lastError: Exception? = null

        for ((index, modelName) in modelsToTry.withIndex()) {
            var emittedAny = false
            val hasFallback = index < modelsToTry.lastIndex
            try {
                val chat = getModel(mode, modelName, deepCoding).startChat(history = chatHistory)
                coroutineScope {
                    val watchdog = if (hasFallback) {
                        launch {
                            delay(PRIMARY_FIRST_CHUNK_TIMEOUT_MS)
                            if (!emittedAny) {
                                this@coroutineScope.cancel(PrimaryStallException())
                            }
                        }
                    } else {
                        null
                    }

                    chat.sendMessageStream(userContent).collect { chunk ->
                        val text = chunk.text
                        if (!text.isNullOrEmpty()) {
                            if (!emittedAny) {
                                emittedAny = true
                                watchdog?.cancel()
                            }
                            emit(text)
                        }
                    }
                    if (!emittedAny) {
                        val unary = chat.sendMessage(userContent).text?.trim()
                        if (!unary.isNullOrEmpty()) {
                            emittedAny = true
                            watchdog?.cancel()
                            emit(unary)
                        }
                    }
                    watchdog?.cancel()
                }
                if (emittedAny) return@flow
            } catch (e: PrimaryStallException) {
                lastError = e
                Log.w(TAG, "Primary model $modelName stalled before first chunk; falling back", e)
                if (!hasFallback) throw e
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                Log.w(TAG, "Inference attempt failed for $modelName (emittedAny=$emittedAny)", e)
                if (emittedAny || !hasFallback || !isRetryableOverload(e)) {
                    throw e
                }
                delay(350L)
            }
        }

        throw lastError ?: IllegalStateException("Merkop şu an yanıt üretemedi.")
    }.flowOn(Dispatchers.IO)

    suspend fun reviewAndPolishCode(
        userPrompt: String,
        draftReply: String
    ): String? = withContext(Dispatchers.IO) {
        if (!draftReply.contains("```")) return@withContext null
        val auditPrompt = buildString {
            appendLine("Kullanıcının isteği:")
            appendLine(userPrompt)
            appendLine()
            appendLine("Üretilen taslak yanıt:")
            appendLine(draftReply)
            appendLine()
            appendLine("GÖREV: Bu taslaktaki kodları titizlikle denetle. Eksik import, sözdizimi hatası, tanımlanmamış değişken, mantık hatası veya '// TODO' gibi yarım bırakılmış yerler varsa hepsini düzeltip TAM ve ÇALIŞIR son sürümü ver. Eğer taslak zaten eksiksiz ve hatasızsa aynen koru. Yalnızca son yanıtı döndür.")
        }
        try {
            val model = getModel(MerkopMode.CODER, FALLBACK_MODEL_NAME, deepCoding = false)
            model.generateContent(auditPrompt).text?.trim()?.takeIf { it.isNotEmpty() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Auto-review skipped due to error", e)
            null
        }
    }

    suspend fun generateReplyUnary(
        mode: MerkopMode,
        history: List<ChatMessage>,
        userPrompt: String,
        attachedImage: Bitmap?,
        attachedModels3d: List<com.example.util.Model3dAsset> = emptyList()
    ): String? = withContext(Dispatchers.IO) {
        val chatHistory = buildSanitizedHistory(history)
        val modelContext = com.example.util.Model3dHelper.buildModels3dPromptContext(attachedModels3d)
        val effectivePrompt = if (modelContext.isNotBlank()) "$userPrompt\n$modelContext" else userPrompt
        val userContent = content(role = "user") {
            if (attachedImage != null) {
                image(attachedImage)
            }
            text(effectivePrompt)
        }

        for (modelName in listOf(PRIMARY_MODEL_NAME, FALLBACK_MODEL_NAME)) {
            try {
                val chat = getModel(mode, modelName).startChat(history = chatHistory)
                val text = chat.sendMessage(userContent).text?.trim()
                if (!text.isNullOrEmpty()) return@withContext text
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Unary attempt failed for $modelName", e)
                if (!isRetryableOverload(e) || modelName == FALLBACK_MODEL_NAME) {
                    throw e
                }
            }
        }
        null
    }

    private fun isRetryableOverload(error: Throwable): Boolean {
        val msg = generateSequence(error) { it.cause }
            .mapNotNull { it.message }
            .joinToString(" ")
        return Regex(
            pattern = "high demand|overloaded|unavailable|503|429|resource_exhausted|quota|try again|temporar",
            option = RegexOption.IGNORE_CASE
        ).containsMatchIn(msg)
    }

    private fun buildSanitizedHistory(messages: List<ChatMessage>): List<Content> {
        val sanitized = mutableListOf<Content>()
        var lastRole: String? = null
        for (msg in messages.takeLast(MAX_HISTORY_TURNS)) {
            val role = if (msg.role == ChatMessage.ROLE_MODEL) "model" else "user"
            if (sanitized.isEmpty() && role != "user") continue
            if (msg.text.isBlank()) continue
            if (role == lastRole && sanitized.isNotEmpty()) {
                val prev = sanitized.removeAt(sanitized.lastIndex)
                val combinedText = prev.parts.joinToString("\n") {
                    (it as? com.google.firebase.ai.type.TextPart)?.text.orEmpty()
                } + "\n" + msg.text
                sanitized.add(content(role) { text(combinedText) })
            } else {
                sanitized.add(content(role) { text(msg.text) })
                lastRole = role
            }
        }
        while (sanitized.isNotEmpty() && sanitized.last().role == "user") {
            sanitized.removeAt(sanitized.lastIndex)
        }
        return sanitized
    }

    companion object {
        private const val TAG = "MerkopAiRepo"
        private const val PRIMARY_MODEL_NAME = "gemini-3.8-flash"
        private const val FALLBACK_MODEL_NAME = "gemini-3.5-flash-lite"
        private const val PRIMARY_FIRST_CHUNK_TIMEOUT_MS = 12_000L
        private const val MAX_HISTORY_TURNS = 24

        fun toUserFriendlyMessage(error: Throwable): String {
            val raw = error.localizedMessage.orEmpty()
            return if (Regex(
                    pattern = "high demand|overloaded|unavailable|503|429|resource_exhausted|quota|try again",
                    option = RegexOption.IGNORE_CASE
                ).containsMatchIn(raw)
            ) {
                "Merkop sunucuları şu an çok yoğun. Lütfen birkaç saniye bekleyip tekrar deneyin."
            } else {
                raw.ifBlank { "Merkop yanıt üretirken bir hata oluştu." }
            }
        }
    }
}
