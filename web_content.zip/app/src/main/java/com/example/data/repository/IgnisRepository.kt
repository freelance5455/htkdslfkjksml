package com.example.data.repository

import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

class IgnisRepository private constructor() {

    private val _selectedRole = MutableStateFlow(UserRole.CONSUMER)
    val selectedRole: StateFlow<UserRole> = _selectedRole.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(
        User(
            id = "user_consumer_1",
            name = "Maya Chen",
            email = "maya.chen@example.com",
            phone = "+1 (555) 019-2834",
            role = UserRole.CONSUMER,
            age = 27,
            profession = "Industrial Designer",
            location = "Downtown Innovation District, New Tech City",
            bio = "Enthusiast of modular electronics, clean materials, and sustainable everyday gadgets."
        )
    )
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _onboardingCompleted = MutableStateFlow(true)
    val onboardingCompleted: StateFlow<Boolean> = _onboardingCompleted.asStateFlow()

    private val _locationGranted = MutableStateFlow(true)
    val locationGranted: StateFlow<Boolean> = _locationGranted.asStateFlow()

    private val _approximateLocation = MutableStateFlow("Downtown Innovation District (~1.8 km)")
    val approximateLocation: StateFlow<String> = _approximateLocation.asStateFlow()

    private val _products = MutableStateFlow(SampleData.sampleProducts)
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _sellerSpaces = MutableStateFlow(SampleData.sampleSellerSpaces)
    val sellerSpaces: StateFlow<List<SellerSpace>> = _sellerSpaces.asStateFlow()

    private val _deliveryPartners = MutableStateFlow(SampleData.sampleDeliveryPartners)
    val deliveryPartners: StateFlow<List<DeliveryPartner>> = _deliveryPartners.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _orders = MutableStateFlow(SampleData.sampleOrders)
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _chats = MutableStateFlow(SampleData.sampleChats)
    val chats: StateFlow<List<Chat>> = _chats.asStateFlow()

    private val _notifications = MutableStateFlow(SampleData.sampleNotifications)
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _commissionConfig = MutableStateFlow(CommissionConfig(0.85, 0.10, 0.05))
    val commissionConfig: StateFlow<CommissionConfig> = _commissionConfig.asStateFlow()

    fun setRole(role: UserRole) {
        _selectedRole.value = role
        // Also ensure user model adapts
        _currentUser.update { current ->
            current?.copy(role = role) ?: User(
                id = "user_${role.name.lowercase()}_active",
                name = if (role == UserRole.SELLER) "Apex Labs Innovator" else if (role == UserRole.DELIVERY_PARTNER) "Marcus Vance" else "Maya Chen",
                email = "user@ignis.market",
                phone = "+1 (555) 892-1002",
                role = role,
                age = 29,
                profession = if (role == UserRole.SELLER) "Hardware Innovator" else if (role == UserRole.DELIVERY_PARTNER) "Logistics Specialist" else "Designer",
                location = "Downtown Innovation District"
            )
        }
    }

    fun completeOnboarding(
        name: String,
        role: UserRole,
        age: Int,
        profession: String,
        location: String,
        locationGranted: Boolean
    ) {
        _locationGranted.value = locationGranted
        _approximateLocation.value = if (locationGranted) location else "Location not shared (Limited local matching)"
        _selectedRole.value = role
        _currentUser.value = User(
            id = "user_${UUID.randomUUID().toString().take(6)}",
            name = name.ifBlank { if (role == UserRole.SELLER) "Innovator Studio" else if (role == UserRole.DELIVERY_PARTNER) "Alex Reed" else "Alex Explorer" },
            email = "${name.lowercase().replace(" ", "")}@ignis.app",
            phone = "+1 (555) 781-9021",
            role = role,
            age = age,
            profession = profession,
            location = _approximateLocation.value
        )
        _onboardingCompleted.value = true
    }

    fun setLocationPermission(granted: Boolean, approxLocation: String? = null) {
        _locationGranted.value = granted
        if (granted) {
            _approximateLocation.value = approxLocation ?: "Downtown Innovation District (~2.1 km)"
        } else {
            _approximateLocation.value = "Location access denied (Manual Area)"
        }
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        _cart.update { current ->
            val existing = current.find { it.product.id == product.id }
            if (existing != null) {
                current.map {
                    if (it.product.id == product.id) it.copy(quantity = it.quantity + quantity) else it
                }
            } else {
                current + CartItem(product, quantity)
            }
        }
    }

    fun updateCartQuantity(productId: String, quantity: Int) {
        if (quantity <= 0) {
            removeFromCart(productId)
            return
        }
        _cart.update { current ->
            current.map {
                if (it.product.id == productId) it.copy(quantity = quantity) else it
            }
        }
    }

    fun removeFromCart(productId: String) {
        _cart.update { current -> current.filterNot { it.product.id == productId } }
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun placeOrder(address: DeliveryAddress, paymentMethod: String): Order {
        val currentCart = _cart.value
        val subtotal = currentCart.sumOf { it.totalPrice }
        val deliveryCharge = 4.50
        val platformFee = subtotal * _commissionConfig.value.platformPercentage
        val total = subtotal + deliveryCharge + platformFee

        val newOrder = Order(
            id = "ord_${UUID.randomUUID().toString().take(6)}",
            orderNumber = "IGN-${(10000..99999).random()}",
            consumerId = _currentUser.value?.id ?: "consumer_1",
            consumerName = _currentUser.value?.name ?: "Customer",
            sellerId = currentCart.firstOrNull()?.product?.sellerId ?: "seller_apex",
            sellerName = currentCart.firstOrNull()?.product?.sellerName ?: "Apex Labs Modular Tech",
            deliveryPartnerId = null,
            deliveryPartnerName = null,
            items = currentCart,
            subtotal = subtotal,
            deliveryCharge = deliveryCharge,
            platformFee = platformFee,
            total = total,
            status = OrderStatus.ORDER_PLACED,
            deliveryAddress = address,
            createdAt = System.currentTimeMillis(),
            paymentMethod = paymentMethod,
            estimatedDeliveryMinutes = 35
        )

        _orders.update { listOf(newOrder) + it }
        clearCart()

        // Create notification
        _notifications.update { current ->
            listOf(
                NotificationItem(
                    id = "notif_${System.currentTimeMillis()}",
                    title = "Order Placed Successfully",
                    message = "Order ${newOrder.orderNumber} sent to ${newOrder.sellerName}.",
                    roleTarget = UserRole.CONSUMER,
                    type = NotificationType.ORDER
                ),
                NotificationItem(
                    id = "notif_s_${System.currentTimeMillis()}",
                    title = "New Incoming Order!",
                    message = "Received order ${newOrder.orderNumber} for $${"%.2f".format(newOrder.total)}",
                    roleTarget = UserRole.SELLER,
                    type = NotificationType.ORDER
                )
            ) + current
        }

        return newOrder
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        _orders.update { current ->
            current.map { order ->
                if (order.id == orderId) {
                    order.copy(status = newStatus, updatedAt = System.currentTimeMillis())
                } else order
            }
        }
    }

    fun sellerConfirmOrder(orderId: String) {
        updateOrderStatus(orderId, OrderStatus.SELLER_CONFIRMED)
        _notifications.update { current ->
            listOf(
                NotificationItem(
                    id = "notif_${System.currentTimeMillis()}",
                    title = "Order Confirmed by Seller",
                    message = "The seller is preparing your innovative items.",
                    roleTarget = UserRole.CONSUMER,
                    type = NotificationType.ORDER
                )
            ) + current
        }
    }

    fun sellerRequestDeliveryPartner(orderId: String, partner: DeliveryPartner) {
        _orders.update { current ->
            current.map { order ->
                if (order.id == orderId) {
                    order.copy(
                        status = OrderStatus.DELIVERY_ASSIGNED,
                        deliveryPartnerId = partner.id,
                        deliveryPartnerName = partner.name,
                        deliveryPartnerPhone = partner.phone,
                        updatedAt = System.currentTimeMillis()
                    )
                } else order
            }
        }
        _notifications.update { current ->
            listOf(
                NotificationItem(
                    id = "notif_${System.currentTimeMillis()}",
                    title = "Delivery Partner Assigned 🛵",
                    message = "${partner.name} (${partner.vehicle.label}) has been assigned to order.",
                    roleTarget = UserRole.CONSUMER,
                    type = NotificationType.DELIVERY
                ),
                NotificationItem(
                    id = "notif_dp_${System.currentTimeMillis()}",
                    title = "New Delivery Assigned",
                    message = "Pickup assigned from seller. Tap to navigate.",
                    roleTarget = UserRole.DELIVERY_PARTNER,
                    type = NotificationType.DELIVERY
                )
            ) + current
        }
    }

    fun advanceDeliveryWorkflow(orderId: String) {
        _orders.update { current ->
            current.map { order ->
                if (order.id == orderId) {
                    val nextStatus = when (order.status) {
                        OrderStatus.ORDER_PLACED -> OrderStatus.SELLER_CONFIRMED
                        OrderStatus.SELLER_CONFIRMED -> OrderStatus.DELIVERY_REQUESTED
                        OrderStatus.DELIVERY_REQUESTED -> OrderStatus.DELIVERY_ASSIGNED
                        OrderStatus.DELIVERY_ASSIGNED -> OrderStatus.PICKED_UP
                        OrderStatus.PICKED_UP -> OrderStatus.ON_THE_WAY
                        OrderStatus.ON_THE_WAY -> OrderStatus.DELIVERED
                        OrderStatus.DELIVERED -> OrderStatus.COMPLETED
                        else -> order.status
                    }
                    order.copy(status = nextStatus, updatedAt = System.currentTimeMillis())
                } else order
            }
        }
    }

    fun addProduct(
        name: String,
        description: String,
        category: String,
        price: Double,
        stock: Int,
        deliveryAreaKm: Int,
        specifications: Map<String, String>
    ) {
        val newProduct = Product(
            id = "prod_${UUID.randomUUID().toString().take(6)}",
            sellerId = _currentUser.value?.id ?: "seller_custom",
            sellerName = _sellerSpaces.value.firstOrNull()?.name ?: "Innovator Studio",
            sellerRating = 5.0,
            name = name,
            description = description,
            category = category,
            price = price,
            stock = stock,
            imageUrl = "https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=600",
            specifications = specifications,
            deliveryAvailability = true,
            deliveryAreaKm = deliveryAreaKm,
            distanceKm = 1.5,
            isInnovation = true,
            isFeatured = true
        )
        _products.update { listOf(newProduct) + it }
    }

    fun deleteProduct(productId: String) {
        _products.update { current -> current.filterNot { it.id == productId } }
    }

    fun toggleProductActive(productId: String) {
        _products.update { current ->
            current.map {
                if (it.id == productId) it.copy(active = !it.active) else it
            }
        }
    }

    fun addInnovationPost(title: String, content: String, tags: List<String>) {
        val newPost = InnovationPost(
            id = "post_${UUID.randomUUID().toString().take(5)}",
            title = title,
            content = content,
            date = "Just now",
            likesCount = 1,
            tags = tags
        )
        _sellerSpaces.update { current ->
            current.mapIndexed { idx, space ->
                if (idx == 0) space.copy(innovations = listOf(newPost) + space.innovations) else space
            }
        }
    }

    fun toggleDeliveryPartnerAvailability(partnerId: String) {
        _deliveryPartners.update { current ->
            current.map {
                if (it.id == partnerId) it.copy(isAvailable = !it.isAvailable) else it
            }
        }
    }

    fun sendChatMessage(chatId: String, text: String, senderRole: UserRole) {
        val senderUser = _currentUser.value
        val newMessage = ChatMessage(
            id = "msg_${System.currentTimeMillis()}",
            senderId = senderUser?.id ?: "user_me",
            senderName = senderUser?.name ?: "You",
            senderRole = senderRole,
            text = text,
            timestamp = System.currentTimeMillis()
        )

        _chats.update { current ->
            current.map { chat ->
                if (chat.id == chatId) {
                    chat.copy(
                        lastMessage = text,
                        lastTimestamp = System.currentTimeMillis(),
                        messages = chat.messages + newMessage
                    )
                } else chat
            }
        }
    }

    fun getOrCreateChat(
        orderId: String?,
        otherPartyId: String,
        otherPartyName: String,
        otherPartyRole: UserRole
    ): String {
        val existing = _chats.value.find { it.otherPartyId == otherPartyId }
        if (existing != null) return existing.id

        val newId = "chat_${UUID.randomUUID().toString().take(6)}"
        val newChat = Chat(
            id = newId,
            orderId = orderId,
            otherPartyId = otherPartyId,
            otherPartyName = otherPartyName,
            otherPartyRole = otherPartyRole,
            lastMessage = "Started a conversation",
            lastTimestamp = System.currentTimeMillis(),
            messages = listOf(
                ChatMessage(
                    id = "msg_${System.currentTimeMillis()}",
                    senderId = "system",
                    senderName = "Ignis",
                    senderRole = UserRole.CONSUMER,
                    text = "This is a direct, secure conversation on Ignis. Official order details remain protected in your Orders tab.",
                    isSystem = true
                )
            )
        )
        _chats.update { listOf(newChat) + it }
        return newId
    }

    fun markNotificationRead(id: String) {
        _notifications.update { current ->
            current.map {
                if (it.id == id) it.copy(isRead = true) else it
            }
        }
    }

    companion object {
        @Volatile
        private var instance: IgnisRepository? = null

        fun getInstance(): IgnisRepository {
            return instance ?: synchronized(this) {
                instance ?: IgnisRepository().also { instance = it }
            }
        }
    }
}
