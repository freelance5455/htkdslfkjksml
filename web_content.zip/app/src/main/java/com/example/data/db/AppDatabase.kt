package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.CycleStatus
import com.example.data.model.DeliveryEntry
import com.example.data.model.GpsTrackPoint
import com.example.data.model.TrackingSession
import com.example.data.model.UserProfile

@Database(
    entities = [
        DeliveryEntry::class,
        CycleStatus::class,
        UserProfile::class,
        TrackingSession::class,
        GpsTrackPoint::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun deliveryDao(): DeliveryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "delivery_agent_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
