package com.example.data.model

import com.example.data.local.CycleLogEntity
import com.example.data.local.HormoneCheckEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CyclePhase(val title: String, val guidance: String) {
    MENSTRUAL("Menstrual", "Rest, stay warm, hydrate, and eat iron-rich foods."),
    FOLLICULAR("Follicular", "Energy rises—great time for movement and fresh focus."),
    OVULATION("Ovulation", "Peak vitality and social energy window."),
    LUTEAL("Luteal", "Prioritize 8–9h sleep, gentle walks, and magnesium-rich meals.")
}

enum class FlowIntensity(val label: String, val level: Int) {
    NONE("None", 0),
    SPOTTING("Spotting", 1),
    LIGHT("Light", 2),
    MEDIUM("Medium", 3),
    HEAVY("Heavy", 4);

    companion object {
        fun fromLabel(label: String): FlowIntensity =
            entries.firstOrNull { it.label.equals(label, ignoreCase = true) } ?: NONE
    }
}

enum class CycleSymptom(val label: String) {
    FATIGUE("Fatigue"),
    CRAMPS("Cramps"),
    HEADACHE("Headache"),
    BLOATING("Bloating"),
    MOOD_SWINGS("Mood Swings"),
    ACNE("Skin Breakouts"),
    CRAVINGS("Cravings"),
    CLEAR("Clear / No Symptoms")
}

enum class TrendMetric(val label: String, val maxValue: Float, val unit: String) {
    HORMONE_BALANCE("Hormone Balance", 5f, "/5"),
    ENERGY("Energy", 5f, "/5"),
    MOOD_STABILITY("Mood", 5f, "/5"),
    SLEEP_QUALITY("Sleep", 5f, "/5"),
    CRAMPS("Cramps", 5f, "/5")
}

/**
 * Unified domain model for daily hormone & cycle symptom tracking and trend visualization.
 */
data class DailyHormoneCycleLog(
    val id: String,
    val dateEpochDay: Long,
    val dateLabel: String,
    val energyScore: Int = 3,
    val moodBalanceScore: Int = 3,
    val skinClarityScore: Int = 3,
    val sleepQualityScore: Int = 3,
    val stressCalmScore: Int = 3,
    val flowIntensity: FlowIntensity = FlowIntensity.NONE,
    val crampsLevel: Int = 0,
    val symptoms: List<String> = emptyList(),
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    val overallBalanceScore: Float
        get() = (energyScore + moodBalanceScore + skinClarityScore + sleepQualityScore + stressCalmScore) / 5f
}

object HormoneCycleMapper {
    private val shortDate = SimpleDateFormat("MMM d", Locale.getDefault())

    fun fromEntities(
        hormoneChecks: List<HormoneCheckEntity>,
        cycleLogs: List<CycleLogEntity>
    ): List<DailyHormoneCycleLog> {
        val hormonePoints = hormoneChecks.map { check ->
            DailyHormoneCycleLog(
                id = "h_${check.id}",
                dateEpochDay = check.timestamp / 86_400_000L,
                dateLabel = shortDate.format(Date(check.timestamp)),
                energyScore = check.energyScore,
                moodBalanceScore = check.moodBalanceScore,
                skinClarityScore = check.skinClarityScore,
                sleepQualityScore = check.sleepQualityScore,
                stressCalmScore = check.stressCalmScore,
                symptoms = check.dailySymptoms.split(",").map { it.trim() }.filter { it.isNotEmpty() },
                notes = check.insightSummary,
                timestamp = check.timestamp
            )
        }

        val cyclePoints = cycleLogs.map { log ->
            val millis = log.dateEpochDay * 86_400_000L
            DailyHormoneCycleLog(
                id = "c_${log.id}",
                dateEpochDay = log.dateEpochDay,
                dateLabel = shortDate.format(Date(millis)),
                flowIntensity = FlowIntensity.fromLabel(log.flowLevel),
                crampsLevel = log.crampsLevel,
                symptoms = log.symptoms.split(",").map { it.trim() }.filter { it.isNotEmpty() },
                notes = log.notes,
                timestamp = millis
            )
        }

        return (hormonePoints + cyclePoints).sortedBy { it.timestamp }
    }

    fun calculateCyclePhase(daysSinceStart: Int, cycleLength: Int): CyclePhase = when {
        daysSinceStart <= 5 -> CyclePhase.MENSTRUAL
        daysSinceStart <= (cycleLength / 2 - 2) -> CyclePhase.FOLLICULAR
        daysSinceStart <= (cycleLength / 2 + 2) -> CyclePhase.OVULATION
        else -> CyclePhase.LUTEAL
    }
}
