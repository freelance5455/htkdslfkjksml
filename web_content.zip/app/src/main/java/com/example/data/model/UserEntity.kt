package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Stores local user credentials, security hashes, session timestamps, and login cooldown metadata.
 */
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: Int = 1,
    val username: String,
    val passwordHash: String,
    val passwordSalt: String,
    val recoveryCodeHash: String,
    val recoveryCodeSalt: String,
    // Milliseconds epoch when user last entered credentials manually (14-day persistent session)
    val lastManualLoginTimestamp: Long,
    // Consecutive failed login or recovery-code attempts
    val failedAttempts: Int = 0,
    // Milliseconds epoch until which login is disabled (survives app restarts)
    val cooldownUntilTimestamp: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
