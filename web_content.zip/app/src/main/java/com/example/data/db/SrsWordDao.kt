package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SrsWordDao {

    @Query("SELECT * FROM srs_words ORDER BY CASE WHEN nextReviewTimestamp <= :currentTime THEN 0 ELSE 1 END, nextReviewTimestamp ASC, timesForgotten DESC")
    fun getPrioritizedWords(currentTime: Long): Flow<List<SrsWordEntity>>

    @Query("SELECT * FROM srs_words ORDER BY learnedTimestamp DESC")
    fun getAllWords(): Flow<List<SrsWordEntity>>

    @Query("SELECT * FROM srs_words WHERE nextReviewTimestamp <= :currentTime ORDER BY nextReviewTimestamp ASC")
    fun getDueWords(currentTime: Long): Flow<List<SrsWordEntity>>

    @Query("SELECT * FROM srs_words WHERE id = :id LIMIT 1")
    suspend fun getWordById(id: String): SrsWordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(words: List<SrsWordEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWord(word: SrsWordEntity)

    @Update
    suspend fun updateWord(word: SrsWordEntity)

    @Query("DELETE FROM srs_words WHERE id = :id")
    suspend fun deleteWordById(id: String)

    @Query("DELETE FROM srs_words")
    suspend fun clearAll()
}
