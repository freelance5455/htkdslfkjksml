package com.example.data.repository

import com.example.data.local.CalculationHistoryDao
import com.example.data.local.CalculationHistoryEntity
import kotlinx.coroutines.flow.Flow

interface HistoryDataSource {
  val history: Flow<List<CalculationHistoryEntity>>

  suspend fun saveCalculation(
    expression: String,
    resultFormatted: String,
    resultRaw: String,
    angleMode: String,
    isScientific: Boolean,
  )

  suspend fun deleteById(id: Long)

  suspend fun clearAll()
}

class HistoryRepository(private val dao: CalculationHistoryDao) : HistoryDataSource {
  override val history: Flow<List<CalculationHistoryEntity>> = dao.observeHistory()

  override suspend fun saveCalculation(
    expression: String,
    resultFormatted: String,
    resultRaw: String,
    angleMode: String,
    isScientific: Boolean,
  ) {
    dao.insert(
      CalculationHistoryEntity(
        expression = expression,
        resultFormatted = resultFormatted,
        resultRaw = resultRaw,
        angleMode = angleMode,
        isScientific = isScientific,
      )
    )
  }

  override suspend fun deleteById(id: Long) = dao.deleteById(id)

  override suspend fun clearAll() = dao.clearAll()
}
