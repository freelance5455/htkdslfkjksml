package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Withdrawal(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val methodId: String = "",
    val methodTitle: String = "",
    val accountDetail: String = "",
    val coinsDeducted: Long = 0L,
    val cashAmount: String = "",
    val status: String = "PENDING",
    @ServerTimestamp val createdAt: Timestamp? = null
)
