package com.example.data.model

data class CycleSummary(
    val cycleNumber: Int, // 1, 2, 3
    val label: String, // "Cycle 1 (1 to 10)", "Cycle 2 (11 to 20)", "Cycle 3 (21 to 31)"
    val dateRangeText: String, // "1st - 10th", "11th - 20th", "21st - End"
    val totalDeliveries: Int,
    val totalEarnings: Double,
    val entryCount: Int,
    val status: String = "PENDING", // PENDING, INVOICED, PAID
    val isCurrent: Boolean = false
)

data class DashboardPayoutSummary(
    val todayDeliveries: Int,
    val todayRate: Double,
    val todayEarnings: Double,
    val monthKey: String,
    val monthDeliveries: Int,
    val monthTotalEarnings: Double,
    val cycle1Summary: CycleSummary,
    val cycle2Summary: CycleSummary,
    val cycle3Summary: CycleSummary,
    val currentCycleNumber: Int,
    val pendingPayoutTotal: Double,
    val settledPayoutTotal: Double
)
