package com.example.data

import android.content.Context
import com.example.R
import com.example.model.AppNotification
import com.example.model.ChatMessage
import com.example.model.Conversation
import com.example.model.JobApplication
import com.example.model.JobListing
import com.example.model.JobyConstants
import com.example.model.ModerationReport
import com.example.model.PaymentTransaction
import com.example.model.SideQuest
import com.example.model.SubscriptionPlan
import com.example.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class JobyRepository(private val db: FirebaseFirestore) {

  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private val auth get() = Firebase.auth

  private fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
  }

  private fun <T> Flow<T>.logAndRethrow(op: OperationType, path: String, expectedUid: String? = null): Flow<T> =
    catch { error ->
      val firestoreError = generateSequence(error) { it.cause }
        .filterIsInstance<FirebaseFirestoreException>()
        .firstOrNull()
      if (firestoreError == null && error is CancellationException) throw error
      val ex = firestoreError ?: (error as? Exception)
      if (ex != null && (expectedUid == null || auth.currentUser?.uid == expectedUid)) {
        handleFirestoreError(ex, op, path)
      }
      throw error
    }

  // --- User Profile ---
  fun observeUserProfile(userId: String): Flow<UserProfile?> {
    val path = "users/$userId"
    return db.collection("users").document(userId)
      .snapshots()
      .map { it.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
      .logAndRethrow(OperationType.GET, path, userId)
  }

  suspend fun getUserProfile(userId: String): UserProfile? {
    val docRef = db.collection("users").document(userId)
    return try {
      docRef.get().await().toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, docRef.path)
      throw e
    }
  }

  suspend fun upsertUserProfile(profile: UserProfile): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    return try {
      val existing = docRef.get().await()
      if (!existing.exists()) {
        val cleanProfile = profile.copy(
          userId = uid,
          accountStatus = "ACTIVE",
          companyVerified = false,
          subscriptionTier = "FREE"
        )
        docRef.set(cleanProfile.toCreateMap()).await()
      } else {
        val updates = buildMap<String, Any> {
          put("displayName", profile.displayName.trim())
          if (profile.phone.isNotBlank()) put("phone", profile.phone.trim())
          if (profile.state.isNotBlank()) put("state", profile.state.trim())
          if (profile.city.isNotBlank()) put("city", profile.city.trim())
          if (profile.pincode.isNotBlank()) put("pincode", profile.pincode.trim())
          put("role", profile.role)
          put("age", profile.age.coerceIn(14L, 100L))
          put("isAgeVerified", profile.isAgeVerified)
          put("skills", profile.skills.take(15))
          if (profile.education.isNotBlank()) put("education", profile.education.trim())
          if (profile.bio.isNotBlank()) put("bio", profile.bio.trim())
          if (profile.resumeLabel.isNotBlank()) put("resumeLabel", profile.resumeLabel.trim())
          put("preferredJobTypes", profile.preferredJobTypes.take(8))
          put("savedJobIds", profile.savedJobIds.take(50))
          if (profile.companyName.isNotBlank()) put("companyName", profile.companyName.trim())
          if (profile.gstOrRegNumber.isNotBlank()) put("gstOrRegNumber", profile.gstOrRegNumber.trim())
          put("preferredLanguage", profile.preferredLanguage)
          put("updatedAt", FieldValue.serverTimestamp())
        }
        docRef.update(updates).await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun toggleSavedJob(currentSavedIds: List<String>, jobId: String): Result<Unit> {
    val uid = requireUserId()
    val updated = if (jobId in currentSavedIds) {
      currentSavedIds - jobId
    } else {
      (currentSavedIds + jobId).distinct().take(50)
    }
    val docRef = db.collection("users").document(uid)
    return try {
      docRef.update(
        mapOf(
          "savedJobIds" to updated,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun updatePreferredLanguage(languageCode: String): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    return try {
      docRef.update(
        mapOf(
          "preferredLanguage" to languageCode,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  // --- Jobs ---
  fun observeApprovedJobs(uid: String): Flow<List<JobListing>> {
    return db.collection("jobs")
      .whereEqualTo("moderationStatus", "APPROVED")
      .snapshots()
      .map { snap ->
        snap.toObjects(JobListing::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "jobs", uid)
  }

  fun observeEmployerJobs(employerId: String): Flow<List<JobListing>> {
    return db.collection("jobs")
      .whereEqualTo("employerId", employerId)
      .snapshots()
      .map { snap ->
        snap.toObjects(JobListing::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "jobs", employerId)
  }

  fun observeAllJobsAdmin(uid: String): Flow<List<JobListing>> {
    return db.collection("jobs")
      .snapshots()
      .map { snap ->
        snap.toObjects(JobListing::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "jobs", uid)
  }

  suspend fun createJob(job: JobListing, isAdminUser: Boolean = false): Result<String> {
    val uid = requireUserId()
    require(job.applicationFee == 0L) { "Zero-Fee Mandate: Application fees are strictly prohibited." }
    val docRef = db.collection("jobs").document()
    val status = if (isAdminUser) "APPROVED" else "PENDING"
    val payload = job.copy(employerId = uid, applicationFee = 0L).toCreateMap(status)
    return try {
      docRef.set(payload).await()
      Result.success(docRef.id)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun toggleJobActive(jobId: String, active: Boolean): Result<Unit> {
    requireUserId()
    val docRef = db.collection("jobs").document(jobId)
    return try {
      docRef.update(
        mapOf(
          "isActive" to active,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun moderateJob(jobId: String, status: String): Result<Unit> {
    requireUserId()
    val docRef = db.collection("jobs").document(jobId)
    return try {
      docRef.update(
        mapOf(
          "moderationStatus" to status,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  // --- Side Quests ---
  fun observeApprovedSideQuests(uid: String): Flow<List<SideQuest>> {
    return db.collection("side_quests")
      .whereEqualTo("moderationStatus", "APPROVED")
      .snapshots()
      .map { snap ->
        snap.toObjects(SideQuest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "side_quests", uid)
  }

  fun observeEmployerSideQuests(employerId: String): Flow<List<SideQuest>> {
    return db.collection("side_quests")
      .whereEqualTo("employerId", employerId)
      .snapshots()
      .map { snap ->
        snap.toObjects(SideQuest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "side_quests", employerId)
  }

  fun observeAllSideQuestsAdmin(uid: String): Flow<List<SideQuest>> {
    return db.collection("side_quests")
      .snapshots()
      .map { snap ->
        snap.toObjects(SideQuest::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "side_quests", uid)
  }

  suspend fun createSideQuest(quest: SideQuest, isAdminUser: Boolean = false): Result<String> {
    val uid = requireUserId()
    val docRef = db.collection("side_quests").document()
    val status = if (isAdminUser) "APPROVED" else "PENDING"
    val payload = quest.copy(employerId = uid, applicationFee = 0L).toCreateMap(status)
    return try {
      docRef.set(payload).await()
      Result.success(docRef.id)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun claimSideQuest(quest: SideQuest, seeker: UserProfile): Result<Unit> {
    val uid = requireUserId()
    if (seeker.age < quest.minAge || (quest.isHazardousOrRestricted && seeker.age < 18L)) {
      return Result.failure(IllegalArgumentException("Age restriction: You must be ${quest.minAge}+ for this Side Quest."))
    }
    val docRef = db.collection("side_quests").document(quest.id)
    return try {
      docRef.update(
        mapOf(
          "questStatus" to "ASSIGNED",
          "assignedSeekerId" to uid,
          "assignedSeekerName" to seeker.displayName,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      createNotification(
        recipientId = quest.employerId,
        type = "SIDE_QUEST",
        title = "Side Quest Accepted",
        body = "${seeker.displayName} accepted \"${quest.title}\"."
      )
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun submitSideQuestProof(quest: SideQuest, proofNote: String): Result<Unit> {
    requireUserId()
    val docRef = db.collection("side_quests").document(quest.id)
    return try {
      docRef.update(
        mapOf(
          "questStatus" to "COMPLETION_SUBMITTED",
          "proofNote" to proofNote.trim(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      createNotification(
        recipientId = quest.employerId,
        type = "SIDE_QUEST",
        title = "Proof Submitted",
        body = "${quest.assignedSeekerName} submitted completion proof for \"${quest.title}\"."
      )
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun releaseSideQuestPayout(quest: SideQuest): Result<String> {
    val uid = requireUserId()
    val payRef = "UPI-${UUID.randomUUID().toString().take(8).uppercase()}"
    val docRef = db.collection("side_quests").document(quest.id)
    return try {
      docRef.update(
        mapOf(
          "questStatus" to "PAID",
          "paymentReference" to payRef,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()

      val txnRef = db.collection("transactions").document()
      val invoice = "INV-SQ-${System.currentTimeMillis().toString().takeLast(6)}"
      txnRef.set(
        mapOf(
          "userId" to uid,
          "userName" to quest.posterName,
          "type" to "SIDE_QUEST_PAYOUT",
          "referenceId" to quest.id,
          "title" to "Side Quest Payout: ${quest.title}",
          "amountInr" to quest.payoutInr,
          "paymentMethod" to "UPI_SIMULATED",
          "status" to "COMPLETED",
          "invoiceNumber" to invoice,
          "createdAt" to FieldValue.serverTimestamp()
        )
      ).await()

      if (quest.assignedSeekerId.isNotBlank()) {
        createNotification(
          recipientId = quest.assignedSeekerId,
          type = "PAYMENT",
          title = "₹${quest.payoutInr} Side Quest Paid!",
          body = "Payment ($payRef) released for \"${quest.title}\"."
        )
      }
      Result.success(payRef)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun moderateSideQuest(questId: String, status: String): Result<Unit> {
    requireUserId()
    val docRef = db.collection("side_quests").document(questId)
    return try {
      docRef.update(
        mapOf(
          "moderationStatus" to status,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  // --- Applications ---
  fun observeSeekerApplications(seekerId: String): Flow<List<JobApplication>> {
    return db.collection("applications")
      .whereEqualTo("seekerId", seekerId)
      .snapshots()
      .map { snap ->
        snap.toObjects(JobApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "applications", seekerId)
  }

  fun observeEmployerApplications(employerId: String): Flow<List<JobApplication>> {
    return db.collection("applications")
      .whereEqualTo("employerId", employerId)
      .snapshots()
      .map { snap ->
        snap.toObjects(JobApplication::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "applications", employerId)
  }

  suspend fun applyToJob(
    job: JobListing,
    seeker: UserProfile,
    coverNote: String
  ): Result<String> {
    val uid = requireUserId()
    if (seeker.accountStatus == "SUSPENDED") {
      return Result.failure(IllegalStateException("Account is suspended by moderation."))
    }
    if (seeker.age < job.minAge || (job.isHazardousOrRestricted && seeker.age < 18L)) {
      return Result.failure(
        IllegalArgumentException("Indian Child-Labour Compliance: Minimum age for this role is ${job.minAge} years.")
      )
    }
    val docRef = db.collection("applications").document()
    val app = JobApplication(
      seekerId = uid,
      seekerName = seeker.displayName,
      seekerAge = seeker.age,
      seekerCity = seeker.city,
      seekerSkills = seeker.skills,
      seekerBio = seeker.bio,
      resumeLabel = seeker.resumeLabel,
      jobId = job.id,
      jobTitle = job.title,
      companyName = job.companyName,
      employerId = job.employerId,
      coverNote = coverNote.trim().ifBlank { "Interested in ${job.title} at ${job.companyName}." }
    )
    return try {
      docRef.set(app.toCreateMap()).await()
      db.collection("jobs").document(job.id).update(
        mapOf(
          "applicantCount" to FieldValue.increment(1L),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      createNotification(
        recipientId = job.employerId,
        type = "APPLICATION",
        title = "New Applicant: ${seeker.displayName}",
        body = "Applied for ${job.title} (${seeker.city})."
      )
      Result.success(docRef.id)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun updateApplicationStatus(
    application: JobApplication,
    newStatus: String,
    interviewNote: String = ""
  ): Result<Unit> {
    requireUserId()
    val docRef = db.collection("applications").document(application.id)
    return try {
      val updates = buildMap<String, Any> {
        put("status", newStatus)
        if (interviewNote.isNotBlank()) put("interviewNote", interviewNote.trim())
        put("updatedAt", FieldValue.serverTimestamp())
      }
      docRef.update(updates).await()
      val targetRecipient = if (newStatus == "WITHDRAWN") application.employerId else application.seekerId
      createNotification(
        recipientId = targetRecipient,
        type = "APPLICATION",
        title = "Application $newStatus",
        body = "${application.jobTitle} at ${application.companyName} is now $newStatus."
      )
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  // --- Conversations & Messages ---
  fun observeConversations(userId: String): Flow<List<Conversation>> {
    return db.collection("conversations")
      .whereArrayContains("participantIds", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(Conversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.lastMessageAt ?: it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "conversations", userId)
  }

  fun observeMessages(conversationId: String, currentUserId: String): Flow<List<ChatMessage>> {
    val path = "conversations/$conversationId/messages"
    return db.collection("conversations").document(conversationId)
      .collection("messages")
      .whereArrayContains("participantIds", currentUserId)
      .snapshots()
      .map { snap ->
        snap.toObjects(ChatMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedBy { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, path, currentUserId)
  }

  suspend fun startOrGetConversation(
    seekerId: String,
    employerId: String,
    seekerName: String,
    employerName: String,
    jobTitle: String
  ): Result<String> {
    val uid = requireUserId()
    val convId = "conv_${seekerId.take(24)}_${employerId.take(24)}"
    val docRef = db.collection("conversations").document(convId)
    return try {
      val existing = docRef.get().await()
      if (!existing.exists()) {
        docRef.set(
          mapOf(
            "participantIds" to listOf(seekerId, employerId),
            "seekerId" to seekerId,
            "employerId" to employerId,
            "seekerName" to seekerName,
            "employerName" to employerName,
            "jobTitle" to jobTitle,
            "lastMessage" to "Conversation started regarding $jobTitle",
            "lastMessageAt" to FieldValue.serverTimestamp(),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
          )
        ).await()
      }
      Result.success(convId)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "conversations/$convId (uid=$uid)")
      Result.failure(e)
    }
  }

  suspend fun sendMessage(
    conversation: Conversation,
    senderName: String,
    text: String,
    attachmentLabel: String = ""
  ): Result<Unit> {
    val uid = requireUserId()
    val msgRef = db.collection("conversations").document(conversation.id)
      .collection("messages").document()
    return try {
      val msgPayload = buildMap<String, Any> {
        put("participantIds", conversation.participantIds)
        put("senderId", uid)
        put("senderName", senderName)
        put("text", text.trim())
        if (attachmentLabel.isNotBlank()) put("attachmentLabel", attachmentLabel.trim())
        put("isRead", false)
        put("createdAt", FieldValue.serverTimestamp())
      }
      msgRef.set(msgPayload).await()
      db.collection("conversations").document(conversation.id).update(
        mapOf(
          "lastMessage" to text.trim().take(200),
          "lastMessageAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      val recipientId = conversation.participantIds.firstOrNull { it != uid } ?: ""
      if (recipientId.isNotBlank()) {
        createNotification(
          recipientId = recipientId,
          type = "SYSTEM",
          title = "New Message from $senderName",
          body = text.trim().take(140)
        )
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, msgRef.path)
      Result.failure(e)
    }
  }

  // --- Notifications ---
  fun observeNotifications(userId: String): Flow<List<AppNotification>> {
    return db.collection("notifications")
      .whereEqualTo("recipientId", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(AppNotification::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "notifications", userId)
  }

  suspend fun createNotification(
    recipientId: String,
    type: String,
    title: String,
    body: String
  ) {
    if (recipientId.isBlank()) return
    val docRef = db.collection("notifications").document()
    try {
      docRef.set(
        mapOf(
          "recipientId" to recipientId,
          "type" to type,
          "title" to title.take(120),
          "body" to body.take(400),
          "isRead" to false,
          "createdAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
    }
  }

  suspend fun markNotificationRead(notificationId: String): Result<Unit> {
    requireUserId()
    val docRef = db.collection("notifications").document(notificationId)
    return try {
      docRef.update("isRead", true).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  // --- Subscriptions & Transactions ---
  fun observeSubscriptionPlans(uid: String): Flow<List<SubscriptionPlan>> {
    return db.collection("subscription_plans")
      .snapshots()
      .map { snap ->
        snap.toObjects(SubscriptionPlan::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedBy { it.priceInr }
      }
      .logAndRethrow(OperationType.LIST, "subscription_plans", uid)
  }

  fun observeUserTransactions(userId: String): Flow<List<PaymentTransaction>> {
    return db.collection("transactions")
      .whereEqualTo("userId", userId)
      .snapshots()
      .map { snap ->
        snap.toObjects(PaymentTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "transactions", userId)
  }

  fun observeAllTransactionsAdmin(uid: String): Flow<List<PaymentTransaction>> {
    return db.collection("transactions")
      .snapshots()
      .map { snap ->
        snap.toObjects(PaymentTransaction::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "transactions", uid)
  }

  suspend fun upgradeSubscriptionPlan(
    user: UserProfile,
    plan: SubscriptionPlan,
    paymentMethod: String
  ): Result<String> {
    val uid = requireUserId()
    val userRef = db.collection("users").document(uid)
    val txnRef = db.collection("transactions").document()
    val invoice = "INV-JOBY-${System.currentTimeMillis().toString().takeLast(6)}"
    return try {
      userRef.update(
        mapOf(
          "subscriptionTier" to plan.code,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      txnRef.set(
        mapOf(
          "userId" to uid,
          "userName" to user.displayName,
          "type" to "SUBSCRIPTION",
          "referenceId" to plan.code,
          "title" to "${plan.name} (${plan.billingCycle})",
          "amountInr" to plan.priceInr,
          "paymentMethod" to paymentMethod,
          "status" to "COMPLETED",
          "invoiceNumber" to invoice,
          "createdAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(invoice)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, txnRef.path)
      Result.failure(e)
    }
  }

  suspend fun saveSubscriptionPlanAdmin(plan: SubscriptionPlan): Result<Unit> {
    requireUserId()
    val docRef = db.collection("subscription_plans").document(plan.code)
    return try {
      docRef.set(
        mapOf(
          "code" to plan.code,
          "name" to plan.name,
          "priceInr" to plan.priceInr,
          "billingCycle" to plan.billingCycle,
          "maxActiveJobs" to plan.maxActiveJobs,
          "featuredBoosts" to plan.featuredBoosts,
          "verifiedBadge" to plan.verifiedBadge,
          "isActive" to plan.isActive,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  // --- Trust & Safety Reports + Admin Controls ---
  fun observeAllUsersAdmin(uid: String): Flow<List<UserProfile>> {
    return db.collection("users")
      .snapshots()
      .map { snap ->
        snap.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "users", uid)
  }

  fun observeAllReportsAdmin(uid: String): Flow<List<ModerationReport>> {
    return db.collection("reports")
      .snapshots()
      .map { snap ->
        snap.toObjects(ModerationReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
          .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
      }
      .logAndRethrow(OperationType.LIST, "reports", uid)
  }

  suspend fun submitReport(
    targetType: String,
    targetId: String,
    targetTitle: String,
    reason: String,
    details: String
  ): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("reports").document()
    return try {
      docRef.set(
        mapOf(
          "reporterId" to uid,
          "targetType" to targetType,
          "targetId" to targetId,
          "targetTitle" to targetTitle.take(140),
          "reason" to reason.take(100),
          "details" to details.trim().take(800),
          "status" to "OPEN",
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun resolveReportAdmin(reportId: String, status: String, adminNote: String): Result<Unit> {
    requireUserId()
    val docRef = db.collection("reports").document(reportId)
    return try {
      docRef.update(
        mapOf(
          "status" to status,
          "adminNote" to adminNote.trim(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun setCompanyVerifiedAdmin(userId: String, verified: Boolean): Result<Unit> {
    requireUserId()
    val docRef = db.collection("users").document(userId)
    return try {
      docRef.update(
        mapOf(
          "companyVerified" to verified,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun setUserAccountStatusAdmin(userId: String, status: String): Result<Unit> {
    requireUserId()
    val docRef = db.collection("users").document(userId)
    return try {
      docRef.update(
        mapOf(
          "accountStatus" to status,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  // --- Admin Sample Marketplace Seeder (Pan-India Realistic Listings & Plans) ---
  suspend fun seedIndiaMarketplaceDataAdmin(): Result<Unit> {
    val uid = requireUserId()
    return try {
      val plans = listOf(
        SubscriptionPlan(
          code = "FREE",
          name = "JOBY Starter",
          priceInr = 0L,
          billingCycle = "MONTHLY",
          maxActiveJobs = 3L,
          featuredBoosts = 0L,
          verifiedBadge = false,
          isActive = true
        ),
        SubscriptionPlan(
          code = "JOBY_PLUS",
          name = "JOBY Plus",
          priceInr = 999L,
          billingCycle = "MONTHLY",
          maxActiveJobs = 25L,
          featuredBoosts = 5L,
          verifiedBadge = true,
          isActive = true
        ),
        SubscriptionPlan(
          code = "ENTERPRISE",
          name = "JOBY Enterprise",
          priceInr = 4999L,
          billingCycle = "MONTHLY",
          maxActiveJobs = 200L,
          featuredBoosts = 30L,
          verifiedBadge = true,
          isActive = true
        )
      )
      plans.forEach { saveSubscriptionPlanAdmin(it) }

      val sampleJobs = listOf(
        JobListing(
          employerId = uid,
          companyName = "ZetaPay Bengaluru",
          companyVerified = true,
          title = "Android Kotlin Engineer",
          category = "Technology",
          jobType = "FULL_TIME",
          state = "Karnataka",
          city = "Bengaluru",
          pincode = "560034",
          isRemote = false,
          salaryMinInr = 65000L,
          salaryMaxInr = 110000L,
          salaryPeriod = "MONTH",
          experienceLevel = "1_3_YRS",
          description = "Build UPI payment flows and merchant onboarding screens in Jetpack Compose for pan-India kirana partners.",
          requirements = "Kotlin, Jetpack Compose, Coroutines, REST/Firebase.",
          minAge = 18L,
          isHazardousOrRestricted = false
        ),
        JobListing(
          employerId = uid,
          companyName = "SwiftKart Logistics",
          companyVerified = true,
          title = "Last-Mile Delivery Partner",
          category = "Delivery & Logistics",
          jobType = "GIG",
          state = "Maharashtra",
          city = "Mumbai",
          pincode = "400053",
          isRemote = false,
          salaryMinInr = 22000L,
          salaryMaxInr = 34000L,
          salaryPeriod = "MONTH",
          experienceLevel = "FRESHER",
          description = "Flexible neighborhood parcel deliveries in Andheri & Bandra with weekly bank payouts and fuel bonus.",
          requirements = "Valid two-wheeler license, Android smartphone, 18+ age verification.",
          minAge = 18L,
          isHazardousOrRestricted = true
        ),
        JobListing(
          employerId = uid,
          companyName = "ShikshaBridge Academy",
          companyVerified = true,
          title = "Bilingual Maths & Science Tutor",
          category = "Teaching & Tutoring",
          jobType = "PART_TIME",
          state = "Tamil Nadu",
          city = "Chennai",
          pincode = "600017",
          isRemote = true,
          salaryMinInr = 15000L,
          salaryMaxInr = 28000L,
          salaryPeriod = "MONTH",
          experienceLevel = "FRESHER",
          description = "Teach Class 8–10 CBSE & State Board students online in English and Tamil during evening batches.",
          requirements = "Strong fundamentals in Maths/Science and clear communication.",
          minAge = 16L,
          isHazardousOrRestricted = false
        ),
        JobListing(
          employerId = uid,
          companyName = "Jaipur Craft Collective",
          companyVerified = true,
          title = "Social Media & Catalog Intern",
          category = "Design & Media",
          jobType = "INTERNSHIP",
          state = "Rajasthan",
          city = "Jaipur",
          pincode = "302001",
          isRemote = true,
          salaryMinInr = 10000L,
          salaryMaxInr = 14000L,
          salaryPeriod = "MONTH",
          experienceLevel = "FRESHER",
          description = "Curate product reels and Hindi/English catalog captions for women-led artisan cooperatives.",
          requirements = "Canva or mobile video editing, creative storytelling.",
          minAge = 16L,
          isHazardousOrRestricted = false
        ),
        JobListing(
          employerId = uid,
          companyName = "MetroBuild Infra Hub",
          companyVerified = true,
          title = "Electrical Site Technician",
          category = "Trades & Field Work",
          jobType = "DAILY_WAGE",
          state = "Delhi NCR",
          city = "Noida",
          pincode = "201301",
          isRemote = false,
          salaryMinInr = 950L,
          salaryMaxInr = 1350L,
          salaryPeriod = "DAY",
          experienceLevel = "1_3_YRS",
          description = "Commercial panel wiring, safety earthing inspection, and daily shift maintenance.",
          requirements = "ITI Electrician certificate, safety gear compliance, strictly 18+.",
          minAge = 18L,
          isHazardousOrRestricted = true
        )
      )
      sampleJobs.forEachIndexed { idx, job ->
        db.collection("jobs").document("seed_job_${idx + 1}").set(job.toCreateMap("APPROVED")).await()
      }

      val sampleQuests = listOf(
        SideQuest(
          employerId = uid,
          posterName = "KiranaPulse Research",
          title = "Verify 6 Medical Store Timings in Koramangala",
          category = "Field Audit",
          description = "Walk to 6 listed pharmacies in Koramangala 4th Block, confirm Sunday open hours, and log GST board presence.",
          deliverableSpec = "Checklist summary with verified store names & timings",
          payoutInr = 450L,
          estimatedMinutes = 45L,
          city = "Bengaluru",
          state = "Karnataka",
          isRemote = false,
          minAge = 18L,
          isHazardousOrRestricted = false
        ),
        SideQuest(
          employerId = uid,
          posterName = "BhashaAI Labs",
          title = "Translate 30 Retail Product Labels to Hindi",
          category = "Translation",
          description = "Review 30 FMCG snack labels and write natural, accurate Hindi & Hinglish descriptions from home.",
          deliverableSpec = "Completed translation sheet / note submission",
          payoutInr = 600L,
          estimatedMinutes = 60L,
          city = "Remote",
          state = "All India",
          isRemote = true,
          minAge = 16L,
          isHazardousOrRestricted = false
        ),
        SideQuest(
          employerId = uid,
          posterName = "FestiveDukaan Hyderabad",
          title = "QA Test 10 Checkout Flows in Telugu/English",
          category = "App Testing",
          description = "Test UPI QR & PIN code address validation on our staging storefront and report any broken screens.",
          deliverableSpec = "Bug & usability summary note",
          payoutInr = 500L,
          estimatedMinutes = 40L,
          city = "Hyderabad",
          state = "Telangana",
          isRemote = true,
          minAge = 16L,
          isHazardousOrRestricted = false
        )
      )
      sampleQuests.forEachIndexed { idx, quest ->
        db.collection("side_quests").document("seed_quest_${idx + 1}").set(quest.toCreateMap("APPROVED")).await()
      }

      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "seed")
      Result.failure(e)
    }
  }
}
