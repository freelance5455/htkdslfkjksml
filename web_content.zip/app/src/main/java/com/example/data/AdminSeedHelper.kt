package com.example.data

import com.example.model.*
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.tasks.await
import java.util.Date

object AdminSeedHelper {
    suspend fun seedVerifiedMarketplaceCatalog(
        db: FirebaseFirestore,
        adminUid: String,
        adminEmail: String
    ): Result<Unit> {
        return try {
            val batch = db.batch()
            val subExp = Timestamp(Date(System.currentTimeMillis() + 28L * 24L * 60L * 60L * 1000L))

            val providers = listOf(
                Triple("prov_simba_tz", "Simba Shield Security Ltd", ServiceCategory.SECURITY_GUARDS) to mapOf(
                    "ownerId" to adminUid,
                    "companyName" to "Simba Shield Security Ltd",
                    "description" to "Kampuni iliyothibitishwa ya walinzi wa kitaalamu, doria za usiku, na ulinzi wa makazi na ofisi kote Tanzania.",
                    "categories" to listOf(ServiceCategory.SECURITY_GUARDS.name, ServiceCategory.SECURITY_CONSULTATION.name),
                    "locations" to listOf("Dar es Salaam", "Arusha", "Dodoma"),
                    "startingPriceTzs" to 350000L,
                    "businessRegNumber" to "BRELA-104882",
                    "securityLicenseNumber" to "PSRA-TZ-0041",
                    "contactPhone" to "0788016987",
                    "galleryBase64" to emptyList<String>(),
                    "verificationStatus" to VerificationStatus.VERIFIED.name,
                    "verifiedBadge" to true,
                    "featured" to true,
                    "revenueModel" to RevenueModel.COMMISSION.name,
                    "subscriptionStatus" to SubscriptionStatus.INACTIVE.name,
                    "ratingAvg" to 4.9,
                    "ratingCount" to 34L,
                    "completedOrdersCount" to 42L,
                    "totalEarningsTzs" to 18400000L,
                    "commissionOwedTzs" to 120000L,
                    "commissionCollectedTzs" to 800000L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                Triple("prov_kibo_cctv", "Kilimanjaro CCTV & Tech", ServiceCategory.CCTV_INSTALLATION) to mapOf(
                    "ownerId" to adminUid,
                    "companyName" to "Kilimanjaro CCTV & Tech",
                    "description" to "Wataalamu wa kamera za CCTV zenye HD, mifumo ya udhibiti wa milango (Access Control), na ufuatiliaji wa magari kwa GPS.",
                    "categories" to listOf(
                        ServiceCategory.CCTV_INSTALLATION.name,
                        ServiceCategory.ACCESS_CONTROL.name,
                        ServiceCategory.GPS_TRACKING.name,
                        ServiceCategory.EQUIPMENT_SUPPLY.name
                    ),
                    "locations" to listOf("Dar es Salaam", "Arusha", "Mwanza", "Kilimanjaro"),
                    "startingPriceTzs" to 480000L,
                    "businessRegNumber" to "BRELA-209415",
                    "securityLicenseNumber" to "PSRA-TZ-0118",
                    "contactPhone" to "0784552210",
                    "galleryBase64" to emptyList<String>(),
                    "verificationStatus" to VerificationStatus.VERIFIED.name,
                    "verifiedBadge" to true,
                    "featured" to true,
                    "revenueModel" to RevenueModel.MONTHLY_SUBSCRIPTION.name,
                    "subscriptionStatus" to SubscriptionStatus.ACTIVE.name,
                    "subscriptionExpiresAt" to subExp,
                    "ratingAvg" to 4.8,
                    "ratingCount" to 27L,
                    "completedOrdersCount" to 31L,
                    "totalEarningsTzs" to 24500000L,
                    "commissionOwedTzs" to 0L,
                    "commissionCollectedTzs" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                Triple("prov_zanzibar_fence", "Zanzibar Perimeter & Fire", ServiceCategory.ELECTRIC_FENCE) to mapOf(
                    "ownerId" to adminUid,
                    "companyName" to "Zanzibar Perimeter & Fire",
                    "description" to "Ufungaji wa uzio wa umeme (Electric Fence), mifumo ya kugundua moto, kengele za hatari, na matengenezo ya haraka.",
                    "categories" to listOf(
                        ServiceCategory.ELECTRIC_FENCE.name,
                        ServiceCategory.ALARM_SYSTEMS.name,
                        ServiceCategory.FIRE_DETECTION.name,
                        ServiceCategory.SECURITY_MAINTENANCE.name
                    ),
                    "locations" to listOf("Zanzibar", "Dar es Salaam", "Tanga", "Morogoro"),
                    "startingPriceTzs" to 650000L,
                    "businessRegNumber" to "ZBPRA-33890",
                    "securityLicenseNumber" to "PSRA-TZ-0209",
                    "contactPhone" to "0787334499",
                    "galleryBase64" to emptyList<String>(),
                    "verificationStatus" to VerificationStatus.VERIFIED.name,
                    "verifiedBadge" to true,
                    "featured" to true,
                    "revenueModel" to RevenueModel.COMMISSION.name,
                    "subscriptionStatus" to SubscriptionStatus.INACTIVE.name,
                    "ratingAvg" to 4.7,
                    "ratingCount" to 19L,
                    "completedOrdersCount" to 22L,
                    "totalEarningsTzs" to 16900000L,
                    "commissionOwedTzs" to 45000L,
                    "commissionCollectedTzs" to 800000L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            providers.forEach { (meta, data) ->
                batch.set(db.collection("providers").document(meta.first), data)
            }

            val services = listOf(
                "srv_seed_1" to mapOf(
                    "providerId" to "prov_simba_tz",
                    "ownerId" to adminUid,
                    "companyName" to "Simba Shield Security Ltd",
                    "providerVerified" to true,
                    "category" to ServiceCategory.SECURITY_GUARDS.name,
                    "title" to "Walinzi wa Masaa 24 (24/7 Guards)",
                    "description" to "Walinzi wawili wenye mafunzo ya kipolisi, redio za mawasiliano, na usimamizi wa doria.",
                    "priceTzs" to 350000L,
                    "priceUnit" to "kwa mwezi",
                    "location" to "Dar es Salaam",
                    "offerBadge" to "Popular",
                    "discountPercent" to 0L,
                    "active" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                "srv_seed_2" to mapOf(
                    "providerId" to "prov_kibo_cctv",
                    "ownerId" to adminUid,
                    "companyName" to "Kilimanjaro CCTV & Tech",
                    "providerVerified" to true,
                    "category" to ServiceCategory.CCTV_INSTALLATION.name,
                    "title" to "4-Channel Hikvision HD CCTV Kit",
                    "description" to "Kamera 4 za nje/ndani zenye night vision, 1TB HDD, na uwezo wa kuangalia kwenye simu.",
                    "priceTzs" to 680000L,
                    "priceUnit" to "ufungaji kamili",
                    "location" to "Dar es Salaam",
                    "offerBadge" to "15% OFF",
                    "discountPercent" to 15L,
                    "active" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                "srv_seed_3" to mapOf(
                    "providerId" to "prov_zanzibar_fence",
                    "ownerId" to adminUid,
                    "companyName" to "Zanzibar Perimeter & Fire",
                    "providerVerified" to true,
                    "category" to ServiceCategory.ELECTRIC_FENCE.name,
                    "title" to "Uzio wa Umeme (Nemtek Energizer)",
                    "description" to "Ufungaji wa nyaya 8 za uzio wa umeme na king'ora cha tahadhari kwa nyumba au ghala.",
                    "priceTzs" to 950000L,
                    "priceUnit" to "kwa mita 50",
                    "location" to "Zanzibar",
                    "offerBadge" to "Ofa Mpya",
                    "discountPercent" to 10L,
                    "active" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                "srv_seed_4" to mapOf(
                    "providerId" to "prov_kibo_cctv",
                    "ownerId" to adminUid,
                    "companyName" to "Kilimanjaro CCTV & Tech",
                    "providerVerified" to true,
                    "category" to ServiceCategory.GPS_TRACKING.name,
                    "title" to "GPS Vehicle Tracker + Engine Cut-off",
                    "description" to "Fuatilia gari lako live kwenye simu, tahadhari ya mwendo kasi na kuzima injini kwa SMS.",
                    "priceTzs" to 240000L,
                    "priceUnit" to "kwa gari",
                    "location" to "Arusha",
                    "offerBadge" to "10% OFF",
                    "discountPercent" to 10L,
                    "active" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                "srv_seed_5" to mapOf(
                    "providerId" to "prov_zanzibar_fence",
                    "ownerId" to adminUid,
                    "companyName" to "Zanzibar Perimeter & Fire",
                    "providerVerified" to true,
                    "category" to ServiceCategory.FIRE_DETECTION.name,
                    "title" to "Mfumo wa Kugundua Moto na Moshi",
                    "description" to "Smoke detectors, fire alarm panel na vifaa vya kuzimia moto kwa ofisi na hoteli.",
                    "priceTzs" to 720000L,
                    "priceUnit" to "ufungaji",
                    "location" to "Mwanza",
                    "active" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                "srv_seed_6" to mapOf(
                    "providerId" to "prov_simba_tz",
                    "ownerId" to adminUid,
                    "companyName" to "Simba Shield Security Ltd",
                    "providerVerified" to true,
                    "category" to ServiceCategory.SECURITY_CONSULTATION.name,
                    "title" to "Ukaguzi wa Usalama wa Kiwanda/Ofisi",
                    "description" to "Tathmini ya kitaalamu ya hatari za kiulinzi, mpango wa dharura na ushauri wa mifumo.",
                    "priceTzs" to 300000L,
                    "priceUnit" to "kwa ukaguzi",
                    "location" to "Dodoma",
                    "active" to true,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            services.forEach { (id, data) ->
                batch.set(db.collection("services").document(id), data)
            }

            batch.set(
                db.collection("audit_logs").document("log_seed_catalog"),
                mapOf(
                    "actorId" to adminUid,
                    "actorEmail" to adminEmail,
                    "action" to "CATALOG_BOOTSTRAPPED",
                    "targetType" to "SYSTEM",
                    "targetId" to "starter_catalog",
                    "summary" to "Admin initialized verified Tanzania security providers and service catalog",
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "providers/services")
            Result.failure(e)
        }
    }
}
