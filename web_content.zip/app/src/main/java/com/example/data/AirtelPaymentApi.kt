package com.example.data

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

data class AirtelInitiateRequest(
    val paymentId: String,
    val payerPhone: String,
    val amountTzs: Long,
    val orderId: String?,
    val paymentType: String
)

data class AirtelInitiateResponse(
    val mode: String? = null,
    val status: String? = null,
    val message: String? = null
)

interface AirtelPaymentApi {
    @POST("api/payments/airtel/initiate")
    suspend fun initiateCollection(
        @Header("Authorization") bearerToken: String,
        @Body request: AirtelInitiateRequest
    ): Response<AirtelInitiateResponse>
}

object AirtelGatewayConfig {
    val backendBaseUrl: String
        get() = BuildConfig.PAYMENT_BACKEND_URL.trim()

    val isProductionBackendConfigured: Boolean
        get() = backendBaseUrl.startsWith("https://") || backendBaseUrl.startsWith("http://")

    fun createApiOrNull(): AirtelPaymentApi? {
        val url = backendBaseUrl
        if (!isProductionBackendConfigured) return null
        val normalized = if (url.endsWith("/")) url else "$url/"
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .addInterceptor(logging)
            .build()
        val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
        return Retrofit.Builder()
            .baseUrl(normalized)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(AirtelPaymentApi::class.java)
    }
}
