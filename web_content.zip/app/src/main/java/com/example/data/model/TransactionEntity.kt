package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    WITHDRAWAL,
    BILL_PAYMENT
}

enum class TransactionStatus {
    COMPLETED,
    PENDING,
    CANCELLED
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val txId: String,
    val type: String, // "WITHDRAWAL" or "BILL_PAYMENT"
    val timestamp: Long = System.currentTimeMillis(),
    val amount: Double,
    val platformFeePercent: Double,
    val platformFeeAmount: Double,
    val isManualPlatformFee: Boolean = false,
    val commissionPercent: Double,
    val commissionAmount: Double,
    val serviceChargePercent: Double = 0.0,
    val serviceChargeAmount: Double = 0.0,
    val transactionCharge: Double = 0.0,
    val otherCosts: Double = 0.0,
    val customerPayoutOrCharge: Double,
    val grossProfit: Double,
    val netProfit: Double,
    val status: String = TransactionStatus.COMPLETED.name,
    val notes: String = "",
    val isTransactionChargeRetained: Boolean = true
)
