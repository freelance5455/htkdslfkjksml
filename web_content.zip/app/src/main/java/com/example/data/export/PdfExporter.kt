package com.example.data.export

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.model.BookingWithDetails
import com.example.data.model.ClientWithBookings
import com.example.data.model.ReportPreview
import com.example.utils.CurrencyFormatters
import com.example.utils.DateFormatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class PdfExporter(private val context: Context) {

    private val exportsDir: File
        get() = File(context.filesDir, "exports").apply { if (!exists()) mkdirs() }

    private val arabicTypeface: Typeface by lazy {
        runCatching { ResourcesCompat.getFont(context, R.font.cairo) }.getOrNull() ?: Typeface.DEFAULT
    }

    private val navyColor = Color.rgb(11, 31, 58)
    private val goldColor = Color.rgb(212, 175, 55)
    private val softGoldBg = Color.rgb(253, 246, 223)
    private val lightGrayBg = Color.rgb(244, 246, 249)
    private val borderColor = Color.rgb(210, 218, 230)
    private val textDark = Color.rgb(15, 23, 42)
    private val textMuted = Color.rgb(71, 85, 105)

    suspend fun exportReportToPdf(
        report: ReportPreview,
        fromDate: String,
        toDate: String,
    ): File = withContext(Dispatchers.IO) {
        val fileName = "SD_TRAVEL_Report_${report.reportType.id}_${DateFormatters.fileTimestamp()}.pdf"
        val outFile = File(exportsDir, fileName)

        // Landscape A4 for multi-column reports (842 x 595)
        val pageWidth = 842
        val pageHeight = 595
        val margin = 28f
        val contentWidth = pageWidth - margin * 2

        val pdf = PdfDocument()
        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas

        fun drawHeader(c: Canvas, isFirstPage: Boolean): Float {
            val headerPaint = Paint().apply { color = navyColor }
            c.drawRect(0f, 0f, pageWidth.toFloat(), 64f, headerPaint)
            val goldLine = Paint().apply { color = goldColor; strokeWidth = 3f }
            c.drawLine(0f, 64f, pageWidth.toFloat(), 64f, goldLine)

            drawRtlText(c, "SD TRAVEL", pageWidth - margin, 14f, 220f, 18f, Color.rgb(212, 175, 55), bold = true)
            drawRtlText(c, report.title, pageWidth - margin, 36f, 440f, 13f, Color.WHITE, bold = true)
            drawLtrText(c, "تاريخ التقرير: ${DateFormatters.todayIso()}", margin, 26f, 10.5f, Color.WHITE)

            var y = 78f
            if (isFirstPage) {
                val filterDesc = buildString {
                    if (fromDate.isNotBlank() || toDate.isNotBlank()) {
                        append("الفترة: ${fromDate.ifBlank { "البداية" }} إلى ${toDate.ifBlank { "النهاية" }}   |   ")
                    }
                    append(report.summaryMetrics.joinToString("   |   ") { "${it.first}: ${it.second}" })
                }
                if (filterDesc.isNotBlank()) {
                    val boxPaint = Paint().apply { color = softGoldBg }
                    c.drawRoundRect(RectF(margin, y, pageWidth - margin, y + 32f), 8f, 8f, boxPaint)
                    drawRtlText(c, filterDesc, pageWidth - margin - 10f, y + 8f, contentWidth - 20f, 10.5f, navyColor, bold = true)
                    y += 42f
                }
            }
            return y
        }

        val colCount = report.headers.size.coerceAtLeast(1)
        val colWidth = contentWidth / colCount

        fun drawTableHeader(c: Canvas, yStart: Float): Float {
            val rowH = 26f
            val bgPaint = Paint().apply { color = navyColor }
            c.drawRect(margin, yStart, pageWidth - margin, yStart + rowH, bgPaint)
            // RTL columns: index 0 on the far right
            for (i in 0 until colCount) {
                val rightX = pageWidth - margin - (i * colWidth)
                drawRtlText(c, report.headers[i], rightX - 6f, yStart + 6f, colWidth - 12f, 9.5f, Color.WHITE, bold = true)
            }
            return yStart + rowH
        }

        var y = drawHeader(canvas, isFirstPage = true)
        y = drawTableHeader(canvas, y)

        val borderPaint = Paint().apply {
            color = borderColor
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val altBgPaint = Paint().apply { color = lightGrayBg }

        if (report.rows.isEmpty()) {
            drawRtlText(canvas, "لا توجد بيانات مطابقة لهذا التقرير في الفترة المحددة.", pageWidth - margin, y + 16f, contentWidth, 12f, textMuted, bold = false)
        } else {
            report.rows.forEachIndexed { idx, row ->
                val rowHeight = 24f
                if (y + rowHeight > pageHeight - 36f) {
                    drawLtrText(canvas, "صفحة $pageNum", margin, pageHeight - 20f, 9f, textMuted)
                    pdf.finishPage(page)
                    pageNum++
                    page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                    canvas = page.canvas
                    y = drawHeader(canvas, isFirstPage = false)
                    y = drawTableHeader(canvas, y)
                }
                if (idx % 2 == 1) {
                    canvas.drawRect(margin, y, pageWidth - margin, y + rowHeight, altBgPaint)
                }
                canvas.drawRect(margin, y, pageWidth - margin, y + rowHeight, borderPaint)
                for (i in 0 until colCount) {
                    val rightX = pageWidth - margin - (i * colWidth)
                    val cellText = row.getOrNull(i).orEmpty()
                    drawRtlText(canvas, cellText, rightX - 6f, y + 5f, colWidth - 12f, 9f, textDark, bold = false)
                }
                y += rowHeight
            }
        }

        drawLtrText(canvas, "صفحة $pageNum - SD TRAVEL", margin, pageHeight - 20f, 9f, textMuted)
        pdf.finishPage(page)

        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        outFile
    }

    suspend fun exportClientProfilePdf(
        clientWithBookings: ClientWithBookings,
        selectedBooking: BookingWithDetails?,
    ): File = withContext(Dispatchers.IO) {
        val safeCode = clientWithBookings.client.clientCode.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val outFile = File(exportsDir, "SD_TRAVEL_Client_${safeCode}_${DateFormatters.fileTimestamp()}.pdf")

        // Portrait A4 (595 x 842)
        val pageWidth = 595
        val pageHeight = 842
        val margin = 32f
        val contentWidth = pageWidth - margin * 2

        val pdf = PdfDocument()
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create())
        val c = page.canvas

        // Banner
        val navyPaint = Paint().apply { color = navyColor }
        c.drawRect(0f, 0f, pageWidth.toFloat(), 84f, navyPaint)
        val goldPaint = Paint().apply { color = goldColor; strokeWidth = 3f }
        c.drawLine(0f, 84f, pageWidth.toFloat(), 84f, goldPaint)

        drawRtlText(c, "SD TRAVEL", pageWidth - margin, 18f, 250f, 20f, goldColor, bold = true)
        drawRtlText(c, "بطاقة بيانات العميل وحجز العمرة", pageWidth - margin, 46f, 340f, 13f, Color.WHITE, bold = true)
        drawLtrText(c, DateFormatters.todayIso(), margin, 32f, 11f, Color.WHITE)

        var y = 104f
        val client = clientWithBookings.client

        // Client Details Section
        y = drawSectionBox(
            c = c,
            title = "البيانات الشخصية للعميل",
            lines = listOf(
                "كود العميل: ${client.clientCode}    |    الاسم: ${client.fullName}",
                "رقم الهاتف: ${client.phone}    |    الواتساب: ${client.whatsapp.ifBlank { "-" }}",
                "رقم البطاقة: ${client.nationalId.ifBlank { "-" }}    |    رقم الجواز: ${client.passportNumber.ifBlank { "-" }}",
                "تاريخ الميلاد: ${client.birthDate.ifBlank { "-" }}",
                "ملاحظات: ${client.notes.ifBlank { "لا توجد" }}",
            ),
            margin = margin,
            width = contentWidth,
            yStart = y,
        )

        if (selectedBooking != null) {
            val b = selectedBooking.booking
            val tripLabel = if (b.customTripLabel.isNotBlank()) "${b.tripType.arabicLabel} (${b.customTripLabel})" else b.tripType.arabicLabel
            y = drawSectionBox(
                c = c,
                title = "بيانات الرحلة والحجز (${b.status.arabicLabel})",
                lines = listOf(
                    "تاريخ الرحلة: ${b.tripDate}    |    تاريخ العودة: ${b.returnDate.ifBlank { "-" }}",
                    "نوع البرنامج: $tripLabel    |    شركة السياحة: ${b.companyName.ifBlank { "-" }}",
                    "فندق مكة: ${b.makkahHotel.ifBlank { "-" }}    |    فندق المدينة: ${b.madinahHotel.ifBlank { "-" }}",
                    "ملاحظات الحجز: ${b.notes.ifBlank { "لا توجد" }}",
                ),
                margin = margin,
                width = contentWidth,
                yStart = y + 10f,
            )

            y = drawSectionBox(
                c = c,
                title = "الملخص المالي",
                lines = listOf(
                    "سعر الرحلة الإجمالي: ${CurrencyFormatters.formatMoney(b.totalPrice)}    |    المبالغ الإضافية: ${CurrencyFormatters.formatMoney(b.extraAmount)}",
                    "إجمالي المستحق: ${CurrencyFormatters.formatMoney(selectedBooking.totalDue)}    |    إجمالي المدفوع: ${CurrencyFormatters.formatMoney(selectedBooking.totalPaid)}",
                    "المبلغ المتبقي: ${CurrencyFormatters.formatMoney(selectedBooking.remainingAmount)}",
                ),
                margin = margin,
                width = contentWidth,
                yStart = y + 10f,
                highlightBox = true,
            )

            // Payments ledger
            val paymentLines = if (selectedBooking.payments.isEmpty()) {
                listOf("لا توجد دفعات مسجلة.")
            } else {
                selectedBooking.payments.take(12).mapIndexed { index, p ->
                    "${index + 1}. التاريخ: ${p.paymentDate} | المبلغ: ${CurrencyFormatters.formatMoney(p.amount)} | الطريقة: ${p.paymentMethod.arabicLabel} | ${p.notes.ifBlank { "-" }}"
                }
            }
            drawSectionBox(
                c = c,
                title = "سجل المدفوعات (${selectedBooking.payments.size})",
                lines = paymentLines,
                margin = margin,
                width = contentWidth,
                yStart = y + 10f,
            )
        }

        drawRtlText(c, "تم إنشاء المستند عبر تطبيق SD TRAVEL (بدون إنترنت)", pageWidth - margin, pageHeight - 28f, contentWidth, 9.5f, textMuted, bold = false)
        pdf.finishPage(page)

        FileOutputStream(outFile).use { pdf.writeTo(it) }
        pdf.close()
        outFile
    }

    private fun drawSectionBox(
        c: Canvas,
        title: String,
        lines: List<String>,
        margin: Float,
        width: Float,
        yStart: Float,
        highlightBox: Boolean = false,
    ): Float {
        val lineHeight = 20f
        val boxHeight = 36f + lines.size * lineHeight + 10f
        val bgPaint = Paint().apply { color = if (highlightBox) softGoldBg else lightGrayBg }
        val strokePaint = Paint().apply {
            color = if (highlightBox) goldColor else borderColor
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val rect = RectF(margin, yStart, margin + width, yStart + boxHeight)
        c.drawRoundRect(rect, 10f, 10f, bgPaint)
        c.drawRoundRect(rect, 10f, 10f, strokePaint)

        val headerRect = RectF(margin, yStart, margin + width, yStart + 28f)
        val headerPaint = Paint().apply { color = navyColor }
        c.drawRoundRect(headerRect, 10f, 10f, headerPaint)
        c.drawRect(margin, yStart + 18f, margin + width, yStart + 28f, headerPaint)

        drawRtlText(c, title, margin + width - 12f, yStart + 6f, width - 24f, 11.5f, Color.WHITE, bold = true)

        var lineY = yStart + 38f
        lines.forEach { line ->
            drawRtlText(c, line, margin + width - 12f, lineY, width - 24f, 10.5f, textDark, bold = highlightBox)
            lineY += lineHeight
        }
        return yStart + boxHeight
    }

    private fun drawRtlText(
        canvas: Canvas,
        text: String,
        rightX: Float,
        topY: Float,
        maxWidth: Float,
        textSizeSp: Float,
        color: Int,
        bold: Boolean,
    ) {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.textSize = textSizeSp
            this.typeface = if (bold) Typeface.create(arabicTypeface, Typeface.BOLD) else arabicTypeface
        }
        val safeW = maxWidth.toInt().coerceAtLeast(20)
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, paint, safeW)
            .setTextDirection(android.text.TextDirectionHeuristics.RTL)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setMaxLines(2)
            .build()
        canvas.save()
        canvas.translate(rightX - safeW, topY)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawLtrText(
        canvas: Canvas,
        text: String,
        leftX: Float,
        topY: Float,
        textSizeSp: Float,
        color: Int,
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            this.textSize = textSizeSp
            this.typeface = arabicTypeface
        }
        canvas.drawText(text, leftX, topY + textSizeSp, paint)
    }
}
