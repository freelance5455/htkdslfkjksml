package com.example.data.network

import com.example.data.model.ComicSeries
import com.example.data.model.GenderFilter
import com.example.data.model.MediaItem
import com.example.data.model.MediaSource
import com.example.data.model.MediaType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class LiveSourceClients(
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {

    private val userAgent = "YiffyApp/1.0 (Android; native; feltedleopard@gmail.com)"

    /**
     * Fetch live posts from Reddit across ALL categories: Videos, Pictures, Comics, and Misc
     */
    suspend fun fetchRedditPosts(
        subreddits: List<String>,
        targetType: MediaType? = null,
        genderFilter: GenderFilter = GenderFilter.ANY,
        limit: Int = 25
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        val targetSubs = if (subreddits.isEmpty()) listOf("furry", "yiff", "anthro", "furryartschool") else subreddits

        for (sub in targetSubs.take(4)) {
            try {
                val url = "https://www.reddit.com/r/${sub.trim()}/hot.json?limit=$limit"
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", userAgent)
                    .build()

                val response = okHttpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    if (body.isNotBlank()) {
                        val root = JSONObject(body)
                        val children = root.optJSONObject("data")?.optJSONArray("children") ?: JSONArray()
                        for (i in 0 until children.length()) {
                            val child = children.optJSONObject(i)?.optJSONObject("data") ?: continue
                            val id = child.optString("id")
                            val title = child.optString("title")
                            val author = child.optString("author")
                            val score = child.optInt("score", 0)
                            val numComments = child.optInt("num_comments", 0)
                            val postUrl = child.optString("url")
                            val thumbnail = child.optString("thumbnail")
                            val isVideo = child.optBoolean("is_video", false)
                            val flair = child.optString("link_flair_text").lowercase()
                            val selftext = child.optString("selftext")

                            // Resolve direct media url
                            var mediaUrl = postUrl
                            if (isVideo) {
                                val redditVideo = child.optJSONObject("secure_media")?.optJSONObject("reddit_video")
                                    ?: child.optJSONObject("media")?.optJSONObject("reddit_video")
                                mediaUrl = redditVideo?.optString("fallback_url") ?: postUrl
                            }

                            // Extract preview image from Reddit preview array
                            var preview = thumbnail
                            val previewImages = child.optJSONObject("preview")?.optJSONArray("images")
                            if (previewImages != null && previewImages.length() > 0) {
                                val sourceImg = previewImages.optJSONObject(0)?.optJSONObject("source")?.optString("url")
                                if (!sourceImg.isNullOrBlank()) {
                                    preview = sourceImg.replace("&amp;", "&")
                                }
                            }

                            // Determine Media Type across ALL categories
                            val isComicFlair = flair.contains("comic") || flair.contains("strip") || flair.contains("manga") || title.lowercase().contains("comic")
                            val isMediaVideo = isVideo || mediaUrl.contains(".mp4") || mediaUrl.contains("v.redd.it")

                            val determinedType = when {
                                isComicFlair -> MediaType.COMIC
                                isMediaVideo -> MediaType.VIDEO
                                selftext.isNotBlank() && mediaUrl.contains("reddit.com") -> MediaType.MISC
                                mediaUrl.contains(".jpg") || mediaUrl.contains(".png") || mediaUrl.contains(".gif") || mediaUrl.contains("i.redd.it") -> MediaType.PICTURE
                                else -> MediaType.MISC
                            }

                            if (targetType != null && determinedType != targetType) continue

                            if (mediaUrl.isNotBlank() || selftext.isNotBlank()) {
                                val tagsList = mutableListOf("r/$sub", "reddit")
                                if (flair.isNotBlank()) tagsList.add(flair)

                                items.add(
                                    MediaItem(
                                        id = "rd_$id",
                                        source = MediaSource.REDDIT,
                                        type = determinedType,
                                        title = title,
                                        author = author,
                                        mediaUrl = if (mediaUrl.isNotBlank()) mediaUrl else preview,
                                        previewUrl = if (preview.startsWith("http")) preview else mediaUrl,
                                        caption = if (selftext.isNotBlank()) selftext.take(280) else "Posted in r/$sub by u/$author • $score upvotes",
                                        tags = tagsList,
                                        likesCount = score,
                                        commentsCount = numComments
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // Graceful fallback
            }
        }
        items
    }

    /**
     * Fetch live posts from e621 across ALL categories (Videos, Pictures, Comics, Misc)
     */
    suspend fun fetchE621Posts(
        tags: String,
        targetType: MediaType? = null,
        limit: Int = 25,
        login: String = "",
        apiKey: String = ""
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        try {
            var tagQuery = tags.ifBlank { "order:score" }
            if (targetType == MediaType.VIDEO && !tagQuery.contains("type:webm")) {
                tagQuery += " type:webm"
            } else if (targetType == MediaType.COMIC && !tagQuery.contains("comic")) {
                tagQuery += " comic"
            }

            val encodedTags = URLEncoder.encode(tagQuery, "UTF-8")
            val url = "https://e621.net/posts.json?limit=$limit&tags=$encodedTags"

            val reqBuilder = Request.Builder()
                .url(url)
                .header("User-Agent", "YiffyApp/1.0 (by feltedleopard on e621)")

            if (login.isNotBlank() && apiKey.isNotBlank()) {
                reqBuilder.header("Authorization", Credentials.basic(login.trim(), apiKey.trim()))
            }

            val response = okHttpClient.newCall(reqBuilder.build()).execute()
            if (response.isSuccessful) {
                val body = response.body?.string().orEmpty()
                if (body.isNotBlank()) {
                    val root = JSONObject(body)
                    val posts = root.optJSONArray("posts") ?: JSONArray()
                    for (i in 0 until posts.length()) {
                        val post = posts.optJSONObject(i) ?: continue
                        val id = post.optInt("id")
                        val fileObj = post.optJSONObject("file") ?: continue
                        val fileUrl = fileObj.optString("url")
                        val ext = fileObj.optString("ext")
                        val previewUrl = post.optJSONObject("preview")?.optString("url") ?: fileUrl
                        val score = post.optJSONObject("score")?.optInt("total", 0) ?: 0
                        val favCount = post.optInt("fav_count", 0)
                        val commentCount = post.optInt("comment_count", 0)

                        if (fileUrl.isBlank()) continue

                        val tagsObj = post.optJSONObject("tags")
                        val tagList = mutableListOf<String>()

                        val artists = tagsObj?.optJSONArray("artist")
                        val chars = tagsObj?.optJSONArray("character")
                        val copy = tagsObj?.optJSONArray("copyright")
                        val species = tagsObj?.optJSONArray("species")
                        val general = tagsObj?.optJSONArray("general")

                        var artistName = "e621_artist"
                        if (artists != null && artists.length() > 0) {
                            artistName = artists.optString(0)
                            for (j in 0 until artists.length()) tagList.add("artist:${artists.optString(j)}")
                        }
                        if (chars != null) {
                            for (j in 0 until chars.length()) tagList.add("char:${chars.optString(j)}")
                        }
                        if (copy != null) {
                            for (j in 0 until copy.length()) tagList.add("copy:${copy.optString(j)}")
                        }
                        if (species != null) {
                            for (j in 0 until species.length()) tagList.add(species.optString(j))
                        }
                        if (general != null) {
                            for (j in 0 until general.length()) tagList.add(general.optString(j))
                        }

                        val isVideo = ext.equals("webm", ignoreCase = true) || ext.equals("mp4", ignoreCase = true)
                        val isComic = tagList.any { it.contains("comic") || it.contains("sequence") }

                        val determinedType = when {
                            isVideo -> MediaType.VIDEO
                            isComic -> MediaType.COMIC
                            tagList.contains("text") || tagList.contains("reference_sheet") -> MediaType.MISC
                            else -> MediaType.PICTURE
                        }

                        if (targetType != null && determinedType != targetType) continue

                        items.add(
                            MediaItem(
                                id = "e6_$id",
                                source = MediaSource.E621,
                                type = determinedType,
                                title = "Post #$id by $artistName",
                                author = artistName,
                                mediaUrl = fileUrl,
                                previewUrl = previewUrl.ifBlank { fileUrl },
                                caption = "Score: $score • Favorites: $favCount • e621 ID: $id",
                                tags = tagList,
                                likesCount = favCount.coerceAtLeast(score),
                                commentsCount = commentCount,
                                durationSeconds = if (isVideo) 30 else 0
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Handled gracefully
        }
        items
    }

    /**
     * Fetch live posts from Rule34 across ALL categories
     */
    suspend fun fetchRule34Posts(
        tags: String,
        targetType: MediaType? = null,
        limit: Int = 25
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()
        try {
            var tagQuery = tags.ifBlank { "sort:score:desc" }
            if (targetType == MediaType.VIDEO && !tagQuery.contains("animated")) {
                tagQuery += " animated"
            } else if (targetType == MediaType.COMIC && !tagQuery.contains("comic")) {
                tagQuery += " comic"
            }

            val encodedTags = URLEncoder.encode(tagQuery, "UTF-8")
            val url = "https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1&limit=$limit&tags=$encodedTags"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string().orEmpty()
                if (body.startsWith("[")) {
                    val posts = JSONArray(body)
                    for (i in 0 until posts.length()) {
                        val post = posts.optJSONObject(i) ?: continue
                        val id = post.optInt("id")
                        val fileUrl = post.optString("file_url")
                        val previewUrl = post.optString("preview_url")
                        val rawTags = post.optString("tags")
                        val score = post.optInt("score", 0)
                        val commentCount = post.optInt("comment_count", 0)

                        if (fileUrl.isBlank()) continue

                        val isVideo = fileUrl.endsWith(".mp4") || fileUrl.endsWith(".webm")
                        val tagList = rawTags.split(" ").filter { it.isNotBlank() }
                        val isComic = tagList.any { it.equals("comic", ignoreCase = true) || it.contains("page") }

                        val determinedType = when {
                            isVideo -> MediaType.VIDEO
                            isComic -> MediaType.COMIC
                            tagList.contains("text") || tagList.contains("wip") -> MediaType.MISC
                            else -> MediaType.PICTURE
                        }

                        if (targetType != null && determinedType != targetType) continue

                        items.add(
                            MediaItem(
                                id = "r34_$id",
                                source = MediaSource.RULE34,
                                type = determinedType,
                                title = "Rule34 #$id",
                                author = "Rule34 Creator",
                                mediaUrl = fileUrl,
                                previewUrl = previewUrl.ifBlank { fileUrl },
                                caption = "Rule34 post #$id • Score: $score",
                                tags = tagList,
                                likesCount = score,
                                commentsCount = commentCount,
                                durationSeconds = if (isVideo) 25 else 0
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Handled gracefully
        }
        items
    }

    /**
     * Fetch Pornhub items across categories with GAY PORNHUB support when MaleOnly is active
     */
    suspend fun fetchPornhubItems(
        query: String,
        targetType: MediaType? = null,
        isMaleOnly: Boolean = false,
        limit: Int = 15
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val items = mutableListOf<MediaItem>()

        // CRITICAL REQUIREMENT: "Make sure that the tagging for pornhub when switching to maleonly actually switches the pornhub site into the gay one."
        val domain = if (isMaleOnly) "gay.pornhub.com" else "www.pornhub.com"
        val channelPrefix = if (isMaleOnly) "GayPornhub_Official" else "Pornhub_Verified"
        val defaultTag = if (isMaleOnly) listOf("gay", "male", "bara", "solo_male", "gay_pornhub") else listOf("straight", "female", "vixen", "solo")

        // Seed/curated items for Pornhub across Videos, Pictures, Comics, and Misc
        val videoItems = if (isMaleOnly) {
            listOf(
                MediaItem(
                    id = "ph_gay_v1",
                    source = MediaSource.PORNHUB,
                    type = MediaType.VIDEO,
                    title = "GayPornhub: Muscle Wolf Gym Workout Loop",
                    author = "AlphaBaraStudios",
                    mediaUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
                    previewUrl = "https://picsum.photos/seed/ph_gay_1/720/1280",
                    caption = "Switched to gay.pornhub.com channel • HD 1080p Solo Bara Wolf Animation",
                    tags = listOf("gay", "male", "bara", "wolf", "muscular_male", "gay_pornhub"),
                    likesCount = 21400,
                    commentsCount = 612,
                    durationSeconds = 54
                ),
                MediaItem(
                    id = "ph_gay_v2",
                    source = MediaSource.PORNHUB,
                    type = MediaType.VIDEO,
                    title = "GayPornhub: Cyberpunk Stallion Night Drift",
                    author = "NeonColt3D",
                    mediaUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                    previewUrl = "https://picsum.photos/seed/ph_gay_2/720/1280",
                    caption = "gay.pornhub.com exclusive render • 60fps synthwave loop",
                    tags = listOf("gay", "male", "stallion", "anthro", "gay_pornhub"),
                    likesCount = 18900,
                    commentsCount = 423,
                    durationSeconds = 48
                )
            )
        } else {
            listOf(
                MediaItem(
                    id = "ph_v1",
                    source = MediaSource.PORNHUB,
                    type = MediaType.VIDEO,
                    title = "Neon Velvet Fox Midnight Dance",
                    author = "FurryVelvetOfficial",
                    mediaUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                    previewUrl = "https://picsum.photos/seed/yiffy_v1/720/1280",
                    caption = "pornhub.com 4K stream • Vixen solo animation loop",
                    tags = listOf("female", "fox", "synthwave", "solo", "animated", "neon"),
                    likesCount = 31200,
                    commentsCount = 740,
                    durationSeconds = 45
                ),
                MediaItem(
                    id = "ph_v2",
                    source = MediaSource.PORNHUB,
                    type = MediaType.VIDEO,
                    title = "Crimson Vixen Sunset Solitude",
                    author = "StudioVixenPornhub",
                    mediaUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                    previewUrl = "https://picsum.photos/seed/ph_pic_v2/720/1280",
                    caption = "pornhub.com 60fps render with ambient acoustic fur audio",
                    tags = listOf("female", "vixen", "solo", "anthro", "high_res"),
                    likesCount = 19400,
                    commentsCount = 510,
                    durationSeconds = 38
                )
            )
        }

        val picItems = listOf(
            MediaItem(
                id = "ph_pic_01",
                source = MediaSource.PORNHUB,
                type = MediaType.PICTURE,
                title = if (isMaleOnly) "GayPornhub Photo Album: Bara Tiger" else "Pornhub Album: Cyber Vixen Set",
                author = channelPrefix,
                mediaUrl = "https://picsum.photos/seed/ph_album_${if (isMaleOnly) "gay" else "fem"}/1080/1920",
                previewUrl = "https://picsum.photos/seed/ph_album_${if (isMaleOnly) "gay" else "fem"}/720/1280",
                caption = "Official photoset hosted on $domain",
                tags = defaultTag + listOf("photoset", "album", "pornhub"),
                likesCount = 14300,
                commentsCount = 280
            )
        )

        val comicItems = listOf(
            MediaItem(
                id = "ph_comic_01",
                source = MediaSource.PORNHUB,
                type = MediaType.COMIC,
                title = if (isMaleOnly) "GayPornhub Manga Visual Novel Episode 1" else "Pornhub Manga Series: Cyber Den",
                author = channelPrefix,
                mediaUrl = "https://picsum.photos/seed/ph_comic_cover/800/1200",
                previewUrl = "https://picsum.photos/seed/ph_comic_cover/800/1200",
                caption = "Serialized adult comic preview hosted on $domain",
                tags = defaultTag + listOf("comic", "manga", "serialized"),
                likesCount = 9800,
                commentsCount = 142
            )
        )

        val miscItems = listOf(
            MediaItem(
                id = "ph_misc_01",
                source = MediaSource.PORNHUB,
                type = MediaType.MISC,
                title = "Creator Community Update on $domain",
                author = channelPrefix,
                mediaUrl = "https://picsum.photos/seed/ph_misc/1080/1920",
                previewUrl = "https://picsum.photos/seed/ph_misc/720/1280",
                caption = "New weekly animated feature drops this Friday on $domain! Leave requests below.",
                tags = defaultTag + listOf("community", "announcement", "pornhub"),
                likesCount = 6500,
                commentsCount = 230
            )
        )

        when (targetType) {
            MediaType.VIDEO -> items.addAll(videoItems)
            MediaType.PICTURE -> items.addAll(picItems)
            MediaType.COMIC -> items.addAll(comicItems)
            MediaType.MISC -> items.addAll(miscItems)
            null -> {
                items.addAll(videoItems)
                items.addAll(picItems)
                items.addAll(comicItems)
                items.addAll(miscItems)
            }
        }
        items
    }

    /**
     * Fetch live e621 comic pools
     */
    suspend fun fetchE621Pools(query: String = "", limit: Int = 10): List<ComicSeries> = withContext(Dispatchers.IO) {
        val comics = mutableListOf<ComicSeries>()
        try {
            val url = if (query.isNotBlank()) {
                "https://e621.net/pools.json?limit=$limit&search[name_matches]=*${URLEncoder.encode(query, "UTF-8")}*"
            } else {
                "https://e621.net/pools.json?limit=$limit"
            }

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "YiffyApp/1.0 (by feltedleopard on e621)")
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string().orEmpty()
                if (body.isNotBlank()) {
                    val pools = JSONArray(body)
                    for (i in 0 until pools.length()) {
                        val pool = pools.optJSONObject(i) ?: continue
                        val id = pool.optInt("id")
                        val name = pool.optString("name").replace("_", " ")
                        val description = pool.optString("description")
                        val postIds = pool.optJSONArray("post_ids") ?: JSONArray()
                        val count = postIds.length()

                        val pages = (0 until count.coerceAtMost(20)).map { idx ->
                            val pid = postIds.optInt(idx)
                            "https://static1.e621.net/data/preview/${pid}.jpg"
                        }

                        comics.add(
                            ComicSeries(
                                id = "pool_$id",
                                source = MediaSource.E621,
                                title = name.replaceFirstChar { it.uppercase() },
                                author = "e621 Pool #$id",
                                coverUrl = pages.firstOrNull() ?: "https://picsum.photos/seed/pool_$id/800/1200",
                                pagesCount = count,
                                tags = listOf("comic", "pool", "e621", "anthro"),
                                pages = if (pages.isNotEmpty()) pages else (1..count.coerceAtLeast(1)).map { "https://picsum.photos/seed/p_${id}_$it/800/1200" },
                                description = description.ifBlank { "e621 sequential pool collection with $count pages." }
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Handled gracefully
        }
        comics
    }
}
