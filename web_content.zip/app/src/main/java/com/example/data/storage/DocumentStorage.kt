package com.example.data.storage

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class DocumentStorage(private val context: Context) {

    private val docsRoot: File
        get() = File(context.filesDir, "documents").apply { if (!exists()) mkdirs() }

    private val cameraCacheDir: File
        get() = File(context.cacheDir, "camera").apply { if (!exists()) mkdirs() }

    fun createTempCameraFileAndUri(): Pair<File, Uri> {
        val file = File(cameraCacheDir, "cam_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file,
        )
        return file to uri
    }

    suspend fun copyUriToTempFile(uri: Uri): File? = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(cameraCacheDir, "pick_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output ->
                    input.copyTo(output)
                }
            } ?: return@runCatching null
            if (file.length() <= 0L) {
                file.delete()
                return@runCatching null
            }
            file
        }.getOrNull()
    }

    suspend fun saveTempFilePermanently(tempFile: File, bookingId: Long): String = withContext(Dispatchers.IO) {
        val bookingDir = File(docsRoot, "booking_$bookingId").apply { if (!exists()) mkdirs() }
        val ext = tempFile.extension.ifBlank { "jpg" }
        val fileName = "doc_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.$ext"
        val destFile = File(bookingDir, fileName)
        tempFile.inputStream().use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        }
        "documents/booking_$bookingId/$fileName"
    }

    suspend fun saveUriPermanently(uri: Uri, bookingId: Long): String? = withContext(Dispatchers.IO) {
        runCatching {
            val bookingDir = File(docsRoot, "booking_$bookingId").apply { if (!exists()) mkdirs() }
            val fileName = "doc_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
            val destFile = File(bookingDir, fileName)
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return@runCatching null
            if (destFile.length() <= 0L) {
                destFile.delete()
                return@runCatching null
            }
            "documents/booking_$bookingId/$fileName"
        }.getOrNull()
    }

    fun resolveFile(relativePath: String): File = File(context.filesDir, relativePath)

    fun deleteFile(relativePath: String) {
        runCatching {
            val file = resolveFile(relativePath)
            if (file.exists()) {
                file.delete()
            }
        }
    }

    fun deleteBookingFolder(bookingId: Long) {
        runCatching {
            val folder = File(docsRoot, "booking_$bookingId")
            if (folder.exists()) {
                folder.deleteRecursively()
            }
        }
    }

    fun getShareUri(file: File): Uri = FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file,
    )
}
