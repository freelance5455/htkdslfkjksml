package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "perfumes")
data class Perfume(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val codigo: String,
    val nome: String,
    val marca: String,
    val custo: Double,
    val venda: Double,
    val estoque: Int, // Quantidade deste lote específico
    val validade: String, // Data de validade deste lote (YYYY-MM-DD)
    val numeroLote: String = "", // Identificação opcional do lote (ex: LOTE-01)
    val dataCadastro: Long = System.currentTimeMillis()
)
