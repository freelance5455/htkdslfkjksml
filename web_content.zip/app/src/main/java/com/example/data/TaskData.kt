package com.example.data

import com.example.model.GameTask
import com.example.model.UserStats

object TaskCatalog {

    fun getDailyTasks(stats: UserStats): List<GameTask> {
        val todayStr = getTodayDateString()
        val dailyCompleted = stats.lastDailyDate == todayStr
        val dailyProgress = if (dailyCompleted) 1 else 0

        return listOf(
            GameTask(
                id = "daily_solve_1",
                title = "Sharp Observer",
                description = "Solve any 1 image puzzle today",
                isDaily = true,
                icon = "🎯",
                currentProgress = (stats.totalSolved).coerceAtMost(1),
                targetProgress = 1,
                rewardScore = 500,
                rewardCoins = 60,
                isCompleted = stats.totalSolved >= 1,
                isClaimed = stats.claimedTaskIds.contains("daily_solve_1")
            ),
            GameTask(
                id = "daily_zoom_1",
                title = "Extreme Zoom Sniper",
                description = "Solve an image at Zoom Stage 1 (Micro-Zoom)",
                isDaily = true,
                icon = "🔍",
                currentProgress = stats.stage1Solves.coerceAtMost(1),
                targetProgress = 1,
                rewardScore = 800,
                rewardCoins = 90,
                isCompleted = stats.stage1Solves >= 1,
                isClaimed = stats.claimedTaskIds.contains("daily_zoom_1")
            ),
            GameTask(
                id = "daily_streak_3",
                title = "Streak Sprinter",
                description = "Build a streak of 3 consecutive correct guesses",
                isDaily = true,
                icon = "🔥",
                currentProgress = stats.streak.coerceAtMost(3),
                targetProgress = 3,
                rewardScore = 1000,
                rewardCoins = 100,
                isCompleted = stats.streak >= 3 || stats.highestStreak >= 3,
                isClaimed = stats.claimedTaskIds.contains("daily_streak_3")
            ),
            GameTask(
                id = "daily_challenge_done",
                title = "Daily Challenger",
                description = "Complete today's official Daily Challenge",
                isDaily = true,
                icon = "🌟",
                currentProgress = dailyProgress,
                targetProgress = 1,
                rewardScore = 1500,
                rewardCoins = 150,
                isCompleted = dailyCompleted,
                isClaimed = stats.claimedTaskIds.contains("daily_challenge_done")
            ),
            GameTask(
                id = "daily_three_solves",
                title = "Trophy Hunter",
                description = "Solve 3 images across any level",
                isDaily = true,
                icon = "🏆",
                currentProgress = stats.totalSolved.coerceAtMost(3),
                targetProgress = 3,
                rewardScore = 1200,
                rewardCoins = 120,
                isCompleted = stats.totalSolved >= 3,
                isClaimed = stats.claimedTaskIds.contains("daily_three_solves")
            )
        )
    }

    fun getLifetimeAchievements(stats: UserStats): List<GameTask> {
        return listOf(
            GameTask(
                id = "ach_novice_5",
                title = "Novice Sleuth",
                description = "Solve 5 images total across all levels",
                isDaily = false,
                icon = "🥉",
                currentProgress = stats.totalSolved.coerceAtMost(5),
                targetProgress = 5,
                rewardScore = 1000,
                rewardCoins = 150,
                isCompleted = stats.totalSolved >= 5,
                isClaimed = stats.claimedTaskIds.contains("ach_novice_5")
            ),
            GameTask(
                id = "ach_detective_15",
                title = "Seasoned Detective",
                description = "Solve 15 images total",
                isDaily = false,
                icon = "🥈",
                currentProgress = stats.totalSolved.coerceAtMost(15),
                targetProgress = 15,
                rewardScore = 2500,
                rewardCoins = 300,
                isCompleted = stats.totalSolved >= 15,
                isClaimed = stats.claimedTaskIds.contains("ach_detective_15")
            ),
            GameTask(
                id = "ach_master_30",
                title = "Master Mind",
                description = "Solve 30 images total",
                isDaily = false,
                icon = "🥇",
                currentProgress = stats.totalSolved.coerceAtMost(30),
                targetProgress = 30,
                rewardScore = 5000,
                rewardCoins = 500,
                isCompleted = stats.totalSolved >= 30,
                isClaimed = stats.claimedTaskIds.contains("ach_master_30")
            ),
            GameTask(
                id = "ach_grandmaster_50",
                title = "Grandmaster Investigator",
                description = "Solve 50 images total and conquer high levels",
                isDaily = false,
                icon = "👑",
                currentProgress = stats.totalSolved.coerceAtMost(50),
                targetProgress = 50,
                rewardScore = 10000,
                rewardCoins = 1000,
                isCompleted = stats.totalSolved >= 50,
                isClaimed = stats.claimedTaskIds.contains("ach_grandmaster_50")
            ),
            GameTask(
                id = "ach_sniper_10",
                title = "Microscopic Vision",
                description = "Solve 10 images on Zoom Stage 1 without zooming out",
                isDaily = false,
                icon = "👁️",
                currentProgress = stats.stage1Solves.coerceAtMost(10),
                targetProgress = 10,
                rewardScore = 4000,
                rewardCoins = 450,
                isCompleted = stats.stage1Solves >= 10,
                isClaimed = stats.claimedTaskIds.contains("ach_sniper_10")
            ),
            GameTask(
                id = "ach_streak_7",
                title = "Unstoppable Fire",
                description = "Reach a combo streak of 7 correct answers in a row",
                isDaily = false,
                icon = "⚡",
                currentProgress = stats.highestStreak.coerceAtMost(7),
                targetProgress = 7,
                rewardScore = 3500,
                rewardCoins = 400,
                isCompleted = stats.highestStreak >= 7,
                isClaimed = stats.claimedTaskIds.contains("ach_streak_7")
            ),
            GameTask(
                id = "ach_score_25k",
                title = "Hall of Fame Candidate",
                description = "Amass 25,000 total score points",
                isDaily = false,
                icon = "💰",
                currentProgress = stats.score.coerceAtMost(25000),
                targetProgress = 25000,
                rewardScore = 6000,
                rewardCoins = 600,
                isCompleted = stats.score >= 25000,
                isClaimed = stats.claimedTaskIds.contains("ach_score_25k")
            ),
            GameTask(
                id = "ach_daily_streak_5",
                title = "Daily Devotee",
                description = "Maintain a 5-day continuous Daily Challenge streak",
                isDaily = false,
                icon = "📅",
                currentProgress = stats.highestDailyStreak.coerceAtMost(5),
                targetProgress = 5,
                rewardScore = 5000,
                rewardCoins = 750,
                isCompleted = stats.highestDailyStreak >= 5,
                isClaimed = stats.claimedTaskIds.contains("ach_daily_streak_5")
            )
        )
    }

    fun getUnclaimedCount(stats: UserStats): Int {
        val daily = getDailyTasks(stats).count { it.isCompleted && !it.isClaimed }
        val ach = getLifetimeAchievements(stats).count { it.isCompleted && !it.isClaimed }
        return daily + ach
    }
}
