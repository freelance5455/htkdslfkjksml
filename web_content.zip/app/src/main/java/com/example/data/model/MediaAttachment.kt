package com.example.data.model

enum class AttachmentKind(val label: String) {
    PHOTO("Фото"),
    VIDEO("Видео"),
    AUDIO("Аудио"),
    PDF("PDF"),
    TEXT("Файл")
}

data class PendingAttachment(
    val uriString: String,
    val displayName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val kind: AttachmentKind
)

data class ResolvedAttachment(
    val displayName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val kind: AttachmentKind,
    val bytes: ByteArray? = null,
    val extractedText: String? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ResolvedAttachment) return false
        return displayName == other.displayName &&
            mimeType == other.mimeType &&
            sizeBytes == other.sizeBytes &&
            kind == other.kind &&
            bytes.contentEquals(other.bytes) &&
            extractedText == other.extractedText
    }

    override fun hashCode(): Int {
        var result = displayName.hashCode()
        result = 31 * result + mimeType.hashCode()
        result = 31 * result + sizeBytes.hashCode()
        result = 31 * result + kind.hashCode()
        result = 31 * result + (bytes?.contentHashCode() ?: 0)
        result = 31 * result + (extractedText?.hashCode() ?: 0)
        return result
    }
}
