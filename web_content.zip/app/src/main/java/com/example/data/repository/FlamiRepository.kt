package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.ContextualMemory
import com.example.data.model.SearchHit
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot.ServerTimestampBehavior
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class FlamiRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : FlamiWorkspaceRepository {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun userDoc(uid: String) = db.collection("users").document(uid)
    private fun chatsCol(uid: String) = userDoc(uid).collection("chats")
    private fun chatDoc(uid: String, chatId: String) = chatsCol(uid).document(chatId)
    private fun messagesCol(uid: String, chatId: String) = chatDoc(uid, chatId).collection("messages")
    private fun memoriesCol(uid: String) = userDoc(uid).collection("memories")

    override fun observeUserProfile(): Flow<UserProfile?> = flow {
        val uid = requireUserId()
        val docRef = userDoc(uid)
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(UserProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                    } else {
                        null
                    }
                }
                .catch { error ->
                    logFlowError(error, OperationType.GET, docRef.path, uid)
                    throw error
                }
        )
    }

    override suspend fun ensureUserProfile(displayName: String, defaultLanguage: String): Result<UserProfile> {
        val uid = requireUserId()
        val docRef = userDoc(uid)
        return try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(UserProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                if (existing != null) {
                    return Result.success(existing)
                }
            }
            val safeName = displayName.trim().take(120).ifBlank { "FLAMI User" }
            val safeLang = defaultLanguage.takeIf { it in SUPPORTED_LANG_CODES } ?: "auto"
            val payload = mapOf(
                "userId" to uid,
                "displayName" to safeName,
                "preferredLanguage" to safeLang,
                "modelMode" to "balanced",
                "ttsEnabled" to true,
                "ttsRate" to 1.0,
                "memoryEnabled" to true,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            val created = docRef.get().await()
                .toObject(UserProfile::class.java, ServerTimestampBehavior.ESTIMATE)
                ?: UserProfile(
                    id = uid,
                    userId = uid,
                    displayName = safeName,
                    preferredLanguage = safeLang
                )
            Result.success(created)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun updateUserPreferences(
        preferredLanguage: String?,
        modelMode: String?,
        ttsEnabled: Boolean?,
        ttsRate: Double?,
        memoryEnabled: Boolean?,
        displayName: String?
    ): Result<Unit> {
        val uid = requireUserId()
        val docRef = userDoc(uid)
        val updates = mutableMapOf<String, Any>(
            "updatedAt" to FieldValue.serverTimestamp()
        )
        preferredLanguage?.let { if (it in SUPPORTED_LANG_CODES) updates["preferredLanguage"] = it }
        modelMode?.let { if (it in SUPPORTED_MODEL_MODES) updates["modelMode"] = it }
        ttsEnabled?.let { updates["ttsEnabled"] = it }
        ttsRate?.let { updates["ttsRate"] = it.coerceIn(0.5, 2.0) }
        memoryEnabled?.let { updates["memoryEnabled"] = it }
        displayName?.let { updates["displayName"] = it.trim().take(120) }

        return try {
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override fun observeChats(): Flow<List<ChatSession>> = flow {
        val uid = requireUserId()
        val colRef = chatsCol(uid)
        emitAll(
            colRef.orderBy("updatedAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(ChatSession::class.java, ServerTimestampBehavior.ESTIMATE)
                        .sortedWith(
                            compareByDescending<ChatSession> { it.isPinned }
                                .thenByDescending { it.updatedAt?.seconds ?: 0L }
                                .thenByDescending { it.updatedAt?.nanoseconds ?: 0 }
                        )
                }
                .catch { error ->
                    logFlowError(error, OperationType.LIST, colRef.path, uid)
                    throw error
                }
        )
    }

    override suspend fun createChat(title: String, initialPreview: String): Result<String> {
        val uid = requireUserId()
        val docRef = chatsCol(uid).document()
        val safeTitle = title.trim().take(140).ifBlank { "New Chat" }
        val safePreview = initialPreview.trim().take(400)
        val payload = mapOf(
            "userId" to uid,
            "title" to safeTitle,
            "lastMessagePreview" to safePreview,
            "messageCount" to 0L,
            "isPinned" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun renameChat(chatId: String, newTitle: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = chatDoc(uid, chatId)
        val safeTitle = newTitle.trim().take(140).ifBlank { return Result.failure(IllegalArgumentException("Title blank")) }
        return try {
            docRef.update(
                mapOf(
                    "title" to safeTitle,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun togglePinChat(chatId: String, pinned: Boolean): Result<Unit> {
        val uid = requireUserId()
        val docRef = chatDoc(uid, chatId)
        return try {
            docRef.update(
                mapOf(
                    "isPinned" to pinned,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun deleteChat(chatId: String): Result<Unit> {
        val uid = requireUserId()
        val cDoc = chatDoc(uid, chatId)
        val msgsRef = messagesCol(uid, chatId)
        return try {
            val msgsSnap = msgsRef.get().await()
            val docs = msgsSnap.documents
            for (chunk in docs.chunked(400)) {
                val batch = db.batch()
                for (doc in chunk) {
                    batch.delete(doc.reference)
                }
                batch.commit().await()
            }
            cDoc.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, cDoc.path, auth)
            Result.failure(e)
        }
    }

    override fun observeMessages(chatId: String): Flow<List<ChatMessage>> = flow {
        val uid = requireUserId()
        val colRef = messagesCol(uid, chatId)
        emitAll(
            colRef.orderBy("createdAt", Query.Direction.ASCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(ChatMessage::class.java, ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    logFlowError(error, OperationType.LIST, colRef.path, uid)
                    throw error
                }
        )
    }

    override suspend fun getMessagesOnce(chatId: String): Result<List<ChatMessage>> {
        val uid = requireUserId()
        val colRef = messagesCol(uid, chatId)
        return try {
            val snap = colRef.orderBy("createdAt", Query.Direction.ASCENDING).get().await()
            val list = snap.toObjects(ChatMessage::class.java, ServerTimestampBehavior.ESTIMATE)
            Result.success(list)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, colRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun addMessage(
        chatId: String,
        role: String,
        text: String,
        hasImage: Boolean,
        imageNote: String?,
        languageCode: String?,
        isError: Boolean,
        updateChatPreview: Boolean
    ): Result<String> {
        val uid = requireUserId()
        val msgRef = messagesCol(uid, chatId).document()
        val safeText = text.take(100000)
        val payload = mutableMapOf<String, Any>(
            "userId" to uid,
            "chatId" to chatId,
            "role" to role,
            "text" to safeText,
            "hasImage" to hasImage,
            "isError" to isError,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        imageNote?.take(250)?.takeIf { it.isNotBlank() }?.let { payload["imageNote"] = it }
        languageCode?.take(16)?.takeIf { it.isNotBlank() }?.let { payload["languageCode"] = it }

        return try {
            msgRef.set(payload).await()
            if (updateChatPreview) {
                val previewText = safeText.replace('\n', ' ').trim().take(200)
                chatDoc(uid, chatId).update(
                    mapOf(
                        "lastMessagePreview" to previewText,
                        "messageCount" to FieldValue.increment(1L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(msgRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, msgRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun updateMessage(
        chatId: String,
        messageId: String,
        newText: String,
        isError: Boolean,
        updateChatPreview: Boolean
    ): Result<Unit> {
        val uid = requireUserId()
        val msgRef = messagesCol(uid, chatId).document(messageId)
        val safeText = newText.take(100000)
        return try {
            msgRef.update(
                mapOf(
                    "text" to safeText,
                    "isError" to isError,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (updateChatPreview) {
                val previewText = safeText.replace('\n', ' ').trim().take(200)
                chatDoc(uid, chatId).update(
                    mapOf(
                        "lastMessagePreview" to previewText,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, msgRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun searchMessages(query: String, chats: List<ChatSession>): Result<List<SearchHit>> {
        val uid = requireUserId()
        val q = query.trim().lowercase()
        if (q.isBlank()) return Result.success(emptyList())
        return try {
            val hits = mutableListOf<SearchHit>()
            for (chat in chats.take(30)) {
                val msgs = messagesCol(uid, chat.id)
                    .orderBy("createdAt", Query.Direction.DESCENDING)
                    .limit(100)
                    .get()
                    .await()
                    .toObjects(ChatMessage::class.java, ServerTimestampBehavior.ESTIMATE)
                for (msg in msgs) {
                    if (msg.text.lowercase().contains(q) || chat.title.lowercase().contains(q)) {
                        hits.add(SearchHit(chatId = chat.id, chatTitle = chat.title, message = msg))
                    }
                }
            }
            Result.success(hits)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, chatsCol(uid).path, auth)
            Result.failure(e)
        }
    }

    override fun observeMemories(): Flow<List<ContextualMemory>> = flow {
        val uid = requireUserId()
        val colRef = memoriesCol(uid)
        emitAll(
            colRef.orderBy("updatedAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(ContextualMemory::class.java, ServerTimestampBehavior.ESTIMATE)
                }
                .catch { error ->
                    logFlowError(error, OperationType.LIST, colRef.path, uid)
                    throw error
                }
        )
    }

    override suspend fun addMemory(
        fact: String,
        category: String,
        sourceChatId: String?
    ): Result<String> {
        val uid = requireUserId()
        val safeFact = fact.trim().take(500)
        if (safeFact.isBlank()) return Result.failure(IllegalArgumentException("Memory fact blank"))
        val safeCat = category.takeIf { it in SUPPORTED_MEMORY_CATEGORIES } ?: "general"
        val docRef = memoriesCol(uid).document()
        val payload = mutableMapOf<String, Any>(
            "userId" to uid,
            "fact" to safeFact,
            "category" to safeCat,
            "isActive" to true,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        sourceChatId?.take(128)?.takeIf { it.isNotBlank() }?.let { payload["sourceChatId"] = it }

        return try {
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun updateMemory(memory: ContextualMemory): Result<Unit> {
        val uid = requireUserId()
        require(memory.id.isNotBlank()) { "Memory ID must not be blank for update" }
        val docRef = memoriesCol(uid).document(memory.id)
        val safeCat = memory.category.takeIf { it in SUPPORTED_MEMORY_CATEGORIES } ?: "general"
        val updates = mapOf(
            "fact" to memory.fact.trim().take(500),
            "category" to safeCat,
            "isActive" to memory.isActive,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path, auth)
            Result.failure(e)
        }
    }

    override suspend fun deleteMemory(memoryId: String): Result<Unit> {
        val uid = requireUserId()
        val docRef = memoriesCol(uid).document(memoryId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path, auth)
            Result.failure(e)
        }
    }

    private fun logFlowError(error: Throwable, op: OperationType, path: String, uid: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, op, path, auth)
        }
    }

    companion object {
        val SUPPORTED_LANG_CODES = setOf("auto", "ru", "en", "es", "de", "fr", "uk", "zh")
        val SUPPORTED_MODEL_MODES = setOf("balanced", "reasoning", "fast")
        val SUPPORTED_MEMORY_CATEGORIES = setOf("preference", "profile", "project", "learning", "general")
    }
}
