package com.example.data.model

data class Currency(
    val code: String,
    val name: String,
    val symbol: String,
    val flag: String,
    val rateToUSD: Double // 1 USD = rate units of this currency
)

object CurrencyData {
    val currencies = listOf(
        Currency("USD", "US Dollar", "$", "🇺🇸", 1.0),
        Currency("EUR", "Euro", "€", "🇪🇺", 0.92),
        Currency("GBP", "British Pound", "£", "🇬🇧", 0.79),
        Currency("INR", "Indian Rupee", "₹", "🇮🇳", 83.25),
        Currency("PKR", "Pakistani Rupee", "₨", "🇵🇰", 278.50),
        Currency("AED", "UAE Dirham", "د.إ", "🇦🇪", 3.67),
        Currency("SAR", "Saudi Riyal", "﷼", "🇸🇦", 3.75),
        Currency("CAD", "Canadian Dollar", "C$", "🇨🇦", 1.36),
        Currency("AUD", "Australian Dollar", "A$", "🇦🇺", 1.52),
        Currency("JPY", "Japanese Yen", "¥", "🇯🇵", 154.60),
        Currency("CNY", "Chinese Yuan", "¥", "🇨🇳", 7.23),
        Currency("CHF", "Swiss Franc", "CHF", "🇨🇭", 0.90),
        Currency("SGD", "Singapore Dollar", "S$", "🇸🇬", 1.35),
        Currency("KWD", "Kuwaiti Dinar", "KD", "🇰🇼", 0.31),
        Currency("QAR", "Qatari Riyal", "QR", "🇶🇦", 3.64),
        Currency("BRL", "Brazilian Real", "R$", "🇧🇷", 5.25),
        Currency("TRY", "Turkish Lira", "₺", "🇹🇷", 32.80)
    )

    fun convert(amount: Double, from: Currency, to: Currency): Double {
        // Amount in USD
        val inUSD = amount / from.rateToUSD
        // In Target
        return inUSD * to.rateToUSD
    }
}
