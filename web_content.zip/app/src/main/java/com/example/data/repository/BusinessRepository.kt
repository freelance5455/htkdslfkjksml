package com.example.data.repository

import com.example.data.local.ExpenseDao
import com.example.data.local.SettingsDao
import com.example.data.local.TransactionDao
import com.example.data.model.BusinessSettings
import com.example.data.model.ExpenseEntity
import com.example.data.model.TransactionEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class BusinessRepository(
    private val transactionDao: TransactionDao,
    private val expenseDao: ExpenseDao,
    private val settingsDao: SettingsDao
) {
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allExpenses: Flow<List<ExpenseEntity>> = expenseDao.getAllExpenses()
    val settings: Flow<BusinessSettings> = settingsDao.getSettings().map {
        it ?: BusinessSettings()
    }

    suspend fun getSettingsSync(): BusinessSettings {
        return settingsDao.getSettingsSync() ?: BusinessSettings()
    }

    suspend fun updateSettings(settings: BusinessSettings) {
        settingsDao.insertOrUpdate(settings)
    }

    fun getTransactionsBetween(start: Long, end: Long): Flow<List<TransactionEntity>> {
        return transactionDao.getTransactionsBetween(start, end)
    }

    fun getExpensesBetween(start: Long, end: Long): Flow<List<ExpenseEntity>> {
        return expenseDao.getExpensesBetween(start, end)
    }

    suspend fun insertTransaction(transaction: TransactionEntity): Long {
        return transactionDao.insertTransaction(transaction)
    }

    suspend fun updateTransaction(transaction: TransactionEntity) {
        transactionDao.updateTransaction(transaction)
    }

    suspend fun deleteTransaction(transaction: TransactionEntity) {
        transactionDao.deleteTransaction(transaction)
    }

    suspend fun deleteTransactionById(id: Long) {
        transactionDao.deleteTransactionById(id)
    }

    suspend fun deleteTransactionsByType(type: String) {
        transactionDao.deleteTransactionsByType(type)
    }

    suspend fun insertExpense(expense: ExpenseEntity): Long {
        return expenseDao.insertExpense(expense)
    }

    suspend fun updateExpense(expense: ExpenseEntity) {
        expenseDao.updateExpense(expense)
    }

    suspend fun deleteExpense(expense: ExpenseEntity) {
        expenseDao.deleteExpense(expense)
    }

    suspend fun deleteExpenseById(id: Long) {
        expenseDao.deleteExpenseById(id)
    }

    suspend fun clearAllData() {
        transactionDao.clearAllTransactions()
        expenseDao.clearAllExpenses()
    }

    suspend fun restoreData(
        transactions: List<TransactionEntity>,
        expenses: List<ExpenseEntity>,
        newSettings: BusinessSettings?
    ) {
        transactionDao.insertAllTransactions(transactions)
        expenseDao.insertAllExpenses(expenses)
        if (newSettings != null) {
            settingsDao.insertOrUpdate(newSettings)
        }
    }
}
