package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.FinanceDao
import com.example.data.entity.AppSettingsEntity
import com.example.data.entity.LoanEntity
import com.example.data.entity.LoanRepaymentEntity
import com.example.data.entity.SalaryEntity
import com.example.data.entity.TransactionEntity

@Database(
    entities = [
        TransactionEntity::class,
        LoanEntity::class,
        LoanRepaymentEntity::class,
        SalaryEntity::class,
        AppSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun financeDao(): FinanceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nijer_hisab_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
