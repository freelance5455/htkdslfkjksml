package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.PerfumeDao
import com.example.data.dao.VendaDao
import com.example.data.model.Perfume
import com.example.data.model.Venda
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Database(entities = [Perfume::class, Venda::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun perfumeDao(): PerfumeDao
    abstract fun vendaDao(): VendaDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "perfumaria_stock.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.perfumeDao(), database.vendaDao())
                    }
                }
            }

            private suspend fun populateInitialData(perfumeDao: PerfumeDao, vendaDao: VendaDao) {
                val cal = Calendar.getInstance()
                cal.add(Calendar.DAY_OF_YEAR, 15)
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val expiringSoonDate = sdf.format(cal.time)

                // Lotes cadastrados (mesmo produto pode ter múltiplos lotes com validades distintas)
                val initialPerfumes = listOf(
                    // Floratta Red: 2 Lotes (Total somado = 8 un.)
                    Perfume(
                        codigo = "7891033300508",
                        nome = "Floratta Red Desodorante Colônia 75ml",
                        marca = "O Boticário",
                        custo = 75.0,
                        venda = 149.90,
                        estoque = 5,
                        validade = "2027-05-10",
                        numeroLote = "LT-01"
                    ),
                    Perfume(
                        codigo = "7891033300508",
                        nome = "Floratta Red Desodorante Colônia 75ml",
                        marca = "O Boticário",
                        custo = 75.0,
                        venda = 149.90,
                        estoque = 3,
                        validade = "2027-11-20",
                        numeroLote = "LT-02"
                    ),

                    // 1 Million: 2 Lotes (1 próximo do vencimento de 6 meses + 1 lote longo)
                    Perfume(
                        codigo = "3349666007891",
                        nome = "1 Million Eau de Toilette 100ml",
                        marca = "Paco Rabanne",
                        custo = 320.0,
                        venda = 589.00,
                        estoque = 2,
                        validade = "2026-11-15",
                        numeroLote = "LT-PR01"
                    ),
                    Perfume(
                        codigo = "3349666007891",
                        nome = "1 Million Eau de Toilette 100ml",
                        marca = "Paco Rabanne",
                        custo = 320.0,
                        venda = 589.00,
                        estoque = 4,
                        validade = "2027-08-30",
                        numeroLote = "LT-PR02"
                    ),

                    // Essencial Exclusivo: 1 Lote Vencido (bloqueado) + 1 Lote Regular
                    Perfume(
                        codigo = "7898523789123",
                        nome = "Essencial Exclusivo Deo Parfum 100ml",
                        marca = "Natura",
                        custo = 90.0,
                        venda = 219.00,
                        estoque = 1,
                        validade = "2024-01-10",
                        numeroLote = "LT-NAT-OLD"
                    ),
                    Perfume(
                        codigo = "7898523789123",
                        nome = "Essencial Exclusivo Deo Parfum 100ml",
                        marca = "Natura",
                        custo = 90.0,
                        venda = 219.00,
                        estoque = 3,
                        validade = "2027-03-10",
                        numeroLote = "LT-NAT-NEW"
                    ),

                    // Malbec: Lote prestes a vencer
                    Perfume(
                        codigo = "7891033001234",
                        nome = "Malbec Desodorante Colônia 100ml",
                        marca = "O Boticário",
                        custo = 110.0,
                        venda = 219.90,
                        estoque = 2,
                        validade = expiringSoonDate,
                        numeroLote = "LT-BOT-05"
                    )
                )
                perfumeDao.insertAll(initialPerfumes)
            }
        }
    }
}
