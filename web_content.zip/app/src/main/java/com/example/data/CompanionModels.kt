package com.example.data

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class StageBackground(val id: String, val label: String, val description: String) {
    SAKURA_SHRINE("sakura_shrine", "Sakura Shrine", "Twilight cherry blossom courtyard"),
    STARLIGHT_STUDIO("starlight_studio", "Starlight Studio", "Pastel idol rehearsal room"),
    LAVENDER_GLOW("lavender_glow", "Lavender Glow", "Minimalist soft gradient");

    companion object {
        fun fromId(raw: String?): StageBackground =
            entries.firstOrNull { it.id == raw } ?: SAKURA_SHRINE
    }
}

@Keep
@IgnoreExtraProperties
data class UserCompanionPrefs(
    val userId: String = "",
    val displayName: String = "",
    val backgroundId: String = StageBackground.SAKURA_SHRINE.id,
    val dressColor: String = "orig",
    val jpMode: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class LearnedMoveDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val steps: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
