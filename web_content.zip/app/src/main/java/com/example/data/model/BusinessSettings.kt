package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "settings")
data class BusinessSettings(
    @PrimaryKey
    val id: Int = 1,
    val businessName: String = "CredPay Cash",
    val defaultWithdrawalPlatformFeePercent: Double = 1.5,
    val defaultWithdrawalCommissionPercent: Double = 0.2,
    val defaultWithdrawalTransactionCharge: Double = 20.0,
    val defaultWithdrawalRetainChargeAsIncome: Boolean = true,
    val defaultBillPlatformFeePercent: Double = 1.5,
    val defaultBillServiceChargePercent: Double = 1.5,
    val defaultBillCommissionPercent: Double = 0.2,
    val isGstEnabled: Boolean = true,
    val defaultGstRatePercent: Double = 18.0,
    val isGstOnCommission: Boolean = true,
    val isGstOnServiceCharge: Boolean = true,
    val isInputTaxCreditEnabled: Boolean = true,
    val currencySymbol: String = "₹"
)
