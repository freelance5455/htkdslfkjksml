package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "history_items")
data class HistoryEntity(
    @PrimaryKey val id: String,
    val source: String,
    val type: String,
    val title: String,
    val author: String,
    val mediaUrl: String,
    val previewUrl: String,
    val caption: String,
    val tagsRaw: String, // comma separated
    val viewedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "liked_items")
data class LikedEntity(
    @PrimaryKey val id: String,
    val source: String,
    val type: String,
    val title: String,
    val author: String,
    val mediaUrl: String,
    val previewUrl: String,
    val caption: String,
    val tagsRaw: String,
    val likedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_items")
data class FavoriteEntity(
    @PrimaryKey val id: String,
    val source: String, // segregated by platform
    val type: String,
    val title: String,
    val author: String,
    val mediaUrl: String,
    val previewUrl: String,
    val caption: String,
    val tagsRaw: String,
    val favoritedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "downloaded_items")
data class DownloadedEntity(
    @PrimaryKey val id: String,
    val localFilePath: String,
    val source: String,
    val type: String,
    val title: String,
    val author: String,
    val previewUrl: String,
    val fileSize: Long = 0,
    val downloadedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_comments")
data class UserCommentEntity(
    @PrimaryKey val id: String,
    val postId: String,
    val postTitle: String,
    val source: String,
    val commentText: String,
    val createdTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "algorithm_tag_weights")
data class AlgorithmTagEntity(
    @PrimaryKey val tag: String,
    val weight: Float,
    val occurrences: Int = 1,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Dao
interface MediaDao {
    // History queries (max 100 enforced)
    @Query("SELECT * FROM history_items ORDER BY viewedTimestamp DESC LIMIT 100")
    fun getHistory(): Flow<List<HistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(item: HistoryEntity)

    @Query("DELETE FROM history_items WHERE id NOT IN (SELECT id FROM history_items ORDER BY viewedTimestamp DESC LIMIT 100)")
    suspend fun pruneHistoryTo100()

    // Liked queries
    @Query("SELECT * FROM liked_items ORDER BY likedTimestamp DESC")
    fun getLikedItems(): Flow<List<LikedEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM liked_items WHERE id = :id)")
    suspend fun isLiked(id: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLiked(item: LikedEntity)

    @Query("DELETE FROM liked_items WHERE id = :id")
    suspend fun removeLiked(id: String)

    // Favorite queries
    @Query("SELECT * FROM favorite_items ORDER BY favoritedTimestamp DESC")
    fun getFavoriteItems(): Flow<List<FavoriteEntity>>

    @Query("SELECT * FROM favorite_items WHERE source = :source ORDER BY favoritedTimestamp DESC")
    fun getFavoritesBySource(source: String): Flow<List<FavoriteEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_items WHERE id = :id)")
    suspend fun isFavorited(id: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(item: FavoriteEntity)

    @Query("DELETE FROM favorite_items WHERE id = :id")
    suspend fun removeFavorite(id: String)

    // Download queries
    @Query("SELECT * FROM downloaded_items ORDER BY downloadedTimestamp DESC")
    fun getDownloadedItems(): Flow<List<DownloadedEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownloaded(item: DownloadedEntity)

    @Query("DELETE FROM downloaded_items WHERE id = :id")
    suspend fun deleteDownloaded(id: String)

    // Comments queries
    @Query("SELECT * FROM user_comments ORDER BY createdTimestamp DESC")
    fun getUserComments(): Flow<List<UserCommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserComment(comment: UserCommentEntity)

    // Algorithm queries
    @Query("SELECT * FROM algorithm_tag_weights ORDER BY weight DESC LIMIT 200")
    fun getAlgorithmTags(): Flow<List<AlgorithmTagEntity>>

    @Query("SELECT * FROM algorithm_tag_weights ORDER BY weight DESC LIMIT 200")
    suspend fun getAlgorithmTagsSnapshot(): List<AlgorithmTagEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAlgorithmTag(tagEntity: AlgorithmTagEntity)
}

@Database(
    entities = [
        HistoryEntity::class,
        LikedEntity::class,
        FavoriteEntity::class,
        DownloadedEntity::class,
        UserCommentEntity::class,
        AlgorithmTagEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun mediaDao(): MediaDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "yiffy_master.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
