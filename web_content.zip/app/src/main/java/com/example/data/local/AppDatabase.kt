package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CareLogEntity::class,
        DiaryEntryEntity::class,
        CycleLogEntity::class,
        VitalityLogEntity::class,
        HormoneCheckEntity::class,
        EmergencyContactEntity::class,
        SosMessageEntity::class,
        ReminderScheduleEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun havenDao(): HavenDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "haven_wellness.db"
                ).fallbackToDestructiveMigration(true)
                    .build()
                    .also { instance = it }
            }
        }
    }
}
