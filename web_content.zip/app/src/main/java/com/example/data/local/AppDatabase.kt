package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.*

@Database(
  entities = [
    Airport::class,
    FavoriteAirport::class,
    RecentAirport::class,
    MetarData::class,
    TafData::class,
    SigmetData::class,
    SnowtamData::class
  ],
  version = 1,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun airportDao(): AirportDao
  abstract fun favoriteDao(): FavoriteDao
  abstract fun weatherCacheDao(): WeatherCacheDao
  abstract fun snowtamDao(): SnowtamDao

  companion object {
    @Volatile
    private var INSTANCE: AppDatabase? = null

    fun getDatabase(context: Context): AppDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          AppDatabase::class.java,
          "atc_aviation_weather.db"
        ).fallbackToDestructiveMigration().build()
        INSTANCE = instance
        instance
      }
    }
  }
}
