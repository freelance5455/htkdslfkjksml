package com.example.data.repository

import android.content.Context
import com.example.data.local.CommitteeDao
import com.example.data.local.CommitteeEntity
import com.example.data.local.MemberDao
import com.example.data.local.MemberEntity
import com.example.ui.model.CharghatData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MemberRepository(
    private val memberDao: MemberDao,
    private val committeeDao: CommitteeDao? = null,
    private val context: Context
) {
    // Secondary constructor for backward compatibility
    constructor(memberDao: MemberDao, context: Context) : this(memberDao, null, context)

    private val prefs = context.getSharedPreferences("charghat_bsl_prefs", Context.MODE_PRIVATE)

    val allMembers: Flow<List<MemberEntity>> = memberDao.getAllMembers()
    val allCommittees: Flow<List<CommitteeEntity>> = committeeDao?.getAllCommittees() ?: emptyFlow()

    val totalMembersCount: Flow<Int> = memberDao.getTotalCount()
    val leaderCount: Flow<Int> = memberDao.getLeaderCount()
    val workerCount: Flow<Int> = memberDao.getWorkerCount()

    suspend fun insertMember(member: MemberEntity): Long {
        val id = memberDao.insert(member)
        // Also persist to dedicated committee table if this is a leadership/committee record
        if (member.type == "leader" && committeeDao != null) {
            val committee = CommitteeEntity(
                unit = member.union,
                sovapotiName = member.sovapotiName,
                sovapotiMobile = member.sovapotiMobile,
                sovapotiFb = member.sovapotiFb,
                secretaryName = member.secretaryName,
                secretaryMobile = member.secretaryMobile,
                secretaryFb = member.secretaryFb,
                otherDesignation = member.otherDesignation,
                otherName = member.otherName,
                otherMobile = member.otherMobile,
                otherFb = member.otherFb,
                createdAt = member.createdAt,
                timestamp = member.timestamp,
                syncedToSheet = member.syncedToSheet
            )
            committeeDao.insert(committee)
        }
        return id
    }

    suspend fun insertCommittee(committee: CommitteeEntity): Long {
        return committeeDao?.insert(committee) ?: 0L
    }

    suspend fun deleteMember(member: MemberEntity) = memberDao.delete(member)

    suspend fun deleteById(id: Long) = memberDao.deleteById(id)

    suspend fun clearAll() {
        memberDao.clearAll()
        committeeDao?.clearAll()
    }

    suspend fun markSynced(id: Long, synced: Boolean = true) = memberDao.markSynced(id, synced)

    fun getAdminPin(): String {
        return prefs.getString("admin_pin", CharghatData.DEFAULT_ADMIN_PIN) ?: CharghatData.DEFAULT_ADMIN_PIN
    }

    fun setAdminPin(newPin: String) {
        prefs.edit().putString("admin_pin", newPin.trim()).apply()
    }

    fun getWebhookUrl(): String {
        return prefs.getString("sheet_webhook_url", "") ?: ""
    }

    fun setWebhookUrl(url: String) {
        prefs.edit().putString("sheet_webhook_url", url.trim()).apply()
    }

    suspend fun loadSampleData() {
        val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
        val sampleList = listOf(
            MemberEntity(
                type = "leader",
                union = "চারঘাট উপজেলা ছাত্রলীগ",
                ward = "১নং ওয়ার্ড",
                sovapotiName = "মোঃ আরিফুল ইসলাম",
                sovapotiMobile = "01712345678",
                sovapotiFb = "https://facebook.com/ariful.bsl",
                secretaryName = "হাসিবুর রহমান",
                secretaryMobile = "01723456789",
                secretaryFb = "https://facebook.com/hasibur.bsl",
                otherDesignation = "সাংগঠনিক সম্পাদক",
                otherName = "কামরুল হাসান",
                otherMobile = "01734567890",
                otherFb = "https://facebook.com/kamrul.bsl",
                createdAt = today
            ),
            MemberEntity(
                type = "leader",
                union = "চারঘাট পৌরসভা ছাত্রলীগ",
                ward = "৩নং ওয়ার্ড",
                sovapotiName = "শাহারিয়ার আহমেদ",
                sovapotiMobile = "01745678901",
                sovapotiFb = "https://facebook.com/shahariar.bsl",
                secretaryName = "তানভীর হাসান",
                secretaryMobile = "01756789012",
                secretaryFb = "https://facebook.com/tanvir.bsl",
                otherDesignation = "যুগ্ম সাধারণ সম্পাদক",
                otherName = "রিফাত মাহমুদ",
                otherMobile = "01767890123",
                otherFb = "",
                createdAt = today
            ),
            MemberEntity(
                type = "worker",
                union = "সরদহ ইউনিয়ন ছাত্রলীগ",
                ward = "২নং ওয়ার্ড",
                workerName = "শাকিল আহমেদ",
                workerDesignation = "সক্রিয় কর্মী",
                workerMobile = "01778901234",
                workerFb = "https://facebook.com/shakil.bsl",
                createdAt = today
            ),
            MemberEntity(
                type = "worker",
                union = "ইউসুফপুর ইউনিয়ন ছাত্রলীগ",
                ward = "১নং ওয়ার্ড",
                workerName = "রাকিবুল ইসলাম",
                workerDesignation = "সদস্য",
                workerMobile = "01789012345",
                workerFb = "",
                createdAt = today
            )
        )
        sampleList.forEach { insertMember(it) }
    }

    /**
     * Generates a clean, UTF-8 CSV with Byte Order Mark (BOM) so Bengali characters
     * open perfectly without distortion in Excel, Google Sheets, and mobile viewers.
     * Uses a unified tabular layout:
     * ক্রমিক, রেকর্ড আইডি, ক্যাটাগরি, ইউনিট/শাখা, ওয়ার্ড, পদবী, নাম, মোবাইল নম্বর, ফেসবুক আইডি/লিংক, এন্ট্রি তারিখ
     */
    fun generateCsv(members: List<MemberEntity>): String {
        val sb = StringBuilder()
        sb.append('\uFEFF') // UTF-8 BOM
        sb.append("ক্রমিক,রেকর্ড আইডি,ক্যাটাগরি,ইউনিট/শাখা,ওয়ার্ড,পদবী,নাম,মোবাইল নম্বর,ফেসবুক আইডি/লিংক,এন্ট্রি তারিখ\n")
        var serial = 1

        fun escape(value: String): String = "\"${value.replace("\"", "\"\"")}\""

        fun appendRow(
            recordId: Long,
            category: String,
            unit: String,
            ward: String,
            designation: String,
            name: String,
            mobile: String,
            fb: String,
            date: String
        ) {
            sb.append("${serial++},")
            sb.append("${recordId},")
            sb.append("${escape(category)},")
            sb.append("${escape(unit)},")
            sb.append("${escape(ward)},")
            sb.append("${escape(designation)},")
            sb.append("${escape(name)},")
            sb.append("${escape(mobile)},")
            sb.append("${escape(fb)},")
            sb.append("${escape(date)}\n")
        }

        members.forEach { m ->
            if (m.type == "leader") {
                val cat = "দায়িত্বপ্রাপ্ত নেতা"
                if (m.otherDesignation.isNotBlank() || m.otherName.isNotBlank()) {
                    appendRow(
                        recordId = m.id,
                        category = cat,
                        unit = m.union,
                        ward = m.ward,
                        designation = m.otherDesignation.ifBlank { "দায়িত্বপ্রাপ্ত নেতা" },
                        name = m.otherName,
                        mobile = m.otherMobile,
                        fb = m.otherFb,
                        date = m.createdAt
                    )
                } else {
                    var hasLeader = false
                    if (m.sovapotiName.isNotBlank() || m.sovapotiMobile.isNotBlank()) {
                        hasLeader = true
                        appendRow(
                            recordId = m.id,
                            category = cat,
                            unit = m.union,
                            ward = m.ward,
                            designation = "সভাপতি",
                            name = m.sovapotiName,
                            mobile = m.sovapotiMobile,
                            fb = m.sovapotiFb,
                            date = m.createdAt
                        )
                    }
                    if (m.secretaryName.isNotBlank() || m.secretaryMobile.isNotBlank()) {
                        hasLeader = true
                        appendRow(
                            recordId = m.id,
                            category = cat,
                            unit = m.union,
                            ward = m.ward,
                            designation = "সাধারণ সম্পাদক",
                            name = m.secretaryName,
                            mobile = m.secretaryMobile,
                            fb = m.secretaryFb,
                            date = m.createdAt
                        )
                    }
                    if (!hasLeader) {
                        appendRow(
                            recordId = m.id,
                            category = cat,
                            unit = m.union,
                            ward = m.ward,
                            designation = "দায়িত্বপ্রাপ্ত নেতা",
                            name = "",
                            mobile = "",
                            fb = "",
                            date = m.createdAt
                        )
                    }
                }
            } else {
                appendRow(
                    recordId = m.id,
                    category = "সাধারণ কর্মী",
                    unit = m.union,
                    ward = m.ward,
                    designation = m.workerDesignation.ifBlank { "সাধারণ কর্মী" },
                    name = m.workerName,
                    mobile = m.workerMobile,
                    fb = m.workerFb,
                    date = m.createdAt
                )
            }
        }
        return sb.toString()
    }
}
