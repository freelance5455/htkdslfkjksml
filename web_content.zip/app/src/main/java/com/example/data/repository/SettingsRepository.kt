package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AiEngineType
import com.example.data.model.AppSettings
import com.example.data.model.AssistantPersona
import com.example.data.model.GeminiModelOption
import com.example.data.model.VoicePreset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("nexus_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        val name = prefs.getString("assistant_name", "NEXUS") ?: "NEXUS"
        val personaStr = prefs.getString("persona", AssistantPersona.OMNI_AI.name)
        val persona = try {
            AssistantPersona.valueOf(personaStr ?: AssistantPersona.OMNI_AI.name)
        } catch (e: Exception) {
            AssistantPersona.OMNI_AI
        }

        val engineStr = prefs.getString("engine_type", AiEngineType.CLOUD.name)
        val engine = try {
            AiEngineType.valueOf(engineStr ?: AiEngineType.CLOUD.name)
        } catch (e: Exception) {
            AiEngineType.CLOUD
        }

        val geminiModelStr = prefs.getString("gemini_model", GeminiModelOption.GEMINI_3_8_FLASH.name)
        val geminiModel = try {
            GeminiModelOption.valueOf(geminiModelStr ?: GeminiModelOption.GEMINI_3_8_FLASH.name)
        } catch (e: Exception) {
            GeminiModelOption.GEMINI_3_8_FLASH
        }
        val customModelId = prefs.getString("custom_gemini_model_id", "") ?: ""

        val voicePresetStr = prefs.getString("voice_preset", VoicePreset.ALISA.name)
        val voicePreset = try {
            VoicePreset.valueOf(voicePresetStr ?: VoicePreset.ALISA.name)
        } catch (e: Exception) {
            VoicePreset.ALISA
        }
        val selectedVoiceName = prefs.getString("selected_voice_name", "") ?: ""
        val useAiNeuralVoice = prefs.getBoolean("use_ai_neural_voice", true)
        val aiTtsVoiceId = prefs.getString("ai_tts_voice_id", voicePreset.aiVoiceId) ?: voicePreset.aiVoiceId

        val speed = prefs.getFloat("voice_speed", voicePreset.defaultRate)
        val pitch = prefs.getFloat("voice_pitch", voicePreset.defaultPitch)
        val autoTts = prefs.getBoolean("auto_tts", true)
        val quantization = prefs.getString("model_quantization", "Q4_K_M (1.5B параметров)") ?: "Q4_K_M (1.5B параметров)"
        val ram = prefs.getInt("allocated_ram_mb", 1450)
        val ggufPath = prefs.getString("external_gguf_path", "") ?: ""

        return AppSettings(
            assistantName = name,
            persona = persona,
            engineType = engine,
            geminiModel = geminiModel,
            customGeminiModelId = customModelId,
            voicePreset = voicePreset,
            selectedVoiceName = selectedVoiceName,
            useAiNeuralVoice = useAiNeuralVoice,
            aiTtsVoiceId = aiTtsVoiceId,
            voiceSpeed = speed,
            voicePitch = pitch,
            autoTts = autoTts,
            modelQuantization = quantization,
            allocatedRamMb = ram,
            externalGgufPath = ggufPath
        )
    }

    fun updateAssistantName(name: String) {
        val safe = name.trim().ifEmpty { "NEXUS" }
        prefs.edit().putString("assistant_name", safe).apply()
        _settings.update { it.copy(assistantName = safe) }
    }

    fun updatePersona(persona: AssistantPersona) {
        prefs.edit().putString("persona", persona.name).apply()
        _settings.update { it.copy(persona = persona) }
    }

    fun updateEngineType(engineType: AiEngineType) {
        prefs.edit().putString("engine_type", engineType.name).apply()
        _settings.update { it.copy(engineType = engineType) }
    }

    fun updateGeminiModel(model: GeminiModelOption) {
        prefs.edit().putString("gemini_model", model.name).apply()
        _settings.update { it.copy(geminiModel = model) }
    }

    fun updateCustomGeminiModelId(modelId: String) {
        val clean = modelId.trim()
        prefs.edit().putString("custom_gemini_model_id", clean).apply()
        _settings.update { it.copy(customGeminiModelId = clean) }
    }

    fun updateVoicePreset(preset: VoicePreset) {
        val editor = prefs.edit().putString("voice_preset", preset.name)
        if (preset != VoicePreset.CUSTOM) {
            editor.putFloat("voice_speed", preset.defaultRate)
            editor.putFloat("voice_pitch", preset.defaultPitch)
            editor.putString("selected_voice_name", "")
            editor.putString("ai_tts_voice_id", preset.aiVoiceId)
        }
        editor.apply()
        _settings.update {
            if (preset != VoicePreset.CUSTOM) {
                it.copy(
                    voicePreset = preset,
                    voiceSpeed = preset.defaultRate,
                    voicePitch = preset.defaultPitch,
                    selectedVoiceName = "",
                    aiTtsVoiceId = preset.aiVoiceId
                )
            } else {
                it.copy(voicePreset = preset)
            }
        }
    }

    fun updateUseAiNeuralVoice(enabled: Boolean) {
        prefs.edit().putBoolean("use_ai_neural_voice", enabled).apply()
        _settings.update { it.copy(useAiNeuralVoice = enabled) }
    }

    fun updateAiTtsVoiceId(voiceId: String) {
        val clean = voiceId.trim().ifBlank { "Kore" }
        prefs.edit().putString("ai_tts_voice_id", clean).apply()
        _settings.update { it.copy(aiTtsVoiceId = clean) }
    }

    fun updateSelectedVoiceName(voiceName: String) {
        prefs.edit().putString("selected_voice_name", voiceName).apply()
        _settings.update { it.copy(selectedVoiceName = voiceName) }
    }

    fun updateVoiceSpeed(speed: Float) {
        prefs.edit().putFloat("voice_speed", speed).apply()
        _settings.update { it.copy(voiceSpeed = speed) }
    }

    fun updateVoicePitch(pitch: Float) {
        prefs.edit().putFloat("voice_pitch", pitch).apply()
        _settings.update { it.copy(voicePitch = pitch) }
    }

    fun updateAutoTts(enabled: Boolean) {
        prefs.edit().putBoolean("auto_tts", enabled).apply()
        _settings.update { it.copy(autoTts = enabled) }
    }

    fun updateQuantization(quant: String) {
        prefs.edit().putString("model_quantization", quant).apply()
        _settings.update { it.copy(modelQuantization = quant) }
    }

    fun updateGgufPath(path: String) {
        prefs.edit().putString("external_gguf_path", path).apply()
        _settings.update { it.copy(externalGgufPath = path) }
    }
}
