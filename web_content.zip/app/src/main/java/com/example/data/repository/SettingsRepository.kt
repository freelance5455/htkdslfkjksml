package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AiEngineType
import com.example.data.model.AppSettings
import com.example.data.model.AssistantPersona
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("nexus_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    private fun loadSettings(): AppSettings {
        val name = prefs.getString("assistant_name", "NEXUS") ?: "NEXUS"
        val personaStr = prefs.getString("persona", AssistantPersona.OMNI_AI.name)
        val persona = try {
            AssistantPersona.valueOf(personaStr ?: AssistantPersona.OMNI_AI.name)
        } catch (e: Exception) {
            AssistantPersona.OMNI_AI
        }

        val engineStr = prefs.getString("engine_type", AiEngineType.CLOUD.name)
        val engine = try {
            AiEngineType.valueOf(engineStr ?: AiEngineType.CLOUD.name)
        } catch (e: Exception) {
            AiEngineType.CLOUD
        }

        val speed = prefs.getFloat("voice_speed", 1.0f)
        val pitch = prefs.getFloat("voice_pitch", 1.0f)
        val autoTts = prefs.getBoolean("auto_tts", true)
        val quantization = prefs.getString("model_quantization", "Q4_K_M (1.5B параметров)") ?: "Q4_K_M (1.5B параметров)"
        val ram = prefs.getInt("allocated_ram_mb", 1450)
        val ggufPath = prefs.getString("external_gguf_path", "") ?: ""

        return AppSettings(
            assistantName = name,
            persona = persona,
            engineType = engine,
            voiceSpeed = speed,
            voicePitch = pitch,
            autoTts = autoTts,
            modelQuantization = quantization,
            allocatedRamMb = ram,
            externalGgufPath = ggufPath
        )
    }

    fun updateAssistantName(name: String) {
        val safe = name.trim().ifEmpty { "NEXUS" }
        prefs.edit().putString("assistant_name", safe).apply()
        _settings.update { it.copy(assistantName = safe) }
    }

    fun updatePersona(persona: AssistantPersona) {
        prefs.edit().putString("persona", persona.name).apply()
        _settings.update { it.copy(persona = persona) }
    }

    fun updateEngineType(engineType: AiEngineType) {
        prefs.edit().putString("engine_type", engineType.name).apply()
        _settings.update { it.copy(engineType = engineType) }
    }

    fun updateVoiceSpeed(speed: Float) {
        prefs.edit().putFloat("voice_speed", speed).apply()
        _settings.update { it.copy(voiceSpeed = speed) }
    }

    fun updateVoicePitch(pitch: Float) {
        prefs.edit().putFloat("voice_pitch", pitch).apply()
        _settings.update { it.copy(voicePitch = pitch) }
    }

    fun updateAutoTts(enabled: Boolean) {
        prefs.edit().putBoolean("auto_tts", enabled).apply()
        _settings.update { it.copy(autoTts = enabled) }
    }

    fun updateQuantization(quant: String) {
        prefs.edit().putString("model_quantization", quant).apply()
        _settings.update { it.copy(modelQuantization = quant) }
    }

    fun updateGgufPath(path: String) {
        prefs.edit().putString("external_gguf_path", path).apply()
        _settings.update { it.copy(externalGgufPath = path) }
    }
}
