package com.example.data.repository

import com.example.data.dao.AppSettingsDao
import com.example.data.model.AppSettingsEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SettingsRepository(
    private val appSettingsDao: AppSettingsDao
) {
    val settingsFlow: Flow<AppSettingsEntity?> = appSettingsDao.getSettingsFlow()

    val isDarkThemeFlow: Flow<Boolean> = settingsFlow.map { settings ->
        settings?.themeMode == AppSettingsEntity.THEME_DARK
    }

    suspend fun setThemeMode(themeMode: String) {
        val validMode = if (themeMode == AppSettingsEntity.THEME_DARK) {
            AppSettingsEntity.THEME_DARK
        } else {
            AppSettingsEntity.THEME_NORMAL
        }
        val settings = AppSettingsEntity(id = 1, themeMode = validMode)
        appSettingsDao.insertOrUpdate(settings)
    }
}
