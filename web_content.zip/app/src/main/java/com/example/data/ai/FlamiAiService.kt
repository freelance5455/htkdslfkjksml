package com.example.data.ai

import android.graphics.Bitmap
import android.util.Log
import com.example.data.model.ChatMessage
import com.example.data.model.ContextualMemory
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class ExtractedMemoryCandidate(
    val shouldSave: Boolean,
    val fact: String,
    val category: String
)

class FlamiAiService {

    private val memorySchema = Schema.obj(
        properties = mapOf(
            "shouldSave" to Schema.boolean(
                description = "True only if the user revealed a durable personal preference, skill level, ongoing project, or profile fact worth remembering across sessions."
            ),
            "fact" to Schema.string(
                description = "A concise single-sentence fact in the user's language (max 140 chars)."
            ),
            "category" to Schema.enumeration(
                values = listOf("preference", "profile", "project", "learning", "general"),
                description = "Memory category"
            )
        )
    )

    private val memoryExtractorModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = memorySchema
                temperature = 0.2f
            }
        )
    }

    private val titleModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = generationConfig {
                temperature = 0.3f
                maxOutputTokens = 32
            }
        )
    }

    fun streamReply(
        history: List<ChatMessage>,
        userPrompt: String,
        attachedBitmap: Bitmap?,
        memories: List<ContextualMemory>,
        preferredLanguage: String,
        modelMode: String
    ): Flow<String> = flow {
        val modelName = when (modelMode) {
            "fast" -> "gemini-3.5-flash-lite"
            else -> "gemini-3.8-flash"
        }

        val systemText = buildSystemInstruction(
            memories = memories.filter { it.isActive },
            preferredLanguage = preferredLanguage,
            reasoningMode = modelMode == "reasoning"
        )

        val config = generationConfig {
            temperature = if (modelMode == "reasoning") 0.35f else 0.7f
        }

        val model = Firebase.ai.generativeModel(
            modelName = modelName,
            generationConfig = config,
            systemInstruction = content { text(systemText) }
        )

        // Include recent conversation turns (excluding empty placeholders or error markers)
        val priorHistory: List<Content> = history
            .filter { !it.isError && it.text.isNotBlank() }
            .takeLast(24)
            .map { msg ->
                val role = if (msg.role == "user") "user" else "model"
                content(role) { text(msg.text) }
            }

        val chat = model.startChat(history = priorHistory)
        val userContent = content("user") {
            if (attachedBitmap != null) {
                image(scaleBitmapForUpload(attachedBitmap))
            }
            val effectivePrompt = userPrompt.ifBlank { "Please analyze the attached image in detail." }
            text(effectivePrompt)
        }

        val accumulated = StringBuilder()
        withTimeout(60_000L) {
            chat.sendMessageStream(userContent).collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    accumulated.append(chunkText)
                    emit(accumulated.toString())
                }
            }
        }
        if (accumulated.isBlank()) {
            throw IllegalStateException("Model returned an empty response.")
        }
    }

    suspend fun extractMemoryIfUseful(
        userMessage: String,
        existingMemories: List<ContextualMemory>
    ): ExtractedMemoryCandidate? {
        if (userMessage.trim().length < 12) return null
        return try {
            val existingList = existingMemories.take(20).joinToString("\n") { "- ${it.fact}" }
            val prompt = """
                Analyze this user message and determine whether it contains a durable personal fact, preference, ongoing project, or learning goal useful for future personalization.
                Do NOT save transient questions, greetings, or facts already covered in the existing memory list.

                Existing memories:
                $existingList

                User message:
                "$userMessage"
            """.trimIndent()

            val response = withTimeout(30_000L) {
                memoryExtractorModel.generateContent(prompt)
            }
            val rawJson = response.text ?: return null
            val obj = JSONObject(rawJson)
            val shouldSave = obj.optBoolean("shouldSave", false)
            val fact = obj.optString("fact", "").trim()
            val category = obj.optString("category", "general").trim()
            if (!shouldSave || fact.isBlank()) return null

            val normalizedFact = fact.lowercase()
            val duplicate = existingMemories.any { it.fact.lowercase() == normalizedFact }
            if (duplicate) return null

            ExtractedMemoryCandidate(
                shouldSave = true,
                fact = fact.take(300),
                category = category
            )
        } catch (e: TimeoutCancellationException) {
            Log.w(AI_TAG, "Memory extraction timed out")
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(AI_TAG, "Memory extraction skipped: ${e.message}")
            null
        }
    }

    suspend fun generateChatTitle(firstUserPrompt: String, preferredLanguage: String): String {
        val fallback = firstUserPrompt.trim().replace('\n', ' ').take(40).ifBlank { "New Chat" }
        return try {
            val langHint = if (preferredLanguage == "auto") "the same language as the prompt" else preferredLanguage
            val prompt = "Write a concise 2 to 5 word title (no quotes, no markdown, no punctuation at the end) in $langHint summarizing: \"$firstUserPrompt\""
            val response = withTimeout(15_000L) {
                titleModel.generateContent(prompt)
            }
            response.text?.trim()?.replace("\"", "")?.take(60)?.ifBlank { fallback } ?: fallback
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            fallback
        }
    }

    private fun buildSystemInstruction(
        memories: List<ContextualMemory>,
        preferredLanguage: String,
        reasoningMode: Boolean
    ): String {
        val languageDirective = when (preferredLanguage) {
            "ru" -> "Always respond in Russian unless the user explicitly asks to write or translate into another language."
            "en" -> "Always respond in English unless the user explicitly asks to write or translate into another language."
            "es" -> "Always respond in Spanish unless the user explicitly asks to write or translate into another language."
            "de" -> "Always respond in German unless the user explicitly asks to write or translate into another language."
            "fr" -> "Always respond in French unless the user explicitly asks to write or translate into another language."
            "uk" -> "Always respond in Ukrainian unless the user explicitly asks to write or translate into another language."
            "zh" -> "Always respond in Simplified Chinese unless the user explicitly asks to write or translate into another language."
            else -> "Detect the language of the user's latest message and respond naturally in that exact language."
        }

        val reasoningDirective = if (reasoningMode) {
            "DEEP REASONING MODE ACTIVE: Break down complex problems step-by-step, verify edge cases, math, and code logic before concluding."
        } else {
            "Adapt answer length to complexity: concise for simple questions, thorough and structured for complex topics."
        }

        val memoryBlock = if (memories.isEmpty()) {
            "No saved user profile facts yet."
        } else {
            memories.take(25).joinToString("\n") { "- [${it.category}] ${it.fact}" }
        }

        return """
            You are FLAMI AI, an intelligent, accurate, and thoughtful AI assistant.

            1. Intelligence & Accuracy:
               - Analyze the user's request carefully before answering.
               - Solve complex tasks, math, and debugging step-by-step.
               - Use the full conversation context across turns without ignoring prior messages.
               - If the user has a misconception or error, explain it politely and clearly.
               - NEVER invent facts, URLs, APIs, or claim to have executed external actions you did not perform.
               - You do NOT have live internet browsing in this session; if asked for real-time news/prices/events beyond your knowledge, honestly state that live web search is unavailable rather than guessing.
            2. Communication Style:
               - Speak naturally and clearly, without robotic filler or unnecessary preambles.
               - Do not overuse emojis.
               - $reasoningDirective
            3. Technical & Creative Capabilities:
               - Analyze text and source code accurately.
               - Write clean, runnable HTML, CSS, JavaScript, Kotlin, Python, and other languages inside fenced code blocks (```html, ```css, ```js, ```kotlin, etc.).
               - When generating web projects intended for export, provide a complete self-contained `index.html` block (and optional `css`/`js` blocks) since FLAMI AI packages ZIP exports with `index.html` at the archive root.
               - Help with learning, tutoring, math proofs, and document drafting.
               - Analyze attached images carefully when provided.
            4. Language:
               - $languageDirective
            5. User Contextual Memory (use naturally to personalize responses when relevant):
               $memoryBlock
        """.trimIndent()
    }

    private fun scaleBitmapForUpload(bitmap: Bitmap): Bitmap {
        val maxDim = 1280
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDim && height <= maxDim) return bitmap
        val ratio = maxDim.toFloat() / maxOf(width, height).toFloat()
        val targetW = (width * ratio).toInt().coerceAtLeast(1)
        val targetH = (height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }

    companion object {
        private const val AI_TAG = "FlamiAiService"
    }
}
