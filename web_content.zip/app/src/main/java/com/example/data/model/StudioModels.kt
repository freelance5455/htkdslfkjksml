package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import org.json.JSONArray
import org.json.JSONObject

enum class AiProvider(
    val id: String,
    val displayName: String,
    val vendorSubtitle: String,
    val endpointHost: String
) {
    OPENAI(
        id = "OPENAI",
        displayName = "OpenAI (ChatGPT)",
        vendorSubtitle = "api.openai.com/v1/chat/completions",
        endpointHost = "https://api.openai.com/"
    ),
    ANTHROPIC(
        id = "ANTHROPIC",
        displayName = "Anthropic (Claude)",
        vendorSubtitle = "api.anthropic.com/v1/messages",
        endpointHost = "https://api.anthropic.com/"
    ),
    GEMINI(
        id = "GEMINI",
        displayName = "Google Gemini",
        vendorSubtitle = "Firebase AI Logic & Gemini API",
        endpointHost = "https://generativelanguage.googleapis.com/"
    );

    companion object {
        fun fromId(id: String): AiProvider =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: GEMINI
    }
}

enum class AiModelOption(
    val modelId: String,
    val firebaseModelName: String,
    val displayName: String,
    val provider: AiProvider,
    val contextBadge: String,
    val architectureNote: String
) {
    GPT_4O(
        modelId = "gpt-4o",
        firebaseModelName = "gpt-4o",
        displayName = "GPT-4o",
        provider = AiProvider.OPENAI,
        contextBadge = "128K Context",
        architectureNote = "High-precision omni model for full-screen Android Compose layouts, responsive websites, and state machines."
    ),
    GPT_4O_MINI(
        modelId = "gpt-4o-mini",
        firebaseModelName = "gpt-4o-mini",
        displayName = "GPT-4o-mini",
        provider = AiProvider.OPENAI,
        contextBadge = "128K Fast",
        architectureNote = "Low-latency OpenAI model optimized for rapid utility prototyping and code generation."
    ),
    CLAUDE_3_5_SONNET(
        modelId = "claude-3-5-sonnet-latest",
        firebaseModelName = "claude-3-5-sonnet-latest",
        displayName = "Claude 3.5 Sonnet",
        provider = AiProvider.ANTHROPIC,
        contextBadge = "200K Context",
        architectureNote = "Anthropic flagship coding model for clean Kotlin architecture, semantic HTML5/CSS3, and modular UI synthesis."
    ),
    GEMINI_4_ARGON(
        modelId = "gemini-4-argon",
        firebaseModelName = "gemini-4-argon",
        displayName = "Gemini 4 Argon",
        provider = AiProvider.GEMINI,
        contextBadge = "Frontier Reasoning",
        architectureNote = "Most capable Google Gemini model for complex multi-file Android & full-stack web engineering."
    ),
    GEMINI_3_5_FLASH(
        modelId = "gemini-3.5-flash",
        firebaseModelName = "gemini-3.5-flash-lite",
        displayName = "Gemini 3.5 Flash",
        provider = AiProvider.GEMINI,
        contextBadge = "Ultra-Low Latency",
        architectureNote = "High-speed Google Gemini 3.5 model for instant interactive sandbox, web, and Kotlin generation."
    );

    companion object {
        fun fromModelId(modelId: String): AiModelOption =
            entries.firstOrNull { it.modelId.equals(modelId, ignoreCase = true) }
                ?: GEMINI_4_ARGON

        fun forProvider(provider: AiProvider): List<AiModelOption> =
            entries.filter { it.provider == provider }
    }
}

enum class WebsiteLayoutPreset(
    val id: String,
    val label: String,
    val subtitle: String,
    val promptDirective: String
) {
    SAAS_LANDING(
        id = "SAAS_LANDING",
        label = "SaaS Product Site",
        subtitle = "Hero, feature grid, interactive ROI calculator, pricing & FAQ",
        promptDirective = "Build a high-converting technical SaaS product website with sticky navigation, value proposition hero, feature grid, interactive pricing/ROI calculator, and FAQ."
    ),
    WEB_UTILITY_APP(
        id = "WEB_UTILITY_APP",
        label = "Interactive Web App",
        subtitle = "Functional single-page calculator, converter, or live dashboard",
        promptDirective = "Build a functional interactive single-page web application with live JavaScript calculation inputs, real-time output cards, and responsive controls."
    ),
    DOCS_PORTAL(
        id = "DOCS_PORTAL",
        label = "Technical Docs & API",
        subtitle = "Architecture overview, endpoint specs, interactive request builder",
        promptDirective = "Build a clean developer documentation and API portal with structured endpoint cards, parameter tables, and interactive configuration toggles."
    ),
    PORTFOLIO_SHOWCASE(
        id = "PORTFOLIO_SHOWCASE",
        label = "Engineering Showcase",
        subtitle = "Case studies, system metrics, architecture stack & contact form",
        promptDirective = "Build an engineering case-study showcase website with quantified performance metrics, technical stack breakdown, and interactive project estimator."
    );

    companion object {
        fun fromId(id: String): WebsiteLayoutPreset =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: SAAS_LANDING
    }
}

enum class WebsiteThemePalette(
    val id: String,
    val label: String,
    val bgHex: String,
    val surfaceHex: String,
    val primaryHex: String,
    val secondaryHex: String,
    val textHex: String
) {
    OBSIDIAN_CYAN(
        id = "OBSIDIAN_CYAN",
        label = "Obsidian & Cyan",
        bgHex = "#0B0F17",
        surfaceHex = "#151D2A",
        primaryHex = "#38BDF8",
        secondaryHex = "#818CF8",
        textHex = "#F1F5F9"
    ),
    EMERALD_FINTECH(
        id = "EMERALD_FINTECH",
        label = "Emerald Terminal",
        bgHex = "#071410",
        surfaceHex = "#10241E",
        primaryHex = "#34D399",
        secondaryHex = "#2DD4BF",
        textHex = "#ECFDF5"
    ),
    AMBER_INDUSTRIAL(
        id = "AMBER_INDUSTRIAL",
        label = "Amber Forge",
        bgHex = "#12100E",
        surfaceHex = "#1E1B18",
        primaryHex = "#F59E0B",
        secondaryHex = "#FB7185",
        textHex = "#FEF3C7"
    ),
    DAYLIGHT_SLATE(
        id = "DAYLIGHT_SLATE",
        label = "Daylight Slate",
        bgHex = "#F8FAFC",
        surfaceHex = "#FFFFFF",
        primaryHex = "#0284C7",
        secondaryHex = "#4F46E5",
        textHex = "#0F172A"
    );

    companion object {
        fun fromId(id: String): WebsiteThemePalette =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: OBSIDIAN_CYAN
    }
}

@IgnoreExtraProperties
data class StudioProject(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val prompt: String = "",
    val provider: String = AiProvider.GEMINI.id,
    val modelId: String = AiModelOption.GEMINI_4_ARGON.modelId,
    val summary: String = "",
    val sandboxSpecJson: String = "",
    val kotlinCode: String = "",
    val manifestXml: String = "",
    val buildGradleKts: String = "",
    val isPinned: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun isWebsiteProject(): Boolean {
        return try {
            if (sandboxSpecJson.isBlank()) return false
            val obj = JSONObject(sandboxSpecJson)
            obj.optString("projectTarget", "").equals("WEBSITE", ignoreCase = true)
        } catch (_: Exception) {
            false
        }
    }
}

data class WebsiteSectionSpec(
    val id: String,
    val sectionType: String, // "HERO", "FEATURE_GRID", "INTERACTIVE_CALCULATOR", "PRICING_MATRIX", "FAQ_ACCORDION", "CTA_BANNER"
    val heading: String,
    val subheading: String,
    val badge: String = "",
    val items: List<String> = emptyList()
)

data class WebsiteSpec(
    val siteTitle: String,
    val tagline: String,
    val layoutPresetId: String,
    val themePaletteId: String,
    val primaryColorHex: String,
    val secondaryColorHex: String,
    val seoMetaDescription: String,
    val navLinks: List<String>,
    val heroHeadline: String,
    val heroSubheadline: String,
    val heroCtaLabel: String,
    val calculatorLabel: String,
    val calculatorUnit: String,
    val calculatorMultiplier: Float,
    val sections: List<WebsiteSectionSpec>
) {
    fun toJsonString(): String {
        val root = JSONObject()
        root.put("projectTarget", "WEBSITE")
        root.put("appTitle", siteTitle)
        root.put("siteTitle", siteTitle)
        root.put("tagline", tagline)
        root.put("layoutPresetId", layoutPresetId)
        root.put("themePaletteId", themePaletteId)
        root.put("themeAccentHex", primaryColorHex)
        root.put("primaryColorHex", primaryColorHex)
        root.put("secondaryColorHex", secondaryColorHex)
        root.put("seoMetaDescription", seoMetaDescription)
        root.put("heroHeadline", heroHeadline)
        root.put("heroSubheadline", heroSubheadline)
        root.put("heroCtaLabel", heroCtaLabel)
        root.put("primaryFormulaLabel", calculatorLabel)
        root.put("calculatorLabel", calculatorLabel)
        root.put("primaryFormulaUnit", calculatorUnit)
        root.put("calculatorUnit", calculatorUnit)
        root.put("calculatorMultiplier", calculatorMultiplier.toDouble())
        root.put("formulaMode", "MULTIPLY")

        val navArr = JSONArray()
        navLinks.forEach { navArr.put(it) }
        root.put("navLinks", navArr)

        val secArr = JSONArray()
        sections.forEach { sec ->
            val sObj = JSONObject()
            sObj.put("id", sec.id)
            sObj.put("sectionType", sec.sectionType)
            sObj.put("heading", sec.heading)
            sObj.put("subheading", sec.subheading)
            sObj.put("badge", sec.badge)
            val itemsArr = JSONArray()
            sec.items.forEach { itemsArr.put(it) }
            sObj.put("items", itemsArr)
            secArr.put(sObj)
        }
        root.put("sections", secArr)

        // Also populate widgets array so if opened in Android Sandbox tab it works seamlessly
        val widgetsArr = JSONArray()
        widgetsArr.put(
            JSONObject().apply {
                put("id", "web_scale_factor")
                put("type", "SLIDER")
                put("label", calculatorLabel.ifBlank { "Monthly Active Volume" })
                put("subtitle", "Interactive parameter from Website Maker")
                put("defaultValue", "25")
                put("minValue", 1.0)
                put("maxValue", 500.0)
                put("unit", "units")
                put("options", JSONArray())
            }
        )
        widgetsArr.put(
            JSONObject().apply {
                put("id", "web_multiplier")
                put("type", "NUMBER_INPUT")
                put("label", "Unit Rate ($calculatorUnit)")
                put("subtitle", "Conversion factor")
                put("defaultValue", calculatorMultiplier.toString())
                put("minValue", 1.0)
                put("maxValue", 1000.0)
                put("unit", calculatorUnit)
                put("options", JSONArray())
            }
        )
        root.put("widgets", widgetsArr)
        return root.toString()
    }

    companion object {
        fun fromJsonString(jsonStr: String, fallbackTitle: String = "Generated Website"): WebsiteSpec {
            return try {
                val obj = JSONObject(jsonStr)
                val navArr = obj.optJSONArray("navLinks") ?: JSONArray()
                val navList = mutableListOf<String>()
                for (i in 0 until navArr.length()) {
                    val item = navArr.optString(i).trim()
                    if (item.isNotEmpty()) navList.add(item)
                }

                val secArr = obj.optJSONArray("sections") ?: JSONArray()
                val secList = mutableListOf<WebsiteSectionSpec>()
                for (i in 0 until secArr.length()) {
                    val sObj = secArr.optJSONObject(i) ?: continue
                    val itemsArr = sObj.optJSONArray("items") ?: JSONArray()
                    val items = mutableListOf<String>()
                    for (j in 0 until itemsArr.length()) {
                        val itStr = itemsArr.optString(j).trim()
                        if (itStr.isNotEmpty()) items.add(itStr)
                    }
                    secList.add(
                        WebsiteSectionSpec(
                            id = sObj.optString("id", "section_$i"),
                            sectionType = sObj.optString("sectionType", "FEATURE_GRID"),
                            heading = sObj.optString("heading", "Section ${i + 1}"),
                            subheading = sObj.optString("subheading", ""),
                            badge = sObj.optString("badge", "MODULE"),
                            items = items
                        )
                    )
                }

                val palette = WebsiteThemePalette.fromId(obj.optString("themePaletteId", "OBSIDIAN_CYAN"))
                val title = obj.optString("siteTitle", obj.optString("appTitle", fallbackTitle)).ifBlank { fallbackTitle }
                WebsiteSpec(
                    siteTitle = title,
                    tagline = obj.optString("tagline", "Responsive HTML5 + CSS3 + JS Web Application"),
                    layoutPresetId = obj.optString("layoutPresetId", WebsiteLayoutPreset.SAAS_LANDING.id),
                    themePaletteId = palette.id,
                    primaryColorHex = obj.optString("primaryColorHex", palette.primaryHex),
                    secondaryColorHex = obj.optString("secondaryColorHex", palette.secondaryHex),
                    seoMetaDescription = obj.optString(
                        "seoMetaDescription",
                        "Production-grade responsive web platform for $title."
                    ),
                    navLinks = if (navList.isNotEmpty()) navList else listOf("Overview", "Features", "Calculator", "Specifications"),
                    heroHeadline = obj.optString("heroHeadline", title),
                    heroSubheadline = obj.optString("heroSubheadline", obj.optString("tagline", "Built with OmniPrompt Website Maker.")),
                    heroCtaLabel = obj.optString("heroCtaLabel", "Launch Interactive Tool"),
                    calculatorLabel = obj.optString("calculatorLabel", "Projected Output"),
                    calculatorUnit = obj.optString("calculatorUnit", "USD"),
                    calculatorMultiplier = obj.optDouble("calculatorMultiplier", 12.5).toFloat(),
                    sections = secList
                )
            } catch (_: Exception) {
                WebsiteSpec(
                    siteTitle = fallbackTitle,
                    tagline = "Responsive Web Application",
                    layoutPresetId = WebsiteLayoutPreset.SAAS_LANDING.id,
                    themePaletteId = WebsiteThemePalette.OBSIDIAN_CYAN.id,
                    primaryColorHex = "#38BDF8",
                    secondaryColorHex = "#818CF8",
                    seoMetaDescription = "Responsive web application generated by OmniPrompt Studio.",
                    navLinks = listOf("Overview", "Features", "Calculator", "Specifications"),
                    heroHeadline = fallbackTitle,
                    heroSubheadline = "Responsive mobile-first web architecture.",
                    heroCtaLabel = "Get Started",
                    calculatorLabel = "Estimated Value",
                    calculatorUnit = "units",
                    calculatorMultiplier = 10f,
                    sections = emptyList()
                )
            }
        }
    }
}

data class SandboxSpec(
    val appTitle: String,
    val tagline: String,
    val themeAccentHex: String,
    val primaryFormulaLabel: String,
    val primaryFormulaUnit: String,
    val formulaMode: String, // "MULTIPLY", "ADD", "RATIO", "COMPOUND", "CUSTOM_SCORE"
    val widgets: List<SandboxWidget>
) {
    fun toJsonString(): String {
        val root = JSONObject()
        root.put("projectTarget", "ANDROID_APP")
        root.put("appTitle", appTitle)
        root.put("tagline", tagline)
        root.put("themeAccentHex", themeAccentHex)
        root.put("primaryFormulaLabel", primaryFormulaLabel)
        root.put("primaryFormulaUnit", primaryFormulaUnit)
        root.put("formulaMode", formulaMode)
        val arr = JSONArray()
        widgets.forEach { w ->
            val obj = JSONObject()
            obj.put("id", w.id)
            obj.put("type", w.type)
            obj.put("label", w.label)
            obj.put("subtitle", w.subtitle)
            obj.put("defaultValue", w.defaultValue)
            obj.put("minValue", w.minValue)
            obj.put("maxValue", w.maxValue)
            obj.put("unit", w.unit)
            val opts = JSONArray()
            w.options.forEach { opts.put(it) }
            obj.put("options", opts)
            arr.put(obj)
        }
        root.put("widgets", arr)
        return root.toString()
    }

    companion object {
        fun fromJsonString(jsonStr: String, fallbackTitle: String = "Generated App"): SandboxSpec {
            return try {
                val obj = JSONObject(jsonStr)
                val widgetsArr = obj.optJSONArray("widgets") ?: JSONArray()
                val parsedWidgets = mutableListOf<SandboxWidget>()
                for (i in 0 until widgetsArr.length()) {
                    val wObj = widgetsArr.optJSONObject(i) ?: continue
                    val optsArr = wObj.optJSONArray("options") ?: JSONArray()
                    val opts = mutableListOf<String>()
                    for (j in 0 until optsArr.length()) {
                        opts.add(optsArr.optString(j))
                    }
                    parsedWidgets.add(
                        SandboxWidget(
                            id = wObj.optString("id", "widget_$i"),
                            type = wObj.optString("type", "TEXT_INPUT"),
                            label = wObj.optString("label", "Input ${i + 1}"),
                            subtitle = wObj.optString("subtitle", ""),
                            defaultValue = wObj.optString("defaultValue", ""),
                            minValue = wObj.optDouble("minValue", 0.0).toFloat(),
                            maxValue = wObj.optDouble("maxValue", 100.0).toFloat(),
                            unit = wObj.optString("unit", ""),
                            options = opts
                        )
                    )
                }
                SandboxSpec(
                    appTitle = obj.optString("appTitle", fallbackTitle).ifBlank { fallbackTitle },
                    tagline = obj.optString("tagline", "Interactive Native Compose Sandbox"),
                    themeAccentHex = obj.optString("themeAccentHex", "#38BDF8"),
                    primaryFormulaLabel = obj.optString("primaryFormulaLabel", "Computed Result"),
                    primaryFormulaUnit = obj.optString("primaryFormulaUnit", "pts"),
                    formulaMode = obj.optString("formulaMode", "MULTIPLY"),
                    widgets = parsedWidgets
                )
            } catch (e: Exception) {
                SandboxSpec(
                    appTitle = fallbackTitle,
                    tagline = "Interactive Native Compose Sandbox",
                    themeAccentHex = "#38BDF8",
                    primaryFormulaLabel = "Live Output",
                    primaryFormulaUnit = "units",
                    formulaMode = "MULTIPLY",
                    widgets = emptyList()
                )
            }
        }
    }
}

data class SandboxWidget(
    val id: String,
    val type: String, // "SLIDER", "NUMBER_INPUT", "TEXT_INPUT", "TOGGLE", "SEGMENTED", "CHECKLIST", "METRIC_CARD", "ACTION_BUTTON"
    val label: String,
    val subtitle: String = "",
    val defaultValue: String = "",
    val minValue: Float = 0f,
    val maxValue: Float = 100f,
    val unit: String = "",
    val options: List<String> = emptyList()
)

enum class SubscriptionTier(
    val planId: String,
    val displayName: String,
    val priceDisplay: String,
    val inrPriceDisplay: String,
    val inrAmountValue: String,
    val unitAmountCents: Int,
    val billingInterval: String, // "month" or "year"
    val monthlyGenerationLimit: Int,
    val features: List<String>
) {
    FREE(
        planId = "FREE",
        displayName = "Free Starter Plan",
        priceDisplay = "₹0 / month",
        inrPriceDisplay = "₹0 / month",
        inrAmountValue = "0.00",
        unitAmountCents = 0,
        billingInterval = "month",
        monthlyGenerationLimit = 5,
        features = listOf(
            "5 AI Android App & Website syntheses per month",
            "Standard multi-model routing (Gemini, OpenAI, Anthropic)",
            "Live Native Sandbox & HTML5 WebView preview",
            "Standard .zip project archive export"
        )
    ),
    PRO_MONTHLY(
        planId = "PRO_MONTHLY",
        displayName = "Pro Monthly Premium",
        priceDisplay = "₹49 / month",
        inrPriceDisplay = "₹49 / month",
        inrAmountValue = "49.00",
        unitAmountCents = 4900,
        billingInterval = "month",
        monthlyGenerationLimit = 250,
        features = listOf(
            "250 AI Android App & Website syntheses per month",
            "Unlocks Frontier AI Models (Gemini 4 Argon, Claude 3.5 Sonnet, GPT-4o)",
            "Unlocks Unlimited Iterative AI Refinements & Custom Sandbox Widgets",
            "Unlocks Full 8-File Gradle & Netlify/Vercel Static Web Bundle Export"
        )
    ),
    ENTERPRISE_ANNUAL(
        planId = "ENTERPRISE_ANNUAL",
        displayName = "Studio Annual VIP (Save 50%)",
        priceDisplay = "₹299 / year",
        inrPriceDisplay = "₹299 / year",
        inrAmountValue = "299.00",
        unitAmountCents = 29900,
        billingInterval = "year",
        monthlyGenerationLimit = 2500,
        features = listOf(
            "2,500 AI Android App & Website syntheses per month",
            "Unlocks All Frontier Models + Custom Temperature & Token Controls",
            "Unlocks Unlimited Automated Code & SEO Compliance Audits",
            "Instant Premium Unlock via UPI Transaction ID or Direct Card Payment"
        )
    );

    companion object {
        fun fromPlanId(planId: String): SubscriptionTier =
            entries.firstOrNull { it.planId.equals(planId, ignoreCase = true) } ?: FREE
    }
}

@IgnoreExtraProperties
data class UserSubscription(
    val userId: String = "",
    val planId: String = SubscriptionTier.FREE.planId,
    val status: String = "FREE_TIER",
    val stripeSessionId: String = "",
    val stripeSubscriptionId: String = "",
    val stripeCustomerEmail: String = "",
    val monthlyGenerationsUsed: Int = 0,
    val monthlyGenerationLimit: Int = SubscriptionTier.FREE.monthlyGenerationLimit,
    val currentPeriodEndEpochSec: Long = 0L,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val tier: SubscriptionTier
        get() = SubscriptionTier.fromPlanId(planId)

    val isPaidActive: Boolean
        get() = (planId == SubscriptionTier.PRO_MONTHLY.planId || planId == SubscriptionTier.ENTERPRISE_ANNUAL.planId) &&
            (status.equals("ACTIVE", ignoreCase = true) || status.equals("TRIALING", ignoreCase = true))

    val remainingGenerations: Int
        get() = (monthlyGenerationLimit - monthlyGenerationsUsed).coerceAtLeast(0)
}

