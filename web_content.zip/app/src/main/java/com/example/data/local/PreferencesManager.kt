package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.FocusStats
import com.example.util.DateTimeUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "thanaweya_prefs")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val EXAM_DATE = stringPreferencesKey("exam_date")
        val FOCUS_DATE = stringPreferencesKey("focus_date")
        val FOCUS_SESSIONS = intPreferencesKey("focus_sessions")
        val FOCUS_MINUTES = intPreferencesKey("focus_minutes")
        val IS_SEEDED = booleanPreferencesKey("is_seeded")
    }

    val isDarkTheme: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.DARK_THEME] ?: true
    }

    val examDate: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.EXAM_DATE] ?: "2027-06-12"
    }

    val focusStats: Flow<FocusStats> = context.dataStore.data.map { prefs ->
        val today = DateTimeUtils.todayIsoKey()
        val savedDate = prefs[Keys.FOCUS_DATE] ?: today
        if (savedDate == today) {
            FocusStats(
                date = today,
                sessions = prefs[Keys.FOCUS_SESSIONS] ?: 0,
                minutes = prefs[Keys.FOCUS_MINUTES] ?: 0
            )
        } else {
            FocusStats(date = today, sessions = 0, minutes = 0)
        }
    }

    suspend fun isSeeded(): Boolean = context.dataStore.data.first()[Keys.IS_SEEDED] ?: false

    suspend fun markSeeded() {
        context.dataStore.edit { it[Keys.IS_SEEDED] = true }
    }

    suspend fun setDarkTheme(isDark: Boolean) {
        context.dataStore.edit { it[Keys.DARK_THEME] = isDark }
    }

    suspend fun setExamDate(dateIso: String) {
        context.dataStore.edit { it[Keys.EXAM_DATE] = dateIso }
    }

    suspend fun recordFocusSession(minutesToAdd: Int) {
        val today = DateTimeUtils.todayIsoKey()
        context.dataStore.edit { prefs ->
            val savedDate = prefs[Keys.FOCUS_DATE]
            if (savedDate == today) {
                prefs[Keys.FOCUS_SESSIONS] = (prefs[Keys.FOCUS_SESSIONS] ?: 0) + 1
                prefs[Keys.FOCUS_MINUTES] = (prefs[Keys.FOCUS_MINUTES] ?: 0) + minutesToAdd
            } else {
                prefs[Keys.FOCUS_DATE] = today
                prefs[Keys.FOCUS_SESSIONS] = 1
                prefs[Keys.FOCUS_MINUTES] = minutesToAdd
            }
        }
    }
}
