package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("suesa_ai_preferences", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"
        private const val KEY_TTS_AUTO_SPEAK = "tts_auto_speak"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_WEB_SEARCH_ENABLED = "web_search_enabled"
        private const val KEY_ACTIVE_SESSION_ID = "active_session_id"
    }

    fun isWebSearchEnabled(): Boolean {
        return prefs.getBoolean(KEY_WEB_SEARCH_ENABLED, true)
    }

    fun setWebSearchEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WEB_SEARCH_ENABLED, enabled).apply()
    }

    fun getEffectiveApiKey(): String {
        val custom = getCustomApiKey()
        if (custom.isNotBlank()) {
            return custom.trim()
        }
        val buildKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }
        return if (buildKey != "MY_GEMINI_API_KEY" && buildKey.isNotBlank()) {
            buildKey.trim()
        } else {
            ""
        }
    }

    fun getCustomApiKey(): String {
        return prefs.getString(KEY_CUSTOM_API_KEY, "") ?: ""
    }

    fun setCustomApiKey(key: String) {
        prefs.edit().putString(KEY_CUSTOM_API_KEY, key.trim()).apply()
    }

    fun isTtsAutoSpeakEnabled(): Boolean {
        return prefs.getBoolean(KEY_TTS_AUTO_SPEAK, false)
    }

    fun setTtsAutoSpeakEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_TTS_AUTO_SPEAK, enabled).apply()
    }

    fun getSpeechRate(): Float {
        return prefs.getFloat(KEY_SPEECH_RATE, 1.0f)
    }

    fun setSpeechRate(rate: Float) {
        prefs.edit().putFloat(KEY_SPEECH_RATE, rate).apply()
    }

    fun getActiveSessionId(): Long {
        return prefs.getLong(KEY_ACTIVE_SESSION_ID, -1L)
    }

    fun setActiveSessionId(sessionId: Long) {
        prefs.edit().putLong(KEY_ACTIVE_SESSION_ID, sessionId).apply()
    }
}
