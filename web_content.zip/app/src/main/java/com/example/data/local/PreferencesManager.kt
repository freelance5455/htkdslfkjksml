package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sd_travel_prefs")

class PreferencesManager(private val context: Context) {

    private val keyLastBackupTime = longPreferencesKey("last_backup_timestamp")
    private val keyLastBackupName = stringPreferencesKey("last_backup_name")

    val lastBackupTimestamp: Flow<Long?> = context.dataStore.data.map { prefs ->
        prefs[keyLastBackupTime]
    }

    val lastBackupName: Flow<String?> = context.dataStore.data.map { prefs ->
        prefs[keyLastBackupName]
    }

    suspend fun recordBackup(timestamp: Long, fileName: String) {
        context.dataStore.edit { prefs ->
            prefs[keyLastBackupTime] = timestamp
            prefs[keyLastBackupName] = fileName
        }
    }
}
