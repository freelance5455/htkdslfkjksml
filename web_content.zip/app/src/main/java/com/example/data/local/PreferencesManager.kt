package com.example.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "atc_settings")

enum class ThemeMode {
  SYSTEM, DARK, LIGHT
}

data class AppSettings(
  val themeMode: ThemeMode = ThemeMode.LIGHT,
  val windSpeedUnit: String = "KT", // KT, MPS, KMH
  val tempUnit: String = "C", // C, F
  val pressureUnit: String = "hPa", // hPa, inHg
  val showLocalTimeAlongsideUtc: Boolean = true,
  val autoRefreshMinutes: Int = 15,
  val highlightSpeci: Boolean = true,
  val offlineModeAlert: Boolean = true
)

class PreferencesManager(private val context: Context) {

  private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val WIND_UNIT = stringPreferencesKey("wind_unit")
    val TEMP_UNIT = stringPreferencesKey("temp_unit")
    val PRESSURE_UNIT = stringPreferencesKey("pressure_unit")
    val SHOW_LOCAL_TIME = booleanPreferencesKey("show_local_time")
    val REFRESH_INTERVAL = intPreferencesKey("refresh_interval")
    val HIGHLIGHT_SPECI = booleanPreferencesKey("highlight_speci")
    val OFFLINE_ALERT = booleanPreferencesKey("offline_alert")
  }

  val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
    AppSettings(
      themeMode = try {
        ThemeMode.valueOf(prefs[Keys.THEME_MODE] ?: ThemeMode.LIGHT.name)
      } catch (_: Exception) {
        ThemeMode.LIGHT
      },
      windSpeedUnit = prefs[Keys.WIND_UNIT] ?: "KT",
      tempUnit = prefs[Keys.TEMP_UNIT] ?: "C",
      pressureUnit = prefs[Keys.PRESSURE_UNIT] ?: "hPa",
      showLocalTimeAlongsideUtc = prefs[Keys.SHOW_LOCAL_TIME] ?: true,
      autoRefreshMinutes = prefs[Keys.REFRESH_INTERVAL] ?: 15,
      highlightSpeci = prefs[Keys.HIGHLIGHT_SPECI] ?: true,
      offlineModeAlert = prefs[Keys.OFFLINE_ALERT] ?: true
    )
  }

  suspend fun updateThemeMode(mode: ThemeMode) {
    context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
  }

  suspend fun updateWindUnit(unit: String) {
    context.dataStore.edit { it[Keys.WIND_UNIT] = unit }
  }

  suspend fun updateTempUnit(unit: String) {
    context.dataStore.edit { it[Keys.TEMP_UNIT] = unit }
  }

  suspend fun updatePressureUnit(unit: String) {
    context.dataStore.edit { it[Keys.PRESSURE_UNIT] = unit }
  }

  suspend fun updateShowLocalTime(show: Boolean) {
    context.dataStore.edit { it[Keys.SHOW_LOCAL_TIME] = show }
  }

  suspend fun updateRefreshInterval(minutes: Int) {
    context.dataStore.edit { it[Keys.REFRESH_INTERVAL] = minutes }
  }

  suspend fun updateHighlightSpeci(highlight: Boolean) {
    context.dataStore.edit { it[Keys.HIGHLIGHT_SPECI] = highlight }
  }
}
