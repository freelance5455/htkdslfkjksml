package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class ProjectCategory(val labelFa: String) {
    DEVELOPMENT("توسعه نرم‌افزار"),
    DESIGN("طراحی و تجربه کاربری"),
    MARKETING("بازاریابی و محتوا"),
    BUSINESS("کسب‌وکار و استراتژی"),
    PERSONAL("شخصی و یادگیری");

    companion object {
        fun fromName(name: String): ProjectCategory =
            entries.firstOrNull { it.name == name } ?: DEVELOPMENT
    }
}

enum class ProjectStatus(val labelFa: String) {
    ACTIVE("فعال"),
    ON_HOLD("متوقف"),
    COMPLETED("تکمیل‌شده"),
    ARCHIVED("بایگانی");

    companion object {
        fun fromName(name: String): ProjectStatus =
            entries.firstOrNull { it.name == name } ?: ACTIVE
    }
}

enum class TaskStatus(val labelFa: String) {
    TODO("در انتظار"),
    IN_PROGRESS("در حال انجام"),
    DONE("انجام‌شده");

    fun next(): TaskStatus = when (this) {
        TODO -> IN_PROGRESS
        IN_PROGRESS -> DONE
        DONE -> TODO
    }

    companion object {
        fun fromName(name: String): TaskStatus =
            entries.firstOrNull { it.name == name } ?: TODO
    }
}

enum class TaskPriority(val labelFa: String, val weight: Int) {
    URGENT("فوری", 4),
    HIGH("بالا", 3),
    MEDIUM("متوسط", 2),
    LOW("عادی", 1);

    companion object {
        fun fromName(name: String): TaskPriority =
            entries.firstOrNull { it.name == name } ?: MEDIUM
    }
}

enum class ThemeMode(val labelFa: String) {
    SYSTEM("خودکار (سیستم)"),
    DARK("حالت تاریک"),
    LIGHT("حالت روشن")
}

enum class ProjectTemplateType(
    val titleFa: String,
    val subtitleFa: String,
    val category: ProjectCategory,
    val colorIndex: Int
) {
    STARTUP_PRODUCT(
        titleFa = "توسعه محصول و اپلیکیشن",
        subtitleFa = "اسپرینت طراحی UI، توسعه بک‌اند، تست و انتشار نسخه",
        category = ProjectCategory.DEVELOPMENT,
        colorIndex = 0
    ),
    SOCIAL_CAMPAIGN(
        titleFa = "کمپین محتوا و سوشال مدیا",
        subtitleFa = "سناریونویسی، تولید تیزر، تقویم انتشار و آنالیز بازخورد",
        category = ProjectCategory.MARKETING,
        colorIndex = 4
    ),
    ACADEMIC_RESEARCH(
        titleFa = "پروژه پژوهشی و دانشگاهی",
        subtitleFa = "گردآوری منابع، تحلیل داده، نگارش مقاله و دفاع نهایی",
        category = ProjectCategory.PERSONAL,
        colorIndex = 2
    ),
    BUSINESS_SALES(
        titleFa = "رشد فروش و توسعه کسب‌وکار",
        subtitleFa = "شناسایی سرنخ‌ها، ارائه پروپوزال، قرارداد و پشتیبانی",
        category = ProjectCategory.BUSINESS,
        colorIndex = 1
    )
}

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val description: String = "",
    val notes: String = "",
    val budgetLabel: String = "",
    val category: String = ProjectCategory.DEVELOPMENT.name,
    val status: String = ProjectStatus.ACTIVE.name,
    val colorIndex: Int = 0,
    val isPinned: Boolean = false,
    val targetDateMillis: Long? = null,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val projectId: Long,
    val title: String,
    val description: String = "",
    val status: String = TaskStatus.TODO.name,
    val priority: String = TaskPriority.MEDIUM.name,
    val dueDateMillis: Long? = null,
    val estimatedMinutes: Int = 45,
    val focusMinutesSpent: Int = 0,
    val storyPoints: Int = 3,
    val assigneeName: String = "",
    val bookmarked: Boolean = false,
    val tag: String = "",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val completedAtMillis: Long? = null
)

@Entity(
    tableName = "subtasks",
    foreignKeys = [
        ForeignKey(
            entity = TaskEntity::class,
            parentColumns = ["id"],
            childColumns = ["taskId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["taskId"])]
)
data class SubtaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val taskId: Long,
    val title: String,
    val isCompleted: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "milestones",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["projectId"])]
)
data class MilestoneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val projectId: Long,
    val title: String,
    val targetDateMillis: Long? = null,
    val isCompleted: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val taskId: Long? = null,
    val projectId: Long? = null,
    val durationMinutes: Int,
    val completedAtMillis: Long = System.currentTimeMillis()
)

data class ProjectWithStats(
    val project: ProjectEntity,
    val totalTasks: Int,
    val doneTasks: Int,
    val inProgressTasks: Int,
    val todoTasks: Int,
    val totalMilestones: Int,
    val completedMilestones: Int,
    val totalEstimatedMinutes: Int = 0,
    val totalFocusMinutes: Int = 0,
    val totalStoryPoints: Int = 0,
    val doneStoryPoints: Int = 0
) {
    val progress: Float
        get() = if (totalTasks == 0) 0f else doneTasks.toFloat() / totalTasks.toFloat()
}

data class TaskWithMeta(
    val task: TaskEntity,
    val projectTitle: String,
    val projectColorIndex: Int,
    val subtasks: List<SubtaskEntity>
) {
    val completedSubtasksCount: Int
        get() = subtasks.count { it.isCompleted }
}
