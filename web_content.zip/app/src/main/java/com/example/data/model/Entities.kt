package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // "APK_TO_AAB", "ZIP_TO_APK"
    val sourceFileName: String,
    val sourceFileSize: Long,
    val outputFileName: String,
    val outputFileSize: Long,
    val status: String, // "COMPLETED", "PROCESSING", "FAILED", "DRAFT"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val compressionRatio: Float = 0f,
    val dexCount: Int = 1,
    val signingKeyAlias: String = "Debug Key",
    val optimizationScore: Int = 85,
    val isCloudSynced: Boolean = false,
    val cloudSyncTimestamp: Long = 0L,
    val logMessages: String = "",
    val packageName: String = "com.app.sample",
    val versionName: String = "1.0.0",
    val targetSdk: Int = 34,
    val isDebuggable: Boolean = false,
    val has64BitSupport: Boolean = true,
    val notes: String = ""
)

@Entity(tableName = "keystores")
data class KeystoreEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val alias: String,
    val storePassword: String,
    val keyPassword: String,
    val keyType: String = "RSA_2048",
    val validityYears: Int = 25,
    val createdAt: Long = System.currentTimeMillis(),
    val sha256Fingerprint: String = "",
    val sha1Fingerprint: String = "",
    val md5Fingerprint: String = "",
    val organization: String = "Android Developer",
    val countryCode: String = "US",
    val isDefault: Boolean = false
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val type: String = "INFO" // "BUILD_SUCCESS", "BUILD_FAIL", "SYNC", "SECURITY"
)
