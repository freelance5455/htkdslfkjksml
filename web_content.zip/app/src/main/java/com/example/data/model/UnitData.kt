package com.example.data.model

enum class UnitType(val titleKey: String) {
    LENGTH("unit_length"),
    WEIGHT("unit_weight"),
    TEMPERATURE("unit_temp"),
    SPEED("unit_speed"),
    AREA("unit_area"),
    VOLUME("unit_volume")
}

data class ConversionUnit(
    val id: String,
    val name: String,
    val symbol: String,
    val toBaseFactor: Double = 1.0 // Multiplier to convert to base unit
)

object UnitData {
    val lengthUnits = listOf(
        ConversionUnit("m", "Meter", "m", 1.0),
        ConversionUnit("km", "Kilometer", "km", 1000.0),
        ConversionUnit("cm", "Centimeter", "cm", 0.01),
        ConversionUnit("mm", "Millimeter", "mm", 0.001),
        ConversionUnit("in", "Inch", "in", 0.0254),
        ConversionUnit("ft", "Foot", "ft", 0.3048),
        ConversionUnit("yd", "Yard", "yd", 0.9144),
        ConversionUnit("mi", "Mile", "mi", 1609.344)
    )

    val weightUnits = listOf(
        ConversionUnit("kg", "Kilogram", "kg", 1.0),
        ConversionUnit("g", "Gram", "g", 0.001),
        ConversionUnit("mg", "Milligram", "mg", 0.000001),
        ConversionUnit("lb", "Pound", "lb", 0.45359237),
        ConversionUnit("oz", "Ounce", "oz", 0.02834952),
        ConversionUnit("t", "Metric Ton", "t", 1000.0)
    )

    val speedUnits = listOf(
        ConversionUnit("kmh", "Kilometers/hour", "km/h", 0.277778),
        ConversionUnit("mph", "Miles/hour", "mph", 0.44704),
        ConversionUnit("ms", "Meters/second", "m/s", 1.0),
        ConversionUnit("knot", "Knot", "kn", 0.514444)
    )

    val areaUnits = listOf(
        ConversionUnit("sqm", "Square Meter", "m²", 1.0),
        ConversionUnit("sqkm", "Square Kilometer", "km²", 1000000.0),
        ConversionUnit("sqft", "Square Foot", "ft²", 0.092903),
        ConversionUnit("acre", "Acre", "ac", 4046.86),
        ConversionUnit("ha", "Hectare", "ha", 10000.0)
    )

    val volumeUnits = listOf(
        ConversionUnit("l", "Liter", "L", 1.0),
        ConversionUnit("ml", "Milliliter", "mL", 0.001),
        ConversionUnit("gal", "US Gallon", "gal", 3.78541),
        ConversionUnit("cup", "US Cup", "cup", 0.24),
        ConversionUnit("floz", "Fluid Ounce", "fl oz", 0.0295735)
    )

    val tempUnits = listOf(
        ConversionUnit("c", "Celsius", "°C"),
        ConversionUnit("f", "Fahrenheit", "°F"),
        ConversionUnit("k", "Kelvin", "K")
    )

    fun convert(value: Double, from: ConversionUnit, to: ConversionUnit, type: UnitType): Double {
        if (type == UnitType.TEMPERATURE) {
            return convertTemperature(value, from.id, to.id)
        }
        val inBase = value * from.toBaseFactor
        return inBase / to.toBaseFactor
    }

    private fun convertTemperature(value: Double, fromId: String, toId: String): Double {
        // Convert from source to Celsius first
        val inCelsius = when (fromId) {
            "c" -> value
            "f" -> (value - 32.0) * 5.0 / 9.0
            "k" -> value - 273.15
            else -> value
        }
        // Convert from Celsius to target
        return when (toId) {
            "c" -> inCelsius
            "f" -> (inCelsius * 9.0 / 5.0) + 32.0
            "k" -> inCelsius + 273.15
            else -> inCelsius
        }
    }
}
