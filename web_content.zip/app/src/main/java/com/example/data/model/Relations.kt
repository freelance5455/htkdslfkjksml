package com.example.data.model

import androidx.room.Embedded
import androidx.room.Relation
import com.example.data.local.BookingEntity
import com.example.data.local.ClientEntity
import com.example.data.local.DocumentEntity
import com.example.data.local.PaymentEntity

data class BookingWithDetails(
    @Embedded val booking: BookingEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "bookingId",
    )
    val payments: List<PaymentEntity> = emptyList(),
    @Relation(
        parentColumn = "id",
        entityColumn = "bookingId",
    )
    val documents: List<DocumentEntity> = emptyList(),
) {
    val totalDue: Double
        get() = booking.totalPrice + booking.extraAmount

    val totalPaid: Double
        get() = payments.sumOf { it.amount }

    val remainingAmount: Double
        get() = totalDue - totalPaid

    val profitAmount: Double
        get() = totalDue - booking.costAmount
}

data class ClientWithBookings(
    @Embedded val client: ClientEntity,
    @Relation(
        entity = BookingEntity::class,
        parentColumn = "id",
        entityColumn = "clientId",
    )
    val bookings: List<BookingWithDetails> = emptyList(),
) {
    val totalPaidAcrossBookings: Double
        get() = bookings.sumOf { it.totalPaid }

    val totalRemainingAcrossBookings: Double
        get() = bookings
            .filter { it.booking.status != BookingStatus.CANCELLED }
            .sumOf { it.remainingAmount }
}

data class DashboardStats(
    val totalClients: Int = 0,
    val totalBookings: Int = 0,
    val upcomingTrips: Int = 0,
    val totalCollected: Double = 0.0,
    val totalRemaining: Double = 0.0,
    val confirmedCount: Int = 0,
    val pendingCount: Int = 0,
    val cancelledCount: Int = 0,
)

data class SearchFilter(
    val clientCode: String = "",
    val fullName: String = "",
    val phone: String = "",
    val passportNumber: String = "",
    val exactTripDate: String = "",
    val companyName: String = "",
    val status: BookingStatus? = null,
    val tripDateFrom: String = "",
    val tripDateTo: String = "",
) {
    val hasAnyCriteria: Boolean
        get() = clientCode.isNotBlank() ||
            fullName.isNotBlank() ||
            phone.isNotBlank() ||
            passportNumber.isNotBlank() ||
            exactTripDate.isNotBlank() ||
            companyName.isNotBlank() ||
            status != null ||
            tripDateFrom.isNotBlank() ||
            tripDateTo.isNotBlank()
}

data class ReportPreview(
    val reportType: ReportType,
    val title: String,
    val headers: List<String>,
    val rows: List<List<String>>,
    val summaryMetrics: List<Pair<String, String>>,
)

data class RestoreSummary(
    val addedClients: Int,
    val skippedDuplicateClients: Int,
    val addedBookings: Int,
    val addedPayments: Int,
    val restoredDocuments: Int,
)

data class PendingAttachment(
    val docType: DocumentType,
    val title: String,
    val tempFilePath: String,
)
