package com.example.data.model

import android.graphics.Bitmap

data class PageData(
    val pageNumber: Int,
    val rawText: String,
    val words: List<WordContext>,
    val sentences: List<String>,
    var pageBitmap: Bitmap? = null
)

data class ScannedDocument(
    val id: String,
    val title: String,
    val totalPages: Int,
    val pages: List<PageData>,
    val fileSizeFormatted: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
