package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val subjectId: Long,
    val subjectName: String,
    val subjectColorHex: String,
    val subjectIcon: String = "📚",
    val durationSeconds: Int,
    val sessionType: String = "FOCUS", // "FOCUS", "SHORT_BREAK", "LONG_BREAK"
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
