package com.example.data.repository

import com.example.data.local.SnowtamDao
import com.example.data.local.WeatherCacheDao
import com.example.data.model.*
import com.example.data.parser.MetarParser
import com.example.data.parser.SnowtamParser
import com.example.data.parser.TafParser
import com.example.data.remote.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class WeatherRepository(
  private val weatherCacheDao: WeatherCacheDao,
  private val snowtamDao: SnowtamDao,
  private val aviationApi: AviationWeatherApi = NetworkClient.aviationWeatherApi,
  private val openMeteoApi: OpenMeteoAviationApi = NetworkClient.openMeteoApi
) {

  val aviationWeatherGovAdapter = AviationWeatherGovAdapter(aviationApi)
  val openMeteoAdapter = OpenMeteoUpperAirAdapter(openMeteoApi)
  val wifsAdapter = WifsAdapter()
  val icaoAdapter = IcaoApiAdapter()
  val iranAisAdapter = IranianAisAdapter()

  suspend fun getMetar(icao: String): Result<Pair<MetarData, Boolean>> = withContext(Dispatchers.IO) {
    try {
      val response = aviationApi.getMetar(ids = icao.uppercase())
      if (response.isSuccessful && !response.body().isNullOrEmpty()) {
        val dto = response.body()!!.first()
        val raw = dto.rawOb ?: "METAR ${dto.icaoId ?: icao} NO RAW OBS"
        val parsed = MetarParser.parse(raw, icaoFallback = icao.uppercase()).copy(
          receiptTimeUtc = dto.receiptTime ?: "",
          obsTimestampEpochSec = dto.obsTime ?: 0L,
          source = "AviationWeather.gov (NOAA/NWS)"
        )
        weatherCacheDao.saveMetar(parsed)
        Result.success(Pair(parsed, false)) // false = not offline cached
      } else {
        // Fallback to local cache
        val cached = weatherCacheDao.getCachedMetar(icao.uppercase())
        if (cached != null) {
          Result.success(Pair(cached, true)) // true = offline cached
        } else {
          Result.failure(Exception("NO CURRENT DATA"))
        }
      }
    } catch (e: Exception) {
      val cached = weatherCacheDao.getCachedMetar(icao.uppercase())
      if (cached != null) {
        Result.success(Pair(cached, true))
      } else {
        Result.failure(e)
      }
    }
  }

  suspend fun getTaf(icao: String): Result<Pair<TafData, Boolean>> = withContext(Dispatchers.IO) {
    try {
      val response = aviationApi.getTaf(ids = icao.uppercase())
      if (response.isSuccessful && !response.body().isNullOrEmpty()) {
        val dto = response.body()!!.first()
        val raw = dto.rawTAF ?: "TAF ${dto.icaoId ?: icao} NO RAW TAF"
        val parsed = TafParser.parse(raw, icaoFallback = icao.uppercase()).copy(
          validFromEpochSec = dto.validTimeFrom ?: 0L,
          validToEpochSec = dto.validTimeTo ?: 0L,
          source = "AviationWeather.gov / WIFS OPMET"
        )
        weatherCacheDao.saveTaf(parsed)
        Result.success(Pair(parsed, false))
      } else {
        val cached = weatherCacheDao.getCachedTaf(icao.uppercase())
        if (cached != null) {
          Result.success(Pair(cached, true))
        } else {
          Result.failure(Exception("NO CURRENT DATA"))
        }
      }
    } catch (e: Exception) {
      val cached = weatherCacheDao.getCachedTaf(icao.uppercase())
      if (cached != null) {
        Result.success(Pair(cached, true))
      } else {
        Result.failure(e)
      }
    }
  }

  suspend fun getSigmets(): Result<List<SigmetData>> = withContext(Dispatchers.IO) {
    try {
      val response = aviationApi.getSigmets()
      if (response.isSuccessful && response.body() != null) {
        val nowSec = System.currentTimeMillis() / 1000L
        val list = response.body()!!.mapIndexed { index, dto ->
          val raw = dto.rawSigmet ?: "${dto.firId ?: "FIR"} SIGMET"
          val coordsList = dto.coords?.mapNotNull { c ->
            if (c.lat != null && c.lon != null) GeoPoint(c.lat, c.lon) else null
          } ?: emptyList()
          val coordsStr = coordsList.joinToString(";") { "${it.lat},${it.lon}" }

          SigmetData(
            sigmetId = dto.sigmetId?.toString() ?: "SIGMET_${dto.firId}_$index",
            firId = dto.firId ?: "OIIX",
            firName = dto.firName ?: (dto.firId ?: "FIR"),
            rawSigmet = raw,
            hazard = dto.hazard ?: "WX",
            qualifier = dto.qualifier ?: "",
            baseFt = dto.base,
            topFt = dto.top,
            movementDir = dto.dir,
            change = dto.chng,
            issueTimeUtc = dto.issueTime ?: "",
            validFromUtc = dto.validTimeFrom?.let { formatEpochToUtc(it) } ?: "",
            validToUtc = dto.validTimeTo?.let { formatEpochToUtc(it) } ?: "",
            validFromEpochSec = dto.validTimeFrom ?: 0L,
            validToEpochSec = dto.validTimeTo ?: 0L,
            coordsJson = coordsStr,
            source = "AviationWeather.gov / WIFS International"
          )
        }
        // Save to cache
        weatherCacheDao.saveSigmets(list)
        Result.success(list)
      } else {
        val cached = weatherCacheDao.getAllCachedSigmets()
        Result.success(emptyList())
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun getWindAloft(
    icao: String,
    airportName: String,
    lat: Double,
    lon: Double
  ): Result<WindAloftReport> = withContext(Dispatchers.IO) {
    try {
      val response = openMeteoApi.getUpperAirForecast(lat = lat, lon = lon)
      if (response.isSuccessful && response.body()?.hourly != null) {
        val h = response.body()!!.hourly!!
        val times = h.time ?: emptyList()
        val index = 0 // current or earliest forecast hour

        val validTime = if (times.isNotEmpty()) times[index] + " UTC" else "Current UTC"
        val retrievalTime = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US).apply {
          timeZone = TimeZone.getTimeZone("UTC")
        }.format(Date())

        val levels = mutableListOf<WindAloftLevel>()

        fun addLevel(name: String, hpa: Int, altFt: Int, spd: Double?, dir: Int?, tmp: Double?) {
          levels.add(
            WindAloftLevel(
              flightLevelName = name,
              pressureHpa = hpa,
              altitudeFt = altFt,
              windDirDeg = dir ?: 0,
              windSpeedKt = (spd ?: 0.0).toInt(),
              tempC = tmp ?: 0.0,
              validTimeUtc = validTime
            )
          )
        }

        // Add standard vertical flight levels
        addLevel("Surface (1000 hPa)", 1000, 300, h.windSpeed1000?.getOrNull(index), h.windDir1000?.getOrNull(index), h.temp1000?.getOrNull(index))
        addLevel("FL050 (850 hPa)", 850, 5000, h.windSpeed850?.getOrNull(index), h.windDir850?.getOrNull(index), h.temp850?.getOrNull(index))
        addLevel("FL100 (700 hPa)", 700, 10000, h.windSpeed700?.getOrNull(index), h.windDir700?.getOrNull(index), h.temp700?.getOrNull(index))
        addLevel("FL180 (500 hPa)", 500, 18000, h.windSpeed500?.getOrNull(index), h.windDir500?.getOrNull(index), h.temp500?.getOrNull(index))
        addLevel("FL300 (300 hPa)", 300, 30000, h.windSpeed300?.getOrNull(index), h.windDir300?.getOrNull(index), h.temp300?.getOrNull(index))
        addLevel("FL340 (250 hPa)", 250, 34000, h.windSpeed250?.getOrNull(index), h.windDir250?.getOrNull(index), h.temp250?.getOrNull(index))
        addLevel("FL390 (200 hPa)", 200, 39000, h.windSpeed200?.getOrNull(index), h.windDir200?.getOrNull(index), h.temp200?.getOrNull(index))

        Result.success(
          WindAloftReport(
            icao = icao,
            airportName = airportName,
            latitude = lat,
            longitude = lon,
            validTimeUtc = validTime,
            retrievalTimeUtc = retrievalTime,
            levels = levels
          )
        )
      } else {
        Result.failure(Exception("WIND DATA SOURCE UNAVAILABLE"))
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun getStoredSnowtams(icao: String): Flow<List<SnowtamData>> =
    snowtamDao.getSnowtamsForAirport(icao.uppercase())

  suspend fun insertSnowtam(snowtam: SnowtamData): Long =
    snowtamDao.insertSnowtam(snowtam)

  suspend fun seedOfficialSampleSnowtamIfEmpty(icao: String) {
    val existing = snowtamDao.getLatestSnowtam(icao.uppercase())
    if (existing == null) {
      val sampleRaw = """
        SWIR0001 $icao 12050020
        (SNOWTAM 0001
        $icao
        12050020 29R 5/5/5 100/100/100 03/03/03 WET SNOW/WET SNOW/WET SNOW
        RWY 29R FICON 5/5/5 100/100/100 03/03/03 WET SNOW/WET SNOW/WET SNOW CHEMICALLY TREATED)
      """.trimIndent()

      val parsed = SnowtamParser.parse(
        raw = sampleRaw,
        icaoFallback = icao.uppercase(),
        sourceName = "ICAO GRF Doc 10066 Official Verification Sample",
        isSample = true
      )
      snowtamDao.insertSnowtam(parsed)
    }
  }

  suspend fun checkAllSources(): List<DataSourceStatus> = withContext(Dispatchers.IO) {
    listOf(
      aviationWeatherGovAdapter.checkStatus(),
      openMeteoAdapter.checkStatus(),
      wifsAdapter.checkStatus(),
      icaoAdapter.checkStatus(),
      iranAisAdapter.checkStatus()
    )
  }

  private fun formatEpochToUtc(epochSec: Long): String {
    val sdf = SimpleDateFormat("ddHHmm'Z'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }
    return sdf.format(Date(epochSec * 1000L))
  }
}
