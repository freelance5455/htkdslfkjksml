package com.example.data.model

enum class FileCategory(val label: String) {
    IMAGES("Images"),
    AUDIO("Audio"),
    VIDEOS("Videos"),
    DOCUMENTS("Documents"),
    DOWNLOADS("Downloads"),
    INSTALLATION("Installation files"),
    COMPRESSED("Compressed files"),
    APPS("Apps")
}

enum class FileKind(
    val displayLabel: String,
    val badgeText: String? = null
) {
    FOLDER("Folder"),
    APK("Android Package", "Installation file"),
    APKS("Split APK Bundle", "Installation file"),
    XAPK("XAPK Package", "Installation file"),
    EXE("Windows Executable", "Cannot run on Android"),
    MSI("Windows Installer", "Cannot run on Android"),
    ZIP("ZIP Archive"),
    ARCHIVE("Compressed Archive"),
    PDF("PDF Document"),
    WORD("Word Document"),
    EXCEL("Spreadsheet"),
    POWERPOINT("Presentation"),
    TEXT("Text / Code"),
    IMAGE("Image"),
    AUDIO("Audio"),
    VIDEO("Video"),
    GENERIC("File")
}

enum class StorageRootType {
    INTERNAL_WORKSPACE,
    SAF_FOLDER,
    SAF_CLOUD,
    USB_OTG
}

enum class FileSystemType(val label: String, val isReadOnlyOnAndroid: Boolean) {
    FAT("FAT", false),
    FAT32("FAT32", false),
    EXFAT("exFAT", false),
    NTFS("NTFS", true),
    EXT2("ext2", true),
    EXT3("ext3", true),
    EXT4("ext4", true),
    F2FS("F2FS", false),
    SAF_PROVIDER("SAF Tree", false),
    UNSUPPORTED("Unsupported", true),
    UNKNOWN("Unknown", false)
}

data class StorageVolumeInfo(
    val id: String,
    val title: String,
    val subtitle: String,
    val rootPath: String,
    val type: StorageRootType,
    val usedBytes: Long,
    val totalBytes: Long,
    val fileSystemType: FileSystemType = FileSystemType.F2FS,
    val isReadOnly: Boolean = false,
    val isEjectable: Boolean = false,
    val isUnsupportedFormat: Boolean = false,
    val unsupportedExplanation: String? = null,
    val treeUriString: String? = null
)

data class BreadcrumbSegment(
    val label: String,
    val path: String
)

data class FileNode(
    val id: String,
    val name: String,
    val path: String,
    val parentPath: String?,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val mimeType: String,
    val extension: String,
    val kind: FileKind,
    val magicSignature: String? = null,
    val hasSuspiciousDoubleExtension: Boolean = false,
    val doubleExtensionWarning: String? = null,
    val isHidden: Boolean = false,
    val isFavorite: Boolean = false,
    val isReadOnly: Boolean = false,
    val childFolderCount: Int = 0,
    val childFileCount: Int = 0,
    val contentUriString: String? = null
) {
    fun displayName(showExtensions: Boolean): String {
        if (isDirectory || showExtensions || extension.isBlank()) return name
        val suffix = ".$extension"
        return if (name.endsWith(suffix, ignoreCase = true) && name.length > suffix.length) {
            name.dropLast(suffix.length)
        } else {
            name
        }
    }
}

data class ApkPackageMetadata(
    val fileName: String,
    val sizeBytes: Long,
    val packageName: String?,
    val appLabel: String?,
    val versionName: String?,
    val versionCode: Long?,
    val minSdk: Int?,
    val targetSdk: Int?,
    val archiveEntriesCount: Int,
    val isBundleFormat: Boolean,
    val installExplanation: String
)

enum class BrowserViewMode(val label: String) {
    LIST("List"),
    GRID("Grid"),
    DETAIL("Detail")
}

enum class SortField(val label: String) {
    NAME("Name"),
    DATE("Date"),
    TYPE("Type"),
    SIZE("Size")
}

enum class ConflictAction {
    SKIP,
    REPLACE,
    KEEP_BOTH
}

data class ConflictPrompt(
    val fileName: String,
    val destinationPath: String,
    val existingSizeBytes: Long,
    val incomingSizeBytes: Long
)

data class TransferProgress(
    val operationLabel: String,
    val currentFileName: String,
    val processedCount: Int,
    val totalCount: Int,
    val bytesProcessed: Long,
    val totalBytes: Long,
    val isCancellable: Boolean = true
)

data class StorageAnalysisReport(
    val totalDeviceBytes: Long,
    val usedDeviceBytes: Long,
    val categoryBreakdown: Map<FileCategory, Long>,
    val categoryCounts: Map<FileCategory, Int>,
    val largeFiles: List<FileNode>,
    val duplicateGroups: List<List<FileNode>>,
    val unusedOldFiles: List<FileNode>
)
