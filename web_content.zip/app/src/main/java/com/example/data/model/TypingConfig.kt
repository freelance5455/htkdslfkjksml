package com.example.data.model

/**
 * Configuration parameters for the AutoWriter engine.
 */
data class TypingConfig(
    val charSpeedMs: Long = 65L,
    val wordDelayMs: Long = 250L,
    val isRandomMode: Boolean = true,
    val randomWordCount: Int = 6,
    val isAutoRepeat: Boolean = false,
    val isSlotFillMode: Boolean = false,
    val isHumanJitter: Boolean = true,
    val isSoundEnabled: Boolean = true,
    val isHapticsEnabled: Boolean = true,
    val targetField: TargetFieldType = TargetFieldType.SINGLE_LINE
)

/**
 * Real-time telemetry and statistics about typing speed and progress.
 */
data class TypingTelemetry(
    val wordsTypedTotal: Int = 0,
    val charsTypedTotal: Int = 0,
    val currentCycleWordsTyped: Int = 0,
    val targetWordsCount: Int = 0,
    val currentWordText: String = "",
    val currentCharIndex: Int = 0,
    val wordsPerMinute: Int = 0,
    val elapsedSeconds: Int = 0,
    val cycleNumber: Int = 1,
    val progress: Float = 0f
)
