package com.example.data.storage

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import androidx.documentfile.provider.DocumentFile
import com.example.data.local.FileMetadataDao
import com.example.data.local.SafRootEntity
import com.example.data.local.TrashEntity
import com.example.data.model.BreadcrumbSegment
import com.example.data.model.ConflictAction
import com.example.data.model.ConflictPrompt
import com.example.data.model.FileCategory
import com.example.data.model.FileKind
import com.example.data.model.FileNode
import com.example.data.model.FileSystemType
import com.example.data.model.StorageAnalysisReport
import com.example.data.model.StorageRootType
import com.example.data.model.StorageVolumeInfo
import com.example.data.model.TransferProgress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Strict real-device StorageProvider implementation:
 * 1) Real Internal Workspace storage on the Android filesystem (creating standard empty
 *    Samsung-like user directories if first run so CameraX, ZIP, and folder creation work out of the box).
 * 2) User-granted Storage Access Framework (SAF) directory trees (Downloads, Documents, DCIM, Cloud, USB).
 * 3) Real USB/OTG and removable storage volumes detected via UsbOtgMonitor.
 *
 * Zero synthetic/fake files are generated.
 */
class DeviceAndSafStorageAdapter(
    private val context: Context,
    private val dao: FileMetadataDao,
    private val usbMonitor: UsbOtgMonitor
) : StorageProvider {

    val workspaceRootDir: File = File(context.filesDir, "MyFilesWorkspace").apply {
        if (!exists()) {
            mkdirs()
            // Initialize standard empty Samsung directory skeleton on real filesystem
            listOf("DCIM/Camera", "Download", "Documents", "Pictures", "Music", "Movies").forEach { rel ->
                File(this, rel).mkdirs()
            }
        }
    }

    private val trashStorageDir: File = File(context.filesDir, ".RecycleBin").apply {
        if (!exists()) mkdirs()
    }

    val workspaceRootPath: String get() = "file://${workspaceRootDir.absolutePath}"

    suspend fun purgeExpiredTrash(maxAgeDays: Int = 30) = withContext(Dispatchers.IO) {
        val cutoff = System.currentTimeMillis() - maxAgeDays * 24L * 60L * 60L * 1000L
        val all = dao.getAllTrash()
        for (item in all) {
            if (item.deletedAtEpochMs < cutoff) {
                val f = File(item.trashedFilePath.removePrefix("file://"))
                if (f.exists()) f.deleteRecursively()
                dao.deleteTrashById(item.id)
            }
        }
    }

    suspend fun restoreTrashItem(trash: TrashEntity): Boolean = withContext(Dispatchers.IO) {
        val trashedFile = File(trash.trashedFilePath.removePrefix("file://"))
        if (!trashedFile.exists()) {
            dao.deleteTrashById(trash.id)
            return@withContext false
        }
        val destParent = trash.originalParentPath
        if (destParent.startsWith("saf://")) {
            val docParent = resolveSafDocument(destParent) ?: return@withContext false
            if (trashedFile.isDirectory) {
                copyLocalDirToSaf(trashedFile, docParent)
            } else {
                val created = docParent.createFile(trash.mimeType, trash.originalName) ?: return@withContext false
                context.contentResolver.openOutputStream(created.uri)?.use { out ->
                    trashedFile.inputStream().use { inp -> inp.copyTo(out) }
                }
            }
            trashedFile.deleteRecursively()
            dao.deleteTrashById(trash.id)
            true
        } else {
            val parentDir = File(destParent.removePrefix("file://")).apply { if (!exists()) mkdirs() }
            var target = File(parentDir, trash.originalName)
            if (target.exists()) {
                target = uniqueLocalFile(parentDir, trash.originalName)
            }
            val moved = trashedFile.renameTo(target) || run {
                trashedFile.copyRecursively(target, overwrite = true)
                trashedFile.deleteRecursively()
            }
            if (moved) dao.deleteTrashById(trash.id)
            moved
        }
    }

    suspend fun emptyTrash() = withContext(Dispatchers.IO) {
        val all = dao.getAllTrash()
        for (item in all) {
            val f = File(item.trashedFilePath.removePrefix("file://"))
            if (f.exists()) f.deleteRecursively()
        }
        trashStorageDir.listFiles()?.forEach { it.deleteRecursively() }
        dao.clearAllTrash()
    }

    suspend fun registerSafTree(treeUri: Uri, isCloud: Boolean = false): StorageVolumeInfo = withContext(Dispatchers.IO) {
        val doc = DocumentFile.fromTreeUri(context, treeUri)
        val name = doc?.name?.takeIf { it.isNotBlank() } ?: if (isCloud) "Cloud Drive Folder" else "Granted Device Folder"
        val id = "saf_${treeUri.toString().hashCode().toUInt()}"
        val entity = SafRootEntity(
            id = id,
            treeUriString = treeUri.toString(),
            displayName = name,
            isCloudProvider = isCloud,
            addedAtEpochMs = System.currentTimeMillis()
        )
        dao.insertSafRoot(entity)
        val stat = queryInternalStatFs()
        StorageVolumeInfo(
            id = id,
            title = name,
            subtitle = if (isCloud) "Mounted Cloud Document Provider" else "Storage Access Framework folder",
            rootPath = "saf://$id|",
            type = if (isCloud) StorageRootType.SAF_CLOUD else StorageRootType.SAF_FOLDER,
            usedBytes = stat.first,
            totalBytes = stat.second,
            fileSystemType = FileSystemType.SAF_PROVIDER,
            isReadOnly = doc?.canWrite() == false,
            isEjectable = true,
            treeUriString = treeUri.toString()
        )
    }

    suspend fun removeSafRoot(id: String) = withContext(Dispatchers.IO) {
        dao.deleteSafRoot(id)
    }

    override suspend fun listRoots(): List<StorageVolumeInfo> = withContext(Dispatchers.IO) {
        val (usedBytes, totalBytes) = queryInternalStatFs()
        val roots = mutableListOf<StorageVolumeInfo>()

        // 1. Primary Internal Storage / App Workspace
        roots.add(
            StorageVolumeInfo(
                id = "internal_workspace",
                title = "Internal storage",
                subtitle = "Device storage telemetry • App Workspace & Mounted Folders",
                rootPath = workspaceRootPath,
                type = StorageRootType.INTERNAL_WORKSPACE,
                usedBytes = usedBytes,
                totalBytes = totalBytes,
                fileSystemType = FileSystemType.F2FS,
                isReadOnly = false,
                isEjectable = false
            )
        )

        // 2. Persisted SAF Roots (Device folders like Downloads/DCIM & Cloud providers)
        val safRoots = dao.getSafRootsSnapshot()
        for (saf in safRoots) {
            val uri = Uri.parse(saf.treeUriString)
            val doc = DocumentFile.fromTreeUri(context, uri)
            if (doc != null && doc.exists()) {
                roots.add(
                    StorageVolumeInfo(
                        id = saf.id,
                        title = saf.displayName,
                        subtitle = if (saf.isCloudProvider) "Cloud Drive (SAF)" else "Granted Device Folder (SAF)",
                        rootPath = "saf://${saf.id}|",
                        type = if (saf.isCloudProvider) StorageRootType.SAF_CLOUD else StorageRootType.SAF_FOLDER,
                        usedBytes = usedBytes,
                        totalBytes = totalBytes,
                        fileSystemType = FileSystemType.SAF_PROVIDER,
                        isReadOnly = !doc.canWrite(),
                        isEjectable = true,
                        treeUriString = saf.treeUriString
                    )
                )
            }
        }

        // 3. Connected USB OTG / Removable Hardware Volumes
        roots.addAll(usbMonitor.getConnectedUsbAndRemovableVolumes())
        roots
    }

    override suspend fun getStorageInfo(): List<StorageVolumeInfo> = listRoots()

    override suspend fun list(path: String, showHidden: Boolean): List<FileNode> = withContext(Dispatchers.IO) {
        val favorites = dao.observeFavorites().first().map { it.path }.toSet()
        val hiddenSet = dao.observeHiddenPaths().first().map { it.path }.toSet()

        val rawNodes = when {
            path.startsWith("saf://") -> listSafDirectory(path, favorites, hiddenSet)
            path.startsWith("file://") -> listLocalDirectory(File(path.removePrefix("file://")), favorites, hiddenSet)
            else -> emptyList()
        }

        if (showHidden) rawNodes else rawNodes.filterNot { it.isHidden }
    }

    private fun listLocalDirectory(
        dir: File,
        favorites: Set<String>,
        hiddenSet: Set<String>
    ): List<FileNode> {
        if (!dir.exists() || !dir.isDirectory) return emptyList()
        val children = dir.listFiles() ?: return emptyList()
        return children.map { child ->
            toLocalFileNode(child, favorites, hiddenSet)
        }
    }

    private fun toLocalFileNode(
        file: File,
        favorites: Set<String>,
        hiddenSet: Set<String>
    ): FileNode {
        val fullPath = "file://${file.absolutePath}"
        val parentPath = file.parentFile?.let { "file://${it.absolutePath}" }
        val header = if (file.isFile) FileTypeInspector.readHeaderBytes(file) else null
        val inspection = FileTypeInspector.inspect(file.name, file.isDirectory, header)
        val subItems = if (file.isDirectory) file.listFiles() else null
        val childFolders = subItems?.count { it.isDirectory } ?: 0
        val childFiles = subItems?.count { it.isFile } ?: 0
        val ext = file.extension.lowercase()
        val hidden = file.name.startsWith(".") || fullPath in hiddenSet

        return FileNode(
            id = fullPath,
            name = file.name,
            path = fullPath,
            parentPath = parentPath,
            isDirectory = file.isDirectory,
            sizeBytes = if (file.isDirectory) computeDirShallowBytes(subItems) else file.length(),
            lastModified = file.lastModified(),
            mimeType = inspection.mimeType,
            extension = ext,
            kind = inspection.kind,
            magicSignature = inspection.magicSignature,
            hasSuspiciousDoubleExtension = inspection.hasSuspiciousDoubleExtension,
            doubleExtensionWarning = inspection.doubleExtensionWarning,
            isHidden = hidden,
            isFavorite = fullPath in favorites,
            isReadOnly = !file.canWrite(),
            childFolderCount = childFolders,
            childFileCount = childFiles,
            contentUriString = Uri.fromFile(file).toString()
        )
    }

    private fun computeDirShallowBytes(files: Array<File>?): Long {
        if (files == null) return 0L
        var sum = 0L
        for (f in files) {
            if (f.isFile) sum += f.length()
        }
        return sum
    }

    private suspend fun listSafDirectory(
        safPath: String,
        favorites: Set<String>,
        hiddenSet: Set<String>
    ): List<FileNode> {
        val docDir = resolveSafDocument(safPath) ?: return emptyList()
        val rootPrefix = safPath.substringBefore("|") + "|"
        val relativePrefix = safPath.substringAfter("|", "").trim('/')

        return docDir.listFiles().mapNotNull { doc ->
            val name = doc.name ?: return@mapNotNull null
            val childRel = if (relativePrefix.isEmpty()) name else "$relativePrefix/$name"
            val childPath = "$rootPrefix$childRel"
            val ext = name.substringAfterLast('.', "").takeIf { name.contains('.') }?.lowercase() ?: ""
            val header = if (doc.isFile) {
                FileTypeInspector.readHeaderBytes({ context.contentResolver.openInputStream(doc.uri) })
            } else null
            val inspection = FileTypeInspector.inspect(name, doc.isDirectory, header)
            val hidden = name.startsWith(".") || childPath in hiddenSet

            FileNode(
                id = childPath,
                name = name,
                path = childPath,
                parentPath = safPath,
                isDirectory = doc.isDirectory,
                sizeBytes = doc.length(),
                lastModified = doc.lastModified(),
                mimeType = doc.type ?: inspection.mimeType,
                extension = ext,
                kind = inspection.kind,
                magicSignature = inspection.magicSignature,
                hasSuspiciousDoubleExtension = inspection.hasSuspiciousDoubleExtension,
                doubleExtensionWarning = inspection.doubleExtensionWarning,
                isHidden = hidden,
                isFavorite = childPath in favorites,
                isReadOnly = !doc.canWrite(),
                childFolderCount = 0,
                childFileCount = 0,
                contentUriString = doc.uri.toString()
            )
        }
    }

    suspend fun buildBreadcrumbs(path: String): List<BreadcrumbSegment> = withContext(Dispatchers.IO) {
        if (path.startsWith("saf://")) {
            val rootId = path.removePrefix("saf://").substringBefore("|")
            val safRoot = dao.getSafRootsSnapshot().find { it.id == rootId }
            val rootLabel = safRoot?.displayName ?: "Folder"
            val segments = mutableListOf(BreadcrumbSegment(rootLabel, "saf://$rootId|"))
            val rel = path.substringAfter("|", "").trim('/')
            if (rel.isNotEmpty()) {
                var accum = ""
                for (part in rel.split('/')) {
                    accum = if (accum.isEmpty()) part else "$accum/$part"
                    segments.add(BreadcrumbSegment(part, "saf://$rootId|$accum"))
                }
            }
            segments
        } else {
            val raw = path.removePrefix("file://")
            val wsPath = workspaceRootDir.absolutePath
            if (raw.startsWith(wsPath)) {
                val segments = mutableListOf(BreadcrumbSegment("Internal storage", workspaceRootPath))
                val rel = raw.removePrefix(wsPath).trim('/')
                if (rel.isNotEmpty()) {
                    var currentFile = workspaceRootDir
                    for (part in rel.split('/')) {
                        currentFile = File(currentFile, part)
                        segments.add(BreadcrumbSegment(part, "file://${currentFile.absolutePath}"))
                    }
                }
                segments
            } else {
                val f = File(raw)
                listOf(BreadcrumbSegment(f.name.ifBlank { "Storage" }, path))
            }
        }
    }

    override suspend fun read(path: String): ByteArray = withContext(Dispatchers.IO) {
        openReadStream(path)?.use { it.readBytes() } ?: ByteArray(0)
    }

    override fun openReadStream(path: String): InputStream? {
        return try {
            if (path.startsWith("file://")) {
                val f = File(path.removePrefix("file://"))
                if (f.exists() && f.isFile) BufferedInputStream(f.inputStream()) else null
            } else if (path.startsWith("saf://")) {
                val doc = resolveSafDocumentSync(path)
                doc?.uri?.let { context.contentResolver.openInputStream(it) }
            } else if (path.startsWith("content://")) {
                context.contentResolver.openInputStream(Uri.parse(path))
            } else null
        } catch (_: Exception) {
            null
        }
    }

    override suspend fun write(
        parentPath: String,
        fileName: String,
        bytes: ByteArray,
        mimeType: String,
        overwrite: Boolean
    ): FileNode = withContext(Dispatchers.IO) {
        if (parentPath.startsWith("saf://")) {
            val parentDoc = resolveSafDocument(parentPath)
                ?: throw IllegalStateException("Cannot resolve target SAF folder")
            val existing = parentDoc.findFile(fileName)
            val targetDoc = when {
                existing != null && overwrite -> existing
                existing != null && !overwrite -> {
                    val uniqueName = generateUniqueName(fileName) { parentDoc.findFile(it) != null }
                    parentDoc.createFile(mimeType, uniqueName)
                }
                else -> parentDoc.createFile(mimeType, fileName)
            } ?: throw IllegalStateException("Failed to create file in SAF folder")

            context.contentResolver.openOutputStream(targetDoc.uri, "wt")?.use { out ->
                out.write(bytes)
            }
            val rootPrefix = parentPath.substringBefore("|") + "|"
            val relPrefix = parentPath.substringAfter("|", "").trim('/')
            val actualName = targetDoc.name ?: fileName
            val childPath = if (relPrefix.isEmpty()) "$rootPrefix$actualName" else "$rootPrefix$relPrefix/$actualName"
            stat(childPath) ?: throw IllegalStateException("Unable to stat written SAF file")
        } else {
            val dir = File(parentPath.removePrefix("file://")).apply { if (!exists()) mkdirs() }
            val target = if (!overwrite && File(dir, fileName).exists()) {
                uniqueLocalFile(dir, fileName)
            } else {
                File(dir, fileName)
            }
            target.writeBytes(bytes)
            stat("file://${target.absolutePath}") ?: throw IllegalStateException("Unable to stat written file")
        }
    }

    override suspend fun mkdir(parentPath: String, folderName: String): FileNode = withContext(Dispatchers.IO) {
        val clean = folderName.trim().replace("/", "_")
        require(clean.isNotEmpty()) { "Folder name cannot be empty" }

        if (parentPath.startsWith("saf://")) {
            val parentDoc = resolveSafDocument(parentPath)
                ?: throw IllegalStateException("SAF folder is unavailable or read-only")
            val created = parentDoc.createDirectory(clean)
                ?: throw IllegalStateException("Could not create folder (storage may be read-only)")
            val rootPrefix = parentPath.substringBefore("|") + "|"
            val rel = parentPath.substringAfter("|", "").trim('/')
            val actualName = created.name ?: clean
            val newPath = if (rel.isEmpty()) "$rootPrefix$actualName" else "$rootPrefix$rel/$actualName"
            stat(newPath)!!
        } else {
            val parentDir = File(parentPath.removePrefix("file://"))
            val newDir = File(parentDir, clean)
            if (!newDir.exists() && !newDir.mkdirs()) {
                throw IllegalStateException("Failed to create folder (check write permission)")
            }
            stat("file://${newDir.absolutePath}")!!
        }
    }

    override suspend fun rename(path: String, newName: String): FileNode = withContext(Dispatchers.IO) {
        val clean = newName.trim()
        require(clean.isNotEmpty()) { "New name cannot be empty" }
        if (path.startsWith("saf://")) {
            val doc = resolveSafDocument(path) ?: throw IllegalStateException("SAF item not found")
            if (!doc.renameTo(clean)) {
                throw IllegalStateException("Rename not supported or denied by storage provider")
            }
            val parent = path.substringBeforeLast('/', path.substringBefore("|") + "|")
            val newPath = if (parent.endsWith("|")) "$parent$clean" else "$parent/$clean"
            stat(newPath) ?: throw IllegalStateException("Renamed item could not be resolved")
        } else {
            val src = File(path.removePrefix("file://"))
            val dst = File(src.parentFile, clean)
            if (!src.renameTo(dst)) {
                throw IllegalStateException("Failed to rename file")
            }
            stat("file://${dst.absolutePath}")!!
        }
    }

    override suspend fun deleteToTrash(paths: List<String>): Int = withContext(Dispatchers.IO) {
        var count = 0
        for (path in paths) {
            val node = stat(path) ?: continue
            val trashId = UUID.randomUUID().toString()
            val trashTarget = File(trashStorageDir, "${trashId}_${node.name}")

            if (path.startsWith("file://")) {
                val src = File(path.removePrefix("file://"))
                if (!src.exists()) continue
                val moved = src.renameTo(trashTarget) || run {
                    src.copyRecursively(trashTarget, overwrite = true)
                    src.deleteRecursively()
                }
                if (moved) {
                    dao.insertTrash(
                        TrashEntity(
                            id = trashId,
                            originalName = node.name,
                            trashedFilePath = "file://${trashTarget.absolutePath}",
                            originalParentPath = node.parentPath ?: workspaceRootPath,
                            sizeBytes = node.sizeBytes,
                            isDirectory = node.isDirectory,
                            mimeType = node.mimeType,
                            deletedAtEpochMs = System.currentTimeMillis()
                        )
                    )
                    count++
                }
            } else if (path.startsWith("saf://")) {
                val doc = resolveSafDocument(path) ?: continue
                if (doc.isDirectory) {
                    copySafDirToLocal(doc, trashTarget)
                } else {
                    context.contentResolver.openInputStream(doc.uri)?.use { inp ->
                        trashTarget.outputStream().use { out -> inp.copyTo(out) }
                    }
                }
                if (doc.delete()) {
                    dao.insertTrash(
                        TrashEntity(
                            id = trashId,
                            originalName = node.name,
                            trashedFilePath = "file://${trashTarget.absolutePath}",
                            originalParentPath = node.parentPath ?: workspaceRootPath,
                            sizeBytes = node.sizeBytes,
                            isDirectory = node.isDirectory,
                            mimeType = node.mimeType,
                            deletedAtEpochMs = System.currentTimeMillis()
                        )
                    )
                    count++
                }
            }
        }
        count
    }

    override suspend fun deletePermanently(paths: List<String>): Int = withContext(Dispatchers.IO) {
        var count = 0
        for (path in paths) {
            if (path.startsWith("file://")) {
                val f = File(path.removePrefix("file://"))
                if (f.exists() && f.deleteRecursively()) count++
            } else if (path.startsWith("saf://")) {
                val doc = resolveSafDocument(path)
                if (doc != null && doc.delete()) count++
            }
        }
        count
    }

    override suspend fun copy(
        sourcePaths: List<String>,
        destinationDirPath: String,
        onProgress: (TransferProgress) -> Unit,
        onConflict: suspend (ConflictPrompt) -> ConflictAction,
        isCancelled: () -> Boolean
    ): Int = transferInternal(
        sourcePaths = sourcePaths,
        destinationDirPath = destinationDirPath,
        deleteSourceAfter = false,
        onProgress = onProgress,
        onConflict = onConflict,
        isCancelled = isCancelled
    )

    override suspend fun move(
        sourcePaths: List<String>,
        destinationDirPath: String,
        onProgress: (TransferProgress) -> Unit,
        onConflict: suspend (ConflictPrompt) -> ConflictAction,
        isCancelled: () -> Boolean
    ): Int = transferInternal(
        sourcePaths = sourcePaths,
        destinationDirPath = destinationDirPath,
        deleteSourceAfter = true,
        onProgress = onProgress,
        onConflict = onConflict,
        isCancelled = isCancelled
    )

    private suspend fun transferInternal(
        sourcePaths: List<String>,
        destinationDirPath: String,
        deleteSourceAfter: Boolean,
        onProgress: (TransferProgress) -> Unit,
        onConflict: suspend (ConflictPrompt) -> ConflictAction,
        isCancelled: () -> Boolean
    ): Int = withContext(Dispatchers.IO) {
        val opLabel = if (deleteSourceAfter) "Moving files" else "Copying files"
        val nodes = sourcePaths.mapNotNull { stat(it) }
        val totalBytes = nodes.sumOf { it.sizeBytes }.coerceAtLeast(1L)
        var bytesDone = 0L
        var completed = 0

        for ((index, srcNode) in nodes.withIndex()) {
            if (isCancelled()) break
            onProgress(
                TransferProgress(
                    operationLabel = opLabel,
                    currentFileName = srcNode.name,
                    processedCount = index,
                    totalCount = nodes.size,
                    bytesProcessed = bytesDone,
                    totalBytes = totalBytes
                )
            )

            val existingDest = checkExistingChild(destinationDirPath, srcNode.name)
            var finalTargetName = srcNode.name
            var shouldOverwrite = false

            if (existingDest != null) {
                val resolution = onConflict(
                    ConflictPrompt(
                        fileName = srcNode.name,
                        destinationPath = destinationDirPath,
                        existingSizeBytes = existingDest.sizeBytes,
                        incomingSizeBytes = srcNode.sizeBytes
                    )
                )
                when (resolution) {
                    ConflictAction.SKIP -> {
                        bytesDone += srcNode.sizeBytes
                        continue
                    }
                    ConflictAction.REPLACE -> {
                        shouldOverwrite = true
                    }
                    ConflictAction.KEEP_BOTH -> {
                        finalTargetName = generateUniqueName(srcNode.name) { candidate ->
                            checkExistingChildBlocking(destinationDirPath, candidate)
                        }
                    }
                }
            }

            val copiedOk = copySingleNode(
                srcNode = srcNode,
                destinationDirPath = destinationDirPath,
                targetName = finalTargetName,
                overwrite = shouldOverwrite,
                onChunk = { chunk ->
                    bytesDone += chunk
                    onProgress(
                        TransferProgress(
                            operationLabel = opLabel,
                            currentFileName = srcNode.name,
                            processedCount = index,
                            totalCount = nodes.size,
                            bytesProcessed = bytesDone.coerceAtMost(totalBytes),
                            totalBytes = totalBytes
                        )
                    )
                },
                isCancelled = isCancelled
            )

            if (copiedOk && !isCancelled()) {
                if (deleteSourceAfter) {
                    deletePermanently(listOf(srcNode.path))
                }
                completed++
            }
        }
        completed
    }

    private suspend fun checkExistingChild(dirPath: String, childName: String): FileNode? {
        return if (dirPath.startsWith("file://")) {
            val f = File(File(dirPath.removePrefix("file://")), childName)
            if (f.exists()) stat("file://${f.absolutePath}") else null
        } else if (dirPath.startsWith("saf://")) {
            val doc = resolveSafDocument(dirPath)?.findFile(childName)
            if (doc != null && doc.exists()) {
                val rootPrefix = dirPath.substringBefore("|") + "|"
                val rel = dirPath.substringAfter("|", "").trim('/')
                val p = if (rel.isEmpty()) "$rootPrefix$childName" else "$rootPrefix$rel/$childName"
                stat(p)
            } else null
        } else null
    }

    private fun checkExistingChildBlocking(dirPath: String, childName: String): Boolean {
        return if (dirPath.startsWith("file://")) {
            File(File(dirPath.removePrefix("file://")), childName).exists()
        } else if (dirPath.startsWith("saf://")) {
            resolveSafDocumentSync(dirPath)?.findFile(childName) != null
        } else false
    }

    private suspend fun copySingleNode(
        srcNode: FileNode,
        destinationDirPath: String,
        targetName: String,
        overwrite: Boolean,
        onChunk: (Long) -> Unit,
        isCancelled: () -> Boolean
    ): Boolean {
        if (srcNode.isDirectory) {
            val createdSubDir = mkdir(destinationDirPath, targetName)
            val children = list(srcNode.path, showHidden = true)
            for (child in children) {
                if (isCancelled()) return false
                copySingleNode(child, createdSubDir.path, child.name, overwrite, onChunk, isCancelled)
            }
            return true
        }

        val inStream = openReadStream(srcNode.path) ?: return false
        inStream.use { input ->
            openWriteStream(destinationDirPath, targetName, srcNode.mimeType, overwrite)?.use { output ->
                val buffer = ByteArray(32 * 1024)
                var read = input.read(buffer)
                while (read >= 0) {
                    if (isCancelled()) return false
                    output.write(buffer, 0, read)
                    onChunk(read.toLong())
                    read = input.read(buffer)
                }
                output.flush()
                return true
            }
        }
        return false
    }

    private suspend fun openWriteStream(
        dirPath: String,
        fileName: String,
        mimeType: String,
        overwrite: Boolean
    ): OutputStream? {
        return if (dirPath.startsWith("file://")) {
            val dir = File(dirPath.removePrefix("file://")).apply { if (!exists()) mkdirs() }
            val dst = File(dir, fileName)
            if (dst.exists() && overwrite) dst.delete()
            BufferedOutputStream(FileOutputStream(dst))
        } else if (dirPath.startsWith("saf://")) {
            val parentDoc = resolveSafDocument(dirPath) ?: return null
            val existing = parentDoc.findFile(fileName)
            val targetDoc = if (existing != null && overwrite) {
                existing
            } else {
                existing?.delete()
                parentDoc.createFile(mimeType, fileName)
            } ?: return null
            context.contentResolver.openOutputStream(targetDoc.uri, "wt")
        } else null
    }

    override suspend fun stat(path: String): FileNode? = withContext(Dispatchers.IO) {
        val favorites = dao.observeFavorites().first().map { it.path }.toSet()
        val hiddenSet = dao.observeHiddenPaths().first().map { it.path }.toSet()

        if (path.startsWith("file://")) {
            val f = File(path.removePrefix("file://"))
            if (!f.exists()) return@withContext null
            toLocalFileNode(f, favorites, hiddenSet)
        } else if (path.startsWith("saf://")) {
            val doc = resolveSafDocument(path) ?: return@withContext null
            val name = doc.name ?: "Folder"
            val ext = name.substringAfterLast('.', "").takeIf { name.contains('.') }?.lowercase() ?: ""
            val header = if (doc.isFile) {
                FileTypeInspector.readHeaderBytes({ context.contentResolver.openInputStream(doc.uri) })
            } else null
            val inspection = FileTypeInspector.inspect(name, doc.isDirectory, header)
            val rel = path.substringAfter("|", "").trim('/')
            val parentPath = if (rel.isEmpty()) null else {
                val rootPrefix = path.substringBefore("|") + "|"
                val parentRel = rel.substringBeforeLast('/', "")
                "$rootPrefix$parentRel"
            }
            FileNode(
                id = path,
                name = name,
                path = path,
                parentPath = parentPath,
                isDirectory = doc.isDirectory,
                sizeBytes = doc.length(),
                lastModified = doc.lastModified(),
                mimeType = doc.type ?: inspection.mimeType,
                extension = ext,
                kind = inspection.kind,
                magicSignature = inspection.magicSignature,
                hasSuspiciousDoubleExtension = inspection.hasSuspiciousDoubleExtension,
                doubleExtensionWarning = inspection.doubleExtensionWarning,
                isHidden = name.startsWith(".") || path in hiddenSet,
                isFavorite = path in favorites,
                isReadOnly = !doc.canWrite(),
                contentUriString = doc.uri.toString()
            )
        } else null
    }

    override suspend fun compressToZip(
        sourcePaths: List<String>,
        destinationDirPath: String,
        zipFileName: String,
        onProgress: (TransferProgress) -> Unit
    ): FileNode = withContext(Dispatchers.IO) {
        val normalizedZipName = if (zipFileName.lowercase().endsWith(".zip")) zipFileName else "$zipFileName.zip"
        val tempZip = File(context.cacheDir, "tmp_${System.currentTimeMillis()}_$normalizedZipName")
        val nodes = sourcePaths.mapNotNull { stat(it) }
        val totalBytes = nodes.sumOf { it.sizeBytes }.coerceAtLeast(1L)
        var processedBytes = 0L

        ZipOutputStream(BufferedOutputStream(FileOutputStream(tempZip))).use { zos ->
            for ((idx, node) in nodes.withIndex()) {
                onProgress(
                    TransferProgress(
                        operationLabel = "Compressing to ZIP",
                        currentFileName = node.name,
                        processedCount = idx,
                        totalCount = nodes.size,
                        bytesProcessed = processedBytes,
                        totalBytes = totalBytes,
                        isCancellable = false
                    )
                )
                addNodeToZip(zos, node, "") { delta -> processedBytes += delta }
            }
        }

        val finalBytes = tempZip.readBytes()
        tempZip.delete()
        write(destinationDirPath, normalizedZipName, finalBytes, "application/zip", overwrite = false)
    }

    private suspend fun addNodeToZip(
        zos: ZipOutputStream,
        node: FileNode,
        parentPrefix: String,
        onBytes: (Long) -> Unit
    ) {
        val entryPath = if (parentPrefix.isEmpty()) node.name else "$parentPrefix/${node.name}"
        if (node.isDirectory) {
            zos.putNextEntry(ZipEntry("$entryPath/"))
            zos.closeEntry()
            val children = list(node.path, showHidden = false)
            for (child in children) {
                addNodeToZip(zos, child, entryPath, onBytes)
            }
        } else {
            zos.putNextEntry(ZipEntry(entryPath))
            openReadStream(node.path)?.use { input ->
                val buf = ByteArray(16 * 1024)
                var len = input.read(buf)
                while (len > 0) {
                    zos.write(buf, 0, len)
                    onBytes(len.toLong())
                    len = input.read(buf)
                }
            }
            zos.closeEntry()
        }
    }

    override suspend fun extractZip(
        zipPath: String,
        destinationDirPath: String,
        onProgress: (TransferProgress) -> Unit
    ): FileNode = withContext(Dispatchers.IO) {
        val zipNode = stat(zipPath) ?: throw IllegalStateException("ZIP archive not found")
        val folderBase = zipNode.name.removeSuffix(".zip").removeSuffix(".ZIP").ifBlank { "Extracted" }
        val targetFolder = mkdir(destinationDirPath, folderBase)

        var extractedEntries = 0
        openReadStream(zipPath)?.use { raw ->
            ZipInputStream(BufferedInputStream(raw)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val safeName = entry.name.trim('/').replace("..", "")
                    if (safeName.isNotEmpty()) {
                        onProgress(
                            TransferProgress(
                                operationLabel = "Extracting archive",
                                currentFileName = safeName.substringAfterLast('/'),
                                processedCount = extractedEntries,
                                totalCount = (extractedEntries + 1),
                                bytesProcessed = extractedEntries.toLong(),
                                totalBytes = (extractedEntries + 1).toLong(),
                                isCancellable = false
                            )
                        )
                        if (entry.isDirectory) {
                            ensureNestedFolder(targetFolder.path, safeName)
                        } else {
                            val parentSub = safeName.substringBeforeLast('/', "")
                            val leafName = safeName.substringAfterLast('/')
                            val destParent = if (parentSub.isEmpty()) {
                                targetFolder.path
                            } else {
                                ensureNestedFolder(targetFolder.path, parentSub)
                            }
                            val bytes = zis.readBytes()
                            val inspection = FileTypeInspector.inspect(leafName, false, bytes.take(16).toByteArray())
                            write(destParent, leafName, bytes, inspection.mimeType, overwrite = true)
                        }
                        extractedEntries++
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        targetFolder
    }

    private suspend fun ensureNestedFolder(basePath: String, relativeFolders: String): String {
        var current = basePath
        for (segment in relativeFolders.split('/').filter { it.isNotBlank() }) {
            val existing = checkExistingChild(current, segment)
            current = existing?.path ?: mkdir(current, segment).path
        }
        return current
    }

    override suspend fun queryByCategory(category: FileCategory, showHidden: Boolean): List<FileNode> = withContext(Dispatchers.IO) {
        val allFiles = collectAllAccessibleFiles(showHidden)
        allFiles.filter { node ->
            !node.isDirectory && matchesCategory(node, category)
        }.sortedByDescending { it.lastModified }
    }

    override suspend fun queryRecentFiles(limit: Int): List<FileNode> = withContext(Dispatchers.IO) {
        collectAllAccessibleFiles(showHidden = false)
            .filter { !it.isDirectory }
            .sortedByDescending { it.lastModified }
            .take(limit)
    }

    override suspend fun analyzeStorage(): StorageAnalysisReport = withContext(Dispatchers.IO) {
        val (usedDevice, totalDevice) = queryInternalStatFs()
        val allFiles = collectAllAccessibleFiles(showHidden = false).filter { !it.isDirectory }

        val breakdown = mutableMapOf<FileCategory, Long>()
        val counts = mutableMapOf<FileCategory, Int>()
        FileCategory.entries.forEach {
            breakdown[it] = 0L
            counts[it] = 0
        }

        for (file in allFiles) {
            for (cat in FileCategory.entries) {
                if (matchesCategory(file, cat)) {
                    breakdown[cat] = (breakdown[cat] ?: 0L) + file.sizeBytes
                    counts[cat] = (counts[cat] ?: 0) + 1
                }
            }
        }

        // Large files (> 5 MB threshold so real captured videos/photos/ZIPs surface immediately)
        val largeFiles = allFiles.filter { it.sizeBytes >= 5_000_000L }
            .sortedByDescending { it.sizeBytes }

        // Duplicate files: group by identical byte size (> 0 B) then verify SHA-256 content hash
        val duplicateGroups = allFiles
            .filter { it.sizeBytes > 0L }
            .groupBy { it.sizeBytes }
            .values
            .filter { it.size > 1 }
            .flatMap { sameSizeGroup ->
                sameSizeGroup.groupBy { computeSha256Sample(it.path) }
                    .values
                    .filter { it.size > 1 }
            }

        // Unused / old files (> 30 days since last modification)
        val thirtyDaysAgo = System.currentTimeMillis() - 30L * 24L * 60L * 60L * 1000L
        val oldFiles = allFiles.filter { it.lastModified in 1 until thirtyDaysAgo }
            .sortedBy { it.lastModified }

        StorageAnalysisReport(
            totalDeviceBytes = totalDevice,
            usedDeviceBytes = usedDevice,
            categoryBreakdown = breakdown,
            categoryCounts = counts,
            largeFiles = largeFiles,
            duplicateGroups = duplicateGroups,
            unusedOldFiles = oldFiles
        )
    }

    suspend fun collectAllAccessibleFiles(showHidden: Boolean): List<FileNode> = withContext(Dispatchers.IO) {
        val results = mutableListOf<FileNode>()
        val favorites = dao.observeFavorites().first().map { it.path }.toSet()
        val hiddenSet = dao.observeHiddenPaths().first().map { it.path }.toSet()

        // 1. Walk Internal Workspace recursively
        walkLocalDir(workspaceRootDir, favorites, hiddenSet, showHidden, results, maxDepth = 6)

        // 2. Walk granted SAF roots (up to depth 3 for snappy responsiveness)
        for (saf in dao.getSafRootsSnapshot()) {
            walkSafDir("saf://${saf.id}|", favorites, hiddenSet, showHidden, results, depth = 0, maxDepth = 3)
        }
        results
    }

    private fun walkLocalDir(
        dir: File,
        favorites: Set<String>,
        hiddenSet: Set<String>,
        showHidden: Boolean,
        out: MutableList<FileNode>,
        depth: Int = 0,
        maxDepth: Int = 6
    ) {
        if (depth > maxDepth || !dir.exists() || !dir.isDirectory) return
        val children = dir.listFiles() ?: return
        for (child in children) {
            val node = toLocalFileNode(child, favorites, hiddenSet)
            if (!showHidden && node.isHidden) continue
            out.add(node)
            if (child.isDirectory) {
                walkLocalDir(child, favorites, hiddenSet, showHidden, out, depth + 1, maxDepth)
            }
        }
    }

    private suspend fun walkSafDir(
        safPath: String,
        favorites: Set<String>,
        hiddenSet: Set<String>,
        showHidden: Boolean,
        out: MutableList<FileNode>,
        depth: Int,
        maxDepth: Int
    ) {
        if (depth > maxDepth) return
        val items = listSafDirectory(safPath, favorites, hiddenSet)
        for (node in items) {
            if (!showHidden && node.isHidden) continue
            out.add(node)
            if (node.isDirectory) {
                walkSafDir(node.path, favorites, hiddenSet, showHidden, out, depth + 1, maxDepth)
            }
        }
    }

    private fun matchesCategory(node: FileNode, category: FileCategory): Boolean {
        return when (category) {
            FileCategory.IMAGES -> node.kind == FileKind.IMAGE
            FileCategory.AUDIO -> node.kind == FileKind.AUDIO
            FileCategory.VIDEOS -> node.kind == FileKind.VIDEO
            FileCategory.DOCUMENTS -> node.kind in setOf(
                FileKind.PDF, FileKind.WORD, FileKind.EXCEL, FileKind.POWERPOINT, FileKind.TEXT
            )
            FileCategory.DOWNLOADS -> node.path.contains("/Download", ignoreCase = true)
            FileCategory.INSTALLATION -> node.kind in setOf(
                FileKind.APK, FileKind.APKS, FileKind.XAPK, FileKind.EXE, FileKind.MSI
            )
            FileCategory.COMPRESSED -> node.kind in setOf(FileKind.ZIP, FileKind.ARCHIVE)
            FileCategory.APPS -> node.kind in setOf(FileKind.APK, FileKind.APKS, FileKind.XAPK)
        }
    }

    private fun computeSha256Sample(path: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            openReadStream(path)?.use { inp ->
                val buf = ByteArray(64 * 1024)
                val read = inp.read(buf)
                if (read > 0) digest.update(buf, 0, read)
            }
            digest.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            path
        }
    }

    private fun queryInternalStatFs(): Pair<Long, Long> {
        return try {
            val stat = StatFs(Environment.getDataDirectory().absolutePath)
            val total = stat.totalBytes
            val avail = stat.availableBytes
            val used = (total - avail).coerceAtLeast(0L)
            used to total
        } catch (_: Exception) {
            0L to 0L
        }
    }

    private suspend fun resolveSafDocument(safPath: String): DocumentFile? {
        val rootId = safPath.removePrefix("saf://").substringBefore("|")
        val safRoot = dao.getSafRootsSnapshot().find { it.id == rootId } ?: return null
        var current = DocumentFile.fromTreeUri(context, Uri.parse(safRoot.treeUriString)) ?: return null
        val rel = safPath.substringAfter("|", "").trim('/')
        if (rel.isEmpty()) return current
        for (segment in rel.split('/')) {
            current = current.findFile(segment) ?: return null
        }
        return current
    }

    private fun resolveSafDocumentSync(safPath: String): DocumentFile? {
        // Used for synchronous InputStream resolution when URI is already known or local
        return kotlinx.coroutines.runBlocking(Dispatchers.IO) {
            resolveSafDocument(safPath)
        }
    }

    private fun copySafDirToLocal(safDir: DocumentFile, localTarget: File) {
        localTarget.mkdirs()
        for (child in safDir.listFiles()) {
            val name = child.name ?: continue
            val dest = File(localTarget, name)
            if (child.isDirectory) {
                copySafDirToLocal(child, dest)
            } else {
                context.contentResolver.openInputStream(child.uri)?.use { inp ->
                    dest.outputStream().use { out -> inp.copyTo(out) }
                }
            }
        }
    }

    private fun copyLocalDirToSaf(localDir: File, safParent: DocumentFile) {
        val createdDir = safParent.createDirectory(localDir.name) ?: return
        localDir.listFiles()?.forEach { child ->
            if (child.isDirectory) {
                copyLocalDirToSaf(child, createdDir)
            } else {
                val analysis = FileTypeInspector.inspect(child.name, false)
                val docFile = createdDir.createFile(analysis.mimeType, child.name)
                if (docFile != null) {
                    context.contentResolver.openOutputStream(docFile.uri)?.use { out ->
                        child.inputStream().use { inp -> inp.copyTo(out) }
                    }
                }
            }
        }
    }

    private fun uniqueLocalFile(dir: File, originalName: String): File {
        val chosen = generateUniqueName(originalName) { File(dir, it).exists() }
        return File(dir, chosen)
    }

    private fun generateUniqueName(originalName: String, existsPredicate: (String) -> Boolean): String {
        val dotIdx = originalName.lastIndexOf('.')
        val base = if (dotIdx > 0) originalName.substring(0, dotIdx) else originalName
        val ext = if (dotIdx > 0) originalName.substring(dotIdx) else ""
        var counter = 1
        var candidate = "$base ($counter)$ext"
        while (existsPredicate(candidate)) {
            counter++
            candidate = "$base ($counter)$ext"
        }
        return candidate
    }
}
