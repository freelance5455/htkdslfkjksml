package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vendas")
data class Venda(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val perfumeId: Long, // ID do lote que deu baixa
    val perfumeNome: String,
    val perfumeMarca: String,
    val codigo: String,
    val validadeVendida: String = "", // Data de validade do produto/lote vendido
    val quantidade: Int,
    val precoUnitario: Double,
    val custoUnitario: Double = 0.0,
    val total: Double,
    val lucro: Double,
    val dataHora: Long = System.currentTimeMillis()
)
