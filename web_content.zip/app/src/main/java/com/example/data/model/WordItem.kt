package com.example.data.model

import java.util.UUID

/**
 * Represents a single word or phrase entity in the user's custom vocabulary bank.
 */
data class WordItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val category: String = "عام",
    val isEnabled: Boolean = true,
    val timesUsed: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Target field where auto-typing takes place.
 */
enum class TargetFieldType(val titleAr: String, val titleEn: String) {
    SINGLE_LINE("حقل إدخال سريع", "Single Line Field"),
    MULTI_LINE("محرر نصوص ومستندات", "Multi-line Document"),
    LETTER_SLOTS("خانات أحرف موجهة", "Character Slots")
}

/**
 * State of the automated typing engine.
 */
enum class EngineState(val labelAr: String) {
    IDLE("جاهز للبدء"),
    TYPING("جارِ الكتابة..."),
    PAUSED("متوقف مؤقتاً"),
    COMPLETED("اكتملت الدورة")
}

/**
 * Character slot for the position-based auto-fill feature.
 */
data class SlotItem(
    val index: Int,
    val charValue: Char? = null,
    val isActive: Boolean = false,
    val isFilled: Boolean = false
)
