package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.local.UserEntity
import com.example.data.model.AppConfigSettings
import com.example.data.model.PayoutMethod
import com.example.data.model.Task
import com.example.data.model.TaskCategory
import com.example.data.model.User
import com.example.data.model.Withdrawal
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class LeaderboardFilter {
    DAILY,
    WEEKLY,
    ALL_TIME
}

class FirestoreRepository(
    private val db: FirebaseFirestore,
    private val database: AppDatabase? = null
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        ),
        AppDatabase.getInstance(context)
    )

    private val auth: FirebaseAuth = Firebase.auth
    private val userDao = database?.userDao()

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    private fun getTodayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    private fun getCurrentWeekString(): String {
        return SimpleDateFormat("yyyy-'W'ww", Locale.US).format(Date())
    }

    /**
     * Initializes or synchronizes the user profile in Firestore and local Room DB.
     * Grants welcome bonus (50 coins, 5 gems) if this is a brand new user.
     */
    fun syncUserProfile(displayName: String, email: String, photoUrl: String?): Flow<User> = callbackFlow {
        val uid = requireUserId()
        val userDocRef = db.collection("users").document(uid)
        val todayStr = getTodayDateString()
        val weekStr = getCurrentWeekString()

        // 1. Initial existence check & welcome bonus
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val snapshot = userDocRef.get().await()
                if (!snapshot.exists()) {
                    // Fetch configured welcome bonus if available
                    val configSnap = try {
                        db.collection("app_config").document("settings").get().await()
                    } catch (e: Exception) {
                        null
                    }
                    val welcomeCoins = (configSnap?.getLong("welcomeBonusCoins") ?: 50L)
                    val welcomeGems = (configSnap?.getLong("welcomeBonusGems") ?: 5L)

                    val initialUser = mapOf(
                        "uid" to uid,
                        "displayName" to displayName,
                        "email" to email,
                        "photoUrl" to photoUrl,
                        "coins" to welcomeCoins,
                        "gems" to welcomeGems,
                        "dailyCoins" to 0L,
                        "weeklyCoins" to 0L,
                        "lastDailyDate" to todayStr,
                        "lastWeeklyDate" to weekStr,
                        "isBlocked" to false,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    userDocRef.set(initialUser).await()

                    userDao?.insertOrUpdate(
                        UserEntity(
                            uid = uid,
                            displayName = displayName,
                            email = email,
                            photoUrl = photoUrl,
                            coins = welcomeCoins,
                            gems = welcomeGems,
                            dailyCoins = 0L,
                            weeklyCoins = 0L,
                            lastDailyDate = todayStr,
                            lastWeeklyDate = weekStr,
                            isBlocked = false
                        )
                    )
                } else {
                    // Check if daily or weekly reset is needed
                    val existingUser = snapshot.toObject(User::class.java)
                    if (existingUser != null) {
                        var needsUpdate = false
                        val updates = mutableMapOf<String, Any>()

                        if (existingUser.lastDailyDate != todayStr) {
                            updates["dailyCoins"] = 0L
                            updates["lastDailyDate"] = todayStr
                            needsUpdate = true
                        }
                        if (existingUser.lastWeeklyDate != weekStr) {
                            updates["weeklyCoins"] = 0L
                            updates["lastWeeklyDate"] = weekStr
                            needsUpdate = true
                        }
                        if (needsUpdate) {
                            updates["updatedAt"] = FieldValue.serverTimestamp()
                            userDocRef.update(updates).await()
                        }
                    }
                }
            } catch (e: Exception) {
                handleFirestoreError(e, OperationType.WRITE, userDocRef.path)
            }
        }

        // 2. Realtime listener
        val listener = userDocRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                handleFirestoreError(error, OperationType.GET, userDocRef.path)
                close(error)
                return@addSnapshotListener
            }
            if (snapshot != null && snapshot.exists()) {
                val user = snapshot.toObject(User::class.java)
                if (user != null) {
                    trySend(user)
                    // Sync to local Room DB
                    CoroutineScope(Dispatchers.IO).launch {
                        userDao?.insertOrUpdate(
                            UserEntity(
                                uid = user.uid.ifEmpty { uid },
                                displayName = user.displayName,
                                email = user.email,
                                photoUrl = user.photoUrl,
                                coins = user.coins,
                                gems = user.gems,
                                dailyCoins = user.dailyCoins,
                                weeklyCoins = user.weeklyCoins,
                                lastDailyDate = user.lastDailyDate,
                                lastWeeklyDate = user.lastWeeklyDate,
                                isBlocked = user.isBlocked
                            )
                        )
                    }
                }
            }
        }

        awaitClose { listener.remove() }
    }

    /**
     * Observe dynamic tasks configured by Admin
     */
    fun observeTasks(category: String? = null): Flow<List<Task>> = flow {
        requireUserId()
        val query = if (category.isNullOrBlank() || category.uppercase() == "ALL") {
            db.collection("tasks")
        } else {
            db.collection("tasks").whereEqualTo("category", category.uppercase())
        }

        emitAll(
            query.snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Task::class.java)
                        .filter { it.isEnabled }
                        .sortedBy { it.order }
                }
                .catch { error ->
                    handleFirestoreError(error, OperationType.LIST, "tasks")
                    throw error
                }
        )
    }

    /**
     * Observe task categories
     */
    fun observeCategories(): Flow<List<TaskCategory>> = flow {
        requireUserId()
        emitAll(
            db.collection("task_categories").snapshots()
                .map { snapshot ->
                    snapshot.toObjects(TaskCategory::class.java)
                        .filter { it.isEnabled }
                        .sortedBy { it.order }
                }
                .catch { error ->
                    handleFirestoreError(error, OperationType.LIST, "task_categories")
                    throw error
                }
        )
    }

    /**
     * Observe payout methods configured by Admin
     */
    fun observePayoutMethods(): Flow<List<PayoutMethod>> = flow {
        requireUserId()
        emitAll(
            db.collection("payout_methods").snapshots()
                .map { snapshot ->
                    snapshot.toObjects(PayoutMethod::class.java)
                        .filter { it.isEnabled }
                        .sortedBy { it.order }
                }
                .catch { error ->
                    handleFirestoreError(error, OperationType.LIST, "payout_methods")
                    throw error
                }
        )
    }

    /**
     * Observe user's submitted withdrawals
     */
    fun observeUserWithdrawals(): Flow<List<Withdrawal>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("withdrawals")
                .whereEqualTo("userId", uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Withdrawal::class.java)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    handleFirestoreError(error, OperationType.LIST, "withdrawals")
                    throw error
                }
        )
    }

    /**
     * Observe global leaderboard of real users
     */
    fun observeLeaderboard(filter: LeaderboardFilter): Flow<List<User>> = flow {
        requireUserId()
        val sortField = when (filter) {
            LeaderboardFilter.DAILY -> "dailyCoins"
            LeaderboardFilter.WEEKLY -> "weeklyCoins"
            LeaderboardFilter.ALL_TIME -> "coins"
        }

        emitAll(
            db.collection("users")
                .orderBy(sortField, Query.Direction.DESCENDING)
                .limit(50)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(User::class.java)
                        .filter { !it.isBlocked && it.displayName.isNotBlank() }
                }
                .catch { error ->
                    handleFirestoreError(error, OperationType.LIST, "users")
                    throw error
                }
        )
    }

    /**
     * Observe App Economy settings
     */
    fun observeAppSettings(): Flow<AppConfigSettings> = flow {
        requireUserId()
        val docRef = db.collection("app_config").document("settings")
        emitAll(
            docRef.snapshots()
                .map { snapshot ->
                    snapshot.toObject(AppConfigSettings::class.java) ?: AppConfigSettings()
                }
                .catch { error ->
                    handleFirestoreError(error, OperationType.GET, docRef.path)
                    emit(AppConfigSettings())
                }
        )
    }

    /**
     * Award Gem for finding the target image in Image Finder Game
     */
    suspend fun awardGameGem(): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)
        try {
            userDoc.update(
                mapOf(
                    "gems" to FieldValue.increment(1),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            userDao?.addGems(uid, 1)
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userDoc.path)
            Result.failure(e)
        }
    }

    /**
     * Unlock Super Offer by spending gems and claiming high-value coin reward
     */
    suspend fun completeSuperOffer(requiredGems: Long, rewardCoins: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)
        try {
            val userSnap = userDoc.get().await()
            val currentGems = userSnap.getLong("gems") ?: 0L
            if (currentGems < requiredGems) {
                return@withContext Result.failure(IllegalStateException("Insufficient gems. You need $requiredGems gems to unlock this offer."))
            }

            userDoc.update(
                mapOf(
                    "gems" to FieldValue.increment(-requiredGems),
                    "coins" to FieldValue.increment(rewardCoins),
                    "dailyCoins" to FieldValue.increment(rewardCoins),
                    "weeklyCoins" to FieldValue.increment(rewardCoins),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            userDao?.deductGems(uid, requiredGems)
            userDao?.addCoins(uid, rewardCoins)
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userDoc.path)
            Result.failure(e)
        }
    }

    /**
     * Claim reward coins for completing a task
     */
    suspend fun claimTaskReward(rewardCoins: Long): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)
        try {
            userDoc.update(
                mapOf(
                    "coins" to FieldValue.increment(rewardCoins),
                    "dailyCoins" to FieldValue.increment(rewardCoins),
                    "weeklyCoins" to FieldValue.increment(rewardCoins),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            userDao?.addCoins(uid, rewardCoins)
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, userDoc.path)
            Result.failure(e)
        }
    }

    /**
     * Submit payout withdrawal request
     */
    suspend fun submitWithdrawal(
        userName: String,
        userEmail: String,
        payoutMethod: PayoutMethod,
        accountDetail: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)

        try {
            val userSnap = userDoc.get().await()
            val currentCoins = userSnap.getLong("coins") ?: 0L
            if (currentCoins < payoutMethod.minCoins) {
                return@withContext Result.failure(IllegalStateException("Insufficient coins. Required: ${payoutMethod.minCoins}, Available: $currentCoins"))
            }

            // Deduct coins and create withdrawal document
            val withdrawalRef = db.collection("withdrawals").document()
            val withdrawalData = mapOf(
                "userId" to uid,
                "userName" to userName,
                "userEmail" to userEmail,
                "methodId" to payoutMethod.id,
                "methodTitle" to payoutMethod.title,
                "accountDetail" to accountDetail,
                "coinsDeducted" to payoutMethod.minCoins,
                "cashAmount" to payoutMethod.cashAmount,
                "status" to "PENDING",
                "createdAt" to FieldValue.serverTimestamp()
            )

            db.runBatch { batch ->
                batch.update(
                    userDoc,
                    mapOf(
                        "coins" to FieldValue.increment(-payoutMethod.minCoins),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.set(withdrawalRef, withdrawalData)
            }.await()

            userDao?.deductCoins(uid, payoutMethod.minCoins)
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "withdrawals")
            Result.failure(e)
        }
    }

    /**
     * Clean up local Room balance on logout
     */
    suspend fun clearLocalData() = withContext(Dispatchers.IO) {
        userDao?.clearAll()
    }
}
