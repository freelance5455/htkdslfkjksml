package com.example.data.storage

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.example.data.model.ApkPackageMetadata
import com.example.data.model.FileKind
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

data class FileTypeAnalysis(
    val kind: FileKind,
    val mimeType: String,
    val magicSignature: String?,
    val hasSuspiciousDoubleExtension: Boolean,
    val doubleExtensionWarning: String?
)

object FileTypeInspector {

    private val dangerousExtensions = setOf("exe", "msi", "bat", "cmd", "scr", "com", "vbs", "js", "apk", "xapk", "apks", "sh")
    private val benignDecoyExtensions = setOf("jpg", "jpeg", "png", "gif", "webp", "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "mp3", "mp4")

    fun inspect(
        fileName: String,
        isDirectory: Boolean,
        headerBytes: ByteArray? = null
    ): FileTypeAnalysis {
        if (isDirectory) {
            return FileTypeAnalysis(
                kind = FileKind.FOLDER,
                mimeType = "inode/directory",
                magicSignature = null,
                hasSuspiciousDoubleExtension = false,
                doubleExtensionWarning = null
            )
        }

        val parts = fileName.split('.').filter { it.isNotBlank() }
        val ext = if (parts.size >= 2) parts.last().lowercase() else ""
        val prevExt = if (parts.size >= 3) parts[parts.size - 2].lowercase() else ""

        val doubleExtSuspicious = prevExt in benignDecoyExtensions && ext in dangerousExtensions
        val doubleExtWarning = if (doubleExtSuspicious) {
            "Suspicious double extension detected (.$prevExt.$ext). This file disguises an executable or installer as a media/document file."
        } else null

        val magic = detectMagicSignature(headerBytes)

        val kindByExt = when (ext) {
            "apk" -> FileKind.APK
            "apks" -> FileKind.APKS
            "xapk" -> FileKind.XAPK
            "exe" -> FileKind.EXE
            "msi" -> FileKind.MSI
            "zip" -> FileKind.ZIP
            "rar", "7z", "tar", "gz", "bz2", "xz" -> FileKind.ARCHIVE
            "pdf" -> FileKind.PDF
            "doc", "docx", "odt", "rtf" -> FileKind.WORD
            "xls", "xlsx", "csv", "ods" -> FileKind.EXCEL
            "ppt", "pptx", "odp" -> FileKind.POWERPOINT
            "txt", "md", "json", "xml", "log", "kt", "java", "py", "html", "css", "yaml", "yml", "ini" -> FileKind.TEXT
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg" -> FileKind.IMAGE
            "mp3", "wav", "flac", "aac", "ogg", "m4a", "opus" -> FileKind.AUDIO
            "mp4", "mkv", "webm", "mov", "avi", "3gp", "m4v" -> FileKind.VIDEO
            else -> null
        }

        // Magic byte override or enrichment when extension is missing or mismatched
        val resolvedKind = when {
            magic == "Windows PE (MZ)" && kindByExt != FileKind.MSI -> FileKind.EXE
            kindByExt != null -> kindByExt
            magic == "PDF Header (%PDF)" -> FileKind.PDF
            magic == "PNG Signature" || magic == "JPEG SOI" || magic == "GIF89a/87a" || magic == "RIFF WEBP" -> FileKind.IMAGE
            magic == "ZIP / JAR / APK (PK)" -> FileKind.ZIP
            magic == "7-Zip Signature" || magic == "RAR Archive" || magic == "GZIP Stream" -> FileKind.ARCHIVE
            magic == "ID3 / MP3" || magic == "FLAC Stream" || magic == "OggS Container" -> FileKind.AUDIO
            magic == "ISO Media / MP4 (ftyp)" -> FileKind.VIDEO
            else -> FileKind.GENERIC
        }

        val mime = when (resolvedKind) {
            FileKind.FOLDER -> "inode/directory"
            FileKind.APK -> "application/vnd.android.package-archive"
            FileKind.APKS, FileKind.XAPK, FileKind.ZIP -> "application/zip"
            FileKind.EXE, FileKind.MSI -> "application/x-msdownload"
            FileKind.ARCHIVE -> "application/octet-stream"
            FileKind.PDF -> "application/pdf"
            FileKind.WORD -> "application/msword"
            FileKind.EXCEL -> "application/vnd.ms-excel"
            FileKind.POWERPOINT -> "application/vnd.ms-powerpoint"
            FileKind.TEXT -> "text/plain"
            FileKind.IMAGE -> when (ext) {
                "png" -> "image/png"
                "gif" -> "image/gif"
                "webp" -> "image/webp"
                else -> "image/jpeg"
            }
            FileKind.AUDIO -> when (ext) {
                "wav" -> "audio/wav"
                "flac" -> "audio/flac"
                "ogg" -> "audio/ogg"
                else -> "audio/mpeg"
            }
            FileKind.VIDEO -> when (ext) {
                "webm" -> "video/webm"
                "mkv" -> "video/x-matroska"
                else -> "video/mp4"
            }
            FileKind.GENERIC -> "application/octet-stream"
        }

        return FileTypeAnalysis(
            kind = resolvedKind,
            mimeType = mime,
            magicSignature = magic,
            hasSuspiciousDoubleExtension = doubleExtSuspicious,
            doubleExtensionWarning = doubleExtWarning
        )
    }

    fun readHeaderBytes(file: File, count: Int = 16): ByteArray? {
        if (!file.exists() || !file.isFile || !file.canRead()) return null
        return try {
            file.inputStream().use { stream ->
                val buf = ByteArray(count)
                val read = stream.read(buf)
                if (read > 0) buf.copyOf(read) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    fun readHeaderBytes(streamProvider: () -> InputStream?, count: Int = 16): ByteArray? {
        return try {
            streamProvider()?.use { stream ->
                val buf = ByteArray(count)
                val read = stream.read(buf)
                if (read > 0) buf.copyOf(read) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun detectMagicSignature(bytes: ByteArray?): String? {
        if (bytes == null || bytes.size < 2) return null
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val b2 = if (bytes.size > 2) bytes[2].toInt() and 0xFF else -1
        val b3 = if (bytes.size > 3) bytes[3].toInt() and 0xFF else -1

        return when {
            b0 == 0x4D && b1 == 0x5A -> "Windows PE (MZ)"
            b0 == 0x50 && b1 == 0x4B && (b2 == 0x03 || b2 == 0x05) -> "ZIP / JAR / APK (PK)"
            b0 == 0x25 && b1 == 0x50 && b2 == 0x44 && b3 == 0x46 -> "PDF Header (%PDF)"
            b0 == 0x89 && b1 == 0x50 && b2 == 0x4E && b3 == 0x47 -> "PNG Signature"
            b0 == 0xFF && b1 == 0xD8 && b2 == 0xFF -> "JPEG SOI"
            b0 == 0x47 && b1 == 0x49 && b2 == 0x46 && b3 == 0x38 -> "GIF89a/87a"
            b0 == 0x52 && b1 == 0x49 && b2 == 0x46 && b3 == 0x46 && bytes.size >= 12 &&
                bytes[8].toInt().toChar() == 'W' && bytes[9].toInt().toChar() == 'E' -> "RIFF WEBP"
            b0 == 0x37 && b1 == 0x7A && b2 == 0xBC && b3 == 0xAF -> "7-Zip Signature"
            b0 == 0x52 && b1 == 0x61 && b2 == 0x72 && b3 == 0x21 -> "RAR Archive"
            b0 == 0x1F && b1 == 0x8B -> "GZIP Stream"
            b0 == 0x49 && b1 == 0x44 && b2 == 0x33 -> "ID3 / MP3"
            b0 == 0x66 && b1 == 0x4C && b2 == 0x61 && b3 == 0x43 -> "FLAC Stream"
            b0 == 0x4F && b1 == 0x67 && b2 == 0x67 && b3 == 0x53 -> "OggS Container"
            bytes.size >= 8 && bytes[4].toInt().toChar() == 'f' &&
                bytes[5].toInt().toChar() == 't' &&
                bytes[6].toInt().toChar() == 'y' &&
                bytes[7].toInt().toChar() == 'p' -> "ISO Media / MP4 (ftyp)"
            else -> null
        }
    }

    /**
     * Parses real Android APK package metadata via PackageManager.getPackageArchiveInfo
     * or inspects XAPK / APKS ZIP manifests (`manifest.json` / `info.json`).
     */
    fun inspectApkArchive(
        context: Context,
        fileName: String,
        sizeBytes: Long,
        localFile: File?,
        streamProvider: (() -> InputStream?)? = null
    ): ApkPackageMetadata {
        val lower = fileName.lowercase()
        val isBundle = lower.endsWith(".xapk") || lower.endsWith(".apks")
        val installNote = "Direct silent package installation requires privileged system installer permissions restricted by Google Play security policies. You can inspect full package metadata here or share the archive to your device's system Package Installer."

        // Local .apk file: inspect directly via Android PackageManager + ZipFile count
        if (!isBundle && localFile != null && localFile.exists()) {
            var entryCount = 0
            runCatching {
                ZipFile(localFile).use { zf -> entryCount = zf.size() }
            }
            val pm = context.packageManager
            val pkgInfo = runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageArchiveInfo(localFile.absolutePath, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageArchiveInfo(localFile.absolutePath, 0)
                }
            }.getOrNull()

            if (pkgInfo != null) {
                val appInfo = pkgInfo.applicationInfo
                appInfo?.sourceDir = localFile.absolutePath
                appInfo?.publicSourceDir = localFile.absolutePath
                val label = appInfo?.let { runCatching { pm.getApplicationLabel(it).toString() }.getOrNull() }
                val vCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    pkgInfo.longVersionCode
                } else {
                    @Suppress("DEPRECATION")
                    pkgInfo.versionCode.toLong()
                }
                return ApkPackageMetadata(
                    fileName = fileName,
                    sizeBytes = sizeBytes,
                    packageName = pkgInfo.packageName,
                    appLabel = label,
                    versionName = pkgInfo.versionName,
                    versionCode = vCode,
                    minSdk = appInfo?.minSdkVersion,
                    targetSdk = appInfo?.targetSdkVersion,
                    archiveEntriesCount = entryCount,
                    isBundleFormat = false,
                    installExplanation = installNote
                )
            }
        }

        // XAPK / APKS or SAF stream inspection via ZipInputStream
        var entries = 0
        var parsedPkg: String? = null
        var parsedLabel: String? = null
        var parsedVersionName: String? = null
        var parsedVersionCode: Long? = null
        var parsedMinSdk: Int? = null
        var parsedTargetSdk: Int? = null

        val openStream: InputStream? = when {
            localFile != null && localFile.exists() -> runCatching { localFile.inputStream() }.getOrNull()
            streamProvider != null -> runCatching { streamProvider() }.getOrNull()
            else -> null
        }

        openStream?.use { raw ->
            runCatching {
                ZipInputStream(raw).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        entries++
                        val entryName = entry.name.lowercase()
                        if (entryName == "manifest.json" || entryName == "info.json") {
                            val jsonText = zis.bufferedReader().readText()
                            val obj = JSONObject(jsonText)
                            parsedPkg = obj.optString("package_name").takeIf { it.isNotBlank() }
                                ?: obj.optString("packageName").takeIf { it.isNotBlank() }
                            parsedLabel = obj.optString("name").takeIf { it.isNotBlank() }
                                ?: obj.optString("label").takeIf { it.isNotBlank() }
                            parsedVersionName = obj.optString("version_name").takeIf { it.isNotBlank() }
                                ?: obj.optString("versionName").takeIf { it.isNotBlank() }
                            parsedVersionCode = obj.optLong("version_code", -1L).takeIf { it > 0 }
                            parsedMinSdk = obj.optInt("min_sdk_version", -1).takeIf { it > 0 }
                            parsedTargetSdk = obj.optInt("target_sdk_version", -1).takeIf { it > 0 }
                        }
                        entry = zis.nextEntry
                    }
                }
            }
        }

        return ApkPackageMetadata(
            fileName = fileName,
            sizeBytes = sizeBytes,
            packageName = parsedPkg,
            appLabel = parsedLabel,
            versionName = parsedVersionName,
            versionCode = parsedVersionCode,
            minSdk = parsedMinSdk,
            targetSdk = parsedTargetSdk,
            archiveEntriesCount = entries,
            isBundleFormat = isBundle,
            installExplanation = installNote
        )
    }
}
