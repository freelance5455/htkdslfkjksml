package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.local.CommitteeEntity
import com.example.data.local.MemberEntity
import com.example.data.local.ProgramEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

@IgnoreExtraProperties
data class FirestoreMember(
    val id: String = "",
    val type: String = "worker",
    val union: String = "",
    val ward: String = "",
    val sovapotiName: String = "",
    val sovapotiMobile: String = "",
    val sovapotiFb: String = "",
    val secretaryName: String = "",
    val secretaryMobile: String = "",
    val secretaryFb: String = "",
    val otherDesignation: String = "",
    val otherName: String = "",
    val otherMobile: String = "",
    val otherFb: String = "",
    val workerName: String = "",
    val workerDesignation: String = "",
    val workerMobile: String = "",
    val workerFb: String = "",
    val createdAt: String = "",
    val userId: String = ""
)

@IgnoreExtraProperties
data class FirestoreCommittee(
    val id: String = "",
    val unit: String = "",
    val sovapotiName: String = "",
    val sovapotiMobile: String = "",
    val sovapotiFb: String = "",
    val secretaryName: String = "",
    val secretaryMobile: String = "",
    val secretaryFb: String = "",
    val otherDesignation: String = "",
    val otherName: String = "",
    val otherMobile: String = "",
    val otherFb: String = "",
    val createdAt: String = "",
    val userId: String = ""
)

@IgnoreExtraProperties
data class FirestoreProgram(
    val id: String = "",
    val title: String = "",
    val unit: String = "",
    val date: String = "",
    val time: String = "",
    val location: String = "",
    val description: String = "",
    val status: String = "আসন্ন",
    val authorName: String = "",
    val userId: String = ""
)

class FirestoreRepository(
    private val db: FirebaseFirestore
) {
    companion object {
        private const val TAG = "FirestoreRepo"

        fun create(context: Context): FirestoreRepository {
            val databaseId = context.getString(R.string.firestore_database_id)
            val db = FirebaseFirestore.getInstance(databaseId)
            return FirestoreRepository(db)
        }
    }

    suspend fun saveMember(member: MemberEntity, userId: String): Result<String> {
        return try {
            val docRef = if (member.id > 0) {
                db.collection("members").document("member_${member.id}")
            } else {
                db.collection("members").document()
            }

            val data = hashMapOf<String, Any>(
                "id" to docRef.id,
                "type" to member.type,
                "union" to member.union,
                "ward" to member.ward,
                "sovapotiName" to member.sovapotiName,
                "sovapotiMobile" to member.sovapotiMobile,
                "sovapotiFb" to member.sovapotiFb,
                "secretaryName" to member.secretaryName,
                "secretaryMobile" to member.secretaryMobile,
                "secretaryFb" to member.secretaryFb,
                "otherDesignation" to member.otherDesignation,
                "otherName" to member.otherName,
                "otherMobile" to member.otherMobile,
                "otherFb" to member.otherFb,
                "workerName" to member.workerName,
                "workerDesignation" to member.workerDesignation,
                "workerMobile" to member.workerMobile,
                "workerFb" to member.workerFb,
                "createdAt" to member.createdAt,
                "userId" to userId
            )

            docRef.set(data).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving member to Firestore", e)
            Result.failure(e)
        }
    }

    suspend fun saveCommitteeMember(
        name: String,
        designation: String,
        contactNumber: String,
        wardNumber: String,
        unit: String,
        fbLink: String = "",
        userId: String
    ): Result<String> {
        val today = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(java.util.Date())
        val member = MemberEntity(
            type = "committee",
            union = unit,
            ward = wardNumber,
            workerName = name,
            workerDesignation = designation,
            workerMobile = contactNumber,
            workerFb = fbLink,
            otherName = name,
            otherDesignation = designation,
            otherMobile = contactNumber,
            otherFb = fbLink,
            createdAt = today
        )
        return saveMember(member, userId)
    }

    suspend fun saveCommittee(committee: CommitteeEntity, userId: String): Result<String> {
        return try {
            val docRef = if (committee.id > 0) {
                db.collection("committees").document("committee_${committee.id}")
            } else {
                db.collection("committees").document()
            }

            val data = hashMapOf<String, Any>(
                "id" to docRef.id,
                "unit" to committee.unit,
                "sovapotiName" to committee.sovapotiName,
                "sovapotiMobile" to committee.sovapotiMobile,
                "sovapotiFb" to committee.sovapotiFb,
                "secretaryName" to committee.secretaryName,
                "secretaryMobile" to committee.secretaryMobile,
                "secretaryFb" to committee.secretaryFb,
                "otherDesignation" to committee.otherDesignation,
                "otherName" to committee.otherName,
                "otherMobile" to committee.otherMobile,
                "otherFb" to committee.otherFb,
                "createdAt" to committee.createdAt,
                "userId" to userId
            )

            docRef.set(data).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving committee to Firestore", e)
            Result.failure(e)
        }
    }

    suspend fun saveProgram(program: ProgramEntity, userId: String): Result<String> {
        return try {
            val docRef = if (program.id > 0) {
                db.collection("programs").document("program_${program.id}")
            } else {
                db.collection("programs").document()
            }

            val data = hashMapOf<String, Any>(
                "id" to docRef.id,
                "title" to program.title,
                "unit" to program.unit,
                "date" to program.date,
                "time" to program.time,
                "location" to program.location,
                "description" to program.description,
                "status" to program.status,
                "authorName" to program.authorName,
                "userId" to userId
            )

            docRef.set(data).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving program to Firestore", e)
            Result.failure(e)
        }
    }

    fun observeMembers(): Flow<List<FirestoreMember>> {
        return db.collection("members")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(FirestoreMember::class.java)
            }
    }

    fun observeCommittees(): Flow<List<FirestoreCommittee>> {
        return db.collection("committees")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(FirestoreCommittee::class.java)
            }
    }

    fun observePrograms(): Flow<List<FirestoreProgram>> {
        return db.collection("programs")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(FirestoreProgram::class.java)
            }
    }
}
