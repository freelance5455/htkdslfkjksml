package com.example.data.repository

import com.example.data.dao.ExamDao
import com.example.data.exam.ExamDateHelper
import com.example.data.model.ExamEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate

class ExamRepository(
    private val examDao: ExamDao
) {
    val allExamsFlow: Flow<List<ExamEntity>> = examDao.getAllExamsFlow()

    // Automatically distinguishes active (upcoming or today) vs archived (past or marked archived)
    val activeExamsFlow: Flow<List<ExamEntity>> = allExamsFlow.map { exams ->
        val today = LocalDate.now()
        exams.filter { exam ->
            try {
                val examDate = LocalDate.parse(exam.date)
                !ExamDateHelper.isExamPast(examDate, today) && !exam.isArchived
            } catch (e: Exception) {
                !exam.isArchived
            }
        }.sortedBy { it.date }
    }

    val archivedExamsFlow: Flow<List<ExamEntity>> = allExamsFlow.map { exams ->
        val today = LocalDate.now()
        exams.filter { exam ->
            try {
                val examDate = LocalDate.parse(exam.date)
                ExamDateHelper.isExamPast(examDate, today) || exam.isArchived
            } catch (e: Exception) {
                exam.isArchived
            }
        }.sortedByDescending { it.date }
    }

    suspend fun getExamById(id: Long): ExamEntity? = examDao.getExamById(id)

    suspend fun addExam(
        name: String,
        date: String,
        subjectId: Long?,
        remind30: Boolean,
        remind7: Boolean,
        remind1: Boolean
    ): Long {
        val entity = ExamEntity(
            name = name.trim(),
            date = date,
            subjectId = subjectId,
            remind30Days = remind30,
            remind7Days = remind7,
            remind1Day = remind1,
            isArchived = false
        )
        return examDao.insertExam(entity)
    }

    suspend fun updateExam(exam: ExamEntity) {
        examDao.updateExam(exam)
    }

    suspend fun archiveExam(id: Long) {
        examDao.archiveExam(id)
    }

    suspend fun restoreExam(id: Long) {
        examDao.restoreExam(id)
    }

    suspend fun deleteExam(id: Long) {
        examDao.deleteExam(id)
    }
}
