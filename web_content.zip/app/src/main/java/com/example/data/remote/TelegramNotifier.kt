package com.example.data.remote

import com.example.data.model.Order
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class TelegramNotifier {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    fun formatOrderMessage(order: Order): String {
        return """
🚨 *NEW ORDER RECEIVED - EDITO X AI STUDIO*

👤 *Client Name:* ${order.clientName}
📞 *Contact Number:* ${order.clientContact}
🛠 *Service Requested:* ${order.serviceType}
💰 *Amount / Budget:* ₹${order.budget.ifBlank { "Not Specified" }}
📅 *Deadline:* ${order.deadline.ifBlank { "Not Specified" }}
📁 *Assets Drive Link:* ${order.fileLink?.ifBlank { "Not Provided" } ?: "Not Provided"}
📝 *Special Instructions:* ${order.notes?.ifBlank { "None" } ?: "None"}
💳 *Payment Status:* ${order.paymentStatus}
⏱ *Order ID:* #${order.id}
        """.trimIndent()
    }

    suspend fun sendTelegramAlert(
        order: Order,
        botToken: String,
        chatId: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (botToken.isBlank() || chatId.isBlank() || botToken == "YOUR_TELEGRAM_BOT_TOKEN") {
            // Simulated/Local Notification mode
            return@withContext Result.success("Order logged locally (Configure Telegram Bot Token in Studio Settings for live webhook delivery).")
        }

        try {
            val message = formatOrderMessage(order)
            val json = JSONObject().apply {
                put("chat_id", chatId)
                put("text", message)
                put("parse_mode", "Markdown")
            }

            val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url("https://api.telegram.org/bot$botToken/sendMessage")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                Result.success("Telegram alert dispatched successfully!")
            } else {
                val errorMsg = response.body?.string() ?: "Unknown error"
                Result.failure(Exception("Telegram API error ${response.code}: $errorMsg"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
