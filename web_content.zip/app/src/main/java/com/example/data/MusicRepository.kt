package com.example.data

import com.example.data.dao.PlaylistDao
import com.example.data.dao.QueueDao
import com.example.data.dao.SongDao
import com.example.data.model.PlaylistEntity
import com.example.data.model.PlaylistSongCrossRef
import com.example.data.model.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MusicRepository(
    private val songDao: SongDao,
    private val playlistDao: PlaylistDao,
    private val queueDao: QueueDao
) {
    val allSongs: Flow<List<SongEntity>> = songDao.getAllSongs()
    val favoriteSongs: Flow<List<SongEntity>> = songDao.getFavoriteSongs()
    val recentlyPlayedSongs: Flow<List<SongEntity>> = songDao.getRecentlyPlayedSongs(20)
    val recentlyAddedSongs: Flow<List<SongEntity>> = songDao.getRecentlyAddedSongs(20)
    val allPlaylists: Flow<List<PlaylistEntity>> = playlistDao.getAllPlaylists()

    fun searchSongs(query: String): Flow<List<SongEntity>> = songDao.searchSongs(query)

    suspend fun getSongById(id: Long): SongEntity? = withContext(Dispatchers.IO) {
        songDao.getSongById(id)
    }

    suspend fun getSongByHash(hash: String): SongEntity? = withContext(Dispatchers.IO) {
        songDao.getSongByHash(hash)
    }

    suspend fun insertSong(song: SongEntity): Long = withContext(Dispatchers.IO) {
        songDao.insertSong(song)
    }

    suspend fun updateSong(song: SongEntity) = withContext(Dispatchers.IO) {
        songDao.updateSong(song)
    }

    suspend fun deleteSong(id: Long) = withContext(Dispatchers.IO) {
        songDao.deleteSongById(id)
    }

    suspend fun deleteSongs(ids: List<Long>) = withContext(Dispatchers.IO) {
        songDao.deleteSongsByIds(ids)
    }

    suspend fun toggleFavorite(songId: Long, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        songDao.setFavorite(songId, isFavorite)
    }

    suspend fun recordPlay(songId: Long) = withContext(Dispatchers.IO) {
        songDao.recordPlay(songId, System.currentTimeMillis())
    }

    suspend fun createPlaylist(name: String, description: String = "", customArtworkPath: String? = null): Long =
        withContext(Dispatchers.IO) {
            playlistDao.insertPlaylist(
                PlaylistEntity(
                    name = name.trim(),
                    description = description.trim(),
                    customArtworkPath = customArtworkPath
                )
            )
        }

    suspend fun updatePlaylist(playlist: PlaylistEntity) = withContext(Dispatchers.IO) {
        playlistDao.updatePlaylist(playlist)
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        playlistDao.deletePlaylistById(playlistId)
    }

    fun getSongsForPlaylist(playlistId: Long): Flow<List<SongEntity>> =
        playlistDao.getSongsForPlaylist(playlistId)

    suspend fun getSongsForPlaylistOnce(playlistId: Long): List<SongEntity> = withContext(Dispatchers.IO) {
        playlistDao.getSongsForPlaylistOnce(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        val currentMax = playlistDao.getMaxSortOrder(playlistId) ?: -1
        playlistDao.insertCrossRef(
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = songId,
                sortOrder = currentMax + 1
            )
        )
    }

    suspend fun addSongsToPlaylist(playlistId: Long, songIds: List<Long>) = withContext(Dispatchers.IO) {
        val currentMax = playlistDao.getMaxSortOrder(playlistId) ?: -1
        val refs = songIds.mapIndexed { index, sId ->
            PlaylistSongCrossRef(
                playlistId = playlistId,
                songId = sId,
                sortOrder = currentMax + 1 + index
            )
        }
        playlistDao.insertCrossRefs(refs)
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) = withContext(Dispatchers.IO) {
        playlistDao.removeSongFromPlaylist(playlistId, songId)
    }

    suspend fun reorderPlaylist(playlistId: Long, songIdsInOrder: List<Long>) = withContext(Dispatchers.IO) {
        playlistDao.reorderSongs(playlistId, songIdsInOrder)
    }

    suspend fun saveQueue(songIdsInOrder: List<Long>) = withContext(Dispatchers.IO) {
        queueDao.saveQueue(songIdsInOrder)
    }

    suspend fun getSavedQueue(): List<SongEntity> = withContext(Dispatchers.IO) {
        queueDao.getQueueSongsOnce()
    }

    suspend fun getAllSongFilePaths(): List<String> = withContext(Dispatchers.IO) {
        songDao.getAllFilePaths()
    }

    suspend fun getAllArtworkPaths(): List<String> = withContext(Dispatchers.IO) {
        songDao.getAllArtworkPaths()
    }
}
