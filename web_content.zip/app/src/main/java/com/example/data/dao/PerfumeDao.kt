package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Perfume
import kotlinx.coroutines.flow.Flow

@Dao
interface PerfumeDao {
    @Query("SELECT * FROM perfumes ORDER BY nome ASC, validade ASC")
    fun getAllPerfumes(): Flow<List<Perfume>>

    @Query("SELECT * FROM perfumes WHERE id = :id LIMIT 1")
    suspend fun getPerfumeById(id: Long): Perfume?

    @Query("SELECT * FROM perfumes WHERE codigo = :codigo ORDER BY validade ASC")
    fun getPerfumesByCodigoFlow(codigo: String): Flow<List<Perfume>>

    @Query("SELECT * FROM perfumes WHERE codigo = :codigo ORDER BY validade ASC")
    suspend fun getPerfumesByCodigoList(codigo: String): List<Perfume>

    @Query("SELECT * FROM perfumes WHERE nome LIKE '%' || :query || '%' OR marca LIKE '%' || :query || '%' OR codigo LIKE '%' || :query || '%' ORDER BY nome ASC, validade ASC")
    fun searchPerfumes(query: String): Flow<List<Perfume>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerfume(perfume: Perfume): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(perfumes: List<Perfume>)

    @Update
    suspend fun updatePerfume(perfume: Perfume)

    @Delete
    suspend fun deletePerfume(perfume: Perfume)

    @Query("DELETE FROM perfumes WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE perfumes SET estoque = :novoEstoque WHERE id = :id")
    suspend fun updateEstoque(id: Long, novoEstoque: Int)

    @Query("SELECT COUNT(*) FROM perfumes")
    suspend fun getPerfumesCount(): Int
}
