package com.example.data

import android.content.Context
import com.example.R
import com.example.model.Booking
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class BookingRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val bookingsCollection = db.collection("bookings")

    fun observeCustomerBookings(customerUid: String): Flow<List<Booking>> =
        bookingsCollection
            .whereEqualTo("customerUid", customerUid)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Booking::class.java)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, bookingsCollection.path)
                }
                throw error
            }

    fun observeAllBookings(): Flow<List<Booking>> =
        bookingsCollection
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Booking::class.java)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, bookingsCollection.path)
                }
                throw error
            }

    suspend fun createBooking(booking: Booking): Result<String> {
        return try {
            val payload = mapOf(
                "customerUid" to booking.customerUid,
                "customerName" to booking.customerName.trim(),
                "customerPhone" to booking.customerPhone.trim(),
                "providerId" to booking.providerId,
                "providerName" to booking.providerName,
                "category" to booking.category,
                "city" to booking.city,
                "address" to booking.address.trim(),
                "description" to booking.description.trim(),
                "preferredDate" to booking.preferredDate,
                "preferredTime" to booking.preferredTime,
                "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val docRef = bookingsCollection.document()
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, bookingsCollection.path)
            Result.failure(e)
        }
    }

    suspend fun cancelBooking(bookingId: String): Result<Unit> {
        val docRef = bookingsCollection.document(bookingId)
        return try {
            docRef.update(
                mapOf(
                    "status" to "cancelled",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateBookingStatusByAdmin(bookingId: String, newStatus: String): Result<Unit> {
        require(newStatus in listOf("pending", "accepted", "completed", "cancelled")) {
            "Invalid status transition"
        }
        val docRef = bookingsCollection.document(bookingId)
        return try {
            docRef.update(
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }
}
