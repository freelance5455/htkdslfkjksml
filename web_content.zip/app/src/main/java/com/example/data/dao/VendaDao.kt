package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Venda
import kotlinx.coroutines.flow.Flow

@Dao
interface VendaDao {
    @Query("SELECT * FROM vendas ORDER BY dataHora DESC")
    fun getAllVendas(): Flow<List<Venda>>

    @Query("SELECT * FROM vendas ORDER BY dataHora DESC LIMIT :limit")
    fun getRecentVendas(limit: Int = 100): Flow<List<Venda>>

    @Query("SELECT * FROM vendas WHERE id = :id LIMIT 1")
    suspend fun getVendaById(id: Long): Venda?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVenda(venda: Venda): Long

    @Update
    suspend fun updateVenda(venda: Venda)

    @Delete
    suspend fun deleteVenda(venda: Venda)

    @Query("DELETE FROM vendas WHERE id = :id")
    suspend fun deleteVendaById(id: Long)

    @Query("SELECT SUM(total) FROM vendas")
    fun getTotalVendasValor(): Flow<Double?>

    @Query("SELECT COUNT(*) FROM vendas")
    fun getTotalVendasCount(): Flow<Int>

    @Query("DELETE FROM vendas")
    suspend fun clearAllVendas()
}
