package com.example.data.analytics

import com.example.data.model.StudySessionEntity
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.Locale

enum class PerformancePeriod {
    WEEKLY,
    MONTHLY,
    YEARLY
}

data class ChartBarData(
    val label: String,
    val dateOrPeriod: String,
    val totalMinutes: Int,
    val subjectBreakdown: Map<Long, Int> = emptyMap()
)

data class PeriodDateRange(
    val startDate: LocalDate,
    val endDate: LocalDate,
    val prevStartDate: LocalDate,
    val prevEndDate: LocalDate,
    val title: String,
    val prevTitle: String
)

data class PerformanceMetrics(
    val period: PerformancePeriod,
    val range: PeriodDateRange,
    val totalMinutes: Int,
    val totalHours: Double,
    val sessionCount: Int,
    val averageHoursPerDay: Double,
    val bestDayDate: LocalDate?,
    val bestDayMinutes: Int,
    val mostStudiedSubjectId: Long?,
    val mostStudiedMinutes: Int,
    val leastStudiedSubjectId: Long?,
    val leastStudiedMinutes: Int,
    val prevTotalMinutes: Int,
    val percentageChange: Double?, // null if prev is 0 and current is 0
    val chartBars: List<ChartBarData>,
    val subjectMinutes: Map<Long, Int>,
    val textSummary: String
)

object PerformanceCalculator {

    fun getWeekDateRange(referenceDate: LocalDate, weekOffset: Int = 0): PeriodDateRange {
        val target = referenceDate.plusWeeks(weekOffset.toLong())
        val start = target.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        val end = target.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))

        val prevStart = start.minusWeeks(1)
        val prevEnd = end.minusWeeks(1)

        val title = "Week of ${start.month.name.take(3)} ${start.dayOfMonth} - ${end.month.name.take(3)} ${end.dayOfMonth}, ${end.year}"
        val prevTitle = "Week of ${prevStart.month.name.take(3)} ${prevStart.dayOfMonth} - ${prevEnd.month.name.take(3)} ${prevEnd.dayOfMonth}"

        return PeriodDateRange(start, end, prevStart, prevEnd, title, prevTitle)
    }

    fun getMonthDateRange(referenceDate: LocalDate, monthOffset: Int = 0): PeriodDateRange {
        val targetYm = YearMonth.from(referenceDate).plusMonths(monthOffset.toLong())
        val start = targetYm.atDay(1)
        val end = targetYm.atEndOfMonth()

        val prevYm = targetYm.minusMonths(1)
        val prevStart = prevYm.atDay(1)
        val prevEnd = prevYm.atEndOfMonth()

        val title = "${targetYm.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${targetYm.year}"
        val prevTitle = "${prevYm.month.name.lowercase().replaceFirstChar { it.uppercase() }} ${prevYm.year}"

        return PeriodDateRange(start, end, prevStart, prevEnd, title, prevTitle)
    }

    fun getYearDateRange(referenceDate: LocalDate, yearOffset: Int = 0): PeriodDateRange {
        val targetYear = referenceDate.year + yearOffset
        val start = LocalDate.of(targetYear, 1, 1)
        val end = LocalDate.of(targetYear, 12, 31)

        val prevYear = targetYear - 1
        val prevStart = LocalDate.of(prevYear, 1, 1)
        val prevEnd = LocalDate.of(prevYear, 12, 31)

        val title = "$targetYear"
        val prevTitle = "$prevYear"

        return PeriodDateRange(start, end, prevStart, prevEnd, title, prevTitle)
    }

    fun calculateWeeklyPerformance(
        sessions: List<StudySessionEntity>,
        referenceDate: LocalDate = LocalDate.now(),
        weekOffset: Int = 0,
        subjectNames: Map<Long, String> = emptyMap()
    ): PerformanceMetrics {
        val range = getWeekDateRange(referenceDate, weekOffset)
        val currentSessions = filterSessionsInRange(sessions, range.startDate, range.endDate)
        val prevSessions = filterSessionsInRange(sessions, range.prevStartDate, range.prevEndDate)

        // Build 7 bars: Mon through Sun
        val bars = mutableListOf<ChartBarData>()
        val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        var cursor = range.startDate
        var dayIdx = 0

        val dailyMinutesMap = mutableMapOf<LocalDate, Int>()

        while (!cursor.isAfter(range.endDate)) {
            val daySessions = currentSessions.filter { it.date == cursor.toString() }
            val totalMins = daySessions.sumOf { it.durationMinutes }
            dailyMinutesMap[cursor] = totalMins

            val breakdown = daySessions.groupBy { it.subjectId }
                .mapValues { entry -> entry.value.sumOf { it.durationMinutes } }

            bars.add(
                ChartBarData(
                    label = dayNames.getOrElse(dayIdx) { cursor.dayOfWeek.name.take(3) },
                    dateOrPeriod = cursor.toString(),
                    totalMinutes = totalMins,
                    subjectBreakdown = breakdown
                )
            )
            cursor = cursor.plusDays(1)
            dayIdx++
        }

        return computeMetrics(
            period = PerformancePeriod.WEEKLY,
            range = range,
            currentSessions = currentSessions,
            prevSessions = prevSessions,
            dailyMinutesMap = dailyMinutesMap,
            chartBars = bars,
            daysInPeriod = 7,
            subjectNames = subjectNames
        )
    }

    fun calculateMonthlyPerformance(
        sessions: List<StudySessionEntity>,
        referenceDate: LocalDate = LocalDate.now(),
        monthOffset: Int = 0,
        subjectNames: Map<Long, String> = emptyMap()
    ): PerformanceMetrics {
        val range = getMonthDateRange(referenceDate, monthOffset)
        val currentSessions = filterSessionsInRange(sessions, range.startDate, range.endDate)
        val prevSessions = filterSessionsInRange(sessions, range.prevStartDate, range.prevEndDate)

        val targetYm = YearMonth.from(range.startDate)
        val daysInMonth = targetYm.lengthOfMonth()

        val dailyMinutesMap = mutableMapOf<LocalDate, Int>()
        for (day in 1..daysInMonth) {
            val date = targetYm.atDay(day)
            dailyMinutesMap[date] = 0
        }
        for (s in currentSessions) {
            try {
                val d = LocalDate.parse(s.date)
                dailyMinutesMap[d] = (dailyMinutesMap[d] ?: 0) + s.durationMinutes
            } catch (_: Exception) {}
        }

        // Group into week intervals (e.g. W1: Days 1-7, W2: Days 8-14, W3: Days 15-21, W4: Days 22-28, W5: Days 29+)
        val bars = mutableListOf<ChartBarData>()
        val weekBuckets = listOf(
            Pair("W1", 1..7),
            Pair("W2", 8..14),
            Pair("W3", 15..21),
            Pair("W4", 22..28),
            Pair("W5", 29..daysInMonth)
        )

        for ((label, rangeDays) in weekBuckets) {
            if (rangeDays.first <= daysInMonth) {
                val validEnd = rangeDays.last.coerceAtMost(daysInMonth)
                val bucketSessions = currentSessions.filter {
                    try {
                        val d = LocalDate.parse(it.date)
                        d.dayOfMonth in rangeDays.first..validEnd
                    } catch (e: Exception) { false }
                }
                val totalMins = bucketSessions.sumOf { it.durationMinutes }
                val breakdown = bucketSessions.groupBy { it.subjectId }
                    .mapValues { entry -> entry.value.sumOf { it.durationMinutes } }

                bars.add(
                    ChartBarData(
                        label = label,
                        dateOrPeriod = "Days ${rangeDays.first}-$validEnd",
                        totalMinutes = totalMins,
                        subjectBreakdown = breakdown
                    )
                )
            }
        }

        return computeMetrics(
            period = PerformancePeriod.MONTHLY,
            range = range,
            currentSessions = currentSessions,
            prevSessions = prevSessions,
            dailyMinutesMap = dailyMinutesMap,
            chartBars = bars,
            daysInPeriod = daysInMonth,
            subjectNames = subjectNames
        )
    }

    fun calculateYearlyPerformance(
        sessions: List<StudySessionEntity>,
        referenceDate: LocalDate = LocalDate.now(),
        yearOffset: Int = 0,
        subjectNames: Map<Long, String> = emptyMap()
    ): PerformanceMetrics {
        val range = getYearDateRange(referenceDate, yearOffset)
        val currentSessions = filterSessionsInRange(sessions, range.startDate, range.endDate)
        val prevSessions = filterSessionsInRange(sessions, range.prevStartDate, range.prevEndDate)

        val targetYear = range.startDate.year
        val monthNames = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        val bars = mutableListOf<ChartBarData>()

        val dailyMinutesMap = mutableMapOf<LocalDate, Int>()

        for (m in 1..12) {
            val monthSessions = currentSessions.filter {
                try {
                    val d = LocalDate.parse(it.date)
                    d.monthValue == m
                } catch (e: Exception) { false }
            }
            val totalMins = monthSessions.sumOf { it.durationMinutes }
            val breakdown = monthSessions.groupBy { it.subjectId }
                .mapValues { entry -> entry.value.sumOf { it.durationMinutes } }

            bars.add(
                ChartBarData(
                    label = monthNames[m - 1],
                    dateOrPeriod = "$targetYear-${String.format(Locale.US, "%02d", m)}",
                    totalMinutes = totalMins,
                    subjectBreakdown = breakdown
                )
            )

            for (s in monthSessions) {
                try {
                    val d = LocalDate.parse(s.date)
                    dailyMinutesMap[d] = (dailyMinutesMap[d] ?: 0) + s.durationMinutes
                } catch (_: Exception) {}
            }
        }

        val daysInYear = if (LocalDate.of(targetYear, 1, 1).isLeapYear) 366 else 365

        return computeMetrics(
            period = PerformancePeriod.YEARLY,
            range = range,
            currentSessions = currentSessions,
            prevSessions = prevSessions,
            dailyMinutesMap = dailyMinutesMap,
            chartBars = bars,
            daysInPeriod = daysInYear,
            subjectNames = subjectNames
        )
    }

    private fun filterSessionsInRange(
        sessions: List<StudySessionEntity>,
        startDate: LocalDate,
        endDate: LocalDate
    ): List<StudySessionEntity> {
        return sessions.filter {
            try {
                val d = LocalDate.parse(it.date)
                !d.isBefore(startDate) && !d.isAfter(endDate)
            } catch (e: Exception) {
                false
            }
        }
    }

    private fun computeMetrics(
        period: PerformancePeriod,
        range: PeriodDateRange,
        currentSessions: List<StudySessionEntity>,
        prevSessions: List<StudySessionEntity>,
        dailyMinutesMap: Map<LocalDate, Int>,
        chartBars: List<ChartBarData>,
        daysInPeriod: Int,
        subjectNames: Map<Long, String>
    ): PerformanceMetrics {
        val totalMinutes = currentSessions.sumOf { it.durationMinutes }
        val totalHours = totalMinutes / 60.0
        val sessionCount = currentSessions.size
        val averageHoursPerDay = totalHours / daysInPeriod.coerceAtLeast(1)

        val bestEntry = dailyMinutesMap.filter { it.value > 0 }.maxByOrNull { it.value }
        val bestDayDate = bestEntry?.key
        val bestDayMinutes = bestEntry?.value ?: 0

        val subjectMinutes = currentSessions.groupBy { it.subjectId }
            .mapValues { entry -> entry.value.sumOf { it.durationMinutes } }

        val mostStudiedEntry = subjectMinutes.maxByOrNull { it.value }
        val leastStudiedEntry = subjectMinutes.minByOrNull { it.value }

        val prevTotalMinutes = prevSessions.sumOf { it.durationMinutes }
        val percentageChange: Double? = when {
            prevTotalMinutes == 0 && totalMinutes == 0 -> null
            prevTotalMinutes == 0 && totalMinutes > 0 -> 100.0
            else -> ((totalMinutes - prevTotalMinutes).toDouble() / prevTotalMinutes) * 100.0
        }

        val textSummary = generateTextSummary(
            period = period,
            totalHours = totalHours,
            sessionCount = sessionCount,
            percentageChange = percentageChange,
            bestDayDate = bestDayDate,
            bestDayMinutes = bestDayMinutes,
            mostSubjectName = mostStudiedEntry?.key?.let { subjectNames[it] },
            mostSubjectMinutes = mostStudiedEntry?.value ?: 0
        )

        return PerformanceMetrics(
            period = period,
            range = range,
            totalMinutes = totalMinutes,
            totalHours = totalHours,
            sessionCount = sessionCount,
            averageHoursPerDay = averageHoursPerDay,
            bestDayDate = bestDayDate,
            bestDayMinutes = bestDayMinutes,
            mostStudiedSubjectId = mostStudiedEntry?.key,
            mostStudiedMinutes = mostStudiedEntry?.value ?: 0,
            leastStudiedSubjectId = leastStudiedEntry?.key,
            leastStudiedMinutes = leastStudiedEntry?.value ?: 0,
            prevTotalMinutes = prevTotalMinutes,
            percentageChange = percentageChange,
            chartBars = chartBars,
            subjectMinutes = subjectMinutes,
            textSummary = textSummary
        )
    }

    private fun generateTextSummary(
        period: PerformancePeriod,
        totalHours: Double,
        sessionCount: Int,
        percentageChange: Double?,
        bestDayDate: LocalDate?,
        bestDayMinutes: Int,
        mostSubjectName: String?,
        mostSubjectMinutes: Int
    ): String {
        if (totalHours <= 0.0) {
            return "No study sessions logged for this period yet. Begin studying to view analytical progress."
        }

        val periodName = when (period) {
            PerformancePeriod.WEEKLY -> "this week"
            PerformancePeriod.MONTHLY -> "this month"
            PerformancePeriod.YEARLY -> "this year"
        }

        val formattedHours = String.format(Locale.US, "%.1f", totalHours)
        val changeStr = when {
            percentageChange == null -> ""
            percentageChange > 0 -> " (+${String.format(Locale.US, "%.0f", percentageChange)}% vs previous)"
            percentageChange < 0 -> " (${String.format(Locale.US, "%.0f", percentageChange)}% vs previous)"
            else -> " (equal to previous period)"
        }

        val bestDayStr = if (bestDayDate != null && bestDayMinutes > 0) {
            val bestHrs = String.format(Locale.US, "%.1f", bestDayMinutes / 60.0)
            " Best day was ${bestDayDate.dayOfWeek.name.lowercase().replaceFirstChar { it.uppercase() }} ($bestHrs hrs)."
        } else ""

        val subjectStr = if (!mostSubjectName.isNullOrBlank() && mostSubjectMinutes > 0) {
            val subHrs = String.format(Locale.US, "%.1f", mostSubjectMinutes / 60.0)
            " Top focus: $mostSubjectName ($subHrs hrs)."
        } else ""

        return "Logged $formattedHours hrs across $sessionCount sessions $periodName$changeStr.$bestDayStr$subjectStr"
    }
}
