package com.example.data.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.models.ChatLanguage
import com.example.data.models.VoiceProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale

class VoiceSynthesisEngine(private val context: Context) : TextToSpeech.OnInitListener {
    private val TAG = "VoiceSynthesisEngine"
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var mediaPlayer: MediaPlayer? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentlySpeakingText = MutableStateFlow<String?>(null)
    val currentlySpeakingText: StateFlow<String?> = _currentlySpeakingText.asStateFlow()

    private val _audioWaveformProgress = MutableStateFlow(0f)
    val audioWaveformProgress: StateFlow<Float> = _audioWaveformProgress.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Main)
    private var visualizerJob: Job? = null

    val availableVoices = listOf(
        // Hindi
        VoiceProfile(
            id = "hi_aarav",
            name = "Aarav (आरव - Natural Male)",
            language = ChatLanguage.HINDI,
            gender = "Male",
            description = "Natural, calm, authentic Hindi voice",
            defaultPitch = 0.95f,
            defaultSpeed = 1.0f,
            sampleText = "नमस्ते! मैं हाज़िम एआई का आरव हूँ। आज का दिन आपके लिए मंगलमय हो।"
        ),
        VoiceProfile(
            id = "hi_ananya",
            name = "Ananya (अनन्या - Studio Female)",
            language = ChatLanguage.HINDI,
            gender = "Female",
            description = "Warm, expressive, articulate Hindi tone",
            defaultPitch = 1.15f,
            defaultSpeed = 1.02f,
            sampleText = "सुप्रभात! हाज़िम एआई आपकी हर कल्पना को हकीकत में बदलने के लिए तैयार है।"
        ),
        VoiceProfile(
            id = "hi_kabir",
            name = "Kabir (कबीर - Storyteller)",
            language = ChatLanguage.HINDI,
            gender = "Male",
            description = "Deep, resonant storyteller Hindi tone",
            defaultPitch = 0.85f,
            defaultSpeed = 0.92f,
            sampleText = "कहानियों और विचारों की दुनिया में आपका स्वागत है। चलिए कुछ अद्भुत बनाएं।"
        ),
        // English
        VoiceProfile(
            id = "en_rachel",
            name = "Rachel (Studio Pro)",
            language = ChatLanguage.ENGLISH,
            gender = "Female",
            description = "Crisp, professional studio narrator",
            defaultPitch = 1.05f,
            defaultSpeed = 1.0f,
            sampleText = "Welcome to HAZIM AI. Experience the future of multi-modal creativity."
        ),
        VoiceProfile(
            id = "en_liam",
            name = "Liam (Modern Casual)",
            language = ChatLanguage.ENGLISH,
            gender = "Male",
            description = "Energetic, friendly modern assistant",
            defaultPitch = 0.95f,
            defaultSpeed = 1.05f,
            sampleText = "Hey there! I am ready to turn your thoughts into images, videos, and voices."
        ),
        VoiceProfile(
            id = "en_sophia",
            name = "Sophia (Cinematic Warm)",
            language = ChatLanguage.ENGLISH,
            gender = "Female",
            description = "Gentle, soothing cinematic voice",
            defaultPitch = 1.15f,
            defaultSpeed = 0.95f,
            sampleText = "Every great creation begins with a single spark of imagination."
        ),
        // Kashmiri
        VoiceProfile(
            id = "ks_burhan",
            name = "Burhan (برہان / बुर्हान)",
            language = ChatLanguage.KASHMIRI,
            gender = "Male",
            description = "Traditional, clear Kashmiri tone",
            defaultPitch = 0.92f,
            defaultSpeed = 0.95f,
            sampleText = "السلام علیکم! کشیر ہنٛز خوبصورتی تہٕ ثقافت چھِ واریاہ خاص۔ خوش آمدید!"
        ),
        VoiceProfile(
            id = "ks_zoon",
            name = "Zoon (زون / जून)",
            language = ChatLanguage.KASHMIRI,
            gender = "Female",
            description = "Melodic, sweet Kashmiri poetic tone",
            defaultPitch = 1.20f,
            defaultSpeed = 0.98f,
            sampleText = "ڈل جھیل کس ٹھنڈس آبس منز، ہازم اے آئی چھُ تۄہند سواگت کران۔"
        )
    )

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e(TAG, "Error instantiating TextToSpeech", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isPlaying.value = true
                    startVisualizer()
                }

                override fun onDone(utteranceId: String?) {
                    _isPlaying.value = false
                    _currentlySpeakingText.value = null
                    stopVisualizer()
                }

                override fun onError(utteranceId: String?) {
                    _isPlaying.value = false
                    _currentlySpeakingText.value = null
                    stopVisualizer()
                }
            })
        }
    }

    fun speak(
        text: String,
        language: ChatLanguage = ChatLanguage.ENGLISH,
        pitch: Float = 1.0f,
        speed: Float = 1.0f
    ) {
        stop()
        _currentlySpeakingText.value = text
        _isPlaying.value = true
        startVisualizer()

        // 1. Try real online natural human speech synthesis (Google Neural TTS audio)
        val langCode = when (language) {
            ChatLanguage.ENGLISH -> "en"
            ChatLanguage.HINDI, ChatLanguage.HINGLISH -> "hi"
            ChatLanguage.KASHMIRI -> "ur" // Urdu/Kashmiri phonetic alignment
        }

        scope.launch(Dispatchers.IO) {
            val success = playOnlineNeuralTts(text, langCode)
            if (!success) {
                // 2. Fallback to on-device Android TextToSpeech engine
                launch(Dispatchers.Main) {
                    playLocalTts(text, language, pitch, speed)
                }
            }
        }
    }

    private fun playOnlineNeuralTts(text: String, langCode: String): Boolean {
        return try {
            val encoded = URLEncoder.encode(text.take(200), StandardCharsets.UTF_8.toString())
            val audioUrl = "https://translate.google.com/translate_tts?ie=UTF-8&tl=$langCode&client=tw-ob&q=$encoded"

            val cacheFile = java.io.File(context.cacheDir, "tts_speech_${System.currentTimeMillis()}.mp3")
            val connection = (java.net.URL(audioUrl).openConnection() as java.net.HttpURLConnection).apply {
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 8)")
                connectTimeout = 7000
                readTimeout = 7000
            }

            if (connection.responseCode == 200) {
                connection.inputStream.use { input ->
                    java.io.FileOutputStream(cacheFile).use { output ->
                        input.copyTo(output)
                    }
                }

                val mp = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )
                    setDataSource(cacheFile.absolutePath)
                    setOnPreparedListener { player ->
                        player.start()
                    }
                    setOnCompletionListener { player ->
                        player.release()
                        mediaPlayer = null
                        _isPlaying.value = false
                        _currentlySpeakingText.value = null
                        stopVisualizer()
                        try { cacheFile.delete() } catch (_: Exception) {}
                    }
                    setOnErrorListener { player, _, _ ->
                        player.release()
                        mediaPlayer = null
                        _isPlaying.value = false
                        stopVisualizer()
                        try { cacheFile.delete() } catch (_: Exception) {}
                        false
                    }
                    prepareAsync()
                }
                mediaPlayer = mp
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Online neural TTS failed, falling back to local TTS engine: ${e.message}")
            false
        }
    }

    private fun playLocalTts(text: String, language: ChatLanguage, pitch: Float, speed: Float) {
        val engine = tts
        if (engine != null && isTtsInitialized) {
            try {
                val targetLocale = when (language) {
                    ChatLanguage.ENGLISH -> Locale.US
                    ChatLanguage.HINDI, ChatLanguage.HINGLISH -> Locale("hi", "IN")
                    ChatLanguage.KASHMIRI -> {
                        val ks = Locale("ks", "IN")
                        if (engine.isLanguageAvailable(ks) >= TextToSpeech.LANG_AVAILABLE) ks else Locale("ur", "PK")
                    }
                }

                if (engine.isLanguageAvailable(targetLocale) >= TextToSpeech.LANG_AVAILABLE) {
                    engine.language = targetLocale
                } else {
                    engine.language = Locale.US
                }

                engine.setPitch(pitch.coerceIn(0.5f, 2.0f))
                engine.setSpeechRate(speed.coerceIn(0.5f, 2.0f))

                val utteranceId = "utt_${System.currentTimeMillis()}"
                engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
                return
            } catch (e: Exception) {
                Log.w(TAG, "Local TTS speak error: ${e.message}")
            }
        }

        // If local TTS not ready yet, simulate completion after text duration
        scope.launch {
            val estimatedSeconds = (text.split(" ").size / 2.5f).coerceIn(2.0f, 6.0f)
            delay((estimatedSeconds * 1000).toLong())
            _isPlaying.value = false
            _currentlySpeakingText.value = null
            stopVisualizer()
        }
    }

    private fun startVisualizer() {
        visualizerJob?.cancel()
        visualizerJob = scope.launch {
            var phase = 0f
            while (_isPlaying.value) {
                delay(60)
                phase += 0.2f
                _audioWaveformProgress.value = (kotlin.math.sin(phase.toDouble()).toFloat() + 1f) / 2f
            }
            _audioWaveformProgress.value = 0f
        }
    }

    private fun stopVisualizer() {
        visualizerJob?.cancel()
        _audioWaveformProgress.value = 0f
    }

    fun stop() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
            // ignore
        }
        try {
            tts?.stop()
        } catch (e: Exception) {
            // ignore
        }
        _isPlaying.value = false
        _currentlySpeakingText.value = null
        stopVisualizer()
    }

    fun release() {
        stop()
        try {
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            // ignore
        }
    }
}
