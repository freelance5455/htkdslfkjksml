package com.example.data.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.models.ChatLanguage
import com.example.data.models.VoiceProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceSynthesisEngine(context: Context) : TextToSpeech.OnInitListener {
    private val TAG = "VoiceSynthesisEngine"
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentlySpeakingText = MutableStateFlow<String?>(null)
    val currentlySpeakingText: StateFlow<String?> = _currentlySpeakingText.asStateFlow()

    val availableVoices = listOf(
        // Hindi
        VoiceProfile(
            id = "hi_aarav",
            name = "Aarav (आरव)",
            language = ChatLanguage.HINDI,
            gender = "Male",
            description = "Natural, calm, authentic Hindi voice",
            defaultPitch = 0.95f,
            defaultSpeed = 1.0f,
            sampleText = "नमस्ते! मैं हाज़िम एआई का आरव हूँ। आज का दिन आपके लिए मंगलमय हो।"
        ),
        VoiceProfile(
            id = "hi_ananya",
            name = "Ananya (अनन्या)",
            language = ChatLanguage.HINDI,
            gender = "Female",
            description = "Warm, expressive, articulate Hindi tone",
            defaultPitch = 1.15f,
            defaultSpeed = 1.02f,
            sampleText = "सुप्रभात! हाज़िम एआई आपकी हर कल्पना को हकीकत में बदलने के लिए तैयार है।"
        ),
        VoiceProfile(
            id = "hi_kabir",
            name = "Kabir (कबीर)",
            language = ChatLanguage.HINDI,
            gender = "Male",
            description = "Deep, resonant storyteller Hindi tone",
            defaultPitch = 0.82f,
            defaultSpeed = 0.92f,
            sampleText = "कहानियों और विचारों की दुनिया में आपका स्वागत है। चलिए कुछ अद्भुत बनाएं।"
        ),
        // English
        VoiceProfile(
            id = "en_rachel",
            name = "Rachel (Pro Studio)",
            language = ChatLanguage.ENGLISH,
            gender = "Female",
            description = "Crisp, professional studio narrator",
            defaultPitch = 1.08f,
            defaultSpeed = 1.0f,
            sampleText = "Welcome to HAZIM AI. Experience the future of multi-modal creativity."
        ),
        VoiceProfile(
            id = "en_liam",
            name = "Liam (Modern Casual)",
            language = ChatLanguage.ENGLISH,
            gender = "Male",
            description = "Energetic, friendly modern assistant",
            defaultPitch = 0.96f,
            defaultSpeed = 1.05f,
            sampleText = "Hey there! I'm ready to turn your thoughts into images, videos, and voices."
        ),
        VoiceProfile(
            id = "en_sophia",
            name = "Sophia (Warm Cinematic)",
            language = ChatLanguage.ENGLISH,
            gender = "Female",
            description = "Gentle, soothing cinematic voice",
            defaultPitch = 1.18f,
            defaultSpeed = 0.95f,
            sampleText = "Every great creation begins with a single spark of imagination."
        ),
        // Kashmiri
        VoiceProfile(
            id = "ks_burhan",
            name = "Burhan (برہان / बुर्हान)",
            language = ChatLanguage.KASHMIRI,
            gender = "Male",
            description = "Traditional, clear Kashmiri tone",
            defaultPitch = 0.92f,
            defaultSpeed = 0.95f,
            sampleText = "السلام علیکم! کشیر ہنٛز خوبصورتی تہٕ ثقافت چھِ واریاہ خاص۔ خوش آمدید!"
        ),
        VoiceProfile(
            id = "ks_zoon",
            name = "Zoon (زون / जून)",
            language = ChatLanguage.KASHMIRI,
            gender = "Female",
            description = "Melodic, sweet Kashmiri poetic tone",
            defaultPitch = 1.20f,
            defaultSpeed = 0.98f,
            sampleText = "ڈل جھیل کس ٹھنڈس آبس منز، ہازم اے آئی چھُ تۄہند سواگت کران۔"
        )
    )

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isPlaying.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isPlaying.value = false
                    _currentlySpeakingText.value = null
                }

                override fun onError(utteranceId: String?) {
                    _isPlaying.value = false
                    _currentlySpeakingText.value = null
                }
            })
        } else {
            Log.e(TAG, "TTS initialization failed with code: $status")
        }
    }

    fun speak(
        text: String,
        language: ChatLanguage = ChatLanguage.ENGLISH,
        pitch: Float = 1.0f,
        speed: Float = 1.0f
    ) {
        val engine = tts ?: return
        if (!isInitialized) return

        try {
            val locale = when (language) {
                ChatLanguage.ENGLISH -> Locale.US
                ChatLanguage.HINDI, ChatLanguage.HINGLISH -> Locale("hi", "IN")
                ChatLanguage.KASHMIRI -> {
                    // Try Kashmiri or fallback to Urdu locale which shares vocabulary and phonetic base
                    val ksLocale = Locale("ks", "IN")
                    val res = engine.isLanguageAvailable(ksLocale)
                    if (res >= TextToSpeech.LANG_AVAILABLE) ksLocale else Locale("ur", "PK")
                }
            }

            engine.language = locale
            engine.setPitch(pitch.coerceIn(0.5f, 2.0f))
            engine.setSpeechRate(speed.coerceIn(0.5f, 2.0f))

            _currentlySpeakingText.value = text
            val utteranceId = "utterance_${System.currentTimeMillis()}"
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (e: Exception) {
            Log.e(TAG, "Error speaking text", e)
            _isPlaying.value = false
        }
    }

    fun stop() {
        tts?.stop()
        _isPlaying.value = false
        _currentlySpeakingText.value = null
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
