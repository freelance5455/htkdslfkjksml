package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.Difficulty
import com.example.model.GameStats
import com.example.model.MascotSkin
import com.example.model.UpdateChannel

class GamePreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("flappy_droid_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_HIGH_SCORE = "high_score"
        private const val KEY_GAMES_PLAYED = "games_played"
        private const val KEY_TOTAL_FLAPS = "total_flaps"
        private const val KEY_TOTAL_PIPES = "total_pipes"
        private const val KEY_SOUND_ENABLED = "sound_enabled"
        private const val KEY_HAPTICS_ENABLED = "haptics_enabled"
        private const val KEY_DIFFICULTY = "difficulty"
        private const val KEY_MASCOT_SKIN = "mascot_skin"
        private const val KEY_UPDATE_CHANNEL = "update_channel"
        private const val KEY_LAST_UPDATE_CHECK = "last_update_check"
        private const val KEY_AUTO_UPDATE_CHECK = "auto_update_check"
    }

    fun getStats(): GameStats {
        return GameStats(
            highScore = prefs.getInt(KEY_HIGH_SCORE, 0),
            gamesPlayed = prefs.getInt(KEY_GAMES_PLAYED, 0),
            totalFlaps = prefs.getInt(KEY_TOTAL_FLAPS, 0),
            totalPipesCleared = prefs.getInt(KEY_TOTAL_PIPES, 0)
        )
    }

    fun saveHighScoreIfGreater(score: Int): Boolean {
        val currentBest = prefs.getInt(KEY_HIGH_SCORE, 0)
        if (score > currentBest) {
            prefs.edit().putInt(KEY_HIGH_SCORE, score).apply()
            return true
        }
        return false
    }

    fun incrementGamePlayed() {
        val count = prefs.getInt(KEY_GAMES_PLAYED, 0) + 1
        prefs.edit().putInt(KEY_GAMES_PLAYED, count).apply()
    }

    fun addFlaps(flaps: Int) {
        val total = prefs.getInt(KEY_TOTAL_FLAPS, 0) + flaps
        prefs.edit().putInt(KEY_TOTAL_FLAPS, total).apply()
    }

    fun addPipesCleared(pipes: Int) {
        val total = prefs.getInt(KEY_TOTAL_PIPES, 0) + pipes
        prefs.edit().putInt(KEY_TOTAL_PIPES, total).apply()
    }

    fun resetHighScore() {
        prefs.edit()
            .putInt(KEY_HIGH_SCORE, 0)
            .apply()
    }

    fun resetAllStats() {
        prefs.edit()
            .putInt(KEY_HIGH_SCORE, 0)
            .putInt(KEY_GAMES_PLAYED, 0)
            .putInt(KEY_TOTAL_FLAPS, 0)
            .putInt(KEY_TOTAL_PIPES, 0)
            .apply()
    }

    var isSoundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, value).apply()

    var isHapticsEnabled: Boolean
        get() = prefs.getBoolean(KEY_HAPTICS_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTICS_ENABLED, value).apply()

    var isAutoUpdateCheckEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_UPDATE_CHECK, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_UPDATE_CHECK, value).apply()

    var difficulty: Difficulty
        get() {
            val name = prefs.getString(KEY_DIFFICULTY, Difficulty.NORMAL.name)
            return try {
                Difficulty.valueOf(name ?: Difficulty.NORMAL.name)
            } catch (_: Exception) {
                Difficulty.NORMAL
            }
        }
        set(value) = prefs.edit().putString(KEY_DIFFICULTY, value.name).apply()

    var mascotSkin: MascotSkin
        get() {
            val name = prefs.getString(KEY_MASCOT_SKIN, MascotSkin.CLASSIC_GREEN.name)
            return try {
                MascotSkin.valueOf(name ?: MascotSkin.CLASSIC_GREEN.name)
            } catch (_: Exception) {
                MascotSkin.CLASSIC_GREEN
            }
        }
        set(value) = prefs.edit().putString(KEY_MASCOT_SKIN, value.name).apply()

    var updateChannel: UpdateChannel
        get() {
            val name = prefs.getString(KEY_UPDATE_CHANNEL, UpdateChannel.STABLE.name)
            return try {
                UpdateChannel.valueOf(name ?: UpdateChannel.STABLE.name)
            } catch (_: Exception) {
                UpdateChannel.STABLE
            }
        }
        set(value) = prefs.edit().putString(KEY_UPDATE_CHANNEL, value.name).apply()

    var lastUpdateCheck: String?
        get() = prefs.getString(KEY_LAST_UPDATE_CHECK, null)
        set(value) = prefs.edit().putString(KEY_LAST_UPDATE_CHECK, value).apply()
}
