package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class MainTab(val route: String) {
    TIMETABLE("timetable"),
    TRACKS("tracks"),
    TASKS("tasks"),
    FOCUS("focus")
}

enum class TimetableFilter { ALL, TODAY }

enum class TrackFilter { ALL, ACTIVE, COMPLETED }

enum class TaskFilter { ALL, PENDING, COMPLETED }

enum class LessonMode(val key: String, val label: String, val shortBadge: String) {
    CENTER("center", "سنتر / حضوري", "سنتر"),
    ONLINE("online", "أونلاين / منصة", "أونلاين"),
    PRIVATE("private", "مجموعة خاصة", "خاصة");

    companion object {
        fun fromKey(key: String?): LessonMode =
            entries.firstOrNull { it.key == key } ?: CENTER
    }
}

enum class TaskPriority(val key: String, val label: String, val weight: Int) {
    HIGH("high", "عاجل 🔥", 0),
    MEDIUM("medium", "مهم", 1),
    NORMAL("normal", "أولوية عادية", 2);

    companion object {
        fun fromKey(key: String?): TaskPriority =
            entries.firstOrNull { it.key == key } ?: NORMAL
    }
}

enum class PomodoroMode(
    val key: String,
    val chipLabel: String,
    val statusLabel: String,
    val seconds: Int,
    val isFocus: Boolean
) {
    FOCUS_25("focus25", "بومودورو (25 د)", "وقت التركيز (25 د)", 1500, true),
    FOCUS_50("focus50", "عميق (50 د)", "مذاكرة عميقة (50 د)", 3000, true),
    SHORT_BREAK("shortBreak", "استراحة (5 د)", "استراحة قصيرة", 300, false),
    LONG_BREAK("longBreak", "راحة طويلة (15 د)", "استراحة طويلة", 900, false)
}

data class FocusStats(
    val date: String,
    val sessions: Int,
    val minutes: Int
)

object AppConstants {
    val DAYS_OF_WEEK = listOf(
        "السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"
    )

    val LESSON_PRESET_COLORS = listOf(
        "#4f46e5", "#059669", "#d97706", "#dc2626", "#0284c7", "#7c3aed", "#db2777"
    )

    val TRACK_PRESET_COLORS = listOf(
        "#10b981", "#4f46e5", "#f59e0b", "#ec4899", "#06b6d4", "#8b5cf6", "#ef4444"
    )

    val MOTIVATIONAL_QUOTES = listOf(
        "«النجاح ليس صدفة، بل هو نتيجة خطوات صغيرة تتكرر كل يوم بثبات.»",
        "«ساعة تركيز حقيقية خير من خمس ساعات تشتّت.»",
        "«تعب هذه الشهور سيتحول إلى فرحة عمر لا تُنسى بإذن الله.»",
        "«كل درس تنجزه اليوم هو لبنة جديدة في حلمك غداً.»",
        "«الاستمرارية تهزم الموهبة عندما تتوقف الموهبة عن العمل.»"
    )

    fun parseHexColor(hex: String?, fallback: Color = Color(0xFF4F46E5)): Color {
        return try {
            val clean = (hex ?: "").trim()
            if (clean.matches(Regex("^#[0-9A-Fa-f]{6}$"))) {
                Color(android.graphics.Color.parseColor(clean))
            } else {
                fallback
            }
        } catch (_: Exception) {
            fallback
        }
    }
}
