package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Airport information model
 */
@Entity(tableName = "airports")
data class Airport(
  @PrimaryKey val icao: String,
  val iata: String,
  val nameEn: String,
  val nameFa: String,
  val cityEn: String,
  val cityFa: String,
  val countryEn: String,
  val countryFa: String,
  val latitude: Double,
  val longitude: Double,
  val elevationFt: Int,
  val timezone: String,
  val hasMetar: Boolean = true,
  val hasTaf: Boolean = true,
  val fir: String = "OIIX"
)

@Entity(tableName = "favorites")
data class FavoriteAirport(
  @PrimaryKey val icao: String,
  val addedTimestamp: Long = System.currentTimeMillis(),
  val sortOrder: Int = 0
)

@Entity(tableName = "recent_airports")
data class RecentAirport(
  @PrimaryKey val icao: String,
  val lastViewedTimestamp: Long = System.currentTimeMillis()
)

/**
 * Cloud layer decoding
 */
data class CloudLayer(
  val cover: String, // SKC, CLR, FEW, SCT, BKN, OVC, VV
  val baseFt: Int? = null,
  val type: String? = null // CB, TCU
)

/**
 * Normalized METAR / SPECI model
 */
@Entity(tableName = "cached_metar")
data class MetarData(
  @PrimaryKey val icao: String,
  val rawMetar: String,
  val isSpeci: Boolean = false,
  val obsTimeUtc: String,
  val obsTimestampEpochSec: Long = 0L,
  val receiptTimeUtc: String = "",
  val source: String = "AviationWeather.gov / WMO OPMET",
  val windDirDeg: Int? = null,
  val windSpeedKt: Int? = null,
  val windGustKt: Int? = null,
  val windVariableFromDeg: Int? = null,
  val windVariableToDeg: Int? = null,
  val isWindCalm: Boolean = false,
  val isWindVariable: Boolean = false,
  val visibilityMeters: Int? = null,
  val visibilitySm: String? = null,
  val isCavok: Boolean = false,
  val rvr: String? = null,
  val presentWeather: String? = null,
  val tempC: Double? = null,
  val dewPointC: Double? = null,
  val altimeterHpa: Double? = null,
  val altimeterInHg: Double? = null,
  val ceilingFt: Int? = null,
  val flightCategory: String = "VFR", // VFR, MVFR, IFR, LIFR, UNKNOWN
  val cloudsSummary: String = "",
  val trend: String? = null, // NOSIG, BECMG, TEMPO
  val parsingFailed: Boolean = false,
  val cachedAtTimestamp: Long = System.currentTimeMillis()
)

/**
 * Forecast change block in TAF
 */
data class TafForecastItem(
  val timeFromUtc: String,
  val timeToUtc: String,
  val changeType: String?, // FM, BECMG, TEMPO, PROB30, PROB40
  val probability: Int? = null,
  val windDirDeg: Int? = null,
  val windSpeedKt: Int? = null,
  val windGustKt: Int? = null,
  val visibilityMeters: Int? = null,
  val weather: String? = null,
  val clouds: String? = null
)

/**
 * Normalized TAF model
 */
@Entity(tableName = "cached_taf")
data class TafData(
  @PrimaryKey val icao: String,
  val rawTaf: String,
  val issueTimeUtc: String,
  val validFromUtc: String,
  val validToUtc: String,
  val validFromEpochSec: Long = 0L,
  val validToEpochSec: Long = 0L,
  val source: String = "AviationWeather.gov / WIFS OPMET",
  val forecastsSummary: String = "",
  val cachedAtTimestamp: Long = System.currentTimeMillis()
)

/**
 * Geographic coordinate point
 */
data class GeoPoint(
  val lat: Double,
  val lon: Double
)

/**
 * SIGMET Model
 */
@Entity(tableName = "cached_sigmet")
data class SigmetData(
  @PrimaryKey val sigmetId: String,
  val firId: String,
  val firName: String,
  val rawSigmet: String,
  val hazard: String, // TS, TURB, ICE, MTW, VA, TC, RDOACT
  val qualifier: String = "", // SEV, EMBD, FRQ, SQL
  val baseFt: Int? = null,
  val topFt: Int? = null,
  val movementDir: String? = null,
  val movementSpdKt: Int? = null,
  val change: String? = null, // INTSF, WKN, NC
  val issueTimeUtc: String,
  val validFromUtc: String,
  val validToUtc: String,
  val validFromEpochSec: Long = 0L,
  val validToEpochSec: Long = 0L,
  val source: String = "AviationWeather.gov / WIFS",
  val coordsJson: String = "",
  val cachedAtTimestamp: Long = System.currentTimeMillis()
)

/**
 * Upper-air Wind Aloft level model
 */
data class WindAloftLevel(
  val flightLevelName: String, // SFC, FL050, FL100, FL180, FL240, FL300, FL340, FL390, FL450
  val pressureHpa: Int,
  val altitudeFt: Int,
  val windDirDeg: Int,
  val windSpeedKt: Int,
  val tempC: Double,
  val validTimeUtc: String
)

/**
 * Full wind aloft dataset for an airport / location
 */
data class WindAloftReport(
  val icao: String,
  val airportName: String,
  val latitude: Double,
  val longitude: Double,
  val validTimeUtc: String,
  val source: String = "WMO GFS / ECMWF Open Numerical Prediction",
  val retrievalTimeUtc: String,
  val levels: List<WindAloftLevel> = emptyList()
)

/**
 * SNOWTAM / Runway Condition Report following ICAO Doc 10066 & GRF
 */
@Entity(tableName = "stored_snowtam")
data class SnowtamData(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val icao: String,
  val serialNumber: String = "",
  val issueTimeUtc: String,
  val rawSnowtam: String,
  val runwayDesignator: String, // e.g. 29R
  val rwyccPart1: Int?, // 0-6
  val rwyccPart2: Int?, // 0-6
  val rwyccPart3: Int?, // 0-6
  val lowestRwycc: Int?, // 0-6
  val contaminantType: String = "", // DRY SNOW, WET SNOW, COMPACTED SNOW, SLUSH, ICE, FROST, WET
  val coveragePercentPart1: Int? = null,
  val coveragePercentPart2: Int? = null,
  val coveragePercentPart3: Int? = null,
  val depthMmPart1: Int? = null,
  val depthMmPart2: Int? = null,
  val depthMmPart3: Int? = null,
  val widthClearedMeters: Int? = null,
  val remarks: String = "",
  val source: String = "Official OPMET / ICAO GRF",
  val receivedTimeUtc: String,
  val isSampleOrManual: Boolean = false,
  val receivedTimestampEpochMs: Long = System.currentTimeMillis()
)

/**
 * Status of external data sources
 */
enum class SourceConnectionState {
  CONNECTED,
  AUTHENTICATION_REQUIRED,
  NOT_CONFIGURED,
  UNAVAILABLE,
  NO_CURRENT_DATA
}

data class DataSourceStatus(
  val nameFa: String,
  val nameEn: String,
  val state: SourceConnectionState,
  val descriptionFa: String,
  val lastCheckedUtc: String = "",
  val officialUrl: String = "",
  val requiresCredentials: Boolean = false
)
