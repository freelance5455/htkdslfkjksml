package com.example.data.model

enum class UserRole(val label: String, val description: String) {
    CONSUMER(
        label = "Consumer",
        description = "Discover and buy innovative products."
    ),
    SELLER(
        label = "Seller / Innovator",
        description = "Showcase your ideas and sell innovative products."
    ),
    DELIVERY_PARTNER(
        label = "Delivery Partner",
        description = "Deliver products and earn from completed deliveries."
    )
}

enum class VehicleType(val label: String) {
    BICYCLE("Bicycle"),
    MOTORCYCLE("Motorcycle"),
    SCOOTER("Scooter"),
    CAR("Car"),
    OTHER("Other")
}

data class User(
    val id: String,
    val name: String,
    val email: String,
    val phone: String,
    val role: UserRole,
    val age: Int,
    val profession: String,
    val location: String,
    val profileImageUrl: String = "",
    val bio: String = ""
)

data class Product(
    val id: String,
    val sellerId: String,
    val sellerName: String,
    val sellerRating: Double,
    val name: String,
    val description: String,
    val category: String,
    val price: Double,
    val stock: Int,
    val imageUrl: String,
    val specifications: Map<String, String> = emptyMap(),
    val deliveryAvailability: Boolean = true,
    val deliveryAreaKm: Int = 25,
    val distanceKm: Double = 3.8,
    val isInnovation: Boolean = true,
    val isFeatured: Boolean = false,
    val rating: Double = 4.8,
    val reviewCount: Int = 42,
    val active: Boolean = true
)

data class InnovationPost(
    val id: String,
    val title: String,
    val content: String,
    val date: String,
    val likesCount: Int = 18,
    val imageUrl: String = "",
    val tags: List<String> = emptyList()
)

data class SellerSpace(
    val id: String,
    val sellerId: String,
    val name: String,
    val handle: String,
    val description: String,
    val logoUrl: String = "",
    val bannerColorHex: Long = 0xFF1E293B,
    val categories: List<String>,
    val followerCount: Int = 1420,
    val rating: Double = 4.9,
    val innovations: List<InnovationPost> = emptyList(),
    val verified: Boolean = true
)

data class DeliveryPartner(
    val id: String,
    val name: String,
    val vehicle: VehicleType,
    val vehiclePlate: String,
    val rating: Double,
    val completedDeliveries: Int,
    val experienceYears: Int,
    val isAvailable: Boolean,
    val distanceKm: Double,
    val approximateArea: String,
    val phone: String
)

data class CartItem(
    val product: Product,
    val quantity: Int
) {
    val totalPrice: Double get() = product.price * quantity
}

enum class OrderStatus(val label: String, val stepIndex: Int) {
    ORDER_PLACED("Order Placed", 0),
    SELLER_CONFIRMED("Seller Confirmed", 1),
    DELIVERY_REQUESTED("Delivery Partner Requested", 2),
    DELIVERY_ASSIGNED("Delivery Partner Assigned", 3),
    PICKED_UP("Picked Up", 4),
    ON_THE_WAY("On the Way", 5),
    DELIVERED("Delivered", 6),
    COMPLETED("Completed", 7),
    CANCELLED("Cancelled", -1)
}

data class DeliveryAddress(
    val fullName: String,
    val phone: String,
    val street: String,
    val city: String,
    val state: String,
    val postalCode: String,
    val instructions: String = ""
)

data class Order(
    val id: String,
    val orderNumber: String,
    val consumerId: String,
    val consumerName: String,
    val sellerId: String,
    val sellerName: String,
    val deliveryPartnerId: String? = null,
    val deliveryPartnerName: String? = null,
    val deliveryPartnerPhone: String? = null,
    val items: List<CartItem>,
    val subtotal: Double,
    val deliveryCharge: Double,
    val platformFee: Double,
    val total: Double,
    val status: OrderStatus,
    val deliveryAddress: DeliveryAddress,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val paymentMethod: String = "Ignis Pay / Card",
    val estimatedDeliveryMinutes: Int = 35
)

data class ChatMessage(
    val id: String,
    val senderId: String,
    val senderName: String,
    val senderRole: UserRole,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSystem: Boolean = false,
    val attachmentName: String? = null
)

data class Chat(
    val id: String,
    val orderId: String? = null,
    val otherPartyId: String,
    val otherPartyName: String,
    val otherPartyRole: UserRole,
    val lastMessage: String,
    val lastTimestamp: Long,
    val unreadCount: Int = 0,
    val messages: List<ChatMessage> = emptyList()
)

enum class NotificationType {
    ORDER,
    DELIVERY,
    MESSAGE,
    COMMUNITY
}

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val roleTarget: UserRole,
    val isRead: Boolean = false,
    val type: NotificationType
)

data class CommissionConfig(
    val sellerPercentage: Double = 0.85,
    val deliveryPercentage: Double = 0.10,
    val platformPercentage: Double = 0.05
)
