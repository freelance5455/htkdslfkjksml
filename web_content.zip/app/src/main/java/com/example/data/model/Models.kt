package com.example.data.model

data class ServerStatus(
    val online: Boolean = false,
    val statusText: String = "Desconectado",
    val host: String = "chaufaland.exaroton.me",
    val port: Int = 19132,
    val tps: Double = 20.0,
    val ramUsed: String = "0 MB",
    val ramLimit: String = "2048 MB",
    val cpuPercent: Int = 0,
    val playersCount: Int = 0,
    val maxPlayers: Int = 20,
    val playerList: List<String> = emptyList(),
    val motd: String = "Servidor Oficial CHAUFALAND Bedrock & Java"
)

data class VoiceChannel(
    val id: String,
    val name: String,
    val icon: String
)

data class VoiceUser(
    val gamerTag: String,
    val channelId: String,
    val isMuted: Boolean = false,
    val isSpeaking: Boolean = false,
    val avatarUrl: String = "https://minotar.net/avatar/$gamerTag/64.png"
)

data class BedrockPlayer(
    val gamerTag: String,
    val dimension: String = "overworld",
    val x: Int = 0,
    val y: Int = 64,
    val z: Int = 0,
    val health: Int = 20
)

data class AppConfig(
    val gamerTag: String = "",
    val activeServerType: String = "exaroton", // "exaroton" | "aternos"
    val exarotonApiToken: String = "",
    val exarotonServerId: String = "",
    val aternosServerIp: String = "chaufaland.aternos.me",
    val bedrockWsUrl: String = "ws://localhost:3000/bedrock-ws"
)
