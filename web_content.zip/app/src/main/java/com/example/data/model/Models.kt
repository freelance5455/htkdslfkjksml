package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class AuctionStatus {
    ACTIVE,
    PAUSED,
    ENDED,
    SETTLED,
    CANCELLED;

    companion object {
        fun fromRaw(raw: String): AuctionStatus =
            entries.firstOrNull { it.name == raw } ?: ACTIVE
    }
}

enum class WithdrawalStatus {
    PENDING,
    APPROVED,
    DECLINED;

    companion object {
        fun fromRaw(raw: String): WithdrawalStatus =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

enum class InquiryStatus {
    PENDING,
    NEGOTIATING,
    APPROVED,
    DECLINED;

    companion object {
        fun fromRaw(raw: String): InquiryStatus =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val phone: String = "",
    val bidderNumber: String = "",
    val bankName: String = "",
    val accountNumber: String = "",
    val accountName: String = "",
    val accountStatus: String = "ACTIVE",
    val role: String = "USER",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Wallet(
    @DocumentId val id: String = "",
    val userId: String = "",
    val availableBalance: Long = 0L,
    val pendingWithdrawal: Long = 0L,
    val totalDeposited: Long = 0L,
    val totalEarned: Long = 0L,
    val totalCommissionPaid: Long = 0L,
    val lastSettledAuctionId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class WalletTransaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val counterpartyId: String = "",
    val auctionId: String = "",
    val type: String = "DEPOSIT",
    val amount: Long = 0L,
    val feeAmount: Long = 0L,
    val description: String = "",
    val status: String = "COMPLETED",
    val referenceCode: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class WithdrawalRequest(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userDisplayName: String = "",
    val bidderNumber: String = "",
    val amount: Long = 0L,
    val bankName: String = "",
    val accountNumber: String = "",
    val accountName: String = "",
    val status: String = "PENDING",
    val adminNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Auction(
    @DocumentId val id: String = "",
    val sellerId: String = "",
    val sellerName: String = "",
    val sellerBidderNumber: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "Watches",
    val imageItems: List<String> = emptyList(),
    val startingBid: Long = 0L,
    val minIncrement: Long = 1000L,
    val currentBid: Long = 0L,
    val bidCount: Long = 0L,
    val highestBidderId: String = "",
    val highestBidderNumber: String = "",
    val featured: Boolean = false,
    val featuredFeePaid: Long = 0L,
    val commissionRate: Long = 3L,
    val commissionAmount: Long = 0L,
    val sellerPayout: Long = 0L,
    val status: String = "ACTIVE",
    val endsAt: Timestamp? = null,
    val settledAt: Timestamp? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun effectiveStatus(nowMillis: Long = System.currentTimeMillis()): AuctionStatus {
        val parsed = AuctionStatus.fromRaw(status)
        if (parsed == AuctionStatus.ACTIVE && endsAt != null && endsAt.toDate().time <= nowMillis) {
            return AuctionStatus.ENDED
        }
        return parsed
    }

    fun minimumNextBid(): Long =
        if (bidCount == 0L || currentBid == 0L) startingBid else currentBid + minIncrement

    fun projectedCommission(): Long {
        val basis = if (currentBid > 0L) currentBid else startingBid
        return (basis * commissionRate) / 100L
    }

    fun projectedSellerPayout(): Long {
        val basis = if (currentBid > 0L) currentBid else startingBid
        return basis - projectedCommission()
    }
}

@Keep
@IgnoreExtraProperties
data class Bid(
    @DocumentId val id: String = "",
    val auctionId: String = "",
    val bidderId: String = "",
    val bidderNumber: String = "",
    val amount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserBidRecord(
    @DocumentId val id: String = "",
    val auctionId: String = "",
    val auctionTitle: String = "",
    val imageItem: String = "",
    val myHighestBid: Long = 0L,
    val bidCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class BusinessAd(
    @DocumentId val id: String = "",
    val businessName: String = "",
    val tagline: String = "",
    val ctaLabel: String = "Learn More",
    val category: String = "Partner",
    val negotiatedFee: Long = 0L,
    val status: String = "ACTIVE",
    val createdBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AdInquiry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val businessName: String = "",
    val proposedBudget: Long = 0L,
    val message: String = "",
    val status: String = "PENDING",
    val adminNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)
