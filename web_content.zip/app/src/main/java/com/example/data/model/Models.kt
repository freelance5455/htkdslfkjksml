package com.example.data.model

data class Course(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val isPublished: Boolean = true,
    val gradeOrder: Int
)

data class Lesson(
    val id: String,
    val courseId: String,
    val title: String,
    val status: String = "لسه هتنزل",
    val description: String = "سيتم رفع المحاضرة والمحتوى التعليمي قريباً بواسطة مستر زاهر جمال",
    val videoUrl: String? = null,
    val pdfUrl: String? = null,
    val isPublished: Boolean = true,
    val order: Int = 1
)

data class Announcement(
    val id: String,
    val title: String,
    val content: String,
    val date: String,
    val isPinned: Boolean = false
)

data class UserProfile(
    val id: String,
    val fullName: String,
    val phone: String,
    val academicStage: String,
    val role: String = "student",
    val enrolledCourses: List<String> = emptyList()
)
