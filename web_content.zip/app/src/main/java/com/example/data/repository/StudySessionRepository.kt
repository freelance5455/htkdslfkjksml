package com.example.data.repository

import com.example.data.dao.StudySessionDao
import com.example.data.model.StudySessionEntity
import kotlinx.coroutines.flow.Flow

class StudySessionRepository(
    private val sessionDao: StudySessionDao
) {
    val allSessionsFlow: Flow<List<StudySessionEntity>> = sessionDao.getAllSessionsFlow()

    fun getSessionsForSubject(subjectId: Long): Flow<List<StudySessionEntity>> =
        sessionDao.getSessionsForSubjectFlow(subjectId)

    suspend fun getAllSessions(): List<StudySessionEntity> =
        sessionDao.getAllSessionsOnce()

    suspend fun getSessionById(id: Long): StudySessionEntity? =
        sessionDao.getSessionById(id)

    suspend fun addSession(
        subjectId: Long,
        date: String,
        startTime: String,
        durationMinutes: Int,
        topic: String?,
        remark: String?
    ): Long {
        val entity = StudySessionEntity(
            subjectId = subjectId,
            date = date,
            startTime = startTime,
            durationMinutes = durationMinutes,
            topic = topic?.trim()?.ifBlank { null },
            remark = remark?.trim()?.ifBlank { null }
        )
        return sessionDao.insertSession(entity)
    }

    suspend fun updateSession(session: StudySessionEntity) {
        sessionDao.updateSession(session)
    }

    suspend fun deleteSession(id: Long) {
        sessionDao.deleteSession(id)
    }
}
