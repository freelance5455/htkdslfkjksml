package com.example.data.model

data class AppSettings(
    val assistantName: String = "NEXUS",
    val persona: AssistantPersona = AssistantPersona.OMNI_AI,
    val engineType: AiEngineType = AiEngineType.CLOUD,
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Float = 1.0f,
    val autoTts: Boolean = true,
    val modelQuantization: String = "Q4_K_M (1.5B параметров)",
    val allocatedRamMb: Int = 1450,
    val externalGgufPath: String = ""
)
