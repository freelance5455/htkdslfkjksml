package com.example.data.model

data class AppSettings(
    val assistantName: String = "NEXUS",
    val persona: AssistantPersona = AssistantPersona.OMNI_AI,
    val engineType: AiEngineType = AiEngineType.CLOUD,
    val geminiModel: GeminiModelOption = GeminiModelOption.GEMINI_3_8_FLASH,
    val customGeminiModelId: String = "",
    val voicePreset: VoicePreset = VoicePreset.ALISA,
    val selectedVoiceName: String = "",
    val useAiNeuralVoice: Boolean = true,
    val aiTtsVoiceId: String = "Kore",
    val voiceSpeed: Float = 1.05f,
    val voicePitch: Float = 1.12f,
    val autoTts: Boolean = true,
    val modelQuantization: String = "Q4_K_M (1.5B параметров)",
    val allocatedRamMb: Int = 1450,
    val externalGgufPath: String = ""
) {
    fun effectiveGeminiModelId(): String {
        return if (geminiModel == GeminiModelOption.CUSTOM && customGeminiModelId.isNotBlank()) {
            customGeminiModelId.trim()
        } else {
            geminiModel.modelId.ifBlank { GeminiModelOption.GEMINI_3_8_FLASH.modelId }
        }
    }

    fun effectiveGeminiModelTitle(): String {
        return if (geminiModel == GeminiModelOption.CUSTOM && customGeminiModelId.isNotBlank()) {
            customGeminiModelId.trim()
        } else if (geminiModel == GeminiModelOption.CUSTOM) {
            GeminiModelOption.GEMINI_3_8_FLASH.title
        } else {
            geminiModel.title
        }
    }
}
