package com.example.data

import android.content.Context
import com.example.R
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class CreditRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
) {
  constructor(context: Context) : this(
      FirebaseFirestore.getInstance(
          context.applicationContext.getString(R.string.firestore_database_id)
      )
  )

  private fun requireUserId(): String {
    return auth.currentUser?.uid
        ?: throw IllegalStateException("User must be signed in before accessing Firestore.")
  }

  suspend fun ensureUserProfile(): Result<UserAccount> {
    val user =
        auth.currentUser
            ?: return Result.failure(IllegalStateException("User is not signed in."))
    val uid = user.uid
    val email = (user.email ?: "").ifBlank { "$uid@pixelforge.local" }
    val displayName =
        (user.displayName ?: email.substringBefore('@')).ifBlank { "PixelForge User" }.take(100)
    val photoUrl = user.photoUrl?.toString()?.take(500)
    val docRef = db.collection("users").document(uid)

    return try {
      val snapshot = docRef.get().await()
      if (!snapshot.exists()) {
        val isBootstrappedAdmin =
            email.equals(UserAccount.BOOTSTRAPPED_ADMIN_EMAIL, ignoreCase = true)
        val payload =
            mutableMapOf<String, Any>(
                "uid" to uid,
                "email" to email,
                "displayName" to displayName,
                "role" to if (isBootstrappedAdmin) "admin" else "user",
                "credits" to 10L,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
        if (!photoUrl.isNullOrBlank()) {
          payload["photoUrl"] = photoUrl
        }
        docRef.set(payload).await()
        val created =
            docRef
                .get()
                .await()
                .toObject(
                    UserAccount::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                )
        Result.success(
            created
                ?: UserAccount(
                    id = uid,
                    uid = uid,
                    email = email,
                    displayName = displayName,
                    photoUrl = photoUrl,
                    role = if (isBootstrappedAdmin) "admin" else "user",
                    credits = 10L,
                )
        )
      } else {
        val existing =
            snapshot.toObject(
                UserAccount::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
            ) ?: UserAccount(id = uid, uid = uid, email = email, displayName = displayName)

        if (existing.displayName != displayName || existing.photoUrl != photoUrl) {
          val updates =
              mutableMapOf<String, Any>(
                  "displayName" to displayName,
                  "updatedAt" to FieldValue.serverTimestamp(),
              )
          if (photoUrl != null) {
            updates["photoUrl"] = photoUrl
          }
          docRef.update(updates).await()
        }
        Result.success(existing)
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path, auth)
      Result.failure(e)
    }
  }

  fun observeCurrentUser(uid: String): Flow<UserAccount?> = flow {
    val docRef = db.collection("users").document(uid)
    emitAll(
        docRef
            .snapshots()
            .map { snapshot ->
              if (snapshot.exists()) {
                snapshot.toObject(
                    UserAccount::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                )
              } else {
                null
              }
            }
            .catch { error ->
              val firestoreError =
                  generateSequence(error) { it.cause }
                      .filterIsInstance<FirebaseFirestoreException>()
                      .firstOrNull()
              if (firestoreError == null && error is CancellationException) throw error
              val exceptionToLog = firestoreError ?: (error as? Exception)
              if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                handleFirestoreError(exceptionToLog, OperationType.GET, docRef.path, auth)
              }
              throw error
            }
    )
  }

  fun observeAllUsers(): Flow<List<UserAccount>> = flow {
    val uid = auth.currentUser?.uid
    val path = "users"
    emitAll(
        db.collection(path)
            .snapshots()
            .map { snapshot ->
              snapshot
                  .toObjects(
                      UserAccount::class.java,
                      DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                  )
                  .sortedWith(
                      compareByDescending<UserAccount> { it.isAdmin }
                          .thenByDescending { it.updatedAt ?: Timestamp(0, 0) }
                  )
            }
            .catch { error ->
              val firestoreError =
                  generateSequence(error) { it.cause }
                      .filterIsInstance<FirebaseFirestoreException>()
                      .firstOrNull()
              if (firestoreError == null && error is CancellationException) throw error
              val exceptionToLog = firestoreError ?: (error as? Exception)
              if (exceptionToLog != null && uid != null && auth.currentUser?.uid == uid) {
                handleFirestoreError(exceptionToLog, OperationType.LIST, path, auth)
              }
              throw error
            }
    )
  }

  fun observeTransactions(uid: String, isAdmin: Boolean): Flow<List<CreditTransaction>> = flow {
    val path = "credit_transactions"
    val query =
        if (isAdmin) {
          db.collection(path)
        } else {
          db.collection(path).whereEqualTo("targetUid", uid)
        }
    emitAll(
        query
            .snapshots()
            .map { snapshot ->
              snapshot
                  .toObjects(
                      CreditTransaction::class.java,
                      DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                  )
                  .sortedByDescending { it.createdAt ?: Timestamp(0, 0) }
            }
            .catch { error ->
              val firestoreError =
                  generateSequence(error) { it.cause }
                      .filterIsInstance<FirebaseFirestoreException>()
                      .firstOrNull()
              if (firestoreError == null && error is CancellationException) throw error
              val exceptionToLog = firestoreError ?: (error as? Exception)
              if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                handleFirestoreError(exceptionToLog, OperationType.LIST, path, auth)
              }
              throw error
            }
    )
  }

  suspend fun adjustUserCredits(
      targetUid: String,
      delta: Long,
      reason: String,
  ): Result<Long> {
    val adminUser =
        auth.currentUser
            ?: return Result.failure(IllegalStateException("Admin must be signed in."))
    if (delta == 0L) {
      return Result.failure(IllegalArgumentException("Credit adjustment amount must not be zero."))
    }
    val cleanReason = reason.trim().ifBlank { if (delta > 0) "Admin credit grant" else "Admin credit adjustment" }.take(240)
    val userRef = db.collection("users").document(targetUid)
    val txId = UUID.randomUUID().toString()
    val txRef = db.collection("credit_transactions").document(txId)

    return try {
      val newBalance =
          db.runTransaction { transaction ->
                val snap = transaction.get(userRef)
                if (!snap.exists()) {
                  throw IllegalStateException("Target user account was not found.")
                }
                val currentCredits = snap.getLong("credits") ?: 0L
                val targetEmail = snap.getString("email") ?: "$targetUid@pixelforge.local"
                val updatedBalance = currentCredits + delta
                if (updatedBalance < 0L) {
                  throw IllegalArgumentException(
                      "Cannot deduct ${-delta} credits; balance is only $currentCredits."
                  )
                }

                transaction.update(
                    userRef,
                    mapOf(
                        "credits" to updatedBalance,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    ),
                )

                val txPayload =
                    mapOf(
                        "targetUid" to targetUid,
                        "targetEmail" to targetEmail,
                        "adminUid" to adminUser.uid,
                        "adminEmail" to (adminUser.email ?: adminUser.uid),
                        "type" to if (delta > 0L) "admin_grant" else "admin_deduct",
                        "amount" to delta,
                        "balanceAfter" to updatedBalance,
                        "reason" to cleanReason,
                        "createdAt" to FieldValue.serverTimestamp(),
                    )
                transaction.set(txRef, txPayload)
                updatedBalance
              }
              .await()
      Result.success(newBalance)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, userRef.path, auth)
      Result.failure(e)
    }
  }

  suspend fun spendCredits(amount: Long, reason: String): Result<Long> {
    val currentUser =
        auth.currentUser
            ?: return Result.failure(IllegalStateException("User must be signed in."))
    if (amount <= 0L) {
      return Result.failure(IllegalArgumentException("Spend amount must be positive."))
    }
    val uid = currentUser.uid
    val userRef = db.collection("users").document(uid)
    val txRef = db.collection("credit_transactions").document(UUID.randomUUID().toString())
    val cleanReason = reason.trim().ifBlank { "AI Studio usage" }.take(240)

    return try {
      val newBalance =
          db.runTransaction { transaction ->
                val snap = transaction.get(userRef)
                if (!snap.exists()) {
                  throw IllegalStateException("User account does not exist.")
                }
                val currentCredits = snap.getLong("credits") ?: 0L
                if (currentCredits < amount) {
                  throw IllegalStateException("Insufficient credits ($currentCredits available).")
                }
                val updatedBalance = currentCredits - amount
                transaction.update(
                    userRef,
                    mapOf(
                        "credits" to updatedBalance,
                        "updatedAt" to FieldValue.serverTimestamp(),
                    ),
                )
                transaction.set(
                    txRef,
                    mapOf(
                        "targetUid" to uid,
                        "targetEmail" to (currentUser.email ?: "$uid@pixelforge.local"),
                        "adminUid" to uid,
                        "adminEmail" to (currentUser.email ?: "$uid@pixelforge.local"),
                        "type" to "ai_usage",
                        "amount" to -amount,
                        "balanceAfter" to updatedBalance,
                        "reason" to cleanReason,
                        "createdAt" to FieldValue.serverTimestamp(),
                    ),
                )
                updatedBalance
              }
              .await()
      Result.success(newBalance)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, userRef.path, auth)
      Result.failure(e)
    }
  }

  suspend fun setAdminRole(targetAccount: UserAccount, makeAdmin: Boolean): Result<Unit> {
    val actingAdmin =
        auth.currentUser
            ?: return Result.failure(IllegalStateException("Admin must be signed in."))
    if (targetAccount.email.equals(UserAccount.BOOTSTRAPPED_ADMIN_EMAIL, ignoreCase = true) && !makeAdmin) {
      return Result.failure(IllegalArgumentException("Cannot remove primary owner admin role."))
    }
    val userRef = db.collection("users").document(targetAccount.uid)
    val adminRef = db.collection("admins").document(targetAccount.uid)

    return try {
      val batch = db.batch()
      batch.update(
          userRef,
          mapOf(
              "role" to if (makeAdmin) "admin" else "user",
              "updatedAt" to FieldValue.serverTimestamp(),
          ),
      )
      if (makeAdmin) {
        batch.set(
            adminRef,
            mapOf(
                "uid" to targetAccount.uid,
                "email" to targetAccount.email,
                "grantedBy" to actingAdmin.uid,
                "createdAt" to FieldValue.serverTimestamp(),
            ),
        )
      } else {
        batch.delete(adminRef)
      }
      batch.commit().await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, userRef.path, auth)
      Result.failure(e)
    }
  }
}
