package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.CurrencyExchange
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.FitnessCenter
import androidx.compose.material.icons.outlined.Functions
import androidx.compose.material.icons.outlined.Percent
import androidx.compose.material.icons.outlined.Receipt
import androidx.compose.material.icons.outlined.Scale
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material.icons.outlined.Savings
import androidx.compose.ui.graphics.vector.ImageVector

enum class ToolCategory(val key: String, val titleKey: String) {
    ALL("all", "cat_all"),
    CALCULATORS("calculators", "cat_basic"),
    FINANCE("finance", "cat_finance"),
    HEALTH("health", "cat_health"),
    CONVERTERS("converters", "cat_converters"),
    LIFE("life", "cat_life")
}

data class ToolItem(
    val id: String,
    val titleKey: String,
    val descKey: String,
    val category: ToolCategory,
    val icon: ImageVector,
    val route: String,
    val isPrimary: Boolean = false
)

object AvailableTools {
    val allTools = listOf(
        ToolItem(
            id = "standard_calc",
            titleKey = "tool_standard",
            descKey = "tool_standard_desc",
            category = ToolCategory.CALCULATORS,
            icon = Icons.Outlined.Calculate,
            route = "calc_standard",
            isPrimary = true
        ),
        ToolItem(
            id = "scientific_calc",
            titleKey = "tool_scientific",
            descKey = "tool_scientific_desc",
            category = ToolCategory.CALCULATORS,
            icon = Icons.Outlined.Science,
            route = "calc_scientific",
            isPrimary = true
        ),
        ToolItem(
            id = "age_calc",
            titleKey = "tool_age",
            descKey = "tool_age_desc",
            category = ToolCategory.LIFE,
            icon = Icons.Outlined.DateRange,
            route = "tool_age",
            isPrimary = true
        ),
        ToolItem(
            id = "gst_calc",
            titleKey = "tool_gst",
            descKey = "tool_gst_desc",
            category = ToolCategory.FINANCE,
            icon = Icons.Outlined.Receipt,
            route = "tool_gst",
            isPrimary = true
        ),
        ToolItem(
            id = "bmi_calc",
            titleKey = "tool_bmi",
            descKey = "tool_bmi_desc",
            category = ToolCategory.HEALTH,
            icon = Icons.Outlined.FitnessCenter,
            route = "tool_bmi",
            isPrimary = true
        ),
        ToolItem(
            id = "unit_converter",
            titleKey = "tool_unit",
            descKey = "tool_unit_desc",
            category = ToolCategory.CONVERTERS,
            icon = Icons.Outlined.Scale,
            route = "tool_unit",
            isPrimary = true
        ),
        ToolItem(
            id = "currency_converter",
            titleKey = "tool_currency",
            descKey = "tool_currency_desc",
            category = ToolCategory.CONVERTERS,
            icon = Icons.Outlined.CurrencyExchange,
            route = "tool_currency",
            isPrimary = true
        ),
        ToolItem(
            id = "discount_calc",
            titleKey = "tool_discount",
            descKey = "tool_discount_desc",
            category = ToolCategory.FINANCE,
            icon = Icons.Outlined.Percent,
            route = "tool_discount"
        ),
        ToolItem(
            id = "emi_calc",
            titleKey = "tool_emi",
            descKey = "tool_emi_desc",
            category = ToolCategory.FINANCE,
            icon = Icons.Outlined.Savings,
            route = "tool_emi"
        ),
        ToolItem(
            id = "tip_calc",
            titleKey = "tool_tip",
            descKey = "tool_tip_desc",
            category = ToolCategory.LIFE,
            icon = Icons.Outlined.Functions,
            route = "tool_tip"
        )
    )
}

data class CalculationHistory(
    val id: String,
    val expression: String,
    val result: String,
    val timestamp: Long,
    val isFavorite: Boolean = false
)
