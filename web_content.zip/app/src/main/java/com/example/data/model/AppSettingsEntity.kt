package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Stores app-wide settings including theme preference (persists across restarts).
 */
@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val themeMode: String = THEME_NORMAL
) {
    companion object {
        const val THEME_NORMAL = "NORMAL"
        const val THEME_DARK = "DARK"
        const val THEME_BOOK = "BOOK"
        const val THEME_SCHOOL_BAG = "SCHOOL_BAG"
        const val THEME_FLOWERS = "FLOWERS"
        const val THEME_NARUTO = "NARUTO"
        const val THEME_JUJUTSU_KAISEN = "JUJUTSU_KAISEN"
        const val THEME_FOREST = "FOREST"
    }
}
