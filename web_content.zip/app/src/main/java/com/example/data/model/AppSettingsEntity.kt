package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val isDarkMode: Boolean = false, // Light theme by default
    val themeId: String = "CYBER_NEON",
    val is24HourFormat: Boolean = false,
    val defaultSnoozeMinutes: Int = 10,
    val defaultVibrate: Boolean = true,
    val defaultTone: String = "Digital Pulse",
    val defaultCustomAudioPath: String? = null,
    val defaultCustomAudioTitle: String? = null
)
