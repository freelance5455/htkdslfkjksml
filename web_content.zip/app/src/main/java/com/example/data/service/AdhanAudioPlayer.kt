package com.example.data.service

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.data.model.AdhanAlertType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AdhanAudioPlayer(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPlayingKey = MutableStateFlow<String?>(null)
    val currentPlayingKey: StateFlow<String?> = _currentPlayingKey.asStateFlow()

    fun playPreview(type: AdhanAlertType) {
        stop()

        when (type) {
            AdhanAlertType.SILENT -> {
                // Do nothing
            }
            AdhanAlertType.BEEP -> {
                try {
                    val notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    val ringtone = RingtoneManager.getRingtone(context, notificationUri)
                    ringtone?.play()
                    vibrate()
                } catch (e: Exception) {
                    vibrate()
                }
            }
            AdhanAlertType.FULL_ABDULBASIT,
            AdhanAlertType.FULL_AFASY,
            AdhanAlertType.FULL_MAKKAH -> {
                val url = type.audioUrl ?: return
                try {
                    val player = MediaPlayer().apply {
                        setAudioAttributes(
                            AudioAttributes.Builder()
                                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .build()
                        )
                        setDataSource(url)
                        setOnPreparedListener { mp ->
                            mp.start()
                            _isPlaying.value = true
                            _currentPlayingKey.value = type.key
                        }
                        setOnCompletionListener {
                            stop()
                        }
                        setOnErrorListener { _, _, _ ->
                            stop()
                            // Fallback to notification sound
                            playPreview(AdhanAlertType.BEEP)
                            true
                        }
                        prepareAsync()
                    }
                    mediaPlayer = player
                } catch (e: Exception) {
                    stop()
                    playPreview(AdhanAlertType.BEEP)
                }
            }
        }
    }

    fun stop() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.release()
            }
        } catch (ignored: Exception) {}
        mediaPlayer = null
        _isPlaying.value = false
        _currentPlayingKey.value = null
    }

    private fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(100)
                }
            }
        } catch (ignored: Exception) {}
    }
}
