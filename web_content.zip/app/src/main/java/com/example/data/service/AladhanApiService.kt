package com.example.data.service

import com.example.data.model.HijriDate
import com.example.data.model.PrayerType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AladhanApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    data class OnlinePrayerResult(
        val timings: Map<PrayerType, Pair<Int, Int>>,
        val hijriDate: HijriDate?
    )

    suspend fun fetchTimingsByCity(
        city: String,
        country: String = "Algeria",
        methodId: Int = 3
    ): Result<OnlinePrayerResult> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.aladhan.com/v1/timingsByCity?city=$city&country=$country&method=$methodId"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP error ${response.code}"))
            }

            val body = response.body?.string() ?: return@withContext Result.failure(Exception("Empty body"))
            val parsed = parseJsonResponse(body)
            Result.success(parsed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchTimingsByCoordinates(
        latitude: Double,
        longitude: Double,
        methodId: Int = 3
    ): Result<OnlinePrayerResult> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.aladhan.com/v1/timings?latitude=$latitude&longitude=$longitude&method=$methodId"
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("HTTP error ${response.code}"))
            }

            val body = response.body?.string() ?: return@withContext Result.failure(Exception("Empty body"))
            val parsed = parseJsonResponse(body)
            Result.success(parsed)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseJsonResponse(jsonStr: String): OnlinePrayerResult {
        val root = JSONObject(jsonStr)
        val dataObj = root.getJSONObject("data")
        val timingsObj = dataObj.getJSONObject("timings")

        val timingsMap = mutableMapOf<PrayerType, Pair<Int, Int>>()
        for (prayer in PrayerType.entries) {
            if (timingsObj.has(prayer.key)) {
                val timeStr = timingsObj.getString(prayer.key)
                // Aladhan returns "HH:mm" or "HH:mm (CET)"
                val cleanTime = timeStr.split(" ").firstOrNull() ?: timeStr
                val parts = cleanTime.split(":")
                if (parts.size >= 2) {
                    val h = parts[0].toIntOrNull() ?: 0
                    val m = parts[1].toIntOrNull() ?: 0
                    timingsMap[prayer] = Pair(h, m)
                }
            }
        }

        var hijriDate: HijriDate? = null
        if (dataObj.has("date")) {
            val dateObj = dataObj.getJSONObject("date")
            if (dateObj.has("hijri")) {
                val hijriObj = dateObj.getJSONObject("hijri")
                val day = hijriObj.optString("day", "1")
                val year = hijriObj.optString("year", "1448")
                var monthAr = ""
                var monthEn = ""
                if (hijriObj.has("month")) {
                    val monthObj = hijriObj.getJSONObject("month")
                    monthAr = monthObj.optString("ar", "")
                    monthEn = monthObj.optString("en", "")
                }
                hijriDate = HijriDate(
                    day = day,
                    monthAr = monthAr,
                    monthEn = monthEn,
                    year = year,
                    designation = "هـ"
                )
            }
        }

        return OnlinePrayerResult(timingsMap, hijriDate)
    }
}
