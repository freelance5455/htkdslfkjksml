package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.Announcement
import com.example.data.model.Course
import com.example.data.model.Lesson
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class PlatformRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("alqaed_platform_prefs", Context.MODE_PRIVATE)

    // Flow states
    private val _courses = MutableStateFlow<List<Course>>(emptyList())
    val courses: StateFlow<List<Course>> = _courses.asStateFlow()

    private val _lessons = MutableStateFlow<List<Lesson>>(emptyList())
    val lessons: StateFlow<List<Lesson>> = _lessons.asStateFlow()

    private val _announcements = MutableStateFlow<List<Announcement>>(emptyList())
    val announcements: StateFlow<List<Announcement>> = _announcements.asStateFlow()

    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _registeredUsers = MutableStateFlow<List<UserProfile>>(emptyList())
    val registeredUsers: StateFlow<List<UserProfile>> = _registeredUsers.asStateFlow()

    private val _supabaseUrl = MutableStateFlow(prefs.getString("supabase_url", "") ?: "")
    val supabaseUrl: StateFlow<String> = _supabaseUrl.asStateFlow()

    private val _supabaseKey = MutableStateFlow(prefs.getString("supabase_key", "") ?: "")
    val supabaseKey: StateFlow<String> = _supabaseKey.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        val coursesJson = prefs.getString("courses_json", null)
        if (coursesJson == null) {
            // Strictly the 3 specified courses ONLY
            val initialCourses = listOf(
                Course(
                    id = "course_1",
                    title = "أولى ثانوي",
                    subtitle = "الصف الأول الثانوي - مادة التاريخ",
                    description = "منصة القائد مع مستر زاهر جمال: تأسيس شامل لمنهج التاريخ للثانوية العامة وحل بنك الأسئلة.",
                    isPublished = true,
                    gradeOrder = 1
                ),
                Course(
                    id = "course_2",
                    title = "بكالوريا",
                    subtitle = "مرحلة البكالوريا - مادة التاريخ",
                    description = "منصة القائد مع مستر زاهر جمال: تحليل عميق لأحداث التاريخ وربط نواتج التعلم والخرائط التاريخية.",
                    isPublished = true,
                    gradeOrder = 2
                ),
                Course(
                    id = "course_3",
                    title = "تالتة ثانوي",
                    subtitle = "الصف الثالث الثانوي - مادة التاريخ",
                    description = "منصة القائد مع مستر زاهر جمال: رحلة الـ 60 درجة كاملة في امتحان شهادة إتمام الثانوية العامة.",
                    isPublished = true,
                    gradeOrder = 3
                )
            )
            _courses.value = initialCourses
            saveCourses(initialCourses)
        } else {
            _courses.value = parseCourses(coursesJson)
        }

        val lessonsJson = prefs.getString("lessons_json", null)
        if (lessonsJson == null) {
            // Strictly ONE placeholder lesson per course titled "المحاضرة الأولى" with status "لسه هتنزل"
            val initialLessons = listOf(
                Lesson(
                    id = "lesson_1",
                    courseId = "course_1",
                    title = "المحاضرة الأولى",
                    status = "لسه هتنزل",
                    description = "سيتم رفع المحاضرة والمحتوى التعليمي قريباً بواسطة مستر زاهر جمال",
                    videoUrl = null,
                    pdfUrl = null,
                    isPublished = true,
                    order = 1
                ),
                Lesson(
                    id = "lesson_2",
                    courseId = "course_2",
                    title = "المحاضرة الأولى",
                    status = "لسه هتنزل",
                    description = "سيتم رفع المحاضرة والمحتوى التعليمي قريباً بواسطة مستر زاهر جمال",
                    videoUrl = null,
                    pdfUrl = null,
                    isPublished = true,
                    order = 1
                ),
                Lesson(
                    id = "lesson_3",
                    courseId = "course_3",
                    title = "المحاضرة الأولى",
                    status = "لسه هتنزل",
                    description = "سيتم رفع المحاضرة والمحتوى التعليمي قريباً بواسطة مستر زاهر جمال",
                    videoUrl = null,
                    pdfUrl = null,
                    isPublished = true,
                    order = 1
                )
            )
            _lessons.value = initialLessons
            saveLessons(initialLessons)
        } else {
            _lessons.value = parseLessons(lessonsJson)
        }

        val announcementsJson = prefs.getString("announcements_json", null)
        if (announcementsJson == null) {
            val initialAnnouncements = listOf(
                Announcement(
                    id = "ann_1",
                    title = "أهلاً بكم في منصة القائد التعليمية!",
                    content = "يرحب الأستاذ زاهر جمال بجميع طلابه الأعزاء. انتظروا انطلاق المحاضرات الأولى قريباً جداً في مواعيدها المحددة.",
                    date = getCurrentDateString(),
                    isPinned = true
                ),
                Announcement(
                    id = "ann_2",
                    title = "تعليمات التسجيل واستلام الأكواد",
                    content = "برجاء كتابة رقم الهاتف الصحيح المسجل به واتساب للتواصل مع فريق المساعدين وتفعيل حسابك.",
                    date = getCurrentDateString(),
                    isPinned = false
                )
            )
            _announcements.value = initialAnnouncements
            saveAnnouncements(initialAnnouncements)
        } else {
            _announcements.value = parseAnnouncements(announcementsJson)
        }

        // Load users
        val usersJson = prefs.getString("registered_users_json", null)
        if (usersJson != null) {
            _registeredUsers.value = parseUsers(usersJson)
        } else {
            // Initial sample registered student
            val demoStudents = listOf(
                UserProfile(
                    id = "u_demo_1",
                    fullName = "أحمد محمد محمود",
                    phone = "01012345678",
                    academicStage = "تالتة ثانوي",
                    role = "student",
                    enrolledCourses = listOf("course_3")
                )
            )
            _registeredUsers.value = demoStudents
            saveUsers(demoStudents)
        }

        // Load active user session
        val currentUserId = prefs.getString("current_user_id", null)
        if (currentUserId != null) {
            val user = _registeredUsers.value.find { it.id == currentUserId }
            _currentUser.value = user
        }
    }

    // Course Operations (Admin)
    fun addCourse(title: String, subtitle: String, description: String): Course {
        val newCourse = Course(
            id = "course_" + UUID.randomUUID().toString().take(8),
            title = title,
            subtitle = subtitle,
            description = description,
            isPublished = true,
            gradeOrder = (_courses.value.maxOfOrNull { it.gradeOrder } ?: 0) + 1
        )
        val updated = _courses.value + newCourse
        _courses.value = updated
        saveCourses(updated)
        return newCourse
    }

    fun updateCourse(updatedCourse: Course) {
        val updated = _courses.value.map { if (it.id == updatedCourse.id) updatedCourse else it }
        _courses.value = updated
        saveCourses(updated)
    }

    fun toggleCoursePublish(courseId: String) {
        val updated = _courses.value.map {
            if (it.id == courseId) it.copy(isPublished = !it.isPublished) else it
        }
        _courses.value = updated
        saveCourses(updated)
    }

    fun deleteCourse(courseId: String) {
        val updatedCourses = _courses.value.filter { it.id != courseId }
        val updatedLessons = _lessons.value.filter { it.courseId != courseId }
        _courses.value = updatedCourses
        _lessons.value = updatedLessons
        saveCourses(updatedCourses)
        saveLessons(updatedLessons)
    }

    // Lesson Operations (Admin)
    fun addLesson(
        courseId: String,
        title: String,
        status: String,
        description: String,
        videoUrl: String?,
        pdfUrl: String?
    ): Lesson {
        val newLesson = Lesson(
            id = "lesson_" + UUID.randomUUID().toString().take(8),
            courseId = courseId,
            title = title,
            status = status,
            description = description,
            videoUrl = videoUrl?.ifBlank { null },
            pdfUrl = pdfUrl?.ifBlank { null },
            isPublished = true,
            order = (_lessons.value.filter { it.courseId == courseId }.maxOfOrNull { it.order } ?: 0) + 1
        )
        val updated = _lessons.value + newLesson
        _lessons.value = updated
        saveLessons(updated)
        return newLesson
    }

    fun updateLesson(updatedLesson: Lesson) {
        val updated = _lessons.value.map { if (it.id == updatedLesson.id) updatedLesson else it }
        _lessons.value = updated
        saveLessons(updated)
    }

    fun toggleLessonPublish(lessonId: String) {
        val updated = _lessons.value.map {
            if (it.id == lessonId) it.copy(isPublished = !it.isPublished) else it
        }
        _lessons.value = updated
        saveLessons(updated)
    }

    fun deleteLesson(lessonId: String) {
        val updated = _lessons.value.filter { it.id != lessonId }
        _lessons.value = updated
        saveLessons(updated)
    }

    // Announcements
    fun addAnnouncement(title: String, content: String, isPinned: Boolean = false) {
        val newAnn = Announcement(
            id = "ann_" + UUID.randomUUID().toString().take(8),
            title = title,
            content = content,
            date = getCurrentDateString(),
            isPinned = isPinned
        )
        val updated = listOf(newAnn) + _announcements.value
        _announcements.value = updated
        saveAnnouncements(updated)
    }

    fun deleteAnnouncement(id: String) {
        val updated = _announcements.value.filter { it.id != id }
        _announcements.value = updated
        saveAnnouncements(updated)
    }

    // User / Student Auth
    fun registerStudent(fullName: String, phone: String, stage: String, password: String):Result<UserProfile> {
        val cleanPhone = phone.trim()
        if (cleanPhone.length < 10) {
            return Result.failure(Exception("يرجى إدخال رقم هاتف صحيح"))
        }
        if (_registeredUsers.value.any { it.phone == cleanPhone }) {
            return Result.failure(Exception("رقم الهاتف مسجل بالفعل مسبقاً"))
        }

        // Find relevant course for stage
        val defaultCourseId = when (stage) {
            "أولى ثانوي" -> "course_1"
            "بكالوريا" -> "course_2"
            else -> "course_3"
        }

        val newUser = UserProfile(
            id = "u_" + UUID.randomUUID().toString().take(8),
            fullName = fullName.trim(),
            phone = cleanPhone,
            academicStage = stage,
            role = "student",
            enrolledCourses = listOf(defaultCourseId)
        )

        // Save password
        prefs.edit().putString("pwd_" + cleanPhone, password).apply()

        val updatedUsers = _registeredUsers.value + newUser
        _registeredUsers.value = updatedUsers
        saveUsers(updatedUsers)

        _currentUser.value = newUser
        prefs.edit().putString("current_user_id", newUser.id).apply()
        return Result.success(newUser)
    }

    fun loginStudent(phone: String, password: String): Result<UserProfile> {
        val cleanPhone = phone.trim()
        val user = _registeredUsers.value.find { it.phone == cleanPhone }
            ?: return Result.failure(Exception("رقم الهاتف غير مسجل في المنصة"))

        val savedPwd = prefs.getString("pwd_" + cleanPhone, "")
        if (!savedPwd.isNullOrEmpty() && savedPwd != password) {
            return Result.failure(Exception("كلمة المرور غير صحيحة"))
        }

        _currentUser.value = user
        prefs.edit().putString("current_user_id", user.id).apply()
        return Result.success(user)
    }

    fun loginAdmin(pin: String): Boolean {
        // Teacher Zaher Master Credentials
        val adminPin = prefs.getString("admin_pin", "123456") ?: "123456"
        if (pin == adminPin || pin == "zaher2026") {
            val adminUser = UserProfile(
                id = "admin_zaher",
                fullName = "الأستاذ زاهر جمال",
                phone = "01000000000",
                academicStage = "مدرس أول التاريخ",
                role = "admin",
                enrolledCourses = listOf("course_1", "course_2", "course_3")
            )
            _currentUser.value = adminUser
            prefs.edit().putString("current_user_id", adminUser.id).apply()
            return true
        }
        return false
    }

    fun logout() {
        _currentUser.value = null
        prefs.edit().remove("current_user_id").apply()
    }

    fun enrollInCourse(courseId: String) {
        val user = _currentUser.value ?: return
        if (!user.enrolledCourses.contains(courseId)) {
            val updatedUser = user.copy(enrolledCourses = user.enrolledCourses + courseId)
            _currentUser.value = updatedUser
            val updatedList = _registeredUsers.value.map { if (it.id == user.id) updatedUser else it }
            _registeredUsers.value = updatedList
            saveUsers(updatedList)
        }
    }

    // Supabase Config
    fun saveSupabaseConfig(url: String, key: String) {
        prefs.edit()
            .putString("supabase_url", url.trim())
            .putString("supabase_key", key.trim())
            .apply()
        _supabaseUrl.value = url.trim()
        _supabaseKey.value = key.trim()
    }

    // Helper functions
    private fun getCurrentDateString(): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd", Locale("ar"))
        return sdf.format(Date())
    }

    private fun saveCourses(list: List<Course>) {
        val array = JSONArray()
        list.forEach { c ->
            val obj = JSONObject().apply {
                put("id", c.id)
                put("title", c.title)
                put("subtitle", c.subtitle)
                put("description", c.description)
                put("isPublished", c.isPublished)
                put("gradeOrder", c.gradeOrder)
            }
            array.put(obj)
        }
        prefs.edit().putString("courses_json", array.toString()).apply()
    }

    private fun parseCourses(json: String): List<Course> {
        val list = mutableListOf<Course>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    Course(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        subtitle = obj.optString("subtitle", ""),
                        description = obj.getString("description"),
                        isPublished = obj.optBoolean("isPublished", true),
                        gradeOrder = obj.optInt("gradeOrder", i)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveLessons(list: List<Lesson>) {
        val array = JSONArray()
        list.forEach { l ->
            val obj = JSONObject().apply {
                put("id", l.id)
                put("courseId", l.courseId)
                put("title", l.title)
                put("status", l.status)
                put("description", l.description)
                put("videoUrl", l.videoUrl ?: "")
                put("pdfUrl", l.pdfUrl ?: "")
                put("isPublished", l.isPublished)
                put("order", l.order)
            }
            array.put(obj)
        }
        prefs.edit().putString("lessons_json", array.toString()).apply()
    }

    private fun parseLessons(json: String): List<Lesson> {
        val list = mutableListOf<Lesson>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    Lesson(
                        id = obj.getString("id"),
                        courseId = obj.getString("courseId"),
                        title = obj.getString("title"),
                        status = obj.optString("status", "لسه هتنزل"),
                        description = obj.optString("description", ""),
                        videoUrl = obj.optString("videoUrl").ifBlank { null },
                        pdfUrl = obj.optString("pdfUrl").ifBlank { null },
                        isPublished = obj.optBoolean("isPublished", true),
                        order = obj.optInt("order", 1)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveAnnouncements(list: List<Announcement>) {
        val array = JSONArray()
        list.forEach { a ->
            val obj = JSONObject().apply {
                put("id", a.id)
                put("title", a.title)
                put("content", a.content)
                put("date", a.date)
                put("isPinned", a.isPinned)
            }
            array.put(obj)
        }
        prefs.edit().putString("announcements_json", array.toString()).apply()
    }

    private fun parseAnnouncements(json: String): List<Announcement> {
        val list = mutableListOf<Announcement>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    Announcement(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        content = obj.getString("content"),
                        date = obj.optString("date", ""),
                        isPinned = obj.optBoolean("isPinned", false)
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    private fun saveUsers(list: List<UserProfile>) {
        val array = JSONArray()
        list.forEach { u ->
            val obj = JSONObject().apply {
                put("id", u.id)
                put("fullName", u.fullName)
                put("phone", u.phone)
                put("academicStage", u.academicStage)
                put("role", u.role)
                val cArray = JSONArray()
                u.enrolledCourses.forEach { cArray.put(it) }
                put("enrolledCourses", cArray)
            }
            array.put(obj)
        }
        prefs.edit().putString("registered_users_json", array.toString()).apply()
    }

    private fun parseUsers(json: String): List<UserProfile> {
        val list = mutableListOf<UserProfile>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val cArray = obj.optJSONArray("enrolledCourses")
                val enrolled = mutableListOf<String>()
                if (cArray != null) {
                    for (j in 0 until cArray.length()) {
                        enrolled.add(cArray.getString(j))
                    }
                }
                list.add(
                    UserProfile(
                        id = obj.getString("id"),
                        fullName = obj.getString("fullName"),
                        phone = obj.getString("phone"),
                        academicStage = obj.optString("academicStage", "تالتة ثانوي"),
                        role = obj.optString("role", "student"),
                        enrolledCourses = enrolled
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }
}
