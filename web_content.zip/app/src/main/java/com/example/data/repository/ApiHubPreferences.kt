package com.example.data.repository

import android.content.Context
import com.example.BuildConfig
import com.example.data.model.AiModelOption
import com.example.data.model.AiProvider

enum class ArchitecturePreset(
    val id: String,
    val label: String,
    val promptDirective: String
) {
    SINGLE_SCREEN_UTILITY(
        id = "SINGLE_SCREEN_UTILITY",
        label = "Single-Screen Utility",
        promptDirective = "Structure as a self-contained single-screen Compose utility with immediate state hoisting and reactive calculation cards."
    ),
    MVVM_STATEFLOW(
        id = "MVVM_STATEFLOW",
        label = "MVVM + StateFlow",
        promptDirective = "Structure using clean MVVM architecture with a dedicated ViewModel, StateFlow state holder, and modular Material 3 composables."
    ),
    MULTI_STEP_WORKFLOW(
        id = "MULTI_STEP_WORKFLOW",
        label = "Multi-Step Validator",
        promptDirective = "Structure as a multi-stage interactive workflow with input validation, step progression, and live diagnostic output."
    );

    companion object {
        fun fromId(id: String): ArchitecturePreset =
            entries.firstOrNull { it.id == id } ?: MVVM_STATEFLOW
    }
}

data class ApiHubConfig(
    val selectedProvider: AiProvider = AiProvider.GEMINI,
    val selectedModel: AiModelOption = AiModelOption.GEMINI_4_ARGON,
    val openAiApiKey: String = "",
    val anthropicApiKey: String = "",
    val geminiCustomApiKey: String = "",
    val stripeSecretKey: String = "",
    val useFirebaseAiForGemini: Boolean = true,
    val temperature: Float = 0.3f,
    val maxOutputTokens: Int = 4096,
    val architecturePreset: ArchitecturePreset = ArchitecturePreset.MVVM_STATEFLOW,
    val includeFullGradleScaffold: Boolean = true
) {
    fun hasActiveCredential(): Boolean {
        return when (selectedProvider) {
            AiProvider.OPENAI -> openAiApiKey.isNotBlank()
            AiProvider.ANTHROPIC -> anthropicApiKey.isNotBlank()
            AiProvider.GEMINI -> useFirebaseAiForGemini || geminiCustomApiKey.isNotBlank()
        }
    }

    fun maskedKeyFor(provider: AiProvider): String {
        val raw = when (provider) {
            AiProvider.OPENAI -> openAiApiKey
            AiProvider.ANTHROPIC -> anthropicApiKey
            AiProvider.GEMINI -> geminiCustomApiKey
        }.trim()
        if (raw.isEmpty()) {
            return if (provider == AiProvider.GEMINI && useFirebaseAiForGemini) {
                "Firebase AI Logic (App Check Attested)"
            } else {
                "Not configured"
            }
        }
        return if (raw.length <= 8) {
            "••••••••"
        } else {
            "${raw.take(4)}••••${raw.takeLast(4)}"
        }
    }

    fun maskedStripeKey(): String {
        val raw = stripeSecretKey.trim()
        if (raw.isEmpty()) return "Not configured"
        return if (raw.length <= 8) "••••••••" else "${raw.take(7)}••••${raw.takeLast(4)}"
    }
}

class ApiHubPreferences(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private fun resolveBuildConfigStripeKey(): String {
        val raw = try {
            BuildConfig.STRIPE_SECRET_KEY
        } catch (_: Exception) {
            ""
        }
        return if (raw.isNullOrBlank() || raw == "null" || raw == "YOUR_STRIPE_SECRET_KEY") {
            ""
        } else {
            raw.trim()
        }
    }

    fun loadConfig(): ApiHubConfig {
        val providerId = prefs.getString(KEY_PROVIDER, AiProvider.GEMINI.id) ?: AiProvider.GEMINI.id
        val provider = AiProvider.fromId(providerId)
        val defaultModelId = AiModelOption.forProvider(provider).first().modelId
        val modelId = prefs.getString(KEY_MODEL, defaultModelId) ?: defaultModelId
        val model = AiModelOption.fromModelId(modelId).let {
            if (it.provider == provider) it else AiModelOption.forProvider(provider).first()
        }
        val presetId = prefs.getString(KEY_ARCH_PRESET, ArchitecturePreset.MVVM_STATEFLOW.id).orEmpty()
        val storedStripeKey = prefs.getString(KEY_STRIPE_SECRET, "").orEmpty().trim()
        val effectiveStripeKey = storedStripeKey.ifBlank { resolveBuildConfigStripeKey() }

        return ApiHubConfig(
            selectedProvider = provider,
            selectedModel = model,
            openAiApiKey = prefs.getString(KEY_OPENAI, "").orEmpty(),
            anthropicApiKey = prefs.getString(KEY_ANTHROPIC, "").orEmpty(),
            geminiCustomApiKey = prefs.getString(KEY_GEMINI, "").orEmpty(),
            stripeSecretKey = effectiveStripeKey,
            useFirebaseAiForGemini = prefs.getBoolean(KEY_USE_FIREBASE_AI, true),
            temperature = prefs.getFloat(KEY_TEMPERATURE, 0.3f).coerceIn(0.0f, 1.0f),
            maxOutputTokens = prefs.getInt(KEY_MAX_TOKENS, 4096).coerceIn(1024, 8192),
            architecturePreset = ArchitecturePreset.fromId(presetId),
            includeFullGradleScaffold = prefs.getBoolean(KEY_FULL_SCAFFOLD, true)
        )
    }

    fun saveProviderAndModel(provider: AiProvider, model: AiModelOption) {
        val alignedModel = if (model.provider == provider) {
            model
        } else {
            AiModelOption.forProvider(provider).first()
        }
        prefs.edit()
            .putString(KEY_PROVIDER, provider.id)
            .putString(KEY_MODEL, alignedModel.modelId)
            .apply()
    }

    fun saveArchitecturePreset(preset: ArchitecturePreset) {
        prefs.edit()
            .putString(KEY_ARCH_PRESET, preset.id)
            .apply()
    }

    fun saveGenerationParameters(
        temperature: Float,
        maxOutputTokens: Int,
        includeFullGradleScaffold: Boolean
    ) {
        prefs.edit()
            .putFloat(KEY_TEMPERATURE, temperature.coerceIn(0.0f, 1.0f))
            .putInt(KEY_MAX_TOKENS, maxOutputTokens.coerceIn(1024, 8192))
            .putBoolean(KEY_FULL_SCAFFOLD, includeFullGradleScaffold)
            .apply()
    }

    fun saveStripeSecretKey(stripeKey: String) {
        prefs.edit()
            .putString(KEY_STRIPE_SECRET, stripeKey.trim())
            .apply()
    }

    fun saveApiKeys(
        openAiKey: String,
        anthropicKey: String,
        geminiKey: String,
        useFirebaseAiForGemini: Boolean,
        stripeKey: String? = null
    ) {
        val editor = prefs.edit()
            .putString(KEY_OPENAI, openAiKey.trim())
            .putString(KEY_ANTHROPIC, anthropicKey.trim())
            .putString(KEY_GEMINI, geminiKey.trim())
            .putBoolean(KEY_USE_FIREBASE_AI, useFirebaseAiForGemini)
        if (stripeKey != null) {
            editor.putString(KEY_STRIPE_SECRET, stripeKey.trim())
        }
        editor.apply()
    }

    fun clearAllKeys() {
        prefs.edit()
            .remove(KEY_OPENAI)
            .remove(KEY_ANTHROPIC)
            .remove(KEY_GEMINI)
            .remove(KEY_STRIPE_SECRET)
            .putBoolean(KEY_USE_FIREBASE_AI, true)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "omniprompt_api_hub_prefs"
        private const val KEY_PROVIDER = "selected_provider"
        private const val KEY_MODEL = "selected_model"
        private const val KEY_OPENAI = "openai_api_key"
        private const val KEY_ANTHROPIC = "anthropic_api_key"
        private const val KEY_GEMINI = "gemini_custom_api_key"
        private const val KEY_STRIPE_SECRET = "stripe_secret_key"
        private const val KEY_USE_FIREBASE_AI = "use_firebase_ai_for_gemini"
        private const val KEY_TEMPERATURE = "generation_temperature"
        private const val KEY_MAX_TOKENS = "generation_max_tokens"
        private const val KEY_ARCH_PRESET = "architecture_preset"
        private const val KEY_FULL_SCAFFOLD = "include_full_gradle_scaffold"
    }
}
