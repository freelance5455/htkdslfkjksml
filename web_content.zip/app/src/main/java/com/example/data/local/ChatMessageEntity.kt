package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole

@Entity(
    tableName = "sessions",
    indices = [Index(value = ["updatedAt"])]
)
data class ConversationSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val messageCount: Int = 0,
    val lastMessagePreview: String = ""
)

@Entity(
    tableName = "chat_messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["sessionId"]),
        Index(value = ["timestamp"])
    ]
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sessionId: Long,
    val role: String, // "USER", "ASSISTANT", "SYSTEM"
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val engineUsed: String = "Local Neural G100",
    val latencyMs: Long = 0,
    val tokensCount: Int = 0
)

fun ChatMessageEntity.toDomain(): ChatMessage {
    val messageRole = try {
        MessageRole.valueOf(role)
    } catch (e: Exception) {
        MessageRole.ASSISTANT
    }
    return ChatMessage(
        id = id,
        sessionId = sessionId,
        role = messageRole,
        content = content,
        timestamp = timestamp,
        engineUsed = engineUsed,
        latencyMs = latencyMs,
        tokensCount = tokensCount,
        isStreaming = false
    )
}

fun ChatMessage.toEntity(): ChatMessageEntity {
    return ChatMessageEntity(
        id = id,
        sessionId = sessionId,
        role = role.name,
        content = content,
        timestamp = timestamp,
        engineUsed = engineUsed,
        latencyMs = latencyMs,
        tokensCount = tokensCount
    )
}
