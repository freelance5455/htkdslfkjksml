package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ArkChallenge
import com.example.data.model.ChallengeProgress
import com.example.data.model.GameCatalog
import com.example.data.model.GroupEvent
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ChallengeRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing challenges.")

    fun observeActiveChallenges(): Flow<List<ArkChallenge>> = flow {
        val path = "challenges"
        emitAll(
            db.collection("challenges")
                .whereEqualTo("isActive", true)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ArkChallenge::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.rewardPoints }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeUserProgress(userId: String): Flow<Map<String, ChallengeProgress>> = flow {
        val path = "users/$userId/challengeProgress"
        emitAll(
            db.collection("users").document(userId).collection("challengeProgress")
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ChallengeProgress::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).associateBy { it.challengeId }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeUpcomingEvents(userId: String): Flow<List<GroupEvent>> = flow {
        val path = "events"
        emitAll(
            db.collection("events")
                .whereEqualTo("isPublic", true)
                .limit(20)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        GroupEvent::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun ensureSafeChallengesSeeded() {
        val uid = requireUserId()
        val path = "challenges"
        try {
            val existingChallenges = db.collection("challenges")
                .whereEqualTo("isActive", true)
                .limit(1)
                .get()
                .await()
            val existingEvents = db.collection("events")
                .whereEqualTo("isPublic", true)
                .limit(1)
                .get()
                .await()

            if (!existingChallenges.isEmpty && !existingEvents.isEmpty) return

            val batch = db.batch()
            var hasWrites = false

            if (existingChallenges.isEmpty) {
                GameCatalog.safeSeedChallenges.forEach { seed ->
                    val ref = db.collection("challenges").document(seed.id)
                    if (!ref.get().await().exists()) {
                        batch.set(
                            ref,
                            mapOf(
                                "title" to seed.title,
                                "description" to seed.description,
                                "category" to seed.category,
                                "difficulty" to seed.difficulty,
                                "frequency" to seed.frequency,
                                "rewardPoints" to seed.rewardPoints,
                                "isGroupChallenge" to seed.isGroupChallenge,
                                "isActive" to true,
                                "expiresLabel" to seed.expiresLabel,
                                "createdBy" to uid,
                                "createdAt" to FieldValue.serverTimestamp()
                            )
                        )
                        hasWrites = true
                    }
                }
            }

            if (existingEvents.isEmpty) {
                val eventRef = db.collection("events").document("evt_friday_arena")
                if (!eventRef.get().await().exists()) {
                    batch.set(
                        eventRef,
                        mapOf(
                            "creatorId" to uid,
                            "groupId" to "community",
                            "title" to "Weekend Squad Quiz Night",
                            "description" to "Friendly community trivia & Word Chain showcase.",
                            "category" to "Game Night",
                            "isPublic" to true,
                            "memberUids" to listOf(uid),
                            "scheduledLabel" to "Saturday • 7:30 PM IST",
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )
                    hasWrites = true
                }
            }

            if (hasWrites) {
                batch.commit().await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
        }
    }

    suspend fun completeChallenge(
        challenge: ArkChallenge,
        reflectionNote: String,
        userRepository: UserRepository
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        val progressRef = db.collection("users").document(uid)
            .collection("challengeProgress").document(challenge.id)

        try {
            val existingSnap = progressRef.get().await()
            require(!existingSnap.exists()) { "Challenge already completed or skipped." }

            val payload = mutableMapOf<String, Any>(
                "userId" to uid,
                "challengeId" to challenge.id,
                "status" to "completed",
                "pointsAwarded" to challenge.rewardPoints.coerceIn(10L, 250L),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (reflectionNote.isNotBlank()) {
                payload["reflectionNote"] = reflectionNote.trim().take(240)
            }
            progressRef.set(payload).await()

            userRepository.awardProgress(
                userId = uid,
                pointsDelta = challenge.rewardPoints,
                xpDelta = challenge.rewardPoints,
                incrementChallenges = true,
                newBadge = "Challenge Achiever"
            ).getOrThrow()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, progressRef.path)
            throw e
        }
    }

    suspend fun skipChallenge(challengeId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val progressRef = db.collection("users").document(uid)
            .collection("challengeProgress").document(challengeId)
        try {
            val existingSnap = progressRef.get().await()
            if (existingSnap.exists()) return@runCatching
            progressRef.set(
                mapOf(
                    "userId" to uid,
                    "challengeId" to challengeId,
                    "status" to "skipped",
                    "pointsAwarded" to 0L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, progressRef.path)
            throw e
        }
    }
}
