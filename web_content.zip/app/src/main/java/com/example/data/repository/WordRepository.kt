package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.WordItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Repository responsible for managing the user's word bank, presets,
 * persistence, and non-repeating random cycle generation.
 */
class WordRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("autowriter_words_prefs", Context.MODE_PRIVATE)

    private val _words = MutableStateFlow<List<WordItem>>(emptyList())
    val words: StateFlow<List<WordItem>> = _words.asStateFlow()

    init {
        loadWords()
    }

    private fun loadWords() {
        val jsonString = prefs.getString(KEY_WORDS_JSON, null)
        if (jsonString.isNullOrEmpty()) {
            val defaults = getDefaultWordBank()
            _words.value = defaults
            saveWordsToPrefs(defaults)
        } else {
            try {
                val list = mutableListOf<WordItem>()
                val array = JSONArray(jsonString)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        WordItem(
                            id = obj.getString("id"),
                            text = obj.getString("text"),
                            category = obj.optString("category", "عام"),
                            isEnabled = obj.optBoolean("isEnabled", true),
                            timesUsed = obj.optInt("timesUsed", 0),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
                _words.value = if (list.isNotEmpty()) list else getDefaultWordBank()
            } catch (_: Exception) {
                _words.value = getDefaultWordBank()
            }
        }
    }

    private fun saveWordsToPrefs(items: List<WordItem>) {
        try {
            val array = JSONArray()
            for (item in items) {
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("text", item.text)
                    put("category", item.category)
                    put("isEnabled", item.isEnabled)
                    put("timesUsed", item.timesUsed)
                    put("createdAt", item.createdAt)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_WORDS_JSON, array.toString()).apply()
        } catch (_: Exception) {
        }
    }

    fun addWord(text: String, category: String = "مخصص") {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        val current = _words.value.toMutableList()
        // Prevent duplicate word in list
        if (current.none { it.text.equals(trimmed, ignoreCase = true) }) {
            current.add(0, WordItem(text = trimmed, category = category, isEnabled = true))
            _words.value = current
            saveWordsToPrefs(current)
        }
    }

    fun bulkAddWords(rawText: String, category: String = "مخصص"): Int {
        val tokens = rawText.split(Regex("[,\\n،;\\t]+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        if (tokens.isEmpty()) return 0
        val current = _words.value.toMutableList()
        var addedCount = 0
        for (token in tokens) {
            if (current.none { it.text.equals(token, ignoreCase = true) }) {
                current.add(WordItem(text = token, category = category, isEnabled = true))
                addedCount++
            }
        }
        if (addedCount > 0) {
            _words.value = current
            saveWordsToPrefs(current)
        }
        return addedCount
    }

    fun deleteWord(id: String) {
        val current = _words.value.filter { it.id != id }
        _words.value = current
        saveWordsToPrefs(current)
    }

    fun toggleWord(id: String) {
        val current = _words.value.map {
            if (it.id == id) it.copy(isEnabled = !it.isEnabled) else it
        }
        _words.value = current
        saveWordsToPrefs(current)
    }

    fun selectAll(select: Boolean) {
        val current = _words.value.map { it.copy(isEnabled = select) }
        _words.value = current
        saveWordsToPrefs(current)
    }

    fun incrementUsage(wordText: String) {
        val current = _words.value.map {
            if (it.text == wordText) it.copy(timesUsed = it.timesUsed + 1) else it
        }
        _words.value = current
        saveWordsToPrefs(current)
    }

    fun resetToDefaults() {
        val defaults = getDefaultWordBank()
        _words.value = defaults
        saveWordsToPrefs(defaults)
    }

    /**
     * Generates a sequence of words according to user criteria:
     * - If [isRandom] is true: Random shuffle WITHOUT repetition during the cycle!
     * - If count > available words: multiple non-repeating cycles are chained.
     */
    fun generateSequence(count: Int, isRandom: Boolean): List<WordItem> {
        val active = _words.value.filter { it.isEnabled }
        if (active.isEmpty()) return emptyList()

        val targetCount = count.coerceAtLeast(1)
        val result = mutableListOf<WordItem>()

        if (isRandom) {
            while (result.size < targetCount) {
                val cycleShuffled = active.shuffled()
                val needed = targetCount - result.size
                result.addAll(cycleShuffled.take(needed))
            }
        } else {
            var index = 0
            while (result.size < targetCount) {
                result.add(active[index % active.size])
                index++
            }
        }
        return result
    }

    companion object {
        private const val KEY_WORDS_JSON = "key_words_json_v1"

        fun getDefaultWordBank(): List<WordItem> {
            val list = mutableListOf<WordItem>()
            val techWords = listOf(
                "الذكاء الاصطناعي", "برمجة أندرويد", "كوتلن وسويفت", "واجهات كومبوز",
                "هندسة البرمجيات", "إدارة الحالة", "قواعد البيانات", "الحوسبة السحابية",
                "الأمن السيبراني", "الخوارزميات الذكية", "التطوير المستمر", "الأتمتة الكاملة"
            )
            techWords.forEach { list.add(WordItem(text = it, category = "تقنية وبرمجة")) }

            val arabicGeneral = listOf(
                "مرحباً بك", "السرعة والدقة", "إبداع بلا حدود", "تميز وكفاءة",
                "المستقبل الرقمي", "العمل الجاد", "نجاح مستحق", "ابتكار ريادي",
                "طموح يعانق السماء", "حلول ذكية", "تجربة استثنائية", "إتقان واحتراف"
            )
            arabicGeneral.forEach { list.add(WordItem(text = it, category = "عام وملهم")) }

            val quickSpeed = listOf(
                "AutoWriter", "Fast", "Smart", "Efficiency", "Matrix",
                "Compose", "Coroutines", "Flow", "Speed", "Keyboard"
            )
            quickSpeed.forEach { list.add(WordItem(text = it, category = "English Speed")) }

            return list
        }
    }
}
