package com.example.data.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "salaries",
    indices = [
        Index(value = ["institution", "year", "monthIndex"], unique = true)
    ]
)
data class SalaryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val institution: String, // "মাদরাসা" or "মসজিদ"
    val year: Int,
    val monthIndex: Int, // 1 to 12
    val monthName: String, // "জানুয়ারি", "ফেব্রুয়ারি" ইত্যাদি
    val amount: Double,
    val date: String, // yyyy-MM-dd
    val description: String,
    val isPaid: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
