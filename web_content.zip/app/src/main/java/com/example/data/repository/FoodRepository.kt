package com.example.data.repository

import android.graphics.Bitmap
import android.graphics.Color
import com.example.data.local.MealDao
import com.example.data.local.MealEntity
import com.example.data.model.FoodAnalysisResult
import com.example.data.model.IngredientDetail
import com.example.data.model.MealType
import com.example.data.model.SampleFoodPreset
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

interface FoodRepository {
    suspend fun analyzeFood(bitmap: Bitmap?, presetId: String? = null): FoodAnalysisResult
    fun getMealsForDate(dateString: String): Flow<List<MealEntity>>
    fun getTotalCaloriesForDate(dateString: String): Flow<Int?>
    suspend fun saveMeal(meal: MealEntity): Long
    suspend fun deleteMeal(meal: MealEntity)
    fun getSamplePresets(): List<SampleFoodPreset>
}

class FoodRepositoryImpl(
    private val mealDao: MealDao
) : FoodRepository {

    override fun getSamplePresets(): List<SampleFoodPreset> = listOf(
        SampleFoodPreset(
            id = "zereshk_polo",
            title = "زرشک‌پلو با مرغ",
            subtitle = "برنج زعفرانی، ران مرغ و زرشک",
            calories = 620,
            emoji = "🍗",
            defaultMealType = MealType.LUNCH
        ),
        SampleFoodPreset(
            id = "ghormeh_sabzi",
            title = "قورمه‌سبزی با کته",
            subtitle = "سبزی سرخ‌شده، گوشت گوساله و لوبیا",
            calories = 580,
            emoji = "🥘",
            defaultMealType = MealType.LUNCH
        ),
        SampleFoodPreset(
            id = "caesar_salad",
            title = "سالاد سزار با مرغ گریل",
            subtitle = "کاهو رسمی، فیله گریل و پنیر پارمسان",
            calories = 340,
            emoji = "🥗",
            defaultMealType = MealType.DINNER
        ),
        SampleFoodPreset(
            id = "koobideh",
            title = "چلو کباب کوبیده",
            subtitle = "دو سیخ کوبیده با برنج و گوجه کبابی",
            calories = 780,
            emoji = "🥩",
            defaultMealType = MealType.DINNER
        ),
        SampleFoodPreset(
            id = "pizza",
            title = "پیتزا مخصوص تنوری",
            subtitle = "قارچ، ژامبون بیکن و پنیر موزارلا",
            calories = 690,
            emoji = "🍕",
            defaultMealType = MealType.DINNER
        ),
        SampleFoodPreset(
            id = "healthy_breakfast",
            title = "املت گوجه و نان سنگک",
            subtitle = "تخم‌مرغ، گوجه تازه و روغن زیتون",
            calories = 380,
            emoji = "🍳",
            defaultMealType = MealType.BREAKFAST
        ),
        SampleFoodPreset(
            id = "pasta_alfredo",
            title = "پاستا پنه با سس آلفردو",
            subtitle = "پاستا، سینه مرغ، قارچ و خامه",
            calories = 650,
            emoji = "🍝",
            defaultMealType = MealType.LUNCH
        ),
        SampleFoodPreset(
            id = "fruit_bowl",
            title = "کاسه میوه و جو دوسر",
            subtitle = "موز، توت فرنگی، شیر بادام و عسل",
            calories = 290,
            emoji = "🍓",
            defaultMealType = MealType.BREAKFAST
        )
    )

    override suspend fun analyzeFood(bitmap: Bitmap?, presetId: String?): FoodAnalysisResult {
        // Simulate realistic AI vision inference time
        delay(1200)

        // Check if a predefined preset was selected
        if (presetId != null) {
            return getPresetResult(presetId)
        }

        // If bitmap is provided, use image heuristic analysis
        if (bitmap != null) {
            return analyzeBitmap(bitmap)
        }

        // Default fallback healthy meal
        return getPresetResult("caesar_salad")
    }

    private fun analyzeBitmap(bitmap: Bitmap): FoodAnalysisResult {
        // Sample pixels to determine color profile (e.g., greens for salads, reds/browns for meat/pizza)
        var totalRed = 0L
        var totalGreen = 0L
        var totalBlue = 0L
        var sampledPixels = 0

        val stepX = (bitmap.width / 16).coerceAtLeast(1)
        val stepY = (bitmap.height / 16).coerceAtLeast(1)

        for (x in 0 until bitmap.width step stepX) {
            for (y in 0 until bitmap.height step stepY) {
                val pixel = bitmap.getPixel(x, y)
                totalRed += Color.red(pixel)
                totalGreen += Color.green(pixel)
                totalBlue += Color.blue(pixel)
                sampledPixels++
            }
        }

        val avgR = if (sampledPixels > 0) totalRed / sampledPixels else 128
        val avgG = if (sampledPixels > 0) totalGreen / sampledPixels else 128
        val avgB = if (sampledPixels > 0) totalBlue / sampledPixels else 128

        // Heuristic classification based on color balance
        return when {
            avgG > avgR * 1.15 && avgG > avgB * 1.15 -> {
                // Dominant green -> Healthy salad / vegetable dish
                FoodAnalysisResult(
                    dishName = "سالاد سبزیجات و کلم بروکلی",
                    englishName = "Fresh Garden Vegetable Salad",
                    calories = 240,
                    servingSize = "۱ کاسه متوسط (۲۵۰ گرم)",
                    proteinGrams = 8.5f,
                    carbsGrams = 22f,
                    fatGrams = 12f,
                    fiberGrams = 6.5f,
                    healthScore = 95,
                    burnOffMinsWalking = 40,
                    burnOffMinsRunning = 18,
                    burnOffMinsCycling = 22,
                    advice = "عالی برای رژیم لاغری و سلامت روده! سرشار از فیبر و ویتامین C بدون قند افزودنی.",
                    ingredients = listOf(
                        IngredientDetail("بروکلی و کاهو تازه", "۱۵۰ گرم", 45),
                        IngredientDetail("روغن زیتون فرابکر و لیمو", "۱ قاشق غذاخوری", 120),
                        IngredientDetail("دانه چیا و آفتابگردان", "۱۵ گرم", 75)
                    ),
                    isAiLive = false
                )
            }
            avgR > avgG * 1.25 && avgR > avgB * 1.25 -> {
                // Dominant red/orange -> Pasta with tomato / Grilled Meat / Pizza
                FoodAnalysisResult(
                    dishName = "پاستا با سس گوجه و گوشت",
                    englishName = "Bolognese Pasta & Meat Sauce",
                    calories = 540,
                    servingSize = "۱ بشقاب متوسط (۳۰۰ گرم)",
                    proteinGrams = 24f,
                    carbsGrams = 68f,
                    fatGrams = 18f,
                    fiberGrams = 4f,
                    healthScore = 78,
                    burnOffMinsWalking = 85,
                    burnOffMinsRunning = 38,
                    burnOffMinsCycling = 48,
                    advice = "منبع بسیار خوبی برای تامین انرژی و کربوهیدرات، مناسب قبل از تمرینات ورزشی سنگین.",
                    ingredients = listOf(
                        IngredientDetail("پاستا پخته شده", "۱۸۰ گرم", 280),
                        IngredientDetail("گوشت چرخ‌کرده کم‌چرب", "۸۰ گرم", 160),
                        IngredientDetail("سس گوجه و پیاز تفت داده", "۵۰ گرم", 100)
                    ),
                    isAiLive = false
                )
            }
            avgR > 140 && avgG > 120 && avgB < 100 -> {
                // Yellow/Golden -> Rice dish / Chelo Kabab / Roasted Chicken
                FoodAnalysisResult(
                    dishName = "چلو مرغ زعفرانی با برنج کته",
                    englishName = "Persian Saffron Rice with Roast Chicken",
                    calories = 610,
                    servingSize = "۱ دیس یک‌نفره (۳۲۰ گرم)",
                    proteinGrams = 38f,
                    carbsGrams = 72f,
                    fatGrams = 16f,
                    fiberGrams = 2.5f,
                    healthScore = 82,
                    burnOffMinsWalking = 95,
                    burnOffMinsRunning = 42,
                    burnOffMinsCycling = 54,
                    advice = "حاوی ۳۸ گرم پروتئین عالی برای حفظ عضلات. در صورت تمایل به کاهش وزن مصرف کره را کمتر کنید.",
                    ingredients = listOf(
                        IngredientDetail("برنج سفید زعفرانی", "۱۵۰ گرم", 240),
                        IngredientDetail("سینه مرغ گریل شده", "۱۴۰ گرم", 230),
                        IngredientDetail("کره و زعفران معطر", "۱۵ گرم", 140)
                    ),
                    isAiLive = false
                )
            }
            else -> {
                // Balanced / Mixed dish
                FoodAnalysisResult(
                    dishName = "ساندویچ مرغ و سبزیجات پروتئینی",
                    englishName = "Grilled Chicken & Veggie Sandwich",
                    calories = 460,
                    servingSize = "۱ ساندویچ کامل (۲۲۰ گرم)",
                    proteinGrams = 32f,
                    carbsGrams = 45f,
                    fatGrams = 14f,
                    fiberGrams = 4.8f,
                    healthScore = 88,
                    burnOffMinsWalking = 72,
                    burnOffMinsRunning = 32,
                    burnOffMinsCycling = 40,
                    advice = "تعادل مناسب بین پروتئین و کربوهیدرات برای احساس سیری پایدار در طول روز.",
                    ingredients = listOf(
                        IngredientDetail("نان سبوس‌دار چند غله", "۸۰ گرم", 180),
                        IngredientDetail("فیله مرغ پخته", "۱۰۰ گرم", 165),
                        IngredientDetail("گوجه، خیارشور و کاهو", "۴۰ گرم", 25),
                        IngredientDetail("سس ماست خردل لایت", "۲۰ گرم", 90)
                    ),
                    isAiLive = false
                )
            }
        }
    }

    private fun getPresetResult(presetId: String): FoodAnalysisResult = when (presetId) {
        "zereshk_polo" -> FoodAnalysisResult(
            dishName = "زرشک‌پلو با مرغ مجلسی",
            englishName = "Zereshk Polo Morgh (Barberry Rice & Chicken)",
            calories = 620,
            servingSize = "۱ بشقاب کامل (۳۸۰ گرم)",
            proteinGrams = 39f,
            carbsGrams = 78f,
            fatGrams = 18f,
            fiberGrams = 3.2f,
            healthScore = 81,
            burnOffMinsWalking = 98,
            burnOffMinsRunning = 44,
            burnOffMinsCycling = 55,
            advice = "غذای بسیار مقوی و غنی از پروتئین و آنتی‌اکسیدان زرشک. برای رژیم لاغری می‌توان روغن پلو را کاهش داد.",
            ingredients = listOf(
                IngredientDetail("برنج باسماتی پخته", "۱۸۰ گرم", 290),
                IngredientDetail("ران مرغ پخته بدون پوست", "۱۵۰ گرم", 220),
                IngredientDetail("زرشک تفت داده شده با شکر", "۳۰ گرم", 110)
            ),
            isAiLive = false
        )
        "ghormeh_sabzi" -> FoodAnalysisResult(
            dishName = "خورشت قورمه‌سبزی با کته",
            englishName = "Ghormeh Sabzi with Persian Rice",
            calories = 580,
            servingSize = "۱ بشقاب خورشت و برنج (۳۵۰ گرم)",
            proteinGrams = 32f,
            carbsGrams = 64f,
            fatGrams = 22f,
            fiberGrams = 7.5f,
            healthScore = 84,
            burnOffMinsWalking = 90,
            burnOffMinsRunning = 40,
            burnOffMinsCycling = 50,
            advice = "سرشار از فیبر و آهن به دلیل سبزیجات معطر و لوبیا قرمز. چربی خورشت را با کنترل روغن به حداقل برسانید.",
            ingredients = listOf(
                IngredientDetail("خورشت قورمه سبزی با گوشت", "۱۸۰ گرم", 320),
                IngredientDetail("برنج سفید کته", "۱۵۰ گرم", 240),
                IngredientDetail("لوبیا قرمز پخته", "۳۰ گرم", 20)
            ),
            isAiLive = false
        )
        "caesar_salad" -> FoodAnalysisResult(
            dishName = "سالاد سزار با فیله مرغ گریل",
            englishName = "Grilled Chicken Caesar Salad",
            calories = 340,
            servingSize = "۱ ظرف بزرگ (۲۸۰ گرم)",
            proteinGrams = 28f,
            carbsGrams = 16f,
            fatGrams = 17f,
            fiberGrams = 3.8f,
            healthScore = 91,
            burnOffMinsWalking = 54,
            burnOffMinsRunning = 24,
            burnOffMinsCycling = 30,
            advice = "گزینه عالی برای وعده شام یا رژیم کم کربوهیدرات (Low-Carb). بخش عمده کالری مربوط به سس سزار است.",
            ingredients = listOf(
                IngredientDetail("کاهو پیچ تازه", "۱۵۰ گرم", 25),
                IngredientDetail("فیله سینه مرغ گریل شده", "۱۲۰ گرم", 160),
                IngredientDetail("سس سزار و پنیر پارمسان", "۳۰ گرم", 130),
                IngredientDetail("نان تست سیردار (کروتان)", "۲۰ گرم", 25)
            ),
            isAiLive = false
        )
        "koobideh" -> FoodAnalysisResult(
            dishName = "چلو کباب کوبیده سنتی",
            englishName = "Chelo Kabab Koobideh",
            calories = 780,
            servingSize = "۲ سیخ کوبیده با برنج و کره (۴۰۰ گرم)",
            proteinGrams = 42f,
            carbsGrams = 80f,
            fatGrams = 32f,
            fiberGrams = 2.1f,
            healthScore = 68,
            burnOffMinsWalking = 120,
            burnOffMinsRunning = 55,
            burnOffMinsCycling = 68,
            advice = "پروتئین بسیار بالا و طعم دلپذیر، اما چربی اشباع نسبتاً بالایی دارد. گوجه و سبزی خوردن تازه همراه آن مصرف شود.",
            ingredients = listOf(
                IngredientDetail("کباب کوبیده گوشت گوسفند و گوساله", "۱۸۰ گرم", 440),
                IngredientDetail("چلو سفید معطر", "۱۸۰ گرم", 280),
                IngredientDetail("گوجه فرنگی کبابی و کره", "۴۰ گرم", 60)
            ),
            isAiLive = false
        )
        "pizza" -> FoodAnalysisResult(
            dishName = "پیتزا مخصوص دست‌ساز تنوری",
            englishName = "Supreme Crispy Pizza",
            calories = 690,
            servingSize = "۳ برش متوسط (۲۶۰ گرم)",
            proteinGrams = 26f,
            carbsGrams = 72f,
            fatGrams = 31f,
            fiberGrams = 3.6f,
            healthScore = 65,
            burnOffMinsWalking = 110,
            burnOffMinsRunning = 48,
            burnOffMinsCycling = 60,
            advice = "غذایی پرکالری و پرانرژی. برای تعادل بیشتر بهتر است در کنار آن سالاد سبز بدون سس مصرف کنید.",
            ingredients = listOf(
                IngredientDetail("خمیر پیتزا و سس مارینارا", "۱۲۰ گرم", 310),
                IngredientDetail("پنیر موزارلا مرغوب", "۸۰ گرم", 240),
                IngredientDetail("تاپینگ قارچ، فلفل دلمه و زیتون", "۶۰ گرم", 140)
            ),
            isAiLive = false
        )
        "healthy_breakfast" -> FoodAnalysisResult(
            dishName = "املت گوجه‌فرنگی و نان سنگک",
            englishName = "Persian Tomato Omelet & Flatbread",
            calories = 380,
            servingSize = "۱ بشقاب املت با ۱ کف دست نان (۲۵۰ گرم)",
            proteinGrams = 19f,
            carbsGrams = 36f,
            fatGrams = 18f,
            fiberGrams = 4.2f,
            healthScore = 89,
            burnOffMinsWalking = 60,
            burnOffMinsRunning = 27,
            burnOffMinsCycling = 34,
            advice = "شروع ایده‌آل روز با کولین و پروتئین تخم‌مرغ و لیکوپن گوجه فرنگی، موجب تمرکز ذهنی بالا در طول روز می‌شود.",
            ingredients = listOf(
                IngredientDetail("۲ عدد تخم‌مرغ کامل", "۱۰۰ گرم", 140),
                IngredientDetail("گوجه فرنگی رنده شده و روغن زیتون", "۱۰۰ گرم", 110),
                IngredientDetail("نان سبوس‌دار سنگک", "۵۰ گرم", 130)
            ),
            isAiLive = false
        )
        "pasta_alfredo" -> FoodAnalysisResult(
            dishName = "پاستا پنه با سس آلفردو و مرغ",
            englishName = "Penne Chicken Alfredo",
            calories = 650,
            servingSize = "۱ کاسه پاستا (۳۰۰ گرم)",
            proteinGrams = 34f,
            carbsGrams = 68f,
            fatGrams = 26f,
            fiberGrams = 3.2f,
            healthScore = 74,
            burnOffMinsWalking = 100,
            burnOffMinsRunning = 45,
            burnOffMinsCycling = 58,
            advice = "غذایی غنی از کربوهیدرات و پروتئین شیری. برای افراد در دوره حجم عضلانی فوق‌العاده است.",
            ingredients = listOf(
                IngredientDetail("پاستا پنه", "۱۶۰ گرم", 260),
                IngredientDetail("فیله مرغ و قارچ", "۱۰۰ گرم", 160),
                IngredientDetail("سس خامه و پنیر پارمسان", "۶۰ گرم", 230)
            ),
            isAiLive = false
        )
        "fruit_bowl" -> FoodAnalysisResult(
            dishName = "کاسه میوه و اوتمیل جو دوسر",
            englishName = "Berry Oatmeal & Fruit Energy Bowl",
            calories = 290,
            servingSize = "۱ کاسه متوسط (۲۴۰ گرم)",
            proteinGrams = 9f,
            carbsGrams = 54f,
            fatGrams = 4.5f,
            fiberGrams = 7.8f,
            healthScore = 97,
            burnOffMinsWalking = 46,
            burnOffMinsRunning = 20,
            burnOffMinsCycling = 25,
            advice = "امتیاز سلامت ۹۷! سرشار از بتاگلوکان، کاهنده کلسترول بد و بسیار سبک و پر انرژی.",
            ingredients = listOf(
                IngredientDetail("جو دوسر پرک پخته", "۱۰۰ گرم", 130),
                IngredientDetail("موز حلقه شده و توت‌فرنگی", "۱۰۰ گرم", 95),
                IngredientDetail("عسل طبیعی و دارچین", "۱۵ گرم", 65)
            ),
            isAiLive = false
        )
        else -> FoodAnalysisResult(
            dishName = "وعده غذایی سالم مخلوط",
            englishName = "Nutritious Mixed Meal",
            calories = 450,
            servingSize = "۱ وعده متوسط (۳۰۰ گرم)",
            proteinGrams = 25f,
            carbsGrams = 50f,
            fatGrams = 15f,
            fiberGrams = 5f,
            healthScore = 85,
            burnOffMinsWalking = 70,
            burnOffMinsRunning = 31,
            burnOffMinsCycling = 40,
            advice = "تعادل مناسب در ریزمغذی‌ها و درشت‌مغذی‌ها.",
            ingredients = listOf(
                IngredientDetail("پروتئین حیوانی/گیاهی", "۱۰۰ گرم", 180),
                IngredientDetail("کربوهیدرات کامل", "۱۰۰ گرم", 160),
                IngredientDetail("سبزیجات تازه", "۱۰۰ گرم", 110)
            ),
            isAiLive = false
        )
    }

    override fun getMealsForDate(dateString: String): Flow<List<MealEntity>> {
        return mealDao.getMealsForDate(dateString)
    }

    override fun getTotalCaloriesForDate(dateString: String): Flow<Int?> {
        return mealDao.getTotalCaloriesForDate(dateString)
    }

    override suspend fun saveMeal(meal: MealEntity): Long {
        return mealDao.insertMeal(meal)
    }

    override suspend fun deleteMeal(meal: MealEntity) {
        mealDao.deleteMeal(meal)
    }
}
