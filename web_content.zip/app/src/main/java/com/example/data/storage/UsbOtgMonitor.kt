package com.example.data.storage

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.storage.StorageManager
import com.example.data.model.FileSystemType
import com.example.data.model.StorageRootType
import com.example.data.model.StorageVolumeInfo
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Inspects real connected USB OTG mass-storage hardware and removable SD/USB volumes
 * via Android's UsbManager and StorageManager APIs.
 */
class UsbOtgMonitor(private val context: Context) {

    private val ejectedDeviceIds = mutableSetOf<String>()

    fun observeUsbEvents(): Flow<Unit> = callbackFlow {
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(Intent.ACTION_MEDIA_MOUNTED)
            addAction(Intent.ACTION_MEDIA_UNMOUNTED)
            addAction(Intent.ACTION_MEDIA_EJECT)
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) {
                    ejectedDeviceIds.clear()
                }
                trySend(Unit)
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        trySend(Unit)
        awaitClose {
            runCatching { context.unregisterReceiver(receiver) }
        }
    }

    fun getConnectedUsbAndRemovableVolumes(): List<StorageVolumeInfo> {
        val results = mutableListOf<StorageVolumeInfo>()
        val storageManager = context.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
        val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager

        // 1. Check mounted removable StorageVolumes (SD cards & mounted USB OTG drives)
        val removableVolumes = storageManager?.storageVolumes?.filter { it.isRemovable } ?: emptyList()
        for (vol in removableVolumes) {
            val volId = vol.uuid ?: vol.getDescription(context)
            if (volId in ejectedDeviceIds) continue

            val dir = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) vol.directory else null
            val total = dir?.totalSpace ?: 0L
            val free = dir?.usableSpace ?: 0L
            val used = (total - free).coerceAtLeast(0L)
            val state = vol.state

            val fsType = inferVolumeFileSystem(vol.getDescription(context), state)
            val isUnsupported = state == "unmountable" || state == "nofs"
            val path = if (dir != null && dir.canRead()) {
                "file://${dir.absolutePath}"
            } else {
                "usb://$volId"
            }

            results.add(
                StorageVolumeInfo(
                    id = "vol_$volId",
                    title = vol.getDescription(context).ifBlank { "External USB / SD" },
                    subtitle = if (isUnsupported) "Unsupported or unformatted drive" else "Removable storage ($state)",
                    rootPath = path,
                    type = StorageRootType.USB_OTG,
                    usedBytes = used,
                    totalBytes = total,
                    fileSystemType = if (isUnsupported) FileSystemType.UNSUPPORTED else fsType,
                    isReadOnly = fsType.isReadOnlyOnAndroid || (dir != null && !dir.canWrite()),
                    isEjectable = true,
                    isUnsupportedFormat = isUnsupported,
                    unsupportedExplanation = if (isUnsupported) {
                        "Unsupported filesystem: Android cannot mount raw NTFS/ext4/APFS partitions natively without read-only driver translation or reformatting to exFAT/FAT32."
                    } else null
                )
            )
        }

        // 2. Check physical USB Mass Storage OTG hardware via UsbManager if not yet mounted as a StorageVolume
        val deviceList: Collection<UsbDevice> = usbManager?.deviceList?.values ?: emptyList()
        for (device in deviceList) {
            val devKey = "usb_hw_${device.deviceId}"
            if (devKey in ejectedDeviceIds) continue
            val isMassStorage = (0 until device.interfaceCount).any { idx ->
                device.getInterface(idx).interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE
            }
            if (isMassStorage && results.none { it.title.contains(device.productName ?: "", ignoreCase = true) }) {
                val hasPermission = usbManager?.hasPermission(device) == true
                val label = device.productName?.takeIf { it.isNotBlank() }
                    ?: device.manufacturerName?.takeIf { it.isNotBlank() }
                    ?: "USB OTG Drive (${device.vendorId}:${device.productId})"

                results.add(
                    StorageVolumeInfo(
                        id = devKey,
                        title = label,
                        subtitle = if (hasPermission) "Connected via USB OTG — Select folder via SAF to browse" else "USB OTG detected — Tap to grant folder access",
                        rootPath = "usb://$devKey",
                        type = StorageRootType.USB_OTG,
                        usedBytes = 0L,
                        totalBytes = 0L,
                        fileSystemType = FileSystemType.EXFAT,
                        isReadOnly = false,
                        isEjectable = true,
                        isUnsupportedFormat = false
                    )
                )
            }
        }

        return results
    }

    fun safeEject(volumeId: String) {
        ejectedDeviceIds.add(volumeId.removePrefix("vol_"))
        ejectedDeviceIds.add(volumeId)
    }

    private fun inferVolumeFileSystem(description: String, state: String): FileSystemType {
        val lower = description.lowercase()
        return when {
            state == "nofs" || state == "unmountable" -> FileSystemType.UNSUPPORTED
            "ntfs" in lower -> FileSystemType.NTFS
            "ext4" in lower -> FileSystemType.EXT4
            "ext3" in lower -> FileSystemType.EXT3
            "ext2" in lower -> FileSystemType.EXT2
            "exfat" in lower -> FileSystemType.EXFAT
            "fat32" in lower -> FileSystemType.FAT32
            "fat" in lower -> FileSystemType.FAT
            else -> FileSystemType.EXFAT
        }
    }
}
