package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ArkFeedIds
import com.example.data.model.DirectConversation
import com.example.data.model.DirectMessage
import com.example.data.model.FollowEdge
import com.example.data.model.FriendEdge
import com.example.data.model.MediaChunk
import com.example.data.model.UserProfile
import com.example.util.ImageCompressionHelper
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.io.File

class DirectMessageRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before using Direct Messages.")

    fun observeConversations(userId: String): Flow<List<DirectConversation>> = flow {
        val path = "conversations"
        emitAll(
            db.collection("conversations")
                .whereArrayContains("participantUids", userId)
                .limit(50)
                .snapshots()
                .map { snap ->
                    snap.toObjects(DirectConversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .filter { it.status != "declined" || it.requesterUid == userId }
                        .sortedByDescending { it.lastMessageAt?.seconds ?: it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observeMessages(conversationId: String): Flow<List<DirectMessage>> = flow {
        val path = "conversations/$conversationId/messages"
        emitAll(
            db.collection("conversations").document(conversationId).collection("messages")
                .limit(100)
                .snapshots()
                .map { snap ->
                    snap.toObjects(DirectMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
                }
                .catch { error ->
                    val fe = error.unwrapFirestoreException()
                    if (fe == null && error is CancellationException) throw error
                    val ex = fe ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) handleFirestoreError(ex, OperationType.LIST, path)
                    throw error
                }
        )
    }

    suspend fun openOrStartConversation(
        currentUser: UserProfile,
        targetUser: UserProfile,
        myFollowing: List<FollowEdge>,
        myFriends: List<FriendEdge>,
        isBlocked: Boolean
    ): Result<DirectConversation> = runCatching {
        val uid = requireUserId()
        require(uid == currentUser.userId)
        require(targetUser.userId != uid) { "Cannot message yourself." }
        require(!isBlocked) { "Unblock @${targetUser.username} before sending a message." }
        require(targetUser.allowMessagesFrom != "nobody") { "@${targetUser.username} has turned off direct messages." }

        val convId = ArkFeedIds.conversationIdFor(uid, targetUser.userId)
        val convRef = db.collection("conversations").document(convId)
        val existingSnap = convRef.get().await()
        if (existingSnap.exists()) {
            val existing = existingSnap.toObject(DirectConversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            if (existing != null) return@runCatching existing
        }

        val isFriend = myFriends.any { it.friendUid == targetUser.userId }
        val isFollowing = myFollowing.any { it.peerUid == targetUser.userId }
        if (targetUser.allowMessagesFrom == "friends" && !isFriend) {
            throw IllegalStateException("@${targetUser.username} only accepts messages from friends.")
        }

        val initialStatus = if (isFriend || (!targetUser.isPrivateAccount && isFollowing && targetUser.allowMessagesFrom == "everyone")) {
            "active"
        } else {
            "request"
        }

        val participants = listOf(uid, targetUser.userId).sorted()
        val namesMap = mapOf(
            uid to currentUser.username.take(30).ifBlank { "player" },
            targetUser.userId to targetUser.username.take(30).ifBlank { "player" }
        )
        val avatarsMap = mapOf(
            uid to currentUser.avatarPreset.take(40).ifBlank { "prism_cyan" },
            targetUser.userId to targetUser.avatarPreset.take(40).ifBlank { "prism_cyan" }
        )
        val payload = hashMapOf<String, Any>(
            "participantUids" to participants,
            "participantNames" to namesMap,
            "participantAvatars" to avatarsMap,
            "status" to initialStatus,
            "requesterUid" to uid,
            "lastMessageText" to "",
            "lastSenderUid" to "",
            "unreadCounts" to mapOf(uid to 0L, targetUser.userId to 0L),
            "typingUids" to emptyMap<String, Long>(),
            "readAtMillis" to mapOf(uid to System.currentTimeMillis()),
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        try {
            convRef.set(payload).await()
            val createdSnap = convRef.get().await()
            createdSnap.toObject(DirectConversation::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: DirectConversation(
                    id = convId,
                    participantUids = participants,
                    participantNames = namesMap,
                    participantAvatars = avatarsMap,
                    status = initialStatus,
                    requesterUid = uid
                )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, convRef.path)
            throw e
        }
    }

    suspend fun sendDirectMessage(
        conversation: DirectConversation,
        sender: UserProfile,
        text: String,
        imageBase64: String? = null,
        videoThumbnailBase64: String? = null,
        videoDurationMs: Long = 0L,
        videoChunksBase64: List<String> = emptyList(),
        replyToId: String? = null,
        replyToPreview: String? = null
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(uid == sender.userId)
        require(conversation.participantUids.contains(uid))
        require(!sender.isRestricted) { "Restricted accounts cannot send messages." }
        val cleanChunks = videoChunksBase64.filter { it.isNotBlank() && it.length <= 700_000 }.take(16)
        val cleanText = text.trim().take(1000)
        require(cleanText.isNotBlank() || !imageBase64.isNullOrBlank() || cleanChunks.isNotEmpty()) {
            "Message cannot be empty."
        }

        val otherUid = conversation.participantUids.firstOrNull { it != uid } ?: uid
        val convRef = db.collection("conversations").document(conversation.id)
        val msgId = ArkFeedIds.newForwardDocId("dm")
        val msgRef = convRef.collection("messages").document(msgId)

        val msgPayload = hashMapOf<String, Any>(
            "conversationId" to conversation.id,
            "participantUids" to conversation.participantUids,
            "senderId" to uid,
            "senderUsername" to sender.username.take(30).ifBlank { "player" },
            "text" to cleanText,
            "videoDurationMs" to videoDurationMs.coerceIn(0L, 45_000L),
            "videoChunkCount" to cleanChunks.size.toLong(),
            "reactions" to emptyMap<String, String>(),
            "isDeleted" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!imageBase64.isNullOrBlank()) msgPayload["imageBase64"] = imageBase64.take(80_000)
        if (!videoThumbnailBase64.isNullOrBlank()) msgPayload["videoThumbnailBase64"] = videoThumbnailBase64.take(90_000)
        if (!replyToId.isNullOrBlank()) msgPayload["replyToId"] = replyToId.take(128)
        if (!replyToPreview.isNullOrBlank()) msgPayload["replyToPreview"] = replyToPreview.take(120)

        val preview = when {
            cleanText.isNotBlank() -> cleanText.take(180)
            cleanChunks.isNotEmpty() -> "Sent a video"
            !imageBase64.isNullOrBlank() -> "Sent a photo"
            else -> "Sent a message"
        }

        try {
            val convSnap = convRef.get().await()
            val rawUnread = convSnap.get("unreadCounts") as? Map<*, *>
            val nextUnread = mutableMapOf<String, Long>()
            rawUnread?.forEach { (k, v) -> if (k is String && v is Number) nextUnread[k] = v.toLong().coerceAtLeast(0L) }
            nextUnread[uid] = 0L
            nextUnread[otherUid] = (nextUnread[otherUid] ?: 0L) + 1L

            val rawTyping = (convSnap.get("typingUids") as? Map<*, *>)?.entries
                ?.mapNotNull { (k, v) -> if (k is String && v is Number && k != uid) k to v.toLong() else null }
                ?.toMap() ?: emptyMap()

            val firstChunks = cleanChunks.take(9)
            val restChunks = if (cleanChunks.size > 9) cleanChunks.drop(9) else emptyList()
            val batch = db.batch()
            batch.set(msgRef, msgPayload)
            firstChunks.forEachIndexed { idx, chunk ->
                batch.set(
                    msgRef.collection("media").document("chunk_$idx"),
                    mapOf(
                        "index" to idx.toLong(),
                        "dataBase64" to chunk,
                        "authorId" to uid,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.update(
                convRef,
                mapOf(
                    "lastMessageText" to preview,
                    "lastSenderUid" to uid,
                    "lastMessageAt" to FieldValue.serverTimestamp(),
                    "unreadCounts" to nextUnread,
                    "typingUids" to rawTyping,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            if (restChunks.isNotEmpty()) {
                val batch2 = db.batch()
                restChunks.forEachIndexed { relIdx, chunk ->
                    val idx = relIdx + 9
                    batch2.set(
                        msgRef.collection("media").document("chunk_$idx"),
                        mapOf(
                            "index" to idx.toLong(),
                            "dataBase64" to chunk,
                            "authorId" to uid,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
                batch2.commit().await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, msgRef.path)
            throw e
        }
    }

    suspend fun acceptMessageRequest(conversationId: String): Result<Unit> = runCatching {
        requireUserId()
        db.collection("conversations").document(conversationId)
            .update(mapOf("status" to "active", "updatedAt" to FieldValue.serverTimestamp()))
            .await()
    }

    suspend fun declineMessageRequest(conversationId: String): Result<Unit> = runCatching {
        requireUserId()
        db.collection("conversations").document(conversationId)
            .update(mapOf("status" to "declined", "updatedAt" to FieldValue.serverTimestamp()))
            .await()
    }

    suspend fun markConversationRead(conversationId: String, userId: String) {
        val uid = auth.currentUser?.uid ?: return
        if (uid != userId) return
        runCatching {
            val convRef = db.collection("conversations").document(conversationId)
            db.runTransaction { tx ->
                val snap = tx.get(convRef)
                if (!snap.exists()) return@runTransaction
                val rawUnread = snap.get("unreadCounts") as? Map<*, *>
                val nextUnread = mutableMapOf<String, Long>()
                rawUnread?.forEach { (k, v) -> if (k is String && v is Number) nextUnread[k] = v.toLong().coerceAtLeast(0L) }
                nextUnread[uid] = 0L

                val rawRead = snap.get("readAtMillis") as? Map<*, *>
                val nextRead = mutableMapOf<String, Long>()
                rawRead?.forEach { (k, v) -> if (k is String && v is Number) nextRead[k] = v.toLong() }
                nextRead[uid] = System.currentTimeMillis()

                tx.update(
                    convRef,
                    mapOf(
                        "unreadCounts" to nextUnread,
                        "readAtMillis" to nextRead,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
        }
    }

    suspend fun setTyping(conversationId: String, isTyping: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        runCatching {
            val convRef = db.collection("conversations").document(conversationId)
            db.runTransaction { tx ->
                val snap = tx.get(convRef)
                if (!snap.exists()) return@runTransaction
                val rawTyping = snap.get("typingUids") as? Map<*, *>
                val nextTyping = mutableMapOf<String, Long>()
                rawTyping?.forEach { (k, v) -> if (k is String && v is Number) nextTyping[k] = v.toLong() }
                if (isTyping) {
                    nextTyping[uid] = System.currentTimeMillis()
                } else {
                    nextTyping.remove(uid)
                }
                tx.update(
                    convRef,
                    mapOf(
                        "typingUids" to nextTyping,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
        }
    }

    suspend fun reactToDirectMessage(conversationId: String, messageId: String, emoji: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val msgRef = db.collection("conversations").document(conversationId).collection("messages").document(messageId)
        db.runTransaction { tx ->
            val snap = tx.get(msgRef)
            val raw = snap.get("reactions") as? Map<*, *>
            val next = mutableMapOf<String, String>()
            raw?.forEach { (k, v) -> if (k is String && v is String) next[k] = v }
            if (next[uid] == emoji) {
                next.remove(uid)
            } else {
                next[uid] = emoji.take(8)
            }
            tx.update(msgRef, mapOf("reactions" to next, "updatedAt" to FieldValue.serverTimestamp()))
        }.await()
    }

    suspend fun deleteDirectMessage(conversationId: String, messageId: String): Result<Unit> = runCatching {
        requireUserId()
        val msgRef = db.collection("conversations").document(conversationId).collection("messages").document(messageId)
        msgRef.update(
            mapOf(
                "isDeleted" to true,
                "text" to "Message unsent",
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun fetchMessageVideoFile(context: Context, conversationId: String, messageId: String): File? = runCatching {
        val snap = db.collection("conversations").document(conversationId)
            .collection("messages").document(messageId)
            .collection("media").get().await()
        val chunks = snap.toObjects(MediaChunk::class.java)
        ImageCompressionHelper.reconstructVideoToCache(context, "dm_${conversationId}_${messageId}", chunks)
    }.getOrNull()
}
