package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val displayName: String = "Style Enthusiast",
    val userGender: String = "MALE",
    val preferredLanguage: String = "Auto Local",
    val heightCm: Long = 172L,
    val weightKg: Long = 68L,
    val preferredTopSize: String = "M",
    val preferredBottomSize: String = "32",
    val bodyFitPreference: String = "Tailored Fit",
    val preferredStyle: String = "Luxury Minimalist",
    val preferredOccasion: String = "Casual",
    val preferredColors: String = "Obsidian Black, Ivory White, Charcoal",
    val budgetMaxInr: Long = 5000L,
    val preferredRetailers: String = "Myntra, AJIO, Amazon, Flipkart",
    val membershipTier: String = "FREE",
    val tryOnCountUsed: Long = 0L,
    val recommendationsUsed: Long = 0L,
    val photoConsentGranted: Boolean = false,
    val hasUploadedPhoto: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class SalesAssistantPersona(
    val assistantName: String,
    val assistantGender: String, // "FEMALE" for Male user, "MALE" for Female user
    val roleTitle: String,
    val badgeTagline: String,
    val userHonorific: String
)

@IgnoreExtraProperties
data class SavedOutfit(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val category: String = "",
    val occasion: String = "",
    val brand: String = "",
    val color: String = "",
    val priceInr: Long = 0L,
    val imageUrl: String = "",
    val productUrl: String = "",
    val retailer: String = "",
    val stylistNote: String = "",
    val matchingShoes: String = "",
    val matchingAccessories: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class WishlistItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val productId: String = "",
    val title: String = "",
    val brand: String = "",
    val category: String = "",
    val occasion: String = "",
    val selectedColor: String = "",
    val selectedSize: String = "M",
    val priceInr: Long = 0L,
    val originalPriceInr: Long = 0L,
    val imageUrl: String = "",
    val productUrl: String = "",
    val retailer: String = "",
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TryOnSession(
    @DocumentId val id: String = "",
    val userId: String = "",
    val outfitId: String = "",
    val outfitTitle: String = "",
    val outfitCategory: String = "",
    val selectedColor: String = "",
    val selectedSize: String = "M",
    val aiFitNotes: String = "",
    val localPreviewFilename: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class RecentlyViewedProduct(
    @DocumentId val id: String = "",
    val userId: String = "",
    val productId: String = "",
    val productName: String = "",
    val brand: String = "",
    val category: String = "",
    val priceInr: Long = 0L,
    val imageUrl: String = "",
    val retailer: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class RetailerOffer(
    val platformName: String,
    val listedPriceInr: Int?,
    val originalPriceInr: Int?,
    val discountPercent: Int?,
    val availableOffers: String,
    val shippingInfo: String,
    val inStock: Boolean,
    val directProductUrl: String,
    val isExactMatch: Boolean,
    val isLiveFeedVerified: Boolean = true,
    val statusLabel: String = "Verified Authorized Feed"
)

data class FashionProduct(
    val id: String,
    val name: String,
    val brand: String,
    val category: String,
    val occasion: String,
    val color: String,
    val availableColors: List<String>,
    val availableSizes: List<String>,
    val priceInr: Int,
    val originalPriceInr: Int,
    val imageUrl: String,
    val description: String,
    val primaryRetailer: String,
    val productUrl: String,
    val matchingShoes: String,
    val matchingAccessories: String,
    val stylistWhyItWorks: String,
    val retailerOffers: List<RetailerOffer>,
    val isOutfitCombo: Boolean = false,
    val isTrending: Boolean = false
)

data class AiOutfitRecommendation(
    val outfitTitle: String,
    val category: String,
    val occasion: String,
    val matchedProductId: String,
    val whyRecommended: String,
    val stylingTips: String,
    val colorPalette: String,
    val estimatedPriceInr: Int,
    val matchingFootwear: String,
    val matchingAccessories: String
)

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val recommendedProducts: List<FashionProduct> = emptyList(),
    val timestampMillis: Long = System.currentTimeMillis()
)
