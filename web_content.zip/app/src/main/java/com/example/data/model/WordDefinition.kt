package com.example.data.model

data class WordDefinition(
    val id: String,
    val number: Int, // 1, 2, 3...
    val word: String,
    val displayWord: String,
    val simpleSynonym: String, // "Palabra que ya conoces / Sinónimo súper fácil"
    val colloquialMeaning: String, // "Explicación coloquial y sin rodeos"
    val contextualExplanation: String, // "Qué significa justo en este PDF/texto"
    val originalSentence: String, // Sentence from the material
    val dailyLifeExample: String, // Everyday relatable example
    val category: String,
    val imageUrl: String,
    val pageNumber: Int,
    var isMemorized: Boolean = false
)
