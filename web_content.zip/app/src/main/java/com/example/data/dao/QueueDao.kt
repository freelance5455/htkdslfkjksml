package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.QueueItemEntity
import com.example.data.model.SongEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface QueueDao {
    @Query("""
        SELECT s.* FROM songs s
        INNER JOIN queue_items q ON s.id = q.songId
        ORDER BY q.sortOrder ASC
    """)
    fun getQueueSongs(): Flow<List<SongEntity>>

    @Query("""
        SELECT s.* FROM songs s
        INNER JOIN queue_items q ON s.id = q.songId
        ORDER BY q.sortOrder ASC
    """)
    suspend fun getQueueSongsOnce(): List<SongEntity>

    @Query("DELETE FROM queue_items")
    suspend fun clearQueue()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQueueItems(items: List<QueueItemEntity>)

    @Transaction
    suspend fun saveQueue(songIdsInOrder: List<Long>) {
        clearQueue()
        val items = songIdsInOrder.mapIndexed { index, id ->
            QueueItemEntity(songId = id, sortOrder = index)
        }
        insertQueueItems(items)
    }
}
