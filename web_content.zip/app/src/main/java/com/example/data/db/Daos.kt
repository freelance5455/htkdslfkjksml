package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface InformationDao {
    @Query("SELECT * FROM information_records ORDER BY transactionNumber DESC")
    fun getAllRecords(): Flow<List<InformationRecord>>

    @Query("SELECT * FROM information_records WHERE id = :id LIMIT 1")
    suspend fun getRecordById(id: Long): InformationRecord?

    @Query("SELECT COALESCE(MAX(transactionNumber), 0) FROM information_records")
    suspend fun getMaxTransactionNumber(): Long

    @Query("SELECT COALESCE(MAX(transactionNumber), 0) FROM information_records")
    fun observeMaxTransactionNumber(): Flow<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: InformationRecord): Long

    @Update
    suspend fun updateRecord(record: InformationRecord)

    @Delete
    suspend fun deleteRecord(record: InformationRecord)

    @Query("DELETE FROM information_records WHERE id = :id")
    suspend fun deleteRecordById(id: Long)
}

@Dao
interface VaultFileDao {
    @Query("SELECT * FROM vault_files WHERE category = :category ORDER BY createdAt DESC")
    fun getFilesByCategory(category: String): Flow<List<VaultFile>>

    @Query("SELECT * FROM vault_files ORDER BY createdAt DESC")
    fun getAllFiles(): Flow<List<VaultFile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFile(file: VaultFile): Long

    @Update
    suspend fun updateFile(file: VaultFile)

    @Delete
    suspend fun deleteFile(file: VaultFile)

    @Query("DELETE FROM vault_files WHERE id = :id")
    suspend fun deleteFileById(id: Long)
}

@Dao
interface PdfDao {
    @Query("SELECT * FROM pdf_documents ORDER BY createdAt DESC")
    fun getAllPdfs(): Flow<List<PdfDocumentRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPdf(pdf: PdfDocumentRecord): Long

    @Delete
    suspend fun deletePdf(pdf: PdfDocumentRecord)

    @Query("DELETE FROM pdf_documents WHERE id = :id")
    suspend fun deletePdfById(id: Long)
}
