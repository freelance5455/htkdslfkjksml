package com.example.data.repository

import com.example.data.dao.PerfumeDao
import com.example.data.dao.VendaDao
import com.example.data.model.Perfume
import com.example.data.model.Venda
import com.example.util.ValidadeNivel
import com.example.util.ValidadeUtil
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class PerfumeRepository(
    private val perfumeDao: PerfumeDao,
    private val vendaDao: VendaDao
) {
    val allPerfumes: Flow<List<Perfume>> = perfumeDao.getAllPerfumes()
    val allVendas: Flow<List<Venda>> = vendaDao.getAllVendas()
    val recentVendas: Flow<List<Venda>> = vendaDao.getRecentVendas(100)
    val totalVendasValor: Flow<Double?> = vendaDao.getTotalVendasValor()
    val totalVendasCount: Flow<Int> = vendaDao.getTotalVendasCount()

    fun searchPerfumes(query: String): Flow<List<Perfume>> {
        return if (query.isBlank()) {
            perfumeDao.getAllPerfumes()
        } else {
            perfumeDao.searchPerfumes(query.trim())
        }
    }

    suspend fun getPerfumeById(id: Long): Perfume? {
        return perfumeDao.getPerfumeById(id)
    }

    suspend fun getLotesByCodigo(codigo: String): List<Perfume> {
        return perfumeDao.getPerfumesByCodigoList(codigo.trim())
    }

    suspend fun savePerfume(perfume: Perfume): Long {
        return perfumeDao.insertPerfume(perfume)
    }

    suspend fun deletePerfume(id: Long) {
        perfumeDao.deleteById(id)
    }

    suspend fun adjustStock(id: Long, delta: Int) {
        val current = perfumeDao.getPerfumeById(id) ?: return
        val newStock = (current.estoque + delta).coerceAtLeast(0)
        perfumeDao.updateEstoque(id, newStock)
    }

    /**
     * Realiza a venda com baixa inteligente por lote e validade (FEFO - Primeiro que vence é o primeiro que sai)
     */
    suspend fun realizarVenda(
        codigo: String,
        quantidade: Int,
        loteIdEspecifico: Long? = null
    ): Result<Venda> {
        val lotesDisponiveis = perfumeDao.getPerfumesByCodigoList(codigo.trim())
        if (lotesDisponiveis.isEmpty()) {
            return Result.failure(Exception("Nenhum produto cadastrado com o código $codigo"))
        }

        // Selecionar o lote específico ou aplicar FEFO (lote mais próximo do vencimento com estoque)
        val loteEscolhido = if (loteIdEspecifico != null) {
            lotesDisponiveis.find { it.id == loteIdEspecifico }
                ?: return Result.failure(Exception("Lote selecionado não foi encontrado"))
        } else {
            // Prioriza lotes não vencidos e com validade mais próxima
            lotesDisponiveis
                .filter { it.estoque > 0 }
                .sortedBy { it.validade }
                .firstOrNull() ?: lotesDisponiveis.first()
        }

        if (loteEscolhido.estoque < quantidade) {
            return Result.failure(
                Exception("Estoque insuficiente no lote (${loteEscolhido.validade})! Disponível: ${loteEscolhido.estoque} un.")
            )
        }

        // Baixa no estoque do lote
        val novoEstoque = loteEscolhido.estoque - quantidade
        perfumeDao.updateEstoque(loteEscolhido.id, novoEstoque)

        val total = loteEscolhido.venda * quantidade
        val custoTotal = loteEscolhido.custo * quantidade
        val lucro = total - custoTotal

        val venda = Venda(
            perfumeId = loteEscolhido.id,
            perfumeNome = loteEscolhido.nome,
            perfumeMarca = loteEscolhido.marca,
            codigo = loteEscolhido.codigo,
            validadeVendida = loteEscolhido.validade,
            quantidade = quantidade,
            precoUnitario = loteEscolhido.venda,
            custoUnitario = loteEscolhido.custo,
            total = total,
            lucro = lucro,
            dataHora = System.currentTimeMillis()
        )

        val vendaId = vendaDao.insertVenda(venda)
        return Result.success(venda.copy(id = vendaId))
    }

    /**
     * Permite editar a venda caso o operador tenha errado a quantidade ou valor,
     * reajustando automaticamente o estoque do lote correspondente.
     */
    suspend fun editarVenda(
        vendaId: Long,
        novaQuantidade: Int,
        novoPrecoUnitario: Double
    ): Result<Venda> {
        val vendaExistente = vendaDao.getVendaById(vendaId)
            ?: return Result.failure(Exception("Venda não encontrada"))

        if (novaQuantidade <= 0) {
            return Result.failure(Exception("Quantidade deve ser maior que zero"))
        }

        val lote = perfumeDao.getPerfumeById(vendaExistente.perfumeId)
            ?: perfumeDao.getPerfumesByCodigoList(vendaExistente.codigo).firstOrNull()

        if (lote != null) {
            val diferencaQtd = novaQuantidade - vendaExistente.quantidade
            if (diferencaQtd > 0) {
                // Aumentou a quantidade vendida -> precisa dar baixa em mais estoque
                if (lote.estoque < diferencaQtd) {
                    return Result.failure(
                        Exception("Estoque insuficiente no lote para aumentar a venda! Restam apenas ${lote.estoque} un.")
                    )
                }
                perfumeDao.updateEstoque(lote.id, lote.estoque - diferencaQtd)
            } else if (diferencaQtd < 0) {
                // Diminuiu a quantidade vendida -> devolve itens ao estoque
                val devolver = kotlin.math.abs(diferencaQtd)
                perfumeDao.updateEstoque(lote.id, lote.estoque + devolver)
            }
        }

        val custoUnit = if (vendaExistente.custoUnitario > 0.0) vendaExistente.custoUnitario else (lote?.custo ?: 0.0)
        val novoTotal = novaQuantidade * novoPrecoUnitario
        val novoLucro = novoTotal - (custoUnit * novaQuantidade)

        val vendaAtualizada = vendaExistente.copy(
            quantidade = novaQuantidade,
            precoUnitario = novoPrecoUnitario,
            custoUnitario = custoUnit,
            total = novoTotal,
            lucro = novoLucro
        )

        vendaDao.updateVenda(vendaAtualizada)
        return Result.success(vendaAtualizada)
    }

    /**
     * Cancela a venda e devolve 100% dos produtos vendidos de volta ao lote.
     */
    suspend fun cancelarVenda(vendaId: Long): Result<Unit> {
        val venda = vendaDao.getVendaById(vendaId)
            ?: return Result.failure(Exception("Venda não encontrada"))

        val lote = perfumeDao.getPerfumeById(venda.perfumeId)
            ?: perfumeDao.getPerfumesByCodigoList(venda.codigo).firstOrNull()

        if (lote != null) {
            // Estorna os produtos de volta ao lote
            perfumeDao.updateEstoque(lote.id, lote.estoque + venda.quantidade)
        }

        vendaDao.deleteVendaById(vendaId)
        return Result.success(Unit)
    }

    suspend fun resetInitialData() {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 15)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val expiringSoonDate = sdf.format(cal.time)

        val initialPerfumes = listOf(
            Perfume(
                codigo = "7891033300508",
                nome = "Floratta Red Desodorante Colônia 75ml",
                marca = "O Boticário",
                custo = 75.0,
                venda = 149.90,
                estoque = 5,
                validade = "2027-05-10",
                numeroLote = "LT-01"
            ),
            Perfume(
                codigo = "7891033300508",
                nome = "Floratta Red Desodorante Colônia 75ml",
                marca = "O Boticário",
                custo = 75.0,
                venda = 149.90,
                estoque = 3,
                validade = "2027-11-20",
                numeroLote = "LT-02"
            ),
            Perfume(
                codigo = "3349666007891",
                nome = "1 Million Eau de Toilette 100ml",
                marca = "Paco Rabanne",
                custo = 320.0,
                venda = 589.00,
                estoque = 2,
                validade = "2026-11-15",
                numeroLote = "LT-PR01"
            ),
            Perfume(
                codigo = "3349666007891",
                nome = "1 Million Eau de Toilette 100ml",
                marca = "Paco Rabanne",
                custo = 320.0,
                venda = 589.00,
                estoque = 4,
                validade = "2027-08-30",
                numeroLote = "LT-PR02"
            ),
            Perfume(
                codigo = "7898523789123",
                nome = "Essencial Exclusivo Deo Parfum 100ml",
                marca = "Natura",
                custo = 90.0,
                venda = 219.00,
                estoque = 1,
                validade = "2024-01-10",
                numeroLote = "LT-NAT-OLD"
            ),
            Perfume(
                codigo = "7898523789123",
                nome = "Essencial Exclusivo Deo Parfum 100ml",
                marca = "Natura",
                custo = 90.0,
                venda = 219.00,
                estoque = 3,
                validade = "2027-03-10",
                numeroLote = "LT-NAT-NEW"
            ),
            Perfume(
                codigo = "7891033001234",
                nome = "Malbec Desodorante Colônia 100ml",
                marca = "O Boticário",
                custo = 110.0,
                venda = 219.90,
                estoque = 2,
                validade = expiringSoonDate,
                numeroLote = "LT-BOT-05"
            )
        )
        perfumeDao.insertAll(initialPerfumes)
    }
}
