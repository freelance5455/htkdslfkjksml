package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.api.ChatInputMessage
import com.example.data.api.GeminiApiClient
import com.example.data.local.AppDao
import com.example.data.local.ChatMessage
import com.example.data.local.ChatSession
import com.example.data.local.PreferencesManager
import com.example.ui.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ChatRepository(
    private val context: Context,
    private val dao: AppDao,
    private val apiClient: GeminiApiClient,
    private val preferencesManager: PreferencesManager
) {

    val allSessions: Flow<List<ChatSession>> = dao.getAllSessions()

    fun getMessagesForSession(sessionId: Long): Flow<List<ChatMessage>> {
        return dao.getMessagesForSession(sessionId)
    }

    suspend fun getOrCreateSession(sessionId: Long?): ChatSession = withContext(Dispatchers.IO) {
        if (sessionId != null && sessionId > 0) {
            val existing = dao.getSessionById(sessionId)
            if (existing != null) return@withContext existing
        }
        val newSession = ChatSession(title = "Yeni Sohbet")
        val id = dao.insertSession(newSession)
        preferencesManager.setActiveSessionId(id)
        dao.getSessionById(id) ?: newSession.copy(id = id)
    }

    suspend fun createNewSession(): ChatSession = withContext(Dispatchers.IO) {
        val session = ChatSession(title = "Yeni Sohbet")
        val id = dao.insertSession(session)
        preferencesManager.setActiveSessionId(id)
        session.copy(id = id)
    }

    suspend fun deleteSession(sessionId: Long) = withContext(Dispatchers.IO) {
        dao.deleteMessagesForSession(sessionId)
        dao.deleteSessionById(sessionId)
    }

    suspend fun deleteAllHistory() = withContext(Dispatchers.IO) {
        dao.deleteAllSessions()
    }

    suspend fun sendMessage(
        sessionId: Long,
        text: String,
        imageUri: Uri? = null,
        fileUri: Uri? = null
    ): Result<ChatMessage> = withContext(Dispatchers.IO) {
        val apiKey = preferencesManager.getEffectiveApiKey()

        // 1. Process attachments
        var imageBase64: String? = null
        var imageMime: String? = null
        var fileName: String? = null
        var fileTextContent: String? = null

        if (imageUri != null) {
            val imgData = FileUtils.uriToBase64(context, imageUri)
            if (imgData != null) {
                imageBase64 = imgData.first
                imageMime = imgData.second
            }
        }

        if (fileUri != null) {
            fileName = FileUtils.getFileName(context, fileUri)
            fileTextContent = FileUtils.readFileContent(context, fileUri)
        }

        // 2. Insert User Message
        val userMessage = ChatMessage(
            sessionId = sessionId,
            role = "user",
            content = text.trim(),
            imageUri = imageUri?.toString(),
            fileName = fileName,
            fileType = fileUri?.let { context.contentResolver.getType(it) }
        )
        dao.insertMessage(userMessage)
        dao.touchSession(sessionId)

        // 3. Build context from recent session messages
        val history = dao.getMessagesList(sessionId)
        val apiMessages = mutableListOf<ChatInputMessage>()

        // Take last 10 messages for conversation context
        val contextWindow = history.takeLast(10)
        for (msg in contextWindow) {
            val isCurrent = (msg.id == userMessage.id)
            apiMessages.add(
                ChatInputMessage(
                    role = msg.role,
                    text = msg.content,
                    imageBase64 = if (isCurrent) imageBase64 else null,
                    imageMimeType = if (isCurrent) imageMime else null,
                    fileTextContent = if (isCurrent) fileTextContent else null,
                    fileName = if (isCurrent) fileName else null
                )
            )
        }

        // 4. Update session title if first exchange
        if (history.size <= 2) {
            val summaryTitle = if (text.isNotBlank()) {
                if (text.length > 28) text.take(28) + "..." else text
            } else if (fileName != null) {
                "Dosya: $fileName"
            } else if (imageUri != null) {
                "Fotoğraf Analizi"
            } else {
                "Sohbet"
            }
            val currentSession = dao.getSessionById(sessionId)
            if (currentSession != null && currentSession.title == "Yeni Sohbet") {
                dao.updateSession(currentSession.copy(title = summaryTitle))
            }
        }

        // 5. Call Gemini API
        val responseResult = apiClient.generateChatResponse(apiMessages, apiKey)

        if (responseResult.isSuccess) {
            val replyText = responseResult.getOrNull() ?: ""
            val assistantMessage = ChatMessage(
                sessionId = sessionId,
                role = "assistant",
                content = replyText,
                isError = false
            )
            val insertedId = dao.insertMessage(assistantMessage)
            dao.touchSession(sessionId)
            Result.success(assistantMessage.copy(id = insertedId))
        } else {
            val errorText = responseResult.exceptionOrNull()?.message
                ?: "Suesa AI ile iletişim kurulurken bir sorun meydana geldi."
            val errorMessage = ChatMessage(
                sessionId = sessionId,
                role = "assistant",
                content = errorText,
                isError = true
            )
            val insertedId = dao.insertMessage(errorMessage)
            dao.touchSession(sessionId)
            Result.failure(Exception(errorText))
        }
    }
}
