package com.example.data.repository

import com.example.data.local.ChatDao
import com.example.data.local.ConversationSessionEntity
import com.example.data.local.toDomain
import com.example.data.local.toEntity
import com.example.data.model.ChatMessage
import com.example.data.model.ConversationSession
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ChatRepository(private val chatDao: ChatDao) {

    val allSessions: Flow<List<ConversationSession>> = chatDao.getAllSessions().map { entities ->
        entities.map { entity ->
            ConversationSession(
                id = entity.id,
                title = entity.title,
                createdAt = entity.createdAt,
                updatedAt = entity.updatedAt,
                messageCount = entity.messageCount,
                lastMessagePreview = entity.lastMessagePreview
            )
        }
    }

    fun getMessagesForSession(sessionId: Long): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForSession(sessionId).map { list ->
            list.map { it.toDomain() }
        }
    }

    suspend fun getMessagesList(sessionId: Long): List<ChatMessage> {
        return chatDao.getMessagesListForSession(sessionId).map { it.toDomain() }
    }

    suspend fun createNewSession(initialTitle: String = "Новый диалог"): Long {
        val now = System.currentTimeMillis()
        val session = ConversationSessionEntity(
            title = initialTitle,
            createdAt = now,
            updatedAt = now,
            messageCount = 0,
            lastMessagePreview = ""
        )
        return chatDao.insertSession(session)
    }

    suspend fun getOrCreateLatestSession(): Long {
        val latest = chatDao.getLatestSession()
        return latest?.id ?: createNewSession("Диалог с NEXUS")
    }

    suspend fun saveMessage(message: ChatMessage): Long {
        val msgId = chatDao.insertMessage(message.toEntity())
        
        // Update session meta
        val session = chatDao.getSessionById(message.sessionId)
        if (session != null) {
            val preview = message.content.take(60).replace("\n", " ")
            val updatedTitle = if (session.title == "Новый диалог" || session.title.isEmpty()) {
                message.content.take(30).trim().ifEmpty { "Диалог с NEXUS" }
            } else {
                session.title
            }
            chatDao.updateSession(
                session.copy(
                    title = updatedTitle,
                    updatedAt = System.currentTimeMillis(),
                    messageCount = session.messageCount + 1,
                    lastMessagePreview = preview
                )
            )
        }
        return msgId
    }

    suspend fun updateSessionTitle(sessionId: Long, newTitle: String) {
        val session = chatDao.getSessionById(sessionId) ?: return
        chatDao.updateSession(session.copy(title = newTitle, updatedAt = System.currentTimeMillis()))
    }

    suspend fun deleteSession(sessionId: Long) {
        chatDao.deleteSessionById(sessionId)
    }

    suspend fun getTotalMessageCount(): Int = chatDao.getTotalMessageCount()

    suspend fun deleteAllHistory() {
        chatDao.deleteAllSessions()
    }
}
