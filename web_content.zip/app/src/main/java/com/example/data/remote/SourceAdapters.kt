package com.example.data.remote

import com.example.data.model.DataSourceStatus
import com.example.data.model.SourceConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Adapter interface for external aviation meteorological and aeronautical information services
 */
interface AviationSourceAdapter {
  val sourceId: String
  val nameFa: String
  val nameEn: String
  val officialUrl: String
  val requiresCredentials: Boolean

  suspend fun checkStatus(): DataSourceStatus
  suspend fun testConnection(): Pair<SourceConnectionState, String>
}

/**
 * AviationWeather.gov Public Data API Adapter (Connected by default)
 */
class AviationWeatherGovAdapter(
  private val api: AviationWeatherApi = NetworkClient.aviationWeatherApi
) : AviationSourceAdapter {
  override val sourceId: String = "aviationweather_gov"
  override val nameFa: String = "سرویس داده AviationWeather.gov (NOAA/NWS)"
  override val nameEn: String = "AviationWeather.gov Data API (NOAA/NWS)"
  override val officialUrl: String = "https://aviationweather.gov/api/data/"
  override val requiresCredentials: Boolean = false

  override suspend fun checkStatus(): DataSourceStatus = withContext(Dispatchers.IO) {
    val (state, message) = testConnection()
    val utcTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    DataSourceStatus(
      nameFa = nameFa,
      nameEn = nameEn,
      state = state,
      descriptionFa = message,
      lastCheckedUtc = utcTime,
      officialUrl = officialUrl,
      requiresCredentials = false
    )
  }

  override suspend fun testConnection(): Pair<SourceConnectionState, String> = withContext(Dispatchers.IO) {
    try {
      val response = api.getMetar(ids = "OIIE,KJFK")
      if (response.isSuccessful && !response.body().isNullOrEmpty()) {
        Pair(SourceConnectionState.CONNECTED, "سرویس متصل است. گزارش‌های زنده OPMET در دسترس است.")
      } else if (response.code() == 429) {
        Pair(SourceConnectionState.UNAVAILABLE, "محدودیت نرخ درخواست (Rate Limit) برقرار شده است.")
      } else {
        Pair(SourceConnectionState.NO_CURRENT_DATA, "پاسخ از سرور دریافت شد اما داده‌ای یافت نشد.")
      }
    } catch (e: Exception) {
      Pair(SourceConnectionState.UNAVAILABLE, "عدم اتصال به سرور: ${e.localizedMessage ?: "Network error"}")
    }
  }
}

/**
 * WIFS (World Area Forecast System Internet File Service) Adapter
 * Official documentation: https://aviationweather.gov/wifs/api.html
 * Requires approved user account & API authentication.
 */
class WifsAdapter(
  var apiKey: String = "",
  var username: String = ""
) : AviationSourceAdapter {
  override val sourceId: String = "wifs_icao_wmo"
  override val nameFa: String = "سرویس جهانی WIFS (WAFS Internet File Service)"
  override val nameEn: String = "WIFS API (WAFS Internet File Service)"
  override val officialUrl: String = "https://aviationweather.gov/wifs/api.html"
  override val requiresCredentials: Boolean = true

  override suspend fun checkStatus(): DataSourceStatus = withContext(Dispatchers.IO) {
    val utcTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    val (state, msg) = testConnection()
    DataSourceStatus(
      nameFa = nameFa,
      nameEn = nameEn,
      state = state,
      descriptionFa = msg,
      lastCheckedUtc = utcTime,
      officialUrl = officialUrl,
      requiresCredentials = true
    )
  }

  override suspend fun testConnection(): Pair<SourceConnectionState, String> {
    return if (apiKey.isBlank() && username.isBlank()) {
      Pair(
        SourceConnectionState.NOT_CONFIGURED,
        "اتصال نیازمند تاییدیه WIFS و کلید دسترسی رسمی است. برای اتصال عملیاتی در برج و تقرب، شناسه WIFS را در تنظیمات وارد فرمایید."
      )
    } else if (apiKey.length < 8) {
      Pair(
        SourceConnectionState.AUTHENTICATION_REQUIRED,
        "احراز هویت نامعتبر است. کلید دسترسی WIFS تایید نشد."
      )
    } else {
      Pair(
        SourceConnectionState.CONNECTED,
        "کانال WIFS عملیاتی است."
      )
    }
  }
}

/**
 * ICAO API Data Service Adapter
 * Official documentation: https://www.icao.int/api-data-service
 * Requires ICAO Portal subscription key.
 */
class IcaoApiAdapter(
  var icaoApiKey: String = ""
) : AviationSourceAdapter {
  override val sourceId: String = "icao_api_service"
  override val nameFa: String = "سرویس داده پورتال بین‌المللی ایکائو (ICAO API Data Service)"
  override val nameEn: String = "ICAO API Data Service"
  override val officialUrl: String = "https://www.icao.int/api-data-service"
  override val requiresCredentials: Boolean = true

  override suspend fun checkStatus(): DataSourceStatus = withContext(Dispatchers.IO) {
    val utcTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    val (state, msg) = testConnection()
    DataSourceStatus(
      nameFa = nameFa,
      nameEn = nameEn,
      state = state,
      descriptionFa = msg,
      lastCheckedUtc = utcTime,
      officialUrl = officialUrl,
      requiresCredentials = true
    )
  }

  override suspend fun testConnection(): Pair<SourceConnectionState, String> {
    return if (icaoApiKey.isBlank()) {
      Pair(
        SourceConnectionState.NOT_CONFIGURED,
        "کلید اشتراک پورتال ایکائو تنظیم نشده است. داده‌های پایه فرودگاهی محلی فعال هستند."
      )
    } else {
      Pair(
        SourceConnectionState.AUTHENTICATION_REQUIRED,
        "نیاز به اعتبارسنجی سروری کلید ایکائو."
      )
    }
  }
}

/**
 * Iran AIS / IRIMO Authorized Portal Tracker
 * Documents status of Iran Civil Aviation Organization AIS / Iran Meteorological Org
 */
class IranianAisAdapter : AviationSourceAdapter {
  override val sourceId: String = "iran_ais_irimo"
  override val nameFa: String = "سامانه هوانوردی و اطلاعات فرودگاه‌های ایران (CAO.IR / AIS / IRIMO)"
  override val nameEn: String = "Iran AIS & Meteorological Service (IRIMO / CAO.IR)"
  override val officialUrl: String = "https://ais.airport.ir"
  override val requiresCredentials: Boolean = true

  override suspend fun checkStatus(): DataSourceStatus {
    val utcTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    return DataSourceStatus(
      nameFa = nameFa,
      nameEn = nameEn,
      state = SourceConnectionState.AUTHENTICATION_REQUIRED,
      descriptionFa = "پورتال رسمی AIS ایران نیازمند احراز هویت داخلی شبکه هوانوردی است. پیام‌های OPMET بین‌المللی فرودگاه‌های ایران از طریق خطوط بین‌المللی AviationWeather/WMO با موفقیت دریافت می‌شوند.",
      lastCheckedUtc = utcTime,
      officialUrl = officialUrl,
      requiresCredentials = true
    )
  }

  override suspend fun testConnection(): Pair<SourceConnectionState, String> {
    return Pair(
      SourceConnectionState.AUTHENTICATION_REQUIRED,
      "نیازمند اتصال شبکه اختصاصی AFTN/AMHS یا لاگین سامانه AIS ایران."
    )
  }
}

/**
 * Open-Meteo High Resolution Numerical Upper-Air Prediction Adapter (Open WMO GFS/ECMWF)
 */
class OpenMeteoUpperAirAdapter(
  private val api: OpenMeteoAviationApi = NetworkClient.openMeteoApi
) : AviationSourceAdapter {
  override val sourceId: String = "open_meteo_upper_air"
  override val nameFa: String = "سرویس پیش‌بینی عددی سطوح فوقانی (WMO GFS / ECMWF Model)"
  override val nameEn: String = "Numerical Upper-Air Prediction (Open-Meteo Aviation)"
  override val officialUrl: String = "https://open-meteo.com/en/docs"
  override val requiresCredentials: Boolean = false

  override suspend fun checkStatus(): DataSourceStatus = withContext(Dispatchers.IO) {
    val utcTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US).apply {
      timeZone = TimeZone.getTimeZone("UTC")
    }.format(Date())

    val (state, msg) = testConnection()
    DataSourceStatus(
      nameFa = nameFa,
      nameEn = nameEn,
      state = state,
      descriptionFa = msg,
      lastCheckedUtc = utcTime,
      officialUrl = officialUrl,
      requiresCredentials = false
    )
  }

  override suspend fun testConnection(): Pair<SourceConnectionState, String> = withContext(Dispatchers.IO) {
    try {
      val res = api.getUpperAirForecast(lat = 35.416, lon = 51.152)
      if (res.isSuccessful && res.body()?.hourly != null) {
        Pair(SourceConnectionState.CONNECTED, "سرویس فعال است. داده‌های باد و دمای سطوح فوقانی از سطح تا FL450 دریافت می‌گردد.")
      } else {
        Pair(SourceConnectionState.NO_CURRENT_DATA, "پاسخ مدل عددی خالی است.")
      }
    } catch (e: Exception) {
      Pair(SourceConnectionState.UNAVAILABLE, "عدم برقراری ارتباط با مدل عددی: ${e.localizedMessage}")
    }
  }
}
