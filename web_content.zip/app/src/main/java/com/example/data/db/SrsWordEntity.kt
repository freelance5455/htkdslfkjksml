package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "srs_words")
data class SrsWordEntity(
    @PrimaryKey val id: String, // Normalized lowercase word
    val word: String,
    val displayWord: String,
    val simpleSynonym: String,
    val colloquialMeaning: String,
    val imageUrl: String,
    val originalSentence: String,
    val dailyLifeExample: String,
    val category: String,
    val sourceDocument: String,
    val pageNumber: Int = 1,
    val learnedTimestamp: Long = System.currentTimeMillis(),
    val lastReviewedTimestamp: Long = 0L,
    val nextReviewTimestamp: Long = System.currentTimeMillis() + (15 * 60 * 1000L), // 15 mins
    val repetitionCount: Int = 0,
    val intervalMinutes: Long = 15L,
    val easeFactor: Double = 2.5,
    val timesForgotten: Int = 0,
    val timesRemembered: Int = 0,
    val isMemorized: Boolean = false
) {
    val isDueForReview: Boolean
        get() = nextReviewTimestamp <= System.currentTimeMillis()
}
