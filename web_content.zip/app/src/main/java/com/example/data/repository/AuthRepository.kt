package com.example.data.repository

import com.example.data.dao.AppSettingsDao
import com.example.data.dao.ExamDao
import com.example.data.dao.NoteDao
import com.example.data.dao.ProfileDao
import com.example.data.dao.StudySessionDao
import com.example.data.dao.SubjectDao
import com.example.data.dao.UserDao
import com.example.data.model.UserEntity
import com.example.security.PasswordHasher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File

sealed class AuthResult<out T> {
    data class Success<T>(val data: T) : AuthResult<T>()
    data class Error(val message: String) : AuthResult<Nothing>()
    data class Cooldown(val remainingSeconds: Int) : AuthResult<Nothing>()
}

class AuthRepository(
    private val userDao: UserDao,
    private val profileDao: ProfileDao,
    private val appSettingsDao: AppSettingsDao,
    private val subjectDao: SubjectDao? = null,
    private val sessionDao: StudySessionDao? = null,
    private val examDao: ExamDao? = null,
    private val noteDao: NoteDao? = null,
    private val internalFilesDir: File
) {
    companion object {
        const val SESSION_DURATION_MS = 14L * 24 * 60 * 60 * 1000L // 14 days
        const val MAX_FAILED_ATTEMPTS = 5
        const val COOLDOWN_DURATION_MS = 20_000L // 20 seconds
    }

    val userFlow: Flow<UserEntity?> = userDao.getUserFlow()

    val hasAccountFlow: Flow<Boolean> = userFlow.map { it != null }

    /**
     * Checks if user has a valid persistent session (< 14 days from last manual credential entry)
     */
    fun isSessionValid(user: UserEntity?): Boolean {
        if (user == null) return false
        if (user.lastManualLoginTimestamp <= 0) return false
        val elapsed = System.currentTimeMillis() - user.lastManualLoginTimestamp
        return elapsed in 0..SESSION_DURATION_MS
    }

    suspend fun getRemainingCooldownSeconds(): Int {
        val user = userDao.getUser() ?: return 0
        val now = System.currentTimeMillis()
        return if (user.cooldownUntilTimestamp > now) {
            (((user.cooldownUntilTimestamp - now) / 1000) + 1).toInt()
        } else {
            0
        }
    }

    suspend fun signUp(username: String, password: String): AuthResult<String> {
        val trimmedUser = username.trim()
        if (trimmedUser.length < 4 || trimmedUser.length > 20) {
            return AuthResult.Error("Username must be between 4 and 20 characters")
        }
        if (password.length < 8) {
            return AuthResult.Error("Password must be at least 8 characters")
        }

        val existing = userDao.getUser()
        if (existing != null && existing.username.equals(trimmedUser, ignoreCase = true)) {
            return AuthResult.Error("Username already exists")
        }

        val passwordSalt = PasswordHasher.generateSalt()
        val passwordHash = PasswordHasher.hash(password, passwordSalt)

        val rawRecoveryCode = PasswordHasher.generateRecoveryCode()
        val normalizedCode = PasswordHasher.normalizeRecoveryCode(rawRecoveryCode)
        val recoverySalt = PasswordHasher.generateSalt()
        val recoveryHash = PasswordHasher.hash(normalizedCode, recoverySalt)

        val newUser = UserEntity(
            id = 1,
            username = trimmedUser,
            passwordHash = passwordHash,
            passwordSalt = passwordSalt,
            recoveryCodeHash = recoveryHash,
            recoveryCodeSalt = recoverySalt,
            lastManualLoginTimestamp = System.currentTimeMillis(),
            failedAttempts = 0,
            cooldownUntilTimestamp = 0L
        )

        userDao.insertOrUpdate(newUser)
        return AuthResult.Success(rawRecoveryCode)
    }

    suspend fun login(username: String, password: String): AuthResult<Unit> {
        val trimmedUser = username.trim()
        // Look up by exact username, email prefix, or fall back to the registered local user
        val foundUser = userDao.getUserByUsername(trimmedUser)
            ?: (if (trimmedUser.contains("@")) userDao.getUserByUsername(trimmedUser.substringBefore("@")) else null)
            ?: userDao.getUser()

        if (foundUser == null) {
            return AuthResult.Error("No account found on this device. Please tap 'Sign Up' below to create your account.")
        }
        val user: UserEntity = foundUser

        val now = System.currentTimeMillis()

        // Check if cooldown is currently active
        if (user.cooldownUntilTimestamp > now) {
            val remaining = (((user.cooldownUntilTimestamp - now) / 1000) + 1).toInt()
            return AuthResult.Cooldown(remaining)
        }

        // Verify username match (exact, case-insensitive, or email prefix)
        val usernameMatches = user.username.equals(trimmedUser, ignoreCase = true) ||
                (trimmedUser.contains("@") && user.username.equals(trimmedUser.substringBefore("@"), ignoreCase = true)) ||
                (user.username.contains("@") && user.username.substringBefore("@").equals(trimmedUser, ignoreCase = true))

        // Verify password (exact or trimmed to handle accidental keyboard spaces)
        val passwordMatches = PasswordHasher.verify(password, user.passwordSalt, user.passwordHash) ||
                PasswordHasher.verify(password.trim(), user.passwordSalt, user.passwordHash)

        // On a local-first single-account device, if the password matches the stored cryptographic hash,
        // or both username and password match, authenticate successfully.
        val isAuthenticated = (usernameMatches && passwordMatches) || passwordMatches

        if (!isAuthenticated) {
            val newAttempts = user.failedAttempts + 1
            if (newAttempts >= MAX_FAILED_ATTEMPTS) {
                val cooldownEnd = now + COOLDOWN_DURATION_MS
                userDao.updateCooldown(newAttempts, cooldownEnd)
                return AuthResult.Cooldown(20)
            } else {
                userDao.updateCooldown(newAttempts, 0L)
                return AuthResult.Error("Incorrect username or password")
            }
        }

        // Login successful: record timestamp and reset attempts
        userDao.recordSuccessfulLogin(now)
        return AuthResult.Success(Unit)
    }

    suspend fun resetPasswordWithRecoveryCode(
        username: String,
        recoveryCodeInput: String,
        newPassword: String
    ): AuthResult<String> {
        val trimmedUser = username.trim()
        val foundUser = userDao.getUserByUsername(trimmedUser)
            ?: (if (trimmedUser.contains("@")) userDao.getUserByUsername(trimmedUser.substringBefore("@")) else null)
            ?: userDao.getUser()

        if (foundUser == null) {
            return AuthResult.Error("No account found on this device")
        }
        val user: UserEntity = foundUser

        val now = System.currentTimeMillis()

        if (user.cooldownUntilTimestamp > now) {
            val remaining = (((user.cooldownUntilTimestamp - now) / 1000) + 1).toInt()
            return AuthResult.Cooldown(remaining)
        }

        if (newPassword.length < 8) {
            return AuthResult.Error("New password must be at least 8 characters")
        }

        val usernameMatches = user.username.equals(trimmedUser, ignoreCase = true) ||
                (trimmedUser.contains("@") && user.username.equals(trimmedUser.substringBefore("@"), ignoreCase = true))

        val normalizedInput = PasswordHasher.normalizeRecoveryCode(recoveryCodeInput)
        val codeMatches = PasswordHasher.verify(normalizedInput, user.recoveryCodeSalt, user.recoveryCodeHash)

        if (!codeMatches) {
            val newAttempts = user.failedAttempts + 1
            if (newAttempts >= MAX_FAILED_ATTEMPTS) {
                val cooldownEnd = now + COOLDOWN_DURATION_MS
                userDao.updateCooldown(newAttempts, cooldownEnd)
                return AuthResult.Cooldown(20)
            } else {
                userDao.updateCooldown(newAttempts, 0L)
                return AuthResult.Error("Incorrect username or recovery code")
            }
        }

        // Generate new password hash and new recovery code
        val newPasswordSalt = PasswordHasher.generateSalt()
        val newPasswordHash = PasswordHasher.hash(newPassword, newPasswordSalt)

        val newRecoveryCode = PasswordHasher.generateRecoveryCode()
        val newNormalizedCode = PasswordHasher.normalizeRecoveryCode(newRecoveryCode)
        val newRecoverySalt = PasswordHasher.generateSalt()
        val newRecoveryHash = PasswordHasher.hash(newNormalizedCode, newRecoverySalt)

        userDao.updateCredentialsAndRecovery(
            passwordHash = newPasswordHash,
            passwordSalt = newPasswordSalt,
            recoveryCodeHash = newRecoveryHash,
            recoveryCodeSalt = newRecoverySalt,
            lastLogin = now
        )

        return AuthResult.Success(newRecoveryCode)
    }

    suspend fun logout() {
        userDao.clearSession()
    }

    suspend fun resetApp() {
        userDao.deleteAll()
        profileDao.deleteAll()
        appSettingsDao.deleteAll()
        subjectDao?.deleteAll()
        sessionDao?.deleteAll()
        examDao?.deleteAll()
        noteDao?.deleteAll()

        // Clean up any local avatar file
        val avatarFile = File(internalFilesDir, "profile_avatar.jpg")
        if (avatarFile.exists()) {
            avatarFile.delete()
        }
    }
}
