package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AppConfig
import com.example.data.model.ServerStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ServerRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("chaufaland_prefs", Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    fun getConfig(): AppConfig {
        return AppConfig(
            gamerTag = prefs.getString("gamer_tag", "") ?: "",
            activeServerType = prefs.getString("active_server_type", "exaroton") ?: "exaroton",
            exarotonApiToken = prefs.getString("exaroton_token", "") ?: "",
            exarotonServerId = prefs.getString("exaroton_server_id", "") ?: "",
            aternosServerIp = prefs.getString("aternos_ip", "chaufaland.aternos.me") ?: "chaufaland.aternos.me",
            bedrockWsUrl = prefs.getString("bedrock_ws_url", "ws://localhost:3000/bedrock-ws") ?: "ws://localhost:3000/bedrock-ws"
        )
    }

    fun saveGamerTag(tag: String) {
        prefs.edit().putString("gamer_tag", tag.trim()).apply()
    }

    fun saveConfig(config: AppConfig) {
        prefs.edit()
            .putString("gamer_tag", config.gamerTag.trim())
            .putString("active_server_type", config.activeServerType)
            .putString("exaroton_token", config.exarotonApiToken.trim())
            .putString("exaroton_server_id", config.exarotonServerId.trim())
            .putString("aternos_ip", config.aternosServerIp.trim())
            .putString("bedrock_ws_url", config.bedrockWsUrl.trim())
            .apply()
    }

    suspend fun fetchStatus(config: AppConfig): Result<ServerStatus> = withContext(Dispatchers.IO) {
        try {
            if (config.activeServerType == "exaroton" && config.exarotonApiToken.isNotBlank() && config.exarotonServerId.isNotBlank()) {
                fetchExarotonStatus(config.exarotonApiToken, config.exarotonServerId)
            } else {
                fetchMcsrvstatStatus(config.aternosServerIp)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchExarotonStatus(token: String, serverId: String): Result<ServerStatus> {
        val request = Request.Builder()
            .url("https://api.exaroton.com/v1/servers/$serverId")
            .header("Authorization", "Bearer $token")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return Result.failure(Exception("HTTP ${response.code}: ${response.message}"))
            }
            val body = response.body?.string() ?: return Result.failure(Exception("Respuesta vacía"))
            val root = JSONObject(body)
            val data = root.optJSONObject("data") ?: return Result.failure(Exception("Sin datos"))

            val statusCode = data.optInt("status", 0)
            val isOnline = statusCode == 1
            val statusMap = mapOf(
                0 to "Apagado",
                1 to "En Línea",
                2 to "Iniciando",
                3 to "Deteniendo",
                4 to "Reiniciando",
                5 to "Guardando",
                6 to "Cargando",
                7 to "Crasheado",
                8 to "Pendiente"
            )
            val statusText = statusMap[statusCode] ?: "Desconocido"

            val host = data.optString("address", data.optString("name") + ".exaroton.me")
            val port = data.optInt("port", 19132)
            val motd = data.optString("motd", "Servidor Oficial CHAUFALAND")

            var playersCount = 0
            var maxPlayers = 20
            val playerList = mutableListOf<String>()

            val playersObj = data.optJSONObject("players")
            if (playersObj != null) {
                playersCount = playersObj.optInt("count", 0)
                maxPlayers = playersObj.optInt("max", 20)
                val listArr = playersObj.optJSONArray("list")
                if (listArr != null) {
                    for (i in 0 until listArr.length()) {
                        playerList.add(listArr.getString(i))
                    }
                }
            }

            return Result.success(
                ServerStatus(
                    online = isOnline,
                    statusText = statusText,
                    host = host,
                    port = port,
                    tps = if (isOnline) 20.0 else 0.0,
                    ramUsed = if (isOnline) "1.4 GB" else "0 MB",
                    ramLimit = "2.0 GB",
                    cpuPercent = if (isOnline) 18 else 0,
                    playersCount = playersCount,
                    maxPlayers = maxPlayers,
                    playerList = playerList,
                    motd = motd
                )
            )
        }
    }

    private fun fetchMcsrvstatStatus(host: String): Result<ServerStatus> {
        val target = if (host.isBlank()) "chaufaland.aternos.me" else host
        val request = Request.Builder()
            .url("https://api.mcsrvstat.us/2/$target")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return Result.failure(Exception("HTTP ${response.code}"))
            }
            val body = response.body?.string() ?: return Result.failure(Exception("Respuesta vacía"))
            val root = JSONObject(body)
            val isOnline = root.optBoolean("online", false)

            val port = root.optInt("port", 19132)
            var motd = "Servidor Oficial CHAUFALAND"
            val motdObj = root.optJSONObject("motd")
            if (motdObj != null) {
                val cleanArr = motdObj.optJSONArray("clean")
                if (cleanArr != null && cleanArr.length() > 0) {
                    val sb = StringBuilder()
                    for (i in 0 until cleanArr.length()) {
                        sb.append(cleanArr.getString(i)).append(" ")
                    }
                    motd = sb.toString().trim()
                }
            }

            var playersCount = 0
            var maxPlayers = 20
            val playerList = mutableListOf<String>()

            val playersObj = root.optJSONObject("players")
            if (playersObj != null) {
                playersCount = playersObj.optInt("online", 0)
                maxPlayers = playersObj.optInt("max", 20)
                val listArr = playersObj.optJSONArray("list")
                if (listArr != null) {
                    for (i in 0 until listArr.length()) {
                        playerList.add(listArr.getString(i))
                    }
                }
            }

            return Result.success(
                ServerStatus(
                    online = isOnline,
                    statusText = if (isOnline) "En Línea" else "Apagado",
                    host = target,
                    port = port,
                    tps = if (isOnline) 20.0 else 0.0,
                    ramUsed = if (isOnline) "1.2 GB" else "0 MB",
                    ramLimit = "2.0 GB",
                    cpuPercent = if (isOnline) 12 else 0,
                    playersCount = playersCount,
                    maxPlayers = maxPlayers,
                    playerList = playerList,
                    motd = motd
                )
            )
        }
    }

    suspend fun executeExarotonAction(token: String, serverId: String, action: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val jsonMediaType = "application/json; charset=utf-8".toMediaType()
            val request = Request.Builder()
                .url("https://api.exaroton.com/v1/servers/$serverId/$action")
                .header("Authorization", "Bearer $token")
                .post("{}".toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    Result.success("Acción $action ejecutada con éxito")
                } else {
                    Result.failure(Exception("Error Exaroton: HTTP ${response.code} $body"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun sendExarotonCommand(token: String, serverId: String, command: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val jsonMediaType = "application/json; charset=utf-8".toMediaType()
            val json = JSONObject().put("command", command).toString()
            val request = Request.Builder()
                .url("https://api.exaroton.com/v1/servers/$serverId/command")
                .header("Authorization", "Bearer $token")
                .post(json.toRequestBody(jsonMediaType))
                .build()

            client.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    Result.success("Comando enviado: $command")
                } else {
                    Result.failure(Exception("Error Exaroton: HTTP ${response.code} $body"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
