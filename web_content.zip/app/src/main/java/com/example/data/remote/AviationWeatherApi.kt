package com.example.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface AviationWeatherApi {

  @GET("api/data/metar")
  suspend fun getMetar(
    @Query("ids") ids: String,
    @Query("format") format: String = "json"
  ): Response<List<MetarResponseDto>>

  @GET("api/data/taf")
  suspend fun getTaf(
    @Query("ids") ids: String,
    @Query("format") format: String = "json"
  ): Response<List<TafResponseDto>>

  @GET("api/data/sigmet")
  suspend fun getSigmets(
    @Query("format") format: String = "json"
  ): Response<List<SigmetResponseDto>>
}

interface OpenMeteoAviationApi {

  @GET("v1/forecast")
  suspend fun getUpperAirForecast(
    @Query("latitude") lat: Double,
    @Query("longitude") lon: Double,
    @Query("hourly") hourly: String = "wind_speed_1000hPa,wind_direction_1000hPa,temperature_1000hPa,wind_speed_850hPa,wind_direction_850hPa,temperature_850hPa,wind_speed_700hPa,wind_direction_700hPa,temperature_700hPa,wind_speed_500hPa,wind_direction_500hPa,temperature_500hPa,wind_speed_300hPa,wind_direction_300hPa,temperature_300hPa,wind_speed_250hPa,wind_direction_250hPa,temperature_250hPa,wind_speed_200hPa,wind_direction_200hPa,temperature_200hPa",
    @Query("wind_speed_unit") windUnit: String = "kn",
    @Query("forecast_days") forecastDays: Int = 1
  ): Response<OpenMeteoResponseDto>
}

object NetworkClient {

  private val moshi: Moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

  private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(15, TimeUnit.SECONDS)
    .writeTimeout(15, TimeUnit.SECONDS)
    .addInterceptor(HttpLoggingInterceptor().apply {
      level = HttpLoggingInterceptor.Level.BASIC
    })
    .build()

  val aviationWeatherApi: AviationWeatherApi by lazy {
    Retrofit.Builder()
      .baseUrl("https://aviationweather.gov/")
      .client(okHttpClient)
      .addConverterFactory(MoshiConverterFactory.create(moshi))
      .build()
      .create(AviationWeatherApi::class.java)
  }

  val openMeteoApi: OpenMeteoAviationApi by lazy {
    Retrofit.Builder()
      .baseUrl("https://api.open-meteo.com/")
      .client(okHttpClient)
      .addConverterFactory(MoshiConverterFactory.create(moshi))
      .build()
      .create(OpenMeteoAviationApi::class.java)
  }
}
