package com.example.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "notes",
    foreignKeys = [
        ForeignKey(
            entity = SubjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [Index("subjectId"), Index("updatedAt"), Index("isPinned")]
)
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val contentJson: String,
    val plainTextPreview: String,
    val subjectId: Long? = null,
    val isPinned: Boolean = false,
    val fontFamily: String = "sans", // "sans", "serif", "monospace", "handwriting"
    val fontSize: Int = 16,           // 10..36 pt/sp
    val textAlign: String = "left",   // "left", "center", "right"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
