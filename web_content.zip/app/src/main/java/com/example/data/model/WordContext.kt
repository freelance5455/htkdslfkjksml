package com.example.data.model

data class WordContext(
    val id: String,
    val word: String, // cleaned word (lowercase/normalized for matching)
    val displayWord: String, // as displayed in text (with original case)
    val sentenceContext: String, // surrounding sentence
    val pageNumber: Int,
    val wordIndexInPage: Int,
    val isStopWord: Boolean = false,
    var isKnown: Boolean? = null // null = pending, true = knows it, false = doesn't know
)
