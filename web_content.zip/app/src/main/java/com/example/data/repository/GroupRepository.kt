package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.ArkGroup
import com.example.data.model.GroupMedia
import com.example.data.model.GroupMessage
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlin.random.Random

class GroupRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing groups.")

    fun observeMyGroups(userId: String): Flow<List<ArkGroup>> = flow {
        val path = "groups"
        emitAll(
            db.collection("groups")
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ArkGroup::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.updatedAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == userId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observePublicCommunities(): Flow<List<ArkGroup>> = flow {
        val path = "groups"
        emitAll(
            db.collection("groups")
                .whereEqualTo("isPrivate", false)
                .limit(30)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ArkGroup::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.memberCount }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeGroup(groupId: String): Flow<ArkGroup?> = flow {
        val path = "groups/$groupId"
        emitAll(
            db.collection("groups").document(groupId)
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            ArkGroup::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else null
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser != null) {
                        handleFirestoreError(ex, OperationType.GET, path)
                    }
                    throw error
                }
        )
    }

    fun observeMessages(groupId: String, currentUserId: String): Flow<List<GroupMessage>> = flow {
        val path = "groups/$groupId/messages"
        emitAll(
            db.collection("groups").document(groupId).collection("messages")
                .whereArrayContains("memberUids", currentUserId)
                .limit(100)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        GroupMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == currentUserId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeGroupMedia(groupId: String, currentUserId: String): Flow<List<GroupMedia>> = flow {
        val path = "groups/$groupId/media"
        emitAll(
            db.collection("groups").document(groupId).collection("media")
                .whereArrayContains("memberUids", currentUserId)
                .limit(60)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        GroupMedia::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .catch { error ->
                    val firestoreError = error.unwrapFirestoreException()
                    if (firestoreError == null && error is CancellationException) throw error
                    val ex = firestoreError ?: (error as? Exception)
                    if (ex != null && auth.currentUser?.uid == currentUserId) {
                        handleFirestoreError(ex, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createGroup(
        name: String,
        description: String,
        theme: String,
        isPrivate: Boolean,
        allowMediaDownloads: Boolean
    ): Result<ArkGroup> = runCatching {
        val uid = requireUserId()
        val cleanName = name.trim().take(40)
        require(cleanName.length >= 2) { "Group name must be at least 2 characters." }
        val inviteCode = generateInviteCode()
        val groupRef = db.collection("groups").document()
        val inviteRef = db.collection("groupInvites").document(inviteCode)

        val groupPayload = mapOf(
            "ownerId" to uid,
            "name" to cleanName,
            "description" to description.trim().take(200),
            "inviteCode" to inviteCode,
            "theme" to theme.ifBlank { "aurora" },
            "isPrivate" to isPrivate,
            "allowMediaDownloads" to allowMediaDownloads,
            "memberUids" to listOf(uid),
            "adminUids" to listOf(uid),
            "memberCount" to 1L,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        val invitePayload = mapOf(
            "groupId" to groupRef.id,
            "groupName" to cleanName,
            "ownerId" to uid,
            "createdAt" to FieldValue.serverTimestamp()
        )

        val batch = db.batch()
        batch.set(groupRef, groupPayload)
        batch.set(inviteRef, invitePayload)
        try {
            batch.commit().await()
            ArkGroup(
                id = groupRef.id,
                ownerId = uid,
                name = cleanName,
                description = description.trim().take(200),
                inviteCode = inviteCode,
                theme = theme.ifBlank { "aurora" },
                isPrivate = isPrivate,
                allowMediaDownloads = allowMediaDownloads,
                memberUids = listOf(uid),
                adminUids = listOf(uid),
                memberCount = 1L
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, groupRef.path)
            throw e
        }
    }

    suspend fun joinGroupByInviteCode(code: String): Result<String> = runCatching {
        val uid = requireUserId()
        val cleanCode = code.trim().uppercase()
        require(cleanCode.length in 4..16) { "Enter a valid invite code." }
        val inviteRef = db.collection("groupInvites").document(cleanCode)
        try {
            val inviteSnap = inviteRef.get().await()
            require(inviteSnap.exists()) { "No group found for invite code $cleanCode." }
            val groupId = inviteSnap.getString("groupId")
                ?: throw IllegalStateException("Invite is missing group reference.")
            joinGroupById(groupId, uid)
            groupId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, inviteRef.path)
            throw e
        }
    }

    suspend fun joinPublicGroup(groupId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        joinGroupById(groupId, uid)
    }

    private suspend fun joinGroupById(groupId: String, uid: String) {
        val groupRef = db.collection("groups").document(groupId)
        try {
            groupRef.update(
                mapOf(
                    "memberUids" to FieldValue.arrayUnion(uid),
                    "memberCount" to FieldValue.increment(1L),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // If the user is already a member, allow get succeeds and we can treat join as idempotent.
            val alreadyMember = runCatching {
                val snap = groupRef.get().await()
                val members = (snap.get("memberUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                snap.exists() && members.contains(uid)
            }.getOrDefault(false)
            if (alreadyMember) return
            handleFirestoreError(e, OperationType.UPDATE, groupRef.path)
            throw e
        }
    }

    suspend fun updateGroupSettings(
        groupId: String,
        name: String,
        description: String,
        theme: String,
        allowMediaDownloads: Boolean
    ): Result<Unit> = runCatching {
        requireUserId()
        val groupRef = db.collection("groups").document(groupId)
        try {
            groupRef.update(
                mapOf(
                    "name" to name.trim().take(40),
                    "description" to description.trim().take(200),
                    "theme" to theme,
                    "allowMediaDownloads" to allowMediaDownloads,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, groupRef.path)
            throw e
        }
    }

    suspend fun promoteMemberToAdmin(group: ArkGroup, targetUid: String): Result<Unit> = runCatching {
        requireUserId()
        if (group.adminUids.contains(targetUid)) return@runCatching
        val groupRef = db.collection("groups").document(group.id)
        try {
            groupRef.update(
                mapOf(
                    "adminUids" to (group.adminUids + targetUid).take(10),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, groupRef.path)
            throw e
        }
    }

    suspend fun removeMember(group: ArkGroup, targetUid: String): Result<Unit> = runCatching {
        requireUserId()
        val nextMembers = group.memberUids.filterNot { it == targetUid }
        val nextAdmins = group.adminUids.filterNot { it == targetUid }
        require(nextMembers.isNotEmpty() && nextAdmins.isNotEmpty()) { "Group must keep at least one admin." }
        val groupRef = db.collection("groups").document(group.id)
        try {
            groupRef.update(
                mapOf(
                    "memberUids" to nextMembers,
                    "adminUids" to nextAdmins,
                    "memberCount" to nextMembers.size.toLong(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, groupRef.path)
            throw e
        }
    }

    suspend fun leaveGroup(group: ArkGroup): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(group.ownerId != uid) { "Owner cannot leave without deleting or transferring the group." }
        val nextMembers = group.memberUids.filterNot { it == uid }
        val nextAdmins = group.adminUids.filterNot { it == uid }
        val groupRef = db.collection("groups").document(group.id)
        try {
            groupRef.update(
                mapOf(
                    "memberUids" to nextMembers,
                    "adminUids" to nextAdmins,
                    "memberCount" to nextMembers.size.toLong(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, groupRef.path)
            throw e
        }
    }

    suspend fun deleteGroup(group: ArkGroup): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(group.ownerId == uid) { "Only the group owner can delete this group." }
        val groupRef = db.collection("groups").document(group.id)
        val inviteRef = db.collection("groupInvites").document(group.inviteCode)
        val batch = db.batch()
        batch.delete(groupRef)
        batch.delete(inviteRef)
        try {
            batch.commit().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, groupRef.path)
            throw e
        }
    }

    suspend fun sendMessage(
        group: ArkGroup,
        sender: UserProfile,
        text: String,
        imageBase64: String? = null,
        replyToId: String? = null,
        replyToPreview: String? = null
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(uid == sender.userId)
        require(text.isNotBlank() || !imageBase64.isNullOrBlank()) { "Message cannot be empty." }
        val msgRef = db.collection("groups").document(group.id).collection("messages").document()
        val payload = mutableMapOf<String, Any>(
            "groupId" to group.id,
            "memberUids" to group.memberUids,
            "senderId" to uid,
            "senderUsername" to sender.username,
            "senderAvatar" to sender.avatarPreset,
            "text" to text.trim().take(1000),
            "reactions" to emptyMap<String, Long>(),
            "isDeleted" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!imageBase64.isNullOrBlank()) payload["imageBase64"] = imageBase64.take(80000)
        if (!replyToId.isNullOrBlank()) payload["replyToId"] = replyToId
        if (!replyToPreview.isNullOrBlank()) payload["replyToPreview"] = replyToPreview.take(120)

        try {
            msgRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, msgRef.path)
            throw e
        }
    }

    suspend fun addReaction(groupId: String, message: GroupMessage, emoji: String): Result<Unit> = runCatching {
        requireUserId()
        val msgRef = db.collection("groups").document(groupId).collection("messages").document(message.id)
        val nextReactions = message.reactions.toMutableMap()
        nextReactions[emoji] = (nextReactions[emoji] ?: 0L) + 1L
        try {
            msgRef.update(
                mapOf(
                    "reactions" to nextReactions,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, msgRef.path)
            throw e
        }
    }

    suspend fun deleteMessage(groupId: String, messageId: String): Result<Unit> = runCatching {
        requireUserId()
        val msgRef = db.collection("groups").document(groupId).collection("messages").document(messageId)
        try {
            msgRef.update(
                mapOf(
                    "isDeleted" to true,
                    "text" to "This message was deleted",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, msgRef.path)
            throw e
        }
    }

    suspend fun uploadGroupMedia(
        group: ArkGroup,
        uploader: UserProfile,
        albumName: String,
        caption: String,
        imageBase64: String
    ): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(imageBase64.isNotBlank()) { "Image data cannot be empty." }
        val mediaRef = db.collection("groups").document(group.id).collection("media").document()
        val payload = mapOf(
            "groupId" to group.id,
            "memberUids" to group.memberUids,
            "uploaderId" to uid,
            "uploaderUsername" to uploader.username,
            "albumName" to albumName.ifBlank { "Memories" }.take(40),
            "caption" to caption.trim().take(160),
            "imageBase64" to imageBase64.take(80000),
            "createdAt" to FieldValue.serverTimestamp()
        )
        try {
            mediaRef.set(payload).await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, mediaRef.path)
            throw e
        }
    }

    private fun generateInviteCode(): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return buildString(6) {
            repeat(6) { append(chars[Random.nextInt(chars.length)]) }
        }
    }
}
