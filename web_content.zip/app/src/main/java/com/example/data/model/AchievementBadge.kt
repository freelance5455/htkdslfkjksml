package com.example.data.model

data class AchievementBadge(
  val id: String,
  val title: String,
  val description: String,
  val iconEmoji: String,
  val targetValue: Int,
  val currentValue: Int,
  val isUnlocked: Boolean,
  val category: String = "Başarı"
) {
  val progressPercent: Float
    get() = if (targetValue > 0) (currentValue.toFloat() / targetValue).coerceIn(0f, 1f) else 1f
}

data class DailyTrendPoint(
  val dayLabel: String,
  val date: String,
  val solvedQuestions: Int
)
