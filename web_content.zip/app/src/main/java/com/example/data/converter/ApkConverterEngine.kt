package com.example.data.converter

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import com.example.data.model.ApkInfo
import com.example.data.model.ConversionProgress
import com.example.data.model.ConversionStage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.DecimalFormat
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ApkConverterEngine(private val context: Context) {

    private val outputDir = File(context.filesDir, "converted_apks").apply { mkdirs() }
    private val tempDir = File(context.cacheDir, "converter_temp").apply { mkdirs() }

    suspend fun convertFile(
        sourceUri: Uri?,
        sourceFile: File? = null,
        assetName: String? = null,
        customAppName: String? = null,
        onProgress: (ConversionProgress) -> Unit
    ): Result<ApkInfo> = withContext(Dispatchers.IO) {
        try {
            tempDir.deleteRecursively()
            tempDir.mkdirs()

            onProgress(ConversionProgress(ConversionStage.READING, 0.1f, "Opening source file..."))

            // 1. Copy source stream to local temp file
            val localSource = File(tempDir, "source_input.bin")
            getInputStream(sourceUri, sourceFile, assetName).use { input ->
                localSource.outputStream().use { output ->
                    input.copyTo(output)
                }
            }

            val totalBytes = localSource.length()
            if (totalBytes < 4) {
                return@withContext Result.failure(IllegalArgumentException("File is empty or invalid"))
            }

            onProgress(ConversionProgress(ConversionStage.EXTRACTING, 0.25f, "Analyzing file structure..."))

            // 2. Inspect file header
            val isZip = isZipFile(localSource)

            val finalApkFile: File
            val detectedType: String

            if (isZip) {
                // Check what's inside the ZIP
                val zipInspection = inspectZip(localSource)

                if (zipInspection.apkEntries.isNotEmpty()) {
                    // Scenario A: Archive contains one or more APK files (ZIP with APK / XAPK / APKS)
                    onProgress(ConversionProgress(ConversionStage.EXTRACTING, 0.5f, "Extracting APK from archive..."))
                    finalApkFile = extractApkFromArchive(localSource, zipInspection)
                    detectedType = if (zipInspection.hasManifestJson) "XAPK" else "ZIP (APK Archive)"
                } else if (zipInspection.hasHtmlFiles) {
                    // Scenario B: HTML/Web project ZIP -> Package into standalone Web APK
                    onProgress(ConversionProgress(ConversionStage.PACKAGING, 0.5f, "Packaging Web/HTML into APK..."))
                    finalApkFile = packageWebToApk(localSource, customAppName, onProgress)
                    detectedType = "Web HTML to APK"
                } else {
                    // Scenario C: Generic ZIP with other assets/files
                    // If it contains an AndroidManifest.xml directly, it's an APK with a .zip extension!
                    if (zipInspection.hasAndroidManifest) {
                        onProgress(ConversionProgress(ConversionStage.SIGNING, 0.6f, "Recognized APK with ZIP extension..."))
                        finalApkFile = File(outputDir, "Converted_${System.currentTimeMillis()}.apk")
                        localSource.copyTo(finalApkFile, overwrite = true)
                        detectedType = "ZIP to APK"
                    } else {
                        // Package generic assets into Web runner APK
                        onProgress(ConversionProgress(ConversionStage.PACKAGING, 0.5f, "Packaging archive files into APK runner..."))
                        finalApkFile = packageWebToApk(localSource, customAppName, onProgress)
                        detectedType = "ZIP Package to APK"
                    }
                }
            } else {
                // Not a ZIP. Could be raw HTML or other file
                onProgress(ConversionProgress(ConversionStage.PACKAGING, 0.5f, "Packaging single file into APK..."))
                finalApkFile = packageSingleFileToApk(localSource, customAppName, onProgress)
                detectedType = "HTML to APK"
            }

            // 3. Verify and Extract metadata from final APK
            onProgress(ConversionProgress(ConversionStage.VERIFYING, 0.85f, "Verifying and reading APK metadata..."))
            val apkInfo = parseApkMetadata(finalApkFile, customAppName, detectedType)

            onProgress(ConversionProgress(ConversionStage.COMPLETE, 1.0f, "Conversion Complete!"))
            Result.success(apkInfo)
        } catch (e: Exception) {
            onProgress(ConversionProgress(ConversionStage.ERROR, 0f, e.localizedMessage ?: "Conversion error"))
            Result.failure(e)
        }
    }

    private fun getInputStream(sourceUri: Uri?, sourceFile: File?, assetName: String?): InputStream {
        return when {
            assetName != null -> {
                if (assetName.contains("/")) {
                    context.assets.open(assetName)
                } else {
                    context.assets.open("samples/$assetName")
                }
            }
            sourceFile != null -> sourceFile.inputStream()
            sourceUri != null -> context.contentResolver.openInputStream(sourceUri)
                ?: throw IllegalArgumentException("Cannot open file stream")
            else -> throw IllegalArgumentException("No source provided")
        }
    }

    private fun isZipFile(file: File): Boolean {
        file.inputStream().use {
            val header = ByteArray(4)
            val read = it.read(header)
            return read == 4 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()
        }
    }

    data class ZipInspectionResult(
        val apkEntries: List<String>,
        val hasManifestJson: Boolean,
        val hasHtmlFiles: Boolean,
        val hasAndroidManifest: Boolean,
        val xapkAppName: String? = null
    )

    private fun inspectZip(zipFile: File): ZipInspectionResult {
        val apkEntries = mutableListOf<String>()
        var hasManifestJson = false
        var hasHtmlFiles = false
        var hasAndroidManifest = false
        var xapkAppName: String? = null

        ZipFile(zipFile).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val name = entry.name.lowercase()
                if (name.endsWith(".apk")) {
                    apkEntries.add(entry.name)
                }
                if (name == "manifest.json") {
                    hasManifestJson = true
                    try {
                        val content = zip.getInputStream(entry).bufferedReader().readText()
                        val json = JSONObject(content)
                        if (json.has("name")) {
                            xapkAppName = json.getString("name")
                        }
                    } catch (_: Exception) {}
                }
                if (name.endsWith(".html") || name.endsWith(".htm")) {
                    hasHtmlFiles = true
                }
                if (name == "androidmanifest.xml") {
                    hasAndroidManifest = true
                }
            }
        }
        return ZipInspectionResult(apkEntries, hasManifestJson, hasHtmlFiles, hasAndroidManifest, xapkAppName)
    }

    private fun extractApkFromArchive(archiveFile: File, inspection: ZipInspectionResult): File {
        // Choose best APK: if base.apk exists, pick it. Otherwise pick the largest .apk
        ZipFile(archiveFile).use { zip ->
            var chosenEntry: ZipEntry? = null
            var maxSize = -1L

            for (entryName in inspection.apkEntries) {
                val entry = zip.getEntry(entryName) ?: continue
                if (entry.name.lowercase().contains("base.apk")) {
                    chosenEntry = entry
                    break
                }
                if (entry.size > maxSize) {
                    maxSize = entry.size
                    chosenEntry = entry
                }
            }

            val targetEntry = chosenEntry ?: zip.getEntry(inspection.apkEntries.first())
            val cleanName = File(targetEntry.name).name
            val destFile = File(outputDir, "Converted_${System.currentTimeMillis()}_$cleanName")

            zip.getInputStream(targetEntry).use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            return destFile
        }
    }

    private fun packageWebToApk(
        zipSource: File,
        customAppName: String?,
        onProgress: (ConversionProgress) -> Unit
    ): File {
        val extractedWebDir = File(tempDir, "extracted_web").apply { mkdirs() }

        // Unzip source files
        ZipFile(zipSource).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val target = File(extractedWebDir, entry.name)
                if (entry.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    zip.getInputStream(entry).use { input ->
                        target.outputStream().use { output -> input.copyTo(output) }
                    }
                }
            }
        }

        // If no index.html is in root, check if it's in a subdirectory
        val indexFile = File(extractedWebDir, "index.html")
        if (!indexFile.exists()) {
            val foundIndex = extractedWebDir.walkTopDown().firstOrNull { it.name.equals("index.html", ignoreCase = true) }
            if (foundIndex != null) {
                // Move contents from that directory to extractedWebDir
                val parentDir = foundIndex.parentFile
                if (parentDir != null && parentDir != extractedWebDir) {
                    parentDir.listFiles()?.forEach { file ->
                        file.copyRecursively(File(extractedWebDir, file.name), overwrite = true)
                    }
                }
            } else {
                // Generate default index.html that shows files
                indexFile.writeText(
                    """
                    <!DOCTYPE html>
                    <html>
                    <head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
                    <title>${customAppName ?: "Converted App"}</title>
                    <style>body{background:#0f172a;color:#fff;font-family:sans-serif;padding:24px;text-align:center;}</style>
                    </head>
                    <body>
                    <h1>${customAppName ?: "Converted APK App"}</h1>
                    <p>Web package converted successfully!</p>
                    </body>
                    </html>
                    """.trimIndent()
                )
            }
        }

        return assembleAndSignApk(extractedWebDir, customAppName, onProgress)
    }

    private fun packageSingleFileToApk(
        singleFile: File,
        customAppName: String?,
        onProgress: (ConversionProgress) -> Unit
    ): File {
        val webDir = File(tempDir, "single_web").apply { mkdirs() }
        val destHtml = File(webDir, "index.html")
        singleFile.copyTo(destHtml, overwrite = true)
        return assembleAndSignApk(webDir, customAppName, onProgress)
    }

    private fun assembleAndSignApk(
        webDir: File,
        customAppName: String?,
        onProgress: (ConversionProgress) -> Unit
    ): File {
        val unsignedApk = File(tempDir, "template_unsigned.apk")

        // 1. Copy base template APK to unsignedApk
        context.assets.open("template/base_web_template.apk").use { input ->
            unsignedApk.outputStream().use { output -> input.copyTo(output) }
        }

        // 2. Create intermediate APK with injected assets/www/
        val withAssetsApk = File(tempDir, "intermediate_with_assets.apk")
        ZipFile(unsignedApk).use { zipIn ->
            ZipOutputStream(withAssetsApk.outputStream().buffered()).use { zipOut ->
                // Copy existing non-www, non-meta-inf entries
                val inEntries = zipIn.entries()
                while (inEntries.hasMoreElements()) {
                    val entry = inEntries.nextElement()
                    val name = entry.name
                    if (!name.startsWith("assets/www/") && !name.startsWith("META-INF/")) {
                        zipOut.putNextEntry(ZipEntry(name))
                        zipIn.getInputStream(entry).use { it.copyTo(zipOut) }
                        zipOut.closeEntry()
                    }
                }

                // Add all files from webDir into assets/www/
                webDir.walkTopDown().forEach { file ->
                    if (file.isFile) {
                        val relPath = file.relativeTo(webDir).path.replace('\\', '/')
                        val entryName = "assets/www/$relPath"
                        zipOut.putNextEntry(ZipEntry(entryName))
                        file.inputStream().use { it.copyTo(zipOut) }
                        zipOut.closeEntry()
                    }
                }
            }
        }

        // 3. Sign the APK using pure Kotlin ApkSignerUtil
        onProgress(ConversionProgress(ConversionStage.SIGNING, 0.75f, "Signing APK with cryptographic signature..."))
        val safeName = (customAppName?.filter { it.isLetterOrDigit() || it == '_' } ?: "ConvertedApp").ifEmpty { "ConvertedApp" }
        val signedApk = File(outputDir, "${safeName}_${System.currentTimeMillis()}.apk")

        ApkSignerUtil.signApk(context, withAssetsApk, signedApk)

        return signedApk
    }

    private fun parseApkMetadata(
        apkFile: File,
        suggestedName: String?,
        sourceType: String
    ): ApkInfo {
        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or PackageManager.GET_SIGNATURES
        }

        val packageInfo = pm.getPackageArchiveInfo(apkFile.absolutePath, flags)
        val appInfo = packageInfo?.applicationInfo

        val extractedName = if (appInfo != null) {
            appInfo.sourceDir = apkFile.absolutePath
            appInfo.publicSourceDir = apkFile.absolutePath
            try {
                appInfo.loadLabel(pm).toString()
            } catch (_: Exception) {
                null
            }
        } else null

        val appName = suggestedName ?: extractedName ?: apkFile.nameWithoutExtension.removePrefix("Converted_")
        val packageName = packageInfo?.packageName ?: "com.converted.app"
        val versionName = packageInfo?.versionName ?: "1.0"
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            packageInfo?.longVersionCode ?: 1L
        } else {
            @Suppress("DEPRECATION")
            packageInfo?.versionCode?.toLong() ?: 1L
        }

        val minSdkVersion = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            appInfo?.minSdkVersion ?: 21
        } else {
            21
        }
        val targetSdkVersion = appInfo?.targetSdkVersion ?: 29

        val iconBitmap = if (appInfo != null) {
            try {
                drawableToBitmap(appInfo.loadIcon(pm))
            } catch (_: Exception) {
                null
            }
        } else null

        val permissions = packageInfo?.requestedPermissions?.toList() ?: emptyList()

        return ApkInfo(
            fileName = apkFile.name,
            filePath = apkFile.absolutePath,
            appName = appName,
            packageName = packageName,
            versionName = versionName,
            versionCode = versionCode,
            minSdkVersion = minSdkVersion,
            targetSdkVersion = targetSdkVersion,
            fileSizeBytes = apkFile.length(),
            formattedSize = formatBytes(apkFile.length()),
            iconBitmap = iconBitmap,
            permissions = permissions,
            conversionTimestamp = System.currentTimeMillis(),
            sourceType = sourceType
        )
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    private fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
        val format = DecimalFormat("#,##0.#")
        return "${format.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
    }
}
