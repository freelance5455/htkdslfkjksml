package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HavenDao {
    @Query("SELECT * FROM care_logs WHERE dateEpochDay = :epochDay ORDER BY timestamp DESC")
    fun observeCareLogsForDay(epochDay: Long): Flow<List<CareLogEntity>>

    @Query("SELECT * FROM care_logs ORDER BY timestamp DESC LIMIT 100")
    fun observeAllCareLogs(): Flow<List<CareLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCareLog(log: CareLogEntity)

    @Query("SELECT * FROM diary_entries ORDER BY timestamp DESC")
    fun observeDiaryEntries(): Flow<List<DiaryEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDiaryEntry(entry: DiaryEntryEntity)

    @Query("DELETE FROM diary_entries WHERE id = :id")
    suspend fun deleteDiaryEntry(id: Int)

    @Query("SELECT * FROM cycle_logs ORDER BY dateEpochDay DESC")
    fun observeCycleLogs(): Flow<List<CycleLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCycleLog(log: CycleLogEntity)

    @Query("SELECT * FROM vitality_logs ORDER BY dateEpochDay DESC")
    fun observeVitalityLogs(): Flow<List<VitalityLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVitalityLog(log: VitalityLogEntity)

    @Query("SELECT * FROM hormone_checks ORDER BY timestamp DESC LIMIT 20")
    fun observeHormoneChecks(): Flow<List<HormoneCheckEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHormoneCheck(check: HormoneCheckEntity)

    @Query("SELECT * FROM emergency_contacts ORDER BY id ASC")
    fun observeEmergencyContacts(): Flow<List<EmergencyContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmergencyContact(contact: EmergencyContactEntity)

    @Query("DELETE FROM emergency_contacts WHERE id = :id")
    suspend fun deleteEmergencyContact(id: Int)

    @Query("SELECT * FROM sos_messages ORDER BY timestamp DESC LIMIT 50")
    fun observeSosMessages(): Flow<List<SosMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSosMessage(message: SosMessageEntity)

    @Query("SELECT * FROM reminder_schedules")
    fun observeReminderSchedules(): Flow<List<ReminderScheduleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReminderSchedule(schedule: ReminderScheduleEntity)
}
