package com.example.data

import com.example.model.QuizHints
import com.example.model.QuizItem
import com.example.model.ZoomTarget

val QUIZ_ITEMS = listOf(
    // ==========================================
    // Level 1: Starter Icons (Easy • 1.0x PTS)
    // ==========================================
    QuizItem(
        id = "nike",
        name = "NIKE",
        cleanAnswer = "NIKE",
        category = "clothes",
        categoryLabel = "Fashion & Shoes",
        level = 1,
        difficulty = "Easy",
        zoom = ZoomTarget(x = 75f, y = 42f, initialScale = 4.5f, stage2Scale = 2.8f, stage3Scale = 1.7f),
        hints = QuizHints(
            clue1 = "Global sportswear giant with the famous slogan 'Just Do It'.",
            clue2 = "Named after Greek goddess of victory; logo designed by Carolyn Davidson in 1971."
        ),
        primaryColor = 0xFF0F172A,
        bgColor = 0xFFF8FAFC,
        accentColor = 0xFFFF5722,
        description = "The Nike Swoosh, one of the most recognized brand marks in human history.",
        logoType = "nike"
    ),
    QuizItem(
        id = "apple",
        name = "APPLE",
        cleanAnswer = "APPLE",
        category = "mobile",
        categoryLabel = "Mobile & Tech",
        level = 1,
        difficulty = "Easy",
        zoom = ZoomTarget(x = 68f, y = 36f, initialScale = 4.5f, stage2Scale = 2.8f, stage3Scale = 1.7f),
        hints = QuizHints(
            clue1 = "California tech giant famous for the iPhone, iPad, and Mac.",
            clue2 = "The iconic silhouette features a leaf at the top and a single bite taken out of the right side."
        ),
        primaryColor = 0xFF1E293B,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF64748B,
        description = "The monochrome Apple logo, symbol of the world's most valuable technology company.",
        logoType = "apple"
    ),
    QuizItem(
        id = "youtube",
        name = "YOUTUBE",
        cleanAnswer = "YOUTUBE",
        category = "app_game",
        categoryLabel = "Apps & Video",
        level = 1,
        difficulty = "Easy",
        zoom = ZoomTarget(x = 52f, y = 50f, initialScale = 4.4f, stage2Scale = 2.8f, stage3Scale = 1.7f),
        hints = QuizHints(
            clue1 = "The world's largest video streaming platform, home to billions of videos.",
            clue2 = "Features a white triangular play symbol inside a sleek red rounded rectangle."
        ),
        primaryColor = 0xFFFF0000,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF282828,
        description = "The YouTube play button logo, synonymous with online creator entertainment.",
        logoType = "youtube"
    ),
    QuizItem(
        id = "mcdonalds",
        name = "MCDONALDS",
        cleanAnswer = "MCDONALDS",
        aliases = listOf("MC DONALDS", "MCDONALD"),
        category = "company",
        categoryLabel = "Company Logo",
        level = 1,
        difficulty = "Easy",
        zoom = ZoomTarget(x = 50f, y = 35f, initialScale = 4.6f, stage2Scale = 2.9f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "World famous fast food chain famous for the Big Mac and Happy Meals.",
            clue2 = "The Golden Arches that form the letter 'M' on a vivid red backdrop."
        ),
        primaryColor = 0xFFFFC72C,
        bgColor = 0xFFDA291C,
        accentColor = 0xFF27251F,
        description = "McDonald's Golden Arches, one of the most prominent fast food trademarks worldwide.",
        logoType = "mcdonalds"
    ),
    QuizItem(
        id = "discord",
        name = "DISCORD",
        cleanAnswer = "DISCORD",
        category = "app_game",
        categoryLabel = "Apps & Games",
        level = 1,
        difficulty = "Easy",
        zoom = ZoomTarget(x = 42f, y = 52f, initialScale = 4.8f, stage2Scale = 3.1f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "The primary chat, voice, and streaming hub for gamers and online communities.",
            clue2 = "The mascot is named 'Clyde', a friendly controller-like robot face."
        ),
        primaryColor = 0xFF5865F2,
        bgColor = 0xFF2B2D31,
        accentColor = 0xFFFFFFFF,
        description = "Discord's Clyde robot emblem, uniting millions of gamers in servers and voice calls.",
        logoType = "discord"
    ),
    QuizItem(
        id = "mrbeast-starter",
        name = "MRBEAST",
        cleanAnswer = "MRBEAST",
        aliases = listOf("MR BEAST"),
        category = "youtuber",
        categoryLabel = "YouTubers Logo",
        level = 1,
        difficulty = "Easy",
        zoom = ZoomTarget(x = 58f, y = 42f, initialScale = 4.4f, stage2Scale = 2.8f, stage3Scale = 1.7f),
        hints = QuizHints(
            clue1 = "The most-subscribed individual YouTuber on earth, known for massive philanthropic stunts.",
            clue2 = "A ferocious blue wildcat/panther with a neon pink lightning bolt and sharp fangs."
        ),
        primaryColor = 0xFF00C8FF,
        bgColor = 0xFF0A0F1D,
        accentColor = 0xFFFF007F,
        description = "MrBeast's electric wildcat insignia, reigning over hundreds of millions of YouTube subscribers.",
        logoType = "mrbeast"
    ),

    // ==========================================
    // Level 2: Tech & Mobile Titans (Medium • 1.25x PTS)
    // ==========================================
    QuizItem(
        id = "google",
        name = "GOOGLE",
        cleanAnswer = "GOOGLE",
        category = "company",
        categoryLabel = "Company Logo",
        level = 2,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 72f, y = 48f, initialScale = 4.8f, stage2Scale = 3.1f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "The world's dominant search engine and creator of Android OS.",
            clue2 = "A circular capital 'G' rendered with four distinct vibrant colors: blue, red, yellow, and green."
        ),
        primaryColor = 0xFF4285F4,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFFEA4335,
        description = "The multi-colored Google 'G', connecting billions to internet knowledge every minute.",
        logoType = "google"
    ),
    QuizItem(
        id = "samsung",
        name = "SAMSUNG",
        cleanAnswer = "SAMSUNG",
        category = "mobile",
        categoryLabel = "Mobile Company",
        level = 2,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 35f, y = 48f, initialScale = 4.8f, stage2Scale = 3.0f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "South Korean tech giant known for Galaxy smartphones, OLED displays, and electronics.",
            clue2 = "Features bold white typography tilted dynamically inside an iconic horizontal blue oval."
        ),
        primaryColor = 0xFF1428A0,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF000000,
        description = "Samsung's dynamic tilted blue ellipse, leader in mobile Galaxy smartphones and memory chips.",
        logoType = "samsung"
    ),
    QuizItem(
        id = "tesla",
        name = "TESLA",
        cleanAnswer = "TESLA",
        category = "car",
        categoryLabel = "Car & Tech",
        level = 2,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 50f, y = 28f, initialScale = 5.0f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Electric vehicle and clean energy leader led by Elon Musk.",
            clue2 = "The emblem is a stylized capital 'T' representing a cross-section of an electric motor."
        ),
        primaryColor = 0xFFE82127,
        bgColor = 0xFF0F172A,
        accentColor = 0xFFFFFFFF,
        description = "Tesla's shield-sword 'T' emblem, symbol of the electric vehicle revolution.",
        logoType = "tesla"
    ),
    QuizItem(
        id = "spotify",
        name = "SPOTIFY",
        cleanAnswer = "SPOTIFY",
        category = "app_game",
        categoryLabel = "Apps & Music",
        level = 2,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 55f, y = 45f, initialScale = 4.8f, stage2Scale = 3.0f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Swedish music streaming service boasting over 600 million monthly active listeners.",
            clue2 = "A vibrant neon green circle with three tilted horizontal curved soundwave lines."
        ),
        primaryColor = 0xFF1DB954,
        bgColor = 0xFF121212,
        accentColor = 0xFFFFFFFF,
        description = "Spotify's iconic neon green circle with sound waves, the soundtrack of modern streaming.",
        logoType = "spotify"
    ),
    QuizItem(
        id = "xiaomi",
        name = "XIAOMI",
        cleanAnswer = "XIAOMI",
        category = "mobile",
        categoryLabel = "Mobile Company",
        level = 2,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 48f, y = 50f, initialScale = 4.8f, stage2Scale = 3.0f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Huge smartphone and consumer electronics manufacturer from Beijing.",
            clue2 = "Known for their signature bright orange rounded squircle containing the stylized letters 'MI'."
        ),
        primaryColor = 0xFFFF6900,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF222222,
        description = "Xiaomi's vibrant orange squircle emblem, standing for 'Mobile Internet' across worldwide phones.",
        logoType = "xiaomi"
    ),
    QuizItem(
        id = "microsoft",
        name = "MICROSOFT",
        cleanAnswer = "MICROSOFT",
        category = "company",
        categoryLabel = "Company Logo",
        level = 2,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.0f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Tech titan behind Windows, Xbox, Azure, and Microsoft 365.",
            clue2 = "Four flat color squares arranged in a 2x2 grid: red, green, blue, and yellow."
        ),
        primaryColor = 0xFF00A4EF,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF7FBA00,
        description = "Microsoft's 4-tile quadrant logo, representing diverse software and hardware ecosystems.",
        logoType = "microsoft"
    ),

    // ==========================================
    // Level 3: Creator Legends (Medium • 1.25x PTS)
    // ==========================================
    QuizItem(
        id = "pewdiepie",
        name = "PEWDIEPIE",
        cleanAnswer = "PEWDIEPIE",
        aliases = listOf("PEW DIE PIE", "FELIX KJELLBERG"),
        category = "youtuber",
        categoryLabel = "YouTubers Logo",
        level = 3,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 50f, y = 52f, initialScale = 5.0f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Swedish creator Felix Kjellberg, one of the earliest megastars of YouTube gaming.",
            clue2 = "Famous for the 'Brofist' and the hypnotic red-and-black wavy optical lines."
        ),
        primaryColor = 0xFFFF0044,
        bgColor = 0xFF000000,
        accentColor = 0xFFFFFFFF,
        description = "PewDiePie's signature black and red psychedelic wave pattern and Brofist hallmark.",
        logoType = "pewdiepie"
    ),
    QuizItem(
        id = "dude-perfect",
        name = "DUDE PERFECT",
        cleanAnswer = "DUDEPERFECT",
        aliases = listOf("DUDE PERFECT", "DP"),
        category = "youtuber",
        categoryLabel = "YouTubers Logo",
        level = 3,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 62f, y = 40f, initialScale = 4.8f, stage2Scale = 3.0f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Group of five college friends famous for crazy sports trick shots and stereotyping battles.",
            clue2 = "Features interlocking cyan/turquoise and orange letters 'd' and 'p'."
        ),
        primaryColor = 0xFF00B4D8,
        bgColor = 0xFF0A0A0A,
        accentColor = 0xFFF77F00,
        description = "Dude Perfect's high-energy cyan and orange 'dp' emblem, masters of impossible trick shots.",
        logoType = "dude-perfect"
    ),
    QuizItem(
        id = "mkbhd",
        name = "MKBHD",
        cleanAnswer = "MKBHD",
        aliases = listOf("MARQUES BROWNLEE"),
        category = "youtuber",
        categoryLabel = "YouTubers Logo",
        level = 3,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 52f, y = 50f, initialScale = 4.9f, stage2Scale = 3.1f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "The world's premier consumer tech reviewer, Marques Brownlee.",
            clue2 = "A crisp geometric emblem of red, white, and matte black triangles forming an M-shape."
        ),
        primaryColor = 0xFFFF1E27,
        bgColor = 0xFF121212,
        accentColor = 0xFFFFFFFF,
        description = "MKBHD's clean matte red and black geometric emblem, signature of Marques Brownlee.",
        logoType = "mkbhd"
    ),
    QuizItem(
        id = "markiplier",
        name = "MARKIPLIER",
        cleanAnswer = "MARKIPLIER",
        category = "youtuber",
        categoryLabel = "YouTubers Logo",
        level = 3,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 50f, y = 55f, initialScale = 4.8f, stage2Scale = 3.0f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "Popular horror gaming creator Mark Fischbach, famous for Five Nights at Freddy's playthroughs.",
            clue2 = "His mascot is Wilford Warfstache, signified by an iconic bright pink cartoon mustache."
        ),
        primaryColor = 0xFFFF1493,
        bgColor = 0xFF0A0A0A,
        accentColor = 0xFFFFFFFF,
        description = "Markiplier's iconic hot pink Warfstache mustache and signature 'M' insignia.",
        logoType = "markiplier"
    ),
    QuizItem(
        id = "sidemen",
        name = "SIDEMEN",
        cleanAnswer = "SIDEMEN",
        aliases = listOf("THE SIDEMEN", "SDMN"),
        category = "youtuber",
        categoryLabel = "YouTubers Logo",
        level = 3,
        difficulty = "Medium",
        zoom = ZoomTarget(x = 50f, y = 48f, initialScale = 5.0f, stage2Scale = 3.2f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "British YouTube supergroup featuring KSI, Miniminter, W2S, Zerkaa, Behzinga, TBJZL, and Vikkstar123.",
            clue2 = "Their brand uses the Roman numerals XIX (19) denoting their founding year and brand identity."
        ),
        primaryColor = 0xFFFFFFFF,
        bgColor = 0xFF050505,
        accentColor = 0xFFE11D48,
        description = "The Sidemen's XIX emblem, UK entertainment titans conquering YouTube culture.",
        logoType = "sidemen"
    ),

    // ==========================================
    // Level 4: Supercars & Autos (Hard • 1.55x PTS)
    // ==========================================
    QuizItem(
        id = "ferrari",
        name = "FERRARI",
        cleanAnswer = "FERRARI",
        category = "car",
        categoryLabel = "Supercars",
        level = 4,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 49f, y = 45f, initialScale = 5.2f, stage2Scale = 3.3f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "Maranello's most storied luxury sports car and Formula 1 manufacturer.",
            clue2 = "The 'Cavallino Rampante' (black prancing stallion) on a Canary yellow shield with Italian tricolor."
        ),
        primaryColor = 0xFFFF2800,
        bgColor = 0xFF1A1A1A,
        accentColor = 0xFFFFE600,
        description = "Ferrari's legendary prancing horse crest, symbol of Italian racing perfection.",
        logoType = "ferrari"
    ),
    QuizItem(
        id = "lamborghini",
        name = "LAMBORGHINI",
        cleanAnswer = "LAMBORGHINI",
        category = "car",
        categoryLabel = "Supercars",
        level = 4,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 52f, initialScale = 5.3f, stage2Scale = 3.4f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "Sant'Agata Bolognese automaker famous for the Countach, Aventador, and Revuelto.",
            clue2 = "A ferocious raging golden bull charging forward inside a sharp black and gold shield."
        ),
        primaryColor = 0xFFD4AF37,
        bgColor = 0xFF0A0A0A,
        accentColor = 0xFFFFFFFF,
        description = "Lamborghini's ferocious golden bull shield, roaring with V12 supercar power.",
        logoType = "lamborghini"
    ),
    QuizItem(
        id = "bmw",
        name = "BMW",
        cleanAnswer = "BMW",
        category = "car",
        categoryLabel = "Car Brand",
        level = 4,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.2f, stage2Scale = 3.2f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "Bavarian luxury automaker renowned as 'The Ultimate Driving Machine'.",
            clue2 = "A circular roundel featuring alternating blue and white quadrants of the Bavarian flag."
        ),
        primaryColor = 0xFF0066B1,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF000000,
        description = "The BMW Bavarian propeller roundel, emblem of precision German engineering.",
        logoType = "bmw"
    ),
    QuizItem(
        id = "mercedes",
        name = "MERCEDES",
        cleanAnswer = "MERCEDES",
        aliases = listOf("MERCEDES BENZ", "BENZ"),
        category = "car",
        categoryLabel = "Car Brand",
        level = 4,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.2f, stage2Scale = 3.3f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "Stuttgart automotive pioneer whose slogan is 'The Best or Nothing'.",
            clue2 = "A shining silver three-pointed star enclosed within a circular chrome ring."
        ),
        primaryColor = 0xFF94A3B8,
        bgColor = 0xFF0A0E1A,
        accentColor = 0xFFFFFFFF,
        description = "The Mercedes-Benz three-pointed star, representing mastery over land, sea, and air.",
        logoType = "mercedes"
    ),
    QuizItem(
        id = "audi",
        name = "AUDI",
        cleanAnswer = "AUDI",
        category = "car",
        categoryLabel = "Car Brand",
        level = 4,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.0f, stage2Scale = 3.1f, stage3Scale = 1.8f),
        hints = QuizHints(
            clue1 = "German manufacturer known for Quattro all-wheel-drive technology.",
            clue2 = "Four interlocking silver rings symbolizing the merger of four motor companies in 1932."
        ),
        primaryColor = 0xFFBB0A30,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF27272A,
        description = "Audi's iconic four interlocking rings, emblem of automotive unity and Quattro technology.",
        logoType = "audi"
    ),

    // ==========================================
    // Level 5: Fashion & Streetwear (Hard • 1.55x PTS)
    // ==========================================
    QuizItem(
        id = "adidas",
        name = "ADIDAS",
        cleanAnswer = "ADIDAS",
        category = "clothes",
        categoryLabel = "Clothes & Shoes",
        level = 5,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 48f, y = 42f, initialScale = 5.2f, stage2Scale = 3.3f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "German sportswear powerhouse founded by Adolf 'Adi' Dassler.",
            clue2 = "Famous worldwide as 'The Brand with the Three Stripes', forming a mountain shape."
        ),
        primaryColor = 0xFF000000,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF3B82F6,
        description = "The Adidas 3-stripe mountain, symbolizing overcoming challenges in sports.",
        logoType = "adidas"
    ),
    QuizItem(
        id = "gucci",
        name = "GUCCI",
        cleanAnswer = "GUCCI",
        category = "clothes",
        categoryLabel = "Luxury Clothes",
        level = 5,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.4f, stage2Scale = 3.4f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "Italian luxury fashion house founded by Guccio Gucci in Florence in 1921.",
            clue2 = "Two interlocking capital 'G' letters facing each other, one inverted."
        ),
        primaryColor = 0xFF005522,
        bgColor = 0xFFFBFBFB,
        accentColor = 0xFF18181B,
        description = "Gucci's interlocking double-G monogram, hallmark of Italian haute couture and luxury.",
        logoType = "gucci"
    ),
    QuizItem(
        id = "supreme",
        name = "SUPREME",
        cleanAnswer = "SUPREME",
        category = "clothes",
        categoryLabel = "Streetwear",
        level = 5,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 48f, y = 50f, initialScale = 5.3f, stage2Scale = 3.3f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "New York skateboarding and hype streetwear brand with massive resale culture.",
            clue2 = "A bold red rectangular box logo with white italicized Futura Bold typography."
        ),
        primaryColor = 0xFFFF0000,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFFDA291C,
        description = "Supreme's iconic red box logo, the king of modern streetwear culture.",
        logoType = "supreme"
    ),
    QuizItem(
        id = "puma",
        name = "PUMA",
        cleanAnswer = "PUMA",
        category = "clothes",
        categoryLabel = "Sportswear",
        level = 5,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 58f, y = 42f, initialScale = 5.2f, stage2Scale = 3.2f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "Athletic shoe and apparel brand founded by Rudolf Dassler, brother of Adidas's founder.",
            clue2 = "A sleek feline cougar leaping gracefully through the air."
        ),
        primaryColor = 0xFF000000,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFFE11D48,
        description = "Puma's leaping wildcat, symbolizing agility and athletic speed.",
        logoType = "puma"
    ),
    QuizItem(
        id = "louis-vuitton",
        name = "LOUIS VUITTON",
        cleanAnswer = "LOUISVUITTON",
        aliases = listOf("LOUIS VUITTON", "LV"),
        category = "clothes",
        categoryLabel = "Luxury Clothes",
        level = 5,
        difficulty = "Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.4f, stage2Scale = 3.4f, stage3Scale = 1.9f),
        hints = QuizHints(
            clue1 = "French luxury trunkmaker and world's most valuable fashion house.",
            clue2 = "The interlocking 'L' and 'V' monogram accompanied by four-petal floral motifs."
        ),
        primaryColor = 0xFF6D4C41,
        bgColor = 0xFF2B1810,
        accentColor = 0xFFD4AF37,
        description = "Louis Vuitton's gold monogram, symbol of Parisian craftsmanship and luxury.",
        logoType = "louis-vuitton"
    ),

    // ==========================================
    // Level 6: Apps & Gaming Arena (Very Hard • 1.9x PTS)
    // ==========================================
    QuizItem(
        id = "minecraft",
        name = "MINECRAFT",
        cleanAnswer = "MINECRAFT",
        aliases = listOf("CREEPER", "MOJANG"),
        category = "app_game",
        categoryLabel = "Games",
        level = 6,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.6f, stage2Scale = 3.5f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "The best-selling video game in history with over 300 million copies sold.",
            clue2 = "Signature icon is the frowning green pixelated face of the hissing Creeper mob."
        ),
        primaryColor = 0xFF22C55E,
        bgColor = 0xFF14532D,
        accentColor = 0xFF000000,
        description = "Minecraft's explosive Creeper face, defining a generation of sandbox block builders.",
        logoType = "minecraft"
    ),
    QuizItem(
        id = "roblox",
        name = "ROBLOX",
        cleanAnswer = "ROBLOX",
        category = "app_game",
        categoryLabel = "Games Platform",
        level = 6,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.6f, stage2Scale = 3.5f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Massive online sandbox creation platform home to Adopt Me and Blox Fruits.",
            clue2 = "A distinctive tilted square Cheez-It shape with a hollow square hole in the center."
        ),
        primaryColor = 0xFF000000,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFFE11D48,
        description = "Roblox's tilted square icon, the hub for user-generated games and virtual hangouts.",
        logoType = "roblox"
    ),
    QuizItem(
        id = "tiktok",
        name = "TIKTOK",
        cleanAnswer = "TIKTOK",
        aliases = listOf("TIK TOK"),
        category = "app_game",
        categoryLabel = "Social Video",
        level = 6,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 48f, initialScale = 5.7f, stage2Scale = 3.6f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "ByteDance's viral short-form video app with the hyper-personalized 'For You' algorithm.",
            clue2 = "A stylized musical note layered with chromatic aberration cyan and neon magenta 3D shadows."
        ),
        primaryColor = 0xFF25F4EE,
        bgColor = 0xFF010101,
        accentColor = 0xFFFE2C55,
        description = "TikTok's chromatic 3D musical note, soundtracking trends across global feeds.",
        logoType = "tiktok"
    ),
    QuizItem(
        id = "instagram",
        name = "INSTAGRAM",
        cleanAnswer = "INSTAGRAM",
        category = "app_game",
        categoryLabel = "Apps",
        level = 6,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.7f, stage2Scale = 3.6f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Meta's premier photo and reel sharing social media network.",
            clue2 = "A minimalist camera outline on a vibrant gradient of purple, pink, orange, and yellow."
        ),
        primaryColor = 0xFFE1306C,
        bgColor = 0xFF833AB4,
        accentColor = 0xFFFCAF45,
        description = "Instagram's sunset gradient camera lens, capturing photos and stories around the world.",
        logoType = "instagram"
    ),
    QuizItem(
        id = "steam",
        name = "STEAM",
        cleanAnswer = "STEAM",
        category = "app_game",
        categoryLabel = "Games & Store",
        level = 6,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.7f, stage2Scale = 3.6f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Valve Corporation's digital distribution platform dominating PC gaming.",
            clue2 = "A locomotive steam engine piston and crank arm connecting two wheels."
        ),
        primaryColor = 0xFF171A21,
        bgColor = 0xFF1B2838,
        accentColor = 0xFF66C0F4,
        description = "Steam's mechanical locomotive piston insignia, powering PC gaming for decades.",
        logoType = "steam"
    ),
    QuizItem(
        id = "playstation",
        name = "PLAYSTATION",
        cleanAnswer = "PLAYSTATION",
        aliases = listOf("PS", "SONY PLAYSTATION"),
        category = "app_game",
        categoryLabel = "Gaming Console",
        level = 6,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 48f, y = 50f, initialScale = 5.6f, stage2Scale = 3.5f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Sony's historic home console brand behind PS1 through PS5.",
            clue2 = "An upright red 'P' casting a colorful horizontal 'S' shadow in yellow, teal, and blue."
        ),
        primaryColor = 0xFF003791,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFFE4002B,
        description = "The classic PlayStation PS mark designed by Manabu Sakamoto, an icon of gaming history.",
        logoType = "playstation"
    ),

    // ==========================================
    // Level 7: Global Powerhouses (Very Hard • 1.9x PTS)
    // ==========================================
    QuizItem(
        id = "netflix",
        name = "NETFLIX",
        cleanAnswer = "NETFLIX",
        category = "app_game",
        categoryLabel = "Entertainment",
        level = 7,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 48f, initialScale = 5.8f, stage2Scale = 3.6f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Global streaming giant with famous 'Ta-Dum' sound effect.",
            clue2 = "The iconic curved red ribbon forming the single capital letter 'N'."
        ),
        primaryColor = 0xFFE50914,
        bgColor = 0xFF000000,
        accentColor = 0xFFB81D24,
        description = "Netflix's dramatic red ribbon 'N', welcoming viewers with the signature Ta-Dum chord.",
        logoType = "netflix"
    ),
    QuizItem(
        id = "starbucks",
        name = "STARBUCKS",
        cleanAnswer = "STARBUCKS",
        category = "company",
        categoryLabel = "Company Logo",
        level = 7,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 38f, initialScale = 5.8f, stage2Scale = 3.7f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Seattle-born worldwide coffeehouse chain famous for Frappuccinos and espresso drinks.",
            clue2 = "A green circular emblem featuring a crowned twin-tailed mermaid (Siren)."
        ),
        primaryColor = 0xFF00704A,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF27251F,
        description = "Starbucks's emerald green Siren mermaid, brewing coffee for millions every morning.",
        logoType = "starbucks"
    ),
    QuizItem(
        id = "twitch",
        name = "TWITCH",
        cleanAnswer = "TWITCH",
        category = "app_game",
        categoryLabel = "Livestreaming",
        level = 7,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 52f, y = 48f, initialScale = 5.8f, stage2Scale = 3.6f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Amazon's live streaming platform that dominates esports, gaming, and creator broadcasts.",
            clue2 = "A vivid purple angular chat bubble mascot with two black rectangular eyes."
        ),
        primaryColor = 0xFF9146FF,
        bgColor = 0xFF0E0E10,
        accentColor = 0xFFFFFFFF,
        description = "Twitch's iconic Glitch chat bubble, home of live game streaming.",
        logoType = "twitch"
    ),
    QuizItem(
        id = "red-bull",
        name = "RED BULL",
        cleanAnswer = "REDBULL",
        aliases = listOf("RED BULL"),
        category = "company",
        categoryLabel = "Company Logo",
        level = 7,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 5.8f, stage2Scale = 3.7f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Energy drink empire and extreme sports powerhouse with multiple F1 world championships.",
            clue2 = "Two charging red bulls locking horns in front of a brilliant golden-yellow sun."
        ),
        primaryColor = 0xFFCC0000,
        bgColor = 0xFF001A4D,
        accentColor = 0xFFFFCC00,
        description = "Red Bull's colliding charging bulls and sun, giving wings to extreme athletes and F1 champions.",
        logoType = "red-bull"
    ),
    QuizItem(
        id = "nasa",
        name = "NASA",
        cleanAnswer = "NASA",
        category = "company",
        categoryLabel = "Space & Science",
        level = 7,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 58f, y = 38f, initialScale = 5.9f, stage2Scale = 3.7f, stage3Scale = 2.1f),
        hints = QuizHints(
            clue1 = "United States agency behind lunar Apollo missions and the James Webb Space Telescope.",
            clue2 = "The famous 'meatball' emblem: spherical blue cosmos with stars and an aerodynamic red wing."
        ),
        primaryColor = 0xFF0B3D91,
        bgColor = 0xFF061434,
        accentColor = 0xFFFC3D21,
        description = "NASA's meatball insignia, carrying human aspirations to Mars and deep space.",
        logoType = "nasa"
    ),
    QuizItem(
        id = "pepsi",
        name = "PEPSI",
        cleanAnswer = "PEPSI",
        aliases = listOf("PEPSI COLA"),
        category = "company",
        categoryLabel = "Beverages",
        level = 7,
        difficulty = "Very Hard",
        zoom = ZoomTarget(x = 50f, y = 46f, initialScale = 5.8f, stage2Scale = 3.6f, stage3Scale = 2.0f),
        hints = QuizHints(
            clue1 = "Worldwide cola beverage titan, arch-rival of Coca-Cola.",
            clue2 = "A spherical globe divided into a top red wave, middle white stripe, and bottom royal blue wave."
        ),
        primaryColor = 0xFF004B93,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFFE32934,
        description = "Pepsi's dynamic spherical globe emblem of red, white, and blue waves.",
        logoType = "pepsi"
    ),

    // ==========================================
    // Level 8: Cyber Empires & Socials (Extreme • 2.4x PTS)
    // ==========================================
    QuizItem(
        id = "reddit",
        name = "REDDIT",
        cleanAnswer = "REDDIT",
        category = "app_game",
        categoryLabel = "Social Discussion",
        level = 8,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 60f, y = 35f, initialScale = 6.2f, stage2Scale = 3.8f, stage3Scale = 2.1f),
        hints = QuizHints(
            clue1 = "The 'front page of the internet', famous for subreddits, karma points, and AMAs.",
            clue2 = "Mascot is 'Snoo', an alien with a curved antenna, orange-red eyes, and a cheerful smile."
        ),
        primaryColor = 0xFFFF4500,
        bgColor = 0xFF0E1113,
        accentColor = 0xFFFFFFFF,
        description = "Reddit's Snoo alien emblem, representing millions of online community discussions.",
        logoType = "reddit"
    ),
    QuizItem(
        id = "whatsapp",
        name = "WHATSAPP",
        cleanAnswer = "WHATSAPP",
        aliases = listOf("WHATASPP", "WHATTSAPP"),
        category = "mobile",
        categoryLabel = "Messaging Network",
        level = 8,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 42f, y = 42f, initialScale = 6.3f, stage2Scale = 3.9f, stage3Scale = 2.1f),
        hints = QuizHints(
            clue1 = "World's most popular encrypted mobile messaging service with over 2 billion users.",
            clue2 = "A green speech bubble badge enclosing a vintage telephone handset tilted at 45 degrees."
        ),
        primaryColor = 0xFF25D366,
        bgColor = 0xFF128C7E,
        accentColor = 0xFFFFFFFF,
        description = "WhatsApp's green speech bubble phone receiver, connecting billions in chat.",
        logoType = "whatsapp"
    ),
    QuizItem(
        id = "snapchat",
        name = "SNAPCHAT",
        cleanAnswer = "SNAPCHAT",
        aliases = listOf("SNAP"),
        category = "mobile",
        categoryLabel = "Ephemeral Social",
        level = 8,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 46f, initialScale = 6.2f, stage2Scale = 3.8f, stage3Scale = 2.1f),
        hints = QuizHints(
            clue1 = "Pioneered vanishing photo snaps, AR selfie lenses, and Snap streaks.",
            clue2 = "A white ghost silhouette with stick arms named 'Ghostface Chillah' on radiant yellow."
        ),
        primaryColor = 0xFFFFFC00,
        bgColor = 0xFFFFFC00,
        accentColor = 0xFF000000,
        description = "Snapchat's famous white ghost silhouette on neon yellow backdrop.",
        logoType = "snapchat"
    ),
    QuizItem(
        id = "telegram",
        name = "TELEGRAM",
        cleanAnswer = "TELEGRAM",
        category = "mobile",
        categoryLabel = "Cloud Messaging",
        level = 8,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 55f, y = 45f, initialScale = 6.2f, stage2Scale = 3.8f, stage3Scale = 2.1f),
        hints = QuizHints(
            clue1 = "Pavel Durov's cloud-based messaging platform renowned for massive public channels and bots.",
            clue2 = "A minimalist white paper airplane soaring upward inside a calm sky-blue circular badge."
        ),
        primaryColor = 0xFF2AABEE,
        bgColor = 0xFF17212B,
        accentColor = 0xFFFFFFFF,
        description = "Telegram's soaring paper airplane in blue orbit, emblem of rapid cloud communication.",
        logoType = "telegram"
    ),
    QuizItem(
        id = "github",
        name = "GITHUB",
        cleanAnswer = "GITHUB",
        aliases = listOf("GIT HUB"),
        category = "company",
        categoryLabel = "Developer Platform",
        level = 8,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 52f, y = 48f, initialScale = 6.4f, stage2Scale = 4.0f, stage3Scale = 2.2f),
        hints = QuizHints(
            clue1 = "The home of open source code repositories, commits, and pull requests.",
            clue2 = "The silhouette of an 'Octocat' — part cat, part octopus with five tentacles."
        ),
        primaryColor = 0xFF24292F,
        bgColor = 0xFF0D1117,
        accentColor = 0xFFF0F6FC,
        description = "GitHub's Octocat silhouette, uniting software developers building the future of code.",
        logoType = "github"
    ),
    QuizItem(
        id = "twitter",
        name = "TWITTER",
        cleanAnswer = "TWITTER",
        aliases = listOf("X", "X CORP"),
        category = "app_game",
        categoryLabel = "Microblogging",
        level = 8,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 6.4f, stage2Scale = 4.0f, stage3Scale = 2.2f),
        hints = QuizHints(
            clue1 = "Global microblogging network transformed into the everything app by Elon Musk.",
            clue2 = "A bold, modern monochrome capital letter 'X' formed by diagonal intersecting bars."
        ),
        primaryColor = 0xFFFFFFFF,
        bgColor = 0xFF000000,
        accentColor = 0xFF1D9BF0,
        description = "The minimalist monochrome 'X' mark, modern identity of the global town square.",
        logoType = "twitter"
    ),

    // ==========================================
    // Level 9: Apex Hypercars & Horology (Extreme • 2.4x PTS)
    // ==========================================
    QuizItem(
        id = "bugatti",
        name = "BUGATTI",
        cleanAnswer = "BUGATTI",
        category = "car",
        categoryLabel = "French Hypercars",
        level = 9,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 45f, initialScale = 6.5f, stage2Scale = 4.0f, stage3Scale = 2.2f),
        hints = QuizHints(
            clue1 = "Molsheim atelier that shattered production speed barriers with the Veyron and Chiron.",
            clue2 = "An oval red enamel badge studded with 60 silver pearls and Ettore Bugatti's 'EB' initials."
        ),
        primaryColor = 0xFFDC2626,
        bgColor = 0xFF111827,
        accentColor = 0xFFF8FAFC,
        description = "Bugatti's historic 60-pearl red oval emblem, pinnacle of bespoke hypercar craftsmanship.",
        logoType = "bugatti"
    ),
    QuizItem(
        id = "rolex",
        name = "ROLEX",
        cleanAnswer = "ROLEX",
        category = "clothes",
        categoryLabel = "Haute Horlogerie",
        level = 9,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 72f, y = 32f, initialScale = 6.6f, stage2Scale = 4.1f, stage3Scale = 2.3f),
        hints = QuizHints(
            clue1 = "Geneva's legendary luxury watch brand celebrated for the Submariner and Cosmograph Daytona.",
            clue2 = "A 5-pointed golden coronet crown with circular jewel beads placed atop deep emerald green."
        ),
        primaryColor = 0xFF006039,
        bgColor = 0xFF042416,
        accentColor = 0xFFE5B128,
        description = "The five-pointed gold coronet crown of Rolex, benchmark of luxury watchmaking.",
        logoType = "rolex"
    ),
    QuizItem(
        id = "cartier",
        name = "CARTIER",
        cleanAnswer = "CARTIER",
        category = "clothes",
        categoryLabel = "Fine Jewelry",
        level = 9,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 6.5f, stage2Scale = 4.0f, stage3Scale = 2.2f),
        hints = QuizHints(
            clue1 = "Parisian jeweler hailed as 'The Jeweler of Kings and King of Jewelers'.",
            clue2 = "Signature crimson red box identity and interlocking cursive double-C crest."
        ),
        primaryColor = 0xFFB91C1C,
        bgColor = 0xFF450A0A,
        accentColor = 0xFFE2E8F0,
        description = "Cartier's intertwined royal double-C monogram in precious gold and crimson.",
        logoType = "cartier"
    ),
    QuizItem(
        id = "bentley",
        name = "BENTLEY",
        cleanAnswer = "BENTLEY",
        category = "car",
        categoryLabel = "British Grand Tourers",
        level = 9,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 48f, initialScale = 6.5f, stage2Scale = 4.0f, stage3Scale = 2.2f),
        hints = QuizHints(
            clue1 = "Crewe manufacturer of the handcrafted Continental GT and Flying Spur.",
            clue2 = "A pair of outstretched bird wings framing a central capital letter 'B'."
        ),
        primaryColor = 0xFF044026,
        bgColor = 0xFF0A150F,
        accentColor = 0xFFE2E8F0,
        description = "The Winged 'B' emblem of Bentley Motors, heritage of British luxury speed.",
        logoType = "bentley"
    ),
    QuizItem(
        id = "aston-martin",
        name = "ASTON MARTIN",
        cleanAnswer = "ASTONMARTIN",
        aliases = listOf("ASTON MARTIN", "AM"),
        category = "car",
        categoryLabel = "British Sports Cars",
        level = 9,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 6.6f, stage2Scale = 4.1f, stage3Scale = 2.3f),
        hints = QuizHints(
            clue1 = "James Bond's iconic automobile marque behind the DB5 and Valkyrie hypercar.",
            clue2 = "A wide aerodynamic pair of stylized scarab beetle feathered wings framing its name."
        ),
        primaryColor = 0xFF003E29,
        bgColor = 0xFF061A12,
        accentColor = 0xFFFFFFFF,
        description = "Aston Martin's winged insignia inspired by Egyptian scarab wings, synonym of 007 spy cool.",
        logoType = "aston-martin"
    ),
    QuizItem(
        id = "porsche",
        name = "PORSCHE",
        cleanAnswer = "PORSCHE",
        category = "car",
        categoryLabel = "German Sports Cars",
        level = 9,
        difficulty = "Extreme",
        zoom = ZoomTarget(x = 50f, y = 42f, initialScale = 6.6f, stage2Scale = 4.1f, stage3Scale = 2.3f),
        hints = QuizHints(
            clue1 = "Stuttgart maker of the rear-engine 911 Turbo and GT3 RS.",
            clue2 = "Heraldic gold shield with black and red antler stripes around the city horse."
        ),
        primaryColor = 0xFFD97706,
        bgColor = 0xFF18181B,
        accentColor = 0xFFB91C1C,
        description = "The Porsche Stuttgart crest combining Württemberg antlers and the rearing horse.",
        logoType = "porsche"
    ),

    // ==========================================
    // Level 10: Grandmaster Mystery Hall (Grandmaster • 3.0x PTS)
    // ==========================================
    QuizItem(
        id = "openai",
        name = "OPENAI",
        cleanAnswer = "OPENAI",
        aliases = listOf("CHATGPT", "OPEN AI"),
        category = "company",
        categoryLabel = "Artificial Intelligence",
        level = 10,
        difficulty = "Grandmaster",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 7.0f, stage2Scale = 4.4f, stage3Scale = 2.4f),
        hints = QuizHints(
            clue1 = "Pioneering artificial intelligence laboratory behind ChatGPT, GPT-4, and Sora.",
            clue2 = "An intricate spiral rosette knot looping six continuous curving petals into a vortex."
        ),
        primaryColor = 0xFF10A37F,
        bgColor = 0xFF202123,
        accentColor = 0xFFFFFFFF,
        description = "OpenAI's spiral rosette knot, representing neural pathways and artificial general intelligence.",
        logoType = "openai"
    ),
    QuizItem(
        id = "formula1",
        name = "FORMULA 1",
        cleanAnswer = "FORMULA1",
        aliases = listOf("F1", "FORMULA ONE"),
        category = "company",
        categoryLabel = "Motorsports Championship",
        level = 10,
        difficulty = "Grandmaster",
        zoom = ZoomTarget(x = 48f, y = 48f, initialScale = 7.2f, stage2Scale = 4.5f, stage3Scale = 2.5f),
        hints = QuizHints(
            clue1 = "The highest class of international single-seater open-cockpit auto racing.",
            clue2 = "A curving, bold scarlet ribbon 'F' with parallel speed streaks merging into an angled numeral '1'."
        ),
        primaryColor = 0xFFE10600,
        bgColor = 0xFF15151E,
        accentColor = 0xFFFFFFFF,
        description = "The dynamic Formula 1 speed ribbon, symbol of the fastest track racing on the planet.",
        logoType = "formula1"
    ),
    QuizItem(
        id = "jumpman",
        name = "JORDAN",
        cleanAnswer = "JORDAN",
        aliases = listOf("JUMPMAN", "AIR JORDAN"),
        category = "clothes",
        categoryLabel = "Basketball Legend",
        level = 10,
        difficulty = "Grandmaster",
        zoom = ZoomTarget(x = 52f, y = 32f, initialScale = 7.2f, stage2Scale = 4.5f, stage3Scale = 2.5f),
        hints = QuizHints(
            clue1 = "Nike subsidiary celebrating Michael Jordan, six-time NBA champion with the Chicago Bulls.",
            clue2 = "The silhouette of MJ soaring through the air mid-dunk with legs extended and ball outstretched."
        ),
        primaryColor = 0xFFE11D48,
        bgColor = 0xFF0F172A,
        accentColor = 0xFFFFFFFF,
        description = "The iconic Air Jordan Jumpman silhouette, the holy grail of sneakerhead culture.",
        logoType = "jumpman"
    ),
    QuizItem(
        id = "chanel",
        name = "CHANEL",
        cleanAnswer = "CHANEL",
        category = "clothes",
        categoryLabel = "Haute Couture",
        level = 10,
        difficulty = "Grandmaster",
        zoom = ZoomTarget(x = 50f, y = 50f, initialScale = 7.0f, stage2Scale = 4.3f, stage3Scale = 2.4f),
        hints = QuizHints(
            clue1 = "Legendary French fashion house founded by Coco Chanel, creator of the 'Little Black Dress' and No. 5.",
            clue2 = "Two bold interlocking capital 'C' letters mirrored back-to-back."
        ),
        primaryColor = 0xFF000000,
        bgColor = 0xFFFFFFFF,
        accentColor = 0xFF18181B,
        description = "Chanel's interlocking mirrored CC monogram, timeless symbol of French elegance.",
        logoType = "chanel"
    ),
    QuizItem(
        id = "lamborghini-v2",
        name = "LAMBORGHINI",
        cleanAnswer = "LAMBORGHINI",
        aliases = listOf("LAMBO"),
        category = "car",
        categoryLabel = "Extreme Bull Zoom",
        level = 10,
        difficulty = "Grandmaster",
        zoom = ZoomTarget(x = 42f, y = 38f, initialScale = 7.5f, stage2Scale = 4.6f, stage3Scale = 2.5f),
        hints = QuizHints(
            clue1 = "Italian bull badge hyper-zoomed on the sharp golden horn and muscular neck.",
            clue2 = "The legendary fighting bull of Ferruccio Lamborghini charging inside a golden border."
        ),
        primaryColor = 0xFFD4AF37,
        bgColor = 0xFF050505,
        accentColor = 0xFFF59E0B,
        description = "Grandmaster micro-crop of the Lamborghini golden fighting bull's lethal horn.",
        logoType = "lamborghini"
    ),
    QuizItem(
        id = "ferrari-shield",
        name = "FERRARI",
        cleanAnswer = "FERRARI",
        aliases = listOf("SCUDERIA FERRARI"),
        category = "car",
        categoryLabel = "Extreme Stallion Zoom",
        level = 10,
        difficulty = "Grandmaster",
        zoom = ZoomTarget(x = 50f, y = 18f, initialScale = 7.5f, stage2Scale = 4.6f, stage3Scale = 2.5f),
        hints = QuizHints(
            clue1 = "Ultra-close magnification of the Italian national tricolor atop the Maranello shield.",
            clue2 = "Green, white, and red horizontal stripes crowning the Cavallino Rampante."
        ),
        primaryColor = 0xFFFF2800,
        bgColor = 0xFF111827,
        accentColor = 0xFFFFE600,
        description = "Grandmaster micro-crop of Ferrari's Scuderia racing shield crown.",
        logoType = "ferrari"
    )
)
