package com.example.data.repository

import com.example.data.dao.SubjectDao
import com.example.data.model.SubjectEntity
import kotlinx.coroutines.flow.Flow

class SubjectRepository(
    private val subjectDao: SubjectDao
) {
    val activeSubjectsFlow: Flow<List<SubjectEntity>> = subjectDao.getActiveSubjectsFlow()
    val archivedSubjectsFlow: Flow<List<SubjectEntity>> = subjectDao.getArchivedSubjectsFlow()
    val allSubjectsFlow: Flow<List<SubjectEntity>> = subjectDao.getAllSubjectsFlow()

    suspend fun getSubjectById(id: Long): SubjectEntity? = subjectDao.getSubjectById(id)

    suspend fun addSubject(
        name: String,
        colorHex: String,
        iconName: String,
        weeklyTargetHours: Float?
    ): Long {
        val entity = SubjectEntity(
            name = name.trim(),
            colorHex = colorHex,
            iconName = iconName,
            weeklyTargetHours = weeklyTargetHours,
            isArchived = false
        )
        return subjectDao.insertSubject(entity)
    }

    suspend fun updateSubject(
        id: Long,
        name: String,
        colorHex: String,
        iconName: String,
        weeklyTargetHours: Float?
    ) {
        val existing = subjectDao.getSubjectById(id) ?: return
        val updated = existing.copy(
            name = name.trim(),
            colorHex = colorHex,
            iconName = iconName,
            weeklyTargetHours = weeklyTargetHours
        )
        subjectDao.updateSubject(updated)
    }

    suspend fun archiveSubject(id: Long) {
        subjectDao.archiveSubject(id)
    }

    suspend fun restoreSubject(id: Long) {
        subjectDao.restoreSubject(id)
    }

    suspend fun deleteSubject(id: Long) {
        subjectDao.deleteSubject(id)
    }
}
