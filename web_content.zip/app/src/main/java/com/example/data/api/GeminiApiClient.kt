package com.example.data.api

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class ChatInputMessage(
    val role: String, // "user" or "model" / "assistant"
    val text: String,
    val imageBase64: String? = null,
    val imageMimeType: String? = null,
    val fileTextContent: String? = null,
    val fileName: String? = null
)

data class GeneratedMedia(
    val imageBytes: ByteArray?,
    val mimeType: String = "image/jpeg",
    val description: String = ""
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as GeneratedMedia
        return imageBytes?.contentEquals(other.imageBytes) ?: (other.imageBytes == null)
    }

    override fun hashCode(): Int {
        return imageBytes?.contentHashCode() ?: 0
    }
}

data class VideoGenerationResult(
    val isSuccess: Boolean,
    val operationName: String? = null,
    val videoUrl: String? = null,
    val message: String
)

class GeminiApiClient {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
        const val MODEL_CHAT = "gemini-3.5-flash"
        const val MODEL_IMAGE = "gemini-2.5-flash-image"
        const val MODEL_VIDEO = "veo-3.1-fast-generate-preview"

        const val SUESA_SYSTEM_INSTRUCTION = """Sen "Suesa AI" adında modern, akıllı, samimi ve arkadaş canlısı bir yapay zekâ asistanısın.
Kuralların:
1. Her zaman Türkçe konuş.
2. Doğal, samimi, yardımsever ve gerektiğinde hafif esprili bir üslup kullan.
3. Asla kaba olma, küfür kullanma.
4. Gereksiz yere lafı uzatma, soruya doğrudan ve net cevap ver; ancak kullanıcı detaylı açıklama istediğinde kapsamlı bilgi sağla.
5. Kod sorularında temiz, çalışan, açıklamalı kod blokları oluştur.
6. Matematik, fen, programlama, metin yazma, görsel ve dosya analizinde son derece yeteneklisin.
7. Kullanıcı görsel veya dosya paylaştığında içeriğini dikkatle incele ve sorusunu buna göre yanıtla.
8. İsmin Suesa AI'dır. Kendini her zaman Suesa AI olarak tanıt."""
    }

    /**
     * Send chat messages to Gemini 3.5 Flash
     */
    suspend fun generateChatResponse(
        messages: List<ChatInputMessage>,
        apiKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalArgumentException("Gemini API anahtarı bulunamadı. Lütfen Ayarlar menüsünden geçerli bir API anahtarı ekleyin.")
            )
        }

        try {
            val rootJson = JSONObject()

            // System Instruction
            val systemInstructionObj = JSONObject().apply {
                val partsArray = JSONArray()
                partsArray.put(JSONObject().put("text", SUESA_SYSTEM_INSTRUCTION))
                put("parts", partsArray)
            }
            rootJson.put("systemInstruction", systemInstructionObj)

            // Contents array
            val contentsArray = JSONArray()
            for (msg in messages) {
                val contentObj = JSONObject()
                val apiRole = if (msg.role == "user") "user" else "model"
                contentObj.put("role", apiRole)

                val partsArray = JSONArray()

                // If user attached file text (PDF/TXT/CSV/JSON)
                if (!msg.fileTextContent.isNullOrBlank()) {
                    val fileHeader = "[Eklenen Dosya: ${msg.fileName ?: "Belge"}]\n" +
                            "${msg.fileTextContent}\n---\n"
                    partsArray.put(JSONObject().put("text", fileHeader))
                }

                // Text part
                if (msg.text.isNotBlank()) {
                    partsArray.put(JSONObject().put("text", msg.text))
                }

                // Image inline data
                if (!msg.imageBase64.isNullOrBlank()) {
                    val inlineData = JSONObject().apply {
                        put("mimeType", msg.imageMimeType ?: "image/jpeg")
                        put("data", msg.imageBase64)
                    }
                    partsArray.put(JSONObject().put("inlineData", inlineData))
                }

                contentObj.put("parts", partsArray)
                contentsArray.put(contentObj)
            }
            rootJson.put("contents", contentsArray)

            // Generation config
            val configObj = JSONObject().apply {
                put("temperature", 0.7)
                put("topP", 0.95)
            }
            rootJson.put("generationConfig", configObj)

            val url = "$BASE_URL/models/$MODEL_CHAT:generateContent?key=$apiKey"
            val requestBody = rootJson.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMessage = parseErrorMessage(response.code, responseBody)
                return@withContext Result.failure(Exception(errorMessage))
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        val text = part.optString("text")
                        if (text.isNotEmpty()) {
                            sb.append(text)
                        }
                    }
                    return@withContext Result.success(sb.toString().trim())
                }
            }

            return@withContext Result.failure(Exception("Suesa AI yanıt üretemedi. Lütfen tekrar deneyin."))
        } catch (e: Exception) {
            val message = mapExceptionToTurkish(e)
            return@withContext Result.failure(Exception(message))
        }
    }

    /**
     * Generate or edit an image using gemini-2.5-flash-image
     */
    suspend fun generateImage(
        prompt: String,
        inputImageBase64: String?,
        inputImageMimeType: String?,
        aspectRatio: String,
        apiKey: String
    ): Result<GeneratedMedia> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalArgumentException("Gemini API anahtarı gerekli. Lütfen Ayarlar'dan anahtarınızı girin.")
            )
        }

        try {
            val rootJson = JSONObject()

            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            // If editing an existing image
            if (!inputImageBase64.isNullOrBlank()) {
                val inlineData = JSONObject().apply {
                    put("mimeType", inputImageMimeType ?: "image/jpeg")
                    put("data", inputImageBase64)
                }
                partsArray.put(JSONObject().put("inlineData", inlineData))
            }

            // Prompt text
            partsArray.put(JSONObject().put("text", prompt))
            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            rootJson.put("contents", contentsArray)

            // Image generation config
            val configObj = JSONObject().apply {
                val modalities = JSONArray().apply {
                    put("TEXT")
                    put("IMAGE")
                }
                put("responseModalities", modalities)

                val imageConfig = JSONObject().apply {
                    put("aspectRatio", aspectRatio)
                    put("imageSize", "1K")
                }
                put("imageConfig", imageConfig)
            }
            rootJson.put("generationConfig", configObj)

            val url = "$BASE_URL/models/$MODEL_IMAGE:generateContent?key=$apiKey"
            val requestBody = rootJson.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMessage = parseErrorMessage(response.code, responseBody)
                return@withContext Result.failure(Exception(errorMessage))
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null) {
                    var imageBytes: ByteArray? = null
                    var mimeType = "image/jpeg"
                    val descBuilder = StringBuilder()

                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        val inline = part.optJSONObject("inlineData")
                        if (inline != null) {
                            val dataStr = inline.optString("data")
                            mimeType = inline.optString("mimeType", "image/jpeg")
                            if (dataStr.isNotEmpty()) {
                                imageBytes = Base64.decode(dataStr, Base64.DEFAULT)
                            }
                        }
                        val text = part.optString("text")
                        if (text.isNotEmpty()) {
                            descBuilder.append(text)
                        }
                    }

                    if (imageBytes != null) {
                        return@withContext Result.success(
                            GeneratedMedia(
                                imageBytes = imageBytes,
                                mimeType = mimeType,
                                description = descBuilder.toString().trim()
                            )
                        )
                    }
                }
            }

            return@withContext Result.failure(
                Exception("Model görsel verisi döndürmedi. Lütfen isteminizi değiştirip tekrar deneyin.")
            )
        } catch (e: Exception) {
            return@withContext Result.failure(Exception(mapExceptionToTurkish(e)))
        }
    }

    /**
     * Generate Video via Veo endpoint (veo-3.1-fast-generate-preview)
     */
    suspend fun generateVideo(
        prompt: String,
        inputImageBase64: String?,
        aspectRatio: String,
        apiKey: String
    ): Result<VideoGenerationResult> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalArgumentException("Gemini API anahtarı gerekli. Lütfen Ayarlar'dan anahtarınızı girin.")
            )
        }

        try {
            val rootJson = JSONObject().apply {
                put("prompt", prompt)
                val config = JSONObject().apply {
                    put("numberOfVideos", 1)
                    put("resolution", "720p")
                    put("aspectRatio", aspectRatio)
                }
                put("config", config)
                if (!inputImageBase64.isNullOrBlank()) {
                    val imageObj = JSONObject().apply {
                        put("imageBytes", inputImageBase64)
                        put("mimeType", "image/jpeg")
                    }
                    put("image", imageObj)
                }
            }

            val url = "$BASE_URL/models/$MODEL_VIDEO:generateVideos?key=$apiKey"
            val requestBody = rootJson.toString().toRequestBody("application/json".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                // Check if Veo is not enabled on this specific API key or region
                if (response.code == 404 || response.code == 403 || response.code == 400) {
                    val parsed = parseErrorMessage(response.code, responseBody)
                    return@withContext Result.success(
                        VideoGenerationResult(
                            isSuccess = false,
                            message = "Veo Video API: $parsed\n(Not: Google Veo video modeli şu an belirli hesap ve bölgelerde önizlemededir. API anahtarınızda Veo erişimi etkinleştirildiğinde otomatik olarak tam video oluşturulacaktır.)"
                        )
                    )
                }
                val errorMessage = parseErrorMessage(response.code, responseBody)
                return@withContext Result.failure(Exception(errorMessage))
            }

            val json = JSONObject(responseBody)
            val operationName = json.optString("name")

            return@withContext Result.success(
                VideoGenerationResult(
                    isSuccess = true,
                    operationName = operationName,
                    message = "Video oluşturma işlemi başlatıldı."
                )
            )
        } catch (e: Exception) {
            return@withContext Result.failure(Exception(mapExceptionToTurkish(e)))
        }
    }

    /**
     * Test connection to Gemini API
     */
    suspend fun testConnection(apiKey: String): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext Result.failure(Exception("API anahtarı boş olamaz."))
        }
        val messages = listOf(
            ChatInputMessage(role = "user", text = "Merhaba, bağlantı testi. Tek bir kelimeyle 'Tamam' de.")
        )
        val result = generateChatResponse(messages, apiKey)
        if (result.isSuccess) {
            Result.success("Bağlantı başarılı! Suesa AI yanıt verdi.")
        } else {
            Result.failure(result.exceptionOrNull() ?: Exception("Bağlantı kurulamadı."))
        }
    }

    private fun parseErrorMessage(code: Int, body: String): String {
        return try {
            val json = JSONObject(body)
            val errorObj = json.optJSONObject("error")
            val rawMsg = errorObj?.optString("message") ?: "Hata kodu: $code"
            when {
                code == 400 && rawMsg.contains("API_KEY_INVALID", ignoreCase = true) ->
                    "Girdiğiniz Gemini API anahtarı geçersiz. Lütfen Ayarlar'dan doğru anahtarı kontrol edin."
                code == 403 ->
                    "API anahtarınızın bu modele erişim izni bulunmuyor veya kota yetersiz (Hata 403)."
                code == 429 ->
                    "İstek kotası aşıldı. Lütfen kısa bir süre sonra tekrar deneyin (Hata 429)."
                code == 500 || code == 503 ->
                    "Gemini sunucularında geçici bir yoğunluk var. Lütfen biraz bekleyip tekrar deneyin."
                else -> "Sunucu Hatası ($code): $rawMsg"
            }
        } catch (e: Exception) {
            "Sunucu bağlantı hatası ($code)"
        }
    }

    private fun mapExceptionToTurkish(e: Exception): String {
        val msg = e.message ?: ""
        return when {
            e is java.net.UnknownHostException || msg.contains("Unable to resolve host") ->
                "İnternet bağlantısı yok veya sunucuya erişilemiyor. Lütfen internetinizi kontrol edin."
            e is java.net.SocketTimeoutException ->
                "Bağlantı zaman aşımına uğradı. Yapay zekâ sunucusu yanıt vermedi, lütfen tekrar deneyin."
            msg.isNotBlank() -> msg
            else -> "Bilinmeyen bir hata oluştu. Lütfen tekrar deneyin."
        }
    }
}
