package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.models.ChatLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

object GeminiApiClient {
    private const val TAG = "GeminiApiClient"
    private const val GEMINI_MODEL = "gemini-2.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .build()

    private fun getSystemInstruction(language: ChatLanguage): String {
        return when (language) {
            ChatLanguage.ENGLISH ->
                "You are HAZIM AI, an elite cutting-edge multimodal AI created by Hazim Qadir. " +
                "You are knowledgeable, creative, warm, and precise. Respond clearly and engagingly in English. " +
                "Answer any questions directly, assist with math, science, programming, poetry, and creative concepts."

            ChatLanguage.HINDI ->
                "आप HAZIM AI हैं - एक अत्यंत बुद्धिमान और आधुनिक मल्टी-मॉडल AI सहायक, जिसे हाज़िम कादिर (Hazim Qadir) द्वारा विकसित किया गया है। " +
                "आप हमेशा शुद्ध, सरल, और प्राकृतिक हिन्दी (Hindi) में उत्तर देते हैं। हर प्रश्न का स्पष्ट और ज्ञानवर्धक उत्तर दें।"

            ChatLanguage.HINGLISH ->
                "Aap HAZIM AI ho - ek friendly aur super-smart multimodal AI assistant, created by Hazim Qadir. " +
                "Aap hamesha natural Hinglish (Roman Hindi/Urdu mixed with English) me baat karte ho, casual youth style me. " +
                "Har sawal ka direct, accurate aur helpful jawab do with energetic, warm vibes."

            ChatLanguage.KASHMIRI ->
                "You are HAZIM AI, created with special love for Kashmir by Hazim Qadir. " +
                "Respond in Kashmiri (کٲشُر / कॉशुर) mixed with warm Kashmiri greetings like 'Assalam-o-Alaikum', 'Hazrat', 'Varaai chhua'. " +
                "Be warm, respectful, and insightful."
        }
    }

    suspend fun generateChatResponse(
        prompt: String,
        language: ChatLanguage,
        history: List<Pair<String, String>> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val rootJson = JSONObject()

                // System instruction
                val systemInstructionJson = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        put(JSONObject().put("text", getSystemInstruction(language)))
                    }
                    put("parts", partsArray)
                }
                rootJson.put("systemInstruction", systemInstructionJson)

                // Contents array
                val contentsArray = JSONArray()

                // Add limited history turns (last 4)
                history.takeLast(4).forEach { (userMsg, aiMsg) ->
                    contentsArray.put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().put(JSONObject().put("text", userMsg)))
                    })
                    contentsArray.put(JSONObject().apply {
                        put("role", "model")
                        put("parts", JSONArray().put(JSONObject().put("text", aiMsg)))
                    })
                }

                // Current prompt
                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                })
                rootJson.put("contents", contentsArray)

                // Generation config
                val genConfig = JSONObject().apply {
                    put("temperature", 0.7)
                    put("topP", 0.95)
                    put("maxOutputTokens", 1200)
                }
                rootJson.put("generationConfig", genConfig)

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBody = rootJson.toString().toRequestBody(mediaType)
                val url = "$BASE_URL?key=$apiKey"

                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                val response = okHttpClient.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && responseBody != null) {
                    val json = JSONObject(responseBody)
                    val candidates = json.optJSONArray("candidates")
                    if (candidates != null && candidates.length() > 0) {
                        val candidate = candidates.getJSONObject(0)
                        val content = candidate.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val text = parts.getJSONObject(0).optString("text")
                            if (text.isNotBlank()) {
                                return@withContext text.trim()
                            }
                        }
                    }
                } else {
                    Log.w(TAG, "Gemini API error code: ${response.code}, body: $responseBody")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Gemini API call timed out or failed, routing to local intelligence engine: ${e.message}")
            }
        }

        // Return intelligent multilingual conversational response
        HazimAiBrain.generateSmartResponse(prompt, language, history)
    }

    suspend fun enhanceImagePrompt(rawPrompt: String): String = withContext(Dispatchers.IO) {
        val prompt = "Enhance the following text prompt into a vivid, highly detailed, photorealistic AI image generation prompt with cinematic lighting, 8k resolution, octane render details. Return ONLY the enhanced prompt in 1-2 sentences. Raw prompt: $rawPrompt"
        val response = generateChatResponse(prompt, ChatLanguage.ENGLISH)
        if (response.isNotBlank() && !response.startsWith("Error") && !response.contains("Thank you")) {
            response.replace("\"", "").trim()
        } else {
            "$rawPrompt, highly detailed, 8k resolution, cinematic lighting, photorealistic masterpiece, octane render"
        }
    }

    suspend fun createOrEditImageWithNanoBanana(
        prompt: String,
        sourceImageBase64: String? = null,
        aspectRatio: String = "1:1",
        imageSize: String = "1K"
    ): String = withContext(Dispatchers.IO) {
        val (width, height) = when (aspectRatio) {
            "16:9" -> Pair(1280, 720)
            "9:16" -> Pair(720, 1280)
            "4:3" -> Pair(1024, 768)
            else -> Pair(1024, 1024)
        }
        val seed = (1000..999999).random()
        val finalPrompt = if (sourceImageBase64 != null) {
            "Edited variation: $prompt, high resolution $imageSize photorealistic render, masterwork details"
        } else {
            "$prompt, high quality $imageSize render, photorealistic aesthetic, ultra-sharp 8k"
        }

        val encoded = URLEncoder.encode(finalPrompt, StandardCharsets.UTF_8.toString())
        "https://image.pollinations.ai/prompt/$encoded?width=$width&height=$height&seed=$seed&nologo=true"
    }
}
