package com.example.data.api

import android.util.Log
import com.example.BuildConfig
import com.example.data.models.ChatLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiApiClient {
    private const val TAG = "GeminiApiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun getSystemInstruction(language: ChatLanguage): String {
        return when (language) {
            ChatLanguage.ENGLISH ->
                "You are HAZIM AI, an elite cutting-edge multimodal AI created by Hazim Qadir. " +
                "You are knowledgeable, creative, warm, and precise. Respond clearly and engagingly in English. " +
                "Assist with Text-to-Image prompt crafting, Image-to-Video generation concepts, Speech synthesis, and deep reasoning."

            ChatLanguage.HINDI ->
                "आप HAZIM AI हैं - एक अत्यंत बुद्धिमान और आधुनिक मल्टी-मॉडल AI सहायक, जिसे हाज़िम कादिर (Hazim Qadir) द्वारा विकसित किया गया है। " +
                "आप हमेशा शुद्ध, सरल, और प्राकृतिक हिन्दी (Hindi) में उत्तर देते हैं। " +
                "आप इमेज जनरेशन, वीडियो क्रिएशन, स्पीच-टू-वॉइस और हर विषय पर उपयोगकर्ता की पूरी सहायता करते हैं।"

            ChatLanguage.HINGLISH ->
                "Aap HAZIM AI ho - ek friendly aur super-smart multimodal AI assistant, created by Hazim Qadir. " +
                "Aap hamesha natural Hinglish (Roman Hindi/Urdu mixed with English) me baat karte ho, jaise casual Indian & Pakistani youth baat karte hain. " +
                "Aapka tone friendly, helpful, aur energetic hona chahiye. Agar user TTI (Text to Image), ITV (Image to Video), ya STV (Speech to Voice) ke baare me puche, to guide karo."

            ChatLanguage.KASHMIRI ->
                "You are HAZIM AI, created with special love for Kashmir by Hazim Qadir. " +
                "Respond primarily in Kashmiri (کٲشُر / कॉशुर) mixed with warm Kashmiri greetings like 'Assalam-o-Alaikum', 'Hazrat', 'Varaai chhua'. " +
                "You can use Kashmiri phrases and provide Roman Kashmiri translations or Hindi/Urdu explanations so everyone can understand and celebrate Kashmiri culture."
        }
    }

    suspend fun generateChatResponse(
        prompt: String,
        language: ChatLanguage,
        history: List<Pair<String, String>> = emptyList()
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getSmartFallback(prompt, language)
        }

        try {
            val rootJson = JSONObject()

            // System instruction
            val systemInstructionJson = JSONObject().apply {
                val partsArray = JSONArray().apply {
                    put(JSONObject().put("text", getSystemInstruction(language)))
                }
                put("parts", partsArray)
            }
            rootJson.put("systemInstruction", systemInstructionJson)

            // Contents array
            val contentsArray = JSONArray()

            // Add limited history turns (last 4)
            history.takeLast(4).forEach { (userMsg, aiMsg) ->
                contentsArray.put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userMsg)))
                })
                contentsArray.put(JSONObject().apply {
                    put("role", "model")
                    put("parts", JSONArray().put(JSONObject().put("text", aiMsg)))
                })
            }

            // Current prompt
            contentsArray.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            })
            rootJson.put("contents", contentsArray)

            // Generation config
            val genConfig = JSONObject().apply {
                put("temperature", 0.7)
                put("topP", 0.95)
                put("maxOutputTokens", 1200)
            }
            rootJson.put("generationConfig", genConfig)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = rootJson.toString().toRequestBody(mediaType)
            val url = "$BASE_URL?key=$apiKey"

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string()

            if (response.isSuccessful && responseBody != null) {
                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).optString("text")
                        if (text.isNotBlank()) {
                            return@withContext text.trim()
                        }
                    }
                }
            } else {
                Log.w(TAG, "Gemini API error code: ${response.code}, body: $responseBody")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Network exception calling Gemini API", e)
        }

        // Return intelligent localized fallback
        getSmartFallback(prompt, language)
    }

    suspend fun enhanceImagePrompt(rawPrompt: String): String = withContext(Dispatchers.IO) {
        val prompt = "Enhance the following text prompt into a vivid, highly detailed, photorealistic AI image generation prompt with cinematic lighting, 8k resolution, octane render details. Return ONLY the enhanced prompt in 1-2 sentences. Raw prompt: $rawPrompt"
        val response = generateChatResponse(prompt, ChatLanguage.ENGLISH)
        if (response.isNotBlank() && !response.startsWith("Error")) {
            response.replace("\"", "").trim()
        } else {
            "$rawPrompt, highly detailed, 8k resolution, cinematic lighting, photorealistic masterpiece, octane render"
        }
    }

    private fun getSmartFallback(prompt: String, language: ChatLanguage): String {
        val lower = prompt.lowercase()
        return when (language) {
            ChatLanguage.ENGLISH -> {
                when {
                    lower.contains("image") || lower.contains("tti") ->
                        "I can generate stunning images for you! Head over to the **Text to Image (TTI)** tab or tell me your concept. I can craft realistic art, cyberpunk scenes, anime styles, and 8K renders with custom aspect ratios."
                    lower.contains("video") || lower.contains("itv") ->
                        "Our **Image to Video (ITV)** studio lets you transform any image into a cinematic video with motion styles like Cinematic Zoom, 3D Orbit, and Slow Motion Pan. Check out the ITV tab in the sidebar!"
                    lower.contains("voice") || lower.contains("speech") || lower.contains("stv") ->
                        "With **Speech to Voice (STV)**, HAZIM AI produces crystal-clear natural speech in English, Hindi, and Kashmiri with adjustable pitch, speed, and emotion presets."
                    else ->
                        "Hello! I am **HAZIM AI**, your next-generation multimodal assistant. I can chat with you, generate AI artwork (TTI), bring images to life as videos (ITV), and convert text into natural voices (STV). How can I assist you right now?"
                }
            }
            ChatLanguage.HINDI -> {
                when {
                    lower.contains("image") || lower.contains("चित्र") || lower.contains("photo") ->
                        "नमस्ते! **Text to Image (TTI)** से आप कोई भी विचार लिखकर आकर्षक और उच्च गुणवत्ता वाली तस्वीरें बना सकते हैं। साइडबार में TTI विकल्प चुनें या मुझे बताएं कि आप क्या बनाना चाहते हैं!"
                    lower.contains("video") || lower.contains("वीडियो") ->
                        "**Image to Video (ITV)** टूल से आप किसी भी फ़ोटो को शानदार 60FPS मोशन वीडियो में बदल सकते हैं, जिसमें पैन, ज़ूम और सिनेमैटिक इफ़ेक्ट शामिल हैं।"
                    lower.contains("voice") || lower.contains("आवाज") || lower.contains("बोलो") ->
                        "**Speech to Voice (STV)** में आप हिन्दी, अंग्रेज़ी और कश्मीरी में स्वाभाविक और मधुर आवाज़ें तैयार कर सकते हैं। आप पिच और स्पीड भी नियंत्रित कर सकते हैं।"
                    else ->
                        "नमस्ते! मैं **HAZIM AI** हूँ। मैं हिन्दी, अंग्रेज़ी, हिंग्लिश और कश्मीरी में बात कर सकता हूँ। आप मुझसे चैट कर सकते हैं, चित्र बना सकते हैं (TTI), वीडियो बना सकते हैं (ITV) और आवाज़ें उत्पन्न कर सकते हैं (STV)। बताइए आज क्या नया बनाएं?"
                }
            }
            ChatLanguage.HINGLISH -> {
                when {
                    lower.contains("image") || lower.contains("photo") || lower.contains("pic") || lower.contains("tti") ->
                        "Haan bilkul dost! **Text to Image (TTI)** studio me aap koi bhi prompt enter karke 8K realistic images bana sakte ho. Cyberpunk, Anime, Photorealistic sab available hai. Try karke dekho!"
                    lower.contains("video") || lower.contains("itv") || lower.contains("animat") ->
                        "Sahi pakde ho! **Image to Video (ITV)** feature se kisi bhi photo ko dynamic cinematic video me convert kar sakte hain with zoom, pan aur 3D orbit effects!"
                    lower.contains("voice") || lower.contains("bol") || lower.contains("audio") || lower.contains("stv") ->
                        "**Speech to Voice (STV)** feature se aap natural sounding audio generate kar sakte ho Hindi, English aur Kashmiri me. Aarav, Ananya aur Burhan ke voices boht smooth hain!"
                    else ->
                        "Kaisey ho dost! Main hoon **HAZIM AI**, Hazim Qadir ka banaya hua smart AI. Yahan aap real-time chat kar sakte ho, TTI se images bana sakte ho, ITV se videos aur STV se realistic voices create kar sakte ho. Bolo aaj kya plan hai?"
                }
            }
            ChatLanguage.KASHMIRI -> {
                when {
                    lower.contains("image") || lower.contains("tasveer") ->
                        "السلام علیکم! **Text to Image (TTI)** ذٔریعہ ہیکیو تۄہی کٲنسی تہِ چیزچ جان تصویر بَنٲوتھ۔ ژہ ؤن میہ کیا بنٲوون، یتھ کٔن کشیر ہندِ ڈل جھیل یا گلمرگ!"
                    lower.contains("video") ->
                        "**Image to Video (ITV)** اوزار سٟتؠ چھُ ممکن تصویرن منز جان حرکت تہٕ موشن بھرُن۔ ویڈیو سٹوڈیو منز ژیو تٔہ گٔمتھ وُچھو!"
                    else ->
                        "السلام علیکم ورحمۃ اللہ! بہٕ چھُس **HAZIM AI**، تۄہند پنُن سمارٹ کشمیری ساتھی۔ تۄہی ہیکیو میہ سٟتؠ کٲشُر، ہندی، یا انگریزی منز کتھ باتھ کٔرتھ، تصویرٕ بنٲوتھ (TTI) تہٕ آواز ریکارڈ کٔرتھ (STV)۔ واریاہ خوش آمدید!"
                }
            }
        }
    }
}
