package com.example.data.remote

import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.local.MessageEntity
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Streaming

interface GeminiApiService {
    @retrofit2.http.GET("v1beta/models/{model}")
    suspend fun getModelInfo(
        @Path("model") model: String,
        @Query("key") apiKey: String
    ): ResponseBody

    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse

    @POST("v1beta/models/{model}:streamGenerateContent?alt=sse")
    @Streaming
    suspend fun streamGenerateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): ResponseBody
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"
    private const val TAG = "RaynoxGemini"

    val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
    }

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    val api: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GeminiApiService::class.java)
    }

    const val MODEL_RAYNOX_CORE = "gemini-3.5-flash"
    const val MODEL_RAYNOX_PRO = "gemini-3.5-flash-lite"

    /**
     * Resolves the Gemini API key strictly from BuildConfig (.env / Secrets panel)
     * or server/container environment variables — never hardcoded in source code.
     */
    fun getEffectiveApiKey(): String {
        val buildKey = try { BuildConfig.GEMINI_API_KEY.trim() } catch (_: Throwable) { "" }
        if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY" && buildKey != "YOUR_GEMINI_API_KEY") {
            return buildKey
        }
        val envKey = try { System.getenv("GEMINI_API_KEY")?.trim() } catch (_: Throwable) { null }
        if (!envKey.isNullOrBlank() && envKey != "MY_GEMINI_API_KEY" && envKey != "YOUR_GEMINI_API_KEY") {
            return envKey
        }
        return ""
    }

    /**
     * Performs a real network health-check ping against the Gemini API.
     * Never reports Connected unless the server responds successfully.
     */
    suspend fun pingHealthCheck(model: String = MODEL_RAYNOX_CORE): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Not Connected: GEMINI_API_KEY is not configured in BuildConfig / .env.")
            )
        }
        val startMs = System.currentTimeMillis()
        try {
            api.getModelInfo(model = model, apiKey = apiKey).use { _ ->
                val latency = System.currentTimeMillis() - startMs
                Result.success("Connected • ${getModelDisplayName(model)} (${latency}ms)")
            }
        } catch (httpEx: HttpException) {
            Result.failure(IllegalStateException("Not Connected: ${parseHttpError(httpEx)}"))
        } catch (e: Exception) {
            val detail = when {
                e.message?.contains("Unable to resolve host", ignoreCase = true) == true ->
                    "Network error — unable to reach Google Gemini server."
                e.message?.contains("timeout", ignoreCase = true) == true ->
                    "Connection timed out while checking AI service."
                else -> e.message ?: "Connection check failed."
            }
            Result.failure(IllegalStateException("Not Connected: $detail"))
        }
    }

    fun getModelDisplayName(modelId: String): String = when (modelId) {
        MODEL_RAYNOX_PRO -> "Raynox Pro"
        else -> "Raynox Core"
    }

    fun getModelDescription(modelId: String): String = when (modelId) {
        MODEL_RAYNOX_PRO -> "Ultra-fast response with high reasoning efficiency"
        else -> "Comprehensive, versatile everyday intelligence"
    }

    fun buildSystemInstruction(
        userName: String,
        customInstructions: String,
        userMemories: List<String> = emptyList()
    ): Content {
        val temporalHeader = com.example.util.DateTimeHelper.formatSystemPromptTemporalHeader()
        val basePrompt = buildString {
            appendLine("You are RAYNOX AI, a helpful, intelligent, friendly, and professional personal AI assistant.")
            appendLine("Your identity is RAYNOX AI. Respond naturally and confidently, with clear and useful explanations.")
            appendLine("Never unnecessarily mention internal model providers, model names, API vendors, backend infrastructure, or implementation details.")
            appendLine("If asked who you are, introduce yourself as RAYNOX AI.")
            appendLine("If asked which AI provider or model powers you, answer truthfully without pretending that your underlying technology is something else.")
            appendLine("Never claim to have capabilities, permissions, live information, or device access that you do not actually possess.")
            appendLine("Answer the user's actual question directly. Do not insert irrelevant branding or repetitive introductions into every response.")
            appendLine()
            appendLine(temporalHeader)
            appendLine()
            appendLine("Intelligence & Quality Guidelines:")
            appendLine("- Understand the user's complete question before formulating the response.")
            appendLine("- Answer directly before adding extra detail or context.")
            appendLine("- Provide useful, well-structured explanations when necessary.")
            appendLine("- Respond naturally and fluently in Hindi, Hinglish, or English according to the user's language and tone.")
            appendLine("- Avoid repetitive introductions (e.g., do NOT say 'Hi! I'm Raynox' in every response). Only greet if the user is greeting you.")
            appendLine("- Avoid repeating the same information.")
            appendLine("- Use headings (##, ###), bullet points, and numbered lists when they improve readability.")
            appendLine("- Keep simple answers concise. Explain complicated subjects step by step.")
            appendLine("- Ask for clarification when the user's question is genuinely ambiguous.")
            appendLine("- Acknowledge uncertainty instead of inventing facts.")
            appendLine("- Use available conversation context for follow-up questions.")
            appendLine("- When an image, screenshot, PDF, text file, or code file is attached, analyze its actual contents thoroughly and answer directly.")
            appendLine()
            appendLine("Device & Assistant Capabilities:")
            appendLine("- You can control and trigger device actions on the user's Android phone using action tags at the end of your message:")
            appendLine("  * [ACTION: TORCH_ON] or [ACTION: TORCH_OFF] (flashlight)")
            appendLine("  * [ACTION: OPEN_APP: youtube|whatsapp|camera|calculator|maps|settings]")
            appendLine("  * [ACTION: OPEN_SETTINGS: wifi|bluetooth|sound|display|battery]")
            appendLine("  * [ACTION: DIAL: <phone_number>] (opens dialer safely)")
            appendLine("  * [ACTION: SET_REMINDER: <title> | <in_minutes_int>] (e.g., [ACTION: SET_REMINDER: Call Mom | 30])")
            appendLine("  * [ACTION: SAVE_MEMORY: <topic> | <fact>] (e.g., [ACTION: SAVE_MEMORY: birthday | User's birthday is 15 August])")
            appendLine("- When the user requests one of these actions, confirm politely in natural language and include the corresponding action tag.")
            if (userName.isNotBlank()) {
                appendLine("- User name: $userName.")
            }
            if (customInstructions.isNotBlank()) {
                appendLine("- User preferences: $customInstructions")
            }
            if (userMemories.isNotEmpty()) {
                appendLine()
                appendLine("Saved User Memories & Personalization:")
                userMemories.forEach { mem ->
                    appendLine("• $mem")
                }
            }
        }
        return Content(parts = listOf(Part(text = basePrompt.trim())))
    }

    fun buildConversationContents(history: List<MessageEntity>): List<Content> {
        // Keep up to the last 20 non-error messages for fast, relevant context window management
        val validMessages = history
            .filter { !it.isError && (it.content.isNotBlank() || it.attachmentPath != null || !it.attachmentExtractedText.isNullOrBlank()) }
            .takeLast(20)

        return validMessages.mapNotNull { msg ->
            val role = if (msg.role == "user") "user" else "model"
            val parts = mutableListOf<Part>()

            if (msg.role == "user") {
                // Include inline binary attachment (Image or PDF) if present on disk
                if (msg.attachmentPath != null && (msg.attachmentType == "IMAGE" || msg.attachmentType == "PDF")) {
                    val file = File(msg.attachmentPath)
                    if (file.exists() && file.length() > 0 && file.length() <= 15 * 1024 * 1024) {
                        try {
                            val bytes = file.readBytes()
                            val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                            val mime = msg.attachmentMimeType ?: if (msg.attachmentType == "PDF") "application/pdf" else "image/jpeg"
                            parts.add(Part(inlineData = InlineData(mimeType = mime, data = base64)))
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to encode attachment file: ${e.message}")
                        }
                    }
                }

                // Include extracted text/code file content if present
                val combinedText = buildString {
                    if (!msg.attachmentExtractedText.isNullOrBlank()) {
                        appendLine("[Attached File: ${msg.attachmentName ?: "document"}]")
                        appendLine("```")
                        appendLine(msg.attachmentExtractedText)
                        appendLine("```")
                        appendLine()
                    }
                    if (msg.content.isNotBlank()) {
                        append(msg.content)
                    } else if (msg.attachmentType == "IMAGE") {
                        append("Please analyze this image in detail.")
                    } else if (msg.attachmentType == "PDF") {
                        append("Please analyze and summarize this PDF document.")
                    } else if (msg.attachmentType == "TEXT") {
                        append("Please analyze and explain this attached file.")
                    }
                }.trim()

                if (combinedText.isNotEmpty()) {
                    parts.add(Part(text = combinedText))
                }
            } else {
                if (msg.content.isNotBlank()) {
                    parts.add(Part(text = msg.content))
                }
            }

            if (parts.isEmpty()) null else Content(role = role, parts = parts)
        }
    }

    suspend fun streamChatResponse(
        model: String,
        history: List<MessageEntity>,
        userName: String,
        customInstructions: String,
        userMemories: List<String> = emptyList(),
        onPartialUpdate: suspend (String) -> Unit
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("AI service is not connected: GEMINI_API_KEY is missing in .env / BuildConfig.")
            )
        }

        val contents = buildConversationContents(history)
        if (contents.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Cannot send an empty conversation request."))
        }

        val request = GenerateContentRequest(
            contents = contents,
            systemInstruction = buildSystemInstruction(userName, customInstructions, userMemories),
            generationConfig = GenerationConfig(temperature = 0.7f, topP = 0.95f, topK = 40)
        )

        // Try primary model first, fallback to alternate model on 429/503/404
        val modelsToTry = if (model == MODEL_RAYNOX_PRO) {
            listOf(MODEL_RAYNOX_PRO, MODEL_RAYNOX_CORE)
        } else {
            listOf(MODEL_RAYNOX_CORE, MODEL_RAYNOX_PRO)
        }

        var lastError: Exception? = null

        for (activeModel in modelsToTry) {
            val accumulated = StringBuilder()
            try {
                val responseBody = api.streamGenerateContent(
                    model = activeModel,
                    apiKey = apiKey,
                    request = request
                )

                responseBody.byteStream().bufferedReader(Charsets.UTF_8).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        coroutineContext.ensureActive()
                        val trimmed = line?.trim() ?: continue
                        if (!trimmed.startsWith("data:")) continue
                        val payload = trimmed.removePrefix("data:").trim()
                        if (payload.isEmpty() || payload == "[DONE]") continue

                        try {
                            val jsonObj = json.parseToJsonElement(payload).jsonObject
                            val candidates = jsonObj["candidates"]?.jsonArray
                            val parts = candidates?.firstOrNull()?.jsonObject
                                ?.get("content")?.jsonObject
                                ?.get("parts")?.jsonArray

                            if (parts != null) {
                                for (partElement in parts) {
                                    val textChunk = partElement.jsonObject["text"]?.jsonPrimitive?.content
                                    if (!textChunk.isNullOrEmpty()) {
                                        accumulated.append(textChunk)
                                        onPartialUpdate(accumulated.toString())
                                    }
                                }
                            }
                        } catch (parseEx: Exception) {
                            Log.w(TAG, "Non-fatal SSE chunk parse warning: ${parseEx.message}")
                        }
                    }
                }

                if (accumulated.isNotEmpty()) {
                    return@withContext Result.success(accumulated.toString().trim())
                }

                // Fallback to standard generateContent if stream returned empty
                val fallbackResponse = api.generateContent(model = activeModel, apiKey = apiKey, request = request)
                val fallbackText = fallbackResponse.candidates
                    ?.firstOrNull()
                    ?.content
                    ?.parts
                    ?.mapNotNull { it.text }
                    ?.joinToString("")
                    ?.trim()

                if (!fallbackText.isNullOrEmpty()) {
                    onPartialUpdate(fallbackText)
                    return@withContext Result.success(fallbackText)
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (httpEx: HttpException) {
                Log.w(TAG, "Model $activeModel returned HTTP ${httpEx.code()}, checking fallback")
                lastError = httpEx
                if (accumulated.isNotEmpty()) {
                    return@withContext Result.success(accumulated.toString().trim())
                }
                // Continue loop to try fallback model
            } catch (e: Exception) {
                Log.w(TAG, "Model $activeModel failed: ${e.message}, checking fallback")
                lastError = e
                if (accumulated.isNotEmpty()) {
                    return@withContext Result.success(accumulated.toString().trim())
                }
            }
        }

        // If loop completes without success
        val finalEx = lastError
        if (finalEx is HttpException) {
            val friendly = parseHttpError(finalEx)
            Result.failure(IllegalStateException(friendly))
        } else {
            val message = when {
                finalEx?.message?.contains("Unable to resolve host", ignoreCase = true) == true ->
                    "Network connection unavailable. Please check your internet connection."
                finalEx?.message?.contains("timeout", ignoreCase = true) == true ->
                    "The AI request timed out. Please tap Retry to try again."
                else -> finalEx?.message ?: "Raynox AI was unable to complete the response. Please try again."
            }
            Result.failure(IllegalStateException(message))
        }
    }

    suspend fun generateQuickReply(prompt: String, model: String = MODEL_RAYNOX_CORE): Result<String> =
        withContext(Dispatchers.IO) {
            val apiKey = getEffectiveApiKey()
            if (apiKey.isBlank()) {
                return@withContext Result.failure(
                    IllegalStateException("AI service is not connected: GEMINI_API_KEY is missing.")
                )
            }
            val request = GenerateContentRequest(
                contents = listOf(
                    Content(role = "user", parts = listOf(Part(text = prompt)))
                ),
                systemInstruction = Content(
                    parts = listOf(
                        Part(
                            text = "You are RAYNOX AI, a helpful voice assistant. Answer concisely and naturally in 1 to 3 sentences suitable for being spoken aloud. Never mention internal model providers or API vendors. Support English, Hindi, and Hinglish naturally."
                        )
                    )
                )
            )

            val modelsToTry = listOf(model, MODEL_RAYNOX_PRO, MODEL_RAYNOX_CORE).distinct()
            for (m in modelsToTry) {
                try {
                    val response = api.generateContent(model = m, apiKey = apiKey, request = request)
                    val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
                    if (!text.isNullOrEmpty()) {
                        return@withContext Result.success(text)
                    }
                } catch (_: Exception) {
                    // Try next model
                }
            }
            Result.failure(IllegalStateException("Voice reply unavailable. Please check your network connection."))
        }

    private fun parseHttpError(httpEx: HttpException): String {
        val code = httpEx.code()
        val rawError = try {
            httpEx.response()?.errorBody()?.string()
        } catch (_: Exception) {
            null
        }
        val apiMessage = try {
            if (!rawError.isNullOrBlank()) {
                val jsonObj = json.parseToJsonElement(rawError).jsonObject
                jsonObj["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content
            } else null
        } catch (_: Exception) {
            null
        }

        return when (code) {
            400 -> apiMessage ?: "Invalid request sent to the AI service (HTTP 400)."
            401, 403 -> "AI service connection error (HTTP $code). Service credentials could not be verified."
            404 -> "Selected model endpoint unavailable (HTTP 404). Please try again in a moment."
            429 -> "AI service is receiving high volume right now. Please wait a moment and tap Retry."
            500, 502, 503, 504 -> "AI service is experiencing high temporary demand (HTTP $code). Please tap Retry in a moment."
            else -> apiMessage ?: "Request failed with HTTP $code."
        }
    }
}
