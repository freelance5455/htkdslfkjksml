package com.example.data.remote

import android.graphics.Bitmap
import com.example.BuildConfig
import com.example.util.AttachmentHelper
import com.example.util.SelectedAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatTurn(
    val role: String, // "user" or "model"
    val text: String,
    val inlineImages: List<Pair<String, String>> = emptyList() // Pair(mimeType, base64Data)
)

object GeminiService {
    private val MODELS = listOf(
        "gemini-3.5-flash",
        "gemini-flash-latest",
        "gemini-3.1-flash-lite-preview"
    )

    private const val SUESA_SYSTEM_PROMPT =
        "Sen Suesa AI’sın. Türkçe konuş. Gerçek bir arkadaş gibi doğal, zeki ve komik ol. " +
            "Alaycı, biraz zalim ve laf sokan bir mizahın olsun ama bunu sürekli ve mekanik yapma. " +
            "Ciddi veya üzücü konularda bile mizah yapabilirsin, fakat kullanıcıyı küçümseme ve gerçek zarar/tehdit içeren şeylere yönlendirme. " +
            "Küfürü çok azalt: her cümlenin sonuna küfür ekleme; yalnızca konuşmanın akışına gerçekten uyduğunda ara sıra “aq”, “mk”, “AMK” veya “ap” kullan. " +
            "Bunun yerine komik bir tepki gerektiğinde bazen “skdlskdlskdks” veya “SKDKSKDLSKDKDKSLSL” gibi rastgele klavye gülüşleri kullan. " +
            "Bunları da her cevapta değil, gerçekten komik bir an olduğunda kullan; yapay ve tekrarlı görünmesin. " +
            "Kısa, doğal ve insan gibi cevaplar ver. Minecraft Bedrock içindeki @Suesa_Sㅤム botunu kontrol eden bir uygulamadasın. " +
            "Kullanıcıya kısa, doğal ve net cevaplar ver."

    private val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    fun resolveApiKey(customKey: String?): String {
        val trimmedCustom = customKey?.trim().orEmpty()
        if (trimmedCustom.isNotEmpty()) return trimmedCustom
        val buildConfigKey = runCatching { BuildConfig.GEMINI_API_KEY.trim() }.getOrDefault("")
        if (buildConfigKey.isNotEmpty() && buildConfigKey != "MY_GEMINI_API_KEY" && buildConfigKey != "PLACEHOLDER") {
            return buildConfigKey
        }
        return ""
    }

    suspend fun sendChatMessage(
        history: List<ChatTurn>,
        currentUserText: String,
        attachments: List<SelectedAttachment>,
        customApiKey: String?,
        onStatusUpdate: (String) -> Unit = {}
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = resolveApiKey(customApiKey)
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("Önce sağ üstteki ⚙️ bölümünden veya AI Studio Secrets panelinden Gemini API anahtarını ekle.")
            )
        }

        val contentsArray = JSONArray()

        // Include recent conversation history (up to last 24 turns)
        for (turn in history.takeLast(24)) {
            val partsArray = JSONArray()
            if (turn.text.isNotBlank()) {
                partsArray.put(JSONObject().put("text", turn.text))
            }
            for ((mime, b64) in turn.inlineImages) {
                if (b64.isNotBlank()) {
                    partsArray.put(
                        JSONObject().put(
                            "inlineData",
                            JSONObject().put("mimeType", mime).put("data", b64)
                        )
                    )
                }
            }
            if (partsArray.length() > 0) {
                contentsArray.put(
                    JSONObject()
                        .put("role", if (turn.role == "model") "model" else "user")
                        .put("parts", partsArray)
                )
            }
        }

        // Current user message parts
        val currentParts = JSONArray()
        currentParts.put(JSONObject().put("text", currentUserText))

        for (file in attachments) {
            when {
                (file.isImage || file.isPdf) && file.base64Data.isNotBlank() -> {
                    currentParts.put(
                        JSONObject().put(
                            "inlineData",
                            JSONObject()
                                .put("mimeType", file.mimeType)
                                .put("data", file.base64Data)
                        )
                    )
                }
                !file.textContent.isNullOrBlank() -> {
                    currentParts.put(
                        JSONObject().put(
                            "text",
                            "\n[Dosya: ${file.name}]\n${file.textContent.take(120_000)}"
                        )
                    )
                }
                else -> {
                    currentParts.put(
                        JSONObject().put("text", "\n[Dosya eklendi: ${file.name} (${file.mimeType})]")
                    )
                }
            }
        }

        contentsArray.put(
            JSONObject()
                .put("role", "user")
                .put("parts", currentParts)
        )

        val requestPayload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", SUESA_SYSTEM_PROMPT))
                )
            )
            put("contents", contentsArray)
        }

        executeWithModelFallback(apiKey, requestPayload, onStatusUpdate)
    }

    suspend fun analyzeScreenOrVision(
        screenBitmap: Bitmap,
        userQuestion: String?,
        customApiKey: String?,
        onStatusUpdate: (String) -> Unit = {}
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = resolveApiKey(customApiKey)
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(
                IllegalStateException("Ekranı analiz edebilmem için ⚙️ Ayarlar'dan veya Secrets panelinden Gemini API anahtarını eklemen lazım.")
            )
        }

        val base64Jpeg = AttachmentHelper.bitmapToBase64(screenBitmap, 82)
        val prompt = if (userQuestion.isNullOrBlank()) {
            "Şu an kullanıcının ekranında / kamerasında bu görüntü var. Yüzen küçük panelden (Overlay) bakıyorsun. " +
                "Ekranda ne gördüğünü, önemli detayları, varsa oyundaki durumu, kodu veya metni Suesa tarzında samimi, zeki ve net şekilde anlat."
        } else {
            "Yüzen küçük panelden kullanıcının ekranına bakıyorsun. Kullanıcı soruyor: \"$userQuestion\". " +
                "Ekrandaki görüntüyü inceleyerek Suesa tarzında kısa ve net cevap ver."
        }

        val parts = JSONArray().apply {
            put(JSONObject().put("text", prompt))
            put(
                JSONObject().put(
                    "inlineData",
                    JSONObject()
                        .put("mimeType", "image/jpeg")
                        .put("data", base64Jpeg)
                )
            )
        }

        val contentsArray = JSONArray().put(
            JSONObject()
                .put("role", "user")
                .put("parts", parts)
        )

        val requestPayload = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", SUESA_SYSTEM_PROMPT))
                )
            )
            put("contents", contentsArray)
        }

        executeWithModelFallback(apiKey, requestPayload, onStatusUpdate)
    }

    private suspend fun executeWithModelFallback(
        apiKey: String,
        payload: JSONObject,
        onStatusUpdate: (String) -> Unit
    ): Result<String> {
        var lastError = "Bağlantı hatası"
        val mediaType = "application/json; charset=utf-8".toMediaType()
        val bodyString = payload.toString()

        for (round in 0..1) {
            for (model in MODELS) {
                onStatusUpdate("Suesa cevap hazırlıyor…")
                try {
                    val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                    val request = Request.Builder()
                        .url(url)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("x-goog-api-key", apiKey)
                        .post(bodyString.toRequestBody(mediaType))
                        .build()

                    val response = okHttpClient.newCall(request).execute()
                    val respText = response.body?.string().orEmpty()
                    val json = runCatching { JSONObject(respText) }.getOrNull()

                    if (response.isSuccessful && json != null) {
                        val candidates = json.optJSONArray("candidates")
                        val firstCandidate = candidates?.optJSONObject(0)
                        val content = firstCandidate?.optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val sb = StringBuilder()
                            for (i in 0 until parts.length()) {
                                val partObj = parts.optJSONObject(i)
                                val textPiece = partObj?.optString("text", "").orEmpty()
                                sb.append(textPiece)
                            }
                            val finalAnswer = sb.toString().trim()
                            if (finalAnswer.isNotEmpty()) {
                                return Result.success(finalAnswer)
                            }
                        }
                    }

                    val errMsg = json?.optJSONObject("error")?.optString("message")
                        ?: "HTTP ${response.code}"
                    lastError = errMsg
                    if (response.code in listOf(429, 500, 502, 503, 504, 408, 404)) {
                        continue
                    } else {
                        return Result.failure(IllegalStateException(lastError))
                    }
                } catch (e: Exception) {
                    lastError = e.message ?: "Bağlantı hatası"
                }
            }
            if (round == 0) {
                onStatusUpdate("Bağlantı yoğun, tekrar deneniyor…")
                delay(1500)
            }
        }

        return Result.failure(
            IllegalStateException(
                if (lastError.contains("API", ignoreCase = true) || lastError.contains("HTTP", ignoreCase = true)) {
                    "Gemini ile bağlantı kurulamadı ($lastError). API anahtarını ve internet bağlantını kontrol et."
                } else {
                    lastError
                }
            )
        )
    }
}
