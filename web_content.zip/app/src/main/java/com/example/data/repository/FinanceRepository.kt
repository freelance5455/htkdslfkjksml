package com.example.data.repository

import com.example.data.dao.FinanceDao
import com.example.data.entity.AppSettingsEntity
import com.example.data.entity.LoanEntity
import com.example.data.entity.LoanRepaymentEntity
import com.example.data.entity.SalaryEntity
import com.example.data.entity.TransactionEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

class FinanceRepository(private val dao: FinanceDao) {

    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()
    val allLoans: Flow<List<LoanEntity>> = dao.getAllLoans()
    val allRepayments: Flow<List<LoanRepaymentEntity>> = dao.getAllRepayments()
    val allSalaries: Flow<List<SalaryEntity>> = dao.getAllSalaries()
    val settings: Flow<AppSettingsEntity?> = dao.getSettings()

    // Transaction actions
    suspend fun insertTransaction(transaction: TransactionEntity): Long =
        dao.insertTransaction(transaction)

    suspend fun updateTransaction(transaction: TransactionEntity) =
        dao.updateTransaction(transaction)

    suspend fun deleteTransaction(id: Long) =
        dao.deleteTransactionById(id)

    // Loan actions
    suspend fun insertLoan(loan: LoanEntity): Long =
        dao.insertLoan(loan)

    suspend fun updateLoan(loan: LoanEntity) =
        dao.updateLoan(loan)

    suspend fun deleteLoan(id: Long) =
        dao.deleteLoanById(id)

    // Loan Repayment actions
    suspend fun insertRepayment(repayment: LoanRepaymentEntity): Long =
        dao.insertRepayment(repayment)

    suspend fun updateRepayment(repayment: LoanRepaymentEntity) =
        dao.updateRepayment(repayment)

    suspend fun deleteRepayment(id: Long) =
        dao.deleteRepaymentById(id)

    // Salary actions
    suspend fun getSalaryByMonth(institution: String, year: Int, monthIndex: Int): SalaryEntity? =
        dao.getSalaryByMonth(institution, year, monthIndex)

    suspend fun insertSalary(salary: SalaryEntity): Long =
        dao.insertSalary(salary)

    suspend fun updateSalary(salary: SalaryEntity) =
        dao.updateSalary(salary)

    suspend fun deleteSalary(id: Long) =
        dao.deleteSalaryById(id)

    // Settings actions
    suspend fun saveSettings(settings: AppSettingsEntity) =
        dao.saveSettings(settings)

    // Clear all data
    suspend fun clearAllData() {
        dao.clearAllTransactions()
        dao.clearAllLoans()
        dao.clearAllRepayments()
        dao.clearAllSalaries()
    }

    // Export Backup to JSON String
    suspend fun exportBackupJson(): String {
        val transactions = dao.getAllTransactions().first()
        val loans = dao.getAllLoans().first()
        val repayments = dao.getAllRepayments().first()
        val salaries = dao.getAllSalaries().first()

        val root = JSONObject()
        root.put("version", 1)
        root.put("timestamp", System.currentTimeMillis())

        val txArray = JSONArray()
        for (tx in transactions) {
            val obj = JSONObject()
            obj.put("id", tx.id)
            obj.put("type", tx.type)
            obj.put("categoryLabel", tx.categoryLabel)
            obj.put("amount", tx.amount)
            obj.put("date", tx.date)
            obj.put("description", tx.description)
            obj.put("timestamp", tx.timestamp)
            txArray.put(obj)
        }
        root.put("transactions", txArray)

        val loansArray = JSONArray()
        for (loan in loans) {
            val obj = JSONObject()
            obj.put("id", loan.id)
            obj.put("lenderName", loan.lenderName)
            obj.put("description", loan.description)
            obj.put("amount", loan.amount)
            obj.put("date", loan.date)
            obj.put("timestamp", loan.timestamp)
            loansArray.put(obj)
        }
        root.put("loans", loansArray)

        val repayArray = JSONArray()
        for (rep in repayments) {
            val obj = JSONObject()
            obj.put("id", rep.id)
            obj.put("loanId", rep.loanId ?: 0)
            obj.put("lenderName", rep.lenderName)
            obj.put("amount", rep.amount)
            obj.put("description", rep.description)
            obj.put("date", rep.date)
            obj.put("timestamp", rep.timestamp)
            repayArray.put(obj)
        }
        root.put("repayments", repayArray)

        val salArray = JSONArray()
        for (sal in salaries) {
            val obj = JSONObject()
            obj.put("id", sal.id)
            obj.put("institution", sal.institution)
            obj.put("year", sal.year)
            obj.put("monthIndex", sal.monthIndex)
            obj.put("monthName", sal.monthName)
            obj.put("amount", sal.amount)
            obj.put("date", sal.date)
            obj.put("description", sal.description)
            obj.put("isPaid", sal.isPaid)
            obj.put("timestamp", sal.timestamp)
            salArray.put(obj)
        }
        root.put("salaries", salArray)

        return root.toString(2)
    }

    // Restore Backup from JSON String
    suspend fun restoreBackupJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)

            clearAllData()

            if (root.has("transactions")) {
                val txArray = root.getJSONArray("transactions")
                for (i in 0 until txArray.length()) {
                    val obj = txArray.getJSONObject(i)
                    dao.insertTransaction(
                        TransactionEntity(
                            type = obj.optString("type", "INCOME"),
                            categoryLabel = obj.optString("categoryLabel", "সাধারণ"),
                            amount = obj.optDouble("amount", 0.0),
                            date = obj.optString("date", ""),
                            description = obj.optString("description", ""),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
            }

            if (root.has("loans")) {
                val loansArray = root.getJSONArray("loans")
                for (i in 0 until loansArray.length()) {
                    val obj = loansArray.getJSONObject(i)
                    dao.insertLoan(
                        LoanEntity(
                            lenderName = obj.optString("lenderName", ""),
                            description = obj.optString("description", ""),
                            amount = obj.optDouble("amount", 0.0),
                            date = obj.optString("date", ""),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
            }

            if (root.has("repayments")) {
                val repayArray = root.getJSONArray("repayments")
                for (i in 0 until repayArray.length()) {
                    val obj = repayArray.getJSONObject(i)
                    dao.insertRepayment(
                        LoanRepaymentEntity(
                            loanId = if (obj.has("loanId")) obj.optLong("loanId") else null,
                            lenderName = obj.optString("lenderName", ""),
                            amount = obj.optDouble("amount", 0.0),
                            description = obj.optString("description", ""),
                            date = obj.optString("date", ""),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
            }

            if (root.has("salaries")) {
                val salArray = root.getJSONArray("salaries")
                for (i in 0 until salArray.length()) {
                    val obj = salArray.getJSONObject(i)
                    dao.insertSalary(
                        SalaryEntity(
                            institution = obj.optString("institution", "মাদরাসা"),
                            year = obj.optInt("year", 2026),
                            monthIndex = obj.optInt("monthIndex", 1),
                            monthName = obj.optString("monthName", "জানুয়ারি"),
                            amount = obj.optDouble("amount", 0.0),
                            date = obj.optString("date", ""),
                            description = obj.optString("description", ""),
                            isPaid = obj.optBoolean("isPaid", true),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
            }

            true
        } catch (_: Exception) {
            false
        }
    }
}
