package com.example.data.repository

import com.example.data.model.*

object SampleData {

    val sampleCategories = listOf(
        "All",
        "Electronics",
        "Gadgets",
        "Home & Living",
        "Eco-Friendly Products",
        "Fitness",
        "Creative Products",
        "Tools",
        "Kitchen",
        "Automotive",
        "Handmade Products"
    )

    val sampleProfessions = listOf(
        "Software Engineer",
        "Industrial Designer",
        "Student / Researcher",
        "Hardware Innovator",
        "Courier / Logistics Specialist",
        "Small Business Owner",
        "Architect / Creator",
        "Marketing Specialist",
        "Other"
    )

    val sampleSellerSpaces = listOf(
        SellerSpace(
            id = "seller_apex",
            sellerId = "user_seller_1",
            name = "Apex Labs Modular Tech",
            handle = "@apexlabs",
            description = "Pioneering modular consumer electronics, open hardware accessories, and sustainable micro-computing gadgets.",
            logoUrl = "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=300",
            bannerColorHex = 0xFF1E293B,
            categories = listOf("Electronics", "Gadgets", "Creative Products"),
            followerCount = 3840,
            rating = 4.9,
            verified = true,
            innovations = listOf(
                InnovationPost(
                    id = "post_1",
                    title = "Solari Core Gen 2 - 40% Smaller Footprint",
                    content = "We just finished field testing our gen 2 magnetic modular power ring. Thermal dissipation improved by 35% using recycled aerospace aluminum.",
                    date = "Yesterday",
                    likesCount = 142,
                    imageUrl = "https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=500",
                    tags = listOf("Hardware", "Solar", "NextGen")
                ),
                InnovationPost(
                    id = "post_2",
                    title = "Open Source Blueprint Release",
                    content = "All mounting bracket schematics for our AeroBeam magnetic joints are now open for 3D printing enthusiasts in the Ignis ecosystem.",
                    date = "3 days ago",
                    likesCount = 89,
                    imageUrl = "",
                    tags = listOf("OpenSource", "3DPrinting")
                )
            )
        ),
        SellerSpace(
            id = "seller_terranova",
            sellerId = "user_seller_2",
            name = "TerraNova EcoLiving",
            handle = "@terranova",
            description = "Nature-infused tech. We craft carbon-negative home living accessories, smart micro-gardens, and biodegradable tech essentials.",
            logoUrl = "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=300",
            bannerColorHex = 0xFF064E3B,
            categories = listOf("Eco-Friendly Products", "Home & Living"),
            followerCount = 2190,
            rating = 4.8,
            verified = true,
            innovations = listOf(
                InnovationPost(
                    id = "post_3",
                    title = "Zero Plastic Packaging Milestone",
                    content = "100% of our shipment boxes are now made from mycelium compostable cushions manufactured locally.",
                    date = "May 14",
                    likesCount = 230,
                    imageUrl = "",
                    tags = listOf("Sustainability", "ZeroWaste")
                )
            )
        ),
        SellerSpace(
            id = "seller_sparklab",
            sellerId = "user_seller_3",
            name = "SparkLab Robotics",
            handle = "@sparklab",
            description = "Miniaturized robotics, sensor arrays, and kinetic energy harvesters designed for everyday creators.",
            logoUrl = "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=300",
            bannerColorHex = 0xFF312E81,
            categories = listOf("Gadgets", "Tools", "Fitness"),
            followerCount = 1750,
            rating = 4.95,
            verified = true,
            innovations = listOf(
                InnovationPost(
                    id = "post_4",
                    title = "Kinetic Generation in Rain Proof Casing",
                    content = "Tested KinetiCharge across a 42km gravel trail in heavy rainfall. Steady 15W continuous USB-C power maintained!",
                    date = "Last week",
                    likesCount = 94,
                    imageUrl = "",
                    tags = listOf("Kinetic", "OutdoorTech")
                )
            )
        )
    )

    val sampleProducts = listOf(
        Product(
            id = "prod_1",
            sellerId = "user_seller_1",
            sellerName = "Apex Labs Modular Tech",
            sellerRating = 4.9,
            name = "Solari Core - Magnetic Modular Power Ring",
            description = "A sleek titanium-alloy magnetic ring power dock with swappable lithium-ceramic battery pods and rapid inductive Qi2 charging. Designed for ultra-portable, uninterrupted power on the go.",
            category = "Electronics",
            price = 89.00,
            stock = 24,
            imageUrl = "https://images.unsplash.com/photo-1550009158-9ebf69173e03?w=600",
            specifications = mapOf(
                "Capacity" to "10,000 mAh total",
                "Weight" to "145 grams",
                "Charging" to "15W Qi2 MagSafe & 30W USB-C PD",
                "Material" to "Aerospace Grade Recycled Titanium"
            ),
            deliveryAvailability = true,
            deliveryAreaKm = 30,
            distanceKm = 2.4,
            isInnovation = true,
            isFeatured = true,
            rating = 4.9,
            reviewCount = 58
        ),
        Product(
            id = "prod_2",
            sellerId = "user_seller_1",
            sellerName = "Apex Labs Modular Tech",
            sellerRating = 4.9,
            name = "AeroBeam Levitating Ambient Audio Lamp",
            description = "Combining magnetic levitation with a precision 360-degree planar magnetic speaker. Creates an ambient warm glow that synchronizes with acoustic resonance.",
            category = "Gadgets",
            price = 145.00,
            stock = 12,
            imageUrl = "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=600",
            specifications = mapOf(
                "Audio Driver" to "Planar Magnetic 45mm",
                "Illumination" to "2200K - 6500K Tunable LED",
                "Levitation Gap" to "18 mm stable magnetic float"
            ),
            deliveryAvailability = true,
            deliveryAreaKm = 20,
            distanceKm = 2.4,
            isInnovation = true,
            isFeatured = true,
            rating = 4.85,
            reviewCount = 31
        ),
        Product(
            id = "prod_3",
            sellerId = "user_seller_2",
            sellerName = "TerraNova EcoLiving",
            sellerRating = 4.8,
            name = "TerraBiome Smart Self-Watering Micro-Terrarium",
            description = "Living moss terrarium fitted with passive moisture sensors, ambient micro-misting nozzle, and gentle solar-spectrum LED base.",
            category = "Home & Living",
            price = 68.50,
            stock = 30,
            imageUrl = "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=600",
            specifications = mapOf(
                "Water Tank" to "300 ml (lasts 60 days)",
                "Plant Species" to "Preserved Cushion & Reindeer Moss",
                "Glass" to "Hand-blown Borosilicate"
            ),
            deliveryAvailability = true,
            deliveryAreaKm = 25,
            distanceKm = 4.1,
            isInnovation = true,
            isFeatured = false,
            rating = 4.8,
            reviewCount = 27
        ),
        Product(
            id = "prod_4",
            sellerId = "user_seller_2",
            sellerName = "TerraNova EcoLiving",
            sellerRating = 4.8,
            name = "BioFilter Bamboo Activated Water Purifier",
            description = "Natural carbon gravity filtration housed in a sustainable carved moso bamboo carafe. Purifies 1 liter of water in under 4 minutes without electricity.",
            category = "Eco-Friendly Products",
            price = 44.00,
            stock = 45,
            imageUrl = "https://images.unsplash.com/photo-1523362628745-0c100150b504?w=600",
            specifications = mapOf(
                "Filter Life" to "400 Gallons (~6 months)",
                "Purity" to "99.9% Chlorine, Microplastics, Heavy Metals",
                "Carafe" to "Treated Organic Bamboo & Food-Grade Silicone"
            ),
            deliveryAvailability = true,
            deliveryAreaKm = 25,
            distanceKm = 4.1,
            isInnovation = true,
            isFeatured = true,
            rating = 4.75,
            reviewCount = 42
        ),
        Product(
            id = "prod_5",
            sellerId = "user_seller_3",
            sellerName = "SparkLab Robotics",
            sellerRating = 4.95,
            name = "KinetiCharge Kinetic Heel Energy Generator",
            description = "Compact biomechanical generator that attaches securely to your athletic shoes. Charges power banks and smartphones as you walk, jog, or hike.",
            category = "Fitness",
            price = 95.00,
            stock = 18,
            imageUrl = "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600",
            specifications = mapOf(
                "Output" to "5V / 2.4A USB-C fast burst",
                "Stride efficiency" to "3W per standard walking kilometer",
                "Waterproofing" to "IP67 submersible"
            ),
            deliveryAvailability = true,
            deliveryAreaKm = 35,
            distanceKm = 6.2,
            isInnovation = true,
            isFeatured = true,
            rating = 4.95,
            reviewCount = 19
        ),
        Product(
            id = "prod_6",
            sellerId = "user_seller_3",
            sellerName = "SparkLab Robotics",
            sellerRating = 4.95,
            name = "PrecisionLaser 3D Room & Object Scanner Pen",
            description = "Pocket-sized dual-laser lidar pen that projects instant millimeter-accurate CAD dimensions onto your smartphone.",
            category = "Tools",
            price = 119.00,
            stock = 8,
            imageUrl = "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600",
            specifications = mapOf(
                "Range" to "0.05m to 40m",
                "Accuracy" to "± 1.0 mm",
                "Display" to "OLED High-Contrast HUD"
            ),
            deliveryAvailability = true,
            deliveryAreaKm = 30,
            distanceKm = 6.2,
            isInnovation = true,
            isFeatured = false,
            rating = 4.9,
            reviewCount = 38
        )
    )

    val sampleDeliveryPartners = listOf(
        DeliveryPartner(
            id = "dp_1",
            name = "Marcus Vance",
            vehicle = VehicleType.MOTORCYCLE,
            vehiclePlate = "IG-902-MV",
            rating = 4.92,
            completedDeliveries = 348,
            experienceYears = 3,
            isAvailable = true,
            distanceKm = 1.8,
            approximateArea = "Downtown Innovation District",
            phone = "+1 (555) 234-8901"
        ),
        DeliveryPartner(
            id = "dp_2",
            name = "Elena Rostova",
            vehicle = VehicleType.SCOOTER,
            vehiclePlate = "EV-441-EL",
            rating = 4.98,
            completedDeliveries = 520,
            experienceYears = 4,
            isAvailable = true,
            distanceKm = 2.4,
            approximateArea = "Eastside Tech Park",
            phone = "+1 (555) 345-9012"
        ),
        DeliveryPartner(
            id = "dp_3",
            name = "Devon Reed",
            vehicle = VehicleType.BICYCLE,
            vehiclePlate = "BIKE-08",
            rating = 4.85,
            completedDeliveries = 194,
            experienceYears = 1,
            isAvailable = true,
            distanceKm = 0.9,
            approximateArea = "Central Arts Quarter",
            phone = "+1 (555) 456-0123"
        ),
        DeliveryPartner(
            id = "dp_4",
            name = "Tariq Mansour",
            vehicle = VehicleType.CAR,
            vehiclePlate = "EV-782-TM",
            rating = 4.90,
            completedDeliveries = 812,
            experienceYears = 5,
            isAvailable = false,
            distanceKm = 4.2,
            approximateArea = "Metro West Heights",
            phone = "+1 (555) 567-1234"
        )
    )

    val sampleOrders = listOf(
        Order(
            id = "ord_101",
            orderNumber = "IGN-84920",
            consumerId = "user_consumer_1",
            consumerName = "Maya Chen",
            sellerId = "user_seller_1",
            sellerName = "Apex Labs Modular Tech",
            deliveryPartnerId = "dp_1",
            deliveryPartnerName = "Marcus Vance",
            deliveryPartnerPhone = "+1 (555) 234-8901",
            items = listOf(
                CartItem(product = sampleProducts[0], quantity = 1)
            ),
            subtotal = 89.00,
            deliveryCharge = 4.50,
            platformFee = 4.45,
            total = 97.95,
            status = OrderStatus.ON_THE_WAY,
            deliveryAddress = DeliveryAddress(
                fullName = "Maya Chen",
                phone = "+1 (555) 019-2834",
                street = "424 Pioneer Way, Suite 300",
                city = "New Tech City",
                state = "CA",
                postalCode = "94016",
                instructions = "Leave at lobby reception or call upon arrival"
            ),
            createdAt = System.currentTimeMillis() - 42 * 60 * 1000,
            estimatedDeliveryMinutes = 12
        ),
        Order(
            id = "ord_102",
            orderNumber = "IGN-77312",
            consumerId = "user_consumer_1",
            consumerName = "Maya Chen",
            sellerId = "user_seller_2",
            sellerName = "TerraNova EcoLiving",
            deliveryPartnerId = "dp_2",
            deliveryPartnerName = "Elena Rostova",
            deliveryPartnerPhone = "+1 (555) 345-9012",
            items = listOf(
                CartItem(product = sampleProducts[3], quantity = 1)
            ),
            subtotal = 44.00,
            deliveryCharge = 3.50,
            platformFee = 2.20,
            total = 49.70,
            status = OrderStatus.DELIVERED,
            deliveryAddress = DeliveryAddress(
                fullName = "Maya Chen",
                phone = "+1 (555) 019-2834",
                street = "424 Pioneer Way, Suite 300",
                city = "New Tech City",
                state = "CA",
                postalCode = "94016"
            ),
            createdAt = System.currentTimeMillis() - 3 * 3600 * 1000,
            estimatedDeliveryMinutes = 0
        )
    )

    val sampleChats = listOf(
        Chat(
            id = "chat_1",
            orderId = "ord_101",
            otherPartyId = "user_seller_1",
            otherPartyName = "Apex Labs Modular Tech",
            otherPartyRole = UserRole.SELLER,
            lastMessage = "We've packed your Solari Core with extra protective wrap!",
            lastTimestamp = System.currentTimeMillis() - 25 * 60 * 1000,
            unreadCount = 0,
            messages = listOf(
                ChatMessage(
                    id = "msg_1",
                    senderId = "user_consumer_1",
                    senderName = "Maya Chen",
                    senderRole = UserRole.CONSUMER,
                    text = "Hello! Does the power ring come with the titanium adapter in the box?",
                    timestamp = System.currentTimeMillis() - 40 * 60 * 1000
                ),
                ChatMessage(
                    id = "msg_2",
                    senderId = "user_seller_1",
                    senderName = "Apex Labs",
                    senderRole = UserRole.SELLER,
                    text = "Yes absolutely Maya! It includes both the MagSafe plate and the titanium adapter.",
                    timestamp = System.currentTimeMillis() - 32 * 60 * 1000
                ),
                ChatMessage(
                    id = "msg_3",
                    senderId = "user_seller_1",
                    senderName = "Apex Labs",
                    senderRole = UserRole.SELLER,
                    text = "We've packed your Solari Core with extra protective wrap!",
                    timestamp = System.currentTimeMillis() - 25 * 60 * 1000
                )
            )
        ),
        Chat(
            id = "chat_2",
            orderId = "ord_101",
            otherPartyId = "dp_1",
            otherPartyName = "Marcus Vance (Delivery)",
            otherPartyRole = UserRole.DELIVERY_PARTNER,
            lastMessage = "I am 5 minutes away on my motorcycle. Will meet you at front lobby!",
            lastTimestamp = System.currentTimeMillis() - 5 * 60 * 1000,
            unreadCount = 1,
            messages = listOf(
                ChatMessage(
                    id = "msg_dp_1",
                    senderId = "dp_1",
                    senderName = "Marcus Vance",
                    senderRole = UserRole.DELIVERY_PARTNER,
                    text = "Hi Maya! Just picked up your order from Apex Labs.",
                    timestamp = System.currentTimeMillis() - 15 * 60 * 1000
                ),
                ChatMessage(
                    id = "msg_dp_2",
                    senderId = "user_consumer_1",
                    senderName = "Maya Chen",
                    senderRole = UserRole.CONSUMER,
                    text = "Awesome, thank you Marcus! The reception desk has parking right in front.",
                    timestamp = System.currentTimeMillis() - 10 * 60 * 1000
                ),
                ChatMessage(
                    id = "msg_dp_3",
                    senderId = "dp_1",
                    senderName = "Marcus Vance",
                    senderRole = UserRole.DELIVERY_PARTNER,
                    text = "I am 5 minutes away on my motorcycle. Will meet you at front lobby!",
                    timestamp = System.currentTimeMillis() - 5 * 60 * 1000
                )
            )
        )
    )

    val sampleNotifications = listOf(
        NotificationItem(
            id = "notif_1",
            title = "Order on the way! ⚡",
            message = "Marcus Vance is on the way with your Solari Core. ETA 12 mins.",
            roleTarget = UserRole.CONSUMER,
            type = NotificationType.ORDER
        ),
        NotificationItem(
            id = "notif_2",
            title = "New Delivery Opportunity",
            message = "Pickup available at Apex Labs (1.8 km) - Est. Earning: $8.50",
            roleTarget = UserRole.DELIVERY_PARTNER,
            type = NotificationType.DELIVERY
        ),
        NotificationItem(
            id = "notif_3",
            title = "New Order Placed",
            message = "Order IGN-84920 received for Solari Core.",
            roleTarget = UserRole.SELLER,
            type = NotificationType.ORDER
        )
    )
}
