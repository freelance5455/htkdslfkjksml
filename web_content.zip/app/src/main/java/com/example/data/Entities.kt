package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class BookEntity(
    @PrimaryKey val id: String,
    val title: String,
    val filename: String,
    val localFilePath: String,
    val uriString: String? = null,
    val fileSize: Long,
    val totalPages: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val lastReadPage: Int = 1,
    val lastReadTime: Long = System.currentTimeMillis(),
    val zoom: Float = 1.0f
)

@Entity(tableName = "page_annotations", primaryKeys = ["bookId", "pageNumber"])
data class PageAnnotationEntity(
    val bookId: String,
    val pageNumber: Int,
    val strokesJson: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "piece_templates")
data class PieceTemplateEntity(
    @PrimaryKey val id: String, // "${bookId}_${pieceCode}_${squareShade}"
    val bookId: String,
    val pieceCode: String,
    val squareShade: String,
    val sampleCount: Int,
    val pixelsBlob: String, // compact comma-separated floats (length 1024)
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "catalog_diagrams")
data class CatalogDiagramEntity(
    @PrimaryKey val id: String,
    val bookId: String,
    val pageNumber: Int,
    val title: String,
    val fen: String,
    val turn: String,
    val confidence: Float,
    val sourceMethod: String,
    val cropX: Int,
    val cropY: Int,
    val cropW: Int,
    val cropH: Int,
    val uncertainSquaresCsv: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pms_positions")
data class PmsPositionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val fen: String,
    val bookId: String? = null,
    val bookTitle: String? = null,
    val pageNumber: Int? = null,
    val note: String = "",
    val turn: String = "w",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "imported_games")
data class ImportedGameEntity(
    @PrimaryKey val id: String,
    val platform: String, // "lichess", "chesscom", "pgn"
    val white: String,
    val black: String,
    val whiteRating: Int? = null,
    val blackRating: Int? = null,
    val result: String = "*",
    val datePlayed: String = "",
    val openingName: String = "",
    val pgn: String,
    val importedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "study_notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val tags: String = "",
    val linkedFen: String? = null,
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

enum class PrinciplePhase(val label: String) {
    OPENING("Opening"),
    MIDDLEGAME("Middlegame"),
    ENDGAME("Endgame")
}

@Entity(tableName = "chess_principles")
data class PrincipleEntity(
    @PrimaryKey val id: String,
    val phase: String, // OPENING, MIDDLEGAME, ENDGAME
    val title: String,
    val description: String,
    val linkedFen: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_settings")
data class AppSettingEntity(
    @PrimaryKey val key: String,
    val value: String
)

data class PdfAnnotationStroke(
    val id: String,
    val tool: String, // "pen", "highlighter", "text"
    val colorHex: Long,
    val strokeWidth: Float,
    val points: List<Pair<Float, Float>>, // normalized [0..1] page coordinates
    val text: String = ""
)
