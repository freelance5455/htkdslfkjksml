package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        BookEntity::class,
        PageAnnotationEntity::class,
        PieceTemplateEntity::class,
        CatalogDiagramEntity::class,
        PmsPositionEntity::class,
        ImportedGameEntity::class,
        NoteEntity::class,
        PrincipleEntity::class,
        AppSettingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MoonChessDatabase : RoomDatabase() {
    abstract fun dao(): MoonChessDao

    companion object {
        @Volatile
        private var INSTANCE: MoonChessDatabase? = null

        fun getInstance(context: Context): MoonChessDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MoonChessDatabase::class.java,
                    "moonchess_offline.db"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
