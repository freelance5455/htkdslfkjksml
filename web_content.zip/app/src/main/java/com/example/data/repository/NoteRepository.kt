package com.example.data.repository

import com.example.data.dao.NoteDao
import com.example.data.model.NoteEntity
import com.example.data.notes.RichNoteDocument
import kotlinx.coroutines.flow.Flow

class NoteRepository(
    private val noteDao: NoteDao
) {
    val allNotesFlow: Flow<List<NoteEntity>> = noteDao.getAllNotesFlow()

    suspend fun getNoteById(id: Long): NoteEntity? = noteDao.getNoteById(id)

    suspend fun createNote(
        title: String,
        document: RichNoteDocument,
        subjectId: Long? = null,
        isPinned: Boolean = false
    ): Long {
        val now = System.currentTimeMillis()
        val plainPreview = document.toPreviewText()
        val entity = NoteEntity(
            title = title.trim(),
            contentJson = document.toJson(),
            plainTextPreview = plainPreview,
            subjectId = subjectId,
            isPinned = isPinned,
            fontFamily = document.fontFamily,
            fontSize = document.fontSize,
            textAlign = document.alignment.key,
            createdAt = now,
            updatedAt = now
        )
        return noteDao.insertNote(entity)
    }

    suspend fun updateNote(
        id: Long,
        title: String,
        document: RichNoteDocument,
        subjectId: Long? = null,
        isPinned: Boolean = false,
        createdAt: Long
    ) {
        val now = System.currentTimeMillis()
        val plainPreview = document.toPreviewText()
        val entity = NoteEntity(
            id = id,
            title = title.trim(),
            contentJson = document.toJson(),
            plainTextPreview = plainPreview,
            subjectId = subjectId,
            isPinned = isPinned,
            fontFamily = document.fontFamily,
            fontSize = document.fontSize,
            textAlign = document.alignment.key,
            createdAt = createdAt,
            updatedAt = now
        )
        noteDao.updateNote(entity)
    }

    suspend fun togglePin(id: Long, isPinned: Boolean) {
        noteDao.setPinned(id, isPinned)
    }

    suspend fun deleteNote(id: Long) {
        noteDao.deleteNote(id)
    }

    suspend fun deleteAll() {
        noteDao.deleteAll()
    }
}
