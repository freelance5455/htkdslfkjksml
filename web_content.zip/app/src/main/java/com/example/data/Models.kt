package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.R
import com.example.ui.theme.ChemistryColor
import com.example.ui.theme.ComputerSciColor
import com.example.ui.theme.MathsColor
import com.example.ui.theme.PhysicsColor

enum class Subject(
  val displayName: String,
  val shortCode: String,
  val color: Color
) {
  PHYSICS("Physics", "PHY", PhysicsColor),
  CHEMISTRY("Chemistry", "CHEM", ChemistryColor),
  MATHEMATICS("Mathematics", "MATH", MathsColor),
  COMPUTER_SCIENCE("Computer Science", "CS", ComputerSciColor);

  companion object {
    fun fromString(name: String): Subject {
      return entries.firstOrNull { it.name.equals(name, ignoreCase = true) || it.displayName.equals(name, ignoreCase = true) }
        ?: COMPUTER_SCIENCE
    }
  }
}

data class Chapter(
  val id: String,
  val subject: Subject,
  val title: String,
  val isCompleted: Boolean = false,
  val isCustom: Boolean = false
)

data class StudySession(
  val id: String,
  val subject: Subject,
  val durationMinutes: Int,
  val timestamp: Long,
  val dateFormatted: String
)

data class QuizQuestion(
  val id: String,
  val subject: Subject,
  val chapterTitle: String,
  val question: String,
  val options: List<String>,
  val correctIndex: Int,
  val explanation: String
)

data class WrongAnswerDetail(
  val question: String,
  val selectedAnswer: String,
  val correctAnswer: String,
  val explanation: String
)

data class QuizResult(
  val id: String,
  val subject: Subject,
  val chapterTitle: String,
  val score: Int,
  val total: Int,
  val timestamp: Long,
  val dateFormatted: String,
  val wrongAnswers: List<WrongAnswerDetail> = emptyList()
)

enum class SenseiCharacter(
  val charName: String,
  val title: String,
  val catchphrase: String,
  val avatarRes: Int
) {
  NARUTO(
    charName = "Naruto Uzumaki",
    title = "Energetic Hokage in Training",
    catchphrase = "Believe it! Dattebayo!",
    avatarRes = R.drawable.img_naruto_avatar
  ),
  HINATA(
    charName = "Hinata Hyuga",
    title = "Gentle & Patient Master",
    catchphrase = "Step by step, I believe in you!",
    avatarRes = R.drawable.img_hinata_avatar
  )
}

data class ChatMessage(
  val id: String,
  val senderName: String,
  val text: String,
  val timestamp: Long,
  val isUser: Boolean,
  val character: SenseiCharacter? = null
)

data class NinjaRank(
  val title: String,
  val requiredProgress: Int,
  val badgeDescription: String,
  val badgeEmoji: String
) {
  companion object {
    fun calculateRank(percentage: Int): NinjaRank {
      return when {
        percentage >= 90 -> NinjaRank("Hokage", 90, "Supreme Legend of the Study Dojo!", "🔥 ⚡")
        percentage >= 70 -> NinjaRank("Jonin", 70, "Elite Master of Plus Two Science", "🌀 📜")
        percentage >= 50 -> NinjaRank("Special Jonin", 50, "Computer Science Specialist", "💻 🎯")
        percentage >= 25 -> NinjaRank("Chunin", 25, "Battle-hardened Student Ninja", "⚔️ 🛡️")
        percentage >= 10 -> NinjaRank("Genin", 10, "Official Shinobi of the Leaf", "🍃 🏃")
        else -> NinjaRank("Academy Student", 0, "Beginning the Study Ninja Way", "🌱 📖")
      }
    }
  }
}
