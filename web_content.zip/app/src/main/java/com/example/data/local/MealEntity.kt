package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "meals")
data class MealEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val calories: Int,
    val protein: Float,
    val carbs: Float,
    val fat: Float,
    val mealType: String, // BREAKFAST, LUNCH, DINNER, SNACK
    val timestamp: Long = System.currentTimeMillis(),
    val dateString: String, // e.g. "2026-11-07"
    val servingSize: String = "یک وعده",
    val healthScore: Int = 80,
    val advice: String = ""
)
