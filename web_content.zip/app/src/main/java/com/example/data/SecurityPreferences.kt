package com.example.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import org.json.JSONArray
import org.json.JSONObject

data class InterceptionLog(
    val timestamp: Long,
    val reason: String,
    val targetApp: String
)

class SecurityPreferences(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("tecnoguard_security_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PIN_HASH = "key_pin_hash"
        private const val KEY_PIN_SALT = "key_pin_salt"
        private const val KEY_PROTECT_POWER = "key_protect_power"
        private const val KEY_PROTECT_MEMORY = "key_protect_memory"
        private const val KEY_PROTECT_ADMIN_ACCESSIBILITY = "key_protect_admin_acc"
        private const val KEY_PROTECT_DESKTOP = "key_protect_desktop"
        private const val KEY_GRACE_PERIOD_UNTIL = "key_grace_period_until"
        private const val KEY_SETUP_NAVIGATION_UNTIL = "key_setup_nav_until"
        private const val KEY_INTERCEPTION_LOGS = "key_interception_logs"
        private const val KEY_FAILED_ATTEMPTS = "key_failed_attempts"

        @Volatile
        private var INSTANCE: SecurityPreferences? = null

        fun getInstance(context: Context): SecurityPreferences {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SecurityPreferences(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    val isPinSet: Boolean
        get() = prefs.getString(KEY_PIN_HASH, null)?.isNotEmpty() == true

    fun setPin(pin: String): Boolean {
        if (pin.length != 6 || !pin.all { it.isDigit() }) return false
        val salt = System.currentTimeMillis().toString()
        val hash = hashPin(pin, salt)
        prefs.edit()
            .putString(KEY_PIN_SALT, salt)
            .putString(KEY_PIN_HASH, hash)
            .apply()
        return true
    }

    fun verifyPin(pin: String): Boolean {
        if (pin.length != 6) return false
        val storedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val salt = prefs.getString(KEY_PIN_SALT, "") ?: ""
        val matches = hashPin(pin, salt) == storedHash
        if (matches) {
            resetFailedAttempts()
        } else {
            incrementFailedAttempts()
        }
        return matches
    }

    private fun hashPin(pin: String, salt: String): String {
        val input = "$pin::$salt::tecnoguard_secure_salt_2026"
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // Protection Toggles
    var isPowerProtected: Boolean
        get() = prefs.getBoolean(KEY_PROTECT_POWER, true)
        set(value) = prefs.edit().putBoolean(KEY_PROTECT_POWER, value).apply()

    var isMemoryProtected: Boolean
        get() = prefs.getBoolean(KEY_PROTECT_MEMORY, true)
        set(value) = prefs.edit().putBoolean(KEY_PROTECT_MEMORY, value).apply()

    var isAdminAndAccessibilityProtected: Boolean
        get() = prefs.getBoolean(KEY_PROTECT_ADMIN_ACCESSIBILITY, true)
        set(value) = prefs.edit().putBoolean(KEY_PROTECT_ADMIN_ACCESSIBILITY, value).apply()

    var isDesktopProtected: Boolean
        get() = prefs.getBoolean(KEY_PROTECT_DESKTOP, true)
        set(value) = prefs.edit().putBoolean(KEY_PROTECT_DESKTOP, value).apply()

    // Temporary Grace Period when user enters PIN to legitimately change settings
    fun grantTemporaryAccess(durationSeconds: Long = 25) {
        val until = System.currentTimeMillis() + (durationSeconds * 1000)
        prefs.edit().putLong(KEY_GRACE_PERIOD_UNTIL, until).apply()
    }

    fun isGracePeriodActive(): Boolean {
        val until = prefs.getLong(KEY_GRACE_PERIOD_UNTIL, 0L)
        return System.currentTimeMillis() < until
    }

    fun revokeTemporaryAccess() {
        prefs.edit().putLong(KEY_GRACE_PERIOD_UNTIL, 0L).apply()
    }

    // Allow user to navigate to system settings from within TecnoGuard without self-blocking
    fun grantSetupNavigationAccess(durationSeconds: Long = 45) {
        val until = System.currentTimeMillis() + (durationSeconds * 1000)
        prefs.edit().putLong(KEY_SETUP_NAVIGATION_UNTIL, until).apply()
    }

    fun isSetupNavigationActive(): Boolean {
        val until = prefs.getLong(KEY_SETUP_NAVIGATION_UNTIL, 0L)
        return System.currentTimeMillis() < until
    }

    // Failed attempts & logs
    val failedAttempts: Int
        get() = prefs.getInt(KEY_FAILED_ATTEMPTS, 0)

    private fun incrementFailedAttempts() {
        val count = failedAttempts + 1
        prefs.edit().putInt(KEY_FAILED_ATTEMPTS, count).apply()
    }

    private fun resetFailedAttempts() {
        prefs.edit().putInt(KEY_FAILED_ATTEMPTS, 0).apply()
    }

    fun logInterception(reason: String, targetApp: String) {
        val logs = getInterceptionLogs().toMutableList()
        logs.add(0, InterceptionLog(System.currentTimeMillis(), reason, targetApp))
        // keep last 50 logs
        val trimmed = logs.take(50)
        val jsonArray = JSONArray()
        for (item in trimmed) {
            val obj = JSONObject()
            obj.put("timestamp", item.timestamp)
            obj.put("reason", item.reason)
            obj.put("targetApp", item.targetApp)
            jsonArray.put(obj)
        }
        prefs.edit().putString(KEY_INTERCEPTION_LOGS, jsonArray.toString()).apply()
    }

    fun getInterceptionLogs(): List<InterceptionLog> {
        val jsonStr = prefs.getString(KEY_INTERCEPTION_LOGS, null) ?: return emptyList()
        val list = mutableListOf<InterceptionLog>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    InterceptionLog(
                        timestamp = obj.optLong("timestamp", 0L),
                        reason = obj.optString("reason", ""),
                        targetApp = obj.optString("targetApp", "")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun clearLogs() {
        prefs.edit().remove(KEY_INTERCEPTION_LOGS).apply()
    }
}
