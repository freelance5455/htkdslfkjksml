package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import com.example.model.ProtectedSection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap

data class SecuritySettingsSnapshot(
    val hasPin: Boolean = false,
    val masterProtectionEnabled: Boolean = true,
    val protectPowerAndReboot: Boolean = true,
    val protectAccessibilityAndAdmin: Boolean = true,
    val protectDesktopSettings: Boolean = true,
    val interceptionCount: Int = 0,
)

class SecurityPreferences private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val temporaryUnlockExpiry = ConcurrentHashMap<ProtectedSection, Long>()

    private val _settingsFlow = MutableStateFlow(readSnapshot())
    val settingsFlow: StateFlow<SecuritySettingsSnapshot> = _settingsFlow.asStateFlow()

    fun hasPin(): Boolean = !prefs.getString(KEY_PIN_HASH, null).isNullOrEmpty()

    fun savePin(pin: String) {
        require(pin.length == 6 && pin.all { it.isDigit() }) {
            "El PIN debe tener exactamente 6 dígitos numéricos."
        }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val saltEncoded = Base64.encodeToString(salt, Base64.NO_WRAP)
        val hash = hashPin(pin, saltEncoded)
        prefs.edit()
            .putString(KEY_PIN_SALT, saltEncoded)
            .putString(KEY_PIN_HASH, hash)
            .apply()
        refreshFlow()
    }

    fun verifyPin(pin: String): Boolean {
        if (pin.length != 6 || !pin.all { it.isDigit() }) return false
        val savedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val salt = prefs.getString(KEY_PIN_SALT, null) ?: return false
        val candidateHash = hashPin(pin, salt)
        return MessageDigest.isEqual(
            savedHash.toByteArray(Charsets.UTF_8),
            candidateHash.toByteArray(Charsets.UTF_8),
        )
    }

    fun isMasterProtectionEnabled(): Boolean =
        prefs.getBoolean(KEY_MASTER_PROTECTION, true)

    fun setMasterProtectionEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_MASTER_PROTECTION, enabled).apply()
        if (!enabled) clearTemporaryAccess()
        refreshFlow()
    }

    fun setProtectPowerAndReboot(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PROTECT_POWER, enabled).apply()
        refreshFlow()
    }

    fun setProtectAccessibilityAndAdmin(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PROTECT_ADMIN, enabled).apply()
        refreshFlow()
    }

    fun setProtectDesktopSettings(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PROTECT_DESKTOP, enabled).apply()
        refreshFlow()
    }

    fun isRuleEnabled(section: ProtectedSection): Boolean {
        if (!isMasterProtectionEnabled()) return false
        return when (section) {
            ProtectedSection.POWER_AND_REBOOT -> prefs.getBoolean(KEY_PROTECT_POWER, true)
            ProtectedSection.ACCESSIBILITY_AND_ADMIN -> prefs.getBoolean(KEY_PROTECT_ADMIN, true)
            ProtectedSection.DESKTOP_SETTINGS -> prefs.getBoolean(KEY_PROTECT_DESKTOP, true)
        }
    }

    fun recordInterception() {
        val updated = prefs.getInt(KEY_INTERCEPTION_COUNT, 0) + 1
        prefs.edit().putInt(KEY_INTERCEPTION_COUNT, updated).apply()
        refreshFlow()
    }

    fun grantTemporaryAccess(section: ProtectedSection, durationMs: Long = DEFAULT_GRACE_MS) {
        temporaryUnlockExpiry[section] = System.currentTimeMillis() + durationMs
    }

    fun hasTemporaryAccess(section: ProtectedSection): Boolean {
        val expiry = temporaryUnlockExpiry[section] ?: return false
        if (System.currentTimeMillis() < expiry) {
            return true
        }
        temporaryUnlockExpiry.remove(section)
        return false
    }

    fun clearTemporaryAccess() {
        temporaryUnlockExpiry.clear()
    }

    private fun readSnapshot(): SecuritySettingsSnapshot = SecuritySettingsSnapshot(
        hasPin = hasPin(),
        masterProtectionEnabled = prefs.getBoolean(KEY_MASTER_PROTECTION, true),
        protectPowerAndReboot = prefs.getBoolean(KEY_PROTECT_POWER, true),
        protectAccessibilityAndAdmin = prefs.getBoolean(KEY_PROTECT_ADMIN, true),
        protectDesktopSettings = prefs.getBoolean(KEY_PROTECT_DESKTOP, true),
        interceptionCount = prefs.getInt(KEY_INTERCEPTION_COUNT, 0),
    )

    private fun refreshFlow() {
        _settingsFlow.value = readSnapshot()
    }

    private fun hashPin(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest("$salt:$pin".toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    companion object {
        private const val PREFS_NAME = "escudo_pin_security_prefs"
        private const val KEY_PIN_HASH = "pin_hash"
        private const val KEY_PIN_SALT = "pin_salt"
        private const val KEY_MASTER_PROTECTION = "master_protection_enabled"
        private const val KEY_PROTECT_POWER = "protect_power_and_reboot"
        private const val KEY_PROTECT_ADMIN = "protect_accessibility_and_admin"
        private const val KEY_PROTECT_DESKTOP = "protect_desktop_settings"
        private const val KEY_INTERCEPTION_COUNT = "interception_count"
        private const val DEFAULT_GRACE_MS = 20_000L

        @Volatile
        private var instance: SecurityPreferences? = null

        fun getInstance(context: Context): SecurityPreferences {
            return instance ?: synchronized(this) {
                instance ?: SecurityPreferences(context).also { instance = it }
            }
        }
    }
}
