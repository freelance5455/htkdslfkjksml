package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "prozheyar_prefs")

class ThemePreferences(private val context: Context) {
    private val themeModeKey = stringPreferencesKey("theme_mode")
    private val ownerNameKey = stringPreferencesKey("workspace_owner_name")
    private val desktopPreviewKey = booleanPreferencesKey("force_desktop_layout")

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        val raw = prefs[themeModeKey] ?: ThemeMode.SYSTEM.name
        ThemeMode.entries.firstOrNull { it.name == raw } ?: ThemeMode.SYSTEM
    }

    val ownerName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[ownerNameKey] ?: "فضای کاری شخصی"
    }

    val forceDesktopLayout: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[desktopPreviewKey] ?: false
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[themeModeKey] = mode.name
        }
    }

    suspend fun setOwnerName(name: String) {
        context.dataStore.edit { prefs ->
            prefs[ownerNameKey] = name.trim().ifBlank { "فضای کاری شخصی" }
        }
    }

    suspend fun setForceDesktopLayout(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[desktopPreviewKey] = enabled
        }
    }
}
