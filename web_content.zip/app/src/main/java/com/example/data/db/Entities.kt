package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "information_records")
data class InformationRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val transactionNumber: Long,
    val name: String,
    val age: String,
    val place: String,
    val address: String,
    val phone1: String,
    val phone2: String,
    val email: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "vault_files")
data class VaultFile(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fileName: String,
    val category: String, // Photos, Videos, Audio, Documents, APKS, Archives, Downloads
    val filePath: String,
    val mimeType: String,
    val sizeBytes: Long,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "pdf_documents")
data class PdfDocumentRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val fileName: String,
    val filePath: String,
    val pageCount: Int,
    val sizeBytes: Long,
    val createdAt: Long = System.currentTimeMillis()
)
