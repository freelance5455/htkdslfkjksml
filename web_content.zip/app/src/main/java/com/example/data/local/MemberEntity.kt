package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Room Entity for storing member and committee records locally for full offline support.
 */
@Entity(
    tableName = "members",
    indices = [
        Index(value = ["type"]),
        Index(value = ["union"]),
        Index(value = ["timestamp"]),
        Index(value = ["syncedToSheet"])
    ]
)
data class MemberEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "leader" or "worker"
    val union: String = "",
    val ward: String = "",
    // Leadership / Committee Fields
    val sovapotiName: String = "",
    val sovapotiMobile: String = "",
    val sovapotiFb: String = "",
    val secretaryName: String = "",
    val secretaryMobile: String = "",
    val secretaryFb: String = "",
    val otherDesignation: String = "",
    val otherName: String = "",
    val otherMobile: String = "",
    val otherFb: String = "",
    // Worker / Member Fields
    val workerName: String = "",
    val workerDesignation: String = "",
    val workerMobile: String = "",
    val workerFb: String = "",
    // Metadata & Offline Sync Status
    val createdAt: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val syncedToSheet: Boolean = false
)
