package com.example.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PreferencesManager(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("study_dojo_prefs", Context.MODE_PRIVATE)

  private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
  private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

  fun isDarkMode(): Boolean {
    return prefs.getBoolean("dark_mode", true)
  }

  fun setDarkMode(enabled: Boolean) {
    prefs.edit().putBoolean("dark_mode", enabled).apply()
  }

  // --- Chapters Management ---
  fun loadChapters(): List<Chapter> {
    val jsonString = prefs.getString("chapters_json", null)
    if (jsonString.isNullOrEmpty()) {
      val defaults = DefaultData.getDefaultChapters()
      saveChapters(defaults)
      return defaults
    }
    return try {
      val array = JSONArray(jsonString)
      val result = mutableListOf<Chapter>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        result.add(
          Chapter(
            id = obj.getString("id"),
            subject = Subject.fromString(obj.getString("subject")),
            title = obj.getString("title"),
            isCompleted = obj.optBoolean("isCompleted", false),
            isCustom = obj.optBoolean("isCustom", false)
          )
        )
      }
      result
    } catch (e: Exception) {
      DefaultData.getDefaultChapters()
    }
  }

  fun saveChapters(chapters: List<Chapter>) {
    val array = JSONArray()
    chapters.forEach { c ->
      val obj = JSONObject().apply {
        put("id", c.id)
        put("subject", c.subject.name)
        put("title", c.title)
        put("isCompleted", c.isCompleted)
        put("isCustom", c.isCustom)
      }
      array.put(obj)
    }
    prefs.edit().putString("chapters_json", array.toString()).apply()
  }

  // --- Study Sessions ---
  fun loadStudySessions(): List<StudySession> {
    val jsonString = prefs.getString("sessions_json", null) ?: return emptyList()
    return try {
      val array = JSONArray(jsonString)
      val list = mutableListOf<StudySession>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        list.add(
          StudySession(
            id = obj.getString("id"),
            subject = Subject.fromString(obj.getString("subject")),
            durationMinutes = obj.getInt("durationMinutes"),
            timestamp = obj.getLong("timestamp"),
            dateFormatted = obj.getString("dateFormatted")
          )
        )
      }
      list.sortedByDescending { it.timestamp }
    } catch (e: Exception) {
      emptyList()
    }
  }

  fun addStudySession(subject: Subject, durationMinutes: Int): StudySession {
    val now = System.currentTimeMillis()
    val session = StudySession(
      id = "sess_${now}_${(100..999).random()}",
      subject = subject,
      durationMinutes = durationMinutes,
      timestamp = now,
      dateFormatted = "${dateFormat.format(Date(now))} • ${timeFormat.format(Date(now))}"
    )
    val current = loadStudySessions().toMutableList()
    current.add(0, session)
    val array = JSONArray()
    current.take(100).forEach { s ->
      val obj = JSONObject().apply {
        put("id", s.id)
        put("subject", s.subject.name)
        put("durationMinutes", s.durationMinutes)
        put("timestamp", s.timestamp)
        put("dateFormatted", s.dateFormatted)
      }
      array.put(obj)
    }
    prefs.edit().putString("sessions_json", array.toString()).apply()
    return session
  }

  // --- Quiz Results ---
  fun loadQuizResults(): List<QuizResult> {
    val jsonString = prefs.getString("quiz_results_json", null) ?: return emptyList()
    return try {
      val array = JSONArray(jsonString)
      val list = mutableListOf<QuizResult>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val wrongArray = obj.optJSONArray("wrongAnswers") ?: JSONArray()
        val wrongs = mutableListOf<WrongAnswerDetail>()
        for (w in 0 until wrongArray.length()) {
          val wObj = wrongArray.getJSONObject(w)
          wrongs.add(
            WrongAnswerDetail(
              question = wObj.getString("question"),
              selectedAnswer = wObj.getString("selectedAnswer"),
              correctAnswer = wObj.getString("correctAnswer"),
              explanation = wObj.getString("explanation")
            )
          )
        }
        list.add(
          QuizResult(
            id = obj.getString("id"),
            subject = Subject.fromString(obj.getString("subject")),
            chapterTitle = obj.getString("chapterTitle"),
            score = obj.getInt("score"),
            total = obj.getInt("total"),
            timestamp = obj.getLong("timestamp"),
            dateFormatted = obj.getString("dateFormatted"),
            wrongAnswers = wrongs
          )
        )
      }
      list.sortedByDescending { it.timestamp }
    } catch (e: Exception) {
      emptyList()
    }
  }

  fun addQuizResult(
    subject: Subject,
    chapterTitle: String,
    score: Int,
    total: Int,
    wrongAnswers: List<WrongAnswerDetail>
  ): QuizResult {
    val now = System.currentTimeMillis()
    val result = QuizResult(
      id = "quiz_${now}_${(100..999).random()}",
      subject = subject,
      chapterTitle = chapterTitle,
      score = score,
      total = total,
      timestamp = now,
      dateFormatted = "${dateFormat.format(Date(now))} • ${timeFormat.format(Date(now))}",
      wrongAnswers = wrongAnswers
    )
    val current = loadQuizResults().toMutableList()
    current.add(0, result)

    val array = JSONArray()
    current.take(50).forEach { r ->
      val obj = JSONObject().apply {
        put("id", r.id)
        put("subject", r.subject.name)
        put("chapterTitle", r.chapterTitle)
        put("score", r.score)
        put("total", r.total)
        put("timestamp", r.timestamp)
        put("dateFormatted", r.dateFormatted)

        val wArray = JSONArray()
        r.wrongAnswers.forEach { w ->
          val wObj = JSONObject().apply {
            put("question", w.question)
            put("selectedAnswer", w.selectedAnswer)
            put("correctAnswer", w.correctAnswer)
            put("explanation", w.explanation)
          }
          wArray.put(wObj)
        }
        put("wrongAnswers", wArray)
      }
      array.put(obj)
    }
    prefs.edit().putString("quiz_results_json", array.toString()).apply()
    return result
  }

  // --- Doubt Chat Messages ---
  fun loadChatMessages(): List<ChatMessage> {
    val jsonString = prefs.getString("chat_messages_json", null)
    if (jsonString.isNullOrEmpty()) {
      val now = System.currentTimeMillis()
      return listOf(
        ChatMessage(
          id = "init_naruto",
          senderName = "Naruto Uzumaki",
          text = "Yo! Welcome to the Study Dojo! I'm Naruto Uzumaki, your study partner! Ready to master Kerala Plus Two Physics, Chem, Maths, and CS? Ask me anything or drill your skills! Believe it!",
          timestamp = now - 60000,
          isUser = false,
          character = SenseiCharacter.NARUTO
        ),
        ChatMessage(
          id = "init_hinata",
          senderName = "Hinata Hyuga",
          text = "Hello... I'm Hinata. Don't worry if any topic feels hard right now. We will review step by step together. You are doing your best!",
          timestamp = now - 30000,
          isUser = false,
          character = SenseiCharacter.HINATA
        )
      )
    }

    return try {
      val array = JSONArray(jsonString)
      val list = mutableListOf<ChatMessage>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val charName = obj.optString("character", "")
        val character = if (charName.isNotEmpty()) {
          try { SenseiCharacter.valueOf(charName) } catch (e: Exception) { null }
        } else null

        list.add(
          ChatMessage(
            id = obj.getString("id"),
            senderName = obj.getString("senderName"),
            text = obj.getString("text"),
            timestamp = obj.getLong("timestamp"),
            isUser = obj.getBoolean("isUser"),
            character = character
          )
        )
      }
      list
    } catch (e: Exception) {
      emptyList()
    }
  }

  fun saveChatMessages(messages: List<ChatMessage>) {
    val array = JSONArray()
    messages.takeLast(100).forEach { m ->
      val obj = JSONObject().apply {
        put("id", m.id)
        put("senderName", m.senderName)
        put("text", m.text)
        put("timestamp", m.timestamp)
        put("isUser", m.isUser)
        m.character?.let { put("character", it.name) }
      }
      array.put(obj)
    }
    prefs.edit().putString("chat_messages_json", array.toString()).apply()
  }

  // --- Backup & Restore ---
  fun getBackupJson(): String {
    val backup = JSONObject().apply {
      put("chapters", JSONArray(prefs.getString("chapters_json", "[]")))
      put("sessions", JSONArray(prefs.getString("sessions_json", "[]")))
      put("quiz_results", JSONArray(prefs.getString("quiz_results_json", "[]")))
      put("chat_messages", JSONArray(prefs.getString("chat_messages_json", "[]")))
      put("version", 1)
      put("timestamp", System.currentTimeMillis())
    }
    return backup.toString(2)
  }

  fun restoreFromBackup(json: String): Boolean {
    return try {
      val backup = JSONObject(json)
      val chapters = backup.optJSONArray("chapters")
      val sessions = backup.optJSONArray("sessions")
      val quizResults = backup.optJSONArray("quiz_results")
      val chatMessages = backup.optJSONArray("chat_messages")

      prefs.edit().apply {
        if (chapters != null) putString("chapters_json", chapters.toString())
        if (sessions != null) putString("sessions_json", sessions.toString())
        if (quizResults != null) putString("quiz_results_json", quizResults.toString())
        if (chatMessages != null) putString("chat_messages_json", chatMessages.toString())
        apply()
      }
      true
    } catch (e: Exception) {
      false
    }
  }
}
