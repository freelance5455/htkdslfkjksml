package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorHex: String = "#2563EB",
    val iconName: String = "school",
    val weeklyTargetHours: Float? = null,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
