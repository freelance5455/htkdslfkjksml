package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class MetarCloudDto(
  @Json(name = "cover") val cover: String?,
  @Json(name = "base") val base: Int?,
  @Json(name = "type") val type: String?
)

@JsonClass(generateAdapter = true)
data class MetarResponseDto(
  @Json(name = "metar_id") val metarId: Long?,
  @Json(name = "icaoId") val icaoId: String?,
  @Json(name = "receiptTime") val receiptTime: String?,
  @Json(name = "obsTime") val obsTime: Long?,
  @Json(name = "reportTime") val reportTime: String?,
  @Json(name = "temp") val temp: Double?,
  @Json(name = "dewp") val dewp: Double?,
  @Json(name = "wdir") val wdir: Any?, // Can be number or string "VRB"
  @Json(name = "wspd") val wspd: Int?,
  @Json(name = "wgst") val wgst: Int?,
  @Json(name = "visib") val visib: Any?, // Can be Double or String e.g. "6+"
  @Json(name = "altim") val altim: Double?,
  @Json(name = "slp") val slp: Double?,
  @Json(name = "qcField") val qcField: Int?,
  @Json(name = "wxString") val wxString: String?,
  @Json(name = "metarType") val metarType: String?,
  @Json(name = "rawOb") val rawOb: String?,
  @Json(name = "lat") val lat: Double?,
  @Json(name = "lon") val lon: Double?,
  @Json(name = "elev") val elev: Int?,
  @Json(name = "name") val name: String?,
  @Json(name = "cover") val cover: String?,
  @Json(name = "clouds") val clouds: List<MetarCloudDto>?,
  @Json(name = "fltCat") val fltCat: String?
)

@JsonClass(generateAdapter = true)
data class TafForecastDto(
  @Json(name = "timeFrom") val timeFrom: Long?,
  @Json(name = "timeTo") val timeTo: Long?,
  @Json(name = "fcstChange") val fcstChange: String?,
  @Json(name = "probability") val probability: Int?,
  @Json(name = "wdir") val wdir: Any?,
  @Json(name = "wspd") val wspd: Int?,
  @Json(name = "wgst") val wgst: Int?,
  @Json(name = "visib") val visib: Any?,
  @Json(name = "wxString") val wxString: String?,
  @Json(name = "clouds") val clouds: List<MetarCloudDto>?
)

@JsonClass(generateAdapter = true)
data class TafResponseDto(
  @Json(name = "taf_id") val tafId: Long?,
  @Json(name = "icaoId") val icaoId: String?,
  @Json(name = "bulletinTime") val bulletinTime: String?,
  @Json(name = "issueTime") val issueTime: String?,
  @Json(name = "validTimeFrom") val validTimeFrom: Long?,
  @Json(name = "validTimeTo") val validTimeTo: Long?,
  @Json(name = "rawTAF") val rawTAF: String?,
  @Json(name = "name") val name: String?,
  @Json(name = "fcsts") val fcsts: List<TafForecastDto>?
)

@JsonClass(generateAdapter = true)
data class SigmetCoordDto(
  @Json(name = "lat") val lat: Double?,
  @Json(name = "lon") val lon: Double?
)

@JsonClass(generateAdapter = true)
data class SigmetResponseDto(
  @Json(name = "sigmetId") val sigmetId: Any?,
  @Json(name = "airSigmetType") val airSigmetType: String?,
  @Json(name = "icaoId") val icaoId: String?,
  @Json(name = "firId") val firId: String?,
  @Json(name = "firName") val firName: String?,
  @Json(name = "receiptTime") val receiptTime: String?,
  @Json(name = "issueTime") val issueTime: String?,
  @Json(name = "validTimeFrom") val validTimeFrom: Long?,
  @Json(name = "validTimeTo") val validTimeTo: Long?,
  @Json(name = "sigmetType") val sigmetType: String?,
  @Json(name = "seriesId") val seriesId: String?,
  @Json(name = "hazard") val hazard: String?,
  @Json(name = "qualifier") val qualifier: String?,
  @Json(name = "base") val base: Int?,
  @Json(name = "top") val top: Int?,
  @Json(name = "dir") val dir: String?,
  @Json(name = "spd") val spd: Any?,
  @Json(name = "chng") val chng: String?,
  @Json(name = "rawSigmet") val rawSigmet: String?,
  @Json(name = "coords") val coords: List<SigmetCoordDto>?
)

@JsonClass(generateAdapter = true)
data class OpenMeteoHourlyDto(
  @Json(name = "time") val time: List<String>?,
  @Json(name = "wind_speed_1000hPa") val windSpeed1000: List<Double>?,
  @Json(name = "wind_direction_1000hPa") val windDir1000: List<Int>?,
  @Json(name = "temperature_1000hPa") val temp1000: List<Double>?,
  @Json(name = "wind_speed_850hPa") val windSpeed850: List<Double>?,
  @Json(name = "wind_direction_850hPa") val windDir850: List<Int>?,
  @Json(name = "temperature_850hPa") val temp850: List<Double>?,
  @Json(name = "wind_speed_700hPa") val windSpeed700: List<Double>?,
  @Json(name = "wind_direction_700hPa") val windDir700: List<Int>?,
  @Json(name = "temperature_700hPa") val temp700: List<Double>?,
  @Json(name = "wind_speed_500hPa") val windSpeed500: List<Double>?,
  @Json(name = "wind_direction_500hPa") val windDir500: List<Int>?,
  @Json(name = "temperature_500hPa") val temp500: List<Double>?,
  @Json(name = "wind_speed_300hPa") val windSpeed300: List<Double>?,
  @Json(name = "wind_direction_300hPa") val windDir300: List<Int>?,
  @Json(name = "temperature_300hPa") val temp300: List<Double>?,
  @Json(name = "wind_speed_250hPa") val windSpeed250: List<Double>?,
  @Json(name = "wind_direction_250hPa") val windDir250: List<Int>?,
  @Json(name = "temperature_250hPa") val temp250: List<Double>?,
  @Json(name = "wind_speed_200hPa") val windSpeed200: List<Double>?,
  @Json(name = "wind_direction_200hPa") val windDir200: List<Int>?,
  @Json(name = "temperature_200hPa") val temp200: List<Double>?
)

@JsonClass(generateAdapter = true)
data class OpenMeteoResponseDto(
  @Json(name = "latitude") val latitude: Double?,
  @Json(name = "longitude") val longitude: Double?,
  @Json(name = "elevation") val elevation: Double?,
  @Json(name = "hourly") val hourly: OpenMeteoHourlyDto?
)
