package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val username: String,
    val displayName: String,
    val avatarUrl: String,
    val bio: String,
    val isVerified: Boolean = false,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val totalLikes: Int = 0,
    val isBlocked: Boolean = false,
    val isFollowing: Boolean = false,
    val role: String = "creator", // "creator", "user", "admin"
    val walletBalance: Double = 12500.0,
    val coinBalance: Int = 450
)

@Entity(tableName = "videos")
data class VideoEntity(
    @PrimaryKey val id: String,
    val creatorId: String,
    val creatorName: String,
    val creatorHandle: String,
    val creatorAvatar: String,
    val caption: String,
    val soundTitle: String,
    val videoUri: String,
    val posterResName: String = "",
    val bgGradientStart: Long = 0xFF180A2E,
    val bgGradientEnd: Long = 0xFF3D0C5A,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val viewsCount: Int = 0,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val tags: String = "",
    val category: String = "Entertainment",
    val adRevenue: Double = 0.0,
    val giftCoins: Int = 0,
    val isReported: Boolean = false,
    val isTakenDown: Boolean = false
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey val id: String,
    val videoId: String,
    val userId: String,
    val userName: String,
    val userAvatar: String,
    val text: String,
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val actorName: String,
    val actorAvatar: String,
    val title: String,
    val message: String,
    val type: String, // LIKE, COMMENT, FOLLOW, GIFT, MONETIZATION
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "payouts")
data class PayoutEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val amount: Double,
    val currency: String = "INR",
    val payoutMethod: String, // UPI, Bank Transfer, PayPal
    val accountDetails: String,
    val status: String, // PENDING, PROCESSING, COMPLETED
    val requestDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey val id: String,
    val reporterId: String,
    val targetVideoId: String?,
    val targetUserId: String?,
    val targetCaption: String,
    val reason: String,
    val status: String = "PENDING_REVIEW", // PENDING_REVIEW, RESOLVED, DISMISSED
    val timestamp: Long = System.currentTimeMillis()
)
