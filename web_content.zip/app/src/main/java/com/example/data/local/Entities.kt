package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "care_logs")
data class CareLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val categoryKey: String,
    val dateEpochDay: Long,
    val countAdded: Int = 1,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "diary_entries")
data class DiaryEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val moodKey: String,
    val energyScore: Int,
    val isVoiceTyped: Boolean = false,
    val detectedCue: String = "",
    val aiSupportResponse: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "cycle_logs")
data class CycleLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dateEpochDay: Long,
    val flowLevel: String,
    val crampsLevel: Int,
    val symptoms: String,
    val notes: String = ""
)

@Entity(tableName = "vitality_logs")
data class VitalityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dateEpochDay: Long,
    val workoutMinutes: Int,
    val workoutType: String,
    val proteinMeals: Int,
    val hydrationAndZincDone: Boolean,
    val sleepHours: Float,
    val notes: String = ""
)

@Entity(tableName = "hormone_checks")
data class HormoneCheckEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val energyScore: Int,
    val moodBalanceScore: Int,
    val skinClarityScore: Int,
    val sleepQualityScore: Int,
    val stressCalmScore: Int,
    val dailySymptoms: String = "",
    val insightSummary: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "emergency_contacts")
data class EmergencyContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val relationship: String,
    val isTrustedSos: Boolean = true
)

@Entity(tableName = "sos_messages")
data class SosMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val recipientName: String,
    val recipientPhone: String,
    val messageText: String,
    val locationSummary: String,
    val channel: String,
    val status: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "reminder_schedules")
data class ReminderScheduleEntity(
    @PrimaryKey val categoryKey: String,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean
)
