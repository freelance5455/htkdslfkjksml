package com.example.data.local

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

@Entity(tableName = "lessons")
data class LessonEntity(
    @PrimaryKey val id: String,
    val subject: String,
    val day: String,
    val mode: String,
    val teacher: String,
    val time: String,
    val location: String,
    val colorHex: String,
    val attended: Boolean
)

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val name: String,
    val teacher: String,
    val colorHex: String,
    val sortOrder: Int = 0
)

@Entity(
    tableName = "track_lessons",
    foreignKeys = [
        ForeignKey(
            entity = TrackEntity::class,
            parentColumns = ["id"],
            childColumns = ["trackId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["trackId"])]
)
data class TrackLessonEntity(
    @PrimaryKey val id: String,
    val trackId: String,
    val title: String,
    val note: String,
    val completed: Boolean,
    val sortOrder: Int = 0
)

data class TrackWithLessons(
    @Embedded val track: TrackEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "trackId"
    )
    val lessons: List<TrackLessonEntity>
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subject: String,
    val priority: String,
    val dueDate: String,
    val completed: Boolean,
    val createdAt: Long
)
