package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.data.model.BookingStatus
import com.example.data.model.DocumentType
import com.example.data.model.PaymentMethod
import com.example.data.model.TripType

@Entity(
    tableName = "clients",
    indices = [Index(value = ["clientCode"], unique = true)]
)
data class ClientEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientCode: String,
    val fullName: String,
    val phone: String,
    val whatsapp: String,
    val nationalId: String,
    val passportNumber: String,
    val birthDate: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "bookings",
    foreignKeys = [
        ForeignKey(
            entity = ClientEntity::class,
            parentColumns = ["id"],
            childColumns = ["clientId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index(value = ["clientId"]), Index(value = ["tripDate"])]
)
data class BookingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val clientId: Long,
    val tripDate: String,
    val returnDate: String,
    val tripType: TripType,
    val customTripLabel: String = "",
    val companyName: String,
    val makkahHotel: String,
    val madinahHotel: String,
    val totalPrice: Double,
    val extraAmount: Double = 0.0,
    val costAmount: Double = 0.0,
    val status: BookingStatus = BookingStatus.PENDING,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = BookingEntity::class,
            parentColumns = ["id"],
            childColumns = ["bookingId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index(value = ["bookingId"])]
)
data class PaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookingId: Long,
    val amount: Double,
    val paymentDate: String,
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val isDeposit: Boolean = false,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "documents",
    foreignKeys = [
        ForeignKey(
            entity = BookingEntity::class,
            parentColumns = ["id"],
            childColumns = ["bookingId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index(value = ["bookingId"])]
)
data class DocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookingId: Long,
    val docType: DocumentType,
    val title: String = "",
    val relativePath: String,
    val createdAt: Long = System.currentTimeMillis(),
)
