package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Stores optional user profile details (name, photo local URI, institute name).
 */
@Entity(tableName = "profile")
data class ProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String? = null,
    val photoUri: String? = null,
    val instituteName: String? = null
)
