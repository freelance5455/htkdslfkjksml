package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.api.GeminiApiClient
import com.example.data.local.AppDao
import com.example.data.local.CreationItem
import com.example.data.local.PreferencesManager
import com.example.ui.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CreationRepository(
    private val context: Context,
    private val dao: AppDao,
    private val apiClient: GeminiApiClient,
    private val preferencesManager: PreferencesManager
) {

    val allCreations: Flow<List<CreationItem>> = dao.getAllCreations()

    suspend fun generateImage(
        prompt: String,
        inputImageUri: Uri?,
        aspectRatio: String = "1:1",
        style: String? = null
    ): Result<CreationItem> = withContext(Dispatchers.IO) {
        val apiKey = preferencesManager.getEffectiveApiKey()

        var inputBase64: String? = null
        var inputMime: String? = null
        if (inputImageUri != null) {
            val imgData = FileUtils.uriToBase64(context, inputImageUri)
            inputBase64 = imgData?.first
            inputMime = imgData?.second
        }

        val enrichedPrompt = if (!style.isNullOrBlank() && style != "Varsayılan") {
            "$prompt (Tarz: $style, yüksek kaliteli, detaylı sanat)"
        } else {
            prompt
        }

        val apiResult = apiClient.generateImage(
            prompt = enrichedPrompt,
            inputImageBase64 = inputBase64,
            inputImageMimeType = inputMime,
            aspectRatio = aspectRatio,
            apiKey = apiKey
        )

        if (apiResult.isSuccess) {
            val media = apiResult.getOrNull()
            val imageBytes = media?.imageBytes
            if (imageBytes != null) {
                // Save locally in app files
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val creationsDir = File(context.filesDir, "creations").apply {
                    if (!exists()) mkdirs()
                }
                val ext = if (media.mimeType.contains("png")) "png" else "jpg"
                val file = File(creationsDir, "SUESA_IMG_${timeStamp}.$ext")
                FileOutputStream(file).use { stream ->
                    stream.write(imageBytes)
                }

                val savedUri = Uri.fromFile(file).toString()

                val creation = CreationItem(
                    type = "image",
                    prompt = prompt,
                    mediaUri = savedUri,
                    inputImageUri = inputImageUri?.toString(),
                    status = "completed",
                    aspectRatio = aspectRatio,
                    style = style
                )
                val id = dao.insertCreation(creation)
                Result.success(creation.copy(id = id))
            } else {
                Result.failure(Exception("Görsel verisi alınamadı."))
            }
        } else {
            Result.failure(apiResult.exceptionOrNull() ?: Exception("Görsel oluşturulamadı."))
        }
    }

    suspend fun generateVideo(
        prompt: String,
        inputImageUri: Uri?,
        aspectRatio: String = "16:9"
    ): Result<CreationItem> = withContext(Dispatchers.IO) {
        val apiKey = preferencesManager.getEffectiveApiKey()

        var inputBase64: String? = null
        if (inputImageUri != null) {
            val imgData = FileUtils.uriToBase64(context, inputImageUri)
            inputBase64 = imgData?.first
        }

        val apiResult = apiClient.generateVideo(
            prompt = prompt,
            inputImageBase64 = inputBase64,
            aspectRatio = aspectRatio,
            apiKey = apiKey
        )

        if (apiResult.isSuccess) {
            val res = apiResult.getOrNull()!!
            if (res.isSuccess) {
                val creation = CreationItem(
                    type = "video",
                    prompt = prompt,
                    mediaUri = res.videoUrl ?: (inputImageUri?.toString() ?: ""),
                    inputImageUri = inputImageUri?.toString(),
                    status = "completed",
                    aspectRatio = aspectRatio
                )
                val id = dao.insertCreation(creation)
                Result.success(creation.copy(id = id))
            } else {
                // Returns clean explanation from Veo API
                Result.failure(Exception(res.message))
            }
        } else {
            Result.failure(apiResult.exceptionOrNull() ?: Exception("Video oluşturma başarısız oldu."))
        }
    }

    suspend fun deleteCreation(id: Long) = withContext(Dispatchers.IO) {
        dao.deleteCreationById(id)
    }

    suspend fun deleteAllCreations() = withContext(Dispatchers.IO) {
        dao.deleteAllCreations()
    }
}
