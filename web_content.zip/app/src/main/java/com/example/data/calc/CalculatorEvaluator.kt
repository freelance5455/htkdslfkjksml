package com.example.data.calc

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.*

object CalculatorEvaluator {

    fun evaluate(expression: String, isDegreeMode: Boolean = true, precision: Int = 4): EvaluationResult {
        if (expression.isBlank()) return EvaluationResult.Success("0")

        try {
            // Clean and normalize expression
            val sanitized = expression
                .replace("×", "*")
                .replace("÷", "/")
                .replace("−", "-")
                .replace("π", Math.PI.toString())
                .replace("e", Math.E.toString())

            val tokens = tokenize(sanitized)
            val postfix = infixToPostfix(tokens)
            val result = evaluatePostfix(postfix, isDegreeMode)

            if (result.isNaN()) {
                return EvaluationResult.Error("Invalid Expression")
            }
            if (result.isInfinite()) {
                return EvaluationResult.Error("Cannot divide by 0")
            }

            return EvaluationResult.Success(formatResult(result, precision))
        } catch (e: ArithmeticException) {
            return EvaluationResult.Error("Cannot divide by 0")
        } catch (e: Exception) {
            return EvaluationResult.Error("Invalid Expression")
        }
    }

    private fun formatResult(value: Double, precision: Int): String {
        if (abs(value) < 1e-12) return "0"

        // If it's a clean whole number
        if (value == floor(value) && !value.isInfinite() && abs(value) < 1e15) {
            return value.toLong().toString()
        }

        val bd = BigDecimal(value).setScale(precision, RoundingMode.HALF_UP).stripTrailingZeros()
        val plain = bd.toPlainString()
        return if (plain.length > 15) {
            String.format("%.${min(precision, 6)}e", value)
        } else {
            plain
        }
    }

    private fun tokenize(expr: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        while (i < expr.length) {
            val c = expr[i]
            when {
                c.isWhitespace() -> i++
                c in "+-*/^%()" -> {
                    // Check if '-' is unary
                    if (c == '-' && (tokens.isEmpty() || tokens.last() in "(+*/^")) {
                        tokens.add("neg")
                    } else {
                        tokens.add(c.toString())
                    }
                    i++
                }
                c == '!' -> {
                    tokens.add("!")
                    i++
                }
                c.isDigit() || c == '.' -> {
                    val sb = StringBuilder()
                    while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                        sb.append(expr[i])
                        i++
                    }
                    tokens.add(sb.toString())
                }
                c.isLetter() -> {
                    val sb = StringBuilder()
                    while (i < expr.length && expr[i].isLetter()) {
                        sb.append(expr[i])
                        i++
                    }
                    tokens.add(sb.toString())
                }
                else -> i++
            }
        }
        return tokens
    }

    private fun precedence(op: String): Int {
        return when (op) {
            "+", "-" -> 1
            "*", "/", "%" -> 2
            "^" -> 3
            "neg" -> 4
            "!" -> 5
            "sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "sqrt" -> 6
            else -> 0
        }
    }

    private fun isFunction(token: String): Boolean {
        return token in listOf("sin", "cos", "tan", "asin", "acos", "atan", "ln", "log", "sqrt")
    }

    private fun infixToPostfix(tokens: List<String>): List<String> {
        val output = mutableListOf<String>()
        val stack = ArrayDeque<String>()

        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null -> output.add(token)
                isFunction(token) -> stack.addFirst(token)
                token == "(" -> stack.addFirst(token)
                token == ")" -> {
                    while (stack.isNotEmpty() && stack.first() != "(") {
                        output.add(stack.removeFirst())
                    }
                    if (stack.isNotEmpty() && stack.first() == "(") {
                        stack.removeFirst()
                    }
                    if (stack.isNotEmpty() && isFunction(stack.first())) {
                        output.add(stack.removeFirst())
                    }
                }
                token == "!" -> output.add(token)
                else -> {
                    while (stack.isNotEmpty() && precedence(stack.first()) >= precedence(token) && stack.first() != "(") {
                        output.add(stack.removeFirst())
                    }
                    stack.addFirst(token)
                }
            }
        }

        while (stack.isNotEmpty()) {
            val top = stack.removeFirst()
            if (top != "(" && top != ")") {
                output.add(top)
            }
        }

        return output
    }

    private fun evaluatePostfix(postfix: List<String>, isDegreeMode: Boolean): Double {
        val stack = ArrayDeque<Double>()

        fun toRadians(d: Double): Double = if (isDegreeMode) Math.toRadians(d) else d
        fun fromRadians(d: Double): Double = if (isDegreeMode) Math.toDegrees(d) else d

        for (token in postfix) {
            val num = token.toDoubleOrNull()
            if (num != null) {
                stack.addFirst(num)
            } else if (token == "neg") {
                val a = stack.removeFirstOrNull() ?: 0.0
                stack.addFirst(-a)
            } else if (token == "!") {
                val a = stack.removeFirstOrNull() ?: 0.0
                stack.addFirst(factorial(a))
            } else if (isFunction(token)) {
                val a = stack.removeFirstOrNull() ?: 0.0
                val res = when (token) {
                    "sin" -> sin(toRadians(a))
                    "cos" -> cos(toRadians(a))
                    "tan" -> {
                        val rad = toRadians(a)
                        if (cos(rad) == 0.0) Double.NaN else tan(rad)
                    }
                    "asin" -> fromRadians(asin(a))
                    "acos" -> fromRadians(acos(a))
                    "atan" -> fromRadians(atan(a))
                    "ln" -> if (a <= 0) Double.NaN else ln(a)
                    "log" -> if (a <= 0) Double.NaN else log10(a)
                    "sqrt" -> if (a < 0) Double.NaN else sqrt(a)
                    else -> Double.NaN
                }
                stack.addFirst(res)
            } else {
                val b = stack.removeFirstOrNull() ?: 0.0
                val a = stack.removeFirstOrNull() ?: 0.0
                val res = when (token) {
                    "+" -> a + b
                    "-" -> a - b
                    "*" -> a * b
                    "/" -> if (b == 0.0) throw ArithmeticException("Divide by zero") else a / b
                    "%" -> a * (b / 100.0)
                    "^" -> a.pow(b)
                    else -> 0.0
                }
                stack.addFirst(res)
            }
        }

        return stack.firstOrNull() ?: 0.0
    }

    private fun factorial(n: Double): Double {
        val k = n.toLong()
        if (k < 0 || k > 20) return Double.NaN
        var result = 1.0
        for (i in 2..k) {
            result *= i
        }
        return result
    }
}

sealed class EvaluationResult {
    data class Success(val value: String) : EvaluationResult()
    data class Error(val message: String) : EvaluationResult()
}
