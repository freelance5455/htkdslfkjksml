package com.example.data.local

import com.example.data.model.AppLanguage

data class BiblePassage(
    val id: String,
    val reference: String,
    val theme: String,
    val text: String,
    val teenReflection: String
)

data class DailyQuickQuestion(
    val id: String,
    val category: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

data class DailyDiscoveryFact(
    val id: String,
    val topic: String,
    val title: String,
    val summary: String,
    val takeaway: String
)

object LearnContentProvider {

    val biblePassages = listOf(
        BiblePassage(
            id = "psalm_23",
            reference = "Psalm 23:1-4",
            theme = "Peace & Strength",
            text = "The Lord is my shepherd; I shall not want. He makes me lie down in green pastures. He leads me beside still waters. He restores my soul. Even though I walk through the darkest valley, I will fear no evil, for You are with me.",
            teenReflection = "Even on hard school days or lonely nights, you never walk alone—pause, breathe, and let your soul rest."
        ),
        BiblePassage(
            id = "phil_4_6",
            reference = "Philippians 4:6-7",
            theme = "Anxiety Relief",
            text = "Do not be anxious about anything, but in every situation, by prayer and petition, with thanksgiving, present your requests to God. And the peace of God, which transcends all understanding, will guard your hearts and your minds.",
            teenReflection = "When stress feels too loud, naming what you're carrying turns worry into calm focus."
        ),
        BiblePassage(
            id = "jer_29_11",
            reference = "Jeremiah 29:11",
            theme = "Hope & Future",
            text = "'For I know the plans I have for you,' declares the Lord, 'plans to prosper you and not to harm you, plans to give you hope and a future.'",
            teenReflection = "Your teenage years are a chapter, not the whole book. Your future still holds so much purpose."
        ),
        BiblePassage(
            id = "tim_4_12",
            reference = "1 Timothy 4:12",
            theme = "Teen Leadership",
            text = "Don't let anyone look down on you because you are young, but set an example for the believers in speech, in conduct, in love, in faith and in purity.",
            teenReflection = "Being young doesn't mean waiting to matter—your kindness and courage count right now."
        ),
        BiblePassage(
            id = "psalm_139_14",
            reference = "Psalm 139:14",
            theme = "Self-Worth",
            text = "I praise you because I am fearfully and wonderfully made; your works are wonderful, I know that full well.",
            teenReflection = "Your body, mind, and identity are worthy of respect, care, and kindness today."
        ),
        BiblePassage(
            id = "isa_40_31",
            reference = "Isaiah 40:31",
            theme = "Renewal",
            text = "But those who hope in the Lord will renew their strength. They will soar on wings like eagles; they will run and not grow weary, they will walk and not be faint.",
            teenReflection = "Rest is not laziness—it is how your strength gets renewed."
        )
    )

    val dailyQuestions = listOf(
        DailyQuickQuestion(
            id = "q_sleep",
            category = "Teen Brain & Health",
            question = "How many hours of sleep do teens (ages 13–19) typically need each night for memory, mood, and hormone balance?",
            options = listOf("4–5 hours", "8–10 hours", "12–14 hours", "6 hours max"),
            correctIndex = 1,
            explanation = "Sleep experts recommend 8–10 hours for teens! Deep sleep resets cortisol, supports growth hormones, and improves exam recall."
        ),
        DailyQuickQuestion(
            id = "q_water",
            category = "Body Literacy",
            question = "What is a simple everyday clue that your body needs more water?",
            options = listOf("Dark yellow urine & dry lips", "Cold feet", "Singing loudly", "Fast hair growth"),
            correctIndex = 0,
            explanation = "Pale straw-colored urine means good hydration; dark yellow means it's time to drink a glass of water!"
        ),
        DailyQuickQuestion(
            id = "q_fresh_air",
            category = "Mental Focus",
            question = "How does stepping outside for 10–15 minutes of morning sunlight help your sleep?",
            options = listOf("It stops dreams", "It sets your circadian clock so melatonin releases on time at night", "It replaces drinking water", "It lowers oxygen"),
            correctIndex = 1,
            explanation = "Morning daylight tells your brain when daytime starts, helping melatonin naturally rise when bedtime arrives."
        ),
        DailyQuickQuestion(
            id = "q_study",
            category = "Study Skill",
            question = "Which study method helps your brain remember material longest?",
            options = listOf("Re-reading notes 5 times in a row", "Active recall (testing yourself) + spaced breaks", "Studying at 3 AM with notifications on", "Highlighting every word"),
            correctIndex = 1,
            explanation = "Active recall forces your brain to retrieve answers, building stronger memory pathways than passive re-reading."
        )
    )

    val dailyFacts = listOf(
        DailyDiscoveryFact(
            id = "f_neuroplasticity",
            topic = "Brain Science",
            title = "Your Teen Brain Is Supercharged for Learning",
            summary = "During ages 13–19, your prefrontal cortex and neural pathways undergo rapid rewiring called synaptic pruning—making teens faster at picking up languages, music, coding, and emotional resilience.",
            takeaway = "Every time you practice a skill or calm breathing, you physically strengthen that circuit!"
        ),
        DailyDiscoveryFact(
            id = "f_gut_brain",
            topic = "Body & Mood",
            title = "Your Gut Makes Most of Your Body's Serotonin",
            summary = "Around 90% of the body's serotonin (a key mood & digestion messenger) is produced in the digestive tract. Drinking water, eating fiber, and not holding bathroom breaks directly help your mood!",
            takeaway = "Taking pee & poop breaks and eating real food literally supports mental health."
        ),
        DailyDiscoveryFact(
            id = "f_sunlight_vitd",
            topic = "Vitality",
            title = "Fresh Air & Sunlight Power Hormones and Immunity",
            summary = "Just 15 minutes of outdoor fresh air boosts vitamin D synthesis, lowers stress cortisol, and gives your eyes a break from close-up phone focus.",
            takeaway = "Take a 15-minute outdoor pause after school today."
        ),
        DailyDiscoveryFact(
            id = "f_empathy",
            topic = "Life Skills",
            title = "Naming an Emotion Calms the Amygdala",
            summary = "Psychologists call it 'affect labeling': speaking or writing exact feelings ('I feel overwhelmed about math') reduces activity in your brain's alarm center within seconds.",
            takeaway = "Use your Voice Diary whenever emotions feel tangled."
        )
    )

    fun tutorGreeting(language: AppLanguage): String = when (language) {
        AppLanguage.ES -> "Hola, soy Tshenolo Maseko, tu tutor 24 horas. Pregúntame sobre matemáticas, ciencias, tareas, Biblia o habilidades de vida."
        AppLanguage.FR -> "Bonjour, je suis Tshenolo Maseko, ton tuteur 24h/24. Pose-moi tes questions en maths, sciences, études ou vie quotidienne."
        AppLanguage.ZU -> "Sawubona! Ngingu-Tshenolo Maseko, uthisha wakho wamahora angu-24. Ngibuze ngezibalo, isayensi, ukufunda noma impilo."
        else -> "Hi! I'm Tshenolo Maseko, your 24-hour personal tutor. Ask me anytime—day or night—about Math, Science, English, Study Habits, Bible study, or life skills!"
    }
}
