package com.example.data

import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import com.example.scanner.PieceTemplate
import com.example.scanner.ScannerCrop
import com.example.scanner.ScannerNcc
import com.example.scanner.SquareShade
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

class MoonChessRepository(
    private val context: Context,
    private val dao: MoonChessDao
) {
    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    val booksFlow: Flow<List<BookEntity>> = dao.observeBooks()
    val notesFlow: Flow<List<NoteEntity>> = dao.observeNotes()
    val principlesFlow: Flow<List<PrincipleEntity>> = dao.observePrinciples()
    val pmsPositionsFlow: Flow<List<PmsPositionEntity>> = dao.observePmsPositions()
    val importedGamesFlow: Flow<List<ImportedGameEntity>> = dao.observeImportedGames()

    fun observeBookAnnotations(bookId: String): Flow<List<PageAnnotationEntity>> =
        dao.observeBookAnnotations(bookId)

    fun observeCatalogDiagrams(bookId: String): Flow<List<CatalogDiagramEntity>> =
        dao.observeCatalogDiagrams(bookId)

    fun observeBookTemplates(bookId: String): Flow<List<PieceTemplateEntity>> =
        dao.observeBookTemplates(bookId)

    // ---- Book Import & Offline File Persistence ----

    suspend fun importPdfUri(uri: Uri): BookEntity = withContext(Dispatchers.IO) {
        // Persist URI permission across device restarts when supported by provider
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Some providers do not grant persistable permissions; our local copy guarantees offline access
        }

        var displayName = "Chess_Book.pdf"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIdx >= 0) {
                displayName = cursor.getString(nameIdx) ?: displayName
            }
        }

        val booksDir = File(context.filesDir, "books").apply { mkdirs() }
        val bookId = "book_${UUID.randomUUID().toString().take(8)}"
        val destFile = File(booksDir, "$bookId.pdf")

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalStateException("Unable to read selected PDF file.")

        val pageCount = countPdfPages(destFile)
        val cleanTitle = displayName
            .removeSuffix(".pdf")
            .removeSuffix(".PDF")
            .replace('_', ' ')
            .replace('-', ' ')
            .trim()
            .ifBlank { "Untitled Chess Book" }

        val entity = BookEntity(
            id = bookId,
            title = cleanTitle,
            filename = displayName,
            localFilePath = destFile.absolutePath,
            uriString = uri.toString(),
            fileSize = destFile.length(),
            totalPages = pageCount,
            lastReadPage = 1,
            zoom = 1.0f
        )
        dao.upsertBook(entity)
        entity
    }

    suspend fun registerGeneratedPdfFile(file: File, title: String): BookEntity = withContext(Dispatchers.IO) {
        val pageCount = countPdfPages(file)
        val bookId = "book_${file.nameWithoutExtension}"
        val entity = BookEntity(
            id = bookId,
            title = title,
            filename = file.name,
            localFilePath = file.absolutePath,
            fileSize = file.length(),
            totalPages = pageCount,
            lastReadPage = 1,
            zoom = 1.0f
        )
        dao.upsertBook(entity)
        entity
    }

    private fun countPdfPages(file: File): Int {
        return try {
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    val count = renderer.pageCount
                    if (count > 0) count else countPagesFromPdfBytes(file)
                }
            }
        } catch (_: Throwable) {
            countPagesFromPdfBytes(file)
        }
    }

    private fun countPagesFromPdfBytes(file: File): Int {
        return try {
            val raw = String(file.readBytes(), Charsets.ISO_8859_1)
            val regex = Regex("""/Type\s*/Page\b""")
            regex.findAll(raw).count().coerceAtLeast(1)
        } catch (_: Throwable) {
            1
        }
    }

    suspend fun getBookById(bookId: String): BookEntity? = dao.getBookById(bookId)

    suspend fun updateReadingProgress(bookId: String, page: Int, zoom: Float) {
        dao.updateReadingProgress(bookId, page, zoom)
    }

    suspend fun deleteBook(book: BookEntity) = withContext(Dispatchers.IO) {
        runCatching { File(book.localFilePath).delete() }
        dao.deleteBook(book.id)
    }

    // ---- Page Annotations ----

    suspend fun savePageStrokes(bookId: String, pageNumber: Int, strokes: List<PdfAnnotationStroke>) =
        withContext(Dispatchers.IO) {
            if (strokes.isEmpty()) {
                dao.clearPageAnnotations(bookId, pageNumber)
                return@withContext
            }
            val arr = JSONArray()
            for (s in strokes) {
                val ptsArr = JSONArray()
                for ((x, y) in s.points) {
                    ptsArr.put(JSONArray().put(x.toDouble()).put(y.toDouble()))
                }
                arr.put(
                    JSONObject()
                        .put("id", s.id)
                        .put("tool", s.tool)
                        .put("colorHex", s.colorHex)
                        .put("strokeWidth", s.strokeWidth.toDouble())
                        .put("text", s.text)
                        .put("points", ptsArr)
                )
            }
            dao.upsertPageAnnotation(PageAnnotationEntity(bookId, pageNumber, arr.toString()))
        }

    fun parseStrokesJson(json: String): List<PdfAnnotationStroke> {
        if (json.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val ptsJson = o.optJSONArray("points")
                    val pts = buildList {
                        if (ptsJson != null) {
                            for (j in 0 until ptsJson.length()) {
                                val pair = ptsJson.getJSONArray(j)
                                add(pair.getDouble(0).toFloat() to pair.getDouble(1).toFloat())
                            }
                        }
                    }
                    add(
                        PdfAnnotationStroke(
                            id = o.optString("id", UUID.randomUUID().toString()),
                            tool = o.optString("tool", "pen"),
                            colorHex = o.optLong("colorHex", 0xFFF59E0B),
                            strokeWidth = o.optDouble("strokeWidth", 3.0).toFloat(),
                            points = pts,
                            text = o.optString("text", "")
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    // ---- Learned 32x32 NCC Piece Templates ----

    suspend fun loadBookTemplateMap(bookId: String): Map<String, PieceTemplate> =
        withContext(Dispatchers.IO) {
            val rows = dao.getBookTemplates(bookId)
            decodeTemplateEntities(rows)
        }

    fun decodeTemplateEntities(rows: List<PieceTemplateEntity>): Map<String, PieceTemplate> {
        val map = HashMap<String, PieceTemplate>(rows.size)
        for (row in rows) {
            val shade = if (row.squareShade == "dark") SquareShade.DARK else SquareShade.LIGHT
            val parts = row.pixelsBlob.split(',')
            if (parts.size != 1024) continue
            val floats = FloatArray(1024) { idx -> parts[idx].toFloatOrNull() ?: 0f }
            val key = "${row.pieceCode}_${shade.raw}"
            map[key] = PieceTemplate(row.pieceCode, shade, floats, row.sampleCount)
        }
        return map
    }

    suspend fun learnTemplatesFromConfirmedScan(
        bookId: String,
        cleanCrop640: android.graphics.Bitmap,
        confirmedGrid: Array<Array<String>>
    ) = withContext(Dispatchers.Default) {
        val existingMap = loadBookTemplateMap(bookId).toMutableMap()
        val cells32 = ScannerCrop.extractBoardCells32x32(cleanCrop640)

        for (r in 0..7) {
            for (c in 0..7) {
                val pieceCode = confirmedGrid[r][c]
                val shade = if ((r + c) % 2 == 1) SquareShade.DARK else SquareShade.LIGHT
                val key = "${pieceCode}_${shade.raw}"
                val updated = ScannerNcc.mergeRunningAverage(
                    existing = existingMap[key],
                    newPixels = cells32[r][c],
                    pieceCode = pieceCode,
                    shade = shade
                )
                existingMap[key] = updated
            }
        }

        val entities = existingMap.values.map { tpl ->
            val blob = tpl.pixels.joinToString(",") {
                String.format(Locale.US, "%.4f", it)
            }
            PieceTemplateEntity(
                id = "${bookId}_${tpl.pieceCode}_${tpl.squareColor.raw}",
                bookId = bookId,
                pieceCode = tpl.pieceCode,
                squareShade = tpl.squareColor.raw,
                sampleCount = tpl.sampleCount,
                pixelsBlob = blob
            )
        }
        dao.upsertTemplates(entities)
    }

    // ---- Diagram Catalog & JSON Export/Import ----

    suspend fun saveCatalogDiagram(diagram: CatalogDiagramEntity) = dao.upsertCatalogDiagram(diagram)
    suspend fun deleteCatalogDiagram(id: String) = dao.deleteCatalogDiagram(id)

    suspend fun exportCatalogJson(bookId: String): String = withContext(Dispatchers.IO) {
        val list = dao.getCatalogDiagramsSnapshot(bookId)
        val arr = JSONArray()
        for (d in list) {
            arr.put(
                JSONObject()
                    .put("id", d.id)
                    .put("bookId", d.bookId)
                    .put("pageNumber", d.pageNumber)
                    .put("title", d.title)
                    .put("fen", d.fen)
                    .put("turn", d.turn)
                    .put("confidence", d.confidence.toDouble())
                    .put("sourceMethod", d.sourceMethod)
                    .put("cropX", d.cropX)
                    .put("cropY", d.cropY)
                    .put("cropW", d.cropW)
                    .put("cropH", d.cropH)
            )
        }
        arr.toString(2)
    }

    suspend fun importCatalogJson(bookId: String, jsonText: String): Int = withContext(Dispatchers.IO) {
        val arr = JSONArray(jsonText)
        val list = ArrayList<CatalogDiagramEntity>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                CatalogDiagramEntity(
                    id = o.optString("id", "cat_${UUID.randomUUID().toString().take(8)}"),
                    bookId = bookId,
                    pageNumber = o.optInt("pageNumber", 1),
                    title = o.optString("title", "Diagram ${i + 1}"),
                    fen = o.getString("fen"),
                    turn = o.optString("turn", "w"),
                    confidence = o.optDouble("confidence", 0.95).toFloat(),
                    sourceMethod = o.optString("sourceMethod", "imported"),
                    cropX = o.optInt("cropX", 0),
                    cropY = o.optInt("cropY", 0),
                    cropW = o.optInt("cropW", 200),
                    cropH = o.optInt("cropH", 200)
                )
            )
        }
        dao.upsertCatalogDiagrams(list)
        list.size
    }

    // ---- PMS Positions ----
    suspend fun savePmsPosition(pos: PmsPositionEntity) = dao.upsertPmsPosition(pos)
    suspend fun deletePmsPosition(id: String) = dao.deletePmsPosition(id)

    // ---- Notes & Principles (Strictly User-Authored) ----
    suspend fun saveNote(note: NoteEntity) = dao.upsertNote(note)
    suspend fun deleteNote(id: String) = dao.deleteNote(id)
    suspend fun savePrinciple(principle: PrincipleEntity) = dao.upsertPrinciple(principle)
    suspend fun deletePrinciple(id: String) = dao.deletePrinciple(id)

    // ---- Settings ----
    suspend fun getSetting(key: String): String? = dao.getSetting(key)
    suspend fun setSetting(key: String, value: String) = dao.setSetting(AppSettingEntity(key, value))

    // ---- Lichess & Chess.com Public Game Import ----

    suspend fun fetchLichessGamesByUsername(username: String, maxGames: Int = 25): List<ImportedGameEntity> =
        withContext(Dispatchers.IO) {
            val cleanUser = username.trim()
            require(cleanUser.isNotEmpty()) { "Please enter a Lichess username." }
            val url = "https://lichess.org/api/games/user/${Uri.encode(cleanUser)}?max=$maxGames&pgnInJson=true&opening=true"
            val req = Request.Builder()
                .url(url)
                .header("Accept", "application/x-ndjson")
                .header("User-Agent", "MoonChessReaderAndroid/1.0")
                .build()

            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Lichess returned HTTP ${resp.code} for user '$cleanUser'.")
                }
                val body = resp.body?.string().orEmpty()
                val imported = ArrayList<ImportedGameEntity>()
                for (line in body.lineSequence()) {
                    val trimmed = line.trim()
                    if (trimmed.isEmpty()) continue
                    val obj = JSONObject(trimmed)
                    val id = obj.optString("id", UUID.randomUUID().toString())
                    val pgn = obj.optString("pgn", "")
                    if (pgn.isBlank()) continue
                    val players = obj.optJSONObject("players")
                    val wObj = players?.optJSONObject("white")
                    val bObj = players?.optJSONObject("black")
                    val whiteName = wObj?.optJSONObject("user")?.optString("name") ?: "Anonymous"
                    val blackName = bObj?.optJSONObject("user")?.optString("name") ?: "Anonymous"
                    val whiteElo = wObj?.optInt("rating")?.takeIf { it > 0 }
                    val blackElo = bObj?.optInt("rating")?.takeIf { it > 0 }
                    val winner = obj.optString("winner", "")
                    val res = when (winner) {
                        "white" -> "1-0"
                        "black" -> "0-1"
                        else -> if (obj.optString("status") == "draw" || obj.optString("status") == "stalemate") "1/2-1/2" else "*"
                    }
                    val opening = obj.optJSONObject("opening")?.optString("name", "") ?: ""
                    val createdMs = obj.optLong("createdAt", System.currentTimeMillis())
                    val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date(createdMs))

                    imported.add(
                        ImportedGameEntity(
                            id = "lichess_$id",
                            platform = "lichess",
                            white = whiteName,
                            black = blackName,
                            whiteRating = whiteElo,
                            blackRating = blackElo,
                            result = res,
                            datePlayed = dateStr,
                            openingName = opening,
                            pgn = pgn
                        )
                    )
                }
                if (imported.isNotEmpty()) {
                    dao.upsertImportedGames(imported)
                }
                imported
            }
        }

    suspend fun fetchChessComGamesByUsername(username: String, maxGames: Int = 25): List<ImportedGameEntity> =
        withContext(Dispatchers.IO) {
            val cleanUser = username.trim().lowercase(Locale.US)
            require(cleanUser.isNotEmpty()) { "Please enter a Chess.com username." }
            val archivesUrl = "https://api.chess.com/pub/player/${Uri.encode(cleanUser)}/games/archives"
            val archReq = Request.Builder()
                .url(archivesUrl)
                .header("Accept", "application/json")
                .header("User-Agent", "MoonChessReaderAndroid/1.0")
                .build()

            val latestArchiveUrl = httpClient.newCall(archReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Chess.com returned HTTP ${resp.code} for user '$cleanUser'.")
                }
                val json = JSONObject(resp.body?.string().orEmpty())
                val arr = json.optJSONArray("archives")
                if (arr == null || arr.length() == 0) {
                    throw IllegalStateException("No public game archives found for '$cleanUser'.")
                }
                arr.getString(arr.length() - 1)
            }

            val gamesReq = Request.Builder()
                .url(latestArchiveUrl)
                .header("Accept", "application/json")
                .header("User-Agent", "MoonChessReaderAndroid/1.0")
                .build()

            httpClient.newCall(gamesReq).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw IllegalStateException("Failed to download Chess.com archive (${resp.code}).")
                }
                val json = JSONObject(resp.body?.string().orEmpty())
                val gamesArr = json.optJSONArray("games") ?: JSONArray()
                val imported = ArrayList<ImportedGameEntity>()
                val startIdx = (gamesArr.length() - maxGames).coerceAtLeast(0)
                for (i in gamesArr.length() - 1 downTo startIdx) {
                    val g = gamesArr.getJSONObject(i)
                    val pgn = g.optString("pgn", "")
                    if (pgn.isBlank()) continue
                    val wObj = g.optJSONObject("white")
                    val bObj = g.optJSONObject("black")
                    val whiteName = wObj?.optString("username", "White") ?: "White"
                    val blackName = bObj?.optString("username", "Black") ?: "Black"
                    val whiteElo = wObj?.optInt("rating")?.takeIf { it > 0 }
                    val blackElo = bObj?.optInt("rating")?.takeIf { it > 0 }
                    val urlId = g.optString("url", UUID.randomUUID().toString()).substringAfterLast('/')
                    val endTimeSec = g.optLong("end_time", System.currentTimeMillis() / 1000)
                    val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        .format(java.util.Date(endTimeSec * 1000))
                    val resultHeader = Regex("""\[Result\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1) ?: "*"
                    val ecoUrl = g.optString("eco", "")
                    val opening = ecoUrl.substringAfterLast('/').replace('-', ' ')

                    imported.add(
                        ImportedGameEntity(
                            id = "chesscom_$urlId",
                            platform = "chesscom",
                            white = whiteName,
                            black = blackName,
                            whiteRating = whiteElo,
                            blackRating = blackElo,
                            result = resultHeader,
                            datePlayed = dateStr,
                            openingName = opening,
                            pgn = pgn
                        )
                    )
                }
                if (imported.isNotEmpty()) {
                    dao.upsertImportedGames(imported)
                }
                imported
            }
        }

    suspend fun saveCustomPgnGame(pgn: String): ImportedGameEntity = withContext(Dispatchers.IO) {
        val white = Regex("""\[White\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1) ?: "Player 1"
        val black = Regex("""\[Black\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1) ?: "Player 2"
        val result = Regex("""\[Result\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1) ?: "*"
        val event = Regex("""\[Event\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1) ?: "Imported PGN"
        val date = Regex("""\[Date\s+"([^"]+)"\]""").find(pgn)?.groupValues?.get(1) ?: ""
        val entity = ImportedGameEntity(
            id = "pgn_${UUID.randomUUID().toString().take(8)}",
            platform = "pgn",
            white = white,
            black = black,
            result = result,
            datePlayed = date,
            openingName = event,
            pgn = pgn
        )
        dao.upsertImportedGame(entity)
        entity
    }

    suspend fun updateSavedGamePgn(gameId: String, updatedPgn: String) {
        dao.updateGamePgn(gameId, updatedPgn)
    }

    suspend fun deleteImportedGame(gameId: String) {
        dao.deleteImportedGame(gameId)
    }
}
