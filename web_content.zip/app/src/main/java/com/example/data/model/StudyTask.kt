package com.example.data.model

data class StudyTask(
  val id: String,
  val title: String,
  val subject: Subject,
  val targetQuestions: Int = 20,
  val completedQuestions: Int = 0,
  val targetMinutes: Int = 30,
  val completedMinutes: Int = 0,
  val isCompleted: Boolean = false,
  val dayOfWeek: String = "Bugün",
  val priority: String = "Yüksek",
  val topicRef: String? = null,
  val scheduledDate: String = "2026-11-12",
  val reminderTime: String? = null,
  val hasReminder: Boolean = false,
  val notes: String = ""
)
