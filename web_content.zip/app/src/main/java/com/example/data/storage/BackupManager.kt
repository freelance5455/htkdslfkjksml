package com.example.data.storage

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.example.data.local.BookingEntity
import com.example.data.local.ClientEntity
import com.example.data.local.DocumentEntity
import com.example.data.local.PaymentEntity
import com.example.data.local.PreferencesManager
import com.example.data.local.SdTravelDatabase
import com.example.data.model.BookingStatus
import com.example.data.model.DocumentType
import com.example.data.model.PaymentMethod
import com.example.data.model.RestoreSummary
import com.example.data.model.TripType
import com.example.utils.DateFormatters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class LocalBackupFile(
    val file: File,
    val name: String,
    val sizeBytes: Long,
    val modifiedAt: Long,
)

class BackupManager(
    private val context: Context,
    private val database: SdTravelDatabase,
    private val documentStorage: DocumentStorage,
    private val preferencesManager: PreferencesManager,
) {
    private val dao = database.sdTravelDao()

    private val backupsDir: File
        get() = File(context.filesDir, "backups").apply { if (!exists()) mkdirs() }

    suspend fun createFullBackup(): File = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()
        val fileName = "SD_TRAVEL_Backup_${DateFormatters.fileTimestamp()}.zip"
        val outFile = File(backupsDir, fileName)

        val clients = dao.getAllClientsOnce()
        val bookings = dao.getAllBookingsOnce()
        val payments = dao.getAllPaymentsOnce()
        val documents = dao.getAllDocumentsOnce()

        val rootJson = JSONObject().apply {
            put("schemaVersion", 1)
            put("app", "SD TRAVEL")
            put("createdAt", timestamp)

            put("clients", JSONArray().apply {
                clients.forEach { c ->
                    put(JSONObject().apply {
                        put("id", c.id)
                        put("clientCode", c.clientCode)
                        put("fullName", c.fullName)
                        put("phone", c.phone)
                        put("whatsapp", c.whatsapp)
                        put("nationalId", c.nationalId)
                        put("passportNumber", c.passportNumber)
                        put("birthDate", c.birthDate)
                        put("notes", c.notes)
                        put("createdAt", c.createdAt)
                    })
                }
            })

            put("bookings", JSONArray().apply {
                bookings.forEach { b ->
                    put(JSONObject().apply {
                        put("id", b.id)
                        put("clientId", b.clientId)
                        put("tripDate", b.tripDate)
                        put("returnDate", b.returnDate)
                        put("tripType", b.tripType.name)
                        put("customTripLabel", b.customTripLabel)
                        put("companyName", b.companyName)
                        put("makkahHotel", b.makkahHotel)
                        put("madinahHotel", b.madinahHotel)
                        put("totalPrice", b.totalPrice)
                        put("extraAmount", b.extraAmount)
                        put("costAmount", b.costAmount)
                        put("status", b.status.name)
                        put("notes", b.notes)
                        put("createdAt", b.createdAt)
                    })
                }
            })

            put("payments", JSONArray().apply {
                payments.forEach { p ->
                    put(JSONObject().apply {
                        put("id", p.id)
                        put("bookingId", p.bookingId)
                        put("amount", p.amount)
                        put("paymentDate", p.paymentDate)
                        put("paymentMethod", p.paymentMethod.name)
                        put("isDeposit", p.isDeposit)
                        put("notes", p.notes)
                        put("createdAt", p.createdAt)
                    })
                }
            })

            put("documents", JSONArray().apply {
                documents.forEach { d ->
                    put(JSONObject().apply {
                        put("id", d.id)
                        put("bookingId", d.bookingId)
                        put("docType", d.docType.name)
                        put("title", d.title)
                        put("relativePath", d.relativePath)
                        put("createdAt", d.createdAt)
                    })
                }
            })
        }

        ZipOutputStream(FileOutputStream(outFile)).use { zip ->
            zip.putNextEntry(ZipEntry("backup_data.json"))
            zip.write(rootJson.toString(2).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            val addedEntries = mutableSetOf<String>()
            documents.forEach { doc ->
                val file = documentStorage.resolveFile(doc.relativePath)
                if (file.exists() && file.isFile && addedEntries.add(doc.relativePath)) {
                    zip.putNextEntry(ZipEntry(doc.relativePath))
                    FileInputStream(file).use { input -> input.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }

        preferencesManager.recordBackup(timestamp, fileName)
        outFile
    }

    suspend fun copyBackupToUri(backupFile: File, targetUri: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openOutputStream(targetUri)?.use { output ->
                FileInputStream(backupFile).use { input ->
                    input.copyTo(output)
                }
            } ?: return@runCatching false
            true
        }.getOrDefault(false)
    }

    suspend fun restoreFromUri(uri: Uri): RestoreSummary = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            restoreFromStream(stream)
        } ?: throw IllegalStateException("تعذر فتح ملف النسخة الاحتياطية المحدد")
    }

    suspend fun restoreFromFile(file: File): RestoreSummary = withContext(Dispatchers.IO) {
        FileInputStream(file).use { stream ->
            restoreFromStream(stream)
        }
    }

    private suspend fun restoreFromStream(inputStream: InputStream): RestoreSummary {
        val tempRestoreDir = File(context.cacheDir, "restore_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            var jsonContent: String? = null
            ZipInputStream(inputStream).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val safeName = entry.name.replace("\\", "/")
                        if (safeName == "backup_data.json") {
                            jsonContent = zip.readBytes().toString(Charsets.UTF_8)
                        } else if (safeName.startsWith("documents/") && !safeName.contains("..")) {
                            val targetTemp = File(tempRestoreDir, safeName)
                            targetTemp.parentFile?.mkdirs()
                            FileOutputStream(targetTemp).use { out -> zip.copyTo(out) }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }

            val rawJson = jsonContent ?: throw IllegalArgumentException("ملف النسخة الاحتياطية غير صالح أو لا يحتوي على backup_data.json")
            val root = JSONObject(rawJson)

            val clientsJson = root.optJSONArray("clients") ?: JSONArray()
            val bookingsJson = root.optJSONArray("bookings") ?: JSONArray()
            val paymentsJson = root.optJSONArray("payments") ?: JSONArray()
            val documentsJson = root.optJSONArray("documents") ?: JSONArray()

            var addedClients = 0
            var skippedDuplicateClients = 0
            var addedBookings = 0
            var addedPayments = 0
            var restoredDocuments = 0

            val oldClientIdToNewId = mutableMapOf<Long, Long>()
            val skippedOldClientIds = mutableSetOf<Long>()
            val oldBookingIdToNewId = mutableMapOf<Long, Long>()

            database.withTransaction {
                for (i in 0 until clientsJson.length()) {
                    val obj = clientsJson.getJSONObject(i)
                    val oldId = obj.getLong("id")
                    val code = obj.getString("clientCode").trim()
                    val existing = dao.getClientByCode(code)
                    if (existing != null) {
                        // Strict rule: never duplicate clients with an existing clientCode
                        skippedDuplicateClients++
                        skippedOldClientIds.add(oldId)
                        oldClientIdToNewId[oldId] = existing.id
                    } else {
                        val newId = dao.insertClient(
                            ClientEntity(
                                clientCode = code,
                                fullName = obj.getString("fullName"),
                                phone = obj.optString("phone"),
                                whatsapp = obj.optString("whatsapp"),
                                nationalId = obj.optString("nationalId"),
                                passportNumber = obj.optString("passportNumber"),
                                birthDate = obj.optString("birthDate"),
                                notes = obj.optString("notes"),
                                createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            )
                        )
                        oldClientIdToNewId[oldId] = newId
                        addedClients++
                    }
                }

                for (i in 0 until bookingsJson.length()) {
                    val obj = bookingsJson.getJSONObject(i)
                    val oldBookingId = obj.getLong("id")
                    val oldClientId = obj.getLong("clientId")
                    // Only restore bookings for newly added clients to prevent duplicating bookings on repeated restores
                    if (skippedOldClientIds.contains(oldClientId)) continue
                    val newClientId = oldClientIdToNewId[oldClientId] ?: continue

                    val newBookingId = dao.insertBooking(
                        BookingEntity(
                            clientId = newClientId,
                            tripDate = obj.optString("tripDate"),
                            returnDate = obj.optString("returnDate"),
                            tripType = TripType.fromLabel(obj.optString("tripType")),
                            customTripLabel = obj.optString("customTripLabel"),
                            companyName = obj.optString("companyName"),
                            makkahHotel = obj.optString("makkahHotel"),
                            madinahHotel = obj.optString("madinahHotel"),
                            totalPrice = obj.optDouble("totalPrice", 0.0),
                            extraAmount = obj.optDouble("extraAmount", 0.0),
                            costAmount = obj.optDouble("costAmount", 0.0),
                            status = BookingStatus.fromName(obj.optString("status")),
                            notes = obj.optString("notes"),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        )
                    )
                    oldBookingIdToNewId[oldBookingId] = newBookingId
                    addedBookings++
                }

                for (i in 0 until paymentsJson.length()) {
                    val obj = paymentsJson.getJSONObject(i)
                    val oldBookingId = obj.getLong("bookingId")
                    val newBookingId = oldBookingIdToNewId[oldBookingId] ?: continue

                    dao.insertPayment(
                        PaymentEntity(
                            bookingId = newBookingId,
                            amount = obj.optDouble("amount", 0.0),
                            paymentDate = obj.optString("paymentDate"),
                            paymentMethod = PaymentMethod.fromName(obj.optString("paymentMethod")),
                            isDeposit = obj.optBoolean("isDeposit", false),
                            notes = obj.optString("notes"),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        )
                    )
                    addedPayments++
                }

                for (i in 0 until documentsJson.length()) {
                    val obj = documentsJson.getJSONObject(i)
                    val oldBookingId = obj.getLong("bookingId")
                    val newBookingId = oldBookingIdToNewId[oldBookingId] ?: continue
                    val oldRelPath = obj.optString("relativePath")
                    val sourceFile = File(tempRestoreDir, oldRelPath)
                    if (sourceFile.exists() && sourceFile.isFile) {
                        val newRelPath = documentStorage.saveTempFilePermanently(sourceFile, newBookingId)
                        dao.insertDocument(
                            DocumentEntity(
                                bookingId = newBookingId,
                                docType = DocumentType.fromName(obj.optString("docType")),
                                title = obj.optString("title"),
                                relativePath = newRelPath,
                                createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            )
                        )
                        restoredDocuments++
                    }
                }
            }

            return RestoreSummary(
                addedClients = addedClients,
                skippedDuplicateClients = skippedDuplicateClients,
                addedBookings = addedBookings,
                addedPayments = addedPayments,
                restoredDocuments = restoredDocuments,
            )
        } finally {
            tempRestoreDir.deleteRecursively()
        }
    }

    fun listLocalBackups(): List<LocalBackupFile> {
        return backupsDir.listFiles { file -> file.isFile && file.name.endsWith(".zip") }
            ?.sortedByDescending { it.lastModified() }
            ?.map {
                LocalBackupFile(
                    file = it,
                    name = it.name,
                    sizeBytes = it.length(),
                    modifiedAt = it.lastModified(),
                )
            } ?: emptyList()
    }

    fun deleteBackupFile(file: File): Boolean = runCatching { file.delete() }.getOrDefault(false)
}
