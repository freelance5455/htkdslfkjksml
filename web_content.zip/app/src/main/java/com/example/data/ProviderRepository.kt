package com.example.data

import android.content.Context
import com.example.R
import com.example.model.Provider
import com.example.util.OperationType
import com.example.util.handleFirestoreError
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ProviderRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val providersCollection = db.collection("providers")

    fun observeActiveProviders(): Flow<List<Provider>> =
        providersCollection
            .whereEqualTo("active", true)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Provider::class.java)
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, providersCollection.path)
                }
                throw error
            }

    fun observeAllProviders(): Flow<List<Provider>> =
        providersCollection
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(Provider::class.java)
            }
            .catch { error ->
                if (error is Exception) {
                    handleFirestoreError(error, OperationType.LIST, providersCollection.path)
                }
                throw error
            }

    suspend fun createProvider(provider: Provider): Result<String> {
        return try {
            val payload = provider.toMap() + mapOf(
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            val docRef = providersCollection.document()
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, providersCollection.path)
            Result.failure(e)
        }
    }

    suspend fun updateProvider(provider: Provider): Result<Unit> {
        require(provider.id.isNotBlank()) { "Provider ID must not be blank" }
        val docRef = providersCollection.document(provider.id)
        return try {
            val payload = provider.toMap() + mapOf(
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun toggleActive(providerId: String, currentActive: Boolean): Result<Unit> {
        require(providerId.isNotBlank()) { "Provider ID must not be blank" }
        val docRef = providersCollection.document(providerId)
        return try {
            docRef.update(
                mapOf(
                    "active" to !currentActive,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteProvider(providerId: String): Result<Unit> {
        require(providerId.isNotBlank()) { "Provider ID must not be blank" }
        val docRef = providersCollection.document(providerId)
        return try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun seedInitialProviders(): Result<Int> {
        return try {
            val current = providersCollection.limit(1).get().await()
            if (!current.isEmpty) {
                return Result.success(0)
            }

            val seedList = listOf(
                Provider(
                    name = "राम बहादुर थापा (Ram B. Thapa)",
                    category = "electrician",
                    city = "Tulsipur",
                    description = "घर तथा पसलको वायरिङ, इन्भर्टर जडान, मिटर बक्स र सम्पूर्ण बिजुली मर्मतमा १० वर्षको अनुभव।",
                    phone = "9847812345",
                    phonePublic = true,
                    active = true,
                    rating = 4.9,
                    experienceYears = 10
                ),
                Provider(
                    name = "सुरेश चौधरी (Suresh Chaudhary)",
                    category = "plumber",
                    city = "Tulsipur",
                    description = "धारा चुहावट, नयाँ घरमा पाइप फिटिङ, पानी ट्याङ्की र सेनेटरी सम्बन्धी भरपर्दो सेवा।",
                    phone = "9809823456",
                    phonePublic = true,
                    active = true,
                    rating = 4.8,
                    experienceYears = 7
                ),
                Provider(
                    name = "कमल श्रेष्ठ (Kamal Shrestha)",
                    category = "other_repairs",
                    city = "Tulsipur",
                    description = "रेफ्रिजरेटर, वासिङ मेसिन, माइक्रोवेभ र पानी तान्ने मोटर मर्मत विशेषज्ञ।",
                    phone = "9857834567",
                    phonePublic = true,
                    active = true,
                    rating = 4.7,
                    experienceYears = 8
                ),
                Provider(
                    name = "दिनेश शर्मा (Dinesh Sharma)",
                    category = "electrician",
                    city = "Ghorahi",
                    description = "घोराही बजार क्षेत्रमा छिटो र सस्तो बिजुली सेवा, थ्री-फेज लाइन तथा स्विचबोर्ड मर्मत।",
                    phone = "9847198765",
                    phonePublic = true,
                    active = true,
                    rating = 4.9,
                    experienceYears = 6
                ),
                Provider(
                    name = "सन्तोष बुढा (Santosh Budha)",
                    category = "plumber",
                    city = "Ghorahi",
                    description = "बाथरुम फिटिङ, गिजिर जडान तथा ढल निकास मर्मतमा दक्ष प्राविधिक।",
                    phone = "9812345678",
                    phonePublic = false,
                    active = true,
                    rating = 4.6,
                    experienceYears = 5
                ),
                Provider(
                    name = "प्रकाश घर्ती (Prakash Gharti)",
                    category = "other_repairs",
                    city = "Lamahi",
                    description = "ग्यास चुल्हो, सिलिण्डर रेगुलेटर र घरायसी विद्युतीय सामग्री मर्मत केन्द्र।",
                    phone = "9867011223",
                    phonePublic = true,
                    active = true,
                    rating = 4.7,
                    experienceYears = 4
                ),
                Provider(
                    name = "नारायण केसी (Narayan KC)",
                    category = "electrician",
                    city = "Bhalubang",
                    description = "भालुवाङ र राप्ती गाउँपालिका क्षेत्रमा सौर्य ऊर्जा (Solar) र विद्युतीय मर्मत सेवा।",
                    phone = "9847554433",
                    phonePublic = true,
                    active = true,
                    rating = 4.8,
                    experienceYears = 9
                )
            )

            for (prov in seedList) {
                val payload = prov.toMap() + mapOf(
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                providersCollection.document().set(payload).await()
            }
            Result.success(seedList.size)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, providersCollection.path)
            Result.failure(e)
        }
    }
}
