package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ai.AnswerMode
import com.example.ui.theme.ThemePreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "luminary_prefs")

class LuminaryRepository(
    private val context: Context,
    private val dao: LuminaryDao
) {
    private object PrefKeys {
        val ANSWER_MODE = stringPreferencesKey("answer_mode")
        val THEME_PREF = stringPreferencesKey("theme_preference")
    }

    val threads: Flow<List<ThreadEntity>> = dao.observeThreads()
    val bookmarkedMessages: Flow<List<MessageEntity>> = dao.observeBookmarkedMessages()

    val preferredMode: Flow<AnswerMode> = context.dataStore.data.map { prefs ->
        val raw = prefs[PrefKeys.ANSWER_MODE]
        AnswerMode.entries.firstOrNull { it.name == raw } ?: AnswerMode.BALANCED
    }

    val themePreference: Flow<ThemePreference> = context.dataStore.data.map { prefs ->
        val raw = prefs[PrefKeys.THEME_PREF]
        ThemePreference.entries.firstOrNull { it.name == raw } ?: ThemePreference.SYSTEM
    }

    fun observeMessages(threadId: Long): Flow<List<MessageEntity>> =
        dao.observeMessagesForThread(threadId)

    suspend fun getMessagesOnce(threadId: Long): List<MessageEntity> =
        dao.getMessagesForThreadOnce(threadId)

    suspend fun createThread(title: String, mode: AnswerMode): Long {
        val now = System.currentTimeMillis()
        return dao.insertThread(
            ThreadEntity(
                title = title.take(80),
                modeName = mode.name,
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun touchThread(threadId: Long, mode: AnswerMode) {
        dao.touchThread(threadId, System.currentTimeMillis(), mode.name)
    }

    suspend fun deleteThread(threadId: Long) {
        val messages = dao.getMessagesForThreadOnce(threadId)
        withContext(Dispatchers.IO) {
            messages.mapNotNull { it.imagePath }.forEach { path ->
                runCatching { File(path).delete() }
            }
        }
        dao.deleteThread(threadId)
    }

    suspend fun insertMessage(
        threadId: Long,
        role: String,
        text: String,
        imagePath: String? = null,
        modeLabel: String? = null
    ): Long {
        return dao.insertMessage(
            MessageEntity(
                threadId = threadId,
                role = role,
                text = text,
                imagePath = imagePath,
                modeLabel = modeLabel,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    suspend fun setBookmarked(messageId: Long, bookmarked: Boolean) {
        dao.setBookmarked(messageId, bookmarked)
    }

    suspend fun deleteMessage(messageId: Long) {
        dao.deleteMessage(messageId)
    }

    suspend fun savePreferredMode(mode: AnswerMode) {
        context.dataStore.edit { it[PrefKeys.ANSWER_MODE] = mode.name }
    }

    suspend fun saveThemePreference(theme: ThemePreference) {
        context.dataStore.edit { it[PrefKeys.THEME_PREF] = theme.name }
    }

    suspend fun decodeAndPersistAttachment(uri: Uri): Pair<Bitmap, String>? = withContext(Dispatchers.IO) {
        runCatching {
            val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOpts)
            }
            val maxDim = 1280
            var sampleSize = 1
            while (boundsOpts.outWidth / sampleSize > maxDim || boundsOpts.outHeight / sampleSize > maxDim) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: return@withContext null

            val scaled = scaleBitmapIfNeeded(decoded, maxDim)
            val dir = File(context.filesDir, "attachments").apply { mkdirs() }
            val file = File(dir, "img_${UUID.randomUUID()}.jpg")
            FileOutputStream(file).use { out ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
            }
            scaled to file.absolutePath
        }.getOrNull()
    }

    suspend fun loadBitmapFromPath(path: String?): Bitmap? = withContext(Dispatchers.IO) {
        if (path.isNullOrBlank()) return@withContext null
        runCatching {
            val file = File(path)
            if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
        }.getOrNull()
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDim: Int): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= maxDim && h <= maxDim) return bitmap
        val ratio = minOf(maxDim.toFloat() / w, maxDim.toFloat() / h)
        val targetW = (w * ratio).toInt().coerceAtLeast(1)
        val targetH = (h * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    }
}
