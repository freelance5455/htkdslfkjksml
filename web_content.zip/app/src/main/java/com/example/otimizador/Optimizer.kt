package com.example.otimizador

object Optimizer {

    private fun StringBuilder.step(label: String, cmd: String) {
        val (code, out) = Shell.run(cmd)
        appendLine(if (code == 0) "✓ $label" else "✗ $label ${out.take(80)}")
    }

    private fun animations(scale: String) =
        "settings put global window_animation_scale $scale; " +
            "settings put global transition_animation_scale $scale; " +
            "settings put global animator_duration_scale $scale"

    /** Modo Jogo: reduz animações, libera RAM, ativa game mode e abre o jogo. */
    fun gameOn(pkg: String) = buildString {
        step("Animações reduzidas (0.5x)", animations("0.5"))
        step("Apps em segundo plano encerrados", "am kill-all")
        step("Game mode: desempenho", "cmd game mode performance $pkg")
        step("Abrindo o jogo", "monkey -p $pkg -c android.intent.category.LAUNCHER 1")
    }

    /** Restaura as configurações normais. */
    fun gameOff(pkg: String) = buildString {
        step("Animações restauradas (1x)", animations("1.0"))
        step("Game mode: padrão", "cmd game mode standard $pkg")
    }

    /** Compila o app para abrir e rodar mais rápido. */
    fun compile(pkg: String) = buildString {
        step("Compilação speed-profile (pode demorar)", "cmd package compile -m speed-profile -f $pkg")
    }

    /** Limpeza rápida: encerra apps em cache e limpa caches. */
    fun clean() = buildString {
        step("Apps em segundo plano encerrados", "am kill-all")
        step("Cache dos apps limpo", "pm trim-caches 999G")
    }
}
