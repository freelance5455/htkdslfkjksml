package com.example.otimizador

import rikka.shizuku.Shizuku

/** Executa comandos shell com privilégio de ADB via Shizuku. */
object Shell {
    // Shizuku.newProcess é privado nas versões 13.x, por isso usamos reflexão.
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    /** Retorna (código de saída, saída combinada stdout+stderr). */
    fun run(cmd: String): Pair<Int, String> {
        val p = newProcess.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        val code = p.waitFor()
        return code to (out + err).trim()
    }
}
