package com.example.otimizador

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var web: WebView

    private val onBinder = Shizuku.OnBinderReceivedListener { notifyJs() }
    private val onDead = Shizuku.OnBinderDeadListener { notifyJs() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> notifyJs() }

    private fun notifyJs() {
        if (::web.isInitialized) web.post { web.evaluateJavascript("refresh()", null) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addBinderDeadListener(onDead)
        Shizuku.addRequestPermissionResultListener(onPerm)
    }

    override fun onResume() {
        super.onResume()
        notifyJs()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeBinderDeadListener(onDead)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        super.onDestroy()
    }

    /** Ponte entre o index.html (window.Android) e o Shizuku. */
    inner class Bridge {

        @JavascriptInterface
        fun status(): String = when {
            !Shizuku.pingBinder() -> "off"
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> "perm"
            else -> "ready"
        }

        @JavascriptInterface
        fun apps(): String {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val arr = JSONArray()
            pm.queryIntentActivities(intent, 0)
                .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
                .filter { it.second != packageName }
                .distinctBy { it.second }
                .sortedBy { it.first.lowercase() }
                .forEach { arr.put(JSONObject().put("label", it.first).put("pkg", it.second)) }
            return arr.toString()
        }

        @JavascriptInterface
        fun requestPermission() {
            web.post { Shizuku.requestPermission(1001) }
        }

        @JavascriptInterface
        fun run(action: String, pkg: String) {
            thread {
                val out = runCatching {
                    // valida o nome do pacote antes de usar em comando shell
                    if (action != "clean" && !Regex("^[A-Za-z0-9._]+$").matches(pkg)) {
                        "Pacote inválido."
                    } else when (action) {
                        "on" -> Optimizer.gameOn(pkg)
                        "off" -> Optimizer.gameOff(pkg)
                        "compile" -> Optimizer.compile(pkg)
                        "clean" -> Optimizer.clean()
                        else -> "Ação inválida."
                    }
                }.getOrElse { "Erro: ${it.message}" }
                web.post { web.evaluateJavascript("onResult(${JSONObject.quote(out)})", null) }
            }
        }
    }
}
