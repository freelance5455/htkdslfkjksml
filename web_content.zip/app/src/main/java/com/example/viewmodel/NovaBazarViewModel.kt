package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.data.NovaBazarRepository
import com.example.model.CartItem
import com.example.model.DeliveryZone
import com.example.model.Order
import com.example.model.OrderItem
import com.example.model.OrderStatus
import com.example.model.Product
import com.example.model.ShopSettings
import com.example.model.SortOption
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.model.WishlistItem
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class MarketFilterState(
    val query: String = "",
    val selectedCategory: String = "সব",
    val sortOption: SortOption = SortOption.POPULAR,
    val onlyDiscounted: Boolean = false
)

class NovaBazarViewModel(
    private val repository: NovaBazarRepository,
    val currentUserId: String
) : ViewModel() {

    private val _filterState = MutableStateFlow(MarketFilterState())
    val filterState: StateFlow<MarketFilterState> = _filterState.asStateFlow()

    private val _selectedDeliveryZone = MutableStateFlow(DeliveryZone.DHAKA_CITY)
    val selectedDeliveryZone: StateFlow<DeliveryZone> = _selectedDeliveryZone.asStateFlow()

    private val _isAdminUnlocked = MutableStateFlow(false)
    val isAdminUnlocked: StateFlow<Boolean> = _isAdminUnlocked.asStateFlow()

    private val _isMutating = MutableStateFlow(false)
    val isMutating: StateFlow<Boolean> = _isMutating.asStateFlow()

    private val _toastEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toastEvents: SharedFlow<String> = _toastEvents.asSharedFlow()

    val productsState: StateFlow<UiState<List<Product>>> =
        repository.observeProducts(currentUserId)
            .toUiState("পণ্য লোড করা যায়নি")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val ordersState: StateFlow<UiState<List<Order>>> =
        repository.observeOrders(currentUserId)
            .toUiState("অর্ডার তালিকা লোড করা যায়নি")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val cartItems: StateFlow<List<CartItem>> =
        repository.observeCart(currentUserId)
            .catch { error ->
                unwrapOrThrow(error, "Cart")
                emit(emptyList())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val wishlistIds: StateFlow<Set<String>> =
        repository.observeWishlist(currentUserId)
            .map { items -> items.map(WishlistItem::productId).toSet() }
            .catch { error ->
                unwrapOrThrow(error, "Wishlist")
                emit(emptySet())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptySet())

    val shopSettings: StateFlow<ShopSettings> =
        repository.observeShopSettings(currentUserId)
            .catch { error ->
                unwrapOrThrow(error, "Settings")
                emit(ShopSettings())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), ShopSettings())

    val userProfile: StateFlow<UserProfile> =
        repository.observeUserProfile(currentUserId)
            .catch { error ->
                unwrapOrThrow(error, "Profile")
                emit(UserProfile())
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UserProfile())

    val categories: StateFlow<List<String>> =
        productsState.map { state ->
            when (state) {
                is UiState.Success -> listOf("সব") + state.data.map { it.category }.distinct()
                else -> listOf("সব")
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), listOf("সব"))

    val filteredProductsState: StateFlow<UiState<List<Product>>> =
        combine(productsState, _filterState) { state, filter ->
            when (state) {
                is UiState.Loading -> UiState.Loading
                is UiState.Error -> state
                is UiState.Success -> {
                    val q = filter.query.trim().lowercase()
                    val filtered = state.data.filter { product ->
                        val catMatch = filter.selectedCategory == "সব" || product.category == filter.selectedCategory
                        val queryMatch = q.isEmpty() ||
                            product.name.lowercase().contains(q) ||
                            product.category.lowercase().contains(q) ||
                            product.description.lowercase().contains(q)
                        val discountMatch = !filter.onlyDiscounted || product.discountPercent > 0
                        catMatch && queryMatch && discountMatch
                    }
                    val sorted = when (filter.sortOption) {
                        SortOption.POPULAR -> filtered.sortedByDescending { (if (it.featured) 10000L else 0L) + it.soldCount }
                        SortOption.DISCOUNT -> filtered.sortedByDescending { it.discountPercent }
                        SortOption.PRICE_LOW -> filtered.sortedBy { it.price }
                        SortOption.PRICE_HIGH -> filtered.sortedByDescending { it.price }
                    }
                    UiState.Success(sorted)
                }
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val cartBadgeCount: StateFlow<Int> =
        cartItems.map { items -> items.sumOf { it.qty.toInt() } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), 0)

    init {
        viewModelScope.launch {
            repository.ensureInitialSeed(currentUserId).onFailure { err ->
                Log.w(TAG, "Initial catalog seed failed", err)
            }
        }
    }

    private fun <T> Flow<T>.toUiState(fallbackError: String): Flow<UiState<T>> =
        map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val rootError = unwrapOrThrow(error, TAG)
                emit(UiState.Error(rootError.localizedMessage ?: fallbackError))
            }

    private fun unwrapOrThrow(error: Throwable, tag: String): Throwable {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(tag, "Firestore stream error", rootError)
        return rootError
    }

    fun updateSearchQuery(query: String) {
        _filterState.value = _filterState.value.copy(query = query)
    }

    fun selectCategory(category: String) {
        _filterState.value = _filterState.value.copy(selectedCategory = category)
    }

    fun updateSortOption(option: SortOption) {
        _filterState.value = _filterState.value.copy(sortOption = option)
    }

    fun toggleDiscountOnly() {
        _filterState.value = _filterState.value.copy(onlyDiscounted = !_filterState.value.onlyDiscounted)
    }

    fun selectDeliveryZone(zone: DeliveryZone) {
        _selectedDeliveryZone.value = zone
    }

    fun addToCart(product: Product, deltaQty: Long = 1L) {
        if (product.id.isBlank()) return
        viewModelScope.launch {
            val currentQty = cartItems.value.firstOrNull { it.productId == product.id }?.qty ?: 0L
            val targetQty = (currentQty + deltaQty).coerceIn(1L, 99L)
            repository.setCartQuantity(currentUserId, product.id, targetQty)
                .onSuccess {
                    _toastEvents.tryEmit("কার্টে যোগ হয়েছে: ${product.name}")
                }
                .onFailure {
                    _toastEvents.tryEmit(it.localizedMessage ?: "কার্টে যোগ করা যায়নি")
                }
        }
    }

    fun updateCartQuantity(productId: String, newQty: Long) {
        viewModelScope.launch {
            repository.setCartQuantity(currentUserId, productId, newQty)
                .onFailure {
                    _toastEvents.tryEmit(it.localizedMessage ?: "কার্ট আপডেট করা যায়নি")
                }
        }
    }

    fun toggleWishlist(product: Product) {
        if (product.id.isBlank()) return
        val currentlySaved = wishlistIds.value.contains(product.id)
        viewModelScope.launch {
            repository.toggleWishlist(currentUserId, product.id, currentlySaved)
                .onSuccess {
                    _toastEvents.tryEmit(
                        if (currentlySaved) "পছন্দের তালিকা থেকে সরানো হয়েছে" else "পছন্দের তালিকায় যোগ হয়েছে ❤️"
                    )
                }
                .onFailure {
                    _toastEvents.tryEmit(it.localizedMessage ?: "আপডেট করা যায়নি")
                }
        }
    }

    fun placeOrder(
        customerName: String,
        phone: String,
        address: String,
        note: String,
        items: List<OrderItem>,
        clearCartAfterOrder: Boolean,
        onSuccess: (orderNumber: String) -> Unit
    ) {
        viewModelScope.launch {
            _isMutating.value = true
            val zone = _selectedDeliveryZone.value
            val settings = shopSettings.value
            val fee = if (zone == DeliveryZone.DHAKA_CITY) settings.dhakaDeliveryFee else settings.outsideDeliveryFee
            val result = try {
                repository.placeOrder(
                    userId = currentUserId,
                    customerName = customerName,
                    phone = phone,
                    address = address,
                    note = note,
                    deliveryZone = zone.label,
                    deliveryFee = fee,
                    items = items,
                    clearCartAfterOrder = clearCartAfterOrder
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                _isMutating.value = false
            }

            result.onSuccess { orderNumber ->
                onSuccess(orderNumber)
            }.onFailure { err ->
                _toastEvents.tryEmit(err.localizedMessage ?: "অর্ডার সম্পন্ন করা যায়নি")
            }
        }
    }

    fun reorderItems(order: Order) {
        viewModelScope.launch {
            var addedCount = 0
            val products = (productsState.value as? UiState.Success)?.data.orEmpty()
            order.items.forEach { item ->
                if (products.any { it.id == item.productId }) {
                    val existingQty = cartItems.value.firstOrNull { it.productId == item.productId }?.qty ?: 0L
                    repository.setCartQuantity(currentUserId, item.productId, (existingQty + item.qty).coerceAtMost(99L))
                    addedCount++
                }
            }
            _toastEvents.tryEmit(
                if (addedCount > 0) "অর্ডারের পণ্যগুলো কার্টে যোগ হয়েছে" else "পণ্যগুলো স্টকে পাওয়া যায়নি"
            )
        }
    }

    fun unlockAdmin(pinAttempt: String): Boolean {
        val currentPin = shopSettings.value.adminPin.ifBlank { "6708" }
        return if (pinAttempt.trim() == currentPin) {
            _isAdminUnlocked.value = true
            true
        } else {
            _toastEvents.tryEmit("ভুল অ্যাডমিন পিন!")
            false
        }
    }

    fun lockAdmin() {
        _isAdminUnlocked.value = false
        _toastEvents.tryEmit("Admin Control Center লগআউট হয়েছে")
    }

    fun saveProduct(
        existingProduct: Product?,
        name: String,
        category: String,
        price: Long,
        oldPrice: Long,
        emoji: String,
        description: String,
        imageBase64: String?,
        featured: Boolean,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _isMutating.value = true
            val result = try {
                repository.saveProduct(
                    userId = currentUserId,
                    existingProduct = existingProduct,
                    name = name,
                    category = category,
                    price = price,
                    oldPrice = oldPrice,
                    emoji = emoji,
                    description = description,
                    imageBase64 = imageBase64,
                    featured = featured
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                _isMutating.value = false
            }

            result.onSuccess {
                _toastEvents.tryEmit("পণ্য সফলভাবে সংরক্ষিত হয়েছে")
                onComplete()
            }.onFailure { err ->
                _toastEvents.tryEmit(err.localizedMessage ?: "পণ্য সংরক্ষণ করা যায়নি")
            }
        }
    }

    fun deleteProduct(productId: String) {
        viewModelScope.launch {
            repository.deleteProduct(currentUserId, productId)
                .onSuccess { _toastEvents.tryEmit("পণ্য মুছে ফেলা হয়েছে") }
                .onFailure { _toastEvents.tryEmit(it.localizedMessage ?: "পণ্য মুছে ফেলা যায়নি") }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(currentUserId, orderId, newStatus)
                .onSuccess { _toastEvents.tryEmit("অর্ডার স্ট্যাটাস আপডেট হয়েছে: ${newStatus.label}") }
                .onFailure { _toastEvents.tryEmit(it.localizedMessage ?: "স্ট্যাটাস আপডেট করা যায়নি") }
        }
    }

    fun updateShopSettings(
        shopName: String,
        phone: String,
        facebookUrl: String,
        currentPinInput: String,
        newPinInput: String,
        dhakaFee: Long,
        outsideFee: Long
    ) {
        val activePin = shopSettings.value.adminPin.ifBlank { "6708" }
        if (currentPinInput.trim() != activePin) {
            _toastEvents.tryEmit("বর্তমান পিন সঠিক নয়")
            return
        }
        val finalPin = newPinInput.trim().ifEmpty { activePin }
        if (finalPin.length < 4) {
            _toastEvents.tryEmit("নতুন পিন কমপক্ষে ৪ অক্ষরের হতে হবে")
            return
        }

        viewModelScope.launch {
            _isMutating.value = true
            val result = try {
                repository.updateShopSettings(
                    userId = currentUserId,
                    shopName = shopName,
                    phone = phone,
                    facebookUrl = facebookUrl,
                    adminPin = finalPin,
                    dhakaFee = dhakaFee,
                    outsideFee = outsideFee
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                _isMutating.value = false
            }

            result.onSuccess {
                _toastEvents.tryEmit("দোকানের সেটিংস ও পিন সংরক্ষিত হয়েছে")
            }.onFailure { err ->
                _toastEvents.tryEmit(err.localizedMessage ?: "সেটিংস সংরক্ষণ করা যায়নি")
            }
        }
    }

    fun saveUserProfile(
        fullName: String,
        phone: String,
        defaultAddress: String,
        preferredZone: DeliveryZone
    ) {
        viewModelScope.launch {
            repository.saveUserProfile(
                userId = currentUserId,
                fullName = fullName,
                phone = phone,
                defaultAddress = defaultAddress,
                preferredZone = preferredZone.label
            ).onSuccess {
                _selectedDeliveryZone.value = preferredZone
            }.onFailure { err ->
                _toastEvents.tryEmit(err.localizedMessage ?: "প্রোফাইল সংরক্ষণ করা যায়নি")
            }
        }
    }

    companion object {
        private const val TAG = "NovaBazarVM"
        private const val STOP_TIMEOUT_MS = 5000L

        fun provideFactory(currentUserId: String) = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                NovaBazarViewModel(NovaBazarRepository(db), currentUserId)
            }
        }
    }
}
