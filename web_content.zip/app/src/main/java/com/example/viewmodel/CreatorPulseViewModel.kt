package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.ai.type.Schema
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

// Data classes for UI state
data class RelatedKeyword(
    val term: String,
    val volume: Int,
    val competition: Int,
    val score: Int
)

data class KeywordResult(
    val keyword: String,
    val overallScore: Int,
    val searchVolume: Int,
    val competition: Int,
    val monthlySearches: String,
    val relatedKeywords: List<RelatedKeyword>,
    val questions: List<String>
)

data class IdeaItem(
    val id: Int,
    val title: String,
    val prediction: String,
    val score: Int,
    val hook: String,
    val tags: List<String>
)

data class SeoOptimizationResult(
    val optimizedTitle: String,
    val optimizedDescription: String,
    val recommendedTags: List<String>
)

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Success(val message: String = "") : AiUiState
    data class Error(val message: String) : AiUiState
}

class CreatorPulseViewModel : ViewModel() {
    private val tag = "CreatorPulseVM"

    private val model by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    private val _keywordState = MutableStateFlow<KeywordResult>(
        KeywordResult(
            keyword = "Tutorial AI untuk Pemula",
            overallScore = 78,
            searchVolume = 84,
            competition = 32,
            monthlySearches = "145,200",
            relatedKeywords = listOf(
                RelatedKeyword("cara menggunakan chatgpt bahasa indonesia", 88, 28, 82),
                RelatedKeyword("aplikasi ai terbaik 2026 gratis", 92, 45, 75),
                RelatedKeyword("belajar artificial intelligence dari nol", 74, 22, 79),
                RelatedKeyword("tools ai untuk konten kreator youtube", 81, 35, 77),
                RelatedKeyword("membuat video dengan ai otomatis", 95, 58, 69)
            ),
            questions = listOf(
                "Bagaimana cara mulai belajar AI tanpa coding?",
                "Apa saja aplikasi AI gratis yang wajib dicoba pemula?",
                "Bisakah menghasilkan uang dari YouTube menggunakan AI?"
            )
        )
    )
    val keywordState: StateFlow<KeywordResult> = _keywordState.asStateFlow()

    private val _ideasState = MutableStateFlow<List<IdeaItem>>(
        listOf(
            IdeaItem(
                1,
                "7 Website AI Rahasia yang Akan Menghemat 10 Jam Kerja Minggu Ini!",
                "Sangat Tinggi",
                94,
                "Mulai dengan menunjukkan hasil akhir dalam 5 detik pertama sebelum menjelaskan daftar website.",
                listOf("ai tools", "produktivitas", "website rahasia", "teknologi 2026")
            ),
            IdeaItem(
                2,
                "Saya Mencoba Hidup 24 Jam Hanya Menggunakan Asisten AI (Hasilnya Mengejutkan!)",
                "Tinggi",
                86,
                "Tantangan personal dengan elemen humor saat AI membuat keputusan yang aneh.",
                listOf("tantangan 24 jam", "eksperimen ai", "vlog teknologi", "indonesia")
            ),
            IdeaItem(
                3,
                "Jangan Beli Laptop Baru Sebelum Mengaktifkan 5 Fitur Tersembunyi Ini",
                "Tinggi",
                81,
                "Tunjukkan perbandingan kecepatan laptop sebelum dan sesudah optimasi.",
                listOf("tips laptop", "windows 11", "percepat laptop", "tutorial pc")
            )
        )
    )
    val ideasState: StateFlow<List<IdeaItem>> = _ideasState.asStateFlow()

    private val _aiStatus = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val aiStatus: StateFlow<AiUiState> = _aiStatus.asStateFlow()

    // 1. Keyword Research with Gemini
    fun analyzeKeyword(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _aiStatus.value = AiUiState.Loading
            try {
                val schema = Schema.obj(
                    properties = mapOf(
                        "keyword" to Schema.string(),
                        "overallScore" to Schema.integer(),
                        "searchVolume" to Schema.integer(),
                        "competition" to Schema.integer(),
                        "monthlySearches" to Schema.string(),
                        "relatedKeywords" to Schema.array(
                            items = Schema.obj(
                                properties = mapOf(
                                    "term" to Schema.string(),
                                    "volume" to Schema.integer(),
                                    "competition" to Schema.integer(),
                                    "score" to Schema.integer()
                                )
                            )
                        ),
                        "questions" to Schema.array(items = Schema.string())
                    )
                )

                val jsonConfig = generationConfig {
                    responseMimeType = "application/json"
                    responseSchema = schema
                }

                val jsonModel = Firebase.ai.generativeModel(
                    modelName = "gemini-3.8-flash",
                    generationConfig = jsonConfig
                )

                val prompt = "Analisis kata kunci YouTube berikut dalam Bahasa Indonesia: \"$query\". Berikan estimasi realistis untuk skor keseluruhan (0-100), volume pencarian (0-100), skor kompetisi (0-100), estimasi pencarian bulanan, 5 kata kunci terkait, dan 3 pertanyaan populer."
                
                val response = withTimeout(60_000L) {
                    jsonModel.generateContent(prompt)
                }
                val jsonText = response.text ?: throw IllegalStateException("Empty response")
                val json = JSONObject(jsonText)

                val kw = json.getString("keyword")
                val overall = json.getInt("overallScore")
                val vol = json.getInt("searchVolume")
                val comp = json.getInt("competition")
                val monthly = json.getString("monthlySearches")

                val relArr = json.getJSONArray("relatedKeywords")
                val relList = mutableListOf<RelatedKeyword>()
                for (i in 0 until relArr.length()) {
                    val obj = relArr.getJSONObject(i)
                    relList.add(
                        RelatedKeyword(
                            term = obj.getString("term"),
                            volume = obj.getInt("volume"),
                            competition = obj.getInt("competition"),
                            score = obj.getInt("score")
                        )
                    )
                }

                val qArr = json.getJSONArray("questions")
                val qList = mutableListOf<String>()
                for (i in 0 until qArr.length()) {
                    qList.add(qArr.getString(i))
                }

                _keywordState.value = KeywordResult(
                    keyword = kw,
                    overallScore = overall,
                    searchVolume = vol,
                    competition = comp,
                    monthlySearches = monthly,
                    relatedKeywords = relList,
                    questions = qList
                )
                _aiStatus.value = AiUiState.Success("Analisis kata kunci berhasil")
            } catch (e: TimeoutCancellationException) {
                Log.e(tag, "Timeout during keyword analysis", e)
                _aiStatus.value = AiUiState.Error("Timeout: Waktu analisis habis (60s).")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(tag, "Keyword analysis failed", e)
                _aiStatus.value = AiUiState.Error("Gagal menganalisis: ${e.localizedMessage}")
            }
        }
    }

    // 2. Daily Ideas Generation with Gemini
    fun generateIdeas(niche: String) {
        if (niche.isBlank()) return
        viewModelScope.launch {
            _aiStatus.value = AiUiState.Loading
            try {
                val schema = Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "id" to Schema.integer(),
                            "title" to Schema.string(),
                            "prediction" to Schema.string(),
                            "score" to Schema.integer(),
                            "hook" to Schema.string(),
                            "tags" to Schema.array(items = Schema.string())
                        )
                    )
                )

                val jsonConfig = generationConfig {
                    responseMimeType = "application/json"
                    responseSchema = schema
                }

                val jsonModel = Firebase.ai.generativeModel(
                    modelName = "gemini-3.8-flash",
                    generationConfig = jsonConfig
                )

                val prompt = "Buat 4 ide video YouTube viral yang sangat menarik (high CTR) untuk niche: \"$niche\" dalam Bahasa Indonesia. Sertakan id (1-4), judul, prediksi performa, skor (75-98), saran hook 5 detik pertama, dan tag."

                val response = withTimeout(60_000L) {
                    jsonModel.generateContent(prompt)
                }
                val jsonText = response.text ?: throw IllegalStateException("Empty response")
                val jsonArr = JSONArray(jsonText)
                val newList = mutableListOf<IdeaItem>()

                for (i in 0 until jsonArr.length()) {
                    val obj = jsonArr.getJSONObject(i)
                    val tagsArr = obj.getJSONArray("tags")
                    val tagsList = mutableListOf<String>()
                    for (j in 0 until tagsArr.length()) {
                        tagsList.add(tagsArr.getString(j))
                    }
                    newList.add(
                        IdeaItem(
                            id = obj.optInt("id", i + 1),
                            title = obj.getString("title"),
                            prediction = obj.getString("prediction"),
                            score = obj.getInt("score"),
                            hook = obj.getString("hook"),
                            tags = tagsList
                        )
                    )
                }

                _ideasState.value = newList
                _aiStatus.value = AiUiState.Success("Ide viral berhasil dibuat")
            } catch (e: TimeoutCancellationException) {
                Log.e(tag, "Timeout during ideas generation", e)
                _aiStatus.value = AiUiState.Error("Timeout: Waktu pembuatan ide habis.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(tag, "Ideas generation failed", e)
                _aiStatus.value = AiUiState.Error("Gagal membuat ide: ${e.localizedMessage}")
            }
        }
    }

    // 3. SEO Optimization with Gemini
    fun optimizeSeo(title: String, desc: String, onResult: (SeoOptimizationResult) -> Unit) {
        if (title.isBlank()) return
        viewModelScope.launch {
            _aiStatus.value = AiUiState.Loading
            try {
                val schema = Schema.obj(
                    properties = mapOf(
                        "optimizedTitle" to Schema.string(),
                        "optimizedDescription" to Schema.string(),
                        "recommendedTags" to Schema.array(items = Schema.string())
                    )
                )

                val jsonConfig = generationConfig {
                    responseMimeType = "application/json"
                    responseSchema = schema
                }

                val jsonModel = Firebase.ai.generativeModel(
                    modelName = "gemini-3.8-flash",
                    generationConfig = jsonConfig
                )

                val prompt = "Optimalkan metadata video YouTube ini untuk SEO dan CTR maksimal dalam Bahasa Indonesia. Judul: \"$title\". Deskripsi: \"$desc\". Berikan judul optimal (maks 65 karakter), deskripsi kaya kata kunci, dan 8 tag SEO terbaik."

                val response = withTimeout(60_000L) {
                    jsonModel.generateContent(prompt)
                }
                val jsonText = response.text ?: throw IllegalStateException("Empty response")
                val json = JSONObject(jsonText)

                val optTitle = json.getString("optimizedTitle")
                val optDesc = json.getString("optimizedDescription")
                val tArr = json.getJSONArray("recommendedTags")
                val tagsList = mutableListOf<String>()
                for (i in 0 until tArr.length()) {
                    tagsList.add(tArr.getString(i))
                }

                _aiStatus.value = AiUiState.Success("SEO berhasil dioptimalkan")
                onResult(SeoOptimizationResult(optTitle, optDesc, tagsList))
            } catch (e: TimeoutCancellationException) {
                Log.e(tag, "Timeout during SEO optimization", e)
                _aiStatus.value = AiUiState.Error("Timeout: Waktu optimasi SEO habis.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(tag, "SEO optimization failed", e)
                _aiStatus.value = AiUiState.Error("Gagal optimasi SEO: ${e.localizedMessage}")
            }
        }
    }
}
