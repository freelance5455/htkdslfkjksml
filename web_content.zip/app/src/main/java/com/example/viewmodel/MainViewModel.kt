package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ActionConfirmation
import com.example.data.model.ActionType
import com.example.data.model.AppInfo
import com.example.data.model.AssistantState
import com.example.data.model.AutomationRoutine
import com.example.data.model.ChatMessage
import com.example.data.model.DeviceStatus
import com.example.data.model.MessageSender
import com.example.data.model.RoutineStep
import com.example.data.model.VisionAnalysisResult
import com.example.data.model.VoiceLanguage
import com.example.data.model.WeatherInfo
import com.example.service.AiEngineService
import com.example.service.DeviceAutomationManager
import com.example.service.VoiceAssistantManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class XtraScreen(val title: String) {
    DASHBOARD("Dashboard"),
    AI_CHAT("AI Chat"),
    PHONE_CONTROLS("Phone Controls"),
    APP_LAUNCHER("App Launcher"),
    AUTOMATION("Automation"),
    UTILITIES_VISION("Vision & Tools"),
    SETTINGS("Settings")
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val TAG = "MainViewModel"

    val deviceManager = DeviceAutomationManager(application)
    val voiceManager = VoiceAssistantManager(application)
    val aiEngine = AiEngineService(application)

    // Current screen navigation
    private val _currentScreen = MutableStateFlow(XtraScreen.DASHBOARD)
    val currentScreen: StateFlow<XtraScreen> = _currentScreen.asStateFlow()

    // Assistant State
    private val _assistantState = MutableStateFlow(AssistantState.IDLE)
    val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

    // Chat messages
    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = MessageSender.XTRA,
                text = "🛡️ **XTRA Systems Online.**\nGreetings, Sir. All cognitive and hardware automation protocols are fully engaged. You can command me with voice (\"Hey XTRA\") or type anytime."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    // Pending Action Confirmation (Strict safety requirement)
    private val _pendingConfirmation = MutableStateFlow<ActionConfirmation?>(null)
    val pendingConfirmation: StateFlow<ActionConfirmation?> = _pendingConfirmation.asStateFlow()

    // Voice language and preferences
    private val _selectedLanguage = MutableStateFlow(VoiceLanguage.ENGLISH)
    val selectedLanguage: StateFlow<VoiceLanguage> = _selectedLanguage.asStateFlow()

    private val _speechSpeed = MutableStateFlow(1.0f)
    val speechSpeed: StateFlow<Float> = _speechSpeed.asStateFlow()

    private val _speechPitch = MutableStateFlow(1.05f)
    val speechPitch: StateFlow<Float> = _speechPitch.asStateFlow()

    // Installed apps
    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    // Weather
    private val _weather = MutableStateFlow(WeatherInfo())
    val weather: StateFlow<WeatherInfo> = _weather.asStateFlow()

    // Vision Analysis
    private val _visionResult = MutableStateFlow<VisionAnalysisResult?>(null)
    val visionResult: StateFlow<VisionAnalysisResult?> = _visionResult.asStateFlow()

    private val _isAnalyzingVision = MutableStateFlow(false)
    val isAnalyzingVision: StateFlow<Boolean> = _isAnalyzingVision.asStateFlow()

    // Automation Routines
    private val _routines = MutableStateFlow(getDefaultRoutines())
    val routines: StateFlow<List<AutomationRoutine>> = _routines.asStateFlow()

    init {
        // Wire voice recognizer callbacks
        voiceManager.onCommandRecognized = { command ->
            handleUserQuery(command)
        }

        voiceManager.onWakeWordDetected = {
            _assistantState.value = AssistantState.LISTENING
        }

        // Observe TTS state
        viewModelScope.launch {
            voiceManager.isSpeaking.collect { speaking ->
                if (speaking) {
                    _assistantState.value = AssistantState.SPEAKING
                } else if (_assistantState.value == AssistantState.SPEAKING) {
                    _assistantState.value = AssistantState.IDLE
                }
            }
        }

        viewModelScope.launch {
            voiceManager.isListening.collect { listening ->
                if (listening) {
                    _assistantState.value = AssistantState.LISTENING
                } else if (_assistantState.value == AssistantState.LISTENING) {
                    _assistantState.value = AssistantState.IDLE
                }
            }
        }

        // Load apps and weather
        loadApps()
        loadWeather()
    }

    fun navigateTo(screen: XtraScreen) {
        _currentScreen.value = screen
    }

    fun loadApps() {
        viewModelScope.launch {
            _installedApps.value = deviceManager.getInstalledLaunchableApps()
        }
    }

    fun loadWeather() {
        viewModelScope.launch {
            _weather.value = aiEngine.fetchLiveWeather()
        }
    }

    fun setLanguage(lang: VoiceLanguage) {
        _selectedLanguage.value = lang
        voiceManager.setLanguage(lang)
    }

    fun setSpeechSpeed(speed: Float) {
        _speechSpeed.value = speed
        voiceManager.setSpeechSpeed(speed)
    }

    fun setSpeechPitch(pitch: Float) {
        _speechPitch.value = pitch
        voiceManager.setSpeechPitch(pitch)
    }

    fun startListening() {
        voiceManager.startListening()
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
        _assistantState.value = AssistantState.IDLE
    }

    /**
     * Primary entrypoint for text or voice command.
     */
    fun handleUserQuery(query: String, userImage: Bitmap? = null) {
        if (query.isBlank() && userImage == null) return

        // Add user message to chat
        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = query.ifBlank { "Analyzed image attachment" },
            imageBitmap = userImage
        )
        _messages.value = _messages.value + userMsg

        _assistantState.value = AssistantState.THINKING

        viewModelScope.launch {
            try {
                if (userImage != null) {
                    // Vision processing
                    _isAnalyzingVision.value = true
                    val result = aiEngine.analyzeImageWithVision(userImage, query)
                    _visionResult.value = result
                    _isAnalyzingVision.value = false

                    val xtraMsg = ChatMessage(
                        sender = MessageSender.XTRA,
                        text = result.summary
                    )
                    _messages.value = _messages.value + xtraMsg
                    voiceManager.speak("Image analysis complete. Details displayed on screen.")
                    _assistantState.value = AssistantState.SPEAKING
                    return@launch
                }

                // AI Reasoning & Automation evaluation
                val result = aiEngine.processUserQuery(
                    rawQuery = query,
                    language = _selectedLanguage.value,
                    deviceManager = deviceManager
                )

                if (result.proposedAction != null) {
                    // Security protocol: Set pending confirmation
                    _pendingConfirmation.value = result.proposedAction

                    val promptMsg = ChatMessage(
                        sender = MessageSender.XTRA,
                        text = result.textResponse,
                        actionConfirmation = result.proposedAction
                    )
                    _messages.value = _messages.value + promptMsg
                    voiceManager.speak(result.speechResponse)
                } else {
                    val xtraMsg = ChatMessage(
                        sender = MessageSender.XTRA,
                        text = result.textResponse,
                        actionSuccessMessage = result.actionSuccessInfo
                    )
                    _messages.value = _messages.value + xtraMsg

                    if (result.executedDirectly) {
                        _assistantState.value = AssistantState.EXECUTING
                        // Re-fetch device status if hardware action was run
                        deviceManager.refreshStatus()
                    }

                    voiceManager.speak(result.speechResponse)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error handling query", e)
                val errMsg = ChatMessage(
                    sender = MessageSender.SYSTEM,
                    text = "⚠️ Execution interrupted: ${e.localizedMessage ?: "Unknown error"}"
                )
                _messages.value = _messages.value + errMsg
                _assistantState.value = AssistantState.IDLE
            }
        }
    }

    fun confirmPendingAction() {
        val action = _pendingConfirmation.value
        if (action != null) {
            action.onConfirm.invoke()
            _pendingConfirmation.value = null

            val successMsg = ChatMessage(
                sender = MessageSender.XTRA,
                text = "✅ Action authorized and executed: **${action.title}**"
            )
            _messages.value = _messages.value + successMsg
            voiceManager.speak("Action authorized and executed, Sir.")
            deviceManager.refreshStatus()
        }
    }

    fun dismissPendingAction() {
        val action = _pendingConfirmation.value
        action?.onCancel?.invoke()
        _pendingConfirmation.value = null

        val abortedMsg = ChatMessage(
            sender = MessageSender.SYSTEM,
            text = "🛑 Action aborted by user."
        )
        _messages.value = _messages.value + abortedMsg
        voiceManager.speak("Action aborted.")
    }

    fun runRoutine(routine: AutomationRoutine) {
        _assistantState.value = AssistantState.EXECUTING
        viewModelScope.launch {
            for (step in routine.steps) {
                when (step.actionType) {
                    ActionType.TOGGLE_TORCH -> {
                        deviceManager.setFlashlight(step.param == "on")
                    }
                    ActionType.ADJUST_VOLUME -> {
                        step.param.toIntOrNull()?.let { deviceManager.setMediaVolume(it) }
                    }
                    ActionType.LAUNCH_APP -> {
                        deviceManager.launchPackage(step.param)
                    }
                    else -> {}
                }
            }
            deviceManager.refreshStatus()
            val msg = "Routine \"${routine.name}\" executed successfully."
            _messages.value = _messages.value + ChatMessage(sender = MessageSender.XTRA, text = "⚡ **Automation Routine Completed**\n$msg")
            voiceManager.speak(msg)
            _assistantState.value = AssistantState.SPEAKING
        }
    }

    fun clearChatHistory() {
        _messages.value = listOf(
            ChatMessage(
                sender = MessageSender.XTRA,
                text = "🛡️ **Conversation history cleared.**\nAll temporary memory wiped securely per user request."
            )
        )
        voiceManager.speak("Conversation history cleared.")
    }

    fun addCustomRoutine(name: String, voiceTrigger: String, steps: List<RoutineStep>) {
        val newRoutine = AutomationRoutine(
            id = java.util.UUID.randomUUID().toString(),
            name = name,
            description = "Custom user sequence",
            voiceTrigger = voiceTrigger,
            iconName = "Bolt",
            isBuiltIn = false,
            isEnabled = true,
            steps = steps
        )
        _routines.value = _routines.value + newRoutine
    }

    private fun getDefaultRoutines(): List<AutomationRoutine> {
        return listOf(
            AutomationRoutine(
                id = "good_morning",
                name = "Good Morning",
                description = "Greets, un-mutes audio, and presents telemetry",
                voiceTrigger = "Good Morning",
                iconName = "WbSunny",
                isBuiltIn = true,
                steps = listOf(
                    RoutineStep("Set volume to 50%", ActionType.ADJUST_VOLUME, "50"),
                    RoutineStep("Disable flashlight", ActionType.TOGGLE_TORCH, "off")
                )
            ),
            AutomationRoutine(
                id = "good_night",
                name = "Good Night",
                description = "Turns off torch, silences media, prepares sleep mode",
                voiceTrigger = "Good Night",
                iconName = "NightsStay",
                isBuiltIn = true,
                steps = listOf(
                    RoutineStep("Mute volume", ActionType.ADJUST_VOLUME, "0"),
                    RoutineStep("Turn off torch", ActionType.TOGGLE_TORCH, "off")
                )
            ),
            AutomationRoutine(
                id = "study_mode",
                name = "Study Mode",
                description = "Silences notifications, turns off flashlight, focuses mind",
                voiceTrigger = "Study Mode",
                iconName = "School",
                isBuiltIn = true,
                steps = listOf(
                    RoutineStep("Mute media volume", ActionType.ADJUST_VOLUME, "0"),
                    RoutineStep("Turn off torch", ActionType.TOGGLE_TORCH, "off")
                )
            ),
            AutomationRoutine(
                id = "gaming_mode",
                name = "Gaming Mode",
                description = "Boosts media volume to 80% for immersive audio",
                voiceTrigger = "Gaming Mode",
                iconName = "SportsEsports",
                isBuiltIn = true,
                steps = listOf(
                    RoutineStep("Set volume to 80%", ActionType.ADJUST_VOLUME, "80")
                )
            ),
            AutomationRoutine(
                id = "meeting_mode",
                name = "Meeting Mode",
                description = "Completely silences phone sounds",
                voiceTrigger = "Meeting Mode",
                iconName = "MeetingRoom",
                isBuiltIn = true,
                steps = listOf(
                    RoutineStep("Mute volume", ActionType.ADJUST_VOLUME, "0")
                )
            ),
            AutomationRoutine(
                id = "battery_saver",
                name = "Battery Saving Mode",
                description = "Lowers volume and turns off torch",
                voiceTrigger = "Battery Saving Mode",
                iconName = "BatterySaver",
                isBuiltIn = true,
                steps = listOf(
                    RoutineStep("Turn off torch", ActionType.TOGGLE_TORCH, "off"),
                    RoutineStep("Reduce volume to 20%", ActionType.ADJUST_VOLUME, "20")
                )
            )
        )
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
