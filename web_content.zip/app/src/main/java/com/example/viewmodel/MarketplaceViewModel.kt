package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MarketplaceRepository
import com.example.localization.AppLang
import com.example.localization.LanguageStore
import com.example.model.*
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

data class SearchFilters(
    val query: String = "",
    val category: ServiceCategory? = null,
    val location: String? = null,
    val maxPriceTzs: Long? = null,
    val minRating: Double = 0.0
)

class MarketplaceViewModel(
    private val repository: MarketplaceRepository,
    private val languageStore: LanguageStore,
    val currentUserId: String,
    val currentUserEmail: String,
    val isAdminUser: Boolean
) : ViewModel() {

    private val _activeRole = MutableStateFlow(ActiveAppRole.CUSTOMER)
    val activeRole: StateFlow<ActiveAppRole> = _activeRole.asStateFlow()

    private val _filters = MutableStateFlow(SearchFilters())
    val filters: StateFlow<SearchFilters> = _filters.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    val language: StateFlow<AppLang> = languageStore.languageFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppLang.SW)

    val userProfile: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .asUiState("profile")

    val providersState: StateFlow<UiState<List<SecurityProvider>>> = repository.observeAllProviders()
        .asUiState("providers")

    val servicesState: StateFlow<UiState<List<SecurityServiceListing>>> = repository.observeAllServices()
        .asUiState("services")

    val customerOrdersState: StateFlow<UiState<List<SecurityOrder>>> = repository.observeCustomerOrders(currentUserId)
        .asUiState("customerOrders")

    val providerOrdersState: StateFlow<UiState<List<SecurityOrder>>> = repository.observeProviderOrders(currentUserId)
        .asUiState("providerOrders")

    val customerPaymentsState: StateFlow<UiState<List<PaymentTransaction>>> = repository.observeCustomerPayments(currentUserId)
        .asUiState("customerPayments")

    val providerPaymentsState: StateFlow<UiState<List<PaymentTransaction>>> = repository.observeProviderPayments(currentUserId)
        .asUiState("providerPayments")

    val customerComplaintsState: StateFlow<UiState<List<Complaint>>> = repository.observeCustomerComplaints(currentUserId)
        .asUiState("customerComplaints")

    // Admin-only streams (gated by isAdminUser so non-admins never trigger PERMISSION_DENIED)
    val adminUsersState: StateFlow<UiState<List<UserProfile>>> =
        if (isAdminUser) repository.observeAdminUsers().asUiState("adminUsers")
        else MutableStateFlow(UiState.Success(emptyList()))

    val adminOrdersState: StateFlow<UiState<List<SecurityOrder>>> =
        if (isAdminUser) repository.observeAdminOrders().asUiState("adminOrders")
        else MutableStateFlow(UiState.Success(emptyList()))

    val adminPaymentsState: StateFlow<UiState<List<PaymentTransaction>>> =
        if (isAdminUser) repository.observeAdminPayments().asUiState("adminPayments")
        else MutableStateFlow(UiState.Success(emptyList()))

    val adminComplaintsState: StateFlow<UiState<List<Complaint>>> =
        if (isAdminUser) repository.observeAdminComplaints().asUiState("adminComplaints")
        else MutableStateFlow(UiState.Success(emptyList()))

    val adminAuditLogsState: StateFlow<UiState<List<AuditLog>>> =
        if (isAdminUser) repository.observeAdminAuditLogs().asUiState("adminAuditLogs")
        else MutableStateFlow(UiState.Success(emptyList()))

    val myProvider: StateFlow<SecurityProvider?> = providersState
        .map { state ->
            (state as? UiState.Success)?.data?.firstOrNull { it.ownerId == currentUserId }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val filteredProviders: StateFlow<List<SecurityProvider>> = combine(providersState, filters) { state, f ->
        val list = (state as? UiState.Success)?.data ?: emptyList()
        list.filter { p ->
            val matchesQuery = f.query.isBlank() ||
                p.companyName.contains(f.query, ignoreCase = true) ||
                p.description.contains(f.query, ignoreCase = true) ||
                p.locations.any { it.contains(f.query, ignoreCase = true) }
            val matchesCat = f.category == null || p.categories.contains(f.category.name)
            val matchesLoc = f.location == null || p.locations.contains(f.location)
            val matchesPrice = f.maxPriceTzs == null || p.startingPriceTzs <= f.maxPriceTzs
            val matchesRating = p.ratingAvg >= f.minRating
            matchesQuery && matchesCat && matchesLoc && matchesPrice && matchesRating
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val filteredServices: StateFlow<List<SecurityServiceListing>> = combine(servicesState, filters) { state, f ->
        val list = (state as? UiState.Success)?.data ?: emptyList()
        list.filter { s ->
            val matchesQuery = f.query.isBlank() ||
                s.title.contains(f.query, ignoreCase = true) ||
                s.companyName.contains(f.query, ignoreCase = true) ||
                s.location.contains(f.query, ignoreCase = true)
            val matchesCat = f.category == null || s.category == f.category.name
            val matchesLoc = f.location == null || s.location == f.location
            val matchesPrice = f.maxPriceTzs == null || s.priceTzs <= f.maxPriceTzs
            s.active && matchesQuery && matchesCat && matchesLoc && matchesPrice
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    init {
        viewModelScope.launch {
            repository.ensureUserProfile(language.value.code)
        }
    }

    private fun <T> Flow<T>.asUiState(label: String): StateFlow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w(TAG, "Stream error [$label]", root)
                emit(UiState.Error(root.localizedMessage ?: "Failed to load $label"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )

    fun observeOrderMessages(orderId: String): Flow<List<OrderMessage>> =
        repository.observeOrderMessages(orderId).catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            emit(emptyList())
        }

    fun setLanguage(lang: AppLang) {
        viewModelScope.launch {
            languageStore.setLanguage(lang)
            val profile = (userProfile.value as? UiState.Success)?.data
            if (profile != null) {
                repository.updateUserProfile(profile.fullName, profile.phone, profile.region, profile.address, lang.code)
            }
        }
    }

    fun setActiveRole(role: ActiveAppRole) {
        if (role == ActiveAppRole.ADMIN && !isAdminUser) return
        _activeRole.value = role
    }

    fun updateFilters(transform: (SearchFilters) -> SearchFilters) {
        _filters.update(transform)
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun postFeedback(msg: String) {
        _feedbackMessage.value = msg
    }

    fun updateUserProfile(fullName: String, phone: String, region: String, address: String, onDone: () -> Unit = {}) {
        runAction("Profile updated") {
            repository.updateUserProfile(fullName, phone, region, address, language.value.code).also {
                if (it.isSuccess) onDone()
            }
        }
    }

    fun registerProvider(
        companyName: String,
        description: String,
        categories: List<ServiceCategory>,
        locations: List<String>,
        startingPriceTzs: Long,
        businessRegNumber: String,
        securityLicenseNumber: String,
        contactPhone: String,
        revenueModel: RevenueModel,
        logoBase64: String?,
        galleryBase64: List<String>,
        onSuccess: () -> Unit = {}
    ) {
        runAction("Provider submitted for Admin verification") {
            repository.registerProvider(
                companyName, description, categories, locations, startingPriceTzs,
                businessRegNumber, securityLicenseNumber, contactPhone, revenueModel,
                logoBase64, galleryBase64
            ).map { }.also { if (it.isSuccess) onSuccess() }
        }
    }

    fun switchRevenueModel(providerId: String, model: RevenueModel) {
        runAction("Billing model updated") {
            repository.switchProviderRevenueModel(providerId, model)
        }
    }

    fun createServiceListing(
        provider: SecurityProvider,
        category: ServiceCategory,
        title: String,
        description: String,
        priceTzs: Long,
        priceUnit: String,
        location: String,
        offerBadge: String?,
        discountPercent: Long,
        onSuccess: () -> Unit = {}
    ) {
        runAction("Service published") {
            repository.createServiceListing(
                provider, category, title, description, priceTzs, priceUnit, location, offerBadge, discountPercent
            ).also { if (it.isSuccess) onSuccess() }
        }
    }

    fun deleteServiceListing(serviceId: String) {
        runAction("Service removed") { repository.deleteServiceListing(serviceId) }
    }

    fun submitOrderRequest(
        customerName: String,
        customerPhone: String,
        provider: SecurityProvider,
        service: SecurityServiceListing?,
        category: ServiceCategory,
        serviceTitle: String,
        location: String,
        requirementDescription: String,
        attachmentPreviews: List<String>,
        onSuccess: () -> Unit = {}
    ) {
        runAction("Security request sent") {
            repository.submitOrderRequest(
                customerName, customerPhone, provider, service, category,
                serviceTitle, location, requirementDescription, attachmentPreviews
            ).map { }.also { if (it.isSuccess) onSuccess() }
        }
    }

    fun markOrderReceived(orderId: String) =
        runAction("Order marked received") { repository.markOrderReceived(orderId) }

    fun submitQuotation(orderId: String, amountTzs: Long, notes: String, onSuccess: () -> Unit = {}) =
        runAction("Quotation sent") { repository.submitQuotation(orderId, amountTzs, notes).also { if (it.isSuccess) onSuccess() } }

    fun acceptQuotation(orderId: String) =
        runAction("Quotation accepted") { repository.acceptQuotation(orderId) }

    fun initiateOrderPayment(order: SecurityOrder, payerName: String, payerPhone: String, onCreated: (PaymentTransaction) -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.initiateOrderAirtelPayment(order, payerName, payerPhone)
            _busy.value = false
            res.onSuccess { tx ->
                _feedbackMessage.value = "Airtel Money payment initiated (${tx.transactionRef})"
                onCreated(tx)
            }.onFailure { err ->
                _feedbackMessage.value = err.localizedMessage ?: "Payment initiation failed"
            }
        }
    }

    fun initiateSubscriptionPayment(provider: SecurityProvider, payerName: String, payerPhone: String, onCreated: (PaymentTransaction) -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            val res = repository.initiateSubscriptionAirtelPayment(provider, payerName, payerPhone)
            _busy.value = false
            res.onSuccess { tx ->
                _feedbackMessage.value = "Subscription payment initiated (${tx.transactionRef})"
                onCreated(tx)
            }.onFailure { err ->
                _feedbackMessage.value = err.localizedMessage ?: "Subscription initiation failed"
            }
        }
    }

    fun verifyPaymentCallback(payment: PaymentTransaction, onSuccess: () -> Unit = {}) =
        runAction("Payment verified & receipt generated") {
            repository.verifyPaymentCallback(payment).also { if (it.isSuccess) onSuccess() }
        }

    fun markServiceDelivered(orderId: String) =
        runAction("Service marked delivered") { repository.markServiceDelivered(orderId) }

    fun confirmCompletionAndClose(order: SecurityOrder) =
        runAction("Order closed & 5% commission calculated") { repository.confirmCompletionAndClose(order) }

    fun cancelOrder(orderId: String, reason: String) =
        runAction("Order cancelled") { repository.cancelOrder(orderId, reason) }

    fun disputeOrder(orderId: String, reason: String) =
        runAction("Dispute submitted to Admin") { repository.disputeOrder(orderId, reason) }

    fun rateOrder(order: SecurityOrder, provider: SecurityProvider?, stars: Int, comment: String) =
        runAction("Rating submitted") { repository.rateClosedOrder(order, provider, stars, comment) }

    fun sendOrderMessage(order: SecurityOrder, senderName: String, text: String) {
        viewModelScope.launch {
            val res = repository.sendOrderMessage(order, senderName, text)
            res.onFailure { _feedbackMessage.value = it.localizedMessage ?: "Failed to send message" }
        }
    }

    fun submitComplaint(customerName: String, subject: String, description: String, orderId: String? = null, providerId: String? = null, onSuccess: () -> Unit = {}) =
        runAction("Complaint submitted") {
            repository.submitComplaint(customerName, subject, description, orderId, providerId).also { if (it.isSuccess) onSuccess() }
        }

    // Admin actions
    fun verifyProviderByAdmin(providerId: String, status: VerificationStatus, verified: Boolean, featured: Boolean) =
        runAction("Provider verification updated") { repository.verifyProviderByAdmin(providerId, status, verified, featured) }

    fun markCommissionCollected(provider: SecurityProvider, amountTzs: Long) =
        runAction("Commission recorded as collected") { repository.markCommissionCollectedByAdmin(provider, amountTzs) }

    fun resolveComplaint(complaintId: String, status: ComplaintStatus, notes: String) =
        runAction("Complaint updated") { repository.resolveComplaintByAdmin(complaintId, status, notes) }

    fun bootstrapStarterCatalog() =
        runAction("Verified Tanzania marketplace catalog created") { repository.bootstrapStarterCatalogByAdmin() }

    private fun runAction(successMessage: String, block: suspend () -> Result<Unit>) {
        viewModelScope.launch {
            _busy.value = true
            val result = block()
            _busy.value = false
            result.onSuccess {
                _feedbackMessage.value = successMessage
            }.onFailure { err ->
                _feedbackMessage.value = err.localizedMessage ?: "Operation failed"
            }
        }
    }

    private companion object {
        const val TAG = "MarketplaceVM"
    }
}
