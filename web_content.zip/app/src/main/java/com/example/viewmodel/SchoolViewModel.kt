package com.example.viewmodel

import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SchoolRepository
import com.example.domain.AcademicCalculator
import com.example.domain.SchoolBackupBundle
import com.example.model.AttendanceRecord
import com.example.model.AttendanceStatus
import com.example.model.ClassAnalytics
import com.example.model.ObservationRule
import com.example.model.SchoolClass
import com.example.model.SchoolConfig
import com.example.model.Student
import com.example.model.Subject
import com.example.model.TeacherAssignment
import com.example.model.UiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class SchoolDashboardData(
    val config: SchoolConfig,
    val classes: List<SchoolClass>,
    val activeClass: SchoolClass?,
    val subjects: List<Subject>,
    val students: List<Student>,
    val allSubjects: List<Subject>,
    val allStudents: List<Student>,
    val selectedStudent: Student?,
    val analytics: ClassAnalytics,
    val attendanceForDate: Map<String, AttendanceRecord>,
    val allAttendance: List<AttendanceRecord>,
    val teacherAssignments: List<TeacherAssignment>,
    val observationRules: List<ObservationRule>,
    val activeDateKey: String,
)

class SchoolViewModel(
    private val repository: SchoolRepository,
    @Suppress("unused") private val currentUserId: String,
) : ViewModel() {

    private val dateFormatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private val _selectedClassId = MutableStateFlow("")
    private val _selectedStudentId = MutableStateFlow("")
    private val _selectedDateKey = MutableStateFlow(dateFormatter.format(Date()))
    private val _brandingRevision = MutableStateFlow(0)
    val brandingRevision: StateFlow<Int> = _brandingRevision.asStateFlow()

    private val _snackbarMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

    init {
        viewModelScope.launch {
            repository.seedDemoDataIfEmpty(_selectedDateKey.value)
        }
    }

    private fun <T> Flow<T>.unwrapFirestoreErrors(label: String): Flow<Result<T>> =
        map { Result.success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing $label", rootError)
                emit(Result.failure(rootError))
            }

    private val baseDataFlow = combine(
        repository.observeConfig().unwrapFirestoreErrors("config"),
        repository.observeClasses().unwrapFirestoreErrors("classes"),
        repository.observeSubjects().unwrapFirestoreErrors("subjects"),
        repository.observeStudents().unwrapFirestoreErrors("students"),
        repository.observeAttendance().unwrapFirestoreErrors("attendance"),
    ) { cfgRes, clsRes, subRes, stuRes, attRes ->
        val firstFailure = listOf(cfgRes, clsRes, subRes, stuRes, attRes).firstOrNull { it.isFailure }
        if (firstFailure != null) {
            Result.failure(firstFailure.exceptionOrNull() ?: IllegalStateException("Sync error"))
        } else {
            Result.success(
                Quint(
                    cfgRes.getOrThrow(),
                    clsRes.getOrThrow(),
                    subRes.getOrThrow(),
                    stuRes.getOrThrow(),
                    attRes.getOrThrow(),
                )
            )
        }
    }

    private val secondaryDataFlow = combine(
        repository.observeTeacherAssignments().unwrapFirestoreErrors("teacher_assignments"),
        repository.observeObservationRules().unwrapFirestoreErrors("observation_rules"),
        _selectedClassId,
        _selectedStudentId,
        _selectedDateKey,
    ) { taRes, rulesRes, selClassId, selStuId, dateKey ->
        val firstFailure = listOf(taRes, rulesRes).firstOrNull { it.isFailure }
        if (firstFailure != null) {
            Result.failure(firstFailure.exceptionOrNull() ?: IllegalStateException("Sync error"))
        } else {
            Result.success(
                Quint(
                    taRes.getOrThrow(),
                    rulesRes.getOrThrow(),
                    selClassId,
                    selStuId,
                    dateKey,
                )
            )
        }
    }

    val uiState: StateFlow<UiState<SchoolDashboardData>> = combine(baseDataFlow, secondaryDataFlow) { baseRes, secRes ->
        val err = baseRes.exceptionOrNull() ?: secRes.exceptionOrNull()
        if (err != null) {
            UiState.Error(err.message ?: "Failed to load school records")
        } else {
            val (config, classes, allSubjects, allStudents, allAttendance) = baseRes.getOrThrow()
            val (teacherAssignments, obsRules, selClassId, selStuId, dateKey) = secRes.getOrThrow()

            val activeClass = classes.firstOrNull { it.id == selClassId } ?: classes.firstOrNull()
            val classSubjects = if (activeClass != null) {
                allSubjects.filter { it.classId == activeClass.id }.sortedBy { it.sortOrder }
            } else emptyList()
            val classStudents = if (activeClass != null) {
                allStudents.filter { it.classId == activeClass.id }.sortedBy { it.name }
            } else emptyList()
            val selectedStudent = classStudents.firstOrNull { it.id == selStuId } ?: classStudents.firstOrNull()

            val analytics = AcademicCalculator.computeClassAnalytics(
                subjects = classSubjects,
                students = classStudents,
                config = config,
            )

            val attendanceForDate = if (activeClass != null) {
                allAttendance
                    .filter { it.classId == activeClass.id && it.dateKey == dateKey }
                    .associateBy { it.studentId }
            } else emptyMap()

            UiState.Success(
                SchoolDashboardData(
                    config = config,
                    classes = classes,
                    activeClass = activeClass,
                    subjects = classSubjects,
                    students = classStudents,
                    allSubjects = allSubjects,
                    allStudents = allStudents,
                    selectedStudent = selectedStudent,
                    analytics = analytics,
                    attendanceForDate = attendanceForDate,
                    allAttendance = allAttendance,
                    teacherAssignments = teacherAssignments,
                    observationRules = obsRules,
                    activeDateKey = dateKey,
                )
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = UiState.Loading,
    )

    fun selectClass(classId: String) {
        _selectedClassId.value = classId
        _selectedStudentId.value = ""
    }

    fun selectStudent(studentId: String) {
        _selectedStudentId.value = studentId
    }

    fun stepStudent(students: List<Student>, delta: Int) {
        if (students.isEmpty()) return
        val currentIdx = students.indexOfFirst { it.id == _selectedStudentId.value }.takeIf { it >= 0 } ?: 0
        val nextIdx = (currentIdx + delta + students.size) % students.size
        _selectedStudentId.value = students[nextIdx].id
    }

    fun selectDate(dateKey: String) {
        _selectedDateKey.value = dateKey
    }

    fun stepDate(days: Int) {
        val cal = Calendar.getInstance()
        try {
            cal.time = dateFormatter.parse(_selectedDateKey.value) ?: Date()
        } catch (_: Exception) {
            cal.time = Date()
        }
        cal.add(Calendar.DAY_OF_MONTH, days)
        _selectedDateKey.value = dateFormatter.format(cal.time)
    }

    fun setTodayDate() {
        _selectedDateKey.value = dateFormatter.format(Date())
    }

    private fun launchMutation(successMsg: String? = null, block: suspend () -> Result<Unit>) {
        viewModelScope.launch {
            val res = block()
            if (res.isSuccess) {
                if (!successMsg.isNullOrBlank()) _snackbarMessages.tryEmit(successMsg)
            } else {
                _snackbarMessages.tryEmit(res.exceptionOrNull()?.localizedMessage ?: "Operation failed")
            }
        }
    }

    fun saveConfig(config: SchoolConfig, toastMsg: String? = null) {
        launchMutation(toastMsg) { repository.saveSchoolConfig(config) }
    }

    fun createClass(name: String, sortOrder: Long, copyFromSubjects: List<Subject>) {
        viewModelScope.launch {
            val res = repository.createClass(name, sortOrder, copyFromSubjects)
            if (res.isSuccess) {
                _selectedClassId.value = res.getOrThrow()
                _selectedStudentId.value = ""
                _snackbarMessages.tryEmit("Created class ${name.trim().uppercase()}")
            } else {
                _snackbarMessages.tryEmit(res.exceptionOrNull()?.localizedMessage ?: "Failed to create class")
            }
        }
    }

    fun renameClass(classId: String, newName: String) {
        launchMutation("Class renamed") { repository.renameClass(classId, newName) }
    }

    fun deleteClass(classId: String, subjectIds: List<String>, studentIds: List<String>) {
        launchMutation("Class deleted") {
            repository.deleteClass(classId, subjectIds, studentIds).also {
                if (it.isSuccess) {
                    _selectedClassId.value = ""
                    _selectedStudentId.value = ""
                }
            }
        }
    }

    fun upsertSubject(subject: Subject) {
        launchMutation("Subject saved") { repository.upsertSubject(subject) }
    }

    fun moveSubject(subjects: List<Subject>, index: Int, delta: Int) {
        val target = index + delta
        if (target !in subjects.indices) return
        val a = subjects[index]
        val b = subjects[target]
        viewModelScope.launch {
            repository.upsertSubject(a.copy(sortOrder = b.sortOrder))
            repository.upsertSubject(b.copy(sortOrder = a.sortOrder))
        }
    }

    fun applySubjectWeightsPreset(subjects: List<Subject>, maxTest: Long, maxExam: Long) {
        launchMutation("Updated subject weights") {
            repository.applySubjectWeightsPreset(subjects, maxTest, maxExam)
        }
    }

    fun deleteSubject(subjectId: String) {
        launchMutation("Subject removed") { repository.deleteSubject(subjectId) }
    }

    fun addStudent(classId: String, name: String, idNo: String, conduct: String) {
        viewModelScope.launch {
            val res = repository.addStudent(
                Student(
                    classId = classId,
                    name = name,
                    studentIdNo = idNo,
                    conduct = conduct,
                )
            )
            if (res.isSuccess) {
                _selectedStudentId.value = res.getOrThrow()
                _snackbarMessages.tryEmit("Added ${name.trim().uppercase()}")
            } else {
                _snackbarMessages.tryEmit(res.exceptionOrNull()?.localizedMessage ?: "Failed to add student")
            }
        }
    }

    fun bulkAddStudents(classId: String, rawText: String) {
        val names = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
        launchMutation("Added ${names.size} students") {
            repository.bulkAddStudents(classId, names)
        }
    }

    fun updateStudent(student: Student, silent: Boolean = true) {
        launchMutation(if (silent) null else "Student updated") {
            repository.updateStudent(student)
        }
    }

    fun deleteStudent(studentId: String) {
        launchMutation("Student deleted") { repository.deleteStudent(studentId) }
    }

    fun clearStudentsInClass(studentIds: List<String>) {
        launchMutation("Cleared students in class") { repository.clearStudentsInClass(studentIds) }
    }

    fun setAttendanceStatus(
        classId: String,
        studentId: String,
        dateKey: String,
        status: AttendanceStatus,
        note: String,
    ) {
        launchMutation(null) {
            repository.setAttendanceStatus(classId, studentId, dateKey, status, note)
        }
    }

    fun markAllPresent(
        classId: String,
        students: List<Student>,
        existingForDate: Map<String, AttendanceRecord>,
        dateKey: String,
    ) {
        launchMutation("Marked all ${students.size} students Present") {
            repository.markAllPresent(classId, students, existingForDate, dateKey)
        }
    }

    fun syncAttendanceToReportCards(
        students: List<Student>,
        classAttendance: List<AttendanceRecord>,
    ) {
        launchMutation("Synced Lates & Absences to report cards") {
            repository.syncAttendanceCountsToStudents(students, classAttendance)
        }
    }

    fun upsertTeacherAssignment(assignment: TeacherAssignment) {
        launchMutation("Teacher assignment saved") {
            repository.upsertTeacherAssignment(assignment)
        }
    }

    fun deleteTeacherAssignment(assignmentId: String) {
        launchMutation("Assignment removed") {
            repository.deleteTeacherAssignment(assignmentId)
        }
    }

    fun upsertObservationRule(rule: ObservationRule) {
        launchMutation("Rule saved") { repository.upsertObservationRule(rule) }
    }

    fun deleteObservationRule(ruleId: String) {
        launchMutation("Rule deleted") { repository.deleteObservationRule(ruleId) }
    }

    fun applyObservationRulesToAll(
        analytics: ClassAnalytics,
        rules: List<ObservationRule>,
    ) {
        val updates = analytics.studentsComputed.map { comp ->
            comp.student.id to AcademicCalculator.resolveAutoObservation(comp.rawPct, rules)
        }
        launchMutation("Updated observations for ${updates.size} students") {
            repository.applyObservationUpdates(updates)
        }
    }

    fun uploadLogoImage(uri: Uri, currentConfig: SchoolConfig) {
        viewModelScope.launch {
            val fileName = "school_logo_${System.currentTimeMillis()}.png"
            val res = repository.savePickedBrandingImage(uri, fileName)
            if (res.isSuccess) {
                repository.saveSchoolConfig(currentConfig.copy(logoFileName = fileName, showLogo = true))
                _brandingRevision.value++
                _snackbarMessages.tryEmit("Custom school logo updated")
            } else {
                _snackbarMessages.tryEmit("Failed to load selected logo")
            }
        }
    }

    fun uploadSignatureImage(uri: Uri, currentConfig: SchoolConfig) {
        viewModelScope.launch {
            val fileName = "teacher_sig_${System.currentTimeMillis()}.png"
            val res = repository.savePickedBrandingImage(uri, fileName)
            if (res.isSuccess) {
                repository.saveSchoolConfig(currentConfig.copy(signatureFileName = fileName))
                _brandingRevision.value++
                _snackbarMessages.tryEmit("Teacher signature image updated")
            } else {
                _snackbarMessages.tryEmit("Failed to load signature image")
            }
        }
    }

    fun loadLogoBitmap(fileName: String) = repository.loadBrandingBitmap(fileName)

    fun loadSignatureBitmap(fileName: String) = repository.loadBrandingBitmap(fileName)

    fun buildBackupJson(data: SchoolDashboardData): String {
        return repository.exportBackupJson(
            SchoolBackupBundle(
                config = data.config,
                classes = data.classes,
                subjects = data.allSubjects,
                students = data.allStudents,
                attendance = data.allAttendance,
                teacherAssignments = data.teacherAssignments,
                observationRules = data.observationRules,
            )
        )
    }

    fun importBackupJson(rawJson: String) {
        launchMutation("School backup imported") {
            repository.importBackupJson(rawJson)
        }
    }

    fun notifyMessage(msg: String) {
        _snackbarMessages.tryEmit(msg)
    }

    private data class Quint<A, B, C, D, E>(
        val first: A,
        val second: B,
        val third: C,
        val fourth: D,
        val fifth: E,
    )

    private companion object {
        const val TAG = "SchoolViewModel"
    }
}
