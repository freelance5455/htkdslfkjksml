package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.HistoryRepository
import com.example.engine.TrafficSimulatorEngine
import com.example.model.HttpMethod
import com.example.model.PacingMode
import com.example.model.SimulationConfig
import com.example.model.SimulationState
import com.example.model.SimulationStats
import com.example.model.TestRunHistory
import com.example.model.VisitResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class TrafficSimulatorViewModel(application: Application) : AndroidViewModel(application) {

    private val historyRepository = HistoryRepository(application.applicationContext)
    val history: StateFlow<List<TestRunHistory>> = historyRepository.history

    private val engine = TrafficSimulatorEngine(application.applicationContext, viewModelScope)
    val stats: StateFlow<SimulationStats> = engine.stats

    private val _config = MutableStateFlow(SimulationConfig())
    val config: StateFlow<SimulationConfig> = _config.asStateFlow()

    fun updateExecutionEngine(engineType: com.example.model.ExecutionEngine) {
        _config.update { it.copy(executionEngine = engineType) }
    }

    private val _visits = MutableStateFlow<List<VisitResult>>(emptyList())
    val visits: StateFlow<List<VisitResult>> = _visits.asStateFlow()

    private val _selectedVisit = MutableStateFlow<VisitResult?>(null)
    val selectedVisit: StateFlow<VisitResult?> = _selectedVisit.asStateFlow()

    private val _activeTab = MutableStateFlow(0)
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    private val _logFilter = MutableStateFlow("ALL") // ALL, SUCCESS, REDIRECT, ERROR
    val logFilter: StateFlow<String> = _logFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredVisits: StateFlow<List<VisitResult>> = combine(
        _visits,
        _logFilter,
        _searchQuery
    ) { allVisits, filter, query ->
        allVisits.filter { visit ->
            val matchesFilter = when (filter) {
                "SUCCESS" -> visit.statusCode in 200..299
                "REDIRECT" -> visit.statusCode in 300..399
                "ERROR" -> visit.statusCode >= 400 || visit.statusCode == 0 || visit.errorMessage != null
                else -> true
            }
            val matchesQuery = if (query.isBlank()) true else {
                visit.url.contains(query, ignoreCase = true) ||
                visit.sessionProfile.browserName.contains(query, ignoreCase = true) ||
                visit.sessionProfile.simulatedIp.contains(query, ignoreCase = true) ||
                visit.statusCode.toString().contains(query) ||
                (visit.sessionProfile.referer?.contains(query, ignoreCase = true) == true)
            }
            matchesFilter && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            historyRepository.loadHistory()
        }
        viewModelScope.launch {
            engine.visitEventFlow.collect { newVisit ->
                _visits.update { listOf(newVisit) + it }
            }
        }
    }

    fun updateUrl(url: String) {
        _config.update { it.copy(url = url) }
    }

    fun updateTotalVisits(count: Int) {
        _config.update { it.copy(totalVisits = count.coerceIn(1, 10000)) }
    }

    fun updateHttpMethod(method: HttpMethod) {
        _config.update { it.copy(httpMethod = method) }
    }

    fun updatePacing(mode: PacingMode) {
        _config.update { it.copy(pacingMode = mode) }
    }

    fun updateConcurrency(concurrency: Int) {
        _config.update { it.copy(concurrency = concurrency.coerceIn(1, 20)) }
    }

    fun toggleRotateAgents(value: Boolean) {
        _config.update { it.copy(rotateUserAgents = value) }
    }

    fun toggleRotateIps(value: Boolean) {
        _config.update { it.copy(rotateSimulatedIps = value) }
    }

    fun toggleRotateReferrers(value: Boolean) {
        _config.update { it.copy(rotateReferrers = value) }
    }

    fun toggleIsolatedCookies(value: Boolean) {
        _config.update { it.copy(isolatedCookies = value) }
    }

    fun updateCustomPayload(payload: String) {
        _config.update { it.copy(customPayload = payload) }
    }

    fun updateCustomHeaders(headers: String) {
        _config.update { it.copy(customHeadersString = headers) }
    }

    fun setActiveTab(tab: Int) {
        _activeTab.value = tab
    }

    fun setLogFilter(filter: String) {
        _logFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectVisit(visit: VisitResult?) {
        _selectedVisit.value = visit
    }

    fun testSinglePing() {
        viewModelScope.launch {
            val result = engine.executeSingleVisit(1, _config.value)
            _visits.update { listOf(result) + it }
            _selectedVisit.value = result
        }
    }

    fun startSimulation() {
        _visits.value = emptyList()
        val currentConfig = _config.value
        engine.startSimulation(currentConfig) { finalStats ->
            // Save run in history
            val runHistory = TestRunHistory(
                id = UUID.randomUUID().toString(),
                timestamp = System.currentTimeMillis(),
                url = currentConfig.url,
                method = currentConfig.httpMethod.name,
                totalVisits = finalStats.totalScheduled,
                successCount = finalStats.successCount,
                failureCount = finalStats.clientErrorCount + finalStats.serverErrorCount + finalStats.networkErrorCount,
                avgLatencyMs = finalStats.avgLatencyMs,
                totalBytes = finalStats.totalBytesReceived,
                completedDurationMs = finalStats.elapsedMs
            )
            viewModelScope.launch {
                historyRepository.saveRun(runHistory)
            }
        }
    }

    fun pauseSimulation() {
        engine.pauseSimulation()
    }

    fun resumeSimulation() {
        engine.resumeSimulation()
    }

    fun stopSimulation() {
        engine.stopSimulation()
    }

    fun resetSimulation() {
        engine.resetStats()
        _visits.value = emptyList()
    }

    fun loadPreset(url: String, visits: Int, concurrency: Int = 1, pacing: PacingMode = PacingMode.STEP_BY_STEP) {
        _config.update {
            it.copy(
                url = url,
                totalVisits = visits,
                concurrency = concurrency,
                pacingMode = pacing
            )
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            historyRepository.clearHistory()
        }
    }

    fun generateMarkdownReport(): String {
        val s = stats.value
        val c = config.value
        val uniqueAgents = _visits.value.map { it.sessionProfile.browserName }.distinct().size
        val uniqueIps = _visits.value.map { it.sessionProfile.simulatedIp }.distinct().size
        val cookieCount = _visits.value.sumOf { it.cookiesReceived.size }

        return buildString {
            appendLine("# TrafficPulse Simulation Report")
            appendLine("- **Target URL:** ${c.url}")
            appendLine("- **HTTP Method:** ${c.httpMethod}")
            appendLine("- **Status:** ${s.state}")
            appendLine("- **Completed Visits:** ${s.completedCount} / ${s.totalScheduled}")
            appendLine("- **Success (2xx):** ${s.successCount}")
            appendLine("- **Redirects (3xx):** ${s.redirectCount}")
            appendLine("- **Client Errors (4xx):** ${s.clientErrorCount}")
            appendLine("- **Server Errors (5xx):** ${s.serverErrorCount}")
            appendLine("- **Network Failures:** ${s.networkErrorCount}")
            appendLine("- **Avg Latency:** ${s.avgLatencyMs} ms (Min: ${s.minLatencyMs}ms, Max: ${s.maxLatencyMs}ms)")
            appendLine("- **Total Data Received:** ${s.totalBytesReceived / 1024} KB")
            appendLine("- **Unique Device Fingerprints:** $uniqueAgents")
            appendLine("- **Unique Simulated IPs:** $uniqueIps")
            appendLine("- **Unique Set-Cookie Headers Received:** $cookieCount")
            appendLine("- **Concurrency:** ${c.concurrency} worker(s)")
            appendLine("- **Pacing:** ${c.pacingMode.label}")
        }
    }
}
