package com.example.viewmodel

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.engine.RealtimeAudioEngine
import com.example.audio.player.StudioAudioPlayer
import com.example.model.AudioEffectsConfig
import com.example.model.AudioPreset
import com.example.model.BitDepth
import com.example.model.DelayRangeMode
import com.example.model.RecordingItem
import com.example.model.RecordingState
import com.example.model.ReverbType
import com.example.repository.PresetsRepository
import com.example.repository.RecordingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

enum class StudioScreen {
    DASHBOARD,
    RECORDINGS,
    PRESETS
}

class StudioViewModel(application: Application) : AndroidViewModel(application) {

    val audioEngine = RealtimeAudioEngine(application)
    val audioPlayer = StudioAudioPlayer(application)
    private val presetsRepository = PresetsRepository(application)
    private val recordingsRepository = RecordingsRepository(application)

    private val _activeScreen = MutableStateFlow(StudioScreen.DASHBOARD)
    val activeScreen: StateFlow<StudioScreen> = _activeScreen.asStateFlow()

    private val _effectsConfig = MutableStateFlow(AudioEffectsConfig())
    val effectsConfig: StateFlow<AudioEffectsConfig> = _effectsConfig.asStateFlow()

    private val _presets = MutableStateFlow<List<AudioPreset>>(emptyList())
    val presets: StateFlow<List<AudioPreset>> = _presets.asStateFlow()

    private val _selectedPresetId = MutableStateFlow<String?>(null)
    val selectedPresetId: StateFlow<String?> = _selectedPresetId.asStateFlow()

    private val _recordings = MutableStateFlow<List<RecordingItem>>(emptyList())
    val recordings: StateFlow<List<RecordingItem>> = _recordings.asStateFlow()

    private val _delayRangeMode = MutableStateFlow(DelayRangeMode.LONG)
    val delayRangeMode: StateFlow<DelayRangeMode> = _delayRangeMode.asStateFlow()

    // Waveform peak cache for recordings list: recordingId -> list of floats
    private val _recordingWaveforms = MutableStateFlow<Map<String, List<Float>>>(emptyMap())
    val recordingWaveforms: StateFlow<Map<String, List<Float>>> = _recordingWaveforms.asStateFlow()

    // Live audio levels from engine
    val liveRmsLevel: StateFlow<Float> = audioEngine.liveRmsLevel
    val livePeakLevel: StateFlow<Float> = audioEngine.livePeakLevel
    val liveWaveform: StateFlow<FloatArray> = audioEngine.liveWaveform
    val recordingState: StateFlow<RecordingState> = audioEngine.recordingState
    val recordingDurationMs: StateFlow<Long> = audioEngine.recordingDurationMs

    // Player state
    val isPlaying: StateFlow<Boolean> = audioPlayer.isPlaying
    val playerCurrentPositionMs: StateFlow<Int> = audioPlayer.currentPositionMs
    val playerDurationMs: StateFlow<Int> = audioPlayer.durationMs
    val currentPlayingId: StateFlow<String?> = audioPlayer.currentPlayingId

    // Dialog & alert state
    private val _showHeadphoneWarning = MutableStateFlow(false)
    val showHeadphoneWarning: StateFlow<Boolean> = _showHeadphoneWarning.asStateFlow()

    private val _hasMicPermission = MutableStateFlow(false)
    val hasMicPermission: StateFlow<Boolean> = _hasMicPermission.asStateFlow()

    private val _lastSavedRecording = MutableStateFlow<RecordingItem?>(null)
    val lastSavedRecording: StateFlow<RecordingItem?> = _lastSavedRecording.asStateFlow()

    init {
        loadPresets()
        loadRecordings()
        // Apply default classic Naat preset
        presetsRepository.builtInPresets.firstOrNull()?.let {
            applyPreset(it)
        }
    }

    fun setMicPermissionGranted(granted: Boolean) {
        _hasMicPermission.value = granted
        if (granted) {
            audioEngine.startEngine()
        }
    }

    fun navigateTo(screen: StudioScreen) {
        _activeScreen.value = screen
        if (screen == StudioScreen.RECORDINGS) {
            loadRecordings()
        }
    }

    fun loadPresets() {
        val list = presetsRepository.getAllPresets()
        _presets.value = list
    }

    fun applyPreset(preset: AudioPreset) {
        _selectedPresetId.value = preset.id
        _effectsConfig.value = preset.config
        audioEngine.updateConfig(preset.config)

        // Sync delay range mode
        val ms = preset.config.delayTimeMs
        _delayRangeMode.value = when {
            ms <= 100 -> DelayRangeMode.SHORT
            ms <= 350 -> DelayRangeMode.MEDIUM
            else -> DelayRangeMode.LONG
        }
    }

    fun saveCustomPreset(name: String, subtitle: String) {
        val saved = presetsRepository.saveCustomPreset(name, subtitle, _effectsConfig.value)
        loadPresets()
        _selectedPresetId.value = saved.id
    }

    fun deleteCustomPreset(id: String) {
        presetsRepository.deleteCustomPreset(id)
        loadPresets()
        if (_selectedPresetId.value == id) {
            _selectedPresetId.value = null
        }
    }

    private fun updateConfigInternal(transform: (AudioEffectsConfig) -> AudioEffectsConfig) {
        val updated = transform(_effectsConfig.value)
        _effectsConfig.value = updated
        audioEngine.updateConfig(updated)
        // If modified, user has customized beyond standard preset
        _selectedPresetId.value = null
    }

    fun setEchoLevel(level: Float) {
        updateConfigInternal { it.copy(echoLevel = level.coerceIn(0f, 1f)) }
    }

    fun setDelayTimeMs(delayMs: Int) {
        updateConfigInternal { it.copy(delayTimeMs = delayMs.coerceIn(20, 1000)) }
    }

    fun setDelayRangeMode(mode: DelayRangeMode) {
        _delayRangeMode.value = mode
        if (mode != DelayRangeMode.FREE) {
            val clamped = _effectsConfig.value.delayTimeMs.coerceIn(mode.minMs, mode.maxMs)
            setDelayTimeMs(clamped)
        }
    }

    fun setFeedback(feedback: Float) {
        updateConfigInternal { it.copy(feedback = feedback.coerceIn(0f, 0.90f)) }
    }

    fun setToneDamp(tone: Float) {
        updateConfigInternal { it.copy(toneDamp = tone.coerceIn(0f, 1f)) }
    }

    fun setReverbType(type: ReverbType) {
        updateConfigInternal { it.copy(reverbType = type) }
    }

    fun setReverbLevel(level: Float) {
        updateConfigInternal { it.copy(reverbLevel = level.coerceIn(0f, 1f)) }
    }

    fun setReverbDecay(decay: Float) {
        updateConfigInternal { it.copy(reverbDecay = decay.coerceIn(0.1f, 0.95f)) }
    }

    fun setDryLevel(level: Float) {
        updateConfigInternal { it.copy(dryLevel = level.coerceIn(0f, 1f)) }
    }

    fun setWetLevel(level: Float) {
        updateConfigInternal { it.copy(wetLevel = level.coerceIn(0f, 1f)) }
    }

    fun setMasterGain(gain: Float) {
        updateConfigInternal { it.copy(masterGain = gain.coerceIn(0.5f, 1.5f)) }
    }

    fun setBitDepth(bitDepth: BitDepth) {
        updateConfigInternal { it.copy(bitDepth = bitDepth) }
    }

    fun toggleLiveMonitor(enable: Boolean) {
        if (enable) {
            val hasHeadset = audioEngine.isHeadsetConnected()
            if (!hasHeadset) {
                // Show recommendation dialog before enabling
                _showHeadphoneWarning.value = true
                return
            }
        }
        updateConfigInternal { it.copy(isMonitorEnabled = enable) }
    }

    fun confirmMonitorWithoutHeadset() {
        _showHeadphoneWarning.value = false
        updateConfigInternal { it.copy(isMonitorEnabled = true) }
    }

    fun dismissHeadphoneWarning() {
        _showHeadphoneWarning.value = false
    }

    // Recording operations
    fun startRecording() {
        if (!_hasMicPermission.value) return
        viewModelScope.launch {
            val file = recordingsRepository.createNewRecordingFile(_effectsConfig.value.bitDepth)
            val success = audioEngine.startRecording(file, _effectsConfig.value.bitDepth)
            if (!success) {
                // handle error
            }
        }
    }

    fun pauseRecording() {
        audioEngine.pauseRecording()
    }

    fun resumeRecording() {
        audioEngine.resumeRecording()
    }

    fun stopRecording() {
        viewModelScope.launch {
            audioEngine.stopRecording()
            loadRecordings()
            // Set last saved recording
            _recordings.value.firstOrNull()?.let {
                _lastSavedRecording.value = it
            }
        }
    }

    fun dismissLastSavedRecording() {
        _lastSavedRecording.value = null
    }

    // Recordings Library Management
    fun loadRecordings() {
        viewModelScope.launch {
            val list = recordingsRepository.loadAllRecordings()
            _recordings.value = list

            // Pre-extract waveform peaks for new recordings
            list.forEach { item ->
                if (!_recordingWaveforms.value.containsKey(item.id)) {
                    val peaks = StudioAudioPlayer.extractWaveformPeaks(File(item.filePath))
                    _recordingWaveforms.value = _recordingWaveforms.value + (item.id to peaks)
                }
            }
        }
    }

    fun playRecording(item: RecordingItem) {
        val file = File(item.filePath)
        audioPlayer.play(item.id, file)
    }

    fun pausePlayback() {
        audioPlayer.pause()
    }

    fun resumePlayback() {
        audioPlayer.resume()
    }

    fun seekPlayback(positionMs: Int) {
        audioPlayer.seekTo(positionMs)
    }

    fun stopPlayback() {
        audioPlayer.stop()
    }

    fun renameRecording(item: RecordingItem, newName: String) {
        viewModelScope.launch {
            recordingsRepository.renameRecording(item, newName)
            loadRecordings()
        }
    }

    fun deleteRecording(item: RecordingItem) {
        viewModelScope.launch {
            if (currentPlayingId.value == item.id) {
                audioPlayer.stop()
            }
            recordingsRepository.deleteRecording(item)
            loadRecordings()
        }
    }

    fun createShareIntent(item: RecordingItem): Intent {
        return recordingsRepository.createShareIntent(item)
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.stopEngine()
        audioPlayer.stop()
    }
}
