package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundHelper
import com.example.model.CarModel
import com.example.model.OperatingMode
import com.example.model.PedestrianModel
import com.example.model.PedestrianState
import com.example.model.QuizQuestion
import com.example.model.SequenceStyle
import com.example.model.SignalPhase
import com.example.model.TrafficConfig
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

data class TrafficUiState(
    val currentPhase: SignalPhase = SignalPhase.RED,
    val secondsRemaining: Int = 10,
    val totalSeconds: Int = 10,
    val operatingMode: OperatingMode = OperatingMode.AUTOMATIC,
    val isPaused: Boolean = false,
    val pedestrianState: PedestrianState = PedestrianState.WALK,
    val isPedestrianRequested: Boolean = false,
    val pedestrianSecondsRemaining: Int = 8,
    val isNightFlashOn: Boolean = true,
    val config: TrafficConfig = TrafficConfig(),
    val cars: List<CarModel> = emptyList(),
    val pedestrians: List<PedestrianModel> = emptyList(),
    val selectedTab: Int = 0,
    // Quiz state
    val currentQuizIndex: Int = 0,
    val selectedQuizAnswer: Int? = null,
    val quizScore: Int = 0,
    val isQuizFinished: Boolean = false
)

class TrafficLightViewModel(application: Application) : AndroidViewModel(application) {

    private val soundHelper = SoundHelper(application)

    private val _uiState = MutableStateFlow(
        TrafficUiState(
            currentPhase = SignalPhase.RED,
            secondsRemaining = 10,
            totalSeconds = 10,
            pedestrianState = PedestrianState.WALK,
            pedestrianSecondsRemaining = 8,
            cars = initializeCars(),
            pedestrians = initializePedestrians()
        )
    )
    val uiState: StateFlow<TrafficUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null
    private var simulationJob: Job? = null
    private var nightFlashJob: Job? = null

    val quizQuestions = listOf(
        QuizQuestion(
            id = 1,
            question = "ما هو التصرف الصحيح عند رؤية الضوء الأصفر الثابت؟",
            options = listOf(
                "زيادة السرعة لتجاوز الإشارة بسرعة",
                "التهدئة والتوقف إذا كان ذلك ممكناً بأمان دون التسبب بحادث",
                "التوقف المفاجئ في منتصف التقاطع",
                "استخدام بوق السيارة والاستمرار بالقيادة"
            ),
            correctIndex = 1,
            explanation = "الضوء الأصفر يعني الاستعداد للتوقف، ويجب التوقف بأمان قبل خط الوقوف إلا إذا كان التوقف المفاجئ سيشكل خطراً."
        ),
        QuizQuestion(
            id = 2,
            question = "ماذا يعني الوميض الأصفر المتقطع في الإشارة الضوئية؟",
            options = listOf(
                "الإشارة معطلة بالكامل ولا يجب الالتفات لها",
                "هدئ السرعة وتوخ الحذر مع إعطاء الأولوية لمن في التقاطع",
                "توقف تماماً وانتظر حتى يضيء الأخضر",
                "الطريق مغلق أمام جميع المركبات"
            ),
            correctIndex = 1,
            explanation = "الوميض الأصفر المتقطع يعمل عادة أثناء الليل أو في تقاطعات معينة، ويعني التهدئة والحذر الشديد مع إعطاء الأولوية."
        ),
        QuizQuestion(
            id = 3,
            question = "عند الضغط على زر طلب عبور المشاة، متى يمكنك العبور؟",
            options = listOf(
                "مباشرة بعد الضغط على الزر",
                "عندما تصبح إشارة المشاة خضراء ويقف مسار السيارات تماماً",
                "في أي وقت طالما أن الشارع فارغ",
                "عندما تضيء إشارة السيارات باللون الأصفر"
            ),
            correctIndex = 1,
            explanation = "زر العبور يرسل إشارة للنظام لتغيير الضوء، ولا يجوز العبور إلا بعد إضاءة إشارة المشاة الخضراء وتأكد وقوف المركبات."
        ),
        QuizQuestion(
            id = 4,
            question = "ما هو التصرف الإلزامي عند اقتراب سيارة إسعاف أو طوارئ مشغلة أضواءها وصفارتها؟",
            options = listOf(
                "الاستمرار في السير بنفس السرعة",
                "إفساح الطريق بأمان والانتقال لليمين أو التوقف للسماح بمرورها",
                "ملاحقة سيارة الإسعاف لتجاوز الزحام",
                "قطع الإشارة الحمراء بسرعة عالية بدون انتباه"
            ),
            correctIndex = 1,
            explanation = "تمنح مركبات الطوارئ أولوية المرور المطلقة، ويجب إفساح المسار لها بأمان وبشكل فوري."
        ),
        QuizQuestion(
            id = 5,
            question = "ما دلالة الضوء الأحمر الومّاض في الإشارات الضوئية؟",
            options = listOf(
                "يُعامل معاملة إشارة 'قف' (Stop)، توقف تام ثم انطلق بأمان",
                "انطلق بسرعة قبل أن يتغير",
                "الطريق مخصص للمشاة فقط",
                "تجاهل الإشارة واكمل طريقك"
            ),
            correctIndex = 0,
            explanation = "الضوء الأحمر الوماض يتطلب توقفاً تاماً للمركبة عند خط الوقوف، ثم التقدم بحذر فقط عندما يخلو الطريق تماماً."
        ),
        QuizQuestion(
            id = 6,
            question = "ما هي المسافة الآمنة المفترضة خلف المركبة التي أمامك؟",
            options = listOf(
                "نصف متر لتوفير مساحة في الطريق",
                "قاعدة ثانيتين إلى 3 ثوانٍ على الأقل في الظروف العادية",
                "لا حاجة لمسافة أمان مع وجود الفرامل الحديثة",
                "10 سنتيمترات فقط"
            ),
            correctIndex = 1,
            explanation = "قاعدة ثانيتين إلى 3 ثوانٍ تضمن مسافة كافية للتوقف المفاجئ وتفادي الاصطدام الخلفي."
        )
    )

    init {
        startTimerLoop()
        startSimulationLoop()
    }

    private fun startTimerLoop() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                if (_uiState.value.isPaused || _uiState.value.operatingMode != OperatingMode.AUTOMATIC) {
                    continue
                }

                val current = _uiState.value
                val newSeconds = current.secondsRemaining - 1

                if (newSeconds <= 0) {
                    // Switch to next phase in sequence
                    advancePhaseAutomatically()
                } else {
                    // Update countdown and pedestrian states
                    updatePedestrianStateForRemaining(current.currentPhase, newSeconds)
                    _uiState.update { it.copy(secondsRemaining = newSeconds) }

                    // Sound cues
                    if (current.currentPhase == SignalPhase.RED && current.pedestrianState == PedestrianState.WALK) {
                        soundHelper.playPedestrianWalkBeep(current.config.soundEnabled)
                    }
                }
            }
        }
    }

    private fun advancePhaseAutomatically() {
        val current = _uiState.value
        val config = current.config

        when (current.currentPhase) {
            SignalPhase.RED -> {
                if (config.sequenceStyle == SequenceStyle.EUROPEAN) {
                    switchToPhase(SignalPhase.RED_YELLOW, 2)
                } else {
                    switchToPhase(SignalPhase.GREEN, config.greenDuration)
                }
            }
            SignalPhase.RED_YELLOW -> {
                switchToPhase(SignalPhase.GREEN, config.greenDuration)
            }
            SignalPhase.GREEN -> {
                switchToPhase(SignalPhase.YELLOW, config.yellowDuration)
            }
            SignalPhase.YELLOW -> {
                val nextRedDuration = if (current.isPedestrianRequested) {
                    maxOf(config.redDuration, config.pedestrianWalkDuration)
                } else {
                    config.redDuration
                }
                switchToPhase(SignalPhase.RED, nextRedDuration)
                if (current.isPedestrianRequested) {
                    _uiState.update { it.copy(isPedestrianRequested = false) }
                }
            }
            SignalPhase.FLASHING_YELLOW, SignalPhase.FLASHING_RED, SignalPhase.OFF -> {
                switchToPhase(SignalPhase.RED, config.redDuration)
            }
        }
    }

    private fun switchToPhase(phase: SignalPhase, durationSeconds: Int) {
        soundHelper.playSignalChangeBeep(_uiState.value.config.soundEnabled)
        soundHelper.vibrate(50, _uiState.value.config.vibrationEnabled)

        val pedState = when (phase) {
            SignalPhase.RED -> PedestrianState.WALK
            SignalPhase.RED_YELLOW, SignalPhase.YELLOW, SignalPhase.GREEN -> PedestrianState.DONT_WALK
            else -> PedestrianState.DONT_WALK
        }
        val pedSeconds = if (phase == SignalPhase.RED) durationSeconds else 0

        _uiState.update {
            it.copy(
                currentPhase = phase,
                secondsRemaining = durationSeconds,
                totalSeconds = durationSeconds,
                pedestrianState = pedState,
                pedestrianSecondsRemaining = pedSeconds
            )
        }
    }

    private fun updatePedestrianStateForRemaining(phase: SignalPhase, remaining: Int) {
        if (phase == SignalPhase.RED) {
            val pedState = if (remaining <= 3) {
                PedestrianState.FLASHING_DONT_WALK
            } else {
                PedestrianState.WALK
            }
            _uiState.update {
                it.copy(
                    pedestrianState = pedState,
                    pedestrianSecondsRemaining = remaining
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    pedestrianState = PedestrianState.DONT_WALK,
                    pedestrianSecondsRemaining = 0
                )
            }
        }
    }

    fun setOperatingMode(mode: OperatingMode) {
        soundHelper.playButtonClickSound(_uiState.value.config.soundEnabled)
        soundHelper.vibrate(30, _uiState.value.config.vibrationEnabled)

        _uiState.update { it.copy(operatingMode = mode) }

        if (mode == OperatingMode.NIGHT_FLASH) {
            startNightFlashLoop()
        } else {
            nightFlashJob?.cancel()
            nightFlashJob = null
            if (mode == OperatingMode.AUTOMATIC) {
                val dur = _uiState.value.config.redDuration
                switchToPhase(SignalPhase.RED, dur)
            }
        }
    }

    private fun startNightFlashLoop() {
        nightFlashJob?.cancel()
        nightFlashJob = viewModelScope.launch {
            while (isActive) {
                _uiState.update { it.copy(isNightFlashOn = !it.isNightFlashOn) }
                delay(700)
            }
        }
    }

    fun togglePause() {
        soundHelper.playButtonClickSound(_uiState.value.config.soundEnabled)
        soundHelper.vibrate(30, _uiState.value.config.vibrationEnabled)
        _uiState.update { it.copy(isPaused = !it.isPaused) }
    }

    fun manualSelectPhase(phase: SignalPhase) {
        soundHelper.playButtonClickSound(_uiState.value.config.soundEnabled)
        soundHelper.vibrate(40, _uiState.value.config.vibrationEnabled)

        _uiState.update { it.copy(operatingMode = OperatingMode.MANUAL) }
        val duration = when (phase) {
            SignalPhase.RED -> _uiState.value.config.redDuration
            SignalPhase.YELLOW -> _uiState.value.config.yellowDuration
            SignalPhase.GREEN -> _uiState.value.config.greenDuration
            else -> 10
        }
        switchToPhase(phase, duration)
    }

    fun nextPhaseManual() {
        soundHelper.playButtonClickSound(_uiState.value.config.soundEnabled)
        soundHelper.vibrate(40, _uiState.value.config.vibrationEnabled)
        advancePhaseAutomatically()
    }

    fun requestPedestrianCrossing() {
        soundHelper.playButtonClickSound(_uiState.value.config.soundEnabled)
        soundHelper.vibrate(60, _uiState.value.config.vibrationEnabled)

        val current = _uiState.value
        if (current.currentPhase == SignalPhase.RED) {
            // Already red, reinforce walk
            soundHelper.playPedestrianWaitBeep(current.config.soundEnabled)
            return
        }

        _uiState.update { it.copy(isPedestrianRequested = true) }

        // If in GREEN phase, accelerate transition to Yellow then Red
        if (current.currentPhase == SignalPhase.GREEN && current.secondsRemaining > 3) {
            _uiState.update { it.copy(secondsRemaining = 3) }
        }
    }

    fun updateConfig(newConfig: TrafficConfig) {
        _uiState.update { it.copy(config = newConfig) }
    }

    fun setSelectedTab(tabIndex: Int) {
        soundHelper.playButtonClickSound(_uiState.value.config.soundEnabled)
        _uiState.update { it.copy(selectedTab = tabIndex) }
    }

    // Quiz logic
    fun selectQuizOption(index: Int) {
        val current = _uiState.value
        if (current.selectedQuizAnswer != null) return // already answered this question

        val question = quizQuestions[current.currentQuizIndex]
        val isCorrect = index == question.correctIndex
        val newScore = if (isCorrect) current.quizScore + 1 else current.quizScore

        soundHelper.playButtonClickSound(current.config.soundEnabled)
        soundHelper.vibrate(if (isCorrect) 60 else 120, current.config.vibrationEnabled)

        _uiState.update {
            it.copy(
                selectedQuizAnswer = index,
                quizScore = newScore
            )
        }
    }

    fun nextQuizQuestion() {
        soundHelper.playButtonClickSound(_uiState.value.config.soundEnabled)
        val current = _uiState.value
        if (current.currentQuizIndex + 1 < quizQuestions.size) {
            _uiState.update {
                it.copy(
                    currentQuizIndex = it.currentQuizIndex + 1,
                    selectedQuizAnswer = null
                )
            }
        } else {
            _uiState.update { it.copy(isQuizFinished = true) }
        }
    }

    fun resetQuiz() {
        soundHelper.playButtonClickSound(_uiState.value.config.soundEnabled)
        _uiState.update {
            it.copy(
                currentQuizIndex = 0,
                selectedQuizAnswer = null,
                quizScore = 0,
                isQuizFinished = false
            )
        }
    }

    // Street Simulation Logic
    private fun initializeCars(): List<CarModel> {
        return listOf(
            CarModel(id = 1L, positionX = 0.1f, speed = 0.008f, colorHex = 0xFFE53935, typeName = "sedan"),
            CarModel(id = 2L, positionX = 0.35f, speed = 0.007f, colorHex = 0xFF1E88E5, typeName = "suv"),
            CarModel(id = 3L, positionX = 0.75f, speed = 0.009f, colorHex = 0xFFFFB300, typeName = "taxi")
        )
    }

    private fun initializePedestrians(): List<PedestrianModel> {
        return listOf(
            PedestrianModel(id = 1L, positionY = 0.1f, speed = 0.012f, isWalking = false, clothesColorHex = 0xFF43A047),
            PedestrianModel(id = 2L, positionY = 0.85f, speed = 0.010f, isWalking = false, clothesColorHex = 0xFF8E24AA)
        )
    }

    fun spawnNewCar() {
        val colors = listOf(0xFFE53935, 0xFF1E88E5, 0xFFFFB300, 0xFF43A047, 0xFF8E24AA, 0xFF00ACC1)
        val types = listOf("sedan", "suv", "taxi", "bus")
        val newCar = CarModel(
            id = System.currentTimeMillis(),
            positionX = 0.02f,
            speed = 0.006f + Random.nextFloat() * 0.004f,
            colorHex = colors.random(),
            typeName = types.random()
        )
        _uiState.update { it.copy(cars = it.cars + newCar) }
    }

    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            val stopLineX = 0.52f // Normalized position of crosswalk & stop line
            while (isActive) {
                delay(33) // ~30 FPS simulation loop

                val current = _uiState.value
                val phase = current.currentPhase
                val isRedOrYellow = phase == SignalPhase.RED || phase == SignalPhase.YELLOW || phase == SignalPhase.RED_YELLOW
                val isPedestrianCrossing = current.pedestrianState == PedestrianState.WALK || current.pedestrianState == PedestrianState.FLASHING_DONT_WALK

                // Update Cars
                val updatedCars = current.cars.mapIndexed { index, car ->
                    var isBraking = false
                    var isStopped = false
                    var newPosX = car.positionX

                    // Check if car should stop for red/yellow light before the stop line
                    val isApproachingStopLine = car.positionX in (stopLineX - 0.22f)..stopLineX

                    // Check if there is another car closely ahead
                    val carAhead = current.cars.getOrNull(index - 1)
                    val isBlockedByAheadCar = carAhead != null &&
                            carAhead.positionX > car.positionX &&
                            (carAhead.positionX - car.positionX) < 0.14f

                    if ((isRedOrYellow && isApproachingStopLine) || isBlockedByAheadCar) {
                        isBraking = true
                        if (car.positionX >= stopLineX - 0.08f || (isBlockedByAheadCar && carAhead?.isStopped == true)) {
                            isStopped = true
                        } else {
                            newPosX += car.speed * 0.3f
                        }
                    } else {
                        newPosX += car.speed
                    }

                    // Recycle car if it left the screen
                    if (newPosX > 1.15f) {
                        newPosX = -0.1f
                    }

                    car.copy(
                        positionX = newPosX,
                        isBraking = isBraking,
                        isStopped = isStopped
                    )
                }

                // Update Pedestrians
                val updatedPedestrians = current.pedestrians.map { ped ->
                    if (isPedestrianCrossing) {
                        var newY = ped.positionY + ped.speed
                        if (newY > 0.95f) {
                            newY = 0.05f
                        }
                        ped.copy(positionY = newY, isWalking = true)
                    } else {
                        ped.copy(isWalking = false)
                    }
                }

                _uiState.update {
                    it.copy(cars = updatedCars, pedestrians = updatedPedestrians)
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundHelper.release()
        timerJob?.cancel()
        simulationJob?.cancel()
        nightFlashJob?.cancel()
    }
}
