package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiApiClient
import com.example.data.models.ChatLanguage
import com.example.data.models.ChatMessage
import com.example.data.models.ChatSession
import com.example.data.models.MediaItem
import com.example.data.models.MediaType
import com.example.data.models.MessageSender
import com.example.data.models.ScreenDestination
import com.example.data.models.UserAccount
import com.example.data.models.VoiceProfile
import com.example.data.storage.AccountDataStorage
import com.example.data.tts.VoiceSynthesisEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class HazimAiViewModel(application: Application) : AndroidViewModel(application) {

    val ttsEngine = VoiceSynthesisEngine(application)
    val accountStorage = AccountDataStorage(application)

    // Navigation
    private val _currentScreen = MutableStateFlow(ScreenDestination.CHAT)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    // Auth & User Account
    private val _userAccount = MutableStateFlow(accountStorage.getActiveUser())
    val userAccount: StateFlow<UserAccount> = _userAccount.asStateFlow()

    private val _isAuthDialogOpen = MutableStateFlow(false)
    val isAuthDialogOpen: StateFlow<Boolean> = _isAuthDialogOpen.asStateFlow()

    // Chat State
    private val _chatLanguage = MutableStateFlow(ChatLanguage.HINGLISH)
    val chatLanguage: StateFlow<ChatLanguage> = _chatLanguage.asStateFlow()

    private val _chatSessions = MutableStateFlow<List<ChatSession>>(emptyList())
    val chatSessions: StateFlow<List<ChatSession>> = _chatSessions.asStateFlow()

    private val _currentSessionId = MutableStateFlow<String>("")
    val currentSessionId: StateFlow<String> = _currentSessionId.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    private val _chatInputText = MutableStateFlow("")
    val chatInputText: StateFlow<String> = _chatInputText.asStateFlow()

    // Text to Image (TTI)
    private val _imagePrompt = MutableStateFlow("")
    val imagePrompt: StateFlow<String> = _imagePrompt.asStateFlow()

    private val _selectedStyle = MutableStateFlow("Photorealistic")
    val selectedStyle: StateFlow<String> = _selectedStyle.asStateFlow()

    private val _selectedAspectRatio = MutableStateFlow("1:1")
    val selectedAspectRatio: StateFlow<String> = _selectedAspectRatio.asStateFlow()

    private val _isGeneratingImage = MutableStateFlow(false)
    val isGeneratingImage: StateFlow<Boolean> = _isGeneratingImage.asStateFlow()

    private val _isEnhancingPrompt = MutableStateFlow(false)
    val isEnhancingPrompt: StateFlow<Boolean> = _isEnhancingPrompt.asStateFlow()

    private val _lastGeneratedImage = MutableStateFlow<MediaItem?>(null)
    val lastGeneratedImage: StateFlow<MediaItem?> = _lastGeneratedImage.asStateFlow()

    // Create & Edit Images
    private val _imageStudioMode = MutableStateFlow("CREATE") // "CREATE" or "EDIT"
    val imageStudioMode: StateFlow<String> = _imageStudioMode.asStateFlow()

    private val _selectedResolution = MutableStateFlow("1K") // "1K", "2K", "4K"
    val selectedResolution: StateFlow<String> = _selectedResolution.asStateFlow()

    private val _editSourceImage = MutableStateFlow<MediaItem?>(null)
    val editSourceImage: StateFlow<MediaItem?> = _editSourceImage.asStateFlow()

    private val _editSourceImageBase64 = MutableStateFlow<String?>(null)
    val editSourceImageBase64: StateFlow<String?> = _editSourceImageBase64.asStateFlow()

    private val _editPrompt = MutableStateFlow("")
    val editPrompt: StateFlow<String> = _editPrompt.asStateFlow()

    private val _isProcessingNanoBanana = MutableStateFlow(false)
    val isProcessingNanoBanana: StateFlow<Boolean> = _isProcessingNanoBanana.asStateFlow()

    private val _lastEditedImage = MutableStateFlow<MediaItem?>(null)
    val lastEditedImage: StateFlow<MediaItem?> = _lastEditedImage.asStateFlow()

    // Image to Video (ITV)
    private val _itvSourceImage = MutableStateFlow<MediaItem?>(null)
    val itvSourceImage: StateFlow<MediaItem?> = _itvSourceImage.asStateFlow()

    private val _itvMotionPrompt = MutableStateFlow("")
    val itvMotionPrompt: StateFlow<String> = _itvMotionPrompt.asStateFlow()

    private val _selectedMotion = MutableStateFlow("Cinematic Zoom")
    val selectedMotion: StateFlow<String> = _selectedMotion.asStateFlow()

    private val _videoDuration = MutableStateFlow(5)
    val videoDuration: StateFlow<Int> = _videoDuration.asStateFlow()

    private val _isGeneratingVideo = MutableStateFlow(false)
    val isGeneratingVideo: StateFlow<Boolean> = _isGeneratingVideo.asStateFlow()

    private val _generationStage = MutableStateFlow("")
    val generationStage: StateFlow<String> = _generationStage.asStateFlow()

    private val _lastGeneratedVideo = MutableStateFlow<MediaItem?>(null)
    val lastGeneratedVideo: StateFlow<MediaItem?> = _lastGeneratedVideo.asStateFlow()

    private val _isVideoPlaying = MutableStateFlow(false)
    val isVideoPlaying: StateFlow<Boolean> = _isVideoPlaying.asStateFlow()

    private val _videoProgress = MutableStateFlow(0f)
    val videoProgress: StateFlow<Float> = _videoProgress.asStateFlow()

    private var videoPlaybackJob: Job? = null

    // Speech to Voice (STV)
    private val _stvLanguage = MutableStateFlow(ChatLanguage.HINGLISH)
    val stvLanguage: StateFlow<ChatLanguage> = _stvLanguage.asStateFlow()

    private val _selectedVoice = MutableStateFlow(ttsEngine.availableVoices.first())
    val selectedVoice: StateFlow<VoiceProfile> = _selectedVoice.asStateFlow()

    private val _stvText = MutableStateFlow(
        "Kaisey ho dost! HAZIM AI me aapka swagat hai. Main natural voices generate kar sakta hoon Hindi, English aur Kashmiri me."
    )
    val stvText: StateFlow<String> = _stvText.asStateFlow()

    private val _stvPitch = MutableStateFlow(1.0f)
    val stvPitch: StateFlow<Float> = _stvPitch.asStateFlow()

    private val _stvSpeed = MutableStateFlow(1.0f)
    val stvSpeed: StateFlow<Float> = _stvSpeed.asStateFlow()

    private val _stvEmotion = MutableStateFlow("Cheerful")
    val stvEmotion: StateFlow<String> = _stvEmotion.asStateFlow()

    private val _isGeneratingVoice = MutableStateFlow(false)
    val isGeneratingVoice: StateFlow<Boolean> = _isGeneratingVoice.asStateFlow()

    // Gallery
    private val _galleryFilter = MutableStateFlow("ALL")
    val galleryFilter: StateFlow<String> = _galleryFilter.asStateFlow()

    private val _galleryItems = MutableStateFlow<List<MediaItem>>(emptyList())
    val galleryItems: StateFlow<List<MediaItem>> = _galleryItems.asStateFlow()

    private val _selectedGalleryItem = MutableStateFlow<MediaItem?>(null)
    val selectedGalleryItem: StateFlow<MediaItem?> = _selectedGalleryItem.asStateFlow()

    init {
        loadDataForUser(_userAccount.value.email)
    }

    private fun loadDataForUser(email: String) {
        // 1. Load chat sessions
        val savedSessions = accountStorage.loadChatSessionsForUser(email)
        if (!savedSessions.isNullOrEmpty()) {
            _chatSessions.value = savedSessions
            val first = savedSessions.first()
            _currentSessionId.value = first.id
            _messages.value = first.messages
        } else {
            createNewChat()
        }

        // 2. Load gallery items
        val savedGallery = accountStorage.loadGalleryForUser(email)
        if (!savedGallery.isNullOrEmpty()) {
            _galleryItems.value = savedGallery
            val img = savedGallery.find { it.type == MediaType.IMAGE }
            if (img != null) _itvSourceImage.value = img
        } else {
            initDefaultGalleryForUser(email)
        }
    }

    private fun initDefaultGalleryForUser(email: String) {
        val sampleItems = listOf(
            MediaItem(
                title = "Dal Lake Golden Hour",
                prompt = "Serene Dal Lake in Srinagar Kashmir with traditional Shikara boats, glowing sunset over snow-capped Zabarwan mountains, 8k resolution cinematic reflection",
                type = MediaType.IMAGE,
                mediaUrl = "https://images.unsplash.com/photo-1595815771614-ade9d652a65d?auto=format&fit=crop&w=1080&q=80",
                durationSeconds = null
            ),
            MediaItem(
                title = "Cyberpunk Hazim Neural Core",
                prompt = "Futuristic quantum neural AI matrix core glowing with cyan and neon violet laser data streams, 8k octane render",
                type = MediaType.IMAGE,
                mediaUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1080&q=80",
                durationSeconds = null
            ),
            MediaItem(
                title = "Kashmir Gulmarg Snow Motion",
                prompt = "Slow cinematic drone sweep through pine trees covered with fresh powdery snow in Gulmarg Kashmir",
                type = MediaType.VIDEO,
                mediaUrl = "https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&w=1080&q=80",
                videoMotionType = "Cinematic Zoom",
                durationSeconds = 5
            ),
            MediaItem(
                title = "Hazim Welcome Voice (Hinglish)",
                prompt = "Natural warm welcome greeting synthesized with Aarav neural voice model",
                type = MediaType.AUDIO,
                mediaUrl = "",
                voiceName = "Aarav (आरव)",
                language = "Hinglish",
                durationSeconds = 6
            )
        )
        _galleryItems.value = sampleItems
        _itvSourceImage.value = sampleItems[0]
        accountStorage.saveGalleryForUser(email, sampleItems)
    }

    private fun persistCurrentUserData() {
        val email = _userAccount.value.email
        if (email.isNotBlank()) {
            accountStorage.saveChatSessionsForUser(email, _chatSessions.value)
            accountStorage.saveGalleryForUser(email, _galleryItems.value)
        }
    }

    // Navigation
    fun navigateTo(destination: ScreenDestination) {
        _currentScreen.value = destination
    }

    // Auth
    fun openAuthDialog() {
        _isAuthDialogOpen.value = true
    }

    fun closeAuthDialog() {
        _isAuthDialogOpen.value = false
    }

    fun getAccountsForProvider(provider: String): List<UserAccount> {
        return accountStorage.getKnownAccounts(provider)
    }

    fun login(provider: String, email: String, name: String) {
        // 1. Save data of previously active user
        persistCurrentUserData()

        // 2. Switch to new account
        val newAccount = UserAccount(
            isLoggedIn = true,
            name = name,
            email = email,
            authProvider = provider,
            avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80",
            isPro = true
        )
        _userAccount.value = newAccount
        accountStorage.saveActiveUser(newAccount)

        // 3. Load this specific account's saved data
        loadDataForUser(email)
        _isAuthDialogOpen.value = false
    }

    fun logout() {
        persistCurrentUserData()
        val guest = UserAccount(
            isLoggedIn = false,
            name = "Guest User",
            email = "guest@hazimai.com",
            authProvider = "None",
            isPro = false
        )
        _userAccount.value = guest
        accountStorage.saveActiveUser(guest)
        loadDataForUser(guest.email)
    }

    // Chat Management
    fun setChatLanguage(language: ChatLanguage) {
        _chatLanguage.value = language
    }

    fun setChatInputText(text: String) {
        _chatInputText.value = text
    }

    fun createNewChat() {
        val newSessionId = java.util.UUID.randomUUID().toString()
        val initialGreeting = when (_chatLanguage.value) {
            ChatLanguage.ENGLISH -> "Hello! I am **HAZIM AI**. Ask me anything, generate images (TTI), create videos (ITV), or try realistic voice synthesis (STV)."
            ChatLanguage.HINDI -> "नमस्ते! मैं **HAZIM AI** हूँ। आप मुझसे हिन्दी में बात कर सकते हैं, चित्र (TTI) और वीडियो (ITV) बना सकते हैं, या आवाज़ें (STV) उत्पन्न कर सकते हैं।"
            ChatLanguage.HINGLISH -> "Kaisey ho dost! Main hoon **HAZIM AI**. Real-time chat, TTI se images, ITV se videos aur STV se realistic voices sab ready hai. Kya help chahiye aaj?"
            ChatLanguage.KASHMIRI -> "السلام علیکم ورحمۃ اللہ! بہٕ چھُس **HAZIM AI**۔ کشیرِ ہنٛد تہٕ دنیاہس متعلق کیا کٔرو کتھ باتھ؟ ؤنِیو جناب!"
        }

        val initialMessage = ChatMessage(
            sender = MessageSender.AI,
            text = initialGreeting,
            language = _chatLanguage.value
        )

        val newSession = ChatSession(
            id = newSessionId,
            title = "New Chat",
            messages = listOf(initialMessage)
        )

        _chatSessions.update { listOf(newSession) + it }
        _currentSessionId.value = newSessionId
        _messages.value = listOf(initialMessage)

        persistCurrentUserData()
    }

    fun switchChatSession(sessionId: String) {
        val session = _chatSessions.value.find { it.id == sessionId } ?: return
        _currentSessionId.value = session.id
        _messages.value = session.messages
    }

    fun deleteChatSession(sessionId: String) {
        _chatSessions.update { it.filter { session -> session.id != sessionId } }
        if (_currentSessionId.value == sessionId) {
            if (_chatSessions.value.isNotEmpty()) {
                switchChatSession(_chatSessions.value.first().id)
            } else {
                createNewChat()
            }
        }
        persistCurrentUserData()
    }

    fun sendChatMessage() {
        val prompt = _chatInputText.value.trim()
        if (prompt.isBlank() || _isChatLoading.value) return

        val userMessage = ChatMessage(
            sender = MessageSender.USER,
            text = prompt,
            language = _chatLanguage.value
        )

        val updatedMessages = _messages.value + userMessage
        _messages.value = updatedMessages
        _chatInputText.value = ""
        _isChatLoading.value = true

        // Update session title if first user message
        val currentId = _currentSessionId.value
        _chatSessions.update { sessions ->
            sessions.map { session ->
                if (session.id == currentId) {
                    val newTitle = if (session.title == "New Chat") {
                        if (prompt.length > 25) prompt.take(25) + "..." else prompt
                    } else session.title
                    session.copy(title = newTitle, messages = updatedMessages)
                } else session
            }
        }

        viewModelScope.launch {
            val historyPairs = updatedMessages
                .dropLast(1)
                .chunked(2)
                .mapNotNull {
                    if (it.size == 2 && it[0].sender == MessageSender.USER && it[1].sender == MessageSender.AI) {
                        Pair(it[0].text, it[1].text)
                    } else null
                }

            val aiResponseText = GeminiApiClient.generateChatResponse(
                prompt = prompt,
                language = _chatLanguage.value,
                history = historyPairs
            )

            val aiMessage = ChatMessage(
                sender = MessageSender.AI,
                text = aiResponseText,
                language = _chatLanguage.value
            )

            val finalMessages = updatedMessages + aiMessage
            _messages.value = finalMessages
            _isChatLoading.value = false

            _chatSessions.update { sessions ->
                sessions.map { session ->
                    if (session.id == currentId) {
                        session.copy(messages = finalMessages)
                    } else session
                }
            }

            persistCurrentUserData()
        }
    }

    fun speakMessage(message: ChatMessage) {
        ttsEngine.speak(
            text = message.text,
            language = message.language
        )
    }

    // Text to Image (TTI)
    fun setImagePrompt(prompt: String) {
        _imagePrompt.value = prompt
    }

    fun setSelectedStyle(style: String) {
        _selectedStyle.value = style
    }

    fun setSelectedAspectRatio(ratio: String) {
        _selectedAspectRatio.value = ratio
    }

    fun enhanceImagePrompt() {
        val current = _imagePrompt.value.trim()
        if (current.isBlank() || _isEnhancingPrompt.value) return

        _isEnhancingPrompt.value = true
        viewModelScope.launch {
            val enhanced = GeminiApiClient.enhanceImagePrompt(current)
            _imagePrompt.value = enhanced
            _isEnhancingPrompt.value = false
        }
    }

    fun generateImage() {
        val rawPrompt = _imagePrompt.value.trim()
        if (rawPrompt.isBlank() || _isGeneratingImage.value) return

        _isGeneratingImage.value = true
        viewModelScope.launch {
            val stylePrefix = when (_selectedStyle.value) {
                "Photorealistic" -> "photorealistic 8k octane render portrait masterpiece"
                "Cyberpunk" -> "cyberpunk neon glowing synthwave futuristic"
                "Anime" -> "makoto shinkai aesthetic anime digital illustration vibrant"
                "Cinematic" -> "cinematic film still anamorphic lens dramatic moody lighting"
                "Digital Art" -> "detailed digital concept art matte painting masterpiece"
                "3D Render" -> "3D cute Pixar Disney render smooth subsurface scattering"
                else -> ""
            }

            val finalPrompt = "$rawPrompt, $stylePrefix"
            val (width, height) = when (_selectedAspectRatio.value) {
                "16:9" -> Pair(1280, 720)
                "9:16" -> Pair(720, 1280)
                "4:3" -> Pair(1024, 768)
                else -> Pair(1024, 1024)
            }

            val seed = (1000..999999).random()
            val encodedPrompt = URLEncoder.encode(finalPrompt, StandardCharsets.UTF_8.toString())
            val imageUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=$width&height=$height&seed=$seed&nologo=true"

            delay(1000)

            val newMedia = MediaItem(
                title = if (rawPrompt.length > 30) rawPrompt.take(30) + "..." else rawPrompt,
                prompt = rawPrompt,
                type = MediaType.IMAGE,
                mediaUrl = imageUrl
            )

            _lastGeneratedImage.value = newMedia
            _galleryItems.update { listOf(newMedia) + it }
            _itvSourceImage.value = newMedia
            _isGeneratingImage.value = false

            persistCurrentUserData()
        }
    }

    fun setImageStudioMode(mode: String) {
        _imageStudioMode.value = mode
    }

    fun setSelectedResolution(res: String) {
        _selectedResolution.value = res
    }

    fun setEditPrompt(prompt: String) {
        _editPrompt.value = prompt
    }

    fun setEditSourceImage(item: MediaItem?) {
        _editSourceImage.value = item
        _editSourceImageBase64.value = null
    }

    fun loadEditImageFromUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()

                if (bitmap != null) {
                    val outputStream = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
                    val base64 = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
                    _editSourceImageBase64.value = base64

                    val mediaItem = MediaItem(
                        title = "Imported Photo",
                        prompt = "Custom photo for AI image editing",
                        type = MediaType.IMAGE,
                        mediaUrl = uri.toString()
                    )
                    _editSourceImage.value = mediaItem
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun executeCreateOrEditWithNanoBanana(isEdit: Boolean) {
        val prompt = if (isEdit) _editPrompt.value.trim() else _imagePrompt.value.trim()
        if (prompt.isBlank() || _isProcessingNanoBanana.value) return

        _isProcessingNanoBanana.value = true
        _isGeneratingImage.value = true

        viewModelScope.launch {
            val resultUrl = GeminiApiClient.createOrEditImageWithNanoBanana(
                prompt = prompt,
                sourceImageBase64 = if (isEdit) _editSourceImageBase64.value else null,
                aspectRatio = _selectedAspectRatio.value,
                imageSize = _selectedResolution.value
            )

            val newMedia = MediaItem(
                title = if (isEdit) "Edited: ${prompt.take(20)}" else if (prompt.length > 25) prompt.take(25) + "..." else prompt,
                prompt = if (isEdit) "Edited: $prompt" else "$prompt (${_selectedResolution.value} AI Render)",
                type = MediaType.IMAGE,
                mediaUrl = resultUrl
            )

            if (isEdit) {
                _lastEditedImage.value = newMedia
            } else {
                _lastGeneratedImage.value = newMedia
            }

            _galleryItems.update { listOf(newMedia) + it }
            _itvSourceImage.value = newMedia
            _isProcessingNanoBanana.value = false
            _isGeneratingImage.value = false

            persistCurrentUserData()
        }
    }

    // Image to Video (ITV)
    fun setItvSourceImage(item: MediaItem) {
        _itvSourceImage.value = item
    }

    fun setItvMotionPrompt(prompt: String) {
        _itvMotionPrompt.value = prompt
    }

    fun setSelectedMotion(motion: String) {
        _selectedMotion.value = motion
    }

    fun setVideoDuration(duration: Int) {
        _videoDuration.value = duration
    }

    fun generateVideo() {
        val source = _itvSourceImage.value ?: return
        if (_isGeneratingVideo.value) return

        _isGeneratingVideo.value = true
        viewModelScope.launch {
            _generationStage.value = "Analyzing optical flow & scene depth..."
            delay(1000)
            _generationStage.value = "Synthesizing AI motion vectors (${_selectedMotion.value})..."
            delay(1000)
            _generationStage.value = "Rendering 60 FPS motion trajectory frames..."
            delay(1000)
            _generationStage.value = "Polishing lighting dynamics & output encode..."
            delay(600)

            val videoUrl = when (_selectedMotion.value) {
                "Slow Drone" -> "https://media.w3.org/2010/05/sintel/trailer.mp4"
                else -> "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4"
            }

            val newVideo = MediaItem(
                title = "Video: ${source.title}",
                prompt = _itvMotionPrompt.value.ifBlank { "${_selectedMotion.value} camera movement on ${source.prompt}" },
                type = MediaType.VIDEO,
                mediaUrl = videoUrl,
                thumbnailUrl = source.mediaUrl,
                videoMotionType = _selectedMotion.value,
                durationSeconds = _videoDuration.value
            )

            _lastGeneratedVideo.value = newVideo
            _galleryItems.update { listOf(newVideo) + it }
            _isGeneratingVideo.value = false
            _generationStage.value = ""

            persistCurrentUserData()
            startVideoPlayback()
        }
    }

    fun toggleVideoPlayback() {
        if (_isVideoPlaying.value) {
            pauseVideoPlayback()
        } else {
            startVideoPlayback()
        }
    }

    fun setVideoScrubberProgress(progress: Float) {
        _videoProgress.value = progress.coerceIn(0f, 1f)
    }

    private fun startVideoPlayback() {
        _isVideoPlaying.value = true
        videoPlaybackJob?.cancel()
        videoPlaybackJob = viewModelScope.launch {
            val totalSteps = 100
            val durationMs = (_videoDuration.value * 1000).toLong()
            val stepDelay = (durationMs / totalSteps).coerceAtLeast(20)

            while (_isVideoPlaying.value) {
                while (_videoProgress.value < 1.0f && _isVideoPlaying.value) {
                    delay(stepDelay)
                    _videoProgress.value = (_videoProgress.value + 0.01f).coerceAtMost(1f)
                }
                if (_isVideoPlaying.value) {
                    delay(400)
                    _videoProgress.value = 0f // Loop
                }
            }
        }
    }

    private fun pauseVideoPlayback() {
        _isVideoPlaying.value = false
        videoPlaybackJob?.cancel()
    }

    // Speech to Voice (STV)
    fun setStvLanguage(language: ChatLanguage) {
        _stvLanguage.value = language
        val matchingVoice = ttsEngine.availableVoices.find { it.language == language }
            ?: ttsEngine.availableVoices.first()
        _selectedVoice.value = matchingVoice
    }

    fun setSelectedVoice(voice: VoiceProfile) {
        _selectedVoice.value = voice
        _stvPitch.value = voice.defaultPitch
        _stvSpeed.value = voice.defaultSpeed
    }

    fun setStvText(text: String) {
        _stvText.value = text
    }

    fun setStvPitch(pitch: Float) {
        _stvPitch.value = pitch
    }

    fun setStvSpeed(speed: Float) {
        _stvSpeed.value = speed
    }

    fun setStvEmotion(emotion: String) {
        _stvEmotion.value = emotion
        when (emotion) {
            "Cheerful" -> {
                _stvPitch.value = 1.15f
                _stvSpeed.value = 1.08f
            }
            "Calm" -> {
                _stvPitch.value = 0.90f
                _stvSpeed.value = 0.90f
            }
            "Inspiring" -> {
                _stvPitch.value = 1.05f
                _stvSpeed.value = 0.95f
            }
            else -> {
                _stvPitch.value = 1.0f
                _stvSpeed.value = 1.0f
            }
        }
    }

    fun playStvVoice() {
        val text = _stvText.value.trim()
        if (text.isBlank()) return

        _isGeneratingVoice.value = true
        ttsEngine.speak(
            text = text,
            language = _selectedVoice.value.language,
            pitch = _stvPitch.value,
            speed = _stvSpeed.value
        )
        viewModelScope.launch {
            delay(500)
            _isGeneratingVoice.value = false
        }
    }

    fun stopStvVoice() {
        ttsEngine.stop()
    }

    fun saveVoiceToGallery() {
        val text = _stvText.value.trim()
        if (text.isBlank()) return

        val title = if (text.length > 25) text.take(25) + "..." else text
        val newAudio = MediaItem(
            title = "Voice: $title",
            prompt = text,
            type = MediaType.AUDIO,
            mediaUrl = "",
            voiceName = _selectedVoice.value.name,
            language = _selectedVoice.value.language.displayName,
            durationSeconds = (text.split(" ").size / 2.5).toInt().coerceAtLeast(3)
        )
        _galleryItems.update { listOf(newAudio) + it }
        persistCurrentUserData()
    }

    // Gallery
    fun setGalleryFilter(filter: String) {
        _galleryFilter.value = filter
    }

    fun selectGalleryItem(item: MediaItem?) {
        _selectedGalleryItem.value = item
    }

    fun deleteGalleryItem(id: String) {
        _galleryItems.update { it.filter { item -> item.id != id } }
        if (_selectedGalleryItem.value?.id == id) {
            _selectedGalleryItem.value = null
        }
        persistCurrentUserData()
    }

    override fun onCleared() {
        super.onCleared()
        persistCurrentUserData()
        ttsEngine.release()
    }
}
