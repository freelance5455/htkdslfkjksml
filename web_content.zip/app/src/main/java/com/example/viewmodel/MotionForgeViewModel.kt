package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.AudioAnalysisResult
import com.example.engine.AudioAnalyzer
import com.example.engine.RecipeParser
import com.example.model.ProjectRecipe
import com.example.model.ValidationResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MotionForgeViewModel : ViewModel() {

  private val _recipe = MutableStateFlow<ProjectRecipe?>(null)
  val recipe: StateFlow<ProjectRecipe?> = _recipe.asStateFlow()

  private val _currentTime = MutableStateFlow(0f)
  val currentTime: StateFlow<Float> = _currentTime.asStateFlow()

  private val _isPlaying = MutableStateFlow(false)
  val isPlaying: StateFlow<Float?> = MutableStateFlow(null) // handled via isPlayingState

  private val _isPlayingState = MutableStateFlow(false)
  val isPlayingState: StateFlow<Boolean> = _isPlayingState.asStateFlow()

  private val _validationResult = MutableStateFlow<ValidationResult?>(null)
  val validationResult: StateFlow<ValidationResult?> = _validationResult.asStateFlow()

  private val _audioAnalysis = MutableStateFlow<AudioAnalysisResult?>(null)
  val audioAnalysis: StateFlow<AudioAnalysisResult?> = _audioAnalysis.asStateFlow()

  private val _isExporting = MutableStateFlow(false)
  val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

  private val _exportProgress = MutableStateFlow(0f)
  val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

  private val _exportComplete = MutableStateFlow(false)
  val exportComplete: StateFlow<Boolean> = _exportComplete.asStateFlow()

  private var playbackJob: Job? = null

  init {
    // Load default sample recipe
    val samples = RecipeParser.getSampleRecipes()
    val defaultJson = samples["Cyberpunk Cinematic Title"] ?: ""
    loadRecipeJson(defaultJson)
  }

  fun loadRecipeJson(jsonStr: String) {
    val result = RecipeParser.parseAndValidate(jsonStr)
    _validationResult.value = result
    if (result.isValid && result.recipe != null) {
      _recipe.value = result.recipe
      _currentTime.value = 0f
      // Analyze audio
      val dur = result.recipe.settings.durationSeconds
      _audioAnalysis.value = AudioAnalyzer.analyzeAudio("Cyber Beat 120BPM", dur, "balanced")
    }
  }

  fun togglePlay() {
    if (_isPlayingState.value) {
      pausePlayback()
    } else {
      startPlayback()
    }
  }

  private fun startPlayback() {
    _isPlayingState.value = true
    playbackJob?.cancel()
    playbackJob = viewModelScope.launch {
      val maxDuration = _recipe.value?.settings?.durationSeconds ?: 10f
      while (isActive && _isPlayingState.value) {
        delay(33) // ~30fps
        val nextTime = _currentTime.value + 0.033f
        if (nextTime >= maxDuration) {
          _currentTime.value = 0f
          _isPlayingState.value = false
          break
        } else {
          _currentTime.value = nextTime
        }
      }
    }
  }

  fun pausePlayback() {
    _isPlayingState.value = false
    playbackJob?.cancel()
  }

  fun seekTo(time: Float) {
    val maxDuration = _recipe.value?.settings?.durationSeconds ?: 10f
    _currentTime.value = time.coerceIn(0f, maxDuration)
  }

  fun updateLayerText(layerId: String, newText: String) {
    val current = _recipe.value ?: return
    val updatedScenes = current.scenes.map { scene ->
      scene.copy(layers = scene.layers.map { layer ->
        if (layer.id == layerId && layer.textConfig != null) {
          layer.copy(textConfig = layer.textConfig.copy(text = newText))
        } else {
          layer
        }
      })
    }
    _recipe.value = current.copy(scenes = updatedScenes)
  }

  fun startExport(resolution: String, format: String) {
    _isExporting.value = true
    _exportProgress.value = 0f
    _exportComplete.value = false

    viewModelScope.launch {
      for (i in 1..100) {
        delay(35)
        _exportProgress.value = i / 100f
      }
      _isExporting.value = false
      _exportComplete.value = true
    }
  }

  fun resetExportState() {
    _exportComplete.value = false
    _exportProgress.value = 0f
  }
}
