package com.example.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ScanDatabase
import com.example.data.ScanItem
import com.example.data.ScanRepository
import com.example.generator.QrColorTheme
import com.example.generator.QrGenerator
import com.example.model.ParsedQr
import com.example.model.QrCategory
import com.example.model.QrParser
import com.example.util.FeedbackHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ScannerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ScanRepository

    init {
        val db = ScanDatabase.getInstance(application)
        repository = ScanRepository(db.scanDao())
    }

    // Active scan result modal
    private val _currentResult = MutableStateFlow<ParsedQr?>(null)
    val currentResult: StateFlow<ParsedQr?> = _currentResult.asStateFlow()

    // URL Metadata preview state (title, favicon, description)
    private val _currentUrlMetadata = MutableStateFlow<com.example.model.UrlMetadata?>(null)
    val currentUrlMetadata: StateFlow<com.example.model.UrlMetadata?> = _currentUrlMetadata.asStateFlow()

    // Safe Link Confirmation
    private val _pendingUrlToOpen = MutableStateFlow<String?>(null)
    val pendingUrlToOpen: StateFlow<String?> = _pendingUrlToOpen.asStateFlow()

    // Hardware camera controls
    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    private val _isFrontCamera = MutableStateFlow(false)
    val isFrontCamera: StateFlow<Boolean> = _isFrontCamera.asStateFlow()

    // History filtering
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategoryFilter = MutableStateFlow(QrCategory.ALL)
    val selectedCategoryFilter: StateFlow<QrCategory> = _selectedCategoryFilter.asStateFlow()

    private val _onlyFavorites = MutableStateFlow(false)
    val onlyFavorites: StateFlow<Boolean> = _onlyFavorites.asStateFlow()

    // Settings
    private val prefs = application.getSharedPreferences("scanova_settings", Context.MODE_PRIVATE)

    private val _vibrateOnScan = MutableStateFlow(prefs.getBoolean("vibrate_on_scan", true))
    val vibrateOnScan: StateFlow<Boolean> = _vibrateOnScan.asStateFlow()

    private val _hapticStyle = MutableStateFlow(
        runCatching {
            com.example.model.HapticFeedbackStyle.valueOf(
                prefs.getString("haptic_style", com.example.model.HapticFeedbackStyle.CRISP_CLICK.name) ?: com.example.model.HapticFeedbackStyle.CRISP_CLICK.name
            )
        }.getOrDefault(com.example.model.HapticFeedbackStyle.CRISP_CLICK)
    )
    val hapticStyle: StateFlow<com.example.model.HapticFeedbackStyle> = _hapticStyle.asStateFlow()

    private val _soundOnScan = MutableStateFlow(prefs.getBoolean("sound_on_scan", true))
    val soundOnScan: StateFlow<Boolean> = _soundOnScan.asStateFlow()

    private val _safeLinkConfirmation = MutableStateFlow(prefs.getBoolean("safe_link_confirmation", true))
    val safeLinkConfirmation: StateFlow<Boolean> = _safeLinkConfirmation.asStateFlow()

    private val _autoCopyScanned = MutableStateFlow(prefs.getBoolean("auto_copy_scanned", false))
    val autoCopyScanned: StateFlow<Boolean> = _autoCopyScanned.asStateFlow()

    // Biometric Security Setting
    private val _biometricLockEnabled = MutableStateFlow(prefs.getBoolean("biometric_lock_enabled", false))
    val biometricLockEnabled: StateFlow<Boolean> = _biometricLockEnabled.asStateFlow()

    // Whether history is currently unlocked for this session
    private val _isHistoryUnlocked = MutableStateFlow(false)
    val isHistoryUnlocked: StateFlow<Boolean> = _isHistoryUnlocked.asStateFlow()

    // Generator state
    private val _generatorCategory = MutableStateFlow(QrCategory.URL)
    val generatorCategory: StateFlow<QrCategory> = _generatorCategory.asStateFlow()

    private val _generatorInput1 = MutableStateFlow("https://")
    val generatorInput1: StateFlow<String> = _generatorInput1.asStateFlow()

    private val _generatorInput2 = MutableStateFlow("")
    val generatorInput2: StateFlow<String> = _generatorInput2.asStateFlow()

    private val _generatorInput3 = MutableStateFlow("")
    val generatorInput3: StateFlow<String> = _generatorInput3.asStateFlow()

    private val _selectedTheme = MutableStateFlow(QrGenerator.THEMES[0])
    val selectedTheme: StateFlow<QrColorTheme> = _selectedTheme.asStateFlow()

    private val _generatedBitmap = MutableStateFlow<Bitmap?>(null)
    val generatedBitmap: StateFlow<Bitmap?> = _generatedBitmap.asStateFlow()

    // Combined filtered scans
    val historyItems: StateFlow<List<ScanItem>> = combine(
        repository.allScans,
        _searchQuery,
        _selectedCategoryFilter,
        _onlyFavorites
    ) { all, query, category, favOnly ->
        all.filter { item ->
            val matchesFav = !favOnly || item.isFavorite
            val matchesCategory = category == QrCategory.ALL || item.category == category.name
            val matchesQuery = query.isBlank() ||
                item.title.contains(query, ignoreCase = true) ||
                item.rawContent.contains(query, ignoreCase = true) ||
                item.subtitle.contains(query, ignoreCase = true)
            matchesFav && matchesCategory && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onBarcodeDetected(rawText: String) {
        val parsed = QrParser.parse(rawText)
        _currentResult.value = parsed

        // If it's a URL, asynchronously fetch website title & favicon
        if (parsed.category == QrCategory.URL) {
            val targetUrl = parsed.actionableUri ?: parsed.rawText
            fetchMetadataForUrl(targetUrl)
        } else {
            _currentUrlMetadata.value = null
        }

        // Feedback
        if (_vibrateOnScan.value) {
            FeedbackHelper.vibrate(getApplication(), _hapticStyle.value)
        }
        if (_soundOnScan.value) {
            FeedbackHelper.playBeep()
        }

        // Auto copy if enabled
        if (_autoCopyScanned.value) {
            copyToClipboard(parsed.rawText, showToast = false)
        }

        // Save to Room DB
        viewModelScope.launch {
            repository.insert(
                ScanItem(
                    rawContent = parsed.rawText,
                    category = parsed.category.name,
                    title = parsed.title,
                    subtitle = parsed.subtitle,
                    timestamp = System.currentTimeMillis(),
                    isFavorite = false,
                    isCreated = false
                )
            )
        }
    }

    private fun fetchMetadataForUrl(url: String) {
        val host = runCatching { java.net.URI(url).host ?: url }.getOrDefault(url)
        _currentUrlMetadata.value = com.example.model.UrlMetadata(
            url = url,
            host = host,
            faviconUrl = "https://www.google.com/s2/favicons?sz=128&domain=$host",
            title = host,
            isLoading = true
        )
        viewModelScope.launch {
            val meta = com.example.util.UrlMetadataFetcher.fetchMetadata(url)
            _currentUrlMetadata.value = meta
        }
    }

    fun dismissResult() {
        _currentResult.value = null
        _currentUrlMetadata.value = null
    }

    fun requestOpenUrl(url: String) {
        if (_safeLinkConfirmation.value) {
            _pendingUrlToOpen.value = url
            if (_currentUrlMetadata.value == null || _currentUrlMetadata.value?.url != url) {
                fetchMetadataForUrl(url)
            }
        } else {
            openUrlDirectly(url)
        }
    }

    fun confirmOpenUrl() {
        _pendingUrlToOpen.value?.let { openUrlDirectly(it) }
        _pendingUrlToOpen.value = null
    }

    fun dismissUrlConfirmation() {
        _pendingUrlToOpen.value = null
    }

    private fun openUrlDirectly(url: String) {
        try {
            val intent = android.content.Intent(
                android.content.Intent.ACTION_VIEW,
                android.net.Uri.parse(url)
            ).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            getApplication<Application>().startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(getApplication(), "No browser application found to open link.", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyToClipboard(text: String, showToast: Boolean = true) {
        val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Scanned QR Content", text)
        clipboard.setPrimaryClip(clip)
        if (showToast) {
            Toast.makeText(getApplication(), "Copied to clipboard", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleTorch() {
        _isTorchOn.value = !_isTorchOn.value
    }

    fun toggleCameraFacing() {
        _isFrontCamera.value = !_isFrontCamera.value
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: QrCategory) {
        _selectedCategoryFilter.value = category
    }

    fun toggleFavoritesOnly() {
        _onlyFavorites.value = !_onlyFavorites.value
    }

    fun toggleFavorite(item: ScanItem) {
        viewModelScope.launch {
            repository.toggleFavorite(item.id, item.isFavorite)
        }
    }

    fun deleteScan(id: Long) {
        viewModelScope.launch {
            repository.delete(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    // Settings mutators
    fun setVibrate(enabled: Boolean) {
        _vibrateOnScan.value = enabled
        prefs.edit().putBoolean("vibrate_on_scan", enabled).apply()
        if (enabled) {
            FeedbackHelper.vibrate(getApplication(), _hapticStyle.value)
        }
    }

    fun setHapticStyle(style: com.example.model.HapticFeedbackStyle) {
        _hapticStyle.value = style
        prefs.edit().putString("haptic_style", style.name).apply()
        // Play sample vibration immediately so user feels the selected intensity
        FeedbackHelper.vibrate(getApplication(), style)
    }
    fun setSound(enabled: Boolean) {
        _soundOnScan.value = enabled
        prefs.edit().putBoolean("sound_on_scan", enabled).apply()
    }
    fun setSafeLink(enabled: Boolean) {
        _safeLinkConfirmation.value = enabled
        prefs.edit().putBoolean("safe_link_confirmation", enabled).apply()
    }
    fun setAutoCopy(enabled: Boolean) {
        _autoCopyScanned.value = enabled
        prefs.edit().putBoolean("auto_copy_scanned", enabled).apply()
    }
    fun setBiometricLock(enabled: Boolean) {
        _biometricLockEnabled.value = enabled
        prefs.edit().putBoolean("biometric_lock_enabled", enabled).apply()
        if (!enabled) {
            _isHistoryUnlocked.value = true
        } else {
            _isHistoryUnlocked.value = false
        }
    }

    fun unlockHistory() {
        _isHistoryUnlocked.value = true
    }

    fun lockHistory() {
        if (_biometricLockEnabled.value) {
            _isHistoryUnlocked.value = false
        }
    }

    // Generator handlers
    fun setGeneratorCategory(category: QrCategory) {
        _generatorCategory.value = category
        when (category) {
            QrCategory.URL -> {
                _generatorInput1.value = "https://"
                _generatorInput2.value = ""
                _generatorInput3.value = ""
            }
            QrCategory.WIFI -> {
                _generatorInput1.value = "" // SSID
                _generatorInput2.value = "" // Password
                _generatorInput3.value = "WPA" // Type
            }
            QrCategory.CONTACT -> {
                _generatorInput1.value = "" // Name
                _generatorInput2.value = "" // Phone
                _generatorInput3.value = "" // Email
            }
            QrCategory.PHONE -> {
                _generatorInput1.value = ""
                _generatorInput2.value = ""
                _generatorInput3.value = ""
            }
            QrCategory.EMAIL -> {
                _generatorInput1.value = "" // Email
                _generatorInput2.value = "" // Subject
                _generatorInput3.value = "" // Message
            }
            QrCategory.SMS -> {
                _generatorInput1.value = "" // Phone
                _generatorInput2.value = "" // Message
                _generatorInput3.value = ""
            }
            else -> {
                _generatorInput1.value = ""
                _generatorInput2.value = ""
                _generatorInput3.value = ""
            }
        }
        rebuildGeneratedQr()
    }

    fun setGeneratorInput1(v: String) {
        _generatorInput1.value = v
        rebuildGeneratedQr()
    }

    fun setGeneratorInput2(v: String) {
        _generatorInput2.value = v
        rebuildGeneratedQr()
    }

    fun setGeneratorInput3(v: String) {
        _generatorInput3.value = v
        rebuildGeneratedQr()
    }

    fun setGeneratorTheme(theme: QrColorTheme) {
        _selectedTheme.value = theme
        rebuildGeneratedQr()
    }

    private fun buildPayload(): String {
        return when (_generatorCategory.value) {
            QrCategory.URL -> _generatorInput1.value.trim()
            QrCategory.WIFI -> {
                val ssid = _generatorInput1.value.trim()
                val pass = _generatorInput2.value.trim()
                val type = _generatorInput3.value.ifBlank { "WPA" }
                "WIFI:S:$ssid;T:$type;P:$pass;;"
            }
            QrCategory.CONTACT -> {
                val name = _generatorInput1.value.trim()
                val phone = _generatorInput2.value.trim()
                val email = _generatorInput3.value.trim()
                "BEGIN:VCARD\nVERSION:3.0\nFN:$name\nTEL:$phone\nEMAIL:$email\nEND:VCARD"
            }
            QrCategory.PHONE -> "tel:${_generatorInput1.value.trim()}"
            QrCategory.EMAIL -> {
                val email = _generatorInput1.value.trim()
                val sub = _generatorInput2.value.trim()
                val body = _generatorInput3.value.trim()
                "mailto:$email?subject=${android.net.Uri.encode(sub)}&body=${android.net.Uri.encode(body)}"
            }
            QrCategory.SMS -> {
                val phone = _generatorInput1.value.trim()
                val msg = _generatorInput2.value.trim()
                "smsto:$phone:$msg"
            }
            else -> _generatorInput1.value.trim()
        }
    }

    fun rebuildGeneratedQr() {
        val payload = buildPayload()
        if (payload.isBlank()) {
            _generatedBitmap.value = null
            return
        }
        val theme = _selectedTheme.value
        val bmp = QrGenerator.generateBitmap(
            content = payload,
            size = 650,
            foregroundColor = theme.foregroundColor,
            backgroundColor = theme.backgroundColor
        )
        _generatedBitmap.value = bmp
    }

    fun saveGeneratedQrToHistory() {
        val payload = buildPayload()
        if (payload.isBlank()) return
        val parsed = QrParser.parse(payload)
        viewModelScope.launch {
            repository.insert(
                ScanItem(
                    rawContent = payload,
                    category = parsed.category.name,
                    title = "Created: ${parsed.title}",
                    subtitle = parsed.subtitle,
                    timestamp = System.currentTimeMillis(),
                    isFavorite = true,
                    isCreated = true
                )
            )
            Toast.makeText(getApplication(), "Saved to History & Favorites", Toast.LENGTH_SHORT).show()
        }
    }
}
