package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.model.ChatMessage
import com.example.network.GeminiService
import com.example.speech.SpeechHelper
import com.example.utils.ImageUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FaizViewModel(application: Application) : AndroidViewModel(application) {

    private val geminiService = GeminiService()
    private val speechHelper = SpeechHelper(application.applicationContext)
    private val prefs = application.getSharedPreferences("faiz_saathi_prefs", Context.MODE_PRIVATE)

    private val initialWelcomeMessage = ChatMessage(
        text = "नमस्ते! मैं Faiz Saathi हूँ 🙏\n\nफोटो भेजो, बोलकर पूछो, लिखकर पूछो - हर सवाल का जवाब दूँगा।\n\nकोई भी होमवर्क, पढ़ाई का सवाल, या कोई किस्सा-कहानी - बेझिझक पूछिए!",
        isUser = false
    )

    private val _messages = MutableStateFlow<List<ChatMessage>>(listOf(initialWelcomeMessage))
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _selectedImageUri = MutableStateFlow<Uri?>(null)
    val selectedImageUri: StateFlow<Uri?> = _selectedImageUri.asStateFlow()

    private val _selectedImageBase64 = MutableStateFlow<String?>(null)
    private val _selectedImageMimeType = MutableStateFlow<String>("image/jpeg")

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _isListeningVoice = MutableStateFlow(false)
    val isListeningVoice: StateFlow<Boolean> = _isListeningVoice.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(prefs.getBoolean("is_dark_theme", false))
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _apiKey = MutableStateFlow(getStoredApiKey())
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _showApiKeyDialog = MutableStateFlow(false)
    val showApiKeyDialog: StateFlow<Boolean> = _showApiKeyDialog.asStateFlow()

    private val _showPwaInfoDialog = MutableStateFlow(false)
    val showPwaInfoDialog: StateFlow<Boolean> = _showPwaInfoDialog.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private fun getStoredApiKey(): String {
        val saved = prefs.getString("gemini_api_key", "") ?: ""
        if (saved.isNotBlank()) return saved
        return try {
            val buildKey = BuildConfig.GEMINI_API_KEY
            if (buildKey.isNotBlank() && buildKey != "MY_GEMINI_API_KEY") buildKey else ""
        } catch (_: Exception) {
            ""
        }
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text
    }

    fun onImageSelected(uri: Uri?) {
        _selectedImageUri.value = uri
        if (uri != null) {
            val context = getApplication<Application>().applicationContext
            val encoded = ImageUtils.uriToBase64(context, uri)
            if (encoded != null) {
                _selectedImageBase64.value = encoded.first
                _selectedImageMimeType.value = encoded.second
            } else {
                _selectedImageBase64.value = null
                _errorMessage.value = "Photo load nahi ho saki."
            }
        } else {
            _selectedImageBase64.value = null
        }
    }

    fun removeSelectedImage() {
        _selectedImageUri.value = null
        _selectedImageBase64.value = null
    }

    fun toggleTheme() {
        val newTheme = !_isDarkTheme.value
        _isDarkTheme.value = newTheme
        prefs.edit().putBoolean("is_dark_theme", newTheme).apply()
    }

    fun showApiKeyDialog(show: Boolean) {
        _showApiKeyDialog.value = show
    }

    fun showPwaInfoDialog(show: Boolean) {
        _showPwaInfoDialog.value = show
    }

    fun updateApiKey(newKey: String) {
        val trimmed = newKey.trim()
        _apiKey.value = trimmed
        prefs.edit().putString("gemini_api_key", trimmed).apply()
        _showApiKeyDialog.value = false
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    fun clearChat() {
        _messages.value = listOf(initialWelcomeMessage)
    }

    fun startVoiceInput(onPermissionNeeded: () -> Unit) {
        speechHelper.startListening(
            onResult = { transcript ->
                if (transcript.isNotBlank()) {
                    _inputText.value = transcript
                }
            },
            onError = { err ->
                if (err.contains("Microphone permission", ignoreCase = true)) {
                    onPermissionNeeded()
                } else {
                    _errorMessage.value = err
                }
            },
            onStateChange = { listening ->
                _isListeningVoice.value = listening
            }
        )
    }

    fun stopVoiceInput() {
        speechHelper.stopListening()
        _isListeningVoice.value = false
    }

    fun sendSuggestion(suggestion: String) {
        when {
            suggestion.contains("होमवर्क", ignoreCase = true) -> {
                _inputText.value = "Mera ye homework samajh nahi aa raha hai, kripya step-by-step samjhaayein:"
            }
            suggestion.contains("निबंध", ignoreCase = true) -> {
                _inputText.value = "Kripya 'Vigyan ke Chamatkar' ya 'Mera Bharat Mahan' par ek aasan Hindi nibandh likhiye."
            }
            suggestion.contains("किस्सा", ignoreCase = true) -> {
                sendMessageDirect("Mujhe Akbar-Birbal ya Panchatantra ka ek mazedaar aur seekh dene wala kissa sunao!")
            }
            else -> {
                sendMessageDirect(suggestion)
            }
        }
    }

    private fun sendMessageDirect(text: String) {
        _inputText.value = text
        sendMessage()
    }

    fun sendMessage() {
        val currentText = _inputText.value.trim()
        val currentImageUri = _selectedImageUri.value
        val currentImageBase64 = _selectedImageBase64.value
        val currentMimeType = _selectedImageMimeType.value

        if (currentText.isBlank() && currentImageBase64 == null) {
            return
        }

        // Active key
        val key = _apiKey.value.ifBlank {
            try {
                BuildConfig.GEMINI_API_KEY
            } catch (_: Exception) { "" }
        }

        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            _showApiKeyDialog.value = true
            return
        }

        // Add user message to chat list
        val userMsg = ChatMessage(
            text = if (currentText.isNotBlank()) currentText else "Photo bheji gayi hai",
            isUser = true,
            imageUri = currentImageUri,
            imageBase64 = currentImageBase64
        )

        _messages.value = _messages.value + userMsg

        // Reset inputs
        _inputText.value = ""
        _selectedImageUri.value = null
        _selectedImageBase64.value = null

        // Trigger AI response
        _isThinking.value = true

        viewModelScope.launch {
            val result = geminiService.generateContent(
                apiKey = key,
                prompt = currentText,
                imageBase64 = currentImageBase64,
                mimeType = currentMimeType
            )

            _isThinking.value = false

            result.onSuccess { aiResponse ->
                val aiMsg = ChatMessage(
                    text = aiResponse,
                    isUser = false
                )
                _messages.value = _messages.value + aiMsg
            }.onFailure { exception ->
                val errorMsg = exception.message ?: "Unknown error"
                val errorChat = ChatMessage(
                    text = "⚠️ $errorMsg\n\n(Aap header me 🔑 icon par click karke apna Gemini API Key check ya update kar sakte hain.)",
                    isUser = false,
                    isError = true
                )
                _messages.value = _messages.value + errorChat
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechHelper.stopListening()
    }
}
