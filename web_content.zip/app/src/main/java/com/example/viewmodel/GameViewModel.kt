package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiClueService
import com.example.audio.SoundManager
import com.example.data.DailyChallenges
import com.example.data.GAME_LEVELS
import com.example.data.LeaderboardRepository
import com.example.data.QUIZ_ITEMS
import com.example.data.TaskCatalog
import com.example.model.DailyRecord
import com.example.model.GameTask
import com.example.model.LeaderboardEntry
import com.example.model.QuizItem
import com.example.model.UserStats
import com.example.storage.GamePreferences
import com.example.ui.components.TileLetter
import com.example.ui.components.VictorySummary
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.random.Random

data class GameUiState(
    val currentItem: QuizItem,
    val zoomStage: Int = 1,
    val placedLetters: List<Char?> = emptyList(),
    val keyboardTiles: List<TileLetter> = emptyList(),
    val userStats: UserStats = UserStats(),
    val solvedIds: Set<String> = emptySet(),
    val isRevealed: Boolean = false,
    val isWrongShake: Boolean = false,
    val isSubtleClueUnlocked: Boolean = false,
    val subtleClueFeedback: String? = null,
    val activeClueText: String? = null,
    val hintStage: Int = 0,
    val isLoadingAi: Boolean = false,
    val victorySummary: VictorySummary? = null,
    val showLevelsDialog: Boolean = false,
    val showDailyDialog: Boolean = false,
    val showLeaderboardDialog: Boolean = false,
    val showTasksDialog: Boolean = false,
    val leaderboardEntries: List<LeaderboardEntry> = emptyList(),
    val dailyTasks: List<GameTask> = emptyList(),
    val achievements: List<GameTask> = emptyList(),
    val unclaimedTasksCount: Int = 0,
    val isDailyMode: Boolean = false,
    val dailyMultiplierLabel: String = "1.0x",
    val dailyMultiplier: Float = 1.0f,
    val isDailyCompletedToday: Boolean = false,
    val isDailyReminderEnabled: Boolean = true,
    val showProfileDialog: Boolean = false,
    val lastSavedTimestamp: String? = null
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = GamePreferences(application)
    private val soundManager = SoundManager(application)
    private val leaderboardRepo = LeaderboardRepository(application)
    private val geminiService = GeminiClueService()

    private val _uiState = MutableStateFlow(
        GameUiState(
            currentItem = QUIZ_ITEMS.first()
        )
    )
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    init {
        loadInitialState()
    }

    private fun loadInitialState() {
        val stats = prefs.loadStats()
        val solved = prefs.getSolvedIds()
        val todayStr = getTodayDateString()
        val effectiveDailyStreak = getEffectiveDailyStreak(stats, todayStr)
        val multiplier = DailyChallenges.getStreakMultiplier(effectiveDailyStreak)
        val multLabel = DailyChallenges.getMultiplierLabel(multiplier)
        val isDailyCompleted = stats.lastDailyDate == todayStr

        val candidate = QUIZ_ITEMS.firstOrNull { it.level == stats.currentLevel && !solved.contains(it.id) }
            ?: QUIZ_ITEMS.firstOrNull { it.level == stats.currentLevel }
            ?: QUIZ_ITEMS.first()

        val activeStats = stats.copy(dailyStreak = effectiveDailyStreak)
        val (daily, ach, unclaimed) = computeTasks(activeStats)
        val reminderEnabled = prefs.isDailyReminderEnabled()
        val initialSavedTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

        if (reminderEnabled) {
            com.example.notification.DailyReminderManager.scheduleDailyReminder(getApplication())
        }

        _uiState.value = _uiState.value.copy(
            userStats = activeStats,
            solvedIds = solved,
            dailyMultiplier = multiplier,
            dailyMultiplierLabel = multLabel,
            isDailyCompletedToday = isDailyCompleted,
            isDailyReminderEnabled = reminderEnabled,
            leaderboardEntries = leaderboardRepo.getLeaderboard(),
            dailyTasks = daily,
            achievements = ach,
            unclaimedTasksCount = unclaimed,
            lastSavedTimestamp = initialSavedTime
        )

        prepareItem(candidate, isDaily = false)
    }

    private fun computeTasks(stats: UserStats): Triple<List<GameTask>, List<GameTask>, Int> {
        val daily = TaskCatalog.getDailyTasks(stats)
        val ach = TaskCatalog.getLifetimeAchievements(stats)
        val unclaimed = daily.count { it.isCompleted && !it.isClaimed } + ach.count { it.isCompleted && !it.isClaimed }
        return Triple(daily, ach, unclaimed)
    }

    fun prepareItem(item: QuizItem, isDaily: Boolean = false) {
        val clean = item.cleanAnswer.uppercase()
        val slots = List<Char?>(clean.length) { null }

        val neededLetters = clean.toList().toMutableList()
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        while (neededLetters.size < 14) {
            neededLetters.add(alphabet[Random.nextInt(alphabet.length)])
        }
        neededLetters.shuffle()

        val tiles = neededLetters.mapIndexed { idx, ch ->
            TileLetter(
                id = "${ch}_${idx}_${UUID.randomUUID()}",
                char = ch,
                isUsed = false,
                isDisabled = false
            )
        }

        val isAlreadySolved = _uiState.value.solvedIds.contains(item.id)

        _uiState.value = _uiState.value.copy(
            currentItem = item,
            zoomStage = 1,
            placedLetters = slots,
            keyboardTiles = tiles,
            isRevealed = isAlreadySolved,
            isSubtleClueUnlocked = false,
            subtleClueFeedback = null,
            activeClueText = null,
            hintStage = 0,
            isDailyMode = isDaily,
            victorySummary = null
        )

        if (isAlreadySolved) {
            _uiState.value = _uiState.value.copy(
                placedLetters = clean.toList().map { it }
            )
        }
    }

    fun onKeyboardTileClicked(tile: TileLetter) {
        val state = _uiState.value
        if (state.isRevealed || tile.isUsed || tile.isDisabled) return

        val emptyIndex = state.placedLetters.indexOfFirst { it == null }
        if (emptyIndex == -1) return

        soundManager.playTap()

        val updatedSlots = state.placedLetters.toMutableList().apply {
            set(emptyIndex, tile.char)
        }
        val updatedTiles = state.keyboardTiles.map {
            if (it.id == tile.id) it.copy(isUsed = true) else it
        }

        _uiState.value = state.copy(
            placedLetters = updatedSlots,
            keyboardTiles = updatedTiles
        )

        if (!updatedSlots.contains(null)) {
            viewModelScope.launch {
                delay(120)
                evaluateGuess(updatedSlots.filterNotNull().joinToString(""))
            }
        }
    }

    fun onPlacedSlotClicked(index: Int) {
        val state = _uiState.value
        if (state.isRevealed) return

        val charToRemove = state.placedLetters.getOrNull(index) ?: return

        soundManager.playTap()

        val updatedSlots = state.placedLetters.toMutableList().apply {
            set(index, null)
        }

        var restored = false
        val updatedTiles = state.keyboardTiles.map { tile ->
            if (!restored && tile.isUsed && tile.char == charToRemove) {
                restored = true
                tile.copy(isUsed = false)
            } else {
                tile
            }
        }

        _uiState.value = state.copy(
            placedLetters = updatedSlots,
            keyboardTiles = updatedTiles
        )
    }

    fun onBackspace() {
        val state = _uiState.value
        if (state.isRevealed) return

        val lastFilledIndex = state.placedLetters.indexOfLast { it != null }
        if (lastFilledIndex == -1) return

        onPlacedSlotClicked(lastFilledIndex)
    }

    fun clearAllPlacedSlots() {
        val state = _uiState.value
        if (state.isRevealed) return

        soundManager.playTap()
        val clean = state.currentItem.cleanAnswer
        _uiState.value = state.copy(
            placedLetters = List(clean.length) { null },
            keyboardTiles = state.keyboardTiles.map { it.copy(isUsed = false) }
        )
    }

    private fun getDifficultyMultiplier(difficulty: String): Float {
        return when (difficulty.lowercase()) {
            "easy" -> 1.0f
            "medium" -> 1.25f
            "hard" -> 1.55f
            "very hard" -> 1.9f
            "extreme" -> 2.4f
            "grandmaster" -> 3.0f
            else -> 1.2f
        }
    }

    private fun evaluateGuess(guess: String) {
        val state = _uiState.value
        val item = state.currentItem
        val isCorrect = guess.equals(item.cleanAnswer, ignoreCase = true) ||
                item.aliases.any { it.replace(" ", "").equals(guess, ignoreCase = true) }

        val newTotalGuesses = state.userStats.totalGuesses + 1

        if (isCorrect) {
            soundManager.playPing()

            // 1. Stage Base Points
            val stageBase = when (state.zoomStage) {
                1 -> 600
                2 -> 420
                3 -> 280
                else -> 160
            }

            // 2. Level Multiplier: +35% per level above 1
            val levelMultiplier = 1.0f + ((item.level - 1) * 0.35f)

            // 3. Difficulty Multiplier (Easy 1.0x -> Grandmaster 3.0x)
            val diffMultiplier = getDifficultyMultiplier(item.difficulty)

            // Scaled base points
            val scaledBasePoints = (stageBase * levelMultiplier).toInt()
            val difficultyBonus = ((scaledBasePoints * diffMultiplier) - scaledBasePoints).toInt()
            val totalBaseWithDiff = scaledBasePoints + difficultyBonus

            // 4. Winning Streak Bonus
            val newStreak = state.userStats.streak + 1
            val bestStreak = maxOf(state.userStats.highestStreak, newStreak)
            val streakBonus = (newStreak - 1).coerceAtLeast(0) * 50

            // 5. Daily Streak Bonus
            val dailyBonus = if (state.isDailyMode) {
                ((totalBaseWithDiff * state.dailyMultiplier) - totalBaseWithDiff).toInt()
            } else 0

            val totalEarned = totalBaseWithDiff + streakBonus + dailyBonus

            // Scaled Coins Reward:
            val baseCoins = 30 + (item.level - 1) * 18
            val diffCoinsBonus = when (item.difficulty.lowercase()) {
                "easy" -> 0
                "medium" -> 10
                "hard" -> 25
                "very hard" -> 45
                "extreme" -> 75
                "grandmaster" -> 120
                else -> 15
            }
            val coinsEarned = if (state.isDailyMode) {
                (150 * state.dailyMultiplier).toInt()
            } else {
                baseCoins + diffCoinsBonus
            }

            val newScore = state.userStats.score + totalEarned
            val newCoins = state.userStats.coins + coinsEarned
            val newSolvedSet = state.solvedIds + item.id
            val totalSolved = newSolvedSet.size
            val newCorrectGuesses = state.userStats.correctGuesses + 1
            val newStage1Solves = if (state.zoomStage == 1) state.userStats.stage1Solves + 1 else state.userStats.stage1Solves

            // Check level unlocks
            var newUnlockedLevel = state.userStats.unlockedLevel
            var newlyUnlockedLevel: Int? = null
            val updatedUnlockedLevels = state.userStats.unlockedLevels.toMutableSet()
            for (lvl in GAME_LEVELS) {
                if (lvl.levelNumber > newUnlockedLevel) {
                    if (newScore >= lvl.requiredScore && totalSolved >= lvl.requiredSolved) {
                        newUnlockedLevel = lvl.levelNumber
                        newlyUnlockedLevel = lvl.levelNumber
                        updatedUnlockedLevels.add(lvl.levelNumber)
                        soundManager.playUnlock()
                    }
                }
            }

            // Daily tracking
            val todayStr = getTodayDateString()
            val yesterdayStr = getYesterdayDateString(todayStr)
            var newDailyStreak = state.userStats.dailyStreak
            var newHighestDailyStreak = state.userStats.highestDailyStreak
            var lastDailyDate = state.userStats.lastDailyDate
            val updatedDailyHistory = state.userStats.dailyHistory.toMutableMap()
            var newDailyCompletedCount = state.userStats.dailyCompletedCount

            if (state.isDailyMode) {
                newDailyCompletedCount++
                newDailyStreak = when (state.userStats.lastDailyDate) {
                    todayStr -> state.userStats.dailyStreak
                    yesterdayStr -> state.userStats.dailyStreak + 1
                    else -> 1
                }
                newHighestDailyStreak = maxOf(newHighestDailyStreak, newDailyStreak)
                lastDailyDate = todayStr
                updatedDailyHistory[todayStr] = DailyRecord(
                    date = todayStr,
                    itemId = item.id,
                    solved = true,
                    scoreEarned = totalEarned,
                    bonusPoints = dailyBonus,
                    zoomStage = state.zoomStage,
                    completedAt = System.currentTimeMillis().toString()
                )
            }

            val earnedXp = totalEarned + (if (state.zoomStage == 1) 50 else 20)
            val newXp = state.userStats.totalXp + earnedXp

            val updatedStats = state.userStats.copy(
                score = newScore,
                xp = newXp,
                coins = newCoins,
                unlockedLevels = updatedUnlockedLevels,
                streak = newStreak,
                highestStreak = bestStreak,
                solvedIds = newSolvedSet,
                totalGuesses = newTotalGuesses,
                correctGuesses = newCorrectGuesses,
                stage1Solves = newStage1Solves,
                dailyCompletedCount = newDailyCompletedCount,
                dailyStreak = newDailyStreak,
                highestDailyStreak = newHighestDailyStreak,
                lastDailyDate = lastDailyDate,
                dailyHistory = updatedDailyHistory
            )

            prefs.saveStats(updatedStats)
            prefs.markSolved(item.id)

            val stars = when (state.zoomStage) {
                1 -> 3
                2, 3 -> 2
                else -> 1
            }

            val summary = VictorySummary(
                basePoints = scaledBasePoints,
                streakBonus = streakBonus,
                difficultyLabel = item.difficulty,
                difficultyMultiplier = diffMultiplier,
                difficultyBonus = difficultyBonus,
                dailyStreakMultiplier = state.dailyMultiplier,
                dailyStreakBonus = dailyBonus,
                dailyStreakLabel = state.dailyMultiplierLabel,
                dailyStreakDays = newDailyStreak,
                totalEarned = totalEarned,
                coinsEarned = coinsEarned,
                stars = stars,
                newlyUnlockedLevel = newlyUnlockedLevel
            )

            val refreshedMult = DailyChallenges.getStreakMultiplier(newDailyStreak)
            val (daily, ach, unclaimed) = computeTasks(updatedStats)

            _uiState.value = state.copy(
                userStats = updatedStats,
                solvedIds = newSolvedSet,
                isRevealed = true,
                victorySummary = summary,
                dailyMultiplier = refreshedMult,
                dailyMultiplierLabel = DailyChallenges.getMultiplierLabel(refreshedMult),
                isDailyCompletedToday = (lastDailyDate == todayStr),
                dailyTasks = daily,
                achievements = ach,
                unclaimedTasksCount = unclaimed
            )
        } else {
            soundManager.playThud()
            val updatedStats = state.userStats.copy(
                streak = 0,
                totalGuesses = newTotalGuesses
            )
            prefs.saveStats(updatedStats)

            _uiState.value = state.copy(
                userStats = updatedStats,
                isWrongShake = true
            )

            viewModelScope.launch {
                delay(450)
                _uiState.value = _uiState.value.copy(isWrongShake = false)
            }
        }
    }

    fun onZoomOut() {
        val state = _uiState.value
        if (state.isRevealed || state.zoomStage >= 4) return

        soundManager.playZoom()
        _uiState.value = state.copy(zoomStage = state.zoomStage + 1)
    }

    fun getScoreBonusForCurrentStage(): Int {
        val state = _uiState.value
        val item = state.currentItem
        val base = when (state.zoomStage) {
            1 -> 600
            2 -> 420
            3 -> 280
            else -> 160
        }
        val levelMult = 1.0f + ((item.level - 1) * 0.35f)
        val diffMult = getDifficultyMultiplier(item.difficulty)
        return (base * levelMult * diffMult).toInt()
    }

    fun unlockSubtleClue() {
        val state = _uiState.value
        if (state.isSubtleClueUnlocked) return

        if (state.userStats.score >= 500) {
            soundManager.playHint()
            val newScore = state.userStats.score - 500
            val updatedStats = state.userStats.copy(
                score = newScore,
                hintsUsed = state.userStats.hintsUsed + 1
            )
            prefs.saveStats(updatedStats)
            val (daily, ach, unclaimed) = computeTasks(updatedStats)

            _uiState.value = state.copy(
                userStats = updatedStats,
                isSubtleClueUnlocked = true,
                activeClueText = state.currentItem.hints.clue1,
                subtleClueFeedback = "-500 PTS: Mystery clue unlocked!",
                dailyTasks = daily,
                achievements = ach,
                unclaimedTasksCount = unclaimed
            )
        } else {
            soundManager.playThud()
            _uiState.value = state.copy(
                subtleClueFeedback = "Need 500 PTS! Solve images to build your score."
            )
        }
    }

    fun revealOneLetter(viaAd: Boolean = false) {
        val state = _uiState.value
        if (state.isRevealed) return
        if (!viaAd && state.userStats.coins < 20) return

        val clean = state.currentItem.cleanAnswer
        var targetIndex = -1
        for (i in clean.indices) {
            if (state.placedLetters.getOrNull(i) != clean[i]) {
                targetIndex = i
                break
            }
        }
        if (targetIndex == -1) return

        soundManager.playHint()
        val correctChar = clean[targetIndex]
        val newCoins = if (viaAd) state.userStats.coins else state.userStats.coins - 20
        val updatedStats = state.userStats.copy(
            coins = newCoins,
            hintsUsed = state.userStats.hintsUsed + 1
        )
        prefs.saveStats(updatedStats)

        val updatedSlots = state.placedLetters.toMutableList().apply {
            set(targetIndex, correctChar)
        }

        var marked = false
        val updatedTiles = state.keyboardTiles.map { tile ->
            if (!marked && !tile.isUsed && tile.char == correctChar) {
                marked = true
                tile.copy(isUsed = true)
            } else {
                tile
            }
        }

        val (daily, ach, unclaimed) = computeTasks(updatedStats)

        _uiState.value = state.copy(
            userStats = updatedStats,
            placedLetters = updatedSlots,
            keyboardTiles = updatedTiles,
            dailyTasks = daily,
            achievements = ach,
            unclaimedTasksCount = unclaimed
        )

        if (!updatedSlots.contains(null)) {
            viewModelScope.launch {
                delay(120)
                evaluateGuess(updatedSlots.filterNotNull().joinToString(""))
            }
        }
    }

    fun removeThreeWrongLetters(viaAd: Boolean = false) {
        val state = _uiState.value
        if (state.isRevealed) return
        if (!viaAd && state.userStats.coins < 30) return

        val clean = state.currentItem.cleanAnswer
        val wrongTiles = state.keyboardTiles.filter { !it.isDisabled && !it.isUsed && !clean.contains(it.char) }
        if (wrongTiles.isEmpty()) return

        soundManager.playHint()
        val toDisable = wrongTiles.shuffled().take(3).map { it.id }.toSet()
        val newCoins = if (viaAd) state.userStats.coins else state.userStats.coins - 30
        val updatedStats = state.userStats.copy(
            coins = newCoins,
            hintsUsed = state.userStats.hintsUsed + 1
        )
        prefs.saveStats(updatedStats)

        val updatedTiles = state.keyboardTiles.map {
            if (toDisable.contains(it.id)) it.copy(isDisabled = true) else it
        }

        val (daily, ach, unclaimed) = computeTasks(updatedStats)

        _uiState.value = state.copy(
            userStats = updatedStats,
            keyboardTiles = updatedTiles,
            dailyTasks = daily,
            achievements = ach,
            unclaimedTasksCount = unclaimed
        )
    }

    fun requestHint(viaAd: Boolean = false) {
        val state = _uiState.value
        val hintCost = 25
        if (!viaAd && state.userStats.coins < hintCost) {
            soundManager.playThud()
            _uiState.value = state.copy(
                subtleClueFeedback = "Need $hintCost 🪙 coins for Hint, or watch a Rewarded Ad!"
            )
            return
        }

        soundManager.playHint()
        val newCoins = if (viaAd) state.userStats.coins else state.userStats.coins - hintCost
        val updatedStats = state.userStats.copy(
            coins = newCoins,
            hintsUsed = state.userStats.hintsUsed + 1
        )
        prefs.saveStats(updatedStats)

        val nextStage = state.hintStage + 1
        val item = state.currentItem
        val clue = when (nextStage) {
            1 -> item.hints.clue1
            2 -> "${item.hints.clue1}\n\n💡 Bonus Clue: ${item.hints.clue2}"
            else -> "${item.hints.clue1}\n\n💡 Bonus Clue: ${item.hints.clue2}\n\n🔍 Description: ${item.description}"
        }

        val (daily, ach, unclaimed) = computeTasks(updatedStats)
        _uiState.value = state.copy(
            userStats = updatedStats,
            hintStage = nextStage,
            activeClueText = clue,
            subtleClueFeedback = null,
            dailyTasks = daily,
            achievements = ach,
            unclaimedTasksCount = unclaimed
        )
    }

    fun addAdRewardCoins(amount: Int = 50) {
        val state = _uiState.value
        soundManager.playUnlock()
        val updatedStats = state.userStats.copy(
            coins = state.userStats.coins + amount
        )
        prefs.saveStats(updatedStats)
        val (daily, ach, unclaimed) = computeTasks(updatedStats)
        _uiState.value = state.copy(
            userStats = updatedStats,
            subtleClueFeedback = "+$amount 🪙 Coins Earned from Ad!",
            dailyTasks = daily,
            achievements = ach,
            unclaimedTasksCount = unclaimed
        )
    }

    fun requestAiClue() = requestHint()

    fun claimTaskReward(task: GameTask) {
        val state = _uiState.value
        if (task.isClaimed || !task.isCompleted) return

        soundManager.playUnlock()

        val updatedClaimed = state.userStats.claimedTaskIds + task.id
        val updatedStats = state.userStats.copy(
            score = state.userStats.score + task.rewardScore,
            xp = state.userStats.totalXp + task.rewardScore,
            coins = state.userStats.coins + task.rewardCoins,
            claimedTaskIds = updatedClaimed
        )
        prefs.saveStats(updatedStats)

        val (daily, ach, unclaimed) = computeTasks(updatedStats)

        _uiState.value = state.copy(
            userStats = updatedStats,
            dailyTasks = daily,
            achievements = ach,
            unclaimedTasksCount = unclaimed
        )
    }

    fun nextPuzzle() {
        val state = _uiState.value
        val itemsInLevel = QUIZ_ITEMS.filter { it.level == state.userStats.currentLevel }
        val unsolvedInLevel = itemsInLevel.filter { !state.solvedIds.contains(it.id) }

        val nextItem = unsolvedInLevel.firstOrNull { it.id != state.currentItem.id }
            ?: itemsInLevel.firstOrNull { it.id != state.currentItem.id }
            ?: QUIZ_ITEMS.firstOrNull { it.level <= state.userStats.unlockedLevel && !state.solvedIds.contains(it.id) }
            ?: QUIZ_ITEMS.first()

        prepareItem(nextItem, isDaily = false)
    }

    fun selectLevel(lvlNumber: Int) {
        val state = _uiState.value
        if (lvlNumber > state.userStats.unlockedLevel) return

        val updatedStats = state.userStats.copy(currentLevel = lvlNumber)
        prefs.saveStats(updatedStats)

        val items = QUIZ_ITEMS.filter { it.level == lvlNumber }
        val itemToPlay = items.firstOrNull { !state.solvedIds.contains(it.id) } ?: items.first()

        _uiState.value = state.copy(
            userStats = updatedStats,
            showLevelsDialog = false
        )
        prepareItem(itemToPlay, isDaily = false)
    }

    fun playDailyChallenge() {
        val dailyItem = DailyChallenges.getTodayDailyItem()
        _uiState.value = _uiState.value.copy(showDailyDialog = false)
        prepareItem(dailyItem, isDaily = true)
    }

    fun submitLeaderboardScore(name: String) {
        val state = _uiState.value
        val accuracy = if (state.userStats.totalGuesses > 0) {
            (state.userStats.correctGuesses * 100) / state.userStats.totalGuesses
        } else 100

        val (_, updated) = leaderboardRepo.submitScore(
            name = name,
            score = state.userStats.score,
            level = state.userStats.unlockedLevel,
            accuracy = accuracy,
            avatar = "⚡",
            streak = state.userStats.highestStreak
        )

        _uiState.value = state.copy(leaderboardEntries = updated)
    }

    fun setShowLevelsDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showLevelsDialog = show)
    }

    fun setShowDailyDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showDailyDialog = show)
    }

    fun setShowLeaderboardDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showLeaderboardDialog = show)
    }

    fun setShowTasksDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showTasksDialog = show)
    }

    fun setShowProfileDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showProfileDialog = show)
    }

    fun updateProfile(name: String, avatar: String, title: String, theme: String) {
        val currentStats = _uiState.value.userStats
        val updatedStats = currentStats.copy(
            playerName = name.ifBlank { currentStats.playerName },
            avatar = avatar,
            playerTitle = title,
            profileTheme = theme
        )
        prefs.saveStats(updatedStats, synchronous = true)
        val timeStr = SimpleDateFormat("h:mm:ss a", Locale.getDefault()).format(Date())
        _uiState.value = _uiState.value.copy(
            userStats = updatedStats,
            lastSavedTimestamp = timeStr
        )
    }

    fun saveAllProgressNow() {
        val state = _uiState.value
        prefs.saveStats(state.userStats, synchronous = true)
        state.solvedIds.forEach { prefs.markSolved(it) }
        soundManager.playUnlock()
        val timeStr = SimpleDateFormat("h:mm:ss a", Locale.getDefault()).format(Date())
        _uiState.value = state.copy(
            lastSavedTimestamp = timeStr
        )
    }

    fun dismissVictoryDialog() {
        _uiState.value = _uiState.value.copy(victorySummary = null)
    }

    // Convenience aliases
    fun onTileClick(tile: TileLetter) = onKeyboardTileClicked(tile)
    fun onRemoveLetter(index: Int) = onPlacedSlotClicked(index)
    fun onClearAll() = clearAllPlacedSlots()
    fun nextImage() = nextPuzzle()

    fun toggleDailyReminder(enabled: Boolean) {
        prefs.setDailyReminderEnabled(enabled)
        _uiState.value = _uiState.value.copy(isDailyReminderEnabled = enabled)
        if (enabled) {
            com.example.notification.DailyReminderManager.scheduleDailyReminder(getApplication())
        } else {
            com.example.notification.DailyReminderManager.cancelDailyReminder(getApplication())
        }
    }

    fun triggerTestReminder() {
        com.example.notification.DailyReminderManager.triggerTestNotification(getApplication())
    }
}

private fun getTodayDateString(): String {
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    return sdf.format(java.util.Date())
}

private fun getYesterdayDateString(today: String): String {
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    val cal = java.util.Calendar.getInstance()
    cal.time = sdf.parse(today) ?: java.util.Date()
    cal.add(java.util.Calendar.DATE, -1)
    return sdf.format(cal.time)
}

private fun getEffectiveDailyStreak(stats: UserStats, today: String): Int {
    val lastDate = stats.lastDailyDate ?: return 0
    if (lastDate == today) return stats.dailyStreak
    val yesterday = getYesterdayDateString(today)
    if (lastDate == yesterday) return stats.dailyStreak
    return 0
}
