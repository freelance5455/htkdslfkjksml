package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.data.local.IQTradeDatabase
import com.example.core.data.local.entity.AppSettingsEntity
import com.example.core.data.local.entity.MarketSyncStatusEntity
import com.example.core.data.local.entity.PaperAccountEntity
import com.example.core.data.local.entity.TradeRecordEntity
import com.example.core.data.repository.IQTradeRepository
import com.example.core.data.security.AndroidSecureCredentialStorage
import com.example.core.floating.DefaultFloatingOverlayController
import com.example.core.floating.FloatingOverlayController
import com.example.core.lifecycle.NetworkMonitor
import com.example.core.model.AppError
import com.example.core.model.ConnectionState
import com.example.core.data.chart.ChartDataAdapter
import com.example.core.data.chart.ChartDataState
import com.example.core.model.chart.Candle
import com.example.core.model.chart.ChartDrawing
import com.example.core.model.chart.DrawingType
import com.example.core.model.chart.ExecutedTradeMarker
import com.example.core.model.chart.IndicatorInstance
import com.example.core.model.chart.IndicatorType
import com.example.core.model.chart.OrderType
import com.example.core.model.chart.PriceAlertEvent
import com.example.core.model.chart.SignalMarker
import com.example.core.model.chart.SignalType
import com.example.core.model.chart.StopLossMode
import com.example.core.model.chart.TradeProtectionState
import com.example.core.model.chart.TradeSide
import com.example.core.model.Instrument
import com.example.core.model.MarketCategory
import com.example.core.model.NavSection
import com.example.core.model.Timeframe
import com.example.core.model.TradingMode
import com.example.core.analysis.persistence.AnalysisPersistenceManager
import com.example.core.analysis.pipeline.CompleteAnalysisPipeline
import com.example.core.model.analysis.CompleteAnalysisResult
import com.example.core.model.LiveTradingState
import com.example.core.network.binance.LiveAccountBalance
import com.example.core.network.binance.LiveOrderResult
import com.example.core.model.analysis.FinalAnalysisSignal
import java.util.Locale
import com.example.core.indicator.analysis.CoreAnalysisEngine
import com.example.core.indicator.persistence.IndicatorPersistenceManager
import com.example.core.model.indicator.AnalysisScoreSnapshot
import com.example.core.network.whatsapp.WhatsAppCloudApiService
import com.example.core.network.whatsapp.WhatsAppSendResult
import com.example.features.news.model.NewsArticle
import com.example.features.news.model.NewsImpact
import com.example.features.news.model.NewsSentiment
import com.example.features.news.network.NewsApiResult
import com.example.features.notifications.WhatsAppNotificationCategory
import com.example.features.notifications.WhatsAppNotificationDispatcher
import com.example.features.notifications.WhatsAppPreferences
import com.example.features.notifications.WhatsAppConnectionMethod
import com.example.features.notifications.WhatsAppConnectionStatus
import com.example.features.notifications.WhatsAppVerificationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class MainUiState(
    val currentSection: NavSection = NavSection.TERMINAL,
    // Authoritative Market & Symbol Global State
    val selectedMarket: MarketCategory = MarketCategory.CRYPTO,
    val selectedSymbol: String = "BTCUSDT",
    val selectedInstrument: Instrument? = null,
    val availableMarkets: List<MarketCategory> = MarketCategory.entries,
    val availableSymbols: List<Instrument> = emptyList(),
    val filteredSymbols: List<Instrument> = emptyList(),
    val symbolSearchQuery: String = "",
    val selectedQuoteFilter: String? = null,
    val isSymbolsLoading: Boolean = false,
    val symbolError: String? = null,
    val isSymbolDataStale: Boolean = false,
    val lastSymbolUpdateTimestamp: Long? = null,
    val isSymbolSearchOpen: Boolean = false,
    val selectedTimeframe: String = "1h",
    val tradingMode: String = "PAPER",
    // MANDATORY DEFAULT STATES: ALL DEFAULT TO OFF / FALSE
    val isSmartModeEnabled: Boolean = false,
    val isAutoTradingEnabled: Boolean = false,
    val isLiveTradingEnabled: Boolean = false,
    val liveTradingState: LiveTradingState = LiveTradingState.LIVE_TRADING_OFF,
    val liveBalance: Double = 0.0,
    val liveAvailableBalance: Double = 0.0,
    val liveBaseAssetBalance: Double = 0.0,
    val liveEquity: Double = 0.0,
    val liveUnrealizedPnl: Double = 0.0,
    val liveRealizedPnl: Double = 0.0,
    val liveTotalFees: Double = 0.0,
    val showLiveTradingConfirmation: Boolean = false,
    val showIndicators: Boolean = false,
    val showVolume: Boolean = false,
    val showSignalPlotting: Boolean = false,
    // Connection states
    val binanceConnectionState: ConnectionState = ConnectionState.Disconnected,
    val newsApiConnectionState: ConnectionState = ConnectionState.Disconnected,
    val isNetworkOnline: Boolean = true,
    // Paper Account State (persistent across restarts)
    val paperBalance: Double = 10000.0,
    val paperEquity: Double = 10000.0,
    val unrealizedPnl: Double = 0.0,
    val realizedPnl: Double = 0.0,
    // Trade history
    val trades: List<TradeRecordEntity> = emptyList(),
    // Overlay permission & floating state
    val isOverlayActive: Boolean = false,
    val hasOverlayPermission: Boolean = false,
    // Global active error banner/alert
    val currentError: AppError? = null,
    val isLoading: Boolean = false,
    val hasSavedBinanceCredentials: Boolean = false,
    val hasSavedNewsApiKey: Boolean = false,
    val savedWhatsAppPhoneNumber: String? = null,
    val savedWhatsAppApiKey: String? = null,
    val savedWhatsAppPhoneNumberId: String? = null,
    val whatsAppPreferences: WhatsAppPreferences = WhatsAppPreferences(),
    val whatsAppConnectionStatus: WhatsAppConnectionStatus = WhatsAppConnectionStatus.Disconnected,
    val whatsAppConnectionMethod: WhatsAppConnectionMethod = WhatsAppConnectionMethod.META_CLOUD_API,
    val whatsAppLastVerifiedTime: String? = null,
    val whatsAppConnectedAccount: String? = null,
    // Professional Chart System State (Module #3)
    val chartDataState: ChartDataState = ChartDataState(),
    val indicators: List<IndicatorInstance> = emptyList(),
    val drawings: List<ChartDrawing> = emptyList(),
    val activeDrawingTool: DrawingType = DrawingType.NONE,
    val executedTradeMarkers: List<ExecutedTradeMarker> = emptyList(),
    val signalMarkers: List<SignalMarker> = emptyList(),
    val activeProtectionState: TradeProtectionState? = null,
    val defaultProtectionState: TradeProtectionState = TradeProtectionState(),
    val isChartFullscreen: Boolean = false,
    val activePriceAlert: PriceAlertEvent? = null,
    val customSelectedIndicators: List<String> = listOf("EMA", "RSI", "MACD"),
    val customSelectedTimeframes: List<String> = listOf("15m", "1h", "4h"),
    val analysisScoreSnapshot: AnalysisScoreSnapshot? = null,
    val completeAnalysisResult: CompleteAnalysisResult? = null,
    val isAnalysisRefreshing: Boolean = false,
    // News System State (Module #11)
    val newsArticles: List<NewsArticle> = emptyList(),
    val isNewsLoading: Boolean = false,
    val newsErrorMessage: String? = null,
    val isNewsCache: Boolean = false,
    val newsLastUpdated: Long = 0L,
    val newsSearchQuery: String = "",
    val selectedNewsMarket: MarketCategory? = null,
    val selectedNewsSentiment: NewsSentiment? = null,
    val selectedNewsImpact: NewsImpact? = null,
    val filterOnlySelectedSymbol: Boolean = false,
    val showNewsScreen: Boolean = false
) {
    val filteredNewsArticles: List<NewsArticle> get() {
        return newsArticles.filter { article ->
            val matchesQuery = article.matchesQuery(newsSearchQuery)
            val matchesMarket = selectedNewsMarket == null || article.marketCategory == selectedNewsMarket
            val matchesSentiment = selectedNewsSentiment == null || article.sentiment == selectedNewsSentiment
            val matchesImpact = selectedNewsImpact == null || article.impact == selectedNewsImpact
            val matchesSymbol = if (filterOnlySelectedSymbol && selectedSymbol.isNotBlank()) {
                val s = selectedSymbol.replace("/", "").uppercase()
                article.relevantSymbols.any {
                    val rel = it.replace("/", "").uppercase()
                    rel.contains(s) || s.contains(rel)
                }
            } else {
                true
            }
            matchesQuery && matchesMarket && matchesSentiment && matchesImpact && matchesSymbol
        }
    }

    val currentSymbolNewsSentiment: NewsSentiment get() {
        val sym = selectedSymbol.replace("/", "").uppercase()
        val relevant = newsArticles.filter { it.relevantSymbols.any { s ->
            val rel = s.replace("/", "").uppercase()
            rel.contains(sym) || sym.contains(rel)
        } }
        if (relevant.isEmpty()) {
            val marketNews = newsArticles.filter { it.marketCategory == selectedMarket }
            if (marketNews.isEmpty()) return NewsSentiment.UNAVAILABLE
            val avgScore = marketNews.map { it.sentimentScore }.average().toInt()
            return NewsSentiment.fromScore(avgScore)
        }
        val avgScore = relevant.map { it.sentimentScore }.average().toInt()
        return NewsSentiment.fromScore(avgScore)
    }

    val currentSymbolNewsScore: Int get() {
        val sym = selectedSymbol.replace("/", "").uppercase()
        val relevant = newsArticles.filter { it.relevantSymbols.any { s ->
            val rel = s.replace("/", "").uppercase()
            rel.contains(sym) || sym.contains(rel)
        } }
        if (relevant.isEmpty()) {
            val marketNews = newsArticles.filter { it.marketCategory == selectedMarket }
            if (marketNews.isEmpty()) return 50
            return marketNews.map { it.sentimentScore }.average().toInt()
        }
        return relevant.map { it.sentimentScore }.average().toInt()
    }
    val selectedMarketId: String get() = selectedMarket.id
    val activeTradingMode: TradingMode get() = TradingMode.fromId(tradingMode)
    val openTrades: List<TradeRecordEntity> get() = trades.filter { it.isOpen }
    val closedTrades: List<TradeRecordEntity> get() = trades.filter { !it.isOpen }
    val paperTrades: List<TradeRecordEntity> get() = trades.filter { it.isPaper }
    val liveTrades: List<TradeRecordEntity> get() = trades.filter { !it.isPaper }
    val openPaperTrades: List<TradeRecordEntity> get() = trades.filter { it.isPaper && it.isOpen }
    val closedPaperTrades: List<TradeRecordEntity> get() = trades.filter { it.isPaper && !it.isOpen }
    val openLiveTrades: List<TradeRecordEntity> get() = trades.filter { !it.isPaper && it.isOpen }
    val closedLiveTrades: List<TradeRecordEntity> get() = trades.filter { !it.isPaper && !it.isOpen }
    val winRatePct: Double get() {
        val closed = closedTrades.filter { it.realizedPnl != null }
        if (closed.isEmpty()) return 0.0
        return (closed.count { (it.realizedPnl ?: 0.0) > 0 }.toDouble() / closed.size) * 100.0
    }
    val paperWinRatePct: Double get() {
        val closed = closedPaperTrades.filter { it.realizedPnl != null }
        if (closed.isEmpty()) return 0.0
        return (closed.count { (it.realizedPnl ?: 0.0) > 0 }.toDouble() / closed.size) * 100.0
    }
    val liveWinRatePct: Double get() {
        val closed = closedLiveTrades.filter { it.realizedPnl != null }
        if (closed.isEmpty()) return 0.0
        return (closed.count { (it.realizedPnl ?: 0.0) > 0 }.toDouble() / closed.size) * 100.0
    }
    val currentMarketPrice: Double get() = chartDataState.currentPrice ?: chartDataState.candles.lastOrNull()?.close ?: 0.0
}

@OptIn(ExperimentalCoroutinesApi::class)
class IQTradeViewModel(application: Application) : AndroidViewModel(application) {

    private val database = IQTradeDatabase.getInstance(application)
    private val secureStorage = AndroidSecureCredentialStorage(application)
    val repository = IQTradeRepository(database, secureStorage)
    val networkMonitor = NetworkMonitor(application)
    val floatingController: FloatingOverlayController = DefaultFloatingOverlayController()

    // Module #9 Live Trading State
    private val _liveTradingState = MutableStateFlow(LiveTradingState.LIVE_TRADING_OFF)
    private val _liveQuoteBalance = MutableStateFlow(0.0)
    private val _liveAvailableBalance = MutableStateFlow(0.0)
    private val _liveBaseAssetBalance = MutableStateFlow(0.0)
    private val _showLiveSafetyConfirmation = MutableStateFlow(false)
    private val _isLiveSyncing = MutableStateFlow(false)
    private val _activeLiveCloseMutex = java.util.concurrent.ConcurrentHashMap<Long, Boolean>()

    private val _binanceConnectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    private val _newsApiConnectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    private val _currentError = MutableStateFlow<AppError?>(null)
    private val _isLoading = MutableStateFlow(false)

    // WhatsApp reactive credentials & connection state
    val whatsAppApiService = WhatsAppCloudApiService()
    val whatsAppDispatcher = WhatsAppNotificationDispatcher(
        apiService = whatsAppApiService,
        scope = viewModelScope,
        isDeduplicatedChecker = { key, now, window -> repository.isEventDeduplicated(key, now, window) },
        recordEventSentAction = { key, timestamp -> repository.recordEventSent(key, timestamp) }
    )
    private val _savedWhatsAppPhoneNumber = MutableStateFlow<String?>(repository.getWhatsAppPhoneNumber())
    private val _savedWhatsAppApiKey = MutableStateFlow<String?>(repository.getWhatsAppApiKey())
    private val _savedWhatsAppPhoneNumberId = MutableStateFlow<String?>(repository.getWhatsAppPhoneNumberId())
    private val _whatsAppPreferences = MutableStateFlow<WhatsAppPreferences>(repository.getWhatsAppPreferences())
    private val _whatsAppConnectionMethod = MutableStateFlow<WhatsAppConnectionMethod>(
        WhatsAppConnectionMethod.fromString(repository.getWhatsAppConnectionMethod())
    )
    private val _whatsAppConnectionStatus = MutableStateFlow<WhatsAppConnectionStatus>(
        WhatsAppConnectionStatus.fromString(repository.getWhatsAppConnectionStatus())
    )
    private val _whatsAppLastVerifiedTime = MutableStateFlow<String?>(repository.getWhatsAppLastVerifiedTime())
    private val _whatsAppConnectedAccount = MutableStateFlow<String?>(repository.getWhatsAppConnectedAccount())

    // Symbol Search & Filter local reactive state
    private val _symbolSearchQuery = MutableStateFlow("")
    private val _selectedQuoteFilter = MutableStateFlow<String?>(null)
    private val _isSymbolsLoading = MutableStateFlow(false)
    private val _symbolError = MutableStateFlow<String?>(null)
    private val _isSymbolSearchOpen = MutableStateFlow(false)

    // Chart Architecture (Module #3) & Module #5 Technical Indicator System
    val chartDataAdapter = ChartDataAdapter(viewModelScope)
    private val indicatorPersistenceManager = IndicatorPersistenceManager(application)
    private val analysisPersistenceManager = AnalysisPersistenceManager(application)
    private val _analysisScoreSnapshot = MutableStateFlow<AnalysisScoreSnapshot?>(null)
    private val _completeAnalysisResult = MutableStateFlow<CompleteAnalysisResult?>(null)
    private val _isAnalysisRefreshing = MutableStateFlow(false)
    private val _indicators = MutableStateFlow<List<IndicatorInstance>>(
        indicatorPersistenceManager.getSavedChartIndicators()
    )
    private val _drawings = MutableStateFlow<List<ChartDrawing>>(emptyList())
    private val _activeDrawingTool = MutableStateFlow<DrawingType>(DrawingType.NONE)
    private val _signalMarkers = MutableStateFlow<List<SignalMarker>>(emptyList())
    private val _activeProtectionState = MutableStateFlow<TradeProtectionState?>(null)
    private val _isChartFullscreen = MutableStateFlow(false)
    private val _activePriceAlert = MutableStateFlow<PriceAlertEvent?>(null)
    private val _lastOrderTimestamps = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private data class ChartInternalState(
        val chartData: ChartDataState,
        val indicators: List<IndicatorInstance>,
        val drawings: List<ChartDrawing>,
        val drawingTool: DrawingType,
        val signals: List<SignalMarker>,
        val activeProtection: TradeProtectionState?,
        val isFullscreen: Boolean,
        val activePriceAlert: PriceAlertEvent? = null
    )

    private val chartVisualsFlow = combine(
        _indicators,
        _drawings,
        _activeDrawingTool,
        _signalMarkers
    ) { indicators, drawings, tool, signals ->
        Triple(indicators, drawings, Pair(tool, signals))
    }

    private val chartInternalFlow = combine(
        chartDataAdapter.state,
        chartVisualsFlow,
        _activeProtectionState,
        _isChartFullscreen,
        _activePriceAlert
    ) { chartData, visuals, protection, isFullscreen, alert ->
        val (indicators, drawings, toolSignals) = visuals
        val (tool, signals) = toolSignals
        ChartInternalState(chartData, indicators, drawings, tool, signals, protection, isFullscreen, alert)
    }

    // News System State Flows (Module #11)
    private val _newsArticles = MutableStateFlow<List<NewsArticle>>(emptyList())
    private val _isNewsLoading = MutableStateFlow<Boolean>(false)
    private val _newsErrorMessage = MutableStateFlow<String?>(null)
    private val _isNewsCache = MutableStateFlow<Boolean>(false)
    private val _newsLastUpdated = MutableStateFlow<Long>(0L)
    private val _newsSearchQuery = MutableStateFlow<String>("")
    private val _selectedNewsMarket = MutableStateFlow<MarketCategory?>(null)
    private val _selectedNewsSentiment = MutableStateFlow<NewsSentiment?>(null)
    private val _selectedNewsImpact = MutableStateFlow<NewsImpact?>(null)
    private val _filterOnlySelectedSymbol = MutableStateFlow<Boolean>(false)
    private val _showNewsScreen = MutableStateFlow<Boolean>(false)

    private data class NewsInternalState(
        val articles: List<NewsArticle> = emptyList(),
        val isLoading: Boolean = false,
        val errorMessage: String? = null,
        val isCache: Boolean = false,
        val lastUpdated: Long = 0L,
        val searchQuery: String = "",
        val selectedMarket: MarketCategory? = null,
        val selectedSentiment: NewsSentiment? = null,
        val selectedImpact: NewsImpact? = null,
        val filterOnlySelectedSymbol: Boolean = false,
        val showNewsScreen: Boolean = false
    )

    private val newsInternalFlow = combine(
        combine(_newsArticles, _isNewsLoading, _newsErrorMessage, _isNewsCache) { a, b, c, d ->
            listOf(a, b, c, d)
        },
        combine(_newsLastUpdated, _newsSearchQuery, _selectedNewsMarket, _selectedNewsSentiment) { e, f, g, h ->
            listOf(e, f, g, h)
        },
        combine(_selectedNewsImpact, _filterOnlySelectedSymbol, _showNewsScreen) { i, j, k ->
            listOf(i, j, k)
        }
    ) { group1, group2, group3 ->
        @Suppress("UNCHECKED_CAST")
        NewsInternalState(
            articles = group1[0] as List<NewsArticle>,
            isLoading = group1[1] as Boolean,
            errorMessage = group1[2] as? String,
            isCache = group1[3] as Boolean,
            lastUpdated = group2[0] as Long,
            searchQuery = group2[1] as String,
            selectedMarket = group2[2] as? MarketCategory,
            selectedSentiment = group2[3] as? NewsSentiment,
            selectedImpact = group3[0] as? NewsImpact,
            filterOnlySelectedSymbol = group3[1] as Boolean,
            showNewsScreen = group3[2] as Boolean
        )
    }

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfNeeded()
            // Module #9 Invariant: Live trading is ALWAYS strictly OFF on startup/restart
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
            repository.setLiveTrading(false)
            val settings = repository.getSettings()
            if (settings.newsApiConnected && repository.hasNewsApiKey()) {
                _newsApiConnectionState.value = ConnectionState.Connected
            }
            // Module #11: Initialize offline news cache and fetch latest news
            val cachedNews = repository.getCachedNews()
            if (cachedNews.isNotEmpty()) {
                _newsArticles.value = cachedNews
                _isNewsCache.value = true
                _newsLastUpdated.value = cachedNews.maxOfOrNull { it.cachedAt } ?: 0L
            }
            if (repository.hasNewsApiKey() && (settings.newsApiConnected || _newsArticles.value.isEmpty())) {
                fetchNews()
            }
            if (settings.binanceConnected && repository.hasBinanceCredentials()) {
                _binanceConnectionState.value = ConnectionState.Connected
                refreshLiveAccountBalances()
                reconcileOpenLiveOrdersWithExchange()
            }
        }
        viewModelScope.launch {
            repository.settingsFlow
                .map { Triple(it.selectedMarket, it.selectedSymbol, it.selectedTimeframe) }
                .distinctUntilChanged()
                .collect { (marketStr, symbolStr, tfStr) ->
                    val market = MarketCategory.fromId(marketStr)
                    val tf = Timeframe.fromLabel(tfStr)
                    chartDataAdapter.loadData(market, symbolStr, tf)
                }
        }
        viewModelScope.launch {
            chartDataAdapter.state
                .map { it.candles }
                .distinctUntilChanged()
                .collect { candles ->
                    val sym = chartDataAdapter.state.value.selectedSymbol
                    val tf = chartDataAdapter.state.value.selectedTimeframe.label
                    val market = chartDataAdapter.state.value.selectedMarket.displayName
                    if (candles.isNotEmpty()) {
                        val isNewsConnected = repository.hasNewsApiKey() && _newsApiConnectionState.value == ConnectionState.Connected
                        val relevantNews = _newsArticles.value.filter { article ->
                            article.relevantSymbols.any { it.equals(sym, ignoreCase = true) || it.contains(sym, ignoreCase = true) }
                        }.ifEmpty {
                            _newsArticles.value.filter { it.marketCategory.displayName.equals(market, ignoreCase = true) }
                        }
                        val sentimentScore = if (relevantNews.isNotEmpty()) {
                            relevantNews.map { it.sentimentScore }.average().toInt().coerceIn(0, 100)
                        } else null
                        val latestArticle = relevantNews.maxByOrNull { it.publishedAt }

                        val completeResult = withContext(Dispatchers.Default) {
                            CompleteAnalysisPipeline.executeAnalysis(
                                symbol = sym,
                                market = market,
                                candles = candles,
                                isNewsConnected = isNewsConnected,
                                newsSentimentScore = sentimentScore,
                                newsHeadline = latestArticle?.headline,
                                newsSource = latestArticle?.source,
                                activeTimeframe = tf
                            )
                        }
                        _completeAnalysisResult.value = completeResult
                        _analysisScoreSnapshot.value = completeResult.coreSnapshot
                        analysisPersistenceManager.updateLastAnalysisTimestamp(completeResult.timestamp)
                        evaluateSmartAutoTradeSignal()
                    }
                    if (candles.size >= 14) {
                        val generated = generateSignalsFromCandles(candles, sym, tf)
                        _signalMarkers.value = generated
                        // Real-time WhatsApp Notification Dispatch for latest signal
                        val latestSignal = generated.lastOrNull()
                        if (latestSignal != null) {
                            val eventKey = "${latestSignal.symbol}_SIGNAL_${latestSignal.type.name}_${latestSignal.timestamp}"
                            val signalText = when (latestSignal.type) {
                                SignalType.BULLISH -> "🟢 BULLISH / BUY"
                                SignalType.BEARISH -> "🔴 BEARISH / SELL"
                                else -> "⚪ NEUTRAL / WAIT"
                            }
                            val timeStr = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).apply {
                                timeZone = java.util.TimeZone.getTimeZone("UTC")
                            }.format(java.util.Date(latestSignal.timestamp))
                            val body = "IQTrade Pro\nSignal Alert\nMarket: $sym\nSymbol: ${latestSignal.symbol}\nSignal: $signalText\nConfidence: ${latestSignal.confidencePct}%\nTime: $timeStr UTC\nCurrent Price: $${latestSignal.price}\nTimeframe: $tf"
                            whatsAppDispatcher.dispatchNotification(
                                category = WhatsAppNotificationCategory.TRADE_SIGNAL,
                                eventKey = eventKey,
                                message = body,
                                preferences = _whatsAppPreferences.value,
                                recipientPhone = _savedWhatsAppPhoneNumber.value,
                                apiKey = _savedWhatsAppApiKey.value,
                                phoneNumberId = _savedWhatsAppPhoneNumberId.value
                            )
                        }
                    }
                }
        }
        viewModelScope.launch {
            chartDataAdapter.state
                .map { Pair(it.selectedSymbol, it.currentPrice) }
                .distinctUntilChanged()
                .collect { (symbol, price) ->
                    if (price != null && price > 0.0) {
                        evaluatePaperPositionsProtection(symbol, price)
                        evaluateLivePositionsProtection(symbol, price)
                    }
                }
        }
    }

    private val currentMarketSymbolsFlow = repository.settingsFlow
        .map { MarketCategory.fromId(it.selectedMarket) }
        .distinctUntilChanged()
        .flatMapLatest { category ->
            repository.symbolRepository.getSymbolsFlow(category)
        }

    private val currentMarketSyncFlow = repository.settingsFlow
        .map { MarketCategory.fromId(it.selectedMarket) }
        .distinctUntilChanged()
        .flatMapLatest { category ->
            repository.symbolRepository.getSyncStatusFlow(category)
        }

    val uiState: StateFlow<MainUiState> = combine(
        repository.settingsFlow,
        repository.paperAccountFlow,
        repository.tradeHistoryFlow,
        networkMonitor.isOnlineFlow,
        _binanceConnectionState,
        _currentError,
        _isLoading,
        currentMarketSymbolsFlow,
        currentMarketSyncFlow,
        _symbolSearchQuery,
        _selectedQuoteFilter,
        _isSymbolsLoading,
        _symbolError,
        _isSymbolSearchOpen,
        _savedWhatsAppPhoneNumber,
        _savedWhatsAppApiKey,
        _savedWhatsAppPhoneNumberId,
        _whatsAppPreferences,
        chartInternalFlow,
        _whatsAppConnectionStatus,
        _whatsAppConnectionMethod,
        _whatsAppLastVerifiedTime,
        _whatsAppConnectedAccount,
        _analysisScoreSnapshot,
        _completeAnalysisResult,
        _isAnalysisRefreshing,
        newsInternalFlow
    ) { params: Array<Any?> ->
        val settings = params[0] as AppSettingsEntity
        val paper = params[1] as PaperAccountEntity
        @Suppress("UNCHECKED_CAST")
        val trades = params[2] as List<TradeRecordEntity>
        val isOnline = params[3] as Boolean
        val binanceState = params[4] as ConnectionState
        val currentErr = params[5] as? AppError
        val loading = params[6] as Boolean
        @Suppress("UNCHECKED_CAST")
        val symbols = params[7] as List<Instrument>
        val syncStatus = params[8] as? MarketSyncStatusEntity
        val searchQuery = params[9] as String
        val quoteFilter = params[10] as? String
        val symbolsLoading = params[11] as Boolean
        val symbolErr = params[12] as? String
        val searchOpen = params[13] as Boolean
        val whatsAppPhone = params[14] as? String
        val whatsAppKey = params[15] as? String
        val whatsAppPhoneId = params[16] as? String
        val whatsAppPrefs = (params[17] as? WhatsAppPreferences) ?: WhatsAppPreferences()
        val chartInternal = params[18] as ChartInternalState
        val whatsAppStatus = (params[19] as? WhatsAppConnectionStatus) ?: WhatsAppConnectionStatus.Disconnected
        val whatsAppMethod = (params[20] as? WhatsAppConnectionMethod) ?: WhatsAppConnectionMethod.META_CLOUD_API
        val whatsAppLastVerified = params[21] as? String
        val whatsAppAccount = params[22] as? String
        val analysisSnapshot = params[23] as? AnalysisScoreSnapshot
        val completeAnalysis = params[24] as? CompleteAnalysisResult
        val isRefreshing = params[25] as? Boolean ?: false
        val newsInternal = (params[26] as? NewsInternalState) ?: NewsInternalState()

        val currentNavSection = try {
            NavSection.valueOf(settings.selectedSection)
        } catch (_: Exception) {
            NavSection.TERMINAL
        }

        val market = MarketCategory.fromId(settings.selectedMarket)

        // Find selected instrument or default to first valid instrument
        val selectedInstrument = symbols.firstOrNull { it.symbolId.equals(settings.selectedSymbol, ignoreCase = true) }
            ?: if (symbols.isNotEmpty()) symbols.first() else null

        // Apply fast mobile-friendly search and quote filter
        val filtered = symbols.filter { instrument ->
            val matchesQuery = instrument.matchesQuery(searchQuery)
            val matchesQuote = if (quoteFilter == null || quoteFilter == "ALL") {
                true
            } else if (quoteFilter.equals("Bullion", ignoreCase = true)) {
                instrument.symbolId.contains("100OZ", ignoreCase = true) || instrument.symbolId.contains("1KG", ignoreCase = true)
            } else {
                instrument.quoteAsset.equals(quoteFilter, ignoreCase = true)
            }
            matchesQuery && matchesQuote
        }

        val isStale = syncStatus?.status == "STALE_CACHE" || !isOnline

        val executedMarkers = trades.map { t ->
            ExecutedTradeMarker(
                id = t.id.toString(),
                symbol = t.symbol,
                side = if (t.side == "BUY") TradeSide.BUY else TradeSide.SELL,
                entryPrice = t.price,
                entryTime = t.timestamp / 1000L,
                stopLossPrice = t.stopLoss,
                takeProfitPrice = t.takeProfit,
                isOpen = t.isOpen,
                isPaper = t.isPaper,
                quantity = t.quantity
            )
        }

        val defaultProtection = TradeProtectionState(
            stopLossMode = try { StopLossMode.valueOf(settings.defaultStopLossMode) } catch (_: Exception) { StopLossMode.FIXED },
            stopLossPercentage = settings.defaultStopLossPct,
            trailingDistancePct = settings.defaultTrailingDistancePct,
            takeProfitPercentage = settings.defaultTakeProfitPct
        )

        val liveExitPrice = chartInternal.chartData.currentPrice ?: chartInternal.chartData.candles.lastOrNull()?.close ?: 0.0
        val paperUnrealizedPnl = trades.filter { it.isPaper && it.isOpen }.sumOf { trade ->
            val exitP = if (trade.symbol.equals(chartInternal.chartData.selectedSymbol, ignoreCase = true) && liveExitPrice > 0.0) {
                liveExitPrice
            } else {
                trade.price
            }
            if (trade.side.equals("BUY", ignoreCase = true)) {
                (exitP - trade.price) * trade.quantity
            } else {
                (trade.price - exitP) * trade.quantity
            }
        }
        val paperEquity = paper.balance + paperUnrealizedPnl

        val liveUnrealizedPnl = trades.filter { !it.isPaper && it.isOpen }.sumOf { trade ->
            val exitP = if (trade.symbol.equals(chartInternal.chartData.selectedSymbol, ignoreCase = true) && liveExitPrice > 0.0) {
                liveExitPrice
            } else {
                trade.price
            }
            val qty = trade.executedQuantity ?: trade.quantity
            if (trade.side.equals("BUY", ignoreCase = true)) {
                (exitP - trade.price) * qty
            } else {
                (trade.price - exitP) * qty
            }
        }
        val liveRealizedPnl = trades.filter { !it.isPaper && !it.isOpen }.sumOf { it.realizedPnl ?: 0.0 }
        val liveFees = trades.filter { !it.isPaper }.sumOf { it.commission ?: 0.0 }
        val currentLiveBal = _liveQuoteBalance.value
        val liveEquity = currentLiveBal + liveUnrealizedPnl
        val isLiveTradingArmed = _liveTradingState.value == LiveTradingState.LIVE_TRADING_ENABLED && settings.isLiveTradingEnabled

        MainUiState(
            currentSection = currentNavSection,
            selectedMarket = market,
            selectedSymbol = selectedInstrument?.symbolId ?: settings.selectedSymbol,
            selectedInstrument = selectedInstrument,
            availableMarkets = MarketCategory.entries,
            availableSymbols = symbols,
            filteredSymbols = filtered,
            symbolSearchQuery = searchQuery,
            selectedQuoteFilter = quoteFilter,
            isSymbolsLoading = symbolsLoading,
            symbolError = symbolErr ?: syncStatus?.errorMessage,
            isSymbolDataStale = isStale,
            lastSymbolUpdateTimestamp = syncStatus?.lastSyncTimestamp,
            isSymbolSearchOpen = searchOpen,
            selectedTimeframe = settings.selectedTimeframe,
            tradingMode = settings.tradingMode,
            isSmartModeEnabled = settings.isSmartModeEnabled,
            isAutoTradingEnabled = settings.isAutoTradingEnabled,
            isLiveTradingEnabled = isLiveTradingArmed,
            liveTradingState = _liveTradingState.value,
            liveBalance = currentLiveBal,
            liveAvailableBalance = _liveAvailableBalance.value,
            liveBaseAssetBalance = _liveBaseAssetBalance.value,
            liveEquity = liveEquity,
            liveUnrealizedPnl = liveUnrealizedPnl,
            liveRealizedPnl = liveRealizedPnl,
            liveTotalFees = liveFees,
            showLiveTradingConfirmation = _showLiveSafetyConfirmation.value,
            showIndicators = settings.showIndicators,
            showVolume = settings.showVolume,
            showSignalPlotting = settings.showSignalPlotting,
            binanceConnectionState = binanceState,
            newsApiConnectionState = _newsApiConnectionState.value,
            isNetworkOnline = isOnline,
            paperBalance = paper.balance,
            paperEquity = paperEquity,
            unrealizedPnl = paperUnrealizedPnl,
            realizedPnl = paper.realizedPnl,
            trades = trades,
            isOverlayActive = floatingController.isOverlayActive.value,
            hasOverlayPermission = floatingController.checkPermission(getApplication()),
            currentError = if (!isOnline) AppError.NoInternet else currentErr,
            isLoading = loading,
            hasSavedBinanceCredentials = repository.hasBinanceCredentials(),
            hasSavedNewsApiKey = repository.hasNewsApiKey(),
            savedWhatsAppPhoneNumber = whatsAppPhone,
            savedWhatsAppApiKey = whatsAppKey,
            savedWhatsAppPhoneNumberId = whatsAppPhoneId,
            whatsAppPreferences = whatsAppPrefs,
            whatsAppConnectionStatus = whatsAppStatus,
            whatsAppConnectionMethod = whatsAppMethod,
            whatsAppLastVerifiedTime = whatsAppLastVerified,
            whatsAppConnectedAccount = whatsAppAccount,
            chartDataState = chartInternal.chartData,
            indicators = chartInternal.indicators,
            drawings = chartInternal.drawings,
            activeDrawingTool = chartInternal.drawingTool,
            executedTradeMarkers = executedMarkers,
            signalMarkers = chartInternal.signals,
            activeProtectionState = chartInternal.activeProtection,
            defaultProtectionState = defaultProtection,
            isChartFullscreen = chartInternal.isFullscreen,
            activePriceAlert = chartInternal.activePriceAlert,
            customSelectedIndicators = settings.customSelectedIndicators.split(",").map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("EMA", "RSI", "MACD") },
            customSelectedTimeframes = settings.customSelectedTimeframes.split(",").map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf("15m", "1h", "4h") },
            analysisScoreSnapshot = analysisSnapshot,
            completeAnalysisResult = completeAnalysis,
            isAnalysisRefreshing = isRefreshing,
            newsArticles = newsInternal.articles,
            isNewsLoading = newsInternal.isLoading,
            newsErrorMessage = newsInternal.errorMessage,
            isNewsCache = newsInternal.isCache,
            newsLastUpdated = newsInternal.lastUpdated,
            newsSearchQuery = newsInternal.searchQuery,
            selectedNewsMarket = newsInternal.selectedMarket,
            selectedNewsSentiment = newsInternal.selectedSentiment,
            selectedNewsImpact = newsInternal.selectedImpact,
            filterOnlySelectedSymbol = newsInternal.filterOnlySelectedSymbol,
            showNewsScreen = newsInternal.showNewsScreen
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MainUiState()
    )

    fun navigateTo(section: NavSection) {
        viewModelScope.launch {
            repository.updateSelectedSection(section.name)
        }
    }

    /**
     * Module #6 — Refreshes complete analysis pipeline on background dispatcher.
     */
    fun refreshCompleteAnalysis() {
        viewModelScope.launch {
            _isAnalysisRefreshing.value = true
            val candles = chartDataAdapter.state.value.candles
            val sym = chartDataAdapter.state.value.selectedSymbol
            val tf = chartDataAdapter.state.value.selectedTimeframe.label
            val market = chartDataAdapter.state.value.selectedMarket.displayName
            val isNewsConnected = repository.hasNewsApiKey() && _newsApiConnectionState.value == ConnectionState.Connected
            if (candles.isNotEmpty()) {
                val relevantNews = _newsArticles.value.filter { article ->
                    article.relevantSymbols.any { it.equals(sym, ignoreCase = true) || it.contains(sym, ignoreCase = true) }
                }.ifEmpty {
                    _newsArticles.value.filter { it.marketCategory.displayName.equals(market, ignoreCase = true) }
                }
                val sentimentScore = if (relevantNews.isNotEmpty()) {
                    relevantNews.map { it.sentimentScore }.average().toInt().coerceIn(0, 100)
                } else null
                val latestArticle = relevantNews.maxByOrNull { it.publishedAt }

                val completeResult = withContext(Dispatchers.Default) {
                    CompleteAnalysisPipeline.executeAnalysis(
                        symbol = sym,
                        market = market,
                        candles = candles,
                        isNewsConnected = isNewsConnected,
                        newsSentimentScore = sentimentScore,
                        newsHeadline = latestArticle?.headline,
                        newsSource = latestArticle?.source,
                        activeTimeframe = tf
                    )
                }
                _completeAnalysisResult.value = completeResult
                _analysisScoreSnapshot.value = completeResult.coreSnapshot
                analysisPersistenceManager.updateLastAnalysisTimestamp(completeResult.timestamp)
                evaluateSmartAutoTradeSignal()
            }
            kotlinx.coroutines.delay(350)
            _isAnalysisRefreshing.value = false
        }
    }

    /**
     * Authoritative Market switching.
     * Updates selected market, resets search, sets market's default symbol.
     * STRICT INVARIANT: Smart Mode, Auto Trading, Live Trading, and Indicators remain strictly OFF.
     * Never triggers an order.
     */
    fun selectMarket(market: MarketCategory) {
        viewModelScope.launch {
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
            repository.setLiveTrading(false)
            _symbolSearchQuery.value = ""
            _selectedQuoteFilter.value = null
            repository.updateMarketAndSymbol(market.id, market.defaultSymbolId)
        }
    }

    /**
     * Authoritative Symbol selection.
     * Updates selected symbol, preserves selected market.
     * STRICT INVARIANT: Does not reset unrelated settings, never triggers an order.
     */
    fun selectInstrument(instrument: Instrument) {
        viewModelScope.launch {
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
            repository.setLiveTrading(false)
            repository.updateMarketAndSymbol(instrument.marketCategory.id, instrument.symbolId)
            _isSymbolSearchOpen.value = false
        }
    }

    fun selectMarketAndSymbol(market: String, symbol: String) {
        viewModelScope.launch {
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
            repository.setLiveTrading(false)
            val category = MarketCategory.fromId(market)
            repository.updateMarketAndSymbol(category.id, symbol)
        }
    }

    fun setSymbolSearchQuery(query: String) {
        _symbolSearchQuery.value = query
    }

    fun setSelectedQuoteFilter(quote: String?) {
        _selectedQuoteFilter.value = quote
    }

    fun setSymbolSearchOpen(isOpen: Boolean) {
        _isSymbolSearchOpen.value = isOpen
    }

    fun refreshSymbols(category: MarketCategory? = null) {
        viewModelScope.launch {
            _isSymbolsLoading.value = true
            _symbolError.value = null
            val targetMarket = category ?: uiState.value.selectedMarket
            val result = repository.symbolRepository.refreshSymbols(targetMarket)
            if (result.isFailure) {
                _symbolError.value = result.exceptionOrNull()?.message ?: "Failed to refresh symbols"
            }
            _isSymbolsLoading.value = false
        }
    }

    fun selectTimeframe(timeframe: String) {
        viewModelScope.launch {
            repository.updateTimeframe(timeframe)
        }
    }

    fun setTradingMode(mode: String) {
        viewModelScope.launch {
            repository.updateTradingMode(mode)
        }
    }

    fun selectTradingMode(mode: TradingMode) {
        viewModelScope.launch {
            if (mode != TradingMode.LIVE_TRADE) {
                _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
                repository.setLiveTrading(false)
            }
            repository.updateTradingMode(mode.id)
            if (mode == TradingMode.ONLY_SIGNAL) {
                repository.setSignalPlottingVisible(true)
            }
            // Preserves symbol and timeframe intact across all mode changes
        }
    }

    fun updateCustomModeConfig(indicators: List<String>, timeframes: List<String>) {
        viewModelScope.launch {
            repository.updateCustomConfig(
                indicators = indicators.joinToString(","),
                timeframes = timeframes.joinToString(",")
            )
        }
    }

    fun saveProtectionSettings(protection: TradeProtectionState) {
        _activeProtectionState.value = protection
    }

    fun executeOneClickScalpOrder(side: TradeSide) {
        val current = uiState.value
        if (current.activeTradingMode == TradingMode.ONLY_SIGNAL) return
        val currentPrice = current.chartDataState.currentPrice ?: 0.0
        if (currentPrice <= 0.0) return
        val defaultQty = 0.01
        val scalpProtection = TradeProtectionState(
            stopLossMode = StopLossMode.FIXED,
            stopLossPercentage = 0.5,
            isTakeProfitEnabled = true,
            takeProfitPercentage = 1.0,
            entryPrice = currentPrice,
            currentPrice = currentPrice,
            quantity = defaultQty,
            side = side,
            accountBalance = current.paperBalance
        )
        executeOrder(side, OrderType.MARKET, currentPrice, defaultQty, scalpProtection)
    }

    fun toggleSmartMode(enabled: Boolean) {
        viewModelScope.launch {
            repository.setSmartMode(enabled)
        }
    }

    fun toggleAutoTrading(enabled: Boolean) {
        viewModelScope.launch {
            repository.setAutoTrading(enabled)
        }
    }

    fun requestLiveTradingAuthorization() {
        _showLiveSafetyConfirmation.value = true
    }

    fun toggleLiveTrading(enabled: Boolean) {
        if (enabled) {
            confirmLiveTradingAuthorization()
        } else {
            disableLiveTrading()
        }
    }

    fun confirmLiveTradingAuthorization() {
        viewModelScope.launch {
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_ENABLED
            repository.setLiveTrading(true)
            _showLiveSafetyConfirmation.value = false
            refreshLiveAccountBalances()
        }
    }

    fun dismissLiveTradingAuthorization() {
        viewModelScope.launch {
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
            repository.setLiveTrading(false)
            _showLiveSafetyConfirmation.value = false
        }
    }

    fun disableLiveTrading() {
        viewModelScope.launch {
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
            repository.setLiveTrading(false)
            _showLiveSafetyConfirmation.value = false
        }
    }

    fun toggleIndicators(visible: Boolean) {
        viewModelScope.launch {
            repository.setIndicatorsVisible(visible)
        }
    }

    fun toggleVolume(visible: Boolean) {
        viewModelScope.launch {
            repository.setVolumeVisible(visible)
        }
    }

    fun toggleSignalPlotting(visible: Boolean) {
        viewModelScope.launch {
            repository.setSignalPlottingVisible(visible)
        }
    }

    fun saveBinanceCredentials(apiKey: String, secretKey: String) {
        if (apiKey.isBlank() || secretKey.isBlank()) {
            _currentError.value = AppError.InvalidConfiguration
            return
        }
        repository.saveBinanceCredentials(apiKey, secretKey)
    }

    fun connectBinanceTest() {
        if (!repository.hasBinanceCredentials()) {
            _currentError.value = AppError.AuthenticationFailure
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            _binanceConnectionState.value = ConnectionState.Connecting
            kotlinx.coroutines.delay(1200)
            _isLoading.value = false
            _binanceConnectionState.value = ConnectionState.Connected
            repository.setBinanceConnected(true)
            refreshLiveAccountBalances()
            reconcileOpenLiveOrdersWithExchange()
        }
    }

    fun disconnectBinance() {
        viewModelScope.launch {
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
            repository.setLiveTrading(false)
            _binanceConnectionState.value = ConnectionState.Disconnected
            repository.setBinanceConnected(false)
            _liveQuoteBalance.value = 0.0
            _liveAvailableBalance.value = 0.0
            _liveBaseAssetBalance.value = 0.0
        }
    }

    fun clearBinanceCredentials() {
        _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
        repository.clearBinanceCredentials()
        disconnectBinance()
    }

    // --- News API Configuration & Feed Operations (Module #11) ---

    fun saveNewsApiCredentials(apiKey: String) {
        if (apiKey.isBlank()) {
            _currentError.value = AppError.InvalidConfiguration
            return
        }
        repository.saveNewsApiKey(apiKey.trim())
    }

    fun fetchNews(forceRefresh: Boolean = false) {
        val apiKey = repository.getNewsApiKey()
        if (apiKey.isNullOrBlank()) {
            _newsErrorMessage.value = "News API Key Required — Configure in Binance > News API tab"
            viewModelScope.launch {
                val cached = repository.getCachedNews()
                if (cached.isNotEmpty()) {
                    _newsArticles.value = cached
                    _isNewsCache.value = true
                }
            }
            return
        }

        viewModelScope.launch {
            _isNewsLoading.value = true
            _newsErrorMessage.value = null

            val result = repository.fetchLiveNews(apiKey)
            when (result) {
                is NewsApiResult.Success -> {
                    _newsArticles.value = result.articles
                    _isNewsCache.value = false
                    _newsLastUpdated.value = System.currentTimeMillis()
                    _newsApiConnectionState.value = ConnectionState.Connected
                    repository.setNewsApiConnected(true)
                    repository.saveCachedNews(result.articles)
                    checkAndDispatchNewsAlerts(result.articles)
                    updateAnalysisWithNewsData()
                }
                is NewsApiResult.Error -> {
                    _newsErrorMessage.value = result.message
                    val cached = repository.getCachedNews()
                    if (cached.isNotEmpty()) {
                        _newsArticles.value = cached
                        _isNewsCache.value = true
                    }
                    if (result.statusCode == 401 || result.statusCode == 403) {
                        _newsApiConnectionState.value = ConnectionState.Error(result.message)
                    }
                }
                is NewsApiResult.NetworkError -> {
                    _newsErrorMessage.value = result.message
                    val cached = repository.getCachedNews()
                    if (cached.isNotEmpty()) {
                        _newsArticles.value = cached
                        _isNewsCache.value = true
                    }
                }
            }
            _isNewsLoading.value = false
        }
    }

    fun connectNewsApiTest() {
        if (!repository.hasNewsApiKey()) {
            _currentError.value = AppError.AuthenticationFailure
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            _isNewsLoading.value = true
            _newsApiConnectionState.value = ConnectionState.Connecting
            val result = repository.fetchLiveNews()
            _isLoading.value = false
            _isNewsLoading.value = false
            when (result) {
                is NewsApiResult.Success -> {
                    _newsArticles.value = result.articles
                    _isNewsCache.value = false
                    _newsLastUpdated.value = System.currentTimeMillis()
                    _newsApiConnectionState.value = ConnectionState.Connected
                    repository.setNewsApiConnected(true)
                    repository.saveCachedNews(result.articles)
                    checkAndDispatchNewsAlerts(result.articles)
                    updateAnalysisWithNewsData()
                }
                is NewsApiResult.Error -> {
                    _newsApiConnectionState.value = ConnectionState.Error(result.message)
                    _newsErrorMessage.value = result.message
                    val cached = repository.getCachedNews()
                    if (cached.isNotEmpty()) {
                        _newsArticles.value = cached
                        _isNewsCache.value = true
                    }
                }
                is NewsApiResult.NetworkError -> {
                    _newsApiConnectionState.value = ConnectionState.Error(result.message)
                    _newsErrorMessage.value = result.message
                    val cached = repository.getCachedNews()
                    if (cached.isNotEmpty()) {
                        _newsArticles.value = cached
                        _isNewsCache.value = true
                    }
                }
            }
        }
    }

    fun disconnectNewsApi() {
        viewModelScope.launch {
            _newsApiConnectionState.value = ConnectionState.Disconnected
            repository.setNewsApiConnected(false)
        }
    }

    fun toggleNewsApiConnection(connect: Boolean) {
        if (connect) {
            connectNewsApiTest()
        } else {
            disconnectNewsApi()
        }
    }

    fun clearNewsApiCredentials() {
        repository.clearNewsApiKey()
        disconnectNewsApi()
    }

    fun setNewsSearchQuery(query: String) {
        _newsSearchQuery.value = query
    }

    fun setSelectedNewsMarket(market: MarketCategory?) {
        _selectedNewsMarket.value = market
    }

    fun setSelectedNewsSentiment(sentiment: NewsSentiment?) {
        _selectedNewsSentiment.value = sentiment
    }

    fun setSelectedNewsImpact(impact: NewsImpact?) {
        _selectedNewsImpact.value = impact
    }

    fun toggleFilterOnlySelectedSymbol(enabled: Boolean) {
        _filterOnlySelectedSymbol.value = enabled
    }

    fun setShowNewsScreen(show: Boolean) {
        _showNewsScreen.value = show
    }

    private fun checkAndDispatchNewsAlerts(articles: List<NewsArticle>) {
        val prefs = repository.getWhatsAppPreferences()
        if (!prefs.notifyOnNews) return

        val highImpactOrBreaking = articles.filter { it.isBreaking || it.impact == NewsImpact.HIGH }
        val now = System.currentTimeMillis()

        val alertCandidate = highImpactOrBreaking.firstOrNull { article ->
            val eventKey = "NEWS_ALERT_${article.id}"
            !repository.isEventDeduplicated(eventKey, now, 3600_000L)
        }

        alertCandidate?.let { article ->
            val symbolTag = article.relevantSymbols.firstOrNull() ?: article.marketCategory.name
            dispatchNewsAlert(
                headline = article.headline,
                source = article.source,
                sentiment = "${article.sentiment.displayBadge} (Score: ${article.sentimentScore})",
                symbol = symbolTag
            )
            repository.recordEventSent("NEWS_ALERT_${article.id}", now)
        }
    }

    private fun updateAnalysisWithNewsData() {
        val sym = chartDataAdapter.state.value.selectedSymbol
        val market = chartDataAdapter.state.value.selectedMarket
        val candles = chartDataAdapter.state.value.candles
        if (candles.isEmpty()) return

        val relevantNews = _newsArticles.value.filter { article ->
            article.relevantSymbols.any { it.equals(sym, ignoreCase = true) || it.contains(sym, ignoreCase = true) }
        }.ifEmpty {
            _newsArticles.value.filter { it.marketCategory == market }
        }

        val sentimentScore = if (relevantNews.isNotEmpty()) {
            relevantNews.map { it.sentimentScore }.average().toInt().coerceIn(0, 100)
        } else {
            50
        }
        val latestArticle = relevantNews.maxByOrNull { it.publishedAt }

        val completeResult = CompleteAnalysisPipeline.executeAnalysis(
            symbol = sym,
            market = market.displayName,
            candles = candles,
            isNewsConnected = _newsApiConnectionState.value == ConnectionState.Connected,
            newsSentimentScore = sentimentScore,
            newsHeadline = latestArticle?.headline,
            newsSource = latestArticle?.source,
            activeTimeframe = chartDataAdapter.state.value.selectedTimeframe.label
        )
        _completeAnalysisResult.value = completeResult
        _analysisScoreSnapshot.value = completeResult.coreSnapshot
    }

    // --- WhatsApp Notifications Configuration ---

    fun saveWhatsAppConfig(phoneNumber: String, apiKey: String, phoneNumberId: String = "") {
        val cleanPhone = phoneNumber.trim()
        val cleanKey = apiKey.trim()
        val cleanPhoneId = phoneNumberId.trim()
        repository.saveWhatsAppConfig(cleanPhone, cleanKey, cleanPhoneId)
        _savedWhatsAppPhoneNumber.value = cleanPhone
        _savedWhatsAppApiKey.value = cleanKey
        if (cleanPhoneId.isNotBlank()) {
            _savedWhatsAppPhoneNumberId.value = cleanPhoneId
        }
    }

    suspend fun verifyAndConnectWhatsApp(phoneNumber: String, apiKey: String, phoneNumberId: String): WhatsAppVerificationResult {
        val cleanPhone = phoneNumber.trim()
        val cleanKey = apiKey.trim()
        val cleanPhoneId = phoneNumberId.trim()

        val verification = whatsAppApiService.verifyConnection(cleanPhoneId, cleanKey)
        when (verification) {
            is WhatsAppVerificationResult.Success -> {
                saveWhatsAppConfig(cleanPhone, cleanKey, cleanPhoneId)
                val accountDesc = if (verification.verifiedName.isNotBlank()) {
                    "${verification.verifiedName} (${verification.displayPhoneNumber})"
                } else {
                    verification.displayPhoneNumber
                }
                repository.saveWhatsAppConnectionStatus("Connected")
                repository.saveWhatsAppLastVerifiedTime(verification.verifiedAt)
                repository.saveWhatsAppConnectedAccount(accountDesc)

                _whatsAppConnectionStatus.value = WhatsAppConnectionStatus.Connected
                _whatsAppLastVerifiedTime.value = verification.verifiedAt
                _whatsAppConnectedAccount.value = accountDesc
            }
            is WhatsAppVerificationResult.Failure -> {
                if (verification.isAuthFailure) {
                    repository.saveWhatsAppConnectionStatus("Authentication Required")
                    _whatsAppConnectionStatus.value = WhatsAppConnectionStatus.AuthenticationRequired(verification.errorMessage)
                } else {
                    repository.saveWhatsAppConnectionStatus("Disconnected")
                    _whatsAppConnectionStatus.value = WhatsAppConnectionStatus.Disconnected
                }
            }
        }
        return verification
    }

    fun setWhatsAppConnectionMethod(method: WhatsAppConnectionMethod) {
        repository.saveWhatsAppConnectionMethod(method.name)
        _whatsAppConnectionMethod.value = method
        if (method == WhatsAppConnectionMethod.QR_CONNECTION) {
            _whatsAppConnectionStatus.value = WhatsAppConnectionStatus.Unavailable(
                "QR device linking unavailable for Meta Cloud API architecture"
            )
        } else {
            val savedStatus = repository.getWhatsAppConnectionStatus()
            _whatsAppConnectionStatus.value = WhatsAppConnectionStatus.fromString(savedStatus)
        }
    }

    fun disconnectWhatsApp() {
        repository.disconnectWhatsApp()
        _whatsAppConnectionStatus.value = WhatsAppConnectionStatus.Disconnected
        _whatsAppLastVerifiedTime.value = null
        _whatsAppConnectedAccount.value = null
    }

    fun updateWhatsAppPreferences(prefs: WhatsAppPreferences) {
        repository.saveWhatsAppPreferences(prefs)
        _whatsAppPreferences.value = prefs
    }

    suspend fun sendTestWhatsAppAlert(phoneNumber: String, apiKey: String, phoneNumberId: String): WhatsAppSendResult {
        val phoneId = if (phoneNumberId.isNotBlank()) phoneNumberId else (_savedWhatsAppPhoneNumberId.value ?: "me")
        val token = if (apiKey.isNotBlank()) apiKey else (_savedWhatsAppApiKey.value.orEmpty())
        val recipient = if (phoneNumber.isNotBlank()) phoneNumber else (_savedWhatsAppPhoneNumber.value.orEmpty())
        val message = "🔔 [IQTrade Pro] WhatsApp Cloud API Test Alert\n\nYour Meta WhatsApp Cloud API gateway is successfully connected and operational.\nInformational alerts for signals, price crossings, and SL/TP are ready."
        return whatsAppApiService.sendTextMessage(
            phoneNumberId = phoneId,
            accessToken = token,
            recipientPhone = recipient,
            messageBody = message
        )
    }

    fun clearWhatsAppConfig() {
        repository.clearWhatsAppConfig()
        _savedWhatsAppPhoneNumber.value = null
        _savedWhatsAppApiKey.value = null
        _savedWhatsAppPhoneNumberId.value = null
        _whatsAppConnectionStatus.value = WhatsAppConnectionStatus.Disconnected
        _whatsAppLastVerifiedTime.value = null
        _whatsAppConnectedAccount.value = null
        _whatsAppPreferences.value = repository.getWhatsAppPreferences()
    }

    fun dispatchNewsAlert(headline: String, source: String, sentiment: String, symbol: String = uiState.value.selectedSymbol) {
        val now = System.currentTimeMillis()
        val eventKey = "${symbol}_NEWS_${headline.hashCode()}_${now / 300_000}" // 5 min dedup window
        val body = "IQTrade Pro\nNews Alert\nHeadline: $headline\nSource: $source\nTimestamp: $now\nMarket/Symbol: $symbol\nSentiment: $sentiment"
        whatsAppDispatcher.dispatchNotification(
            category = WhatsAppNotificationCategory.NEWS_ALERT,
            eventKey = eventKey,
            message = body,
            preferences = _whatsAppPreferences.value,
            recipientPhone = _savedWhatsAppPhoneNumber.value,
            apiKey = _savedWhatsAppApiKey.value,
            phoneNumberId = _savedWhatsAppPhoneNumberId.value
        )
    }

    fun resetPaperAccount() {
        viewModelScope.launch {
            repository.resetPaperAccount()
            database.tradeRecordDao().clearPaperTrades()
        }
    }

    fun simulatePaperTrade(side: String, amountUsdt: Double, price: Double = 65420.0) {
        val currentState = uiState.value
        if (currentState.activeTradingMode == TradingMode.ONLY_SIGNAL) {
            _currentError.value = AppError.Generic("Order rejected: Trading is completely disabled in Only Signal mode")
            return
        }
        val effectivePrice = when {
            price > 0.0 && price != 65420.0 -> price
            currentState.currentMarketPrice > 0.0 -> currentState.currentMarketPrice
            else -> price
        }
        if (effectivePrice <= 0.0 || currentState.isSymbolDataStale) {
            _currentError.value = AppError.Generic("Order rejected: Invalid or stale market data")
            return
        }
        if (amountUsdt <= 0.0) {
            _currentError.value = AppError.Generic("Order rejected: Amount must be greater than zero")
            return
        }
        val quantity = amountUsdt / effectivePrice
        val tradeSide = if (side.equals("BUY", ignoreCase = true)) TradeSide.BUY else TradeSide.SELL
        executeOrder(
            side = tradeSide,
            orderType = OrderType.MARKET,
            entryPrice = effectivePrice,
            quantity = quantity,
            protection = currentState.defaultProtectionState
        )
    }

    fun dismissError() {
        _currentError.value = null
    }

    fun triggerError(error: AppError) {
        _currentError.value = error
    }

    // --- Chart System (Module #3) Actions ---

    fun addIndicator(type: IndicatorType, period: Int, color: String) {
        val newInstance = IndicatorInstance(
            type = type,
            period = period,
            color = color,
            isEnabled = true
        )
        val updated = _indicators.value + newInstance
        _indicators.value = updated
        indicatorPersistenceManager.saveChartIndicators(updated)
    }

    fun removeIndicator(id: String) {
        val updated = _indicators.value.filterNot { it.id == id }
        _indicators.value = updated
        indicatorPersistenceManager.saveChartIndicators(updated)
    }

    fun toggleIndicator(id: String, isEnabled: Boolean) {
        val updated = _indicators.value.map {
            if (it.id == id) it.copy(isEnabled = isEnabled) else it
        }
        _indicators.value = updated
        indicatorPersistenceManager.saveChartIndicators(updated)
    }

    fun updateIndicatorPeriod(id: String, period: Int) {
        val updated = _indicators.value.map {
            if (it.id == id) it.copy(period = period) else it
        }
        _indicators.value = updated
        indicatorPersistenceManager.saveChartIndicators(updated)
    }

    fun resetIndicatorsToDefaults() {
        val defaults = indicatorPersistenceManager.resetToDefaults()
        _indicators.value = defaults
    }

    fun setDrawingTool(tool: DrawingType) {
        _activeDrawingTool.value = tool
    }

    fun addDrawing(drawing: ChartDrawing) {
        _drawings.value = _drawings.value + drawing
    }

    fun clearDrawings() {
        _drawings.value = emptyList()
        _activeDrawingTool.value = DrawingType.NONE
    }

    fun setChartFullscreen(isFullscreen: Boolean) {
        _isChartFullscreen.value = isFullscreen
    }

    fun onPriceAlert(alert: PriceAlertEvent) {
        _activePriceAlert.value = alert
        val currentSym = uiState.value.selectedSymbol
        val eventKey = "${currentSym}_PRICE_LINE_${alert.lineId}_${alert.timestamp / 30000}"
        val body = "IQTrade Pro\nPrice Alert: Horizontal Price Line Crossing\nSymbol: $currentSym\nTitle: ${alert.title}\nDirection: ${alert.direction}\nTarget Price: ${alert.formattedTarget}\nCurrent Price: ${alert.formattedCurrent}\nTimestamp: ${alert.timestamp}"
        whatsAppDispatcher.dispatchNotification(
            category = WhatsAppNotificationCategory.PRICE_ALERT,
            eventKey = eventKey,
            message = body,
            preferences = _whatsAppPreferences.value,
            recipientPhone = _savedWhatsAppPhoneNumber.value,
            apiKey = _savedWhatsAppApiKey.value,
            phoneNumberId = _savedWhatsAppPhoneNumberId.value
        )
        viewModelScope.launch {
            kotlinx.coroutines.delay(6000)
            if (_activePriceAlert.value == alert) {
                _activePriceAlert.value = null
            }
        }
    }

    fun dismissPriceAlert() {
        _activePriceAlert.value = null
    }

    fun reloadChartData() {
        val current = uiState.value
        chartDataAdapter.loadData(
            current.selectedMarket,
            current.selectedSymbol,
            Timeframe.fromLabel(current.selectedTimeframe)
        )
    }

    fun executeOrder(
        side: TradeSide,
        orderType: OrderType,
        entryPrice: Double,
        quantity: Double,
        protection: TradeProtectionState
    ) {
        val currentState = uiState.value
        // Guard 1: ONLY_SIGNAL mode strictly guarantees zero order execution
        if (currentState.activeTradingMode == TradingMode.ONLY_SIGNAL) {
            _currentError.value = AppError.Generic("Order rejected: Trading is completely disabled in Only Signal mode")
            return
        }

        // Guard 2: Symbol validation
        if (currentState.selectedSymbol.isBlank() || currentState.selectedSymbol.length < 2) {
            _currentError.value = AppError.Generic("Order rejected: Invalid trading symbol")
            return
        }

        // Guard 3: Reject orders when market data is invalid or stale
        if (entryPrice <= 0.0 || entryPrice.isNaN() || entryPrice.isInfinite() || currentState.isSymbolDataStale) {
            _currentError.value = AppError.Generic("Order rejected: Invalid or stale market data")
            return
        }

        // Guard 4: Quantity validity (positive, non-zero)
        if (quantity <= 0.0 || quantity.isNaN() || quantity.isInfinite()) {
            _currentError.value = AppError.Generic("Order rejected: Quantity must be greater than zero")
            return
        }

        // Guard 5: Duplicate order spam prevention (3s cooldown)
        val now = System.currentTimeMillis()
        val lastTime = _lastOrderTimestamps[currentState.selectedSymbol] ?: 0L
        if (now - lastTime < 3000L) {
            _currentError.value = AppError.Generic("Duplicate order prevented. Please wait before placing another order.")
            return
        }

        // Guard 6: Position & risk protection validation (if SL / TP set)
        val effSl = protection.effectiveStopLossPrice
        val effTp = protection.effectiveTakeProfitPrice
        if (effSl != null && effSl <= 0.0) {
            _currentError.value = AppError.Generic("Order rejected: Stop loss price must be positive")
            return
        }
        if (effTp != null && effTp <= 0.0) {
            _currentError.value = AppError.Generic("Order rejected: Take profit price must be positive")
            return
        }
        if (side == TradeSide.BUY) {
            if (effSl != null && effSl >= entryPrice) {
                _currentError.value = AppError.Generic("Order rejected: BUY Stop loss must be below entry price")
                return
            }
            if (effTp != null && effTp <= entryPrice) {
                _currentError.value = AppError.Generic("Order rejected: BUY Take profit must be above entry price")
                return
            }
        } else {
            if (effSl != null && effSl <= entryPrice) {
                _currentError.value = AppError.Generic("Order rejected: SELL Stop loss must be above entry price")
                return
            }
            if (effTp != null && effTp >= entryPrice) {
                _currentError.value = AppError.Generic("Order rejected: SELL Take profit must be below entry price")
                return
            }
        }

        val isLiveMode = currentState.activeTradingMode == TradingMode.LIVE_TRADE
        if (isLiveMode) {
            // Guard 7: Binance Live Trading is only supported on Crypto markets
            if (currentState.selectedMarket != MarketCategory.CRYPTO) {
                _currentError.value = AppError.Generic("Order rejected: Binance Live Trading is only supported on Crypto markets")
                return
            }
            // Guard 8: Live trading authorization required
            if (_liveTradingState.value != LiveTradingState.LIVE_TRADING_ENABLED || !currentState.isLiveTradingEnabled) {
                _currentError.value = AppError.Generic("Live Trading authorization required. Please enable Live Trading with explicit confirmation.")
                return
            }
            // Guard 9: Verified API connection required for live orders
            if (!repository.hasBinanceCredentials() || currentState.binanceConnectionState != ConnectionState.Connected) {
                _currentError.value = AppError.Generic("Active Binance API connection required for Live Trading")
                return
            }
            // Guard 10: Minimum notional check (5.0 USDT)
            val notional = entryPrice * quantity
            if (notional < 5.0) {
                _currentError.value = AppError.Generic("Order rejected: Minimum notional value for Binance is 5.0 USDT (Current: $${String.format(Locale.US, "%.2f", notional)})")
                return
            }
            // Guard 11: Balance validation
            if (side == TradeSide.BUY) {
                val quoteAvail = if (_liveAvailableBalance.value > 0.0) _liveAvailableBalance.value else _liveQuoteBalance.value
                if (quoteAvail > 0.0 && quoteAvail < notional) {
                    _currentError.value = AppError.Generic("Insufficient exchange balance: Required $${String.format(Locale.US, "%.2f", notional)}, Available $${String.format(Locale.US, "%.2f", quoteAvail)}")
                    return
                }
            } else {
                val baseAvail = _liveBaseAssetBalance.value
                if (baseAvail > 0.0 && baseAvail < quantity) {
                    _currentError.value = AppError.Generic("Insufficient exchange base asset balance: Required $quantity, Available $baseAvail")
                    return
                }
            }
        }

        _lastOrderTimestamps[currentState.selectedSymbol] = now

        viewModelScope.launch {
            if (isLiveMode) {
                val clientOrderId = "IQ_${System.currentTimeMillis()}_${currentState.selectedSymbol}_${side.name}"
                val initialTrade = TradeRecordEntity(
                    symbol = currentState.selectedSymbol,
                    side = side.name,
                    orderType = orderType.name,
                    quantity = quantity,
                    price = entryPrice,
                    total = entryPrice * quantity,
                    isPaper = false,
                    stopLoss = protection.effectiveStopLossPrice,
                    takeProfit = protection.effectiveTakeProfitPrice,
                    isOpen = false,
                    status = "SUBMITTED",
                    clientOrderId = clientOrderId,
                    requestedPrice = entryPrice
                )
                val insertedId = database.tradeRecordDao().insertTrade(initialTrade)

                val submitResult = repository.submitLiveOrder(
                    symbol = currentState.selectedSymbol,
                    side = side,
                    orderType = orderType,
                    quantity = quantity,
                    price = if (orderType == OrderType.LIMIT) entryPrice else null,
                    stopPrice = if (orderType == OrderType.STOP_TRIGGER) protection.effectiveStopLossPrice else null,
                    clientOrderId = clientOrderId
                )

                when (submitResult) {
                    is LiveOrderResult.Success -> {
                        val isFilledOrPartial = submitResult.isFilled || submitResult.isPartiallyFilled
                        val fillPrice = if (submitResult.avgFillPrice > 0.0) submitResult.avgFillPrice else entryPrice
                        val execQty = if (submitResult.executedQty > 0.0) submitResult.executedQty else quantity
                        val confirmedTrade = initialTrade.copy(
                            id = insertedId,
                            exchangeOrderId = submitResult.exchangeOrderId,
                            status = submitResult.status,
                            price = fillPrice,
                            averageFillPrice = fillPrice,
                            quantity = execQty,
                            executedQuantity = submitResult.executedQty,
                            total = fillPrice * execQty,
                            isOpen = isFilledOrPartial,
                            commission = submitResult.commission,
                            commissionAsset = submitResult.commissionAsset,
                            filledTimestamp = if (submitResult.isFilled) submitResult.transactTime else null,
                            updatedTimestamp = System.currentTimeMillis()
                        )
                        database.tradeRecordDao().updateTrade(confirmedTrade)
                        _activeProtectionState.value = protection
                        refreshLiveAccountBalances()
                        dispatchTradeNotifications(confirmedTrade, protection)
                    }
                    is LiveOrderResult.Rejected -> {
                        val rejectedTrade = initialTrade.copy(
                            id = insertedId,
                            status = "REJECTED",
                            isOpen = false,
                            updatedTimestamp = System.currentTimeMillis()
                        )
                        database.tradeRecordDao().updateTrade(rejectedTrade)
                        _currentError.value = AppError.Generic("Exchange order rejected: ${submitResult.message} (Code: ${submitResult.code})")
                    }
                    is LiveOrderResult.NetworkUncertain -> {
                        // Keep SUBMITTED, launch asynchronous status query to reconcile
                        viewModelScope.launch {
                            kotlinx.coroutines.delay(2000)
                            reconcileOpenLiveOrdersWithExchange()
                        }
                    }
                    is LiveOrderResult.Error -> {
                        val errorTrade = initialTrade.copy(
                            id = insertedId,
                            status = "REJECTED",
                            isOpen = false,
                            updatedTimestamp = System.currentTimeMillis()
                        )
                        database.tradeRecordDao().updateTrade(errorTrade)
                        _currentError.value = AppError.Generic("Live execution error: ${submitResult.message}")
                    }
                }
            } else {
                // Paper Trading Simulation with Realistic Spread & Fill
                val fillPrice = if (side == TradeSide.BUY) entryPrice * 1.0005 else entryPrice * 0.9995
                val totalCost = fillPrice * quantity
                val currentAccount = database.paperAccountDao().getAccount() ?: PaperAccountEntity()

                if (side == TradeSide.BUY && currentAccount.balance < totalCost) {
                    _currentError.value = AppError.Generic("Insufficient paper balance: Required $${String.format(Locale.US, "%.2f", totalCost)}, Available $${String.format(Locale.US, "%.2f", currentAccount.balance)}")
                    return@launch
                }

                val newBalance = if (side == TradeSide.BUY) {
                    (currentAccount.balance - totalCost).coerceAtLeast(0.0)
                } else {
                    currentAccount.balance + totalCost
                }

                val trade = TradeRecordEntity(
                    symbol = currentState.selectedSymbol,
                    side = side.name,
                    orderType = orderType.name,
                    quantity = quantity,
                    price = fillPrice,
                    total = totalCost,
                    isPaper = true,
                    stopLoss = protection.effectiveStopLossPrice,
                    takeProfit = protection.effectiveTakeProfitPrice,
                    isOpen = true,
                    status = "FILLED"
                )
                val insertedId = database.tradeRecordDao().insertTrade(trade)
                repository.updatePaperBalance(newBalance, newBalance)
                _activeProtectionState.value = protection
                dispatchTradeNotifications(trade.copy(id = insertedId), protection)
            }
        }
    }

    /**
     * Refreshes account balances from Binance REST API and stores reactive quote/base quantities.
     */
    fun refreshLiveAccountBalances() {
        if (!repository.hasBinanceCredentials()) return
        viewModelScope.launch {
            _isLiveSyncing.value = true
            val res = repository.queryLiveAccountBalances()
            res.onSuccess { balances ->
                val quoteBal = balances.find { it.asset.equals("USDT", ignoreCase = true) }
                    ?: balances.find { it.asset.equals("USD", ignoreCase = true) }
                    ?: balances.find { it.asset.equals("BUSD", ignoreCase = true) }
                val quoteFree = quoteBal?.free ?: 0.0
                val quoteLocked = quoteBal?.locked ?: 0.0
                _liveQuoteBalance.value = quoteFree + quoteLocked
                _liveAvailableBalance.value = quoteFree

                val currentSym = uiState.value.selectedSymbol
                val baseAsset = when {
                    currentSym.endsWith("USDT") -> currentSym.removeSuffix("USDT")
                    currentSym.endsWith("USD") -> currentSym.removeSuffix("USD")
                    currentSym.endsWith("BUSD") -> currentSym.removeSuffix("BUSD")
                    else -> ""
                }
                if (baseAsset.isNotBlank()) {
                    val baseBal = balances.find { it.asset.equals(baseAsset, ignoreCase = true) }
                    _liveBaseAssetBalance.value = baseBal?.free ?: 0.0
                }
            }.onFailure { err ->
                android.util.Log.w("IQTradeViewModel", "Live balance query failure: ${err.message}")
            }
            _isLiveSyncing.value = false
        }
    }

    /**
     * Reconciles local open and submitted live orders with authoritative Binance status.
     */
    fun reconcileOpenLiveOrdersWithExchange() {
        if (!repository.hasBinanceCredentials()) return
        viewModelScope.launch {
            val openLiveTrades = database.tradeRecordDao().getOpenTrades(isPaper = false)
            for (trade in openLiveTrades) {
                val queryRes = repository.queryLiveOrder(
                    symbol = trade.symbol,
                    exchangeOrderId = trade.exchangeOrderId,
                    clientOrderId = trade.clientOrderId
                )
                if (queryRes is LiveOrderResult.Success) {
                    val isStillOpen = (queryRes.status.equals("NEW", ignoreCase = true) ||
                            queryRes.status.equals("PARTIALLY_FILLED", ignoreCase = true) ||
                            queryRes.status.equals("FILLED", ignoreCase = true)) &&
                            queryRes.status != "CANCELED" && queryRes.status != "EXPIRED" && queryRes.status != "REJECTED"
                    val updated = trade.copy(
                        exchangeOrderId = queryRes.exchangeOrderId,
                        status = queryRes.status,
                        averageFillPrice = if (queryRes.avgFillPrice > 0.0) queryRes.avgFillPrice else trade.averageFillPrice,
                        executedQuantity = if (queryRes.executedQty > 0.0) queryRes.executedQty else trade.executedQuantity,
                        commission = queryRes.commission,
                        commissionAsset = queryRes.commissionAsset,
                        isOpen = isStillOpen,
                        updatedTimestamp = System.currentTimeMillis()
                    )
                    database.tradeRecordDao().updateTrade(updated)
                }
            }
            refreshLiveAccountBalances()
        }
    }

    /**
     * Evaluates open Live positions against incoming market price for SL/TP and Trailing Stop.
     */
    fun evaluateLivePositionsProtection(symbol: String, currentPrice: Double) {
        if (currentPrice <= 0.0) return
        viewModelScope.launch {
            val openTrades = database.tradeRecordDao().getOpenTrades(isPaper = false)
            val matchingTrades = openTrades.filter { it.symbol.equals(symbol, ignoreCase = true) }
            if (matchingTrades.isEmpty()) return@launch

            for (trade in matchingTrades) {
                val isBuy = trade.side.equals("BUY", ignoreCase = true)

                // 1. Trailing Stop Ratchet (in favorable direction only)
                val activeProtection = _activeProtectionState.value
                if (activeProtection?.stopLossMode == StopLossMode.TRAILING && trade.stopLoss != null) {
                    val trailingDistPct = activeProtection.trailingDistancePct
                    if (isBuy && currentPrice > trade.price) {
                        val candidateStop = currentPrice * (1.0 - (trailingDistPct / 100.0))
                        if (candidateStop > (trade.stopLoss ?: 0.0)) {
                            database.tradeRecordDao().updateTrade(trade.copy(stopLoss = candidateStop))
                        }
                    } else if (!isBuy && currentPrice < trade.price) {
                        val candidateStop = currentPrice * (1.0 + (trailingDistPct / 100.0))
                        if (candidateStop < trade.stopLoss) {
                            database.tradeRecordDao().updateTrade(trade.copy(stopLoss = candidateStop))
                        }
                    }
                }

                // 2. Stop Loss Trigger Check
                val slPrice = trade.stopLoss
                if (slPrice != null && slPrice > 0.0) {
                    val isSlTriggered = if (isBuy) currentPrice <= slPrice else currentPrice >= slPrice
                    if (isSlTriggered) {
                        closeLivePosition(trade.id, triggerPrice = slPrice, reason = "Live Stop Loss Triggered")
                        continue
                    }
                }

                // 3. Take Profit Trigger Check
                val tpPrice = trade.takeProfit
                if (tpPrice != null && tpPrice > 0.0) {
                    val isTpTriggered = if (isBuy) currentPrice >= tpPrice else currentPrice <= tpPrice
                    if (isTpTriggered) {
                        closeLivePosition(trade.id, triggerPrice = tpPrice, reason = "Live Take Profit Triggered")
                        continue
                    }
                }
            }
        }
    }

    /**
     * Executes real market order to close an open live position on Binance.
     */
    fun closeLivePosition(tradeId: Long, triggerPrice: Double, reason: String? = null) {
        if (_activeLiveCloseMutex.putIfAbsent(tradeId, true) != null) {
            return
        }

        viewModelScope.launch {
            try {
                val trade = database.tradeRecordDao().getTradeById(tradeId) ?: return@launch
                if (!trade.isOpen || trade.isPaper) return@launch

                val closeSide = if (trade.side.equals("BUY", ignoreCase = true)) TradeSide.SELL else TradeSide.BUY
                val closeQty = trade.executedQuantity ?: trade.quantity
                val clientOrderId = "IQ_CLOSE_${System.currentTimeMillis()}_${trade.symbol}"

                val submitResult = repository.submitLiveOrder(
                    symbol = trade.symbol,
                    side = closeSide,
                    orderType = OrderType.MARKET,
                    quantity = closeQty,
                    clientOrderId = clientOrderId
                )

                val effectiveClosePrice = if (submitResult is LiveOrderResult.Success && submitResult.avgFillPrice > 0.0) {
                    submitResult.avgFillPrice
                } else {
                    triggerPrice
                }

                val pnl = if (trade.side.equals("BUY", ignoreCase = true)) {
                    (effectiveClosePrice - trade.price) * closeQty
                } else {
                    (trade.price - effectiveClosePrice) * closeQty
                }

                database.tradeRecordDao().closeTrade(
                    id = tradeId,
                    closePrice = effectiveClosePrice,
                    pnl = pnl,
                    closeTime = System.currentTimeMillis()
                )

                refreshLiveAccountBalances()

                val closeReason = reason ?: "Live Close"
                val sign = if (pnl >= 0) "+" else ""
                val closeMsg = "IQTrade Pro\nLive Position Closed\nSymbol: ${trade.symbol}\nSide: ${trade.side}\nEntry Price: $${trade.price}\nClose Price: $${effectiveClosePrice}\nRealized P&L: $sign$${String.format(Locale.US, "%.2f", pnl)}\nReason: $closeReason\nTimestamp: ${System.currentTimeMillis()}"
                whatsAppDispatcher.dispatchNotification(
                    category = WhatsAppNotificationCategory.CONFIRMED_TRADE,
                    eventKey = "${trade.symbol}_LIVE_CLOSED_${tradeId}_${System.currentTimeMillis()}",
                    message = closeMsg,
                    preferences = _whatsAppPreferences.value,
                    recipientPhone = _savedWhatsAppPhoneNumber.value,
                    apiKey = _savedWhatsAppApiKey.value,
                    phoneNumberId = _savedWhatsAppPhoneNumberId.value
                )
            } finally {
                _activeLiveCloseMutex.remove(tradeId)
            }
        }
    }

    /**
     * Evaluates open Paper positions against incoming market price for SL/TP and Trailing Stop.
     */
    fun evaluatePaperPositionsProtection(symbol: String, currentPrice: Double) {
        if (currentPrice <= 0.0) return
        viewModelScope.launch {
            val openTrades = database.tradeRecordDao().getOpenTrades(isPaper = true)
            val matchingTrades = openTrades.filter { it.symbol.equals(symbol, ignoreCase = true) }
            if (matchingTrades.isEmpty()) return@launch

            for (trade in matchingTrades) {
                val isBuy = trade.side.equals("BUY", ignoreCase = true)

                // 1. Trailing Stop Ratchet (in favorable direction only)
                val activeProtection = _activeProtectionState.value
                if (activeProtection?.stopLossMode == StopLossMode.TRAILING && trade.stopLoss != null) {
                    val trailingDistPct = activeProtection.trailingDistancePct
                    if (isBuy && currentPrice > trade.price) {
                        val candidateStop = currentPrice * (1.0 - (trailingDistPct / 100.0))
                        if (candidateStop > (trade.stopLoss ?: 0.0)) {
                            database.tradeRecordDao().updateTrade(trade.copy(stopLoss = candidateStop))
                        }
                    } else if (!isBuy && currentPrice < trade.price) {
                        val candidateStop = currentPrice * (1.0 + (trailingDistPct / 100.0))
                        if (candidateStop < trade.stopLoss) {
                            database.tradeRecordDao().updateTrade(trade.copy(stopLoss = candidateStop))
                        }
                    }
                }

                // 2. Stop Loss Trigger Check
                val slPrice = trade.stopLoss
                if (slPrice != null && slPrice > 0.0) {
                    val isSlTriggered = if (isBuy) currentPrice <= slPrice else currentPrice >= slPrice
                    if (isSlTriggered) {
                        closePosition(trade.id, customClosePrice = slPrice, reason = "Stop Loss Triggered")
                        continue
                    }
                }

                // 3. Take Profit Trigger Check
                val tpPrice = trade.takeProfit
                if (tpPrice != null && tpPrice > 0.0) {
                    val isTpTriggered = if (isBuy) currentPrice >= tpPrice else currentPrice <= tpPrice
                    if (isTpTriggered) {
                        closePosition(trade.id, customClosePrice = tpPrice, reason = "Take Profit Triggered")
                        continue
                    }
                }
            }
        }
    }

    /**
     * Module #7 / #8: Closes an open position, realizes P&L and updates account balance.
     */
    fun closePosition(tradeId: Long, customClosePrice: Double? = null, reason: String? = null) {
        viewModelScope.launch {
            val trade = database.tradeRecordDao().getTradeById(tradeId) ?: return@launch
            if (!trade.isOpen) return@launch

            if (!trade.isPaper) {
                // Route to live closing order execution on Binance
                closeLivePosition(tradeId, customClosePrice ?: uiState.value.chartDataState.currentPrice ?: trade.price, reason)
                return@launch
            }

            val currentPrice = customClosePrice ?: (uiState.value.chartDataState.currentPrice?.takeIf { it > 0.0 } ?: trade.price)
            val pnl = if (trade.side == "BUY") {
                (currentPrice - trade.price) * trade.quantity
            } else {
                (trade.price - currentPrice) * trade.quantity
            }

            database.tradeRecordDao().closeTrade(
                id = tradeId,
                closePrice = currentPrice,
                pnl = pnl,
                closeTime = System.currentTimeMillis()
            )

            if (trade.isPaper) {
                val currentAccount = database.paperAccountDao().getAccount() ?: PaperAccountEntity()
                val returnBalance = if (trade.side == "BUY") trade.total + pnl else pnl
                val newBalance = (currentAccount.balance + returnBalance).coerceAtLeast(0.0)
                val newRealizedPnl = currentAccount.realizedPnl + pnl
                database.paperAccountDao().update(
                    currentAccount.copy(
                        balance = newBalance,
                        realizedPnl = newRealizedPnl,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }

            // WhatsApp alert for closed position
            val closeReason = reason ?: "Manual Close"
            val sign = if (pnl >= 0) "+" else ""
            val closeMsg = "IQTrade Pro\nPosition Closed: ${if (trade.isPaper) "Paper" else "Live"}\nSymbol: ${trade.symbol}\nSide: ${trade.side}\nEntry Price: $${trade.price}\nClose Price: $${currentPrice}\nRealized P&L: $sign$${String.format(Locale.US, "%.2f", pnl)}\nReason: $closeReason\nTimestamp: ${System.currentTimeMillis()}"
            whatsAppDispatcher.dispatchNotification(
                category = WhatsAppNotificationCategory.CONFIRMED_TRADE,
                eventKey = "${trade.symbol}_CLOSED_${tradeId}_${System.currentTimeMillis()}",
                message = closeMsg,
                preferences = _whatsAppPreferences.value,
                recipientPhone = _savedWhatsAppPhoneNumber.value,
                apiKey = _savedWhatsAppApiKey.value,
                phoneNumberId = _savedWhatsAppPhoneNumberId.value
            )
        }
    }

    /**
     * Module #7 / #9: Emergency Kill Switch / Panic Close. Disarms Auto Trade and Live Trading and closes open positions.
     */
    fun panicCloseAllPositions() {
        viewModelScope.launch {
            // 1. Immediately disarm Auto Trading and Live Trading
            _liveTradingState.value = LiveTradingState.LIVE_TRADING_OFF
            repository.setAutoTrading(false)
            repository.setLiveTrading(false)

            // 2. Liquidate open paper positions
            val openPaperTrades = database.tradeRecordDao().getOpenTrades(isPaper = true)
            val currentPrice = uiState.value.chartDataState.currentPrice ?: 0.0

            for (trade in openPaperTrades) {
                val execPrice = if (currentPrice > 0.0) currentPrice else trade.price
                val pnl = if (trade.side == "BUY") {
                    (execPrice - trade.price) * trade.quantity
                } else {
                    (trade.price - execPrice) * trade.quantity
                }
                database.tradeRecordDao().closeTrade(
                    id = trade.id,
                    closePrice = execPrice,
                    pnl = pnl,
                    closeTime = System.currentTimeMillis()
                )
                val currentAccount = database.paperAccountDao().getAccount() ?: PaperAccountEntity()
                val returnBalance = if (trade.side == "BUY") trade.total + pnl else pnl
                val newBalance = (currentAccount.balance + returnBalance).coerceAtLeast(0.0)
                database.paperAccountDao().update(
                    currentAccount.copy(
                        balance = newBalance,
                        realizedPnl = currentAccount.realizedPnl + pnl,
                        updatedAt = System.currentTimeMillis()
                    )
                )
            }

            // 3. Liquidate open live trades via live market orders on Binance
            val liveTrades = database.tradeRecordDao().getOpenTrades(isPaper = false)
            for (trade in liveTrades) {
                closeLivePosition(trade.id, triggerPrice = if (currentPrice > 0.0) currentPrice else trade.price, reason = "Emergency Panic Close")
            }

            val emergencyMsg = "IQTrade Pro\nEMERGENCY PANIC CLOSE EXECUTED\nAll Auto Trade Engines Disarmed\nAll Open Positions Liquidated\nTimestamp: ${System.currentTimeMillis()}"
            whatsAppDispatcher.dispatchNotification(
                category = WhatsAppNotificationCategory.CONFIRMED_TRADE,
                eventKey = "EMERGENCY_PANIC_${System.currentTimeMillis()}",
                message = emergencyMsg,
                preferences = _whatsAppPreferences.value,
                recipientPhone = _savedWhatsAppPhoneNumber.value,
                apiKey = _savedWhatsAppApiKey.value,
                phoneNumberId = _savedWhatsAppPhoneNumberId.value
            )
        }
    }

    /**
     * Module #7 / #9: Smart Auto Trade Signal Evaluation using Complete Analysis Engine results.
     */
    fun evaluateSmartAutoTradeSignal() {
        val currentState = uiState.value
        if (!currentState.isAutoTradingEnabled || currentState.activeTradingMode == TradingMode.ONLY_SIGNAL) {
            return
        }
        val analysis = currentState.completeAnalysisResult ?: return
        if (!analysis.isConfirmedCoreMet || currentState.isSymbolDataStale) return

        val score = analysis.overallConfidencePct
        val signal = analysis.overallSignal
        val rr = analysis.riskRewardResult.ratioValue

        if (score < 65 || rr < 1.5) return

        viewModelScope.launch {
            val isPaper = currentState.activeTradingMode != TradingMode.LIVE_TRADE
            // Section 32 Guard: Auto Trading cannot execute live orders without explicit Live authorization
            if (!isPaper && (!currentState.isLiveTradingEnabled || _liveTradingState.value != LiveTradingState.LIVE_TRADING_ENABLED)) {
                return@launch
            }

            val openTrades = database.tradeRecordDao().getOpenTrades(isPaper)
            if (openTrades.any { it.symbol == currentState.selectedSymbol }) return@launch

            val side = when (signal) {
                FinalAnalysisSignal.BULLISH_BUY -> TradeSide.BUY
                FinalAnalysisSignal.BEARISH_SELL -> TradeSide.SELL
                else -> return@launch
            }

            val price = currentState.chartDataState.currentPrice ?: return@launch
            if (price <= 0.0) return@launch

            executeOrder(
                side = side,
                orderType = OrderType.MARKET,
                entryPrice = price,
                quantity = 0.01,
                protection = currentState.defaultProtectionState
            )
        }
    }

    private suspend fun dispatchTradeNotifications(trade: TradeRecordEntity, protection: TradeProtectionState) {
        val tradeKey = "${trade.symbol}_TRADE_OPENED_${trade.id}_${trade.timestamp}"
        val tradeEventType = if (trade.isPaper) "Paper Trade Opened" else "Live Trade Opened"
        val tradeMsg = "IQTrade Pro\nTrade Alert: $tradeEventType\nSymbol: ${trade.symbol}\nMarket: ${uiState.value.selectedMarket.displayName}\nSide: ${trade.side}\nEntry Price: $${trade.price}\nQuantity: ${trade.quantity}\nStop Loss: ${protection.effectiveStopLossPrice?.let { "$$it" } ?: "None"}\nTake Profit: ${protection.effectiveTakeProfitPrice?.let { "$$it" } ?: "None"}\nP&L: $0.00 (Initial)\nTimestamp: ${trade.timestamp}\nTrade Mode: ${if (trade.isPaper) "Paper Trading" else "Live Trading"}"
        whatsAppDispatcher.dispatchNotification(
            category = WhatsAppNotificationCategory.CONFIRMED_TRADE,
            eventKey = tradeKey,
            message = tradeMsg,
            preferences = _whatsAppPreferences.value,
            recipientPhone = _savedWhatsAppPhoneNumber.value,
            apiKey = _savedWhatsAppApiKey.value,
            phoneNumberId = _savedWhatsAppPhoneNumberId.value
        )

        if (protection.effectiveStopLossPrice != null) {
            val slKey = "${trade.symbol}_SL_${protection.stopLossMode.name}_${trade.id}_${trade.timestamp}"
            val slCategory = when (protection.stopLossMode) {
                StopLossMode.TRAILING -> WhatsAppNotificationCategory.TRAILING_STOP
                StopLossMode.MANUAL -> WhatsAppNotificationCategory.MANUAL_STOP
                else -> WhatsAppNotificationCategory.STOP_LOSS
            }
            val slMsg = "IQTrade Pro\nTrade Alert: Stop Loss Configured\nSymbol: ${trade.symbol}\nMarket: ${uiState.value.selectedMarket.displayName}\nSide: ${trade.side}\nMode: ${protection.stopLossMode.label}\nSL Price: $${protection.effectiveStopLossPrice}\nRisk %: ${protection.stopLossPercentage}%\nTimestamp: ${trade.timestamp}\nTrade Mode: ${if (trade.isPaper) "Paper Trading" else "Live Trading"}"
            whatsAppDispatcher.dispatchNotification(
                category = slCategory,
                eventKey = slKey,
                message = slMsg,
                preferences = _whatsAppPreferences.value,
                recipientPhone = _savedWhatsAppPhoneNumber.value,
                apiKey = _savedWhatsAppApiKey.value,
                phoneNumberId = _savedWhatsAppPhoneNumberId.value
            )
        }

        if (protection.effectiveTakeProfitPrice != null) {
            val tpKey = "${trade.symbol}_TP_${trade.id}_${trade.timestamp}"
            val tpMsg = "IQTrade Pro\nTrade Alert: Take Profit Configured\nSymbol: ${trade.symbol}\nMarket: ${uiState.value.selectedMarket.displayName}\nSide: ${trade.side}\nTP Price: $${protection.effectiveTakeProfitPrice}\nTarget %: ${protection.takeProfitPercentage}%\nTimestamp: ${trade.timestamp}\nTrade Mode: ${if (trade.isPaper) "Paper Trading" else "Live Trading"}"
            whatsAppDispatcher.dispatchNotification(
                category = WhatsAppNotificationCategory.TAKE_PROFIT,
                eventKey = tpKey,
                message = tpMsg,
                preferences = _whatsAppPreferences.value,
                recipientPhone = _savedWhatsAppPhoneNumber.value,
                apiKey = _savedWhatsAppApiKey.value,
                phoneNumberId = _savedWhatsAppPhoneNumberId.value
            )
        }
    }

    private fun generateSignalsFromCandles(candles: List<Candle>, symbol: String, timeframe: String): List<SignalMarker> {
        if (candles.size < 14) return emptyList()
        val signals = mutableListOf<SignalMarker>()
        val closes = candles.map { it.close }
        val ema9 = calculateEmaList(closes, 9)
        val ema21 = calculateEmaList(closes, 21)
        val rsiList = calculateRsiList(closes, 14)

        val startIdx = (candles.size - 35).coerceAtLeast(1)
        for (i in startIdx until candles.size) {
            val prevFast = ema9[i - 1]
            val currFast = ema9[i]
            val prevSlow = ema21[i - 1]
            val currSlow = ema21[i]
            val candle = candles[i]
            val rsi = rsiList.getOrElse(i) { 50.0 }

            if (prevFast <= prevSlow && currFast > currSlow) {
                val conf = (65 + (rsi / 3.0)).toInt().coerceIn(60, 95)
                signals.add(
                    SignalMarker(
                        id = "sig_bull_${candle.timestamp}",
                        symbol = symbol,
                        type = SignalType.BULLISH,
                        timestamp = candle.timestamp,
                        price = candle.close,
                        score = conf,
                        confidencePct = conf,
                        timeframe = timeframe
                    )
                )
            } else if (prevFast >= prevSlow && currFast < currSlow) {
                val conf = (65 + ((100.0 - rsi) / 3.0)).toInt().coerceIn(60, 95)
                signals.add(
                    SignalMarker(
                        id = "sig_bear_${candle.timestamp}",
                        symbol = symbol,
                        type = SignalType.BEARISH,
                        timestamp = candle.timestamp,
                        price = candle.close,
                        score = conf,
                        confidencePct = conf,
                        timeframe = timeframe
                    )
                )
            }
        }
        return signals.takeLast(10)
    }

    private fun calculateEmaList(values: List<Double>, period: Int): List<Double> {
        val result = mutableListOf<Double>()
        if (values.isEmpty()) return result
        val multiplier = 2.0 / (period + 1)
        var ema = values.take(period.coerceAtMost(values.size)).average()
        for (i in values.indices) {
            if (i < period) {
                result.add(values[i])
            } else {
                ema = (values[i] - ema) * multiplier + ema
                result.add(ema)
            }
        }
        return result
    }

    private fun calculateRsiList(values: List<Double>, period: Int): List<Double> {
        val result = mutableListOf<Double>()
        if (values.size <= period) return List(values.size) { 50.0 }
        var gains = 0.0
        var losses = 0.0
        for (i in 1..period) {
            val diff = values[i] - values[i - 1]
            if (diff >= 0) gains += diff else losses -= diff
        }
        var avgGain = gains / period
        var avgLoss = losses / period
        val firstRs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
        val firstRsi = 100.0 - (100.0 / (1.0 + firstRs))
        for (i in 0..period) result.add(firstRsi)

        for (i in (period + 1) until values.size) {
            val diff = values[i] - values[i - 1]
            val gain = if (diff > 0) diff else 0.0
            val loss = if (diff < 0) -diff else 0.0
            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period
            val rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            result.add(100.0 - (100.0 / (1.0 + rs)))
        }
        return result
    }

    override fun onCleared() {
        super.onCleared()
        chartDataAdapter.cleanup()
    }
}
