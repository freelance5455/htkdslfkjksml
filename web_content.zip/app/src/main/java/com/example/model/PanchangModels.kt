package com.example.model

enum class Paksha {
    SHUKLA,
    KRISHNA
}

enum class PanchakType {
    NONE,
    ROG,    // Sunday start: Health cautions
    RAJ,    // Monday start: Auspicious for wealth and state work
    AGNI,   // Tuesday start: Fire hazard / construction caution
    SAMANYA,// Wednesday / Thursday: Normal/mild
    CHOR,   // Friday start: Avoid monetary transactions/travel
    MRITYU  // Saturday start: Highly inauspicious / caution
}

data class PanchakInfo(
    val isActive: Boolean,
    val type: PanchakType,
    val nakshatras: String,
    val startTime: String,
    val endTime: String,
    val title: String,
    val description: String,
    val forbiddenWorks: List<String>,
    val startDateTimeFormatted: String = "",
    val endDateTimeFormatted: String = "",
    val timingSummary: String = "",
    val lagneKaTime: String = "",
    val utarneKaTime: String = "",
    val durationText: String = "",
    val todayStatusText: String = "",
    val isStartDay: Boolean = false,
    val isEndDay: Boolean = false
)

data class BichhudaInfo(
    val isActive: Boolean,
    val moonRashi: String, // Scorpio / Vrishchika
    val nakshatra: String, // Jyeshtha / Anuradha
    val startTime: String,
    val endTime: String,
    val title: String,
    val description: String,
    val precautions: List<String>,
    val startDateTimeFormatted: String = "",
    val endDateTimeFormatted: String = "",
    val timingSummary: String = "",
    val lagneKaTime: String = "",
    val utarneKaTime: String = "",
    val durationText: String = "",
    val todayStatusText: String = "",
    val isStartDay: Boolean = false,
    val isEndDay: Boolean = false
)

enum class MuhuratCategory {
    VIVAH,
    GRIHA_PRAVESH,      // मकान उद्घाटन / गृह प्रवेश
    OFFICE_UDGHATAN,    // ऑफिस, दुकान व व्यापार उद्घाटन
    VAHAN_KHARIDI,
    NAMKARAN,
    SARVARTHA_SIDDHI
}

data class ShubhMuhurat(
    val id: String,
    val category: MuhuratCategory,
    val dateString: String,
    val dayOfWeek: String,
    val tithi: String,
    val nakshatra: String,
    val auspiciousLagna: String,
    val timings: String,
    val notes: String
)

enum class ChoghadiyaQuality {
    SHUBH_AMRIT_LAABH, // Auspicious (Green)
    CHAR,              // Neutral / Travel (Blue)
    ASHUBH             // Inauspicious: Rog, Kaal, Udveg (Red)
}

data class ChoghadiyaItem(
    val name: String,
    val nature: String, // अमृत, शुभ, लाभ, चर, रोग, काल, उद्वेग
    val quality: ChoghadiyaQuality,
    val startTime: String,
    val endTime: String,
    val rulerPlanet: String,
    val recommendedActivities: String
)

data class DailyChoghadiya(
    val dayChoghadiya: List<ChoghadiyaItem>,
    val nightChoghadiya: List<ChoghadiyaItem>
)

data class DailyPanchang(
    val dateString: String,
    val gregorianDay: Int,
    val gregorianMonth: Int,
    val gregorianYear: Int,
    val dayOfWeek: String,
    val vikramSamvat: Int,
    val shakaSamvat: Int,
    val hinduMonth: String,
    val tithiNumber: Int, // 1..30
    val tithiName: String,
    val tithiEndTime: String,
    val paksha: Paksha,
    val nakshatra: String,
    val nakshatraEndTime: String,
    val yoga: String,
    val karana: String,
    val sunSign: String,
    val moonSign: String,
    val sunrise: String,
    val sunset: String,
    val moonrise: String,
    val moonset: String,
    val abhijitMuhurat: String,
    val rahuKaal: String,
    val yamagandaKaal: String,
    val gulikaKaal: String,
    val amritKaal: String,
    val brahmaMuhurat: String,
    val ritu: String,
    val ayana: String,
    val panchak: PanchakInfo,
    val bichhuda: BichhudaInfo,
    val festivals: List<String>,
    val vrats: List<String>,
    val choghadiya: DailyChoghadiya
)

data class RashiDetail(
    val rashiName: String,
    val englishName: String,
    val symbol: String,
    val prediction: String,
    val luckyNumber: Int,
    val luckyColor: String,
    val luckyDirection: String,
    val remedy: String
)

data class VratKathaItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: String,
    val pujaVidhi: String,
    val kathaStory: String,
    val significance: String,
    val aartiMantra: String
)

enum class CalendarThemeOption(val displayName: String, val previewColorHex: Long) {
    SHVET_SHYAM("श्वेत व श्याम (White & Black)", 0xFF000000),
    KESAR_GOLD("केसरिया (Kesar Gold)", 0xFFE65100),
    SINDOOR_MAROON("सिंदूरी (Sindoor Maroon)", 0xFF880E4F),
    MAYUR_PEACOCK("मयूर (Mayur Peacock)", 0xFF00695C),
    CHANDAN_LOTUS("चंदन (Chandan Lotus)", 0xFFAD1457)
}

enum class AppLanguage(val code: String, val nativeName: String, val englishName: String) {
    HINDI("hi", "हिन्दी", "Hindi"),
    MARATHI("mr", "मराठी", "Marathi"),
    BENGALI("bn", "বাংলা", "Bengali"),
    TAMIL("ta", "தமிழ்", "Tamil"),
    GUJARATI("gu", "ગુજરાતી", "Gujarati"),
    TELUGU("te", "తెలుగు", "Telugu"),
    ENGLISH("en", "English", "English")
}
