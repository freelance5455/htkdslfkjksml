package com.example.model

data class ParsedQr(
    val rawText: String,
    val category: QrCategory,
    val title: String,
    val subtitle: String,
    val primaryActionLabel: String,
    val extraDetails: Map<String, String> = emptyMap(),
    val displayContent: String = rawText,
    val actionableUri: String? = null,
    val isSecureWeb: Boolean = false
)
