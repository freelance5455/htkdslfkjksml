package com.example.model

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class CapturedPhoto(
    val id: String = UUID.randomUUID().toString(),
    val filePath: String,
    val timestamp: Long = System.currentTimeMillis(),
    val triggerName: String,
    val triggerColorHex: String,
    val matchConfidence: Float, // 0..100
    val isAutoCaptured: Boolean = true,
    val width: Int = 0,
    val height: Int = 0
) {
    val file: File
        get() = File(filePath)

    val formattedDate: String
        get() {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }

    val fileSizeKb: Long
        get() = if (file.exists()) file.length() / 1024 else 0L
}

data class DetectionState(
    val isTriggered: Boolean = false,
    val activeTrigger: TargetTrigger? = null,
    val confidencePercent: Float = 0f,
    val matchStats: Map<String, Float> = emptyMap(),
    val sampledColorHex: String = "#000000",
    val sampledColorRgb: Int = 0,
    val fps: Int = 0
)

enum class DetectionRegion {
    CENTER_RETICLE, // Central 45% box
    FULL_FRAME // Entire camera frame
}
