package com.example.model

enum class BitDepth(val label: String, val bits: Int, val bytesPerSample: Int) {
    BIT_16("16-Bit Studio Standard", 16, 2),
    BIT_24("24-Bit Pro Master", 24, 3)
}

enum class ReverbType(val displayName: String, val description: String) {
    OFF("Off", "Pure delay only"),
    STUDIO_ROOM("Studio Room", "Warm natural acoustic reflection"),
    SACRED_HALL("Sacred Hall", "Lush vocal presence for Naat & Nasheed"),
    GRAND_MASJID("Grand Masjid", "Spacious cathedral-scale spatial tail")
}

enum class DelayRangeMode(val displayName: String, val minMs: Int, val maxMs: Int) {
    SHORT("50ms", 20, 100),
    MEDIUM("200ms", 100, 350),
    LONG("800ms", 350, 800),
    FREE("Free", 20, 1000)
}

data class AudioEffectsConfig(
    val echoLevel: Float = 0.60f,       // 0.0f .. 1.0f
    val delayTimeMs: Int = 280,         // 20 .. 1000 ms
    val feedback: Float = 0.48f,        // 0.0f .. 0.90f
    val toneDamp: Float = 0.65f,        // 0.0f (darkest analog warmth) .. 1.0f (bright)
    val reverbType: ReverbType = ReverbType.SACRED_HALL,
    val reverbLevel: Float = 0.35f,     // 0.0f .. 1.0f
    val reverbDecay: Float = 0.65f,     // 0.1f .. 0.95f
    val dryLevel: Float = 0.95f,        // 0.0f .. 1.0f
    val wetLevel: Float = 0.65f,        // 0.0f .. 1.0f
    val masterGain: Float = 1.0f,       // 0.5f .. 1.5f
    val isMonitorEnabled: Boolean = false,
    val bitDepth: BitDepth = BitDepth.BIT_16,
    val sampleRate: Int = 44100
)

data class AudioPreset(
    val id: String,
    val name: String,
    val subtitle: String,
    val config: AudioEffectsConfig,
    val isBuiltIn: Boolean = false
)

data class RecordingItem(
    val id: String,
    val fileName: String,
    val filePath: String,
    val durationMs: Long,
    val timestamp: Long,
    val fileSizeBytes: Long,
    val bitDepth: BitDepth,
    val sampleRate: Int
)

enum class RecordingState {
    IDLE,
    RECORDING,
    PAUSED
}
