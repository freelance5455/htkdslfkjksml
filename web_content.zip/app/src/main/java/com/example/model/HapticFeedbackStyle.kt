package com.example.model

enum class HapticFeedbackStyle(val displayName: String, val description: String) {
    LIGHT_TICK("Light Tick", "Subtle crisp tick on scan"),
    CRISP_CLICK("Crisp Click", "Standard tactile confirmation click"),
    DOUBLE_TAP("Double Pulse", "Distinct double confirmation pulse"),
    HEAVY_CONFIRM("Strong Buzz", "Punchy prominent vibration")
}
