package com.example.model

enum class Category(val label: String) {
    YOUTUBER("Top YouTubers"),
    COMPANY("Company Logo"),
    MOBILE("Mobile & Tech"),
    CAR("Supercars & Autos"),
    CLOTHES("Fashion & Streetwear"),
    APP_GAME("Apps & Games")
}

data class ZoomTarget(
    val x: Float, // 0..100 center X percent
    val y: Float, // 0..100 center Y percent
    val initialScale: Float = 4.5f,
    val stage2Scale: Float = 2.8f,
    val stage3Scale: Float = 1.7f
)

data class QuizHints(
    val clue1: String,
    val clue2: String
)

data class QuizItem(
    val id: String,
    val name: String,
    val cleanAnswer: String,
    val aliases: List<String> = emptyList(),
    val category: String,
    val categoryLabel: String,
    val level: Int,
    val difficulty: String,
    val zoom: ZoomTarget,
    val hints: QuizHints,
    val primaryColor: Long,
    val bgColor: Long,
    val accentColor: Long,
    val description: String,
    val logoType: String = id
)

data class LevelInfo(
    val levelNumber: Int,
    val title: String,
    val theme: String,
    val requiredScore: Int,
    val requiredSolved: Int,
    val badge: String,
    val description: String
)

data class LeaderboardEntry(
    val id: String,
    val name: String,
    val score: Int,
    val level: Int,
    val accuracy: Int,
    val avatar: String,
    val timestamp: String,
    val streak: Int
)

data class DailyRecord(
    val date: String,
    val itemId: String,
    val solved: Boolean,
    val scoreEarned: Int,
    val bonusPoints: Int,
    val zoomStage: Int,
    val completedAt: String
)

data class UserStats(
    val playerName: String = "Player_" + (1000..9999).random(),
    val avatar: String = "🎮",
    val score: Int = 0,
    val coins: Int = 150,
    val currentLevel: Int = 1,
    val streak: Int = 0,
    val highestStreak: Int = 0,
    val solvedIds: Set<String> = emptySet(),
    val unlockedLevels: Set<Int> = setOf(1),
    val totalGuesses: Int = 0,
    val correctGuesses: Int = 0,
    val dailyStreak: Int = 0,
    val highestDailyStreak: Int = 0,
    val lastDailyDate: String? = null,
    val dailyHistory: Map<String, DailyRecord> = emptyMap(),
    val claimedTaskIds: Set<String> = emptySet(),
    val stage1Solves: Int = 0,
    val hintsUsed: Int = 0,
    val dailyCompletedCount: Int = 0,
    val playerTitle: String = "Novice Sleuth",
    val profileTheme: String = "Amber",
    val xp: Int = 0
) {
    val unlockedLevel: Int get() = unlockedLevels.maxOrNull() ?: 1
    val totalSolved: Int get() = solvedIds.size
    val bestStreak: Int get() = highestStreak
    val dailyStreakDays: Int get() = dailyStreak

    // XP & Level calculations
    val totalXp: Int get() = if (xp > 0) xp else maxOf(score, solvedIds.size * 60 + stage1Solves * 30 + dailyCompletedCount * 100)
    val playerRankLevel: Int get() = maxOf(1, (totalXp / 250) + 1)
    val currentLevelXp: Int get() = totalXp % 250
    val nextLevelXpRequired: Int get() = 250
    val xpProgress: Float get() = (currentLevelXp.toFloat() / nextLevelXpRequired).coerceIn(0f, 1f)
}
