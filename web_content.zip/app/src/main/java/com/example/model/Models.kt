package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

object JobyConstants {
  const val ADMIN_BOOTSTRAP_EMAIL = "emailforbusiness1073@gmail.com"

  val INDIAN_STATES = listOf(
    "All India",
    "Andhra Pradesh",
    "Assam",
    "Bihar",
    "Chandigarh",
    "Chhattisgarh",
    "Delhi NCR",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu & Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Tamil Nadu",
    "Telangana",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal"
  )

  val JOB_CATEGORIES = listOf(
    "All",
    "Technology",
    "Delivery & Logistics",
    "Retail & Sales",
    "Design & Media",
    "Finance & Ops",
    "Teaching & Tutoring",
    "Hospitality",
    "Healthcare",
    "Trades & Field Work"
  )

  val JOB_TYPES = listOf(
    "ALL",
    "FULL_TIME",
    "PART_TIME",
    "GIG",
    "FREELANCE",
    "INTERNSHIP",
    "DAILY_WAGE",
    "REMOTE"
  )

  fun jobTypeLabel(type: String): String = when (type) {
    "FULL_TIME" -> "Full-Time"
    "PART_TIME" -> "Part-Time"
    "GIG" -> "Gig"
    "FREELANCE" -> "Freelance"
    "INTERNSHIP" -> "Internship"
    "DAILY_WAGE" -> "Daily Wage"
    "REMOTE" -> "Remote"
    else -> "All Types"
  }

  fun experienceLabel(exp: String): String = when (exp) {
    "FRESHER" -> "Fresher"
    "1_3_YRS" -> "1–3 Yrs"
    "3_PLUS_YRS" -> "3+ Yrs"
    else -> exp
  }

  fun salaryPeriodLabel(period: String): String = when (period) {
    "MONTH" -> "/mo"
    "DAY" -> "/day"
    "HOUR" -> "/hr"
    "PROJECT" -> "/project"
    else -> ""
  }
}

@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val displayName: String = "",
  val email: String = "",
  val phone: String = "",
  val state: String = "Karnataka",
  val city: String = "Bengaluru",
  val pincode: String = "560001",
  val role: String = "SEEKER", // SEEKER, EMPLOYER
  val age: Long = 22L,
  val isAgeVerified: Boolean = true,
  val accountStatus: String = "ACTIVE", // ACTIVE, SUSPENDED
  val skills: List<String> = emptyList(),
  val education: String = "",
  val bio: String = "",
  val resumeLabel: String = "",
  val preferredJobTypes: List<String> = emptyList(),
  val savedJobIds: List<String> = emptyList(),
  val subscriptionTier: String = "FREE", // FREE, JOBY_PLUS, ENTERPRISE
  val companyName: String = "",
  val companyVerified: Boolean = false,
  val gstOrRegNumber: String = "",
  val preferredLanguage: String = "EN", // EN, HI, TA
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  fun profileCompletionPercent(): Int {
    val checks = if (role == "EMPLOYER") {
      listOf(
        displayName.isNotBlank(),
        companyName.isNotBlank(),
        city.isNotBlank(),
        pincode.isNotBlank(),
        phone.isNotBlank(),
        bio.isNotBlank(),
        gstOrRegNumber.isNotBlank()
      )
    } else {
      listOf(
        displayName.isNotBlank(),
        city.isNotBlank(),
        pincode.isNotBlank(),
        phone.isNotBlank(),
        education.isNotBlank(),
        skills.isNotEmpty(),
        resumeLabel.isNotBlank(),
        bio.isNotBlank()
      )
    }
    return ((checks.count { it }.toFloat() / checks.size) * 100).toInt()
  }

  fun toCreateMap(): Map<String, Any> = buildMap {
    put("userId", userId)
    put("displayName", displayName)
    if (email.isNotBlank()) put("email", email)
    if (phone.isNotBlank()) put("phone", phone)
    if (state.isNotBlank()) put("state", state)
    if (city.isNotBlank()) put("city", city)
    if (pincode.isNotBlank()) put("pincode", pincode)
    put("role", role)
    put("age", age)
    put("isAgeVerified", isAgeVerified)
    put("accountStatus", accountStatus)
    put("skills", skills.take(15))
    if (education.isNotBlank()) put("education", education)
    if (bio.isNotBlank()) put("bio", bio)
    if (resumeLabel.isNotBlank()) put("resumeLabel", resumeLabel)
    put("preferredJobTypes", preferredJobTypes.take(8))
    put("savedJobIds", savedJobIds.take(50))
    put("subscriptionTier", subscriptionTier)
    if (companyName.isNotBlank()) put("companyName", companyName)
    put("companyVerified", companyVerified)
    if (gstOrRegNumber.isNotBlank()) put("gstOrRegNumber", gstOrRegNumber)
    put("preferredLanguage", preferredLanguage)
    put("createdAt", FieldValue.serverTimestamp())
    put("updatedAt", FieldValue.serverTimestamp())
  }
}

@IgnoreExtraProperties
data class JobListing(
  @DocumentId val id: String = "",
  val employerId: String = "",
  val companyName: String = "",
  val companyVerified: Boolean = false,
  val title: String = "",
  val category: String = "Technology",
  val jobType: String = "FULL_TIME",
  val state: String = "Karnataka",
  val city: String = "Bengaluru",
  val pincode: String = "560001",
  val isRemote: Boolean = false,
  val salaryMinInr: Long = 0L,
  val salaryMaxInr: Long = 0L,
  val salaryPeriod: String = "MONTH",
  val experienceLevel: String = "FRESHER",
  val description: String = "",
  val requirements: String = "",
  val minAge: Long = 18L,
  val isHazardousOrRestricted: Boolean = false,
  val applicationFee: Long = 0L,
  val moderationStatus: String = "PENDING", // PENDING, APPROVED, REJECTED
  val isActive: Boolean = true,
  val applicantCount: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  fun toCreateMap(status: String = "PENDING"): Map<String, Any> = mapOf(
    "employerId" to employerId,
    "companyName" to companyName,
    "companyVerified" to companyVerified,
    "title" to title,
    "category" to category,
    "jobType" to jobType,
    "state" to state,
    "city" to city,
    "pincode" to pincode,
    "isRemote" to isRemote,
    "salaryMinInr" to salaryMinInr,
    "salaryMaxInr" to salaryMaxInr,
    "salaryPeriod" to salaryPeriod,
    "experienceLevel" to experienceLevel,
    "description" to description,
    "requirements" to requirements,
    "minAge" to if (isHazardousOrRestricted && minAge < 18L) 18L else minAge,
    "isHazardousOrRestricted" to isHazardousOrRestricted,
    "applicationFee" to 0L,
    "moderationStatus" to status,
    "isActive" to isActive,
    "applicantCount" to 0L,
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
  )
}

@IgnoreExtraProperties
data class SideQuest(
  @DocumentId val id: String = "",
  val employerId: String = "",
  val posterName: String = "",
  val title: String = "",
  val category: String = "Field Audit",
  val description: String = "",
  val deliverableSpec: String = "",
  val payoutInr: Long = 0L,
  val estimatedMinutes: Long = 30L,
  val city: String = "Bengaluru",
  val state: String = "Karnataka",
  val isRemote: Boolean = false,
  val minAge: Long = 18L,
  val isHazardousOrRestricted: Boolean = false,
  val applicationFee: Long = 0L,
  val moderationStatus: String = "PENDING", // PENDING, APPROVED, REJECTED
  val questStatus: String = "OPEN", // OPEN, ASSIGNED, COMPLETION_SUBMITTED, PAID, CANCELLED
  val assignedSeekerId: String = "",
  val assignedSeekerName: String = "",
  val proofNote: String = "",
  val paymentReference: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  fun toCreateMap(status: String = "PENDING"): Map<String, Any> = mapOf(
    "employerId" to employerId,
    "posterName" to posterName,
    "title" to title,
    "category" to category,
    "description" to description,
    "deliverableSpec" to deliverableSpec,
    "payoutInr" to payoutInr,
    "estimatedMinutes" to estimatedMinutes,
    "city" to city,
    "state" to state,
    "isRemote" to isRemote,
    "minAge" to if (isHazardousOrRestricted && minAge < 18L) 18L else minAge,
    "isHazardousOrRestricted" to isHazardousOrRestricted,
    "applicationFee" to 0L,
    "moderationStatus" to status,
    "questStatus" to "OPEN",
    "createdAt" to FieldValue.serverTimestamp(),
    "updatedAt" to FieldValue.serverTimestamp()
  )
}

@IgnoreExtraProperties
data class JobApplication(
  @DocumentId val id: String = "",
  val seekerId: String = "",
  val seekerName: String = "",
  val seekerAge: Long = 18L,
  val seekerCity: String = "",
  val seekerSkills: List<String> = emptyList(),
  val seekerBio: String = "",
  val resumeLabel: String = "",
  val jobId: String = "",
  val jobTitle: String = "",
  val companyName: String = "",
  val employerId: String = "",
  val coverNote: String = "",
  val status: String = "APPLIED", // APPLIED, VIEWED, SHORTLISTED, INTERVIEW, SELECTED, REJECTED, WITHDRAWN
  val interviewNote: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
) {
  fun toCreateMap(): Map<String, Any> = buildMap {
    put("seekerId", seekerId)
    put("seekerName", seekerName)
    put("seekerAge", seekerAge)
    put("seekerCity", seekerCity)
    put("seekerSkills", seekerSkills.take(15))
    put("seekerBio", seekerBio)
    put("resumeLabel", resumeLabel.ifBlank { "JOBY Verified Profile" })
    put("jobId", jobId)
    put("jobTitle", jobTitle)
    put("companyName", companyName)
    put("employerId", employerId)
    put("coverNote", coverNote)
    put("status", "APPLIED")
    put("createdAt", FieldValue.serverTimestamp())
    put("updatedAt", FieldValue.serverTimestamp())
  }
}

@IgnoreExtraProperties
data class Conversation(
  @DocumentId val id: String = "",
  val participantIds: List<String> = emptyList(),
  val seekerId: String = "",
  val employerId: String = "",
  val seekerName: String = "",
  val employerName: String = "",
  val jobTitle: String = "",
  val lastMessage: String = "",
  @ServerTimestamp val lastMessageAt: Timestamp? = null,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ChatMessage(
  @DocumentId val id: String = "",
  val participantIds: List<String> = emptyList(),
  val senderId: String = "",
  val senderName: String = "",
  val text: String = "",
  val attachmentLabel: String = "",
  val isRead: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AppNotification(
  @DocumentId val id: String = "",
  val recipientId: String = "",
  val type: String = "SYSTEM",
  val title: String = "",
  val body: String = "",
  val isRead: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class SubscriptionPlan(
  @DocumentId val id: String = "",
  val code: String = "FREE",
  val name: String = "",
  val priceInr: Long = 0L,
  val billingCycle: String = "MONTHLY",
  val maxActiveJobs: Long = 3L,
  val featuredBoosts: Long = 0L,
  val verifiedBadge: Boolean = false,
  val isActive: Boolean = true,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PaymentTransaction(
  @DocumentId val id: String = "",
  val userId: String = "",
  val userName: String = "",
  val type: String = "SUBSCRIPTION",
  val referenceId: String = "",
  val title: String = "",
  val amountInr: Long = 0L,
  val paymentMethod: String = "UPI",
  val status: String = "COMPLETED",
  val invoiceNumber: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ModerationReport(
  @DocumentId val id: String = "",
  val reporterId: String = "",
  val targetType: String = "JOB",
  val targetId: String = "",
  val targetTitle: String = "",
  val reason: String = "",
  val details: String = "",
  val status: String = "OPEN", // OPEN, RESOLVED, DISMISSED
  val adminNote: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)
