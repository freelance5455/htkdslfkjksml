package com.example.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class Provider(
    @DocumentId val id: String = "",
    val name: String = "",
    val category: String = "electrician", // electrician, plumber, other_repairs
    val city: String = "Tulsipur", // Tulsipur, Ghorahi, Lamahi, Bhalubang
    val description: String = "",
    val phone: String = "",
    val phonePublic: Boolean = true,
    val active: Boolean = true,
    val rating: Double = 4.8,
    val experienceYears: Long = 3L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun toMap(): Map<String, Any> {
        val map = mutableMapOf<String, Any>(
            "name" to name,
            "category" to category,
            "city" to city,
            "description" to description,
            "phonePublic" to phonePublic,
            "active" to active,
            "rating" to rating,
            "experienceYears" to experienceYears
        )
        if (phone.isNotBlank()) {
            map["phone"] = phone
        }
        return map
    }
}

@IgnoreExtraProperties
data class Booking(
    @DocumentId val id: String = "",
    val customerUid: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val providerId: String = "",
    val providerName: String = "",
    val category: String = "",
    val city: String = "",
    val address: String = "",
    val description: String = "",
    val preferredDate: String = "",
    val preferredTime: String = "",
    val status: String = "pending", // pending, accepted, completed, cancelled
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AdminUser(
    @DocumentId val id: String = "",
    val role: String = "admin",
    val email: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

enum class ServiceCategory(
    val id: String,
    val labelNepali: String,
    val labelEnglish: String,
    val descriptionNepali: String
) {
    ELECTRICIAN(
        id = "electrician",
        labelNepali = "इलेक्ट्रिसियन",
        labelEnglish = "Electrician",
        descriptionNepali = "वायरिङ, स्विचबोर्ड, मिटर, फ्यान र बिजुली मर्मत"
    ),
    PLUMBER(
        id = "plumber",
        labelNepali = "प्लम्बर",
        labelEnglish = "Plumber",
        descriptionNepali = "धारा, पाइप फिटिङ, चुहावट, ट्याङ्की र सेनेटरी मर्मत"
    ),
    OTHER_REPAIRS(
        id = "other_repairs",
        labelNepali = "अन्य मर्मत",
        labelEnglish = "Other Repairs",
        descriptionNepali = "टिभी, फ्रिज, मोटर, ग्यास चुल्हो र घरेलु उपकरण मर्मत"
    );

    companion object {
        fun fromId(id: String): ServiceCategory {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: OTHER_REPAIRS
        }
    }
}

object NepalLocations {
    val CITIES = listOf(
        "Tulsipur",
        "Ghorahi",
        "Lamahi",
        "Bhalubang"
    )

    fun getNepaliName(city: String): String {
        return when (city.lowercase()) {
            "tulsipur" -> "तुलसीपुर (Tulsipur)"
            "ghorahi" -> "घोराही (Ghorahi)"
            "lamahi" -> "लमही (Lamahi)"
            "bhalubang" -> "भालुवाङ (Bhalubang)"
            else -> city
        }
    }
}
