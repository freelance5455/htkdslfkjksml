package com.example.model

data class UrlMetadata(
    val url: String,
    val title: String? = null,
    val description: String? = null,
    val faviconUrl: String? = null,
    val host: String,
    val isLoading: Boolean = false,
    val error: String? = null
)
