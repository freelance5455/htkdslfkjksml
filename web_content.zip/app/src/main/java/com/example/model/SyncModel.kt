package com.example.model

data class SyncPlaylist(
    val id: String,
    val name: String,
    val songIds: List<String>,
    val createdAt: Long = System.currentTimeMillis()
)

data class SyncBundle(
    val version: Int = 1,
    val deviceName: String = "PrismSound Android",
    val exportedAt: Long = System.currentTimeMillis(),
    val pairingCode: String,
    val favoriteSongIds: List<String>,
    val songTagAssignments: Map<String, List<String>>,
    val customEqualizerPresets: List<EqualizerPreset>,
    val activeEqualizerPresetName: String,
    val activeVisualizerId: Int,
    val customPlaylists: List<SyncPlaylist>
)

enum class SyncStatus {
    IDLE,
    SYNCING,
    SYNCED,
    FAILED
}

enum class SyncConflictStrategy(val title: String, val description: String) {
    SMART_MERGE("Smart Merge", "Merge tags, playlists, and presets combining changes"),
    LOCAL_WINS("Device Overwrite", "Local device changes overwrite cloud state"),
    REMOTE_WINS("Cloud Overwrite", "Cloud state replaces current device settings")
}

data class SyncDeviceProfile(
    val deviceId: String,
    val pairingCode: String,
    val deviceName: String,
    val cloudServerUrl: String = "https://sync.prismsound.cloud/api/v1",
    val isAutoSyncEnabled: Boolean = true,
    val lastSyncTimestamp: Long? = null,
    val status: SyncStatus = SyncStatus.SYNCED,
    val statusMessage: String = "All libraries and presets up to date"
)
