package com.example.model

data class VisitResult(
    val index: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val url: String,
    val method: String,
    val statusCode: Int,
    val statusMessage: String,
    val latencyMs: Long,
    val bytesReceived: Long,
    val isSuccess: Boolean,
    val errorMessage: String? = null,
    val sessionProfile: SessionProfile,
    val requestHeadersSent: Map<String, String>,
    val responseHeadersReceived: Map<String, String>,
    val cookiesReceived: List<String> = emptyList(),
    val responseBodyPreview: String = "",
    val serverIdentifier: String = "Unknown Server",
    val serverTimestamp: String = "",
    val engineName: String = "HTTP Client"
)
