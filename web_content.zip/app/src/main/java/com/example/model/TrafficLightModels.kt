package com.example.model

enum class LightColor {
    RED,
    YELLOW,
    GREEN,
    OFF
}

enum class SignalPhase(val titleAr: String, val titleEn: String, val descAr: String) {
    RED("أحمر (قف)", "Red (Stop)", "يجب التوقف تماماً عند خط الوقوف وعدم تجاوزه."),
    RED_YELLOW("أحمر وأصفر (استعد)", "Red & Yellow (Prepare)", "استعد للانطلاق عند إضاءة الأخضر فقط."),
    YELLOW("أصفر (استعد)", "Yellow (Caution)", "الضوء الأصفر يعني التهدئة والاستعداد للوقوف إذا كان ذلك آمناً."),
    GREEN("أخضر (انطلق)", "Green (Go)", "انطلق بحذر مع التأكد من خلو التقاطع والممر."),
    FLASHING_YELLOW("وميض أصفر (تحذير)", "Flashing Yellow", "هدئ السرعة وتوخ الحذر مع إعطاء الأولوية."),
    FLASHING_RED("وميض أحمر (قف وتأكد)", "Flashing Red", "توقف تماماً كإشارة قف، ثم انطلق عندما يخلو الطريق."),
    OFF("مطفأة", "Off", "الإشارة في وضع الإطفاء.")
}

enum class OperatingMode(val titleAr: String, val titleEn: String) {
    AUTOMATIC("تلقائي", "Automatic"),
    MANUAL("يدوي", "Manual"),
    NIGHT_FLASH("وميض تحذيري", "Flashing / Night")
}

enum class PedestrianState(val titleAr: String) {
    DONT_WALK("ممنوع العبور"),
    WALK("اعبر بأمان"),
    FLASHING_DONT_WALK("أوشك الوقت على النفاد")
}

enum class SequenceStyle(val titleAr: String) {
    STANDARD("عالمي قياسي (أحمر -> أخضر -> أصفر)"),
    EUROPEAN("أوروبي (أحمر -> أحمر وأصفر -> أخضر -> أصفر)")
}

data class TrafficConfig(
    val redDuration: Int = 10,
    val yellowDuration: Int = 3,
    val greenDuration: Int = 12,
    val pedestrianWalkDuration: Int = 8,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val sequenceStyle: SequenceStyle = SequenceStyle.STANDARD
)

data class CarModel(
    val id: Long,
    val positionX: Float, // 0f to 1f (relative across screen width)
    val speed: Float,
    val colorHex: Long,
    val isBraking: Boolean = false,
    val isStopped: Boolean = false,
    val typeName: String = "sedan" // sedan, suv, bus, taxi
)

data class PedestrianModel(
    val id: Long,
    val positionY: Float, // 0f (top of crosswalk) to 1f (bottom)
    val speed: Float,
    val isWalking: Boolean = false,
    val clothesColorHex: Long = 0xFF42A5F5
)

data class QuizQuestion(
    val id: Int,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)
