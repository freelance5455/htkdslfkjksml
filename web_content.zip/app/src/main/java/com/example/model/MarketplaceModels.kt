package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp
import java.text.NumberFormat
import java.util.Locale

object MarketplaceConstants {
    const val ADMIN_AIRTEL_NUMBER = "0788016987"
    const val ADMIN_EMAIL = "joshuachota04@gmail.com"
    const val COMMISSION_RATE_PERCENT = 5L
    const val MONTHLY_SUBSCRIPTION_FEE_TZS = 20_000L
    const val SUBSCRIPTION_DAYS = 30L

    val TANZANIA_LOCATIONS = listOf(
        "Dar es Salaam",
        "Arusha",
        "Mwanza",
        "Dodoma",
        "Mbeya",
        "Zanzibar",
        "Morogoro",
        "Tanga",
        "Kilimanjaro",
        "Mtwara"
    )
}

object TzsFormatter {
    fun format(amount: Long): String {
        val formatter = NumberFormat.getNumberInstance(Locale.US)
        return "TZS ${formatter.format(amount)}"
    }
}

object CommissionCalculator {
    fun calculateCommission(amountTzs: Long, model: RevenueModel): Long {
        if (amountTzs <= 0L) return 0L
        return when (model) {
            RevenueModel.COMMISSION -> (amountTzs * MarketplaceConstants.COMMISSION_RATE_PERCENT) / 100L
            RevenueModel.MONTHLY_SUBSCRIPTION -> 0L
        }
    }
}

enum class ServiceCategory {
    SECURITY_GUARDS,
    CCTV_INSTALLATION,
    ELECTRIC_FENCE,
    ALARM_SYSTEMS,
    ACCESS_CONTROL,
    GPS_TRACKING,
    FIRE_DETECTION,
    SECURITY_CONSULTATION,
    EQUIPMENT_SUPPLY,
    SECURITY_MAINTENANCE;

    companion object {
        fun safeValueOf(raw: String?): ServiceCategory =
            entries.firstOrNull { it.name == raw } ?: SECURITY_GUARDS
    }
}

enum class VerificationStatus {
    PENDING,
    VERIFIED,
    REJECTED,
    SUSPENDED;

    companion object {
        fun safeValueOf(raw: String?): VerificationStatus =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

enum class RevenueModel {
    COMMISSION,
    MONTHLY_SUBSCRIPTION;

    companion object {
        fun safeValueOf(raw: String?): RevenueModel =
            entries.firstOrNull { it.name == raw } ?: COMMISSION
    }
}

enum class SubscriptionStatus {
    INACTIVE,
    ACTIVE,
    EXPIRING_SOON,
    EXPIRED;

    companion object {
        fun safeValueOf(raw: String?): SubscriptionStatus =
            entries.firstOrNull { it.name == raw } ?: INACTIVE
    }
}

enum class OrderStatus(val stepIndex: Int) {
    REQUESTED(1),
    PROVIDER_RECEIVED(2),
    QUOTATION_SUBMITTED(3),
    QUOTATION_ACCEPTED(4),
    PAYMENT_INITIATED(5),
    PAYMENT_CONFIRMED(6),
    SERVICE_DELIVERED(7),
    COMPLETION_CONFIRMED(8),
    COMMISSION_CALCULATED(9),
    CLOSED(10),
    CANCELLED(0),
    DISPUTED(0);

    companion object {
        fun safeValueOf(raw: String?): OrderStatus =
            entries.firstOrNull { it.name == raw } ?: REQUESTED
    }
}

enum class PaymentStatus {
    UNPAID,
    INITIATED,
    PENDING_CALLBACK,
    VERIFIED,
    FAILED;

    companion object {
        fun safeValueOf(raw: String?): PaymentStatus =
            entries.firstOrNull { it.name == raw } ?: UNPAID
    }
}

enum class ComplaintStatus {
    OPEN,
    UNDER_REVIEW,
    RESOLVED,
    DISMISSED;

    companion object {
        fun safeValueOf(raw: String?): ComplaintStatus =
            entries.firstOrNull { it.name == raw } ?: OPEN
    }
}

enum class ActiveAppRole {
    CUSTOMER,
    PROVIDER,
    ADMIN
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val region: String = "Dar es Salaam",
    val address: String = "",
    val preferredLanguage: String = "sw",
    val activeRole: String = "customer",
    val providerId: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SecurityProvider(
    @DocumentId val id: String = "",
    val ownerId: String = "",
    val companyName: String = "",
    val description: String = "",
    val categories: List<String> = emptyList(),
    val locations: List<String> = emptyList(),
    val startingPriceTzs: Long = 0L,
    val businessRegNumber: String = "",
    val securityLicenseNumber: String = "",
    val contactPhone: String = "",
    val logoBase64: String? = null,
    val galleryBase64: List<String> = emptyList(),
    val verificationStatus: String = VerificationStatus.PENDING.name,
    val verifiedBadge: Boolean = false,
    val featured: Boolean = false,
    val revenueModel: String = RevenueModel.COMMISSION.name,
    val subscriptionStatus: String = SubscriptionStatus.INACTIVE.name,
    val subscriptionExpiresAt: Timestamp? = null,
    val ratingAvg: Double = 0.0,
    val ratingCount: Long = 0L,
    val completedOrdersCount: Long = 0L,
    val totalEarningsTzs: Long = 0L,
    val commissionOwedTzs: Long = 0L,
    val commissionCollectedTzs: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun verificationEnum(): VerificationStatus = VerificationStatus.safeValueOf(verificationStatus)
    fun revenueEnum(): RevenueModel = RevenueModel.safeValueOf(revenueModel)
    fun subscriptionEnum(): SubscriptionStatus = SubscriptionStatus.safeValueOf(subscriptionStatus)

    fun isEligibleToReceiveOrders(nowMillis: Long = System.currentTimeMillis()): Boolean {
        return when (revenueEnum()) {
            RevenueModel.COMMISSION -> true
            RevenueModel.MONTHLY_SUBSCRIPTION -> {
                val exp = subscriptionExpiresAt?.toDate()?.time ?: 0L
                exp > nowMillis && (subscriptionEnum() == SubscriptionStatus.ACTIVE || subscriptionEnum() == SubscriptionStatus.EXPIRING_SOON)
            }
        }
    }

    fun daysUntilSubscriptionExpiry(nowMillis: Long = System.currentTimeMillis()): Long? {
        if (revenueEnum() != RevenueModel.MONTHLY_SUBSCRIPTION) return null
        val exp = subscriptionExpiresAt?.toDate()?.time ?: return 0L
        val diff = exp - nowMillis
        return if (diff <= 0L) 0L else (diff / (24L * 60L * 60L * 1000L)) + 1L
    }
}

@Keep
@IgnoreExtraProperties
data class SecurityServiceListing(
    @DocumentId val id: String = "",
    val providerId: String = "",
    val ownerId: String = "",
    val companyName: String = "",
    val providerVerified: Boolean = false,
    val category: String = ServiceCategory.SECURITY_GUARDS.name,
    val title: String = "",
    val description: String = "",
    val priceTzs: Long = 0L,
    val priceUnit: String = "fixed",
    val location: String = "Dar es Salaam",
    val offerBadge: String? = null,
    val discountPercent: Long = 0L,
    val active: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun categoryEnum(): ServiceCategory = ServiceCategory.safeValueOf(category)
}

@Keep
@IgnoreExtraProperties
data class SecurityOrder(
    @DocumentId val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val providerId: String = "",
    val providerOwnerId: String = "",
    val providerName: String = "",
    val serviceId: String? = null,
    val serviceCategory: String = ServiceCategory.SECURITY_GUARDS.name,
    val serviceTitle: String = "",
    val location: String = "",
    val requirementDescription: String = "",
    val attachmentPreviews: List<String> = emptyList(),
    val quotedAmountTzs: Long = 0L,
    val quotationNotes: String? = null,
    val commissionModel: String = RevenueModel.COMMISSION.name,
    val commissionRatePercent: Long = 5L,
    val commissionAmountTzs: Long = 0L,
    val paymentStatus: String = PaymentStatus.UNPAID.name,
    val paymentReference: String? = null,
    val status: String = OrderStatus.REQUESTED.name,
    val cancellationReason: String? = null,
    val disputeReason: String? = null,
    val ratingStars: Long? = null,
    val ratingComment: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun statusEnum(): OrderStatus = OrderStatus.safeValueOf(status)
    fun paymentEnum(): PaymentStatus = PaymentStatus.safeValueOf(paymentStatus)
    fun categoryEnum(): ServiceCategory = ServiceCategory.safeValueOf(serviceCategory)
    fun revenueEnum(): RevenueModel = RevenueModel.safeValueOf(commissionModel)
}

@Keep
@IgnoreExtraProperties
data class OrderMessage(
    @DocumentId val id: String = "",
    val orderId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val participantIds: List<String> = emptyList(),
    val text: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PaymentTransaction(
    @DocumentId val id: String = "",
    val payerId: String = "",
    val payerName: String = "",
    val payerPhone: String = "",
    val recipientNumber: String = MarketplaceConstants.ADMIN_AIRTEL_NUMBER,
    val providerId: String = "",
    val providerOwnerId: String = "",
    val orderId: String? = null,
    val paymentType: String = "ORDER_PAYMENT",
    val amountTzs: Long = 0L,
    val commissionTzs: Long = 0L,
    val providerNetTzs: Long = 0L,
    val transactionRef: String = "",
    val receiptNumber: String = "",
    val status: String = PaymentStatus.PENDING_CALLBACK.name,
    val mode: String = "SANDBOX",
    val gatewayMessage: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun statusEnum(): PaymentStatus = PaymentStatus.safeValueOf(status)
}

@Keep
@IgnoreExtraProperties
data class Complaint(
    @DocumentId val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val orderId: String? = null,
    val providerId: String? = null,
    val subject: String = "",
    val description: String = "",
    val status: String = ComplaintStatus.OPEN.name,
    val adminNotes: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    fun statusEnum(): ComplaintStatus = ComplaintStatus.safeValueOf(status)
}

@Keep
@IgnoreExtraProperties
data class AuditLog(
    @DocumentId val id: String = "",
    val actorId: String = "",
    val actorEmail: String = "",
    val action: String = "",
    val targetType: String = "",
    val targetId: String = "",
    val summary: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
