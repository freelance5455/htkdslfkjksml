package com.example.model

enum class HttpMethod {
    GET, HEAD, POST
}

enum class PacingMode(val label: String, val delayMs: Long) {
    RAPID("Rapid (100ms)", 100L),
    STEP_BY_STEP("Step-by-step (350ms)", 350L),
    NATURAL("Human-like (1000ms)", 1000L),
    BURST_ZERO("Zero Delay (Burst)", 0L)
}

enum class ExecutionEngine(val label: String, val badge: String, val description: String) {
    HTTP_CLIENT(
        label = "High-Speed HTTP Engine",
        badge = "FAST",
        description = "Direct socket HTTP/HTTPS requests with isolated cookie jars. Ideal for testing server access logs, NGINX/Apache unique counters, reverse proxy IP attribution, and backend API load."
    ),
    HEADLESS_WEBVIEW(
        label = "Full Browser Engine (WebView)",
        badge = "DOM + JS",
        description = "Renders the webpage inside an isolated Android WebKit WebView. Executes client-side JavaScript, firing Google Analytics 4, Plausible, and client-side tracking pixels before clearing cookies."
    )
}

data class SimulationConfig(
    val url: String = "https://httpbin.org/get",
    val httpMethod: HttpMethod = HttpMethod.GET,
    val totalVisits: Int = 35,
    val pacingMode: PacingMode = PacingMode.STEP_BY_STEP,
    val concurrency: Int = 1, // 1 = sequential step-by-step, 2, 5, 10 = batch
    val executionEngine: ExecutionEngine = ExecutionEngine.HTTP_CLIENT,
    val rotateUserAgents: Boolean = true,
    val rotateReferrers: Boolean = true,
    val rotateLanguages: Boolean = true,
    val rotateSimulatedIps: Boolean = true,
    val isolatedCookies: Boolean = true,
    val followRedirects: Boolean = true,
    val timeoutSeconds: Int = 15,
    val customPayload: String = "",
    val customHeadersString: String = ""
)
