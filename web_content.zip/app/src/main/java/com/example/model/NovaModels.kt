package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class OrderStatus(val label: String) {
    NEW("নতুন"),
    CONFIRMED("কনফার্ম"),
    PROCESSING("প্রসেসিং"),
    SHIPPED("পাঠানো হয়েছে"),
    COMPLETED("সম্পন্ন"),
    CANCELLED("বাতিল");

    val terminal: Boolean
        get() = this == COMPLETED || this == CANCELLED

    companion object {
        fun fromLabel(raw: String?): OrderStatus =
            entries.firstOrNull { it.label == raw } ?: NEW
    }
}

enum class DeliveryZone(val label: String, val subtitle: String) {
    DHAKA_CITY("ঢাকা সিটি", "২৪-৪৮ ঘণ্টার মধ্যে ডেলিভারি"),
    OUTSIDE_DHAKA("ঢাকার বাইরে", "২-৪ কার্যদিবসে সারা বাংলাদেশে");

    companion object {
        fun fromLabel(raw: String?): DeliveryZone =
            entries.firstOrNull { it.label == raw } ?: DHAKA_CITY
    }
}

enum class SortOption(val label: String) {
    POPULAR("জনপ্রিয়"),
    DISCOUNT("সেরা ছাড়"),
    PRICE_LOW("কম দাম"),
    PRICE_HIGH("বেশি দাম")
}

@Keep
@IgnoreExtraProperties
data class Product(
    @DocumentId val id: String = "",
    val name: String = "",
    val category: String = "",
    val price: Long = 0L,
    val oldPrice: Long = 0L,
    val emoji: String = "📦",
    val description: String = "",
    val imageBase64: String? = null,
    val featured: Boolean = false,
    val rating: Double = 4.8,
    val soldCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val discountPercent: Int
        get() = if (oldPrice > price && oldPrice > 0) {
            (((oldPrice - price) * 100.0) / oldPrice).toInt().coerceIn(1, 95)
        } else {
            0
        }
}

@Keep
@IgnoreExtraProperties
data class OrderItem(
    val productId: String = "",
    val name: String = "",
    val price: Long = 0L,
    val qty: Long = 1L,
    val emoji: String = "📦"
)

@Keep
@IgnoreExtraProperties
data class Order(
    @DocumentId val id: String = "",
    val orderNumber: String = "",
    val customerName: String = "",
    val phone: String = "",
    val address: String = "",
    val note: String = "",
    val deliveryZone: String = DeliveryZone.DHAKA_CITY.label,
    val deliveryFee: Long = 60L,
    val subtotal: Long = 0L,
    val total: Long = 0L,
    val status: String = OrderStatus.NEW.label,
    val paymentMethod: String = "Cash on Delivery",
    val items: List<OrderItem> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val statusEnum: OrderStatus
        get() = OrderStatus.fromLabel(status)
}

@Keep
@IgnoreExtraProperties
data class CartItem(
    @DocumentId val id: String = "",
    val productId: String = "",
    val qty: Long = 1L,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class WishlistItem(
    @DocumentId val id: String = "",
    val productId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ShopSettings(
    @DocumentId val id: String = "",
    val shopName: String = "NOVA BAZAR",
    val phone: String = "01764458050",
    val facebookUrl: String = "https://www.facebook.com/share/1EFrX218aV/",
    val adminPin: String = "6708",
    val dhakaDeliveryFee: Long = 60L,
    val outsideDeliveryFee: Long = 120L,
    val seeded: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val fullName: String = "",
    val phone: String = "",
    val defaultAddress: String = "",
    val preferredZone: String = DeliveryZone.DHAKA_CITY.label,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

object DefaultCatalog {
    val starterProducts: List<Pair<String, Product>> = listOf(
        "prod_smart_watch" to Product(
            name = "প্রিমিয়াম স্মার্ট ওয়াচ",
            category = "ইলেকট্রনিক্স",
            price = 1250L,
            oldPrice = 1590L,
            emoji = "⌚",
            description = "দৈনন্দিন ব্যবহারের জন্য স্টাইলিশ স্মার্ট ওয়াচ। কল নোটিফিকেশন, হার্ট রেট ও স্টেপ ট্র্যাকার সুবিধা।",
            featured = true,
            rating = 4.9,
            soldCount = 148L
        ),
        "prod_backpack" to Product(
            name = "ক্যাজুয়াল ব্যাকপ্যাক",
            category = "ফ্যাশন",
            price = 890L,
            oldPrice = 1090L,
            emoji = "🎒",
            description = "ভ্রমণ, অফিস ও দৈনন্দিন ব্যবহারের উপযোগী ওয়াটার-রেজিস্ট্যান্ট স্টাইলিশ ব্যাকপ্যাক।",
            featured = true,
            rating = 4.8,
            soldCount = 96L
        ),
        "prod_skincare_set" to Product(
            name = "স্কিন কেয়ার সেট",
            category = "বিউটি",
            price = 750L,
            oldPrice = 950L,
            emoji = "🧴",
            description = "ত্বকের প্রাকৃতিক উজ্জ্বলতা ও ব্যক্তিগত যত্নের জন্য প্রিমিয়াম বিউটি কেয়ার সেট।",
            featured = false,
            rating = 4.7,
            soldCount = 112L
        ),
        "prod_wireless_headphones" to Product(
            name = "ওয়্যারলেস হেডফোন",
            category = "ইলেকট্রনিক্স",
            price = 1450L,
            oldPrice = 1790L,
            emoji = "🎧",
            description = "ক্রিস্টাল ক্লিয়ার মিউজিক ও অনলাইন ক্লাসের জন্য লং-ব্যাটারি ব্লুটুথ হেডফোন।",
            featured = true,
            rating = 4.9,
            soldCount = 203L
        ),
        "prod_home_lamp" to Product(
            name = "হোম ডেকর ল্যাম্প",
            category = "হোম",
            price = 620L,
            oldPrice = 790L,
            emoji = "💡",
            description = "আপনার শোবার ঘর বা পড়ার টেবিলে উষ্ণ ও আধুনিক লুক যোগ করার জন্য ডেকোরেটিভ ল্যাম্প।",
            featured = false,
            rating = 4.6,
            soldCount = 67L
        ),
        "prod_sports_sneakers" to Product(
            name = "স্পোর্টস স্নিকার্স",
            category = "ফ্যাশন",
            price = 1650L,
            oldPrice = 1990L,
            emoji = "👟",
            description = "সারাদিন হাঁটা ও জিমের জন্য আরামদায়ক, হালকা এবং বাতাস চলাচল উপযোগী স্নিকার্স।",
            featured = true,
            rating = 4.8,
            soldCount = 134L
        ),
        "prod_sunglasses" to Product(
            name = "পোলারাইজড সানগ্লাস",
            category = "অ্যাক্সেসরিজ",
            price = 490L,
            oldPrice = 650L,
            emoji = "🕶️",
            description = "রোদে চোখের সুরক্ষা ও স্মার্ট লুকের জন্য UV400 পোলারাইজড স্টাইলিশ সানগ্লাস।",
            featured = false,
            rating = 4.7,
            soldCount = 175L
        ),
        "prod_kitchen_set" to Product(
            name = "কিচেন স্টোরেজ সেট",
            category = "হোম",
            price = 580L,
            oldPrice = 720L,
            emoji = "🍱",
            description = "রান্নাঘরের মসলা ও খাবার পরিপাটি করে গুছিয়ে রাখতে এয়ারটাইট ফুড-গ্রেড কন্টেইনার সেট।",
            featured = false,
            rating = 4.8,
            soldCount = 89L
        )
    )
}
