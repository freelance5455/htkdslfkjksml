package com.example.model

enum class BrowserMode {
    WINDOWS_XP_IE6,
    GOOGLE_CHROME
}

enum class DisplayResolution(
    val label: String,
    val shortLabel: String,
    val width: Int,
    val height: Int,
    val aspectRatio: Float,
    val description: String
) {
    RES_1080P_FHD(
        label = "1080p Full HD (1920×1080)",
        shortLabel = "1080p FHD",
        width = 1920,
        height = 1080,
        aspectRatio = 16f / 9f,
        description = "Crisp 1080p High-Definition widescreen desktop rendering"
    ),
    RES_720P_HD(
        label = "720p HD (1280×720)",
        shortLabel = "720p HD",
        width = 1280,
        height = 720,
        aspectRatio = 16f / 9f,
        description = "Standard 16:9 HD widescreen desktop rendering"
    ),
    RES_1024_SVGA(
        label = "Classic 1024×768 (SVGA 4:3)",
        shortLabel = "1024×768",
        width = 1024,
        height = 768,
        aspectRatio = 4f / 3f,
        description = "Traditional 2000s CRT monitor aspect ratio"
    ),
    RES_NATIVE_AUTO(
        label = "Native Fullscreen Fit",
        shortLabel = "Native Fit",
        width = 0,
        height = 0,
        aspectRatio = 0f,
        description = "Adapts edge-to-edge to your physical device screen"
    )
}

enum class UserAgentType(val label: String, val userAgent: String) {
    IE6_XP(
        "Internet Explorer 6.0 (Windows XP)",
        "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)"
    ),
    IE7_XP(
        "Internet Explorer 7.0 (Windows XP)",
        "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)"
    ),
    NETSCAPE_9(
        "Netscape Navigator 9.0 (Win XP)",
        "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.12) Gecko/20080219 Firefox/2.0.0.12 Navigator/9.0.0.6"
    ),
    CHROME_VINTAGE(
        "Google Chrome 1.0 (Windows XP)",
        "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/1.0.154.36 Safari/525.13"
    ),
    CHROME_MODERN(
        "Modern Chrome (Mobile/Standards)",
        "Mozilla/5.0 (Linux; Android 14; Mobile; rv:120.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    )
}

data class BrowserTab(
    val id: String,
    val title: String,
    val url: String,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val isSecure: Boolean = false,
    val hasFlash: Boolean = true
)

data class EraSite(
    val id: String,
    val title: String,
    val url: String,
    val era: String,
    val category: String,
    val description: String
)

object EraSitesData {
    val SITES = listOf(
        EraSite(
            id = "msn2001",
            title = "MSN.com (2001 Start Page)",
            url = "file:///android_asset/msn_start_2001.html",
            era = "2001",
            category = "Portals & Default Homepages",
            description = "The classic Windows XP default homepage with MSNBC news, stock tickers, Hotmail, and search."
        ),
        EraSite(
            id = "flash_hub",
            title = "Adobe Flash Player 10 Hub",
            url = "file:///android_asset/flash_player_hub.html",
            era = "2008 - 2011",
            category = "Adobe Flash & Games",
            description = "Interactive Helicopter Game, ActionScript 3D demo, Space Arcade, and SWF loader with Ruffle engine."
        ),
        EraSite(
            id = "google1998",
            title = "Google! (1998-2001 Classic)",
            url = "file:///android_asset/google_classic.html",
            era = "1998 - 2001",
            category = "Search Engines",
            description = "The iconic vintage Google search engine with exclamation mark and 'I\\'m Feeling Lucky'."
        ),
        EraSite(
            id = "yahoo2001",
            title = "Yahoo! Directory (2001)",
            url = "file:///android_asset/yahoo_classic.html",
            era = "2001",
            category = "Portals & Default Homepages",
            description = "The classic categorized web directory of the early 2000s web."
        ),
        EraSite(
            id = "spacejam",
            title = "Space Jam (Original 1996)",
            url = "https://www.spacejam.com/1996/",
            era = "1996",
            category = "Pop Culture Archives",
            description = "The legendary original Warner Bros Space Jam promotional site, preserved in authentic 90s HTML."
        ),
        EraSite(
            id = "theoldnet",
            title = "The Old Net (1996-2006 Time Machine)",
            url = "http://theoldnet.com",
            era = "1996 - 2006",
            category = "Historical Web Archives",
            description = "Surfs historical web archives stripped of modern bloat for authentic vintage browser compatibility."
        ),
        EraSite(
            id = "wayback",
            title = "Wayback Machine (Internet Archive)",
            url = "https://web.archive.org",
            era = "All Eras",
            category = "Historical Web Archives",
            description = "Digital archive of the World Wide Web with over 800 billion historical web pages."
        ),
        EraSite(
            id = "homestarrunner",
            title = "Homestar Runner (Flash Cartoon Archive)",
            url = "https://homestarrunner.com",
            era = "2000s",
            category = "Adobe Flash & Games",
            description = "Legendary Flash animated cartoon series, Strong Bad emails, and classic web animations."
        ),
        EraSite(
            id = "wiby",
            title = "Wiby - The Classical Web Search",
            url = "https://wiby.me",
            era = "Retro Style",
            category = "Search Engines",
            description = "A search engine for the classic web, indexing lightweight, personal, and nostalgic websites."
        ),
        EraSite(
            id = "frogfind",
            title = "FrogFind (Vintage Computer Search)",
            url = "http://frogfind.com",
            era = "Retro Style",
            category = "Search Engines",
            description = "Search engine tailored for vintage computers and legacy browsers, converting modern web pages."
        ),
        EraSite(
            id = "xptour",
            title = "Windows XP Product Tour",
            url = "file:///android_asset/windows_xp_tour.html",
            era = "2001",
            category = "Windows XP Experience",
            description = "Relive the iconic Windows XP launch tour and multimedia showcase."
        ),
        EraSite(
            id = "neocities",
            title = "Neocities Retro Web",
            url = "https://neocities.org/browse",
            era = "Geocities Revival",
            category = "Pop Culture Archives",
            description = "Modern revival of GeoCities personal homepages with retro animations, MIDI, and badges."
        )
    )
}
