package com.example.model

import androidx.compose.ui.graphics.Color

enum class GameStatus {
    READY,
    PLAYING,
    PAUSED,
    GAME_OVER
}

enum class Difficulty(
    val title: String,
    val speedMultiplier: Float,
    val gapHeightDp: Float,
    val gravity: Float
) {
    EASY("Easy", 0.85f, 210f, 1500f),
    NORMAL("Normal", 1.0f, 175f, 1800f),
    HARD("Hard", 1.25f, 145f, 2100f)
}

enum class MascotSkin(
    val title: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val eyeColor: Color,
    val accentColor: Color
) {
    CLASSIC_GREEN(
        title = "Android Green",
        primaryColor = Color(0xFF3DDC84),
        secondaryColor = Color(0xFF2E7D32),
        eyeColor = Color.White,
        accentColor = Color(0xFF80E8A8)
    ),
    CYBER_CYAN(
        title = "Cyber Droid",
        primaryColor = Color(0xFF00E5FF),
        secondaryColor = Color(0xFF0091EA),
        eyeColor = Color(0xFF18FFFF),
        accentColor = Color(0xFF84FFFF)
    ),
    NEON_AMBER(
        title = "Solar Amber",
        primaryColor = Color(0xFFFFB300),
        secondaryColor = Color(0xFFE65100),
        eyeColor = Color.White,
        accentColor = Color(0xFFFFE082)
    ),
    CARBON_DARK(
        title = "Stealth Onyx",
        primaryColor = Color(0xFF37474F),
        secondaryColor = Color(0xFF212121),
        eyeColor = Color(0xFF00E676),
        accentColor = Color(0xFF90A4AE)
    )
}

data class PipeObstacle(
    val id: Long,
    val x: Float, // horizontal position in dp
    val topPipeHeight: Float, // height of top pipe in dp
    val bottomPipeY: Float, // Y position where bottom pipe starts in dp
    val passed: Boolean = false
)

data class Mascot(
    val y: Float = 0f, // vertical center in dp
    val velocityY: Float = 0f, // vertical velocity in dp/s
    val rotationAngle: Float = 0f, // in degrees (-30 to +80)
    val flapProgress: Float = 0f // 0f to 1f for wing/jetpack animation
)

data class Particle(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val alpha: Float,
    val size: Float,
    val color: Color
)

enum class UpdateChannel(val displayName: String, val badge: String) {
    STABLE("Stable", "Official"),
    BETA("Beta", "Preview"),
    CANARY("Canary", "Cutting Edge")
}

sealed interface UpdateState {
    data class Idle(val lastCheckedTime: String?) : UpdateState
    object Checking : UpdateState
    data class UpToDate(
        val currentVersion: String,
        val checkedAt: String
    ) : UpdateState
    data class Available(
        val newVersion: String,
        val buildCode: Int,
        val releaseNotes: List<String>,
        val downloadSize: String,
        val channel: UpdateChannel
    ) : UpdateState
    data class Downloading(val progress: Float) : UpdateState
    data class ReadyToApply(val newVersion: String) : UpdateState
    data class Error(val message: String) : UpdateState
}

data class GameStats(
    val highScore: Int = 0,
    val gamesPlayed: Int = 0,
    val totalFlaps: Int = 0,
    val totalPipesCleared: Int = 0
)
