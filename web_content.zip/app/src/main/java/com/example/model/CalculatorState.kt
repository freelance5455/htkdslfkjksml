package com.example.model

data class CalculatorState(
    val expression: String = "0",
    val liveResult: String = "",
    val isUltimateMode: Boolean = false,
    val selectedAlien: Alien = AlienRoster.aliens[0],
    val isScientificOpen: Boolean = false,
    val isRadMode: Boolean = true,
    val lastAction: String = "HERO READY",
    val reactionMessage: String = "Ultimatrix online. Awaiting coordinates.",
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val omnitrixRotation: Float = 0f,
    val dialPulseTrigger: Long = 0L,
    val powerMeterPercent: Float = 0.42f,
    val isEvaluating: Boolean = false,
    val errorMessage: String? = null
)
