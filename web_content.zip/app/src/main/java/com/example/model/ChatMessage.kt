package com.example.model

import android.net.Uri

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val imageUri: Uri? = null,
    val imageBase64: String? = null,
    val isError: Boolean = false
)
