package com.example.model

data class GameTask(
    val id: String,
    val title: String,
    val description: String,
    val isDaily: Boolean,
    val icon: String,
    val currentProgress: Int,
    val targetProgress: Int,
    val rewardScore: Int,
    val rewardCoins: Int,
    val isCompleted: Boolean,
    val isClaimed: Boolean
)
