package com.example.model

import java.util.UUID
import kotlin.math.abs
import kotlin.math.sin

data class Song(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val year: Int,
    val durationSec: Int,
    val audioUri: String? = null,
    val customTags: List<String> = emptyList(),
    val isFavorite: Boolean = false,
    val playCount: Int = 0,
    val primaryColorHex: Long = 0xFF00F0FF,
    val secondaryColorHex: Long = 0xFFA855F7,
    val bpm: Int = 120,
    // Poweramp Audiophile Metadata
    val codec: String = "FLAC",
    val sampleRateHz: Int = 96000,
    val bitDepth: Int = 24,
    val bitrateKbps: Int = 2814,
    val channels: String = "Stereo (2.0)",
    val isHiRes: Boolean = true,
    // Custom precomputed waveform peaks for the Poweramp Waveform Seekbar
    val waveformPoints: List<Float> = emptyList()
) {
    val durationFormatted: String
        get() {
            val minutes = durationSec / 60
            val seconds = durationSec % 60
            return "%d:%02d".format(minutes, seconds)
        }

    val hiResBadgeText: String
        get() = "$codec ${bitDepth}-bit / ${sampleRateHz / 1000}kHz"

    val fullCodecDetail: String
        get() = "$codec Lossless • ${bitDepth}-bit / ${sampleRateHz / 1000} kHz • $bitrateKbps kbps"

    companion object {
        fun generateWaveformPeaks(seed: Int, count: Int = 80): List<Float> {
            return List(count) { i ->
                val x = i.toDouble() / count * 12.0
                val primary = (abs(sin(x * 1.7 + seed)) * 0.6).toFloat()
                val harmonic = (abs(sin(x * 3.4 + seed * 2.1)) * 0.3).toFloat()
                val noise = (abs(sin(x * 7.1 + seed * 3.3)) * 0.15).toFloat()
                val envelope = (sin(i.toDouble() / count * Math.PI)).toFloat().coerceIn(0.25f, 1f)
                ((primary + harmonic + noise) * envelope).coerceIn(0.12f, 1.0f)
            }
        }
    }
}

enum class SongSortOption(val displayName: String) {
    TITLE_ASC("Title (A-Z)"),
    TITLE_DESC("Title (Z-A)"),
    ARTIST("Artist"),
    ALBUM("Album"),
    GENRE("Genre"),
    YEAR_NEWEST("Year (Newest)"),
    YEAR_OLDEST("Year (Oldest)"),
    CUSTOM_TAGS("Custom Tags"),
    DURATION("Duration"),
    MOST_PLAYED("Most Played"),
    FAVORITES("Favorites First")
}
