package com.example.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import java.util.UUID

enum class TriggerType {
    RED,
    GREEN,
    YELLOW,
    BLUE,
    ORANGE,
    PURPLE,
    CUSTOM,
    SYMBOL_CONTRAST
}

data class TargetTrigger(
    val id: String = UUID.randomUUID().toString(),
    val type: TriggerType,
    val nameEn: String,
    val nameAr: String,
    val color: Color,
    val isEnabled: Boolean = true,
    // Custom HSV parameters (for CUSTOM type)
    val customHue: Float = 0f, // 0..360
    val customSat: Float = 0.8f, // 0..1
    val customVal: Float = 0.8f, // 0..1
    val tolerance: Float = 30f // Hue tolerance degrees or distance threshold
) {
    /**
     * Checks if given HSV values match this trigger.
     * hsv[0] is Hue (0..360)
     * hsv[1] is Saturation (0..1)
     * hsv[2] is Value/Brightness (0..1)
     */
    fun matches(hsv: FloatArray): Boolean {
        val h = hsv[0]
        val s = hsv[1]
        val v = hsv[2]

        return when (type) {
            TriggerType.RED -> {
                // Red wraps around 360/0 in HSV
                val isHueRed = (h in 340f..360f) || (h in 0f..20f)
                isHueRed && s >= 0.35f && v >= 0.20f
            }
            TriggerType.GREEN -> {
                // Pure to rich greens
                (h in 75f..165f) && s >= 0.30f && v >= 0.20f
            }
            TriggerType.YELLOW -> {
                // Yellows / warm gold
                (h in 35f..74f) && s >= 0.35f && v >= 0.30f
            }
            TriggerType.BLUE -> {
                // Azure / Blue
                (h in 185f..260f) && s >= 0.35f && v >= 0.20f
            }
            TriggerType.ORANGE -> {
                // Orange
                (h in 21f..34f) && s >= 0.45f && v >= 0.30f
            }
            TriggerType.PURPLE -> {
                // Purple / Magenta
                (h in 265f..335f) && s >= 0.30f && v >= 0.20f
            }
            TriggerType.CUSTOM -> {
                // Distance in HSV cylindrical space
                val hueDiff = Math.abs(h - customHue).let { if (it > 180f) 360f - it else it }
                val satDiff = Math.abs(s - customSat)
                val valDiff = Math.abs(v - customVal)
                (hueDiff <= tolerance) && (satDiff <= 0.45f) && (valDiff <= 0.45f)
            }
            TriggerType.SYMBOL_CONTRAST -> {
                // Dark marker on light background or vice versa (high contrast)
                (v <= 0.15f) || (v >= 0.90f && s <= 0.20f)
            }
        }
    }

    companion object {
        fun createDefaultTriggers(): List<TargetTrigger> {
            return listOf(
                TargetTrigger(
                    type = TriggerType.RED,
                    nameEn = "Red",
                    nameAr = "أحمر",
                    color = Color(0xFFEF4444),
                    isEnabled = true
                ),
                TargetTrigger(
                    type = TriggerType.GREEN,
                    nameEn = "Green",
                    nameAr = "أخضر",
                    color = Color(0xFF10B981),
                    isEnabled = true
                ),
                TargetTrigger(
                    type = TriggerType.YELLOW,
                    nameEn = "Yellow",
                    nameAr = "أصفر",
                    color = Color(0xFFFBBF24),
                    isEnabled = true
                ),
                TargetTrigger(
                    type = TriggerType.BLUE,
                    nameEn = "Blue",
                    nameAr = "أزرق",
                    color = Color(0xFF3B82F6),
                    isEnabled = false
                ),
                TargetTrigger(
                    type = TriggerType.ORANGE,
                    nameEn = "Orange",
                    nameAr = "برتقالي",
                    color = Color(0xFFF97316),
                    isEnabled = false
                ),
                TargetTrigger(
                    type = TriggerType.PURPLE,
                    nameEn = "Purple",
                    nameAr = "بنفسجي",
                    color = Color(0xFFA855F7),
                    isEnabled = false
                ),
                TargetTrigger(
                    type = TriggerType.SYMBOL_CONTRAST,
                    nameEn = "High Contrast / Symbol",
                    nameAr = "رمز عالي التباين",
                    color = Color(0xFFE2E8F0),
                    isEnabled = false
                )
            )
        }

        fun fromColor(color: Color, nameEn: String = "Custom Color", nameAr: String = "لون مخصص"): TargetTrigger {
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(color.toArgb(), hsv)
            return TargetTrigger(
                type = TriggerType.CUSTOM,
                nameEn = nameEn,
                nameAr = nameAr,
                color = color,
                isEnabled = true,
                customHue = hsv[0],
                customSat = hsv[1],
                customVal = hsv[2],
                tolerance = 25f
            )
        }
    }
}
