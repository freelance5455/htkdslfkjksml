package com.example.model

data class EqualizerBand(
    val label: String,
    val freqHz: Int,
    val gainDb: Float // -12f to +12f
)

data class EqualizerPreset(
    val id: String,
    val name: String,
    // 10 Frequency Bands (Poweramp Standard: 31Hz, 62Hz, 125Hz, 250Hz, 500Hz, 1kHz, 2kHz, 4kHz, 8kHz, 16kHz)
    val band31Hz: Float = 0f,
    val band62Hz: Float = 0f,
    val band125Hz: Float = 0f,
    val band250Hz: Float = 0f,
    val band500Hz: Float = 0f,
    val band1kHz: Float = 0f,
    val band2kHz: Float = 0f,
    val band4kHz: Float = 0f,
    val band8kHz: Float = 0f,
    val band16kHz: Float = 0f,
    // Poweramp Tone Knobs & Mastering Controls
    val preampDb: Float = 0f, // -12f to +12f
    val bassTone: Float = 0f, // -10f to +10f (rotary knob)
    val trebleTone: Float = 0f, // -10f to +10f (rotary knob)
    val bassBoost: Float = 0f, // 0 to 100
    val virtualizer3D: Float = 0f, // 0 to 100 (Stereo expander)
    val limiterEnabled: Boolean = true,
    val dvcEnabled: Boolean = true, // Direct Volume Control
    val stereoWidener: Float = 30f, // 0 to 100%
    val balance: Float = 0f, // -10f to +10f (Left to Right)
    val tempo: Float = 1.0f, // 0.5x to 2.0x
    val isCustom: Boolean = false
) {
    fun toBands(): List<EqualizerBand> = listOf(
        EqualizerBand("31Hz", 31, band31Hz),
        EqualizerBand("62Hz", 62, band62Hz),
        EqualizerBand("125Hz", 125, band125Hz),
        EqualizerBand("250Hz", 250, band250Hz),
        EqualizerBand("500Hz", 500, band500Hz),
        EqualizerBand("1kHz", 1000, band1kHz),
        EqualizerBand("2kHz", 2000, band2kHz),
        EqualizerBand("4kHz", 4000, band4kHz),
        EqualizerBand("8kHz", 8000, band8kHz),
        EqualizerBand("16kHz", 16000, band16kHz)
    )

    // Backward-compat helpers
    val band60Hz: Float get() = band62Hz
}

object EqualizerDefaults {
    val BUILT_IN_PRESETS = listOf(
        EqualizerPreset(
            id = "flat",
            name = "Flat (Audiophile Direct)",
            band31Hz = 0f, band62Hz = 0f, band125Hz = 0f, band250Hz = 0f, band500Hz = 0f,
            band1kHz = 0f, band2kHz = 0f, band4kHz = 0f, band8kHz = 0f, band16kHz = 0f,
            preampDb = 0f, bassTone = 0f, trebleTone = 0f, bassBoost = 0f, virtualizer3D = 0f,
            stereoWidener = 0f
        ),
        EqualizerPreset(
            id = "poweramp_bass_treble",
            name = "Poweramp Bass & Treble",
            band31Hz = 6f, band62Hz = 7f, band125Hz = 4f, band250Hz = 1f, band500Hz = -1f,
            band1kHz = 0f, band2kHz = 2f, band4kHz = 4f, band8kHz = 6f, band16kHz = 7.5f,
            preampDb = 1.5f, bassTone = 6.5f, trebleTone = 5.0f, bassBoost = 70f, virtualizer3D = 40f,
            stereoWidener = 35f
        ),
        EqualizerPreset(
            id = "bass_heavy",
            name = "Sub-Bass Cannon",
            band31Hz = 9.5f, band62Hz = 8.5f, band125Hz = 6f, band250Hz = 3f, band500Hz = 0f,
            band1kHz = -1f, band2kHz = 0f, band4kHz = 2f, band8kHz = 3f, band16kHz = 4f,
            preampDb = -1f, bassTone = 9.0f, trebleTone = 2.0f, bassBoost = 95f, virtualizer3D = 30f,
            stereoWidener = 25f
        ),
        EqualizerPreset(
            id = "rock_anthem",
            name = "Rock Anthem",
            band31Hz = 4.5f, band62Hz = 5.5f, band125Hz = 3f, band250Hz = -1f, band500Hz = -2.5f,
            band1kHz = 1.5f, band2kHz = 3.5f, band4kHz = 5f, band8kHz = 6.5f, band16kHz = 6f,
            preampDb = 1.0f, bassTone = 4.5f, trebleTone = 6.0f, bassBoost = 50f, virtualizer3D = 45f,
            stereoWidener = 40f
        ),
        EqualizerPreset(
            id = "techno_edm",
            name = "Techno & EDM Club",
            band31Hz = 8f, band62Hz = 7.5f, band125Hz = 5f, band250Hz = 0f, band500Hz = 1f,
            band1kHz = 2f, band2kHz = 4f, band4kHz = 6f, band8kHz = 7.5f, band16kHz = 8f,
            preampDb = 0f, bassTone = 8.0f, trebleTone = 7.0f, bassBoost = 85f, virtualizer3D = 60f,
            stereoWidener = 60f
        ),
        EqualizerPreset(
            id = "vocal_master",
            name = "Vocal Clarity Master",
            band31Hz = -4f, band62Hz = -2f, band125Hz = 0f, band250Hz = 2f, band500Hz = 5f,
            band1kHz = 7f, band2kHz = 6f, band4kHz = 4f, band8kHz = 2f, band16kHz = 1f,
            preampDb = 0f, bassTone = -2.0f, trebleTone = 3.5f, bassBoost = 15f, virtualizer3D = 25f,
            stereoWidener = 20f
        ),
        EqualizerPreset(
            id = "audiophile_jazz",
            name = "Audiophile Jazz & Blues",
            band31Hz = 3f, band62Hz = 3.5f, band125Hz = 2f, band250Hz = 1.5f, band500Hz = 2f,
            band1kHz = 3f, band2kHz = 2.5f, band4kHz = 3.5f, band8kHz = 4f, band16kHz = 4.5f,
            preampDb = 0.5f, bassTone = 3.0f, trebleTone = 4.0f, bassBoost = 30f, virtualizer3D = 35f,
            stereoWidener = 40f
        ),
        EqualizerPreset(
            id = "concert_classical",
            name = "Concert Hall Classical",
            band31Hz = 4f, band62Hz = 4f, band125Hz = 3f, band250Hz = 2f, band500Hz = 1f,
            band1kHz = 2f, band2kHz = 3f, band4kHz = 4f, band8kHz = 5f, band16kHz = 5.5f,
            preampDb = 1.0f, bassTone = 3.5f, trebleTone = 5.0f, bassBoost = 20f, virtualizer3D = 75f,
            stereoWidener = 70f
        ),
        EqualizerPreset(
            id = "heavy_metal",
            name = "Heavy Metal Shred",
            band31Hz = 7f, band62Hz = 6.5f, band125Hz = 3f, band250Hz = -2f, band500Hz = -4f,
            band1kHz = 0f, band2kHz = 4f, band4kHz = 7f, band8kHz = 8.5f, band16kHz = 7.5f,
            preampDb = 0.5f, bassTone = 6.0f, trebleTone = 7.5f, bassBoost = 70f, virtualizer3D = 50f,
            stereoWidener = 45f
        ),
        EqualizerPreset(
            id = "lofi_vinyl",
            name = "Lo-Fi Warm Vinyl",
            band31Hz = 5f, band62Hz = 4f, band125Hz = 2f, band250Hz = 1f, band500Hz = -1f,
            band1kHz = -2f, band2kHz = -3f, band4kHz = -2f, band8kHz = -4f, band16kHz = -6f,
            preampDb = 0f, bassTone = 5.0f, trebleTone = -4.0f, bassBoost = 45f, virtualizer3D = 30f,
            stereoWidener = 25f
        ),
        EqualizerPreset(
            id = "synthwave_80s",
            name = "Retro Synthwave 80s",
            band31Hz = 6.5f, band62Hz = 6f, band125Hz = 3.5f, band250Hz = 0.5f, band500Hz = 1.5f,
            band1kHz = 3f, band2kHz = 4.5f, band4kHz = 6f, band8kHz = 7f, band16kHz = 8f,
            preampDb = 1.0f, bassTone = 6.0f, trebleTone = 6.5f, bassBoost = 65f, virtualizer3D = 65f,
            stereoWidener = 55f
        )
    )
}
