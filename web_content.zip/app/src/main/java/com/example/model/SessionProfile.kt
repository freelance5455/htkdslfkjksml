package com.example.model

enum class DeviceType(val label: String, val iconName: String) {
    DESKTOP_WINDOWS("Windows PC", "desktop_windows"),
    DESKTOP_MAC("macOS", "laptop_mac"),
    DESKTOP_LINUX("Linux", "computer"),
    MOBILE_ANDROID("Android Mobile", "smartphone"),
    MOBILE_IOS("iPhone iOS", "phone_iphone"),
    TABLET_IPAD("iPad Tablet", "tablet_mac"),
    TABLET_ANDROID("Android Tablet", "tablet_android")
}

data class SessionProfile(
    val id: String,
    val deviceType: DeviceType,
    val browserName: String,
    val userAgent: String,
    val acceptLanguage: String,
    val referer: String?,
    val simulatedIp: String,
    val simulatedCountry: String,
    val secChUa: String,
    val secChUaMobile: String,
    val secChUaPlatform: String,
    val viewport: String
)
