package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class SchoolConfig(
    @DocumentId val id: String = "",
    val userId: String = "",
    val country: String = "REPUBLIC OF RWANDA",
    val schoolName: String = "WISDOM INSTRUCTION SCHOOL",
    val poBox: String = "365@yahoo",
    val tel: String = "0788799193",
    val ministry: String = "MINISTRY OF EDUCATION",
    val academicYear: String = "2026/2027",
    val term: String = "1st Term",
    val reportTitle: String = "REPORT CARD",
    val teacherName: String = "",
    val showLogo: Boolean = true,
    val logoFileName: String = "",
    val logoSizeDp: Long = 82L,
    val logoCircular: Boolean = true,
    val signatureFileName: String = "",
    val signatureSizeDp: Long = 48L,
    val borderColorHex: String = "#1F2937",
    val headerBgHex: String = "#F8FAFC",
    val reportFont: String = "serif",
    val positionFormat: String = "number_only",
    val decimalPlaces: Long = 1L,
    val conductMax: String = "",
    val manualStudentCount: String = "",
    val passMark: Long = 50L,
    val autoApplyObservations: Boolean = false,
    val labels: Map<String, String> = defaultReportLabels(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

fun defaultReportLabels(): Map<String, String> = mapOf(
    "schoolPrefix" to "School:",
    "poBoxPrefix" to "Po.Box:",
    "telPrefix" to "Tel:",
    "studentName" to "Student Name:",
    "className" to "Class:",
    "idNo" to "ID No.:",
    "numStudents" to "N. Students",
    "conduct" to "Conduct:",
    "subjects" to "SUBJECTS",
    "test" to "TEST",
    "exam" to "EXAM",
    "tot" to "TOT",
    "rank" to "Rank",
    "totalRow" to "Total",
    "average" to "Average",
    "position" to "Position",
    "lates" to "Lates",
    "absences" to "Absences",
    "observations" to "Observations",
    "teacherSignature" to "Teacher Signature",
    "parentSignature" to "Parent Signature",
)

@Keep
@IgnoreExtraProperties
data class SchoolClass(
    @DocumentId val id: String = "",
    val userId: String = "",
    val name: String = "",
    val sortOrder: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Subject(
    @DocumentId val id: String = "",
    val userId: String = "",
    val classId: String = "",
    val name: String = "",
    val maxTest: Long = 100L,
    val maxExam: Long = 0L,
    val sortOrder: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class Student(
    @DocumentId val id: String = "",
    val userId: String = "",
    val classId: String = "",
    val name: String = "",
    val studentIdNo: String = "",
    val conduct: String = "",
    val latesCount: Long = 0L,
    val absencesCount: Long = 0L,
    val observation: String = "",
    val testScores: Map<String, Double> = emptyMap(),
    val examScores: Map<String, Double> = emptyMap(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

enum class AttendanceStatus(val label: String) {
    PRESENT("Present"),
    LATE("Late"),
    ABSENT("Absent"),
    EXCUSED("Excused");

    companion object {
        fun fromRaw(raw: String): AttendanceStatus =
            entries.firstOrNull { it.name == raw } ?: PRESENT
    }
}

@Keep
@IgnoreExtraProperties
data class AttendanceRecord(
    @DocumentId val id: String = "",
    val userId: String = "",
    val classId: String = "",
    val studentId: String = "",
    val dateKey: String = "",
    val status: String = AttendanceStatus.PRESENT.name,
    val note: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

enum class TeacherRole(val label: String) {
    SUBJECT_TEACHER("Subject Teacher"),
    CLASS_TEACHER("Class Teacher"),
    HEAD_TEACHER("Head Teacher");

    companion object {
        fun fromRaw(raw: String): TeacherRole =
            entries.firstOrNull { it.name == raw } ?: SUBJECT_TEACHER
    }
}

@Keep
@IgnoreExtraProperties
data class TeacherAssignment(
    @DocumentId val id: String = "",
    val userId: String = "",
    val teacherName: String = "",
    val teacherEmail: String = "",
    val teacherPhone: String = "",
    val classId: String = "",
    val className: String = "",
    val subjectId: String = "",
    val subjectName: String = "",
    val roleType: String = TeacherRole.SUBJECT_TEACHER.name,
    val weeklyHours: Long = 4L,
    val scheduleNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class ObservationRule(
    @DocumentId val id: String = "",
    val userId: String = "",
    val minPct: Long = 0L,
    val commentText: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
)

// Computed Analytics Domain Models (in-memory only)
data class SubjectComputedResult(
    val subjectId: String,
    val maxTest: Long,
    val maxExam: Long,
    val maxTot: Long,
    val hasTest: Boolean,
    val hasExam: Boolean,
    val test: Double,
    val exam: Double,
    val tot: Double,
    val rank: Int,
)

data class StudentComputedResult(
    val student: Student,
    val subjectResults: Map<String, SubjectComputedResult>,
    val studentTestGrand: Double,
    val studentExamGrand: Double,
    val studentTotGrand: Double,
    val rawPct: Double,
    val formattedPct: String,
    val overallRank: Int,
)

data class ClassAnalytics(
    val studentsComputed: List<StudentComputedResult>,
    val byId: Map<String, StudentComputedResult>,
    val maxTestGrand: Long,
    val maxExamGrand: Long,
    val maxTotGrand: Long,
    val anyExamEnabled: Boolean,
    val classAvgPct: Double,
    val highestPct: Double,
    val passRatePct: Double,
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
