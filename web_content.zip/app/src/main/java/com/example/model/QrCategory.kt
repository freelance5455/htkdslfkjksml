package com.example.model

enum class QrCategory(val displayName: String) {
    ALL("All"),
    URL("Web Links"),
    WIFI("Wi-Fi"),
    CONTACT("Contacts"),
    EMAIL("Email"),
    PHONE("Phone"),
    SMS("SMS"),
    LOCATION("Location"),
    PAYMENT("Payments"),
    TEXT("Plain Text")
}
