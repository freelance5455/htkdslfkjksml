package com.example.model

enum class ProtectedSection(
    val overlayTitle: String,
    val overlaySubtitle: String,
) {
    POWER_AND_REBOOT(
        overlayTitle = "Encendido y reinicio bloqueados",
        overlaySubtitle = "Ingresa tu PIN de 6 dígitos para apagar, reiniciar o cambiar ajustes de memoria/sistema.",
    ),
    ACCESSIBILITY_AND_ADMIN(
        overlayTitle = "Ajustes de seguridad bloqueados",
        overlaySubtitle = "Ingresa tu PIN de 6 dígitos para acceder a Accesibilidad o Administrador del dispositivo.",
    ),
    DESKTOP_SETTINGS(
        overlayTitle = "Configuración de escritorio bloqueada",
        overlaySubtitle = "Ingresa tu PIN de 6 dígitos para modificar las opciones del escritorio.",
    ),
}
