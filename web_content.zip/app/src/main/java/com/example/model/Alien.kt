package com.example.model

import androidx.compose.ui.graphics.Color

data class Alien(
    val id: String,
    val name: String,
    val ultimateName: String,
    val species: String,
    val homePlanet: String,
    val ability: String,
    val powerLevel: Int, // 100 - 9999
    val quote: String,
    val ultimateQuote: String,
    val themeColor: Color,
    val ultimateColor: Color,
    val soundProfile: String // "fire", "heavy", "sonic", "ice", "kinetic"
)

object AlienRoster {
    val aliens = listOf(
        Alien(
            id = "humungousaur",
            name = "Humungousaur",
            ultimateName = "Ultimate Humungousaur",
            species = "Vaxasaurian",
            homePlanet = "Terradino",
            ability = "Superhuman Strength & Bio-Missile Gatling Cannons",
            powerLevel = 8800,
            quote = "HUMUNGOUSAUR SMASH!",
            ultimateQuote = "ULTIMATE HUMUNGOUSAUR! BIO-GATLINGS LOCKED!",
            themeColor = Color(0xFF9E6434),
            ultimateColor = Color(0xFF00FF66),
            soundProfile = "heavy"
        ),
        Alien(
            id = "swampfire",
            name = "Swampfire",
            ultimateName = "Ultimate Swampfire",
            species = "Methanosian",
            homePlanet = "Methanos",
            ability = "Methane Pyrokinesis & Blue Plasma Bombs",
            powerLevel = 8400,
            quote = "SWAMPFIRE! Time to burn!",
            ultimateQuote = "ULTIMATE SWAMPFIRE! BLUE FIRE PLASMA BLAST!",
            themeColor = Color(0xFF2E8B57),
            ultimateColor = Color(0xFF00B4D8),
            soundProfile = "fire"
        ),
        Alien(
            id = "echo_echo",
            name = "Echo Echo",
            ultimateName = "Ultimate Echo Echo",
            species = "Sonorosian",
            homePlanet = "Sonorosia",
            ability = "Sonic Screams & Floating Sonic Disks",
            powerLevel = 9100,
            quote = "ECHO ECHO! Sonic vibrations engaged!",
            ultimateQuote = "ULTIMATE ECHO ECHO! SONIC DOOM ATTACK!",
            themeColor = Color(0xFFCBD5E1),
            ultimateColor = Color(0xFF0284C7),
            soundProfile = "sonic"
        ),
        Alien(
            id = "big_chill",
            name = "Big Chill",
            ultimateName = "Ultimate Big Chill",
            species = "Necrofriggian",
            homePlanet = "Kylmyys",
            ability = "Cryo-Intangibility & Crimson Plasma Ice",
            powerLevel = 8200,
            quote = "BIG CHILL! Cold as space!",
            ultimateQuote = "ULTIMATE BIG CHILL! FIRE SO COLD IT BURNS!",
            themeColor = Color(0xFF38BDF8),
            ultimateColor = Color(0xFFEF4444),
            soundProfile = "ice"
        ),
        Alien(
            id = "spidermonkey",
            name = "Spidermonkey",
            ultimateName = "Ultimate Spidermonkey",
            species = "Arachnichimp",
            homePlanet = "Aronet",
            ability = "Arachnid Agility & Giant Gorilla Web Brawn",
            powerLevel = 7900,
            quote = "SPIDERMONKEY! Fast and agile!",
            ultimateQuote = "ULTIMATE SPIDERMONKEY! EXTRA LIMBS & TITAN WEBS!",
            themeColor = Color(0xFF6366F1),
            ultimateColor = Color(0xFF831843),
            soundProfile = "kinetic"
        ),
        Alien(
            id = "cannonbolt",
            name = "Cannonbolt",
            ultimateName = "Ultimate Cannonbolt",
            species = "Arburian Pelarota",
            homePlanet = "Arburia",
            ability = "High-Impact Kinetic Sphere & Metallic Spikes",
            powerLevel = 8600,
            quote = "CANNONBOLT! Roll out!",
            ultimateQuote = "ULTIMATE CANNONBOLT! METALLIC SPIKE SPHERE!",
            themeColor = Color(0xFFF59E0B),
            ultimateColor = Color(0xFF94A3B8),
            soundProfile = "heavy"
        ),
        Alien(
            id = "nrg",
            name = "NRG",
            ultimateName = "NRG (Uncontained)",
            species = "Prypiatosian-B",
            homePlanet = "Prypiatos",
            ability = "Pure Radioactive Plasma Heat Beam",
            powerLevel = 9200,
            quote = "NRG IS G-O-O-D! Nuclear energy max!",
            ultimateQuote = "NRG UNCONTAINED! RADIATION FLARE UP!",
            themeColor = Color(0xFFEA580C),
            ultimateColor = Color(0xFFFBBF24),
            soundProfile = "fire"
        ),
        Alien(
            id = "water_hazard",
            name = "Water Hazard",
            ultimateName = "Water Hazard (Hyper-Tide)",
            species = "Orishan",
            homePlanet = "Kiusana",
            ability = "Pressurized Hydro-Blast Cannons",
            powerLevel = 7800,
            quote = "WATER HAZARD! Torrential blast!",
            ultimateQuote = "WATER HAZARD! HIGH PRESSURE TIDAL TSUNAMI!",
            themeColor = Color(0xFF0284C7),
            ultimateColor = Color(0xFF06B6D4),
            soundProfile = "sonic"
        ),
        Alien(
            id = "armodrillo",
            name = "Armodrillo",
            ultimateName = "Armodrillo (Seismic Drill)",
            species = "Talpaedan",
            homePlanet = "Terraexcava",
            ability = "Jackhammer Pneumatic Earth Tremors",
            powerLevel = 8500,
            quote = "ARMODRILLO! Let's shake the ground!",
            ultimateQuote = "SEISMIC JACKHAMMER OVERDRIVE!",
            themeColor = Color(0xFFEAB308),
            ultimateColor = Color(0xFFCA8A04),
            soundProfile = "heavy"
        ),
        Alien(
            id = "way_big",
            name = "Way Big",
            ultimateName = "Ultimate Way Big",
            species = "To'kustar",
            homePlanet = "Cosmic Storms",
            ability = "Colossal Cosmic Rays & Planet Defense",
            powerLevel = 9999,
            quote = "WAY BIG! Standing over 100 feet tall!",
            ultimateQuote = "ULTIMATE WAY BIG! COSMIC ENERGY VORTEX!",
            themeColor = Color(0xFFE11D48),
            ultimateColor = Color(0xFF4338CA),
            soundProfile = "heavy"
        )
    )
}
