package com.example.model

import androidx.compose.ui.graphics.Color

enum class VisualizerCategory(val displayName: String, val iconName: String) {
    SPECTRUM_BARS("Spectrum Bars", "equalizer"),
    OSCILLOSCOPES("Waveforms & Osc", "graphic_eq"),
    CIRCULAR_RADIAL("Circular & Radial", "radio_button_checked"),
    PARTICLE_VORTEX("Particle Fields", "flare"),
    GEOMETRIC_KALEIDO("Geometric & Prism", "change_history"),
    AMBIENT_ATMOSPHERE("Atmospheres", "grain"),
    RETRO_SYNTHWAVE("Retro Synthwave", "videogame_asset"),
    CYBERPUNK_HUD("Cyberpunk HUD", "memory"),
    ENERGY_PLASMA("Energy & Plasma", "flash_on"),
    ORGANIC_FRACTAL("Organic & Fractals", "spa")
}

enum class VisualizerColorTheme(
    val displayName: String,
    val primary: Color,
    val secondary: Color,
    val glow: Color
) {
    CYAN_PURPLE("Cyan & Purple", Color(0xFF00F0FF), Color(0xFFA855F7), Color(0xFF00FFFF)),
    NEON_SUNSET("Neon Sunset", Color(0xFFFF5E36), Color(0xFFFF0844), Color(0xFFFFB199)),
    MATRIX_GREEN("Matrix Cyber", Color(0xFF00FF66), Color(0xFF00AA33), Color(0xFF88FFBB)),
    ELECTRIC_BLUE("Electric Blue", Color(0xFF00D2FF), Color(0xFF3A7BD5), Color(0xFF90E0EF)),
    FIRE_AMBER("Fire & Amber", Color(0xFFFF9900), Color(0xFFFF3300), Color(0xFFFFD700)),
    GOLDEN_HOUR("Golden Hour", Color(0xFFFFD700), Color(0xFFFF8C00), Color(0xFFFFF0A5)),
    RAINBOW_PRISM("Prism Spectral", Color(0xFF00F0FF), Color(0xFFEC4899), Color(0xFFFFFF00)),
    ICY_AURORA("Icy Aurora", Color(0xFF56CCF2), Color(0xFF2F80ED), Color(0xFFA5F3FC)),
    ACID_MAGENTA("Acid Magenta", Color(0xFFFF007F), Color(0xFF7928CA), Color(0xFFFF77E9)),
    DEEP_SPACE("Cosmic Void", Color(0xFF8B5CF6), Color(0xFF3B82F6), Color(0xFFC084FC))
}

data class VisualizerItem(
    val id: Int,
    val name: String,
    val category: VisualizerCategory,
    val description: String,
    val defaultTheme: VisualizerColorTheme
)

object VisualizerRegistry {
    val ALL_150_VISUALIZERS: List<VisualizerItem> = buildList {
        // 1 - 15: SPECTRUM BARS
        add(VisualizerItem(1, "Classic Equalizer Bars", VisualizerCategory.SPECTRUM_BARS, "Traditional hi-fi studio equalizer bars", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(2, "Mirrored Spectrum", VisualizerCategory.SPECTRUM_BARS, "Symmetrical top and bottom reflecting bars", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(3, "Segmented LED Towers", VisualizerCategory.SPECTRUM_BARS, "Retro hardware rack discrete LED meters", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(4, "Cyberpunk Towers", VisualizerCategory.SPECTRUM_BARS, "High-density neon columns with peak decay", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(5, "Floating Peak Pillars", VisualizerCategory.SPECTRUM_BARS, "Floating levitating peak caps with trails", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(6, "Octave Skyline", VisualizerCategory.SPECTRUM_BARS, "Dynamic urban skyline frequency distribution", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(7, "Gradient Cascade", VisualizerCategory.SPECTRUM_BARS, "Smooth fluid vertical gradient columns", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(8, "Stepped Neon Beams", VisualizerCategory.SPECTRUM_BARS, "Quantized energy beams reacting to bass", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(9, "Dual Sub-Split Bars", VisualizerCategory.SPECTRUM_BARS, "Low and high frequencies split across center", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(10, "Analog VU Stack", VisualizerCategory.SPECTRUM_BARS, "Warm glowing analog VU meter bars", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(11, "Bass Monoliths", VisualizerCategory.SPECTRUM_BARS, "Heavy bass emphasized wide frequency towers", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(12, "Quantum Columns", VisualizerCategory.SPECTRUM_BARS, "Subdivided vibrating quantum pillar bars", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(13, "Hologram Bars", VisualizerCategory.SPECTRUM_BARS, "Semi-transparent glowing holographic bars", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(14, "Dynamic Stems", VisualizerCategory.SPECTRUM_BARS, "Tapered organic stems pulsating with tempo", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(15, "Frequency Waterfall", VisualizerCategory.SPECTRUM_BARS, "Bars cascading downward like a waterfall", VisualizerColorTheme.ELECTRIC_BLUE))

        // 16 - 30: OSCILLOSCOPES & WAVEFORMS
        add(VisualizerItem(16, "Analog CRT Oscilloscope", VisualizerCategory.OSCILLOSCOPES, "Authentic phosphor CRT cathode waveform", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(17, "Laser Sine Beam", VisualizerCategory.OSCILLOSCOPES, "Razor-sharp laser beam dancing across screen", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(18, "Multi-Harmonic Waves", VisualizerCategory.OSCILLOSCOPES, "Overlapping polyphonic harmonic sine waves", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(19, "Dual Stereo Pulse", VisualizerCategory.OSCILLOSCOPES, "Independent Left/Right channel audio streams", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(20, "Liquid Neon Ribbon", VisualizerCategory.OSCILLOSCOPES, "Flowing undulating smooth ribbon waveform", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(21, "Electrocardiogram", VisualizerCategory.OSCILLOSCOPES, "Rhythmic medical heartbeat sound monitor", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(22, "Superwave Detune", VisualizerCategory.OSCILLOSCOPES, "Thick stacked analog synth saw/sine wave", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(23, "Phosphor Green Glow", VisualizerCategory.OSCILLOSCOPES, "Vintage military radar audio receiver trace", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(24, "Velocity Ridge", VisualizerCategory.OSCILLOSCOPES, "Mountain ridge wireframe sound landscape", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(25, "Echo Horizon Wave", VisualizerCategory.OSCILLOSCOPES, "Waveform reflecting across an infinite horizon", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(26, "Sine Morph", VisualizerCategory.OSCILLOSCOPES, "Smooth continuous morphing frequency spline", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(27, "Laser Grid Ripple", VisualizerCategory.OSCILLOSCOPES, "High-intensity laser oscillating grid line", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(28, "Quantum Wave Function", VisualizerCategory.OSCILLOSCOPES, "Probabilistic particle wave envelope", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(29, "Stereo Lissajous", VisualizerCategory.OSCILLOSCOPES, "Complex Lissajous figure X-Y audio loop", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(30, "Acoustic String Vibrato", VisualizerCategory.OSCILLOSCOPES, "Plucked acoustic string harmonic nodes", VisualizerColorTheme.GOLDEN_HOUR))

        // 31 - 45: CIRCULAR & RADIAL
        add(VisualizerItem(31, "Nebula Ring", VisualizerCategory.CIRCULAR_RADIAL, "Cosmic circular pulse radiating starlight", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(32, "Radial Sunburst", VisualizerCategory.CIRCULAR_RADIAL, "Explosive radial beams firing from center", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(33, "Pulsing Halo", VisualizerCategory.CIRCULAR_RADIAL, "Smooth breathing concentric glowing rings", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(34, "Galaxy Spiral Arms", VisualizerCategory.CIRCULAR_RADIAL, "Rotating spiral arms spinning to audio beats", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(35, "Sonic Compass Dial", VisualizerCategory.CIRCULAR_RADIAL, "Precision navigational circular audio gauge", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(36, "Lotus Flower Mandala", VisualizerCategory.CIRCULAR_RADIAL, "Blooming geometric petals opening to rhythm", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(37, "Orbiting Resonance Orbs", VisualizerCategory.CIRCULAR_RADIAL, "Spheres orbiting along frequency tracks", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(38, "Polar Sonar Sweep", VisualizerCategory.CIRCULAR_RADIAL, "Submarine circular radar sweep line", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(39, "Hexagonal Iris", VisualizerCategory.CIRCULAR_RADIAL, "Mechanical camera iris expanding to bass", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(40, "Rotating Chakras", VisualizerCategory.CIRCULAR_RADIAL, "Spinning intricate spiritual energy circles", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(41, "Atomic Orbital Shells", VisualizerCategory.CIRCULAR_RADIAL, "Electrons orbiting nucleus reacting to highs", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(42, "Solar Corona Flare", VisualizerCategory.CIRCULAR_RADIAL, "Blazing solar prominence radiating energy", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(43, "Eclipse Ring", VisualizerCategory.CIRCULAR_RADIAL, "Dark moon silhouette with diamond audio ring", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(44, "Concentric Bass Shockwaves", VisualizerCategory.CIRCULAR_RADIAL, "Ripples propagating outwards from center kick", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(45, "Radial Equalizer Wheel", VisualizerCategory.CIRCULAR_RADIAL, "Circular 360-degree bar visualizer wheel", VisualizerColorTheme.CYAN_PURPLE))

        // 46 - 60: PARTICLE FIELDS & VORTEXES
        add(VisualizerItem(46, "Stardust Vortex", VisualizerCategory.PARTICLE_VORTEX, "Swirling cosmic whirlpool of stardust", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(47, "Firefly Drift", VisualizerCategory.PARTICLE_VORTEX, "Gentle glowing embers floating softly in dark", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(48, "Cosmic Snowfall", VisualizerCategory.PARTICLE_VORTEX, "Crystalline particles falling and rebounding", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(49, "Solar Flare Burst", VisualizerCategory.PARTICLE_VORTEX, "High velocity particles ejected on beat drops", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(50, "Ember Rise", VisualizerCategory.PARTICLE_VORTEX, "Bonfire sparks ascending upwards into night", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(51, "Rain of Light", VisualizerCategory.PARTICLE_VORTEX, "Vertical light streaks falling like luminescent rain", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(52, "Quantum Spark Cloud", VisualizerCategory.PARTICLE_VORTEX, "Microscopic electric sparks jumping across field", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(53, "Meteor Shower", VisualizerCategory.PARTICLE_VORTEX, "Shooting stars streaking diagonally on peaks", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(54, "Swarm Intelligence", VisualizerCategory.PARTICLE_VORTEX, "Boids flocking and swirling following the melody", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(55, "Gravity Well", VisualizerCategory.PARTICLE_VORTEX, "Particles drawn toward an audio event horizon", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(56, "Starlight Warp Speed", VisualizerCategory.PARTICLE_VORTEX, "Hyperspace stars stretching into light rays", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(57, "Plasma Dust Fog", VisualizerCategory.PARTICLE_VORTEX, "Cloud of charged particles diffusing on mids", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(58, "Constellation Drift", VisualizerCategory.PARTICLE_VORTEX, "Nodes linking into star charts dynamically", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(59, "Sparkler Firework", VisualizerCategory.PARTICLE_VORTEX, "Continuous sparkler fireworks expanding", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(60, "Antimatter Cascade", VisualizerCategory.PARTICLE_VORTEX, "Colliding particle sparks annihilating on beat", VisualizerColorTheme.FIRE_AMBER))

        // 61 - 75: GEOMETRIC & KALEIDOSCOPIC
        add(VisualizerItem(61, "Hexagon Lattice Grid", VisualizerCategory.GEOMETRIC_KALEIDO, "Honeycomb cells pulsing in harmonic unison", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(62, "Polyhedron Morph", VisualizerCategory.GEOMETRIC_KALEIDO, "3D platonic solid rotating and deforming", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(63, "Sacred Metatron Cube", VisualizerCategory.GEOMETRIC_KALEIDO, "Ancient geometry intersecting in sacred harmony", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(64, "Kaleidoscope Prism", VisualizerCategory.GEOMETRIC_KALEIDO, "Reflective 8-fold symmetrical prism kaleidoscope", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(65, "Diamond Facets", VisualizerCategory.GEOMETRIC_KALEIDO, "Gleaming gemstone facets refracting light", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(66, "Cyber Tesseract Cube", VisualizerCategory.GEOMETRIC_KALEIDO, "4D hypercube projecting into screen plane", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(67, "Isometric City Blocks", VisualizerCategory.GEOMETRIC_KALEIDO, "Isometric buildings bobbing up and down", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(68, "Tessellation Wave", VisualizerCategory.GEOMETRIC_KALEIDO, "Interlocking triangular mesh undulating", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(69, "Golden Ratio Fibonacci", VisualizerCategory.GEOMETRIC_KALEIDO, "Logarithmic spiral expanding with amplitude", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(70, "Voronoi Cells", VisualizerCategory.GEOMETRIC_KALEIDO, "Dynamic organic Voronoi diagram boundary waves", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(71, "Crystal Lattice Array", VisualizerCategory.GEOMETRIC_KALEIDO, "Mineral atomic lattice resonating to audio", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(72, "Shifting Prism Pyramids", VisualizerCategory.GEOMETRIC_KALEIDO, "Pyramidal prisms refracting laser reflections", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(73, "Quantum Matrix Cage", VisualizerCategory.GEOMETRIC_KALEIDO, "Geometric containment field trapping sound energy", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(74, "Gyroscope Rings", VisualizerCategory.GEOMETRIC_KALEIDO, "Gimbal rings spinning on multiple axes", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(75, "Origami Tessera", VisualizerCategory.GEOMETRIC_KALEIDO, "Paper-like geometric folds breathing to rhythm", VisualizerColorTheme.ACID_MAGENTA))

        // 76 - 90: AMBIENT ATMOSPHERES
        add(VisualizerItem(76, "Aurora Borealis Curtains", VisualizerCategory.AMBIENT_ATMOSPHERE, "Shimmering arctic curtains of green and violet", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(77, "Northern Polar Lights", VisualizerCategory.AMBIENT_ATMOSPHERE, "Mystical geomagnetic polar light ribbons", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(78, "Psychedelic Lava Lamp", VisualizerCategory.AMBIENT_ATMOSPHERE, "Viscous organic fluid bubbles merging and rising", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(79, "Liquid Color Smoke", VisualizerCategory.AMBIENT_ATMOSPHERE, "Dense colorful smoke billows swirling smoothly", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(80, "Sunset Ocean Horizon", VisualizerCategory.AMBIENT_ATMOSPHERE, "Warm dusk sun reflecting upon rolling waves", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(81, "Abyssal Deep Ocean", VisualizerCategory.AMBIENT_ATMOSPHERE, "Subsea bioluminescent pressure waves in the dark", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(82, "Dreamy Cloudscape", VisualizerCategory.AMBIENT_ATMOSPHERE, "Floating ethereal clouds illuminated by moonlight", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(83, "Neon Tokyo Fog", VisualizerCategory.AMBIENT_ATMOSPHERE, "Distant billboard neon bleeding through street fog", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(84, "Bioluminescent Lagoon", VisualizerCategory.AMBIENT_ATMOSPHERE, "Glowing plankton illuminating ripples in water", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(85, "Velvet Midnight Mist", VisualizerCategory.AMBIENT_ATMOSPHERE, "Silky mist drifting across deep indigo shadows", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(86, "Solar Solar Wind", VisualizerCategory.AMBIENT_ATMOSPHERE, "Stream of charged magnetic plasma in space", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(87, "Desert Mirage Mirage", VisualizerCategory.AMBIENT_ATMOSPHERE, "Heat shimmer warping vibrant distant lights", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(88, "Ethereal Spirit Aura", VisualizerCategory.AMBIENT_ATMOSPHERE, "Glowing energy field expanding and breathing", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(89, "Twilight Shimmer", VisualizerCategory.AMBIENT_ATMOSPHERE, "Subtle sparkling glow transitioning to dark", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(90, "Nebular Cloud Nursery", VisualizerCategory.AMBIENT_ATMOSPHERE, "Interstellar gas nursery birthing newborn stars", VisualizerColorTheme.DEEP_SPACE))

        // 91 - 105: RETRO SYNTHWAVE
        add(VisualizerItem(91, "Outrun 80s Grid", VisualizerCategory.RETRO_SYNTHWAVE, "Iconic wireframe neon ground receding to horizon", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(92, "Vaporwave Neon Sun", VisualizerCategory.RETRO_SYNTHWAVE, "Segmented glowing sun rising over purple grid", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(93, "Cassette Tape Spools", VisualizerCategory.RETRO_SYNTHWAVE, "Rotating vintage cassette reels and magnetic tape", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(94, "CRT Terminal Scanlines", VisualizerCategory.RETRO_SYNTHWAVE, "Old school monitor phosphor curvature & noise", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(95, "Arcade Space Invader", VisualizerCategory.RETRO_SYNTHWAVE, "8-bit pixel art shapes pulsating to electro beats", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(96, "Vaporwave Palms", VisualizerCategory.RETRO_SYNTHWAVE, "Neon palm silhouettes against chrome sunset", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(97, "DeLorean Turbo Dash", VisualizerCategory.RETRO_SYNTHWAVE, "Cyber sports car speedometer & flux gauge", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(98, "Neon Highway Cruise", VisualizerCategory.RETRO_SYNTHWAVE, "Infinite highway strip with glowing taillights", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(99, "Wireframe Mountain Ridge", VisualizerCategory.RETRO_SYNTHWAVE, "Retro vectors drawing synth mountain terrain", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(100, "Analog VU Needles", VisualizerCategory.RETRO_SYNTHWAVE, "Bouncing vintage analog needle audio meters", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(101, "VHS Tracking Glitch", VisualizerCategory.RETRO_SYNTHWAVE, "Tape static lines and magnetic chromatic drift", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(102, "Laser Disco Floor", VisualizerCategory.RETRO_SYNTHWAVE, "Tiled light-up dancefloor squares reacting to kick", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(103, "Retro Sci-Fi HUD", VisualizerCategory.RETRO_SYNTHWAVE, "1980s spaceship cockpit flight telemetry", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(104, "Synth Horizon Sunset", VisualizerCategory.RETRO_SYNTHWAVE, "Glow strips descending into a retro horizon line", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(105, "Chiptune Wave Matrix", VisualizerCategory.RETRO_SYNTHWAVE, "Square wave chiptune 4-channel sound visualizer", VisualizerColorTheme.ELECTRIC_BLUE))

        // 106 - 120: CYBERPUNK HUD
        add(VisualizerItem(106, "Matrix Digital Rain", VisualizerCategory.CYBERPUNK_HUD, "Falling glowing Japanese glyphs and code streams", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(107, "Cyber Circuit Traces", VisualizerCategory.CYBERPUNK_HUD, "Printed motherboard traces carrying audio currents", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(108, "Bio-Hazard Tactical HUD", VisualizerCategory.CYBERPUNK_HUD, "Futuristic combat helmet sight tracking audio frequencies", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(109, "Neon City Nightscape", VisualizerCategory.CYBERPUNK_HUD, "Towering cyber skyscrapers flashing advertisements", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(110, "Neural Network Synapses", VisualizerCategory.CYBERPUNK_HUD, "Nodes firing electronic spikes across neural net", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(111, "Glitch Decryptor", VisualizerCategory.CYBERPUNK_HUD, "Hexadecimal memory dump decoding live music", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(112, "Lock-On Target Reticle", VisualizerCategory.CYBERPUNK_HUD, "Locking crosshairs rotating on beat impulses", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(113, "Tactical Sonar Radar", VisualizerCategory.CYBERPUNK_HUD, "Sweeping sweep beam illuminating frequency blips", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(114, "Cybernetic Optical Eye", VisualizerCategory.CYBERPUNK_HUD, "Mechanical cyber iris zooming into sound waves", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(115, "Hologram Flight Nav", VisualizerCategory.CYBERPUNK_HUD, "Floating holographic altimeter and heading indicators", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(116, "Nanotech Swarm Cloud", VisualizerCategory.CYBERPUNK_HUD, "Microscopic nanobots assembling structures", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(117, "Wireframe Skull Cyber", VisualizerCategory.CYBERPUNK_HUD, "Stylized wireframe cybernetic skull pulsing to bass", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(118, "Quantum Fusion Core", VisualizerCategory.CYBERPUNK_HUD, "Reactor containment magnetic rings spinning", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(119, "Data Packet Stream", VisualizerCategory.CYBERPUNK_HUD, "High-bandwidth fiber optic data packet bursts", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(120, "System Override Warning", VisualizerCategory.CYBERPUNK_HUD, "High alert flashing cyber warning indicators", VisualizerColorTheme.FIRE_AMBER))

        // 121 - 135: ENERGY & PLASMA
        add(VisualizerItem(121, "Lightning Arc Discharge", VisualizerCategory.ENERGY_PLASMA, "Branching high voltage lightning strikes on peaks", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(122, "Tesla Coil Sparks", VisualizerCategory.ENERGY_PLASMA, "Singing electric arcs emitting musical frequencies", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(123, "Plasma Orb Sphere", VisualizerCategory.ENERGY_PLASMA, "Glass globe with dancing electric filaments", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(124, "Electric Thunderstorm", VisualizerCategory.ENERGY_PLASMA, "Atmospheric flashes lighting up tempest clouds", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(125, "Tokamak Fusion Flame", VisualizerCategory.ENERGY_PLASMA, "Toroidal plasma ring glowing at millions of degrees", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(126, "Arc Reactor Glow", VisualizerCategory.ENERGY_PLASMA, "Repulsor core heart glowing with pure energy", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(127, "Supernova Stellar Blast", VisualizerCategory.ENERGY_PLASMA, "Cataclysmic star explosion expanding shockwaves", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(128, "Laser Fan Array", VisualizerCategory.ENERGY_PLASMA, "Concert stage fan of sweeping laser beams", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(129, "Solar Prominence Loop", VisualizerCategory.ENERGY_PLASMA, "Gigantic magnetic plasma loop above the sun", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(130, "Ion Particle Beam", VisualizerCategory.ENERGY_PLASMA, "Focused particle accelerator beam glowing blue", VisualizerColorTheme.ELECTRIC_BLUE))
        add(VisualizerItem(131, "Singularity Event Horizon", VisualizerCategory.ENERGY_PLASMA, "Gravitational lensing warping energetic beams", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(132, "Ball Lightning Mirage", VisualizerCategory.ENERGY_PLASMA, "Rare floating spherical lightning manifestation", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(133, "Dark Energy Pulse", VisualizerCategory.ENERGY_PLASMA, "Negative matter shockwave distorting space", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(134, "Proton Collision Ring", VisualizerCategory.ENERGY_PLASMA, "Synchrotron ring accelerating particles to lightspeed", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(135, "High Voltage Corona", VisualizerCategory.ENERGY_PLASMA, "Violet electrical corona discharge around conductors", VisualizerColorTheme.DEEP_SPACE))

        // 136 - 150: ORGANIC & FRACTALS
        add(VisualizerItem(136, "Mandelbrot Fractal Zoom", VisualizerCategory.ORGANIC_FRACTAL, "Endless hypnotic fractal boundary unfolding", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(137, "Human Heart Pulse", VisualizerCategory.ORGANIC_FRACTAL, "Organic heartbeat expansion and vascular flow", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(138, "Bioluminescent Coral", VisualizerCategory.ORGANIC_FRACTAL, "Deep ocean coral polyps glowing under currents", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(139, "Tendril Wave Vines", VisualizerCategory.ORGANIC_FRACTAL, "Climbing creeping vines reacting to acoustic pitch", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(140, "Tree of Life Canopy", VisualizerCategory.ORGANIC_FRACTAL, "Branching fractal tree limbs blooming with leaves", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(141, "Glowing Jellyfish Drift", VisualizerCategory.ORGANIC_FRACTAL, "Translucent deep-sea jellyfish pulsing to bass", VisualizerColorTheme.ICY_AURORA))
        add(VisualizerItem(142, "Mushroom Spore Bloom", VisualizerCategory.ORGANIC_FRACTAL, "Spore pods releasing shimmering micro-particles", VisualizerColorTheme.DEEP_SPACE))
        add(VisualizerItem(143, "Morphing Amoeba Cell", VisualizerCategory.ORGANIC_FRACTAL, "Single-celled organism flexing membrane to rhythm", VisualizerColorTheme.ACID_MAGENTA))
        add(VisualizerItem(144, "Floral Mandala Bloom", VisualizerCategory.ORGANIC_FRACTAL, "Multilayered sacred floral petals unfurling", VisualizerColorTheme.RAINBOW_PRISM))
        add(VisualizerItem(145, "Mycelium Forest Network", VisualizerCategory.ORGANIC_FRACTAL, "Underground fungal hyphae transmitting light signals", VisualizerColorTheme.MATRIX_GREEN))
        add(VisualizerItem(146, "Nautilus Spiral Shell", VisualizerCategory.ORGANIC_FRACTAL, "Logarithmic chambered spiral in cross section", VisualizerColorTheme.GOLDEN_HOUR))
        add(VisualizerItem(147, "Root Pulse Resonance", VisualizerCategory.ORGANIC_FRACTAL, "Deep subterranean roots drawing acoustic nutrients", VisualizerColorTheme.FIRE_AMBER))
        add(VisualizerItem(148, "Cellular Mitosis Division", VisualizerCategory.ORGANIC_FRACTAL, "Cells dividing and multiplying under heavy beats", VisualizerColorTheme.NEON_SUNSET))
        add(VisualizerItem(149, "DNA Double Helix", VisualizerCategory.ORGANIC_FRACTAL, "Rotating double helix strand with illuminated base pairs", VisualizerColorTheme.CYAN_PURPLE))
        add(VisualizerItem(150, "Cosmic Tree of Souls", VisualizerCategory.ORGANIC_FRACTAL, "Ancestral glowing spiritual tree connecting all sounds", VisualizerColorTheme.RAINBOW_PRISM))
    }
}
