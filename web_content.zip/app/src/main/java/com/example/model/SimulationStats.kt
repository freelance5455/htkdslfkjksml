package com.example.model

enum class SimulationState {
    IDLE,
    RUNNING,
    PAUSED,
    COMPLETED,
    STOPPED
}

data class SimulationStats(
    val state: SimulationState = SimulationState.IDLE,
    val totalScheduled: Int = 35,
    val completedCount: Int = 0,
    val successCount: Int = 0,      // 2xx
    val redirectCount: Int = 0,     // 3xx
    val clientErrorCount: Int = 0,  // 4xx
    val serverErrorCount: Int = 0,  // 5xx
    val networkErrorCount: Int = 0, // connection failed / timeouts
    val avgLatencyMs: Long = 0L,
    val minLatencyMs: Long = 0L,
    val maxLatencyMs: Long = 0L,
    val totalBytesReceived: Long = 0L,
    val startTimeMs: Long = 0L,
    val elapsedMs: Long = 0L,
    val currentRequestIndex: Int = 0
) {
    val progress: Float
        get() = if (totalScheduled > 0) (completedCount.toFloat() / totalScheduled.toFloat()).coerceIn(0f, 1f) else 0f

    val requestsPerSecond: Float
        get() {
            val seconds = elapsedMs / 1000f
            return if (seconds > 0.1f && completedCount > 0) completedCount / seconds else 0f
        }

    val estimatedTimeRemainingSeconds: Int
        get() {
            val rps = requestsPerSecond
            val remaining = totalScheduled - completedCount
            return if (rps > 0.05f && remaining > 0) (remaining / rps).toInt() else 0
        }
}

data class TestRunHistory(
    val id: String,
    val timestamp: Long,
    val url: String,
    val method: String,
    val totalVisits: Int,
    val successCount: Int,
    val failureCount: Int,
    val avgLatencyMs: Long,
    val totalBytes: Long,
    val completedDurationMs: Long
)
