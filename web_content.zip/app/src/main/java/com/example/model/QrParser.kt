package com.example.model

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object QrParser {

    fun parse(raw: String): ParsedQr {
        val trimmed = raw.trim()

        // 1. Wi-Fi
        if (trimmed.startsWith("WIFI:", ignoreCase = true)) {
            return parseWifi(trimmed)
        }

        // 2. vCard or MeCard
        if (trimmed.startsWith("BEGIN:VCARD", ignoreCase = true) || trimmed.startsWith("MECARD:", ignoreCase = true)) {
            return parseContact(trimmed)
        }

        // 3. Email
        if (trimmed.startsWith("mailto:", ignoreCase = true) || trimmed.startsWith("MATMSG:", ignoreCase = true) || trimmed.startsWith("SMTP:", ignoreCase = true)) {
            return parseEmail(trimmed)
        }

        // 4. Phone
        if (trimmed.startsWith("tel:", ignoreCase = true) || (trimmed.startsWith("+") && trimmed.substring(1).all { it.isDigit() || it == ' ' || it == '-' })) {
            return parsePhone(trimmed)
        }

        // 5. SMS
        if (trimmed.startsWith("smsto:", ignoreCase = true) || trimmed.startsWith("sms:", ignoreCase = true) || trimmed.startsWith("SMSTO:", ignoreCase = true)) {
            return parseSms(trimmed)
        }

        // 6. Geo location
        if (trimmed.startsWith("geo:", ignoreCase = true)) {
            return parseGeo(trimmed)
        }

        // 7. Payment (UPI, Crypto, PayPal)
        if (trimmed.startsWith("upi://pay", ignoreCase = true) || trimmed.startsWith("bitcoin:", ignoreCase = true) || trimmed.startsWith("ethereum:", ignoreCase = true) || trimmed.contains("paypal.me/", ignoreCase = true)) {
            return parsePayment(trimmed)
        }

        // 8. URL
        if (isLikelyUrl(trimmed)) {
            return parseUrl(trimmed)
        }

        // Fallback: Plain Text
        val preview = if (trimmed.length > 100) trimmed.take(97) + "..." else trimmed
        return ParsedQr(
            rawText = trimmed,
            category = QrCategory.TEXT,
            title = "Plain Text",
            subtitle = "${trimmed.length} characters",
            primaryActionLabel = "Copy Text",
            displayContent = trimmed,
            actionableUri = null
        )
    }

    private fun isLikelyUrl(text: String): Boolean {
        if (text.startsWith("http://", ignoreCase = true) || text.startsWith("https://", ignoreCase = true)) {
            return true
        }
        if (text.startsWith("www.", ignoreCase = true)) {
            return true
        }
        val domainRegex = Regex("^[a-zA-Z0-9-]+\\.[a-zA-Z]{2,}(/.*)?$")
        return domainRegex.matches(text) && !text.contains("\n") && !text.contains(" ")
    }

    private fun parseUrl(raw: String): ParsedQr {
        val fullUrl = if (!raw.startsWith("http://", ignoreCase = true) && !raw.startsWith("https://", ignoreCase = true)) {
            "https://$raw"
        } else {
            raw
        }

        val domain = runCatching {
            val uri = URI(fullUrl)
            uri.host ?: fullUrl
        }.getOrDefault(fullUrl)

        val isSecure = fullUrl.startsWith("https://", ignoreCase = true)

        return ParsedQr(
            rawText = raw,
            category = QrCategory.URL,
            title = domain,
            subtitle = if (isSecure) "Secure HTTPS Website" else "HTTP Website (Unencrypted)",
            primaryActionLabel = "Open Link",
            extraDetails = mapOf(
                "Domain" to domain,
                "Protocol" to if (isSecure) "HTTPS (Secure)" else "HTTP",
                "Full URL" to fullUrl
            ),
            displayContent = fullUrl,
            actionableUri = fullUrl,
            isSecureWeb = isSecure
        )
    }

    private fun parseWifi(raw: String): ParsedQr {
        var ssid = ""
        var password = ""
        var type = "WPA"
        var hidden = false

        // Example: WIFI:S:MyNetwork;T:WPA;P:pass123;H:false;;
        val clean = raw.substring(5).trimEnd(';')
        val tokens = clean.split(";")
        for (token in tokens) {
            val idx = token.indexOf(':')
            if (idx != -1) {
                val key = token.substring(0, idx).uppercase()
                val value = token.substring(idx + 1)
                when (key) {
                    "S" -> ssid = value
                    "P" -> password = value
                    "T" -> type = if (value.isBlank()) "None (Open)" else value
                    "H" -> hidden = value.equals("true", ignoreCase = true)
                }
            }
        }

        val details = mutableMapOf<String, String>()
        details["Network (SSID)"] = ssid.ifBlank { "Unknown" }
        details["Security"] = type
        if (password.isNotBlank()) {
            details["Password"] = password
        }
        details["Hidden Network"] = if (hidden) "Yes" else "No"

        return ParsedQr(
            rawText = raw,
            category = QrCategory.WIFI,
            title = ssid.ifBlank { "Wi-Fi Network" },
            subtitle = "Security: $type",
            primaryActionLabel = "Connect to Wi-Fi",
            extraDetails = details,
            displayContent = "SSID: $ssid\nPassword: ${if (password.isNotBlank()) password else "(No Password)"}",
            actionableUri = "wifi:$ssid"
        )
    }

    private fun parseContact(raw: String): ParsedQr {
        var name = ""
        var phone = ""
        var email = ""
        var org = ""
        var title = ""

        if (raw.startsWith("BEGIN:VCARD", ignoreCase = true)) {
            val lines = raw.lines()
            for (line in lines) {
                val parts = line.split(":", limit = 2)
                if (parts.size == 2) {
                    val key = parts[0].uppercase().substringBefore(";")
                    val value = parts[1].trim()
                    when {
                        key == "FN" && name.isBlank() -> name = value
                        key == "N" && name.isBlank() -> {
                            val names = value.split(";").filter { it.isNotBlank() }
                            name = names.reversed().joinToString(" ")
                        }
                        key.startsWith("TEL") && phone.isBlank() -> phone = value
                        key.startsWith("EMAIL") && email.isBlank() -> email = value
                        key == "ORG" && org.isBlank() -> org = value
                        key == "TITLE" && title.isBlank() -> title = value
                    }
                }
            }
        } else if (raw.startsWith("MECARD:", ignoreCase = true)) {
            val content = raw.substring(7)
            val parts = content.split(";")
            for (part in parts) {
                val idx = part.indexOf(':')
                if (idx != -1) {
                    val key = part.substring(0, idx).uppercase()
                    val value = part.substring(idx + 1)
                    when (key) {
                        "N" -> name = value.replace(",", " ")
                        "TEL" -> if (phone.isBlank()) phone = value
                        "EMAIL" -> if (email.isBlank()) email = value
                        "ORG" -> if (org.isBlank()) org = value
                    }
                }
            }
        }

        val details = mutableMapOf<String, String>()
        if (name.isNotBlank()) details["Name"] = name
        if (phone.isNotBlank()) details["Phone"] = phone
        if (email.isNotBlank()) details["Email"] = email
        if (org.isNotBlank()) details["Organization"] = org
        if (title.isNotBlank()) details["Title"] = title

        val display = buildString {
            if (name.isNotBlank()) appendLine("Name: $name")
            if (phone.isNotBlank()) appendLine("Phone: $phone")
            if (email.isNotBlank()) appendLine("Email: $email")
            if (org.isNotBlank()) appendLine("Org: $org")
        }.trim()

        return ParsedQr(
            rawText = raw,
            category = QrCategory.CONTACT,
            title = name.ifBlank { "Contact Card" },
            subtitle = if (phone.isNotBlank()) phone else if (email.isNotBlank()) email else "vCard Details",
            primaryActionLabel = "Add to Contacts",
            extraDetails = details,
            displayContent = display.ifBlank { raw },
            actionableUri = if (phone.isNotBlank()) "tel:$phone" else null
        )
    }

    private fun parseEmail(raw: String): ParsedQr {
        var email = ""
        var subject = ""
        var body = ""

        if (raw.startsWith("mailto:", ignoreCase = true)) {
            val withoutPrefix = raw.substring(7)
            val parts = withoutPrefix.split("?", limit = 2)
            email = parts[0]
            if (parts.size > 1) {
                val params = parts[1].split("&")
                for (param in params) {
                    val pair = param.split("=", limit = 2)
                    if (pair.size == 2) {
                        val key = pair[0].lowercase()
                        val value = runCatching { URLDecoder.decode(pair[1], StandardCharsets.UTF_8.name()) }.getOrDefault(pair[1])
                        when (key) {
                            "subject" -> subject = value
                            "body" -> body = value
                        }
                    }
                }
            }
        } else if (raw.startsWith("MATMSG:", ignoreCase = true)) {
            val tokens = raw.substring(7).split(";")
            for (token in tokens) {
                val idx = token.indexOf(':')
                if (idx != -1) {
                    val key = token.substring(0, idx).uppercase()
                    val value = token.substring(idx + 1)
                    when (key) {
                        "TO" -> email = value
                        "SUB" -> subject = value
                        "BODY" -> body = value
                    }
                }
            }
        }

        val details = mutableMapOf<String, String>()
        details["Recipient"] = email
        if (subject.isNotBlank()) details["Subject"] = subject
        if (body.isNotBlank()) details["Message"] = body

        return ParsedQr(
            rawText = raw,
            category = QrCategory.EMAIL,
            title = email.ifBlank { "Send Email" },
            subtitle = if (subject.isNotBlank()) "Subject: $subject" else "New Email Message",
            primaryActionLabel = "Send Email",
            extraDetails = details,
            displayContent = "To: $email\n${if (subject.isNotBlank()) "Subject: $subject\n" else ""}${if (body.isNotBlank()) "Body: $body" else ""}".trim(),
            actionableUri = "mailto:$email"
        )
    }

    private fun parsePhone(raw: String): ParsedQr {
        val number = if (raw.startsWith("tel:", ignoreCase = true)) raw.substring(4) else raw
        return ParsedQr(
            rawText = raw,
            category = QrCategory.PHONE,
            title = number,
            subtitle = "Phone Number",
            primaryActionLabel = "Call Number",
            extraDetails = mapOf("Phone Number" to number),
            displayContent = number,
            actionableUri = "tel:$number"
        )
    }

    private fun parseSms(raw: String): ParsedQr {
        var number = ""
        var message = ""

        if (raw.startsWith("smsto:", ignoreCase = true) || raw.startsWith("SMSTO:", ignoreCase = true)) {
            val content = raw.substring(6)
            val parts = content.split(":", limit = 2)
            number = parts[0]
            if (parts.size > 1) message = parts[1]
        } else if (raw.startsWith("sms:", ignoreCase = true)) {
            val content = raw.substring(4)
            val parts = content.split("?", limit = 2)
            number = parts[0]
            if (parts.size > 1 && parts[1].startsWith("body=", ignoreCase = true)) {
                message = runCatching {
                    URLDecoder.decode(parts[1].substring(5), StandardCharsets.UTF_8.name())
                }.getOrDefault(parts[1].substring(5))
            }
        }

        val details = mutableMapOf<String, String>()
        details["Recipient"] = number
        if (message.isNotBlank()) details["Message"] = message

        return ParsedQr(
            rawText = raw,
            category = QrCategory.SMS,
            title = "SMS to $number",
            subtitle = if (message.isNotBlank()) message.take(40) else "Send SMS message",
            primaryActionLabel = "Send SMS",
            extraDetails = details,
            displayContent = "To: $number\nMessage: $message",
            actionableUri = "smsto:$number"
        )
    }

    private fun parseGeo(raw: String): ParsedQr {
        // geo:37.7749,-122.4194?q=San+Francisco
        val content = raw.substring(4)
        val parts = content.split("?", limit = 2)
        val coords = parts[0]
        var query = ""
        if (parts.size > 1 && parts[1].startsWith("q=", ignoreCase = true)) {
            query = runCatching {
                URLDecoder.decode(parts[1].substring(2), StandardCharsets.UTF_8.name())
            }.getOrDefault(parts[1].substring(2))
        }

        val details = mutableMapOf<String, String>()
        details["Coordinates"] = coords
        if (query.isNotBlank()) details["Label/Query"] = query

        return ParsedQr(
            rawText = raw,
            category = QrCategory.LOCATION,
            title = query.ifBlank { coords },
            subtitle = "Map Coordinates: $coords",
            primaryActionLabel = "Open in Maps",
            extraDetails = details,
            displayContent = "Location: $coords\nQuery: $query",
            actionableUri = raw
        )
    }

    private fun parsePayment(raw: String): ParsedQr {
        var payee = ""
        var amount = ""
        var note = ""

        if (raw.startsWith("upi://pay", ignoreCase = true)) {
            val query = raw.substringAfter("?", "")
            for (param in query.split("&")) {
                val pair = param.split("=", limit = 2)
                if (pair.size == 2) {
                    val key = pair[0].lowercase()
                    val value = runCatching { URLDecoder.decode(pair[1], StandardCharsets.UTF_8.name()) }.getOrDefault(pair[1])
                    when (key) {
                        "pn" -> payee = value
                        "pa" -> if (payee.isBlank()) payee = value
                        "am" -> amount = value
                        "tn" -> note = value
                    }
                }
            }
        }

        val details = mutableMapOf<String, String>()
        if (payee.isNotBlank()) details["Payee"] = payee
        if (amount.isNotBlank()) details["Amount"] = amount
        if (note.isNotBlank()) details["Note"] = note

        return ParsedQr(
            rawText = raw,
            category = QrCategory.PAYMENT,
            title = if (payee.isNotBlank()) "Pay $payee" else "Payment QR",
            subtitle = if (amount.isNotBlank()) "Amount: $amount" else "Digital Payment",
            primaryActionLabel = "Proceed to Pay",
            extraDetails = details,
            displayContent = if (details.isNotEmpty()) details.entries.joinToString("\n") { "${it.key}: ${it.value}" } else raw,
            actionableUri = raw
        )
    }
}
