package com.example.model

data class ProjectRecipe(
  val version: String = "1.0",
  val projectName: String = "Untitled Motion",
  val settings: ProjectSettings = ProjectSettings(),
  val scenes: List<Scene> = emptyList(),
  val audioTrack: AudioTrackConfig? = null,
  val exportSettings: ExportSettings = ExportSettings()
)

data class ProjectSettings(
  val width: Int = 1080,
  val height: Int = 1920, // 9:16 vertical default
  val fps: Int = 30,
  val durationSeconds: Float = 10.0f,
  val visualStyle: String = "cyberpunk"
)

data class Scene(
  val id: String = "scene_1",
  val name: String = "Main Scene",
  val startTime: Float = 0.0f,
  val duration: Float = 10.0f,
  val background: BackgroundConfig = BackgroundConfig(),
  val layers: List<Layer> = emptyList()
)

data class BackgroundConfig(
  val type: String = "gradient", // gradient, solid, particle, grid
  val color1: String = "#0D0D0D",
  val color2: String = "#1A1A1A",
  val angle: Float = 45.0f
)

sealed class LayerType {
  data class Text(
    val content: String,
    val fontSize: Float = 48f,
    val textColor: String = "#FFFFFF",
    val revealEffect: String = "character_fade"
  ) : LayerType()

  data class Shape(
    val shapeType: String = "rectangle", // rectangle, circle, star, path
    val fillColor: String = "#FF6B00",
    val strokeColor: String = "#FFFFFF",
    val strokeWidth: Float = 4f
  ) : LayerType()

  data class Object3D(
    val modelType: String = "cube", // cube, sphere, pyramid, text3d
    val material: String = "metallic",
    val color: String = "#FF9E00",
    val rotationSpeed: Float = 1.0f
  ) : LayerType()

  data class ImageLayer(
    val urlOrPlaceholder: String = "placeholder"
  ) : LayerType()
}

data class Layer(
  val id: String,
  val name: String,
  val type: String, // "text", "shape", "3d", "image"
  val startTime: Float = 0.0f,
  val duration: Float = 5.0f,
  val posX: Float = 540f,
  val posY: Float = 960f,
  val scale: Float = 1.0f,
  val rotation: Float = 0.0f,
  val opacity: Float = 1.0f,
  val textConfig: TextConfig? = null,
  val shapeConfig: ShapeConfig? = null,
  val object3DConfig: Object3DConfig? = null
)

data class TextConfig(
  val text: String = "MotionForge AI",
  val fontSize: Int = 56,
  val color: String = "#FFFFFF",
  val revealMode: String = "word_by_word"
)

data class ShapeConfig(
  val shape: String = "rounded_rect", // circle, rect, pill
  val color: String = "#FF6B00",
  val glow: Boolean = true
)

data class Object3DConfig(
  val primitive: String = "cube", // cube, sphere, torus
  val color: String = "#FF9E00",
  val wireframe: Boolean = false
)

data class AudioTrackConfig(
  val title: String = "Cyber Beat 120BPM",
  val duration: Float = 10.0f,
  val beatInterval: Float = 0.5f,
  val syncIntensity: String = "balanced" // subtle, balanced, aggressive
)

data class ExportSettings(
  val resolution: String = "1080x1920",
  val format: String = "mp4",
  val quality: String = "high",
  val fps: Int = 30
)

data class ValidationResult(
  val isValid: Boolean,
  val errors: List<String> = emptyList(),
  val warnings: List<String> = emptyList(),
  val recipe: ProjectRecipe? = null
)
