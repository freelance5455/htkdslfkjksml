package com.example.tictactoepro

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var adView: AdView
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var isAdLoading = false

    // Google official test ad unit IDs. Replace only after testing and setting your real App ID.
    // Your supplied live Banner Ad Unit ID. Set your real AdMob App ID in app/build.gradle before live serving.
    private val bannerAdUnitId = "ca-app-pub-1496380656721365/7222808419"
    private val rewardedInterstitialAdUnitId = "ca-app-pub-3940256099942544/5354046379"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(11, 16, 32))
        }

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidAdsBridge(), "AndroidAds")
        }
        root.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        adView = AdView(this).apply {
            adUnitId = bannerAdUnitId
            setAdSize(AdSize.BANNER)
        }
        root.addView(adView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))
        setContentView(root)

        MobileAds.initialize(this) {
            runOnUiThread {
                adView.loadAd(AdRequest.Builder().build())
                loadRewardedInterstitial()
            }
        }

        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun loadRewardedInterstitial() {
        if (isFinishing || isAdLoading || rewardedInterstitialAd != null) return
        isAdLoading = true
        RewardedInterstitialAd.load(
            this,
            rewardedInterstitialAdUnitId,
            AdRequest.Builder().build(),
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    rewardedInterstitialAd = ad
                    isAdLoading = false
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedInterstitialAd = null
                    isAdLoading = false
                }
            }
        )
    }

    private fun showRewardedInterstitial() {
        val ad = rewardedInterstitialAd
        if (ad == null) {
            runOnUiThread {
                webView.evaluateJavascript(
                    "window.onNativeRewardedAdResult && window.onNativeRewardedAdResult(false, 'not_ready');",
                    null
                )
                Toast.makeText(this, "Ad अभी तैयार नहीं है। थोड़ी देर बाद कोशिश करें।", Toast.LENGTH_SHORT).show()
            }
            loadRewardedInterstitial()
            return
        }

        rewardedInterstitialAd = null
        ad.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                loadRewardedInterstitial()
            }

            override fun onAdFailedToShowFullScreenContent(error: com.google.android.gms.ads.AdError) {
                runOnUiThread {
                    webView.evaluateJavascript(
                        "window.onNativeRewardedAdResult && window.onNativeRewardedAdResult(false, 'show_failed');",
                        null
                    )
                }
                loadRewardedInterstitial()
            }
        }
        ad.show(this) {
            runOnUiThread {
                webView.evaluateJavascript(
                    "window.onNativeRewardedAdResult && window.onNativeRewardedAdResult(true, 'earned');",
                    null
                )
            }
        }
    }

    inner class AndroidAdsBridge {
        @JavascriptInterface
        fun showRewardedInterstitial() {
            runOnUiThread { showRewardedInterstitial() }
        }

        @JavascriptInterface
        fun isNativeAdsAvailable(): Boolean = true
    }

    override fun onResume() {
        super.onResume()
        if (::adView.isInitialized) adView.resume()
    }

    override fun onPause() {
        if (::adView.isInitialized) adView.pause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::adView.isInitialized) adView.destroy()
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("AndroidAds")
            webView.destroy()
        }
        super.onDestroy()
    }
}
