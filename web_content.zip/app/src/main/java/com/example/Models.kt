package com.example

import androidx.compose.ui.graphics.Color

// ==========================================
// MODELS: Video, Photo & Dark User
// ==========================================

data class VideoItem(
  val id: Int,
  val title: String,
  val category: String,
  val duration: String,
  val views: String,
  val description: String,
  val videoUri: String,
  val isLocalFile: Boolean = false,
  val accentColor: Color = Color(0xFF3B82F6),
  val isPublished: Boolean = true,
  val isDark: Boolean = false
)

data class PhotoItem(
  val id: Int,
  val title: String,
  val category: String,
  val imageUri: String,
  val isLocalFile: Boolean = false,
  val uploadDate: String = "Today",
  val likes: Int = 18,
  val isPublished: Boolean = true,
  val isDark: Boolean = false
)

data class DarkUserAuth(
  val userId: String,
  val userName: String,
  val facePhotoUri: String,
  val isApproved: Boolean,
  val status: String // "not_applied", "pending", "approved", "rejected"
)

data class DarkUserApplication(
  val userId: String,
  val userName: String,
  val facePhotoUri: String,
  val status: String,
  val appliedAt: String = ""
)

data class NormalUser(
  val userId: String,
  val userName: String,
  val deviceModel: String = "Android Device",
  val joinedAt: String = "Today",
  val lastSeen: String = "Active now",
  val status: String = "active" // "active" or "inactive"
)

data class AppUpdateInfo(
  val hasUpdate: Boolean = false,
  val latestVersionCode: Int = 1,
  val latestVersionName: String = "1.0",
  val apkUrl: String = "",
  val updateTitle: String = "MTX Update Available",
  val updateNotes: String = "",
  val forceUpdate: Boolean = false
)

data class UsersSummary(
  val normalUsers: List<NormalUser> = emptyList(),
  val approvedDarkUsers: List<DarkUserApplication> = emptyList(),
  val pendingDarkUsers: List<DarkUserApplication> = emptyList(),
  val allDarkApplications: List<DarkUserApplication> = emptyList()
)

// Genre categories for Normal Videos
val availableVideoCategories = listOf(
  "Trending",
  "Action",
  "Comedy",
  "Sci-Fi",
  "Drama",
  "Music",
  "Tech & Gaming",
  "Documentaries"
)

val availablePhotoCategories = listOf(
  "Posters & Art",
  "Movie Stills",
  "Wallpapers",
  "Behind The Scenes",
  "Fan Creations"
)

val availableDarkCategories = listOf(
  "Dark Thrillers",
  "Stealth & Action",
  "Cyber Noir",
  "Obsidian VIP",
  "Underground Archives"
)

val DEFAULT_VIDEOS = emptyList<VideoItem>()

val DEFAULT_PHOTOS = emptyList<PhotoItem>()

// Utility function to guarantee any relative server path or upload URL is fully resolved to the active Cloud Run dev URL
fun resolveMediaUri(uri: String): String {
  if (uri.isBlank()) return ""
  // Never rewrite a complete server URL: fallback uploads may have been stored on
  // the pre-production host, and rewriting it to dev makes the media disappear.
  if (uri.startsWith("http://") || uri.startsWith("https://") ||
      uri.startsWith("content://") || uri.startsWith("file://")) {
    return uri
  }
  val cloudBase = MtxCloudSync.CLOUD_DEV_URL
  return if (uri.startsWith("/")) "$cloudBase$uri" else "$cloudBase/uploads/$uri"
}

