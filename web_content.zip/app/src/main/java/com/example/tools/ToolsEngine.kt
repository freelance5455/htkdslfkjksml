package com.example.tools

import java.math.BigInteger
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.expm1
import kotlin.math.ln1p
import kotlin.math.pow

enum class ToolGroup(val title: String) {
  PERCENTAGE("Percentage Tools"),
  FINANCE("Finance"),
  EVERYDAY("Everyday Utilities"),
}

enum class ToolId(
  val title: String,
  val subtitle: String,
  val group: ToolGroup,
) {
  PERCENT_OF("Percentage of Number", "Find X% of Y", ToolGroup.PERCENTAGE),
  PERCENT_INCREASE("Percentage Increase", "Increase or % change up", ToolGroup.PERCENTAGE),
  PERCENT_DECREASE("Percentage Decrease", "Decrease or % change down", ToolGroup.PERCENTAGE),
  PERCENT_DIFFERENCE("Percentage Difference", "Symmetric % diff between two values", ToolGroup.PERCENTAGE),

  SIMPLE_INTEREST("Simple Interest", "Principal, rate & time", ToolGroup.FINANCE),
  COMPOUND_INTEREST("Compound Interest", "Compound growth & yield", ToolGroup.FINANCE),
  EMI_CALCULATOR("EMI Calculator", "Monthly loan payment schedule", ToolGroup.FINANCE),

  DISCOUNT("Discount Calculator", "Savings & reduced price", ToolGroup.EVERYDAY),
  SALE_PRICE("Sale Price Calculator", "Discount + tax checkout price", ToolGroup.EVERYDAY),
  TAX_GST("Tax / GST Calculator", "Exclusive & inclusive tax breakdown", ToolGroup.EVERYDAY),
  TIP("Tip Calculator", "Quick tip & total bill", ToolGroup.EVERYDAY),
  SPLIT_BILL("Split Bill Calculator", "Divide total & tip per person", ToolGroup.EVERYDAY),
  RATIO("Ratio Calculator", "Simplify & scale proportions", ToolGroup.EVERYDAY),
  AVERAGE("Average Calculator", "Mean, median, min, max & sum", ToolGroup.EVERYDAY),
  FRACTION("Fraction Calculator", "Exact arithmetic & mixed numbers", ToolGroup.EVERYDAY),
  TIME_DURATION("Time Duration", "Elapsed hours & minutes", ToolGroup.EVERYDAY),
  DATE_DIFFERENCE("Date Difference", "Days & weeks between dates", ToolGroup.EVERYDAY),
  AGE("Age Calculator", "Exact age & next birthday", ToolGroup.EVERYDAY),
  SPEED_DISTANCE_TIME("Speed · Distance · Time", "Solve for missing motion metric", ToolGroup.EVERYDAY),
  FUEL_COST("Fuel Cost Calculator", "Trip fuel required & cost", ToolGroup.EVERYDAY),
  UNIT_PRICE("Unit Price Comparison", "Compare two pack deals", ToolGroup.EVERYDAY),
}

enum class CompoundingFrequency(val label: String, val periodsPerYear: Int) {
  YEARLY("Yearly (1×)", 1),
  HALF_YEARLY("Half-Yearly (2×)", 2),
  QUARTERLY("Quarterly (4×)", 4),
  MONTHLY("Monthly (12×)", 12),
}

enum class FractionOp(val symbol: String) {
  ADD("+"),
  SUB("−"),
  MUL("×"),
  DIV("÷"),
}

enum class MotionTarget(val label: String) {
  SPEED("Solve Speed"),
  DISTANCE("Solve Distance"),
  TIME("Solve Time"),
}

data class SimpleDate(
  val year: Int,
  val month: Int, // 1..12
  val day: Int,   // 1..31
) : Comparable<SimpleDate> {
  override fun compareTo(other: SimpleDate): Int {
    if (year != other.year) return year.compareTo(other.year)
    if (month != other.month) return month.compareTo(other.month)
    return day.compareTo(other.day)
  }

  fun formatted(): String = "%04d-%02d-%02d".format(year, month, day)

  fun toEpochMillisUtc(): Long {
    val cal = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
    cal.clear()
    cal.set(year, month - 1, day, 0, 0, 0)
    return cal.timeInMillis
  }

  companion object {
    fun today(): SimpleDate {
      val cal = Calendar.getInstance()
      return SimpleDate(
        year = cal.get(Calendar.YEAR),
        month = cal.get(Calendar.MONTH) + 1,
        day = cal.get(Calendar.DAY_OF_MONTH),
      )
    }

    fun fromUtcMillis(millis: Long): SimpleDate {
      val cal = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"))
      cal.timeInMillis = millis
      return SimpleDate(
        year = cal.get(Calendar.YEAR),
        month = cal.get(Calendar.MONTH) + 1,
        day = cal.get(Calendar.DAY_OF_MONTH),
      )
    }
  }
}

data class FractionResult(
  val numerator: Long,
  val denominator: Long,
  val mixedWhole: Long,
  val mixedRemNum: Long,
  val decimal: Double,
)

data class AverageStats(
  val count: Int,
  val sum: Double,
  val mean: Double,
  val median: Double,
  val min: Double,
  val max: Double,
)

data class DateDiffResult(
  val totalDays: Long,
  val weeks: Long,
  val remainingDays: Long,
  val years: Int,
  val months: Int,
  val days: Int,
)

data class AgeResult(
  val years: Int,
  val months: Int,
  val days: Int,
  val totalDays: Long,
  val daysUntilNextBirthday: Long,
)

object ToolsEngine {

  private val BIG_INT_LONG_MIN = BigInteger.valueOf(Long.MIN_VALUE)
  private val BIG_INT_LONG_MAX = BigInteger.valueOf(Long.MAX_VALUE)

  private fun BigInteger.toLongOrNullExact(): Long? {
    if (this < BIG_INT_LONG_MIN || this > BIG_INT_LONG_MAX) return null
    return this.toLong()
  }

  fun percentOf(percent: Double, number: Double): Double = (percent / 100.0) * number

  fun percentChange(from: Double, to: Double): Pair<Double, Double>? {
    if (from == 0.0) return null
    val delta = to - from
    return ((delta / abs(from)) * 100.0) to delta
  }

  fun increaseByPercent(base: Double, percent: Double): Pair<Double, Double> {
    val delta = base * (percent / 100.0)
    return (base + delta) to delta
  }

  fun decreaseByPercent(base: Double, percent: Double): Pair<Double, Double> {
    val delta = base * (percent / 100.0)
    return (base - delta) to delta
  }

  fun percentDifference(a: Double, b: Double): Double {
    val halfA = abs(a) / 2.0
    val halfB = abs(b) / 2.0
    val avg = halfA + halfB
    if (avg == 0.0) return 0.0
    return (abs(a / 2.0 - b / 2.0) / avg) * 200.0
  }

  fun simpleInterest(principal: Double, annualRatePct: Double, years: Double): Pair<Double, Double> {
    val interest = (principal * annualRatePct * years) / 100.0
    return interest to (principal + interest)
  }

  fun compoundInterest(
    principal: Double,
    annualRatePct: Double,
    years: Double,
    frequency: CompoundingFrequency,
  ): Pair<Double, Double> {
    val n = frequency.periodsPerYear.toDouble()
    val r = annualRatePct / 100.0
    val ratePerPeriod = r / n
    val amount =
      if (ratePerPeriod == 0.0) {
        principal
      } else if (ratePerPeriod > -1.0) {
        principal * exp(n * years * ln1p(ratePerPeriod))
      } else {
        principal * (1.0 + ratePerPeriod).pow(n * years)
      }
    return (amount - principal) to amount
  }

  fun calculateEmi(principal: Double, annualRatePct: Double, months: Int): Triple<Double, Double, Double>? {
    if (months <= 0 || !principal.isFinite() || !annualRatePct.isFinite() || principal < 0.0 || annualRatePct < 0.0) return null
    if (annualRatePct == 0.0) {
      val emi = principal / months
      return Triple(emi, 0.0, principal)
    }
    val monthlyRate = annualRatePct / 12.0 / 100.0
    val logGrowth = months.toDouble() * ln1p(monthlyRate)
    val denom = expm1(logGrowth)
    if (denom.isInfinite() || logGrowth > 709.0) {
      val emi = principal * monthlyRate
      val totalPayment = emi * months
      if (!totalPayment.isFinite()) return null
      return Triple(emi, totalPayment - principal, totalPayment)
    }
    if (denom == 0.0) {
      val emi = principal / months
      return Triple(emi, 0.0, principal)
    }
    val factor = 1.0 + denom
    val emi = principal * monthlyRate * factor / denom
    val totalPayment = emi * months
    if (!emi.isFinite() || !totalPayment.isFinite()) return null
    val totalInterest = totalPayment - principal
    return Triple(emi, totalInterest, totalPayment)
  }

  fun discount(originalPrice: Double, discountPct: Double): Pair<Double, Double> {
    val saved = originalPrice * (discountPct / 100.0)
    return saved to (originalPrice - saved)
  }

  fun salePrice(originalPrice: Double, discountPct: Double, taxPct: Double): Triple<Double, Double, Double> {
    val saved = originalPrice * (discountPct / 100.0)
    val discounted = originalPrice - saved
    val tax = discounted * (taxPct / 100.0)
    return Triple(saved, tax, discounted + tax)
  }

  fun taxGst(amount: Double, taxPct: Double, inclusive: Boolean): Triple<Double, Double, Double> {
    return if (inclusive) {
      val divisor = 1.0 + (taxPct / 100.0)
      val base = if (divisor == 0.0) amount else amount / divisor
      val tax = amount - base
      Triple(base, tax, amount)
    } else {
      val tax = amount * (taxPct / 100.0)
      Triple(amount, tax, amount + tax)
    }
  }

  fun tipAndSplit(bill: Double, tipPct: Double, people: Int): Triple<Double, Double, Double>? {
    if (people <= 0) return null
    val tip = bill * (tipPct / 100.0)
    val total = bill + tip
    return Triple(tip, total, total / people)
  }

  fun ratio(a: Long, b: Long, scaleC: Double?): Pair<Pair<Long, Long>, Double?>? {
    if (a == 0L && b == 0L) return null
    val ba = BigInteger.valueOf(a)
    val bb = BigInteger.valueOf(b)
    val g = ba.abs().gcd(bb.abs()).max(BigInteger.ONE)
    var simpA = ba.divide(g)
    var simpB = bb.divide(g)
    if (simpA.signum() < 0 && simpB.signum() < 0) {
      simpA = simpA.negate()
      simpB = simpB.negate()
    }
    val simpALong = simpA.toLongOrNullExact() ?: return null
    val simpBLong = simpB.toLongOrNullExact() ?: return null
    val simplified = simpALong to simpBLong
    val scaledD =
      if (scaleC != null && scaleC.isFinite() && a != 0L) {
        (b.toDouble() * scaleC) / a.toDouble()
      } else {
        null
      }
    return simplified to scaledD
  }

  fun average(numbers: List<Double>): AverageStats? {
    if (numbers.isEmpty() || numbers.any { !it.isFinite() }) return null
    val sorted = numbers.sorted()
    val sum = numbers.sum()
    val mean = sum / numbers.size
    val mid = sorted.size / 2
    val median = if (sorted.size % 2 == 0) sorted[mid - 1] / 2.0 + sorted[mid] / 2.0 else sorted[mid]
    return AverageStats(
      count = numbers.size,
      sum = sum,
      mean = mean,
      median = median,
      min = sorted.first(),
      max = sorted.last(),
    )
  }

  fun fraction(
    n1: Long,
    d1: Long,
    n2: Long,
    d2: Long,
    op: FractionOp,
  ): FractionResult? {
    if (d1 == 0L || d2 == 0L) return null
    val bn1 = java.math.BigInteger.valueOf(n1)
    val bd1 = java.math.BigInteger.valueOf(d1)
    val bn2 = java.math.BigInteger.valueOf(n2)
    val bd2 = java.math.BigInteger.valueOf(d2)

    var rawNum: java.math.BigInteger
    var rawDen: java.math.BigInteger
    when (op) {
      FractionOp.ADD -> {
        rawNum = bn1.multiply(bd2).add(bn2.multiply(bd1))
        rawDen = bd1.multiply(bd2)
      }
      FractionOp.SUB -> {
        rawNum = bn1.multiply(bd2).subtract(bn2.multiply(bd1))
        rawDen = bd1.multiply(bd2)
      }
      FractionOp.MUL -> {
        rawNum = bn1.multiply(bn2)
        rawDen = bd1.multiply(bd2)
      }
      FractionOp.DIV -> {
        if (n2 == 0L) return null
        rawNum = bn1.multiply(bd2)
        rawDen = bd1.multiply(bn2)
      }
    }
    if (rawDen.signum() < 0) {
      rawNum = rawNum.negate()
      rawDen = rawDen.negate()
    }
    val g = rawNum.abs().gcd(rawDen.abs()).max(java.math.BigInteger.ONE)
    val redNum = rawNum.divide(g)
    val redDen = rawDen.divide(g)
    val num = redNum.toLongOrNullExact() ?: return null
    val den = redDen.toLongOrNullExact() ?: return null
    val whole = num / den
    val rem = abs(num % den)
    return FractionResult(
      numerator = num,
      denominator = den,
      mixedWhole = whole,
      mixedRemNum = rem,
      decimal = num.toDouble() / den.toDouble(),
    )
  }

  fun timeDuration(
    startHour: Int,
    startMinute: Int,
    endHour: Int,
    endMinute: Int,
    overnightIfBefore: Boolean = true,
  ): Triple<Int, Int, Int>? {
    if (startHour !in 0..23 || endHour !in 0..23 || startMinute !in 0..59 || endMinute !in 0..59) {
      return null
    }
    val startTotal = startHour * 60 + startMinute
    val endTotal = endHour * 60 + endMinute
    var diff = endTotal - startTotal
    if (diff < 0 && overnightIfBefore) {
      diff += 24 * 60
    } else if (diff < 0) {
      diff = abs(diff)
    }
    return Triple(diff / 60, diff % 60, diff)
  }

  fun dateDifference(start: SimpleDate, end: SimpleDate): DateDiffResult {
    val (from, to) = if (start > end) end to start else start to end
    val totalDays = daysBetween(from, to)
    val (years, months, days) = calendarYmdDiff(from, to)
    return DateDiffResult(
      totalDays = totalDays,
      weeks = totalDays / 7,
      remainingDays = totalDays % 7,
      years = years,
      months = months,
      days = days,
    )
  }

  fun calculateAge(birthDate: SimpleDate, today: SimpleDate = SimpleDate.today()): AgeResult? {
    if (birthDate > today) return null
    val (years, months, days) = calendarYmdDiff(birthDate, today)
    val totalDays = daysBetween(birthDate, today)

    var nextYear = today.year
    var candidate = clampDay(nextYear, birthDate.month, birthDate.day)
    if (candidate <= today) {
      nextYear++
      candidate = clampDay(nextYear, birthDate.month, birthDate.day)
    }
    val daysToBday = daysBetween(today, candidate)
    return AgeResult(
      years = years,
      months = months,
      days = days,
      totalDays = totalDays,
      daysUntilNextBirthday = daysToBday,
    )
  }

  fun solveMotion(target: MotionTarget, first: Double, second: Double): Double? {
    return when (target) {
      MotionTarget.SPEED -> if (second <= 0.0) null else first / second
      MotionTarget.DISTANCE -> if (first < 0.0 || second < 0.0) null else first * second
      MotionTarget.TIME -> if (second <= 0.0) null else first / second
    }
  }

  fun fuelCost(distance: Double, efficiency: Double, pricePerUnit: Double): Pair<Double, Double>? {
    if (efficiency <= 0.0 || distance < 0.0 || pricePerUnit < 0.0) return null
    val fuel = distance / efficiency
    return fuel to (fuel * pricePerUnit)
  }

  fun unitPriceCompare(
    priceA: Double,
    qtyA: Double,
    priceB: Double,
    qtyB: Double,
  ): Triple<Double, Double, Double>? {
    if (qtyA <= 0.0 || qtyB <= 0.0 || priceA < 0.0 || priceB < 0.0) return null
    val unitA = priceA / qtyA
    val unitB = priceB / qtyB
    val higher = maxOf(unitA, unitB)
    val lower = minOf(unitA, unitB)
    val pctSavings = if (higher == 0.0) 0.0 else ((higher - lower) / higher) * 100.0
    return Triple(unitA, unitB, pctSavings)
  }

  private fun daysBetween(from: SimpleDate, to: SimpleDate): Long {
    return daysFromCivil(to.year.toLong(), to.month.toLong(), to.day.toLong()) -
      daysFromCivil(from.year.toLong(), from.month.toLong(), from.day.toLong())
  }

  private fun daysFromCivil(year: Long, month: Long, day: Long): Long {
    val y = if (month <= 2L) year - 1L else year
    val era = if (y >= 0L) y / 400L else (y - 399L) / 400L
    val yoe = y - era * 400L
    val doy = (153L * (month + if (month > 2L) -3L else 9L) + 2L) / 5L + day - 1L
    val doe = yoe * 365L + yoe / 4L - yoe / 100L + doy
    return era * 146097L + doe - 719468L
  }

  private fun calendarYmdDiff(from: SimpleDate, to: SimpleDate): Triple<Int, Int, Int> {
    var totalMonths = (to.year - from.year) * 12 + (to.month - from.month)
    var days = to.day - from.day
    if (totalMonths > 0 && days < 0) {
      totalMonths -= 1
      val stepped = addMonthsClamped(from, totalMonths)
      days = daysBetween(stepped, to).toInt()
    }
    val years = totalMonths / 12
    val months = totalMonths % 12
    return Triple(years, months, days)
  }

  private fun addMonthsClamped(start: SimpleDate, monthsToAdd: Int): SimpleDate {
    val totalMonthZeroBased = (start.year * 12 + (start.month - 1)) + monthsToAdd
    val targetYear = totalMonthZeroBased / 12
    val targetMonth = (totalMonthZeroBased % 12) + 1
    return clampDay(targetYear, targetMonth, start.day)
  }

  private fun clampDay(year: Int, month: Int, day: Int): SimpleDate {
    return SimpleDate(year, month, day.coerceAtMost(daysInMonth(year, month)))
  }

  private fun daysInMonth(year: Int, month: Int): Int {
    return when (month) {
      1, 3, 5, 7, 8, 10, 12 -> 31
      4, 6, 9, 11 -> 30
      2 -> if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) 29 else 28
      else -> 30
    }
  }
}
