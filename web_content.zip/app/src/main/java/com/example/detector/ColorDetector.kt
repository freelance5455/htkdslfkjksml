package com.example.detector

import android.graphics.Color as AndroidColor
import android.graphics.ImageFormat
import androidx.camera.core.ImageProxy
import com.example.model.DetectionRegion
import com.example.model.DetectionState
import com.example.model.TargetTrigger
import java.nio.ByteBuffer

class ColorDetector {

    private val hsvBuffer = FloatArray(3)

    /**
     * Analyzes an ImageProxy frame from CameraX against the list of enabled triggers.
     * Supports both RGBA_8888 and YUV_420_888 formats.
     */
    fun analyzeFrame(
        image: ImageProxy,
        triggers: List<TargetTrigger>,
        region: DetectionRegion,
        sensitivityThresholdPercent: Float
    ): DetectionState {
        val enabledTriggers = triggers.filter { it.isEnabled }
        if (enabledTriggers.isEmpty()) {
            return DetectionState(
                isTriggered = false,
                confidencePercent = 0f,
                sampledColorHex = "#000000"
            )
        }

        val width = image.width
        val height = image.height

        val (startX, endX, startY, endY) = when (region) {
            DetectionRegion.CENTER_RETICLE -> {
                val marginX = (width * 0.25f).toInt()
                val marginY = (height * 0.25f).toInt()
                Quad(marginX, width - marginX, marginY, height - marginY)
            }
            DetectionRegion.FULL_FRAME -> {
                Quad(0, width, 0, height)
            }
        }

        val triggerCounts = mutableMapOf<String, Int>()
        for (t in enabledTriggers) {
            triggerCounts[t.id] = 0
        }

        var totalSampled = 0
        var sumR = 0L
        var sumG = 0L
        var sumB = 0L

        // Step by 4 for high performance and low CPU usage while preserving high precision
        val step = 4

        val format = image.format
        if (format == ImageFormat.YUV_420_888) {
            analyzeYuv(
                image = image,
                startX = startX,
                endX = endX,
                startY = startY,
                endY = endY,
                step = step,
                enabledTriggers = enabledTriggers,
                triggerCounts = triggerCounts,
                onSample = { r, g, b ->
                    totalSampled++
                    sumR += r
                    sumG += g
                    sumB += b
                }
            )
        } else {
            // Default: RGBA_8888
            analyzeRgba(
                image = image,
                startX = startX,
                endX = endX,
                startY = startY,
                endY = endY,
                step = step,
                enabledTriggers = enabledTriggers,
                triggerCounts = triggerCounts,
                onSample = { r, g, b ->
                    totalSampled++
                    sumR += r
                    sumG += g
                    sumB += b
                }
            )
        }

        if (totalSampled == 0) {
            return DetectionState(isTriggered = false)
        }

        // Calculate average sampled color
        val avgR = (sumR / totalSampled).toInt().coerceIn(0, 255)
        val avgG = (sumG / totalSampled).toInt().coerceIn(0, 255)
        val avgB = (sumB / totalSampled).toInt().coerceIn(0, 255)
        val avgColorRgb = AndroidColor.rgb(avgR, avgG, avgB)
        val avgHex = String.format("#%02X%02X%02X", avgR, avgG, avgB)

        // Find the trigger with highest match percentage
        var bestTrigger: TargetTrigger? = null
        var maxConfidence = 0f
        val matchStats = mutableMapOf<String, Float>()

        for (t in enabledTriggers) {
            val count = triggerCounts[t.id] ?: 0
            val percent = (count.toFloat() / totalSampled.toFloat()) * 100f
            matchStats[t.nameEn] = percent
            if (percent > maxConfidence) {
                maxConfidence = percent
                bestTrigger = t
            }
        }

        val isTriggered = maxConfidence >= sensitivityThresholdPercent && bestTrigger != null

        return DetectionState(
            isTriggered = isTriggered,
            activeTrigger = if (isTriggered) bestTrigger else null,
            confidencePercent = maxConfidence,
            matchStats = matchStats,
            sampledColorHex = avgHex,
            sampledColorRgb = avgColorRgb
        )
    }

    private inline fun analyzeRgba(
        image: ImageProxy,
        startX: Int,
        endX: Int,
        startY: Int,
        endY: Int,
        step: Int,
        enabledTriggers: List<TargetTrigger>,
        triggerCounts: MutableMap<String, Int>,
        onSample: (r: Int, g: Int, b: Int) -> Unit
    ) {
        val plane = image.planes[0]
        val buffer: ByteBuffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val bufferLimit = buffer.limit()

        val hsv = FloatArray(3)

        for (y in startY until endY step step) {
            val rowStart = y * rowStride
            for (x in startX until endX step step) {
                val index = rowStart + x * pixelStride
                if (index + 2 < bufferLimit) {
                    val r = buffer.get(index).toInt() and 0xFF
                    val g = buffer.get(index + 1).toInt() and 0xFF
                    val b = buffer.get(index + 2).toInt() and 0xFF

                    onSample(r, g, b)

                    AndroidColor.colorToHSV(AndroidColor.rgb(r, g, b), hsv)

                    for (trigger in enabledTriggers) {
                        if (trigger.matches(hsv)) {
                            triggerCounts[trigger.id] = (triggerCounts[trigger.id] ?: 0) + 1
                        }
                    }
                }
            }
        }
    }

    private inline fun analyzeYuv(
        image: ImageProxy,
        startX: Int,
        endX: Int,
        startY: Int,
        endY: Int,
        step: Int,
        enabledTriggers: List<TargetTrigger>,
        triggerCounts: MutableMap<String, Int>,
        onSample: (r: Int, g: Int, b: Int) -> Unit
    ) {
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val yBuffer = yPlane.buffer
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer

        val yRowStride = yPlane.rowStride
        val yPixelStride = yPlane.pixelStride
        val uRowStride = uPlane.rowStride
        val uPixelStride = uPlane.pixelStride
        val vRowStride = vPlane.rowStride
        val vPixelStride = vPlane.pixelStride

        val hsv = FloatArray(3)

        for (y in startY until endY step step) {
            val yIndexRow = y * yRowStride
            val uvRow = (y / 2) * uRowStride
            for (x in startX until endX step step) {
                val yIndex = yIndexRow + x * yPixelStride
                val uvIndex = uvRow + (x / 2) * uPixelStride

                if (yIndex < yBuffer.limit() && uvIndex < uBuffer.limit() && uvIndex < vBuffer.limit()) {
                    val yVal = (yBuffer.get(yIndex).toInt() and 0xFF) - 16
                    val uVal = (uBuffer.get(uvIndex).toInt() and 0xFF) - 128
                    val vVal = (vBuffer.get(uvIndex).toInt() and 0xFF) - 128

                    // Standard YUV to RGB conversion
                    val r = (1.164f * yVal + 1.596f * vVal).toInt().coerceIn(0, 255)
                    val g = (1.164f * yVal - 0.813f * vVal - 0.391f * uVal).toInt().coerceIn(0, 255)
                    val b = (1.164f * yVal + 2.018f * uVal).toInt().coerceIn(0, 255)

                    onSample(r, g, b)

                    AndroidColor.colorToHSV(AndroidColor.rgb(r, g, b), hsv)

                    for (trigger in enabledTriggers) {
                        if (trigger.matches(hsv)) {
                            triggerCounts[trigger.id] = (triggerCounts[trigger.id] ?: 0) + 1
                        }
                    }
                }
            }
        }
    }

    private data class Quad(val a: Int, val b: Int, val c: Int, val d: Int)
}
