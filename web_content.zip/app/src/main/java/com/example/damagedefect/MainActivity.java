package com.example.damagedefect;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,102,106));
        WebView w = new WebView(this);
        w.setBackgroundColor(Color.rgb(244,248,248));
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        w.loadUrl("file:///android_asset/index.html");
        setContentView(w);
    }
}
