package com.example.schoolplanner;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class NotificationHelper {
    public static final String CHANNEL_ID = "school_schedule_daily";

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "برنامه روز بعد", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("یادآوری برنامه مدرسه روز آینده");
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    public static void showNextDay(Context context) {
        int next = ScheduleReceiver.nextSchoolDayIndex();
        String[] dayNames = {"شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه"};
        String[][] subjects = ScheduleReceiver.SUBJECTS;
        StringBuilder body = new StringBuilder(dayNames[next]).append("\n");
        for (int i = 0; i < subjects[next].length; i++) {
            body.append(i + 1).append(". ").append(subjects[next][i]).append("\n");
        }

        Intent launch = new Intent(context, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(context, 0, launch,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle("📚 برنامه مدرسه روز بعد")
            .setContentText(dayNames[next] + " — " + subjects[next][0] + " و " + (subjects[next].length - 1) + " درس دیگر")
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body.toString()))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pending);

        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(12030, builder.build());
    }
}
