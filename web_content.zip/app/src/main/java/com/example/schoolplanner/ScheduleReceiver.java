package com.example.schoolplanner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.os.Build;
import java.util.Calendar;

public class ScheduleReceiver extends BroadcastReceiver {
    // Order: Saturday, Sunday, Monday, Tuesday, Wednesday, Thursday
    public static final String[][] SUBJECTS = {
        {"قرآن — ۷:۴۵", "ادبیات فارسی — ۹:۲۰", "مطالعات اجتماعی — ۱۰:۵۵", "املا و نگارش — ۱۲:۴۰"},
        {"تربیت بدنی — ۷:۴۵", "هنر — ۹:۲۰", "کار و فناوری — ۱۰:۵۵", "معارف اسلامی — ۱۲:۴۰"},
        {"فیزیک — ۷:۴۵", "زبان انگلیسی — ۹:۲۰", "ریاضی (هندسه) — ۱۰:۵۵", "مطالعات اجتماعی — ۱۲:۴۰"},
        {"آمادگی دفاعی — ۷:۴۵", "ریاضی — ۹:۲۵", "مشاوره / ریاضی — ۱۱:۰۵"},
        {"فارسی — ۷:۴۵", "زمین‌شناسی — ۹:۲۵", "زیست — ۱۱:۰۵"},
        {"ریاضی — ۷:۴۵", "عربی — ۹:۲۵", "شیمی — ۱۱:۰۵"}
    };

    @Override
    public void onReceive(Context context, Intent intent) {
        NotificationHelper.createChannel(context);
        NotificationHelper.showNextDay(context);
        scheduleNext(context);
    }

    // Returns index of the next school day, skipping Friday.
    public static int nextSchoolDayIndex() {
        Calendar c = Calendar.getInstance();
        int dow = c.get(Calendar.DAY_OF_WEEK); // Sun=1 ... Sat=7
        int index;
        if (dow == Calendar.SATURDAY) index = 1;       // Sunday
        else if (dow == Calendar.SUNDAY) index = 2;    // Monday
        else if (dow == Calendar.MONDAY) index = 3;    // Tuesday
        else if (dow == Calendar.TUESDAY) index = 4;   // Wednesday
        else if (dow == Calendar.WEDNESDAY) index = 5;// Thursday
        else index = 0;                                // Thu/Fri -> Saturday
        return index;
    }

    public static void scheduleNext(Context context) {
        Calendar now = Calendar.getInstance();
        Calendar alarm = (Calendar) now.clone();
        alarm.set(Calendar.HOUR_OF_DAY, 12);
        alarm.set(Calendar.MINUTE, 30);
        alarm.set(Calendar.SECOND, 0);
        alarm.set(Calendar.MILLISECOND, 0);
        if (!alarm.after(now)) alarm.add(Calendar.DAY_OF_YEAR, 1);

        Intent intent = new Intent(context, ScheduleReceiver.class);
        PendingIntent pending = PendingIntent.getBroadcast(context, 12030, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarm.getTimeInMillis(), pending);
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, alarm.getTimeInMillis(), pending);
            }
        } else {
            manager.setExact(AlarmManager.RTC_WAKEUP, alarm.getTimeInMillis(), pending);
        }
    }
}
