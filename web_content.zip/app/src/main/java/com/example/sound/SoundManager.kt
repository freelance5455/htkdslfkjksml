package com.example.sound

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

class SoundManager(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default)
    private val sampleRate = 22050

    // Pre-generated PCM audio buffers for instantaneous, zero-latency playback
    private val flapSound: ByteArray by lazy { generateFrequencyRamp(350f, 750f, 0.08f) }
    private val pointSound: ByteArray by lazy { generateTwoTone(880f, 0.05f, 1318f, 0.10f) }
    private val hitSound: ByteArray by lazy { generateNoiseBuzz(0.12f) }
    private val clickSound: ByteArray by lazy { generateFrequencyRamp(600f, 900f, 0.03f) }

    private val vibrator: Vibrator? by lazy {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Exception) {
            null
        }
    }

    var isSoundEnabled: Boolean = true
    var isHapticsEnabled: Boolean = true

    fun playFlap() {
        if (isSoundEnabled) {
            playPcm(flapSound)
        }
        if (isHapticsEnabled) {
            vibrate(30, 80)
        }
    }

    fun playPoint() {
        if (isSoundEnabled) {
            playPcm(pointSound)
        }
        if (isHapticsEnabled) {
            vibrate(50, 180)
        }
    }

    fun playHit() {
        if (isSoundEnabled) {
            playPcm(hitSound)
        }
        if (isHapticsEnabled) {
            vibrate(120, 255)
        }
    }

    fun playClick() {
        if (isSoundEnabled) {
            playPcm(clickSound)
        }
        if (isHapticsEnabled) {
            vibrate(20, 70)
        }
    }

    private fun playPcm(buffer: ByteArray) {
        scope.launch {
            try {
                val audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_GAME)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AudioFormat.ENCODING_PCM_8BIT)
                                .setSampleRate(sampleRate)
                                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(buffer.size)
                        .setTransferMode(AudioTrack.MODE_STATIC)
                        .build()
                } else {
                    @Suppress("DEPRECATION")
                    AudioTrack(
                        android.media.AudioManager.STREAM_MUSIC,
                        sampleRate,
                        AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_8BIT,
                        buffer.size,
                        AudioTrack.MODE_STATIC
                    )
                }

                audioTrack.write(buffer, 0, buffer.size)
                audioTrack.play()

                // Release audioTrack after playback finishes
                val durationMs = (buffer.size * 1000L) / sampleRate + 50L
                kotlinx.coroutines.delay(durationMs)
                audioTrack.stop()
                audioTrack.release()
            } catch (_: Throwable) {
                // Audio failure graceful fallback
            }
        }
    }

    private fun vibrate(durationMs: Long, amplitude: Int = 100) {
        try {
            vibrator?.let { v ->
                if (v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(
                            VibrationEffect.createOneShot(
                                durationMs,
                                amplitude.coerceIn(1, 255)
                            )
                        )
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(durationMs)
                    }
                }
            }
        } catch (_: Exception) {
            // Ignored safely
        }
    }

    private fun generateFrequencyRamp(startFreq: Float, endFreq: Float, durationSec: Float): ByteArray {
        val totalSamples = (durationSec * sampleRate).toInt()
        val buffer = ByteArray(totalSamples)
        var phase = 0.0

        for (i in 0 until totalSamples) {
            val progress = i.toFloat() / totalSamples
            val currentFreq = startFreq + (endFreq - startFreq) * progress
            val envelope = 1.0f - progress // Decay envelope
            phase += 2.0 * PI * currentFreq / sampleRate
            val sample = (sin(phase) * envelope * 120.0).toInt() + 128
            buffer[i] = sample.coerceIn(0, 255).toByte()
        }
        return buffer
    }

    private fun generateTwoTone(freq1: Float, dur1: Float, freq2: Float, dur2: Float): ByteArray {
        val samples1 = (dur1 * sampleRate).toInt()
        val samples2 = (dur2 * sampleRate).toInt()
        val total = samples1 + samples2
        val buffer = ByteArray(total)

        var phase = 0.0
        for (i in 0 until samples1) {
            phase += 2.0 * PI * freq1 / sampleRate
            val sample = (sin(phase) * 110.0).toInt() + 128
            buffer[i] = sample.coerceIn(0, 255).toByte()
        }

        phase = 0.0
        for (i in 0 until samples2) {
            val progress = i.toFloat() / samples2
            val envelope = 1.0f - (progress * 0.7f)
            phase += 2.0 * PI * freq2 / sampleRate
            val sample = (sin(phase) * envelope * 120.0).toInt() + 128
            buffer[samples1 + i] = sample.coerceIn(0, 255).toByte()
        }
        return buffer
    }

    private fun generateNoiseBuzz(durationSec: Float): ByteArray {
        val totalSamples = (durationSec * sampleRate).toInt()
        val buffer = ByteArray(totalSamples)
        var phase = 0.0

        for (i in 0 until totalSamples) {
            val progress = i.toFloat() / totalSamples
            val freq = 200f * (1.0f - progress * 0.7f)
            phase += 2.0 * PI * freq / sampleRate
            // Mix tone with noise
            val tone = sin(phase)
            val noise = (Math.random() * 2.0 - 1.0)
            val sample = ((tone * 0.6 + noise * 0.4) * (1.0 - progress) * 110.0).toInt() + 128
            buffer[i] = sample.coerceIn(0, 255).toByte()
        }
        return buffer
    }
}
