package com.example.sound

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.content.Context
import kotlin.math.sin
import kotlin.random.Random

/**
 * High-performance, offline sound synthesizer for typewriter key clicks and completion chime.
 * Generates tactile audio without requiring asset files.
 */
class TypewriterSoundPlayer(private val context: Context) {

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private var clickTrack: AudioTrack? = null
    private var chimeTrack: AudioTrack? = null

    init {
        try {
            initAudioTracks()
        } catch (_: Exception) {
            // AudioTrack init failure fallback
        }
    }

    private fun initAudioTracks() {
        val sampleRate = 44100
        val clickDurationMs = 12
        val clickSampleCount = (sampleRate * clickDurationMs) / 1000
        val clickSamples = ShortArray(clickSampleCount)

        // Generate mechanical typewriter click (high freq transient + decay)
        for (i in 0 until clickSampleCount) {
            val t = i.toDouble() / sampleRate
            val decay = (1.0 - (i.toDouble() / clickSampleCount)).coerceIn(0.0, 1.0)
            val freq = 2200.0 + Random.nextDouble(-150.0, 150.0)
            val wave = sin(2.0 * Math.PI * freq * t)
            val noise = (Random.nextDouble(-1.0, 1.0) * 0.3)
            val sample = ((wave * 0.7 + noise) * decay * 24000).toInt()
            clickSamples[i] = sample.coerceIn(-32767, 32767).toShort()
        }

        val chimeDurationMs = 70
        val chimeSampleCount = (sampleRate * chimeDurationMs) / 1000
        val chimeSamples = ShortArray(chimeSampleCount)

        // Generate typewriter bell chime for word completion
        for (i in 0 until chimeSampleCount) {
            val t = i.toDouble() / sampleRate
            val decay = (1.0 - (i.toDouble() / chimeSampleCount)).coerceIn(0.0, 1.0)
            val freq = 1760.0 // A6 bell
            val wave = sin(2.0 * Math.PI * freq * t)
            val sample = (wave * decay * 22000).toInt()
            chimeSamples[i] = sample.coerceIn(-32767, 32767).toShort()
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val audioFormat = AudioFormat.Builder()
            .setSampleRate(sampleRate)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        clickTrack = AudioTrack.Builder()
            .setAudioAttributes(audioAttributes)
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(clickSampleCount * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build().apply {
                write(clickSamples, 0, clickSampleCount)
            }

        chimeTrack = AudioTrack.Builder()
            .setAudioAttributes(audioAttributes)
            .setAudioFormat(audioFormat)
            .setBufferSizeInBytes(chimeSampleCount * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build().apply {
                write(chimeSamples, 0, chimeSampleCount)
            }
    }

    /**
     * Plays a crisp typewriter key click and optional subtle haptic tick.
     */
    fun playKeyClick(enableSound: Boolean, enableHaptics: Boolean) {
        if (enableSound) {
            try {
                clickTrack?.let { track ->
                    if (track.state == AudioTrack.STATE_INITIALIZED) {
                        track.stop()
                        track.reloadStaticData()
                        track.play()
                    }
                }
            } catch (_: Exception) {
            }
        }

        if (enableHaptics) {
            triggerHapticClick()
        }
    }

    /**
     * Plays the typewriter carriage return bell / word completion chime.
     */
    fun playWordBell(enableSound: Boolean, enableHaptics: Boolean) {
        if (enableSound) {
            try {
                chimeTrack?.let { track ->
                    if (track.state == AudioTrack.STATE_INITIALIZED) {
                        track.stop()
                        track.reloadStaticData()
                        track.play()
                    }
                }
            } catch (_: Exception) {
            }
        }
        if (enableHaptics) {
            triggerHapticDing()
        }
    }

    private fun triggerHapticClick() {
        try {
            vibrator?.let { v ->
                if (v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(8)
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun triggerHapticDing() {
        try {
            vibrator?.let { v ->
                if (v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        v.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(25)
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    fun release() {
        try {
            clickTrack?.release()
            chimeTrack?.release()
        } catch (_: Exception) {
        }
        clickTrack = null
        chimeTrack = null
    }
}
