package com.example.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import com.example.R
import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.ui.theme.*

@Composable
fun AuthScreen(
    lang: AppLang,
    onToggleLang: () -> Unit,
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        GoogleAuthHelper.attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = onAuthSuccess,
            onUnauthenticated = {},
            scope = scope
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(NavyDeep, NavyElevated, OffWhite)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.img_brand_logo),
                        contentDescription = "Smart Jones Security Logo",
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "SMART JONES SECURITY",
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite
                        )
                        Text(
                            text = "Tanzania Security Marketplace",
                            style = MaterialTheme.typography.bodySmall,
                            color = OrangeBright
                        )
                    }
                }

                Surface(
                    color = NavyMuted,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .clickable(onClick = onToggleLang)
                        .minimumInteractiveComponentSize()
                ) {
                    Text(
                        text = if (lang == AppLang.SW) "SW / EN" else "EN / SW",
                        style = MaterialTheme.typography.labelMedium,
                        color = PureWhite,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }

            Card(
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(210.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.img_hero_banner),
                        contentDescription = "Tanzania Security Perimeter Banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        NavyDeep.copy(alpha = 0.25f),
                                        NavyDeep.copy(alpha = 0.88f)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = OrangeBrand,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = SjsStrings.t(lang, "KAMPUNI ZILIZOTHIBITISHWA", "VERIFIED PROVIDERS"),
                                style = MaterialTheme.typography.labelSmall,
                                color = PureWhite,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Text(
                            text = SjsStrings.t(
                                lang,
                                "Pata Huduma za Ulinzi, CCTV & Uzio wa Umeme Kote Tanzania",
                                "Book Trusted Security Guards, CCTV & Smart Protection Across Tanzania"
                            ),
                            style = MaterialTheme.typography.headlineSmall,
                            color = PureWhite
                        )
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(22.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = SjsStrings.t(lang, "Karibu Smart Jones Security", "Welcome to Smart Jones Security"),
                        style = MaterialTheme.typography.titleLarge,
                        color = NavyDeep
                    )
                    FeatureHighlightRow(
                        icon = Icons.Filled.VerifiedUser,
                        text = SjsStrings.t(
                            lang,
                            "Makampuni ya ulinzi yaliyohakikiwa (BRELA & Leseni ya Usalama)",
                            "Verified security companies with BRELA & PSRA license checks"
                        )
                    )
                    FeatureHighlightRow(
                        icon = Icons.Filled.RequestQuote,
                        text = SjsStrings.t(
                            lang,
                            "Linganisha bei kwa TZS, omba nukuu (quotation) na fuatilia oda live",
                            "Compare TZS pricing, request quotes, and track 10-stage order lifecycle"
                        )
                    )
                    FeatureHighlightRow(
                        icon = Icons.Filled.Payments,
                        text = SjsStrings.t(
                            lang,
                            "Malipo salama kupitia Airtel Money Tanzania (0788016987) na risiti za kidijitali",
                            "Secure Airtel Money Tanzania payments (0788016987) & digital receipts"
                        )
                    )

                    if (errorMessage != null) {
                        Surface(
                            color = ErrorRedContainer,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = ErrorRed,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Button(
                        onClick = {
                            errorMessage = null
                            isLoading = true
                            GoogleAuthHelper.onGoogleSignInClicked(
                                context = context,
                                credentialManager = credentialManager,
                                onAuthSuccess = {
                                    isLoading = false
                                    onAuthSuccess()
                                },
                                onAuthError = { msg ->
                                    isLoading = false
                                    errorMessage = msg
                                },
                                scope = scope,
                                onAuthCancelled = {
                                    isLoading = false
                                }
                            )
                        },
                        enabled = !isLoading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = OrangeBrand,
                            contentColor = PureWhite
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("google_sign_in_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = PureWhite,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(Icons.Filled.Login, contentDescription = null)
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = SjsStrings.t(lang, "Ingia na Google (Sign in with Google)", "Sign in with Google"),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureHighlightRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
            color = OrangeContainer,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = OrangeBrand, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(text = text, style = MaterialTheme.typography.bodyMedium, color = CharcoalGrey)
    }
}
