package com.example.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private const val TAG = "AuthManager"


fun attemptAutoSignIn(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }

    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        Log.e(TAG, "default_web_client_id not found", e)
        onUnauthenticated()
        return
    }

    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(context, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                Firebase.auth.signInWithCredential(authCredential).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (e: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
        onAuthError("Google Sign-In configuration missing: default_web_client_id not found")
        return
    }

    val activity = context as? Activity
    if (activity == null) {
        onAuthError("Invalid context for sign-in")
        return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(signInOption)
        .build()

    scope.launch {
        try {
            val result = credentialManager.getCredential(activity, request)
            val credential = result.credential
            if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                Firebase.auth.signInWithCredential(authCredential).await()
                onAuthSuccess()
            } else {
                onAuthError("Unexpected credential type")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Google Sign-In cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e(TAG, "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "साइन-इन असफल भयो। कृपया पुन: प्रयास गर्नुहोस्।")
        }
    }
}

fun registerWithEmailAndPassword(
    context: Context,
    name: String,
    email: String,
    password: String,
    phone: String = "",
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope
) {
    scope.launch {
        try {
            val authResult = Firebase.auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val user = authResult.user
            if (user != null) {
                // Update Firebase Auth profile displayName
                try {
                    val profileUpdate = UserProfileChangeRequest.Builder()
                        .setDisplayName(name.trim())
                        .build()
                    user.updateProfile(profileUpdate).await()
                } catch (pe: Exception) {
                    Log.w(TAG, "Profile displayName update failed", pe)
                }

                // Persist user record to Firestore users collection
                try {
                    val dbId = context.applicationContext.getString(R.string.firestore_database_id)
                    val db = FirebaseFirestore.getInstance(dbId)
                    val userDoc = mapOf(
                        "uid" to user.uid,
                        "name" to name.trim(),
                        "email" to email.trim(),
                        "phone" to phone.trim(),
                        "role" to "customer",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                    db.collection("users").document(user.uid).set(userDoc).await()
                } catch (fe: Exception) {
                    Log.w(TAG, "Firestore user document creation note", fe)
                }

                onAuthSuccess()
            } else {
                onAuthError("नयाँ खाता दर्ता हुन सकेन। कृपया फेरि प्रयास गर्नुहोस्।")
            }
        } catch (e: FirebaseAuthWeakPasswordException) {
            onAuthError("पासवर्ड कमजोर छ। कम्तीमा ६ अक्षरको पासवर्ड राख्नुहोस्।")
        } catch (e: FirebaseAuthUserCollisionException) {
            onAuthError("यो इमेल पहिले नै दर्ता भइसकेको छ। कृपया लगइन गर्नुहोस्।")
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            onAuthError("इमेल ढाँचा अमान्य छ। कृपया सही इमेल लेख्नुहोस्।")
        } catch (e: Exception) {
            Log.e(TAG, "Registration failed", e)
            val msg = e.localizedMessage ?: "दर्ता असफल भयो"
            if (msg.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ||
                msg.contains("operation is not allowed", ignoreCase = true) ||
                msg.contains("ADMIN_ONLY_OPERATION", ignoreCase = true)
            ) {
                onAuthError("Firebase Console मा Email/Password प्रदायक सक्रिय गरिएको छैन। कृपया Google बाट तुरुन्त लगइन गर्नुहोस् वा Firebase Console > Authentication मा Email/Password सक्षम गर्नुहोस्।")
            } else {
                onAuthError(msg)
            }
        }
    }
}

fun signInWithEmailAndPassword(
    context: Context,
    email: String,
    password: String,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope
) {
    scope.launch {
        try {
            val authResult = Firebase.auth.signInWithEmailAndPassword(email.trim(), password).await()
            if (authResult.user != null) {
                onAuthSuccess()
            } else {
                onAuthError("लगइन असफल भयो।")
            }
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            onAuthError("इमेल वा पासवर्ड मिलेन। कृपया पुन: जाँच गर्नुहोस्।")
        } catch (e: FirebaseAuthInvalidUserException) {
            onAuthError("यो इमेलबाट कुनै खाता भेटिएन। कृपया पहिले नयाँ खाता दर्ता गर्नुहोस्।")
        } catch (e: Exception) {
            Log.e(TAG, "Email Sign-in failed", e)
            val msg = e.localizedMessage ?: "लगइन असफल भयो"
            if (msg.contains("CONFIGURATION_NOT_FOUND", ignoreCase = true) ||
                msg.contains("operation is not allowed", ignoreCase = true)
            ) {
                onAuthError("Firebase Console मा Email/Password प्रदायक सक्रिय गरिएको छैन। कृपया Google बाट लगइन गर्नुहोस्।")
            } else {
                onAuthError(msg)
            }
        }
    }
}

fun signOut(

    context: Context,
    credentialManager: CredentialManager,
    onSignOutComplete: () -> Unit,
    scope: CoroutineScope
) {
    Firebase.auth.signOut()
    scope.launch {
        try {
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            Log.e(TAG, "Failed to clear credential state", e)
        } finally {
            onSignOutComplete()
        }
    }
}
