package com.example.bridge

import android.webkit.JavascriptInterface
import com.example.MainActivity
import org.json.JSONObject

/**
 * Android WebView ve HTML/JS arasındaki güvenli köprü (SuesaBridge).
 * JavaScript tarafından çağrılabilir fonksiyonları ve komut yönlendirmesini yönetir.
 */
class SuesaBridge(private val activity: MainActivity) {

    @JavascriptInterface
    fun sendCommand(command: String): String {
        return activity.handleBridgeCommand(command)
    }

    @JavascriptInterface
    fun sendMessage(text: String, imageBase64: String?) {
        activity.runOnUiThread {
            activity.processUserMessage(text, imageBase64)
        }
    }

    @JavascriptInterface
    fun startVoice() {
        activity.runOnUiThread {
            activity.startVoiceRecognition()
        }
    }

    @JavascriptInterface
    fun stopVoice() {
        activity.runOnUiThread {
            activity.stopVoiceRecognition()
        }
    }

    @JavascriptInterface
    fun speakText(text: String) {
        activity.runOnUiThread {
            activity.speakText(text)
        }
    }

    @JavascriptInterface
    fun stopSpeaking() {
        activity.runOnUiThread {
            activity.stopSpeaking()
        }
    }

    @JavascriptInterface
    fun openCamera() {
        activity.runOnUiThread {
            activity.launchCameraCapture()
        }
    }

    @JavascriptInterface
    fun selectFile() {
        activity.runOnUiThread {
            activity.launchPhotoPicker()
        }
    }

    @JavascriptInterface
    fun openSettings() {
        activity.runOnUiThread {
            activity.showSettingsInApp()
        }
    }

    @JavascriptInterface
    fun getPreferences(): String {
        return activity.getPreferencesJson()
    }

    @JavascriptInterface
    fun savePreferences(prefsJson: String): Boolean {
        return activity.savePreferencesJson(prefsJson)
    }

    @JavascriptInterface
    fun getSessions(): String {
        return activity.getSessionsJson()
    }

    @JavascriptInterface
    fun loadSession(sessionId: Long): String {
        return activity.loadSessionJson(sessionId)
    }

    @JavascriptInterface
    fun createNewSession(): String {
        return activity.createNewSessionJson()
    }

    @JavascriptInterface
    fun deleteSession(sessionId: Long): Boolean {
        return activity.deleteSessionById(sessionId)
    }

    @JavascriptInterface
    fun clearAllHistory(): Boolean {
        return activity.clearAllChatHistory()
    }

    @JavascriptInterface
    fun checkPermissions(): String {
        return activity.getPermissionsJson()
    }

    @JavascriptInterface
    fun requestPermission(permissionKey: String) {
        activity.runOnUiThread {
            activity.requestNamedPermission(permissionKey)
        }
    }

    @JavascriptInterface
    fun testApiKey(apiKey: String) {
        activity.testApiKey(apiKey)
    }
}
