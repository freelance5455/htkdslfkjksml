package com.example.bridge

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.core.content.ContextCompat
import com.example.ui.IchimatsuViewModel
import org.json.JSONObject
import java.util.Locale

private const val TAG = "IchimatsuBridge"

class IchimatsuWebBridge(
    private val context: Context,
    private val viewModel: IchimatsuViewModel,
    private val evalJs: (String) -> Unit,
    private val requestMicPermission: ((Boolean) -> Unit) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    init {
        initTts()
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    ttsReady = true
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {
                            if (utteranceId != null) {
                                evalJs("window.__androidTtsDone && window.__androidTtsDone(${JSONObject.quote(utteranceId)}, true);")
                            }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            if (utteranceId != null) {
                                evalJs("window.__androidTtsDone && window.__androidTtsDone(${JSONObject.quote(utteranceId)}, false);")
                            }
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            if (utteranceId != null) {
                                evalJs("window.__androidTtsDone && window.__androidTtsDone(${JSONObject.quote(utteranceId)}, false);")
                            }
                        }
                    })
                } else {
                    Log.w(TAG, "TextToSpeech initialization returned status=$status")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Unable to initialize TextToSpeech", e)
        }
    }

    @JavascriptInterface
    fun generateResponse(reqId: String, messagesJson: String, imageBase64: String?) {
        val qId = JSONObject.quote(reqId)
        viewModel.generateForBridge(
            reqId = reqId,
            messagesJson = messagesJson,
            imageBase64 = imageBase64,
            onChunk = { accumulated ->
                evalJs("window.__androidAiChunk && window.__androidAiChunk($qId, ${JSONObject.quote(accumulated)});")
            },
            onSuccess = { fullText ->
                evalJs("window.__androidAiResolve && window.__androidAiResolve($qId, ${JSONObject.quote(fullText)});")
            },
            onError = { errorMsg ->
                evalJs("window.__androidAiReject && window.__androidAiReject($qId, ${JSONObject.quote(errorMsg)});")
            }
        )
    }

    @JavascriptInterface
    fun speakText(uttId: String, text: String, lang: String, pitch: Float, rate: Float) {
        mainHandler.post {
            val engine = tts
            if (engine == null || !ttsReady) {
                evalJs("window.__androidTtsDone && window.__androidTtsDone(${JSONObject.quote(uttId)}, false);")
                return@post
            }
            val locale = if (lang.lowercase().startsWith("ja")) Locale.JAPAN else Locale.US
            val availability = engine.isLanguageAvailable(locale)
            if (availability >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = locale
            } else {
                engine.language = Locale.US
            }
            engine.setPitch(pitch.coerceIn(0.75f, 1.55f))
            engine.setSpeechRate(rate.coerceIn(0.75f, 1.4f))
            val params = Bundle()
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, uttId)
        }
    }

    @JavascriptInterface
    fun stopSpeaking() {
        mainHandler.post {
            try {
                tts?.stop()
            } catch (_: Exception) {}
        }
    }

    @JavascriptInterface
    fun startListening(lang: String) {
        mainHandler.post {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

            if (!granted) {
                requestMicPermission { ok ->
                    if (ok) {
                        startListeningInternal(lang)
                    } else {
                        evalJs("window.__androidSrError && window.__androidSrError('not-allowed');")
                        evalJs("window.__androidSrEnd && window.__androidSrEnd();")
                    }
                }
                return@post
            }
            startListeningInternal(lang)
        }
    }

    private fun startListeningInternal(lang: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            evalJs("window.__androidSrError && window.__androidSrError('service-not-allowed');")
            evalJs("window.__androidSrEnd && window.__androidSrEnd();")
            return
        }
        try {
            speechRecognizer?.destroy()
            val sr = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    val code = when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                        SpeechRecognizer.ERROR_NO_MATCH,
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                        else -> "aborted"
                    }
                    evalJs("window.__androidSrError && window.__androidSrError(${JSONObject.quote(code)});")
                    evalJs("window.__androidSrEnd && window.__androidSrEnd();")
                }

                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val best = list?.firstOrNull().orEmpty()
                    if (best.isNotBlank()) {
                        evalJs("window.__androidSrResult && window.__androidSrResult(${JSONObject.quote(best)}, true);")
                    }
                    evalJs("window.__androidSrEnd && window.__androidSrEnd();")
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partial = list?.firstOrNull().orEmpty()
                    if (partial.isNotBlank()) {
                        evalJs("window.__androidSrResult && window.__androidSrResult(${JSONObject.quote(partial)}, false);")
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.ifBlank { Locale.getDefault().toLanguageTag() })
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            sr.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "SpeechRecognizer failed to start", e)
            evalJs("window.__androidSrError && window.__androidSrError('aborted');")
            evalJs("window.__androidSrEnd && window.__androidSrEnd();")
        }
    }

    @JavascriptInterface
    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
            } catch (_: Exception) {}
        }
    }

    @JavascriptInterface
    fun onStageUpdate(currentMove: String, learnedJson: String) {
        viewModel.updateStageFromWeb(currentMove, learnedJson)
    }

    @JavascriptInterface
    fun onModelLoaded() {
        viewModel.onWebModelLoaded()
    }

    @JavascriptInterface
    fun onDressChanged(dressColor: String) {
        viewModel.onDressChangedFromWeb(dressColor)
    }

    @JavascriptInterface
    fun onJpModeChanged(jpMode: Boolean) {
        viewModel.onJpModeChangedFromWeb(jpMode)
    }

    @JavascriptInterface
    fun onMoveLearned(moveName: String, stepsJson: String) {
        viewModel.onMoveLearnedFromWeb(moveName, stepsJson)
    }

    fun release() {
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (_: Exception) {}
            try {
                tts?.stop()
                tts?.shutdown()
                tts = null
                ttsReady = false
            } catch (_: Exception) {}
        }
    }
}
