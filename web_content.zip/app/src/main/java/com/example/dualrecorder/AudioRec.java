package com.example.dualrecorder;

import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Log;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class AudioRec {

    private static final String TAG = "AudioRec";

    public interface Stopper { void stop(); }

    public static String ext(String f) {
        switch (f) {
            case "aac": return "aac";
            case "3gp":
            case "amrwb": return "3gp";
            case "wav": return "wav";
            default: return "m4a";
        }
    }

    public static Stopper start(int src, String format, File out) throws Exception {
        if ("wav".equals(format)) return startWav(src, out);

        final MediaRecorder r = new MediaRecorder();
        try {
            r.setAudioSource(src);
            switch (format) {
                case "aac":
                    r.setOutputFormat(MediaRecorder.OutputFormat.AAC_ADTS);
                    r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    r.setAudioSamplingRate(44100);
                    r.setAudioEncodingBitRate(128000);
                    break;
                case "3gp":
                    r.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                    r.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                    break;
                case "amrwb":
                    r.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                    r.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_WB);
                    break;
                default:
                    r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                    r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    r.setAudioSamplingRate(44100);
                    r.setAudioEncodingBitRate(128000);
            }
            r.setOutputFile(out.getAbsolutePath());
            r.prepare();
            r.start();
        } catch (Exception e) {
            try { r.release(); } catch (Exception ignored) { }
            throw e;
        }
        return () -> {
            try { r.stop(); } catch (Exception e) { Log.w(TAG, "stop: " + e); }
            try { r.release(); } catch (Exception ignored) { }
        };
    }

    private static Stopper startWav(int src, File out) throws Exception {
        final int sr = 16000;
        int min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) throw new IllegalStateException("bad buffer size");
        final int bufSize = min * 2;
        final AudioRecord ar = new AudioRecord(src, sr, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, bufSize);
        if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
            ar.release();
            throw new IllegalStateException("AudioRecord not initialized");
        }
        final RandomAccessFile f = new RandomAccessFile(out, "rw");
        f.setLength(0);
        f.write(new byte[44]);
        try {
            ar.startRecording();
            if (ar.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                throw new IllegalStateException("AudioRecord not recording");
            }
        } catch (Exception e) {
            try { ar.release(); } catch (Exception ignored) { }
            try { f.close(); } catch (Exception ignored) { }
            throw e;
        }

        final boolean[] run = {true};
        final long[] total = {0};
        final Thread t = new Thread(() -> {
            byte[] buf = new byte[bufSize];
            while (run[0]) {
                int n = ar.read(buf, 0, buf.length);
                if (n > 0) {
                    try { f.write(buf, 0, n); total[0] += n; } catch (Exception e) { break; }
                } else if (n < 0) {
                    break;
                }
            }
        });
        t.start();

        return () -> {
            run[0] = false;
            try { t.join(1500); } catch (InterruptedException ignored) { }
            try { ar.stop(); } catch (Exception ignored) { }
            ar.release();
            try {
                ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
                h.put("RIFF".getBytes()).putInt((int) (36 + total[0])).put("WAVE".getBytes());
                h.put("fmt ".getBytes()).putInt(16).putShort((short) 1).putShort((short) 1);
                h.putInt(sr).putInt(sr * 2).putShort((short) 2).putShort((short) 16);
                h.put("data".getBytes()).putInt((int) total[0]);
                f.seek(0);
                f.write(h.array());
                f.close();
            } catch (Exception e) {
                Log.w(TAG, "wav header: " + e);
            }
        };
    }
}
