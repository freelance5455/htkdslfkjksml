package com.example.dualrecorder;

public class Prefs {
    public static final String FILE = "prefs";
    public static final String FORMAT = "format";
    public static final String SPEAKER = "speaker";
    public static final String BOOT = "boot";
    public static final String ENABLED = "enabled";
}
