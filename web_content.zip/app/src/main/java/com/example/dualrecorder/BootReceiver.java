package com.example.dualrecorder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        boolean enabled = context.getSharedPreferences(Prefs.FILE, Context.MODE_PRIVATE)
                .getBoolean(Prefs.ENABLED, false)
                && context.getSharedPreferences(Prefs.FILE, Context.MODE_PRIVATE)
                .getBoolean(Prefs.BOOT, true);
        if (!enabled) return;
        Intent i = new Intent(context, CallRecorderService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(i);
        } else {
            context.startService(i);
        }
    }
}
