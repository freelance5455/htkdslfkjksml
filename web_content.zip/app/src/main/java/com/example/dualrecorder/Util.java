package com.example.dualrecorder;

import android.content.Context;
import android.net.Uri;
import android.os.Environment;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.security.MessageDigest;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class Util {

    // ایران ساعت تابستانی ندارد؛ ساعت ثابت +03:30
    public static final TimeZone IRAN_TZ = TimeZone.getTimeZone("GMT+03:30");

    /** پوشه ذخیره: حافظه داخلی > CallRecordings */
    public static File outputDir(Context c) {
        File dir = new File(Environment.getExternalStorageDirectory(), "CallRecordings");
        if (!dir.exists() && !dir.mkdirs()) {
            File alt = c.getExternalFilesDir("calls");
            if (alt != null) {
                if (!alt.exists()) alt.mkdirs();
                return alt;
            }
        }
        return dir;
    }

    public static File subDir(Context c, String name) {
        File d = new File(outputDir(c), name);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static Uri uriFor(Context c, File f) {
        return FileProvider.getUriForFile(c, c.getPackageName() + ".fileprovider", f);
    }

    public static String mimeFor(String n) {
        n = n.toLowerCase(Locale.US);
        if (n.endsWith(".m4a")) return "audio/mp4";
        if (n.endsWith(".aac")) return "audio/aac";
        if (n.endsWith(".3gp")) return "audio/3gpp";
        if (n.endsWith(".wav")) return "audio/x-wav";
        if (n.endsWith(".mp3")) return "audio/mpeg";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".json")) return "application/json";
        return "*/*";
    }

    public static String sha256(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    /** مثل 1405-08-14_11-08-23 (تاریخ شمسی و ساعت تهران) */
    public static String jalaliStamp(long ms) {
        Calendar cal = Calendar.getInstance(IRAN_TZ);
        cal.setTimeInMillis(ms);
        int[] j = toJalali(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH));
        return String.format(Locale.US, "%04d-%02d-%02d_%02d-%02d-%02d",
                j[0], j[1], j[2], cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
    }

    /** تبدیل میلادی به شمسی؛ خروجی: {سال, ماه, روز} */
    public static int[] toJalali(int gy, int gm, int gd) {
        int[] gdm = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334};
        int gy2 = (gm > 2) ? (gy + 1) : gy;
        int days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100)
                + ((gy2 + 399) / 400) + gd + gdm[gm - 1];
        int jy = -1595 + (33 * (days / 12053));
        days %= 12053;
        jy += 4 * (days / 1461);
        days %= 1461;
        if (days > 365) {
            jy += (days - 1) / 365;
            days = (days - 1) % 365;
        }
        int jm, jd;
        if (days < 186) {
            jm = 1 + (days / 31);
            jd = 1 + (days % 31);
        } else {
            jm = 7 + ((days - 186) / 30);
            jd = 1 + ((days - 186) % 30);
        }
        return new int[]{jy, jm, jd};
    }
}
