package com.example.dualrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import java.io.File;

/** ضبط صدای اطراف با یک دکمه؛ در پس‌زمینه و با صفحه خاموش هم ادامه دارد. */
public class AmbientRecorderService extends Service {

    private static final String TAG = "Ambient";
    private static final String CHANNEL_ID = "ambient_recorder";

    public static volatile boolean running = false;
    public static volatile long startMs = 0;
    public static volatile AmbientRecorderService instance;

    private AudioRec.Stopper rec;
    private File file;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(2, buildNotification());
        instance = this;
        if (!running) begin();
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, "Ambient recorder", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, EvidenceActivity.class), 0);
        return b.setContentTitle("YA Work Evidence")
                .setContentText("Recording ambient sound - tap to stop")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi)
                .build();
    }

    private void begin() {
        SharedPreferences prefs = getSharedPreferences(Prefs.FILE, MODE_PRIVATE);
        String format = prefs.getString(Prefs.FORMAT, "m4a");
        long now = System.currentTimeMillis();
        File dir = Util.subDir(this, "Ambient");
        File out = new File(dir, "AMBIENT_" + Util.jalaliStamp(now) + "." + AudioRec.ext(format));
        int[] sources = {MediaRecorder.AudioSource.MIC, MediaRecorder.AudioSource.VOICE_RECOGNITION};
        for (int src : sources) {
            try {
                rec = AudioRec.start(src, format, out);
                file = out;
                startMs = now;
                running = true;
                return;
            } catch (Exception e) {
                Log.w(TAG, "source " + src + " failed: " + e);
                try { out.delete(); } catch (Exception ignored) { }
            }
        }
        running = false;
        stopForeground(true);
        stopSelf();
    }

    /** ضبط را تمام می‌کند و فایل را برمی‌گرداند. */
    public synchronized File finish() {
        if (rec != null) {
            try { rec.stop(); } catch (Exception e) { Log.w(TAG, "stop: " + e); }
            rec = null;
        }
        running = false;
        File f = file;
        stopForeground(true);
        stopSelf();
        return f;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        if (rec != null) {
            try { rec.stop(); } catch (Exception ignored) { }
            rec = null;
        }
        running = false;
        instance = null;
        super.onDestroy();
    }
}
