package com.example.dualrecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class CallRecorderService extends Service {

    private static final String TAG = "CallRecorder";
    private static final String CHANNEL_ID = "call_recorder";

    // ایران از سال ۱۴۰۱ ساعت تابستانی ندارد؛ اندروید ۸ قوانین قدیمی منطقه‌ای را دارد،
    // پس ساعت ثابت +03:30 استفاده می‌شود تا زمان ثبت‌شده همیشه دقیق باشد.
    private static final TimeZone IRAN_TZ = TimeZone.getTimeZone("GMT+03:30");

    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneListener;
    private BroadcastReceiver outgoingReceiver;
    private AudioManager audioManager;
    private SharedPreferences prefs;

    private AudioRec.Stopper current;
    private boolean speakerForced = false;
    private boolean prevSpeaker;
    private int prevVolume;

    // اطلاعات تماس جاری
    private int lastState = TelephonyManager.CALL_STATE_IDLE;
    private boolean incoming = false;
    private String number = "";
    private String pendingOutgoing = "";
    private long startMs;
    private File curFile;
    private boolean curDirect;

    @Override
    public void onCreate() {
        super.onCreate();
        telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        prefs = getSharedPreferences(Prefs.FILE, MODE_PRIVATE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(1, buildNotification());

        if (outgoingReceiver == null) {
            outgoingReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    String n = i.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
                    pendingOutgoing = n == null ? "" : n;
                }
            };
            try {
                registerReceiver(outgoingReceiver, new IntentFilter(Intent.ACTION_NEW_OUTGOING_CALL));
            } catch (Exception e) {
                Log.w(TAG, "outgoing receiver: " + e);
            }
        }

        if (phoneListener == null) {
            phoneListener = new PhoneStateListener() {
                @Override
                public void onCallStateChanged(int state, String incomingNumber) {
                    if (state == TelephonyManager.CALL_STATE_RINGING) {
                        incoming = true;
                        number = incomingNumber == null ? "" : incomingNumber;
                    } else if (state == TelephonyManager.CALL_STATE_OFFHOOK) {
                        if (lastState != TelephonyManager.CALL_STATE_RINGING) {
                            incoming = false;
                            number = pendingOutgoing;
                        }
                        startRecording();
                    } else if (state == TelephonyManager.CALL_STATE_IDLE) {
                        stopRecording();
                        pendingOutgoing = "";
                    }
                    lastState = state;
                }
            };
            telephonyManager.listen(phoneListener, PhoneStateListener.LISTEN_CALL_STATE);
        }
        return START_STICKY;
    }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, "Call recorder", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL_ID);
        } else {
            b = new Notification.Builder(this);
        }
        return b.setContentTitle("Dual Call Recorder")
                .setContentText("Auto call recording is active")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build();
    }

    // ---------- شروع ضبط ----------
    private void startRecording() {
        if (current != null) return;
        String format = prefs.getString(Prefs.FORMAT, "m4a");
        boolean speakerFallback = prefs.getBoolean(Prefs.SPEAKER, true);
        startMs = System.currentTimeMillis();

        Calendar cal = Calendar.getInstance(IRAN_TZ);
        cal.setTimeInMillis(startMs);
        int[] j = Util.toJalali(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH));
        String stamp = String.format(Locale.US, "%04d-%02d-%02d_%02d-%02d-%02d",
                j[0], j[1], j[2], cal.get(Calendar.HOUR_OF_DAY),
                cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
        String digits = number.replaceAll("[^0-9+]", "");
        String base = "CALL_" + stamp + (incoming ? "_in" : "_out")
                + (digits.isEmpty() ? "" : "_" + digits);

        File dir = Util.outputDir(this);

        int[] sources = {
                MediaRecorder.AudioSource.VOICE_CALL,          // دوطرفه مستقیم
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MediaRecorder.AudioSource.MIC
        };

        for (int src : sources) {
            boolean direct = (src == MediaRecorder.AudioSource.VOICE_CALL);
            File out = new File(dir, base + (direct ? "_2way." : "_mic.") + AudioRec.ext(format));
            try {
                current = AudioRec.start(src, format, out);
                curFile = out;
                curDirect = direct;
                Log.d(TAG, "Recording source=" + src + " file=" + out);
                if (!direct && speakerFallback) forceSpeaker();
                return;
            } catch (Exception e) {
                Log.w(TAG, "Source " + src + " failed: " + e);
                try { out.delete(); } catch (Exception ignored) { }
            }
        }
        Log.e(TAG, "All audio sources failed");
    }

    // ---------- بلندگو برای حالت میکروفونی ----------
    private void forceSpeaker() {
        try {
            prevSpeaker = audioManager.isSpeakerphoneOn();
            prevVolume = audioManager.getStreamVolume(AudioManager.STREAM_VOICE_CALL);
            audioManager.setSpeakerphoneOn(true);
            audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL,
                    audioManager.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0);
            speakerForced = true;
        } catch (Exception e) {
            Log.w(TAG, "speaker: " + e);
        }
    }

    private void restoreSpeaker() {
        if (!speakerForced) return;
        try {
            audioManager.setSpeakerphoneOn(prevSpeaker);
            audioManager.setStreamVolume(AudioManager.STREAM_VOICE_CALL, prevVolume, 0);
        } catch (Exception e) {
            Log.w(TAG, "restore speaker: " + e);
        }
        speakerForced = false;
    }

    // ---------- پایان ضبط و ثبت در لاگ ----------
    private void stopRecording() {
        if (current == null) {
            restoreSpeaker();
            return;
        }
        try { current.stop(); } catch (Exception e) { Log.w(TAG, "stop: " + e); }
        current = null;
        restoreSpeaker();

        final File f = curFile;
        final boolean direct = curDirect;
        final boolean inc = incoming;
        final String num = number;
        final long st = startMs;
        final long en = System.currentTimeMillis();
        new Thread(() -> writeLog(f, direct, inc, num, st, en)).start();
    }

    private void writeLog(File f, boolean direct, boolean inc, String num, long st, long en) {
        try {
            Calendar cal = Calendar.getInstance(IRAN_TZ);
            cal.setTimeInMillis(st);
            int[] j = Util.toJalali(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
                    cal.get(Calendar.DAY_OF_MONTH));
            String jDate = String.format(Locale.US, "%04d/%02d/%02d", j[0], j[1], j[2]);
            String jTime = String.format(Locale.US, "%02d:%02d:%02d", cal.get(Calendar.HOUR_OF_DAY),
                    cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND));
            SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            iso.setTimeZone(IRAN_TZ);
            String isoStr = iso.format(new Date(st)) + "+03:30";

            String name = lookupName(num);
            long dur = Math.max(0, (en - st) / 1000);
            String hash = sha256(f);

            File log = new File(f.getParentFile(), "log.csv");
            boolean fresh = !log.exists();
            try (OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(log, true), "UTF-8")) {
                if (fresh) {
                    w.write("\uFEFF");
                    w.write("تاریخ شمسی,ساعت (تهران),تاریخ میلادی,جهت,شماره,نام مخاطب,فایل,نوع ضبط,مدت (ثانیه),SHA-256\n");
                }
                w.write(jDate + "," + jTime + "," + isoStr + "," + (inc ? "ورودی" : "خروجی") + ","
                        + csv(num) + "," + csv(name) + "," + csv(f.getName()) + ","
                        + (direct ? "دوطرفه مستقیم" : "میکروفون/بلندگو") + "," + dur + "," + hash + "\n");
            }
        } catch (Exception e) {
            Log.w(TAG, "log: " + e);
        }
    }

    private String csv(String s) {
        if (s == null) s = "";
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private String lookupName(String num) {
        if (num == null || num.isEmpty()) return "";
        try {
            Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num));
            try (Cursor c = getContentResolver().query(uri,
                    new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) return c.getString(0);
            }
        } catch (Exception e) {
            Log.w(TAG, "contact lookup: " + e);
        }
        return "";
    }

    private String sha256(File f) {
        try (FileInputStream in = new FileInputStream(f)) {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        if (phoneListener != null) {
            telephonyManager.listen(phoneListener, PhoneStateListener.LISTEN_NONE);
            phoneListener = null;
        }
        if (outgoingReceiver != null) {
            try { unregisterReceiver(outgoingReceiver); } catch (Exception ignored) { }
            outgoingReceiver = null;
        }
        stopRecording();
        super.onDestroy();
    }
}
