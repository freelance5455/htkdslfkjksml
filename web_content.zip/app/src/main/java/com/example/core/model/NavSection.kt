package com.example.core.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Exactly six primary navigation sections required for IQTrade Pro.
 */
enum class NavSection(
    val title: String,
    val icon: ImageVector,
    val testTag: String
) {
    TERMINAL("Terminal", Icons.AutoMirrored.Filled.TrendingUp, "nav_terminal"),
    ANALYSIS("Analysis", Icons.Default.Analytics, "nav_analysis"),
    PORTFOLIO("Portfolio", Icons.Default.AccountBalanceWallet, "nav_portfolio"),
    AUTO_TRADE("Trading Modes", Icons.Default.SmartToy, "nav_auto_trade"),
    MORE("More", Icons.Default.MoreHoriz, "nav_more"),
    BINANCE("Binance", Icons.Default.CurrencyBitcoin, "nav_binance")
}
