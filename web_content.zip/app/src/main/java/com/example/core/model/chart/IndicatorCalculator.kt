package com.example.core.model.chart

import com.example.core.indicator.engine.ComprehensiveIndicatorEngine
import com.example.core.model.indicator.IndicatorParameters
import com.example.core.model.indicator.IndicatorSource
import kotlin.math.sqrt

/**
 * Isolated Technical Indicator Calculation Engine.
 * Adheres strictly to:
 * - Separate calculation from chart rendering
 * - No look-ahead bias
 * - No repainting (calculated strictly chronologically on closed historical/developing candles)
 */
object IndicatorCalculator {

    fun calculate(instance: IndicatorInstance, candles: List<Candle>): List<IndicatorDataPoint> {
        if (candles.isEmpty()) return emptyList()
        val sorted = ComprehensiveIndicatorEngine.sanitizeCandles(candles)

        val src = when (instance.source.uppercase()) {
            "OPEN" -> IndicatorSource.OPEN
            "HIGH" -> IndicatorSource.HIGH
            "LOW" -> IndicatorSource.LOW
            "HL2" -> IndicatorSource.HL2
            "HLC3" -> IndicatorSource.HLC3
            "OHLC4" -> IndicatorSource.OHLC4
            else -> IndicatorSource.CLOSE
        }

        val params = IndicatorParameters(
            period = instance.period,
            secondaryPeriod = instance.secondaryPeriod,
            signalPeriod = instance.signalPeriod,
            stdDev = instance.stdDev,
            source = src
        )

        return ComprehensiveIndicatorEngine.calculateByCode(instance.type.code, sorted, params)
    }

    private fun calculateSMA(candles: List<Candle>, period: Int): List<IndicatorDataPoint> {
        if (candles.size < period) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()
        var sum = 0.0

        for (i in 0 until period) {
            sum += candles[i].close
        }
        points.add(IndicatorDataPoint(candles[period - 1].timeInSeconds, sum / period))

        for (i in period until candles.size) {
            sum += candles[i].close - candles[i - period].close
            points.add(IndicatorDataPoint(candles[i].timeInSeconds, sum / period))
        }
        return points
    }

    private fun calculateEMA(candles: List<Candle>, period: Int): List<IndicatorDataPoint> {
        if (candles.size < period) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()
        val multiplier = 2.0 / (period + 1)

        // Initial SMA as first EMA value
        var sum = 0.0
        for (i in 0 until period) {
            sum += candles[i].close
        }
        var previousEMA = sum / period
        points.add(IndicatorDataPoint(candles[period - 1].timeInSeconds, previousEMA))

        for (i in period until candles.size) {
            val close = candles[i].close
            val currentEMA = (close - previousEMA) * multiplier + previousEMA
            points.add(IndicatorDataPoint(candles[i].timeInSeconds, currentEMA))
            previousEMA = currentEMA
        }
        return points
    }

    private fun calculateBollingerMiddle(candles: List<Candle>, period: Int): List<IndicatorDataPoint> {
        return calculateSMA(candles, period)
    }

    private fun calculateRSI(candles: List<Candle>, period: Int): List<IndicatorDataPoint> {
        if (candles.size <= period) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val diff = candles[i].close - candles[i - 1].close
            if (diff >= 0) gains += diff else losses -= diff
        }

        var avgGain = gains / period
        var avgLoss = losses / period

        var rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
        var rsi = 100.0 - (100.0 / (1.0 + rs))
        points.add(IndicatorDataPoint(candles[period].timeInSeconds, rsi))

        for (i in (period + 1) until candles.size) {
            val diff = candles[i].close - candles[i - 1].close
            val currentGain = if (diff > 0) diff else 0.0
            val currentLoss = if (diff < 0) -diff else 0.0

            avgGain = (avgGain * (period - 1) + currentGain) / period
            avgLoss = (avgLoss * (period - 1) + currentLoss) / period

            rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            rsi = 100.0 - (100.0 / (1.0 + rs))
            points.add(IndicatorDataPoint(candles[i].timeInSeconds, rsi))
        }

        return points
    }

    private fun calculateMACDFast(candles: List<Candle>, fastPeriod: Int): List<IndicatorDataPoint> {
        return calculateEMA(candles, fastPeriod)
    }

    private fun calculateATR(candles: List<Candle>, period: Int): List<IndicatorDataPoint> {
        if (candles.size <= period) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        fun trueRange(index: Int): Double {
            val current = candles[index]
            val prevClose = candles[index - 1].close
            val hl = current.high - current.low
            val hpc = kotlin.math.abs(current.high - prevClose)
            val lpc = kotlin.math.abs(current.low - prevClose)
            return maxOf(hl, hpc, lpc)
        }

        var trSum = 0.0
        for (i in 1..period) {
            trSum += trueRange(i)
        }
        var prevATR = trSum / period
        points.add(IndicatorDataPoint(candles[period].timeInSeconds, prevATR))

        for (i in (period + 1) until candles.size) {
            val currentTR = trueRange(i)
            val currentATR = (prevATR * (period - 1) + currentTR) / period
            points.add(IndicatorDataPoint(candles[i].timeInSeconds, currentATR))
            prevATR = currentATR
        }
        return points
    }

    private fun calculateVWAP(candles: List<Candle>): List<IndicatorDataPoint> {
        if (candles.isEmpty()) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()
        var cumulativeTPV = 0.0
        var cumulativeVol = 0.0

        for (c in candles) {
            val typicalPrice = (c.high + c.low + c.close) / 3.0
            val vol = if (c.volume > 0.0) c.volume else 1.0
            cumulativeTPV += typicalPrice * vol
            cumulativeVol += vol
            points.add(IndicatorDataPoint(c.timeInSeconds, cumulativeTPV / cumulativeVol))
        }
        return points
    }
}
