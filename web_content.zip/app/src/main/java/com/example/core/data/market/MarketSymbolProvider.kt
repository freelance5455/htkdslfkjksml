package com.example.core.data.market

import com.example.core.model.Instrument
import com.example.core.model.MarketCategory

/**
 * Provider interface abstracting symbol and instrument discovery for each market category.
 * Enables later modules (e.g. Module #4 Binance WebSocket, Forex feed, Bullion feed)
 * to supply real dynamic market symbols without touching the UI or core architecture.
 */
interface MarketSymbolProvider {
    val marketCategory: MarketCategory
    val providerId: String
    val providerName: String

    /**
     * Retrieves the complete symbol universe currently available from this provider.
     * Returns Result.success with instruments or Result.failure with details.
     */
    suspend fun fetchSymbols(): Result<List<Instrument>>

    /**
     * Returns initial or fallback instruments if offline before any sync.
     */
    fun getInitialSymbols(): List<Instrument>
}
