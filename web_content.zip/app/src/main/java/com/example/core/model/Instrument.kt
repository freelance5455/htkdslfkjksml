package com.example.core.model

/**
 * Authoritative instrument metadata model across all markets (Crypto, Forex, Gold).
 * Provides everything Module #3 and later modules need to identify the current instrument.
 */
data class Instrument(
    val symbolId: String,
    val displayName: String,
    val marketCategory: MarketCategory,
    val baseAsset: String,
    val quoteAsset: String,
    val providerId: String,
    val providerName: String,
    val isActive: Boolean = true,
    val pricePrecision: Int = 2,
    val quantityPrecision: Int = 4,
    val tickSize: Double = 0.01,
    val minLotSize: Double = 0.001,
    val description: String = ""
) {
    /**
     * Fast search filter by symbol, base asset, quote asset, display name, or description.
     */
    fun matchesQuery(query: String): Boolean {
        if (query.isBlank()) return true
        val clean = query.trim().lowercase()
        return symbolId.lowercase().contains(clean) ||
                displayName.lowercase().contains(clean) ||
                baseAsset.lowercase().contains(clean) ||
                quoteAsset.lowercase().contains(clean) ||
                description.lowercase().contains(clean)
    }

    val formattedPricePrecision: String
        get() = "%.${pricePrecision}f".format(tickSize)
}
