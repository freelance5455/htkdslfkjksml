package com.example.core.indicator.engine

import com.example.core.model.chart.Candle
import com.example.core.model.chart.IndicatorDataPoint
import com.example.core.model.indicator.DataValidityState
import com.example.core.model.indicator.IndicatorParameters
import com.example.core.model.indicator.IndicatorResult
import com.example.core.model.indicator.IndicatorSource
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Production-grade Technical Indicator Mathematical Engine for IQTrade Pro.
 * Features:
 * - Deterministic, non-repainting mathematical calculations
 * - Historical and live candle updates
 * - Correct chronological ordering and timestamp deduplication
 * - Insufficient data guards (no crashes, graceful fallback)
 * - Zero look-ahead bias
 */
object ComprehensiveIndicatorEngine {

    /**
     * Sanitizes, sorts chronologically, and deduplicates input candles.
     */
    fun sanitizeCandles(candles: List<Candle>): List<Candle> {
        if (candles.isEmpty()) return emptyList()
        return candles
            .filter { it.timestamp > 0 && it.close > 0 }
            .distinctBy { it.timestamp }
            .sortedBy { it.timestamp }
    }

    /**
     * Extracts numerical price series based on requested source.
     */
    fun extractSource(candles: List<Candle>, source: IndicatorSource): List<Double> {
        return candles.map { c ->
            when (source) {
                IndicatorSource.CLOSE -> c.close
                IndicatorSource.OPEN -> c.open
                IndicatorSource.HIGH -> c.high
                IndicatorSource.LOW -> c.low
                IndicatorSource.HL2 -> (c.high + c.low) / 2.0
                IndicatorSource.HLC3 -> (c.high + c.low + c.close) / 3.0
                IndicatorSource.OHLC4 -> (c.open + c.high + c.low + c.close) / 4.0
            }
        }
    }

    // ==========================================
    // MOVING AVERAGES (SMA, EMA, WMA, HMA, DEMA, TEMA)
    // ==========================================

    fun calculateSMA(candles: List<Candle>, period: Int, source: IndicatorSource = IndicatorSource.CLOSE): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return emptyList()
        val prices = extractSource(sanitized, source)
        val points = ArrayList<IndicatorDataPoint>()
        var sum = 0.0

        for (i in 0 until period) {
            sum += prices[i]
        }
        points.add(IndicatorDataPoint(sanitized[period - 1].timeInSeconds, sum / period))

        for (i in period until sanitized.size) {
            sum += prices[i] - prices[i - period]
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, sum / period))
        }
        return points
    }

    fun calculateEMA(candles: List<Candle>, period: Int, source: IndicatorSource = IndicatorSource.CLOSE): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return emptyList()
        val prices = extractSource(sanitized, source)
        val points = ArrayList<IndicatorDataPoint>()
        val multiplier = 2.0 / (period + 1)

        var sum = 0.0
        for (i in 0 until period) {
            sum += prices[i]
        }
        var prevEMA = sum / period
        points.add(IndicatorDataPoint(sanitized[period - 1].timeInSeconds, prevEMA))

        for (i in period until sanitized.size) {
            val currEMA = (prices[i] - prevEMA) * multiplier + prevEMA
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, currEMA))
            prevEMA = currEMA
        }
        return points
    }

    fun calculateWMA(candles: List<Candle>, period: Int, source: IndicatorSource = IndicatorSource.CLOSE): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return emptyList()
        val prices = extractSource(sanitized, source)
        val points = ArrayList<IndicatorDataPoint>()
        val weightSum = period * (period + 1) / 2.0

        for (i in (period - 1) until sanitized.size) {
            var weighted = 0.0
            for (j in 0 until period) {
                val weight = j + 1
                weighted += prices[i - period + 1 + j] * weight
            }
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, weighted / weightSum))
        }
        return points
    }

    fun calculateHMA(candles: List<Candle>, period: Int, source: IndicatorSource = IndicatorSource.CLOSE): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        val halfPeriod = max(1, period / 2)
        val sqrtPeriod = max(1, sqrt(period.toDouble()).toInt())
        if (sanitized.size < (period + sqrtPeriod)) return emptyList()

        val wmaHalf = calculateWMA(sanitized, halfPeriod, source)
        val wmaFull = calculateWMA(sanitized, period, source)
        if (wmaHalf.isEmpty() || wmaFull.isEmpty()) return emptyList()

        // Match timestamps between wmaHalf and wmaFull
        val fullMap = wmaFull.associateBy { it.time }
        val diffCandles = mutableListOf<Candle>()

        for (halfPt in wmaHalf) {
            val fullPt = fullMap[halfPt.time]
            if (fullPt != null) {
                val diffValue = 2.0 * halfPt.value - fullPt.value
                diffCandles.add(
                    Candle(
                        timestamp = halfPt.time * 1000L,
                        open = diffValue,
                        high = diffValue,
                        low = diffValue,
                        close = diffValue
                    )
                )
            }
        }
        return calculateWMA(diffCandles, sqrtPeriod, IndicatorSource.CLOSE)
    }

    fun calculateDEMA(candles: List<Candle>, period: Int, source: IndicatorSource = IndicatorSource.CLOSE): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < (period * 2)) return emptyList()
        val ema1 = calculateEMA(sanitized, period, source)
        if (ema1.isEmpty()) return emptyList()

        val ema1Candles = ema1.map { pt ->
            Candle(
                timestamp = pt.time * 1000L,
                open = pt.value,
                high = pt.value,
                low = pt.value,
                close = pt.value
            )
        }
        val ema2 = calculateEMA(ema1Candles, period, IndicatorSource.CLOSE)
        val ema2Map = ema2.associateBy { it.time }

        val points = ArrayList<IndicatorDataPoint>()
        for (pt1 in ema1) {
            val pt2 = ema2Map[pt1.time]
            if (pt2 != null) {
                val dema = 2.0 * pt1.value - pt2.value
                points.add(IndicatorDataPoint(pt1.time, dema))
            }
        }
        return points
    }

    fun calculateTEMA(candles: List<Candle>, period: Int, source: IndicatorSource = IndicatorSource.CLOSE): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < (period * 3)) return emptyList()
        val ema1 = calculateEMA(sanitized, period, source)
        if (ema1.isEmpty()) return emptyList()

        val ema1Candles = ema1.map { Candle(it.time * 1000L, it.value, it.value, it.value, it.value) }
        val ema2 = calculateEMA(ema1Candles, period, IndicatorSource.CLOSE)
        if (ema2.isEmpty()) return emptyList()

        val ema2Candles = ema2.map { Candle(it.time * 1000L, it.value, it.value, it.value, it.value) }
        val ema3 = calculateEMA(ema2Candles, period, IndicatorSource.CLOSE)

        val ema1Map = ema1.associateBy { it.time }
        val ema2Map = ema2.associateBy { it.time }

        val points = ArrayList<IndicatorDataPoint>()
        for (pt3 in ema3) {
            val pt1 = ema1Map[pt3.time]
            val pt2 = ema2Map[pt3.time]
            if (pt1 != null && pt2 != null) {
                val tema = (3.0 * pt1.value) - (3.0 * pt2.value) + pt3.value
                points.add(IndicatorDataPoint(pt3.time, tema))
            }
        }
        return points
    }

    // ==========================================
    // MOMENTUM & OSCILLATORS (RSI, STOCH, WPR, ROC, CCI, MACD, AO, ADX)
    // ==========================================

    fun calculateRSI(candles: List<Candle>, period: Int = 14): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size <= period || period <= 0) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        var gains = 0.0
        var losses = 0.0

        for (i in 1..period) {
            val diff = sanitized[i].close - sanitized[i - 1].close
            if (diff >= 0) gains += diff else losses -= diff
        }

        var avgGain = gains / period
        var avgLoss = losses / period
        var rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
        points.add(IndicatorDataPoint(sanitized[period].timeInSeconds, (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)))

        for (i in (period + 1) until sanitized.size) {
            val diff = sanitized[i].close - sanitized[i - 1].close
            val currentGain = if (diff > 0) diff else 0.0
            val currentLoss = if (diff < 0) -diff else 0.0

            avgGain = (avgGain * (period - 1) + currentGain) / period
            avgLoss = (avgLoss * (period - 1) + currentLoss) / period

            rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            val rsi = (100.0 - (100.0 / (1.0 + rs))).coerceIn(0.0, 100.0)
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, rsi))
        }
        return points
    }

    fun calculateStochastic(candles: List<Candle>, kPeriod: Int = 14, dPeriod: Int = 3): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < (kPeriod + dPeriod) || kPeriod <= 0) return emptyList()

        val rawK = ArrayList<IndicatorDataPoint>()
        for (i in (kPeriod - 1) until sanitized.size) {
            var highest = Double.MIN_VALUE
            var lowest = Double.MAX_VALUE
            for (j in 0 until kPeriod) {
                val c = sanitized[i - j]
                if (c.high > highest) highest = c.high
                if (c.low < lowest) lowest = c.low
            }
            val range = highest - lowest
            val currentClose = sanitized[i].close
            val k = if (range > 0) ((currentClose - lowest) / range) * 100.0 else 50.0
            rawK.add(IndicatorDataPoint(sanitized[i].timeInSeconds, k.coerceIn(0.0, 100.0)))
        }

        if (rawK.size < dPeriod) return rawK
        // Smooth %K by dPeriod SMA to produce smoothed line
        val smoothed = ArrayList<IndicatorDataPoint>()
        var sum = 0.0
        for (i in 0 until dPeriod) {
            sum += rawK[i].value
        }
        smoothed.add(IndicatorDataPoint(rawK[dPeriod - 1].time, (sum / dPeriod).coerceIn(0.0, 100.0)))

        for (i in dPeriod until rawK.size) {
            sum += rawK[i].value - rawK[i - dPeriod].value
            smoothed.add(IndicatorDataPoint(rawK[i].time, (sum / dPeriod).coerceIn(0.0, 100.0)))
        }
        return smoothed
    }

    fun calculateWilliamsR(candles: List<Candle>, period: Int = 14): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        for (i in (period - 1) until sanitized.size) {
            var highest = Double.MIN_VALUE
            var lowest = Double.MAX_VALUE
            for (j in 0 until period) {
                val c = sanitized[i - j]
                if (c.high > highest) highest = c.high
                if (c.low < lowest) lowest = c.low
            }
            val range = highest - lowest
            val currentClose = sanitized[i].close
            val wr = if (range > 0) ((highest - currentClose) / range) * -100.0 else -50.0
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, wr.coerceIn(-100.0, 0.0)))
        }
        return points
    }

    fun calculateROC(candles: List<Candle>, period: Int = 12): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size <= period || period <= 0) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        for (i in period until sanitized.size) {
            val prevClose = sanitized[i - period].close
            val currClose = sanitized[i].close
            val roc = if (prevClose > 0) ((currClose - prevClose) / prevClose) * 100.0 else 0.0
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, roc))
        }
        return points
    }

    fun calculateCCI(candles: List<Candle>, period: Int = 20): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()
        val typicalPrices = sanitized.map { (it.high + it.low + it.close) / 3.0 }

        for (i in (period - 1) until sanitized.size) {
            var sum = 0.0
            for (j in 0 until period) {
                sum += typicalPrices[i - j]
            }
            val sma = sum / period

            var meanDevSum = 0.0
            for (j in 0 until period) {
                meanDevSum += abs(typicalPrices[i - j] - sma)
            }
            val meanDev = meanDevSum / period
            val cci = if (meanDev > 0) (typicalPrices[i] - sma) / (0.015 * meanDev) else 0.0
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, cci))
        }
        return points
    }

    fun calculateMACD(
        candles: List<Candle>,
        fastPeriod: Int = 12,
        slowPeriod: Int = 26,
        signalPeriod: Int = 9
    ): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < slowPeriod) return emptyList()

        val fastEMA = calculateEMA(sanitized, fastPeriod)
        val slowEMA = calculateEMA(sanitized, slowPeriod)
        if (fastEMA.isEmpty() || slowEMA.isEmpty()) return emptyList()

        val slowMap = slowEMA.associateBy { it.time }
        val macdLine = ArrayList<IndicatorDataPoint>()

        for (fastPt in fastEMA) {
            val slowPt = slowMap[fastPt.time]
            if (slowPt != null) {
                macdLine.add(IndicatorDataPoint(fastPt.time, fastPt.value - slowPt.value))
            }
        }
        return macdLine
    }

    fun calculateAwesomeOscillator(candles: List<Candle>, fastPeriod: Int = 5, slowPeriod: Int = 34): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < slowPeriod) return emptyList()
        val midpoints = sanitized.map { Candle(it.timestamp, (it.high + it.low)/2.0, (it.high + it.low)/2.0, (it.high + it.low)/2.0, (it.high + it.low)/2.0) }

        val smaFast = calculateSMA(midpoints, fastPeriod)
        val smaSlow = calculateSMA(midpoints, slowPeriod)
        val slowMap = smaSlow.associateBy { it.time }

        val points = ArrayList<IndicatorDataPoint>()
        for (f in smaFast) {
            val s = slowMap[f.time]
            if (s != null) {
                points.add(IndicatorDataPoint(f.time, f.value - s.value))
            }
        }
        return points
    }

    fun calculateADX(candles: List<Candle>, period: Int = 14): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < (period * 2)) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        val trList = ArrayList<Double>()
        val dmPlusList = ArrayList<Double>()
        val dmMinusList = ArrayList<Double>()

        for (i in 1 until sanitized.size) {
            val curr = sanitized[i]
            val prev = sanitized[i - 1]
            val tr = max(curr.high - curr.low, max(abs(curr.high - prev.close), abs(curr.low - prev.close)))
            val upMove = curr.high - prev.high
            val downMove = prev.low - curr.low

            val dmPlus = if (upMove > downMove && upMove > 0) upMove else 0.0
            val dmMinus = if (downMove > upMove && downMove > 0) downMove else 0.0

            trList.add(tr)
            dmPlusList.add(dmPlus)
            dmMinusList.add(dmMinus)
        }

        var smoothedTR = trList.take(period).sum()
        var smoothedDMPlus = dmPlusList.take(period).sum()
        var smoothedDMMinus = dmMinusList.take(period).sum()

        val dxList = ArrayList<Double>()
        for (i in period until trList.size) {
            smoothedTR = smoothedTR - (smoothedTR / period) + trList[i]
            smoothedDMPlus = smoothedDMPlus - (smoothedDMPlus / period) + dmPlusList[i]
            smoothedDMMinus = smoothedDMMinus - (smoothedDMMinus / period) + dmMinusList[i]

            val diPlus = if (smoothedTR > 0) (smoothedDMPlus / smoothedTR) * 100.0 else 0.0
            val diMinus = if (smoothedTR > 0) (smoothedDMMinus / smoothedTR) * 100.0 else 0.0
            val diSum = diPlus + diMinus
            val dx = if (diSum > 0) (abs(diPlus - diMinus) / diSum) * 100.0 else 0.0
            dxList.add(dx)
        }

        if (dxList.size < period) return emptyList()
        var adx = dxList.take(period).average()
        val timeOffset = sanitized.size - (dxList.size - period + 1)
        points.add(IndicatorDataPoint(sanitized[timeOffset].timeInSeconds, adx))

        for (i in period until dxList.size) {
            adx = (adx * (period - 1) + dxList[i]) / period
            val candleIdx = sanitized.size - dxList.size + i
            if (candleIdx in sanitized.indices) {
                points.add(IndicatorDataPoint(sanitized[candleIdx].timeInSeconds, adx))
            }
        }
        return points
    }

    // ==========================================
    // VOLATILITY & CHANNELS (BOLL, ATR, KC, DC, STDDEV)
    // ==========================================

    fun calculateATR(candles: List<Candle>, period: Int = 14): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size <= period || period <= 0) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        fun trueRange(i: Int): Double {
            val curr = sanitized[i]
            val prev = sanitized[i - 1]
            return max(curr.high - curr.low, max(abs(curr.high - prev.close), abs(curr.low - prev.close)))
        }

        var trSum = 0.0
        for (i in 1..period) {
            trSum += trueRange(i)
        }
        var prevATR = trSum / period
        points.add(IndicatorDataPoint(sanitized[period].timeInSeconds, prevATR))

        for (i in (period + 1) until sanitized.size) {
            val currTR = trueRange(i)
            val currATR = (prevATR * (period - 1) + currTR) / period
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, currATR))
            prevATR = currATR
        }
        return points
    }

    fun calculateBollingerBands(
        candles: List<Candle>,
        period: Int = 20,
        stdDevMultiplier: Double = 2.0
    ): Triple<List<IndicatorDataPoint>, List<IndicatorDataPoint>, List<IndicatorDataPoint>> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return Triple(emptyList(), emptyList(), emptyList())

        val middle = calculateSMA(sanitized, period)
        val upper = ArrayList<IndicatorDataPoint>()
        val lower = ArrayList<IndicatorDataPoint>()

        val middleMap = middle.associateBy { it.time }
        for (i in (period - 1) until sanitized.size) {
            val t = sanitized[i].timeInSeconds
            val midVal = middleMap[t]?.value ?: continue

            var sumDevSq = 0.0
            for (j in 0 until period) {
                val diff = sanitized[i - j].close - midVal
                sumDevSq += diff * diff
            }
            val dev = sqrt(sumDevSq / period) * stdDevMultiplier
            upper.add(IndicatorDataPoint(t, midVal + dev))
            lower.add(IndicatorDataPoint(t, midVal - dev))
        }
        return Triple(upper, middle, lower)
    }

    fun calculateSupertrend(
        candles: List<Candle>,
        atrPeriod: Int = 10,
        multiplier: Double = 3.0
    ): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        val atrPoints = calculateATR(sanitized, atrPeriod)
        if (atrPoints.isEmpty()) return emptyList()

        val atrMap = atrPoints.associateBy { it.time }
        val points = ArrayList<IndicatorDataPoint>()
        var inUptrend = true
        var prevSupertrend = sanitized.first().close

        for (c in sanitized) {
            val atr = atrMap[c.timeInSeconds]?.value ?: continue
            val hl2 = (c.high + c.low) / 2.0
            val basicUpper = hl2 + (multiplier * atr)
            val basicLower = hl2 - (multiplier * atr)

            if (inUptrend) {
                if (c.close < prevSupertrend) {
                    inUptrend = false
                    prevSupertrend = basicUpper
                } else {
                    prevSupertrend = max(basicLower, prevSupertrend)
                }
            } else {
                if (c.close > prevSupertrend) {
                    inUptrend = true
                    prevSupertrend = basicLower
                } else {
                    prevSupertrend = min(basicUpper, prevSupertrend)
                }
            }
            points.add(IndicatorDataPoint(c.timeInSeconds, prevSupertrend))
        }
        return points
    }

    fun calculateDonchianChannels(
        candles: List<Candle>,
        period: Int = 20
    ): Triple<List<IndicatorDataPoint>, List<IndicatorDataPoint>, List<IndicatorDataPoint>> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return Triple(emptyList(), emptyList(), emptyList())

        val upper = ArrayList<IndicatorDataPoint>()
        val middle = ArrayList<IndicatorDataPoint>()
        val lower = ArrayList<IndicatorDataPoint>()

        for (i in (period - 1) until sanitized.size) {
            var highMax = Double.MIN_VALUE
            var lowMin = Double.MAX_VALUE
            for (j in 0 until period) {
                val c = sanitized[i - j]
                if (c.high > highMax) highMax = c.high
                if (c.low < lowMin) lowMin = c.low
            }
            val t = sanitized[i].timeInSeconds
            upper.add(IndicatorDataPoint(t, highMax))
            lower.add(IndicatorDataPoint(t, lowMin))
            middle.add(IndicatorDataPoint(t, (highMax + lowMin) / 2.0))
        }
        return Triple(upper, middle, lower)
    }

    // ==========================================
    // VOLUME INDICATORS (VWAP, OBV, CMF, MFI)
    // ==========================================

    fun calculateVWAP(candles: List<Candle>): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.isEmpty()) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()
        var cumTPV = 0.0
        var cumVol = 0.0

        for (c in sanitized) {
            val tp = (c.high + c.low + c.close) / 3.0
            val v = if (c.volume > 0.0) c.volume else 1.0
            cumTPV += tp * v
            cumVol += v
            points.add(IndicatorDataPoint(c.timeInSeconds, cumTPV / cumVol))
        }
        return points
    }

    fun calculateOBV(candles: List<Candle>): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < 2) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()
        var obv = 0.0
        points.add(IndicatorDataPoint(sanitized[0].timeInSeconds, 0.0))

        for (i in 1 until sanitized.size) {
            val curr = sanitized[i]
            val prev = sanitized[i - 1]
            val vol = if (curr.volume > 0.0) curr.volume else 1.0
            when {
                curr.close > prev.close -> obv += vol
                curr.close < prev.close -> obv -= vol
            }
            points.add(IndicatorDataPoint(curr.timeInSeconds, obv))
        }
        return points
    }

    fun calculateCMF(candles: List<Candle>, period: Int = 20): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        for (i in (period - 1) until sanitized.size) {
            var mfvSum = 0.0
            var volSum = 0.0
            for (j in 0 until period) {
                val c = sanitized[i - j]
                val range = c.high - c.low
                val mfm = if (range > 0.0) ((c.close - c.low) - (c.high - c.close)) / range else 0.0
                val v = if (c.volume > 0.0) c.volume else 1.0
                mfvSum += mfm * v
                volSum += v
            }
            val cmf = if (volSum > 0.0) mfvSum / volSum else 0.0
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, cmf.coerceIn(-1.0, 1.0)))
        }
        return points
    }

    fun calculateMFI(candles: List<Candle>, period: Int = 14): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size <= period || period <= 0) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        val typicalPrices = sanitized.map { (it.high + it.low + it.close) / 3.0 }
        val rawMoneyFlows = sanitized.mapIndexed { idx, c ->
            val v = if (c.volume > 0.0) c.volume else 1.0
            typicalPrices[idx] * v
        }

        for (i in period until sanitized.size) {
            var posFlow = 0.0
            var negFlow = 0.0
            for (j in 0 until period) {
                val currIdx = i - j
                val prevIdx = currIdx - 1
                if (typicalPrices[currIdx] > typicalPrices[prevIdx]) {
                    posFlow += rawMoneyFlows[currIdx]
                } else if (typicalPrices[currIdx] < typicalPrices[prevIdx]) {
                    negFlow += rawMoneyFlows[currIdx]
                }
            }
            val mfr = if (negFlow == 0.0) 100.0 else posFlow / negFlow
            val mfi = 100.0 - (100.0 / (1.0 + mfr))
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, mfi.coerceIn(0.0, 100.0)))
        }
        return points
    }

    // ==========================================
    // SUPPORT & RESISTANCE & STATISTICAL
    // ==========================================

    fun calculateClassicPivotPoints(candles: List<Candle>): IndicatorResult {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.isEmpty()) {
            return IndicatorResult("PIVOT", System.currentTimeMillis(), 0.0, validity = DataValidityState.INSUFFICIENT_DATA)
        }
        val last = sanitized.last()
        val pivot = (last.high + last.low + last.close) / 3.0
        val r1 = 2.0 * pivot - last.low
        val s1 = 2.0 * pivot - last.high
        return IndicatorResult(
            indicatorCode = "PIVOT",
            timestamp = last.timestamp,
            primaryValue = pivot,
            secondaryValue = r1,
            tertiaryValue = s1,
            metadata = mapOf("P" to "%.2f".format(pivot), "R1" to "%.2f".format(r1), "S1" to "%.2f".format(s1))
        )
    }

    fun calculateLinearRegression(candles: List<Candle>, period: Int = 20): List<IndicatorDataPoint> {
        val sanitized = sanitizeCandles(candles)
        if (sanitized.size < period || period <= 0) return emptyList()
        val points = ArrayList<IndicatorDataPoint>()

        for (i in (period - 1) until sanitized.size) {
            var sumX = 0.0
            var sumY = 0.0
            var sumXY = 0.0
            var sumX2 = 0.0
            for (j in 0 until period) {
                val x = j.toDouble()
                val y = sanitized[i - period + 1 + j].close
                sumX += x
                sumY += y
                sumXY += x * y
                sumX2 += x * x
            }
            val n = period.toDouble()
            val slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX)
            val intercept = (sumY - slope * sumX) / n
            val endVal = slope * (period - 1) + intercept
            points.add(IndicatorDataPoint(sanitized[i].timeInSeconds, endVal))
        }
        return points
    }

    /**
     * Unified calculation dispatch router for any registered indicator.
     */
    fun calculateByCode(code: String, candles: List<Candle>, params: IndicatorParameters): List<IndicatorDataPoint> {
        return when (code.uppercase()) {
            "EMA" -> calculateEMA(candles, params.period, params.source)
            "SMA" -> calculateSMA(candles, params.period, params.source)
            "WMA" -> calculateWMA(candles, params.period, params.source)
            "HMA" -> calculateHMA(candles, params.period, params.source)
            "DEMA" -> calculateDEMA(candles, params.period, params.source)
            "TEMA" -> calculateTEMA(candles, params.period, params.source)
            "SUPERTREND" -> calculateSupertrend(candles, params.period, params.multiplier)
            "RSI" -> calculateRSI(candles, params.period)
            "STOCH" -> calculateStochastic(candles, params.period, params.secondaryPeriod)
            "WPR" -> calculateWilliamsR(candles, params.period)
            "ROC" -> calculateROC(candles, params.period)
            "CCI" -> calculateCCI(candles, params.period)
            "MACD" -> calculateMACD(candles, params.period, params.secondaryPeriod, params.signalPeriod)
            "AO" -> calculateAwesomeOscillator(candles, params.period, params.secondaryPeriod)
            "BOLL" -> calculateBollingerBands(candles, params.period, params.stdDev).second // Middle band
            "ATR" -> calculateATR(candles, params.period)
            "DC" -> calculateDonchianChannels(candles, params.period).second // Middle
            "VWAP" -> calculateVWAP(candles)
            "OBV" -> calculateOBV(candles)
            "CMF" -> calculateCMF(candles, params.period)
            "MFI" -> calculateMFI(candles, params.period)
            "ADX" -> calculateADX(candles, params.period)
            "LINREG" -> calculateLinearRegression(candles, params.period)
            else -> calculateSMA(candles, params.period, params.source)
        }
    }
}
