package com.example.core.model

/**
 * Global application error model.
 * Provides sanitized, user-friendly messages without leaking secret keys or internal traces.
 */
sealed class AppError(
    val title: String,
    val userMessage: String,
    val isRecoverable: Boolean = true
) {
    object NoInternet : AppError(
        title = "No Internet Connection",
        userMessage = "Network appears offline. Please check your Wi-Fi or mobile data connection."
    )

    object ApiUnavailable : AppError(
        title = "Service Unavailable",
        userMessage = "The trading server is temporarily unreachable. Please try again shortly."
    )

    object ConnectionTimeout : AppError(
        title = "Connection Timed Out",
        userMessage = "The request took too long to complete. Retrying might resolve this."
    )

    object ConnectionLost : AppError(
        title = "Connection Interrupted",
        userMessage = "Live connection was interrupted. Automatic reconnection will occur when network stabilizes."
    )

    object InvalidConfiguration : AppError(
        title = "Configuration Notice",
        userMessage = "Please verify your parameters or credentials in settings."
    )

    object AuthenticationFailure : AppError(
        title = "Authentication Issue",
        userMessage = "The provided API credentials could not be authenticated. Please double check permissions.",
        isRecoverable = false
    )

    object UnexpectedServerResponse : AppError(
        title = "Response Error",
        userMessage = "Received an unexpected format from the market data provider."
    )

    data class Custom(
        val customTitle: String,
        val customMessage: String
    ) : AppError(
        title = customTitle,
        userMessage = customMessage
    )

    data class Generic(
        val message: String
    ) : AppError(
        title = "Trade Notice",
        userMessage = message
    )
}
