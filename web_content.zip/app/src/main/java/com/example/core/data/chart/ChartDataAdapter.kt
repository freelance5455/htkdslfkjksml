package com.example.core.data.chart

import com.example.core.model.MarketCategory
import com.example.core.model.Timeframe
import com.example.core.model.chart.Candle
import com.example.core.model.chart.ChartConnectionState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

data class ChartDataState(
    val selectedMarket: MarketCategory = MarketCategory.CRYPTO,
    val selectedSymbol: String = "BTCUSDT",
    val selectedTimeframe: Timeframe = Timeframe.H1,
    val candles: List<Candle> = emptyList(),
    val latestCandle: Candle? = null,
    val currentPrice: Double? = null,
    val connectionState: ChartConnectionState = ChartConnectionState.Loading,
    val errorMessage: String? = null
)

/**
 * Chart Data Adapter bridging between Market Data Providers (Binance, Forex, Gold)
 * and the Lightweight Charts engine.
 *
 * Strict Invariants:
 * - Differentiates historical vs live candles
 * - No duplicate candles on live updates
 * - Correct timestamp ordering (strictly chronological)
 * - Rejection of future candles
 * - Stale data and reconnection state synchronization
 * - Lifecycle-safe subscriptions with cancellation of previous jobs
 */
class ChartDataAdapter(
    private val scope: CoroutineScope,
    private val cryptoProvider: MarketDataProvider = BinanceMarketDataProvider(),
    private val forexProvider: MarketDataProvider = ForexSymbolProviderAdapter(),
    private val goldProvider: MarketDataProvider = GoldSymbolProviderAdapter()
) {
    private val _state = MutableStateFlow(ChartDataState())
    val state: StateFlow<ChartDataState> = _state.asStateFlow()

    private var liveSubscriptionJob: Job? = null
    private var connectionStateJob: Job? = null
    private var historicalFetchJob: Job? = null
    private var activeProvider: MarketDataProvider? = null

    fun getProviderForMarket(market: MarketCategory): MarketDataProvider {
        return when (market) {
            MarketCategory.CRYPTO -> cryptoProvider
            MarketCategory.FOREX -> forexProvider
            MarketCategory.GOLD -> goldProvider
        }
    }

    fun loadData(market: MarketCategory, symbol: String, timeframe: Timeframe) {
        historicalFetchJob?.cancel()
        liveSubscriptionJob?.cancel()
        connectionStateJob?.cancel()

        // Disconnect previous provider if market changed
        val newProvider = getProviderForMarket(market)
        if (activeProvider != null && activeProvider != newProvider) {
            activeProvider?.disconnect()
        }
        activeProvider = newProvider

        _state.value = _state.value.copy(
            selectedMarket = market,
            selectedSymbol = symbol,
            selectedTimeframe = timeframe,
            connectionState = ChartConnectionState.Loading,
            errorMessage = null
        )

        // Observe provider connection state (WebSocket live status, stale, reconnecting, etc.)
        connectionStateJob = scope.launch {
            newProvider.connectionState
                .catch { /* ignore state flow errors */ }
                .collect { connState ->
                    // Only override connectionState if we already have data or if it's an error/reconnect state
                    if (_state.value.candles.isNotEmpty() || connState.isError || connState is ChartConnectionState.Reconnecting) {
                        _state.value = _state.value.copy(connectionState = connState)
                    }
                }
        }

        historicalFetchJob = scope.launch {
            val result = newProvider.fetchHistoricalCandles(symbol, timeframe, limit = 150)
            if (result.isSuccess) {
                val historical = result.getOrNull().orEmpty()
                val sorted = historical.sortedBy { it.timestamp }
                val lastCandle = sorted.lastOrNull()
                val currentPrice = lastCandle?.close

                _state.value = _state.value.copy(
                    candles = sorted,
                    latestCandle = lastCandle,
                    currentPrice = currentPrice,
                    connectionState = if (sorted.isEmpty()) ChartConnectionState.DataUnavailable else ChartConnectionState.Connected
                )

                // Attach real-time WebSocket live stream subscription
                subscribeToLiveUpdates(newProvider, symbol, timeframe)
            } else {
                val err = result.exceptionOrNull()?.message ?: "Failed to load candles"
                _state.value = _state.value.copy(
                    candles = emptyList(),
                    connectionState = ChartConnectionState.Error(err),
                    errorMessage = err
                )
            }
        }
    }

    private fun subscribeToLiveUpdates(
        provider: MarketDataProvider,
        symbol: String,
        timeframe: Timeframe
    ) {
        liveSubscriptionJob?.cancel()
        liveSubscriptionJob = scope.launch {
            provider.observeLiveCandle(symbol, timeframe)
                .catch { e ->
                    _state.value = _state.value.copy(
                        connectionState = ChartConnectionState.Error(e.message ?: "Live feed error")
                    )
                }
                .collect { newCandle ->
                    applyLiveCandle(newCandle)
                }
        }
    }

    /**
     * Ingestion of live candle without duplicating or skipping candles.
     */
    fun applyLiveCandle(incoming: Candle) {
        val currentList = _state.value.candles.toMutableList()
        val now = System.currentTimeMillis()

        // Reject future candle timestamps (> 5 mins into future)
        if (incoming.timestamp > now + 300_000L) {
            return
        }

        if (currentList.isEmpty()) {
            currentList.add(incoming)
        } else {
            val lastIndex = currentList.lastIndex
            val lastCandle = currentList[lastIndex]

            if (incoming.timeInSeconds == lastCandle.timeInSeconds) {
                // Update developing candle in-place
                currentList[lastIndex] = incoming.copy(
                    high = maxOf(lastCandle.high, incoming.high),
                    low = minOf(lastCandle.low, incoming.low)
                )
            } else if (incoming.timeInSeconds > lastCandle.timeInSeconds) {
                // Finalize previous candle as closed
                currentList[lastIndex] = lastCandle.copy(isClosed = true)
                // Append new timeframe bar
                currentList.add(incoming)
            }
            // Older out-of-order candles are discarded to preserve strict chronological ordering
        }

        _state.value = _state.value.copy(
            candles = currentList,
            latestCandle = incoming,
            currentPrice = incoming.close,
            connectionState = if (_state.value.connectionState is ChartConnectionState.Stale) {
                ChartConnectionState.Connected
            } else {
                _state.value.connectionState
            }
        )
    }

    fun cleanup() {
        historicalFetchJob?.cancel()
        liveSubscriptionJob?.cancel()
        connectionStateJob?.cancel()
        activeProvider?.disconnect()
    }
}

private class ForexSymbolProviderAdapter : MarketDataProvider by ForexMarketDataProvider()
private class GoldSymbolProviderAdapter : MarketDataProvider by GoldMarketDataProvider()
