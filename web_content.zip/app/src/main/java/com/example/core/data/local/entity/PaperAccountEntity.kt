package com.example.core.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "paper_account")
data class PaperAccountEntity(
    @PrimaryKey val id: Int = 1,
    val balance: Double = 10000.0,
    val equity: Double = 10000.0,
    val unrealizedPnl: Double = 0.0,
    val realizedPnl: Double = 0.0,
    val currency: String = "USDT",
    val updatedAt: Long = System.currentTimeMillis()
)
