package com.example.core.indicator.persistence

import android.content.Context
import android.content.SharedPreferences
import com.example.core.model.chart.IndicatorInstance
import com.example.core.model.chart.IndicatorType
import org.json.JSONArray
import org.json.JSONObject

/**
 * Isolated persistence repository for visual chart indicators and user favorites.
 *
 * ARCHITECTURAL CONSTRAINT:
 * Stored independently from Analysis Engine state and Custom Mode state.
 * Any modification, reset, or addition here only affects the visual chart display.
 */
class IndicatorPersistenceManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val PREFS_NAME = "iqtrade_indicator_prefs"
        private const val KEY_CHART_INDICATORS = "key_chart_indicators_v2"
        private const val KEY_FAVORITE_CODES = "key_indicator_favorites_v2"

        val DEFAULT_FAVORITES = setOf(
            "EMA", "SMA", "RSI", "MACD", "BOLL", "SUPERTREND", "VWAP", "STOCH", "ADX"
        )

        val DEFAULT_CHART_INDICATORS = listOf(
            IndicatorInstance(type = IndicatorType.EMA, period = 20, color = "#00E5FF", isEnabled = true),
            IndicatorInstance(type = IndicatorType.EMA, period = 50, color = "#F0B90B", isEnabled = true)
        )
    }

    /**
     * Retrieves saved chart visual indicators. Falls back to defaults if not yet customized.
     */
    fun getSavedChartIndicators(): List<IndicatorInstance> {
        val raw = prefs.getString(KEY_CHART_INDICATORS, null) ?: return DEFAULT_CHART_INDICATORS
        return try {
            val array = JSONArray(raw)
            val list = mutableListOf<IndicatorInstance>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val instance = IndicatorInstance.fromConfigJson(obj)
                if (instance != null) {
                    list.add(instance)
                }
            }
            if (list.isEmpty()) DEFAULT_CHART_INDICATORS else list
        } catch (_: Exception) {
            DEFAULT_CHART_INDICATORS
        }
    }

    /**
     * Persists visual chart indicators to storage.
     */
    fun saveChartIndicators(indicators: List<IndicatorInstance>) {
        try {
            val array = JSONArray()
            for (ind in indicators) {
                array.put(ind.toConfigJson())
            }
            prefs.edit().putString(KEY_CHART_INDICATORS, array.toString()).apply()
        } catch (_: Exception) {
            // Safe logging fallback
        }
    }

    /**
     * Retrieves favorite indicator codes.
     */
    fun getFavoriteCodes(): Set<String> {
        val raw = prefs.getString(KEY_FAVORITE_CODES, null) ?: return DEFAULT_FAVORITES
        return try {
            val array = JSONArray(raw)
            val set = mutableSetOf<String>()
            for (i in 0 until array.length()) {
                set.add(array.getString(i).uppercase())
            }
            if (set.isEmpty()) DEFAULT_FAVORITES else set
        } catch (_: Exception) {
            DEFAULT_FAVORITES
        }
    }

    /**
     * Toggles favorite status for an indicator code and persists immediately.
     */
    fun toggleFavorite(code: String): Set<String> {
        val current = getFavoriteCodes().toMutableSet()
        val upper = code.trim().uppercase()
        if (current.contains(upper)) {
            current.remove(upper)
        } else {
            current.add(upper)
        }
        try {
            val array = JSONArray()
            for (item in current) {
                array.put(item)
            }
            prefs.edit().putString(KEY_FAVORITE_CODES, array.toString()).apply()
        } catch (_: Exception) {}
        return current
    }

    /**
     * Checks if a code is currently marked as favorite.
     */
    fun isFavorite(code: String): Boolean {
        return getFavoriteCodes().contains(code.trim().uppercase())
    }

    /**
     * Resets visual indicators back to initial factory settings.
     */
    fun resetToDefaults(): List<IndicatorInstance> {
        saveChartIndicators(DEFAULT_CHART_INDICATORS)
        return DEFAULT_CHART_INDICATORS
    }
}
