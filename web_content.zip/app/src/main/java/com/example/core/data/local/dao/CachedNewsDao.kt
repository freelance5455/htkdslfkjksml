package com.example.core.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.core.data.local.entity.CachedNewsEntity

@Dao
interface CachedNewsDao {

    @Query("SELECT * FROM cached_news ORDER BY publishedAt DESC")
    suspend fun getAllCachedNews(): List<CachedNewsEntity>

    @Query("SELECT * FROM cached_news WHERE marketCategory = :category ORDER BY publishedAt DESC")
    suspend fun getCachedNewsByCategory(category: String): List<CachedNewsEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(news: List<CachedNewsEntity>)

    @Query("DELETE FROM cached_news")
    suspend fun clearAll()

    @Query("DELETE FROM cached_news WHERE publishedAt < :cutoff")
    suspend fun deleteOlderThan(cutoff: Long)

    @Query("SELECT COUNT(*) FROM cached_news")
    suspend fun getCount(): Int
}
