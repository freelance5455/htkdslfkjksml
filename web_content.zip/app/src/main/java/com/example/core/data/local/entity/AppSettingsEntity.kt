package com.example.core.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val selectedSection: String = "TERMINAL",
    val selectedMarket: String = "CRYPTO",
    val selectedSymbol: String = "BTCUSDT",
    val selectedTimeframe: String = "1h",
    val tradingMode: String = "PAPER",
    // MANDATORY DEFAULT STATES: ALL DEFAULT FALSE / OFF
    val isSmartModeEnabled: Boolean = false,
    val isAutoTradingEnabled: Boolean = false,
    val isLiveTradingEnabled: Boolean = false,
    val showIndicators: Boolean = false,
    val showVolume: Boolean = false,
    val showSignalPlotting: Boolean = false,
    // Connection flags
    val binanceConnected: Boolean = false,
    val newsApiConnected: Boolean = false,
    val overlayPermissionGranted: Boolean = false,
    // Default Trade Protection Settings
    val defaultStopLossPct: Double = 1.5,
    val defaultTakeProfitPct: Double = 3.0,
    val defaultTrailingDistancePct: Double = 2.0,
    val defaultStopLossMode: String = "FIXED",
    val customSelectedIndicators: String = "EMA,RSI,MACD",
    val customSelectedTimeframes: String = "15m,1h,4h"
)
