package com.example.core.model

/**
 * Distinct, selectable Trading Modes in IQTrade Pro.
 *
 * NOTE: System engine flags (Smart Mode, Auto Trading Engine, Live Execution Engine)
 * are separate system safety/authorization controls and NOT replacements for these modes.
 */
enum class TradingMode(
    val id: String,
    val title: String,
    val shortLabel: String,
    val subtitle: String,
    val description: String,
    val defaultTimeframe: String,
    val requiresApiCredentials: Boolean = false,
    val isAutomated: Boolean = false
) {
    AUTO_TRADE(
        id = "AUTO_TRADE",
        title = "Auto Trade",
        shortLabel = "Auto Trade",
        subtitle = "Algorithmic Automated Execution",
        description = "Fully automated algorithmic strategy engine that continuously scans market signals and auto-executes positions when armed.",
        defaultTimeframe = "15m",
        isAutomated = true
    ),
    SCALPING_TRADE(
        id = "SCALPING_TRADE",
        title = "Scalping Trade",
        shortLabel = "Scalping",
        subtitle = "High-Frequency Micro-Momentum",
        description = "Fast-execution scalping workspace optimized for quick entries/exits, tight spreads, 1m/3m/5m fast timeframes, and instant stops.",
        defaultTimeframe = "1m"
    ),
    MANUAL_TRADE(
        id = "MANUAL_TRADE",
        title = "Manual Trade",
        shortLabel = "Manual",
        subtitle = "Full Trader Discretion & Control",
        description = "Complete manual order control. Trader manages entry prices, order types (Market/Limit/Trigger), position sizing, and stops with zero automated intervention.",
        defaultTimeframe = "1h"
    ),
    LIVE_TRADE(
        id = "LIVE_TRADE",
        title = "Live Trade",
        shortLabel = "Live Trade",
        subtitle = "Real Binance Exchange Orders",
        description = "Direct broker/exchange execution routing live capital to Binance spot/futures accounts. Requires verified API Key & Secret.",
        defaultTimeframe = "1h",
        requiresApiCredentials = true
    ),
    PAPER_TRADE(
        id = "PAPER_TRADE",
        title = "Paper Trade",
        shortLabel = "Paper Trade",
        subtitle = "Zero-Risk Simulated Trading",
        description = "Simulated market trading on real-time live Binance price ticks with $10,000 virtual balance. Ideal for testing strategies without risking real funds.",
        defaultTimeframe = "1h"
    ),
    ONLY_SIGNAL(
        id = "ONLY_SIGNAL",
        title = "Only Signal",
        shortLabel = "Only Signal",
        subtitle = "Technical & Algorithmic Signal Alerts",
        description = "Real-time technical indicator scanner that delivers buy/sell advisory alerts, trend markers, and price notifications on-chart without placing orders.",
        defaultTimeframe = "15m"
    ),
    CUSTOM_MODE(
        id = "CUSTOM_MODE",
        title = "Custom Mode",
        shortLabel = "Custom Mode",
        subtitle = "User-Tailored Strategy Rules",
        description = "Custom trading workspace allowing user-defined indicator combinations, custom risk-to-reward ratios, custom balance risk %, and execution triggers.",
        defaultTimeframe = "4h"
    );

    companion object {
        fun fromString(str: String): TradingMode {
            val clean = str.trim()
            if (clean.equals("Smart Auto Trade", ignoreCase = true) || 
                clean.equals("Smart Auto", ignoreCase = true) ||
                clean.equals("Swing Trade", ignoreCase = true) ||
                clean.equals("Swing", ignoreCase = true) ||
                clean.equals("SWING_TRADE", ignoreCase = true)
            ) {
                return AUTO_TRADE
            }
            return entries.firstOrNull { 
                it.id.equals(clean, ignoreCase = true) || 
                it.name.equals(clean, ignoreCase = true) ||
                it.title.equals(clean, ignoreCase = true) ||
                it.shortLabel.equals(clean, ignoreCase = true)
            } ?: fromId(clean)
        }

        fun fromId(id: String): TradingMode {
            return entries.firstOrNull { 
                it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true) 
            } ?: when (id.uppercase()) {
                "PAPER" -> PAPER_TRADE
                "LIVE" -> LIVE_TRADE
                "SCALP", "SCALPING" -> SCALPING_TRADE
                "SWING", "SWING_TRADE" -> AUTO_TRADE
                "SIGNAL" -> ONLY_SIGNAL
                "CUSTOM" -> CUSTOM_MODE
                "MANUAL" -> MANUAL_TRADE
                "SMART_AUTO", "SMART_AUTO_TRADE" -> AUTO_TRADE
                else -> AUTO_TRADE
            }
        }
    }
}
