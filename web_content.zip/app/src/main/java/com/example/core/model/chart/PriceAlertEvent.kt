package com.example.core.model.chart

import org.json.JSONObject

/**
 * Represents a price crossing alert triggered by the chart engine
 * when market price moves across a previously set horizontal price line.
 */
data class PriceAlertEvent(
    val lineId: String,
    val targetPrice: Double,
    val currentPrice: Double,
    val previousPrice: Double = 0.0,
    val direction: String, // "CROSS_ABOVE" or "CROSS_BELOW"
    val title: String = "Horizontal Price Line",
    val timestamp: Long = System.currentTimeMillis(),
    val message: String = ""
) {
    val isCrossAbove: Boolean get() = direction.equals("CROSS_ABOVE", ignoreCase = true)
    val isCrossBelow: Boolean get() = direction.equals("CROSS_BELOW", ignoreCase = true)

    val formattedTarget: String get() = String.format(java.util.Locale.US, "%.2f", targetPrice)
    val formattedCurrent: String get() = String.format(java.util.Locale.US, "%.2f", currentPrice)

    companion object {
        fun fromJson(jsonStr: String): PriceAlertEvent? {
            return try {
                val obj = JSONObject(jsonStr)
                PriceAlertEvent(
                    lineId = obj.optString("lineId", "alert_line"),
                    targetPrice = obj.optDouble("targetPrice", 0.0),
                    currentPrice = obj.optDouble("currentPrice", 0.0),
                    previousPrice = obj.optDouble("previousPrice", 0.0),
                    direction = obj.optString("direction", "CROSS"),
                    title = obj.optString("title", "Horizontal Price Line"),
                    timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                    message = obj.optString("message", "")
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
