package com.example.core.analysis.levels

import com.example.core.model.analysis.SupportResistanceLevel
import com.example.core.model.analysis.SupportResistanceResult
import com.example.core.model.chart.Candle
import kotlin.math.abs
import kotlin.math.min

/**
 * Module #6 — Support & Resistance Engine.
 * Calculates mathematical S/R levels from real candle price history:
 * - Swing High / Low confluence clusters
 * - Volume / Pivot reaction points
 * - Distance from current price ($ and %)
 * - Nearest support and resistance identification
 */
object SupportResistanceEngine {

    fun calculateLevels(candles: List<Candle>): SupportResistanceResult {
        if (candles.isEmpty()) {
            return SupportResistanceResult(
                supportLevels = emptyList(),
                resistanceLevels = emptyList(),
                nearestSupport = null,
                nearestResistance = null,
                currentPrice = 0.0,
                rangeStatus = "No candle data available"
            )
        }

        val currentPrice = candles.last().close
        val lookback = min(candles.size, 50)
        val sample = candles.takeLast(lookback)

        // Raw pivot candidate levels from highs and lows
        val pivotHighs = mutableListOf<Double>()
        val pivotLows = mutableListOf<Double>()

        for (i in 1 until sample.size - 1) {
            val prev = sample[i - 1]
            val curr = sample[i]
            val next = sample[i + 1]

            if (curr.high >= prev.high && curr.high >= next.high) {
                pivotHighs.add(curr.high)
            }
            if (curr.low <= prev.low && curr.low <= next.low) {
                pivotLows.add(curr.low)
            }
        }

        // Cluster candidate levels within 0.25% threshold
        val threshold = currentPrice * 0.0025

        fun clusterLevels(raw: List<Double>, isSupport: Boolean): List<SupportResistanceLevel> {
            if (raw.isEmpty()) return emptyList()
            val sorted = raw.sorted()
            val clusters = mutableListOf<MutableList<Double>>()

            for (price in sorted) {
                val existing = clusters.find { group -> abs(group.average() - price) <= threshold }
                if (existing != null) {
                    existing.add(price)
                } else {
                    clusters.add(mutableListOf(price))
                }
            }

            return clusters.map { group ->
                val avgPrice = group.average()
                val touches = group.size
                val strength = when {
                    touches >= 3 -> "Major"
                    touches == 2 -> "Moderate"
                    else -> "Minor"
                }
                val distAbs = abs(currentPrice - avgPrice)
                val distPct = if (currentPrice > 0) (distAbs / currentPrice) * 100.0 else 0.0

                SupportResistanceLevel(
                    price = avgPrice,
                    isSupport = isSupport,
                    strength = strength,
                    touches = touches,
                    distancePct = distPct,
                    distanceAbsolute = distAbs
                )
            }
        }

        val rawSupports = clusterLevels(pivotLows.filter { it <= currentPrice }, isSupport = true)
            .sortedBy { it.distanceAbsolute } // nearest support first
        val rawResistances = clusterLevels(pivotHighs.filter { it >= currentPrice }, isSupport = false)
            .sortedBy { it.distanceAbsolute } // nearest resistance first

        val allSupports = if (rawSupports.isEmpty() && sample.isNotEmpty()) {
            val minLow = sample.minOf { it.low }
            val dist = (currentPrice - minLow).coerceAtLeast(0.0)
            val distPct = if (currentPrice > 0) (dist / currentPrice) * 100.0 else 0.0
            listOf(
                SupportResistanceLevel(
                    price = minLow,
                    isSupport = true,
                    strength = "Swing Low",
                    touches = 1,
                    distancePct = distPct,
                    distanceAbsolute = dist
                )
            )
        } else rawSupports

        val allResistances = if (rawResistances.isEmpty() && sample.isNotEmpty()) {
            val maxHigh = sample.maxOf { it.high }
            val dist = (maxHigh - currentPrice).coerceAtLeast(0.0)
            val distPct = if (currentPrice > 0) (dist / currentPrice) * 100.0 else 0.0
            listOf(
                SupportResistanceLevel(
                    price = maxHigh,
                    isSupport = false,
                    strength = "Swing High",
                    touches = 1,
                    distancePct = distPct,
                    distanceAbsolute = dist
                )
            )
        } else rawResistances

        val nearestSup = allSupports.firstOrNull()
        val nearestRes = allResistances.firstOrNull()

        val rangeStatus = if (nearestSup != null && nearestRes != null) {
            "Oscillating between Support $%.2f (-%.2f%%) and Resistance $%.2f (+%.2f%%)".format(
                nearestSup.price, nearestSup.distancePct,
                nearestRes.price, nearestRes.distancePct
            )
        } else if (nearestSup != null) {
            "Testing near Support at $%.2f (-%.2f%%)".format(nearestSup.price, nearestSup.distancePct)
        } else if (nearestRes != null) {
            "Approaching Resistance at $%.2f (+%.2f%%)".format(nearestRes.price, nearestRes.distancePct)
        } else {
            "S/R consolidation zone around $%.2f".format(currentPrice)
        }

        return SupportResistanceResult(
            supportLevels = allSupports.take(4),
            resistanceLevels = allResistances.take(4),
            nearestSupport = nearestSup,
            nearestResistance = nearestRes,
            currentPrice = currentPrice,
            rangeStatus = rangeStatus
        )
    }
}
