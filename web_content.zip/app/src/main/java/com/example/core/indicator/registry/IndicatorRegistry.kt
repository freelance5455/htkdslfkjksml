package com.example.core.indicator.registry

import com.example.core.model.indicator.IndicatorCategory
import com.example.core.model.indicator.IndicatorDefinition
import com.example.core.model.indicator.IndicatorParameters
import com.example.core.model.indicator.IndicatorSource

/**
 * Extensible central registry for all technical indicators available in IQTrade Pro.
 * Provides lookup by code, category filtering, search, and parameter presets.
 */
object IndicatorRegistry {

    private val allDefinitions = listOf(
        // TREND INDICATORS & MOVING AVERAGES
        IndicatorDefinition(
            code = "EMA",
            name = "Exponential Moving Average",
            category = IndicatorCategory.MOVING_AVERAGE,
            description = "Weighted moving average giving exponentially higher weight to recent prices for responsive trend following.",
            defaultParameters = IndicatorParameters(period = 20, source = IndicatorSource.CLOSE),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "SMA",
            name = "Simple Moving Average",
            category = IndicatorCategory.MOVING_AVERAGE,
            description = "Arithmetic mean of closing prices over a specified period, smoothing out short-term price fluctuations.",
            defaultParameters = IndicatorParameters(period = 50, source = IndicatorSource.CLOSE),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "WMA",
            name = "Weighted Moving Average",
            category = IndicatorCategory.MOVING_AVERAGE,
            description = "Linearly weighted moving average giving linearly decreasing weights to older data points.",
            defaultParameters = IndicatorParameters(period = 20, source = IndicatorSource.CLOSE),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "HMA",
            name = "Hull Moving Average",
            category = IndicatorCategory.MOVING_AVERAGE,
            description = "Alan Hull's extremely fast and smooth moving average that virtually eliminates lag while improving smoothing.",
            defaultParameters = IndicatorParameters(period = 16, source = IndicatorSource.CLOSE),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "DEMA",
            name = "Double Exponential Moving Average",
            category = IndicatorCategory.MOVING_AVERAGE,
            description = "Composite moving average that calculates 2*EMA - EMA(EMA) to drastically reduce lag.",
            defaultParameters = IndicatorParameters(period = 20, source = IndicatorSource.CLOSE),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "TEMA",
            name = "Triple Exponential Moving Average",
            category = IndicatorCategory.MOVING_AVERAGE,
            description = "Triple-smoothed EMA designed to filter out market noise and inertia with near-zero lag.",
            defaultParameters = IndicatorParameters(period = 20, source = IndicatorSource.CLOSE),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "SUPERTREND",
            name = "Supertrend",
            category = IndicatorCategory.TREND,
            description = "Trend-following indicator using ATR to construct dynamic trailing support and resistance stops.",
            defaultParameters = IndicatorParameters(period = 10, multiplier = 3.0),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "PSAR",
            name = "Parabolic SAR",
            category = IndicatorCategory.TREND,
            description = "J. Welles Wilder's Stop and Reverse trailing system trailing prices in high-momentum trends.",
            defaultParameters = IndicatorParameters(step = 0.02, maxStep = 0.20),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "AROON",
            name = "Aroon Indicator",
            category = IndicatorCategory.TREND,
            description = "Measures time between highs and lows over a period to determine if a trend is starting or consolidating.",
            defaultParameters = IndicatorParameters(period = 25),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "ADX",
            name = "Average Directional Index",
            category = IndicatorCategory.TREND,
            description = "Wilder's non-directional trend strength quantifier with directional movement indicators (DI+ and DI-).",
            defaultParameters = IndicatorParameters(period = 14),
            isOverlayOnMainChart = false
        ),

        // MOMENTUM INDICATORS
        IndicatorDefinition(
            code = "RSI",
            name = "Relative Strength Index",
            category = IndicatorCategory.MOMENTUM,
            description = "Wilder's momentum oscillator measuring the speed and velocity of directional price movements.",
            defaultParameters = IndicatorParameters(period = 14, overboughtLevel = 70.0, oversoldLevel = 30.0),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "STOCH",
            name = "Stochastic Oscillator",
            category = IndicatorCategory.MOMENTUM,
            description = "George Lane's momentum oscillator comparing close to the high-low range over a specified period.",
            defaultParameters = IndicatorParameters(period = 14, secondaryPeriod = 3, signalPeriod = 3),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "WPR",
            name = "Williams %R",
            category = IndicatorCategory.MOMENTUM,
            description = "Larry Williams' negative scale (0 to -100) momentum indicator reflecting market extreme levels.",
            defaultParameters = IndicatorParameters(period = 14),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "ROC",
            name = "Rate of Change",
            category = IndicatorCategory.MOMENTUM,
            description = "Pure momentum oscillator measuring percentage price change between current price and n periods ago.",
            defaultParameters = IndicatorParameters(period = 12),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "CCI",
            name = "Commodity Channel Index",
            category = IndicatorCategory.MOMENTUM,
            description = "Donald Lambert's oscillator evaluating price deviation from its statistical moving average mean.",
            defaultParameters = IndicatorParameters(period = 20),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "CMO",
            name = "Chande Momentum Oscillator",
            category = IndicatorCategory.MOMENTUM,
            description = "Tushar Chande's momentum metric calculated on unsmoothed sum of higher closes vs lower closes.",
            defaultParameters = IndicatorParameters(period = 14),
            isOverlayOnMainChart = false
        ),

        // OSCILLATORS
        IndicatorDefinition(
            code = "MACD",
            name = "Moving Average Convergence Divergence",
            category = IndicatorCategory.OSCILLATOR,
            description = "Gerald Appel's trend-following momentum oscillator consisting of MACD line, signal line, and histogram.",
            defaultParameters = IndicatorParameters(period = 12, secondaryPeriod = 26, signalPeriod = 9),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "AO",
            name = "Awesome Oscillator",
            category = IndicatorCategory.OSCILLATOR,
            description = "Bill Williams' market momentum oscillator reflecting difference between 34-period and 5-period SMA of bar midpoints.",
            defaultParameters = IndicatorParameters(period = 5, secondaryPeriod = 34),
            isOverlayOnMainChart = false
        ),

        // VOLATILITY & CHANNELS
        IndicatorDefinition(
            code = "BOLL",
            name = "Bollinger Bands",
            category = IndicatorCategory.VOLATILITY,
            description = "John Bollinger's volatility envelope consisting of a moving average middle line and standard deviation bands.",
            defaultParameters = IndicatorParameters(period = 20, stdDev = 2.0),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "ATR",
            name = "Average True Range",
            category = IndicatorCategory.VOLATILITY,
            description = "Wilder's measure of volatility accounting for overnight price gaps between consecutive trading sessions.",
            defaultParameters = IndicatorParameters(period = 14),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "KC",
            name = "Keltner Channels",
            category = IndicatorCategory.CHANNEL,
            description = "Chester Keltner's volatility channels based on an EMA centerline and ATR distance bands.",
            defaultParameters = IndicatorParameters(period = 20, multiplier = 2.0),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "DC",
            name = "Donchian Channels",
            category = IndicatorCategory.CHANNEL,
            description = "Richard Donchian's breakout channels formed by the highest high and lowest low over the lookback period.",
            defaultParameters = IndicatorParameters(period = 20),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "STDDEV",
            name = "Standard Deviation",
            category = IndicatorCategory.VOLATILITY,
            description = "Statistical dispersion metric quantifying the volatility of price variations around the mean.",
            defaultParameters = IndicatorParameters(period = 20),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "ENV",
            name = "Moving Average Envelope",
            category = IndicatorCategory.CHANNEL,
            description = "Price bands plotted above and below a moving average by a fixed percentage distance.",
            defaultParameters = IndicatorParameters(period = 20, multiplier = 2.5),
            isOverlayOnMainChart = true
        ),

        // VOLUME INDICATORS
        IndicatorDefinition(
            code = "VWAP",
            name = "Volume Weighted Average Price",
            category = IndicatorCategory.VOLUME,
            description = "Benchmark representing the true average price a security has traded at throughout the session, weighted by volume.",
            defaultParameters = IndicatorParameters(period = 1),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "OBV",
            name = "On-Balance Volume",
            category = IndicatorCategory.VOLUME,
            description = "Joe Granville's cumulative volume indicator relating price flow to trading volume pressure.",
            defaultParameters = IndicatorParameters(period = 14),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "CMF",
            name = "Chaikin Money Flow",
            category = IndicatorCategory.VOLUME,
            description = "Marc Chaikin's volume-weighted average of accumulation and distribution over a specified period.",
            defaultParameters = IndicatorParameters(period = 20),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "MFI",
            name = "Money Flow Index",
            category = IndicatorCategory.VOLUME,
            description = "Volume-weighted RSI comparing positive and negative money flow to identify exhaustion levels.",
            defaultParameters = IndicatorParameters(period = 14, overboughtLevel = 80.0, oversoldLevel = 20.0),
            isOverlayOnMainChart = false
        ),
        IndicatorDefinition(
            code = "VOLOSC",
            name = "Volume Oscillator",
            category = IndicatorCategory.VOLUME,
            description = "Difference between two volume moving averages expressed as a percentage of the faster volume average.",
            defaultParameters = IndicatorParameters(period = 5, secondaryPeriod = 20),
            isOverlayOnMainChart = false
        ),

        // SUPPORT / RESISTANCE & BILL WILLIAMS
        IndicatorDefinition(
            code = "PIVOT",
            name = "Classic Pivot Points",
            category = IndicatorCategory.SUPPORT_RESISTANCE,
            description = "Standard floor-trader pivot levels (Pivot, S1, S2, R1, R2) calculated from high, low, and close.",
            defaultParameters = IndicatorParameters(period = 1),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "FIBPIVOT",
            name = "Fibonacci Pivot Points",
            category = IndicatorCategory.SUPPORT_RESISTANCE,
            description = "Floor pivots incorporating key golden Fibonacci ratios (0.382, 0.618, 1.000) for support and resistance.",
            defaultParameters = IndicatorParameters(period = 1),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "HLBANDS",
            name = "High/Low Bands",
            category = IndicatorCategory.SUPPORT_RESISTANCE,
            description = "Dynamic upper and lower boundary lines tracking highest peaks and lowest valleys.",
            defaultParameters = IndicatorParameters(period = 20),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "ALLIGATOR",
            name = "Bill Williams Alligator",
            category = IndicatorCategory.BILL_WILLIAMS,
            description = "Alligator lines: Jaw (13 SMA), Teeth (8 SMA), and Lips (5 SMA) smoothed and shifted into the future.",
            defaultParameters = IndicatorParameters(period = 13, secondaryPeriod = 8, signalPeriod = 5),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "FRACTALS",
            name = "Bill Williams Fractals",
            category = IndicatorCategory.BILL_WILLIAMS,
            description = "5-bar reversal patterns marking local price extremes across market highs and lows.",
            defaultParameters = IndicatorParameters(period = 5),
            isOverlayOnMainChart = true
        ),

        // STATISTICAL / ADVANCED
        IndicatorDefinition(
            code = "LINREG",
            name = "Linear Regression Curve",
            category = IndicatorCategory.STATISTICAL,
            description = "Mathematical line of best fit through closing prices over the lookback window using least squares regression.",
            defaultParameters = IndicatorParameters(period = 20),
            isOverlayOnMainChart = true
        ),
        IndicatorDefinition(
            code = "HISTVOL",
            name = "Historical Volatility",
            category = IndicatorCategory.STATISTICAL,
            description = "Annualized standard deviation of logarithmic returns over a historical window.",
            defaultParameters = IndicatorParameters(period = 20),
            isOverlayOnMainChart = false
        )
    )

    /**
     * Complete list of registered indicators.
     */
    fun getAll(): List<IndicatorDefinition> = allDefinitions

    /**
     * Find definition by code.
     */
    fun findByCode(code: String): IndicatorDefinition? {
        return allDefinitions.firstOrNull { it.code.equals(code, ignoreCase = true) }
    }

    /**
     * Filter definitions by category.
     */
    fun getByCategory(category: IndicatorCategory): List<IndicatorDefinition> {
        return allDefinitions.filter { it.category == category }
    }

    /**
     * Search definitions by text query (matches name, code, or description).
     */
    fun search(query: String): List<IndicatorDefinition> {
        val clean = query.trim().lowercase()
        if (clean.isEmpty()) return allDefinitions
        return allDefinitions.filter {
            it.code.lowercase().contains(clean) ||
            it.name.lowercase().contains(clean) ||
            it.category.displayName.lowercase().contains(clean) ||
            it.description.lowercase().contains(clean)
        }
    }
}
