package com.example.core.model

/**
 * Authoritative Live Trading Permission State for IQTrade Pro (Module #9).
 *
 * STRICT INVARIANTS:
 * - Default state is ALWAYS [LIVE_TRADING_OFF].
 * - Resets to [LIVE_TRADING_OFF] on app restart, process death, market change, symbol change.
 * - Explicit user safety authorization is strictly required to transition to [LIVE_TRADING_ENABLED].
 * - Disabling Live Trading immediately prevents any new live order submission.
 */
enum class LiveTradingState {
    LIVE_TRADING_OFF,
    LIVE_TRADING_ENABLED;

    val isEnabled: Boolean get() = this == LIVE_TRADING_ENABLED
}
