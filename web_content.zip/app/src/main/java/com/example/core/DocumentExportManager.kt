package com.example.core

import android.content.Context
import android.net.Uri
import com.example.data.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ExtractedCodeBlock(
    val language: String,
    val code: String
)

enum class ExportFormat(val extension: String, val mimeType: String) {
    ZIP("zip", "application/zip"),
    HTML("html", "text/html"),
    MARKDOWN("md", "text/markdown"),
    TEXT("txt", "text/plain")
}

object DocumentExportManager {

    private val codeFenceRegex = Regex("```([a-zA-Z0-9_+.-]*)\\s*\\n([\\s\\S]*?)```")

    fun extractCodeBlocks(markdown: String): List<ExtractedCodeBlock> {
        return codeFenceRegex.findAll(markdown).map { match ->
            val lang = match.groupValues[1].trim().lowercase().ifBlank { "txt" }
            val code = match.groupValues[2].trimEnd()
            ExtractedCodeBlock(lang, code)
        }.toList()
    }

    suspend fun writeExportToUri(
        context: Context,
        uri: Uri,
        format: ExportFormat,
        title: String,
        messages: List<ChatMessage>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openOutputStream(uri)?.use { out ->
                when (format) {
                    ExportFormat.ZIP -> writeZipWithRootIndexHtml(out, title, messages)
                    ExportFormat.HTML -> {
                        val html = buildStandaloneHtml(title, messages)
                        out.write(html.toByteArray(Charsets.UTF_8))
                    }
                    ExportFormat.MARKDOWN -> {
                        val md = buildMarkdownDocument(title, messages)
                        out.write(md.toByteArray(Charsets.UTF_8))
                    }
                    ExportFormat.TEXT -> {
                        val txt = buildPlainTextDocument(title, messages)
                        out.write(txt.toByteArray(Charsets.UTF_8))
                    }
                }
            } ?: return@withContext Result.failure(IllegalStateException("Could not open output stream"))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Writes a ZIP archive that ALWAYS places index.html at the root of the archive ("index.html").
     * If the conversation contains HTML/CSS/JS code blocks, they are packaged cleanly as web assets;
     * otherwise a styled interactive index.html archive of the conversation & code artifacts is generated.
     */
    internal fun writeZipWithRootIndexHtml(
        outputStream: java.io.OutputStream,
        title: String,
        messages: List<ChatMessage>
    ) {
        val allBlocks = messages.flatMap { extractCodeBlocks(it.text) }
        val htmlBlock = allBlocks.lastOrNull { it.language in setOf("html", "htm") }
        val cssBlocks = allBlocks.filter { it.language == "css" }
        val jsBlocks = allBlocks.filter { it.language in setOf("js", "javascript") }
        val otherBlocks = allBlocks.filterNot {
            it.language in setOf("html", "htm", "css", "js", "javascript")
        }

        val rootIndexHtml = if (htmlBlock != null) {
            htmlBlock.code
        } else {
            buildStandaloneHtml(title, messages)
        }

        ZipOutputStream(BufferedOutputStream(outputStream)).use { zip ->
            // Mandatory root entry: index.html
            zip.putNextEntry(ZipEntry("index.html"))
            zip.write(rootIndexHtml.toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            if (cssBlocks.isNotEmpty()) {
                zip.putNextEntry(ZipEntry("styles.css"))
                zip.write(cssBlocks.joinToString("\n\n") { it.code }.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }

            if (jsBlocks.isNotEmpty()) {
                zip.putNextEntry(ZipEntry("script.js"))
                zip.write(jsBlocks.joinToString("\n\n") { it.code }.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }

            otherBlocks.forEachIndexed { index, block ->
                val ext = mapLangToExtension(block.language)
                val entryName = "snippets/snippet_${index + 1}.$ext"
                zip.putNextEntry(ZipEntry(entryName))
                zip.write(block.code.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }

            zip.putNextEntry(ZipEntry("conversation.md"))
            zip.write(buildMarkdownDocument(title, messages).toByteArray(Charsets.UTF_8))
            zip.closeEntry()
        }
    }

    private fun mapLangToExtension(lang: String): String = when (lang) {
        "kotlin", "kt" -> "kt"
        "python", "py" -> "py"
        "java" -> "java"
        "typescript", "ts" -> "ts"
        "json" -> "json"
        "xml" -> "xml"
        "sql" -> "sql"
        "bash", "sh" -> "sh"
        else -> "txt"
    }

    fun buildMarkdownDocument(title: String, messages: List<ChatMessage>): String {
        val sb = StringBuilder()
        sb.append("# ").append(title).append("\n\n")
        for (msg in messages) {
            val author = if (msg.role == "user") "User" else "FLAMI AI"
            sb.append("## ").append(author).append("\n\n")
            sb.append(msg.text.trim()).append("\n\n---\n\n")
        }
        return sb.toString()
    }

    fun buildPlainTextDocument(title: String, messages: List<ChatMessage>): String {
        val sb = StringBuilder()
        sb.append(title).append("\n")
        sb.append("=".repeat(title.length.coerceAtLeast(12))).append("\n\n")
        for (msg in messages) {
            val author = if (msg.role == "user") "[USER]" else "[FLAMI AI]"
            sb.append(author).append("\n").append(msg.text.trim()).append("\n\n")
        }
        return sb.toString()
    }

    fun buildStandaloneHtml(title: String, messages: List<ChatMessage>): String {
        val escapedTitle = escapeHtml(title)
        val cards = messages.joinToString("\n") { msg ->
            val roleClass = if (msg.role == "user") "user" else "model"
            val roleLabel = if (msg.role == "user") "You" else "FLAMI AI"
            val body = escapeHtml(msg.text.trim()).replace("\n", "<br/>")
            """
            <article class="msg $roleClass">
              <div class="role">$roleLabel</div>
              <div class="body">$body</div>
            </article>
            """.trimIndent()
        }
        return """
            <!DOCTYPE html>
            <html lang="en">
            <head>
              <meta charset="UTF-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1.0" />
              <title>$escapedTitle — FLAMI AI</title>
              <style>
                :root { color-scheme: dark; }
                body {
                  margin: 0; font-family: system-ui, -apple-system, sans-serif;
                  background: #0b0f1a; color: #e2e8f0; line-height: 1.6;
                }
                main { max-width: 820px; margin: 0 auto; padding: 32px 20px; }
                h1 { font-size: 1.6rem; margin-bottom: 24px; color: #fb923c; }
                .msg {
                  padding: 16px 20px; border-radius: 16px; margin-bottom: 16px;
                  border: 1px solid rgba(148, 163, 184, 0.16);
                }
                .msg.user { background: #1e293b; }
                .msg.model { background: #111827; border-color: rgba(251, 146, 60, 0.25); }
                .role {
                  font-size: 0.78rem; font-weight: 700; text-transform: uppercase;
                  letter-spacing: 0.08em; color: #38bdf8; margin-bottom: 6px;
                }
                .msg.user .role { color: #fb923c; }
                .body { white-space: normal; word-break: break-word; }
              </style>
            </head>
            <body>
              <main>
                <h1>$escapedTitle</h1>
                $cards
              </main>
            </body>
            </html>
        """.trimIndent()
    }

    private fun escapeHtml(input: String): String {
        return input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
    }
}
