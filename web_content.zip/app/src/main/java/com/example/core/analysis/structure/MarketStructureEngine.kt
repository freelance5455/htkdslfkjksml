package com.example.core.analysis.structure

import com.example.core.model.analysis.MarketStructureResult
import com.example.core.model.analysis.MarketStructureState
import com.example.core.model.analysis.MarketTrendType
import com.example.core.model.analysis.SwingPoint
import com.example.core.model.analysis.SwingType
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import kotlin.math.max
import kotlin.math.min

/**
 * Module #6 — Market Trend & Structure Engine.
 * Analyzes market structure from validated swing points using real OHLCV data:
 * - Detects Higher Highs (HH), Higher Lows (HL), Lower Highs (LH), Lower Lows (LL)
 * - Identifies Uptrend, Downtrend, or Range/Sideways
 * - Classifies dynamic state: Breakout, Breakdown, Trend Continuation, or Possible Reversal
 * - Identifies key structural swing high and low reference levels
 */
object MarketStructureEngine {

    fun analyzeStructure(candles: List<Candle>): MarketStructureResult {
        if (candles.size < 10) {
            val lastPrice = candles.lastOrNull()?.close ?: 0.0
            return MarketStructureResult(
                trend = MarketTrendType.RANGE_SIDEWAYS,
                state = MarketStructureState.CONSOLIDATION,
                structuralBias = IndicatorDirection.NEUTRAL,
                recentSwings = emptyList(),
                keySwingHigh = lastPrice,
                keySwingLow = lastPrice,
                higherHighsCount = 0,
                higherLowsCount = 0,
                lowerHighsCount = 0,
                lowerLowsCount = 0,
                supportingInformation = "Insufficient candle history (< 10 bars) for market structure validation"
            )
        }

        val swingHighs = mutableListOf<SwingPoint>()
        val swingLows = mutableListOf<SwingPoint>()

        // 3-bar swing detection (local extrema comparing i-1, i, i+1 or lookback 2)
        val lookback = min(candles.size, 40)
        val sample = candles.takeLast(lookback)

        for (i in 2 until sample.size - 1) {
            val curr = sample[i]
            val prev1 = sample[i - 1]
            val prev2 = sample[i - 2]
            val next = sample[i + 1]

            // Swing High candidate
            if (curr.high > prev1.high && curr.high > prev2.high && curr.high >= next.high) {
                swingHighs.add(SwingPoint(index = i, timestamp = curr.timestamp, price = curr.high, isHigh = true))
            }
            // Swing Low candidate
            if (curr.low < prev1.low && curr.low < prev2.low && curr.low <= next.low) {
                swingLows.add(SwingPoint(index = i, timestamp = curr.timestamp, price = curr.low, isHigh = false))
            }
        }

        // Tag swings with HH / LH and HL / LL
        var hhCount = 0
        var lhCount = 0
        val taggedHighs = mutableListOf<SwingPoint>()
        for (j in swingHighs.indices) {
            if (j == 0) {
                taggedHighs.add(swingHighs[j])
            } else {
                val isHH = swingHighs[j].price > swingHighs[j - 1].price
                if (isHH) hhCount++ else lhCount++
                taggedHighs.add(
                    swingHighs[j].copy(swingType = if (isHH) SwingType.HIGHER_HIGH else SwingType.LOWER_HIGH)
                )
            }
        }

        var hlCount = 0
        var llCount = 0
        val taggedLows = mutableListOf<SwingPoint>()
        for (j in swingLows.indices) {
            if (j == 0) {
                taggedLows.add(swingLows[j])
            } else {
                val isHL = swingLows[j].price > swingLows[j - 1].price
                if (isHL) hlCount++ else llCount++
                taggedLows.add(
                    swingLows[j].copy(swingType = if (isHL) SwingType.HIGHER_LOW else SwingType.LOWER_LOW)
                )
            }
        }

        val allSwings = (taggedHighs + taggedLows).sortedBy { it.index }
        val currentPrice = candles.last().close
        val keyHigh = taggedHighs.lastOrNull()?.price ?: sample.maxOf { it.high }
        val keyLow = taggedLows.lastOrNull()?.price ?: sample.minOf { it.low }

        // Determine Market Trend
        val trend = when {
            hhCount >= lhCount && hlCount >= llCount && (hhCount + hlCount > 0) -> MarketTrendType.UPTREND
            lhCount >= hhCount && llCount >= hlCount && (lhCount + llCount > 0) -> MarketTrendType.DOWNTREND
            sample.last().close > sample.first().close * 1.005 -> MarketTrendType.UPTREND
            sample.last().close < sample.first().close * 0.995 -> MarketTrendType.DOWNTREND
            else -> MarketTrendType.RANGE_SIDEWAYS
        }

        // Determine Structural Dynamic State
        val state = when {
            currentPrice > keyHigh -> MarketStructureState.BREAKOUT
            currentPrice < keyLow -> MarketStructureState.BREAKDOWN
            trend == MarketTrendType.UPTREND && currentPrice > keyLow && currentPrice >= sample.last().open ->
                MarketStructureState.TREND_CONTINUATION
            trend == MarketTrendType.DOWNTREND && currentPrice < keyHigh && currentPrice <= sample.last().open ->
                MarketStructureState.TREND_CONTINUATION
            trend == MarketTrendType.UPTREND && currentPrice < (taggedLows.lastOrNull()?.price ?: keyLow) ->
                MarketStructureState.POSSIBLE_TREND_REVERSAL
            trend == MarketTrendType.DOWNTREND && currentPrice > (taggedHighs.lastOrNull()?.price ?: keyHigh) ->
                MarketStructureState.POSSIBLE_TREND_REVERSAL
            else -> MarketStructureState.CONSOLIDATION
        }

        val structuralBias = when {
            state == MarketStructureState.BREAKOUT -> IndicatorDirection.BULLISH
            state == MarketStructureState.BREAKDOWN -> IndicatorDirection.BEARISH
            trend == MarketTrendType.UPTREND -> IndicatorDirection.BULLISH
            trend == MarketTrendType.DOWNTREND -> IndicatorDirection.BEARISH
            else -> IndicatorDirection.NEUTRAL
        }

        val info = buildString {
            append("${trend.label}: ")
            when (state) {
                MarketStructureState.BREAKOUT -> append("Bullish breakout above key swing high ($%.2f).".format(keyHigh))
                MarketStructureState.BREAKDOWN -> append("Bearish breakdown below key swing low ($%.2f).".format(keyLow))
                MarketStructureState.TREND_CONTINUATION -> append("Structure continuation intact with $hhCount HH, $hlCount HL.")
                MarketStructureState.POSSIBLE_TREND_REVERSAL -> append("Warning: Potential structure shift/reversal detected against prevailing swing series.")
                MarketStructureState.CONSOLIDATION -> append("Price consolidating between $%.2f (Low) and $%.2f (High).".format(keyLow, keyHigh))
            }
        }

        return MarketStructureResult(
            trend = trend,
            state = state,
            structuralBias = structuralBias,
            recentSwings = allSwings,
            keySwingHigh = keyHigh,
            keySwingLow = keyLow,
            higherHighsCount = hhCount,
            higherLowsCount = hlCount,
            lowerHighsCount = lhCount,
            lowerLowsCount = llCount,
            supportingInformation = info
        )
    }
}
