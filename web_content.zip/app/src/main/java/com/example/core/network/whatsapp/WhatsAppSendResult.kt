package com.example.core.network.whatsapp

/**
 * Result state wrapper for WhatsApp Cloud API message delivery.
 */
sealed class WhatsAppSendResult {
    data class Success(val messageId: String, val recipient: String) : WhatsAppSendResult()
    data class Failure(val errorMessage: String, val httpCode: Int? = null) : WhatsAppSendResult()
}
