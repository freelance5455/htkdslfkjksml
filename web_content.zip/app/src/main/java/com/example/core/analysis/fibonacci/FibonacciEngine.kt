package com.example.core.analysis.fibonacci

import com.example.core.model.analysis.FibonacciAnalysisResult
import com.example.core.model.analysis.FibonacciLevel
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import kotlin.math.abs
import kotlin.math.min

/**
 * Module #6 — Fibonacci Analysis Engine.
 * Calculates mathematical Fibonacci retracement levels from validated swing points:
 * 0.0%, 23.6%, 38.2%, 50.0%, 61.8% (Golden Pocket), 78.6%, 100.0%.
 */
object FibonacciEngine {

    fun calculateFibonacci(candles: List<Candle>): FibonacciAnalysisResult {
        if (candles.size < 10) {
            val lastClose = candles.lastOrNull()?.close ?: 0.0
            return FibonacciAnalysisResult(
                swingHigh = lastClose,
                swingLow = lastClose,
                isUptrendRetracement = true,
                levels = emptyList(),
                currentZone = "Insufficient Data",
                nearestLevel = null,
                contextBias = IndicatorDirection.NEUTRAL,
                explanation = "Minimum 10 candles required for swing anchor validation."
            )
        }

        val lookback = min(candles.size, 60)
        val sample = candles.takeLast(lookback)

        // Find absolute swing high and swing low within lookback window
        var highCandle = sample.first()
        var lowCandle = sample.first()

        sample.forEach { c ->
            if (c.high > highCandle.high) highCandle = c
            if (c.low < lowCandle.low) lowCandle = c
        }

        val swingHigh = highCandle.high
        val swingLow = lowCandle.low
        val range = (swingHigh - swingLow).coerceAtLeast(0.0001)
        val currentPrice = candles.last().close

        // Determine if recent leg is Uptrend Retracement or Downtrend Retracement
        // If swing low occurred before swing high -> Uptrend move, measuring pullback from high
        val isUptrend = lowCandle.timestamp <= highCandle.timestamp

        // Canonical Fibonacci Ratios
        val ratios = listOf(
            0.0 to "0.0% (Peak/Trough)",
            0.236 to "23.6% (Shallow)",
            0.382 to "38.2% (Standard)",
            0.500 to "50.0% (Equilibrium)",
            0.618 to "61.8% (Golden Pocket)",
            0.786 to "78.6% (Deep Retracement)",
            1.000 to "100.0% (Base Anchor)"
        )

        val levels = ratios.map { (ratio, label) ->
            val price = if (isUptrend) {
                swingHigh - (range * ratio)
            } else {
                swingLow + (range * ratio)
            }
            FibonacciLevel(
                ratio = ratio,
                percentageLabel = label,
                price = price,
                isGoldenPocket = ratio == 0.618
            )
        }

        // Find nearest Fibonacci level
        val nearestLevel = levels.minByOrNull { abs(it.price - currentPrice) }

        // Determine current Zone
        val currentZone = when {
            currentPrice >= swingHigh -> "Above 0.0% Swing High (Expansion Zone)"
            currentPrice <= swingLow -> "Below 100.0% Swing Low (Breakdown Zone)"
            else -> {
                val upperLevel = levels.sortedByDescending { it.price }.find { it.price >= currentPrice }
                val lowerLevel = levels.sortedBy { it.price }.find { it.price <= currentPrice }
                if (upperLevel != null && lowerLevel != null) {
                    val upperStr = String.format(java.util.Locale.US, "$%.2f", upperLevel.price)
                    val lowerStr = String.format(java.util.Locale.US, "$%.2f", lowerLevel.price)
                    "Between ${upperLevel.percentageLabel.substringBefore(' ')} ($upperStr) and ${lowerLevel.percentageLabel.substringBefore(' ')} ($lowerStr)"
                } else {
                    val priceStr = String.format(java.util.Locale.US, "$%.2f", nearestLevel?.price ?: currentPrice)
                    "Retracement Zone near $priceStr"
                }
            }
        }

        // Context Bias
        val goldenPocket = levels.find { it.isGoldenPocket }?.price ?: (swingHigh - range * 0.618)
        val fiftyLevel = levels.find { it.ratio == 0.5 }?.price ?: (swingHigh - range * 0.5)

        val contextBias = if (isUptrend) {
            if (currentPrice >= fiftyLevel) IndicatorDirection.BULLISH
            else if (currentPrice >= goldenPocket) IndicatorDirection.BULLISH
            else IndicatorDirection.BEARISH
        } else {
            if (currentPrice <= fiftyLevel) IndicatorDirection.BEARISH
            else if (currentPrice <= goldenPocket) IndicatorDirection.BEARISH
            else IndicatorDirection.BULLISH
        }

        val swingHighStr = String.format(java.util.Locale.US, "$%.2f", swingHigh)
        val swingLowStr = String.format(java.util.Locale.US, "$%.2f", swingLow)
        val goldenPocketStr = String.format(java.util.Locale.US, "$%.2f", goldenPocket)

        val explanation = if (isUptrend) {
            val status = if (currentPrice >= goldenPocket) "Price respecting upper bullish structure" else "Deep pullback below 61.8 percent"
            "Uptrend anchor: High $swingHighStr, Low $swingLowStr. Golden Pocket (61.8%) at $goldenPocketStr. $status."
        } else {
            val status = if (currentPrice <= goldenPocket) "Price holding below resistance pocket" else "Retracement testing higher supply"
            "Downtrend anchor: Low $swingLowStr, High $swingHighStr. Golden Pocket (61.8%) at $goldenPocketStr. $status."
        }

        return FibonacciAnalysisResult(
            swingHigh = swingHigh,
            swingLow = swingLow,
            isUptrendRetracement = isUptrend,
            levels = levels,
            currentZone = currentZone,
            nearestLevel = nearestLevel,
            contextBias = contextBias,
            explanation = explanation
        )
    }
}
