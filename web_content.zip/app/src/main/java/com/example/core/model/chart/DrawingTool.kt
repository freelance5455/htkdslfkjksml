package com.example.core.model.chart

import org.json.JSONObject
import java.util.UUID

enum class DrawingType(val label: String) {
    NONE("Select / Pan"),
    HORIZONTAL_LINE("Horizontal Line"),
    TREND_LINE("Trend Line"),
    VERTICAL_LINE("Vertical Line"),
    SUPPORT_RESISTANCE_ZONE("Support / Resistance Zone"),
    FIBONACCI_RETRACEMENT("Fibonacci Retracement")
}

data class ChartDrawing(
    val id: String = UUID.randomUUID().toString(),
    val type: DrawingType,
    val symbolId: String,
    val timeframe: String,
    val price: Double = 0.0,
    val time: Long = 0L,
    val price1: Double = 0.0,
    val time1: Long = 0L,
    val price2: Double = 0.0,
    val time2: Long = 0L,
    val color: String = "#00E5FF",
    val lineWidth: Int = 2,
    val label: String = ""
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("type", type.name)
        obj.put("price", price)
        obj.put("time", time)
        obj.put("price1", price1)
        obj.put("time1", time1)
        obj.put("price2", price2)
        obj.put("time2", time2)
        obj.put("color", color)
        obj.put("lineWidth", lineWidth)
        obj.put("label", label)
        return obj
    }

    companion object {
        fun fromJson(obj: JSONObject, symbolId: String, timeframe: String): ChartDrawing {
            val typeStr = obj.optString("type", DrawingType.HORIZONTAL_LINE.name)
            val type = try { DrawingType.valueOf(typeStr) } catch (_: Exception) { DrawingType.HORIZONTAL_LINE }
            return ChartDrawing(
                id = obj.optString("id", UUID.randomUUID().toString()),
                type = type,
                symbolId = symbolId,
                timeframe = timeframe,
                price = obj.optDouble("price", 0.0),
                time = obj.optLong("time", 0L),
                price1 = obj.optDouble("price1", 0.0),
                time1 = obj.optLong("time1", 0L),
                price2 = obj.optDouble("price2", 0.0),
                time2 = obj.optLong("time2", 0L),
                color = obj.optString("color", "#00E5FF"),
                lineWidth = obj.optInt("lineWidth", 2),
                label = obj.optString("label", "")
            )
        }
    }
}
