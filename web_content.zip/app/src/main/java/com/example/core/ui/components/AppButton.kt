package com.example.core.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary

enum class ButtonStyle {
    PRIMARY,
    SUCCESS,
    DANGER,
    OUTLINE,
    GHOST
}

@Composable
fun AppButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: ButtonStyle = ButtonStyle.PRIMARY,
    enabled: Boolean = true,
    testTag: String = "app_button"
) {
    val minHeight = 48.dp

    when (style) {
        ButtonStyle.PRIMARY -> {
            Button(
                onClick = onClick,
                enabled = enabled,
                modifier = modifier
                    .defaultMinSize(minHeight = minHeight)
                    .testTag(testTag),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanAccent,
                    contentColor = Color(0xFF001F29),
                    disabledContainerColor = Color(0xFF1E2B45),
                    disabledContentColor = TextDisabled
                ),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
        ButtonStyle.SUCCESS -> {
            Button(
                onClick = onClick,
                enabled = enabled,
                modifier = modifier
                    .defaultMinSize(minHeight = minHeight)
                    .testTag(testTag),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BullGreen,
                    contentColor = Color(0xFF002214),
                    disabledContainerColor = Color(0xFF1E2B45),
                    disabledContentColor = TextDisabled
                ),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
        ButtonStyle.DANGER -> {
            Button(
                onClick = onClick,
                enabled = enabled,
                modifier = modifier
                    .defaultMinSize(minHeight = minHeight)
                    .testTag(testTag),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = BearRed,
                    contentColor = Color.White,
                    disabledContainerColor = Color(0xFF1E2B45),
                    disabledContentColor = TextDisabled
                ),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
        ButtonStyle.OUTLINE -> {
            OutlinedButton(
                onClick = onClick,
                enabled = enabled,
                modifier = modifier
                    .defaultMinSize(minHeight = minHeight)
                    .testTag(testTag),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, BorderSubtle),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = TextPrimary,
                    disabledContentColor = TextDisabled
                ),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(text, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            }
        }
        ButtonStyle.GHOST -> {
            TextButton(
                onClick = onClick,
                enabled = enabled,
                modifier = modifier
                    .defaultMinSize(minHeight = minHeight)
                    .testTag(testTag),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.textButtonColors(
                    contentColor = CyanAccent,
                    disabledContentColor = TextDisabled
                ),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(text, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            }
        }
    }
}
