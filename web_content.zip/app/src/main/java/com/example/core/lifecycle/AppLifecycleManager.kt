package com.example.core.lifecycle

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppLifecycleState {
    FOREGROUND_ACTIVE,
    BACKGROUND_PAUSED,
    DESTROYED
}

/**
 * Android lifecycle coordinator for trading services.
 * Prepares architecture for WebSocket pause/resume, reconnects on foreground,
 * and graceful cleanup on termination.
 */
class AppLifecycleManager : DefaultLifecycleObserver {

    private val _lifecycleState = MutableStateFlow(AppLifecycleState.FOREGROUND_ACTIVE)
    val lifecycleState: StateFlow<AppLifecycleState> = _lifecycleState.asStateFlow()

    override fun onResume(owner: LifecycleOwner) {
        _lifecycleState.value = AppLifecycleState.FOREGROUND_ACTIVE
    }

    override fun onPause(owner: LifecycleOwner) {
        _lifecycleState.value = AppLifecycleState.BACKGROUND_PAUSED
    }

    override fun onDestroy(owner: LifecycleOwner) {
        _lifecycleState.value = AppLifecycleState.DESTROYED
    }
}
