package com.example.core.model.chart

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class IndicatorType(
    val code: String,
    val title: String,
    val defaultPeriod: Int,
    val category: String,
    val description: String
) {
    EMA("EMA", "Exponential Moving Average", 20, "Moving Average", "Weighted moving average giving higher weight to recent prices."),
    SMA("SMA", "Simple Moving Average", 50, "Moving Average", "Arithmetic average of closing prices over a specified period."),
    WMA("WMA", "Weighted Moving Average", 20, "Moving Average", "Linearly weighted moving average emphasizing recent bars."),
    HMA("HMA", "Hull Moving Average", 16, "Moving Average", "Alan Hull's extremely responsive, low-lag moving average."),
    DEMA("DEMA", "Double Exponential Moving Average", 20, "Moving Average", "Composite double-smoothed EMA reducing price lag."),
    TEMA("TEMA", "Triple Exponential Moving Average", 20, "Moving Average", "Triple-smoothed EMA designed for high-frequency trends."),
    SUPERTREND("SUPERTREND", "Supertrend", 10, "Trend", "Dynamic trailing ATR-based stop and trend filter."),
    PSAR("PSAR", "Parabolic SAR", 2, "Trend", "Welles Wilder's Stop and Reverse trailing system."),
    AROON("AROON", "Aroon Indicator", 25, "Trend", "Measures time between highs and lows to detect trend beginnings."),
    ADX("ADX", "Average Directional Index", 14, "Trend", "Quantifies trend strength independent of direction."),
    BOLLINGER_BANDS("BOLL", "Bollinger Bands", 20, "Volatility", "Standard deviation bands around a moving average."),
    RSI("RSI", "Relative Strength Index", 14, "Momentum", "Momentum oscillator measuring speed and change of price moves."),
    MACD("MACD", "Moving Average Convergence Divergence", 12, "Momentum", "Trend-following momentum indicator."),
    STOCH("STOCH", "Stochastic Oscillator", 14, "Momentum", "Compares closing price to range over a specified period."),
    WPR("WPR", "Williams %R", 14, "Momentum", "Negative scale momentum oscillator indicating overbought/oversold levels."),
    ROC("ROC", "Rate of Change", 12, "Momentum", "Pure momentum oscillator measuring percentage price change."),
    CCI("CCI", "Commodity Channel Index", 20, "Momentum", "Measures price deviation from statistical moving average."),
    CMO("CMO", "Chande Momentum Oscillator", 14, "Momentum", "Momentum metric computed on unsmoothed sum of higher closes vs lower closes."),
    AO("AO", "Awesome Oscillator", 34, "Oscillator", "Bill Williams market momentum oscillator."),
    ATR("ATR", "Average True Range", 14, "Volatility", "Technical analysis volatility indicator."),
    KC("KC", "Keltner Channels", 20, "Channel", "Volatility channels based on EMA and Average True Range."),
    DC("DC", "Donchian Channels", 20, "Channel", "Highest high and lowest low bands over lookback window."),
    STDDEV("STDDEV", "Standard Deviation", 20, "Volatility", "Statistical volatility measurement of prices."),
    ENV("ENV", "Moving Average Envelope", 20, "Channel", "Percentage-based bands plotted around a moving average."),
    VWAP("VWAP", "Volume Weighted Average Price", 1, "Volume", "Trading benchmark representing average price weighted by volume."),
    OBV("OBV", "On-Balance Volume", 14, "Volume", "Cumulative volume metric relating price changes to volume."),
    CMF("CMF", "Chaikin Money Flow", 20, "Volume", "Volume-weighted accumulation and distribution over a lookback window."),
    MFI("MFI", "Money Flow Index", 14, "Volume", "Volume-weighted RSI measuring buying and selling pressure."),
    VOLOSC("VOLOSC", "Volume Oscillator", 5, "Volume", "Difference between short and long volume moving averages."),
    PIVOT("PIVOT", "Classic Pivot Points", 1, "Support & Resistance", "Calculates floor pivot and support/resistance boundaries."),
    FIBPIVOT("FIBPIVOT", "Fibonacci Pivot Points", 1, "Support & Resistance", "Pivot points utilizing key Fibonacci ratios."),
    HLBANDS("HLBANDS", "High/Low Channel Bands", 20, "Support & Resistance", "Dynamic upper and lower boundaries tracking highest and lowest levels."),
    ALLIGATOR("ALLIGATOR", "Bill Williams Alligator", 13, "Bill Williams", "Jaw, Teeth, and Lips smoothed moving averages."),
    FRACTALS("FRACTALS", "Bill Williams Fractals", 5, "Bill Williams", "5-bar reversal patterns identifying local highs and lows."),
    LINREG("LINREG", "Linear Regression Curve", 20, "Statistical", "Best-fit linear regression endpoint curve."),
    HISTVOL("HISTVOL", "Historical Volatility", 20, "Statistical", "Annualized standard deviation of price changes.")
}

data class IndicatorDataPoint(
    val time: Long, // in seconds
    val value: Double
) {
    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("time", time)
        obj.put("value", value)
        return obj
    }
}

data class IndicatorInstance(
    val id: String = UUID.randomUUID().toString(),
    val type: IndicatorType,
    val period: Int = type.defaultPeriod,
    val secondaryPeriod: Int = 26, // For MACD slow period
    val signalPeriod: Int = 9,    // For MACD signal
    val stdDev: Double = 2.0,      // For Bollinger Bands
    val color: String = "#00E5FF",
    val lineWidth: Int = 2,
    val isEnabled: Boolean = true,
    val source: String = "CLOSE"
) {
    val displayLabel: String get() = "${type.code} ($period)"

    fun toJson(calculatedPoints: List<IndicatorDataPoint>): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("type", type.code)
        obj.put("title", displayLabel)
        obj.put("color", color)
        obj.put("lineWidth", lineWidth)
        obj.put("isEnabled", isEnabled)

        val pts = JSONArray()
        for (pt in calculatedPoints) {
            pts.put(pt.toJson())
        }
        obj.put("points", pts)
        return obj
    }

    fun toConfigJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("type", type.name)
        obj.put("period", period)
        obj.put("secondaryPeriod", secondaryPeriod)
        obj.put("signalPeriod", signalPeriod)
        obj.put("stdDev", stdDev)
        obj.put("color", color)
        obj.put("lineWidth", lineWidth)
        obj.put("isEnabled", isEnabled)
        obj.put("source", source)
        return obj
    }

    companion object {
        fun fromConfigJson(json: JSONObject): IndicatorInstance? {
            return try {
                val typeName = json.getString("type")
                val type = IndicatorType.entries.firstOrNull { it.name.equals(typeName, ignoreCase = true) || it.code.equals(typeName, ignoreCase = true) }
                    ?: IndicatorType.EMA
                IndicatorInstance(
                    id = json.optString("id", UUID.randomUUID().toString()),
                    type = type,
                    period = json.optInt("period", type.defaultPeriod),
                    secondaryPeriod = json.optInt("secondaryPeriod", 26),
                    signalPeriod = json.optInt("signalPeriod", 9),
                    stdDev = json.optDouble("stdDev", 2.0),
                    color = json.optString("color", "#00E5FF"),
                    lineWidth = json.optInt("lineWidth", 2),
                    isEnabled = json.optBoolean("isEnabled", true),
                    source = json.optString("source", "CLOSE")
                )
            } catch (_: Exception) {
                null
            }
        }
    }
}
