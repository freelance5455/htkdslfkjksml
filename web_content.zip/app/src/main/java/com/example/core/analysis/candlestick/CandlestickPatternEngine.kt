package com.example.core.analysis.candlestick

import com.example.core.model.analysis.CandlestickAnalysisResult
import com.example.core.model.analysis.CandlestickPatternMatch
import com.example.core.model.analysis.CandlestickPatternType
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Module #6 — Production Candlestick Pattern Engine.
 * Detects 17 documented standard candlestick patterns deterministically on closed OHLC bars:
 * - Single-bar: Doji, Hammer, Inverted Hammer, Hanging Man, Shooting Star, Spinning Top
 * - Two-bar: Bullish Engulfing, Bearish Engulfing, Piercing Line, Dark Cloud Cover,
 *             Bullish Harami, Bearish Harami, Tweezer Top, Tweezer Bottom
 * - Three-bar: Morning Star, Evening Star, Three White Soldiers, Three Black Crows
 *
 * No lookahead, no repainting, closed candle validation.
 */
object CandlestickPatternEngine {

    fun detectPatterns(candles: List<Candle>, timeframe: String = "15m"): CandlestickAnalysisResult {
        if (candles.size < 3) {
            return CandlestickAnalysisResult(
                detectedPatterns = emptyList(),
                dominantPattern = null,
                overallBias = IndicatorDirection.NEUTRAL,
                bullishPatternsCount = 0,
                bearishPatternsCount = 0,
                neutralPatternsCount = 0,
                summaryText = "Insufficient candle history (< 3 closed bars) for pattern recognition"
            )
        }

        val detected = mutableListOf<CandlestickPatternMatch>()
        val n = candles.size
        val c0 = candles[n - 1] // latest closed bar
        val c1 = candles[n - 2] // prior bar
        val c2 = candles[n - 3] // 2 bars ago

        // Helper calculations for c0
        val range0 = (c0.high - c0.low).coerceAtLeast(0.00001)
        val body0 = abs(c0.close - c0.open)
        val upperWick0 = c0.high - max(c0.open, c0.close)
        val lowerWick0 = min(c0.open, c0.close) - c0.low
        val isBullish0 = c0.close > c0.open
        val isBearish0 = c0.close < c0.open

        // Helper calculations for c1
        val range1 = (c1.high - c1.low).coerceAtLeast(0.00001)
        val body1 = abs(c1.close - c1.open)
        val isBullish1 = c1.close > c1.open
        val isBearish1 = c1.close < c1.open

        // Prior trend context estimate from last 5-10 candles
        val lookback = candles.takeLast(min(10, n))
        val isPriorDowntrend = lookback.first().close > lookback.last().close
        val isPriorUptrend = lookback.first().close < lookback.last().close

        // 1. DOJI: body is very small (< 8% of range) with wicks
        if (body0 <= range0 * 0.08) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.DOJI,
                    name = "Doji",
                    classification = IndicatorDirection.NEUTRAL,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "High Indecision",
                    confidencePct = 80,
                    description = "Open and close virtually equal; equilibrium between buyers and sellers."
                )
            )
        }

        // 2. SPINNING TOP: small body (< 35% range) with substantial balanced upper and lower shadows
        if (body0 > range0 * 0.08 && body0 <= range0 * 0.35 &&
            upperWick0 >= body0 * 0.7 && lowerWick0 >= body0 * 0.7
        ) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.SPINNING_TOP,
                    name = "Spinning Top",
                    classification = IndicatorDirection.NEUTRAL,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Moderate Indecision",
                    confidencePct = 72,
                    description = "Small real body centered between upper and lower wicks, signalling pause/consolidation."
                )
            )
        }

        // 3. HAMMER: small body near top of range, long lower wick (>= 2x body), minimal upper wick, in downward context
        if (lowerWick0 >= body0 * 2.0 && upperWick0 <= range0 * 0.12 && body0 > 0.00001 && isPriorDowntrend) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.HAMMER,
                    name = "Hammer",
                    classification = IndicatorDirection.BULLISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Strong Bullish Reversal",
                    confidencePct = 84,
                    description = "Long lower rejection wick following downward swing; heavy buyers defending support."
                )
            )
        }

        // 4. INVERTED HAMMER: small body near bottom, long upper wick (>= 2x body), minimal lower wick, in downward context
        if (upperWick0 >= body0 * 2.0 && lowerWick0 <= range0 * 0.12 && body0 > 0.00001 && isPriorDowntrend) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.INVERTED_HAMMER,
                    name = "Inverted Hammer",
                    classification = IndicatorDirection.BULLISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Moderate Bullish Reversal",
                    confidencePct = 76,
                    description = "Upper rejection wick at support base; early buyer test anticipating trend change."
                )
            )
        }

        // 5. HANGING MAN: same geometry as hammer but occurs after an upward swing
        if (lowerWick0 >= body0 * 2.0 && upperWick0 <= range0 * 0.12 && body0 > 0.00001 && isPriorUptrend) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.HANGING_MAN,
                    name = "Hanging Man",
                    classification = IndicatorDirection.BEARISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Moderate Bearish Reversal",
                    confidencePct = 75,
                    description = "Long lower wick after up-move indicating supply vulnerability and top exhaustion."
                )
            )
        }

        // 6. SHOOTING STAR: same geometry as inverted hammer but occurs after an upward swing
        if (upperWick0 >= body0 * 2.0 && lowerWick0 <= range0 * 0.12 && body0 > 0.00001 && isPriorUptrend) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.SHOOTING_STAR,
                    name = "Shooting Star",
                    classification = IndicatorDirection.BEARISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Strong Bearish Reversal",
                    confidencePct = 85,
                    description = "Long upper wick rejection at local high; sellers firmly rejected higher prices."
                )
            )
        }

        // 7. BULLISH ENGULFING: c1 is red, c0 is green, c0 body engulfs c1 body
        if (isBearish1 && isBullish0 && c0.open <= c1.close && c0.close >= c1.open && body0 > body1 * 1.05) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.BULLISH_ENGULFING,
                    name = "Bullish Engulfing",
                    classification = IndicatorDirection.BULLISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "High Bullish Reversal",
                    confidencePct = 88,
                    description = "Green body fully engulfs previous red bar; aggressive buyer takeover."
                )
            )
        }

        // 8. BEARISH ENGULFING: c1 is green, c0 is red, c0 body engulfs c1 body
        if (isBullish1 && isBearish0 && c0.open >= c1.close && c0.close <= c1.open && body0 > body1 * 1.05) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.BEARISH_ENGULFING,
                    name = "Bearish Engulfing",
                    classification = IndicatorDirection.BEARISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "High Bearish Reversal",
                    confidencePct = 88,
                    description = "Red body fully engulfs previous green bar; strong institutional selling pressure."
                )
            )
        }

        // 9. PIERCING LINE: c1 is long red, c0 is green opening lower than c1 low and closing > 50% into c1 body
        val midpoint1 = c1.open - (body1 * 0.5)
        if (isBearish1 && isBullish0 && c0.open <= c1.low && c0.close > midpoint1 && c0.close < c1.open) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.PIERCING_LINE,
                    name = "Piercing Line",
                    classification = IndicatorDirection.BULLISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Moderate Bullish Reversal",
                    confidencePct = 80,
                    description = "Bullish candle opens at new low but pierces over 50% of prior red body."
                )
            )
        }

        // 10. DARK CLOUD COVER: c1 is long green, c0 is red opening higher than c1 high and closing < 50% into c1 body
        val midpoint1Bull = c1.open + (body1 * 0.5)
        if (isBullish1 && isBearish0 && c0.open >= c1.high && c0.close < midpoint1Bull && c0.close > c1.open) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.DARK_CLOUD_COVER,
                    name = "Dark Cloud Cover",
                    classification = IndicatorDirection.BEARISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Moderate Bearish Reversal",
                    confidencePct = 80,
                    description = "Bearish candle opens at new high but closes below 50% midpoint of prior green body."
                )
            )
        }

        // 11. BULLISH HARAMI: c1 is long red, c0 is small green inside c1 body
        if (isBearish1 && isBullish0 && c0.open > c1.close && c0.close < c1.open && body0 < body1 * 0.6) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.BULLISH_HARAMI,
                    name = "Bullish Harami",
                    classification = IndicatorDirection.BULLISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Moderate Bullish Reversal",
                    confidencePct = 78,
                    description = "Small green candle completely contained within previous large red bar; momentum loss."
                )
            )
        }

        // 12. BEARISH HARAMI: c1 is long green, c0 is small red inside c1 body
        if (isBullish1 && isBearish0 && c0.open < c1.close && c0.close > c1.open && body0 < body1 * 0.6) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.BEARISH_HARAMI,
                    name = "Bearish Harami",
                    classification = IndicatorDirection.BEARISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Moderate Bearish Reversal",
                    confidencePct = 78,
                    description = "Small red candle completely contained within previous large green bar; upside stalling."
                )
            )
        }

        // 13. TWEEZER TOP: two consecutive candles with matching highs (within 0.15%) at peak
        if (abs(c0.high - c1.high) / c0.high <= 0.0015 && isBullish1 && isBearish0 && isPriorUptrend) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.TWEEZER_TOP,
                    name = "Tweezer Top",
                    classification = IndicatorDirection.BEARISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "High Resistance Reversal",
                    confidencePct = 82,
                    description = "Identical matching candle peaks confirming strong upper supply resistance."
                )
            )
        }

        // 14. TWEEZER BOTTOM: two consecutive candles with matching lows (within 0.15%) at trough
        if (abs(c0.low - c1.low) / c0.low <= 0.0015 && isBearish1 && isBullish0 && isPriorDowntrend) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.TWEEZER_BOTTOM,
                    name = "Tweezer Bottom",
                    classification = IndicatorDirection.BULLISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "High Support Reversal",
                    confidencePct = 82,
                    description = "Identical matching candle troughs confirming strong lower demand support."
                )
            )
        }

        // 15. MORNING STAR: 3 candles (c2 long red, c1 small body gap lower, c0 strong green > c2 midpoint)
        val body2 = abs(c2.close - c2.open)
        val isBearish2 = c2.close < c2.open
        val midpoint2 = c2.open - (body2 * 0.5)
        if (isBearish2 && body1 < body2 * 0.4 && isBullish0 && c0.close > midpoint2) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.MORNING_STAR,
                    name = "Morning Star",
                    classification = IndicatorDirection.BULLISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Major 3-Bar Bullish Reversal",
                    confidencePct = 90,
                    description = "Three-bar bullish reversal: selling climax, deceleration pause, and strong buyer surge."
                )
            )
        }

        // 16. EVENING STAR: 3 candles (c2 long green, c1 small body gap higher, c0 strong red < c2 midpoint)
        val isBullish2 = c2.close > c2.open
        val midpoint2Bull = c2.open + (body2 * 0.5)
        if (isBullish2 && body1 < body2 * 0.4 && isBearish0 && c0.close < midpoint2Bull) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.EVENING_STAR,
                    name = "Evening Star",
                    classification = IndicatorDirection.BEARISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Major 3-Bar Bearish Reversal",
                    confidencePct = 90,
                    description = "Three-bar bearish reversal: buying climax, exhaustion pause, and aggressive seller surge."
                )
            )
        }

        // 17. THREE WHITE SOLDIERS / THREE BLACK CROWS
        if (c0.close > c0.open && c1.close > c1.open && c2.close > c2.open &&
            c0.close > c1.close && c1.close > c2.close &&
            c0.open > c1.open && c1.open > c2.open &&
            upperWick0 < body0 * 0.4
        ) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.THREE_WHITE_SOLDIERS,
                    name = "Three White Soldiers",
                    classification = IndicatorDirection.BULLISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Strong Bullish Continuation",
                    confidencePct = 91,
                    description = "Three consecutive expanding green candles with progressive closes near session highs."
                )
            )
        }

        if (c0.close < c0.open && c1.close < c1.open && c2.close < c2.open &&
            c0.close < c1.close && c1.close < c2.close &&
            c0.open < c1.open && c1.open < c2.open &&
            lowerWick0 < body0 * 0.4
        ) {
            detected.add(
                CandlestickPatternMatch(
                    patternType = CandlestickPatternType.THREE_BLACK_CROWS,
                    name = "Three Black Crows",
                    classification = IndicatorDirection.BEARISH,
                    timeframe = timeframe,
                    detectionTimestamp = c0.timestamp,
                    strength = "Strong Bearish Continuation",
                    confidencePct = 91,
                    description = "Three consecutive expanding red candles with progressive closes near session lows."
                )
            )
        }

        val bullishCount = detected.count { it.classification == IndicatorDirection.BULLISH }
        val bearishCount = detected.count { it.classification == IndicatorDirection.BEARISH }
        val neutralCount = detected.count { it.classification == IndicatorDirection.NEUTRAL }

        val dominant = detected.maxByOrNull { it.confidencePct }
        val overallBias = when {
            bullishCount > bearishCount -> IndicatorDirection.BULLISH
            bearishCount > bullishCount -> IndicatorDirection.BEARISH
            else -> dominant?.classification ?: IndicatorDirection.NEUTRAL
        }

        val summary = if (detected.isEmpty()) {
            "No high-confidence standard candlestick pattern detected on recent closed bars."
        } else {
            "${detected.size} pattern(s) identified: dominant ${dominant?.name} (${dominant?.strength})."
        }

        return CandlestickAnalysisResult(
            detectedPatterns = detected,
            dominantPattern = dominant,
            overallBias = overallBias,
            bullishPatternsCount = bullishCount,
            bearishPatternsCount = bearishCount,
            neutralPatternsCount = neutralCount,
            summaryText = summary
        )
    }
}
