package com.example.core.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.core.model.MarketCategory
import com.example.features.news.model.NewsArticle
import com.example.features.news.model.NewsImpact
import com.example.features.news.model.NewsSentiment

@Entity(tableName = "cached_news")
data class CachedNewsEntity(
    @PrimaryKey val id: String,
    val headline: String,
    val source: String,
    val publishedAt: Long,
    val url: String,
    val urlToImage: String?,
    val description: String?,
    val marketCategory: String,
    val relevantSymbolsJson: String,
    val sentiment: String,
    val sentimentScore: Int,
    val sentimentConfidence: Int,
    val impact: String,
    val isBreaking: Boolean,
    val cachedAt: Long = System.currentTimeMillis()
) {
    fun toNewsArticle(): NewsArticle {
        val cat = try {
            MarketCategory.valueOf(marketCategory)
        } catch (_: Exception) {
            MarketCategory.fromId(marketCategory)
        }
        val symbols = if (relevantSymbolsJson.isNotBlank()) {
            relevantSymbolsJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            emptyList()
        }
        val sent = try {
            NewsSentiment.valueOf(sentiment)
        } catch (_: Exception) {
            NewsSentiment.NEUTRAL
        }
        val imp = try {
            NewsImpact.valueOf(impact)
        } catch (_: Exception) {
            NewsImpact.MEDIUM
        }

        return NewsArticle(
            id = id,
            headline = headline,
            source = source,
            publishedAt = publishedAt,
            url = url,
            urlToImage = urlToImage,
            description = description,
            marketCategory = cat,
            relevantSymbols = symbols,
            sentiment = sent,
            sentimentScore = sentimentScore,
            sentimentConfidence = sentimentConfidence,
            impact = imp,
            isBreaking = isBreaking,
            cachedAt = cachedAt
        )
    }

    companion object {
        fun fromNewsArticle(article: NewsArticle): CachedNewsEntity {
            return CachedNewsEntity(
                id = article.id,
                headline = article.headline,
                source = article.source,
                publishedAt = article.publishedAt,
                url = article.url,
                urlToImage = article.urlToImage,
                description = article.description,
                marketCategory = article.marketCategory.name,
                relevantSymbolsJson = article.relevantSymbols.joinToString(","),
                sentiment = article.sentiment.name,
                sentimentScore = article.sentimentScore,
                sentimentConfidence = article.sentimentConfidence,
                impact = article.impact.name,
                isBreaking = article.isBreaking,
                cachedAt = article.cachedAt
            )
        }
    }
}
