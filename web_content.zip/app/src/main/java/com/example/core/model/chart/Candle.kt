package com.example.core.model.chart

import org.json.JSONObject

/**
 * Standardized financial candlestick data model for IQTrade Pro.
 * Adheres strictly to the requirement:
 * - Timestamps in seconds or milliseconds (timeInSeconds for Lightweight Charts)
 * - Open, High, Low, Close, Volume
 * - isClosed flag to differentiate historical completed candles from current live developing candles.
 */
data class Candle(
    val timestamp: Long, // Unix timestamp in milliseconds
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0,
    val isClosed: Boolean = true
) {
    val timeInSeconds: Long get() = timestamp / 1000L

    val isBullish: Boolean get() = close >= open
    val isBearish: Boolean get() = close < open

    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("time", timeInSeconds)
        obj.put("open", open)
        obj.put("high", high)
        obj.put("low", low)
        obj.put("close", close)
        obj.put("volume", volume)
        return obj
    }
}
