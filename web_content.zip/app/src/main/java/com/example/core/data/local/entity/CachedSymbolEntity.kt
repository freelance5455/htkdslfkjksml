package com.example.core.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.core.model.Instrument
import com.example.core.model.MarketCategory

@Entity(tableName = "cached_symbols")
data class CachedSymbolEntity(
    @PrimaryKey val id: String, // format: "${marketCategory}_${symbolId}"
    val marketCategory: String,
    val symbolId: String,
    val displayName: String,
    val baseAsset: String,
    val quoteAsset: String,
    val providerId: String,
    val providerName: String,
    val isActive: Boolean,
    val pricePrecision: Int,
    val quantityPrecision: Int,
    val tickSize: Double,
    val minLotSize: Double,
    val description: String,
    val cachedAt: Long = System.currentTimeMillis()
) {
    fun toInstrument(): Instrument {
        val category = MarketCategory.fromId(marketCategory)
        return Instrument(
            symbolId = symbolId,
            displayName = displayName,
            marketCategory = category,
            baseAsset = baseAsset,
            quoteAsset = quoteAsset,
            providerId = providerId,
            providerName = providerName,
            isActive = isActive,
            pricePrecision = pricePrecision,
            quantityPrecision = quantityPrecision,
            tickSize = tickSize,
            minLotSize = minLotSize,
            description = description
        )
    }

    companion object {
        fun fromInstrument(instrument: Instrument): CachedSymbolEntity {
            return CachedSymbolEntity(
                id = "${instrument.marketCategory.id}_${instrument.symbolId}",
                marketCategory = instrument.marketCategory.id,
                symbolId = instrument.symbolId,
                displayName = instrument.displayName,
                baseAsset = instrument.baseAsset,
                quoteAsset = instrument.quoteAsset,
                providerId = instrument.providerId,
                providerName = instrument.providerName,
                isActive = instrument.isActive,
                pricePrecision = instrument.pricePrecision,
                quantityPrecision = instrument.quantityPrecision,
                tickSize = instrument.tickSize,
                minLotSize = instrument.minLotSize,
                description = instrument.description,
                cachedAt = System.currentTimeMillis()
            )
        }
    }
}
