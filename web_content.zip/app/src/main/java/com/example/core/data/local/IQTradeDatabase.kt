package com.example.core.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.core.data.local.dao.AppSettingsDao
import com.example.core.data.local.dao.CachedNewsDao
import com.example.core.data.local.dao.CachedSymbolDao
import com.example.core.data.local.dao.PaperAccountDao
import com.example.core.data.local.dao.TradeRecordDao
import com.example.core.data.local.entity.AppSettingsEntity
import com.example.core.data.local.entity.CachedNewsEntity
import com.example.core.data.local.entity.CachedSymbolEntity
import com.example.core.data.local.entity.MarketSyncStatusEntity
import com.example.core.data.local.entity.PaperAccountEntity
import com.example.core.data.local.entity.TradeRecordEntity

@Database(
    entities = [
        AppSettingsEntity::class,
        PaperAccountEntity::class,
        TradeRecordEntity::class,
        CachedSymbolEntity::class,
        MarketSyncStatusEntity::class,
        CachedNewsEntity::class
    ],
    version = 7,
    exportSchema = false
)
abstract class IQTradeDatabase : RoomDatabase() {

    abstract fun appSettingsDao(): AppSettingsDao
    abstract fun paperAccountDao(): PaperAccountDao
    abstract fun tradeRecordDao(): TradeRecordDao
    abstract fun cachedSymbolDao(): CachedSymbolDao
    abstract fun cachedNewsDao(): CachedNewsDao

    companion object {
        @Volatile
        private var INSTANCE: IQTradeDatabase? = null

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val cursor = db.query("PRAGMA table_info(trade_records)")
                val columns = mutableSetOf<String>()
                while (cursor.moveToNext()) {
                    val nameIndex = cursor.getColumnIndex("name")
                    if (nameIndex != -1) {
                        columns.add(cursor.getString(nameIndex))
                    }
                }
                cursor.close()

                if (!columns.contains("status")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `status` TEXT NOT NULL DEFAULT 'FILLED'")
                }
                if (!columns.contains("isOpen")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `isOpen` INTEGER NOT NULL DEFAULT 1")
                }
                if (!columns.contains("closePrice")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `closePrice` REAL")
                }
                if (!columns.contains("realizedPnl")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `realizedPnl` REAL")
                }
                if (!columns.contains("closeTimestamp")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `closeTimestamp` INTEGER")
                }
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val cursor = db.query("PRAGMA table_info(trade_records)")
                val columns = mutableSetOf<String>()
                while (cursor.moveToNext()) {
                    val nameIndex = cursor.getColumnIndex("name")
                    if (nameIndex != -1) {
                        columns.add(cursor.getString(nameIndex))
                    }
                }
                cursor.close()

                if (!columns.contains("exchangeOrderId")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `exchangeOrderId` TEXT")
                }
                if (!columns.contains("clientOrderId")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `clientOrderId` TEXT")
                }
                if (!columns.contains("requestedPrice")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `requestedPrice` REAL")
                }
                if (!columns.contains("executedQuantity")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `executedQuantity` REAL")
                }
                if (!columns.contains("averageFillPrice")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `averageFillPrice` REAL")
                }
                if (!columns.contains("updatedTimestamp")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `updatedTimestamp` INTEGER")
                }
                if (!columns.contains("filledTimestamp")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `filledTimestamp` INTEGER")
                }
                if (!columns.contains("commission")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `commission` REAL")
                }
                if (!columns.contains("commissionAsset")) {
                    db.execSQL("ALTER TABLE `trade_records` ADD COLUMN `commissionAsset` TEXT")
                }
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""
                    CREATE TABLE IF NOT EXISTS `cached_news` (
                        `id` TEXT NOT NULL PRIMARY KEY,
                        `headline` TEXT NOT NULL,
                        `source` TEXT NOT NULL,
                        `publishedAt` INTEGER NOT NULL,
                        `url` TEXT NOT NULL,
                        `urlToImage` TEXT,
                        `description` TEXT,
                        `marketCategory` TEXT NOT NULL,
                        `relevantSymbolsJson` TEXT NOT NULL,
                        `sentiment` TEXT NOT NULL,
                        `sentimentScore` INTEGER NOT NULL,
                        `sentimentConfidence` INTEGER NOT NULL,
                        `impact` TEXT NOT NULL,
                        `isBreaking` INTEGER NOT NULL,
                        `cachedAt` INTEGER NOT NULL
                    )
                """.trimIndent())
            }
        }

        fun getInstance(context: Context): IQTradeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    IQTradeDatabase::class.java,
                    "iqtrade_pro.db"
                ).addMigrations(MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
