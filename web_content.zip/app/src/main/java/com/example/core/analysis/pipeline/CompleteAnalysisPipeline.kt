package com.example.core.analysis.pipeline

import com.example.core.analysis.candlestick.CandlestickPatternEngine
import com.example.core.analysis.fibonacci.FibonacciEngine
import com.example.core.analysis.levels.SupportResistanceEngine
import com.example.core.analysis.risk.RiskRewardEngine
import com.example.core.analysis.structure.MarketStructureEngine
import com.example.core.indicator.analysis.CoreAnalysisEngine
import com.example.core.indicator.engine.ComprehensiveIndicatorEngine
import com.example.core.model.analysis.CompleteAnalysisResult
import com.example.core.model.analysis.ComponentContribution
import com.example.core.model.analysis.FinalAnalysisSignal
import com.example.core.model.analysis.NewsSentimentResult
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Module #6 — Central Complete Analysis Engine Pipeline.
 *
 * Executes the complete real analytical pipeline:
 * Market Data
 * → OHLCV validation
 * → Multi-Timeframe data (10 timeframes: 5M to 1D)
 * → Core Indicators (8 indicators, 5/8 >= 80% confirmation rule)
 * → Candlestick Patterns (17 patterns)
 * → Market Trend & Structure (HH, HL, LH, LL, Breakout, Reversal)
 * → Support & Resistance (nearest levels, distances)
 * → Fibonacci (0%, 23.6%, 38.2%, 50%, 61.8% Golden Pocket, 78.6%, 100%)
 * → News & Sentiment (real News API connection status)
 * → Volatility (ATR, ATR %, Low/Normal/High/Extreme)
 * → Risk/Reward (Entry, SL, TP, Ratio, or Insufficient data)
 * → Component Scores & Contribution Breakdown
 * → Final Analysis Result (BULLISH / BUY, BEARISH / SELL, NEUTRAL / WAIT)
 */
object CompleteAnalysisPipeline {

    fun executeAnalysis(
        symbol: String,
        market: String,
        candles: List<Candle>,
        isNewsConnected: Boolean,
        newsSentimentScore: Int? = null,
        newsHeadline: String? = null,
        newsSource: String? = null,
        activeTimeframe: String = "15m"
    ): CompleteAnalysisResult {
        val now = System.currentTimeMillis()

        // 1. OHLCV Validation & Sanitization
        val sanitizedCandles = ComprehensiveIndicatorEngine.sanitizeCandles(candles)
        val currentPrice = sanitizedCandles.lastOrNull()?.close ?: 0.0

        // 2. 8 Core Indicators & 10 MTF Scores from Module #5
        val coreSnapshot = CoreAnalysisEngine.createSnapshot(
            symbol = symbol,
            currentPrice = currentPrice,
            candles = sanitizedCandles,
            newsSentimentScore = if (isNewsConnected) (newsSentimentScore ?: 70) else 50,
            newsHeadline = if (isNewsConnected) newsHeadline else null
        )

        // 3. Candlestick Pattern Engine (17 Patterns)
        val candlestickResult = CandlestickPatternEngine.detectPatterns(sanitizedCandles, activeTimeframe)

        // 4. Market Trend & Structure Engine
        val structureResult = MarketStructureEngine.analyzeStructure(sanitizedCandles)

        // 5. Support & Resistance Engine
        val srResult = SupportResistanceEngine.calculateLevels(sanitizedCandles)

        // 6. Fibonacci Engine
        val fibResult = FibonacciEngine.calculateFibonacci(sanitizedCandles)

        // 7. Volatility Engine
        val volatilityResult = RiskRewardEngine.analyzeVolatility(sanitizedCandles)

        // 8. News & Sentiment Result
        val newsResult = if (isNewsConnected) {
            val score = (newsSentimentScore ?: 70).coerceIn(0, 100)
            val dir = when {
                score >= 60 -> IndicatorDirection.BULLISH
                score <= 40 -> IndicatorDirection.BEARISH
                else -> IndicatorDirection.NEUTRAL
            }
            NewsSentimentResult(
                isConnected = true,
                sentimentScore = score,
                direction = dir,
                headlineSample = newsHeadline,
                source = newsSource ?: "NewsAPI.org",
                timestamp = now,
                statusMessage = "Connected • Live Sentiment Feed Active"
            )
        } else {
            NewsSentimentResult(
                isConnected = false,
                sentimentScore = 50,
                direction = IndicatorDirection.NEUTRAL,
                headlineSample = null,
                source = null,
                timestamp = now,
                statusMessage = "News unavailable / not connected"
            )
        }

        // 9. Primary Directional Bias synthesis for Risk/Reward calculation
        val coreBullishCount = coreSnapshot.coreScores.count { it.direction == IndicatorDirection.BULLISH }
        val coreBearishCount = coreSnapshot.coreScores.count { it.direction == IndicatorDirection.BEARISH }
        val intermediateBias = when {
            coreBullishCount > coreBearishCount && structureResult.structuralBias != IndicatorDirection.BEARISH ->
                IndicatorDirection.BULLISH
            coreBearishCount > coreBullishCount && structureResult.structuralBias != IndicatorDirection.BULLISH ->
                IndicatorDirection.BEARISH
            else -> structureResult.structuralBias
        }

        // 10. Risk / Reward Analysis
        val riskRewardResult = RiskRewardEngine.calculateRiskReward(
            candles = sanitizedCandles,
            srResult = srResult,
            volatility = volatilityResult,
            directionalBias = intermediateBias
        )

        // 11. Component Contributions & Weighted Scoring
        val contributions = mutableListOf<ComponentContribution>()

        // A) Core Indicators Contribution (Weight: 35%)
        val avgCoreScore = if (coreSnapshot.coreScores.isNotEmpty()) {
            coreSnapshot.coreScores.map { it.scorePct }.average().roundToInt()
        } else 50
        val coreBias = when {
            coreBullishCount >= 5 -> IndicatorDirection.BULLISH
            coreBearishCount >= 5 -> IndicatorDirection.BEARISH
            else -> IndicatorDirection.NEUTRAL
        }
        contributions.add(
            ComponentContribution(
                componentName = "8 Core Indicators",
                weightPercent = 35,
                direction = coreBias,
                scorePercent = avgCoreScore,
                explanation = "${coreSnapshot.confirmationRatioText} Core Indicators >= 80%. Direction: $coreBullishCount Bull, $coreBearishCount Bear."
            )
        )

        // B) Multi-Timeframe Matrix (Weight: 20%)
        val mtfScores = coreSnapshot.timeframeScores
        val avgMtfScore = if (mtfScores.isNotEmpty()) mtfScores.map { it.scorePct }.average().roundToInt() else 50
        val mtfBullCount = mtfScores.count { it.direction == IndicatorDirection.BULLISH }
        val mtfBearCount = mtfScores.count { it.direction == IndicatorDirection.BEARISH }
        val mtfBias = when {
            mtfBullCount >= 6 -> IndicatorDirection.BULLISH
            mtfBearCount >= 6 -> IndicatorDirection.BEARISH
            else -> IndicatorDirection.NEUTRAL
        }
        contributions.add(
            ComponentContribution(
                componentName = "10 Multi-Timeframes (5M to 1D)",
                weightPercent = 20,
                direction = mtfBias,
                scorePercent = avgMtfScore,
                explanation = "$mtfBullCount of 10 TFs Bullish, $mtfBearCount of 10 TFs Bearish across 5M-1D matrix."
            )
        )

        // C) Market Trend & Structure (Weight: 15%)
        val structureScore = when (structureResult.structuralBias) {
            IndicatorDirection.BULLISH -> 85
            IndicatorDirection.BEARISH -> 85
            IndicatorDirection.NEUTRAL -> 50
        }
        contributions.add(
            ComponentContribution(
                componentName = "Market Trend & Structure",
                weightPercent = 15,
                direction = structureResult.structuralBias,
                scorePercent = structureScore,
                explanation = "${structureResult.trend.label} with ${structureResult.higherHighsCount} HH, ${structureResult.higherLowsCount} HL. ${structureResult.state.label}."
            )
        )

        // D) Candlestick Patterns (Weight: 10%)
        val candleScore = candlestickResult.dominantPattern?.confidencePct ?: 50
        contributions.add(
            ComponentContribution(
                componentName = "Candlestick Patterns",
                weightPercent = 10,
                direction = candlestickResult.overallBias,
                scorePercent = candleScore,
                explanation = candlestickResult.summaryText
            )
        )

        // E) S/R & Fibonacci (Weight: 10%)
        val fibScore = when (fibResult.contextBias) {
            IndicatorDirection.BULLISH -> 78
            IndicatorDirection.BEARISH -> 78
            IndicatorDirection.NEUTRAL -> 50
        }
        val sPrice = String.format(java.util.Locale.US, "$%.2f", srResult.nearestSupport?.price ?: 0.0)
        val rPrice = String.format(java.util.Locale.US, "$%.2f", srResult.nearestResistance?.price ?: 0.0)
        contributions.add(
            ComponentContribution(
                componentName = "Support, Resistance & Fibonacci",
                weightPercent = 10,
                direction = fibResult.contextBias,
                scorePercent = fibScore,
                explanation = "${fibResult.currentZone}. Nearest S: $sPrice, Nearest R: $rPrice."
            )
        )

        // F) Volatility & Risk/Reward (Weight: 5%)
        val rrScore = if (riskRewardResult.isValid && riskRewardResult.ratioValue >= 1.5) 82 else 50
        contributions.add(
            ComponentContribution(
                componentName = "Volatility & Risk/Reward",
                weightPercent = 5,
                direction = riskRewardResult.setupBias,
                scorePercent = rrScore,
                explanation = "${volatilityResult.environment.label}. R:R: ${riskRewardResult.ratioText}."
            )
        )

        // G) News & Sentiment (Weight: 5% when available)
        val newsWeight = if (newsResult.isConnected) 5 else 0
        if (newsResult.isConnected) {
            contributions.add(
                ComponentContribution(
                    componentName = "News & Sentiment",
                    weightPercent = 5,
                    direction = newsResult.direction,
                    scorePercent = newsResult.sentimentScore,
                    explanation = "Sentiment score ${newsResult.sentimentScore}%. Headline: ${newsResult.headlineSample ?: "Live feed active"}."
                )
            )
        } else {
            contributions.add(
                ComponentContribution(
                    componentName = "News & Sentiment",
                    weightPercent = 0,
                    direction = IndicatorDirection.NEUTRAL,
                    scorePercent = 0,
                    explanation = "News unavailable / not connected (omitted from weighted composite)."
                )
            )
        }

        // 12. Composite Overall Score Calculation
        var weightedTotal = 0.0
        var totalWeight = 0
        for (c in contributions) {
            if (c.weightPercent > 0) {
                weightedTotal += c.scorePercent * c.weightPercent
                totalWeight += c.weightPercent
            }
        }
        val confidencePct = if (totalWeight > 0) (weightedTotal / totalWeight).roundToInt().coerceIn(0, 100) else 50

        // 13. Determine Final Analysis Signal
        // Requires alignment between Core confirmation (>= 5 of 8 >= 80%), MTF bias, and structure
        val isCoreConfirmed = coreSnapshot.isConfirmationConditionMet
        val finalSignal = when {
            isCoreConfirmed && coreBullishCount >= 5 && structureResult.structuralBias == IndicatorDirection.BULLISH && confidencePct >= 72 ->
                FinalAnalysisSignal.BULLISH_BUY

            isCoreConfirmed && coreBearishCount >= 5 && structureResult.structuralBias == IndicatorDirection.BEARISH && confidencePct >= 72 ->
                FinalAnalysisSignal.BEARISH_SELL

            // Moderate buy if strong structure and >= 5 bull cores
            coreBullishCount >= 5 && mtfBullCount >= 6 && confidencePct >= 68 ->
                FinalAnalysisSignal.BULLISH_BUY

            // Moderate sell if strong structure and >= 5 bear cores
            coreBearishCount >= 5 && mtfBearCount >= 6 && confidencePct >= 68 ->
                FinalAnalysisSignal.BEARISH_SELL

            else -> FinalAnalysisSignal.NEUTRAL_WAIT
        }

        val explanation = buildString {
            append("Signal: ${finalSignal.label} ($confidencePct% confidence). ")
            append("Core confirmation: ${coreSnapshot.confirmationRatioText} >= 80% (${if (isCoreConfirmed) "Confirmed" else "Pending"}). ")
            append("MTF matrix: $mtfBullCount/10 Bullish. ")
            append("Market structure: ${structureResult.trend.label} (${structureResult.state.label}). ")
            if (candlestickResult.dominantPattern != null) {
                append("Candlestick: ${candlestickResult.dominantPattern.name} (${candlestickResult.dominantPattern.strength}). ")
            }
            if (newsResult.isConnected) {
                append("News sentiment: ${newsResult.sentimentScore}%. ")
            } else {
                append("News: Disconnected/Unavailable. ")
            }
            append("R:R: ${riskRewardResult.ratioText}.")
        }

        return CompleteAnalysisResult(
            symbol = symbol,
            market = market,
            currentPrice = currentPrice,
            timestamp = now,
            overallSignal = finalSignal,
            overallConfidencePct = confidencePct,
            coreSnapshot = coreSnapshot,
            candlestickResult = candlestickResult,
            structureResult = structureResult,
            supportResistanceResult = srResult,
            fibonacciResult = fibResult,
            volatilityResult = volatilityResult,
            riskRewardResult = riskRewardResult,
            newsResult = newsResult,
            contributions = contributions,
            contributingFactorsExplanation = explanation,
            isOnlySignalSafe = true
        )
    }
}
