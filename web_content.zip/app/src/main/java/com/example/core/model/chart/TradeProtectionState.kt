package com.example.core.model.chart

enum class StopLossMode(val label: String, val description: String) {
    NONE("No Stop Loss", "Unprotected trade (High Risk)"),
    FIXED("Fixed Stop", "Fixed exit price level or percentage below entry"),
    TRAILING("Trailing Stop", "Dynamic stop that trails the peak price by distance"),
    MANUAL("Manual Stop", "User directly specifies the exact stop price level"),
    AUTO("Auto Stop", "Algorithmic swing-level or dynamic volatility stop"),
    BALANCE_RISK("Balance / Risk", "Automatic stop distance clamped to max % of account balance")
}

enum class OrderType(val label: String) {
    MARKET("Market"),
    LIMIT("Limit"),
    STOP_TRIGGER("Stop / Trigger")
}

data class TradeProtectionState(
    val stopLossMode: StopLossMode = StopLossMode.FIXED,
    val stopLossPrice: Double? = null,
    val stopLossPercentage: Double = 1.5, // 1.5% default stop
    val trailingDistancePct: Double = 2.0, // 2.0% trailing distance
    val isTakeProfitEnabled: Boolean = true,
    val takeProfitPrice: Double? = null,
    val takeProfitPercentage: Double = 3.0, // 3.0% default TP (2:1 R:R)
    val entryPrice: Double = 0.0,
    val currentPrice: Double = 0.0,
    val quantity: Double = 0.0,
    val side: TradeSide = TradeSide.BUY,
    // Advanced Protections
    val accountBalance: Double = 10000.0,
    val maxRiskAccountPercentage: Double = 2.0, // e.g. 1%, 2%, 3% max balance risk
    val strictRiskRewardEnabled: Boolean = false,
    val targetRiskRewardRatio: Double = 2.0, // e.g. 1:1.5, 1:2, 1:3
    val autoStopSwingPrice: Double? = null
) {
    /**
     * Calculated Effective Stop Loss Price based on mode
     */
    val effectiveStopLossPrice: Double?
        get() = when (stopLossMode) {
            StopLossMode.NONE -> null
            StopLossMode.FIXED -> {
                stopLossPrice ?: if (entryPrice > 0) {
                    if (side == TradeSide.BUY) entryPrice * (1.0 - stopLossPercentage / 100.0)
                    else entryPrice * (1.0 + stopLossPercentage / 100.0)
                } else null
            }
            StopLossMode.TRAILING -> {
                if (currentPrice > 0) {
                    if (side == TradeSide.BUY) currentPrice * (1.0 - trailingDistancePct / 100.0)
                    else currentPrice * (1.0 + trailingDistancePct / 100.0)
                } else null
            }
            StopLossMode.MANUAL -> stopLossPrice
            StopLossMode.AUTO -> {
                autoStopSwingPrice ?: if (entryPrice > 0) {
                    // Algorithmic 1.2% swing support/resistance offset
                    if (side == TradeSide.BUY) entryPrice * 0.988
                    else entryPrice * 1.012
                } else null
            }
            StopLossMode.BALANCE_RISK -> {
                if (entryPrice > 0 && quantity > 0.00001 && accountBalance > 0) {
                    val maxAllowedDollarLoss = accountBalance * (maxRiskAccountPercentage / 100.0)
                    val priceDistance = maxAllowedDollarLoss / quantity
                    if (side == TradeSide.BUY) kotlin.math.max(0.0, entryPrice - priceDistance)
                    else entryPrice + priceDistance
                } else if (entryPrice > 0) {
                    if (side == TradeSide.BUY) entryPrice * (1.0 - maxRiskAccountPercentage / 100.0)
                    else entryPrice * (1.0 + maxRiskAccountPercentage / 100.0)
                } else null
            }
        }

    /**
     * Calculated Effective Take Profit Price
     */
    val effectiveTakeProfitPrice: Double?
        get() = if (!isTakeProfitEnabled) null else {
            if (strictRiskRewardEnabled && entryPrice > 0) {
                val sl = effectiveStopLossPrice
                if (sl != null) {
                    val slDistance = kotlin.math.abs(entryPrice - sl)
                    val tpDistance = slDistance * targetRiskRewardRatio
                    if (side == TradeSide.BUY) entryPrice + tpDistance
                    else kotlin.math.max(0.0, entryPrice - tpDistance)
                } else {
                    takeProfitPrice ?: if (side == TradeSide.BUY) entryPrice * (1.0 + takeProfitPercentage / 100.0)
                    else kotlin.math.max(0.0, entryPrice * (1.0 - takeProfitPercentage / 100.0))
                }
            } else {
                takeProfitPrice ?: if (entryPrice > 0) {
                    if (side == TradeSide.BUY) entryPrice * (1.0 + takeProfitPercentage / 100.0)
                    else kotlin.math.max(0.0, entryPrice * (1.0 - takeProfitPercentage / 100.0))
                } else null
            }
        }

    /**
     * Estimated Dollar Risk: |Entry - SL| * Quantity
     */
    val estimatedRiskUsdt: Double
        get() {
            val sl = effectiveStopLossPrice ?: return 0.0
            return kotlin.math.abs(entryPrice - sl) * quantity
        }

    /**
     * Estimated Dollar Reward: |TP - Entry| * Quantity
     */
    val estimatedRewardUsdt: Double
        get() {
            val tp = effectiveTakeProfitPrice ?: return 0.0
            return kotlin.math.abs(tp - entryPrice) * quantity
        }

    /**
     * Risk / Reward Ratio: Reward / Risk
     */
    val riskRewardRatio: Double
        get() {
            if (estimatedRiskUsdt <= 0.0001) return 0.0
            return estimatedRewardUsdt / estimatedRiskUsdt
        }
}
