package com.example.core.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.core.data.local.entity.TradeRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeRecordDao {
    @Query("SELECT * FROM trade_records ORDER BY timestamp DESC")
    fun getAllTradesFlow(): Flow<List<TradeRecordEntity>>

    @Query("SELECT * FROM trade_records WHERE isPaper = :isPaper ORDER BY timestamp DESC")
    fun getTradesByModeFlow(isPaper: Boolean): Flow<List<TradeRecordEntity>>

    @Query("SELECT * FROM trade_records WHERE isPaper = :isPaper AND isOpen = 1 ORDER BY timestamp DESC")
    fun getOpenTradesFlow(isPaper: Boolean): Flow<List<TradeRecordEntity>>

    @Query("SELECT * FROM trade_records WHERE isPaper = :isPaper AND isOpen = 0 ORDER BY timestamp DESC")
    fun getClosedTradesFlow(isPaper: Boolean): Flow<List<TradeRecordEntity>>

    @Query("SELECT * FROM trade_records WHERE id = :id LIMIT 1")
    suspend fun getTradeById(id: Long): TradeRecordEntity?

    @Query("SELECT * FROM trade_records WHERE isPaper = :isPaper AND isOpen = 1")
    suspend fun getOpenTrades(isPaper: Boolean): List<TradeRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrade(trade: TradeRecordEntity): Long

    @Update
    suspend fun updateTrade(trade: TradeRecordEntity)

    @Query("UPDATE trade_records SET isOpen = 0, closePrice = :closePrice, realizedPnl = :pnl, closeTimestamp = :closeTime, status = 'CLOSED' WHERE id = :id")
    suspend fun closeTrade(id: Long, closePrice: Double, pnl: Double, closeTime: Long = System.currentTimeMillis())

    @Query("UPDATE trade_records SET isOpen = 0, closePrice = :closePrice, realizedPnl = 0.0, closeTimestamp = :closeTime, status = 'CLOSED' WHERE isPaper = :isPaper AND isOpen = 1")
    suspend fun closeAllOpenTrades(isPaper: Boolean, closePrice: Double, closeTime: Long = System.currentTimeMillis())

    @Query("SELECT * FROM trade_records WHERE exchangeOrderId = :exchangeOrderId LIMIT 1")
    suspend fun getTradeByExchangeOrderId(exchangeOrderId: String): TradeRecordEntity?

    @Query("SELECT * FROM trade_records WHERE clientOrderId = :clientOrderId LIMIT 1")
    suspend fun getTradeByClientOrderId(clientOrderId: String): TradeRecordEntity?

    @Query("SELECT * FROM trade_records WHERE isPaper = 0 AND isOpen = 1 ORDER BY timestamp DESC")
    fun getOpenLiveTradesFlow(): Flow<List<TradeRecordEntity>>

    @Query("DELETE FROM trade_records WHERE isPaper = 1")
    suspend fun clearPaperTrades()

    @Query("DELETE FROM trade_records")
    suspend fun clearAllTrades()
}
