package com.example.core.data.market

import com.example.core.data.local.dao.CachedSymbolDao
import com.example.core.data.local.entity.CachedSymbolEntity
import com.example.core.data.local.entity.MarketSyncStatusEntity
import com.example.core.model.Instrument
import com.example.core.model.MarketCategory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.ConcurrentHashMap

/**
 * Authoritative repository managing market symbols across Crypto, Forex, and Gold.
 * Bridges providers, Room local cache fallback, and dynamic search/filtering.
 */
class MarketSymbolRepository(
    private val cachedSymbolDao: CachedSymbolDao,
    customProviders: Map<MarketCategory, MarketSymbolProvider>? = null
) {
    private val providers = ConcurrentHashMap<MarketCategory, MarketSymbolProvider>()

    init {
        if (customProviders != null) {
            providers.putAll(customProviders)
        } else {
            providers[MarketCategory.CRYPTO] = CryptoSymbolProvider()
            providers[MarketCategory.FOREX] = ForexSymbolProvider()
            providers[MarketCategory.GOLD] = GoldSymbolProvider()
        }
    }

    fun registerProvider(provider: MarketSymbolProvider) {
        providers[provider.marketCategory] = provider
    }

    fun getProvider(category: MarketCategory): MarketSymbolProvider? {
        return providers[category]
    }

    /**
     * Emits the reactive list of cached instruments for the specified market category.
     * Guaranteed to return strictly instruments for that market category.
     */
    fun getSymbolsFlow(category: MarketCategory): Flow<List<Instrument>> {
        return cachedSymbolDao.getSymbolsForMarketFlow(category.id).map { entities ->
            entities.map { it.toInstrument() }
        }
    }

    /**
     * Emits synchronization metadata (timestamp, status, symbol count, error if any).
     */
    fun getSyncStatusFlow(category: MarketCategory): Flow<MarketSyncStatusEntity?> {
        return cachedSymbolDao.getSyncStatusFlow(category.id)
    }

    /**
     * Initializes cache for all markets if not yet populated.
     */
    suspend fun initializeCacheIfNeeded() {
        for (category in MarketCategory.entries) {
            val existing = cachedSymbolDao.getSymbolsForMarketSync(category.id)
            if (existing.isEmpty()) {
                val provider = providers[category]
                val initialList = provider?.getInitialSymbols() ?: emptyList()
                if (initialList.isNotEmpty()) {
                    val entities = initialList.map { CachedSymbolEntity.fromInstrument(it) }
                    cachedSymbolDao.replaceSymbolsForMarket(category.id, entities)
                    cachedSymbolDao.insertOrUpdateSyncStatus(
                        MarketSyncStatusEntity(
                            marketCategory = category.id,
                            lastSyncTimestamp = System.currentTimeMillis(),
                            symbolCount = entities.size,
                            status = "INITIALIZED",
                            errorMessage = null
                        )
                    )
                }
            }
        }
    }

    /**
     * Refreshes symbol universe from the registered provider with safe local caching.
     * If the provider fails, gracefully falls back to cached symbols with an error status.
     */
    suspend fun refreshSymbols(category: MarketCategory): Result<List<Instrument>> {
        val provider = providers[category]
            ?: return Result.failure(IllegalStateException("No provider registered for ${category.displayName}"))

        val fetchResult = provider.fetchSymbols()
        if (fetchResult.isSuccess) {
            val freshInstruments = fetchResult.getOrNull().orEmpty()
            if (freshInstruments.isNotEmpty()) {
                val entities = freshInstruments.map { CachedSymbolEntity.fromInstrument(it) }
                cachedSymbolDao.replaceSymbolsForMarket(category.id, entities)
                cachedSymbolDao.insertOrUpdateSyncStatus(
                    MarketSyncStatusEntity(
                        marketCategory = category.id,
                        lastSyncTimestamp = System.currentTimeMillis(),
                        symbolCount = entities.size,
                        status = "SUCCESS",
                        errorMessage = null
                    )
                )
                return Result.success(freshInstruments)
            } else {
                // Empty symbol list from provider
                cachedSymbolDao.insertOrUpdateSyncStatus(
                    MarketSyncStatusEntity(
                        marketCategory = category.id,
                        lastSyncTimestamp = System.currentTimeMillis(),
                        symbolCount = 0,
                        status = "EMPTY",
                        errorMessage = "Provider returned 0 instruments"
                    )
                )
                return Result.success(emptyList())
            }
        } else {
            // Provider failure: Fallback to local Room cache
            val error = fetchResult.exceptionOrNull()
            val cached = cachedSymbolDao.getSymbolsForMarketSync(category.id)
            val errorMessage = error?.message ?: "Provider unreachable"

            cachedSymbolDao.insertOrUpdateSyncStatus(
                MarketSyncStatusEntity(
                    marketCategory = category.id,
                    lastSyncTimestamp = System.currentTimeMillis(),
                    symbolCount = cached.size,
                    status = if (cached.isNotEmpty()) "STALE_CACHE" else "FAILED",
                    errorMessage = errorMessage
                )
            )

            return if (cached.isNotEmpty()) {
                // Return cached instruments as safe fallback
                Result.success(cached.map { it.toInstrument() })
            } else {
                Result.failure(error ?: Exception(errorMessage))
            }
        }
    }

    /**
     * Finds instrument by symbolId in the specified market.
     */
    suspend fun getInstrument(category: MarketCategory, symbolId: String): Instrument? {
        val cached = cachedSymbolDao.getSymbolsForMarketSync(category.id)
        return cached.firstOrNull { it.symbolId.equals(symbolId, ignoreCase = true) }?.toInstrument()
            ?: providers[category]?.getInitialSymbols()?.firstOrNull { it.symbolId.equals(symbolId, ignoreCase = true) }
    }
}
