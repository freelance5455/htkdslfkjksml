package com.example.core.model.chart

/**
 * High-fidelity reactive connection state for the chart viewport and feed engines.
 * Adheres strictly to Module #4 requirements:
 * - Connected
 * - Connecting
 * - Reconnecting
 * - Disconnected
 * - HTTP/API Error
 * - WebSocket Error
 * - Authentication/API Error
 * - Data Stale
 * - Provider Unavailable
 */
sealed class ChartConnectionState(val label: String) {
    object Loading : ChartConnectionState("Loading Market Data...")
    object Connected : ChartConnectionState("Live Feed Connected")
    object Reconnecting : ChartConnectionState("Reconnecting to Feed...")
    object Disconnected : ChartConnectionState("Feed Disconnected")
    object DataUnavailable : ChartConnectionState("Market Data Unavailable")
    object Stale : ChartConnectionState("Market Data Stale - Awaiting live updates...")

    data class Connecting(val endpoint: String = "Binance") :
        ChartConnectionState("Connecting to $endpoint...")

    data class ReconnectingAttempt(val attempt: Int, val maxAttempts: Int = 5) :
        ChartConnectionState("Reconnecting ($attempt/$maxAttempts)...")

    data class HttpError(val code: Int, val details: String) :
        ChartConnectionState("Binance API error HTTP $code: $details")

    data class WebSocketError(val details: String) :
        ChartConnectionState("WebSocket Error: $details")

    data class AuthenticationError(val details: String) :
        ChartConnectionState("Auth Error: $details")

    data class ProviderUnavailable(val providerId: String, val reason: String) :
        ChartConnectionState("Provider $providerId Unavailable: $reason")

    data class Error(val message: String, val canRetry: Boolean = true) :
        ChartConnectionState("Data Error: $message")

    val isOnline: Boolean get() = this is Connected
    val isPending: Boolean get() = this is Loading || this is Connecting || this is Reconnecting || this is ReconnectingAttempt
    val isStale: Boolean get() = this is Stale
    val isError: Boolean get() = this is Error || this is HttpError || this is WebSocketError || this is AuthenticationError || this is ProviderUnavailable
}
