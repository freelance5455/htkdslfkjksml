package com.example.core.data.repository

import com.example.core.data.local.IQTradeDatabase
import com.example.core.data.local.entity.AppSettingsEntity
import com.example.core.data.local.entity.PaperAccountEntity
import com.example.core.data.local.entity.TradeRecordEntity
import com.example.core.data.market.MarketSymbolRepository
import com.example.core.data.security.SecureCredentialStorage
import com.example.core.network.binance.LiveAccountBalance
import com.example.core.network.binance.LiveOrderResult
import com.example.core.network.binance.LiveTradingGateway
import com.example.core.network.binance.RealBinanceLiveTradingGateway
import com.example.core.model.chart.OrderType
import com.example.core.model.chart.TradeSide
import com.example.core.data.local.entity.CachedNewsEntity
import com.example.features.news.model.NewsArticle
import com.example.features.news.network.NewsApiGateway
import com.example.features.news.network.NewsApiResult
import com.example.features.notifications.WhatsAppPreferences
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class IQTradeRepository(
    private val database: IQTradeDatabase,
    private val secureStorage: SecureCredentialStorage,
    val liveGateway: LiveTradingGateway = RealBinanceLiveTradingGateway(),
    val newsApiGateway: NewsApiGateway = NewsApiGateway()
) {
    private val settingsDao = database.appSettingsDao()
    private val paperDao = database.paperAccountDao()
    private val tradeDao = database.tradeRecordDao()
    private val cachedNewsDao = database.cachedNewsDao()

    val symbolRepository = MarketSymbolRepository(database.cachedSymbolDao())

    val settingsFlow: Flow<AppSettingsEntity> = settingsDao.getSettingsFlow()
        .map { entity ->
            entity ?: AppSettingsEntity() // Safe defaults: all modes OFF
        }

    val paperAccountFlow: Flow<PaperAccountEntity> = paperDao.getAccountFlow()
        .map { entity ->
            entity ?: PaperAccountEntity(balance = 10000.0, equity = 10000.0)
        }

    val tradeHistoryFlow: Flow<List<TradeRecordEntity>> = tradeDao.getAllTradesFlow()

    suspend fun getSettings(): AppSettingsEntity {
        return settingsDao.getSettings() ?: AppSettingsEntity()
    }

    suspend fun initializeDefaultsIfNeeded() {
        if (settingsDao.getSettings() == null) {
            settingsDao.insertOrUpdate(AppSettingsEntity())
        }
        if (paperDao.getAccount() == null) {
            paperDao.insertOrUpdate(PaperAccountEntity(balance = 10000.0, equity = 10000.0))
        }
        symbolRepository.initializeCacheIfNeeded()
    }

    suspend fun updateSelectedSection(section: String) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(selectedSection = section))
    }

    suspend fun updateMarketAndSymbol(market: String, symbol: String) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(selectedMarket = market, selectedSymbol = symbol))
    }

    suspend fun updateTimeframe(timeframe: String) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(selectedTimeframe = timeframe))
    }

    suspend fun updateTradingMode(mode: String) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(tradingMode = mode))
    }

    suspend fun updateCustomConfig(indicators: String, timeframes: String) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(
            current.copy(
                customSelectedIndicators = indicators,
                customSelectedTimeframes = timeframes
            )
        )
    }

    suspend fun setSmartMode(enabled: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(isSmartModeEnabled = enabled))
    }

    suspend fun setAutoTrading(enabled: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(isAutoTradingEnabled = enabled))
    }

    suspend fun setLiveTrading(enabled: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(isLiveTradingEnabled = enabled))
    }

    suspend fun setIndicatorsVisible(visible: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(showIndicators = visible))
    }

    suspend fun setVolumeVisible(visible: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(showVolume = visible))
    }

    suspend fun setSignalPlottingVisible(visible: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(showSignalPlotting = visible))
    }

    suspend fun setBinanceConnected(connected: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(binanceConnected = connected))
    }

    suspend fun setNewsApiConnected(connected: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(newsApiConnected = connected))
    }

    suspend fun updateOverlayPermission(granted: Boolean) {
        val current = settingsDao.getSettings() ?: AppSettingsEntity()
        settingsDao.insertOrUpdate(current.copy(overlayPermissionGranted = granted))
    }

    // Paper Account explicit operations
    suspend fun resetPaperAccount() {
        paperDao.resetAccount(10000.0)
    }

    suspend fun updatePaperBalance(newBalance: Double, newEquity: Double) {
        val current = paperDao.getAccount() ?: PaperAccountEntity(balance = 10000.0, equity = 10000.0)
        paperDao.update(current.copy(balance = newBalance, equity = newEquity, updatedAt = System.currentTimeMillis()))
    }

    // Secure credentials operations
    fun hasBinanceCredentials(): Boolean = secureStorage.hasBinanceCredentials()
    fun getBinanceApiKey(): String? = secureStorage.getBinanceApiKey()
    fun getBinanceSecretKey(): String? = secureStorage.getBinanceSecretKey()
    fun saveBinanceCredentials(apiKey: String, secretKey: String) {
        secureStorage.saveBinanceApiKey(apiKey)
        secureStorage.saveBinanceSecretKey(secretKey)
    }
    fun clearBinanceCredentials() {
        secureStorage.clearBinanceCredentials()
    }

    // --- Live Trading Gateway Operations (Module #9) ---
    suspend fun queryLiveAccountBalances(): Result<List<LiveAccountBalance>> {
        val key = getBinanceApiKey() ?: return Result.failure(IllegalStateException("Binance API key missing"))
        val secret = getBinanceSecretKey() ?: return Result.failure(IllegalStateException("Binance API secret missing"))
        return liveGateway.queryAccountBalances(key, secret)
    }

    suspend fun submitLiveOrder(
        symbol: String,
        side: TradeSide,
        orderType: OrderType,
        quantity: Double,
        price: Double? = null,
        stopPrice: Double? = null,
        clientOrderId: String
    ): LiveOrderResult {
        val key = getBinanceApiKey() ?: return LiveOrderResult.Error("Binance API key missing")
        val secret = getBinanceSecretKey() ?: return LiveOrderResult.Error("Binance API secret missing")
        return liveGateway.submitLiveOrder(
            apiKey = key,
            apiSecret = secret,
            symbol = symbol,
            side = side,
            orderType = orderType,
            quantity = quantity,
            price = price,
            stopPrice = stopPrice,
            clientOrderId = clientOrderId
        )
    }

    suspend fun queryLiveOrder(
        symbol: String,
        exchangeOrderId: String? = null,
        clientOrderId: String? = null
    ): LiveOrderResult {
        val key = getBinanceApiKey() ?: return LiveOrderResult.Error("Binance API key missing")
        val secret = getBinanceSecretKey() ?: return LiveOrderResult.Error("Binance API secret missing")
        return liveGateway.queryOrder(key, secret, symbol, exchangeOrderId, clientOrderId)
    }

    suspend fun cancelLiveOrder(
        symbol: String,
        exchangeOrderId: String? = null,
        clientOrderId: String? = null
    ): LiveOrderResult {
        val key = getBinanceApiKey() ?: return LiveOrderResult.Error("Binance API key missing")
        val secret = getBinanceSecretKey() ?: return LiveOrderResult.Error("Binance API secret missing")
        return liveGateway.cancelLiveOrder(key, secret, symbol, exchangeOrderId, clientOrderId)
    }

    suspend fun queryOpenLiveOrders(symbol: String? = null): Result<List<LiveOrderResult.Success>> {
        val key = getBinanceApiKey() ?: return Result.failure(IllegalStateException("Binance API key missing"))
        val secret = getBinanceSecretKey() ?: return Result.failure(IllegalStateException("Binance API secret missing"))
        return liveGateway.queryOpenOrders(key, secret, symbol)
    }

    suspend fun getOpenLiveTrades(): List<TradeRecordEntity> = tradeDao.getOpenTrades(isPaper = false)
    suspend fun getTradeByExchangeOrderId(exchangeOrderId: String): TradeRecordEntity? =
        tradeDao.getTradeByExchangeOrderId(exchangeOrderId)
    suspend fun getTradeByClientOrderId(clientOrderId: String): TradeRecordEntity? =
        tradeDao.getTradeByClientOrderId(clientOrderId)
    suspend fun insertTrade(trade: TradeRecordEntity): Long = tradeDao.insertTrade(trade)
    suspend fun updateTrade(trade: TradeRecordEntity) = tradeDao.updateTrade(trade)
    suspend fun closeTrade(id: Long, closePrice: Double, pnl: Double, closeTime: Long = System.currentTimeMillis()) =
        tradeDao.closeTrade(id, closePrice, pnl, closeTime)

    fun hasNewsApiKey(): Boolean = !secureStorage.getNewsApiKey().isNullOrBlank()
    fun getNewsApiKey(): String? = secureStorage.getNewsApiKey()
    fun saveNewsApiKey(apiKey: String) {
        secureStorage.saveNewsApiKey(apiKey)
    }
    fun clearNewsApiKey() {
        secureStorage.clearNewsApiKey()
    }

    suspend fun fetchLiveNews(apiKey: String? = getNewsApiKey()): NewsApiResult {
        val key = apiKey ?: getNewsApiKey().orEmpty()
        return newsApiGateway.fetchNews(key)
    }

    suspend fun getCachedNews(): List<NewsArticle> {
        return cachedNewsDao.getAllCachedNews().map { it.toNewsArticle() }
    }

    suspend fun saveCachedNews(articles: List<NewsArticle>) {
        val entities = articles.map { CachedNewsEntity.fromNewsArticle(it) }
        cachedNewsDao.insertAll(entities)
    }

    suspend fun clearCachedNews() {
        cachedNewsDao.clearAll()
    }

    fun getWhatsAppPhoneNumber(): String? = secureStorage.getWhatsAppPhoneNumber()
    fun getWhatsAppApiKey(): String? = secureStorage.getWhatsAppApiKey()
    fun getWhatsAppPhoneNumberId(): String? = secureStorage.getWhatsAppPhoneNumberId()
    fun getWhatsAppPreferences(): WhatsAppPreferences = secureStorage.getWhatsAppPreferences()
    fun saveWhatsAppPreferences(prefs: WhatsAppPreferences) {
        secureStorage.saveWhatsAppPreferences(prefs)
    }
    fun saveWhatsAppConfig(phoneNumber: String, apiKey: String, phoneNumberId: String = "") {
        secureStorage.saveWhatsAppPhoneNumber(phoneNumber)
        secureStorage.saveWhatsAppApiKey(apiKey)
        if (phoneNumberId.isNotBlank()) {
            secureStorage.saveWhatsAppPhoneNumberId(phoneNumberId)
        }
    }
    fun clearWhatsAppConfig() {
        secureStorage.clearWhatsAppConfig()
    }

    fun getWhatsAppConnectionMethod(): String = secureStorage.getWhatsAppConnectionMethod()
    fun saveWhatsAppConnectionMethod(method: String) = secureStorage.saveWhatsAppConnectionMethod(method)
    fun getWhatsAppConnectionStatus(): String = secureStorage.getWhatsAppConnectionStatus()
    fun saveWhatsAppConnectionStatus(status: String) = secureStorage.saveWhatsAppConnectionStatus(status)
    fun getWhatsAppLastVerifiedTime(): String? = secureStorage.getWhatsAppLastVerifiedTime()
    fun saveWhatsAppLastVerifiedTime(time: String) = secureStorage.saveWhatsAppLastVerifiedTime(time)
    fun getWhatsAppConnectedAccount(): String? = secureStorage.getWhatsAppConnectedAccount()
    fun saveWhatsAppConnectedAccount(account: String) = secureStorage.saveWhatsAppConnectedAccount(account)
    fun isEventDeduplicated(eventKey: String, nowMs: Long, windowMs: Long): Boolean =
        secureStorage.isEventDeduplicated(eventKey, nowMs, windowMs)
    fun recordEventSent(eventKey: String, timestamp: Long) =
        secureStorage.recordEventSent(eventKey, timestamp)
    fun disconnectWhatsApp() = secureStorage.disconnectWhatsApp()
}
