package com.example.core.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "trade_records")
data class TradeRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val side: String, // BUY, SELL
    val orderType: String, // MARKET, LIMIT
    val quantity: Double,
    val price: Double,
    val total: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val isPaper: Boolean = true,
    val status: String = "FILLED",
    val stopLoss: Double? = null,
    val takeProfit: Double? = null,
    val isOpen: Boolean = true,
    val closePrice: Double? = null,
    val realizedPnl: Double? = null,
    val closeTimestamp: Long? = null,
    val exchangeOrderId: String? = null,
    val clientOrderId: String? = null,
    val requestedPrice: Double? = null,
    val executedQuantity: Double? = null,
    val averageFillPrice: Double? = null,
    val updatedTimestamp: Long? = null,
    val filledTimestamp: Long? = null,
    val commission: Double? = null,
    val commissionAsset: String? = null
) {
    val isLive: Boolean get() = !isPaper
}
