package com.example.core.model.chart

import org.json.JSONObject

enum class TradeSide(val label: String) {
    BUY("BUY / LONG"),
    SELL("SELL / SHORT")
}

data class ExecutedTradeMarker(
    val id: String,
    val symbol: String,
    val side: TradeSide,
    val entryPrice: Double,
    val entryTime: Long, // seconds
    val exitPrice: Double? = null,
    val exitTime: Long? = null,
    val stopLossPrice: Double? = null,
    val takeProfitPrice: Double? = null,
    val isOpen: Boolean = true,
    val isPaper: Boolean = true,
    val quantity: Double = 0.0
) {
    /**
     * Converts to Lightweight Charts marker specification for the entry point
     */
    fun toEntryMarkerJson(): JSONObject {
        val obj = JSONObject()
        obj.put("time", entryTime)
        obj.put("position", if (side == TradeSide.BUY) "belowBar" else "aboveBar")
        obj.put("color", if (side == TradeSide.BUY) "#00E676" else "#FF3D57")
        obj.put("shape", if (side == TradeSide.BUY) "arrowUp" else "arrowDown")
        val mode = if (isPaper) "[PAPER]" else "[LIVE]"
        obj.put("text", "$mode ${side.name} @ %.2f".format(entryPrice))
        return obj
    }

    /**
     * Converts to Lightweight Charts marker specification for the exit point if closed
     */
    fun toExitMarkerJson(): JSONObject? {
        if (isOpen || exitTime == null || exitPrice == null) return null
        val obj = JSONObject()
        obj.put("time", exitTime)
        obj.put("position", if (side == TradeSide.BUY) "aboveBar" else "belowBar")
        obj.put("color", "#FFB300")
        obj.put("shape", "circle")
        val mode = if (isPaper) "[PAPER]" else "[LIVE]"
        obj.put("text", "$mode EXIT @ %.2f".format(exitPrice))
        return obj
    }
}
