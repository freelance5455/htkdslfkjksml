package com.example.core.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ConnectionState
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.WarningAmber

@Composable
fun StatusIndicator(
    label: String,
    dotColor: Color,
    modifier: Modifier = Modifier,
    backgroundColor: Color = SurfaceElevated
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            modifier = Modifier.padding(start = 5.dp)
        )
    }
}

@Composable
fun ConnectionStatusBadge(
    connectionState: ConnectionState,
    serviceName: String = "Binance",
    modifier: Modifier = Modifier
) {
    val (dotColor, label) = when (connectionState) {
        is ConnectionState.Connected -> Pair(BullGreen, "$serviceName: Connected")
        is ConnectionState.Connecting -> Pair(WarningAmber, "$serviceName: Connecting")
        is ConnectionState.Reconnecting -> Pair(WarningAmber, "$serviceName: Reconnecting")
        is ConnectionState.Disconnected -> Pair(TextDisabled, "$serviceName: Offline")
        is ConnectionState.Error -> Pair(BearRed, "$serviceName: Error")
        is ConnectionState.AuthenticationError -> Pair(BearRed, "$serviceName: Auth Failed")
    }

    StatusIndicator(
        label = label,
        dotColor = dotColor,
        modifier = modifier
    )
}

@Composable
fun TradingModeBadge(
    isPaper: Boolean,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isPaper) Color(0x2600E5FF) else Color(0x260ECB81)
    val textColor = if (isPaper) CyanAccent else BullGreen
    val label = if (isPaper) "PAPER MODE" else "LIVE MODE"

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .border(0.5.dp, textColor.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = textColor,
            letterSpacing = 0.5.sp
        )
    }
}
