package com.example.core.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "market_sync_status")
data class MarketSyncStatusEntity(
    @PrimaryKey val marketCategory: String,
    val lastSyncTimestamp: Long = System.currentTimeMillis(),
    val symbolCount: Int = 0,
    val status: String = "SUCCESS", // "SUCCESS", "FAILED", "OFFLINE"
    val errorMessage: String? = null
)
