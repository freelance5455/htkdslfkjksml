package com.example.core.model

/**
 * Reusable connection-state model for external endpoints (Binance WebSocket,
 * Binance REST API, News API, etc.).
 */
sealed class ConnectionState {
    object Disconnected : ConnectionState()
    object Connecting : ConnectionState()
    object Connected : ConnectionState()
    object Reconnecting : ConnectionState()
    data class Error(val message: String) : ConnectionState()
    data class AuthenticationError(val message: String) : ConnectionState()

    val isConnected: Boolean
        get() = this is Connected

    val label: String
        get() = when (this) {
            is Disconnected -> "Disconnected"
            is Connecting -> "Connecting..."
            is Connected -> "Connected"
            is Reconnecting -> "Reconnecting..."
            is Error -> "Error"
            is AuthenticationError -> "Auth Error"
        }
}
