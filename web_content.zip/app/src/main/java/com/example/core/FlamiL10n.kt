package com.example.core

import java.util.Locale

enum class AppLanguage(val code: String, val nativeName: String) {
    AUTO("auto", "Auto"),
    RU("ru", "Русский"),
    EN("en", "English"),
    ES("es", "Español"),
    DE("de", "Deutsch"),
    FR("fr", "Français"),
    UK("uk", "Українська"),
    ZH("zh", "中文");

    companion object {
        fun fromCode(code: String): AppLanguage =
            entries.firstOrNull { it.code == code } ?: AUTO
    }
}

data class FlamiStrings(
    val appTitle: String,
    val tagline: String,
    val signInTitle: String,
    val signInSubtitle: String,
    val signInWithGoogle: String,
    val signOut: String,
    val newChat: String,
    val chatsTitle: String,
    val searchHistoryHint: String,
    val searchResultsTitle: String,
    val noSearchResults: String,
    val memoryTitle: String,
    val memorySubtitle: String,
    val addMemoryHint: String,
    val addMemoryButton: String,
    val emptyMemoryHint: String,
    val settingsTitle: String,
    val languageLabel: String,
    val modelModeLabel: String,
    val modeBalanced: String,
    val modeReasoning: String,
    val modeFast: String,
    val memoryToggleLabel: String,
    val ttsToggleLabel: String,
    val ttsRateLabel: String,
    val inputHint: String,
    val attachImageDesc: String,
    val sendDesc: String,
    val stopDesc: String,
    val generatingLabel: String,
    val interruptingNotice: String,
    val welcomeTitle: String,
    val welcomeSubtitle: String,
    val quickPromptCode: String,
    val quickPromptMath: String,
    val quickPromptWebZip: String,
    val quickPromptLearn: String,
    val copyAction: String,
    val copiedToast: String,
    val speakAction: String,
    val stopSpeakAction: String,
    val exportZipAction: String,
    val exportHtmlAction: String,
    val exportMdAction: String,
    val exportSuccess: String,
    val renameChat: String,
    val deleteChat: String,
    val pinChat: String,
    val unpinChat: String,
    val cancel: String,
    val save: String,
    val retry: String,
    val syncActive: String,
    val imageAttachedLabel: String,
    val memoryCategoryPreference: String,
    val memoryCategoryProfile: String,
    val memoryCategoryProject: String,
    val memoryCategoryLearning: String,
    val memoryCategoryGeneral: String,
    val deleteChatConfirm: String,
    val delete: String
)

object FlamiL10n {
    fun resolveEffectiveCode(preferredCode: String): String {
        if (preferredCode != "auto") return preferredCode
        val sys = Locale.getDefault().language.lowercase()
        return when (sys) {
            "ru", "en", "es", "de", "fr", "uk", "zh" -> sys
            else -> "ru"
        }
    }

    fun strings(preferredCode: String): FlamiStrings {
        return when (resolveEffectiveCode(preferredCode)) {
            "en" -> englishStrings()
            "es" -> spanishStrings()
            "de" -> germanStrings()
            "fr" -> frenchStrings()
            "uk" -> ukrainianStrings()
            "zh" -> chineseStrings()
            else -> russianStrings()
        }
    }

    private fun russianStrings() = FlamiStrings(
        appTitle = "FLAMI AI",
        tagline = "Интеллектуальный ассистент с памятью и облачной синхронизацией",
        signInTitle = "Добро пожаловать в FLAMI AI",
        signInSubtitle = "Войдите через Google, чтобы синхронизировать чаты, контекстную память и настройки между всеми вашими устройствами.",
        signInWithGoogle = "Войти через Google",
        signOut = "Выйти из аккаунта",
        newChat = "Новый чат",
        chatsTitle = "Чаты и история",
        searchHistoryHint = "Поиск по сообщениям и чатам...",
        searchResultsTitle = "Результаты поиска",
        noSearchResults = "Ничего не найдено по вашему запросу",
        memoryTitle = "Контекстная память",
        memorySubtitle = "Факты и предпочтения, которые FLAMI AI учитывает в каждом диалоге",
        addMemoryHint = "Например: Пишу на Kotlin и Jetpack Compose...",
        addMemoryButton = "Запомнить",
        emptyMemoryHint = "Память пока пуста. Расскажите о себе в чате или добавьте факт вручную.",
        settingsTitle = "Настройки FLAMI AI",
        languageLabel = "Язык интерфейса и ответов",
        modelModeLabel = "Режим интеллекта",
        modeBalanced = "Баланс (3.8 Flash)",
        modeReasoning = "Глубокий анализ",
        modeFast = "Быстрый (Lite)",
        memoryToggleLabel = "Авто-извлечение контекстной памяти",
        ttsToggleLabel = "Озвучивание ответов (TTS)",
        ttsRateLabel = "Скорость речи",
        inputHint = "Спросите что угодно: код, математику, текст или загрузите фото...",
        attachImageDesc = "Прикрепить изображение",
        sendDesc = "Отправить сообщение",
        stopDesc = "Остановить генерацию",
        generatingLabel = "FLAMI AI думает...",
        interruptingNotice = "Можно отправить новое сообщение прямо сейчас",
        welcomeTitle = "Чем помочь сегодня?",
        welcomeSubtitle = "Анализ кода и изображений, HTML/CSS/JS проекты, пошаговая математика, обучение и документы с экспортом в ZIP.",
        quickPromptCode = "Напиши адаптивную веб-страницу (HTML + CSS + JS)",
        quickPromptMath = "Реши пошагово квадратное уравнение и объясни логику",
        quickPromptWebZip = "Создай интерактивный калькулятор на HTML/JS для ZIP-архива",
        quickPromptLearn = "Составь план изучения Kotlin Coroutines и Flow",
        copyAction = "Копировать",
        copiedToast = "Скопировано в буфер обмена",
        speakAction = "Озвучить",
        stopSpeakAction = "Стоп",
        exportZipAction = "Экспорт ZIP (с index.html)",
        exportHtmlAction = "Экспорт HTML",
        exportMdAction = "Экспорт Markdown",
        exportSuccess = "Файл успешно сохранён",
        renameChat = "Переименовать",
        deleteChat = "Удалить чат",
        pinChat = "Закрепить",
        unpinChat = "Открепить",
        cancel = "Отмена",
        save = "Сохранить",
        retry = "Повторить",
        syncActive = "Облачная синхронизация активна",
        imageAttachedLabel = "Изображение прикреплено",
        memoryCategoryPreference = "Предпочтение",
        memoryCategoryProfile = "Профиль",
        memoryCategoryProject = "Проект",
        memoryCategoryLearning = "Обучение",
        memoryCategoryGeneral = "Общее",
        deleteChatConfirm = "Удалить этот чат и всю его историю сообщений?",
        delete = "Удалить"
    )

    private fun englishStrings() = FlamiStrings(
        appTitle = "FLAMI AI",
        tagline = "Intelligent assistant with contextual memory and cloud sync",
        signInTitle = "Welcome to FLAMI AI",
        signInSubtitle = "Sign in with Google to synchronize chats, contextual memory, and preferences across all your devices.",
        signInWithGoogle = "Sign in with Google",
        signOut = "Sign out",
        newChat = "New Chat",
        chatsTitle = "Chats & History",
        searchHistoryHint = "Search messages and chats...",
        searchResultsTitle = "Search Results",
        noSearchResults = "No matching messages found",
        memoryTitle = "Contextual Memory",
        memorySubtitle = "Facts and preferences FLAMI AI uses to personalize every conversation",
        addMemoryHint = "e.g., I build Android apps with Kotlin and Compose...",
        addMemoryButton = "Remember",
        emptyMemoryHint = "No memories yet. Share your preferences in chat or add one manually.",
        settingsTitle = "FLAMI AI Settings",
        languageLabel = "Interface & Response Language",
        modelModeLabel = "Intelligence Mode",
        modeBalanced = "Balanced (3.8 Flash)",
        modeReasoning = "Deep Reasoning",
        modeFast = "Fast (Lite)",
        memoryToggleLabel = "Auto-extract contextual memory",
        ttsToggleLabel = "Text-to-Speech (TTS)",
        ttsRateLabel = "Speech Rate",
        inputHint = "Ask anything: code, math, analysis, or attach an image...",
        attachImageDesc = "Attach image",
        sendDesc = "Send message",
        stopDesc = "Stop generation",
        generatingLabel = "FLAMI AI is thinking...",
        interruptingNotice = "You can send a new message anytime",
        welcomeTitle = "How can I help today?",
        welcomeSubtitle = "Code & image analysis, HTML/CSS/JS builds, step-by-step math, tutoring, and document export with root index.html ZIP.",
        quickPromptCode = "Build a responsive landing page in HTML, CSS, and JS",
        quickPromptMath = "Solve a differential equation step by step",
        quickPromptWebZip = "Create a complete interactive HTML/JS app ready for ZIP export",
        quickPromptLearn = "Create a study roadmap for Kotlin Coroutines & Flow",
        copyAction = "Copy",
        copiedToast = "Copied to clipboard",
        speakAction = "Read aloud",
        stopSpeakAction = "Stop",
        exportZipAction = "Export ZIP (root index.html)",
        exportHtmlAction = "Export HTML",
        exportMdAction = "Export Markdown",
        exportSuccess = "File exported successfully",
        renameChat = "Rename",
        deleteChat = "Delete chat",
        pinChat = "Pin",
        unpinChat = "Unpin",
        cancel = "Cancel",
        save = "Save",
        retry = "Retry",
        syncActive = "Cloud sync active",
        imageAttachedLabel = "Image attached",
        memoryCategoryPreference = "Preference",
        memoryCategoryProfile = "Profile",
        memoryCategoryProject = "Project",
        memoryCategoryLearning = "Learning",
        memoryCategoryGeneral = "General",
        deleteChatConfirm = "Delete this chat and all its message history?",
        delete = "Delete"
    )

    private fun spanishStrings() = englishStrings().copy(
        tagline = "Asistente inteligente con memoria contextual y sincronización en la nube",
        signInTitle = "Bienvenido a FLAMI AI",
        signInSubtitle = "Inicia sesión con Google para sincronizar chats, memoria contextual y preferencias entre dispositivos.",
        signInWithGoogle = "Iniciar sesión con Google",
        signOut = "Cerrar sesión",
        newChat = "Nuevo chat",
        chatsTitle = "Chats e historial",
        searchHistoryHint = "Buscar mensajes y chats...",
        memoryTitle = "Memoria contextual",
        settingsTitle = "Configuración",
        languageLabel = "Idioma",
        inputHint = "Pregunta lo que quieras: código, matemáticas o adjunta una imagen...",
        welcomeTitle = "¿Cómo puedo ayudarte hoy?",
        exportZipAction = "Exportar ZIP (con index.html)",
        cancel = "Cancelar",
        save = "Guardar",
        delete = "Eliminar"
    )

    private fun germanStrings() = englishStrings().copy(
        tagline = "Intelligenter Assistent mit Kontextgedächtnis und Cloud-Sync",
        signInTitle = "Willkommen bei FLAMI AI",
        signInSubtitle = "Melde dich mit Google an, um Chats, Kontextgedächtnis und Einstellungen geräteübergreifend zu synchronisieren.",
        signInWithGoogle = "Mit Google anmelden",
        signOut = "Abmelden",
        newChat = "Neuer Chat",
        chatsTitle = "Chats & Verlauf",
        searchHistoryHint = "Nachrichten durchsuchen...",
        memoryTitle = "Kontextgedächtnis",
        settingsTitle = "Einstellungen",
        languageLabel = "Sprache",
        inputHint = "Frag alles: Code, Mathe, Texte oder füge ein Bild hinzu...",
        welcomeTitle = "Wobei kann ich heute helfen?",
        exportZipAction = "ZIP exportieren (mit index.html)",
        cancel = "Abbrechen",
        save = "Speichern",
        delete = "Löschen"
    )

    private fun frenchStrings() = englishStrings().copy(
        tagline = "Assistant intelligent avec mémoire contextuelle et synchronisation cloud",
        signInTitle = "Bienvenue dans FLAMI AI",
        signInSubtitle = "Connectez-vous avec Google pour synchroniser vos discussions et votre mémoire contextuelle sur tous vos appareils.",
        signInWithGoogle = "Se connecter avec Google",
        signOut = "Se déconnecter",
        newChat = "Nouvelle discussion",
        chatsTitle = "Discussions et historique",
        searchHistoryHint = "Rechercher dans l'historique...",
        memoryTitle = "Mémoire contextuelle",
        settingsTitle = "Paramètres",
        languageLabel = "Langue",
        inputHint = "Posez votre question : code, maths, analyse ou image...",
        welcomeTitle = "Comment puis-je vous aider ?",
        exportZipAction = "Exporter ZIP (index.html racine)",
        cancel = "Annuler",
        save = "Enregistrer",
        delete = "Supprimer"
    )

    private fun ukrainianStrings() = russianStrings().copy(
        tagline = "Інтелектуальний асистент із контекстною пам'яттю та хмарною синхронізацією",
        signInTitle = "Ласкаво просимо до FLAMI AI",
        signInSubtitle = "Увійдіть через Google, щоб синхронізувати чати, контекстну пам'ять та налаштування між пристроями.",
        signInWithGoogle = "Увійти через Google",
        signOut = "Вийти з акаунту",
        newChat = "Новий чат",
        chatsTitle = "Чати та історія",
        searchHistoryHint = "Пошук за повідомленнями та чатами...",
        memoryTitle = "Контекстна пам'ять",
        settingsTitle = "Налаштування FLAMI AI",
        languageLabel = "Мова інтерфейсу та відповідей",
        inputHint = "Запитайте будь-що: код, математика, текст або зображення...",
        welcomeTitle = "Чим допомогти сьогодні?",
        exportZipAction = "Експорт ZIP (з index.html)",
        cancel = "Скасувати",
        save = "Зберегти",
        delete = "Видалити"
    )

    private fun chineseStrings() = englishStrings().copy(
        tagline = "具有上下文记忆和云同步功能的智能助手",
        signInTitle = "欢迎使用 FLAMI AI",
        signInSubtitle = "使用 Google 登录，在所有设备间同步聊天记录、上下文记忆和偏好设置。",
        signInWithGoogle = "使用 Google 登录",
        signOut = "退出登录",
        newChat = "新对话",
        chatsTitle = "对话与历史记录",
        searchHistoryHint = "搜索消息与对话...",
        memoryTitle = "上下文记忆",
        settingsTitle = "FLAMI AI 设置",
        languageLabel = "界面与回复语言",
        inputHint = "输入问题：代码、数学、文本分析或上传图片...",
        welcomeTitle = "今天我可以帮您什么？",
        exportZipAction = "导出 ZIP（根目录含 index.html）",
        cancel = "取消",
        save = "保存",
        delete = "删除"
    )
}
