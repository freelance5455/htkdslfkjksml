package com.example.core.data.chart.binance

import android.util.Log
import com.example.core.model.Timeframe
import com.example.core.model.chart.Candle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.concurrent.TimeUnit
import kotlin.math.min
import kotlin.random.Random

/**
 * Centralized Binance WebSocket Manager.
 *
 * Responsibilities:
 * - Connects to real-time Binance Kline stream
 * - Supports dynamic symbol and timeframe switching
 * - Manages connection lifecycle (CONNECTING, CONNECTED, RECONNECTING, STALE, DISCONNECTED, ERROR)
 * - Implements automatic exponential backoff reconnection with endpoint failover
 * - Stale data detection (flags STALE if no tick received within 15 seconds)
 * - Safe data parsing via BinanceKlineProcessor
 * - Emits valid candles to liveCandleFlow
 * - Prevents duplicate connections and memory leaks
 */
class BinanceWebSocketManager(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO),
    client: OkHttpClient? = null,
    private val webSocketFactory: WebSocket.Factory? = null
) {
    companion object {
        private const val TAG = "BinanceWebSocketManager"
        private const val STALE_THRESHOLD_MS = 25_000L
        private const val BASE_BACKOFF_MS = 1_000L
        private const val MAX_BACKOFF_MS = 30_000L
    }

    private val webSocketClient: OkHttpClient = client?.newBuilder()
        ?.readTimeout(0, TimeUnit.MILLISECONDS)
        ?.pingInterval(20, TimeUnit.SECONDS)
        ?.connectTimeout(10, TimeUnit.SECONDS)
        ?.retryOnConnectionFailure(true)
        ?.build()
        ?: OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .connectTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()

    private val _streamState = MutableStateFlow(BinanceStreamState())
    val streamState: StateFlow<BinanceStreamState> = _streamState.asStateFlow()

    private val _liveCandleFlow = MutableSharedFlow<Candle>(replay = 1, extraBufferCapacity = 64)
    val liveCandleFlow: SharedFlow<Candle> = _liveCandleFlow.asSharedFlow()

    private var activeWebSocket: WebSocket? = null
    private var activeConnectionId: Long = 0L
    private var staleCheckJob: Job? = null
    private var reconnectJob: Job? = null

    private var currentSymbol: String = ""
    private var currentTimeframe: Timeframe? = null
    private var currentEndpointIndex: Int = 0
    private var isIntentionallyClosed: Boolean = false

    init {
        startStaleDataMonitor()
    }

    /**
     * Connect or switch stream to a specific symbol and timeframe.
     * Guarantees that only ONE active WebSocket exists for the current symbol and timeframe.
     */
    @Synchronized
    fun connect(symbol: String, timeframe: Timeframe) {
        val cleanSymbol = symbol.replace("/", "").uppercase()
        val interval = timeframe.intervalKey

        // Prevent duplicate connection to the exact same stream if already healthy or connecting
        if (activeWebSocket != null &&
            currentSymbol == cleanSymbol &&
            currentTimeframe == timeframe &&
            (_streamState.value.status == BinanceStreamStatus.CONNECTED || _streamState.value.status == BinanceStreamStatus.CONNECTING)
        ) {
            Log.d(TAG, "Already active on $cleanSymbol@kline_$interval, ignoring duplicate connect call")
            return
        }

        currentSymbol = cleanSymbol
        currentTimeframe = timeframe
        isIntentionallyClosed = false

        // Cancel any pending reconnect job
        reconnectJob?.cancel()
        reconnectJob = null

        // Cancel and tear down previous WebSocket before creating a new one
        cancelAndCloseActiveWebSocket()

        openWebSocketConnection()
    }

    @Synchronized
    private fun openWebSocketConnection() {
        if (currentSymbol.isEmpty() || currentTimeframe == null || isIntentionallyClosed) {
            return
        }

        // Cancel any lingering active socket and advance connection ID so that cancellation
        // callbacks (e.g. SocketException: Software caused connection abort) are cleanly dropped as stale.
        val oldWs = activeWebSocket
        activeWebSocket = null
        val myConnectionId = ++activeConnectionId
        if (oldWs != null) {
            try { oldWs.cancel() } catch (_: Exception) {}
        }
        val timeframe = currentTimeframe ?: return
        val interval = timeframe.intervalKey
        val wsEndpoints = BinanceEndpointConfig.WS_ENDPOINTS
        val wsBaseUrl = wsEndpoints[currentEndpointIndex % wsEndpoints.size]
        val streamUrl = BinanceEndpointConfig.buildWebSocketUrl(wsBaseUrl, currentSymbol, interval)

        _streamState.value = _streamState.value.copy(
            status = BinanceStreamStatus.CONNECTING,
            activeSymbol = currentSymbol,
            activeInterval = interval,
            currentEndpoint = wsBaseUrl,
            errorMessage = null
        )

        Log.i(TAG, "Connecting Binance WebSocket (#$myConnectionId) to: $streamUrl")

        val request = Request.Builder()
            .url(streamUrl)
            .addHeader("User-Agent", "IQTradePro-Android/1.0")
            .build()

        val factory = webSocketFactory ?: webSocketClient
        activeWebSocket = factory.newWebSocket(request, createWebSocketListener(myConnectionId))
    }

    private fun createWebSocketListener(connectionId: Long): WebSocketListener {
        return object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (connectionId != activeConnectionId) {
                    Log.d(TAG, "Ignoring onOpen for stale connection #$connectionId")
                    try { webSocket.cancel() } catch (_: Exception) {}
                    return
                }

                Log.i(TAG, "WebSocket #$connectionId connected successfully to ${_streamState.value.currentEndpoint}")

                // Cancel any pending reconnect attempt upon successful connection
                reconnectJob?.cancel()
                reconnectJob = null

                val now = System.currentTimeMillis()
                _streamState.value = _streamState.value.copy(
                    status = BinanceStreamStatus.CONNECTED,
                    lastMessageTimestamp = now,
                    reconnectAttempt = 0,
                    errorMessage = null
                )
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (connectionId != activeConnectionId) {
                    return
                }

                val now = System.currentTimeMillis()
                val timeframe = currentTimeframe ?: return
                val interval = timeframe.intervalKey

                // Update health state
                if (_streamState.value.status == BinanceStreamStatus.STALE ||
                    _streamState.value.status == BinanceStreamStatus.CONNECTING
                ) {
                    _streamState.value = _streamState.value.copy(
                        status = BinanceStreamStatus.CONNECTED,
                        lastMessageTimestamp = now,
                        errorMessage = null
                    )
                } else {
                    _streamState.value = _streamState.value.copy(lastMessageTimestamp = now)
                }

                // Process Kline payload
                val parseResult = BinanceKlineProcessor.parseKlineMessage(
                    rawJson = text,
                    expectedSymbol = currentSymbol,
                    expectedInterval = interval
                )

                parseResult.onSuccess { candle ->
                    scope.launch {
                        _liveCandleFlow.emit(candle)
                    }
                }.onFailure { error ->
                    // Malformed or non-kline ping message; log at debug level
                    Log.d(TAG, "Non-kline or skipped message: ${error.message}")
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                if (connectionId != activeConnectionId) return
                Log.w(TAG, "WebSocket #$connectionId closing (code $code): $reason")
                try {
                    webSocket.close(1000, null)
                } catch (_: Exception) {}
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (connectionId != activeConnectionId) {
                    Log.d(TAG, "Ignoring onClosed for stale connection #$connectionId")
                    return
                }

                Log.i(TAG, "WebSocket #$connectionId closed (code $code): $reason")
                activeWebSocket = null

                if (isIntentionallyClosed) {
                    _streamState.value = _streamState.value.copy(status = BinanceStreamStatus.DISCONNECTED)
                } else if (code == 1000) {
                    // Normal clean closure: do not enter continuous reconnect loop
                    Log.i(TAG, "WebSocket #$connectionId cleanly closed with code 1000; not reconnecting automatically.")
                    _streamState.value = _streamState.value.copy(status = BinanceStreamStatus.DISCONNECTED)
                } else {
                    // Unexpected server closure (code != 1000): schedule reconnection
                    scheduleReconnect("Connection closed: $reason (code $code)")
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (connectionId != activeConnectionId || isIntentionallyClosed) {
                    Log.d(TAG, "Ignoring onFailure for inactive connection #$connectionId")
                    return
                }

                val responseMsg = response?.let { "HTTP ${it.code}: ${it.message}" } ?: (t.message ?: "Connection failure")
                activeWebSocket = null

                val isNetworkIssue = isExpectedNetworkIssue(t)
                if (isNetworkIssue) {
                    Log.w(TAG, "WebSocket #$connectionId network unreachable or disconnected: $responseMsg")
                } else {
                    Log.w(TAG, "WebSocket #$connectionId failure: $responseMsg")
                }

                if (!isIntentionallyClosed) {
                    // Fall back to alternative Binance WebSocket cluster
                    currentEndpointIndex++
                    val isDnsIssue = t is java.net.UnknownHostException || responseMsg.contains("Unable to resolve host", ignoreCase = true)
                    scheduleReconnect("Connection retry: $responseMsg", isDnsIssue = isDnsIssue)
                } else {
                    _streamState.value = _streamState.value.copy(
                        status = BinanceStreamStatus.DISCONNECTED,
                        errorMessage = responseMsg
                    )
                }
            }
        }
    }

    private fun isExpectedNetworkIssue(t: Throwable): Boolean {
        val msg = t.message ?: ""
        return t is java.net.UnknownHostException ||
                t is java.net.SocketException ||
                t is java.net.SocketTimeoutException ||
                t is java.net.ConnectException ||
                t is java.io.InterruptedIOException ||
                t is java.io.EOFException ||
                t is javax.net.ssl.SSLException ||
                msg.contains("Software caused connection abort", ignoreCase = true) ||
                msg.contains("Unable to resolve host", ignoreCase = true) ||
                msg.contains("Socket closed", ignoreCase = true) ||
                msg.contains("Canceled", ignoreCase = true) ||
                msg.contains("ENETUNREACH", ignoreCase = true) ||
                msg.contains("EHOSTUNREACH", ignoreCase = true) ||
                msg.contains("ECONNREFUSED", ignoreCase = true) ||
                msg.contains("ECONNRESET", ignoreCase = true) ||
                msg.contains("Connection reset", ignoreCase = true)
    }

    private fun scheduleReconnect(reason: String, isDnsIssue: Boolean = false) {
        if (isIntentionallyClosed) return

        // Prevent redundant reconnect jobs
        if (reconnectJob?.isActive == true) {
            Log.d(TAG, "Reconnect job already active; keeping existing schedule")
            return
        }

        reconnectJob = scope.launch {
            val currentAttempt = _streamState.value.reconnectAttempt + 1
            val baseDelay = if (isDnsIssue) 5_000L else BASE_BACKOFF_MS
            val backoffMs = min(baseDelay * (1L shl min(currentAttempt, 5)), MAX_BACKOFF_MS)
            val jitterMs = Random.nextLong(100, 500)
            val totalDelay = backoffMs + jitterMs

            _streamState.value = _streamState.value.copy(
                status = BinanceStreamStatus.RECONNECTING,
                reconnectAttempt = currentAttempt,
                errorMessage = "$reason. Reconnecting in ${totalDelay / 1000}s..."
            )

            Log.w(TAG, "Scheduling reconnect attempt #$currentAttempt in ${totalDelay}ms")
            delay(totalDelay)

            if (!isIntentionallyClosed && isActive) {
                openWebSocketConnection()
            }
        }
    }

    /**
     * Stale Data Detection loop.
     * If no ticks or candles are received for > 25s while marked CONNECTED, marks STALE and
     * initiates a single clean reconnection to recover the live stream.
     */
    private fun startStaleDataMonitor() {
        staleCheckJob?.cancel()
        staleCheckJob = scope.launch {
            while (isActive) {
                delay(3000)
                val state = _streamState.value
                if (state.status == BinanceStreamStatus.CONNECTED && state.lastMessageTimestamp > 0L) {
                    val elapsed = System.currentTimeMillis() - state.lastMessageTimestamp
                    if (elapsed > STALE_THRESHOLD_MS && !isIntentionallyClosed) {
                        Log.w(TAG, "Stale data detected! No market updates received for ${elapsed / 1000}s. Reconnecting stale stream.")
                        _streamState.value = state.copy(
                            status = BinanceStreamStatus.STALE,
                            errorMessage = "Market data stale: no update received for ${elapsed / 1000}s"
                        )
                        // Trigger fallback reconnect for genuine stale connection
                        currentEndpointIndex++
                        scheduleReconnect("Market data stale (${elapsed / 1000}s silence)")
                    }
                }
            }
        }
    }

    @Synchronized
    fun disconnect() {
        Log.i(TAG, "Disconnect requested")
        isIntentionallyClosed = true
        reconnectJob?.cancel()
        reconnectJob = null
        cancelAndCloseActiveWebSocket()
        _streamState.value = _streamState.value.copy(
            status = BinanceStreamStatus.DISCONNECTED,
            errorMessage = null
        )
    }

    private fun cancelAndCloseActiveWebSocket() {
        val ws = activeWebSocket
        activeWebSocket = null
        // Advance connection ID to isolate all callbacks from the closing socket
        activeConnectionId++
        if (ws != null) {
            try {
                ws.cancel()
            } catch (e: Exception) {
                Log.w(TAG, "Error cancelling old WebSocket: ${e.message}")
            }
        }
    }

    fun cleanup() {
        disconnect()
        staleCheckJob?.cancel()
        staleCheckJob = null
    }
}
