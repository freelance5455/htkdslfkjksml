package com.example.core.network.binance

import android.util.Log
import com.example.core.data.chart.binance.BinanceEndpointConfig
import com.example.core.model.chart.OrderType
import com.example.core.model.chart.TradeSide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Result model representing exchange order lifecycle state.
 */
sealed class LiveOrderResult {
    data class Success(
        val exchangeOrderId: String,
        val clientOrderId: String,
        val symbol: String,
        val side: String,
        val orderType: String,
        val executedQty: Double,
        val origQty: Double,
        val avgFillPrice: Double,
        val status: String, // NEW, PARTIALLY_FILLED, FILLED, CANCELED, REJECTED, EXPIRED
        val transactTime: Long,
        val commission: Double = 0.0,
        val commissionAsset: String? = null
    ) : LiveOrderResult() {
        val isFilled: Boolean get() = status.equals("FILLED", ignoreCase = true)
        val isPartiallyFilled: Boolean get() = status.equals("PARTIALLY_FILLED", ignoreCase = true)
        val isCanceled: Boolean get() = status.equals("CANCELED", ignoreCase = true)
    }

    data class Rejected(
        val code: Int,
        val message: String
    ) : LiveOrderResult()

    data class NetworkUncertain(
        val clientOrderId: String,
        val error: String
    ) : LiveOrderResult()

    data class Error(
        val message: String
    ) : LiveOrderResult()
}

data class LiveAccountBalance(
    val asset: String,
    val free: Double,
    val locked: Double
) {
    val total: Double get() = free + locked
}

/**
 * Live Trading Gateway interface.
 * The ONLY path allowed to submit real orders to Binance.
 * Paper Trading must NEVER call this gateway.
 */
interface LiveTradingGateway {
    suspend fun submitLiveOrder(
        apiKey: String,
        apiSecret: String,
        symbol: String,
        side: TradeSide,
        orderType: OrderType,
        quantity: Double,
        price: Double? = null,
        stopPrice: Double? = null,
        clientOrderId: String
    ): LiveOrderResult

    suspend fun queryOrder(
        apiKey: String,
        apiSecret: String,
        symbol: String,
        exchangeOrderId: String? = null,
        clientOrderId: String? = null
    ): LiveOrderResult

    suspend fun cancelLiveOrder(
        apiKey: String,
        apiSecret: String,
        symbol: String,
        exchangeOrderId: String? = null,
        clientOrderId: String? = null
    ): LiveOrderResult

    suspend fun queryAccountBalances(
        apiKey: String,
        apiSecret: String
    ): Result<List<LiveAccountBalance>>

    suspend fun queryOpenOrders(
        apiKey: String,
        apiSecret: String,
        symbol: String? = null
    ): Result<List<LiveOrderResult.Success>>
}

class RealBinanceLiveTradingGateway(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .writeTimeout(12, TimeUnit.SECONDS)
        .build()
) : LiveTradingGateway {

    companion object {
        private const val TAG = "LiveTradingGateway"
        private const val HEADER_API_KEY = "X-MBX-APIKEY"
    }

    override suspend fun submitLiveOrder(
        apiKey: String,
        apiSecret: String,
        symbol: String,
        side: TradeSide,
        orderType: OrderType,
        quantity: Double,
        price: Double?,
        stopPrice: Double?,
        clientOrderId: String
    ): LiveOrderResult = withContext(Dispatchers.IO) {
        val upperSymbol = symbol.uppercase(Locale.US)
        val binanceSide = if (side == TradeSide.BUY) "BUY" else "SELL"
        val binanceType = when (orderType) {
            OrderType.MARKET -> "MARKET"
            OrderType.LIMIT -> "LIMIT"
            OrderType.STOP_TRIGGER -> "STOP_LOSS_LIMIT"
        }

        // Format parameters
        val params = mutableMapOf<String, String>()
        params["symbol"] = upperSymbol
        params["side"] = binanceSide
        params["type"] = binanceType
        params["newClientOrderId"] = clientOrderId

        // Format quantity (up to 8 decimal places, removing trailing zeros)
        params["quantity"] = String.format(Locale.US, "%.8f", quantity).trimEnd('0').trimEnd('.')

        if (orderType == OrderType.LIMIT) {
            val limitPrice = price ?: return@withContext LiveOrderResult.Error("Limit order requires price")
            params["price"] = String.format(Locale.US, "%.8f", limitPrice).trimEnd('0').trimEnd('.')
            params["timeInForce"] = "GTC"
        } else if (orderType == OrderType.STOP_TRIGGER) {
            val sPrice = stopPrice ?: price ?: return@withContext LiveOrderResult.Error("Stop / Trigger order requires trigger price")
            params["stopPrice"] = String.format(Locale.US, "%.8f", sPrice).trimEnd('0').trimEnd('.')
            params["price"] = String.format(Locale.US, "%.8f", price ?: sPrice).trimEnd('0').trimEnd('.')
            params["timeInForce"] = "GTC"
        }

        // Safe Audit Log (NEVER contains API secret or raw headers)
        Log.i(
            TAG,
            "Submitting Live Order: symbol=$upperSymbol, side=$binanceSide, type=$binanceType, qty=${params["quantity"]}, clientOrderId=$clientOrderId"
        )

        executeSignedRequest(
            method = "POST",
            path = "/order",
            params = params,
            apiKey = apiKey,
            apiSecret = apiSecret,
            clientOrderId = clientOrderId
        )
    }

    override suspend fun queryOrder(
        apiKey: String,
        apiSecret: String,
        symbol: String,
        exchangeOrderId: String?,
        clientOrderId: String?
    ): LiveOrderResult = withContext(Dispatchers.IO) {
        val params = mutableMapOf<String, String>()
        params["symbol"] = symbol.uppercase(Locale.US)
        if (!exchangeOrderId.isNullOrBlank()) {
            params["orderId"] = exchangeOrderId
        }
        if (!clientOrderId.isNullOrBlank()) {
            params["origClientOrderId"] = clientOrderId
        }

        executeSignedRequest(
            method = "GET",
            path = "/order",
            params = params,
            apiKey = apiKey,
            apiSecret = apiSecret,
            clientOrderId = clientOrderId ?: exchangeOrderId ?: "QUERY"
        )
    }

    override suspend fun cancelLiveOrder(
        apiKey: String,
        apiSecret: String,
        symbol: String,
        exchangeOrderId: String?,
        clientOrderId: String?
    ): LiveOrderResult = withContext(Dispatchers.IO) {
        val params = mutableMapOf<String, String>()
        params["symbol"] = symbol.uppercase(Locale.US)
        if (!exchangeOrderId.isNullOrBlank()) {
            params["orderId"] = exchangeOrderId
        }
        if (!clientOrderId.isNullOrBlank()) {
            params["origClientOrderId"] = clientOrderId
        }

        Log.i(
            TAG,
            "Canceling Live Order: symbol=$symbol, orderId=$exchangeOrderId, clientOrderId=$clientOrderId"
        )

        executeSignedRequest(
            method = "DELETE",
            path = "/order",
            params = params,
            apiKey = apiKey,
            apiSecret = apiSecret,
            clientOrderId = clientOrderId ?: exchangeOrderId ?: "CANCEL"
        )
    }

    override suspend fun queryAccountBalances(
        apiKey: String,
        apiSecret: String
    ): Result<List<LiveAccountBalance>> = withContext(Dispatchers.IO) {
        val params = mutableMapOf<String, String>()
        val result = executeSignedRawRequest(
            method = "GET",
            path = "/account",
            params = params,
            apiKey = apiKey,
            apiSecret = apiSecret
        )

        result.mapCatching { jsonStr ->
            val json = JSONObject(jsonStr)
            val balancesArray = json.getJSONArray("balances")
            val balances = mutableListOf<LiveAccountBalance>()
            for (i in 0 until balancesArray.length()) {
                val item = balancesArray.getJSONObject(i)
                val free = item.optDouble("free", 0.0)
                val locked = item.optDouble("locked", 0.0)
                if (free > 0.0 || locked > 0.0) {
                    balances.add(
                        LiveAccountBalance(
                            asset = item.getString("asset"),
                            free = free,
                            locked = locked
                        )
                    )
                }
            }
            balances
        }
    }

    override suspend fun queryOpenOrders(
        apiKey: String,
        apiSecret: String,
        symbol: String?
    ): Result<List<LiveOrderResult.Success>> = withContext(Dispatchers.IO) {
        val params = mutableMapOf<String, String>()
        if (!symbol.isNullOrBlank()) {
            params["symbol"] = symbol.uppercase(Locale.US)
        }

        val result = executeSignedRawRequest(
            method = "GET",
            path = "/openOrders",
            params = params,
            apiKey = apiKey,
            apiSecret = apiSecret
        )

        result.mapCatching { jsonStr ->
            val array = JSONArray(jsonStr)
            val list = mutableListOf<LiveOrderResult.Success>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val parsed = parseOrderSuccess(obj)
                if (parsed != null) {
                    list.add(parsed)
                }
            }
            list
        }
    }

    private fun executeSignedRequest(
        method: String,
        path: String,
        params: MutableMap<String, String>,
        apiKey: String,
        apiSecret: String,
        clientOrderId: String
    ): LiveOrderResult {
        val rawResult = executeSignedRawRequest(method, path, params, apiKey, apiSecret)
        return rawResult.fold(
            onSuccess = { body ->
                try {
                    val json = JSONObject(body)
                    // Check for Binance API error payload
                    if (json.has("code") && json.getInt("code") < 0) {
                        val code = json.getInt("code")
                        val msg = json.optString("msg", "Exchange rejected request")
                        Log.w(TAG, "Binance order rejected: code=$code, msg=$msg")
                        LiveOrderResult.Rejected(code = code, message = msg)
                    } else {
                        val success = parseOrderSuccess(json)
                        if (success != null) {
                            Log.i(
                                TAG,
                                "Binance Order Confirmed: id=${success.exchangeOrderId}, status=${success.status}, executedQty=${success.executedQty}"
                            )
                            success
                        } else {
                            LiveOrderResult.Error("Unexpected response structure from exchange")
                        }
                    }
                } catch (e: Exception) {
                    LiveOrderResult.Error("Failed to parse exchange response: ${e.message}")
                }
            },
            onFailure = { error ->
                if (error is SocketTimeoutException || error is IOException) {
                    Log.e(TAG, "Network timeout/uncertainty for order: clientOrderId=$clientOrderId, error=${error.message}")
                    LiveOrderResult.NetworkUncertain(
                        clientOrderId = clientOrderId,
                        error = error.message ?: "Network timeout executing live order"
                    )
                } else {
                    Log.e(TAG, "Execution error: ${error.message}")
                    LiveOrderResult.Error(error.message ?: "Unknown order execution error")
                }
            }
        )
    }

    private fun executeSignedRawRequest(
        method: String,
        path: String,
        params: MutableMap<String, String>,
        apiKey: String,
        apiSecret: String
    ): Result<String> {
        val endpoints = BinanceEndpointConfig.REST_ENDPOINTS
        var lastException: Throwable? = null

        for (endpoint in endpoints) {
            try {
                params["timestamp"] = System.currentTimeMillis().toString()
                params["recvWindow"] = "5000"

                val queryString = buildQueryString(params)
                val signature = signHmacSha256(queryString, apiSecret)
                val fullQuery = "$queryString&signature=$signature"

                val url = "${endpoint.baseUrl}$path?$fullQuery"
                val requestBuilder = Request.Builder()
                    .url(url)
                    .header(HEADER_API_KEY, apiKey)

                val request = when (method.uppercase(Locale.US)) {
                    "POST" -> requestBuilder.post("".toRequestBody("application/json".toMediaType())).build()
                    "DELETE" -> requestBuilder.delete().build()
                    else -> requestBuilder.get().build()
                }

                client.newCall(request).execute().use { response ->
                    val body = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        return Result.success(body)
                    }

                    // Check if error response is JSON from Binance
                    if (body.startsWith("{") && body.contains("\"code\"")) {
                        return Result.success(body) // Pass along to be parsed as Rejected
                    }

                    if (response.code == 451 || response.code >= 500) {
                        // Regional restriction or server error, attempt next endpoint
                        lastException = IOException("HTTP ${response.code} from ${endpoint.name}: $body")
                        return@use
                    }

                    return Result.failure(IOException("HTTP ${response.code} from exchange: $body"))
                }
            } catch (e: Exception) {
                lastException = e
            }
        }

        return Result.failure(lastException ?: IOException("Failed to reach Binance trading API"))
    }

    private fun parseOrderSuccess(json: JSONObject): LiveOrderResult.Success? {
        val orderId = json.optString("orderId").ifEmpty { json.optLong("orderId", 0L).toString() }
        if (orderId.isEmpty() || orderId == "0") return null

        val clientOrderId = json.optString("clientOrderId", "")
        val symbol = json.optString("symbol", "")
        val side = json.optString("side", "")
        val type = json.optString("type", "")
        val status = json.optString("status", "NEW")
        val executedQty = json.optDouble("executedQty", 0.0)
        val origQty = json.optDouble("origQty", 0.0)
        val cummulativeQuoteQty = json.optDouble("cummulativeQuoteQty", 0.0)
        val avgPrice = if (executedQty > 0.0 && cummulativeQuoteQty > 0.0) {
            cummulativeQuoteQty / executedQty
        } else {
            json.optDouble("price", 0.0)
        }
        val transactTime = json.optLong("transactTime", json.optLong("time", System.currentTimeMillis()))

        var totalCommission = 0.0
        var commissionAsset: String? = null
        if (json.has("fills")) {
            val fills = json.getJSONArray("fills")
            for (i in 0 until fills.length()) {
                val f = fills.getJSONObject(i)
                totalCommission += f.optDouble("commission", 0.0)
                if (commissionAsset == null && f.has("commissionAsset")) {
                    commissionAsset = f.getString("commissionAsset")
                }
            }
        }

        return LiveOrderResult.Success(
            exchangeOrderId = orderId,
            clientOrderId = clientOrderId,
            symbol = symbol,
            side = side,
            orderType = type,
            executedQty = executedQty,
            origQty = origQty,
            avgFillPrice = avgPrice,
            status = status,
            transactTime = transactTime,
            commission = totalCommission,
            commissionAsset = commissionAsset
        )
    }

    private fun buildQueryString(params: Map<String, String>): String {
        return params.entries.joinToString("&") { (key, value) ->
            "${URLEncoder.encode(key, "UTF-8")}=${URLEncoder.encode(value, "UTF-8")}"
        }
    }

    private fun signHmacSha256(data: String, secret: String): String {
        val sha256Hmac = Mac.getInstance("HmacSHA256")
        val secretKeySpec = SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        sha256Hmac.init(secretKeySpec)
        val hash = sha256Hmac.doFinal(data.toByteArray(Charsets.UTF_8))
        return hash.joinToString("") { "%02x".format(it) }
    }
}
