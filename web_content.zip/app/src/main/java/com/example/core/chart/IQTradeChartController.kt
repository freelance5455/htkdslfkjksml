package com.example.core.chart

import com.example.core.model.chart.PriceAlertEvent

/**
 * Controller allowing callers to trigger imperative actions on the Lightweight Charts engine,
 * such as exporting the canvas as a base64 image string or managing horizontal price line alerts.
 */
class IQTradeChartController {
    var bridge: ChartWebBridge? = null
        internal set

    var fallbackExport: ((callback: (String?) -> Unit) -> Unit)? = null
        internal set

    var onPriceAlert: ((PriceAlertEvent) -> Unit)? = null

    /**
     * Adds an active horizontal price line to monitor for price crossing alerts.
     */
    fun addHorizontalPriceLine(id: String, price: Double, title: String = "Alert Line", color: String = "#00E5FF") {
        bridge?.addHorizontalPriceLine(id, price, title, color)
    }

    /**
     * Removes a horizontal price line from alert monitoring.
     */
    fun removeHorizontalPriceLine(id: String) {
        bridge?.removeHorizontalPriceLine(id)
    }

    /**
     * Sets multiple horizontal price lines for alert monitoring.
     */
    fun setHorizontalPriceLines(lines: List<Pair<String, Double>>) {
        bridge?.setHorizontalPriceLines(lines)
    }

    /**
     * Clears all horizontal price lines set for alert monitoring.
     */
    fun clearHorizontalPriceLines() {
        bridge?.clearHorizontalPriceLines()
    }

    /**
     * Exports the current view of the canvas as a base64 PNG data URL string
     * ("data:image/png;base64,...").
     */
    fun exportCanvasAsBase64(includeDrawings: Boolean = true, callback: (String?) -> Unit) {
        val b = bridge
        if (b != null && b.isChartReady) {
            b.exportCanvasAsBase64(includeDrawings, callback)
        } else if (fallbackExport != null) {
            fallbackExport?.invoke(callback)
        } else {
            callback(null)
        }
    }

    /**
     * Coroutine suspend version of exportCanvasAsBase64.
     */
    suspend fun exportCanvasAsBase64(includeDrawings: Boolean = true): String? =
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            exportCanvasAsBase64(includeDrawings) { result ->
                if (cont.isActive) {
                    cont.resume(result, onCancellation = null)
                }
            }
        }

    fun exportChartAsBase64(callback: (String?) -> Unit) = exportCanvasAsBase64(true, callback)
    suspend fun exportChartAsBase64(): String? = exportCanvasAsBase64(true)
}
