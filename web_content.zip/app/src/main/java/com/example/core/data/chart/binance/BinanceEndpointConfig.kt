package com.example.core.data.chart.binance

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Binance Endpoint Strategy Configuration.
 *
 * Implements resilient multi-endpoint fallback to handle regional restrictions
 * (such as HTTP 451: Unavailable For Legal Reasons on api.binance.com) and network failures.
 *
 * Official Binance Public Endpoints:
 * 1. Binance Vision (data-api.binance.vision): Dedicated public market data cluster with no geoblock
 * 2. Binance Global (api.binance.com): Primary global endpoint
 * 3. Binance US (api.binance.us): Official endpoint for US region
 * 4. Binance Alternative Clusters (api1.binance.com, api2.binance.com, api3.binance.com)
 */
object BinanceEndpointConfig {

    private const val TAG = "BinanceEndpointConfig"

    data class RestEndpoint(
        val baseUrl: String,
        val name: String,
        val matchingWsBaseUrl: String
    )

    val REST_ENDPOINTS = listOf(
        RestEndpoint(
            baseUrl = "https://data-api.binance.vision/api/v3",
            name = "Binance Vision (Public Market Data)",
            matchingWsBaseUrl = "wss://data-stream.binance.vision/ws"
        ),
        RestEndpoint(
            baseUrl = "https://api.binance.com/api/v3",
            name = "Binance Global Primary",
            matchingWsBaseUrl = "wss://stream.binance.com:9443/ws"
        ),
        RestEndpoint(
            baseUrl = "https://api.binance.us/api/v3",
            name = "Binance US Region",
            matchingWsBaseUrl = "wss://stream.binance.us:9443/ws"
        ),
        RestEndpoint(
            baseUrl = "https://api1.binance.com/api/v3",
            name = "Binance Global Cluster 1",
            matchingWsBaseUrl = "wss://stream.binance.com:9443/ws"
        )
    )

    val WS_ENDPOINTS = listOf(
        "wss://data-stream.binance.vision/ws",
        "wss://stream.binance.com:9443/ws",
        "wss://stream.binance.us:9443/ws",
        "wss://stream.binance.com:443/ws"
    )

    /**
     * Executes an HTTP request with endpoint fallback.
     * If an endpoint returns HTTP 451 (Unavailable For Legal Reasons) or fails to connect,
     * it logs the diagnostic event and immediately attempts the next endpoint in the sequence.
     *
     * If all endpoints fail, returns the final failure without fabricating fake data.
     */
    fun executeWithFallback(
        client: OkHttpClient,
        pathWithQueryBuilder: (baseUrl: String) -> String,
        onEndpointSelected: (endpoint: RestEndpoint) -> Unit = {}
    ): Pair<Response, RestEndpoint> {
        var lastException: Exception? = null

        for (endpoint in REST_ENDPOINTS) {
            val url = pathWithQueryBuilder(endpoint.baseUrl)
            try {
                val request = Request.Builder()
                    .url(url)
                    .addHeader("Accept", "application/json")
                    .addHeader("User-Agent", "IQTradePro-Android/1.0")
                    .build()

                val response = client.newCall(request).execute()

                if (response.isSuccessful) {
                    onEndpointSelected(endpoint)
                    return Pair(response, endpoint)
                }

                // If response is HTTP 451 or 403 (geoblock / restricted region), log and try fallback
                if (response.code == 451 || response.code == 403) {
                    Log.w(TAG, "Endpoint ${endpoint.name} returned HTTP ${response.code} (${response.message}). Attempting fallback.")
                    response.close()
                    lastException = IOException("Binance API error HTTP ${response.code}: ${response.message} on ${endpoint.name}")
                    continue
                }

                // For other 4xx client errors (e.g. invalid symbol 400), don't futilely try all endpoints
                if (response.code in 400..499 && response.code != 429) {
                    return Pair(response, endpoint)
                }

                // For 5xx server errors or 429 rate limit, close and attempt fallback
                response.close()
                lastException = IOException("Binance API error HTTP ${response.code} on ${endpoint.name}")
            } catch (e: Exception) {
                Log.w(TAG, "Failed connecting to ${endpoint.name}: ${e.message}. Attempting fallback.")
                lastException = e
            }
        }

        throw lastException ?: IOException("All Binance market data endpoints failed")
    }

    /**
     * Returns the stream URL for a given symbol and interval.
     */
    fun buildWebSocketUrl(wsBaseUrl: String, symbol: String, interval: String): String {
        val cleanSymbol = symbol.replace("/", "").lowercase()
        val normalizedInterval = interval // e.g. "1m", "1h", "1M"
        return "$wsBaseUrl/${cleanSymbol}@kline_${normalizedInterval}"
    }
}
