package com.example.core.analysis.risk

import com.example.core.model.analysis.RiskRewardResult
import com.example.core.model.analysis.SupportResistanceResult
import com.example.core.model.analysis.VolatilityAnalysisResult
import com.example.core.model.analysis.VolatilityEnvironment
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Module #6 — Volatility & Risk/Reward Engine.
 * - Computes real ATR (14) and Historical Volatility from closed candle true ranges
 * - Classifies Volatility Environment: LOW, NORMAL, HIGH, EXTREME
 * - Calculates mathematical Risk/Reward based on current market price, technical S/R levels, and ATR
 * - Rejects invalid setups with explicit "Insufficient data for reliable Risk/Reward"
 */
object RiskRewardEngine {

    /**
     * Volatility Analysis using ATR(14) and 20-period log return standard deviation.
     */
    fun analyzeVolatility(candles: List<Candle>): VolatilityAnalysisResult {
        if (candles.size < 14) {
            val close = candles.lastOrNull()?.close ?: 0.0
            return VolatilityAnalysisResult(
                environment = VolatilityEnvironment.NORMAL,
                atrValue = 0.0,
                atrPercentOfPrice = 0.0,
                historicalVolatility = 0.0,
                contextDescription = "Insufficient candle history (< 14 bars) for ATR true range calculation"
            )
        }

        val currentPrice = candles.last().close

        // True Range Calculation for ATR(14)
        val trList = mutableListOf<Double>()
        for (i in 1 until candles.size) {
            val curr = candles[i]
            val prevClose = candles[i - 1].close
            val tr = max(curr.high - curr.low, max(abs(curr.high - prevClose), abs(curr.low - prevClose)))
            trList.add(tr)
        }

        val atr14 = trList.takeLast(14).average()
        val atrPct = if (currentPrice > 0) (atr14 / currentPrice) * 100.0 else 0.0

        // Historical Volatility (std dev of close changes over last 20 bars)
        val recentCloses = candles.takeLast(min(candles.size, 20)).map { it.close }
        val returns = mutableListOf<Double>()
        for (i in 1 until recentCloses.size) {
            val ret = (recentCloses[i] - recentCloses[i - 1]) / recentCloses[i - 1]
            returns.add(ret)
        }
        val meanRet = returns.average()
        val variance = returns.map { (it - meanRet) * (it - meanRet) }.average()
        val histVol = (sqrt(variance) * sqrt(365.0) * 100.0)

        val env = when {
            atrPct < 0.40 -> VolatilityEnvironment.LOW
            atrPct <= 1.80 -> VolatilityEnvironment.NORMAL
            atrPct <= 3.80 -> VolatilityEnvironment.HIGH
            else -> VolatilityEnvironment.EXTREME
        }

        val context = when (env) {
            VolatilityEnvironment.LOW -> "ATR: $%.2f (%.2f%% of price). Low volatility range compression. Tight consolidation before directional breakout.".format(atr14, atrPct)
            VolatilityEnvironment.NORMAL -> "ATR: $%.2f (%.2f%% of price). Healthy liquid volatility. Balanced spread for directional trend moves.".format(atr14, atrPct)
            VolatilityEnvironment.HIGH -> "ATR: $%.2f (%.2f%% of price). Elevated price swings. Exercise prudent position sizing and wider stop tolerances.".format(atr14, atrPct)
            VolatilityEnvironment.EXTREME -> "ATR: $%.2f (%.2f%% of price). Extreme volatility spike. Heightened liquidation risk; protect capital.".format(atr14, atrPct)
        }

        return VolatilityAnalysisResult(
            environment = env,
            atrValue = atr14,
            atrPercentOfPrice = atrPct,
            historicalVolatility = histVol,
            contextDescription = context
        )
    }

    /**
     * Risk / Reward calculation based on actual technical levels and ATR buffer.
     */
    fun calculateRiskReward(
        candles: List<Candle>,
        srResult: SupportResistanceResult,
        volatility: VolatilityAnalysisResult,
        directionalBias: IndicatorDirection
    ): RiskRewardResult {
        if (candles.size < 10 || volatility.atrValue <= 0.0) {
            return RiskRewardResult(
                isValid = false,
                entryPrice = 0.0,
                stopLossPrice = 0.0,
                takeProfitPrice = 0.0,
                riskDistance = 0.0,
                riskPercent = 0.0,
                rewardDistance = 0.0,
                rewardPercent = 0.0,
                ratioValue = 0.0,
                ratioText = "Insufficient data for reliable Risk/Reward",
                setupBias = IndicatorDirection.NEUTRAL,
                message = "Insufficient data for reliable Risk/Reward"
            )
        }

        val entry = candles.last().close
        val atr = volatility.atrValue

        val (sl, tp, bias) = if (directionalBias == IndicatorDirection.BULLISH) {
            // Long Setup: SL below nearest support, TP at nearest resistance
            val sup = srResult.nearestSupport?.price
            val res = srResult.nearestResistance?.price

            val stopLoss = if (sup != null && sup < entry && (entry - sup) >= atr * 0.5) {
                sup - (atr * 0.2) // buffer below support
            } else {
                entry - (atr * 1.5)
            }

            val takeProfit = if (res != null && res > entry && (res - entry) >= atr * 1.0) {
                res
            } else {
                entry + (atr * 3.0)
            }
            Triple(stopLoss, takeProfit, IndicatorDirection.BULLISH)
        } else if (directionalBias == IndicatorDirection.BEARISH) {
            // Short Setup: SL above nearest resistance, TP at nearest support
            val sup = srResult.nearestSupport?.price
            val res = srResult.nearestResistance?.price

            val stopLoss = if (res != null && res > entry && (res - entry) >= atr * 0.5) {
                res + (atr * 0.2) // buffer above resistance
            } else {
                entry + (atr * 1.5)
            }

            val takeProfit = if (sup != null && sup < entry && (entry - sup) >= atr * 1.0) {
                sup
            } else {
                entry - (atr * 3.0)
            }
            Triple(stopLoss, takeProfit, IndicatorDirection.BEARISH)
        } else {
            // Neutral / Wait - no clear asymmetric setup
            return RiskRewardResult(
                isValid = false,
                entryPrice = entry,
                stopLossPrice = 0.0,
                takeProfitPrice = 0.0,
                riskDistance = 0.0,
                riskPercent = 0.0,
                rewardDistance = 0.0,
                rewardPercent = 0.0,
                ratioValue = 0.0,
                ratioText = "Neutral Market (Wait)",
                setupBias = IndicatorDirection.NEUTRAL,
                message = "Market bias is Neutral; awaiting high-probability directional breakout before setting Risk/Reward."
            )
        }

        val riskDist = if (bias == IndicatorDirection.BULLISH) entry - sl else sl - entry
        val rewardDist = if (bias == IndicatorDirection.BULLISH) tp - entry else entry - tp

        if (riskDist <= 0.0 || rewardDist <= 0.0) {
            return RiskRewardResult(
                isValid = false,
                entryPrice = entry,
                stopLossPrice = sl,
                takeProfitPrice = tp,
                riskDistance = 0.0,
                riskPercent = 0.0,
                rewardDistance = 0.0,
                rewardPercent = 0.0,
                ratioValue = 0.0,
                ratioText = "Insufficient data for reliable Risk/Reward",
                setupBias = bias,
                message = "Insufficient data for reliable Risk/Reward"
            )
        }

        val riskPct = (riskDist / entry) * 100.0
        val rewardPct = (rewardDist / entry) * 100.0
        val ratio = rewardDist / riskDist
        val ratioFormatted = "1 : %.2f".format(ratio)

        val msg = "%s Setup — Entry: $%.2f, SL: $%.2f (-%.2f%%), TP: $%.2f (+%.2f%%). R:R = %s.".format(
            if (bias == IndicatorDirection.BULLISH) "Long" else "Short",
            entry, sl, riskPct, tp, rewardPct, ratioFormatted
        )

        return RiskRewardResult(
            isValid = true,
            entryPrice = entry,
            stopLossPrice = sl,
            takeProfitPrice = tp,
            riskDistance = riskDist,
            riskPercent = riskPct,
            rewardDistance = rewardDist,
            rewardPercent = rewardPct,
            ratioValue = ratio,
            ratioText = ratioFormatted,
            setupBias = bias,
            message = msg
        )
    }
}
