package com.example.core.analysis.persistence

import android.content.Context
import android.content.SharedPreferences

/**
 * Module #6 — Persistence Manager for Analysis Preferences.
 * Persists user-configured analysis preferences across app restarts:
 * - selected symbol
 * - selected market
 * - active timeframe
 * - auto-refresh interval
 * - real-time analysis toggle
 *
 * Stored cleanly and independently from chart indicators and credentials.
 */
class AnalysisPersistenceManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val PREFS_NAME = "iqtrade_analysis_prefs"
        private const val KEY_ANALYSIS_SYMBOL = "key_analysis_symbol"
        private const val KEY_ANALYSIS_MARKET = "key_analysis_market"
        private const val KEY_ANALYSIS_TIMEFRAME = "key_analysis_timeframe"
        private const val KEY_AUTO_REFRESH_INTERVAL = "key_auto_refresh_interval"
        private const val KEY_REALTIME_ACTIVE = "key_realtime_analysis_active"
        private const val KEY_LAST_ANALYSIS_TS = "key_last_analysis_timestamp"

        const val DEFAULT_SYMBOL = "BTCUSDT"
        const val DEFAULT_MARKET = "Crypto"
        const val DEFAULT_TIMEFRAME = "15m"
        const val DEFAULT_REFRESH_INTERVAL_SEC = 5
    }

    fun getAnalysisSymbol(): String = prefs.getString(KEY_ANALYSIS_SYMBOL, DEFAULT_SYMBOL) ?: DEFAULT_SYMBOL

    fun saveAnalysisSymbol(symbol: String) {
        prefs.edit().putString(KEY_ANALYSIS_SYMBOL, symbol.trim().uppercase()).apply()
    }

    fun getAnalysisMarket(): String = prefs.getString(KEY_ANALYSIS_MARKET, DEFAULT_MARKET) ?: DEFAULT_MARKET

    fun saveAnalysisMarket(market: String) {
        prefs.edit().putString(KEY_ANALYSIS_MARKET, market.trim()).apply()
    }

    fun getAnalysisTimeframe(): String = prefs.getString(KEY_ANALYSIS_TIMEFRAME, DEFAULT_TIMEFRAME) ?: DEFAULT_TIMEFRAME

    fun saveAnalysisTimeframe(timeframe: String) {
        prefs.edit().putString(KEY_ANALYSIS_TIMEFRAME, timeframe.trim()).apply()
    }

    fun getAutoRefreshInterval(): Int = prefs.getInt(KEY_AUTO_REFRESH_INTERVAL, DEFAULT_REFRESH_INTERVAL_SEC)

    fun saveAutoRefreshInterval(seconds: Int) {
        prefs.edit().putInt(KEY_AUTO_REFRESH_INTERVAL, seconds.coerceIn(2, 60)).apply()
    }

    fun isRealtimeAnalysisActive(): Boolean = prefs.getBoolean(KEY_REALTIME_ACTIVE, true)

    fun setRealtimeAnalysisActive(active: Boolean) {
        prefs.edit().putBoolean(KEY_REALTIME_ACTIVE, active).apply()
    }

    fun getLastAnalysisTimestamp(): Long = prefs.getLong(KEY_LAST_ANALYSIS_TS, 0L)

    fun updateLastAnalysisTimestamp(ts: Long) {
        prefs.edit().putLong(KEY_LAST_ANALYSIS_TS, ts).apply()
    }
}
