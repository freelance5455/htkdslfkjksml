package com.example.core.floating

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Architectural foundation for Module 12 (Floating System).
 * Manages overlay permissions, service lifecycle readiness, and window coordinates.
 */
object OverlayPermissionHelper {

    fun hasOverlayPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    fun createRequestOverlayPermissionIntent(context: Context): Intent? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
        } else {
            null
        }
    }
}

interface FloatingOverlayController {
    val isOverlayActive: StateFlow<Boolean>
    fun checkPermission(context: Context): Boolean
    fun requestOverlayActivation(context: Context): Boolean
    fun deactivateOverlay()
}

class DefaultFloatingOverlayController : FloatingOverlayController {

    private val _isOverlayActive = MutableStateFlow(false)
    override val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    override fun checkPermission(context: Context): Boolean {
        return OverlayPermissionHelper.hasOverlayPermission(context)
    }

    override fun requestOverlayActivation(context: Context): Boolean {
        if (!checkPermission(context)) {
            return false
        }
        // Architectural boundary: Full floating service implementation planned for Module 12
        _isOverlayActive.value = true
        return true
    }

    override fun deactivateOverlay() {
        _isOverlayActive.value = false
    }
}
