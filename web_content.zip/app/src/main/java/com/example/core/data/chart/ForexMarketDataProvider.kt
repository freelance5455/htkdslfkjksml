package com.example.core.data.chart

import com.example.core.model.MarketCategory
import com.example.core.model.Timeframe
import com.example.core.model.chart.Candle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Institutional Forex Market Data Provider implementation.
 * Prepared for live broker / FIX / WebSocket feed integration.
 * Ensures zero fake data when offline: returns data unavailable status cleanly.
 */
class ForexMarketDataProvider : MarketDataProvider {

    override val marketCategory: MarketCategory = MarketCategory.FOREX
    override val providerId: String = "FOREX_INSTITUTIONAL_FEED"

    private val _liveCandleFlow = MutableSharedFlow<Candle>(replay = 1)

    override suspend fun fetchHistoricalCandles(
        symbol: String,
        timeframe: Timeframe,
        limit: Int
    ): Result<List<Candle>> {
        // Forex feed interface ready for broker API connection.
        // If external broker credentials/session are not yet configured, returns empty list with DataUnavailable
        return Result.success(emptyList())
    }

    override fun observeLiveCandle(symbol: String, timeframe: Timeframe): Flow<Candle> {
        return _liveCandleFlow.asSharedFlow()
    }

    suspend fun emitLiveCandle(candle: Candle) {
        _liveCandleFlow.emit(candle)
    }
}
