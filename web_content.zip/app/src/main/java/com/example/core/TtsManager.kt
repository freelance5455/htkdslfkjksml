package com.example.core

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsManager(context: Context) {
    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isReady = false

    private val _speakingMessageId = MutableStateFlow<String?>(null)
    val speakingMessageId: StateFlow<String?> = _speakingMessageId.asStateFlow()

    private val _isAvailable = MutableStateFlow(true)
    val isAvailable: StateFlow<Boolean> = _isAvailable.asStateFlow()

    init {
        tts = TextToSpeech(appContext) { status ->
            isReady = status == TextToSpeech.SUCCESS
            _isAvailable.value = isReady
            if (!isReady) {
                Log.w("TtsManager", "TextToSpeech initialization failed with status: $status")
            } else {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _speakingMessageId.value = utteranceId
                    }

                    override fun onDone(utteranceId: String?) {
                        if (_speakingMessageId.value == utteranceId) {
                            _speakingMessageId.value = null
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (_speakingMessageId.value == utteranceId) {
                            _speakingMessageId.value = null
                        }
                    }

                    override fun onError(utteranceId: String?, errorCode: Int) {
                        if (_speakingMessageId.value == utteranceId) {
                            _speakingMessageId.value = null
                        }
                    }
                })
            }
        }
    }

    fun toggleSpeak(
        messageId: String,
        rawText: String,
        languageCode: String = "auto",
        speechRate: Float = 1.0f
    ) {
        if (_speakingMessageId.value == messageId) {
            stop()
            return
        }
        speak(messageId, rawText, languageCode, speechRate)
    }

    fun speak(
        messageId: String,
        rawText: String,
        languageCode: String = "auto",
        speechRate: Float = 1.0f
    ) {
        val engine = tts ?: return
        if (!isReady) return

        val cleaned = cleanMarkdownForSpeech(rawText)
        if (cleaned.isBlank()) return

        val targetLocale = resolveLocale(cleaned, languageCode)
        val langResult = engine.setLanguage(targetLocale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.getDefault())
        }
        engine.setSpeechRate(speechRate.coerceIn(0.5f, 2.0f))

        _speakingMessageId.value = messageId
        val params = Bundle()
        // Speak up to 3900 chars safely (TextToSpeech.getMaxSpeechInputLength() is 4000)
        val chunk = cleaned.take(3900)
        engine.speak(chunk, TextToSpeech.QUEUE_FLUSH, params, messageId)
    }

    fun stop() {
        tts?.stop()
        _speakingMessageId.value = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        _speakingMessageId.value = null
    }

    private fun resolveLocale(text: String, languageCode: String): Locale {
        if (languageCode != "auto") {
            return when (languageCode) {
                "ru" -> Locale("ru", "RU")
                "en" -> Locale.US
                "es" -> Locale("es", "ES")
                "de" -> Locale.GERMANY
                "fr" -> Locale.FRANCE
                "uk" -> Locale("uk", "UA")
                "zh" -> Locale.SIMPLIFIED_CHINESE
                else -> Locale.getDefault()
            }
        }
        val hasCyrillic = text.any { it in '\u0400'..'\u04FF' }
        return if (hasCyrillic) Locale("ru", "RU") else Locale.getDefault()
    }

    private fun cleanMarkdownForSpeech(text: String): String {
        return text
            .replace(Regex("```[a-zA-Z0-9]*\\n([\\s\\S]*?)```"), " ")
            .replace(Regex("`([^`]*)`"), "$1")
            .replace(Regex("!\\[[^\\]]*]\\([^)]*\\)"), "")
            .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
            .replace(Regex("^#{1,6}\\s*", RegexOption.MULTILINE), "")
            .replace("**", "")
            .replace("__", "")
            .replace("*", "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
