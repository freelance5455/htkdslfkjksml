package com.example.core.model

data class MarketSymbol(
    val base: String,
    val quote: String,
    val displayName: String
) {
    val symbolString: String get() = "$base$quote"
}

enum class Timeframe(
    val label: String,
    val intervalKey: String,
    val fullDisplayName: String,
    val unitCategory: String
) {
    M1("1m", "1m", "1 Minute", "Minute"),
    M3("3m", "3m", "3 Minutes", "Minute"),
    M5("5m", "5m", "5 Minutes", "Minute"),
    M15("15m", "15m", "15 Minutes", "Minute"),
    M30("30m", "30m", "30 Minutes", "Minute"),
    H1("1h", "1h", "1 Hour", "Hour"),
    H2("2h", "2h", "2 Hours", "Hour"),
    H4("4h", "4h", "4 Hours", "Hour"),
    H6("6h", "6h", "6 Hours", "Hour"),
    H8("8h", "8h", "8 Hours", "Hour"),
    H12("12h", "12h", "12 Hours", "Hour"),
    D1("1D", "1d", "1 Day", "Day"),
    D3("3D", "3d", "3 Days", "Day"),
    W1("1W", "1w", "1 Week", "Week"),
    MN1("1M", "1M", "1 Month", "Month");

    val isMinute: Boolean get() = this == M1
    val isMonth: Boolean get() = this == MN1

    companion object {
        fun fromLabel(label: String): Timeframe {
            return entries.firstOrNull { it.label == label || it.intervalKey == label } ?: H1
        }
    }
}

enum class MarketType(val label: String) {
    SPOT("Spot"),
    FUTURES("USDT-M Futures")
}

enum class TradingAccountType(val label: String) {
    PAPER("Paper Account"),
    LIVE("Live Account")
}
