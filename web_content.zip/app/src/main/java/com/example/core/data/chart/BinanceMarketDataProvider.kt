package com.example.core.data.chart

import android.util.Log
import com.example.core.data.chart.binance.BinanceEndpointConfig
import com.example.core.data.chart.binance.BinanceStreamStatus
import com.example.core.data.chart.binance.BinanceWebSocketManager
import com.example.core.model.MarketCategory
import com.example.core.model.Timeframe
import com.example.core.model.chart.Candle
import com.example.core.model.chart.ChartConnectionState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import org.json.JSONArray
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Real Production Binance Market Data Provider.
 *
 * Implements:
 * - Resilient REST historical fetching with multi-endpoint fallback
 *   (bypasses regional HTTP 451 geoblocks via Binance Vision public market data cluster)
 * - Real-time WebSocket Kline stream integration via BinanceWebSocketManager
 * - Reactive connection state mapping (Connecting, Connected, Reconnecting, Stale, Error)
 * - Zero fake candles, zero simulated prices
 * - Ascending chronological ordering and rejection of future timestamps
 */
class BinanceMarketDataProvider(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build(),
    val webSocketManager: BinanceWebSocketManager = BinanceWebSocketManager()
) : MarketDataProvider {

    companion object {
        private const val TAG = "BinanceDataProvider"
    }

    override val marketCategory: MarketCategory = MarketCategory.CRYPTO
    override val providerId: String = "BINANCE_REALTIME_WS"

    override val connectionState: Flow<ChartConnectionState> =
        webSocketManager.streamState.map { state ->
            when (state.status) {
                BinanceStreamStatus.DISCONNECTED -> ChartConnectionState.Disconnected
                BinanceStreamStatus.CONNECTING -> ChartConnectionState.Connecting(state.currentEndpoint)
                BinanceStreamStatus.CONNECTED -> ChartConnectionState.Connected
                BinanceStreamStatus.RECONNECTING -> {
                    if (state.reconnectAttempt > 0) {
                        ChartConnectionState.ReconnectingAttempt(state.reconnectAttempt)
                    } else {
                        ChartConnectionState.Reconnecting
                    }
                }
                BinanceStreamStatus.STALE -> ChartConnectionState.Stale
                BinanceStreamStatus.ERROR -> ChartConnectionState.Error(
                    state.errorMessage ?: "Binance stream error"
                )
            }
        }

    override suspend fun fetchHistoricalCandles(
        symbol: String,
        timeframe: Timeframe,
        limit: Int
    ): Result<List<Candle>> = withContext(Dispatchers.IO) {
        try {
            val cleanSymbol = symbol.replace("/", "").uppercase()
            val interval = timeframe.intervalKey
            val safeLimit = limit.coerceIn(10, 500)

            Log.i(TAG, "Fetching historical klines for $cleanSymbol, interval: $interval, limit: $safeLimit")

            val (response, endpointUsed) = BinanceEndpointConfig.executeWithFallback(
                client = client,
                pathWithQueryBuilder = { baseUrl ->
                    "$baseUrl/klines?symbol=$cleanSymbol&interval=$interval&limit=$safeLimit"
                },
                onEndpointSelected = { endpoint ->
                    Log.i(TAG, "Selected active Binance endpoint: ${endpoint.name} (${endpoint.baseUrl})")
                }
            )

            if (!response.isSuccessful) {
                val errorMsg = "Binance API response HTTP ${response.code}: ${response.message} on ${endpointUsed.name}"
                Log.w(TAG, errorMsg)
                return@withContext Result.failure(IOException(errorMsg))
            }

            val body = response.body?.string() ?: return@withContext Result.failure(
                IOException("Empty response body from Binance API")
            )

            val jsonArray = JSONArray(body)
            val candles = ArrayList<Candle>(jsonArray.length())
            val now = System.currentTimeMillis()

            for (i in 0 until jsonArray.length()) {
                val kline = jsonArray.getJSONArray(i)
                val openTime = kline.getLong(0)
                val open = kline.getString(1).toDoubleOrNull() ?: 0.0
                val high = kline.getString(2).toDoubleOrNull() ?: 0.0
                val low = kline.getString(3).toDoubleOrNull() ?: 0.0
                val close = kline.getString(4).toDoubleOrNull() ?: 0.0
                val volume = kline.getString(5).toDoubleOrNull() ?: 0.0
                val closeTime = kline.getLong(6)

                // Skip corrupted or future candles
                if (openTime <= 0L || openTime > now + 300_000L) {
                    continue
                }

                val effectiveHigh = maxOf(high, maxOf(open, close))
                val effectiveLow = minOf(low, minOf(open, close))
                val isClosed = closeTime <= now

                candles.add(
                    Candle(
                        timestamp = openTime,
                        open = open,
                        high = effectiveHigh,
                        low = effectiveLow,
                        close = close,
                        volume = volume,
                        isClosed = isClosed
                    )
                )
            }

            // Ensure strictly ascending chronological order
            val sorted = candles.sortedBy { it.timestamp }
            Log.i(TAG, "Successfully loaded ${sorted.size} historical candles from ${endpointUsed.name}")
            Result.success(sorted)
        } catch (e: Exception) {
            Log.w(TAG, "Historical candles unavailable (${e.message ?: "Network error"})")
            Result.failure(e)
        }
    }

    override fun observeLiveCandle(symbol: String, timeframe: Timeframe): Flow<Candle> {
        Log.i(TAG, "Starting live candle subscription: $symbol on ${timeframe.intervalKey}")
        webSocketManager.connect(symbol, timeframe)
        return webSocketManager.liveCandleFlow
    }

    override fun disconnect() {
        Log.i(TAG, "Disconnecting Binance provider")
        webSocketManager.disconnect()
    }
}
