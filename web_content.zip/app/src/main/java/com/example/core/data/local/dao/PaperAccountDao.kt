package com.example.core.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.core.data.local.entity.PaperAccountEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PaperAccountDao {
    @Query("SELECT * FROM paper_account WHERE id = 1 LIMIT 1")
    fun getAccountFlow(): Flow<PaperAccountEntity?>

    @Query("SELECT * FROM paper_account WHERE id = 1 LIMIT 1")
    suspend fun getAccount(): PaperAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(account: PaperAccountEntity)

    @Update
    suspend fun update(account: PaperAccountEntity)

    @Query("UPDATE paper_account SET balance = :balance, equity = :balance, unrealizedPnl = 0.0, realizedPnl = 0.0, updatedAt = :updatedAt WHERE id = 1")
    suspend fun resetAccount(balance: Double = 10000.0, updatedAt: Long = System.currentTimeMillis())
}
