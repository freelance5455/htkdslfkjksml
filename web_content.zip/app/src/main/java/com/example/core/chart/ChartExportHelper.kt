package com.example.core.chart

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object ChartExportHelper {

    /**
     * Converts a raw Bitmap into a base64 PNG data URL string.
     */
    fun bitmapToBase64(bitmap: Bitmap, format: Bitmap.CompressFormat = Bitmap.CompressFormat.PNG, quality: Int = 100): String {
        val outputStream = ByteArrayOutputStream()
        bitmap.compress(format, quality, outputStream)
        val byteArray = outputStream.toByteArray()
        val base64 = Base64.encodeToString(byteArray, Base64.NO_WRAP)
        return "data:image/png;base64,$base64"
    }

    /**
     * Converts a base64 string (with or without data:image/png;base64, prefix) to a Bitmap.
     */
    fun base64ToBitmap(base64Str: String): Bitmap? {
        return try {
            val cleanBase64 = if (base64Str.contains(",")) {
                base64Str.substringAfter(",")
            } else {
                base64Str
            }
            val decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Saves a base64 chart image to a PNG file in the app cache directory.
     */
    fun saveBase64ImageToCache(
        context: Context,
        base64Str: String,
        fileName: String = "chart_snapshot_${System.currentTimeMillis()}.png"
    ): File? {
        return try {
            val bitmap = base64ToBitmap(base64Str) ?: return null
            val file = File(context.cacheDir, fileName)
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
            }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Launches the Android system Share sheet allowing the user to share the chart snapshot.
     */
    fun shareChart(context: Context, base64Str: String, symbol: String, timeframe: String) {
        try {
            val safeSymbol = symbol.replace("/", "_")
            val fileName = "iqtrade_${safeSymbol}_${timeframe}_${System.currentTimeMillis()}.png"
            val file = saveBase64ImageToCache(context, base64Str, fileName)

            if (file != null) {
                val uri: Uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, "IQTrade Pro: $symbol ($timeframe)")
                    putExtra(Intent.EXTRA_TEXT, "Chart analysis for $symbol ($timeframe) on IQTrade Pro")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(intent, "Share Chart State")
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(chooser)
            } else {
                // Fallback: share plain text representation / link
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "IQTrade Pro: $symbol ($timeframe)")
                    putExtra(Intent.EXTRA_TEXT, "IQTrade Pro Chart: $symbol $timeframe")
                }
                val chooser = Intent.createChooser(intent, "Share Chart State")
                chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(chooser)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "Export error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Copies the raw base64 image string to the system clipboard.
     */
    fun copyBase64ToClipboard(context: Context, base64Str: String) {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Chart Base64 Image", base64Str)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(context, "Base64 image string copied to clipboard", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
