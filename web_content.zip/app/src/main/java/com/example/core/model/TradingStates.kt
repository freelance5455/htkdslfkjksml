package com.example.core.model

/**
 * Architectural separation of concerns:
 * - Data Connection: Receiving market/account information
 * - Analysis: Analyzing market data
 * - Signal: Generating technical signals
 * - Trading Permission: Explicit permission to place an order
 * - Automatic Trading: System authorization to automatically execute orders
 *
 * CRITICAL RULE:
 * Binance Connected == YES does NOT mean Smart Mode == ON, Auto Trading == ON, or Live Trading == ON.
 */

enum class DataConnectionStatus {
    OFFLINE,
    CONNECTING,
    ONLINE,
    DEGRADED
}

enum class AnalysisMode {
    STANDBY,
    ACTIVE_MONITORING,
    CALCULATING
}

sealed class SignalState {
    object Idle : SignalState()
    object Scanning : SignalState()
    data class SignalDetected(val type: String, val strengthPct: Int) : SignalState()
}

/**
 * Explicit trading permission levels.
 * Default is PAPER_ONLY with live execution locked.
 */
enum class TradingPermissionLevel {
    REVOKED,
    PAPER_ONLY,
    LIVE_LOCKED,
    LIVE_ENABLED_MANUAL
}

/**
 * Automatic trading execution authorization.
 * MANDATORY DEFAULT: DISABLED.
 */
enum class AutoTradingStatus {
    DISABLED,
    ARMED_WITH_CONFIRMATION
}

/**
 * Smart Mode state.
 * MANDATORY DEFAULT: OFF.
 */
enum class SmartModeStatus {
    OFF,
    ASSISTIVE_ONLY
}
