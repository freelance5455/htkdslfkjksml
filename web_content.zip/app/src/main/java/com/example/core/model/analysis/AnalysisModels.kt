package com.example.core.model.analysis

import com.example.core.model.indicator.AnalysisScoreSnapshot
import com.example.core.model.indicator.IndicatorDirection

/**
 * Module #6 — Final Analysis Signal result.
 */
enum class FinalAnalysisSignal(val label: String, val badgeText: String) {
    BULLISH_BUY("BULLISH / BUY", "🟢 BULLISH / BUY"),
    BEARISH_SELL("BEARISH / SELL", "🔴 BEARISH / SELL"),
    NEUTRAL_WAIT("NEUTRAL / WAIT", "🟡 NEUTRAL / WAIT")
}

/**
 * 17 Documented Candlestick Patterns for Module #6 Candlestick Engine.
 */
enum class CandlestickPatternType(val displayName: String, val defaultBias: IndicatorDirection) {
    DOJI("Doji", IndicatorDirection.NEUTRAL),
    HAMMER("Hammer", IndicatorDirection.BULLISH),
    INVERTED_HAMMER("Inverted Hammer", IndicatorDirection.BULLISH),
    HANGING_MAN("Hanging Man", IndicatorDirection.BEARISH),
    SHOOTING_STAR("Shooting Star", IndicatorDirection.BEARISH),
    BULLISH_ENGULFING("Bullish Engulfing", IndicatorDirection.BULLISH),
    BEARISH_ENGULFING("Bearish Engulfing", IndicatorDirection.BEARISH),
    PIERCING_LINE("Piercing Line", IndicatorDirection.BULLISH),
    DARK_CLOUD_COVER("Dark Cloud Cover", IndicatorDirection.BEARISH),
    MORNING_STAR("Morning Star", IndicatorDirection.BULLISH),
    EVENING_STAR("Evening Star", IndicatorDirection.BEARISH),
    BULLISH_HARAMI("Bullish Harami", IndicatorDirection.BULLISH),
    BEARISH_HARAMI("Bearish Harami", IndicatorDirection.BEARISH),
    TWEEZER_TOP("Tweezer Top", IndicatorDirection.BEARISH),
    TWEEZER_BOTTOM("Tweezer Bottom", IndicatorDirection.BULLISH),
    THREE_WHITE_SOLDIERS("Three White Soldiers", IndicatorDirection.BULLISH),
    THREE_BLACK_CROWS("Three Black Crows", IndicatorDirection.BEARISH),
    SPINNING_TOP("Spinning Top", IndicatorDirection.NEUTRAL)
}

/**
 * Detected Candlestick Pattern Match.
 */
data class CandlestickPatternMatch(
    val patternType: CandlestickPatternType,
    val name: String,
    val classification: IndicatorDirection,
    val timeframe: String,
    val detectionTimestamp: Long,
    val strength: String, // e.g., "High Reversal", "Strong Continuation", "Moderate Reversal", "Indecision"
    val confidencePct: Int,
    val description: String
)

/**
 * Aggregated Candlestick Analysis Result.
 */
data class CandlestickAnalysisResult(
    val detectedPatterns: List<CandlestickPatternMatch>,
    val dominantPattern: CandlestickPatternMatch?,
    val overallBias: IndicatorDirection,
    val bullishPatternsCount: Int,
    val bearishPatternsCount: Int,
    val neutralPatternsCount: Int,
    val summaryText: String
)

/**
 * Market Trend Classification.
 */
enum class MarketTrendType(val label: String) {
    UPTREND("Uptrend"),
    DOWNTREND("Downtrend"),
    RANGE_SIDEWAYS("Range / Sideways")
}

/**
 * Market Structure Swing Type.
 */
enum class SwingType(val label: String, val code: String) {
    HIGHER_HIGH("Higher High", "HH"),
    HIGHER_LOW("Higher Low", "HL"),
    LOWER_HIGH("Lower High", "LH"),
    LOWER_LOW("Lower Low", "LL")
}

/**
 * Market Structural Dynamic State.
 */
enum class MarketStructureState(val label: String) {
    BREAKOUT("Breakout Above Resistance"),
    BREAKDOWN("Breakdown Below Support"),
    TREND_CONTINUATION("Trend Continuation"),
    POSSIBLE_TREND_REVERSAL("Possible Trend Reversal (Structure Shift)"),
    CONSOLIDATION("Consolidation in Range")
}

/**
 * Validated Swing Point.
 */
data class SwingPoint(
    val index: Int,
    val timestamp: Long,
    val price: Double,
    val isHigh: Boolean,
    val swingType: SwingType? = null
)

/**
 * Market Trend & Structure Analysis Result.
 */
data class MarketStructureResult(
    val trend: MarketTrendType,
    val state: MarketStructureState,
    val structuralBias: IndicatorDirection,
    val recentSwings: List<SwingPoint>,
    val keySwingHigh: Double,
    val keySwingLow: Double,
    val higherHighsCount: Int,
    val higherLowsCount: Int,
    val lowerHighsCount: Int,
    val lowerLowsCount: Int,
    val supportingInformation: String
)

/**
 * Support or Resistance Level.
 */
data class SupportResistanceLevel(
    val price: Double,
    val isSupport: Boolean,
    val strength: String, // "Major", "Moderate", "Minor"
    val touches: Int,
    val distancePct: Double,
    val distanceAbsolute: Double
)

/**
 * Support & Resistance Analysis Result.
 */
data class SupportResistanceResult(
    val supportLevels: List<SupportResistanceLevel>,
    val resistanceLevels: List<SupportResistanceLevel>,
    val nearestSupport: SupportResistanceLevel?,
    val nearestResistance: SupportResistanceLevel?,
    val currentPrice: Double,
    val rangeStatus: String
)

/**
 * Individual Fibonacci Retracement Level.
 */
data class FibonacciLevel(
    val ratio: Double,
    val percentageLabel: String,
    val price: Double,
    val isGoldenPocket: Boolean = false
)

/**
 * Fibonacci Analysis Result.
 */
data class FibonacciAnalysisResult(
    val swingHigh: Double,
    val swingLow: Double,
    val isUptrendRetracement: Boolean,
    val levels: List<FibonacciLevel>,
    val currentZone: String,
    val nearestLevel: FibonacciLevel?,
    val contextBias: IndicatorDirection,
    val explanation: String
)

/**
 * Volatility Environment Classification.
 */
enum class VolatilityEnvironment(val label: String) {
    LOW("Low Volatility (Range Compression)"),
    NORMAL("Normal Volatility (Liquid Flow)"),
    HIGH("High Volatility (Elevated Swings)"),
    EXTREME("Extreme Volatility (High Risk / Expansion)")
}

/**
 * Volatility Analysis Result.
 */
data class VolatilityAnalysisResult(
    val environment: VolatilityEnvironment,
    val atrValue: Double,
    val atrPercentOfPrice: Double,
    val historicalVolatility: Double,
    val contextDescription: String
)

/**
 * Risk / Reward Analysis Result.
 */
data class RiskRewardResult(
    val isValid: Boolean,
    val entryPrice: Double,
    val stopLossPrice: Double,
    val takeProfitPrice: Double,
    val riskDistance: Double,
    val riskPercent: Double,
    val rewardDistance: Double,
    val rewardPercent: Double,
    val ratioValue: Double,
    val ratioText: String, // e.g. "1 : 2.5" or "Insufficient data for reliable Risk/Reward"
    val setupBias: IndicatorDirection,
    val message: String
)

/**
 * News & Sentiment Analysis Result.
 */
data class NewsSentimentResult(
    val isConnected: Boolean,
    val sentimentScore: Int, // 0..100
    val direction: IndicatorDirection,
    val headlineSample: String?,
    val source: String?,
    val timestamp: Long,
    val statusMessage: String
)

/**
 * Component contribution breakdown to final analysis result.
 */
data class ComponentContribution(
    val componentName: String,
    val weightPercent: Int,
    val direction: IndicatorDirection,
    val scorePercent: Int,
    val explanation: String
)

/**
 * Complete Module #6 Analysis Result.
 */
data class CompleteAnalysisResult(
    val symbol: String,
    val market: String,
    val currentPrice: Double,
    val timestamp: Long,
    val overallSignal: FinalAnalysisSignal,
    val overallConfidencePct: Int,
    val coreSnapshot: AnalysisScoreSnapshot,
    val candlestickResult: CandlestickAnalysisResult,
    val structureResult: MarketStructureResult,
    val supportResistanceResult: SupportResistanceResult,
    val fibonacciResult: FibonacciAnalysisResult,
    val volatilityResult: VolatilityAnalysisResult,
    val riskRewardResult: RiskRewardResult,
    val newsResult: NewsSentimentResult,
    val contributions: List<ComponentContribution>,
    val contributingFactorsExplanation: String,
    val isOnlySignalSafe: Boolean = true
) {
    val isConfirmedCoreMet: Boolean get() = coreSnapshot.isConfirmationConditionMet
    val coreConfirmationRatioText: String get() = coreSnapshot.confirmationRatioText
}
