package com.example.core

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Samsung One UI uses decimal SI prefixes (1 GB = 1,000,000,000 bytes, 1 MB = 1,000,000 bytes).
 */
object ByteSizeFormatter {
    private const val KB = 1_000L
    private const val MB = 1_000_000L
    private const val GB = 1_000_000_000L
    private const val TB = 1_000_000_000_000L

    fun format(bytes: Long): String {
        val safeBytes = bytes.coerceAtLeast(0L)
        return when {
            safeBytes >= TB -> String.format(Locale.US, "%.2f TB", safeBytes.toDouble() / TB)
            safeBytes >= GB -> String.format(Locale.US, "%.1f GB", safeBytes.toDouble() / GB)
            safeBytes >= MB -> String.format(Locale.US, "%.1f MB", safeBytes.toDouble() / MB)
            safeBytes >= KB -> String.format(Locale.US, "%.1f KB", safeBytes.toDouble() / KB)
            else -> "$safeBytes B"
        }
    }

    fun formatUsedOfTotal(usedBytes: Long, totalBytes: Long): String {
        if (totalBytes <= 0L) return format(usedBytes)
        return "${format(usedBytes)} / ${format(totalBytes)}"
    }

    fun formatTimestamp(epochMillis: Long): String {
        if (epochMillis <= 0L) return "Unknown date"
        val sdf = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault())
        return sdf.format(Date(epochMillis))
    }

    fun formatShortDate(epochMillis: Long): String {
        if (epochMillis <= 0L) return ""
        val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
        return sdf.format(Date(epochMillis))
    }
}
