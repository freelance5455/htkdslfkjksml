package com.example.core.data.market

import com.example.core.model.Instrument
import com.example.core.model.MarketCategory
import kotlinx.coroutines.delay

/**
 * Dedicated Gold market symbol provider.
 * Dynamic instrument universe covering multi-currency spot gold, bullion bars, and standard contracts.
 */
class GoldSymbolProvider(
    private val shouldSimulateFailure: Boolean = false
) : MarketSymbolProvider {

    override val marketCategory: MarketCategory = MarketCategory.GOLD
    override val providerId: String = "BULLION_METALS"
    override val providerName: String = "Global Bullion & Metals Exchange"

    private val dynamicInstruments = mutableListOf<Instrument>()

    init {
        dynamicInstruments.addAll(buildDefaultGoldUniverse())
    }

    override suspend fun fetchSymbols(): Result<List<Instrument>> {
        if (shouldSimulateFailure) {
            return Result.failure(Exception("Precious metals bullion feed temporarily unreachable"))
        }
        delay(100)
        return Result.success(dynamicInstruments.toList())
    }

    override fun getInitialSymbols(): List<Instrument> {
        return dynamicInstruments.toList()
    }

    fun updateAvailableInstruments(newInstruments: List<Instrument>) {
        dynamicInstruments.clear()
        dynamicInstruments.addAll(newInstruments)
    }

    private fun buildDefaultGoldUniverse(): List<Instrument> {
        return listOf(
            Instrument(
                symbolId = "XAUUSD",
                displayName = "XAU/USD",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "USD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Gold Spot / US Dollar (1 Troy Ounce)"
            ),
            Instrument(
                symbolId = "XAUEUR",
                displayName = "XAU/EUR",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "EUR",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Gold Spot / Euro (1 Troy Ounce)"
            ),
            Instrument(
                symbolId = "XAUGBP",
                displayName = "XAU/GBP",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "GBP",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Gold Spot / British Pound"
            ),
            Instrument(
                symbolId = "XAUAUD",
                displayName = "XAU/AUD",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "AUD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Gold Spot / Australian Dollar"
            ),
            Instrument(
                symbolId = "XAUCHF",
                displayName = "XAU/CHF",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "CHF",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Gold Spot / Swiss Franc"
            ),
            Instrument(
                symbolId = "XAUJPY",
                displayName = "XAU/JPY",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "JPY",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 0,
                quantityPrecision = 2,
                tickSize = 1.0,
                minLotSize = 0.01,
                description = "Gold Spot / Japanese Yen"
            ),
            Instrument(
                symbolId = "XAUCAD",
                displayName = "XAU/CAD",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "CAD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Gold Spot / Canadian Dollar"
            ),
            Instrument(
                symbolId = "XAUCNH",
                displayName = "XAU/CNH",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "CNH",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Gold Spot / Offshore Chinese Yuan"
            ),
            Instrument(
                symbolId = "XAU100OZ",
                displayName = "XAU 100oz",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "USD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 1,
                tickSize = 0.05,
                minLotSize = 1.0,
                description = "Physical Gold 100 Troy Ounce Standard Contract"
            ),
            Instrument(
                symbolId = "XAU1KG",
                displayName = "XAU 1kg",
                marketCategory = MarketCategory.GOLD,
                baseAsset = "XAU",
                quoteAsset = "USD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 1,
                tickSize = 0.10,
                minLotSize = 1.0,
                description = "Physical Gold 1kg 999.9 Fine Bullion Bar"
            )
        )
    }
}
