package com.example.core.data.market

import com.example.core.model.Instrument
import com.example.core.model.MarketCategory
import kotlinx.coroutines.delay

/**
 * Dynamic Crypto symbol provider.
 * Architected to seamlessly integrate with Module #4 Binance API / WebSocket / ExchangeInfo.
 */
class CryptoSymbolProvider(
    private val shouldSimulateFailure: Boolean = false
) : MarketSymbolProvider {

    override val marketCategory: MarketCategory = MarketCategory.CRYPTO
    override val providerId: String = "BINANCE_CRYPTO"
    override val providerName: String = "Binance Spot & Futures"

    // In-memory dynamic instruments registry, allowing dynamic updates by provider modules
    private val dynamicInstruments = mutableListOf<Instrument>()

    init {
        dynamicInstruments.addAll(buildDefaultCryptoUniverse())
    }

    override suspend fun fetchSymbols(): Result<List<Instrument>> {
        if (shouldSimulateFailure) {
            return Result.failure(Exception("Crypto exchange endpoint unreachable"))
        }
        // Small async simulated retrieval
        delay(100)
        return Result.success(dynamicInstruments.toList())
    }

    override fun getInitialSymbols(): List<Instrument> {
        return dynamicInstruments.toList()
    }

    /**
     * Allows Module #4 (Binance) to dynamically update the available crypto pairs from exchangeInfo.
     */
    fun updateAvailableInstruments(newInstruments: List<Instrument>) {
        dynamicInstruments.clear()
        dynamicInstruments.addAll(newInstruments)
    }

    private fun buildDefaultCryptoUniverse(): List<Instrument> {
        return listOf(
            Instrument(
                symbolId = "BTCUSDT",
                displayName = "BTC/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "BTC",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 5,
                tickSize = 0.01,
                minLotSize = 0.00001,
                description = "Bitcoin / Tether USD"
            ),
            Instrument(
                symbolId = "ETHUSDT",
                displayName = "ETH/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "ETH",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 4,
                tickSize = 0.01,
                minLotSize = 0.0001,
                description = "Ethereum / Tether USD"
            ),
            Instrument(
                symbolId = "SOLUSDT",
                displayName = "SOL/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "SOL",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Solana / Tether USD"
            ),
            Instrument(
                symbolId = "BNBUSDT",
                displayName = "BNB/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "BNB",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 3,
                tickSize = 0.01,
                minLotSize = 0.001,
                description = "BNB / Tether USD"
            ),
            Instrument(
                symbolId = "XRPUSDT",
                displayName = "XRP/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "XRP",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 4,
                quantityPrecision = 1,
                tickSize = 0.0001,
                minLotSize = 0.1,
                description = "Ripple / Tether USD"
            ),
            Instrument(
                symbolId = "ADAUSDT",
                displayName = "ADA/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "ADA",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 4,
                quantityPrecision = 1,
                tickSize = 0.0001,
                minLotSize = 0.1,
                description = "Cardano / Tether USD"
            ),
            Instrument(
                symbolId = "DOGEUSDT",
                displayName = "DOGE/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "DOGE",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 0,
                tickSize = 0.00001,
                minLotSize = 1.0,
                description = "Dogecoin / Tether USD"
            ),
            Instrument(
                symbolId = "AVAXUSDT",
                displayName = "AVAX/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "AVAX",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 2,
                quantityPrecision = 2,
                tickSize = 0.01,
                minLotSize = 0.01,
                description = "Avalanche / Tether USD"
            ),
            Instrument(
                symbolId = "DOTUSDT",
                displayName = "DOT/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "DOT",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 3,
                quantityPrecision = 2,
                tickSize = 0.001,
                minLotSize = 0.01,
                description = "Polkadot / Tether USD"
            ),
            Instrument(
                symbolId = "LINKUSDT",
                displayName = "LINK/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "LINK",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 3,
                quantityPrecision = 2,
                tickSize = 0.001,
                minLotSize = 0.01,
                description = "Chainlink / Tether USD"
            ),
            Instrument(
                symbolId = "SUIUSDT",
                displayName = "SUI/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "SUI",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 4,
                quantityPrecision = 1,
                tickSize = 0.0001,
                minLotSize = 0.1,
                description = "Sui Network / Tether USD"
            ),
            Instrument(
                symbolId = "NEARUSDT",
                displayName = "NEAR/USDT",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "NEAR",
                quoteAsset = "USDT",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 3,
                quantityPrecision = 1,
                tickSize = 0.001,
                minLotSize = 0.1,
                description = "NEAR Protocol / Tether USD"
            ),
            Instrument(
                symbolId = "ETHBTC",
                displayName = "ETH/BTC",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "ETH",
                quoteAsset = "BTC",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 4,
                tickSize = 0.00001,
                minLotSize = 0.0001,
                description = "Ethereum / Bitcoin Ratio"
            ),
            Instrument(
                symbolId = "SOLBTC",
                displayName = "SOL/BTC",
                marketCategory = MarketCategory.CRYPTO,
                baseAsset = "SOL",
                quoteAsset = "BTC",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 6,
                quantityPrecision = 2,
                tickSize = 0.000001,
                minLotSize = 0.01,
                description = "Solana / Bitcoin Ratio"
            )
        )
    }
}
