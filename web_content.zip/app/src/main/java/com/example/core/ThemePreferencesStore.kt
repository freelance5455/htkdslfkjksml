package com.example.core

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File

enum class DesignSystem(val storageKey: String) {
    ANIME_WORLD("anime_world"),
    FLAMI_ORIGINAL("flami_original"),
    CLASSIC_AI("classic_ai");

    companion object {
        fun fromKey(key: String?): DesignSystem =
            entries.firstOrNull { it.storageKey == key } ?: FLAMI_ORIGINAL
    }
}

enum class ClassicThemeMode(val storageKey: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    companion object {
        fun fromKey(key: String?): ClassicThemeMode =
            entries.firstOrNull { it.storageKey == key } ?: DARK
    }
}

data class AppearanceSettings(
    val designSystem: DesignSystem = DesignSystem.FLAMI_ORIGINAL,
    val animeBgIndex: Int = 0,
    val customAnimeBgPath: String? = null,
    val classicThemeMode: ClassicThemeMode = ClassicThemeMode.DARK
)

private val Context.appearanceDataStore by preferencesDataStore(name = "flami_appearance_prefs")

class ThemePreferencesStore(private val context: Context) {
    private val appContext = context.applicationContext

    private object Keys {
        val DESIGN_SYSTEM = stringPreferencesKey("design_system")
        val ANIME_BG_INDEX = intPreferencesKey("anime_bg_index")
        val CUSTOM_ANIME_BG_PATH = stringPreferencesKey("custom_anime_bg_path")
        val CLASSIC_THEME_MODE = stringPreferencesKey("classic_theme_mode")
    }

    val appearanceFlow: Flow<AppearanceSettings> = appContext.appearanceDataStore.data.map { prefs ->
        AppearanceSettings(
            designSystem = DesignSystem.fromKey(prefs[Keys.DESIGN_SYSTEM]),
            animeBgIndex = prefs[Keys.ANIME_BG_INDEX] ?: 0,
            customAnimeBgPath = prefs[Keys.CUSTOM_ANIME_BG_PATH],
            classicThemeMode = ClassicThemeMode.fromKey(prefs[Keys.CLASSIC_THEME_MODE])
        )
    }

    suspend fun setDesignSystem(designSystem: DesignSystem) {
        appContext.appearanceDataStore.edit { prefs ->
            prefs[Keys.DESIGN_SYSTEM] = designSystem.storageKey
        }
    }

    suspend fun setAnimeBackgroundIndex(index: Int) {
        appContext.appearanceDataStore.edit { prefs ->
            prefs[Keys.ANIME_BG_INDEX] = index
        }
    }

    suspend fun setClassicThemeMode(mode: ClassicThemeMode) {
        appContext.appearanceDataStore.edit { prefs ->
            prefs[Keys.CLASSIC_THEME_MODE] = mode.storageKey
        }
    }

    suspend fun saveCustomAnimeBackground(sourceUri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val destFile = File(appContext.filesDir, "anime_custom_bg.jpg")
            appContext.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("Could not open selected image"))

            appContext.appearanceDataStore.edit { prefs ->
                prefs[Keys.CUSTOM_ANIME_BG_PATH] = destFile.absolutePath
                prefs[Keys.ANIME_BG_INDEX] = -1
            }
            Result.success(destFile.absolutePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
