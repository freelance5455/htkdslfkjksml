package com.example.core

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class DesignSystem(val storageKey: String) {
    ANIME_WORLD("anime_world"),
    FLAMI_ORIGINAL("flami_original"),
    CLASSIC_AI("classic_ai");

    companion object {
        fun fromKey(key: String?): DesignSystem =
            entries.firstOrNull { it.storageKey == key } ?: FLAMI_ORIGINAL
    }
}

enum class ClassicThemeMode(val storageKey: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark");

    companion object {
        fun fromKey(key: String?): ClassicThemeMode =
            entries.firstOrNull { it.storageKey == key } ?: DARK
    }
}

data class AppearanceSettings(
    val designSystem: DesignSystem = DesignSystem.FLAMI_ORIGINAL,
    val animeBgIndex: Int = 0,
    val customAnimeBgPath: String? = null,
    val classicThemeMode: ClassicThemeMode = ClassicThemeMode.DARK
)

private val Context.appearanceDataStore by preferencesDataStore(name = "flami_appearance_prefs")

class ThemePreferencesStore private constructor(private val appContext: Context) {

    private object Keys {
        val DESIGN_SYSTEM = stringPreferencesKey("design_system")
        val ANIME_BG_INDEX = intPreferencesKey("anime_bg_index")
        val CUSTOM_ANIME_BG_PATH = stringPreferencesKey("custom_anime_bg_path")
        val CLASSIC_THEME_MODE = stringPreferencesKey("classic_theme_mode")
    }

    private val storeScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _appearanceFlow = MutableStateFlow(AppearanceSettings())
    val appearanceFlow: StateFlow<AppearanceSettings> = _appearanceFlow.asStateFlow()

    init {
        storeScope.launch {
            appContext.appearanceDataStore.data.collect { prefs ->
                _appearanceFlow.value = AppearanceSettings(
                    designSystem = DesignSystem.fromKey(prefs[Keys.DESIGN_SYSTEM]),
                    animeBgIndex = prefs[Keys.ANIME_BG_INDEX] ?: 0,
                    customAnimeBgPath = prefs[Keys.CUSTOM_ANIME_BG_PATH],
                    classicThemeMode = ClassicThemeMode.fromKey(prefs[Keys.CLASSIC_THEME_MODE])
                )
            }
        }
    }

    suspend fun awaitLoaded(): AppearanceSettings {
        val prefs = appContext.appearanceDataStore.data.first()
        val loaded = AppearanceSettings(
            designSystem = DesignSystem.fromKey(prefs[Keys.DESIGN_SYSTEM]),
            animeBgIndex = prefs[Keys.ANIME_BG_INDEX] ?: 0,
            customAnimeBgPath = prefs[Keys.CUSTOM_ANIME_BG_PATH],
            classicThemeMode = ClassicThemeMode.fromKey(prefs[Keys.CLASSIC_THEME_MODE])
        )
        _appearanceFlow.value = loaded
        return loaded
    }

    suspend fun setDesignSystem(designSystem: DesignSystem) {
        _appearanceFlow.update { it.copy(designSystem = designSystem) }
        appContext.appearanceDataStore.edit { prefs ->
            prefs[Keys.DESIGN_SYSTEM] = designSystem.storageKey
        }
    }

    suspend fun setAnimeBackgroundIndex(index: Int) {
        _appearanceFlow.update { it.copy(animeBgIndex = index) }
        appContext.appearanceDataStore.edit { prefs ->
            prefs[Keys.ANIME_BG_INDEX] = index
        }
    }

    suspend fun setClassicThemeMode(mode: ClassicThemeMode) {
        _appearanceFlow.update { it.copy(classicThemeMode = mode) }
        appContext.appearanceDataStore.edit { prefs ->
            prefs[Keys.CLASSIC_THEME_MODE] = mode.storageKey
        }
    }

    suspend fun saveCustomAnimeBackground(sourceUri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val destFile = File(appContext.filesDir, "anime_custom_${System.currentTimeMillis()}.jpg")
            // Remove older custom background files
            appContext.filesDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("anime_custom") && file.absolutePath != destFile.absolutePath) {
                    file.delete()
                }
            }
            appContext.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext Result.failure(IllegalStateException("Could not open selected image"))

            _appearanceFlow.update {
                it.copy(customAnimeBgPath = destFile.absolutePath, animeBgIndex = -1)
            }
            appContext.appearanceDataStore.edit { prefs ->
                prefs[Keys.CUSTOM_ANIME_BG_PATH] = destFile.absolutePath
                prefs[Keys.ANIME_BG_INDEX] = -1
            }
            Result.success(destFile.absolutePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        @Volatile
        private var instance: ThemePreferencesStore? = null

        fun getInstance(context: Context): ThemePreferencesStore {
            return instance ?: synchronized(this) {
                instance ?: ThemePreferencesStore(context.applicationContext).also { instance = it }
            }
        }

        operator fun invoke(context: Context): ThemePreferencesStore = getInstance(context)
    }
}
