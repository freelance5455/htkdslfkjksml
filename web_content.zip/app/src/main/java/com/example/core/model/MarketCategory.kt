package com.example.core.model

/**
 * The three primary market categories supported by IQTrade Pro.
 * Crypto, Forex, and Gold are strictly separated.
 */
enum class MarketCategory(
    val id: String,
    val displayName: String,
    val defaultSymbolId: String,
    val defaultBaseAsset: String,
    val defaultQuoteAsset: String,
    val description: String
) {
    CRYPTO(
        id = "CRYPTO",
        displayName = "Crypto",
        defaultSymbolId = "BTCUSDT",
        defaultBaseAsset = "BTC",
        defaultQuoteAsset = "USDT",
        description = "Digital Asset Spot & Futures Trading Pairs"
    ),
    FOREX(
        id = "FOREX",
        displayName = "Forex",
        defaultSymbolId = "EURUSD",
        defaultBaseAsset = "EUR",
        defaultQuoteAsset = "USD",
        description = "Global Foreign Exchange Currency Pairs"
    ),
    GOLD(
        id = "GOLD",
        displayName = "Gold",
        defaultSymbolId = "XAUUSD",
        defaultBaseAsset = "XAU",
        defaultQuoteAsset = "USD",
        description = "Precious Metals & Gold Bullion Instruments"
    );

    companion object {
        fun fromId(id: String): MarketCategory {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) }
                ?: if (id.equals("SPOT", ignoreCase = true) || id.equals("FUTURES", ignoreCase = true)) {
                    CRYPTO
                } else {
                    CRYPTO
                }
        }
    }
}
