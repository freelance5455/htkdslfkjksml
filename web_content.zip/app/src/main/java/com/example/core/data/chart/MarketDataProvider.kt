package com.example.core.data.chart

import com.example.core.model.MarketCategory
import com.example.core.model.Timeframe
import com.example.core.model.chart.Candle
import com.example.core.model.chart.ChartConnectionState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/**
 * Architectural Data Provider Interface.
 * Allows decoupling between the market data source (Binance, Forex feed, Gold bullion feed)
 * and the Chart Data Adapter / UI.
 *
 * Adheres strictly to:
 * - Real market data architecture
 * - No fake live data or randomized prices
 * - Differentiates historical candles from developing live candles
 */
interface MarketDataProvider {
    val marketCategory: MarketCategory
    val providerId: String

    val connectionState: Flow<ChartConnectionState>
        get() = flowOf(ChartConnectionState.Connected)

    suspend fun fetchHistoricalCandles(
        symbol: String,
        timeframe: Timeframe,
        limit: Int = 100
    ): Result<List<Candle>>

    fun observeLiveCandle(
        symbol: String,
        timeframe: Timeframe
    ): Flow<Candle>

    fun disconnect() {}
}
