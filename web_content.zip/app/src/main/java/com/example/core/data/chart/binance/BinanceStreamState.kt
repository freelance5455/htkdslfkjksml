package com.example.core.data.chart.binance

/**
 * Connection states for the Binance WebSocket live stream.
 */
enum class BinanceStreamStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    STALE,
    ERROR
}

/**
 * Detailed real-time Binance connection telemetry.
 */
data class BinanceStreamState(
    val status: BinanceStreamStatus = BinanceStreamStatus.DISCONNECTED,
    val activeSymbol: String = "",
    val activeInterval: String = "",
    val currentEndpoint: String = "",
    val lastMessageTimestamp: Long = 0L,
    val reconnectAttempt: Int = 0,
    val errorMessage: String? = null
) {
    val isLive: Boolean get() = status == BinanceStreamStatus.CONNECTED
    val isStale: Boolean get() = status == BinanceStreamStatus.STALE
    val isReconnecting: Boolean get() = status == BinanceStreamStatus.RECONNECTING
}
