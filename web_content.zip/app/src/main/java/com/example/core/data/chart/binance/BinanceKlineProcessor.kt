package com.example.core.data.chart.binance

import com.example.core.model.chart.Candle
import org.json.JSONObject

/**
 * Validates and transforms raw Binance WebSocket messages into type-safe Candle models.
 *
 * Requirements:
 * - Validate symbol and timeframe (strictly differentiate "1m" vs "1M")
 * - Validate positive finite numeric values
 * - Enforce high >= max(open, close) and low <= min(open, close)
 * - Reject future timestamps (> now + 300_000ms clock skew)
 * - Detect open vs closed candles (k.x)
 * - Safe error handling: corrupt or unexpected messages return Result.failure without crashing
 */
object BinanceKlineProcessor {

    /**
     * Parses a raw WebSocket message string.
     * Supports both direct stream payload and combined stream payload {"stream": "...", "data": {...}}.
     */
    fun parseKlineMessage(
        rawJson: String,
        expectedSymbol: String,
        expectedInterval: String
    ): Result<Candle> {
        return try {
            val root = JSONObject(rawJson)

            // Handle combined stream wrapper if present
            val payload = if (root.has("data")) {
                root.getJSONObject("data")
            } else {
                root
            }

            // Check event type
            val eventType = payload.optString("e")
            if (eventType != "kline") {
                return Result.failure(IllegalArgumentException("Ignored non-kline event: $eventType"))
            }

            val klineObj = payload.optJSONObject("k")
                ?: return Result.failure(IllegalArgumentException("Missing 'k' (kline) object in payload"))

            // Symbol check
            val cleanExpectedSymbol = expectedSymbol.replace("/", "").uppercase()
            val symbolInMsg = klineObj.optString("s").uppercase()
            if (symbolInMsg != cleanExpectedSymbol) {
                return Result.failure(
                    IllegalArgumentException("Symbol mismatch: expected $cleanExpectedSymbol, got $symbolInMsg")
                )
            }

            // Interval check (Strictly enforce 1m vs 1M)
            val intervalInMsg = klineObj.optString("i")
            if (intervalInMsg != expectedInterval) {
                return Result.failure(
                    IllegalArgumentException("Interval mismatch: expected '$expectedInterval', got '$intervalInMsg'")
                )
            }

            // Timestamp parsing
            val openTime = klineObj.optLong("t", -1L)
            if (openTime <= 0L) {
                return Result.failure(IllegalArgumentException("Invalid open time: $openTime"))
            }

            val now = System.currentTimeMillis()
            if (openTime > now + 300_000L) {
                return Result.failure(IllegalArgumentException("Future timestamp rejected: $openTime vs now $now"))
            }

            // Price & Volume parsing
            val open = klineObj.optString("o").toDoubleOrNull()
            val high = klineObj.optString("h").toDoubleOrNull()
            val low = klineObj.optString("l").toDoubleOrNull()
            val close = klineObj.optString("c").toDoubleOrNull()
            val volume = klineObj.optString("v").toDoubleOrNull()

            if (open == null || high == null || low == null || close == null || volume == null) {
                return Result.failure(IllegalArgumentException("Malformed numeric values in kline"))
            }

            if (open <= 0.0 || high <= 0.0 || low <= 0.0 || close <= 0.0 || volume < 0.0) {
                return Result.failure(IllegalArgumentException("Invalid non-positive price values"))
            }

            // Geometric consistency check: high >= max(open, close), low <= min(open, close)
            val effectiveHigh = maxOf(high, maxOf(open, close))
            val effectiveLow = minOf(low, minOf(open, close))

            val isClosed = klineObj.optBoolean("x", false)

            val candle = Candle(
                timestamp = openTime,
                open = open,
                high = effectiveHigh,
                low = effectiveLow,
                close = close,
                volume = volume,
                isClosed = isClosed
            )

            Result.success(candle)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
