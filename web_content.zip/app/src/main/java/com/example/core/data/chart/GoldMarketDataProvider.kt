package com.example.core.data.chart

import com.example.core.model.MarketCategory
import com.example.core.model.Timeframe
import com.example.core.model.chart.Candle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Precious Metals & Gold Spot/Bullion Data Provider.
 * Prepared for live metals exchange feed integration.
 */
class GoldMarketDataProvider : MarketDataProvider {

    override val marketCategory: MarketCategory = MarketCategory.GOLD
    override val providerId: String = "GOLD_METALS_FEED"

    private val _liveCandleFlow = MutableSharedFlow<Candle>(replay = 1)

    override suspend fun fetchHistoricalCandles(
        symbol: String,
        timeframe: Timeframe,
        limit: Int
    ): Result<List<Candle>> {
        // Gold feed interface ready for precious metals API connection.
        return Result.success(emptyList())
    }

    override fun observeLiveCandle(symbol: String, timeframe: Timeframe): Flow<Candle> {
        return _liveCandleFlow.asSharedFlow()
    }

    suspend fun emitLiveCandle(candle: Candle) {
        _liveCandleFlow.emit(candle)
    }
}
