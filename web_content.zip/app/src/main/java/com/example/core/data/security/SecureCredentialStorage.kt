package com.example.core.data.security

import android.content.Context
import android.content.SharedPreferences
import com.example.features.notifications.WhatsAppPreferences

/**
 * Android-compatible Secure Credential Storage architecture.
 * Safely persists sensitive API keys and secrets without hardcoding or unencrypted exposure.
 */
interface SecureCredentialStorage {
    fun getBinanceApiKey(): String?
    fun saveBinanceApiKey(apiKey: String)
    fun getBinanceSecretKey(): String?
    fun saveBinanceSecretKey(secretKey: String)
    fun hasBinanceCredentials(): Boolean
    fun clearBinanceCredentials()

    fun getNewsApiKey(): String?
    fun saveNewsApiKey(key: String)
    fun clearNewsApiKey()

    fun getWhatsAppPhoneNumber(): String?
    fun saveWhatsAppPhoneNumber(phoneNumber: String)
    fun getWhatsAppApiKey(): String?
    fun saveWhatsAppApiKey(apiKey: String)
    fun getWhatsAppPhoneNumberId(): String?
    fun saveWhatsAppPhoneNumberId(phoneId: String)
    fun getWhatsAppPreferences(): WhatsAppPreferences
    fun saveWhatsAppPreferences(prefs: WhatsAppPreferences)
    fun clearWhatsAppConfig()

    fun getWhatsAppConnectionMethod(): String
    fun saveWhatsAppConnectionMethod(method: String)
    fun getWhatsAppConnectionStatus(): String
    fun saveWhatsAppConnectionStatus(status: String)
    fun getWhatsAppLastVerifiedTime(): String?
    fun saveWhatsAppLastVerifiedTime(time: String)
    fun getWhatsAppConnectedAccount(): String?
    fun saveWhatsAppConnectedAccount(account: String)
    fun isEventDeduplicated(eventKey: String, nowMs: Long, windowMs: Long): Boolean
    fun recordEventSent(eventKey: String, timestamp: Long)
    fun disconnectWhatsApp()
}

class AndroidSecureCredentialStorage(context: Context) : SecureCredentialStorage {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        "iqtrade_secure_vault",
        Context.MODE_PRIVATE
    )

    override fun getBinanceApiKey(): String? {
        return prefs.getString(KEY_BINANCE_API_KEY, null)
    }

    override fun saveBinanceApiKey(apiKey: String) {
        prefs.edit().putString(KEY_BINANCE_API_KEY, apiKey.trim()).apply()
    }

    override fun getBinanceSecretKey(): String? {
        return prefs.getString(KEY_BINANCE_SECRET_KEY, null)
    }

    override fun saveBinanceSecretKey(secretKey: String) {
        prefs.edit().putString(KEY_BINANCE_SECRET_KEY, secretKey.trim()).apply()
    }

    override fun hasBinanceCredentials(): Boolean {
        val key = getBinanceApiKey()
        val secret = getBinanceSecretKey()
        return !key.isNullOrBlank() && !secret.isNullOrBlank()
    }

    override fun clearBinanceCredentials() {
        prefs.edit()
            .remove(KEY_BINANCE_API_KEY)
            .remove(KEY_BINANCE_SECRET_KEY)
            .apply()
    }

    override fun getNewsApiKey(): String? {
        return prefs.getString(KEY_NEWS_API_KEY, null)
    }

    override fun saveNewsApiKey(key: String) {
        prefs.edit().putString(KEY_NEWS_API_KEY, key.trim()).apply()
    }

    override fun clearNewsApiKey() {
        prefs.edit().remove(KEY_NEWS_API_KEY).apply()
    }

    override fun getWhatsAppPhoneNumber(): String? {
        return prefs.getString(KEY_WHATSAPP_PHONE, null)
    }

    override fun saveWhatsAppPhoneNumber(phoneNumber: String) {
        prefs.edit().putString(KEY_WHATSAPP_PHONE, phoneNumber.trim()).apply()
    }

    override fun getWhatsAppApiKey(): String? {
        return prefs.getString(KEY_WHATSAPP_API_KEY, null)
    }

    override fun saveWhatsAppApiKey(apiKey: String) {
        prefs.edit().putString(KEY_WHATSAPP_API_KEY, apiKey.trim()).apply()
    }

    override fun getWhatsAppPhoneNumberId(): String? {
        return prefs.getString(KEY_WHATSAPP_PHONE_ID, null)
    }

    override fun saveWhatsAppPhoneNumberId(phoneId: String) {
        prefs.edit().putString(KEY_WHATSAPP_PHONE_ID, phoneId.trim()).apply()
    }

    override fun getWhatsAppPreferences(): WhatsAppPreferences {
        return WhatsAppPreferences(
            isServiceEnabled = prefs.getBoolean(KEY_WHATSAPP_ENABLED, false),
            notifyOnTradeSignal = prefs.getBoolean(KEY_WHATSAPP_NOTIF_SIGNAL, true),
            notifyOnPriceAlert = prefs.getBoolean(KEY_WHATSAPP_NOTIF_PRICE, true),
            notifyOnStopLossTakeProfit = prefs.getBoolean(KEY_WHATSAPP_NOTIF_SLTP, true),
            notifyOnTrailingStop = prefs.getBoolean(KEY_WHATSAPP_NOTIF_TRAILING, true),
            notifyOnManualStop = prefs.getBoolean(KEY_WHATSAPP_NOTIF_MANUAL, true),
            notifyOnConfirmedTrade = prefs.getBoolean(KEY_WHATSAPP_NOTIF_CONFIRMED, true),
            notifyOnNews = prefs.getBoolean(KEY_WHATSAPP_NOTIF_NEWS, true)
        )
    }

    override fun saveWhatsAppPreferences(prefsData: WhatsAppPreferences) {
        prefs.edit()
            .putBoolean(KEY_WHATSAPP_ENABLED, prefsData.isServiceEnabled)
            .putBoolean(KEY_WHATSAPP_NOTIF_SIGNAL, prefsData.notifyOnTradeSignal)
            .putBoolean(KEY_WHATSAPP_NOTIF_PRICE, prefsData.notifyOnPriceAlert)
            .putBoolean(KEY_WHATSAPP_NOTIF_SLTP, prefsData.notifyOnStopLossTakeProfit)
            .putBoolean(KEY_WHATSAPP_NOTIF_TRAILING, prefsData.notifyOnTrailingStop)
            .putBoolean(KEY_WHATSAPP_NOTIF_MANUAL, prefsData.notifyOnManualStop)
            .putBoolean(KEY_WHATSAPP_NOTIF_CONFIRMED, prefsData.notifyOnConfirmedTrade)
            .putBoolean(KEY_WHATSAPP_NOTIF_NEWS, prefsData.notifyOnNews)
            .apply()
    }

    override fun clearWhatsAppConfig() {
        prefs.edit()
            .remove(KEY_WHATSAPP_PHONE)
            .remove(KEY_WHATSAPP_API_KEY)
            .remove(KEY_WHATSAPP_PHONE_ID)
            .remove(KEY_WHATSAPP_ENABLED)
            .remove(KEY_WHATSAPP_STATUS)
            .remove(KEY_WHATSAPP_LAST_VERIFIED)
            .remove(KEY_WHATSAPP_ACCOUNT_ID)
            .apply()
    }

    override fun getWhatsAppConnectionMethod(): String {
        return prefs.getString(KEY_WHATSAPP_METHOD, "META_CLOUD_API") ?: "META_CLOUD_API"
    }

    override fun saveWhatsAppConnectionMethod(method: String) {
        prefs.edit().putString(KEY_WHATSAPP_METHOD, method).apply()
    }

    override fun getWhatsAppConnectionStatus(): String {
        return prefs.getString(KEY_WHATSAPP_STATUS, "Disconnected") ?: "Disconnected"
    }

    override fun saveWhatsAppConnectionStatus(status: String) {
        prefs.edit().putString(KEY_WHATSAPP_STATUS, status).apply()
    }

    override fun getWhatsAppLastVerifiedTime(): String? {
        return prefs.getString(KEY_WHATSAPP_LAST_VERIFIED, null)
    }

    override fun saveWhatsAppLastVerifiedTime(time: String) {
        prefs.edit().putString(KEY_WHATSAPP_LAST_VERIFIED, time).apply()
    }

    override fun getWhatsAppConnectedAccount(): String? {
        return prefs.getString(KEY_WHATSAPP_ACCOUNT_ID, null)
    }

    override fun saveWhatsAppConnectedAccount(account: String) {
        prefs.edit().putString(KEY_WHATSAPP_ACCOUNT_ID, account).apply()
    }

    override fun isEventDeduplicated(eventKey: String, nowMs: Long, windowMs: Long): Boolean {
        val lastSent = prefs.getLong(PREFIX_DEDUP + eventKey, 0L)
        return (nowMs - lastSent) in 0 until windowMs
    }

    override fun recordEventSent(eventKey: String, timestamp: Long) {
        prefs.edit().putLong(PREFIX_DEDUP + eventKey, timestamp).apply()
    }

    override fun disconnectWhatsApp() {
        prefs.edit()
            .putString(KEY_WHATSAPP_STATUS, "Disconnected")
            .remove(KEY_WHATSAPP_LAST_VERIFIED)
            .remove(KEY_WHATSAPP_ACCOUNT_ID)
            .putBoolean(KEY_WHATSAPP_ENABLED, false)
            .apply()
    }

    companion object {
        private const val KEY_BINANCE_API_KEY = "sec_binance_api_key"
        private const val KEY_BINANCE_SECRET_KEY = "sec_binance_secret_key"
        private const val KEY_NEWS_API_KEY = "sec_news_api_key"
        private const val KEY_WHATSAPP_PHONE = "sec_whatsapp_phone"
        private const val KEY_WHATSAPP_API_KEY = "sec_whatsapp_api_key"
        private const val KEY_WHATSAPP_PHONE_ID = "sec_whatsapp_phone_id"
        private const val KEY_WHATSAPP_ENABLED = "sec_whatsapp_enabled"
        private const val KEY_WHATSAPP_NOTIF_SIGNAL = "sec_whatsapp_notif_signal"
        private const val KEY_WHATSAPP_NOTIF_PRICE = "sec_whatsapp_notif_price"
        private const val KEY_WHATSAPP_NOTIF_SLTP = "sec_whatsapp_notif_sltp"
        private const val KEY_WHATSAPP_NOTIF_TRAILING = "sec_whatsapp_notif_trailing"
        private const val KEY_WHATSAPP_NOTIF_MANUAL = "sec_whatsapp_notif_manual"
        private const val KEY_WHATSAPP_NOTIF_CONFIRMED = "sec_whatsapp_notif_confirmed"
        private const val KEY_WHATSAPP_NOTIF_NEWS = "sec_whatsapp_notif_news"
        private const val KEY_WHATSAPP_METHOD = "sec_whatsapp_method"
        private const val KEY_WHATSAPP_STATUS = "sec_whatsapp_status"
        private const val KEY_WHATSAPP_LAST_VERIFIED = "sec_whatsapp_last_verified"
        private const val KEY_WHATSAPP_ACCOUNT_ID = "sec_whatsapp_account_id"
        private const val PREFIX_DEDUP = "sec_dedup_"
    }
}
