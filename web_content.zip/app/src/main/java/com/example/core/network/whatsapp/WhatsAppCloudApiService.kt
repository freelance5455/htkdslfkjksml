package com.example.core.network.whatsapp

import android.util.Log
import com.example.features.notifications.WhatsAppVerificationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Production-ready Meta WhatsApp Business Cloud API Network Service.
 *
 * Implements:
 * - Direct HTTP POST dispatch to https://graph.facebook.com/v19.0/{PHONE_NUMBER_ID}/messages
 * - Bearer Token authentication via Access Token (never logged or exposed)
 * - Safe retry strategy for transient 5xx server errors and network IO timeouts
 * - Clear error diagnostics for 400 Bad Request, 401/403 Authentication failures, 404 Not Found
 * - Real API response parsing (messageId extraction)
 */
class WhatsAppCloudApiService(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    companion object {
        private const val TAG = "WhatsAppCloudApi"
        private const val BASE_GRAPH_URL = "https://graph.facebook.com/v19.0"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    /**
     * Dispatches a text message payload to the configured recipient via Meta WhatsApp Cloud API.
     *
     * @param phoneNumberId The Meta Business WhatsApp Phone Number ID (from Meta Developer App Console)
     * @param accessToken The Meta User/System User Access Token
     * @param recipientPhone The recipient's phone in E.164 international format (e.g. +923001234567)
     * @param messageBody The informational message body to send
     * @return [WhatsAppSendResult.Success] on HTTP 200/201 with message ID, or [WhatsAppSendResult.Failure]
     */
    suspend fun sendTextMessage(
        phoneNumberId: String,
        accessToken: String,
        recipientPhone: String,
        messageBody: String
    ): WhatsAppSendResult = withContext(Dispatchers.IO) {
        val cleanPhoneId = phoneNumberId.trim()
        val cleanToken = accessToken.trim()
        val cleanRecipient = recipientPhone.trim().replace(" ", "").replace("-", "")

        if (cleanPhoneId.isBlank()) {
            return@withContext WhatsAppSendResult.Failure(
                "Phone Number ID is missing. Enter your Meta WhatsApp Phone Number ID in Gateway Configuration."
            )
        }
        if (cleanToken.isBlank()) {
            return@withContext WhatsAppSendResult.Failure(
                "Access Token is missing. Enter your Meta WhatsApp Cloud API Token in Gateway Configuration."
            )
        }
        if (cleanRecipient.isBlank()) {
            return@withContext WhatsAppSendResult.Failure(
                "Recipient WhatsApp Number is missing."
            )
        }

        // Meta WhatsApp Cloud API expects recipient without '+' sign for 'to' field (e.g., 923001234567)
        val formattedTo = if (cleanRecipient.startsWith("+")) cleanRecipient.substring(1) else cleanRecipient

        val payload = JSONObject().apply {
            put("messaging_product", "whatsapp")
            put("recipient_type", "individual")
            put("to", formattedTo)
            put("type", "text")
            put("text", JSONObject().apply {
                put("preview_url", false)
                put("body", messageBody)
            })
        }

        val requestUrl = "$BASE_GRAPH_URL/$cleanPhoneId/messages"
        val requestBody = payload.toString().toRequestBody(JSON_MEDIA_TYPE)

        val request = Request.Builder()
            .url(requestUrl)
            .addHeader("Authorization", "Bearer $cleanToken")
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

        var lastException: Exception? = null
        val maxAttempts = 2

        for (attempt in 1..maxAttempts) {
            try {
                client.newCall(request).execute().use { response ->
                    val responseCode = response.code
                    val responseBodyString = response.body?.string().orEmpty()

                    if (response.isSuccessful) {
                        return@withContext try {
                            val json = JSONObject(responseBodyString)
                            val messagesArray = json.optJSONArray("messages")
                            val messageId = if (messagesArray != null && messagesArray.length() > 0) {
                                messagesArray.getJSONObject(0).optString("id", "msg_success")
                            } else {
                                "meta_ack"
                            }
                            WhatsAppSendResult.Success(messageId = messageId, recipient = cleanRecipient)
                        } catch (e: Exception) {
                            WhatsAppSendResult.Success(messageId = "meta_ack", recipient = cleanRecipient)
                        }
                    } else {
                        // Extract human-readable error from Meta Graph API error payload
                        val errorDetail = parseMetaError(responseBodyString, responseCode)
                        // If 5xx server error and retry remaining, retry
                        if (responseCode in 500..599 && attempt < maxAttempts) {
                            delay(1000)
                            return@use // continue loop
                        }
                        return@withContext WhatsAppSendResult.Failure(
                            errorMessage = errorDetail,
                            httpCode = responseCode
                        )
                    }
                }
            } catch (e: IOException) {
                lastException = e
                if (attempt < maxAttempts) {
                    delay(1000)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error calling WhatsApp Cloud API: ${e.message}")
                return@withContext WhatsAppSendResult.Failure("Unexpected error: ${e.message ?: "Unknown"}")
            }
        }

        val timeoutOrNetwork = lastException?.message ?: "Network timeout connecting to Meta WhatsApp API"
        WhatsAppSendResult.Failure(errorMessage = "Network connection failed: $timeoutOrNetwork")
    }

    private fun parseMetaError(responseBody: String, code: Int): String {
        return try {
            val root = JSONObject(responseBody)
            if (root.has("error")) {
                val errorObj = root.getJSONObject("error")
                val message = errorObj.optString("message", "")
                val errorUserTitle = errorObj.optString("error_user_title", "")
                val errorUserMsg = errorObj.optString("error_user_msg", "")
                val type = errorObj.optString("type", "")
                val subcode = errorObj.optInt("error_subcode", 0)

                val details = listOf(errorUserTitle, errorUserMsg, message)
                    .filter { it.isNotBlank() }
                    .joinToString(" - ")

                if (details.isNotBlank()) {
                    "Meta API Error ($code): $details"
                } else {
                    "Meta API Error ($code): $type (subcode $subcode)"
                }
            } else {
                "Meta API returned HTTP $code: $responseBody"
            }
        } catch (e: Exception) {
            when (code) {
                401 -> "HTTP 401 Unauthorized: Invalid or expired Meta Access Token."
                403 -> "HTTP 403 Forbidden: Missing permissions for Phone Number ID or WhatsApp Business Account."
                404 -> "HTTP 404 Not Found: Invalid Phone Number ID endpoint."
                else -> "Meta API returned HTTP $code"
            }
        }
    }

    /**
     * Verifies the configured Meta WhatsApp Phone Number ID and Access Token
     * by querying the official Meta Graph API: GET https://graph.facebook.com/v19.0/{PHONE_NUMBER_ID}
     */
    suspend fun verifyConnection(
        phoneNumberId: String,
        accessToken: String
    ): WhatsAppVerificationResult = withContext(Dispatchers.IO) {
        val cleanPhoneId = phoneNumberId.trim()
        val cleanToken = accessToken.trim()

        if (cleanPhoneId.isBlank()) {
            return@withContext WhatsAppVerificationResult.Failure(
                errorMessage = "Phone Number ID is missing.",
                isAuthFailure = true
            )
        }
        if (cleanToken.isBlank()) {
            return@withContext WhatsAppVerificationResult.Failure(
                errorMessage = "Access Token is missing.",
                isAuthFailure = true
            )
        }

        val requestUrl = "$BASE_GRAPH_URL/$cleanPhoneId?fields=id,display_phone_number,verified_name,quality_rating,code_verification_status"
        val request = Request.Builder()
            .url(requestUrl)
            .addHeader("Authorization", "Bearer $cleanToken")
            .get()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val code = response.code
                val body = response.body?.string().orEmpty()

                if (response.isSuccessful) {
                    val json = JSONObject(body)
                    val displayPhone = json.optString("display_phone_number", cleanPhoneId)
                    val verifiedName = json.optString("verified_name", "WhatsApp Business Account")
                    val nowFormatted = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", java.util.Locale.US).apply {
                        timeZone = java.util.TimeZone.getTimeZone("UTC")
                    }.format(java.util.Date())

                    WhatsAppVerificationResult.Success(
                        displayPhoneNumber = displayPhone,
                        verifiedName = verifiedName,
                        verifiedAt = nowFormatted
                    )
                } else {
                    val errorDetail = parseMetaError(body, code)
                    val isAuth = code == 401 || code == 403
                    WhatsAppVerificationResult.Failure(
                        errorMessage = errorDetail,
                        httpCode = code,
                        isAuthFailure = isAuth
                    )
                }
            }
        } catch (e: Exception) {
            WhatsAppVerificationResult.Failure(
                errorMessage = "Connection check failed: ${e.message ?: "Network error"}",
                httpCode = null,
                isAuthFailure = false
            )
        }
    }
}
