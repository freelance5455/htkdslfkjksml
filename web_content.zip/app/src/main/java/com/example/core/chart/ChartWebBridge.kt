package com.example.core.chart

import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.example.core.model.chart.Candle
import com.example.core.model.chart.ChartDrawing
import com.example.core.model.chart.DrawingType
import com.example.core.model.chart.ExecutedTradeMarker
import com.example.core.model.chart.IndicatorCalculator
import com.example.core.model.chart.IndicatorInstance
import com.example.core.model.chart.PriceAlertEvent
import com.example.core.model.chart.SignalMarker
import com.example.core.model.chart.TradeProtectionState
import org.json.JSONArray
import org.json.JSONObject

/**
 * Native bridge connecting Android Compose runtime with the embedded
 * TradingView Lightweight Charts engine.
 */
class ChartWebBridge(
    private val onChartReadyCallback: () -> Unit = {},
    private val onCrosshairCallback: (time: Long, o: Double, h: Double, l: Double, c: Double) -> Unit = { _, _, _, _, _ -> },
    private val onDrawingCreatedCallback: (ChartDrawing) -> Unit = {},
    private val onPriceAlertCallback: (PriceAlertEvent) -> Unit = {}
) {
    private var webView: WebView? = null
    var isChartReady: Boolean = false
        private set

    var onPriceAlert: ((PriceAlertEvent) -> Unit)? = null

    @Volatile
    private var pendingExportCallback: ((String?) -> Unit)? = null

    fun attachWebView(view: WebView) {
        this.webView = view
    }

    fun detachWebView() {
        this.webView = null
        this.isChartReady = false
    }

    @JavascriptInterface
    fun onChartInitialized() {
        webView?.post {
            isChartReady = true
            onChartReadyCallback()
        }
    }

    @JavascriptInterface
    fun onCrosshairMoved(time: Long, open: Double, high: Double, low: Double, close: Double) {
        webView?.post {
            onCrosshairCallback(time, open, high, low, close)
        }
    }

    @JavascriptInterface
    fun onDrawingCreated(drawingJson: String) {
        webView?.post {
            try {
                val obj = JSONObject(drawingJson)
                val drawing = ChartDrawing.fromJson(obj, "", "")
                onDrawingCreatedCallback(drawing)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun onChartExported(base64Image: String) {
        webView?.post {
            val callback = pendingExportCallback
            pendingExportCallback = null
            callback?.invoke(base64Image)
        }
    }

    @JavascriptInterface
    fun onPriceAlert(alertJson: String) {
        val action = Runnable {
            try {
                val event = PriceAlertEvent.fromJson(alertJson)
                if (event != null) {
                    onPriceAlertCallback(event)
                    onPriceAlert?.invoke(event)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        val target = webView
        if (target != null) {
            target.post(action)
        } else {
            action.run()
        }
    }

    @JavascriptInterface
    fun onPriceAlert(lineId: String, targetPrice: Double, currentPrice: Double, direction: String) {
        webView?.post {
            val event = PriceAlertEvent(
                lineId = lineId,
                targetPrice = targetPrice,
                currentPrice = currentPrice,
                direction = direction,
                title = "Horizontal Price Line",
                timestamp = System.currentTimeMillis(),
                message = "Price crossed $direction $targetPrice"
            )
            onPriceAlertCallback(event)
            onPriceAlert?.invoke(event)
        }
    }

    /**
     * Exports the current view of the canvas as a base64 image string.
     * Evaluates window.exportCanvasBase64() and returns the base64 PNG data URL string
     * to the provided callback.
     */
    fun exportCanvasAsBase64(includeDrawings: Boolean = true, callback: (String?) -> Unit) {
        val currentWebView = webView
        if (!isChartReady || currentWebView == null) {
            callback(null)
            return
        }

        pendingExportCallback = callback
        currentWebView.post {
            val script = "window.exportCanvasBase64 ? window.exportCanvasBase64($includeDrawings) : null"
            currentWebView.evaluateJavascript(script) { result ->
                if (result != null && result != "null" && result != "\"null\"" && result.isNotEmpty()) {
                    val cleaned = try {
                        org.json.JSONTokener(result).nextValue() as? String ?: result.trim('"')
                    } catch (e: Exception) {
                        result.trim('"')
                    }
                    if (cleaned.isNotBlank() && cleaned != "null") {
                        val cb = pendingExportCallback
                        pendingExportCallback = null
                        cb?.invoke(cleaned)
                    }
                }
            }
        }
    }

    /**
     * Coroutine suspend version of exportCanvasAsBase64.
     */
    suspend fun exportCanvasAsBase64(includeDrawings: Boolean = true): String? =
        kotlinx.coroutines.suspendCancellableCoroutine { cont ->
            exportCanvasAsBase64(includeDrawings) { base64 ->
                if (cont.isActive) {
                    cont.resume(base64, onCancellation = null)
                }
            }
        }

    fun exportChartAsBase64(callback: (String?) -> Unit) = exportCanvasAsBase64(true, callback)
    suspend fun exportChartAsBase64(): String? = exportCanvasAsBase64(true)

    fun setCandles(candles: List<Candle>) {
        if (!isChartReady || webView == null) return
        val array = JSONArray()
        for (c in candles) {
            array.put(c.toJson())
        }
        val script = "window.setCandles(${array});"
        executeScript(script)
    }

    fun updateCandle(candle: Candle) {
        if (!isChartReady || webView == null) return
        val script = "window.updateCandle(${candle.toJson()});"
        executeScript(script)
    }

    fun setVolumeVisible(visible: Boolean) {
        if (!isChartReady || webView == null) return
        executeScript("window.setVolumeVisible($visible);")
    }

    fun setWatermark(text: String) {
        if (!isChartReady || webView == null) return
        executeScript("window.setWatermark('$text');")
    }

    fun updateIndicators(indicators: List<IndicatorInstance>, candles: List<Candle>) {
        if (!isChartReady || webView == null) return
        val array = JSONArray()
        for (ind in indicators) {
            val points = if (ind.isEnabled) IndicatorCalculator.calculate(ind, candles) else emptyList()
            array.put(ind.toJson(points))
        }
        executeScript("window.setIndicators(${array});")
    }

    fun updateMarkers(trades: List<ExecutedTradeMarker>, signals: List<SignalMarker>, showSignals: Boolean) {
        if (!isChartReady || webView == null) return
        val array = JSONArray()
        for (t in trades) {
            array.put(t.toEntryMarkerJson())
            val exitMarker = t.toExitMarkerJson()
            if (exitMarker != null) {
                array.put(exitMarker)
            }
        }
        if (showSignals) {
            for (s in signals) {
                array.put(s.toChartMarkerJson())
            }
        }
        executeScript("window.setTradeAndSignalMarkers(${array});")
    }

    fun updatePriceLines(protection: TradeProtectionState?, entryPrice: Double?, isPositionOpen: Boolean) {
        if (!isChartReady || webView == null) return
        val array = JSONArray()

        if (isPositionOpen && entryPrice != null && entryPrice > 0) {
            val entryObj = JSONObject()
            entryObj.put("id", "entry_line")
            entryObj.put("price", entryPrice)
            entryObj.put("color", "#00E5FF")
            entryObj.put("title", "ENTRY: %.2f".format(entryPrice))
            entryObj.put("lineWidth", 2)
            entryObj.put("lineStyle", 0) // Solid
            array.put(entryObj)
        }

        if (protection != null) {
            val sl = protection.effectiveStopLossPrice
            if (sl != null && sl > 0) {
                val slObj = JSONObject()
                slObj.put("id", "sl_line")
                slObj.put("price", sl)
                slObj.put("color", "#FF3D57")
                slObj.put("title", "SL (${protection.stopLossMode.label}): %.2f".format(sl))
                slObj.put("lineWidth", 2)
                slObj.put("lineStyle", 2) // Dashed
                array.put(slObj)
            }

            val tp = protection.effectiveTakeProfitPrice
            if (tp != null && tp > 0) {
                val tpObj = JSONObject()
                tpObj.put("id", "tp_line")
                tpObj.put("price", tp)
                tpObj.put("color", "#00E676")
                tpObj.put("title", "TP: %.2f".format(tp))
                tpObj.put("lineWidth", 2)
                tpObj.put("lineStyle", 2) // Dashed
                array.put(tpObj)
            }
        }

        executeScript("window.setPriceLines(${array});")
    }

    fun setDrawingTool(tool: DrawingType) {
        if (!isChartReady || webView == null) return
        executeScript("window.setDrawingTool('${tool.name}');")
    }

    fun setDrawings(drawings: List<ChartDrawing>) {
        if (!isChartReady || webView == null) return
        val array = JSONArray()
        for (d in drawings) {
            array.put(d.toJson())
        }
        executeScript("window.setDrawings(${array});")
    }

    fun clearDrawings() {
        if (!isChartReady || webView == null) return
        executeScript("window.clearDrawings();")
    }

    /**
     * Adds an active horizontal price line to monitor for price crossing alerts.
     */
    fun addHorizontalPriceLine(id: String, price: Double, title: String = "Alert Line", color: String = "#00E5FF") {
        if (!isChartReady || webView == null) return
        val escapedTitle = JSONObject.quote(title)
        executeScript("window.addHorizontalPriceLine('$id', $price, $escapedTitle, '$color');")
    }

    /**
     * Removes an active horizontal price line from alert monitoring.
     */
    fun removeHorizontalPriceLine(id: String) {
        if (!isChartReady || webView == null) return
        executeScript("window.removeHorizontalPriceLine('$id');")
    }

    /**
     * Sets multiple horizontal price lines for alert monitoring.
     */
    fun setHorizontalPriceLines(lines: List<Pair<String, Double>>) {
        if (!isChartReady || webView == null) return
        val array = JSONArray()
        for (line in lines) {
            val obj = JSONObject()
            obj.put("id", line.first)
            obj.put("price", line.second)
            obj.put("title", "Alert Line")
            obj.put("color", "#00E5FF")
            array.put(obj)
        }
        executeScript("window.setHorizontalPriceLines(${array});")
    }

    /**
     * Clears all horizontal price lines set for alert monitoring.
     */
    fun clearHorizontalPriceLines() {
        if (!isChartReady || webView == null) return
        executeScript("window.clearHorizontalPriceLines();")
    }

    private fun executeScript(script: String) {
        webView?.post {
            webView?.evaluateJavascript(script, null)
        }
    }
}
