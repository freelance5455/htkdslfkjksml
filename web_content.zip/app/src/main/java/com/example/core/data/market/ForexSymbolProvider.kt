package com.example.core.data.market

import com.example.core.model.Instrument
import com.example.core.model.MarketCategory
import kotlinx.coroutines.delay

/**
 * Dynamic Forex symbol provider.
 * Supports complete currency pair universe: Majors, Minors, Crosses, and Liquid Exotics.
 */
class ForexSymbolProvider(
    private val shouldSimulateFailure: Boolean = false
) : MarketSymbolProvider {

    override val marketCategory: MarketCategory = MarketCategory.FOREX
    override val providerId: String = "INTERBANK_FOREX"
    override val providerName: String = "Interbank Institutional FX"

    private val dynamicInstruments = mutableListOf<Instrument>()

    init {
        dynamicInstruments.addAll(buildDefaultForexUniverse())
    }

    override suspend fun fetchSymbols(): Result<List<Instrument>> {
        if (shouldSimulateFailure) {
            return Result.failure(Exception("Forex liquidity network provider unavailable"))
        }
        delay(100)
        return Result.success(dynamicInstruments.toList())
    }

    override fun getInitialSymbols(): List<Instrument> {
        return dynamicInstruments.toList()
    }

    fun updateAvailableInstruments(newInstruments: List<Instrument>) {
        dynamicInstruments.clear()
        dynamicInstruments.addAll(newInstruments)
    }

    private fun buildDefaultForexUniverse(): List<Instrument> {
        return listOf(
            // Major Pairs
            Instrument(
                symbolId = "EURUSD",
                displayName = "EUR/USD",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "EUR",
                quoteAsset = "USD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "Euro / US Dollar"
            ),
            Instrument(
                symbolId = "GBPUSD",
                displayName = "GBP/USD",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "GBP",
                quoteAsset = "USD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "British Pound / US Dollar"
            ),
            Instrument(
                symbolId = "USDJPY",
                displayName = "USD/JPY",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "USD",
                quoteAsset = "JPY",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 3,
                quantityPrecision = 2,
                tickSize = 0.001,
                minLotSize = 0.01,
                description = "US Dollar / Japanese Yen"
            ),
            Instrument(
                symbolId = "AUDUSD",
                displayName = "AUD/USD",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "AUD",
                quoteAsset = "USD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "Australian Dollar / US Dollar"
            ),
            Instrument(
                symbolId = "USDCAD",
                displayName = "USD/CAD",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "USD",
                quoteAsset = "CAD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "US Dollar / Canadian Dollar"
            ),
            Instrument(
                symbolId = "USDCHF",
                displayName = "USD/CHF",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "USD",
                quoteAsset = "CHF",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "US Dollar / Swiss Franc"
            ),
            Instrument(
                symbolId = "NZDUSD",
                displayName = "NZD/USD",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "NZD",
                quoteAsset = "USD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "New Zealand Dollar / US Dollar"
            ),
            // Minor & Cross Pairs
            Instrument(
                symbolId = "EURGBP",
                displayName = "EUR/GBP",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "EUR",
                quoteAsset = "GBP",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "Euro / British Pound"
            ),
            Instrument(
                symbolId = "EURJPY",
                displayName = "EUR/JPY",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "EUR",
                quoteAsset = "JPY",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 3,
                quantityPrecision = 2,
                tickSize = 0.001,
                minLotSize = 0.01,
                description = "Euro / Japanese Yen"
            ),
            Instrument(
                symbolId = "GBPJPY",
                displayName = "GBP/JPY",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "GBP",
                quoteAsset = "JPY",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 3,
                quantityPrecision = 2,
                tickSize = 0.001,
                minLotSize = 0.01,
                description = "British Pound / Japanese Yen"
            ),
            Instrument(
                symbolId = "AUDNZD",
                displayName = "AUD/NZD",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "AUD",
                quoteAsset = "NZD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "Australian Dollar / New Zealand Dollar"
            ),
            Instrument(
                symbolId = "EURCHF",
                displayName = "EUR/CHF",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "EUR",
                quoteAsset = "CHF",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "Euro / Swiss Franc"
            ),
            // Liquid Exotics
            Instrument(
                symbolId = "USDSGD",
                displayName = "USD/SGD",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "USD",
                quoteAsset = "SGD",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 5,
                quantityPrecision = 2,
                tickSize = 0.00001,
                minLotSize = 0.01,
                description = "US Dollar / Singapore Dollar"
            ),
            Instrument(
                symbolId = "USDCNH",
                displayName = "USD/CNH",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "USD",
                quoteAsset = "CNH",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 4,
                quantityPrecision = 2,
                tickSize = 0.0001,
                minLotSize = 0.01,
                description = "US Dollar / Offshore Chinese Yuan"
            ),
            Instrument(
                symbolId = "USDMXN",
                displayName = "USD/MXN",
                marketCategory = MarketCategory.FOREX,
                baseAsset = "USD",
                quoteAsset = "MXN",
                providerId = providerId,
                providerName = providerName,
                isActive = true,
                pricePrecision = 4,
                quantityPrecision = 2,
                tickSize = 0.0001,
                minLotSize = 0.01,
                description = "US Dollar / Mexican Peso"
            )
        )
    }
}
