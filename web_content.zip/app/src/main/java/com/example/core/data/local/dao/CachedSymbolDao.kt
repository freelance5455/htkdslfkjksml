package com.example.core.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.core.data.local.entity.CachedSymbolEntity
import com.example.core.data.local.entity.MarketSyncStatusEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CachedSymbolDao {

    @Query("SELECT * FROM cached_symbols WHERE marketCategory = :marketCategory ORDER BY displayName ASC")
    fun getSymbolsForMarketFlow(marketCategory: String): Flow<List<CachedSymbolEntity>>

    @Query("SELECT * FROM cached_symbols WHERE marketCategory = :marketCategory ORDER BY displayName ASC")
    suspend fun getSymbolsForMarketSync(marketCategory: String): List<CachedSymbolEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSymbols(symbols: List<CachedSymbolEntity>)

    @Query("DELETE FROM cached_symbols WHERE marketCategory = :marketCategory")
    suspend fun deleteSymbolsForMarket(marketCategory: String)

    @Transaction
    suspend fun replaceSymbolsForMarket(marketCategory: String, symbols: List<CachedSymbolEntity>) {
        deleteSymbolsForMarket(marketCategory)
        insertSymbols(symbols)
    }

    @Query("SELECT * FROM market_sync_status WHERE marketCategory = :marketCategory")
    fun getSyncStatusFlow(marketCategory: String): Flow<MarketSyncStatusEntity?>

    @Query("SELECT * FROM market_sync_status WHERE marketCategory = :marketCategory")
    suspend fun getSyncStatus(marketCategory: String): MarketSyncStatusEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSyncStatus(status: MarketSyncStatusEntity)

    @Query("DELETE FROM cached_symbols")
    suspend fun clearAll()
}
