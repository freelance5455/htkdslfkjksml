package com.example.core

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed interface VoiceListeningState {
    data object Idle : VoiceListeningState
    data class Listening(val partialText: String = "") : VoiceListeningState
    data class Error(val message: String) : VoiceListeningState
}

class VoiceAssistantManager(context: Context) {
    private val appContext = context.applicationContext
    private var speechRecognizer: SpeechRecognizer? = null
    private var onFinalCallback: ((String) -> Unit)? = null

    private val _listeningState = MutableStateFlow<VoiceListeningState>(VoiceListeningState.Idle)
    val listeningState: StateFlow<VoiceListeningState> = _listeningState.asStateFlow()

    val isRecognitionAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(appContext)

    fun startListening(
        languageCode: String,
        onFinalResult: (String) -> Unit
    ) {
        if (!isRecognitionAvailable) {
            _listeningState.value = VoiceListeningState.Error("Speech recognition service unavailable on this device.")
            return
        }

        onFinalCallback = onFinalResult
        stopListeningInternal()

        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(appContext)
            speechRecognizer = recognizer
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _listeningState.value = VoiceListeningState.Listening("")
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    val msg = mapError(error)
                    Log.w("VoiceAssistant", "SpeechRecognizer error=$error ($msg)")
                    _listeningState.value = VoiceListeningState.Error(msg)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val recognized = matches?.firstOrNull()?.trim().orEmpty()
                    _listeningState.value = VoiceListeningState.Idle
                    if (recognized.isNotBlank()) {
                        onFinalCallback?.invoke(recognized)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partial = matches?.firstOrNull()?.trim().orEmpty()
                    if (partial.isNotBlank()) {
                        _listeningState.value = VoiceListeningState.Listening(partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val localeTag = when (FlamiL10n.resolveEffectiveCode(languageCode)) {
                "ru" -> "ru-RU"
                "en" -> "en-US"
                "es" -> "es-ES"
                "de" -> "de-DE"
                "fr" -> "fr-FR"
                "uk" -> "uk-UA"
                "zh" -> "zh-CN"
                else -> Locale.getDefault().toLanguageTag()
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            _listeningState.value = VoiceListeningState.Listening("")
            recognizer.startListening(intent)
        } catch (e: Exception) {
            Log.e("VoiceAssistant", "Failed to start listening", e)
            _listeningState.value = VoiceListeningState.Error(e.localizedMessage ?: "Microphone error")
        }
    }

    fun stopListening() {
        stopListeningInternal()
        _listeningState.value = VoiceListeningState.Idle
    }

    fun clearError() {
        if (_listeningState.value is VoiceListeningState.Error) {
            _listeningState.value = VoiceListeningState.Idle
        }
    }

    private fun stopListeningInternal() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        } finally {
            speechRecognizer = null
        }
    }

    fun destroy() {
        stopListeningInternal()
        onFinalCallback = null
    }

    private fun mapError(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech network error"
        SpeechRecognizer.ERROR_NO_MATCH -> "Could not hear speech clearly, try again"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
        else -> "Speech recognition unavailable ($error)"
    }
}
