package com.example.core.model.indicator

import com.example.core.model.chart.IndicatorDataPoint
import java.util.UUID

/**
 * Indicator Categories for the comprehensive IQTrade Pro Indicator Library.
 */
enum class IndicatorCategory(val displayName: String) {
    TREND("Trend"),
    MOVING_AVERAGE("Moving Average"),
    MOMENTUM("Momentum"),
    OSCILLATOR("Oscillator"),
    VOLATILITY("Volatility"),
    VOLUME("Volume"),
    CHANNEL("Channel"),
    SUPPORT_RESISTANCE("Support & Resistance"),
    BILL_WILLIAMS("Bill Williams"),
    STATISTICAL("Statistical")
}

/**
 * Indicator Directional Bias.
 */
enum class IndicatorDirection {
    BULLISH,
    BEARISH,
    NEUTRAL
}

/**
 * Data validity state for indicator calculations.
 */
enum class DataValidityState {
    VALID,
    INSUFFICIENT_DATA,
    ERROR
}

/**
 * Input price source for calculations.
 */
enum class IndicatorSource(val label: String) {
    CLOSE("Close"),
    OPEN("Open"),
    HIGH("High"),
    LOW("Low"),
    HL2("HL/2 (Median)"),
    HLC3("HLC/3 (Typical)"),
    OHLC4("OHLC/4")
}

/**
 * Extensible definition for every technical indicator in the library.
 */
data class IndicatorDefinition(
    val code: String,
    val name: String,
    val category: IndicatorCategory,
    val description: String,
    val defaultParameters: IndicatorParameters,
    val isOverlayOnMainChart: Boolean = true,
    val authorOrFormulaType: String = "Standard Technical Analysis"
)

/**
 * Full parameter specification for configurable indicators.
 */
data class IndicatorParameters(
    val period: Int = 14,
    val secondaryPeriod: Int = 26,
    val signalPeriod: Int = 9,
    val stdDev: Double = 2.0,
    val source: IndicatorSource = IndicatorSource.CLOSE,
    val overboughtLevel: Double = 70.0,
    val oversoldLevel: Double = 30.0,
    val multiplier: Double = 3.0,
    val step: Double = 0.02,
    val maxStep: Double = 0.20,
    val customParams: Map<String, Double> = emptyMap()
) {
    /**
     * Parameter validation ensuring positive periods and mathematically sound configurations.
     */
    fun validate(): List<String> {
        val errors = mutableListOf<String>()
        if (period <= 0) errors.add("Period must be greater than 0")
        if (secondaryPeriod <= 0) errors.add("Secondary period must be greater than 0")
        if (signalPeriod <= 0) errors.add("Signal period must be greater than 0")
        if (stdDev <= 0.0) errors.add("Standard deviation multiplier must be greater than 0")
        if (overboughtLevel <= oversoldLevel) errors.add("Overbought level must exceed oversold level")
        if (step <= 0.0 || maxStep < step) errors.add("Step must be positive and not exceed max step")
        return errors
    }

    val isValid: Boolean get() = validate().isEmpty()
}

/**
 * Calculated result from the indicator engine.
 */
data class IndicatorResult(
    val indicatorCode: String,
    val timestamp: Long,
    val primaryValue: Double,
    val secondaryValue: Double? = null,
    val tertiaryValue: Double? = null,
    val seriesPoints: List<IndicatorDataPoint> = emptyList(),
    val validity: DataValidityState = DataValidityState.VALID,
    val metadata: Map<String, String> = emptyMap()
)

/**
 * General directional score for any indicator.
 */
data class IndicatorScore(
    val indicatorCode: String,
    val indicatorName: String,
    val value: Double,
    val direction: IndicatorDirection,
    val score: Int, // 0..100
    val interpretation: String,
    val timestamp: Long,
    val timeframe: String,
    val validity: DataValidityState
)

/**
 * Core Indicator Score model for the 8 Core Analysis Indicators.
 */
data class CoreIndicatorScore(
    val coreIndex: Int, // 1 through 8
    val indicatorCode: String,
    val name: String,
    val calculatedValue: Double,
    val direction: IndicatorDirection,
    val scorePct: Int, // 0..100
    val interpretation: String,
    val timestamp: Long,
    val timeframe: String,
    val validityState: DataValidityState = DataValidityState.VALID
) {
    val isConfirmed: Boolean get() = scorePct >= 80
}

/**
 * Multi-Timeframe (MTF) analysis score for an individual timeframe.
 */
data class TimeframeAnalysisScore(
    val timeframe: String, // e.g. "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d"
    val scorePct: Int,     // 0..100
    val direction: IndicatorDirection,
    val summaryText: String,
    val timestamp: Long
)

/**
 * Visual Chart Indicator instance configuration (isolated from Analysis Engine).
 */
data class IndicatorConfiguration(
    val instanceId: String = UUID.randomUUID().toString(),
    val indicatorCode: String,
    val parameters: IndicatorParameters,
    val colorHex: String = "#00E5FF",
    val lineWidth: Int = 2,
    val isVisible: Boolean = true,
    val isEnabled: Boolean = true
)

/**
 * Indicator favorite marked by user for quick access.
 */
data class IndicatorFavorite(
    val indicatorCode: String,
    val addedTimestamp: Long = System.currentTimeMillis()
)

/**
 * Complete snapshot of the independent Analysis Score system.
 * Contains:
 * A) 8 Core Indicator Scores
 * B) Multi-Timeframe Analysis Scores (5M, 15M, 30M, 1H, 2H, 4H, 6H, 8H, 12H, 1D)
 * C) News/Sentiment Score
 */
data class AnalysisScoreSnapshot(
    val symbol: String,
    val currentPrice: Double,
    val timestamp: Long,
    val coreScores: List<CoreIndicatorScore>,
    val timeframeScores: List<TimeframeAnalysisScore>,
    val newsSentimentScore: Int, // 0..100
    val newsSentimentDirection: IndicatorDirection,
    val newsHeadlineSample: String? = null,
    val overallCompositeScore: Int = 0
) {
    val confirmedCoreCount: Int get() = coreScores.count { it.scorePct >= 80 }
    val isConfirmationConditionMet: Boolean get() = confirmedCoreCount >= 5
    val confirmationRatioText: String get() = "$confirmedCoreCount / 8"
}
