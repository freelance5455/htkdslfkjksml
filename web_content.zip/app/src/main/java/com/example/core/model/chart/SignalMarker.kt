package com.example.core.model.chart

import org.json.JSONObject

enum class SignalType(val label: String) {
    BULLISH("Bullish Signal"),
    BEARISH("Bearish Signal"),
    NEUTRAL("Neutral / Sideways")
}

data class SignalMarker(
    val id: String,
    val symbol: String,
    val type: SignalType,
    val timestamp: Long, // seconds
    val price: Double,
    val score: Int, // 0 - 100
    val confidencePct: Int, // 0 - 100
    val timeframe: String
) {
    /**
     * Converts to Lightweight Charts marker specification.
     * Note: Visual styling explicitly shows "SIGNAL (score/confidence)"
     * to avoid confusing this with an executed order!
     */
    fun toChartMarkerJson(): JSONObject {
        val obj = JSONObject()
        obj.put("time", timestamp)
        val color = when (type) {
            SignalType.BULLISH -> "#00E5FF"
            SignalType.BEARISH -> "#E040FB"
            SignalType.NEUTRAL -> "#94A3B8"
        }
        val shape = when (type) {
            SignalType.BULLISH -> "arrowUp"
            SignalType.BEARISH -> "arrowDown"
            SignalType.NEUTRAL -> "circle"
        }
        val position = when (type) {
            SignalType.BULLISH -> "belowBar"
            SignalType.BEARISH -> "aboveBar"
            SignalType.NEUTRAL -> "aboveBar"
        }
        obj.put("position", position)
        obj.put("color", color)
        obj.put("shape", shape)
        obj.put("text", "SIG: ${type.name} ($confidencePct%)")
        return obj
    }
}
