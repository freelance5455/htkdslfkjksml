package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.SecurityPreferences

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val prefs = SecurityPreferences.getInstance(context)
            prefs.logInterception(
                reason = "Dispositivo encendido (Sistema iniciado)",
                targetApp = "system.boot"
            )
            // Note: AccessibilityService is automatically started by Android system
            // if enabled by the user in Accessibility settings.
        }
    }
}
