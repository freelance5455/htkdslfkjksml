package com.example.receiver

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.R
import com.example.data.SecurityPreferences

class AntiTheftAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(
            context,
            "TecnoGuard: Protección de Administrador activada",
            Toast.LENGTH_SHORT
        ).show()
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        // Record interception attempt
        SecurityPreferences.getInstance(context).logInterception(
            reason = "Intento de desactivar Administrador de Dispositivo (Anti-desinstalación)",
            targetApp = "com.android.settings"
        )
        return context.getString(R.string.admin_warning_disable)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Toast.makeText(
            context,
            "TecnoGuard: Administrador desactivado",
            Toast.LENGTH_LONG
        ).show()
    }
}
