package com.example.receiver

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.alarm.AlarmScheduler
import com.example.data.database.AppDatabase
import com.example.service.AlarmRingingService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        val label = intent.getStringExtra(EXTRA_ALARM_LABEL) ?: "Alarm"
        val vibrate = intent.getBooleanExtra(EXTRA_ALARM_VIBRATE, true)
        val tone = intent.getStringExtra(EXTRA_ALARM_TONE) ?: "Digital Pulse"
        val customAudioPath = intent.getStringExtra(EXTRA_CUSTOM_AUDIO_PATH)
        val snoozeMinutes = intent.getIntExtra(EXTRA_SNOOZE_MINUTES, 10)

        when (action) {
            ACTION_TRIGGER_ALARM -> {
                // 1. Launch Foreground Service to ensure continuous playback in background
                val serviceIntent = Intent(context, AlarmRingingService::class.java).apply {
                    setAction(AlarmRingingService.ACTION_START_ALARM_SERVICE)
                    putExtra(EXTRA_ALARM_ID, alarmId)
                    putExtra(EXTRA_ALARM_LABEL, label)
                    putExtra(EXTRA_ALARM_VIBRATE, vibrate)
                    putExtra(EXTRA_ALARM_TONE, tone)
                    putExtra(EXTRA_CUSTOM_AUDIO_PATH, customAudioPath)
                    putExtra(EXTRA_SNOOZE_MINUTES, snoozeMinutes)
                }
                try {
                    ContextCompat.startForegroundService(context, serviceIntent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                // 2. Notify active state for app if UI is currently open
                activeAlarmFlow.value = ActiveAlarmState(
                    alarmId = alarmId,
                    label = label,
                    snoozeMinutes = snoozeMinutes,
                    isRinging = true
                )
            }

            ACTION_DISMISS_ALARM -> {
                // Stop ringing service
                val stopIntent = Intent(context, AlarmRingingService::class.java).apply {
                    setAction(AlarmRingingService.ACTION_STOP_ALARM_SERVICE)
                }
                context.startService(stopIntent)

                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(AlarmRingingService.NOTIFICATION_ID)
                if (alarmId > 0) {
                    notificationManager.cancel(NOTIFICATION_ID_BASE + alarmId.toInt())
                }

                activeAlarmFlow.value = null

                // If non-repeating alarm, mark disabled
                if (alarmId > 0) {
                    CoroutineScope(Dispatchers.IO).launch {
                        val db = AppDatabase.getInstance(context)
                        val alarm = db.alarmDao().getAlarmById(alarmId)
                        if (alarm != null && !alarm.isRepeating) {
                            db.alarmDao().updateAlarm(alarm.copy(isEnabled = false, isSnoozed = false))
                        }
                    }
                }
            }

            ACTION_SNOOZE_ALARM -> {
                // Stop ringing service
                val stopIntent = Intent(context, AlarmRingingService::class.java).apply {
                    setAction(AlarmRingingService.ACTION_STOP_ALARM_SERVICE)
                }
                context.startService(stopIntent)

                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(AlarmRingingService.NOTIFICATION_ID)
                if (alarmId > 0) {
                    notificationManager.cancel(NOTIFICATION_ID_BASE + alarmId.toInt())
                }

                activeAlarmFlow.value = null

                if (alarmId > 0) {
                    CoroutineScope(Dispatchers.IO).launch {
                        val db = AppDatabase.getInstance(context)
                        val alarm = db.alarmDao().getAlarmById(alarmId)
                        if (alarm != null) {
                            val snoozeMillis = System.currentTimeMillis() + (snoozeMinutes * 60 * 1000L)
                            val updated = alarm.copy(isSnoozed = true, snoozeTimeMillis = snoozeMillis)
                            db.alarmDao().updateAlarm(updated)
                            AlarmScheduler(context).schedule(updated)
                        }
                    }
                }
            }
        }
    }

    data class ActiveAlarmState(
        val alarmId: Long,
        val label: String,
        val snoozeMinutes: Int,
        val isRinging: Boolean
    )

    companion object {
        const val CHANNEL_ID = "chrono_alarms_channel"
        const val NOTIFICATION_ID_BASE = 5000

        const val ACTION_TRIGGER_ALARM = "com.example.ACTION_TRIGGER_ALARM"
        const val ACTION_DISMISS_ALARM = "com.example.ACTION_DISMISS_ALARM"
        const val ACTION_SNOOZE_ALARM = "com.example.ACTION_SNOOZE_ALARM"

        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_ALARM_VIBRATE = "extra_alarm_vibrate"
        const val EXTRA_ALARM_TONE = "extra_alarm_tone"
        const val EXTRA_CUSTOM_AUDIO_PATH = "extra_custom_audio_path"
        const val EXTRA_SNOOZE_MINUTES = "extra_snooze_minutes"

        const val EXTRA_RINGING_ALARM_ID = "extra_ringing_alarm_id"
        const val EXTRA_RINGING_LABEL = "extra_ringing_label"

        val activeAlarmFlow = kotlinx.coroutines.flow.MutableStateFlow<ActiveAlarmState?>(null)
    }
}
