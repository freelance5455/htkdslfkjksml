package com.example.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.dp
import com.example.model.Mascot
import com.example.model.MascotSkin
import com.example.model.Particle
import com.example.model.PipeObstacle
import kotlin.math.sin

@Composable
fun FlappyDroidCanvas(
    mascot: Mascot,
    pipes: List<PipeObstacle>,
    particles: List<Particle>,
    skin: MascotSkin,
    groundOffset: Float,
    cloudOffset: Float,
    groundHeightDp: Float = 110f,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val density = this.density
        val canvasWidth = size.width
        val canvasHeight = size.height
        val groundHeightPx = groundHeightDp * density
        val skyHeightPx = canvasHeight - groundHeightPx

        // 1. Sky Gradient Background
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF29B6F6),
                    Color(0xFF81D4FA),
                    Color(0xFFE1F5FE)
                ),
                startY = 0f,
                endY = skyHeightPx
            ),
            size = Size(canvasWidth, skyHeightPx)
        )

        // 2. Parallax Clouds & Distant Skyline
        drawDistantSkyline(skyHeightPx, canvasWidth, cloudOffset * 0.3f)
        drawClouds(canvasWidth, skyHeightPx, cloudOffset)

        // 3. Pipes / Obstacles
        val pipeWidthPx = 72.dp.toPx()
        val pipeRimHeightPx = 28.dp.toPx()
        val pipeRimOverhangPx = 6.dp.toPx()

        for (pipe in pipes) {
            val pipeXPx = pipe.x * density
            val topPipeHeightPx = pipe.topPipeHeight * density
            val bottomPipeYPx = pipe.bottomPipeY * density
            val bottomPipeHeightPx = (skyHeightPx - bottomPipeYPx).coerceAtLeast(0f)

            // Skip drawing if offscreen
            if (pipeXPx + pipeWidthPx < -20f || pipeXPx > canvasWidth + 20f) continue

            // Top Pipe Body
            val topPipeRect = Rect(
                offset = Offset(pipeXPx, 0f),
                size = Size(pipeWidthPx, (topPipeHeightPx - pipeRimHeightPx).coerceAtLeast(0f))
            )
            drawPipeBody(topPipeRect)

            // Top Pipe Rim / Cap
            val topRimRect = Rect(
                offset = Offset(pipeXPx - pipeRimOverhangPx, topPipeHeightPx - pipeRimHeightPx),
                size = Size(pipeWidthPx + (pipeRimOverhangPx * 2), pipeRimHeightPx)
            )
            drawPipeRim(topRimRect)

            // Bottom Pipe Body
            val bottomPipeBodyY = bottomPipeYPx + pipeRimHeightPx
            val bottomPipeRect = Rect(
                offset = Offset(pipeXPx, bottomPipeBodyY),
                size = Size(pipeWidthPx, (bottomPipeHeightPx - pipeRimHeightPx).coerceAtLeast(0f))
            )
            drawPipeBody(bottomPipeRect)

            // Bottom Pipe Rim / Cap
            val bottomRimRect = Rect(
                offset = Offset(pipeXPx - pipeRimOverhangPx, bottomPipeYPx),
                size = Size(pipeWidthPx + (pipeRimOverhangPx * 2), pipeRimHeightPx)
            )
            drawPipeRim(bottomRimRect)
        }

        // 4. Particles (Jetpack / Sparks)
        for (particle in particles) {
            val px = particle.x * density
            val py = particle.y * density
            drawCircle(
                color = particle.color.copy(alpha = particle.alpha),
                radius = particle.size * density,
                center = Offset(px, py)
            )
        }

        // 5. Android Mascot
        val mascotXPx = 100.dp.toPx()
        val mascotYPx = mascot.y * density
        val mascotSizeDp = 48.dp
        val mascotSizePx = mascotSizeDp.toPx()

        rotate(
            degrees = mascot.rotationAngle,
            pivot = Offset(mascotXPx, mascotYPx)
        ) {
            translate(
                left = mascotXPx - (mascotSizePx / 2f),
                top = mascotYPx - (mascotSizePx / 2f)
            ) {
                drawAndroidMascot(
                    sizePx = mascotSizePx,
                    skin = skin,
                    flapProgress = mascot.flapProgress
                )
            }
        }

        // 6. Ground & Grass Strip
        drawGround(
            canvasWidth = canvasWidth,
            canvasHeight = canvasHeight,
            skyHeightPx = skyHeightPx,
            groundHeightPx = groundHeightPx,
            groundOffset = groundOffset
        )
    }
}

private fun DrawScope.drawPipeBody(rect: Rect) {
    if (rect.height <= 0f) return

    val pipeBrush = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFF2E7D32),
            Color(0xFF4CAF50),
            Color(0xFF81C784),
            Color(0xFF4CAF50),
            Color(0xFF1B5E20)
        ),
        startX = rect.left,
        endX = rect.right
    )

    drawRect(brush = pipeBrush, topLeft = rect.topLeft, size = rect.size)

    // Highlight stripe
    drawRect(
        color = Color.White.copy(alpha = 0.22f),
        topLeft = Offset(rect.left + rect.width * 0.28f, rect.top),
        size = Size(rect.width * 0.12f, rect.height)
    )

    // Dark outline border
    drawRect(
        color = Color(0xFF0E3D12),
        topLeft = rect.topLeft,
        size = rect.size,
        style = Stroke(width = 2.dp.toPx())
    )
}

private fun DrawScope.drawPipeRim(rect: Rect) {
    val rimBrush = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFF1B5E20),
            Color(0xFF43A047),
            Color(0xFF81C784),
            Color(0xFF388E3C),
            Color(0xFF1B5E20)
        ),
        startX = rect.left,
        endX = rect.right
    )

    val cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
    drawRoundRect(
        brush = rimBrush,
        topLeft = rect.topLeft,
        size = rect.size,
        cornerRadius = cornerRadius
    )

    // Rim highlight
    drawRoundRect(
        color = Color.White.copy(alpha = 0.25f),
        topLeft = Offset(rect.left + rect.width * 0.25f, rect.top + 2.dp.toPx()),
        size = Size(rect.width * 0.12f, rect.height - 4.dp.toPx()),
        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
    )

    // Outline
    drawRoundRect(
        color = Color(0xFF0A2B0D),
        topLeft = rect.topLeft,
        size = rect.size,
        cornerRadius = cornerRadius,
        style = Stroke(width = 2.dp.toPx())
    )
}

private fun DrawScope.drawAndroidMascot(
    sizePx: Float,
    skin: MascotSkin,
    flapProgress: Float
) {
    val w = sizePx
    val h = sizePx

    // Mascot Head & Body dimensions
    val bodyWidth = w * 0.62f
    val bodyHeight = h * 0.38f
    val bodyLeft = (w - bodyWidth) / 2f
    val bodyTop = h * 0.44f

    val headWidth = bodyWidth
    val headHeight = h * 0.28f
    val headLeft = bodyLeft
    val headTop = bodyTop - headHeight - (h * 0.04f)

    // 1. Rocket Thruster / Backpack on the left
    val boosterWidth = w * 0.18f
    val boosterHeight = bodyHeight * 0.8f
    val boosterLeft = bodyLeft - boosterWidth * 0.65f
    val boosterTop = bodyTop + (bodyHeight - boosterHeight) / 2f

    drawRoundRect(
        color = Color(0xFF455A64),
        topLeft = Offset(boosterLeft, boosterTop),
        size = Size(boosterWidth, boosterHeight),
        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
    )

    // Thruster flame animated by flap progress
    val flameLength = (w * 0.28f) * (0.6f + (flapProgress * 0.8f))
    val flamePath = Path().apply {
        moveTo(boosterLeft, boosterTop + boosterHeight * 0.2f)
        lineTo(boosterLeft - flameLength, boosterTop + boosterHeight * 0.5f)
        lineTo(boosterLeft, boosterTop + boosterHeight * 0.8f)
        close()
    }
    drawPath(
        path = flamePath,
        color = if (flapProgress > 0.3f) Color(0xFFFF5722) else Color(0xFFFFB300)
    )

    // Inner core flame
    val innerFlamePath = Path().apply {
        moveTo(boosterLeft, boosterTop + boosterHeight * 0.35f)
        lineTo(boosterLeft - flameLength * 0.5f, boosterTop + boosterHeight * 0.5f)
        lineTo(boosterLeft, boosterTop + boosterHeight * 0.65f)
        close()
    }
    drawPath(path = innerFlamePath, color = Color(0xFFFFEB3B))

    // 2. Antennae (2 angled lines with rounded caps)
    val antennaStroke = 2.8.dp.toPx()
    val antennaLength = h * 0.14f
    val antennaAngleOffset = w * 0.09f

    // Left antenna
    drawLine(
        color = skin.primaryColor,
        start = Offset(headLeft + headWidth * 0.28f, headTop + 2.dp.toPx()),
        end = Offset(headLeft + headWidth * 0.28f - antennaAngleOffset, headTop - antennaLength),
        strokeWidth = antennaStroke,
        cap = StrokeCap.Round
    )
    // Right antenna
    drawLine(
        color = skin.primaryColor,
        start = Offset(headLeft + headWidth * 0.72f, headTop + 2.dp.toPx()),
        end = Offset(headLeft + headWidth * 0.72f + antennaAngleOffset, headTop - antennaLength),
        strokeWidth = antennaStroke,
        cap = StrokeCap.Round
    )

    // 3. Android Mascot Head (Semicircle Dome)
    val headPath = Path().apply {
        val rect = Rect(headLeft, headTop, headLeft + headWidth, headTop + (headHeight * 2f))
        arcTo(rect, 180f, 180f, false)
        close()
    }
    drawPath(path = headPath, color = skin.primaryColor)

    // 4. Eyes
    val eyeRadius = w * 0.042f
    val eyeY = headTop + headHeight * 0.62f
    val eyeLeftX = headLeft + headWidth * 0.32f
    val eyeRightX = headLeft + headWidth * 0.68f

    drawCircle(color = skin.eyeColor, radius = eyeRadius, center = Offset(eyeLeftX, eyeY))
    drawCircle(color = skin.eyeColor, radius = eyeRadius, center = Offset(eyeRightX, eyeY))

    // Pupil looking forward-up
    val pupilRadius = eyeRadius * 0.45f
    drawCircle(color = Color(0xFF1E2633), radius = pupilRadius, center = Offset(eyeLeftX + 1.dp.toPx(), eyeY - 0.5.dp.toPx()))
    drawCircle(color = Color(0xFF1E2633), radius = pupilRadius, center = Offset(eyeRightX + 1.dp.toPx(), eyeY - 0.5.dp.toPx()))

    // 5. Torso / Body (Rounded bottom rectangle)
    val bodyPath = Path().apply {
        addRoundRect(
            RoundRect(
                rect = Rect(bodyLeft, bodyTop, bodyLeft + bodyWidth, bodyTop + bodyHeight),
                bottomLeft = CornerRadius(bodyWidth * 0.28f, bodyWidth * 0.28f),
                bottomRight = CornerRadius(bodyWidth * 0.28f, bodyWidth * 0.28f),
                topLeft = CornerRadius(2.dp.toPx(), 2.dp.toPx()),
                topRight = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        )
    }
    drawPath(path = bodyPath, color = skin.primaryColor)

    // 6. Wings / Flapping Arm
    val armWidth = w * 0.11f
    val armHeight = bodyHeight * 0.85f
    val flapAngle = sin(flapProgress * Math.PI.toFloat()) * 35f // Flaps up and down

    // Left/back arm
    rotate(
        degrees = -flapAngle,
        pivot = Offset(bodyLeft + bodyWidth * 0.45f, bodyTop + bodyHeight * 0.3f)
    ) {
        drawRoundRect(
            color = skin.secondaryColor,
            topLeft = Offset(bodyLeft + bodyWidth * 0.42f, bodyTop + bodyHeight * 0.2f),
            size = Size(armWidth, armHeight),
            cornerRadius = CornerRadius(armWidth / 2f, armWidth / 2f)
        )
    }

    // Cute goggles or visor accent
    drawLine(
        color = skin.accentColor.copy(alpha = 0.5f),
        start = Offset(bodyLeft + 4.dp.toPx(), bodyTop + 4.dp.toPx()),
        end = Offset(bodyLeft + bodyWidth - 4.dp.toPx(), bodyTop + 4.dp.toPx()),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
    )

    // Mascot Legs / Bottom pods
    val legWidth = w * 0.10f
    val legHeight = h * 0.14f
    val legY = bodyTop + bodyHeight - 2.dp.toPx()
    val legRadius = CornerRadius(legWidth / 2f, legWidth / 2f)

    drawRoundRect(
        color = skin.primaryColor,
        topLeft = Offset(bodyLeft + bodyWidth * 0.22f, legY),
        size = Size(legWidth, legHeight),
        cornerRadius = legRadius
    )

    drawRoundRect(
        color = skin.primaryColor,
        topLeft = Offset(bodyLeft + bodyWidth * 0.68f, legY),
        size = Size(legWidth, legHeight),
        cornerRadius = legRadius
    )
}

private fun DrawScope.drawClouds(canvasWidth: Float, skyHeightPx: Float, offset: Float) {
    val cloudColor = Color.White.copy(alpha = 0.85f)
    val shadowColor = Color(0xFFCFD8DC).copy(alpha = 0.45f)

    // Cloud 1
    val c1X = ((offset * 0.5f) % (canvasWidth + 240f)) - 120f
    drawSingleCloud(c1X, skyHeightPx * 0.18f, 130.dp.toPx(), cloudColor, shadowColor)

    // Cloud 2
    val c2X = (((offset * 0.7f) + 260f) % (canvasWidth + 300f)) - 150f
    drawSingleCloud(c2X, skyHeightPx * 0.38f, 160.dp.toPx(), cloudColor, shadowColor)

    // Cloud 3
    val c3X = (((offset * 0.4f) + 520f) % (canvasWidth + 220f)) - 100f
    drawSingleCloud(c3X, skyHeightPx * 0.12f, 110.dp.toPx(), cloudColor, shadowColor)
}

private fun DrawScope.drawSingleCloud(
    x: Float,
    y: Float,
    width: Float,
    color: Color,
    shadowColor: Color
) {
    val height = width * 0.42f
    // Base pill
    drawRoundRect(
        color = shadowColor,
        topLeft = Offset(x, y + 4.dp.toPx()),
        size = Size(width, height),
        cornerRadius = CornerRadius(height / 2f, height / 2f)
    )
    drawRoundRect(
        color = color,
        topLeft = Offset(x, y),
        size = Size(width, height),
        cornerRadius = CornerRadius(height / 2f, height / 2f)
    )

    // Puffy top bubbles
    drawCircle(
        color = color,
        radius = height * 0.58f,
        center = Offset(x + width * 0.36f, y + height * 0.3f)
    )
    drawCircle(
        color = color,
        radius = height * 0.72f,
        center = Offset(x + width * 0.62f, y + height * 0.2f)
    )
}

private fun DrawScope.drawDistantSkyline(skyHeightPx: Float, canvasWidth: Float, offset: Float) {
    val skylineY = skyHeightPx * 0.72f
    val baseColor = Color(0xFFB0BEC5).copy(alpha = 0.35f)

    val buildingWidth = 55.dp.toPx()
    val totalSpan = canvasWidth + buildingWidth * 2
    val startX = -((offset) % buildingWidth)

    var currentX = startX - buildingWidth
    var index = 0
    while (currentX < canvasWidth + buildingWidth) {
        val bHeight = (40 + ((index * 37) % 65)).dp.toPx()
        drawRect(
            color = baseColor,
            topLeft = Offset(currentX, skylineY - bHeight),
            size = Size(buildingWidth - 6.dp.toPx(), bHeight + (skyHeightPx - skylineY))
        )
        currentX += buildingWidth
        index++
    }
}

private fun DrawScope.drawGround(
    canvasWidth: Float,
    canvasHeight: Float,
    skyHeightPx: Float,
    groundHeightPx: Float,
    groundOffset: Float
) {
    val grassHeight = 16.dp.toPx()

    // 1. Top lush grass strip
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFF81C784), Color(0xFF4CAF50)),
            startY = skyHeightPx,
            endY = skyHeightPx + grassHeight
        ),
        topLeft = Offset(0f, skyHeightPx),
        size = Size(canvasWidth, grassHeight)
    )

    // Darker grass trim
    drawLine(
        color = Color(0xFF2E7D32),
        start = Offset(0f, skyHeightPx + grassHeight),
        end = Offset(canvasWidth, skyHeightPx + grassHeight),
        strokeWidth = 2.dp.toPx()
    )

    // Scrolling grass slash marks
    val slashSpacing = 24.dp.toPx()
    val normalizedOffset = groundOffset % slashSpacing
    var slashX = -normalizedOffset
    while (slashX < canvasWidth + slashSpacing) {
        drawLine(
            color = Color(0xFF388E3C),
            start = Offset(slashX, skyHeightPx),
            end = Offset(slashX + 12.dp.toPx(), skyHeightPx + grassHeight),
            strokeWidth = 3.dp.toPx()
        )
        slashX += slashSpacing
    }

    // 2. Earth / Soil substrate
    val dirtTop = skyHeightPx + grassHeight
    val dirtHeight = canvasHeight - dirtTop
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFFD7CCC8),
                Color(0xFFBCAAA4),
                Color(0xFF8D6E63)
            ),
            startY = dirtTop,
            endY = canvasHeight
        ),
        topLeft = Offset(0f, dirtTop),
        size = Size(canvasWidth, dirtHeight)
    )

    // Ground texture dots
    val dotSpacing = 36.dp.toPx()
    val dotOffset = groundOffset % dotSpacing
    var dotX = -dotOffset
    while (dotX < canvasWidth + dotSpacing) {
        drawCircle(
            color = Color(0xFF6D4C41).copy(alpha = 0.4f),
            radius = 2.5.dp.toPx(),
            center = Offset(dotX, dirtTop + 20.dp.toPx())
        )
        drawCircle(
            color = Color(0xFF6D4C41).copy(alpha = 0.3f),
            radius = 3.5.dp.toPx(),
            center = Offset(dotX + 16.dp.toPx(), dirtTop + 45.dp.toPx())
        )
        dotX += dotSpacing
    }
}
