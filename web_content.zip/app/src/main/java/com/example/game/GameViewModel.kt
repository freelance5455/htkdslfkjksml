package com.example.game

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.ui.graphics.Color
import com.example.data.GamePreferences
import com.example.model.Difficulty
import com.example.model.GameStatus
import com.example.model.GameStats
import com.example.model.Mascot
import com.example.model.MascotSkin
import com.example.model.Particle
import com.example.model.PipeObstacle
import com.example.model.UpdateChannel
import com.example.model.UpdateState
import com.example.sound.SoundManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.random.Random

data class GameUiState(
    val status: GameStatus = GameStatus.READY,
    val score: Int = 0,
    val highScore: Int = 0,
    val isNewHighScore: Boolean = false,
    val mascot: Mascot = Mascot(y = 280f),
    val pipes: List<PipeObstacle> = emptyList(),
    val particles: List<Particle> = emptyList(),
    val skin: MascotSkin = MascotSkin.CLASSIC_GREEN,
    val difficulty: Difficulty = Difficulty.NORMAL,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val groundOffset: Float = 0f,
    val cloudOffset: Float = 0f,
    val stats: GameStats = GameStats(),
    val isSettingsOpen: Boolean = false,
    val showResetDialog: Boolean = false,
    val updateChannel: UpdateChannel = UpdateChannel.STABLE,
    val updateState: UpdateState = UpdateState.Idle(lastCheckedTime = null),
    val currentAppVersion: String = "1.0.0 (Build 101)"
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val preferences = GamePreferences(application)
    val soundManager = SoundManager(application)

    private val _uiState = MutableStateFlow(
        GameUiState(
            highScore = preferences.getStats().highScore,
            stats = preferences.getStats(),
            skin = preferences.mascotSkin,
            difficulty = preferences.difficulty,
            soundEnabled = preferences.isSoundEnabled,
            hapticsEnabled = preferences.isHapticsEnabled,
            updateChannel = preferences.updateChannel,
            updateState = UpdateState.Idle(preferences.lastUpdateCheck)
        )
    )
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var pipeIdCounter = 0L
    private var lastPipeX = 0f
    private var currentFlapsThisRound = 0
    private var updateJob: Job? = null

    init {
        soundManager.isSoundEnabled = preferences.isSoundEnabled
        soundManager.isHapticsEnabled = preferences.isHapticsEnabled
    }

    fun openSettings() {
        soundManager.playClick()
        if (_uiState.value.status == GameStatus.PLAYING) {
            _uiState.update { it.copy(status = GameStatus.PAUSED, isSettingsOpen = true) }
        } else {
            _uiState.update { it.copy(isSettingsOpen = true) }
        }
    }

    fun closeSettings() {
        soundManager.playClick()
        _uiState.update { it.copy(isSettingsOpen = false) }
    }

    fun pauseGame() {
        if (_uiState.value.status == GameStatus.PLAYING) {
            soundManager.playClick()
            _uiState.update { it.copy(status = GameStatus.PAUSED) }
        }
    }

    fun resumeGame() {
        if (_uiState.value.status == GameStatus.PAUSED) {
            soundManager.playClick()
            _uiState.update { it.copy(status = GameStatus.PLAYING) }
        }
    }

    fun readyGame() {
        soundManager.playClick()
        _uiState.update {
            it.copy(
                status = GameStatus.READY,
                score = 0,
                isNewHighScore = false,
                mascot = Mascot(y = 280f, velocityY = 0f, rotationAngle = 0f),
                pipes = emptyList(),
                particles = emptyList()
            )
        }
    }

    fun startGame() {
        preferences.incrementGamePlayed()
        currentFlapsThisRound = 0
        pipeIdCounter = 0L
        lastPipeX = 420f

        val initialPipes = createInitialPipes(lastPipeX)

        _uiState.update {
            it.copy(
                status = GameStatus.PLAYING,
                score = 0,
                isNewHighScore = false,
                mascot = Mascot(y = 280f, velocityY = -420f, rotationAngle = -22f, flapProgress = 1f),
                pipes = initialPipes,
                particles = emptyList(),
                stats = preferences.getStats()
            )
        }
        soundManager.playFlap()
    }

    fun onScreenTap() {
        when (_uiState.value.status) {
            GameStatus.READY -> {
                startGame()
            }
            GameStatus.PLAYING -> {
                flap()
            }
            GameStatus.GAME_OVER -> {
                readyGame()
            }
            GameStatus.PAUSED -> {
                // Ignore tap during pause
            }
        }
    }

    fun flap() {
        if (_uiState.value.status != GameStatus.PLAYING) return

        currentFlapsThisRound++
        val jumpImpulse = -480f * _uiState.value.difficulty.speedMultiplier

        val currentMascot = _uiState.value.mascot
        val mascotY = currentMascot.y

        // Generate thruster particles
        val newParticles = mutableListOf<Particle>()
        val skin = _uiState.value.skin
        for (i in 0..3) {
            newParticles.add(
                Particle(
                    x = 88f - Random.nextFloat() * 12f,
                    y = mascotY + 12f + (Random.nextFloat() * 16f - 8f),
                    vx = -(Random.nextFloat() * 120f + 60f),
                    vy = (Random.nextFloat() * 80f - 40f),
                    alpha = 0.9f,
                    size = Random.nextFloat() * 3.5f + 2f,
                    color = if (Random.nextBoolean()) Color(0xFFFF9800) else skin.accentColor
                )
            )
        }

        _uiState.update { state ->
            state.copy(
                mascot = currentMascot.copy(
                    velocityY = jumpImpulse,
                    rotationAngle = -26f,
                    flapProgress = 1.0f
                ),
                particles = (state.particles + newParticles).takeLast(25)
            )
        }

        soundManager.playFlap()
    }

    fun tick(dt: Float, screenWidthDp: Float, screenHeightDp: Float) {
        val currentState = _uiState.value
        val groundHeightDp = 110f
        val groundLimitY = screenHeightDp - groundHeightDp - 22f

        // Animate idle mascot if ready
        if (currentState.status == GameStatus.READY) {
            val idleY = 280f + kotlin.math.sin(System.currentTimeMillis() / 250.0).toFloat() * 12f
            _uiState.update { state ->
                state.copy(
                    mascot = state.mascot.copy(y = idleY, rotationAngle = 0f, flapProgress = 0.2f),
                    cloudOffset = state.cloudOffset + (25f * dt),
                    groundOffset = state.groundOffset + (80f * dt)
                )
            }
            return
        }

        if (currentState.status != GameStatus.PLAYING) {
            // Still update particles if game over or paused
            if (currentState.particles.isNotEmpty()) {
                val updatedParticles = currentState.particles.mapNotNull { p ->
                    val newAlpha = p.alpha - (dt * 1.5f)
                    if (newAlpha <= 0f) null
                    else p.copy(
                        x = p.x + p.vx * dt,
                        y = p.y + p.vy * dt,
                        alpha = newAlpha
                    )
                }
                _uiState.update { it.copy(particles = updatedParticles) }
            }
            return
        }

        val diff = currentState.difficulty
        val scrollSpeed = 160f * diff.speedMultiplier
        val gravity = diff.gravity

        // 1. Mascot physics update
        var newVy = currentState.mascot.velocityY + (gravity * dt)
        var newY = currentState.mascot.y + (newVy * dt)

        // Rotation tilt
        val targetRotation = if (newVy < 0) {
            -25f
        } else {
            ((-25f) + (newVy / 600f) * 95f).coerceAtMost(75f)
        }
        val currentRot = currentState.mascot.rotationAngle
        val newRot = currentRot + (targetRotation - currentRot) * (dt * 9f).coerceAtMost(1f)
        val newFlapProgress = (currentState.mascot.flapProgress - (dt * 4f)).coerceAtLeast(0f)

        // 2. Obstacles / Pipes update
        val pipeWidthDp = 72f
        val mascotX = 100f
        val mascotHitboxRadius = 18f
        var newScore = currentState.score
        var scoredThisTick = false

        val updatedPipes = mutableListOf<PipeObstacle>()
        for (pipe in currentState.pipes) {
            val newPipeX = pipe.x - (scrollSpeed * dt)
            var passed = pipe.passed

            // Check if passed
            if (!passed && (newPipeX + pipeWidthDp) < (mascotX - mascotHitboxRadius)) {
                passed = true
                newScore++
                scoredThisTick = true
            }

            // Keep only visible pipes
            if (newPipeX + pipeWidthDp > -40f) {
                updatedPipes.add(pipe.copy(x = newPipeX, passed = passed))
            }
        }

        // Spawn new pipe if needed
        val lastX = updatedPipes.maxOfOrNull { it.x } ?: 0f
        val pipeSpacing = 220f
        if (lastX < screenWidthDp + 20f) {
            val spawnX = max(lastX + pipeSpacing, screenWidthDp + 40f)
            updatedPipes.add(generatePipe(spawnX, screenHeightDp - groundHeightDp, diff.gapHeightDp))
        }

        // 3. Collision detection
        var collision = false

        // Ceiling collision
        if (newY <= 15f) {
            newY = 15f
            newVy = 0f
        }

        // Ground collision
        if (newY >= groundLimitY) {
            newY = groundLimitY
            collision = true
        }

        // Pipe collision
        if (!collision) {
            for (pipe in updatedPipes) {
                val pipeLeft = pipe.x
                val pipeRight = pipe.x + pipeWidthDp

                // Horizontal overlap check with mascot circle
                if (mascotX + mascotHitboxRadius > pipeLeft && mascotX - mascotHitboxRadius < pipeRight) {
                    // Check vertical bounds: top pipe or bottom pipe
                    val inGap = (newY - mascotHitboxRadius > pipe.topPipeHeight) &&
                            (newY + mascotHitboxRadius < pipe.bottomPipeY)
                    if (!inGap) {
                        collision = true
                        break
                    }
                }
            }
        }

        // 4. Update particles
        val updatedParticles = currentState.particles.mapNotNull { p ->
            val newAlpha = p.alpha - (dt * 2.2f)
            if (newAlpha <= 0f) null
            else p.copy(
                x = p.x + p.vx * dt,
                y = p.y + p.vy * dt,
                alpha = newAlpha
            )
        }

        if (scoredThisTick) {
            soundManager.playPoint()
        }

        if (collision) {
            soundManager.playHit()
            val wasNewBest = preferences.saveHighScoreIfGreater(newScore)
            preferences.addFlaps(currentFlapsThisRound)
            preferences.addPipesCleared(newScore)

            val updatedStats = preferences.getStats()
            _uiState.update { state ->
                state.copy(
                    status = GameStatus.GAME_OVER,
                    score = newScore,
                    highScore = updatedStats.highScore,
                    isNewHighScore = wasNewBest,
                    mascot = Mascot(
                        y = newY,
                        velocityY = 0f,
                        rotationAngle = 75f,
                        flapProgress = 0f
                    ),
                    pipes = updatedPipes,
                    particles = updatedParticles,
                    stats = updatedStats
                )
            }
        } else {
            _uiState.update { state ->
                state.copy(
                    score = newScore,
                    mascot = Mascot(
                        y = newY,
                        velocityY = newVy,
                        rotationAngle = newRot,
                        flapProgress = newFlapProgress
                    ),
                    pipes = updatedPipes,
                    particles = updatedParticles,
                    groundOffset = state.groundOffset + (scrollSpeed * dt),
                    cloudOffset = state.cloudOffset + (25f * dt)
                )
            }
        }
    }

    private fun createInitialPipes(startX: Float): List<PipeObstacle> {
        val list = mutableListOf<PipeObstacle>()
        val gap = _uiState.value.difficulty.gapHeightDp
        val availableHeight = 540f // estimated sky height
        var currentX = startX
        for (i in 0 until 4) {
            list.add(generatePipe(currentX, availableHeight, gap))
            currentX += 220f
        }
        return list
    }

    private fun generatePipe(x: Float, skyHeight: Float, gapHeight: Float): PipeObstacle {
        pipeIdCounter++
        val minPipeHeight = 60f
        val maxTopHeight = (skyHeight - gapHeight - minPipeHeight).coerceAtLeast(minPipeHeight + 20f)
        val topHeight = Random.nextFloat() * (maxTopHeight - minPipeHeight) + minPipeHeight
        val bottomPipeY = topHeight + gapHeight

        return PipeObstacle(
            id = pipeIdCounter,
            x = x,
            topPipeHeight = topHeight,
            bottomPipeY = bottomPipeY,
            passed = false
        )
    }

    // --- Settings & Configurations ---

    fun setDifficulty(difficulty: Difficulty) {
        soundManager.playClick()
        preferences.difficulty = difficulty
        _uiState.update { it.copy(difficulty = difficulty) }
    }

    fun setMascotSkin(skin: MascotSkin) {
        soundManager.playClick()
        preferences.mascotSkin = skin
        _uiState.update { it.copy(skin = skin) }
    }

    fun setSoundEnabled(enabled: Boolean) {
        preferences.isSoundEnabled = enabled
        soundManager.isSoundEnabled = enabled
        if (enabled) soundManager.playClick()
        _uiState.update { it.copy(soundEnabled = enabled) }
    }

    fun setHapticsEnabled(enabled: Boolean) {
        preferences.isHapticsEnabled = enabled
        soundManager.isHapticsEnabled = enabled
        if (enabled) soundManager.playClick()
        _uiState.update { it.copy(hapticsEnabled = enabled) }
    }

    fun setUpdateChannel(channel: UpdateChannel) {
        soundManager.playClick()
        preferences.updateChannel = channel
        _uiState.update { it.copy(updateChannel = channel) }
    }

    fun promptResetStats() {
        soundManager.playClick()
        _uiState.update { it.copy(showResetDialog = true) }
    }

    fun dismissResetDialog() {
        soundManager.playClick()
        _uiState.update { it.copy(showResetDialog = false) }
    }

    fun confirmResetStats() {
        soundManager.playClick()
        preferences.resetAllStats()
        _uiState.update {
            it.copy(
                highScore = 0,
                score = 0,
                isNewHighScore = false,
                stats = GameStats(),
                showResetDialog = false
            )
        }
    }

    // --- Updates System ---

    fun checkForUpdates() {
        soundManager.playClick()
        updateJob?.cancel()
        _uiState.update { it.copy(updateState = UpdateState.Checking) }

        updateJob = viewModelScope.launch {
            // Realistic network check delay
            delay(1600)

            val currentChannel = _uiState.value.updateChannel
            val timeFormat = SimpleDateFormat("h:mm a, MMM d", Locale.getDefault())
            val checkedTime = timeFormat.format(Date())
            preferences.lastUpdateCheck = checkedTime

            when (currentChannel) {
                UpdateChannel.STABLE -> {
                    _uiState.update {
                        it.copy(
                            updateState = UpdateState.UpToDate(
                                currentVersion = "v1.0.0",
                                checkedAt = checkedTime
                            )
                        )
                    }
                }
                UpdateChannel.BETA -> {
                    _uiState.update {
                        it.copy(
                            updateState = UpdateState.Available(
                                newVersion = "v1.1.0-beta.2",
                                buildCode = 112,
                                releaseNotes = listOf(
                                    "✨ High-refresh rate 120Hz flight physics engine",
                                    "🤖 Solar Amber & Cyber Droid skin animations",
                                    "⚡ Enhanced haptic rumble feedback on collision",
                                    "🏆 New Bronze, Silver, and Gold trophy tiers"
                                ),
                                downloadSize = "14.2 MB",
                                channel = UpdateChannel.BETA
                            )
                        )
                    }
                }
                UpdateChannel.CANARY -> {
                    _uiState.update {
                        it.copy(
                            updateState = UpdateState.Available(
                                newVersion = "v1.2.0-canary.7",
                                buildCode = 127,
                                releaseNotes = listOf(
                                    "🧪 Experimental Night Cyber city theme",
                                    "🚀 Turbo Boost thruster energy trails",
                                    "📊 Detailed score telemetry & flight charts",
                                    "🐛 Bugdroid antenna bounce physics"
                                ),
                                downloadSize = "18.8 MB",
                                channel = UpdateChannel.CANARY
                            )
                        )
                    }
                }
            }
        }
    }

    fun startDownloadUpdate() {
        soundManager.playClick()
        val currentState = _uiState.value.updateState
        if (currentState !is UpdateState.Available) return

        val newVersion = currentState.newVersion
        updateJob?.cancel()
        updateJob = viewModelScope.launch {
            for (step in 1..10) {
                delay(220)
                _uiState.update { it.copy(updateState = UpdateState.Downloading(step / 10f)) }
            }
            delay(300)
            _uiState.update { it.copy(updateState = UpdateState.ReadyToApply(newVersion)) }
        }
    }

    fun applyUpdate() {
        soundManager.playClick()
        val currentState = _uiState.value.updateState
        if (currentState !is UpdateState.ReadyToApply) return

        val newVersionStr = "${currentState.newVersion} (Updated)"
        val timeFormat = SimpleDateFormat("h:mm a, MMM d", Locale.getDefault())
        val checkedTime = timeFormat.format(Date())

        _uiState.update {
            it.copy(
                currentAppVersion = newVersionStr,
                updateState = UpdateState.UpToDate(
                    currentVersion = currentState.newVersion,
                    checkedAt = checkedTime
                )
            )
        }
    }
}
