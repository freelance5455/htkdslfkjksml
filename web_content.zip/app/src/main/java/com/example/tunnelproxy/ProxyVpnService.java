package com.example.tunnelproxy;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import hev.htproxy.TProxyService;
import java.io.File;
import java.io.FileWriter;

public class ProxyVpnService extends VpnService {
    public static final String ACTION_STOP = "stop";
    public static volatile boolean running = false;
    public static volatile String message = "";
    private ParcelFileDescriptor tun;

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i == null || ACTION_STOP.equals(i.getAction())) {
            stopTunnel();
            stopSelf();
            return START_NOT_STICKY;
        }
        stopTunnel();
        startTunnel(i.getStringExtra("host"), i.getIntExtra("port", 0),
                i.getStringExtra("user"), i.getStringExtra("pass"));
        if (!running) stopSelf();
        return START_NOT_STICKY;
    }

    private static String q(String s) { return "'" + s.replace("'", "''") + "'"; }

    private void startTunnel(String host, int port, String user, String pass) {
        try {
            Builder b = new Builder().setSession("Tunnel Proxy").setMtu(1500)
                    .addAddress("10.8.0.2", 32).addRoute("0.0.0.0", 0).addDnsServer("8.8.8.8");
            // Keep this app's own sockets (to the proxy) outside the tunnel, or traffic loops.
            try { b.addDisallowedApplication(getPackageName()); } catch (PackageManager.NameNotFoundException ignored) {}
            tun = b.establish();
            if (tun == null) { message = "VPN permission was not granted."; return; }

            StringBuilder c = new StringBuilder();
            c.append("misc:\n  task-stack-size: 81920\n");
            c.append("tunnel:\n  mtu: 1500\n");
            c.append("socks5:\n  port: ").append(port).append("\n  address: ").append(q(host)).append("\n  udp: 'udp'\n");
            if (user != null && !user.isEmpty()) {
                c.append("  username: ").append(q(user)).append("\n  password: ").append(q(pass == null ? "" : pass)).append("\n");
            }
            File f = new File(getFilesDir(), "tproxy.yml");
            try (FileWriter w = new FileWriter(f)) { w.write(c.toString()); }

            TProxyService.TProxyStartService(f.getAbsolutePath(), tun.getFd());
            running = true;
            message = "Connected";
        } catch (Throwable t) {
            message = "Failed: " + t.getMessage();
            stopTunnel();
        }
    }

    private void stopTunnel() {
        if (running) { try { TProxyService.TProxyStopService(); } catch (Throwable ignored) {} }
        running = false;
        if (tun != null) { try { tun.close(); } catch (Exception ignored) {} tun = null; }
    }

    @Override public void onRevoke() { stopTunnel(); message = "VPN was revoked by the system."; stopSelf(); }
    @Override public void onDestroy() { stopTunnel(); super.onDestroy(); }
}
