package com.example.tunnelproxy;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText host, port, user, pass;
    private Button btn;
    private TextView status;
    private SharedPreferences sp;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() { public void run() { refresh(); h.postDelayed(this, 500); } };

    private EditText field(LinearLayout root, String hint, int type, String saved) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setInputType(type); e.setSingleLine(true); e.setText(saved);
        root.addView(e, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        sp = getSharedPreferences("p", MODE_PRIVATE);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad * 2, pad, pad);
        TextView t = new TextView(this);
        t.setText("Tunnel Proxy"); t.setTextSize(24);
        root.addView(t);
        TextView sub = new TextView(this);
        sub.setText("SOCKS5 proxy. All apps on this phone will use it while connected.");
        root.addView(sub);
        host = field(root, "Host (IP or domain)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI, sp.getString("host", ""));
        port = field(root, "Port", InputType.TYPE_CLASS_NUMBER, sp.getString("port", ""));
        user = field(root, "Username (optional)", InputType.TYPE_CLASS_TEXT, sp.getString("user", ""));
        pass = field(root, "Password (optional)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD, sp.getString("pass", ""));
        btn = new Button(this);
        root.addView(btn);
        status = new TextView(this);
        root.addView(status);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
        btn.setOnClickListener(v -> onToggle());
    }

    private void onToggle() {
        if (ProxyVpnService.running) {
            startService(new Intent(this, ProxyVpnService.class).setAction(ProxyVpnService.ACTION_STOP));
            return;
        }
        String hs = host.getText().toString().trim();
        int p;
        try { p = Integer.parseInt(port.getText().toString().trim()); } catch (Exception e) { p = 0; }
        if (hs.isEmpty() || p < 1 || p > 65535) { status.setText("Enter a host and a port between 1 and 65535."); return; }
        sp.edit().putString("host", hs).putString("port", String.valueOf(p))
                .putString("user", user.getText().toString()).putString("pass", pass.getText().toString()).apply();
        Intent prep = VpnService.prepare(this);
        if (prep != null) startActivityForResult(prep, 1); else startVpn();
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (req == 1 && res == RESULT_OK) startVpn();
        else if (req == 1) status.setText("VPN permission denied.");
    }

    private void startVpn() {
        ProxyVpnService.message = "Connecting…";
        Intent i = new Intent(this, ProxyVpnService.class)
                .putExtra("host", sp.getString("host", "")).putExtra("port", Integer.parseInt(sp.getString("port", "0")))
                .putExtra("user", sp.getString("user", "")).putExtra("pass", sp.getString("pass", ""));
        startService(i);
    }

    private void refresh() {
        boolean on = ProxyVpnService.running;
        btn.setText(on ? "Disconnect" : "Connect");
        if (!ProxyVpnService.message.isEmpty()) status.setText(ProxyVpnService.message);
        else status.setText(on ? "Connected" : "Disconnected");
        for (EditText e : new EditText[]{host, port, user, pass}) e.setEnabled(!on);
    }

    @Override protected void onResume() { super.onResume(); h.post(tick); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }
}
