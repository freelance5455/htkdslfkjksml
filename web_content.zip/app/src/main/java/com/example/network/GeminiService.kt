package com.example.network

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val TAG = "GeminiService"
        private const val SYSTEM_PROMPT =
            "You are Faiz Saathi AI, a friendly helpful AI for India. You help students, kids, elders. Always reply in easy Hindi (Hinglish). If user uploads image, first describe the image in Hindi, then answer the question about it. If voice transcript comes, answer accordingly. You are created by Faiz."
        private const val PRIMARY_MODEL = "gemini-1.5-flash"
    }

    suspend fun generateContent(
        apiKey: String,
        prompt: String,
        imageBase64: String? = null,
        mimeType: String = "image/jpeg"
    ): Result<String> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(
                Exception("API Key check karo: Kripya valid Gemini API Key darj karein.")
            )
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$PRIMARY_MODEL:generateContent?key=$apiKey"

            val jsonBody = JSONObject().apply {
                // System Instruction
                put("system_instruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", SYSTEM_PROMPT)
                        })
                    })
                })

                // Contents
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        val parts = JSONArray()

                        val userText = if (prompt.isBlank() && imageBase64 != null) {
                            "Kripya is photo ko dekhein aur iske baare mein batayein."
                        } else {
                            prompt
                        }
                        parts.put(JSONObject().apply {
                            put("text", userText)
                        })

                        if (!imageBase64.isNullOrBlank()) {
                            parts.put(JSONObject().apply {
                                put("inline_data", JSONObject().apply {
                                    put("mime_type", mimeType)
                                    put("data", imageBase64)
                                })
                            })
                        }

                        put("parts", parts)
                    })
                })
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini API error code: ${response.code}, body: $responseBody")
                val errorMessage = try {
                    val errorJson = JSONObject(responseBody).optJSONObject("error")
                    val msg = errorJson?.optString("message", "") ?: ""
                    if (msg.contains("API_KEY_INVALID", ignoreCase = true) || response.code == 400 || response.code == 403) {
                        "API Key check karo: Gemini API key invalid ya expire ho sakti hai. ($msg)"
                    } else {
                        "API Key check karo: ${response.message} - $msg"
                    }
                } catch (_: Exception) {
                    "API Key check karo: HTTP error ${response.code}"
                }
                return@withContext Result.failure(Exception(errorMessage))
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val contentObj = firstCandidate.optJSONObject("content")
                val parts = contentObj?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val textBuilder = StringBuilder()
                    for (i in 0 until parts.length()) {
                        textBuilder.append(parts.getJSONObject(i).optString("text", ""))
                    }
                    val reply = textBuilder.toString().trim()
                    if (reply.isNotEmpty()) {
                        return@withContext Result.success(reply)
                    }
                }
            }

            Result.failure(Exception("Jawab nahi mil paya. Kripya dobara koshish karein."))
        } catch (e: Exception) {
            Log.e(TAG, "Request failed", e)
            Result.failure(Exception("API Key check karo ya internet connection dekhein: ${e.localizedMessage ?: "Unknown error"}"))
        }
    }
}
