package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import androidx.core.graphics.PathParser
import com.example.chess.ChessEngineCore
import com.example.chess.ChessPiece
import com.example.chess.PieceColor
import com.example.chess.PieceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class SampleDiagramPageSpec(
    val chapterTitle: String,
    val fen: String,
    val topCaption: String,
    val moveHeader: String,
    val commentaryLines: List<String>
)

object SampleChessPdfGenerator {

    val CLASSIC_DIAGRAM_SPECS = listOf(
        SampleDiagramPageSpec(
            chapterTitle = "The Botvinnik Attack — Dynamic g2 Bishop",
            fen = "1rbq1rkb/pp3p1n/3p1P1p/2p1P1PN/2Pp3p/1P1P4/P5B1/R1BQ1RK1 b - - 0 20",
            topCaption = "White to play / Black replies 20...hxg5",
            moveHeader = "20...hxg5",
            commentaryLines = listOf(
                "Bringing the Botvinnik bishop on g2 into play, although there was nothing",
                "much wrong with the immediate 20.gxh6.",
                "After 20...dxe5 21.gxh6 White threatens Be4 and there doesn't appear to be",
                "any defence, as shown by 21...Nxf6 22.Kh2! Qg4 23.Qxg4+ Bxg4 24.Bd5! Bxh5",
                "25.Rg1+ Bg7 when 26.Bg5! is both neat and deadly.",
                "21.Be4! Black is simply getting crushed along the dark-square diagonal."
            )
        ),
        SampleDiagramPageSpec(
            chapterTitle = "Capablanca Chess Fundamentals — Elementary Rook Mate",
            fen = "8/8/8/4k3/8/8/R7/4K3 w - - 0 1",
            topCaption = "White to move — Cutting off the King",
            moveHeader = "1.Ra4!",
            commentaryLines = listOf(
                "White to move restricts the Black King to the upper four ranks immediately.",
                "In King and Rook against King, the winning method consists of confining",
                "the opposing King to as few ranks or files as possible, then bringing up",
                "our own King in opposition to force the enemy King to the edge of the board."
            )
        ),
        SampleDiagramPageSpec(
            chapterTitle = "Pawn Endgames — The Rule of the Square",
            fen = "8/8/4k3/8/2P5/8/8/4K3 w - - 0 1",
            topCaption = "White to move and win",
            moveHeader = "1.c5! Kd5 2.c6",
            commentaryLines = listOf(
                "White to play pushes 1.c5! stepping outside the Black King's square.",
                "Count the ranks from the pawn to c8: if the defending King cannot step",
                "into that square on its turn, the passed pawn promotes without assistance."
            )
        ),
        SampleDiagramPageSpec(
            chapterTitle = "Ruy Lopez — Classical Morphy Defense",
            fen = "r1bqk2r/1pp1bppp/p1np1n2/4p3/B3P3/5N2/PPPP1PPP/RNBQ1RK1 w kq - 2 6",
            topCaption = "White to move — 6.Re1 protecting e4",
            moveHeader = "6.Re1 b5 7.Bb3 d6",
            commentaryLines = listOf(
                "White to move plays 6.Re1!, defending the e4 pawn and preparing c3 and d4.",
                "Notice how 6.Re1 also vacates f1 for the Knight maneuver Nbd2-f1-g3,",
                "building classical central tension before launching a kingside attack."
            )
        ),
        SampleDiagramPageSpec(
            chapterTitle = "Tactical Motif — The Greek Gift Sacrifice",
            fen = "r1bq1rk1/pp1nbppp/2p1pn2/3p4/2PP4/2NBPN2/PP3PPP/R1BQ1RK1 w - - 4 8",
            topCaption = "White to play — Kingside Coordination",
            moveHeader = "8.e4 dxe4 9.Nxe4",
            commentaryLines = listOf(
                "White to play seizes central space and lines up the light-squared bishop",
                "toward h7. Whenever Black lacks a defending Knight on f6 and cannot guard",
                "h7 with g6 or Nf8, the classic Bxh7+! Kxh7 Ng5+ sacrifice becomes lethal."
            )
        ),
        SampleDiagramPageSpec(
            chapterTitle = "The Immortal Game — Anderssen's Mating Net",
            fen = "r1b1k2r/ppp1b2p/5n2/1B3p2/5B2/2N5/PPP2PPP/R3K2R w KQkq - 0 13",
            topCaption = "White to move — Rapid Development Lead",
            moveHeader = "13.O-O-O!",
            commentaryLines = listOf(
                "White to move castles queenside, placing the d1 Rook directly opposite",
                "Black's uncastled King. Every White minor piece participates in the",
                "central assault while Black's queenside pieces remain asleep."
            )
        )
    )

    /**
     * Generates a crisp printed-style chess PDF book with real 8x8 vector diagrams,
     * hatched dark squares, double borders, coordinates, and text, plus returns a clean
     * 640px diagram bitmap containing all 12 piece types on light & dark squares so the
     * book's 26 NCC templates can also be verified/learned offline!
     */
    suspend fun generateSamplePdfFile(
        context: Context,
        filename: String,
        pageCount: Int
    ): File = withContext(Dispatchers.IO) {
        val booksDir = File(context.filesDir, "books").apply { mkdirs() }
        val outFile = File(booksDir, filename)

        // Pre-render the unique printed chess diagrams as crisp 560x560 JPEG XObjects
        val imgDim = 560
        val uniqueJpegs = CLASSIC_DIAGRAM_SPECS.map { spec ->
            val bmp = Bitmap.createBitmap(imgDim, imgDim, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.drawColor(Color.WHITE)
            drawPrintedChessDiagramOnCanvas(
                canvas = c,
                fen = spec.fen,
                boardLeft = 40f,
                boardTop = 24f,
                boardSize = 480f
            )
            val baos = java.io.ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, baos)
            baos.toByteArray()
        }

        // Write standards-compliant PDF 1.4 with /DCTDecode diagram XObjects + searchable BT/ET text streams
        // Object layout:
        // 1: Catalog
        // 2: Pages
        // 3: Font /F1 (Times-Roman)
        // 4: Font /F2 (Times-Bold)
        // 5..(5 + uniqueJpegs.size - 1): Image XObjects
        // Remaining pairs: Page dict + Content stream per page
        val firstImgObjId = 5
        val firstPageObjId = firstImgObjId + uniqueJpegs.size
        val totalObjects = firstPageObjId + pageCount * 2 - 1

        val out = java.io.ByteArrayOutputStream(256 * 1024)
        val offsets = IntArray(totalObjects + 1)

        fun writeAscii(s: String) {
            out.write(s.toByteArray(Charsets.ISO_8859_1))
        }

        fun escapePdfLiteral(s: String): String =
            s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
                .replace("—", "-").replace("•", "*")

        writeAscii("%PDF-1.4\n%\u00E2\u00E3\u00CF\u00D3\n")

        // 1: Catalog
        offsets[1] = out.size()
        writeAscii("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")

        // 2: Pages
        val kidsRefs = (0 until pageCount).joinToString(" ") { idx -> "${firstPageObjId + idx * 2} 0 R" }
        offsets[2] = out.size()
        writeAscii("2 0 obj\n<< /Type /Pages /Kids [ $kidsRefs ] /Count $pageCount >>\nendobj\n")

        // 3 & 4: Standard Type1 Fonts
        offsets[3] = out.size()
        writeAscii("3 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Times-Roman >>\nendobj\n")
        offsets[4] = out.size()
        writeAscii("4 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Times-Bold >>\nendobj\n")

        // Image XObjects
        for ((idx, jpegBytes) in uniqueJpegs.withIndex()) {
            val objId = firstImgObjId + idx
            offsets[objId] = out.size()
            writeAscii(
                "$objId 0 obj\n" +
                    "<< /Type /XObject /Subtype /Image /Width $imgDim /Height $imgDim " +
                    "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.size} >>\n" +
                    "stream\n"
            )
            out.write(jpegBytes)
            writeAscii("\nendstream\nendobj\n")
        }

        // Pages & Content Streams (PDF origin bottom-left: MediaBox 612 x 842)
        for (i in 0 until pageCount) {
            val specIdx = i % CLASSIC_DIAGRAM_SPECS.size
            val spec = CLASSIC_DIAGRAM_SPECS[specIdx]
            val imgObjId = firstImgObjId + specIdx
            val pageObjId = firstPageObjId + i * 2
            val contentObjId = pageObjId + 1

            val contentSb = StringBuilder()
            // Top centered page number + chapter heading
            contentSb.append("BT /F1 11 Tf 298 810 Td (${i + 1}) Tj ET\n")
            contentSb.append("BT /F2 14 Tf 52 782 Td (${escapePdfLiteral(spec.chapterTitle)}) Tj ET\n")
            // Place 290x290 pt diagram centered horizontally at x=161, y=474
            contentSb.append("q 290 0 0 290 161 474 cm /Im0 Do Q\n")
            // Caption, bold move header ("20...hxg5"), and commentary lines
            contentSb.append("BT /F1 11.5 Tf 58 446 Td (${escapePdfLiteral(spec.topCaption)}) Tj ET\n")
            contentSb.append("BT /F2 12 Tf 52 418 Td (${escapePdfLiteral(spec.moveHeader)}) Tj ET\n")
            var textY = 392
            for (line in spec.commentaryLines) {
                contentSb.append("BT /F1 11.5 Tf 52 $textY Td (${escapePdfLiteral(line)}) Tj ET\n")
                textY -= 18
            }

            val contentBytes = contentSb.toString().toByteArray(Charsets.ISO_8859_1)

            offsets[pageObjId] = out.size()
            writeAscii(
                "$pageObjId 0 obj\n" +
                    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 842] " +
                    "/Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << /Im0 $imgObjId 0 R >> >> " +
                    "/Contents $contentObjId 0 R >>\n" +
                    "endobj\n"
            )

            offsets[contentObjId] = out.size()
            writeAscii("$contentObjId 0 obj\n<< /Length ${contentBytes.size} >>\nstream\n")
            out.write(contentBytes)
            writeAscii("\nendstream\nendobj\n")
        }

        val xrefOffset = out.size()
        writeAscii("xref\n0 ${totalObjects + 1}\n")
        writeAscii("0000000000 65535 f \n")
        for (id in 1..totalObjects) {
            writeAscii(String.format(java.util.Locale.US, "%010d 00000 n \n", offsets[id]))
        }
        writeAscii(
            "trailer\n<< /Size ${totalObjects + 1} /Root 1 0 R >>\n" +
                "startxref\n$xrefOffset\n%%EOF\n"
        )

        FileOutputStream(outFile).use { fos ->
            fos.write(out.toByteArray())
        }
        outFile
    }

    /**
     * Renders a calibration 640x640 clean diagram bitmap + ground-truth 8x8 grid containing
     * all 12 Staunton piece types on BOTH light and dark hatched squares + empty squares
     * (all 26 templates) in the exact printed book style so offline NCC achieves >0.95 accuracy immediately.
     */
    fun createPrintedBookCalibrationPair(): Pair<Bitmap, Array<Array<String>>> {
        val grid = arrayOf(
            arrayOf("bR", "bN", "bB", "bQ", "bK", "bB", "bN", "bR"),
            arrayOf("bP", "bP", "bK", "bQ", "empty", "empty", "bP", "bP"),
            arrayOf("empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"),
            arrayOf("empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"),
            arrayOf("empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"),
            arrayOf("empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"),
            arrayOf("wP", "wP", "wK", "wQ", "empty", "empty", "wP", "wP"),
            arrayOf("wR", "wN", "wB", "wQ", "wK", "wB", "wN", "wR")
        )
        val bmp = Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val cell = 640f / 8f

        val hatchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(160, 160, 160)
            strokeWidth = (cell * 0.018f).coerceAtLeast(0.8f)
        }
        val gridLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(70, 70, 70)
            style = Paint.Style.STROKE
            strokeWidth = (cell * 0.010f).coerceAtLeast(0.5f)
        }

        for (r in 0..7) {
            for (c in 0..7) {
                val left = c * cell
                val top = r * cell
                if ((r + c) % 2 == 1) {
                    drawDiagonalHatchSquare(canvas, left, top, cell, hatchPaint)
                }
                canvas.drawRect(left, top, left + cell, top + cell, gridLinePaint)
                val code = grid[r][c]
                if (code != "empty") {
                    val color = if (code.startsWith("w")) PieceColor.WHITE else PieceColor.BLACK
                    val type = PieceType.fromChar(code[1]) ?: PieceType.PAWN
                    drawStauntonPieceOnCanvas(canvas, ChessPiece(color, type), left, top, cell)
                }
            }
        }
        return bmp to grid
    }

    fun drawPrintedChessDiagramOnCanvas(
        canvas: Canvas,
        fen: String,
        boardLeft: Float,
        boardTop: Float,
        boardSize: Float
    ) {
        val pos = ChessEngineCore.parseFen(fen) ?: return
        val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2.2f
        }
        val innerFramePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
        }
        // Double border matching printed chess books in screenshot
        canvas.drawRect(boardLeft - 4f, boardTop - 4f, boardLeft + boardSize + 4f, boardTop + boardSize + 4f, outerPaint)
        canvas.drawRect(boardLeft, boardTop, boardLeft + boardSize, boardTop + boardSize, innerFramePaint)

        val cell = boardSize / 8f
        val hatchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(160, 160, 160)
            strokeWidth = (cell * 0.018f).coerceAtLeast(0.8f)
        }
        val cellBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(70, 70, 70)
            style = Paint.Style.STROKE
            strokeWidth = (cell * 0.010f).coerceAtLeast(0.5f)
        }

        for (r in 0..7) {
            for (c in 0..7) {
                val left = boardLeft + c * cell
                val top = boardTop + r * cell
                if ((r + c) % 2 == 1) {
                    drawDiagonalHatchSquare(canvas, left, top, cell, hatchPaint)
                }
                canvas.drawRect(left, top, left + cell, top + cell, cellBorderPaint)
                val piece = pos.board[r][c]
                if (piece != null) {
                    drawStauntonPieceOnCanvas(canvas, piece, left, top, cell)
                }
            }
        }

        // Rank & File coordinates outside frame (matching screenshot: 8..1 left, a..h bottom)
        val coordPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 20, 20)
            textSize = cell * 0.42f
            typeface = Typeface.SANS_SERIF
            textAlign = Paint.Align.CENTER
        }
        for (r in 0..7) {
            val rankStr = "${8 - r}"
            canvas.drawText(rankStr, boardLeft - 13f, boardTop + r * cell + cell * 0.66f, coordPaint)
        }
        for (c in 0..7) {
            val fileStr = "${('a'.code + c).toChar()}"
            canvas.drawText(fileStr, boardLeft + c * cell + cell * 0.5f, boardTop + boardSize + 16f, coordPaint)
        }
    }

    private fun drawDiagonalHatchSquare(canvas: Canvas, left: Float, top: Float, size: Float, paint: Paint) {
        canvas.save()
        canvas.clipRect(left, top, left + size, top + size)
        val step = size / 7f
        var offset = -size
        while (offset < size * 2f) {
            canvas.drawLine(left + offset, top + size, left + offset + size, top, paint)
            offset += step
        }
        canvas.restore()
    }

    fun drawStauntonPieceOnCanvas(
        canvas: Canvas,
        piece: ChessPiece,
        left: Float,
        top: Float,
        cellSize: Float
    ) {
        val scale = cellSize / 45f
        val matrix = Matrix().apply {
            postScale(scale, scale)
            postTranslate(left, top)
        }

        val whiteFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val blackFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(18, 18, 18)
            style = Paint.Style.FILL
        }
        val darkStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 15, 15)
            style = Paint.Style.STROKE
            strokeWidth = (1.6f * scale).coerceAtLeast(1.1f)
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        val lightDetailStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(236, 236, 236)
            style = Paint.Style.STROKE
            strokeWidth = (1.3f * scale).coerceAtLeast(0.9f)
            strokeCap = Paint.Cap.ROUND
        }

        val isWhite = piece.color == PieceColor.WHITE
        val bodyFill = if (isWhite) whiteFill else blackFill

        fun drawSvgPath(pathData: String, fill: Paint?, stroke: Paint?) {
            val path: Path = PathParser.createPathFromPathData(pathData) ?: return
            path.transform(matrix)
            if (fill != null) canvas.drawPath(path, fill)
            if (stroke != null) canvas.drawPath(path, stroke)
        }

        when (piece.type) {
            PieceType.PAWN -> {
                drawSvgPath(
                    "M22.5 9c-2.21 0-4 1.79-4 4 0 .89.29 1.71.78 2.38C17.33 16.5 16 18.59 16 21c0 2.03.94 3.84 2.41 5.03-3 1.06-7.41 5.55-7.41 13.47h23c0-7.92-4.41-12.41-7.41-13.47 1.47-1.19 2.41-3 2.41-5.03 0-2.41-1.33-4.5-3.28-5.62.49-.67.78-1.49.78-2.38 0-2.21-1.79-4-4-4z",
                    bodyFill,
                    darkStroke
                )
            }
            PieceType.ROOK -> {
                drawSvgPath("M9 39h27v-3H9zm3-3v-4h21v4zm-1-22V9h4v2h5V9h5v2h5V9h4v5", bodyFill, darkStroke)
                drawSvgPath("M34 14L31 17H14L11 14", bodyFill, darkStroke)
                drawSvgPath("M31 17v12.5H14V17", bodyFill, darkStroke)
                drawSvgPath("M31 29.5L32.5 32h-20L14 29.5", bodyFill, darkStroke)
                if (!isWhite) {
                    drawSvgPath("M12 35.5h21M13 31.5h19M14 29.5h17M14 16.5h17M11 14h23", null, lightDetailStroke)
                }
            }
            PieceType.KNIGHT -> {
                drawSvgPath("M22 10c10.5 1 16.5 8 16 29H15c0-9 10-6.5 8-21", bodyFill, darkStroke)
                drawSvgPath(
                    "M24 18c.38 2.91-5.55 7.37-8 9-3 2-2.82 4.34-5 4-1.04-.94 1.41-3.04 0-3-1 0 .19 1.23-1 2-1 0-4 1-4-4 0-2 6-12 6-12s1.89-1.9 2-3.5c-.73-1-.5-2-.5-3 1-1 3 2.5 3 2.5h2s.78-2 2.5-3c1 0 1 3 1 3",
                    bodyFill,
                    darkStroke
                )
            }
            PieceType.BISHOP -> {
                drawSvgPath(
                    "M9 36c3.39-.97 10.11.43 13.5-2 3.39 2.43 10.11 1.03 13.5 2 0 0 1.65.54 3 2-.68.97-1.65.99-3 .5-3.39-.97-10.11.46-13.5-1-3.39 1.46-10.11.03-13.5 1-1.35.49-2.32.47-3-.5 1.35-1.94 3-2 3-2z",
                    bodyFill,
                    darkStroke
                )
                drawSvgPath(
                    "M15 32c2.5 2.5 12.5 2.5 15 0 .5-1.5 0-2 0-2 0-2.5-2.5-4-2.5-4 5.5-1.5 6-11.5-5-15.5-11 4-10.5 14-5 15.5 0 0-2.5 1.5-2.5 4 0 0-.5.5 0 2z",
                    bodyFill,
                    darkStroke
                )
                canvas.drawCircle(left + 22.5f * scale, top + 8f * scale, 2.5f * scale, bodyFill)
                canvas.drawCircle(left + 22.5f * scale, top + 8f * scale, 2.5f * scale, darkStroke)
                val crossStroke = if (isWhite) darkStroke else lightDetailStroke
                drawSvgPath("M17.5 26h10M15 30h15M22.5 15.5v5M20 18h5", null, crossStroke)
            }
            PieceType.QUEEN -> {
                drawSvgPath(
                    "M9 26c8.5-1.5 21-1.5 27 0l2-12-7 11V11l-5.5 13.5-3-15-3 15-5.5-14V25L7 14z",
                    bodyFill,
                    darkStroke
                )
                drawSvgPath(
                    "M9 26c0 2 1.5 2 2.5 4 1 1.5 1 1 .5 3.5-1.5 1-1.5 2.5-1.5 2.5-1.5 1.5.5 2.5.5 2.5 6.5 1 16.5 1 23 0 0 0 1.5-1 0-2.5 0 0 .5-1.5-1-2.5-.5-2.5-.5-2 .5-3.5 1-2 2.5-2 2.5-4-8.5-1.5-18.5-1.5-27 0z",
                    bodyFill,
                    darkStroke
                )
                val pearls = arrayOf(6f to 12f, 14f to 9f, 22.5f to 8f, 31f to 9f, 39f to 12f)
                for ((px, py) in pearls) {
                    canvas.drawCircle(left + px * scale, top + py * scale, 2.2f * scale, bodyFill)
                    canvas.drawCircle(left + px * scale, top + py * scale, 2.2f * scale, darkStroke)
                }
                if (!isWhite) {
                    drawSvgPath("M11.5 30c3.5-1 18.5-1 22 0M12 33.5c6-1 15-1 21 0", null, lightDetailStroke)
                }
            }
            PieceType.KING -> {
                drawSvgPath("M22.5 11.6V6M20 8h5", null, darkStroke)
                drawSvgPath(
                    "M22.5 25s4.5-7.5 3-10.5c0 0-1-2.5-3-2.5s-3 2.5-3 2.5c-1.5 3 3 10.5 3 10.5",
                    bodyFill,
                    darkStroke
                )
                drawSvgPath(
                    "M11.5 37c5.5 3.5 15.5 3.5 21 0v-7s9-4.5 6-10.5c-4-6.5-13.5-3.5-16 4V27v-3.5c-3.5-7.5-13-10.5-16-4-3 6 5 10 5 10z",
                    bodyFill,
                    darkStroke
                )
                val bandStroke = if (isWhite) darkStroke else lightDetailStroke
                drawSvgPath("M11.5 30c5.5-3 15.5-3 21 0m-21 3.5c5.5-3 15.5-3 21 0m-21 3.5c5.5-3 15.5-3 21 0", null, bandStroke)
            }
        }
    }
}
