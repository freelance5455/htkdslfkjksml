package com.example.pdf

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import com.example.scanner.CropRect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.Inflater
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

data class PdfSearchMatch(
    val pageNumber: Int,
    val snippet: String
)

class PdfDocumentController(val pdfFile: File) {

    private val mutex = Mutex()
    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null

    private val bitmapCache = object : LruCache<String, Bitmap>(24 * 1024) { // ~24 MB cache
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    var pageCount: Int = 1
        private set

    suspend fun open(): Int = mutex.withLock {
        withContext(Dispatchers.IO) {
            if (renderer == null) {
                val descriptor = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                val pdfRenderer = PdfRenderer(descriptor)
                pfd = descriptor
                renderer = pdfRenderer
                pageCount = pdfRenderer.pageCount.coerceAtLeast(1)
            }
            pageCount
        }
    }

    suspend fun getPageAspectRatio(pageNumber: Int): Float = mutex.withLock {
        withContext(Dispatchers.IO) {
            val r = renderer ?: return@withContext 0.75f
            val idx = (pageNumber - 1).coerceIn(0, (r.pageCount - 1).coerceAtLeast(0))
            r.openPage(idx).use { page ->
                if (page.height > 0) page.width.toFloat() / page.height.toFloat() else 0.75f
            }
        }
    }

    suspend fun renderPage(pageNumber: Int, targetWidthPx: Int): Bitmap? {
        val widthBucket = ((targetWidthPx / 120).coerceAtLeast(3) * 120).coerceAtMost(2400)
        val cacheKey = "${pdfFile.name}_p${pageNumber}_w$widthBucket"
        bitmapCache.get(cacheKey)?.let { cached ->
            if (!cached.isRecycled) return cached
        }

        return mutex.withLock {
            bitmapCache.get(cacheKey)?.let { cached ->
                if (!cached.isRecycled) return@withLock cached
            }
            withContext(Dispatchers.IO) {
                val r = renderer ?: return@withContext null
                if (r.pageCount <= 0) return@withContext null
                val idx = (pageNumber - 1).coerceIn(0, r.pageCount - 1)
                r.openPage(idx).use { page ->
                    val ratio = if (page.width > 0) page.height.toFloat() / page.width.toFloat() else 1.35f
                    val bmpW = widthBucket.coerceAtLeast(200)
                    val bmpH = (bmpW * ratio).roundToInt().coerceAtLeast(200)
                    val bmp = Bitmap.createBitmap(bmpW, bmpH, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmapCache.put(cacheKey, bmp)
                    bmp
                }
            }
        }
    }

    suspend fun close() = mutex.withLock {
        withContext(Dispatchers.IO) {
            runCatching { renderer?.close() }
            runCatching { pfd?.close() }
            renderer = null
            pfd = null
            bitmapCache.evictAll()
        }
    }

    companion object {
        /**
         * Automatically localizes square chess diagram candidate regions on a rendered PDF page bitmap.
         * Scans horizontal dark-ink bands and finds centered square regions (width 28%..82% of page).
         */
        fun detectDiagramCandidatesOnPage(pageBitmap: Bitmap): List<CropRect> {
            val w = pageBitmap.width
            val h = pageBitmap.height
            if (w < 80 || h < 80) return emptyList()

            val pixels = IntArray(w * h)
            pageBitmap.getPixels(pixels, 0, w, 0, 0, w, h)

            // 1. Direct frame-line detector for bordered chess diagrams (pinpoints 8x8 frame accurately)
            val minSide = (w * 0.24f).toInt()
            val maxSide = (w * 0.88f).toInt()
            val frameCandidates = ArrayList<CropRect>()
            var y = (h * 0.03f).toInt()
            while (y < h - minSide) {
                val rowOff = y * w
                var runStart = -1
                var bestRunStart = -1
                var bestRunLen = 0
                for (x in 0 until w) {
                    val c = pixels[rowOff + x]
                    val lum = 0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF)
                    if (lum < 110f) {
                        if (runStart == -1) runStart = x
                        val len = x - runStart + 1
                        if (len > bestRunLen) {
                            bestRunLen = len
                            bestRunStart = runStart
                        }
                    } else {
                        runStart = -1
                    }
                }
                if (bestRunLen in minSide..maxSide) {
                    // Verify matching vertical left/right borders for a square of side ~bestRunLen
                    val checkH = bestRunLen.coerceAtMost(h - y - 1)
                    var leftDark = 0
                    var rightDark = 0
                    val rxLeft = bestRunStart
                    val rxRight = (bestRunStart + bestRunLen - 1).coerceAtMost(w - 1)
                    var sampleCount = 0
                    for (dy in 0 until checkH step 3) {
                        val off = (y + dy) * w
                        val cL = pixels[off + rxLeft]
                        val cR = pixels[off + rxRight]
                        val lumL = 0.299f * ((cL shr 16) and 0xFF) + 0.587f * ((cL shr 8) and 0xFF) + 0.114f * (cL and 0xFF)
                        val lumR = 0.299f * ((cR shr 16) and 0xFF) + 0.587f * ((cR shr 8) and 0xFF) + 0.114f * (cR and 0xFF)
                        if (lumL < 125f) leftDark++
                        if (lumR < 125f) rightDark++
                        sampleCount++
                    }
                    if (sampleCount > 8 && leftDark > sampleCount * 0.75f && rightDark > sampleCount * 0.75f) {
                        val pad = (bestRunLen * 0.03f).toInt().coerceAtLeast(6)
                        val cx = (bestRunStart - pad).coerceAtLeast(0)
                        val cy = (y - pad).coerceAtLeast(0)
                        val cw = (bestRunLen + pad * 2).coerceAtMost(w - cx)
                        val ch = (bestRunLen + pad * 2).coerceAtMost(h - cy)
                        frameCandidates.add(CropRect(cx, cy, cw, ch))
                        y += bestRunLen + 12
                        continue
                    }
                }
                y += 2
            }
            if (frameCandidates.isNotEmpty()) return frameCandidates

            // 2. Smoothed ink-band fallback for borderless diagrams
            val step = 2
            val sw = w / step
            val sh = h / step
            val rawInk = FloatArray(sh)
            for (sy in 0 until sh) {
                val py = sy * step
                var darkCount = 0
                val rowOff = py * w
                for (sx in 0 until sw) {
                    val px = sx * step
                    val c = pixels[rowOff + px]
                    val lum = 0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF)
                    if (lum < 205f) darkCount++
                }
                rawInk[sy] = darkCount.toFloat() / sw
            }
            val win = (sh / 28).coerceAtLeast(3)
            val rowInk = FloatArray(sh) { idx ->
                var s = 0f
                var cnt = 0
                for (k in (idx - win)..(idx + win)) {
                    if (k in 0 until sh) {
                        s += rawInk[k]
                        cnt++
                    }
                }
                s / cnt.coerceAtLeast(1)
            }

            val candidates = ArrayList<CropRect>()
            var bandStart = -1
            for (sy in 0 until sh) {
                val active = rowInk[sy] > 0.045f
                if (active && bandStart == -1) {
                    bandStart = sy
                } else if (!active && bandStart != -1) {
                    val bandH = (sy - bandStart) * step
                    if (bandH in minSide..maxSide) {
                        val yTop = bandStart * step
                        var minX = w
                        var maxX = 0
                        for (py in yTop until min(h, yTop + bandH) step 2) {
                            val off = py * w
                            for (px in (w * 0.05f).toInt() until (w * 0.95f).toInt() step 2) {
                                val c = pixels[off + px]
                                val lum = 0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF)
                                if (lum < 150f) {
                                    if (px < minX) minX = px
                                    if (px > maxX) maxX = px
                                }
                            }
                        }
                        val bandW = maxX - minX
                        if (bandW > minSide && abs(bandW - bandH) < bandW * 0.35f) {
                            val pad = (bandW * 0.03f).toInt()
                            val rx = (minX - pad).coerceAtLeast(0)
                            val ry = (yTop - pad).coerceAtLeast(0)
                            val rw = (bandW + pad * 2).coerceAtMost(w - rx)
                            val rh = (bandH + pad * 2).coerceAtMost(h - ry)
                            candidates.add(CropRect(rx, ry, rw, rh))
                        }
                    }
                    bandStart = -1
                }
            }
            return candidates
        }

        /**
         * Offline PDF stream text extractor for search & surrounding caption context.
         * Decompresses FlateDecode streams and extracts PDF text literals (Tj / TJ / ').
         */
        suspend fun extractTextByPage(pdfFile: File): Map<Int, String> = withContext(Dispatchers.IO) {
            val result = LinkedHashMap<Int, String>()
            try {
                val bytes = pdfFile.readBytes()
                val rawLatin = String(bytes, Charsets.ISO_8859_1)
                val streamRegex = Regex("""<<(.*?)>>\s*stream\r?\n""", setOf(RegexOption.DOT_MATCHES_ALL))
                var pageIdx = 1
                for (match in streamRegex.findAll(rawLatin)) {
                    val dict = match.groupValues[1]
                    val startOffset = match.range.last + 1
                    val endIdx = rawLatin.indexOf("endstream", startOffset)
                    if (endIdx <= startOffset) continue

                    val streamBytes = bytes.copyOfRange(startOffset, endIdx)
                    val decoded = if (dict.contains("/FlateDecode")) {
                        inflateSafe(streamBytes)
                    } else {
                        String(streamBytes, Charsets.ISO_8859_1)
                    }
                    if (decoded.contains("BT") && decoded.contains("ET")) {
                        val extracted = parsePdfTextOperators(decoded)
                        if (extracted.isNotBlank()) {
                            result[pageIdx] = extracted
                            pageIdx++
                        }
                    }
                }
            } catch (_: Exception) {
                // Scanned image-only or encrypted PDF streams gracefully return empty map
            }
            result
        }

        suspend fun searchInPdf(pdfFile: File, query: String): List<PdfSearchMatch> =
            withContext(Dispatchers.Default) {
                val q = query.trim()
                if (q.isEmpty()) return@withContext emptyList()
                val pages = extractTextByPage(pdfFile)
                val matches = ArrayList<PdfSearchMatch>()
                for ((page, txt) in pages) {
                    var idx = txt.indexOf(q, ignoreCase = true)
                    while (idx >= 0) {
                        val s = (idx - 35).coerceAtLeast(0)
                        val e = (idx + q.length + 45).coerceAtMost(txt.length)
                        val snippet = txt.substring(s, e).replace('\n', ' ').trim()
                        matches.add(PdfSearchMatch(page, snippet))
                        idx = txt.indexOf(q, idx + q.length, ignoreCase = true)
                        if (matches.size >= 150) return@withContext matches
                    }
                }
                matches
            }

        private fun inflateSafe(input: ByteArray): String {
            return try {
                val trimmed = if (input.isNotEmpty() && (input[input.size - 1] == '\n'.code.toByte() || input[input.size - 1] == '\r'.code.toByte())) {
                    input.dropLastWhile { it == '\n'.code.toByte() || it == '\r'.code.toByte() }.toByteArray()
                } else input
                val inflater = Inflater()
                inflater.setInput(trimmed)
                val out = ByteArrayOutputStream()
                val buf = ByteArray(4096)
                while (!inflater.finished() && !inflater.needsInput()) {
                    val count = inflater.inflate(buf)
                    if (count <= 0) break
                    out.write(buf, 0, count)
                }
                inflater.end()
                String(out.toByteArray(), Charsets.ISO_8859_1)
            } catch (_: Exception) {
                ""
            }
        }

        private fun parsePdfTextOperators(content: String): String {
            val sb = StringBuilder()
            val literalRegex = Regex("""\((?:\\.|[^\\)])*\)""")
            for (m in literalRegex.findAll(content)) {
                val inner = m.value.substring(1, m.value.length - 1)
                    .replace("\\(", "(")
                    .replace("\\)", ")")
                    .replace("\\\\", "\\")
                if (inner.isNotBlank()) {
                    sb.append(inner).append(' ')
                }
            }
            return sb.toString().replace(Regex("\\s+"), " ").trim()
        }
    }
}
