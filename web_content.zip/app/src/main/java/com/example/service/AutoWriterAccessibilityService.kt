package com.example.service

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Optional system accessibility service that allows AutoWriter to type directly
 * into any active input field across any app on the user's device when requested.
 */
class AutoWriterAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        FloatingBridge.activeAccessibilityService = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Track focused editable nodes if needed
    }

    override fun onInterrupt() {
        // Service interrupted
    }

    override fun onDestroy() {
        super.onDestroy()
        if (FloatingBridge.activeAccessibilityService === this) {
            FloatingBridge.activeAccessibilityService = null
        }
    }

    /**
     * Injects text directly into the currently focused input field of whichever
     * application is on screen.
     */
    fun injectTextIntoFocusedField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focusedNode = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false

        return if (focusedNode.isEditable) {
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            val success = focusedNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
            focusedNode.recycle()
            root.recycle()
            success
        } else {
            focusedNode.recycle()
            root.recycle()
            false
        }
    }
}
