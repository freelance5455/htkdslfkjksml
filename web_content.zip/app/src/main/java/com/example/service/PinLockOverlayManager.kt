package com.example.service

import android.accessibilityservice.AccessibilityService
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.example.admin.AntiTheftDeviceAdminReceiver
import com.example.data.SecurityPreferences
import com.example.model.ProtectedSection

class PinLockOverlayManager(
    private val context: Context,
    private val securityPreferences: SecurityPreferences,
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var overlayView: View? = null
    private var currentSection: ProtectedSection? = null
    private var enteredPin = StringBuilder()
    private var failedAttempts = 0
    private var lockoutTimer: CountDownTimer? = null
    private var isLockedOut = false

    private val dotViews = mutableListOf<View>()
    private var statusTextView: TextView? = null
    private var keypadEnabled = true

    val isShowing: Boolean
        get() = overlayView != null

    fun show(
        section: ProtectedSection,
        accessibilityService: AccessibilityService? = null,
        isTestMode: Boolean = false,
    ) {
        mainHandler.post {
            if (overlayView != null) {
                return@post
            }
            currentSection = section
            enteredPin.clear()
            isLockedOut = false
            keypadEnabled = true

            val root = buildOverlayView(
                section = section,
                accessibilityService = accessibilityService,
                isTestMode = isTestMode,
            )

            val windowType = when {
                Settings.canDrawOverlays(context) -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    } else {
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_PHONE
                    }
                }
                accessibilityService != null -> WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                else -> return@post
            }

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                windowType,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_SECURE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.CENTER
            }

            runCatching {
                windowManager.addView(root, params)
                overlayView = root
                root.requestFocus()
            }.onFailure {
                // Fallback to TYPE_ACCESSIBILITY_OVERLAY if OEM blocks TYPE_APPLICATION_OVERLAY on power dialog
                if (accessibilityService != null && windowType != WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY) {
                    params.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                    runCatching {
                        windowManager.addView(root, params)
                        overlayView = root
                        root.requestFocus()
                    }
                }
            }
        }
    }

    fun dismiss() {
        mainHandler.post {
            lockoutTimer?.cancel()
            lockoutTimer = null
            overlayView?.let { view ->
                runCatching { windowManager.removeViewImmediate(view) }
            }
            overlayView = null
            currentSection = null
            dotViews.clear()
            statusTextView = null
            enteredPin.clear()
        }
    }

    private fun buildOverlayView(
        section: ProtectedSection,
        accessibilityService: AccessibilityService?,
        isTestMode: Boolean,
    ): View {
        val root = object : FrameLayout(context) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                    handleCancel(accessibilityService, isTestMode)
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }.apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setBackgroundColor(Color.parseColor("#F5090E17"))
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(40), dp(24), dp(32))
        }

        val badge = TextView(context).apply {
            text = if (isTestMode) "PRUEBA DE BLOQUEO" else "PROTECCIÓN ANTIRROBO"
            setTextColor(Color.parseColor("#34D399"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1A10B981"))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.parseColor("#4D10B981"))
            }
        }
        container.addView(badge, wrapParams(bottomMargin = dp(18)))

        val titleView = TextView(context).apply {
            text = section.overlayTitle
            setTextColor(Color.parseColor("#F8FAFC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        container.addView(titleView, wrapParams(bottomMargin = dp(8)))

        val subtitleView = TextView(context).apply {
            text = section.overlaySubtitle
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
        }
        container.addView(subtitleView, wrapParams(bottomMargin = dp(28)))

        // 6 PIN dots
        dotViews.clear()
        val dotsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        repeat(6) {
            val dot = View(context).apply {
                background = createDotDrawable(filled = false)
            }
            val lp = LinearLayout.LayoutParams(dp(16), dp(16)).apply {
                setMargins(dp(8), 0, dp(8), 0)
            }
            dotViews.add(dot)
            dotsRow.addView(dot, lp)
        }
        container.addView(dotsRow, wrapParams(bottomMargin = dp(16)))

        statusTextView = TextView(context).apply {
            text = "Ingresa tu PIN de 6 dígitos"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            minHeight = dp(24)
        }
        container.addView(statusTextView, wrapParams(bottomMargin = dp(24)))

        // Numeric Keypad
        val keypad = GridLayout(context).apply {
            columnCount = 3
            rowCount = 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }

        val keys = listOf(
            "1", "2", "3",
            "4", "5", "6",
            "7", "8", "9",
            "BORRAR", "0", "⌫",
        )

        keys.forEach { label ->
            val keyButton = Button(context).apply {
                text = label
                isAllCaps = false
                setTextColor(
                    when (label) {
                        "BORRAR" -> Color.parseColor("#94A3B8")
                        "⌫" -> Color.parseColor("#F59E0B")
                        else -> Color.parseColor("#F8FAFC")
                    },
                )
                setTextSize(
                    TypedValue.COMPLEX_UNIT_SP,
                    if (label == "BORRAR") 12f else 22f,
                )
                typeface = if (label == "BORRAR") Typeface.DEFAULT_BOLD else Typeface.MONOSPACE
                background = GradientDrawable().apply {
                    setColor(
                        if (label == "BORRAR" || label == "⌫") {
                            Color.parseColor("#111827")
                        } else {
                            Color.parseColor("#1E293B")
                        },
                    )
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(1), Color.parseColor("#2D3A4F"))
                }
                setOnClickListener {
                    onKeyPressed(label, accessibilityService, isTestMode)
                }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = dp(82)
                height = dp(64)
                setMargins(dp(8), dp(8), dp(8), dp(8))
            }
            keypad.addView(keyButton, lp)
        }
        container.addView(keypad, wrapParams(bottomMargin = dp(24)))

        val cancelButton = Button(context).apply {
            text = if (isTestMode) "Cerrar prueba" else "Salir del apartado"
            isAllCaps = false
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(dp(24), dp(12), dp(24), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#334155"))
            }
            setOnClickListener {
                handleCancel(accessibilityService, isTestMode)
            }
        }
        container.addView(cancelButton, wrapParams(bottomMargin = 0))

        val containerParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER,
        )
        root.addView(container, containerParams)
        return root
    }

    private fun onKeyPressed(
        label: String,
        accessibilityService: AccessibilityService?,
        isTestMode: Boolean,
    ) {
        if (!keypadEnabled || isLockedOut) return

        when (label) {
            "BORRAR" -> {
                enteredPin.clear()
                updateDots()
                statusTextView?.text = "Ingresa tu PIN de 6 dígitos"
                statusTextView?.setTextColor(Color.parseColor("#94A3B8"))
            }
            "⌫" -> {
                if (enteredPin.isNotEmpty()) {
                    enteredPin.deleteCharAt(enteredPin.length - 1)
                    updateDots()
                }
            }
            else -> {
                if (enteredPin.length < 6) {
                    enteredPin.append(label)
                    updateDots()
                    if (enteredPin.length == 6) {
                        verifyEnteredPin(accessibilityService, isTestMode)
                    }
                }
            }
        }
    }

    private fun verifyEnteredPin(
        accessibilityService: AccessibilityService?,
        isTestMode: Boolean,
    ) {
        val candidate = enteredPin.toString()
        if (securityPreferences.verifyPin(candidate)) {
            failedAttempts = 0
            currentSection?.let { section ->
                if (!isTestMode) {
                    securityPreferences.grantTemporaryAccess(section)
                }
            }
            dismiss()
        } else {
            failedAttempts += 1
            enteredPin.clear()
            updateDots(error = true)

            if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
                triggerLockoutAndLockScreen()
            } else {
                val remaining = MAX_FAILED_ATTEMPTS - failedAttempts
                statusTextView?.text = "PIN incorrecto ($remaining intentos restantes)"
                statusTextView?.setTextColor(Color.parseColor("#EF4444"))
            }
        }
    }

    private fun triggerLockoutAndLockScreen() {
        isLockedOut = true
        keypadEnabled = false
        failedAttempts = 0

        // Lock device immediately if Device Admin is active
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        val adminComponent = ComponentName(context, AntiTheftDeviceAdminReceiver::class.java)
        if (dpm != null && dpm.isAdminActive(adminComponent)) {
            runCatching { dpm.lockNow() }
        }

        lockoutTimer?.cancel()
        lockoutTimer = object : CountDownTimer(LOCKOUT_DURATION_MS, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = (millisUntilFinished / 1000L) + 1
                statusTextView?.text = "Demasiados intentos. Espera ${seconds}s"
                statusTextView?.setTextColor(Color.parseColor("#F59E0B"))
            }

            override fun onFinish() {
                isLockedOut = false
                keypadEnabled = true
                enteredPin.clear()
                updateDots()
                statusTextView?.text = "Ingresa tu PIN de 6 dígitos"
                statusTextView?.setTextColor(Color.parseColor("#94A3B8"))
            }
        }.start()
    }

    private fun handleCancel(
        accessibilityService: AccessibilityService?,
        isTestMode: Boolean,
    ) {
        val section = currentSection
        dismiss()
        if (!isTestMode && accessibilityService != null) {
            if (section == ProtectedSection.POWER_AND_REBOOT) {
                accessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                mainHandler.postDelayed({
                    accessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                }, 120L)
            } else {
                accessibilityService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            }
        }
    }

    private fun updateDots(error: Boolean = false) {
        val count = enteredPin.length
        dotViews.forEachIndexed { index, view ->
            view.background = createDotDrawable(
                filled = index < count,
                error = error,
            )
        }
    }

    private fun createDotDrawable(filled: Boolean, error: Boolean = false): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            when {
                error -> {
                    setColor(Color.parseColor("#33EF4444"))
                    setStroke(dp(2), Color.parseColor("#EF4444"))
                }
                filled -> {
                    setColor(Color.parseColor("#10B981"))
                    setStroke(dp(2), Color.parseColor("#34D399"))
                }
                else -> {
                    setColor(Color.TRANSPARENT)
                    setStroke(dp(2), Color.parseColor("#475569"))
                }
            }
        }
    }

    private fun wrapParams(bottomMargin: Int): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply {
            this.bottomMargin = bottomMargin
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            context.resources.displayMetrics,
        ).toInt()
    }

    companion object {
        private const val MAX_FAILED_ATTEMPTS = 5
        private const val LOCKOUT_DURATION_MS = 30_000L
    }
}
