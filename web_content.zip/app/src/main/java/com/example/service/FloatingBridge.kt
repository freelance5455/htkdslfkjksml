package com.example.service

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Commands sent from Floating Overlay or Accessibility Service to ViewModel/Engine
 */
sealed interface FloatingCommand {
    data object Start : FloatingCommand
    data object Pause : FloatingCommand
    data object Stop : FloatingCommand
    data object ManualRepeat : FloatingCommand
    data object NextWord : FloatingCommand
    data class UpdateSpeed(val speedMs: Long) : FloatingCommand
    data class SetRandomMode(val enabled: Boolean) : FloatingCommand
}

/**
 * Thread-safe singleton bridge between UI, Floating Overlay, and Accessibility Service.
 */
object FloatingBridge {
    private val _commands = MutableSharedFlow<FloatingCommand>(extraBufferCapacity = 16)
    val commands: SharedFlow<FloatingCommand> = _commands.asSharedFlow()

    private val _currentStatusText = MutableStateFlow("جاهز للبدء")
    val currentStatusText: StateFlow<String> = _currentStatusText.asStateFlow()

    private val _currentWordText = MutableStateFlow("")
    val currentWordText: StateFlow<String> = _currentWordText.asStateFlow()

    private val _isTypingActive = MutableStateFlow(false)
    val isTypingActive: StateFlow<Boolean> = _isTypingActive.asStateFlow()

    private val _isOverlayActive = MutableStateFlow(false)
    val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

    fun sendCommand(command: FloatingCommand) {
        _commands.tryEmit(command)
    }

    fun updateStatus(status: String, word: String, isTyping: Boolean) {
        _currentStatusText.value = status
        _currentWordText.value = word
        _isTypingActive.value = isTyping
    }

    fun setOverlayActive(active: Boolean) {
        _isOverlayActive.value = active
    }

    // Reference to active accessibility service if connected
    var activeAccessibilityService: AutoWriterAccessibilityService? = null
}
