package com.example.service

import com.example.model.ProtectedSection
import java.text.Normalizer

data class WindowSnapshot(
    val packageName: String,
    val className: String,
    val windowTitle: String,
    val texts: List<String>,
)

object ScreenInterceptorDetector {

    private val settingsPackages = setOf(
        "com.android.settings",
        "com.google.android.settings",
        "com.transsion.settings",
        "com.tecno.settings",
        "com.itel.settings",
        "com.infinix.settings",
    )

    private val installerPackages = setOf(
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.transsion.packageinstaller",
    )

    private val systemUiPackages = setOf(
        "com.android.systemui",
        "com.transsion.systemui",
        "android",
    )

    private val powerDialogClassTokens = listOf(
        "globalactions",
        "poweroff",
        "shutdown",
        "reboot",
        "powermenu",
    )

    private val powerMenuKeywords = listOf(
        "apagar",
        "reiniciar",
        "power off",
        "restart",
        "emergencia",
        "emergency",
        "desliza para apagar",
        "tocar para apagar",
        "slide to power off",
        "reboot",
    )

    private val rebootSettingsKeywords = listOf(
        "funcion de memoria",
        "fusion de memoria",
        "memfusion",
        "memory fusion",
        "expansion de ram",
        "ram virtual",
        "reiniciar ahora",
        "restart now",
        "reiniciar para aplicar",
        "restart to apply",
        "aplicar y reiniciar",
        "apply and restart",
        "reiniciar dispositivo",
        "reiniciar el telefono",
        "reiniciar telefono",
        "reboot now",
        "restablecer datos de fabrica",
        "restablecer de fabrica",
        "borrar todos los datos",
        "factory data reset",
    )

    private val deviceAdminKeywords = listOf(
        "aplicaciones de administracion",
        "aplicaciones del administrador",
        "administradores del dispositivo",
        "administracion del dispositivo",
        "device admin apps",
        "device administrators",
        "desactivar esta aplicacion de administracion",
        "desactivar esta app de administracion",
        "deactivate this admin app",
        "desactivar y desinstalar",
    )

    private val accessibilityScreenKeywords = listOf(
        "accesibilidad",
        "accessibility",
        "servicios descargados",
        "downloaded services",
        "apps descargadas",
        "downloaded apps",
    )

    private val desktopSettingsKeywords = listOf(
        "configuracion de escritorio",
        "configuracion del escritorio",
        "ajustes de escritorio",
        "ajustes de pantalla de inicio",
        "configuracion de pantalla de inicio",
        "desktop settings",
        "home settings",
        "launcher settings",
    )

    fun detect(
        snapshot: WindowSnapshot,
        ownPackageName: String,
        isDeviceAdminActive: Boolean,
        isAccessibilityActive: Boolean,
    ): ProtectedSection? {
        val pkg = snapshot.packageName.lowercase()
        if (pkg.isBlank() || pkg == ownPackageName.lowercase()) return null

        val cls = snapshot.className.lowercase()
        val normalizedTitle = normalize(snapshot.windowTitle)
        val normalizedTexts = snapshot.texts
            .asSequence()
            .map { normalize(it) }
            .filter { it.isNotBlank() }
            .toList()
        val combinedText = buildString {
            if (normalizedTitle.isNotBlank()) {
                append(normalizedTitle)
                append('\n')
            }
            normalizedTexts.forEach {
                append(it)
                append('\n')
            }
        }

        // 1. Power / Reboot dialog or settings requiring reboot (e.g. Tecno HiOS MemFusion)
        if (pkg in systemUiPackages) {
            val isPowerClass = powerDialogClassTokens.any { cls.contains(it) }
            val matchedPowerTokens = powerMenuKeywords.count { token ->
                normalizedTexts.any { it == token || it.contains(token) } || normalizedTitle.contains(token)
            }
            if (isPowerClass || matchedPowerTokens >= 2) {
                return ProtectedSection.POWER_AND_REBOOT
            }
        }

        val isSettingsOrSystem = pkg in settingsPackages ||
            pkg.startsWith("com.transsion.") ||
            pkg.startsWith("com.tecno.") ||
            pkg in systemUiPackages

        if (isSettingsOrSystem && rebootSettingsKeywords.any { combinedText.contains(it) }) {
            return ProtectedSection.POWER_AND_REBOOT
        }

        // 2. Accessibility & Device Admin Settings (plus App Info / Uninstall protection for EscudoPIN)
        if (pkg in settingsPackages || pkg in installerPackages || pkg == "android") {
            val isDeviceAdminScreen = cls.contains("deviceadmin") ||
                deviceAdminKeywords.any { combinedText.contains(it) }

            if (isDeviceAdminScreen) {
                // Allow initial Device Admin activation if not yet active; protect once active.
                if (isDeviceAdminActive) {
                    return ProtectedSection.ACCESSIBILITY_AND_ADMIN
                }
                // Even if not active, protect the list screen if user already granted Accessibility
                // unless it's specifically the DeviceAdminAdd prompt.
                if (!cls.contains("deviceadminadd")) {
                    return ProtectedSection.ACCESSIBILITY_AND_ADMIN
                }
            }

            val isAccessibilityClass = cls.contains("accessibility")
            val isAccessibilityText = accessibilityScreenKeywords.any { token ->
                normalizedTitle.contains(token) || normalizedTexts.any { it == token || it.startsWith(token) }
            }
            if (isAccessibilityActive && (isAccessibilityClass || isAccessibilityText)) {
                return ProtectedSection.ACCESSIBILITY_AND_ADMIN
            }

            val mentionsEscudoPin = combinedText.contains("escudopin")
            val isDangerAppAction = combinedText.contains("desinstalar") ||
                combinedText.contains("uninstall") ||
                combinedText.contains("forzar detencion") ||
                combinedText.contains("force stop") ||
                combinedText.contains("informacion de la aplicacion") ||
                combinedText.contains("app info")

            if (mentionsEscudoPin && isDangerAppAction) {
                return ProtectedSection.ACCESSIBILITY_AND_ADMIN
            }
        }

        // 3. Desktop / Home Launcher Settings ("Configuración de Escritorio" on Tecno HiOS & others)
        val isLauncherPkg = pkg.contains("launcher") || pkg.contains("hilauncher") || pkg.contains("xoslauncher")
        if (isLauncherPkg || pkg in settingsPackages) {
            val hasDesktopKeyword = desktopSettingsKeywords.any { combinedText.contains(it) }
            val isLauncherSettingsClass = isLauncherPkg &&
                (cls.contains("settings") || cls.contains("preference") || cls.contains("desktop") || cls.contains("homesettings"))
            if (hasDesktopKeyword || isLauncherSettingsClass) {
                return ProtectedSection.DESKTOP_SETTINGS
            }
        }

        return null
    }

    internal fun normalize(input: String): String {
        if (input.isBlank()) return ""
        val decomposed = Normalizer.normalize(input, Normalizer.Form.NFD)
        return Regex("\\p{InCombiningDiacriticalMarks}+")
            .replace(decomposed, "")
            .lowercase()
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
