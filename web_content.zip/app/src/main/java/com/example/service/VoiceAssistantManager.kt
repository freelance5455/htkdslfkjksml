package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.VoiceLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceAssistantManager(private val context: Context) : RecognitionListener, TextToSpeech.OnInitListener {

    private val TAG = "VoiceAssistantManager"

    // Speech Recognizer
    private var speechRecognizer: SpeechRecognizer? = null
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _speechRms = MutableStateFlow(0f)
    val speechRms: StateFlow<Float> = _speechRms.asStateFlow()

    private val _recognizedPartialText = MutableStateFlow("")
    val recognizedPartialText: StateFlow<String> = _recognizedPartialText.asStateFlow()

    // Text to Speech
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var currentLanguage = VoiceLanguage.ENGLISH
    private var speechSpeed = 1.0f
    private var speechPitch = 1.05f // Slightly futuristic crisp tone

    // Callbacks
    var onCommandRecognized: ((String) -> Unit)? = null
    var onWakeWordDetected: (() -> Unit)? = null
    var onErrorOccurred: ((String) -> Unit)? = null

    init {
        initTts()
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to instantiate TextToSpeech", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            applyTtsLanguage(currentLanguage)
            tts?.setSpeechRate(speechSpeed)
            tts?.setPitch(speechPitch)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
            Log.d(TAG, "TTS initialized successfully.")
        } else {
            Log.e(TAG, "TTS initialization failed with status $status")
        }
    }

    fun setLanguage(lang: VoiceLanguage) {
        currentLanguage = lang
        if (isTtsInitialized) {
            applyTtsLanguage(lang)
        }
    }

    private fun applyTtsLanguage(lang: VoiceLanguage) {
        tts?.let { engine ->
            val locale = when (lang) {
                VoiceLanguage.HINDI -> Locale("hi", "IN")
                VoiceLanguage.HINGLISH -> Locale("en", "IN")
                VoiceLanguage.ENGLISH -> Locale.US
            }
            var result = engine.setLanguage(locale)
            if (lang == VoiceLanguage.HINDI && (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)) {
                result = engine.setLanguage(Locale("hi"))
            }
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(TAG, "Locale $locale not fully supported, falling back to default")
                engine.setLanguage(Locale.getDefault())
            }

            // Find best matching voice for Hindi
            try {
                if (lang == VoiceLanguage.HINDI) {
                    val hindiVoice = engine.voices?.firstOrNull { it.locale.language == "hi" }
                    if (hindiVoice != null) {
                        engine.voice = hindiVoice
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Voice selection fallback", e)
            }
        }
    }

    fun setSpeechSpeed(speed: Float) {
        speechSpeed = speed.coerceIn(0.5f, 2.0f)
        tts?.setSpeechRate(speechSpeed)
    }

    fun setSpeechPitch(pitch: Float) {
        speechPitch = pitch.coerceIn(0.5f, 1.8f)
        tts?.setPitch(speechPitch)
    }

    /**
     * Speaks text using Android TextToSpeech.
     * Automatically adjusts language to Hindi when Devanagari script or Hindi mode is active.
     */
    fun speak(text: String, flush: Boolean = true) {
        if (!isTtsInitialized || tts == null) {
            Log.w(TAG, "TTS not ready to speak: $text")
            return
        }

        // Auto-detect Hindi script in the text
        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        if (hasDevanagari || currentLanguage == VoiceLanguage.HINDI) {
            val res = tts?.setLanguage(Locale("hi", "IN"))
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("hi"))
            }
            try {
                val hiVoice = tts?.voices?.firstOrNull { it.locale.language == "hi" }
                if (hiVoice != null) tts?.voice = hiVoice
            } catch (e: Exception) {}
        } else if (currentLanguage == VoiceLanguage.HINGLISH) {
            tts?.setLanguage(Locale("en", "IN"))
        } else {
            tts?.setLanguage(Locale.US)
        }

        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val utteranceId = "xtra_utterance_${System.currentTimeMillis()}"
        val bundle = Bundle()
        tts?.speak(text, queueMode, bundle, utteranceId)
    }

    /**
     * Interrupts XTRA speech immediately.
     */
    fun stopSpeaking() {
        if (tts != null) {
            tts?.stop()
            _isSpeaking.value = false
        }
    }

    /**
     * Starts listening for speech commands or wake-word.
     */
    fun startListening() {
        // Stop any active speech so microphone does not pick up TTS
        stopSpeaking()

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onErrorOccurred?.invoke("Speech recognition is not available on this device.")
            return
        }

        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(this@VoiceAssistantManager)
                }
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)

                val langTag = when (currentLanguage) {
                    VoiceLanguage.HINDI -> "hi-IN"
                    VoiceLanguage.HINGLISH -> "en-IN"
                    VoiceLanguage.ENGLISH -> "en-US"
                }
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
            }

            speechRecognizer?.startListening(intent)
            _isListening.value = true
            _recognizedPartialText.value = ""
        } catch (e: Exception) {
            Log.e(TAG, "Error starting speech recognizer", e)
            _isListening.value = false
            onErrorOccurred?.invoke(e.localizedMessage ?: "Failed to start speech recognizer")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recognizer", e)
        }
        _isListening.value = false
        _speechRms.value = 0f
    }

    fun cancelListening() {
        try {
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.e(TAG, "Error cancelling recognizer", e)
        }
        _isListening.value = false
        _speechRms.value = 0f
    }

    // RecognitionListener implementation
    override fun onReadyForSpeech(params: Bundle?) {
        _isListening.value = true
    }

    override fun onBeginningOfSpeech() {
        _isListening.value = true
    }

    override fun onRmsChanged(rmsdB: Float) {
        // Normalize rmsdB (-2 to 10 typical) to 0.0 - 1.0
        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        _speechRms.value = normalized
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        _isListening.value = false
        _speechRms.value = 0f
    }

    override fun onError(error: Int) {
        _isListening.value = false
        _speechRms.value = 0f
        val msg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Try speaking clearly."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech timed out."
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network required for speech recognition."
            else -> "Speech recognition paused."
        }
        Log.w(TAG, "SpeechRecognizer error: $error -> $msg")
    }

    override fun onResults(results: Bundle?) {
        _isListening.value = false
        _speechRms.value = 0f
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val spokenText = matches[0].trim()
            _recognizedPartialText.value = spokenText

            // Check wake-word activation
            val lower = spokenText.lowercase()
            if (lower.startsWith("hey xtra") || lower.startsWith("ok xtra") || lower.startsWith("xtra")) {
                onWakeWordDetected?.invoke()
                val cleanCommand = spokenText
                    .replaceFirst("(?i)hey\\s+xtra[\\s,:]*".toRegex(), "")
                    .replaceFirst("(?i)ok\\s+xtra[\\s,:]*".toRegex(), "")
                    .replaceFirst("(?i)xtra[\\s,:]*".toRegex(), "")
                    .trim()
                if (cleanCommand.isNotBlank()) {
                    onCommandRecognized?.invoke(cleanCommand)
                } else {
                    onCommandRecognized?.invoke("Hello XTRA")
                }
            } else {
                onCommandRecognized?.invoke(spokenText)
            }
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            _recognizedPartialText.value = matches[0]
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying VoiceAssistantManager", e)
        }
    }
}
