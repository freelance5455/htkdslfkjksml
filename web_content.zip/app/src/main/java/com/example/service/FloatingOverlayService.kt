package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Android Floating Overlay Service ("الشاشة المنبثقة")
 * Provides a persistent draggable floating control window over other applications.
 */
class FloatingOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingRootView: View? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundServiceNotification()
        createFloatingView()
        FloatingBridge.setOverlayActive(true)
        observeBridge()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "autowriter_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "AutoWriter Floating Window",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "الشاشة المنبثقة للكاتب التلقائي الذكي"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("الكاتب التلقائي الذكي نشط")
            .setContentText("الشاشة المنبثقة جاهزة للكتابة التلقائية")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .setOngoing(true)
            .build()

        startForeground(1001, notification)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createFloatingView() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        val container = FrameLayout(this)

        // Bubble View (Compact)
        val bubbleView = createBubbleView()
        // Expanded Panel View
        val panelView = createExpandedPanelView()
        panelView.visibility = View.GONE

        container.addView(bubbleView)
        container.addView(panelView)

        // Dragging & Click Handling
        bubbleView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(container, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val deltaX = Math.abs(event.rawX - initialTouchX)
                    val deltaY = Math.abs(event.rawY - initialTouchY)
                    if (deltaX < 15 && deltaY < 15) {
                        // Click event: toggle expanded state
                        isExpanded = true
                        bubbleView.visibility = View.GONE
                        panelView.visibility = View.VISIBLE
                    }
                    true
                }
                else -> false
            }
        }

        floatingRootView = container
        try {
            windowManager.addView(container, params)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر تشغيل الشاشة المنبثقة: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun createBubbleView(): View {
        val bubble = TextView(this).apply {
            text = "✍️"
            textSize = 24f
            gravity = Gravity.CENTER
            val size = (56 * resources.displayMetrics.density).toInt()
            layoutParams = FrameLayout.LayoutParams(size, size)

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#4F46E5"))
                setStroke(4, Color.parseColor("#67E8F9"))
            }
            background = bg
            elevation = 16f
        }
        return bubble
    }

    private fun createExpandedPanelView(): View {
        val dp = resources.displayMetrics.density
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#151F38"))
                cornerRadius = 16 * dp
                setStroke((1.5 * dp).toInt(), Color.parseColor("#67E8F9"))
            }
            background = bg
            setPadding((14 * dp).toInt(), (12 * dp).toInt(), (14 * dp).toInt(), (12 * dp).toInt())
            elevation = 20f
        }

        // Header with title and minimize button
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "الكاتب التلقائي ⚡"
            setTextColor(Color.WHITE)
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val closeBtn = Button(this).apply {
            text = "✖"
            textSize = 12f
            setTextColor(Color.parseColor("#F43F5E"))
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                stopSelf()
            }
        }
        val minBtn = Button(this).apply {
            text = "🔽"
            textSize = 12f
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener {
                isExpanded = false
                (floatingRootView as? FrameLayout)?.let { container ->
                    container.getChildAt(0).visibility = View.VISIBLE
                    container.getChildAt(1).visibility = View.GONE
                }
            }
        }
        header.addView(title)
        header.addView(minBtn)
        header.addView(closeBtn)
        panel.addView(header)

        // Status text
        val statusText = TextView(this).apply {
            id = View.generateViewId()
            tag = "overlay_status_text"
            text = "جاهز للكتابة"
            setTextColor(Color.parseColor("#67E8F9"))
            textSize = 13f
            setPadding(0, (4 * dp).toInt(), 0, (6 * dp).toInt())
        }
        panel.addView(statusText)

        // Control Buttons Row
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, (4 * dp).toInt(), 0, (4 * dp).toInt())
        }

        val startBtn = Button(this).apply {
            text = "▶ بدء"
            setTextColor(Color.WHITE)
            val btnBg = GradientDrawable().apply {
                setColor(Color.parseColor("#059669"))
                cornerRadius = 8 * dp
            }
            background = btnBg
            textSize = 12f
            setOnClickListener {
                FloatingBridge.sendCommand(FloatingCommand.Start)
            }
            layoutParams = LinearLayout.LayoutParams(0, (38 * dp).toInt(), 1f).apply {
                marginEnd = (4 * dp).toInt()
            }
        }

        val pauseBtn = Button(this).apply {
            text = "⏸ إيقاف"
            setTextColor(Color.WHITE)
            val btnBg = GradientDrawable().apply {
                setColor(Color.parseColor("#FBBF24"))
                cornerRadius = 8 * dp
            }
            background = btnBg
            textSize = 12f
            setOnClickListener {
                FloatingBridge.sendCommand(FloatingCommand.Pause)
            }
            layoutParams = LinearLayout.LayoutParams(0, (38 * dp).toInt(), 1f).apply {
                marginEnd = (4 * dp).toInt()
            }
        }

        val repeatBtn = Button(this).apply {
            text = "🔁 تكرار يدوي"
            setTextColor(Color.WHITE)
            val btnBg = GradientDrawable().apply {
                setColor(Color.parseColor("#0284C7"))
                cornerRadius = 8 * dp
            }
            background = btnBg
            textSize = 11f
            setOnClickListener {
                FloatingBridge.sendCommand(FloatingCommand.ManualRepeat)
            }
            layoutParams = LinearLayout.LayoutParams(0, (38 * dp).toInt(), 1.2f)
        }

        btnRow.addView(startBtn)
        btnRow.addView(pauseBtn)
        btnRow.addView(repeatBtn)
        panel.addView(btnRow)

        // Quick Paste / Copy row
        val copyBtn = Button(this).apply {
            text = "📋 نسخ الكلمة الحالية للحافظة"
            setTextColor(Color.parseColor("#A5B4FC"))
            val btnBg = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = 8 * dp
                setStroke((1 * dp).toInt(), Color.parseColor("#4F46E5"))
            }
            background = btnBg
            textSize = 11f
            setOnClickListener {
                val currentWord = FloatingBridge.currentWordText.value
                if (currentWord.isNotEmpty()) {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("AutoWriter", currentWord))
                    Toast.makeText(this@FloatingOverlayService, "تم نسخ: $currentWord", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this@FloatingOverlayService, "لا توجد كلمة محددة", Toast.LENGTH_SHORT).show()
                }
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (36 * dp).toInt()
            ).apply {
                topMargin = (6 * dp).toInt()
            }
        }
        panel.addView(copyBtn)

        return panel
    }

    private fun observeBridge() {
        serviceScope.launch {
            FloatingBridge.currentStatusText.collect { status ->
                floatingRootView?.findViewWithTag<TextView>("overlay_status_text")?.text = status
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        FloatingBridge.setOverlayActive(false)
        floatingRootView?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        floatingRootView = null
    }
}
