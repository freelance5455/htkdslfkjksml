package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.ui.LockOverlayActivity

object LockOverlayManager {

    private var lastTriggerTime: Long = 0L
    private const val MIN_TRIGGER_INTERVAL_MS = 1200L

    fun triggerLock(context: Context, reason: String, targetPackage: String = "") {
        val now = System.currentTimeMillis()
        if (now - lastTriggerTime < MIN_TRIGGER_INTERVAL_MS) {
            return
        }
        lastTriggerTime = now

        // Vibrate alert
        vibrateAlert(context)

        // Launch full-screen lock overlay activity
        val intent = Intent(context, LockOverlayActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            putExtra(LockOverlayActivity.EXTRA_REASON, reason)
            putExtra(LockOverlayActivity.EXTRA_PACKAGE, targetPackage)
        }
        context.startActivity(intent)
    }

    private fun vibrateAlert(context: Context) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            vibrator?.let {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val timings = longArrayOf(0, 150, 80, 150)
                    val amplitudes = intArrayOf(0, 255, 0, 255)
                    it.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                } else {
                    @Suppress("DEPRECATION")
                    it.vibrate(250)
                }
            }
        } catch (_: Exception) {}
    }
}
