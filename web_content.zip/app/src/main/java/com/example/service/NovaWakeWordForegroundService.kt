package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.assistant.NovaDeviceController
import com.example.assistant.ParsedVoiceIntent
import com.example.data.model.AnswerLength
import com.example.data.model.AssistantMode
import com.example.data.remote.GeminiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

/**
 * Foreground Microphone Service implementing hands-free "Hello Nova" wake-word listening
 * and spoken response execution when explicitly activated by the user.
 */
class NovaWakeWordForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var deviceController: NovaDeviceController

    private var wakePhrase: String = "hello aura"
    private var awaitingFollowUpCommand: Boolean = false
    private var isDestroyed = false

    override fun onCreate() {
        super.onCreate()
        deviceController = NovaDeviceController(applicationContext)
        createNotificationChannel()
        initTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopWakeService()
            return START_NOT_STICKY
        }

        val customPhrase = intent?.getStringExtra(EXTRA_WAKE_PHRASE)?.trim()?.lowercase(Locale.ROOT)
        if (!customPhrase.isNullOrBlank()) {
            wakePhrase = customPhrase
        }

        val notification = buildForegroundNotification("Listening for '${wakePhrase.replaceFirstChar { it.uppercase() }}'")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        acquirePartialWakeLock()
        _isRunning.value = true
        _statusText.value = "Active • Say \"${wakePhrase.replaceFirstChar { it.uppercase() }}\""
        startListeningCycle()

        return START_STICKY
    }

    private fun acquirePartialWakeLock() {
        try {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
                wakeLock = pm?.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "NovaAI::WakeWordSessionLock"
                )?.apply {
                    setReferenceCounted(false)
                    // Bounded 30-minute safety timeout per activation session to protect battery
                    acquire(30 * 60 * 1000L)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale.forLanguageTag("en-IN")
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun startListeningCycle() {
        if (isDestroyed || !_isRunning.value) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            _statusText.value = "SpeechRecognizer unavailable on this device"
            return
        }

        mainHandler.post {
            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(applicationContext).apply {
                        setRecognitionListener(object : RecognitionListener {
                            override fun onReadyForSpeech(params: Bundle?) {}
                            override fun onBeginningOfSpeech() {}
                            override fun onRmsChanged(rmsdB: Float) {}
                            override fun onBufferReceived(buffer: ByteArray?) {}
                            override fun onEndOfSpeech() {}

                            override fun onError(error: Int) {
                                scheduleNextListen(1200L)
                            }

                            override fun onResults(results: Bundle?) {
                                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                                val heard = matches?.firstOrNull()?.trim().orEmpty()
                                if (heard.isNotEmpty()) {
                                    handleHeardSpeech(heard)
                                } else {
                                    scheduleNextListen(600L)
                                }
                            }

                            override fun onPartialResults(partialResults: Bundle?) {}
                            override fun onEvent(eventType: Int, params: Bundle?) {}
                        })
                    }
                }

                val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 2)
                }
                speechRecognizer?.startListening(recognizerIntent)
            } catch (_: Exception) {
                scheduleNextListen(2000L)
            }
        }
    }

    private fun handleHeardSpeech(heardRaw: String) {
        val lower = heardRaw.lowercase(Locale.ROOT)
        _lastDetectedTranscript.value = heardRaw

        val triggeredWake = lower.contains(wakePhrase) ||
            lower.contains("hello aura") ||
            lower.contains("hey aura") ||
            lower.contains("hello nova") ||
            lower.contains("hey nova")

        if (triggeredWake) {
            // Check if the user spoke the command in the same breath: e.g. "Hello Aura mere phone ki battery kitni hai"
            val remainder = lower
                .replace(wakePhrase, "")
                .replace("hello aura", "")
                .replace("hey aura", "")
                .replace("hello nova", "")
                .replace("hey nova", "")
                .trim()

            if (remainder.length > 3) {
                awaitingFollowUpCommand = false
                processSpokenCommand(remainder)
            } else {
                awaitingFollowUpCommand = true
                _statusText.value = "Wake word detected! Listening for your command..."
                updateNotification("Haan, batao! Main sun rahi hoon...")
                speakResponse("Haan, batao! Main sun rahi hoon.")
                scheduleNextListen(2200L)
            }
        } else if (awaitingFollowUpCommand) {
            awaitingFollowUpCommand = false
            processSpokenCommand(heardRaw)
        } else {
            scheduleNextListen(700L)
        }
    }

    private fun processSpokenCommand(command: String) {
        _statusText.value = "Processing: \"$command\""
        val parsed = deviceController.parseNaturalCommand(command)
        when (parsed) {
            is ParsedVoiceIntent.DeviceQuery -> {
                val clean = parsed.spokenResponse.replace("**", "")
                _lastSpokenReply.value = clean
                updateNotification(clean)
                speakResponse(clean)
                scheduleNextListen(4500L)
            }
            is ParsedVoiceIntent.OpenDialer -> {
                deviceController.openDialer(parsed.number)
                val msg = "Opening phone dialer."
                _lastSpokenReply.value = msg
                speakResponse(msg)
                scheduleNextListen(3500L)
            }
            is ParsedVoiceIntent.CallContactQuery -> {
                val contacts = deviceController.searchContacts(parsed.rawNameOrNumber)
                if (contacts.size == 1) {
                    deviceController.openDialer(contacts.first().phoneNumber)
                    val msg = "Opening dialer for ${contacts.first().displayName}."
                    _lastSpokenReply.value = msg
                    speakResponse(msg)
                } else {
                    val msg = "Please unlock AURA AI to confirm calling ${parsed.rawNameOrNumber}."
                    _lastSpokenReply.value = msg
                    speakResponse(msg)
                }
                scheduleNextListen(4000L)
            }
            is ParsedVoiceIntent.SystemAction -> {
                parsed.execute()
                _lastSpokenReply.value = parsed.description
                speakResponse(parsed.description)
                scheduleNextListen(3500L)
            }
            ParsedVoiceIntent.None -> {
                serviceScope.launch {
                    val snap = deviceController.captureDeviceSnapshot()
                    val res = GeminiService.streamChatResponse(
                        history = emptyList(),
                        prompt = command,
                        attachments = emptyList(),
                        mode = AssistantMode.GENERAL,
                        answerLength = AnswerLength.CONCISE,
                        memories = emptyList(),
                        deviceSnapshot = snap,
                        onPartialText = {}
                    )
                    val reply = res.getOrNull()?.text?.replace("**", "")?.take(350)
                        ?: "Main aapki baat samajh gayi. Kripya AURA AI app khol kar dekhein."
                    _lastSpokenReply.value = reply
                    updateNotification(reply)
                    speakResponse(reply)
                    scheduleNextListen(5500L)
                }
            }
        }
    }

    private fun speakResponse(text: String) {
        try {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
        } catch (_: Exception) {
        }
    }

    private fun scheduleNextListen(delayMs: Long) {
        if (isDestroyed || !_isRunning.value) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            startListeningCycle()
        }, delayMs)
    }

    private fun updateNotification(contentText: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        nm?.notify(NOTIFICATION_ID, buildForegroundNotification(contentText))
    }

    private fun buildForegroundNotification(contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, NovaWakeWordForegroundService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AURA AI Hands-Free Assistant")
            .setContentText(contentText)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_media_pause, "Stop Listening", stopPending)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "AURA AI Wake-Word Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays active microphone status when AURA AI hands-free wake-word detection is enabled."
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }
    }

    private fun stopWakeService() {
        _isRunning.value = false
        _statusText.value = "Stopped"
        mainHandler.removeCallbacksAndMessages(null)
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {
        }
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isDestroyed = true
        stopWakeService()
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "nova_wake_word_channel"
        private const val NOTIFICATION_ID = 4091
        const val ACTION_STOP_SERVICE = "com.example.service.STOP_NOVA_WAKE_SERVICE"
        const val EXTRA_WAKE_PHRASE = "extra_wake_phrase"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        private val _statusText = MutableStateFlow("Inactive (Tap to enable hands-free 'Hello Aura')")
        val statusText: StateFlow<String> = _statusText.asStateFlow()

        private val _lastDetectedTranscript = MutableStateFlow("")
        val lastDetectedTranscript: StateFlow<String> = _lastDetectedTranscript.asStateFlow()

        private val _lastSpokenReply = MutableStateFlow("")
        val lastSpokenReply: StateFlow<String> = _lastSpokenReply.asStateFlow()
    }
}
