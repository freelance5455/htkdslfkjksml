package com.example.service

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.util.Log
import com.example.data.model.AppInfo
import com.example.data.model.CallLogItem
import com.example.data.model.ContactItem
import com.example.data.model.DeviceStatus
import com.example.data.model.SmsItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class DeviceAutomationManager(private val context: Context) {

    private val TAG = "DeviceAutomationManager"

    private val _deviceStatus = MutableStateFlow(fetchDeviceStatus())
    val deviceStatus: StateFlow<DeviceStatus> = _deviceStatus.asStateFlow()

    private var isTorchActive = false

    fun refreshStatus() {
        _deviceStatus.value = fetchDeviceStatus()
    }

    private fun fetchDeviceStatus(): DeviceStatus {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val batteryPercent = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 80
        val isCharging = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val status = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS)
            status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        } else false

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val currentVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 7
        val maxVol = audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15
        val volPercent = if (maxVol > 0) (currentVol * 100) / maxVol else 50

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val network = cm?.activeNetwork
        val capabilities = cm?.getNetworkCapabilities(network)
        val isNetworkAvailable = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        val isWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

        // Memory info
        val memoryText = try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val availableMb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024 * 1024)
            val totalMb = (stat.blockCountLong * stat.blockSizeLong) / (1024 * 1024)
            "${availableMb / 1024}GB free of ${totalMb / 1024}GB"
        } catch (e: Exception) {
            "Storage Available"
        }

        return DeviceStatus(
            batteryPercent = batteryPercent,
            isCharging = isCharging,
            isWifiConnected = isWifi,
            isNetworkAvailable = isNetworkAvailable,
            isTorchOn = isTorchActive,
            mediaVolumePercent = volPercent,
            screenBrightnessPercent = 70,
            deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}",
            androidVersion = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            manufacturer = Build.MANUFACTURER,
            memoryUsageText = memoryText
        )
    }

    // 1. FLASHLIGHT
    fun setFlashlight(enabled: Boolean): Result<Boolean> {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: return Result.failure(Exception("Camera service unavailable"))
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: cameraManager.cameraIdList.firstOrNull() ?: return Result.failure(Exception("No camera flash found"))

            cameraManager.setTorchMode(cameraId, enabled)
            isTorchActive = enabled
            refreshStatus()
            Result.success(enabled)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle flashlight", e)
            Result.failure(e)
        }
    }

    fun toggleFlashlight(): Result<Boolean> {
        return setFlashlight(!isTorchActive)
    }

    // 2. VOLUME
    fun setMediaVolume(percent: Int): Boolean {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val target = ((percent.coerceIn(0, 100) * maxVol) / 100f).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
            refreshStatus()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error setting volume", e)
            false
        }
    }

    // 3. SETTINGS INTENTS
    fun openWifiSettings() = startActivitySafely(Intent(Settings.ACTION_WIFI_SETTINGS))
    fun openBluetoothSettings() = startActivitySafely(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
    fun openNetworkSettings() = startActivitySafely(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))
    fun openLocationSettings() = startActivitySafely(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
    fun openBatterySaverSettings() = startActivitySafely(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
    fun openDisplaySettings() = startActivitySafely(Intent(Settings.ACTION_DISPLAY_SETTINGS))
    fun openAppSettings() = startActivitySafely(Intent(Settings.ACTION_SETTINGS))

    // 4. CAMERA & GALLERY
    fun openCamera() = startActivitySafely(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
    fun openGallery() = startActivitySafely(Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI))

    // 5. APPS
    fun openYouTube() = launchAppOrUri("com.google.android.youtube", "https://youtube.com")
    fun openInstagram() = launchAppOrUri("com.instagram.android", "https://instagram.com")
    fun openWhatsApp() = launchAppOrUri("com.whatsapp", "https://whatsapp.com")
    fun openChrome() = launchAppOrUri("com.android.chrome", "https://google.com")
    fun openSpotify() = launchAppOrUri("com.spotify.music", "https://open.spotify.com")
    fun openGoogleMaps(query: String? = null) {
        val uri = if (query != null) Uri.parse("geo:0,0?q=${Uri.encode(query)}") else Uri.parse("geo:0,0")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        if (!startActivitySafely(intent)) {
            startActivitySafely(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${Uri.encode(query ?: "")}")))
        }
    }

    fun launchPackage(packageName: String): Boolean {
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch package $packageName", e)
            false
        }
    }

    private fun launchAppOrUri(packageName: String, webFallback: String): Boolean {
        if (launchPackage(packageName)) return true
        return startActivitySafely(Intent(Intent.ACTION_VIEW, Uri.parse(webFallback)))
    }

    fun getInstalledLaunchableApps(): List<AppInfo> {
        val list = mutableListOf<AppInfo>()
        try {
            val pm = context.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            for (info in resolveInfos) {
                val label = info.loadLabel(pm).toString()
                val pkg = info.activityInfo.packageName
                if (label.isNotBlank() && pkg != context.packageName) {
                    list.add(AppInfo(label = label, packageName = pkg))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error listing installed apps", e)
        }
        return list.sortedBy { it.label }
    }

    // 6. CALLING
    fun openDialer(phoneNumber: String? = null): Boolean {
        val uri = if (phoneNumber.isNullOrBlank()) Uri.parse("tel:") else Uri.parse("tel:${Uri.encode(phoneNumber)}")
        return startActivitySafely(Intent(Intent.ACTION_DIAL, uri))
    }

    fun callEmergency(): Boolean {
        return startActivitySafely(Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")))
    }

    fun makeCall(phoneNumber: String): Boolean {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(phoneNumber)}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return startActivitySafely(intent)
    }

    fun searchContacts(query: String): List<ContactItem> {
        val contacts = mutableListOf<ContactItem>()
        try {
            val resolver = context.contentResolver
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$query%")
            val cursor = resolver.query(uri, projection, selection, selectionArgs, null)

            cursor?.use {
                val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val idIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)

                while (it.moveToNext()) {
                    val name = it.getString(nameIndex) ?: "Unknown"
                    val number = it.getString(numberIndex) ?: ""
                    val id = it.getString(idIndex) ?: ""
                    contacts.add(ContactItem(id = id, name = name, phoneNumber = number))
                }
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Contacts permission not granted", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error reading contacts", e)
        }
        return contacts
    }

    fun getRecentCalls(): List<CallLogItem> {
        val list = mutableListOf<CallLogItem>()
        try {
            val resolver = context.contentResolver
            val cursor = resolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null,
                null,
                "${CallLog.Calls.DATE} DESC LIMIT 15"
            )
            cursor?.use {
                val numIdx = it.getColumnIndex(CallLog.Calls.NUMBER)
                val nameIdx = it.getColumnIndex(CallLog.Calls.CACHED_NAME)
                val typeIdx = it.getColumnIndex(CallLog.Calls.TYPE)
                val dateIdx = it.getColumnIndex(CallLog.Calls.DATE)

                while (it.moveToNext()) {
                    val num = it.getString(numIdx) ?: ""
                    val name = it.getString(nameIdx)
                    val typeCode = it.getInt(typeIdx)
                    val typeStr = when (typeCode) {
                        CallLog.Calls.INCOMING_TYPE -> "Incoming"
                        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                        CallLog.Calls.MISSED_TYPE -> "Missed"
                        else -> "Call"
                    }
                    val date = it.getLong(dateIdx)
                    list.add(CallLogItem(num, name, typeStr, date))
                }
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Call log permission not granted", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error reading call log", e)
        }
        return list
    }

    // 7. MESSAGING
    fun sendSms(phoneNumber: String, message: String): Result<String> {
        return try {
            val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Result.success("SMS sent successfully to $phoneNumber")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send SMS", e)
            Result.failure(e)
        }
    }

    fun sendWhatsAppMessage(phoneNumber: String?, message: String): Boolean {
        return try {
            val cleanPhone = phoneNumber?.replace("[^0-9]".toRegex(), "") ?: ""
            val url = if (cleanPhone.isNotBlank()) {
                "https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}"
            } else {
                "https://api.whatsapp.com/send?text=${Uri.encode(message)}"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (!startActivitySafely(intent)) {
                // Open generic browser or share intent
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Send via WhatsApp"))
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error composing WhatsApp message", e)
            false
        }
    }

    fun getRecentSms(): List<SmsItem> {
        val list = mutableListOf<SmsItem>()
        try {
            val cursor = context.contentResolver.query(
                Telephony.Sms.Inbox.CONTENT_URI,
                arrayOf(Telephony.Sms.Inbox.ADDRESS, Telephony.Sms.Inbox.BODY, Telephony.Sms.Inbox.DATE),
                null,
                null,
                "${Telephony.Sms.Inbox.DATE} DESC LIMIT 10"
            )
            cursor?.use {
                val addrIdx = it.getColumnIndex(Telephony.Sms.Inbox.ADDRESS)
                val bodyIdx = it.getColumnIndex(Telephony.Sms.Inbox.BODY)
                val dateIdx = it.getColumnIndex(Telephony.Sms.Inbox.DATE)
                while (it.moveToNext()) {
                    val addr = it.getString(addrIdx) ?: "Unknown"
                    val body = it.getString(bodyIdx) ?: ""
                    val date = it.getLong(dateIdx)
                    list.add(SmsItem(addr, body, date))
                }
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "SMS read permission not granted", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error reading SMS", e)
        }
        return list
    }

    // 8. UTILITIES
    fun setAlarm(hour: Int, minutes: Int, message: String): Boolean {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minutes)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        return startActivitySafely(intent)
    }

    fun setTimer(seconds: Int, message: String): Boolean {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        return startActivitySafely(intent)
    }

    fun shareText(text: String, title: String = "Share via XTRA") {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    private fun startActivitySafely(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Could not start activity: ${intent.action}", e)
            false
        }
    }
}
