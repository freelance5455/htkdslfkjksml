package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.remote.GeminiClient
import com.example.voice.VoiceAssistantManager
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class WakeWordServiceStatus(
    val isRunning: Boolean = false,
    val phase: String = "Inactive", // "Listening for 'Hey Raynox'", "Waiting for command…", "Thinking…", "Speaking response…"
    val lastQuery: String = "",
    val lastResponse: String = ""
)

class RaynoxVoiceService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var wakeLock: PowerManager.WakeLock? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var isAwaitingCommandAfterWakeWord = false
    private var isProcessingOrSpeaking = false
    private var preferredLanguage: String = "en-IN"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquirePartialWakeLock()
        initTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }

        preferredLanguage = intent?.getStringExtra(EXTRA_LANGUAGE) ?: "en-IN"
        val notification = buildNotification("Say \"Hey Raynox\" followed by your question")

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        _statusFlow.value = _statusFlow.value.copy(
            isRunning = true,
            phase = "Listening for \"Hey Raynox\"…"
        )

        scheduleListenCycle(delayMs = 300L)
        return START_STICKY
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        _statusFlow.value = WakeWordServiceStatus(isRunning = false, phase = "Inactive")
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {
        }
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (_: Exception) {
        }
        releasePartialWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun acquirePartialWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "RaynoxAI::WakeWordGuardWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(4 * 60 * 60 * 1000L) // Up to 4 hours safety bound
            }
        } catch (_: Exception) {
        }
    }

    private fun releasePartialWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {
        }
    }

    private fun initTts() {
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsInitialized = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        isProcessingOrSpeaking = false
                        _statusFlow.value = _statusFlow.value.copy(
                            phase = "Listening for \"Hey Raynox\"…"
                        )
                        updateNotification("Say \"Hey Raynox\" followed by your question")
                        scheduleListenCycle(450L)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isProcessingOrSpeaking = false
                        scheduleListenCycle(600L)
                    }
                })
            }
        }
    }

    private fun scheduleListenCycle(delayMs: Long) {
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            if (!_statusFlow.value.isRunning || isProcessingOrSpeaking) return@postDelayed
            startRecognizerCycle()
        }, delayMs)
    }

    private fun startRecognizerCycle() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            _statusFlow.value = _statusFlow.value.copy(
                phase = "SpeechRecognizer unavailable on this device"
            )
            return
        }

        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(applicationContext)
                speechRecognizer?.setRecognitionListener(recognitionListener)
            }

            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, preferredLanguage)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            speechRecognizer?.startListening(recognizerIntent)
        } catch (_: Exception) {
            scheduleListenCycle(1500L)
        }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            if (!_statusFlow.value.isRunning || isProcessingOrSpeaking) return
            val retryDelay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1400L else 700L
            scheduleListenCycle(retryDelay)
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            handleSpokenCandidates(matches)
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleSpokenCandidates(candidates: List<String>) {
        if (candidates.isEmpty()) {
            scheduleListenCycle(500L)
            return
        }

        val fullUtterance = candidates.first().trim()
        val normalized = fullUtterance.lowercase(Locale.ROOT)

        // Check if we were already triggered by "Hey Raynox" on the previous utterance
        if (isAwaitingCommandAfterWakeWord) {
            isAwaitingCommandAfterWakeWord = false
            if (fullUtterance.isNotBlank()) {
                processWakeCommand(fullUtterance)
                return
            }
        }

        // Check for wake-word prefixes: "hey raynox", "hi raynox", "ok raynox", "hello raynox", "raynox"
        val wakeRegex = Regex("^(?:hey|hi|ok|okay|hello|namaste)?\\s*(?:raynox|renox|reynocks|ranox)\\b[,:\\s]*(.*)$", RegexOption.IGNORE_CASE)
        val match = candidates.firstNotNullOfOrNull { wakeRegex.find(it.trim()) }

        if (match != null) {
            val extractedQuery = match.groupValues.getOrNull(1)?.trim().orEmpty()
            if (extractedQuery.isNotEmpty()) {
                processWakeCommand(extractedQuery)
            } else {
                // User only said "Hey Raynox" — acknowledge and listen for the question next!
                isAwaitingCommandAfterWakeWord = true
                _statusFlow.value = _statusFlow.value.copy(
                    phase = "Wake word detected! Listening for your question…"
                )
                updateNotification("Listening for your question…")
                speakShortPromptAndListen("Yes, how can I help?")
            }
        } else if (normalized.contains("hey raynox") || normalized.contains("hi raynox")) {
            val afterWake = normalized.substringAfter("raynox").trim()
            if (afterWake.isNotEmpty()) {
                processWakeCommand(afterWake)
            } else {
                isAwaitingCommandAfterWakeWord = true
                _statusFlow.value = _statusFlow.value.copy(
                    phase = "Wake word detected! Listening for your question…"
                )
                speakShortPromptAndListen("I'm listening.")
            }
        } else {
            scheduleListenCycle(450L)
        }
    }

    private fun speakShortPromptAndListen(promptText: String) {
        if (!isTtsInitialized) {
            scheduleListenCycle(300L)
            return
        }
        isProcessingOrSpeaking = true
        tts?.setLanguage(Locale.US)
        tts?.speak(promptText, TextToSpeech.QUEUE_FLUSH, null, "wake_ack")
    }

    private fun processWakeCommand(query: String) {
        isProcessingOrSpeaking = true
        _statusFlow.value = _statusFlow.value.copy(
            phase = "Thinking about: \"$query\"",
            lastQuery = query
        )
        updateNotification("Thinking: \"$query\"")

        serviceScope.launch {
            val result = GeminiClient.generateQuickReply(prompt = query)
            result.fold(
                onSuccess = { reply ->
                    val spokenClean = VoiceAssistantManager.stripMarkdownForSpeech(reply)
                    _statusFlow.value = _statusFlow.value.copy(
                        phase = "Speaking response…",
                        lastResponse = spokenClean
                    )
                    updateNotification("Raynox: ${spokenClean.take(80)}")

                    if (isTtsInitialized) {
                        val hasHindi = spokenClean.any { it in '\u0900'..'\u097F' }
                        tts?.setLanguage(if (hasHindi) Locale.forLanguageTag("hi-IN") else Locale.US)
                        tts?.speak(spokenClean, TextToSpeech.QUEUE_FLUSH, null, "wake_reply")
                    } else {
                        isProcessingOrSpeaking = false
                        scheduleListenCycle(600L)
                    }
                },
                onFailure = { err ->
                    val fallbackSpeech = "Sorry, I couldn't reach Raynox AI right now."
                    _statusFlow.value = _statusFlow.value.copy(
                        phase = "Error: ${err.message?.take(60) ?: "Request failed"}",
                        lastResponse = fallbackSpeech
                    )
                    if (isTtsInitialized) {
                        tts?.speak(fallbackSpeech, TextToSpeech.QUEUE_FLUSH, null, "wake_err")
                    } else {
                        isProcessingOrSpeaking = false
                        scheduleListenCycle(1000L)
                    }
                }
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hey Raynox Wake-Word Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Raynox AI listening for 'Hey Raynox' voice commands"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun updateNotification(contentText: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(contentText))
    }

    private fun buildNotification(contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, RaynoxVoiceService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("RAYNOX AI • Wake-Word Guard Active")
            .setContentText(contentText)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop Listening", pendingStop)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "raynox_wake_word_channel"
        private const val NOTIFICATION_ID = 4091
        const val ACTION_STOP_SERVICE = "com.example.service.STOP_RAYNOX_VOICE_SERVICE"
        const val EXTRA_LANGUAGE = "extra_language"

        private val _statusFlow = MutableStateFlow(WakeWordServiceStatus())
        val statusFlow: StateFlow<WakeWordServiceStatus> = _statusFlow.asStateFlow()

        fun startService(context: Context, languageTag: String = "en-IN") {
            val intent = Intent(context, RaynoxVoiceService::class.java).apply {
                putExtra(EXTRA_LANGUAGE, languageTag)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, RaynoxVoiceService::class.java)
            context.stopService(intent)
            _statusFlow.value = WakeWordServiceStatus(isRunning = false, phase = "Inactive")
        }
    }
}
