package com.example.service

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.SecurityPreferences

class AntiTheftAccessibilityService : AccessibilityService() {

    private lateinit var prefs: SecurityPreferences
    private var lastInspectionTime: Long = 0L
    private var lastMatchedReason: String? = null
    private var lastMatchedPackage: String? = null

    companion object {
        private const val TAG = "AntiTheftService"
        var isServiceRunning = false
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = SecurityPreferences.getInstance(this)
        isServiceRunning = true
        Log.d(TAG, "AntiTheftAccessibilityService connected and ready")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!::prefs.isInitialized) {
            prefs = SecurityPreferences.getInstance(this)
        }

        // If PIN is not set yet, do not intercept
        if (!prefs.isPinSet) return

        // If user recently authenticated with PIN, allow temporary access without re-locking
        if (prefs.isGracePeriodActive()) return

        // If user tapped permission configuration from within TecnoGuard, allow navigation
        if (prefs.isSetupNavigationActive()) return

        val pkgName = event.packageName?.toString() ?: ""
        val ownPkg = packageName
        if (pkgName == ownPkg || pkgName == "com.example") return

        // Throttle rapid duplicate events within 300ms
        val now = SystemClock.uptimeMillis()
        if (now - lastInspectionTime < 250) {
            return
        }

        val eventType = event.eventType
        val isWindowEvent = eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                eventType == AccessibilityEvent.TYPE_VIEW_CLICKED

        if (!isWindowEvent) return

        inspectScreen(event, pkgName)
    }

    private fun inspectScreen(event: AccessibilityEvent, pkgName: String) {
        val rootNode: AccessibilityNodeInfo? = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        }

        val collectedTexts = mutableListOf<String>()

        // Collect event texts
        for (charSeq in event.text) {
            if (!charSeq.isNullOrBlank()) {
                collectedTexts.add(charSeq.toString().lowercase())
            }
        }
        event.contentDescription?.let {
            if (it.isNotBlank()) collectedTexts.add(it.toString().lowercase())
        }

        // Collect node hierarchy texts (up to 40 nodes to keep it instantaneous)
        rootNode?.let { node ->
            collectNodeTexts(node, collectedTexts, maxCount = 45)
            try { node.recycle() } catch (_: Exception) {}
        }

        val className = event.className?.toString()?.lowercase() ?: ""
        val fullTextCombined = collectedTexts.joinToString(" ")

        // 1. Check Power Menu / Shutdown / Reboot
        if (prefs.isPowerProtected) {
            val isPowerDialogClass = className.contains("globalaction") ||
                    className.contains("powerdialog") ||
                    className.contains("shutdowndialog") ||
                    className.contains("powerui")

            val hasPowerKeywords = fullTextCombined.contains("apagar") ||
                    fullTextCombined.contains("reiniciar") ||
                    fullTextCombined.contains("power off") ||
                    fullTextCombined.contains("reboot") ||
                    fullTextCombined.contains("restart") ||
                    fullTextCombined.contains("modo apagado") ||
                    fullTextCombined.contains("menú de apagado")

            val isSystemOrPowerPackage = pkgName == "android" ||
                    pkgName.contains("systemui") ||
                    pkgName.contains("power") ||
                    pkgName.contains("transsion")

            if ((isPowerDialogClass && isSystemOrPowerPackage) ||
                (isSystemOrPowerPackage && hasPowerKeywords && (fullTextCombined.contains("apagar") || fullTextCombined.contains("reiniciar") || fullTextCombined.contains("power off")))
            ) {
                triggerInterception(
                    reason = "Menú de Apagado o Reinicio interceptado",
                    pkg = pkgName,
                    shouldDismiss = true
                )
                return
            }
        }

        // 2. Check Memory Function (MemFusion) or Internal Settings requiring reboot
        if (prefs.isMemoryProtected && isSettingsPackage(pkgName)) {
            val hasMemoryOrRebootSetting =
                fullTextCombined.contains("función de memoria") ||
                fullTextCombined.contains("memfusion") ||
                fullTextCombined.contains("fusión de memoria") ||
                fullTextCombined.contains("aumento de memoria") ||
                fullTextCombined.contains("extensión de memoria") ||
                fullTextCombined.contains("memoria virtual") ||
                fullTextCombined.contains("memory extension") ||
                fullTextCombined.contains("reiniciar para surtir efecto") ||
                fullTextCombined.contains("reiniciar para que surta efecto") ||
                fullTextCombined.contains("reiniciar el dispositivo") ||
                fullTextCombined.contains("reinicio necesario") ||
                fullTextCombined.contains("restablecer teléfono") ||
                fullTextCombined.contains("borrar todos los datos") ||
                fullTextCombined.contains("restablecimiento de fábrica") ||
                fullTextCombined.contains("factory reset")

            if (hasMemoryOrRebootSetting) {
                triggerInterception(
                    reason = "Ajuste de Función de Memoria / Reinicio protegido",
                    pkg = pkgName,
                    shouldDismiss = true
                )
                return
            }
        }

        // 3. Check Accessibility and Device Admin internal settings
        if (prefs.isAdminAndAccessibilityProtected && isSettingsPackage(pkgName)) {
            val hasAccessibilityTarget =
                fullTextCombined.contains("accesibilidad") ||
                fullTextCombined.contains("accessibility") ||
                fullTextCombined.contains("servicios descargados") ||
                fullTextCombined.contains("aplicaciones instaladas") ||
                fullTextCombined.contains("tecnoguard")

            val hasDeviceAdminTarget =
                fullTextCombined.contains("aplicaciones del administrador") ||
                fullTextCombined.contains("administrador de dispositivos") ||
                fullTextCombined.contains("administradores de dispositivos") ||
                fullTextCombined.contains("device admin") ||
                fullTextCombined.contains("device admin apps") ||
                fullTextCombined.contains("acceso especial a aplicaciones") ||
                fullTextCombined.contains("acceso especial a apps") ||
                fullTextCombined.contains("acceso especial")

            if (hasAccessibilityTarget || hasDeviceAdminTarget) {
                val label = if (hasDeviceAdminTarget) {
                    "Ajustes de Administrador de Dispositivos protegido"
                } else {
                    "Ajustes de Accesibilidad protegidos"
                }
                triggerInterception(
                    reason = label,
                    pkg = pkgName,
                    shouldDismiss = true
                )
                return
            }
        }

        // 4. Check Desktop Configuration (HiOS Launcher settings)
        if (prefs.isDesktopProtected && isLauncherPackage(pkgName)) {
            val hasDesktopSettings =
                fullTextCombined.contains("configuración de escritorio") ||
                fullTextCombined.contains("ajustes de escritorio") ||
                fullTextCombined.contains("desktop settings") ||
                fullTextCombined.contains("configuración de pantalla de inicio") ||
                fullTextCombined.contains("ajustes de pantalla de inicio") ||
                fullTextCombined.contains("ajustes de inicio") ||
                fullTextCombined.contains("configuración del lanzador") ||
                fullTextCombined.contains("launcher settings") ||
                fullTextCombined.contains("gestos de escritorio")

            if (hasDesktopSettings) {
                triggerInterception(
                    reason = "Configuración de Escritorio HiOS protegida",
                    pkg = pkgName,
                    shouldDismiss = true
                )
                return
            }
        }
    }

    private fun triggerInterception(reason: String, pkg: String, shouldDismiss: Boolean) {
        lastInspectionTime = SystemClock.uptimeMillis()
        lastMatchedReason = reason
        lastMatchedPackage = pkg

        Log.w(TAG, "Interception triggered: $reason on package $pkg")

        // Record in security log
        prefs.logInterception(reason, pkg)

        // Dismiss the target screen or dialog to prevent interaction
        if (shouldDismiss) {
            performGlobalAction(GLOBAL_ACTION_BACK)
        }

        // Launch Lock Screen PIN overlay
        LockOverlayManager.triggerLock(this, reason, pkg)
    }

    private fun isSettingsPackage(pkg: String): Boolean {
        return pkg == "com.android.settings" ||
                pkg.contains("settings") ||
                pkg.contains("transsion.settings")
    }

    private fun isLauncherPackage(pkg: String): Boolean {
        return pkg.contains("hilauncher") ||
                pkg.contains("launcher") ||
                pkg == "com.android.launcher3" ||
                pkg == "com.transsion.hilauncher"
    }

    private fun collectNodeTexts(
        node: AccessibilityNodeInfo,
        result: MutableList<String>,
        maxCount: Int
    ) {
        if (result.size >= maxCount) return

        node.text?.let {
            if (it.isNotBlank()) result.add(it.toString().lowercase())
        }
        node.contentDescription?.let {
            if (it.isNotBlank()) result.add(it.toString().lowercase())
        }

        val childCount = node.childCount
        for (i in 0 until childCount) {
            if (result.size >= maxCount) break
            val child = try {
                node.getChild(i)
            } catch (_: Exception) {
                null
            } ?: continue
            collectNodeTexts(child, result, maxCount)
            try { child.recycle() } catch (_: Exception) {}
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "AntiTheftAccessibilityService onInterrupt")
    }

    override fun onDestroy() {
        super.onDestroy()
        isServiceRunning = false
        Log.w(TAG, "AntiTheftAccessibilityService destroyed")
    }
}
