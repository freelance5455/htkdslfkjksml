package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.SecurityPreferences
import com.example.security.PermissionStatusChecker

class AntiTheftAccessibilityService : AccessibilityService() {

    private lateinit var securityPreferences: SecurityPreferences
    private lateinit var overlayManager: PinLockOverlayManager

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                securityPreferences.clearTemporaryAccess()
                overlayManager.dismiss()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        securityPreferences = SecurityPreferences.getInstance(this)
        overlayManager = PinLockOverlayManager(this, securityPreferences)

        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        registerReceiver(screenOffReceiver, filter)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!::securityPreferences.isInitialized || !::overlayManager.isInitialized) return
        if (!securityPreferences.hasPin() || !securityPreferences.isMasterProtectionEnabled()) return
        if (overlayManager.isShowing) return

        val eventPackage = event.packageName?.toString().orEmpty()
        if (eventPackage == packageName) return

        val snapshot = buildWindowSnapshot(event) ?: return
        val detectedSection = ScreenInterceptorDetector.detect(
            snapshot = snapshot,
            ownPackageName = packageName,
            isDeviceAdminActive = PermissionStatusChecker.isDeviceAdminActive(this),
            isAccessibilityActive = PermissionStatusChecker.isAccessibilityEnabled(this),
        ) ?: return

        if (!securityPreferences.isRuleEnabled(detectedSection)) return
        if (securityPreferences.hasTemporaryAccess(detectedSection)) return

        securityPreferences.recordInterception()
        overlayManager.show(
            section = detectedSection,
            accessibilityService = this,
            isTestMode = false,
        )
    }

    override fun onInterrupt() {
        if (::overlayManager.isInitialized) {
            overlayManager.dismiss()
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenOffReceiver) }
        if (::overlayManager.isInitialized) {
            overlayManager.dismiss()
        }
        super.onDestroy()
    }

    private fun buildWindowSnapshot(event: AccessibilityEvent): WindowSnapshot? {
        val activeRoot = rootInActiveWindow
        val collectedTexts = ArrayList<String>(32)

        // Include event text first (vital for SystemUI Power Dialogs that emit window state text)
        event.text?.forEach { charSeq ->
            val value = charSeq?.toString()?.trim().orEmpty()
            if (value.isNotEmpty()) collectedTexts.add(value)
        }
        event.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let {
            collectedTexts.add(it)
        }

        val rootPackage = activeRoot?.packageName?.toString()
            ?: event.packageName?.toString().orEmpty()
        if (rootPackage.isBlank()) return null

        val className = event.className?.toString().orEmpty()
        var windowTitle = ""

        // Inspect interactive windows (Power Menu / System Dialogs often live in a separate AccessibilityWindowInfo)
        val interactiveWindows = runCatching { windows }.getOrNull().orEmpty()
        for (window in interactiveWindows) {
            val title = window.title?.toString()?.trim().orEmpty()
            if (title.isNotEmpty() && windowTitle.isEmpty()) {
                windowTitle = title
            }
            val winRoot = window.root
            if (winRoot != null) {
                collectNodeTexts(winRoot, collectedTexts, maxNodes = 60)
            }
        }

        if (activeRoot != null) {
            collectNodeTexts(activeRoot, collectedTexts, maxNodes = 80)
        }

        return WindowSnapshot(
            packageName = rootPackage,
            className = className,
            windowTitle = windowTitle,
            texts = collectedTexts,
        )
    }

    private fun collectNodeTexts(
        root: AccessibilityNodeInfo,
        output: MutableList<String>,
        maxNodes: Int,
    ) {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0

        while (queue.isNotEmpty() && visited < maxNodes) {
            val node = queue.removeFirst()
            visited++

            val text = node.text?.toString()?.trim()
            if (!text.isNullOrEmpty() && text.length <= 120) {
                output.add(text)
            }
            val desc = node.contentDescription?.toString()?.trim()
            if (!desc.isNullOrEmpty() && desc.length <= 120) {
                output.add(desc)
            }

            val childCount = node.childCount
            for (i in 0 until childCount) {
                val child = node.getChild(i)
                if (child != null) {
                    queue.add(child)
                }
            }
        }
    }
}
