package com.example.chess

import java.util.UUID

object ChessTreeManager {

    fun createInitialState(orientation: PieceColor = PieceColor.WHITE): ChessBoardState {
        return loadFenPosition(ChessEngineCore.STARTING_FEN, orientation)
    }

    fun loadFenPosition(
        fen: String,
        preferredOrientation: PieceColor? = null,
        title: String? = null
    ): ChessBoardState {
        val parsed = ChessEngineCore.parseFen(fen)
        val validFen = parsed?.toFen() ?: ChessEngineCore.STARTING_FEN
        val orient = preferredOrientation ?: parsed?.turn ?: PieceColor.WHITE
        val root = MoveNode(
            id = "root",
            ply = 0,
            san = "",
            uci = "",
            fen = validFen,
            lastFrom = null,
            lastTo = null
        )
        return ChessBoardState(
            initialFen = validFen,
            fen = validFen,
            orientation = orient,
            rootNodeId = "root",
            currentNodeId = "root",
            nodes = mapOf("root" to root),
            loadedTitle = title
        )
    }

    fun playMove(
        state: ChessBoardState,
        from: Square,
        to: Square,
        promotion: PieceType? = null
    ): ChessBoardState {
        val pos = ChessEngineCore.parseFen(state.fen) ?: return state
        val legal = pos.generateLegalMoves()
        val matching = legal.firstOrNull { mv ->
            mv.from == from && mv.to == to && (mv.promotion == null || mv.promotion == (promotion ?: PieceType.QUEEN))
        } ?: return state

        val san = ChessEngineCore.moveToSan(pos, matching, legal)
        val nextPos = pos.applyMove(matching)
        val nextFen = nextPos.toFen()

        val parentNode = state.currentNode
        // Reuse child if already exists
        val existingChildId = parentNode.childrenIds.firstOrNull { cid ->
            state.nodes[cid]?.uci == matching.uci
        }
        if (existingChildId != null) {
            val child = state.nodes.getValue(existingChildId)
            return state.copy(
                fen = child.fen,
                currentNodeId = existingChildId
            )
        }

        val newNodeId = "n_${UUID.randomUUID().toString().take(8)}"
        val newNode = MoveNode(
            id = newNodeId,
            ply = parentNode.ply + 1,
            san = san,
            uci = matching.uci,
            fen = nextFen,
            lastFrom = matching.from.algebraic,
            lastTo = matching.to.algebraic,
            parentId = parentNode.id
        )
        val updatedParent = parentNode.copy(childrenIds = parentNode.childrenIds + newNodeId)
        val updatedNodes = state.nodes.toMutableMap().apply {
            put(parentNode.id, updatedParent)
            put(newNodeId, newNode)
        }
        return state.copy(
            fen = nextFen,
            currentNodeId = newNodeId,
            nodes = updatedNodes
        )
    }

    fun selectNode(state: ChessBoardState, nodeId: String): ChessBoardState {
        val node = state.nodes[nodeId] ?: return state
        return state.copy(fen = node.fen, currentNodeId = nodeId)
    }

    fun goToStart(state: ChessBoardState): ChessBoardState = selectNode(state, state.rootNodeId)

    fun goToPrev(state: ChessBoardState): ChessBoardState {
        val pid = state.currentNode.parentId ?: return state
        return selectNode(state, pid)
    }

    fun goToNext(state: ChessBoardState): ChessBoardState {
        val cid = state.currentNode.childrenIds.firstOrNull() ?: return state
        return selectNode(state, cid)
    }

    fun goToEnd(state: ChessBoardState): ChessBoardState {
        var cur = state.currentNode
        while (cur.childrenIds.isNotEmpty()) {
            val nextId = cur.childrenIds.first()
            cur = state.nodes[nextId] ?: break
        }
        return selectNode(state, cur.id)
    }

    fun flipOrientation(state: ChessBoardState): ChessBoardState =
        state.copy(orientation = state.orientation.opposite())

    fun setNodeComment(state: ChessBoardState, nodeId: String, comment: String): ChessBoardState {
        val node = state.nodes[nodeId] ?: return state
        val updated = state.nodes.toMutableMap().apply {
            put(nodeId, node.copy(comment = comment))
        }
        return state.copy(nodes = updated)
    }

    fun toggleNodeNag(state: ChessBoardState, nodeId: String, nagSymbol: String): ChessBoardState {
        val node = state.nodes[nodeId] ?: return state
        val nextNags = if (nagSymbol in node.nags) {
            node.nags - nagSymbol
        } else {
            listOf(nagSymbol) // Keep clean single primary assessment NAG per move
        }
        val updated = state.nodes.toMutableMap().apply {
            put(nodeId, node.copy(nags = nextNags))
        }
        return state.copy(nodes = updated)
    }

    fun promoteVariation(state: ChessBoardState, nodeId: String): ChessBoardState {
        val node = state.nodes[nodeId] ?: return state
        val parentId = node.parentId ?: return state
        val parent = state.nodes[parentId] ?: return state
        if (parent.childrenIds.firstOrNull() == nodeId) return state
        val reordered = listOf(nodeId) + parent.childrenIds.filter { it != nodeId }
        val updated = state.nodes.toMutableMap().apply {
            put(parentId, parent.copy(childrenIds = reordered))
        }
        return state.copy(nodes = updated)
    }

    fun deleteNode(state: ChessBoardState, nodeId: String): ChessBoardState {
        if (nodeId == state.rootNodeId) return state
        val node = state.nodes[nodeId] ?: return state
        val parentId = node.parentId ?: return state
        val parent = state.nodes[parentId] ?: return state

        val toRemove = mutableSetOf<String>()
        fun collectDescendants(id: String) {
            toRemove.add(id)
            state.nodes[id]?.childrenIds?.forEach { collectDescendants(it) }
        }
        collectDescendants(nodeId)

        val updatedNodes = state.nodes.toMutableMap()
        toRemove.forEach { updatedNodes.remove(it) }
        updatedNodes[parentId] = parent.copy(childrenIds = parent.childrenIds.filter { it != nodeId })

        val nextCurrent = if (state.currentNodeId in toRemove) parentId else state.currentNodeId
        val nextFen = updatedNodes[nextCurrent]?.fen ?: state.initialFen
        return state.copy(
            fen = nextFen,
            currentNodeId = nextCurrent,
            nodes = updatedNodes
        )
    }

    fun getMainLineNodes(state: ChessBoardState): List<MoveNode> {
        val list = mutableListOf<MoveNode>()
        var cur = state.nodes[state.rootNodeId] ?: return emptyList()
        while (cur.childrenIds.isNotEmpty()) {
            val next = state.nodes[cur.childrenIds.first()] ?: break
            list.add(next)
            cur = next
        }
        return list
    }

    // ---- Full PGN Import & Export ----

    fun exportPgn(state: ChessBoardState): String {
        val sb = StringBuilder()
        val headers = state.headers.toMutableMap()
        if ("Event" !in headers) headers["Event"] = state.loadedTitle ?: "MoonChess Study"
        if (state.initialFen != ChessEngineCore.STARTING_FEN) {
            headers["SetUp"] = "1"
            headers["FEN"] = state.initialFen
        }
        for ((k, v) in headers) {
            sb.append("[$k \"${v.replace("\"", "'")}\"]\n")
        }
        sb.append('\n')

        val root = state.nodes[state.rootNodeId]
        if (root != null && root.comment.isNotBlank()) {
            sb.append("{ ${root.comment.replace("}", ")")} } ")
        }
        val initialTurn = ChessEngineCore.parseFen(state.initialFen)?.turn ?: PieceColor.WHITE
        val initialMoveNum = ChessEngineCore.parseFen(state.initialFen)?.fullMoveNumber ?: 1

        fun renderNodeMove(node: MoveNode, forceMoveNumber: Boolean) {
            val idx = node.ply - 1
            val isW = if (initialTurn == PieceColor.WHITE) idx % 2 == 0 else idx % 2 == 1
            val mNum = if (initialTurn == PieceColor.WHITE) initialMoveNum + idx / 2 else initialMoveNum + (idx + 1) / 2
            if (isW) sb.append("$mNum. ") else if (forceMoveNumber) sb.append("$mNum... ")
            sb.append(node.san)
            if (node.nags.isNotEmpty()) sb.append(node.nags.joinToString(""))
            sb.append(' ')
            if (node.comment.isNotBlank()) sb.append("{ ${node.comment.replace("}", ")")} } ")
        }

        fun renderChildrenOf(parent: MoveNode, forceFirstNumber: Boolean) {
            if (parent.childrenIds.isEmpty()) return
            val firstId = parent.childrenIds.first()
            val rest = parent.childrenIds.drop(1)
            val firstNode = state.nodes[firstId] ?: return
            renderNodeMove(firstNode, forceFirstNumber)
            for (sideId in rest) {
                val sideNode = state.nodes[sideId] ?: continue
                sb.append("( ")
                renderNodeMove(sideNode, forceMoveNumber = true)
                renderChildrenOf(sideNode, forceFirstNumber = false)
                sb.append(") ")
            }
            renderChildrenOf(firstNode, forceFirstNumber = rest.isNotEmpty())
        }

        if (root != null) {
            renderChildrenOf(root, forceFirstNumber = initialTurn == PieceColor.BLACK)
        }
        val res = headers["Result"] ?: "*"
        sb.append(res)
        return sb.toString().trim()
    }

    fun importPgn(
        pgnText: String,
        gameId: String? = null,
        customTitle: String? = null
    ): ChessBoardState? {
        if (pgnText.isBlank()) return null
        val headers = LinkedHashMap<String, String>()
        val headerRegex = Regex("""\[(\w+)\s+"([^"]*)"\]""")
        for (match in headerRegex.findAll(pgnText)) {
            headers[match.groupValues[1]] = match.groupValues[2]
        }

        val body = pgnText.replace(headerRegex, " ").trim()
        val startFen = headers["FEN"]?.takeIf { ChessEngineCore.parseFen(it) != null }
            ?: ChessEngineCore.STARTING_FEN

        val title = customTitle ?: run {
            val w = headers["White"]
            val b = headers["Black"]
            if (!w.isNullOrBlank() && !b.isNullOrBlank()) "$w vs $b" else headers["Event"]
        }

        var workingState = loadFenPosition(startFen, title = title).copy(
            headers = headers,
            loadedGameId = gameId
        )

        val tokens = tokenizePgnBody(body)
        val branchStack = ArrayDeque<String>() // Stores parent nodeId before last move for '(' variations
        var lastMoveParentId: String? = null

        var i = 0
        while (i < tokens.size) {
            when (val tok = tokens[i]) {
                "(" -> {
                    // Start a sideline from the parent of the just-played move
                    val anchorParent = lastMoveParentId ?: workingState.currentNodeId
                    branchStack.addLast(workingState.currentNodeId)
                    workingState = selectNode(workingState, anchorParent)
                }
                ")" -> {
                    if (branchStack.isNotEmpty()) {
                        val resumeId = branchStack.removeLast()
                        workingState = selectNode(workingState, resumeId)
                        lastMoveParentId = workingState.currentNode.parentId
                    }
                }
                else -> {
                    if (tok.startsWith("{") && tok.endsWith("}")) {
                        val commentBody = tok.substring(1, tok.length - 1).trim()
                        if (commentBody.isNotEmpty()) {
                            val existing = workingState.currentNode.comment
                            val combined = if (existing.isBlank()) commentBody else "$existing\n$commentBody"
                            workingState = setNodeComment(workingState, workingState.currentNodeId, combined)
                        }
                    } else if (tok.startsWith("$")) {
                        val nag = numericNagToSymbol(tok)
                        if (nag != null) {
                            workingState = toggleNodeNag(workingState, workingState.currentNodeId, nag)
                        }
                    } else if (tok in RESULT_TOKENS || Regex("""^\d+\.+$""").matches(tok)) {
                        // Skip move numbers and result markers
                    } else {
                        // Strip leading move number if attached (e.g. "1.e4" or "20...hxg5")
                        var moveToken = tok.replace(Regex("""^\d+\.+"""), "")
                        var inlineNag: String? = null
                        val nagMatch = Regex("""([!?]{1,2})$""").find(moveToken)
                        if (nagMatch != null) {
                            inlineNag = nagMatch.groupValues[1]
                            moveToken = moveToken.removeSuffix(inlineNag)
                        }
                        if (moveToken.isNotBlank() && moveToken !in RESULT_TOKENS) {
                            val pos = ChessEngineCore.parseFen(workingState.fen)
                            val parsedMove = pos?.let { ChessEngineCore.parseSanMove(it, moveToken) }
                            if (parsedMove != null) {
                                lastMoveParentId = workingState.currentNodeId
                                workingState = playMove(
                                    workingState,
                                    parsedMove.from,
                                    parsedMove.to,
                                    parsedMove.promotion
                                )
                                if (inlineNag != null) {
                                    workingState = toggleNodeNag(workingState, workingState.currentNodeId, inlineNag)
                                }
                            }
                        }
                    }
                }
            }
            i++
        }

        // Position cursor at start of imported game (or root if FEN puzzle) so user can step forward
        val firstMainChild = workingState.nodes[workingState.rootNodeId]?.childrenIds?.firstOrNull()
        return if (firstMainChild != null) {
            selectNode(workingState, workingState.rootNodeId)
        } else {
            workingState
        }
    }

    private fun numericNagToSymbol(nag: String): String? = when (nag) {
        "$1" -> "!"
        "$2" -> "?"
        "$3" -> "!!"
        "$4" -> "??"
        "$5" -> "!?"
        "$6" -> "?!"
        else -> null
    }

    private fun tokenizePgnBody(body: String): List<String> {
        val tokens = ArrayList<String>()
        var idx = 0
        val n = body.length
        while (idx < n) {
            val ch = body[idx]
            when {
                ch.isWhitespace() -> idx++
                ch == '{' -> {
                    val end = body.indexOf('}', idx + 1)
                    if (end == -1) {
                        tokens.add(body.substring(idx) + "}")
                        break
                    } else {
                        tokens.add(body.substring(idx, end + 1))
                        idx = end + 1
                    }
                }
                ch == ';' -> {
                    val end = body.indexOf('\n', idx + 1)
                    idx = if (end == -1) n else end + 1
                }
                ch == '(' || ch == ')' -> {
                    tokens.add(ch.toString())
                    idx++
                }
                else -> {
                    var end = idx
                    while (end < n && !body[end].isWhitespace() && body[end] !in charArrayOf('{', '(', ')', ';')) {
                        end++
                    }
                    tokens.add(body.substring(idx, end))
                    idx = end
                }
            }
        }
        return tokens
    }

    private val RESULT_TOKENS = setOf("1-0", "0-1", "1/2-1/2", "*")
}
