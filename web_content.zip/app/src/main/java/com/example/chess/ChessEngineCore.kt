package com.example.chess

import kotlin.math.abs

class ChessPosition(
    val board: Array<Array<ChessPiece?>>,
    val turn: PieceColor,
    val castling: CastlingRights,
    val enPassantTarget: Square?,
    val halfMoveClock: Int,
    val fullMoveNumber: Int
) {
    fun pieceAt(sq: Square): ChessPiece? = if (sq.isValid) board[sq.row][sq.col] else null
    fun pieceAt(row: Int, col: Int): ChessPiece? =
        if (row in 0..7 && col in 0..7) board[row][col] else null

    fun copyBoard(): Array<Array<ChessPiece?>> =
        Array(8) { r -> Array(8) { c -> board[r][c] } }

    fun toFen(): String {
        val sb = StringBuilder()
        for (r in 0..7) {
            var empty = 0
            for (c in 0..7) {
                val p = board[r][c]
                if (p == null) {
                    empty++
                } else {
                    if (empty > 0) {
                        sb.append(empty)
                        empty = 0
                    }
                    sb.append(p.fenChar)
                }
            }
            if (empty > 0) sb.append(empty)
            if (r < 7) sb.append('/')
        }
        sb.append(' ').append(turn.code)
        sb.append(' ').append(castling.toFenString())
        sb.append(' ').append(enPassantTarget?.algebraic ?: "-")
        sb.append(' ').append(halfMoveClock)
        sb.append(' ').append(fullMoveNumber)
        return sb.toString()
    }

    fun findKing(color: PieceColor): Square? {
        for (r in 0..7) {
            for (c in 0..7) {
                val p = board[r][c]
                if (p != null && p.color == color && p.type == PieceType.KING) {
                    return Square(r, c)
                }
            }
        }
        return null
    }

    fun isSquareAttackedBy(target: Square, attacker: PieceColor): Boolean {
        // Pawn attacks
        val pawnRowOffset = if (attacker == PieceColor.WHITE) 1 else -1
        for (dc in intArrayOf(-1, 1)) {
            val pr = target.row + pawnRowOffset
            val pc = target.col + dc
            val p = pieceAt(pr, pc)
            if (p != null && p.color == attacker && p.type == PieceType.PAWN) return true
        }
        // Knight attacks
        val knightMoves = arrayOf(
            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
            1 to -2, 1 to 2, 2 to -1, 2 to 1
        )
        for ((dr, dc) in knightMoves) {
            val p = pieceAt(target.row + dr, target.col + dc)
            if (p != null && p.color == attacker && p.type == PieceType.KNIGHT) return true
        }
        // King attacks
        for (dr in -1..1) {
            for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                val p = pieceAt(target.row + dr, target.col + dc)
                if (p != null && p.color == attacker && p.type == PieceType.KING) return true
            }
        }
        // Orthogonal rays (Rook / Queen)
        val orthoDirs = arrayOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)
        for ((dr, dc) in orthoDirs) {
            var r = target.row + dr
            var c = target.col + dc
            while (r in 0..7 && c in 0..7) {
                val p = board[r][c]
                if (p != null) {
                    if (p.color == attacker && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                r += dr
                c += dc
            }
        }
        // Diagonal rays (Bishop / Queen)
        val diagDirs = arrayOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)
        for ((dr, dc) in diagDirs) {
            var r = target.row + dr
            var c = target.col + dc
            while (r in 0..7 && c in 0..7) {
                val p = board[r][c]
                if (p != null) {
                    if (p.color == attacker && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) {
                        return true
                    }
                    break
                }
                r += dr
                c += dc
            }
        }
        return false
    }

    fun isInCheck(color: PieceColor = turn): Boolean {
        val kingSq = findKing(color) ?: return false
        return isSquareAttackedBy(kingSq, color.opposite())
    }

    fun generatePseudoLegalMoves(): List<ChessMove> {
        val moves = ArrayList<ChessMove>(48)
        val us = turn
        val them = us.opposite()
        for (r in 0..7) {
            for (c in 0..7) {
                val piece = board[r][c] ?: continue
                if (piece.color != us) continue
                val from = Square(r, c)
                when (piece.type) {
                    PieceType.PAWN -> {
                        val dir = if (us == PieceColor.WHITE) -1 else 1
                        val startRow = if (us == PieceColor.WHITE) 6 else 1
                        val promoRow = if (us == PieceColor.WHITE) 0 else 7
                        val oneStep = Square(r + dir, c)
                        if (oneStep.isValid && pieceAt(oneStep) == null) {
                            if (oneStep.row == promoRow) {
                                for (pt in PROMO_TYPES) moves.add(ChessMove(from, oneStep, promotion = pt))
                            } else {
                                moves.add(ChessMove(from, oneStep))
                                val twoStep = Square(r + dir * 2, c)
                                if (r == startRow && pieceAt(twoStep) == null) {
                                    moves.add(ChessMove(from, twoStep))
                                }
                            }
                        }
                        for (dc in intArrayOf(-1, 1)) {
                            val capSq = Square(r + dir, c + dc)
                            if (!capSq.isValid) continue
                            val targetPiece = pieceAt(capSq)
                            if (targetPiece != null && targetPiece.color == them) {
                                if (capSq.row == promoRow) {
                                    for (pt in PROMO_TYPES) moves.add(ChessMove(from, capSq, promotion = pt))
                                } else {
                                    moves.add(ChessMove(from, capSq))
                                }
                            } else if (enPassantTarget == capSq) {
                                moves.add(ChessMove(from, capSq, isEnPassant = true))
                            }
                        }
                    }
                    PieceType.KNIGHT -> {
                        val jumps = arrayOf(
                            -2 to -1, -2 to 1, -1 to -2, -1 to 2,
                            1 to -2, 1 to 2, 2 to -1, 2 to 1
                        )
                        for ((dr, dc) in jumps) {
                            val to = Square(r + dr, c + dc)
                            if (!to.isValid) continue
                            val occ = pieceAt(to)
                            if (occ == null || occ.color == them) moves.add(ChessMove(from, to))
                        }
                    }
                    PieceType.BISHOP -> addRayMoves(from, them, arrayOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1), moves)
                    PieceType.ROOK -> addRayMoves(from, them, arrayOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1), moves)
                    PieceType.QUEEN -> addRayMoves(
                        from,
                        them,
                        arrayOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1, -1 to 0, 1 to 0, 0 to -1, 0 to 1),
                        moves
                    )
                    PieceType.KING -> {
                        for (dr in -1..1) {
                            for (dc in -1..1) {
                                if (dr == 0 && dc == 0) continue
                                val to = Square(r + dr, c + dc)
                                if (!to.isValid) continue
                                val occ = pieceAt(to)
                                if (occ == null || occ.color == them) moves.add(ChessMove(from, to))
                            }
                        }
                        // Castling
                        val homeRow = if (us == PieceColor.WHITE) 7 else 0
                        if (r == homeRow && c == 4 && !isSquareAttackedBy(from, them)) {
                            val canKingSide = if (us == PieceColor.WHITE) castling.whiteKingSide else castling.blackKingSide
                            if (canKingSide &&
                                board[homeRow][5] == null &&
                                board[homeRow][6] == null &&
                                board[homeRow][7]?.let { it.color == us && it.type == PieceType.ROOK } == true &&
                                !isSquareAttackedBy(Square(homeRow, 5), them) &&
                                !isSquareAttackedBy(Square(homeRow, 6), them)
                            ) {
                                moves.add(ChessMove(from, Square(homeRow, 6), isCastleKingSide = true))
                            }
                            val canQueenSide = if (us == PieceColor.WHITE) castling.whiteQueenSide else castling.blackQueenSide
                            if (canQueenSide &&
                                board[homeRow][3] == null &&
                                board[homeRow][2] == null &&
                                board[homeRow][1] == null &&
                                board[homeRow][0]?.let { it.color == us && it.type == PieceType.ROOK } == true &&
                                !isSquareAttackedBy(Square(homeRow, 3), them) &&
                                !isSquareAttackedBy(Square(homeRow, 2), them)
                            ) {
                                moves.add(ChessMove(from, Square(homeRow, 2), isCastleQueenSide = true))
                            }
                        }
                    }
                }
            }
        }
        return moves
    }

    private fun addRayMoves(
        from: Square,
        them: PieceColor,
        dirs: Array<Pair<Int, Int>>,
        out: MutableList<ChessMove>
    ) {
        for ((dr, dc) in dirs) {
            var r = from.row + dr
            var c = from.col + dc
            while (r in 0..7 && c in 0..7) {
                val occ = board[r][c]
                if (occ == null) {
                    out.add(ChessMove(from, Square(r, c)))
                } else {
                    if (occ.color == them) out.add(ChessMove(from, Square(r, c)))
                    break
                }
                r += dr
                c += dc
            }
        }
    }

    fun applyMove(move: ChessMove): ChessPosition {
        val nextBoard = copyBoard()
        val moving = nextBoard[move.from.row][move.from.col]
            ?: return this
        val captured = nextBoard[move.to.row][move.to.col]

        nextBoard[move.from.row][move.from.col] = null
        if (move.isEnPassant) {
            val capRow = move.from.row
            nextBoard[capRow][move.to.col] = null
        }
        if (move.isCastleKingSide) {
            val hr = move.from.row
            nextBoard[hr][5] = nextBoard[hr][7]
            nextBoard[hr][7] = null
        } else if (move.isCastleQueenSide) {
            val hr = move.from.row
            nextBoard[hr][3] = nextBoard[hr][0]
            nextBoard[hr][0] = null
        }

        val placedPiece = if (move.promotion != null) {
            ChessPiece(moving.color, move.promotion)
        } else {
            moving
        }
        nextBoard[move.to.row][move.to.col] = placedPiece

        // Update castling rights
        var wk = castling.whiteKingSide
        var wq = castling.whiteQueenSide
        var bk = castling.blackKingSide
        var bq = castling.blackQueenSide
        if (moving.type == PieceType.KING) {
            if (moving.color == PieceColor.WHITE) { wk = false; wq = false }
            else { bk = false; bq = false }
        }
        if (move.from.row == 7 && move.from.col == 7 || move.to.row == 7 && move.to.col == 7) wk = false
        if (move.from.row == 7 && move.from.col == 0 || move.to.row == 7 && move.to.col == 0) wq = false
        if (move.from.row == 0 && move.from.col == 7 || move.to.row == 0 && move.to.col == 7) bk = false
        if (move.from.row == 0 && move.from.col == 0 || move.to.row == 0 && move.to.col == 0) bq = false

        val epTarget = if (moving.type == PieceType.PAWN && abs(move.to.row - move.from.row) == 2) {
            Square((move.from.row + move.to.row) / 2, move.from.col)
        } else null

        val nextHalfMove = if (moving.type == PieceType.PAWN || captured != null || move.isEnPassant) {
            0
        } else {
            halfMoveClock + 1
        }
        val nextFullMove = if (turn == PieceColor.BLACK) fullMoveNumber + 1 else fullMoveNumber

        return ChessPosition(
            board = nextBoard,
            turn = turn.opposite(),
            castling = CastlingRights(wk, wq, bk, bq),
            enPassantTarget = epTarget,
            halfMoveClock = nextHalfMove,
            fullMoveNumber = nextFullMove
        )
    }

    fun generateLegalMoves(): List<ChessMove> {
        val us = turn
        return generatePseudoLegalMoves().filter { mv ->
            val after = applyMove(mv)
            !after.isInCheck(us)
        }
    }

    fun isCheckmate(): Boolean = isInCheck(turn) && generateLegalMoves().isEmpty()
    fun isStalemate(): Boolean = !isInCheck(turn) && generateLegalMoves().isEmpty()
    fun isDraw(): Boolean = isStalemate() || halfMoveClock >= 100 || isInsufficientMaterial()

    fun isInsufficientMaterial(): Boolean {
        val nonKings = mutableListOf<Pair<ChessPiece, Square>>()
        for (r in 0..7) {
            for (c in 0..7) {
                val p = board[r][c] ?: continue
                if (p.type != PieceType.KING) nonKings.add(p to Square(r, c))
            }
        }
        if (nonKings.isEmpty()) return true
        if (nonKings.size == 1) {
            val pt = nonKings[0].first.type
            if (pt == PieceType.KNIGHT || pt == PieceType.BISHOP) return true
        }
        if (nonKings.size == 2 &&
            nonKings[0].first.type == PieceType.BISHOP &&
            nonKings[1].first.type == PieceType.BISHOP &&
            nonKings[0].second.isDark == nonKings[1].second.isDark
        ) {
            return true
        }
        return false
    }

    companion object {
        val PROMO_TYPES = listOf(PieceType.QUEEN, PieceType.ROOK, PieceType.BISHOP, PieceType.KNIGHT)
    }
}

object ChessEngineCore {
    const val STARTING_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    fun parseFen(fen: String): ChessPosition? {
        val parts = fen.trim().split(Regex("\\s+"))
        if (parts.isEmpty()) return null
        val ranks = parts[0].split('/')
        if (ranks.size != 8) return null

        val board = Array(8) { arrayOfNulls<ChessPiece>(8) }
        for (r in 0..7) {
            var c = 0
            for (ch in ranks[r]) {
                if (ch.isDigit()) {
                    c += (ch - '0')
                } else {
                    if (c !in 0..7) return null
                    val piece = ChessPiece.fromFenChar(ch) ?: return null
                    board[r][c] = piece
                    c++
                }
            }
            if (c != 8) return null
        }

        val turn = if (parts.size >= 2) PieceColor.fromChar(parts[1].firstOrNull() ?: 'w') else PieceColor.WHITE
        val castling = if (parts.size >= 3) CastlingRights.fromFenString(parts[2]) else CastlingRights.NONE
        val ep = if (parts.size >= 4 && parts[3] != "-") Square.fromAlgebraic(parts[3]) else null
        val halfMove = parts.getOrNull(4)?.toIntOrNull() ?: 0
        val fullMove = parts.getOrNull(5)?.toIntOrNull()?.coerceAtLeast(1) ?: 1

        val pos = ChessPosition(board, turn, castling, ep, halfMove, fullMove)
        // Must have exactly 1 king per side and opponent not in check
        var wk = 0
        var bk = 0
        for (r in 0..7) {
            for (c in 0..7) {
                val p = board[r][c] ?: continue
                if (p.type == PieceType.KING) {
                    if (p.color == PieceColor.WHITE) wk++ else bk++
                }
                if (p.type == PieceType.PAWN && (r == 0 || r == 7)) return null
            }
        }
        if (wk != 1 || bk != 1) return null
        if (pos.isInCheck(turn.opposite())) return null
        return pos
    }

    fun moveToSan(pos: ChessPosition, move: ChessMove, allLegal: List<ChessMove> = pos.generateLegalMoves()): String {
        val moving = pos.pieceAt(move.from) ?: return move.uci
        val after = pos.applyMove(move)
        val suffix = when {
            after.isCheckmate() -> "#"
            after.isInCheck() -> "+"
            else -> ""
        }

        if (move.isCastleKingSide) return "O-O$suffix"
        if (move.isCastleQueenSide) return "O-O-O$suffix"

        val isCapture = pos.pieceAt(move.to) != null || move.isEnPassant
        val sb = StringBuilder()

        if (moving.type == PieceType.PAWN) {
            if (isCapture) {
                sb.append(move.from.fileChar)
                sb.append('x')
            }
            sb.append(move.to.algebraic)
            if (move.promotion != null) {
                sb.append('=').append(move.promotion.fenUpper)
            }
        } else {
            sb.append(moving.type.sanSymbol)
            // Disambiguation
            val ambiguous = allLegal.filter {
                it != move &&
                    it.to == move.to &&
                    pos.pieceAt(it.from)?.type == moving.type
            }
            if (ambiguous.isNotEmpty()) {
                val sameFile = ambiguous.any { it.from.col == move.from.col }
                val sameRank = ambiguous.any { it.from.row == move.from.row }
                when {
                    !sameFile -> sb.append(move.from.fileChar)
                    !sameRank -> sb.append(move.from.rankNumber)
                    else -> sb.append(move.from.algebraic)
                }
            }
            if (isCapture) sb.append('x')
            sb.append(move.to.algebraic)
        }
        sb.append(suffix)
        return sb.toString()
    }

    fun parseSanMove(pos: ChessPosition, rawSan: String): ChessMove? {
        var clean = rawSan.trim()
            .replace("0-0-0", "O-O-O")
            .replace("0-0", "O-O")
            .replace(Regex("[+#!?]+$"), "")
            .trim()
        if (clean.isEmpty()) return null

        val legal = pos.generateLegalMoves()
        // Direct match against formatted SAN
        for (mv in legal) {
            val formatted = moveToSan(pos, mv, legal).replace(Regex("[+#]+$"), "")
            if (formatted == clean) return mv
        }
        // Fallback: UCI match (e.g. "e2e4", "e7e8q")
        if (clean.length in 4..5) {
            val uciLower = clean.lowercase()
            legal.firstOrNull { it.uci == uciLower }?.let { return it }
        }
        // Permissive SAN fallback (e.g., extra disambiguation like Nge2 vs Ne2)
        clean = clean.replace("x", "")
        if (clean == "O-O") return legal.firstOrNull { it.isCastleKingSide }
        if (clean == "O-O-O") return legal.firstOrNull { it.isCastleQueenSide }

        var promoType: PieceType? = null
        val eqIdx = clean.indexOf('=')
        if (eqIdx >= 0 && eqIdx + 1 < clean.length) {
            promoType = PieceType.fromChar(clean[eqIdx + 1])
            clean = clean.substring(0, eqIdx)
        } else if (clean.last().uppercaseChar() in listOf('Q', 'R', 'B', 'N') && clean.length >= 3 && clean[clean.length - 2].isDigit()) {
            promoType = PieceType.fromChar(clean.last())
            clean = clean.dropLast(1)
        }

        if (clean.length < 2) return null
        val destStr = clean.takeLast(2)
        val destSq = Square.fromAlgebraic(destStr) ?: return null
        val prefix = clean.dropLast(2)

        val pieceType = if (prefix.isNotEmpty() && prefix[0].isUpperCase()) {
            PieceType.fromChar(prefix[0]) ?: PieceType.PAWN
        } else {
            PieceType.PAWN
        }
        val disambig = if (prefix.isNotEmpty() && prefix[0].isUpperCase()) prefix.drop(1) else prefix

        return legal.firstOrNull { mv ->
            val p = pos.pieceAt(mv.from) ?: return@firstOrNull false
            if (p.type != pieceType || mv.to != destSq) return@firstOrNull false
            if ((promoType ?: PieceType.QUEEN) != (mv.promotion ?: PieceType.QUEEN) && (promoType != null || mv.promotion != null)) {
                return@firstOrNull false
            }
            disambig.all { ch ->
                if (ch.isDigit()) mv.from.rankNumber == (ch - '0')
                else mv.from.fileChar == ch.lowercaseChar()
            }
        }
    }
}
