package com.example.chess

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext
import kotlin.math.abs

object AnalysisEngines {

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .build()
    }

    // Piece-Square Tables (from White's perspective; row 0 = rank 8, row 7 = rank 1)
    private val PAWN_PST = intArrayOf(
         0,   0,   0,   0,   0,   0,   0,   0,
        50,  50,  50,  50,  50,  50,  50,  50,
        10,  10,  20,  30,  30,  20,  10,  10,
         5,   5,  10,  25,  25,  10,   5,   5,
         0,   0,   0,  25,  25,   0,   0,   0,
         5,  -5, -10,   0,   0, -10,  -5,   5,
         5,  10,  10, -20, -20,  10,  10,   5,
         0,   0,   0,   0,   0,   0,   0,   0
    )

    private val KNIGHT_PST = intArrayOf(
        -50, -40, -30, -30, -30, -30, -40, -50,
        -40, -20,   0,   0,   0,   0, -20, -40,
        -30,   0,  10,  15,  15,  10,   0, -30,
        -30,   5,  15,  20,  20,  15,   5, -30,
        -30,   0,  15,  20,  20,  15,   0, -30,
        -30,   5,  10,  15,  15,  10,   5, -30,
        -40, -20,   0,   5,   5,   0, -20, -40,
        -50, -40, -30, -30, -30, -30, -40, -50
    )

    private val BISHOP_PST = intArrayOf(
        -20, -10, -10, -10, -10, -10, -10, -20,
        -10,   0,   0,   0,   0,   0,   0, -10,
        -10,   0,   5,  10,  10,   5,   0, -10,
        -10,   5,   5,  10,  10,   5,   5, -10,
        -10,   0,  10,  10,  10,  10,   0, -10,
        -10,  10,  10,  10,  10,  10,  10, -10,
        -10,   5,   0,   0,   0,   0,   5, -10,
        -20, -10, -10, -10, -10, -10, -10, -20
    )

    private val ROOK_PST = intArrayOf(
         0,   0,   0,   0,   0,   0,   0,   0,
         5,  10,  10,  10,  10,  10,  10,   5,
        -5,   0,   0,   0,   0,   0,   0,  -5,
        -5,   0,   0,   0,   0,   0,   0,  -5,
        -5,   0,   0,   0,   0,   0,   0,  -5,
        -5,   0,   0,   0,   0,   0,   0,  -5,
        -5,   0,   0,   0,   0,   0,   0,  -5,
         0,   0,   0,   5,   5,   0,   0,   0
    )

    fun evaluateStaticPosition(pos: ChessPosition): Int {
        var whiteScore = 0
        var blackScore = 0
        for (r in 0..7) {
            for (c in 0..7) {
                val p = pos.board[r][c] ?: continue
                val idx = r * 8 + c
                val mirrorIdx = (7 - r) * 8 + c
                val pstIdx = if (p.color == PieceColor.WHITE) idx else mirrorIdx
                val bonus = when (p.type) {
                    PieceType.PAWN -> PAWN_PST[pstIdx]
                    PieceType.KNIGHT -> KNIGHT_PST[pstIdx]
                    PieceType.BISHOP -> BISHOP_PST[pstIdx]
                    PieceType.ROOK -> ROOK_PST[pstIdx]
                    else -> 0
                }
                if (p.color == PieceColor.WHITE) {
                    whiteScore += p.type.centipawns + bonus
                } else {
                    blackScore += p.type.centipawns + bonus
                }
            }
        }
        // Small tempo bonus matching classical openings (+0.35 / +0.40 on starting position)
        val tempo = if (pos.turn == PieceColor.WHITE) 38 else -15
        return (whiteScore - blackScore) + tempo
    }

    /**
     * 100% Offline VCH Local Engine with Alpha-Beta Pruning & Multi-PV SAN Lines
     */
    suspend fun evaluateVchLocal(fen: String, targetDepth: Int = 3): EngineEvaluation =
        withContext(Dispatchers.Default) {
            val pos = ChessEngineCore.parseFen(fen) ?: return@withContext EngineEvaluation(
                scoreText = "0.0",
                scoreCentipawns = 0,
                depth = 1,
                engineName = "VCH Engine",
                pvLines = emptyList(),
                bestMoveArrows = emptyList()
            )

            val rootLegal = pos.generateLegalMoves()
            if (rootLegal.isEmpty()) {
                val isMate = pos.isInCheck()
                val mateScore = if (pos.turn == PieceColor.WHITE) "-M0" else "+M0"
                return@withContext EngineEvaluation(
                    scoreText = if (isMate) mateScore else "0.0",
                    scoreCentipawns = if (isMate) (if (pos.turn == PieceColor.WHITE) -30000 else 30000) else 0,
                    depth = targetDepth,
                    engineName = "VCH Engine",
                    pvLines = listOf(
                        PvLine(
                            scoreText = if (isMate) mateScore else "0.0",
                            sanSequence = if (isMate) "Checkmate" else "Stalemate / Draw"
                        )
                    ),
                    bestMoveArrows = emptyList(),
                    isMate = isMate
                )
            }

            val searchDepth = targetDepth.coerceIn(1, 4)
            val orderedRoot = orderMoves(pos, rootLegal)

            data class ScoredRootMove(
                val move: ChessMove,
                val whiteCp: Int,
                val pvMoves: List<ChessMove>
            )

            val scoredMoves = ArrayList<ScoredRootMove>(orderedRoot.size)
            for (rm in orderedRoot) {
                coroutineContext.ensureActive()
                val nextPos = pos.applyMove(rm)
                val (cp, tailPv) = alphaBetaWithPv(
                    pos = nextPos,
                    depth = searchDepth - 1,
                    alphaInit = -50000,
                    betaInit = 50000
                )
                scoredMoves.add(ScoredRootMove(rm, cp, listOf(rm) + tailPv))
            }

            val sorted = if (pos.turn == PieceColor.WHITE) {
                scoredMoves.sortedByDescending { it.whiteCp }
            } else {
                scoredMoves.sortedBy { it.whiteCp }
            }

            val topLines = sorted.take(2).map { item ->
                PvLine(
                    scoreText = formatCpScore(item.whiteCp),
                    sanSequence = formatPvSanSequence(pos, item.pvMoves),
                    firstMoveUci = item.move.uci
                )
            }

            val best = sorted.first()
            val arrows = sorted.take(2).map {
                BoardArrow(
                    from = it.move.from.algebraic,
                    to = it.move.to.algebraic,
                    isEngineArrow = true
                )
            }

            EngineEvaluation(
                scoreText = formatCpScore(best.whiteCp),
                scoreCentipawns = best.whiteCp,
                depth = searchDepth,
                engineName = "VCH Engine",
                pvLines = topLines,
                bestMoveArrows = arrows,
                isMate = abs(best.whiteCp) >= 25000
            )
        }

    private fun orderMoves(pos: ChessPosition, moves: List<ChessMove>): List<ChessMove> {
        return moves.sortedByDescending { mv ->
            val captured = pos.pieceAt(mv.to)
            val moving = pos.pieceAt(mv.from)
            var score = 0
            if (captured != null) {
                score += 10 * captured.type.centipawns - (moving?.type?.centipawns ?: 0)
            }
            if (mv.promotion != null) score += mv.promotion.centipawns
            if (mv.to.row in 3..4 && mv.to.col in 2..5) score += 25
            score
        }
    }

    private fun alphaBetaWithPv(
        pos: ChessPosition,
        depth: Int,
        alphaInit: Int,
        betaInit: Int
    ): Pair<Int, List<ChessMove>> {
        val legal = pos.generateLegalMoves()
        if (legal.isEmpty()) {
            return if (pos.isInCheck()) {
                val mateVal = if (pos.turn == PieceColor.WHITE) -(29000 + depth * 100) else (29000 + depth * 100)
                mateVal to emptyList()
            } else {
                0 to emptyList()
            }
        }
        if (depth <= 0) {
            return evaluateStaticPosition(pos) to emptyList()
        }

        var alpha = alphaInit
        var beta = betaInit
        val ordered = orderMoves(pos, legal)
        var bestPv: List<ChessMove> = emptyList()

        if (pos.turn == PieceColor.WHITE) {
            var bestVal = -50000
            for (mv in ordered) {
                val (childVal, childPv) = alphaBetaWithPv(pos.applyMove(mv), depth - 1, alpha, beta)
                if (childVal > bestVal) {
                    bestVal = childVal
                    bestPv = listOf(mv) + childPv
                }
                if (bestVal > alpha) alpha = bestVal
                if (beta <= alpha) break
            }
            return bestVal to bestPv
        } else {
            var bestVal = 50000
            for (mv in ordered) {
                val (childVal, childPv) = alphaBetaWithPv(pos.applyMove(mv), depth - 1, alpha, beta)
                if (childVal < bestVal) {
                    bestVal = childVal
                    bestPv = listOf(mv) + childPv
                }
                if (bestVal < beta) beta = bestVal
                if (beta <= alpha) break
            }
            return bestVal to bestPv
        }
    }

    private fun formatPvSanSequence(startPos: ChessPosition, moves: List<ChessMove>): String {
        val sb = StringBuilder()
        var cur = startPos
        for ((idx, mv) in moves.take(6).withIndex()) {
            val legal = cur.generateLegalMoves()
            val san = ChessEngineCore.moveToSan(cur, mv, legal)
            if (cur.turn == PieceColor.WHITE) {
                sb.append("${cur.fullMoveNumber}.$san ")
            } else {
                if (idx == 0) sb.append("${cur.fullMoveNumber}...$san ")
                else sb.append("$san ")
            }
            cur = cur.applyMove(mv)
        }
        if (moves.size >= 4) sb.append("...")
        return sb.toString().trim()
    }

    fun formatCpScore(whiteCentipawns: Int): String {
        if (abs(whiteCentipawns) >= 25000) {
            val plies = (30000 - abs(whiteCentipawns)).coerceAtLeast(1) / 100 + 1
            return if (whiteCentipawns > 0) "+M$plies" else "-M$plies"
        }
        val pawns = whiteCentipawns / 100.0
        val sign = if (pawns >= 0) "+" else ""
        return String.format(java.util.Locale.US, "%s%.1f", sign, pawns)
    }

    /**
     * Lichess Cloud Evaluation API (with graceful fallback to offline VCH Engine)
     */
    suspend fun evaluateLichessCloudOrLocal(fen: String, fallbackDepth: Int = 3): EngineEvaluation =
        withContext(Dispatchers.IO) {
            try {
                val encodedFen = Uri.encode(fen)
                val url = "https://lichess.org/api/cloud-eval?fen=$encodedFen&multiPv=2"
                val req = Request.Builder()
                    .url(url)
                    .header("Accept", "application/json")
                    .build()
                httpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        return@withContext evaluateVchLocal(fen, fallbackDepth)
                    }
                    val body = resp.body?.string().orEmpty()
                    if (body.isBlank()) return@withContext evaluateVchLocal(fen, fallbackDepth)
                    val json = JSONObject(body)
                    val depth = json.optInt("depth", 23)
                    val pvsArr = json.optJSONArray("pvs")
                    if (pvsArr == null || pvsArr.length() == 0) {
                        return@withContext evaluateVchLocal(fen, fallbackDepth)
                    }

                    val startPos = ChessEngineCore.parseFen(fen)
                        ?: return@withContext evaluateVchLocal(fen, fallbackDepth)

                    val pvLines = ArrayList<PvLine>()
                    val arrows = ArrayList<BoardArrow>()
                    var primaryScoreText = "+0.0"
                    var primaryCp = 0
                    var primaryMate = false

                    for (i in 0 until pvsArr.length()) {
                        val pvObj = pvsArr.getJSONObject(i)
                        val movesUci = pvObj.optString("moves", "").trim().split(Regex("\\s+")).filter { it.length >= 4 }
                        val hasMate = pvObj.has("mate") && !pvObj.isNull("mate")
                        val cpVal = if (hasMate) {
                            val m = pvObj.getInt("mate")
                            if (m >= 0) 29000 else -29000
                        } else {
                            pvObj.optInt("cp", 0)
                        }
                        val scoreStr = if (hasMate) {
                            val m = pvObj.getInt("mate")
                            if (m >= 0) "+M$m" else "-M${abs(m)}"
                        } else {
                            formatCpScore(cpVal)
                        }

                        if (i == 0) {
                            primaryScoreText = scoreStr
                            primaryCp = cpVal
                            primaryMate = hasMate
                        }

                        // Convert UCI sequence to SAN sequence
                        var curPos = startPos
                        val sanBuilder = StringBuilder()
                        var firstUci: String? = null
                        for ((mIdx, uci) in movesUci.take(6).withIndex()) {
                            val legal = curPos.generateLegalMoves()
                            val found = legal.firstOrNull { it.uci.equals(uci, ignoreCase = true) } ?: break
                            if (mIdx == 0) {
                                firstUci = found.uci
                                arrows.add(BoardArrow(found.from.algebraic, found.to.algebraic, isEngineArrow = true))
                            }
                            val san = ChessEngineCore.moveToSan(curPos, found, legal)
                            if (curPos.turn == PieceColor.WHITE) {
                                sanBuilder.append("${curPos.fullMoveNumber}.$san ")
                            } else {
                                if (mIdx == 0) sanBuilder.append("${curPos.fullMoveNumber}...$san ")
                                else sanBuilder.append("$san ")
                            }
                            curPos = curPos.applyMove(found)
                        }
                        if (movesUci.size > 6) sanBuilder.append("...")

                        pvLines.add(
                            PvLine(
                                scoreText = scoreStr,
                                sanSequence = sanBuilder.toString().trim(),
                                firstMoveUci = firstUci
                            )
                        )
                    }

                    EngineEvaluation(
                        scoreText = primaryScoreText,
                        scoreCentipawns = primaryCp,
                        depth = depth,
                        engineName = "Stockfish (Lichess)",
                        pvLines = pvLines,
                        bestMoveArrows = arrows,
                        isMate = primaryMate
                    )
                }
            } catch (_: Exception) {
                evaluateVchLocal(fen, fallbackDepth)
            }
        }

    /**
     * Builds exact Lichess Analysis URL with FEN and orientation so the user can analyze
     * with Stockfish 19 directly on Lichess.org.
     */
    fun buildLichessStockfish19Url(fen: String, orientation: PieceColor): String {
        val fenPath = fen.trim().replace(' ', '_')
        val colorParam = if (orientation == PieceColor.BLACK) "black" else "white"
        return "https://lichess.org/analysis/$fenPath?color=$colorParam"
    }
}
