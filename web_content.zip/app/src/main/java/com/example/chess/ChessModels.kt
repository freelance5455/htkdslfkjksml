package com.example.chess

import androidx.compose.ui.graphics.Color

enum class PieceColor(val code: Char) {
    WHITE('w'),
    BLACK('b');

    fun opposite(): PieceColor = if (this == WHITE) BLACK else WHITE

    companion object {
        fun fromChar(c: Char): PieceColor = if (c.lowercaseChar() == 'b') BLACK else WHITE
    }
}

enum class PieceType(val fenUpper: Char, val sanSymbol: String, val centipawns: Int) {
    PAWN('P', "", 100),
    KNIGHT('N', "N", 320),
    BISHOP('B', "B", 330),
    ROOK('R', "R", 500),
    QUEEN('Q', "Q", 900),
    KING('K', "K", 20000);

    companion object {
        fun fromChar(c: Char): PieceType? = when (c.uppercaseChar()) {
            'P' -> PAWN
            'N' -> KNIGHT
            'B' -> BISHOP
            'R' -> ROOK
            'Q' -> QUEEN
            'K' -> KING
            else -> null
        }
    }
}

data class ChessPiece(
    val color: PieceColor,
    val type: PieceType
) {
    val fenChar: Char
        get() = if (color == PieceColor.WHITE) type.fenUpper else type.fenUpper.lowercaseChar()

    val scannerCode: String
        get() = "${color.code}${type.fenUpper}"

    companion object {
        fun fromFenChar(c: Char): ChessPiece? {
            val type = PieceType.fromChar(c) ?: return null
            val color = if (c.isUpperCase()) PieceColor.WHITE else PieceColor.BLACK
            return ChessPiece(color, type)
        }
    }
}

data class Square(val row: Int, val col: Int) {
    // row 0 = rank 8, row 7 = rank 1; col 0 = file a, col 7 = file h
    val isValid: Boolean get() = row in 0..7 && col in 0..7
    val fileChar: Char get() = ('a'.code + col).toChar()
    val rankNumber: Int get() = 8 - row
    val algebraic: String get() = "$fileChar$rankNumber"
    val isDark: Boolean get() = (row + col) % 2 == 1

    companion object {
        fun fromAlgebraic(str: String): Square? {
            val clean = str.trim().lowercase()
            if (clean.length != 2) return null
            val col = clean[0] - 'a'
            val rank = clean[1] - '0'
            if (col !in 0..7 || rank !in 1..8) return null
            return Square(row = 8 - rank, col = col)
        }
    }
}

data class CastlingRights(
    val whiteKingSide: Boolean = true,
    val whiteQueenSide: Boolean = true,
    val blackKingSide: Boolean = true,
    val blackQueenSide: Boolean = true
) {
    fun toFenString(): String {
        val sb = StringBuilder()
        if (whiteKingSide) sb.append('K')
        if (whiteQueenSide) sb.append('Q')
        if (blackKingSide) sb.append('k')
        if (blackQueenSide) sb.append('q')
        return if (sb.isEmpty()) "-" else sb.toString()
    }

    companion object {
        val NONE = CastlingRights(false, false, false, false)

        fun fromFenString(s: String): CastlingRights {
            if (s == "-" || s.isBlank()) return NONE
            return CastlingRights(
                whiteKingSide = 'K' in s,
                whiteQueenSide = 'Q' in s,
                blackKingSide = 'k' in s,
                blackQueenSide = 'q' in s
            )
        }
    }
}

data class ChessMove(
    val from: Square,
    val to: Square,
    val promotion: PieceType? = null,
    val isEnPassant: Boolean = false,
    val isCastleKingSide: Boolean = false,
    val isCastleQueenSide: Boolean = false
) {
    val uci: String
        get() = "${from.algebraic}${to.algebraic}${promotion?.fenUpper?.lowercaseChar() ?: ""}"
}

data class BoardArrow(
    val from: String,
    val to: String,
    val isEngineArrow: Boolean = true
)

data class MoveNode(
    val id: String,
    val ply: Int,
    val san: String,
    val uci: String,
    val fen: String,
    val lastFrom: String?,
    val lastTo: String?,
    val comment: String = "",
    val nags: List<String> = emptyList(),
    val parentId: String? = null,
    val childrenIds: List<String> = emptyList(),
    val userArrows: List<BoardArrow> = emptyList()
)

data class ChessBoardState(
    val initialFen: String = ChessEngineCore.STARTING_FEN,
    val fen: String = ChessEngineCore.STARTING_FEN,
    val orientation: PieceColor = PieceColor.WHITE,
    val rootNodeId: String = "root",
    val currentNodeId: String = "root",
    val nodes: Map<String, MoveNode> = mapOf(
        "root" to MoveNode(
            id = "root",
            ply = 0,
            san = "",
            uci = "",
            fen = ChessEngineCore.STARTING_FEN,
            lastFrom = null,
            lastTo = null
        )
    ),
    val headers: Map<String, String> = emptyMap(),
    val loadedGameId: String? = null,
    val loadedTitle: String? = null
) {
    val currentNode: MoveNode
        get() = nodes[currentNodeId] ?: nodes.getValue("root")

    val canGoBack: Boolean
        get() = currentNode.parentId != null

    val canGoForward: Boolean
        get() = currentNode.childrenIds.isNotEmpty()
}

data class BoardTheme(
    val id: String,
    val name: String,
    val lightSquare: Color,
    val darkSquare: Color,
    val border: Color,
    val coordOnLight: Color,
    val coordOnDark: Color,
    val highlight: Color,
    val description: String
)

val AVAILABLE_BOARD_THEMES = listOf(
    BoardTheme(
        id = "screenshot_wood",
        name = "Classic Wood (Default)",
        lightSquare = Color(0xFFF0D9B5),
        darkSquare = Color(0xFFB58863),
        border = Color(0xFF5D3E1D),
        coordOnLight = Color(0xFFB58863),
        coordOnDark = Color(0xFFF0D9B5),
        highlight = Color(0x77CDA349),
        description = "Warm tournament maple and walnut matching MoonChess Reader"
    ),
    BoardTheme(
        id = "wood_classic",
        name = "Walnut & Maple",
        lightSquare = Color(0xFFEDD6B0),
        darkSquare = Color(0xFFB88746),
        border = Color(0xFF5D3E1D),
        coordOnLight = Color(0xFFB88746),
        coordOnDark = Color(0xFFEDD6B0),
        highlight = Color(0x88DAA520),
        description = "Handcrafted walnut and maple grain palette"
    ),
    BoardTheme(
        id = "book_diagram",
        name = "Book Diagram Ink",
        lightSquare = Color(0xFFFFFFFF),
        darkSquare = Color(0xFFD8D4C8),
        border = Color(0xFF1C1917),
        coordOnLight = Color(0xFF44403C),
        coordOnDark = Color(0xFF1C1917),
        highlight = Color(0x66B45309),
        description = "Crisp printed chess book parchment and ink"
    ),
    BoardTheme(
        id = "tournament_green",
        name = "Tournament Green",
        lightSquare = Color(0xFFEEEED2),
        darkSquare = Color(0xFF769656),
        border = Color(0xFF36492B),
        coordOnLight = Color(0xFF769656),
        coordOnDark = Color(0xFFEEEED2),
        highlight = Color(0x88F7F769),
        description = "Official USCF and FIDE tournament vinyl green"
    ),
    BoardTheme(
        id = "lichess_blue",
        name = "Lichess Blue",
        lightSquare = Color(0xFFDEE3E6),
        darkSquare = Color(0xFF8CA2AD),
        border = Color(0xFF486574),
        coordOnLight = Color(0xFF8CA2AD),
        coordOnDark = Color(0xFFDEE3E6),
        highlight = Color(0x802980B9),
        description = "Clean modern ocean blue with ice light squares"
    ),
    BoardTheme(
        id = "dark_charcoal",
        name = "Dark Obsidian",
        lightSquare = Color(0xFF8F9DA8),
        darkSquare = Color(0xFF4F5C66),
        border = Color(0xFF273038),
        coordOnLight = Color(0xFF4F5C66),
        coordOnDark = Color(0xFF8F9DA8),
        highlight = Color(0x8038BDF8),
        description = "Midnight slate graphite with high piece contrast"
    ),
    BoardTheme(
        id = "saddle_leather",
        name = "Saddle Leather",
        lightSquare = Color(0xFFE8D2A6),
        darkSquare = Color(0xFF996335),
        border = Color(0xFF4A2C11),
        coordOnLight = Color(0xFF996335),
        coordOnDark = Color(0xFFE8D2A6),
        highlight = Color(0x88EAB308),
        description = "Vintage saddle leather with rich amber patina"
    )
)

enum class EngineChoice(val id: String, val displayLabel: String, val shortLabel: String) {
    VCH_LOCAL("vch_local", "VCH Engine (Offline)", "VCH Engine"),
    LICHESS_CLOUD("lichess_cloud", "Lichess Cloud Engine", "Lichess ..."),
    STOCKFISH_19_LICHESS("stockfish_19_lichess", "Stockfish 19 & Lichess ↗", "Stockfish 19")
}

data class PvLine(
    val scoreText: String,
    val sanSequence: String,
    val firstMoveUci: String? = null
)

data class EngineEvaluation(
    val scoreText: String,
    val scoreCentipawns: Int,
    val depth: Int,
    val engineName: String,
    val pvLines: List<PvLine>,
    val bestMoveArrows: List<BoardArrow>,
    val isMate: Boolean = false,
    val isCalculating: Boolean = false
)
