package com.example.manorahhorror;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.View;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512 | 4096);
  WebView web = new WebView(this);
  web.setBackgroundColor(0xff030407);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  s.setMediaPlaybackRequiresUserGesture(false);
  web.loadUrl("file:///android_asset/index.html");
  setContentView(web);
 }
 @Override public void onBackPressed() { super.onBackPressed(); }
}