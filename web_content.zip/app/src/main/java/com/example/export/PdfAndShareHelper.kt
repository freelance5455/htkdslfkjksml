package com.example.export

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.SeedData
import com.example.data.model.MonthlySummaryResult
import com.example.data.model.Student
import com.example.data.model.StudentRowData
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

object PdfAndShareHelper {

    fun buildDailyShareText(
        title: String,
        centre: String,
        className: String,
        dateIso: String,
        students: List<Student>,
        rows: Map<String, StudentRowData>,
        sotdStudentNum: String,
        includeDetails: Boolean
    ): String {
        val lines = mutableListOf<String>()
        val total = students.size
        var a1 = 0
        var a2 = 0
        var pres = 0
        var totalLines = 0.0
        var sotdName = ""

        students.forEach { st ->
            val key = st.studentNum.toString()
            val r = rows[key] ?: StudentRowData()
            if (r.a1) a1++
            if (r.a2) a2++
            if (r.isPresent) pres++
            totalLines += SeedData.parseNumeric(r.sl)
            if (sotdStudentNum == key) sotdName = st.name
        }

        val anyAtt = pres > 0
        lines.add("*$title*")
        if (centre.isNotBlank()) lines.add(centre)
        lines.add("سیکشن: $className")
        val dayUr = SeedData.urduDayForIso(dateIso)
        lines.add("تاریخ: $dateIso" + if (dayUr.isNotBlank()) " ($dayUr)" else "")
        lines.add("")
        lines.add("کل طلبہ: $total")
        if (anyAtt) {
            lines.add("حاضر: $pres  |  غیر حاضر: ${total - pres}")
            lines.add("فرسٹ ٹائم حاضری: $a1  |  سیکنڈ ٹائم حاضری: $a2")
        } else {
            lines.add("حاضری: درج نہیں")
        }
        if (totalLines > 0) {
            val formattedLines = if (totalLines % 1.0 == 0.0) totalLines.toInt().toString() else totalLines.toString()
            lines.add("کل سبق لائنیں: $formattedLines")
        }
        if (sotdName.isNotBlank()) {
            lines.add("⭐ طالب علم آف دی ڈے: $sotdName")
        }

        if (includeDetails) {
            lines.add("")
            students.forEachIndexed { idx, st ->
                val r = rows[st.studentNum.toString()] ?: StudentRowData()
                val parts = mutableListOf<String>()
                if (anyAtt) parts.add(if (r.isPresent) "حاضر" else "غیر حاضر")
                if (r.sp.isNotBlank() || r.sl.isNotBlank()) {
                    val spPart = if (r.sp.isNotBlank()) "پارہ ${r.sp.trim()}" else ""
                    val slPart = if (r.sl.isNotBlank()) " ${r.sl.trim()} لائن" else ""
                    parts.add("سبق: $spPart$slPart".trim())
                }
                if (r.sq.isNotBlank() || r.sqm.isNotBlank()) {
                    val sqPart = if (r.sq.isNotBlank()) "پارہ ${r.sq.trim()}" else ""
                    val sqmPart = if (r.sqm.isNotBlank()) " (غلطیاں ${r.sqm.trim()})" else ""
                    parts.add("سبقی: $sqPart$sqmPart".trim())
                }
                if (r.mp.isNotBlank() || r.mm.isNotBlank()) {
                    val mpPart = if (r.mp.isNotBlank()) "پارہ ${r.mp.trim()}" else ""
                    val mmPart = if (r.mm.isNotBlank()) " (غلطیاں ${r.mm.trim()})" else ""
                    parts.add("منزل: $mpPart$mmPart".trim())
                }
                lines.add("${idx + 1}. ${st.name}" + if (parts.isNotEmpty()) " — ${parts.joinToString(" | ")}" else "")
            }
        }
        return lines.joinToString("\n")
    }

    fun buildMonthlyShareText(
        title: String,
        centre: String,
        summary: MonthlySummaryResult
    ): String {
        val lines = mutableListOf<String>()
        lines.add("*$title*")
        if (centre.isNotBlank()) lines.add(centre)
        lines.add("سیکشن: ${summary.className}")
        lines.add("ماہانہ خلاصہ: ${summary.yearMonth}")
        lines.add("ریکارڈ شدہ شیٹس: ${summary.recordedSheetsCount}  |  کام کے دن: ${summary.workingDaysCount}")
        lines.add("")
        summary.students.forEachIndexed { idx, st ->
            val totStr = formatNum(st.totalSabaqLines)
            val avgStr = formatNum(st.dailyAvgLines)
            val sqStr = formatNum(st.sabqiMistakes)
            val mmStr = formatNum(st.manzilMistakes)
            lines.add(
                "${idx + 1}. ${st.name} — حاضر ${st.presentDays} | غیر حاضر ${st.absentDays} | سبق لائنیں $totStr" +
                    (if (st.dailyAvgLines > 0) " (اوسط $avgStr)" else "") +
                    " | غلطیاں: سبقی $sqStr، منزل $mmStr"
            )
        }
        return lines.joinToString("\n")
    }

    fun generateDailyReportPdf(
        context: Context,
        title: String,
        centre: String,
        className: String,
        dateIso: String,
        students: List<Student>,
        rows: Map<String, StudentRowData>,
        sotdStudentNum: String
    ): File {
        val pageWidth = 842 // A4 Landscape in points
        val pageHeight = 595
        val margin = 24f
        val arabicTf = try {
            ResourcesCompat.getFont(context, R.font.noto_naskh_arabic) ?: Typeface.DEFAULT
        } catch (_: Exception) {
            Typeface.DEFAULT
        }

        val doc = PdfDocument()
        val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(arabicTf, Typeface.BOLD)
            textSize = 15f
            color = Color.parseColor("#1B5E3F")
        }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = arabicTf
            textSize = 10.5f
            color = Color.DKGRAY
        }
        val thPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(arabicTf, Typeface.BOLD)
            textSize = 8.5f
            color = Color.parseColor("#1A1F1C")
        }
        val cellPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = arabicTf
            textSize = 8.5f
            color = Color.BLACK
        }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#9E9886")
            strokeWidth = 0.8f
            style = Paint.Style.STROKE
        }
        val headBgPaint = Paint().apply {
            color = Color.parseColor("#E9E4D6")
            style = Paint.Style.FILL
        }
        val altRowPaint = Paint().apply {
            color = Color.parseColor("#F9F7F1")
            style = Paint.Style.FILL
        }

        // RTL column order (rightmost = #, Name, Attendance, Sabaq, Sabqi, Manzil, Target)
        // Drawn left-to-right in coordinates [margin .. pageWidth - margin] = 794pt
        data class Col(val label: String, val width: Float, val extractor: (Int, Student, StudentRowData) -> String)
        val cols = listOf(
            Col("ہدف تاریخ", 54f) { _, _, r -> r.td },
            Col("ہدف لائنیں", 42f) { _, _, r -> r.tl },
            Col("منزل سامع", 46f) { _, _, r -> r.ms },
            Col("منزل غلطی", 42f) { _, _, r -> r.mm },
            Col("منزل ربع", 56f) { _, _, r -> listOf(r.q1, r.q2, r.q3, r.q4).filter { it.isNotBlank() }.joinToString("/") },
            Col("منزل پارہ", 42f) { _, _, r -> r.mp },
            Col("سبقی سامع", 46f) { _, _, r -> r.sqs },
            Col("سبقی غلطی", 42f) { _, _, r -> r.sqm },
            Col("سبقی ربع", 56f) { _, _, r -> listOf(r.sq1, r.sq2, r.sq3, r.sq4).filter { it.isNotBlank() }.joinToString("/") },
            Col("سبقی پارہ", 42f) { _, _, r -> r.sq },
            Col("سبق لائنیں", 42f) { _, _, r -> r.sl },
            Col("سبق پارہ", 42f) { _, _, r -> r.sp },
            Col("ثانی حاضری", 36f) { _, _, r -> if (r.a2) "✓" else "—" },
            Col("اول حاضری", 36f) { _, _, r -> if (r.a1) "✓" else "—" },
            Col("طالب علم کا نام", 136f) { _, st, _ ->
                if (st.studentNum.toString() == sotdStudentNum) "★ ${st.name}" else st.name
            },
            Col("#", 28f) { idx, _, _ -> (idx + 1).toString() }
        )

        val rowsPerPage = 19
        val chunks = if (students.isEmpty()) listOf(emptyList()) else students.chunked(rowsPerPage)
        val dayUr = SeedData.urduDayForIso(dateIso)
        val presCount = students.count { (rows[it.studentNum.toString()] ?: StudentRowData()).isPresent }
        val sotdName = students.firstOrNull { it.studentNum.toString() == sotdStudentNum }?.name ?: "—"

        chunks.forEachIndexed { pageIdx, chunk ->
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIdx + 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawColor(Color.WHITE)

            var y = margin
            drawCenteredText(canvas, "$title — $className", pageWidth / 2f, y, pageWidth - margin * 2, headerPaint)
            y += 22f
            if (centre.isNotBlank()) {
                drawCenteredText(canvas, centre, pageWidth / 2f, y, pageWidth - margin * 2, subPaint)
                y += 16f
            }
            val metaLine = "تاریخ: $dateIso ($dayUr)   |   کل طلبہ: ${students.size}   |   حاضر: $presCount   |   طالب علم آف دی ڈے: $sotdName   |   صفحہ ${pageIdx + 1}/${chunks.size}"
            drawCenteredText(canvas, metaLine, pageWidth / 2f, y, pageWidth - margin * 2, subPaint)
            y += 22f

            // Table Header
            val thHeight = 28f
            var x = margin
            cols.forEach { col ->
                canvas.drawRect(x, y, x + col.width, y + thHeight, headBgPaint)
                canvas.drawRect(x, y, x + col.width, y + thHeight, borderPaint)
                drawCellText(canvas, col.label, x + 2f, y + 4f, col.width - 4f, thPaint, Layout.Alignment.ALIGN_CENTER)
                x += col.width
            }
            y += thHeight

            // Rows
            val rowHeight = 22f
            chunk.forEachIndexed { localIdx, student ->
                val globalIdx = pageIdx * rowsPerPage + localIdx
                val rowData = rows[student.studentNum.toString()] ?: StudentRowData()
                x = margin
                cols.forEach { col ->
                    if (localIdx % 2 == 1) {
                        canvas.drawRect(x, y, x + col.width, y + rowHeight, altRowPaint)
                    }
                    canvas.drawRect(x, y, x + col.width, y + rowHeight, borderPaint)
                    val textVal = col.extractor(globalIdx, student, rowData)
                    val align = if (col.label == "طالب علم کا نام") Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_CENTER
                    drawCellText(canvas, textVal, x + 3f, y + 3f, col.width - 6f, cellPaint, align)
                    x += col.width
                }
                y += rowHeight
            }
            doc.finishPage(page)
        }

        val outDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val safeClass = className.replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF_-]"), "_")
        val file = File(outDir, "Hifz_Daily_${safeClass}_$dateIso.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun generateMonthlySummaryPdf(
        context: Context,
        title: String,
        centre: String,
        summary: MonthlySummaryResult
    ): File {
        val pageWidth = 842
        val pageHeight = 595
        val margin = 28f
        val arabicTf = try {
            ResourcesCompat.getFont(context, R.font.noto_naskh_arabic) ?: Typeface.DEFAULT
        } catch (_: Exception) {
            Typeface.DEFAULT
        }

        val doc = PdfDocument()
        val headerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(arabicTf, Typeface.BOLD)
            textSize = 15f
            color = Color.parseColor("#1B5E3F")
        }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = arabicTf
            textSize = 10.5f
            color = Color.DKGRAY
        }
        val thPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(arabicTf, Typeface.BOLD)
            textSize = 9.5f
            color = Color.parseColor("#1A1F1C")
        }
        val cellPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = arabicTf
            textSize = 9.5f
            color = Color.BLACK
        }
        val borderPaint = Paint().apply {
            color = Color.parseColor("#9E9886")
            strokeWidth = 0.9f
            style = Paint.Style.STROKE
        }
        val headBgPaint = Paint().apply {
            color = Color.parseColor("#E9E4D6")
            style = Paint.Style.FILL
        }
        val altRowPaint = Paint().apply {
            color = Color.parseColor("#F9F7F1")
            style = Paint.Style.FILL
        }

        // RTL column order (rightmost = #, Name, Present, Absent, Total Lines, Avg, Sabqi Err, Manzil Err, Last Para, SOTD)
        // Total width = 786pt
        data class MCol(val label: String, val width: Float, val extractor: (Int, com.example.data.model.MonthlyStudentSummary) -> String)
        val cols = listOf(
            MCol("اسٹوڈنٹ آف دی ڈے", 66f) { _, s -> if (s.sotdCount > 0) s.sotdCount.toString() else "—" },
            MCol("آخری سبق پارہ", 70f) { _, s -> s.latestSabaqPara.ifBlank { "—" } },
            MCol("منزل غلطیاں", 68f) { _, s -> formatNum(s.manzilMistakes) },
            MCol("سبقی غلطیاں", 68f) { _, s -> formatNum(s.sabqiMistakes) },
            MCol("روزانہ اوسط", 68f) { _, s -> formatNum(s.dailyAvgLines) },
            MCol("کل سبق لائنیں", 78f) { _, s -> formatNum(s.totalSabaqLines) },
            MCol("غیر حاضر", 60f) { _, s -> s.absentDays.toString() },
            MCol("حاضر", 56f) { _, s -> s.presentDays.toString() },
            MCol("طالب علم کا نام", 214f) { _, s -> s.name },
            MCol("#", 38f) { idx, _ -> (idx + 1).toString() }
        )

        val rowsPerPage = 17
        val chunks = if (summary.students.isEmpty()) listOf(emptyList()) else summary.students.chunked(rowsPerPage)

        chunks.forEachIndexed { pageIdx, chunk ->
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIdx + 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawColor(Color.WHITE)

            var y = margin
            drawCenteredText(canvas, "$title — ماہانہ خلاصہ (${summary.className})", pageWidth / 2f, y, pageWidth - margin * 2, headerPaint)
            y += 22f
            if (centre.isNotBlank()) {
                drawCenteredText(canvas, centre, pageWidth / 2f, y, pageWidth - margin * 2, subPaint)
                y += 16f
            }
            val metaLine = "مہینہ: ${summary.yearMonth}   |   ریکارڈ شدہ شیٹس: ${summary.recordedSheetsCount}   |   کام کے دن: ${summary.workingDaysCount}   |   صفحہ ${pageIdx + 1}/${chunks.size}"
            drawCenteredText(canvas, metaLine, pageWidth / 2f, y, pageWidth - margin * 2, subPaint)
            y += 24f

            val thHeight = 30f
            var x = margin
            cols.forEach { col ->
                canvas.drawRect(x, y, x + col.width, y + thHeight, headBgPaint)
                canvas.drawRect(x, y, x + col.width, y + thHeight, borderPaint)
                drawCellText(canvas, col.label, x + 3f, y + 4f, col.width - 6f, thPaint, Layout.Alignment.ALIGN_CENTER)
                x += col.width
            }
            y += thHeight

            val rowHeight = 23f
            chunk.forEachIndexed { localIdx, st ->
                val globalIdx = pageIdx * rowsPerPage + localIdx
                x = margin
                cols.forEach { col ->
                    if (localIdx % 2 == 1) canvas.drawRect(x, y, x + col.width, y + rowHeight, altRowPaint)
                    canvas.drawRect(x, y, x + col.width, y + rowHeight, borderPaint)
                    val align = if (col.label == "طالب علم کا نام") Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_CENTER
                    drawCellText(canvas, col.extractor(globalIdx, st), x + 4f, y + 3f, col.width - 8f, cellPaint, align)
                    x += col.width
                }
                y += rowHeight
            }

            // Totals footer on last page
            if (pageIdx == chunks.lastIndex && summary.students.isNotEmpty()) {
                val totalLines = summary.students.sumOf { it.totalSabaqLines }
                val totalSabqiErr = summary.students.sumOf { it.sabqiMistakes }
                val totalManzilErr = summary.students.sumOf { it.manzilMistakes }
                x = margin
                cols.forEach { col ->
                    canvas.drawRect(x, y, x + col.width, y + rowHeight, headBgPaint)
                    canvas.drawRect(x, y, x + col.width, y + rowHeight, borderPaint)
                    val txt = when (col.label) {
                        "کل سبق لائنیں" -> formatNum(totalLines)
                        "سبقی غلطیاں" -> formatNum(totalSabqiErr)
                        "منزل غلطیاں" -> formatNum(totalManzilErr)
                        "طالب علم کا نام" -> "مجموعہ (کل)"
                        else -> ""
                    }
                    drawCellText(canvas, txt, x + 4f, y + 3f, col.width - 8f, thPaint, Layout.Alignment.ALIGN_CENTER)
                    x += col.width
                }
            }
            doc.finishPage(page)
        }

        val outDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val safeClass = summary.className.replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF_-]"), "_")
        val file = File(outDir, "Hifz_Monthly_${safeClass}_${summary.yearMonth}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun writeReportTextFile(context: Context, fileName: String, content: String): File {
        val outDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val file = File(outDir, fileName)
        file.writeText(content, Charsets.UTF_8)
        return file
    }

    fun shareFileToWhatsApp(
        context: Context,
        file: File,
        mimeType: String,
        captionText: String? = null
    ) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
        val pm = context.packageManager

        val baseIntent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            if (!captionText.isNullOrBlank()) {
                putExtra(Intent.EXTRA_TEXT, captionText)
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        for (pkg in packages) {
            val targeted = Intent(baseIntent).setPackage(pkg)
            if (targeted.resolveActivity(pm) != null) {
                context.startActivity(targeted)
                return
            }
        }
        // Fallback to system chooser if WhatsApp is not installed
        context.startActivity(Intent.createChooser(baseIntent, "Share Report File"))
    }

    fun shareFileSystem(context: Context, file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    fun copyPdfToUri(context: Context, pdfFile: File, targetUri: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                pdfFile.inputStream().use { input -> input.copyTo(out) }
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun copyTextToClipboard(context: Context, label: String, text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
    }

    fun formatNum(value: Double): String {
        return if (value % 1.0 == 0.0) value.toInt().toString()
        else String.format(Locale.US, "%.1f", value)
    }

    private fun drawCenteredText(
        canvas: Canvas,
        text: String,
        centerX: Float,
        topY: Float,
        maxWidth: Float,
        paint: TextPaint
    ) {
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, maxWidth.toInt().coerceAtLeast(10))
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
        canvas.save()
        canvas.translate(centerX - maxWidth / 2f, topY)
        layout.draw(canvas)
        canvas.restore()
    }

    private fun drawCellText(
        canvas: Canvas,
        text: String,
        leftX: Float,
        topY: Float,
        width: Float,
        paint: TextPaint,
        alignment: Layout.Alignment
    ) {
        if (text.isBlank()) return
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt().coerceAtLeast(8))
            .setAlignment(alignment)
            .setMaxLines(2)
            .setIncludePad(false)
            .build()
        canvas.save()
        canvas.translate(leftX, topY)
        layout.draw(canvas)
        canvas.restore()
    }
}
