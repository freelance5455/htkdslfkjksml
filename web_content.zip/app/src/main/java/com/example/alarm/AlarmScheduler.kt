package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.MainActivity
import com.example.data.model.AlarmEntity
import com.example.receiver.AlarmReceiver
import java.util.Calendar

class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun schedule(alarm: AlarmEntity) {
        if (!alarm.isEnabled) return

        val triggerTime = calculateNextTriggerMillis(alarm)
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_ALARM
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarm.id)
            putExtra(AlarmReceiver.EXTRA_ALARM_LABEL, alarm.label)
            putExtra(AlarmReceiver.EXTRA_ALARM_VIBRATE, alarm.vibrate)
            putExtra(AlarmReceiver.EXTRA_ALARM_TONE, alarm.soundTone)
            putExtra(AlarmReceiver.EXTRA_CUSTOM_AUDIO_PATH, alarm.customAudioPath)
            putExtra(AlarmReceiver.EXTRA_SNOOZE_MINUTES, alarm.snoozeDurationMinutes)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarm.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = PendingIntent.getActivity(
            context,
            alarm.id.toInt(),
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(AlarmReceiver.EXTRA_RINGING_ALARM_ID, alarm.id)
                putExtra(AlarmReceiver.EXTRA_RINGING_LABEL, alarm.label)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setAlarmClock(
                        AlarmManager.AlarmClockInfo(triggerTime, showIntent),
                        pendingIntent
                    )
                } else {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setAlarmClock(
                    AlarmManager.AlarmClockInfo(triggerTime, showIntent),
                    pendingIntent
                )
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            // Fallback safe scheduling
            try {
                alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            } catch (t: Throwable) {
                t.printStackTrace()
            }
        }
    }

    fun cancel(alarm: AlarmEntity) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = AlarmReceiver.ACTION_TRIGGER_ALARM
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarm.id.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        pendingIntent?.let {
            alarmManager.cancel(it)
            it.cancel()
        }
    }

    companion object {
        fun calculateNextTriggerMillis(alarm: AlarmEntity): Long {
            if (alarm.isSnoozed && alarm.snoozeTimeMillis > System.currentTimeMillis()) {
                return alarm.snoozeTimeMillis
            }

            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, alarm.hour)
                set(Calendar.MINUTE, alarm.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            val daysList = alarm.getDaysList()
            if (daysList.isEmpty()) {
                // One-time alarm
                if (target.timeInMillis <= now.timeInMillis) {
                    target.add(Calendar.DAY_OF_YEAR, 1)
                }
                return target.timeInMillis
            }

            // Convert Calendar.DAY_OF_WEEK (Sun=1, Mon=2... Sat=7) to 1=Mon ... 7=Sun
            fun calDayToMonSun(calDay: Int): Int {
                return if (calDay == Calendar.SUNDAY) 7 else calDay - 1
            }

            val currentDayMonSun = calDayToMonSun(now.get(Calendar.DAY_OF_WEEK))

            // Check if today is one of the alarm days and the time is in future
            if (daysList.contains(currentDayMonSun) && target.timeInMillis > now.timeInMillis) {
                return target.timeInMillis
            }

            // Find how many days ahead the next day is
            for (offset in 1..7) {
                val candidateDay = ((currentDayMonSun - 1 + offset) % 7) + 1
                if (daysList.contains(candidateDay)) {
                    target.add(Calendar.DAY_OF_YEAR, offset)
                    return target.timeInMillis
                }
            }

            // Fallback
            if (target.timeInMillis <= now.timeInMillis) {
                target.add(Calendar.DAY_OF_YEAR, 1)
            }
            return target.timeInMillis
        }

        fun getTimeRemainingString(triggerMillis: Long): String {
            val diff = triggerMillis - System.currentTimeMillis()
            if (diff <= 0) return "Due now"

            val totalMinutes = diff / (1000 * 60)
            val hours = totalMinutes / 60
            val minutes = totalMinutes % 60
            val days = hours / 24
            val remainingHours = hours % 24

            return when {
                days > 0 -> "in ${days}d ${remainingHours}h ${minutes}m"
                hours > 0 -> "in ${hours}h ${minutes}m"
                minutes > 0 -> "in ${minutes} min"
                else -> "in less than 1 min"
            }
        }
    }
}
