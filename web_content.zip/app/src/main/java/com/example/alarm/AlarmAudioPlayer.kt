package com.example.alarm

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import java.io.File

object AlarmAudioPlayer {
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var toneGenerator: ToneGenerator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var isPlaying = false

    fun start(
        context: Context,
        vibrate: Boolean = true,
        toneName: String = "Digital Pulse",
        customAudioPath: String? = null
    ) {
        if (isPlaying) stop()
        isPlaying = true

        // Acquire WakeLock to ensure audio continues playing while screen is off / phone is sleeping
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "chrono:AlarmAudioPlayerWakeLock"
            )?.apply {
                setReferenceCounted(false)
                acquire(10 * 60 * 1000L) // 10 minutes maximum duration
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 1. Play Sound
        var playedSuccessfully = false
        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )

                var sourceLoaded = false
                if (!customAudioPath.isNullOrBlank()) {
                    val file = File(customAudioPath)
                    if (file.exists() && file.canRead()) {
                        setDataSource(file.absolutePath)
                        sourceLoaded = true
                    } else if (customAudioPath.startsWith("content://")) {
                        setDataSource(context, Uri.parse(customAudioPath))
                        sourceLoaded = true
                    }
                }

                if (!sourceLoaded) {
                    val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    if (alertUri != null) {
                        setDataSource(context, alertUri)
                        sourceLoaded = true
                    }
                }

                if (sourceLoaded) {
                    isLooping = true
                    prepare()
                    start()
                    playedSuccessfully = true
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Fallback to ToneGenerator if MediaPlayer failed
        if (!playedSuccessfully) {
            try {
                toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 5000)
            } catch (t: Exception) {
                t.printStackTrace()
            }
        }

        // 2. Play Vibration
        if (vibrate) {
            try {
                vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                    vm?.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                }

                val pattern = longArrayOf(0, 500, 250, 500, 250, 800)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(pattern, 0)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun stop() {
        isPlaying = false
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            mediaPlayer = null
        }

        try {
            toneGenerator?.stopTone()
            toneGenerator?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            toneGenerator = null
        }

        try {
            vibrator?.cancel()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            vibrator = null
        }

        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            wakeLock = null
        }
    }

    fun isCurrentlyPlaying(): Boolean = isPlaying
}
