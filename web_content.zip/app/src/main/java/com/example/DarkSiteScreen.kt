package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ==========================================
// DARK USER SECTION
// Face Verification Access Gate + Exclusive Dark Site
// ==========================================

@Composable
fun MtxDarkSiteScreen(
  darkAuth: DarkUserAuth,
  darkVideos: List<VideoItem>,
  darkPhotos: List<PhotoItem>,
  onUpdateAuth: (DarkUserAuth) -> Unit,
  onSelectVideo: (VideoItem) -> Unit,
  onSelectPhoto: (PhotoItem) -> Unit,
  onRefreshStatus: () -> Unit
) {
  if (darkAuth.isApproved) {
    // Once admin approved: DIRECT ACCESS with NO NEED to apply next time!
    MtxDarkExclusiveSite(
      darkVideos = darkVideos,
      darkPhotos = darkPhotos,
      onSelectVideo = onSelectVideo,
      onSelectPhoto = onSelectPhoto
    )
  } else {
    // Gate: Apply to enter Dark User site with face photo
    MtxDarkAccessGate(
      darkAuth = darkAuth,
      onUpdateAuth = onUpdateAuth,
      onRefreshStatus = onRefreshStatus
    )
  }
}

// ==========================================
// 1. DARK USER APPLICATION GATE (Face Verification)
// ==========================================
@Composable
fun MtxDarkAccessGate(
  darkAuth: DarkUserAuth,
  onUpdateAuth: (DarkUserAuth) -> Unit,
  onRefreshStatus: () -> Unit
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  var applicantName by remember { mutableStateOf(darkAuth.userName) }
  var selectedFaceUri by remember { mutableStateOf(darkAuth.facePhotoUri) }
  var isSubmitting by remember { mutableStateOf(false) }
  var isCheckingStatus by remember { mutableStateOf(false) }
  var feedbackMessage by remember { mutableStateOf("") }

  // Camera capture (direct selfie photo click with camera)
  val cameraCaptureLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.TakePicturePreview()
  ) { bitmap: Bitmap? ->
    if (bitmap != null) {
      coroutineScope.launch {
        feedbackMessage = "Saving clicked face photo..."
        val destFile = File(context.filesDir, "face_click_${System.currentTimeMillis()}.jpg")
        withContext(Dispatchers.IO) {
          FileOutputStream(destFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
          }
        }
        selectedFaceUri = destFile.absolutePath
        feedbackMessage = "Face photo clicked! Enter your display name and tap Submit Application."
      }
    }
  }

  // Runtime CAMERA permission request
  val cameraPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted: Boolean ->
    if (isGranted) {
      cameraCaptureLauncher.launch(null)
    } else {
      feedbackMessage = "Camera permission is required to click your face photo."
    }
  }

  fun requestAndLaunchCamera() {
    val hasPermission = ContextCompat.checkSelfPermission(
      context,
      Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    if (hasPermission) {
      cameraCaptureLauncher.launch(null)
    } else {
      cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF07080B))
      .padding(horizontal = 20.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    item {
      Spacer(modifier = Modifier.height(24.dp))

      // Glowing Dark Security Shield Badge
      Box(
        modifier = Modifier
          .size(76.dp)
          .clip(CircleShape)
          .background(
            Brush.radialGradient(
              listOf(Color(0xFFDC2626).copy(alpha = 0.45f), Color(0xFF0F0B15))
            )
          )
          .border(2.dp, Color(0xFFEF4444), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          Icons.Default.Security,
          contentDescription = null,
          tint = Color(0xFFF87171),
          modifier = Modifier.size(38.dp)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Text("MTX ", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text("DARK ZONE", color = Color(0xFFEF4444), fontSize = 24.sp, fontWeight = FontWeight.Black)
      }

      Text(
        "Restricted Member Archive & Private Media Vault",
        color = Color(0xFF94A3B8),
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 4.dp, bottom = 20.dp)
      )
    }

    // STATE A: Application Pending Admin Approval
    if (darkAuth.status == "pending") {
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("dark_application_pending_card"),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF131018)),
          shape = RoundedCornerShape(20.dp),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFEAB308))
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(
              modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(Color(0xFFEAB308).copy(alpha = 0.15f))
                .border(1.dp, Color(0xFFEAB308), CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Text("⏳", fontSize = 22.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text("Application Under Admin Review", color = Color(0xFFFDE047), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              "Your face photo has been submitted to the Administrator. Once approved, you will have permanent access to the Dark Site without ever needing to apply again.",
              color = Color(0xFFCBD5E1),
              fontSize = 12.sp,
              textAlign = TextAlign.Center,
              lineHeight = 18.sp
            )

            if (selectedFaceUri.isNotBlank()) {
              Spacer(modifier = Modifier.height(16.dp))
              Text("Submitted Face Photo:", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              Spacer(modifier = Modifier.height(6.dp))
              Box(
                modifier = Modifier
                  .size(100.dp)
                  .clip(RoundedCornerShape(16.dp))
                  .border(2.dp, Color(0xFFEAB308), RoundedCornerShape(16.dp))
              ) {
                AsyncImage(
                  model = selectedFaceUri,
                  contentDescription = "Face Photo Preview",
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize()
                )
              }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
              onClick = {
                coroutineScope.launch {
                  isCheckingStatus = true
                  val (approved, status) = MtxCloudSync.checkDarkUserStatus(darkAuth.userId)
                  if (approved) {
                    val updated = darkAuth.copy(isApproved = true, status = "approved")
                    DarkUserStorage.save(context, updated)
                    onUpdateAuth(updated)
                  } else {
                    onRefreshStatus()
                  }
                  isCheckingStatus = false
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("check_dark_approval_status_button"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEAB308)),
              shape = RoundedCornerShape(14.dp)
            ) {
              if (isCheckingStatus) {
                CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Checking Status...", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              } else {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Refresh Approval Status", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    } else {
      // STATE B: Application Form (User Clicks/Uploads Face Photo)
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("dark_application_form_card"),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF13101A)),
          shape = RoundedCornerShape(22.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.4f))
        ) {
          Column(modifier = Modifier.padding(22.dp)) {
            Text("Apply for Dark User Access", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(
              "Access requires one-time identity verification. Submit your face photo below. The administrator will review and grant permanent access.",
              color = Color(0xFF94A3B8),
              fontSize = 11.sp,
              modifier = Modifier.padding(top = 4.dp, bottom = 18.dp),
              lineHeight = 16.sp
            )

            // Step 1: User Alias / Name
            Text("1. Enter Your Display Alias", color = Color(0xFFF1F5F9), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
              value = applicantName,
              onValueChange = { applicantName = it },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("dark_user_alias_input"),
              placeholder = { Text("e.g. PhantomShadow or your name", color = Color(0xFF64748B), fontSize = 12.sp) },
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF090A0F),
                unfocusedContainerColor = Color(0xFF090A0F),
                focusedBorderColor = Color(0xFFEF4444),
                unfocusedBorderColor = Color(0xFF2A2234),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
              ),
              shape = RoundedCornerShape(12.dp),
              singleLine = true
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Step 2: Face Photo Capture with Camera Only
            Text("2. Click Face Photo with Camera", color = Color(0xFFF1F5F9), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("Take a live photo showing your face clearly. Gallery uploads are disabled for security verification.", color = Color(0xFF94A3B8), fontSize = 10.sp)
            Spacer(modifier = Modifier.height(10.dp))

            if (selectedFaceUri.isNotBlank()) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(Color(0xFF0A0710), RoundedCornerShape(14.dp))
                  .border(1.dp, Color(0xFF10B981), RoundedCornerShape(14.dp))
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                  modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, Color(0xFF10B981), RoundedCornerShape(10.dp))
                ) {
                  AsyncImage(
                    model = selectedFaceUri,
                    contentDescription = "Selected Face Photo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                  )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Face Photo Captured", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  }
                  Text("Tap retake icon to click again", color = Color(0xFF94A3B8), fontSize = 10.sp)
                }

                IconButton(
                  onClick = { requestAndLaunchCamera() },
                  modifier = Modifier.size(36.dp)
                ) {
                  Icon(Icons.Default.CameraAlt, contentDescription = "Retake", tint = Color(0xFF60A5FA), modifier = Modifier.size(18.dp))
                }
              }
            } else {
              // Primary & Only Option: Click Face Photo with Camera
              Button(
                onClick = { requestAndLaunchCamera() },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(50.dp)
                  .testTag("dark_user_click_camera_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(14.dp)
              ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text("Click Face Photo with Camera", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
              }
            }

            Spacer(modifier = Modifier.height(22.dp))

            // Step 3: Submit Application Button
            Button(
              onClick = {
                if (applicantName.isBlank()) {
                  feedbackMessage = "Please enter your name or display alias."
                  return@Button
                }
                if (selectedFaceUri.isBlank()) {
                  feedbackMessage = "Please click your face photo with the camera first."
                  return@Button
                }

                coroutineScope.launch {
                  isSubmitting = true
                  feedbackMessage = "Uploading face photo to cloud server..."

                  val localFile = File(selectedFaceUri)
                  if (!localFile.exists()) {
                    isSubmitting = false
                    feedbackMessage = "Server unreachable, application NOT sent"
                    return@launch
                  }

                  // 1. Upload face photo to cloud server
                  val cloudFaceUrl = withContext(Dispatchers.IO) {
                    MtxCloudSync.uploadMediaFile(localFile, "image/jpeg")
                  }

                  if (cloudFaceUrl.isNullOrBlank()) {
                    isSubmitting = false
                    feedbackMessage = "Server unreachable, application NOT sent"
                    return@launch
                  }

                  // 2. Submit application to cloud server
                  feedbackMessage = "Submitting application to cloud server..."
                  val isSubmitted = withContext(Dispatchers.IO) {
                    MtxCloudSync.submitDarkUserApplication(
                      userId = darkAuth.userId,
                      userName = applicantName.trim(),
                      facePhotoUri = cloudFaceUrl
                    )
                  }

                  if (!isSubmitted) {
                    isSubmitting = false
                    feedbackMessage = "Server unreachable, application NOT sent"
                    return@launch
                  }

                  // 3. BOTH SUCCEEDED! Record locally and transition state
                  val newApplication = DarkUserApplication(
                    userId = darkAuth.userId,
                    userName = applicantName.trim(),
                    facePhotoUri = cloudFaceUrl,
                    status = "pending",
                    appliedAt = "Just now"
                  )
                  DarkRequestStorage.saveRequest(context, newApplication)

                  val updated = darkAuth.copy(
                    userName = applicantName.trim(),
                    facePhotoUri = cloudFaceUrl,
                    status = "pending",
                    isApproved = false
                  )
                  DarkUserStorage.save(context, updated)
                  onUpdateAuth(updated)

                  isSubmitting = false
                  feedbackMessage = "Application submitted! Awaiting administrator approval."
                }
              },
              enabled = !isSubmitting,
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("dark_user_submit_application_button"),
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
              shape = RoundedCornerShape(14.dp)
            ) {
              if (isSubmitting) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Submitting to Admin...", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              } else {
                Icon(Icons.Default.Security, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text("Submit Application for Approval", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
              }
            }

            if (feedbackMessage.isNotBlank()) {
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                feedbackMessage,
                color = if (feedbackMessage.startsWith("Application submitted")) Color(0xFF10B981) else Color(0xFFFCA5A5),
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
              )
            }
          }
        }
      }
    }

    item {
      Spacer(modifier = Modifier.height(24.dp))
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0B15)),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF281E38))
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Security Protocol Notice:", color = Color(0xFFC084FC), fontSize = 11.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            "• Face verification is required only once.\n• Once approved, your device remains permanently authorized.\n• Admin uploads exclusive high-bitrate videos and 4K stills directly to the Dark Site.",
            color = Color(0xFF94A3B8),
            fontSize = 10.sp,
            lineHeight = 15.sp
          )
        }
      }
      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}

// ==========================================
// 2. EXCLUSIVE DARK SITE (Approved Member Area)
// ==========================================
@Composable
fun MtxDarkExclusiveSite(
  darkVideos: List<VideoItem>,
  darkPhotos: List<PhotoItem>,
  onSelectVideo: (VideoItem) -> Unit,
  onSelectPhoto: (PhotoItem) -> Unit
) {
  // 0 = Dark Videos, 1 = Dark Photos
  var darkSubTab by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var selectedDarkCategory by remember { mutableStateOf("All") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF07080B))
  ) {
    // Top VIP Member Banner
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .background(
          Brush.horizontalGradient(
            listOf(Color(0xFF7F1D1D).copy(alpha = 0.5f), Color(0xFF3B0764).copy(alpha = 0.5f))
          )
        )
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.LockOpen, contentDescription = null, tint = Color(0xFFFDE047), modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("DARK SITE VIP MEMBER", color = Color(0xFFFDE047), fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF10B981).copy(alpha = 0.2f))
            .border(1.dp, Color(0xFF10B981), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
          Text("✓ Approved", color = Color(0xFF34D399), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // Sub-Tabs: Dark Videos vs Dark Photos
    TabRow(
      selectedTabIndex = darkSubTab,
      containerColor = Color(0xFF0D0B14),
      contentColor = Color.White,
      indicator = { tabPositions ->
        SecondaryIndicator(
          Modifier.tabIndicatorOffset(tabPositions[darkSubTab]),
          color = Color(0xFFEF4444),
          height = 3.dp
        )
      }
    ) {
      Tab(
        selected = darkSubTab == 0,
        onClick = { darkSubTab = 0 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.SmartDisplay, contentDescription = null, modifier = Modifier.size(14.dp), tint = if (darkSubTab == 0) Color(0xFFEF4444) else Color(0xFF94A3B8))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Dark Videos (${darkVideos.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (darkSubTab == 0) Color(0xFFEF4444) else Color(0xFF94A3B8))
          }
        },
        modifier = Modifier.testTag("dark_tab_videos")
      )

      Tab(
        selected = darkSubTab == 1,
        onClick = { darkSubTab = 1 },
        text = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Face, contentDescription = null, modifier = Modifier.size(14.dp), tint = if (darkSubTab == 1) Color(0xFFA855F7) else Color(0xFF94A3B8))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Dark Photos (${darkPhotos.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (darkSubTab == 1) Color(0xFFA855F7) else Color(0xFF94A3B8))
          }
        },
        modifier = Modifier.testTag("dark_tab_photos")
      )
    }

    // Search Box for Dark Zone
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp)
        .testTag("dark_search_input"),
      placeholder = { Text("Search dark archive...", color = Color(0xFF64748B), fontSize = 12.sp) },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFFEF4444)) },
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = Color(0xFF13101A),
        unfocusedContainerColor = Color(0xFF13101A),
        focusedBorderColor = Color(0xFFEF4444),
        unfocusedBorderColor = Color(0xFF241A30),
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White
      ),
      shape = RoundedCornerShape(12.dp)
    )

    // TAB 0: DARK VIDEOS
    if (darkSubTab == 0) {
      val filteredDarkVideos = remember(darkVideos, searchQuery, selectedDarkCategory) {
        darkVideos.filter { vid ->
          val matchesCat = (selectedDarkCategory == "All") || (vid.category == selectedDarkCategory)
          val matchesQ = searchQuery.isBlank() || vid.title.contains(searchQuery, ignoreCase = true)
          matchesCat && matchesQ
        }
      }

      if (darkVideos.isNotEmpty()) {
        val cats = listOf("All") + darkVideos.map { it.category }.distinct()
        LazyRow(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          items(cats) { cat ->
            val isSelected = cat == selectedDarkCategory
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) Color(0xFFDC2626) else Color(0xFF161220))
                .border(1.dp, if (isSelected) Color(0xFFEF4444) else Color(0xFF281E38), RoundedCornerShape(8.dp))
                .clickable { selectedDarkCategory = cat }
                .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
              Text(
                cat,
                color = if (isSelected) Color.White else Color(0xFF94A3B8),
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
              )
            }
          }
        }
      }

      if (filteredDarkVideos.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("No dark videos match your search.", color = Color(0xFF94A3B8), fontSize = 12.sp)
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          items(filteredDarkVideos) { video ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .border(1.dp, Color(0xFF381F28), RoundedCornerShape(18.dp))
                .clickable { onSelectVideo(video) }
                .testTag("dark_video_card_${video.id}"),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF120E1A)),
              shape = RoundedCornerShape(18.dp)
            ) {
              Column {
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .background(
                      Brush.radialGradient(
                        listOf(Color(0xFFDC2626).copy(alpha = 0.45f), Color(0xFF09070D))
                      )
                    ),
                  contentAlignment = Alignment.Center
                ) {
                  Box(
                    modifier = Modifier
                      .size(54.dp)
                      .clip(CircleShape)
                      .background(Color(0xFFDC2626).copy(alpha = 0.9f)),
                    contentAlignment = Alignment.Center
                  ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(30.dp))
                  }

                  // VIP Badge
                  Box(
                    modifier = Modifier
                      .align(Alignment.TopStart)
                      .padding(10.dp)
                      .clip(RoundedCornerShape(6.dp))
                      .background(Color.Black.copy(alpha = 0.75f))
                      .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(6.dp))
                      .padding(horizontal = 8.dp, vertical = 3.dp)
                  ) {
                    Text("DARK EXCLUSIVE", color = Color(0xFFF87171), fontSize = 9.sp, fontWeight = FontWeight.Black)
                  }

                  // Duration Badge
                  Box(
                    modifier = Modifier
                      .align(Alignment.BottomEnd)
                      .padding(10.dp)
                      .clip(RoundedCornerShape(6.dp))
                      .background(Color.Black.copy(alpha = 0.8f))
                      .padding(horizontal = 8.dp, vertical = 3.dp)
                  ) {
                    Text(video.duration, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                  }
                }

                Column(modifier = Modifier.padding(14.dp)) {
                  Text(video.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(video.description, color = Color(0xFF94A3B8), fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp)
                  Spacer(modifier = Modifier.height(8.dp))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(video.category, color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(video.views, color = Color(0xFF64748B), fontSize = 11.sp)
                  }
                }
              }
            }
          }
        }
      }
    }

    // TAB 1: DARK PHOTOS
    if (darkSubTab == 1) {
      val filteredDarkPhotos = remember(darkPhotos, searchQuery) {
        darkPhotos.filter { photo ->
          searchQuery.isBlank() || photo.title.contains(searchQuery, ignoreCase = true)
        }
      }

      if (filteredDarkPhotos.isEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
          contentAlignment = Alignment.Center
        ) {
          Text("No dark photos uploaded yet.", color = Color(0xFF94A3B8), fontSize = 12.sp)
        }
      } else {
        LazyVerticalGrid(
          columns = GridCells.Fixed(2),
          modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(filteredDarkPhotos) { photo ->
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Color(0xFF3B1E32), RoundedCornerShape(14.dp))
                .clickable { onSelectPhoto(photo) }
                .testTag("dark_photo_item_${photo.id}"),
              colors = CardDefaults.cardColors(containerColor = Color(0xFF140D1E)),
              shape = RoundedCornerShape(14.dp)
            ) {
              Column {
                Box(
                  modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(Color(0xFF0A0710))
                ) {
                  AsyncImage(
                    model = photo.imageUri,
                    contentDescription = photo.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                  )

                  // VIP Badge
                  Box(
                    modifier = Modifier
                      .align(Alignment.TopEnd)
                      .padding(6.dp)
                      .clip(RoundedCornerShape(4.dp))
                      .background(Color.Black.copy(alpha = 0.7f))
                      .padding(horizontal = 5.dp, vertical = 2.dp)
                  ) {
                    Text("DARK", color = Color(0xFFE879F9), fontSize = 8.sp, fontWeight = FontWeight.Black)
                  }
                }

                Column(modifier = Modifier.padding(10.dp)) {
                  Text(photo.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                  Spacer(modifier = Modifier.height(2.dp))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(photo.category, color = Color(0xFFA855F7), fontSize = 10.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(Icons.Default.Favorite, contentDescription = "Likes", tint = Color(0xFFEC4899), modifier = Modifier.size(12.dp))
                      Spacer(modifier = Modifier.width(3.dp))
                      Text("${photo.likes}", color = Color.White, fontSize = 10.sp)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
