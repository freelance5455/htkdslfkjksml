package com.example.taxinvoice;
import android.app.*;
import android.os.*;
import android.webkit.*;
import android.view.*;
import android.print.*;
import android.content.*;
import android.graphics.pdf.PdfDocument;
import java.io.*;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.setDownloadListener((url,userAgent,contentDisposition,mimetype,contentLength)->{
            Intent i=new Intent(Intent.ACTION_VIEW); i.setData(Uri.parse(url)); startActivity(i);
        });
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}