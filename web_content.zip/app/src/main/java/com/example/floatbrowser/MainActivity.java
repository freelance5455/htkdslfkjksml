package com.example.floatbrowser;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.*;
import android.widget.*;
import android.webkit.CookieManager;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    WebView web;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.webView);
        setupWebView(web);
        // Native bridge is available to the bundled UI when needed.
        web.addJavascriptInterface(new FloatBridge(this), "AndroidFloat");
        web.loadUrl("file:///android_asset/index.html");
    }

    static void setupWebView(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient());
    }

    public void openOverlaySettings() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    class FloatBridge {
        final Context c;
        FloatBridge(Context c){this.c=c;}

        @android.webkit.JavascriptInterface
        public boolean hasPermission() {
            return android.os.Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
        }

        @android.webkit.JavascriptInterface
        public void requestPermission() {
            openOverlaySettings();
        }

        @android.webkit.JavascriptInterface
        public void open(String url, String name, String img) {
            if (!hasPermission()) { openOverlaySettings(); return; }
            Intent i = new Intent(c, FloatService.class);
            i.putExtra("url", url);
            i.putExtra("name", name);
            i.putExtra("img", img);
            if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        web.evaluateJavascript(
            "(function(){try{if(window.refreshOb)window.refreshOb()}catch(e){}})();", null);
    }
}
