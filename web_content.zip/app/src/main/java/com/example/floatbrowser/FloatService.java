package com.example.floatbrowser;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;

/** Native overlay implementation matching the HTML floating-window controls. */
public class FloatService extends Service {
    WindowManager wm; View root; WebView web; WindowManager.LayoutParams lp;
    int minW, minH; boolean minimized=false;

    @Override public void onCreate() {
        super.onCreate();
        minW=dp(180); minH=dp(140);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch=new NotificationChannel("float","Floating browser",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
            startForeground(7,new NotificationCompat.Builder(this,"float")
                    .setContentTitle("Float Browser").setContentText("نافذة عائمة تعمل")
                    .setSmallIcon(android.R.drawable.ic_menu_view).build());
        }
    }
    @Override public int onStartCommand(Intent intent,int flags,int id){
        String url=intent!=null?intent.getStringExtra("url"):null;
        if(url==null||url.trim().isEmpty())url="https://www.google.com";
        show(url); return START_STICKY;
    }
    void show(String url){
        if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this))return;
        if(root!=null)try{wm.removeView(root);}catch(Exception ignored){}
        minimized=false;
        root=getLayoutInflater().inflate(R.layout.overlay,null);
        web=root.findViewById(R.id.overlayWebView); MainActivity.setupWebView(web); web.loadUrl(url);
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        lp=new WindowManager.LayoutParams(dp(360),dp(520),type,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity=Gravity.TOP|Gravity.START; lp.x=dp(12); lp.y=dp(70);
        wm.addView(root,lp);
        root.findViewById(R.id.closeOverlay).setOnClickListener(v->{stopSelf();});
        root.findViewById(R.id.minOverlay).setOnClickListener(v->{
            if(!minimized){lp.width=minW;lp.height=minH;minimized=true;}else{lp.width=dp(360);lp.height=dp(520);minimized=false;}
            wm.updateViewLayout(root,lp);
        });
        DragTouch drag=new DragTouch(); root.findViewById(R.id.moveBar).setOnTouchListener(drag);
        root.findViewById(R.id.leftCorner).setOnTouchListener(new ResizeTouch(true));
        root.findViewById(R.id.rightCorner).setOnTouchListener(new ResizeTouch(false));
    }
    class DragTouch implements View.OnTouchListener{
        int sx,sy,ox,oy;
        public boolean onTouch(View v,android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){sx=(int)e.getRawX();sy=(int)e.getRawY();ox=lp.x;oy=lp.y;return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){lp.x=ox+(int)e.getRawX()-sx;lp.y=oy+(int)e.getRawY()-sy;clamp();wm.updateViewLayout(root,lp);return true;}
            return e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL;
        }
    }
    class ResizeTouch implements View.OnTouchListener{
        final boolean left; int sx,sy,ow,oh,ox;
        ResizeTouch(boolean l){left=l;}
        public boolean onTouch(View v,MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){sx=(int)e.getRawX();sy=(int)e.getRawY();ow=lp.width;oh=lp.height;ox=lp.x;return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){int dx=(int)e.getRawX()-sx,dy=(int)e.getRawY()-sy;int nw=left?ow-dx:ow+dx;lp.width=Math.max(minW,nw);lp.height=Math.max(minH,oh+dy);if(left)lp.x=ox+(ow-lp.width);clamp();wm.updateViewLayout(root,lp);return true;}
            return true;
        }
    }
    void clamp(){DisplayMetrics m=getResources().getDisplayMetrics();int sw=m.widthPixels,sh=m.heightPixels;lp.x=Math.max(-lp.width+dp(80),Math.min(lp.x,sw-dp(80)));lp.y=Math.max(0,Math.min(lp.y,sh-dp(40)));}
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onDestroy(){if(root!=null&&wm!=null)try{wm.removeView(root);}catch(Exception ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
