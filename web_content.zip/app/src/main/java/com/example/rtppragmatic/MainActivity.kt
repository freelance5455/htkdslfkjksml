package com.example.rtppragmatic

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.view.View
import android.widget.FrameLayout
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var uiWeb: WebView
    private lateinit var analyzerWeb: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var currentUrl = ""
    private var scanCount = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        val root = FrameLayout(this)
        uiWeb = WebView(this)
        analyzerWeb = WebView(this)
        analyzerWeb.visibility = View.GONE

        configureWebView(uiWeb)
        configureWebView(analyzerWeb)
        uiWeb.addJavascriptInterface(AndroidBridge(), "Android")

        root.addView(uiWeb, FrameLayout.LayoutParams(-1, -1))
        root.addView(analyzerWeb, FrameLayout.LayoutParams(1, 1))

        analyzerWeb.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                return request?.url?.let { assetLoader.shouldInterceptRequest(it) }
                    ?: super.shouldInterceptRequest(view, request)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (currentUrl.isNotEmpty()) {
                    scanCount = 0
                    scheduleScan()
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    val msg = error?.description?.toString() ?: "Ошибка загрузки страницы"
                    sendStatus("ERROR", msg)
                }
            }

            override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                if (request?.isForMainFrame == true) {
                    sendStatus("HTTP", "HTTP ${errorResponse?.statusCode ?: "?"}: ${errorResponse?.reasonPhrase ?: "ошибка страницы"}")
                }
            }
        }

        setContentView(root)
        uiWeb.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(w: WebView) {
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.databaseEnabled = true
        w.settings.loadsImagesAutomatically = true
        w.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        w.settings.cacheMode = WebSettings.LOAD_DEFAULT
        w.settings.allowFileAccess = false
        w.settings.allowContentAccess = true
        w.settings.javaScriptCanOpenWindowsAutomatically = true
        w.settings.setSupportMultipleWindows(false)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.webChromeClient = WebChromeClient()
    }

    private fun scheduleScan() {
        scanCount++
        extractAllRtp()
        if (scanCount < 4) {
            analyzerWeb.postDelayed({ scheduleScan() }, 1800L)
        }
    }

    private fun extractAllRtp() {
        val js = """
            (function(){
              try {
                var body = document.body ? document.body.innerText : '';
                var html = document.documentElement ? document.documentElement.innerText : '';
                var title = document.title || '';
                var text = (body + '\\n' + html).replace(/\\s+/g,' ').trim();
                var providers = [
                  'Pragmatic Play','Evolution','NetEnt','Play\'n GO','Red Tiger','Hacksaw Gaming',
                  'Nolimit City','Push Gaming','Relax Gaming','Quickspin','Yggdrasil','Playtech',
                  'Microgaming','Betsoft','Spribe','BGaming','Mascot','Thunderkick','ELK Studios',
                  'Blueprint Gaming','Light & Wonder','Aristocrat','IGT','Games Global','Wazdan'
                ];
                var detected=[];
                providers.forEach(function(p){ if(text.toLowerCase().indexOf(p.toLowerCase()) >= 0) detected.push(p); });

                var re = /(?:RTP|Return\\s*to\\s*Player|Return\\s+To\\s+Player|возврат\\s+игроку|процент\\s+возврата)[^0-9]{0,120}([0-9]{2}(?:[.,][0-9]{1,3})?)\\s*%/gi;
                var re2 = /([0-9]{2}(?:[.,][0-9]{1,3})?)\\s*%[^A-Za-zА-Яа-я0-9]{0,40}(?:RTP|Return\\s*to\\s*Player|возврат\\s+игроку)/gi;
                var values=[];
                var m;
                function add(v, pos){
                  var n=parseFloat(String(v).replace(',','.'));
                  if(!(n>=50 && n<=100)) return;
                  var start=Math.max(0,pos-180), end=Math.min(text.length,pos+180);
                  var ctx=text.substring(start,end).replace(/\\s+/g,' ').trim();
                  var before=text.substring(Math.max(0,pos-120),pos);
                  var words=before.split(/\\s+/);
                  var name=words.slice(Math.max(0,words.length-8)).join(' ');
                  values.push({rtp:n.toFixed(3).replace(/0+$/,'').replace(/\\.$/,''),context:ctx,name:name});
                }
                while((m=re.exec(text))!==null) add(m[1],m.index);
                while((m=re2.exec(text))!==null) add(m[1],m.index);

                var unique=[], seen={};
                values.forEach(function(x){ var key=x.rtp+'|'+x.context; if(!seen[key]){seen[key]=1;unique.push(x);} });
                unique=unique.slice(0,50);
                return JSON.stringify({ok:true,title:title,url:location.href,providers:detected,results:unique});
              } catch(e){ return JSON.stringify({ok:false,error:String(e),title:document.title||''}); }
            })()
        """.trimIndent()

        analyzerWeb.evaluateJavascript(js) { value ->
            try {
                val raw = value?.trim()?.let { if (it.startsWith("\"") && it.endsWith("\"")) JSONObject.quote(it) else it } ?: "{}"
                val decoded = try { JSONObject(raw).toString() } catch (_: Exception) { value?.trim()?.removeSurrounding("\"")?.replace("\\\"", "\"") ?: "{}" }
                val obj = JSONObject(decoded)
                val out = JSONObject()
                out.put("url", currentUrl)
                out.put("title", obj.optString("title", ""))
                out.put("providers", obj.optJSONArray("providers") ?: JSONArray())
                out.put("results", obj.optJSONArray("results") ?: JSONArray())
                out.put("scan", scanCount)
                uiWeb.post { uiWeb.evaluateJavascript("window.showScanResult(${JSONObject.quote(out.toString())});", null) }
            } catch (_: Exception) {
                sendStatus("PARSE", "Не удалось обработать ответ страницы.")
            }
        }
    }

    private fun sendStatus(type: String, message: String) {
        val obj = JSONObject().apply { put("type", type); put("message", message); put("url", currentUrl) }
        if (::uiWeb.isInitialized) uiWeb.post { uiWeb.evaluateJavascript("window.showScanError(${JSONObject.quote(obj.toString())});", null) }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun analyze(url: String) {
            var u = url.trim()
            if (u.isEmpty()) return
            if (!u.startsWith("http://", true) && !u.startsWith("https://", true)) u = "https://$u"
            currentUrl = u
            runOnUiThread {
                scanCount = 0
                analyzerWeb.loadUrl(u)
            }
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            var u = url.trim()
            if (u.isEmpty()) return
            if (!u.startsWith("http://", true) && !u.startsWith("https://", true)) u = "https://$u"
            val uri = Uri.parse(u)
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.android.chrome") })
            } catch (_: Exception) {
                try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
            }
        }
    }

    @Deprecated("Deprecated in Android 13+, kept for older devices")
    override fun onBackPressed() {
        if (::analyzerWeb.isInitialized && analyzerWeb.canGoBack()) analyzerWeb.goBack() else super.onBackPressed()
    }
}
