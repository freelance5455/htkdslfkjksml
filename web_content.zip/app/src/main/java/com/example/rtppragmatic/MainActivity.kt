package com.example.rtppragmatic

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.widget.*
import android.text.InputType

data class Game(val name:String,val rtp:Double,val volatility:String,val maxWin:String)

class MainActivity : Activity() {
    private val games = listOf(
        Game("Gates of Olympus",96.50,"Высокая","5,000x"),
        Game("Sweet Bonanza",96.48,"Высокая","21,100x"),
        Game("Starlight Princess",96.50,"Высокая","5,000x"),
        Game("The Dog House",96.55,"Высокая","7,025x"),
        Game("Big Bass Bonanza",96.71,"Высокая","2,100x"),
        Game("Wolf Gold",96.01,"Средняя","2,500x")
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        showMain()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24,24,24,24)
    }

    private fun showMain() {
        val root=base()
        root.addView(TextView(this).apply { text="RTP Pragmatic Analyzer 2.0"; textSize=25f })
        root.addView(TextView(this).apply {
            text="Каталог игр и проверка RTP по ссылке казино"; textSize=14f
            setPadding(0,8,0,20)
        })
        val urlBtn=Button(this).apply { text="🌐 Проверить RTP по ссылке казино" }
        root.addView(urlBtn)
        val search=EditText(this).apply { hint="Поиск игры"; singleLine=true }
        root.addView(search)
        val list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val scroll=ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        fun render(q:String="") {
            list.removeAllViews()
            games.filter{it.name.contains(q,true)}.sortedByDescending{it.rtp}.forEach { g ->
                list.addView(TextView(this).apply {
                    text="${g.name}\nRTP: ${g.rtp}%   |   Волатильность: ${g.volatility}\nMax Win: ${g.maxWin}"
                    textSize=17f; setPadding(18,18,18,18)
                    setBackgroundColor(Color.rgb(245,245,245))
                })
                list.addView(Space(this).apply { minimumHeight=12 })
            }
        }
        search.addTextChangedListener(object: android.text.TextWatcher {
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render(s.toString())}
            override fun afterTextChanged(e:android.text.Editable?){}
        })
        urlBtn.setOnClickListener { showUrlChecker() }
        render()
        setContentView(root)
    }

    private fun showUrlChecker() {
        val root=base()
        root.addView(TextView(this).apply {
            text="Проверка RTP по ссылке казино"; textSize=24f
        })
        root.addView(TextView(this).apply {
            text="Вставь ссылку на страницу игры/казино. Приложение ищет опубликованные значения RTP на странице."
            setPadding(0,8,0,14)
        })
        val input=EditText(this).apply {
            hint="https://example.com/game"
            inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            singleLine=true
        }
        root.addView(input)
        val check=Button(this).apply { text="🔎 Проверить" }
        root.addView(check)
        val result=TextView(this).apply {
            text="Результат появится здесь."
            textSize=17f; setPadding(0,18,0,18)
        }
        root.addView(result)
        val web=WebView(this).apply {
            visibility=View.GONE
            settings.javaScriptEnabled=true
            settings.domStorageEnabled=true
            settings.cacheMode=WebSettings.LOAD_DEFAULT
            webViewClient=WebViewClient()
        }
        root.addView(web, LinearLayout.LayoutParams(-1,0,1f))
        val back=Button(this).apply { text="← Назад" }
        root.addView(back)

        check.setOnClickListener {
            var url=input.text.toString().trim()
            if (url.isEmpty()) { result.text="Вставь ссылку."; return@setOnClickListener }
            if (!url.startsWith("http://") && !url.startsWith("https://")) url="https://$url"
            result.text="Загружаю страницу и ищу RTP…"
            web.visibility=View.VISIBLE
            web.loadUrl(url)

            web.postDelayed({
                val js = """
                    (function(){
                      var t=document.body ? document.body.innerText : "";
                      var m=t.match(/(?:RTP|Return to Player|возврат игроку)[^0-9]{0,80}([0-9]{2}(?:[.,][0-9]{1,2})?)\s*%/i);
                      var v=t.match(/([0-9]{2}(?:[.,][0-9]{1,2})?)\s*%\s*(?:RTP|Return to Player)/i);
                      return (m?m[1]:v?v[1]:"");
                    })()
                """.trimIndent()
                web.evaluateJavascript(js) { value ->
                    val clean=value?.trim('"')?.replace(",", ".") ?: ""
                    result.text = if (clean.matches(Regex("\\d{2}(?:\\.\\d{1,2})?"))) {
                        "Найден опубликованный RTP: $clean%\\n\\nИсточник: страница казино.\\nЭто заявленный RTP, а не прогноз следующего спина."
                    } else {
                        "RTP автоматически не найден.\\n\\nВозможно, казино загружает данные динамически или не публикует RTP на этой странице. Проверь раздел Paytable/Info/Rules игры."
                    }
                }
            }, 2500)
        }
        back.setOnClickListener { showMain() }
        setContentView(root)
    }
}
