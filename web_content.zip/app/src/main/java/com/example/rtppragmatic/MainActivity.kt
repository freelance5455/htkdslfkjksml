package com.example.rtppragmatic

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.view.View
import android.widget.FrameLayout
import android.graphics.Color
import android.net.Uri
import android.content.Intent
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var uiWeb: WebView
    private lateinit var analyzerWeb: WebView
    private var currentUrl = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        uiWeb = WebView(this)
        analyzerWeb = WebView(this)
        analyzerWeb.visibility = View.GONE

        configureWebView(uiWeb)
        configureWebView(analyzerWeb)

        uiWeb.addJavascriptInterface(AndroidBridge(), "Android")
        root.addView(uiWeb, FrameLayout.LayoutParams(-1, -1))
        root.addView(analyzerWeb, FrameLayout.LayoutParams(1, 1))

        analyzerWeb.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                if (currentUrl.isNotEmpty()) {
                    view?.postDelayed({ extractRtp() }, 1200)
                }
            }
        }

        setContentView(root)
        uiWeb.loadUrl("file:///android_asset/index.html")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(w: WebView) {
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.databaseEnabled = true
        w.settings.loadsImagesAutomatically = true
        w.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        w.settings.cacheMode = WebSettings.LOAD_DEFAULT
        w.webViewClient = WebViewClient()
        w.setBackgroundColor(Color.TRANSPARENT)
    }

    private fun extractRtp() {
        val js = """
            (function(){
              try {
                var t = document.body ? document.body.innerText : "";
                var patterns = [
                  /(?:RTP|Return to Player|Return To Player|возврат игроку)[^0-9]{0,100}([0-9]{2}(?:[.,][0-9]{1,3})?)\s*%/i,
                  /([0-9]{2}(?:[.,][0-9]{1,3})?)\s*%\s*(?:RTP|Return to Player|возврат игроку)/i
                ];
                for (var i=0;i<patterns.length;i++) {
                  var m=t.match(patterns[i]);
                  if(m) return JSON.stringify({rtp:m[1], title:document.title || ""});
                }
                return JSON.stringify({rtp:"", title:document.title || ""});
              } catch(e) {
                return JSON.stringify({rtp:"", title:"", error:String(e)});
              }
            })()
        """.trimIndent()

        analyzerWeb.evaluateJavascript(js) { value ->
            try {
                val jsonText = value?.trim()?.removeSurrounding(""")
                    ?.replace("\"", """)
                    ?.replace("\\", "\") ?: "{}"
                val obj = JSONObject(jsonText)
                val rtp = obj.optString("rtp", "")
                val title = obj.optString("title", "")
                val result = JSONObject().apply {
                    put("url", currentUrl)
                    put("rtp", rtp.replace(",", "."))
                    put("title", title)
                }
                uiWeb.post {
                    uiWeb.evaluateJavascript(
                        "window.showRtpResult(${JSONObject.quote(result.toString())});",
                        null
                    )
                }
            } catch (_: Exception) {
                uiWeb.post {
                    uiWeb.evaluateJavascript(
                        "window.showRtpResult(${JSONObject.quote("{\"url\":\"$currentUrl\",\"rtp\":\"\"}")});",
                        null
                    )
                }
            }
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun analyze(url: String) {
            var u = url.trim()
            if (u.isEmpty()) return
            if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
            currentUrl = u
            runOnUiThread {
                analyzerWeb.visibility = View.GONE
                analyzerWeb.loadUrl(u)
            }
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: Exception) {}
        }
    }

    override fun onBackPressed() {
        if (::uiWeb.isInitialized && uiWeb.canGoBack()) uiWeb.goBack()
        else super.onBackPressed()
    }
}
