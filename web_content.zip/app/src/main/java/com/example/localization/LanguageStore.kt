package com.example.localization

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.languageDataStore by preferencesDataStore(name = "smart_jones_settings")

enum class AppLang(val code: String, val label: String) {
    SW("sw", "Kiswahili"),
    EN("en", "English");

    companion object {
        fun fromCode(code: String?): AppLang =
            entries.firstOrNull { it.code == code } ?: SW
    }
}

class LanguageStore(private val context: Context) {
    private val langKey = stringPreferencesKey("preferred_language")

    val languageFlow: Flow<AppLang> = context.languageDataStore.data.map { prefs ->
        AppLang.fromCode(prefs[langKey])
    }

    suspend fun setLanguage(lang: AppLang) {
        context.languageDataStore.edit { prefs ->
            prefs[langKey] = lang.code
        }
    }
}
