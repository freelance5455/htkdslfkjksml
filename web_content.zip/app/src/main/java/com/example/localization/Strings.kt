package com.example.localization

import com.example.model.OrderStatus
import com.example.model.ServiceCategory

object SjsStrings {
    fun t(lang: AppLang, sw: String, en: String): String =
        if (lang == AppLang.SW) sw else en

    fun categoryLabel(category: ServiceCategory, lang: AppLang): String = when (category) {
        ServiceCategory.SECURITY_GUARDS -> t(lang, "Walinzi wa Usalama", "Security Guards")
        ServiceCategory.CCTV_INSTALLATION -> t(lang, "Ufungaji wa CCTV", "CCTV Camera Installation")
        ServiceCategory.ELECTRIC_FENCE -> t(lang, "Uzio wa Umeme", "Electric Fence Installation")
        ServiceCategory.ALARM_SYSTEMS -> t(lang, "Mifumo ya Kengele", "Alarm Systems")
        ServiceCategory.ACCESS_CONTROL -> t(lang, "Udhibiti wa Milango", "Access Control Systems")
        ServiceCategory.GPS_TRACKING -> t(lang, "Ufuatiliaji wa GPS", "GPS Vehicle Tracking")
        ServiceCategory.FIRE_DETECTION -> t(lang, "Kugundua Moto", "Fire Detection Systems")
        ServiceCategory.SECURITY_CONSULTATION -> t(lang, "Ushauri wa Kiulinzi", "Security Consultation")
        ServiceCategory.EQUIPMENT_SUPPLY -> t(lang, "Vifaa vya Usalama", "Security Equipment Supply")
        ServiceCategory.SECURITY_MAINTENANCE -> t(lang, "Matengenezo ya Usalama", "Security Maintenance")
    }

    fun orderStatusLabel(status: OrderStatus, lang: AppLang): String = when (status) {
        OrderStatus.REQUESTED -> t(lang, "1. Ombi Limetumwa", "1. Request Submitted")
        OrderStatus.PROVIDER_RECEIVED -> t(lang, "2. Limepokelewa na Kampuni", "2. Provider Received")
        OrderStatus.QUOTATION_SUBMITTED -> t(lang, "3. Nukuu Imetumwa", "3. Quotation Submitted")
        OrderStatus.QUOTATION_ACCEPTED -> t(lang, "4. Nukuu Imekubaliwa", "4. Quotation Accepted")
        OrderStatus.PAYMENT_INITIATED -> t(lang, "5. Malipo Yameanzishwa", "5. Payment Initiated")
        OrderStatus.PAYMENT_CONFIRMED -> t(lang, "6. Malipo Yamethibitishwa", "6. Payment Confirmed")
        OrderStatus.SERVICE_DELIVERED -> t(lang, "7. Huduma Imefanyika", "7. Service Delivered")
        OrderStatus.COMPLETION_CONFIRMED -> t(lang, "8. Mteja Amethibitisha", "8. Completion Confirmed")
        OrderStatus.COMMISSION_CALCULATED -> t(lang, "9. Kamisheni Imehesabiwa", "9. Commission Calculated")
        OrderStatus.CLOSED -> t(lang, "10. Oda Imefungwa", "10. Order Closed")
        OrderStatus.CANCELLED -> t(lang, "Imeghairiwa", "Cancelled")
        OrderStatus.DISPUTED -> t(lang, "Ina Mgogoro", "Disputed")
    }
}
