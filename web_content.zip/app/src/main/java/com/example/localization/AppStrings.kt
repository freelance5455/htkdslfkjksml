package com.example.localization

import androidx.compose.runtime.compositionLocalOf

data class AppStrings(
  val languageCode: String,
  val languageLabel: String,
  val tagline: String,
  val zeroFeeGuarantee: String,
  val navHome: String,
  val navExplore: String,
  val navSideQuests: String,
  val navApplications: String,
  val navProfile: String,
  val navDashboard: String,
  val navPostings: String,
  val navCandidates: String,
  val navMessages: String,
  val navAdmin: String,
  val applyNow: String,
  val claimQuest: String,
  val submitProof: String,
  val releasePayout: String,
  val approvedBadge: String,
  val pendingBadge: String,
  val ageRestrictedLabel: String,
  val recommendedForYou: String,
  val nearYourCity: String,
  val activeSideQuests: String,
  val searchHint: String,
  val signInSubtitle: String,
  val signInButton: String
)

object AppLocalization {
  val English = AppStrings(
    languageCode = "EN",
    languageLabel = "English",
    tagline = "India's Employment & Side Quests Marketplace",
    zeroFeeGuarantee = "Zero-Fee Mandate · ₹0 Application Fee",
    navHome = "Home",
    navExplore = "Explore",
    navSideQuests = "Side Quests",
    navApplications = "Applied",
    navProfile = "Profile",
    navDashboard = "Overview",
    navPostings = "Postings",
    navCandidates = "Hiring",
    navMessages = "Chats",
    navAdmin = "Admin",
    applyNow = "Apply (₹0 Fee)",
    claimQuest = "Accept Side Quest",
    submitProof = "Submit Completion Proof",
    releasePayout = "Verify & Mark Paid",
    approvedBadge = "Verified",
    pendingBadge = "Pending Review",
    ageRestrictedLabel = "18+ Only (Child-Labour Safety Compliance)",
    recommendedForYou = "Recommended Across India",
    nearYourCity = "Opportunities Near You",
    activeSideQuests = "Quick Paid Side Quests",
    searchHint = "Search roles, skills, city or PIN code...",
    signInSubtitle = "Jobs, gigs, internships & instant paid micro-tasks across all Indian states and UTs.",
    signInButton = "Sign in with Google"
  )

  val Hindi = AppStrings(
    languageCode = "HI",
    languageLabel = "हिन्दी",
    tagline = "भारत का रोज़गार और साइड क्वेस्ट बाज़ार",
    zeroFeeGuarantee = "शून्य शुल्क नियम · ₹0 आवेदन शुल्क",
    navHome = "होम",
    navExplore = "खोजें",
    navSideQuests = "साइड क्वेस्ट",
    navApplications = "आवेदन",
    navProfile = "प्रोफ़ाइल",
    navDashboard = "डैशबोर्ड",
    navPostings = "नौकरियाँ",
    navCandidates = "उम्मीदवार",
    navMessages = "संदेश",
    navAdmin = "एडमिन",
    applyNow = "आवेदन करें (₹0)",
    claimQuest = "साइड क्वेस्ट लें",
    submitProof = "कार्य प्रमाण भेजें",
    releasePayout = "सत्यापित करें और भुगतान दें",
    approvedBadge = "सत्यापित",
    pendingBadge = "समीक्षाधीन",
    ageRestrictedLabel = "केवल 18+ (बाल श्रम सुरक्षा नियम)",
    recommendedForYou = "आपके लिए उपयुक्त नौकरियाँ",
    nearYourCity = "आपके शहर के अवसर",
    activeSideQuests = "तुरंत भुगतान साइड क्वेस्ट",
    searchHint = "नौकरी, कौशल, शहर या पिन कोड खोजें...",
    signInSubtitle = "पूरे भारत में नौकरी, गिग, इंटर्नशिप और तुरंत भुगतान वाले छोटे कार्य।",
    signInButton = "Google से साइन इन करें"
  )

  val Tamil = AppStrings(
    languageCode = "TA",
    languageLabel = "தமிழ்",
    tagline = "இந்தியாவின் வேலைவாய்ப்பு மற்றும் சைட் குவெஸ்ட் தளம்",
    zeroFeeGuarantee = "கட்டணமில்லா விதி · ₹0 விண்ணப்பக் கட்டணம்",
    navHome = "முகப்பு",
    navExplore = "தேடல்",
    navSideQuests = "சைட் குவெஸ்ட்",
    navApplications = "விண்ணப்பம்",
    navProfile = "சுயவிவரம்",
    navDashboard = "டாஷ்போர்ட்",
    navPostings = "பணிகள்",
    navCandidates = "விண்ணப்பதாரர்",
    navMessages = "செய்திகள்",
    navAdmin = "நிர்வாகம்",
    applyNow = "விண்ணப்பிக்கவும் (₹0)",
    claimQuest = "பணியை ஏற்கவும்",
    submitProof = "முடித்த சான்றை அனுப்பவும்",
    releasePayout = "சரிபார்த்து ஊதியம் வழங்கவும்",
    approvedBadge = "சரிபார்க்கப்பட்டது",
    pendingBadge = "ஆய்வில் உள்ளது",
    ageRestrictedLabel = "18+ மட்டும் (குழந்தைத் தொழிலாளர் தடுப்பு விதி)",
    recommendedForYou = "உங்களுக்கான பரிந்துரைகள்",
    nearYourCity = "உங்கள் நகர வாய்ப்புகள்",
    activeSideQuests = "விரைவு ஊதிய சைட் குவெஸ்ட்கள்",
    searchHint = "பணி, திறன், நகரம் அல்லது பின் கோட் தேடுக...",
    signInSubtitle = "இந்தியா முழுவதும் வேலைகள், கிக் பணிகள் மற்றும் உடனடி ஊதிய சிறு பணிகள்.",
    signInButton = "Google உடன் உள்நுழையவும்"
  )

  fun forCode(code: String): AppStrings = when (code.uppercase()) {
    "HI" -> Hindi
    "TA" -> Tamil
    else -> English
  }
}

val LocalAppStrings = compositionLocalOf { AppLocalization.English }
