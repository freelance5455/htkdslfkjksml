package com.example

import android.app.Application
import com.example.data.export.ExcelExporter
import com.example.data.export.PdfExporter
import com.example.data.local.PreferencesManager
import com.example.data.local.SdTravelDatabase
import com.example.data.repository.SdTravelRepository
import com.example.data.storage.BackupManager
import com.example.data.storage.DocumentStorage

class AppContainer(application: Application) {
    val database: SdTravelDatabase by lazy { SdTravelDatabase.getInstance(application) }
    val documentStorage: DocumentStorage by lazy { DocumentStorage(application) }
    val preferencesManager: PreferencesManager by lazy { PreferencesManager(application) }
    val repository: SdTravelRepository by lazy {
        SdTravelRepository(database.sdTravelDao(), documentStorage)
    }
    val excelExporter: ExcelExporter by lazy { ExcelExporter(application) }
    val pdfExporter: PdfExporter by lazy { PdfExporter(application) }
    val backupManager: BackupManager by lazy {
        BackupManager(application, database, documentStorage, preferencesManager)
    }
}

class SdTravelApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
