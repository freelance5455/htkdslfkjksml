package com.example.phoenixpm.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.Client
import com.example.phoenixpm.model.Project
import com.example.phoenixpm.ui.theme.*

@Composable
fun ClientManagementScreen(
    clients: List<Client>,
    projects: List<Project>,
    onOpenAddClient: () -> Unit,
    onOpenZohoImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredClients = clients.filter { client ->
        client.companyName.contains(searchQuery, ignoreCase = true) ||
                client.contactPerson.contains(searchQuery, ignoreCase = true) ||
                client.city.contains(searchQuery, ignoreCase = true) ||
                client.gstin.contains(searchQuery, ignoreCase = true) ||
                client.industry.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Client Portfolios",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "${clients.size} corporate & industrial accounts in Tamil Nadu",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondaryDark
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onOpenZohoImport,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PhoenixSky),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Zoho Sync", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onOpenAddClient,
                        colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Client", fontSize = 12.sp)
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search client name, contact, city, or GSTIN...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondaryDark) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )
        }

        // Clients List
        items(filteredClients) { client ->
            val clientProjects = projects.filter { it.clientId == client.id }

            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = client.companyName,
                                color = TextPrimaryDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = client.industry,
                                color = PhoenixSky,
                                fontSize = 12.sp
                            )
                        }

                        if (!client.zohoContactId.isNullOrBlank()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .border(1.dp, PhoenixSky.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(Icons.Default.CloudDone, contentDescription = null, tint = PhoenixSky, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Zoho Connected", color = PhoenixSky, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("👤 Contact Person: ${client.contactPerson}", color = TextSecondaryDark, fontSize = 12.sp)
                    Text("📞 Phone: ${client.phone} • ✉️ ${client.email}", color = TextSecondaryDark, fontSize = 12.sp)
                    Text("📍 Address: ${client.address}, ${client.city}", color = TextMutedDark, fontSize = 11.sp)
                    Text("📑 GSTIN: ${client.gstin}", color = TextMutedDark, fontSize = 11.sp)

                    if (!client.notes.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Note: ${client.notes}",
                            color = PhoenixAmber,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${clientProjects.size} Active Safety Contracts",
                            color = PhoenixEmerald,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Joined: ${client.createdAt}",
                            color = TextMutedDark,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
