package com.example.phoenixpm.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PhoenixRed,
    onPrimary = Color.White,
    primaryContainer = PhoenixRedDark,
    onPrimaryContainer = Color.White,
    secondary = PhoenixSky,
    onSecondary = Color.White,
    secondaryContainer = PhoenixNavyElevated,
    onSecondaryContainer = Color.White,
    tertiary = PhoenixAmber,
    onTertiary = Color.Black,
    background = PhoenixNavyDark,
    onBackground = TextPrimaryDark,
    surface = PhoenixNavySurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = PhoenixNavyElevated,
    onSurfaceVariant = TextSecondaryDark,
    outline = BorderSubtle
)

@Composable
fun PhoenixPMTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
