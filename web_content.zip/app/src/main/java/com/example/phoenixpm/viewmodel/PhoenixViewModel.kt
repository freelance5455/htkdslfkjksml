package com.example.phoenixpm.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.phoenixpm.data.PhoenixRepository
import com.example.phoenixpm.model.*
import kotlinx.coroutines.flow.*

class PhoenixViewModel(
    val repository: PhoenixRepository = PhoenixRepository()
) : ViewModel() {

    val currentUser = repository.currentUser
    val users = repository.users
    val employees = repository.employees
    val clients = repository.clients
    val projects = repository.projects
    val tasks = repository.tasks
    val progressUpdates = repository.progressUpdates
    val messages = repository.messages
    val documents = repository.documents
    val notifications = repository.notifications
    val settings = repository.settings

    private val _activeView = MutableStateFlow(AppView.DASHBOARD)
    val activeView: StateFlow<AppView> = _activeView.asStateFlow()

    private val _selectedProjectId = MutableStateFlow<String?>("proj-1")
    val selectedProjectId: StateFlow<String?> = _selectedProjectId.asStateFlow()

    private val _selectedEmployeeId = MutableStateFlow<String?>("emp-1")
    val selectedEmployeeId: StateFlow<String?> = _selectedEmployeeId.asStateFlow()

    private val _selectedClientId = MutableStateFlow<String?>("client-apollo")
    val selectedClientId: StateFlow<String?> = _selectedClientId.asStateFlow()

    // Dialog & Modal states
    private val _showCreateProjectDialog = MutableStateFlow(false)
    val showCreateProjectDialog: StateFlow<Boolean> = _showCreateProjectDialog.asStateFlow()

    private val _showCreateTaskDialog = MutableStateFlow(false)
    val showCreateTaskDialog: StateFlow<Boolean> = _showCreateTaskDialog.asStateFlow()

    private val _taskDefaultProjectId = MutableStateFlow<String?>(null)
    val taskDefaultProjectId: StateFlow<String?> = _taskDefaultProjectId.asStateFlow()

    private val _showAddClientDialog = MutableStateFlow(false)
    val showAddClientDialog: StateFlow<Boolean> = _showAddClientDialog.asStateFlow()

    private val _showPersonaDialog = MutableStateFlow(false)
    val showPersonaDialog: StateFlow<Boolean> = _showPersonaDialog.asStateFlow()

    private val _showZohoImportDialog = MutableStateFlow(false)
    val showZohoImportDialog: StateFlow<Boolean> = _showZohoImportDialog.asStateFlow()

    private val _showProgressDialog = MutableStateFlow(false)
    val showProgressDialog: StateFlow<Boolean> = _showProgressDialog.asStateFlow()

    private val _previewDocument = MutableStateFlow<ProjectDocument?>(null)
    val previewDocument: StateFlow<ProjectDocument?> = _previewDocument.asStateFlow()

    // Navigation
    fun navigateTo(view: AppView) {
        _activeView.value = view
    }

    fun openProjectDetail(projectId: String) {
        _selectedProjectId.value = projectId
        _activeView.value = AppView.PROJECT_DETAIL
    }

    fun openEmployeeDetail(employeeId: String) {
        _selectedEmployeeId.value = employeeId
        _activeView.value = AppView.VIEW_EMPLOYEE
    }

    // Dialog controls
    fun openCreateProjectDialog() {
        _showCreateProjectDialog.value = true
    }

    fun closeCreateProjectDialog() {
        _showCreateProjectDialog.value = false
    }

    fun openCreateTaskDialog(projectId: String? = null) {
        _taskDefaultProjectId.value = projectId
        _showCreateTaskDialog.value = true
    }

    fun closeCreateTaskDialog() {
        _showCreateTaskDialog.value = false
        _taskDefaultProjectId.value = null
    }

    fun openAddClientDialog() {
        _showAddClientDialog.value = true
    }

    fun closeAddClientDialog() {
        _showAddClientDialog.value = false
    }

    fun openPersonaDialog() {
        _showPersonaDialog.value = true
    }

    fun closePersonaDialog() {
        _showPersonaDialog.value = false
    }

    fun openZohoImportDialog() {
        _showZohoImportDialog.value = true
    }

    fun closeZohoImportDialog() {
        _showZohoImportDialog.value = false
    }

    fun openProgressDialog(projectId: String) {
        _selectedProjectId.value = projectId
        _showProgressDialog.value = true
    }

    fun closeProgressDialog() {
        _showProgressDialog.value = false
    }

    fun openDocumentPreview(doc: ProjectDocument) {
        _previewDocument.value = doc
    }

    fun closeDocumentPreview() {
        _previewDocument.value = null
    }

    // Role switching
    fun switchUser(userId: String) {
        repository.switchUser(userId)
        val user = repository.currentUser.value
        when (user.role) {
            UserRole.Admin -> _activeView.value = AppView.DASHBOARD
            UserRole.Employee -> _activeView.value = AppView.EMPLOYEE_PORTAL
            UserRole.Client -> _activeView.value = AppView.CLIENT_PORTAL
        }
        closePersonaDialog()
    }
}
