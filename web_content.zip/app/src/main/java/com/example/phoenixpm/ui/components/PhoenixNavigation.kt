package com.example.phoenixpm.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.AppView
import com.example.phoenixpm.model.UserRole
import com.example.phoenixpm.ui.theme.*

data class NavItem(
    val view: AppView,
    val icon: ImageVector,
    val label: String
)

@Composable
fun PhoenixBottomNavigation(
    activeView: AppView,
    userRole: UserRole,
    onSelectView: (AppView) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = when (userRole) {
        UserRole.Client -> listOf(
            NavItem(AppView.CLIENT_PORTAL, Icons.Default.Dashboard, "My Portal"),
            NavItem(AppView.PROJECT_DETAIL, Icons.Default.Folder, "Project"),
            NavItem(AppView.DOCUMENTS, Icons.Default.Description, "Files"),
            NavItem(AppView.SETTINGS, Icons.Default.Settings, "Settings")
        )
        UserRole.Employee -> listOf(
            NavItem(AppView.EMPLOYEE_PORTAL, Icons.Default.Work, "Workspace"),
            NavItem(AppView.PROJECTS, Icons.Default.Business, "Projects"),
            NavItem(AppView.TASKS, Icons.Default.Assignment, "Tasks"),
            NavItem(AppView.DOCUMENTS, Icons.Default.Description, "Files"),
            NavItem(AppView.SETTINGS, Icons.Default.Settings, "Settings")
        )
        UserRole.Admin -> listOf(
            NavItem(AppView.DASHBOARD, Icons.Default.Dashboard, "Dashboard"),
            NavItem(AppView.PROJECTS, Icons.Default.Business, "Projects"),
            NavItem(AppView.TASKS, Icons.Default.Assignment, "Tasks"),
            NavItem(AppView.CLIENTS, Icons.Default.People, "Clients"),
            NavItem(AppView.DOCUMENTS, Icons.Default.Description, "Files"),
            NavItem(AppView.EMPLOYEES, Icons.Default.Badge, "Team"),
            NavItem(AppView.REPORTS, Icons.Default.BarChart, "Reports"),
            NavItem(AppView.SETTINGS, Icons.Default.Settings, "Settings")
        )
    }

    NavigationBar(
        containerColor = PhoenixNavyDark,
        contentColor = TextPrimaryDark,
        tonalElevation = 8.dp,
        modifier = modifier
    ) {
        items.forEach { item ->
            val selected = activeView == item.view
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectView(item.view) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        tint = if (selected) PhoenixRed else TextSecondaryDark
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        color = if (selected) PhoenixRed else TextSecondaryDark,
                        fontSize = 10.sp
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = PhoenixNavyElevated
                )
            )
        }
    }
}
