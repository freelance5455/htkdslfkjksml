package com.example.phoenixpm.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.*
import com.example.phoenixpm.ui.components.PriorityBadge
import com.example.phoenixpm.ui.components.StatusBadge
import com.example.phoenixpm.ui.components.VoiceMessageItem
import com.example.phoenixpm.ui.theme.*

@Composable
fun ClientPortalScreen(
    currentUser: User,
    clients: List<Client>,
    projects: List<Project>,
    documents: List<ProjectDocument>,
    messages: List<ConversationMessage>,
    onOpenProjectDetail: (String) -> Unit,
    onOpenDocumentPreview: (ProjectDocument) -> Unit,
    onSendMessage: (projectId: String, content: String, type: String, duration: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val client = clients.firstOrNull { it.id == currentUser.clientId } ?: clients.firstOrNull()
    val clientProjects = projects.filter { it.clientId == (client?.id ?: "client-apollo") }
    val primaryProject = clientProjects.firstOrNull() ?: projects.firstOrNull()

    val clientDocs = documents.filter { doc ->
        doc.accessLevel == "Client Shared" && (primaryProject == null || doc.projectId == primaryProject.id)
    }

    val projectMsgs = messages.filter { primaryProject != null && it.projectId == primaryProject.id }

    var chatText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Welcome Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PhoenixNavySurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Client Assurance Portal",
                            color = PhoenixRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .border(1.dp, PhoenixEmerald.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = PhoenixEmerald, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("NBC 2016 Compliant", color = PhoenixEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Welcome, ${currentUser.name}",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimaryDark
                    )

                    Text(
                        text = "${client?.companyName ?: "Corporate Client"} • ${currentUser.designation}",
                        color = TextSecondaryDark,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Active Projects
        item {
            Text(
                text = "Your Fire Safety Upgrades (${clientProjects.size})",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimaryDark
            )
        }

        items(clientProjects) { project ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                    .clickable { onOpenProjectDetail(project.id) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(project.reference, color = PhoenixRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        StatusBadge(status = project.status)
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(project.name, color = TextPrimaryDark, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Site: ${project.siteLocation}", color = TextSecondaryDark, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Completion", color = TextSecondaryDark, fontSize = 12.sp)
                        Text("${project.progressPercentage}%", color = PhoenixEmerald, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { project.progressPercentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = PhoenixEmerald,
                        trackColor = PhoenixNavyElevated
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Milestones: ${project.milestones.count { it.completed }} of ${project.milestones.size} delivered • Target: ${project.expectedCompletionDate}",
                        color = TextMutedDark,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Shared Engineering Documents
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Approved Engineering Drawings & Certificates",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimaryDark
            )
        }

        items(clientDocs) { doc ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                    .clickable { onOpenDocumentPreview(doc) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = PhoenixSky,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(doc.title, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text("${doc.filename} • ${doc.fileSize} • Uploaded ${doc.uploadDate}", color = TextSecondaryDark, fontSize = 11.sp)
                    }
                    IconButton(onClick = { onOpenDocumentPreview(doc) }) {
                        Icon(Icons.Default.Visibility, contentDescription = "View", tint = PhoenixSky)
                    }
                }
            }
        }

        // Direct Engineering Message Channel
        if (primaryProject != null) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Direct Channel with Phoenix Engineering Team",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimaryDark
                )
            }

            items(projectMsgs.takeLast(4)) { msg ->
                VoiceMessageItem(message = msg)
            }

            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PhoenixNavySurface, RoundedCornerShape(12.dp))
                        .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                        .padding(8.dp)
                ) {
                    IconButton(
                        onClick = {
                            onSendMessage(
                                primaryProject.id,
                                "[Voice Note - 0:08] 'Please send updated Form B certificate copy for the upcoming audit.'",
                                "voice",
                                8
                            )
                        }
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Record Voice Note", tint = PhoenixRed)
                    }

                    TextField(
                        value = chatText,
                        onValueChange = { chatText = it },
                        placeholder = { Text("Message project supervisor...", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark
                        )
                    )

                    IconButton(
                        onClick = {
                            if (chatText.isNotBlank()) {
                                onSendMessage(primaryProject.id, chatText, "text", 0)
                                chatText = ""
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (chatText.isNotBlank()) PhoenixSky else TextMutedDark
                        )
                    }
                }
            }
        }
    }
}
