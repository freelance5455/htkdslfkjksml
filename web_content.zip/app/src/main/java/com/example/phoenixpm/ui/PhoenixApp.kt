package com.example.phoenixpm.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.phoenixpm.model.*
import com.example.phoenixpm.ui.components.*
import com.example.phoenixpm.ui.screens.*
import com.example.phoenixpm.ui.theme.PhoenixNavyDark
import com.example.phoenixpm.viewmodel.PhoenixViewModel

@Composable
fun PhoenixApp(
    viewModel: PhoenixViewModel = viewModel()
) {
    val activeView by viewModel.activeView.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val users by viewModel.users.collectAsState()
    val employees by viewModel.employees.collectAsState()
    val clients by viewModel.clients.collectAsState()
    val projects by viewModel.projects.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val progressUpdates by viewModel.progressUpdates.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val documents by viewModel.documents.collectAsState()
    val notifications by viewModel.notifications.collectAsState()
    val settings by viewModel.settings.collectAsState()

    val selectedProjectId by viewModel.selectedProjectId.collectAsState()
    val selectedEmployeeId by viewModel.selectedEmployeeId.collectAsState()

    val showCreateProject by viewModel.showCreateProjectDialog.collectAsState()
    val showCreateTask by viewModel.showCreateTaskDialog.collectAsState()
    val taskDefaultProjectId by viewModel.taskDefaultProjectId.collectAsState()
    val showAddClient by viewModel.showAddClientDialog.collectAsState()
    val showPersona by viewModel.showPersonaDialog.collectAsState()
    val showZohoImport by viewModel.showZohoImportDialog.collectAsState()
    val showProgress by viewModel.showProgressDialog.collectAsState()
    val previewDoc by viewModel.previewDocument.collectAsState()

    // BackHandler for secondary views
    if (activeView != AppView.DASHBOARD && activeView != AppView.CLIENT_PORTAL && activeView != AppView.EMPLOYEE_PORTAL) {
        BackHandler {
            viewModel.navigateTo(
                when (currentUser.role) {
                    UserRole.Client -> AppView.CLIENT_PORTAL
                    UserRole.Employee -> AppView.EMPLOYEE_PORTAL
                    UserRole.Admin -> AppView.DASHBOARD
                }
            )
        }
    }

    Scaffold(
        containerColor = PhoenixNavyDark,
        topBar = {
            PhoenixTopAppBar(
                currentUser = currentUser,
                notifications = notifications,
                onOpenPersonaSwitcher = { viewModel.openPersonaDialog() },
                onOpenNewProject = { viewModel.openCreateProjectDialog() },
                onOpenNewTask = { viewModel.openCreateTaskDialog() },
                onOpenZohoImport = { viewModel.openZohoImportDialog() }
            )
        },
        bottomBar = {
            PhoenixBottomNavigation(
                activeView = activeView,
                userRole = currentUser.role,
                onSelectView = { viewModel.navigateTo(it) }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (activeView) {
                AppView.DASHBOARD -> {
                    AdminDashboardScreen(
                        projects = projects,
                        tasks = tasks,
                        clients = clients,
                        onOpenProjectDetail = { viewModel.openProjectDetail(it) },
                        onOpenNewProject = { viewModel.openCreateProjectDialog() },
                        onOpenNewTask = { viewModel.openCreateTaskDialog() },
                        onOpenAddClient = { viewModel.openAddClientDialog() },
                        onOpenZohoImport = { viewModel.openZohoImportDialog() },
                        onToggleTaskStatus = { id, status -> viewModel.repository.updateTaskStatus(id, status) }
                    )
                }

                AppView.PROJECTS -> {
                    ProjectManagementScreen(
                        projects = projects,
                        onOpenProjectDetail = { viewModel.openProjectDetail(it) },
                        onOpenNewProject = { viewModel.openCreateProjectDialog() }
                    )
                }

                AppView.PROJECT_DETAIL -> {
                    ProjectDetailScreen(
                        projectId = selectedProjectId ?: "proj-1",
                        projects = projects,
                        tasks = tasks,
                        documents = documents,
                        messages = messages,
                        progressUpdates = progressUpdates,
                        currentUser = currentUser,
                        onBack = { viewModel.navigateTo(AppView.PROJECTS) },
                        onToggleMilestone = { pId, mId -> viewModel.repository.toggleMilestone(pId, mId) },
                        onToggleTaskStatus = { id, status -> viewModel.repository.updateTaskStatus(id, status) },
                        onOpenNewTask = { pId -> viewModel.openCreateTaskDialog(pId) },
                        onOpenProgressDialog = { pId -> viewModel.openProgressDialog(pId) },
                        onOpenDocumentPreview = { doc -> viewModel.openDocumentPreview(doc) },
                        onSendMessage = { pId, content, type, dur ->
                            viewModel.repository.sendMessage(pId, content, type, dur)
                        }
                    )
                }

                AppView.TASKS -> {
                    TaskManagementScreen(
                        tasks = tasks,
                        projects = projects,
                        onToggleTaskStatus = { id, status -> viewModel.repository.updateTaskStatus(id, status) },
                        onOpenNewTask = { viewModel.openCreateTaskDialog() }
                    )
                }

                AppView.CLIENTS -> {
                    ClientManagementScreen(
                        clients = clients,
                        projects = projects,
                        onOpenAddClient = { viewModel.openAddClientDialog() },
                        onOpenZohoImport = { viewModel.openZohoImportDialog() }
                    )
                }

                AppView.CLIENT_PORTAL -> {
                    ClientPortalScreen(
                        currentUser = currentUser,
                        clients = clients,
                        projects = projects,
                        documents = documents,
                        messages = messages,
                        onOpenProjectDetail = { viewModel.openProjectDetail(it) },
                        onOpenDocumentPreview = { doc -> viewModel.openDocumentPreview(doc) },
                        onSendMessage = { pId, content, type, dur ->
                            viewModel.repository.sendMessage(pId, content, type, dur)
                        }
                    )
                }

                AppView.EMPLOYEE_PORTAL -> {
                    EmployeePortalScreen(
                        currentUser = currentUser,
                        employees = employees,
                        tasks = tasks,
                        projects = projects,
                        onToggleTaskStatus = { id, status -> viewModel.repository.updateTaskStatus(id, status) },
                        onOpenProjectDetail = { viewModel.openProjectDetail(it) },
                        onOpenProgressDialog = { pId -> viewModel.openProgressDialog(pId) }
                    )
                }

                AppView.DOCUMENTS -> {
                    DocumentsScreen(
                        documents = documents,
                        onOpenDocumentPreview = { doc -> viewModel.openDocumentPreview(doc) }
                    )
                }

                AppView.EMPLOYEES -> {
                    EmployeesScreen(
                        employees = employees,
                        onOpenEmployeeDetail = { viewModel.openEmployeeDetail(it) }
                    )
                }

                AppView.VIEW_EMPLOYEE -> {
                    EmployeeDetailScreen(
                        employeeId = selectedEmployeeId ?: "emp-1",
                        employees = employees,
                        projects = projects,
                        onBack = { viewModel.navigateTo(AppView.EMPLOYEES) },
                        onOpenProjectDetail = { viewModel.openProjectDetail(it) }
                    )
                }

                AppView.REPORTS -> {
                    ReportsScreen(
                        projects = projects,
                        tasks = tasks,
                        clients = clients
                    )
                }

                AppView.CLIENT_IMPORT -> {
                    ClientManagementScreen(
                        clients = clients,
                        projects = projects,
                        onOpenAddClient = { viewModel.openAddClientDialog() },
                        onOpenZohoImport = { viewModel.openZohoImportDialog() }
                    )
                }

                AppView.SETTINGS -> {
                    SettingsScreen(
                        settings = settings,
                        onUpdateSettings = { viewModel.repository.updateSettings(it) },
                        onResetData = { viewModel.repository.resetToDefaults() }
                    )
                }
            }
        }
    }

    // Modals & Dialogs
    if (showCreateProject) {
        CreateProjectDialog(
            clients = clients,
            employees = employees,
            onDismiss = { viewModel.closeCreateProjectDialog() },
            onConfirm = { name, clientId, cat, priority, start, end, value, location, desc, empIds, milestones ->
                viewModel.repository.createProject(
                    name = name,
                    clientId = clientId,
                    category = cat,
                    priority = priority,
                    startDate = start,
                    expectedCompletionDate = end,
                    contractValueINR = value,
                    siteLocation = location,
                    description = desc,
                    assignedEmployeeIds = empIds,
                    initialMilestones = milestones
                )
            }
        )
    }

    if (showCreateTask) {
        CreateTaskDialog(
            projects = projects,
            employees = employees,
            defaultProjectId = taskDefaultProjectId,
            onDismiss = { viewModel.closeCreateTaskDialog() },
            onConfirm = { pId, title, desc, empId, deadline, priority, vis, remarks ->
                viewModel.repository.createTask(
                    projectId = pId,
                    title = title,
                    description = desc,
                    assignedToEmployeeId = empId,
                    deadline = deadline,
                    priority = priority,
                    visibleToClient = vis,
                    remarks = remarks
                )
            }
        )
    }

    if (showAddClient) {
        AddClientDialog(
            onDismiss = { viewModel.closeAddClientDialog() },
            onConfirm = { viewModel.repository.addClient(it) }
        )
    }

    if (showPersona) {
        PersonaSwitcherDialog(
            users = users,
            currentUser = currentUser,
            onDismiss = { viewModel.closePersonaDialog() },
            onSelectUser = { viewModel.switchUser(it) }
        )
    }

    if (showZohoImport) {
        ZohoBooksImportDialog(
            onDismiss = { viewModel.closeZohoImportDialog() },
            onImport = { viewModel.repository.importZohoClients(it) }
        )
    }

    if (showProgress) {
        SubmitProgressDialog(
            projectId = selectedProjectId ?: "proj-1",
            currentProgress = projects.firstOrNull { it.id == selectedProjectId }?.progressPercentage ?: 0,
            onDismiss = { viewModel.closeProgressDialog() },
            onSubmit = { pct, notes, att, vis ->
                viewModel.repository.submitProgressUpdate(
                    projectId = selectedProjectId ?: "proj-1",
                    percentageReported = pct,
                    notes = notes,
                    attachmentName = att,
                    clientVisible = vis
                )
            }
        )
    }

    previewDoc?.let { doc ->
        DocumentPreviewDialog(
            document = doc,
            onDismiss = { viewModel.closeDocumentPreview() }
        )
    }
}
