package com.example.phoenixpm.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.R
import com.example.phoenixpm.model.AppNotification
import com.example.phoenixpm.model.User
import com.example.phoenixpm.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoenixTopAppBar(
    currentUser: User,
    notifications: List<AppNotification>,
    onOpenPersonaSwitcher: () -> Unit,
    onOpenNewProject: () -> Unit,
    onOpenNewTask: () -> Unit,
    onOpenZohoImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    val unreadNotifs = notifications.count { !it.read }
    var showMenu by remember { mutableStateOf(false) }

    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = PhoenixNavyDark,
            titleContentColor = TextPrimaryDark
        ),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.phoenix_emblem),
                    contentDescription = "Phoenix Emblem",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                )

                Column {
                    Text(
                        text = "Phoenix PM",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "Fire Safety Equipments • Chennai",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryDark
                    )
                }
            }
        },
        actions = {
            // Persona Pill Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(PhoenixNavyElevated)
                    .clickable { onOpenPersonaSwitcher() }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(PhoenixEmerald)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = currentUser.name.split(" ").firstOrNull() ?: currentUser.name,
                    color = TextPrimaryDark,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.width(4.dp))
                RoleBadge(role = currentUser.role)
            }

            // Quick Actions Overflow Menu
            Box {
                IconButton(onClick = { showMenu = !showMenu }) {
                    Icon(
                        imageVector = Icons.Default.AddCircle,
                        contentDescription = "Quick Actions",
                        tint = PhoenixRed
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(PhoenixNavySurface)
                ) {
                    DropdownMenuItem(
                        text = { Text("New Project", color = TextPrimaryDark) },
                        leadingIcon = { Icon(Icons.Default.AddBusiness, contentDescription = null, tint = PhoenixRed) },
                        onClick = {
                            showMenu = false
                            onOpenNewProject()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Allocate Task", color = TextPrimaryDark) },
                        leadingIcon = { Icon(Icons.Default.Assignment, contentDescription = null, tint = PhoenixSky) },
                        onClick = {
                            showMenu = false
                            onOpenNewTask()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Zoho CRM Import", color = TextPrimaryDark) },
                        leadingIcon = { Icon(Icons.Default.CloudDownload, contentDescription = null, tint = PhoenixAmber) },
                        onClick = {
                            showMenu = false
                            onOpenZohoImport()
                        }
                    )
                }
            }
        },
        modifier = modifier.border(width = 0.5.dp, color = BorderSubtle)
    )
}
