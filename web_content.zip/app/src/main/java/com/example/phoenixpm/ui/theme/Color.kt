package com.example.phoenixpm.ui.theme

import androidx.compose.ui.graphics.Color

val PhoenixRed = Color(0xFFDC2626) // Flame Red primary
val PhoenixRedDark = Color(0xFF991B1B)
val PhoenixRedLight = Color(0xFFF87171)

val PhoenixNavyDark = Color(0xFF0F172A) // Slate-900 background
val PhoenixNavySurface = Color(0xFF1E293B) // Slate-800 card surface
val PhoenixNavyElevated = Color(0xFF334155) // Slate-700 borders & highlights

val PhoenixAmber = Color(0xFFF59E0B) // Warning / Pending
val PhoenixEmerald = Color(0xFF10B981) // Completed / Success
val PhoenixSky = Color(0xFF0EA5E9) // Information / Links
val PhoenixPurple = Color(0xFF8B5CF6) // Milestones

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

val SurfaceCard = Color(0xFF1E293B)
val BorderSubtle = Color(0xFF334155)
