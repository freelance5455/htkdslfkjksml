package com.example.phoenixpm.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.Employee
import com.example.phoenixpm.model.Project
import com.example.phoenixpm.ui.theme.*

@Composable
fun EmployeeDetailScreen(
    employeeId: String,
    employees: List<Employee>,
    projects: List<Project>,
    onBack: () -> Unit,
    onOpenProjectDetail: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val employee = employees.firstOrNull { it.id == employeeId } ?: employees.firstOrNull()
    if (employee == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Employee not found", color = TextSecondaryDark)
        }
        return
    }

    val assignedProjects = projects.filter { it.assignedEmployeeIds.contains(employee.id) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Back Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimaryDark
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = employee.employeeCode,
                        color = PhoenixRed,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = employee.employeeName,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimaryDark
                    )
                }
            }
        }

        // Official Profile Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Official Profile & Role",
                        color = PhoenixSky,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailRow("Designation", employee.designation)
                    DetailRow("Department", employee.department)
                    DetailRow("Joining Date", employee.joiningDate)
                    DetailRow("Status", employee.status)
                    DetailRow("Phone", employee.phone)
                    DetailRow("Email", employee.email)
                }
            }
        }

        // Statutory & Compliance Dossier Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Statutory & Verification Details",
                        color = PhoenixAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailRow("Aadhaar Number", employee.aadhaarNumber ?: "Not Provided")
                    DetailRow("PAN Number", employee.panNumber ?: "Not Provided")
                    DetailRow("Blood Group", employee.bloodGroup ?: "Not Recorded")
                    DetailRow("Date of Birth", employee.dateOfBirth ?: "Not Recorded")
                    DetailRow("Address", employee.address ?: "Chennai, Tamil Nadu")
                    DetailRow("Emergency Contact", "${employee.emergencyContactName ?: "N/A"} (${employee.emergencyContactPhone ?: "N/A"})")
                }
            }
        }

        // Assigned Projects Section
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Assigned Site Installations (${assignedProjects.size})",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimaryDark
            )
        }

        items(assignedProjects) { proj ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(proj.reference, color = PhoenixRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(proj.name, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text("Client: ${proj.clientCompanyName} • Progress: ${proj.progressPercentage}%", color = TextSecondaryDark, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSecondaryDark, fontSize = 12.sp)
        Text(text = value, color = TextPrimaryDark, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
