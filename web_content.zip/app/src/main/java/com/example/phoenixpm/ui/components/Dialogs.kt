package com.example.phoenixpm.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.phoenixpm.model.*
import com.example.phoenixpm.ui.theme.*

@Composable
fun CreateProjectDialog(
    clients: List<Client>,
    employees: List<Employee>,
    onDismiss: () -> Unit,
    onConfirm: (
        name: String,
        clientId: String,
        category: ProjectCategory,
        priority: ProjectPriority,
        startDate: String,
        expectedCompletionDate: String,
        contractValueINR: Long,
        siteLocation: String,
        description: String,
        assignedEmployeeIds: List<String>,
        initialMilestones: List<String>
    ) -> Unit
) {
    var projectName by remember { mutableStateOf("") }
    var selectedClientId by remember { mutableStateOf(clients.firstOrNull()?.id ?: "") }
    var selectedCategory by remember { mutableStateOf(ProjectCategory.FIRE_ALARM) }
    var selectedPriority by remember { mutableStateOf(ProjectPriority.High) }
    var startDate by remember { mutableStateOf("2026-11-01") }
    var endDate by remember { mutableStateOf("2027-04-30") }
    var contractValueText by remember { mutableStateOf("1500000") }
    var siteLocation by remember { mutableStateOf("Chennai, Tamil Nadu") }
    var description by remember { mutableStateOf("") }
    var selectedEmpIds by remember { mutableStateOf(listOf(employees.firstOrNull()?.id ?: "emp-1")) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PhoenixNavySurface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Create New Project",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimaryDark
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMutedDark)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f, fill = false),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = projectName,
                            onValueChange = { projectName = it },
                            label = { Text("Project Name") },
                            placeholder = { Text("e.g. Fire Hydrant & Alarm Overhaul") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PhoenixRed,
                                unfocusedBorderColor = BorderSubtle
                            )
                        )
                    }

                    item {
                        Text("Client Organization", color = TextSecondaryDark, fontSize = 12.sp)
                        clients.forEach { client ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedClientId = client.id }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = selectedClientId == client.id,
                                    onClick = { selectedClientId = client.id },
                                    colors = RadioButtonDefaults.colors(selectedColor = PhoenixRed)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(client.companyName, color = TextPrimaryDark, fontSize = 13.sp)
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = siteLocation,
                            onValueChange = { siteLocation = it },
                            label = { Text("Site Location (Address in Chennai/TN)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = contractValueText,
                            onValueChange = { contractValueText = it },
                            label = { Text("Contract Value (INR ₹)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Scope Description") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondaryDark)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (projectName.isNotBlank()) {
                                onConfirm(
                                    projectName,
                                    selectedClientId,
                                    selectedCategory,
                                    selectedPriority,
                                    startDate,
                                    endDate,
                                    contractValueText.toLongOrNull() ?: 1000000L,
                                    siteLocation,
                                    description.ifBlank { "Turnkey fire protection installation." },
                                    selectedEmpIds,
                                    listOf("Site Survey & CAD Drafting", "Equipment Delivery", "Installation & Piping", "Final Commissioning & TNFRS NOC")
                                )
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed)
                    ) {
                        Text("Create Project")
                    }
                }
            }
        }
    }
}

@Composable
fun CreateTaskDialog(
    projects: List<Project>,
    employees: List<Employee>,
    defaultProjectId: String?,
    onDismiss: () -> Unit,
    onConfirm: (
        projectId: String,
        title: String,
        description: String,
        assignedToEmployeeId: String,
        deadline: String,
        priority: ProjectPriority,
        visibleToClient: Boolean,
        remarks: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedProjectId by remember { mutableStateOf(defaultProjectId ?: projects.firstOrNull()?.id ?: "") }
    var selectedEmpId by remember { mutableStateOf(employees.firstOrNull()?.id ?: "") }
    var deadline by remember { mutableStateOf("2026-11-15") }
    var priority by remember { mutableStateOf(ProjectPriority.High) }
    var visibleToClient by remember { mutableStateOf(true) }
    var remarks by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PhoenixNavySurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("New Task Allocation", style = MaterialTheme.typography.titleLarge, color = TextPrimaryDark)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title") },
                    placeholder = { Text("e.g. Conduct Hydrostatic Pressure Test") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text("Assign to Engineer / Supervisor", color = TextSecondaryDark, fontSize = 12.sp)
                employees.take(3).forEach { emp ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedEmpId = emp.id }
                            .padding(vertical = 2.dp)
                    ) {
                        RadioButton(
                            selected = selectedEmpId == emp.id,
                            onClick = { selectedEmpId = emp.id },
                            colors = RadioButtonDefaults.colors(selectedColor = PhoenixRed)
                        )
                        Text("${emp.employeeName} (${emp.employeeCode})", color = TextPrimaryDark, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = deadline,
                    onValueChange = { deadline = it },
                    label = { Text("Deadline (YYYY-MM-DD)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = remarks,
                    onValueChange = { remarks = it },
                    label = { Text("Site Remarks / Safety Instructions") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondaryDark)
                    }
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                onConfirm(
                                    selectedProjectId,
                                    title,
                                    description.ifBlank { title },
                                    selectedEmpId,
                                    deadline,
                                    priority,
                                    visibleToClient,
                                    remarks
                                )
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed)
                    ) {
                        Text("Save Task")
                    }
                }
            }
        }
    }
}

@Composable
fun AddClientDialog(
    onDismiss: () -> Unit,
    onConfirm: (Client) -> Unit
) {
    var companyName by remember { mutableStateOf("") }
    var contactPerson by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var gstin by remember { mutableStateOf("") }
    var industry by remember { mutableStateOf("Commercial Real Estate") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PhoenixNavySurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Add New Client", style = MaterialTheme.typography.titleLarge, color = TextPrimaryDark)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = companyName,
                    onValueChange = { companyName = it },
                    label = { Text("Company Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = contactPerson,
                    onValueChange = { contactPerson = it },
                    label = { Text("Contact Person") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = gstin,
                    onValueChange = { gstin = it },
                    label = { Text("GSTIN") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondaryDark)
                    }
                    Button(
                        onClick = {
                            if (companyName.isNotBlank() && contactPerson.isNotBlank()) {
                                val newClient = Client(
                                    id = "client-${System.currentTimeMillis() % 10000}",
                                    companyName = companyName,
                                    contactPerson = contactPerson,
                                    email = email.ifBlank { "contact@${companyName.replace(" ", "").lowercase()}.com" },
                                    phone = phone.ifBlank { "+91 98400 00000" },
                                    username = contactPerson.replace(" ", ".").lowercase(),
                                    address = address.ifBlank { "Chennai, Tamil Nadu" },
                                    city = "Chennai, Tamil Nadu 600001",
                                    gstin = gstin.ifBlank { "33AABCP9999Z1Z1" },
                                    industry = industry,
                                    createdAt = "2026-10-20"
                                )
                                onConfirm(newClient)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed)
                    ) {
                        Text("Save Client")
                    }
                }
            }
        }
    }
}

@Composable
fun PersonaSwitcherDialog(
    users: List<User>,
    currentUser: User,
    onDismiss: () -> Unit,
    onSelectUser: (String) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PhoenixNavySurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Switch User Persona",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Test Admin, Employee, or Client portals with live role-based permissions.",
                    color = TextSecondaryDark,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.heightIn(max = 380.dp)
                ) {
                    items(users) { user ->
                        val isSelected = user.id == currentUser.id
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isSelected) PhoenixNavyElevated else Color.Transparent,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { onSelectUser(user.id) }
                                .padding(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = user.name,
                                    color = TextPrimaryDark,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = user.designation,
                                    color = TextSecondaryDark,
                                    fontSize = 12.sp
                                )
                            }
                            RoleBadge(role = user.role)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Close", color = TextSecondaryDark)
                    }
                }
            }
        }
    }
}

@Composable
fun ZohoBooksImportDialog(
    onDismiss: () -> Unit,
    onImport: (List<Client>) -> Unit
) {
    val sampleZohoContacts = remember {
        listOf(
            Client(
                id = "zoho-1",
                companyName = "L&T Construction (ECC Division)",
                contactPerson = "M. Sivasubramanian",
                email = "sivasubramanian.m@lntecc.com",
                phone = "+91 94450 11928",
                username = "sivasubramanian.m",
                address = "Mount Poonamallee Road, Manapakkam",
                city = "Chennai, Tamil Nadu 600089",
                gstin = "33AAACL0140P1ZQ",
                industry = "EPC Heavy Construction",
                zohoContactId = "ZC-9912041",
                createdAt = "2026-10-20"
            ),
            Client(
                id = "zoho-2",
                companyName = "TVS Motor Company Ltd.",
                contactPerson = "R. Chandrasekhar",
                email = "chandrasekhar.r@tvsmotor.com",
                phone = "+91 98409 55192",
                username = "chandrasekhar.r",
                address = "Harita, Hosur & Padi Works",
                city = "Chennai, Tamil Nadu 600050",
                gstin = "33AAACT1940E1ZV",
                industry = "Automotive Manufacturing",
                zohoContactId = "ZC-8819203",
                createdAt = "2026-10-20"
            )
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PhoenixNavySurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, tint = PhoenixSky)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Zoho Books Contacts Sync", style = MaterialTheme.typography.titleLarge, color = TextPrimaryDark)
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Connected Zoho Books CRM Organization: Phoenix Fire Safety Equipments Pvt. Ltd. (Org ID: 7719201)",
                    color = TextSecondaryDark,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(14.dp))

                sampleZohoContacts.forEach { contact ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = PhoenixNavyElevated),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(contact.companyName, color = TextPrimaryDark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Contact: ${contact.contactPerson} • ${contact.phone}", color = TextSecondaryDark, fontSize = 12.sp)
                            Text("Zoho ID: ${contact.zohoContactId} • GSTIN: ${contact.gstin}", color = TextMutedDark, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondaryDark)
                    }
                    Button(
                        onClick = {
                            onImport(sampleZohoContacts)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PhoenixSky)
                    ) {
                        Text("Import 2 Contacts")
                    }
                }
            }
        }
    }
}

@Composable
fun DocumentPreviewDialog(
    document: ProjectDocument,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PhoenixNavySurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Document Preview",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimaryDark
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMutedDark)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(document.title, color = PhoenixSky, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("${document.filename} • ${document.fileSize} • ${document.category.label}", color = TextSecondaryDark, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PhoenixNavyDark, RoundedCornerShape(8.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = document.previewText ?: "Official engineering file uploaded by ${document.uploadedBy} (${document.uploadDate}). Access level: ${document.accessLevel}.",
                        color = TextPrimaryDark,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Verified IS 3844 / NBC 2016", color = PhoenixEmerald, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed)
                    ) {
                        Text("Done")
                    }
                }
            }
        }
    }
}

@Composable
fun SubmitProgressDialog(
    projectId: String,
    currentProgress: Int,
    onDismiss: () -> Unit,
    onSubmit: (percentage: Int, notes: String, attachmentName: String?, clientVisible: Boolean) -> Unit
) {
    var percentage by remember { mutableFloatStateOf(currentProgress.toFloat()) }
    var notes by remember { mutableStateOf("") }
    var attachmentName by remember { mutableStateOf("Site_Inspection_Log.pdf") }
    var clientVisible by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = PhoenixNavySurface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Log Progress Report", style = MaterialTheme.typography.titleLarge, color = TextPrimaryDark)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Work Completion Percentage", color = TextSecondaryDark, fontSize = 13.sp)
                    Text("${percentage.toInt()}%", color = PhoenixRed, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Slider(
                    value = percentage,
                    onValueChange = { percentage = it },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = PhoenixRed,
                        activeTrackColor = PhoenixRed
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Progress Update Notes") },
                    placeholder = { Text("Describe installation, sensor wiring, or pressure test results...") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = attachmentName,
                    onValueChange = { attachmentName = it },
                    label = { Text("Attachment Document / Photos") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondaryDark)
                    }
                    Button(
                        onClick = {
                            if (notes.isNotBlank()) {
                                onSubmit(percentage.toInt(), notes, attachmentName.ifBlank { null }, clientVisible)
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed)
                    ) {
                        Text("Submit Log")
                    }
                }
            }
        }
    }
}
