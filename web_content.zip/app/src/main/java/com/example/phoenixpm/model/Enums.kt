package com.example.phoenixpm.model

enum class UserRole {
    Admin,
    Employee,
    Client
}

enum class ProjectCategory(val label: String) {
    FIRE_ALARM("Fire Alarm System"),
    HYDRANT_SPRINKLER("Hydrant & Sprinkler"),
    CO2_CLEAN_AGENT("CO2 & Clean Agent Gas"),
    EXTINGUISHER_AMC("Extinguisher & AMC"),
    TNFRS_NOC("TNFRS NOC Compliance");

    companion object {
        fun fromLabel(label: String): ProjectCategory {
            return entries.firstOrNull { it.label == label } ?: FIRE_ALARM
        }
    }
}

enum class ProjectPriority {
    Low,
    Medium,
    High,
    Critical
}

enum class ProjectStatus(val label: String) {
    PENDING("Pending"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    ON_HOLD("On Hold"),
    OVERDUE("Overdue");

    companion object {
        fun fromLabel(label: String): ProjectStatus {
            return entries.firstOrNull { it.label == label } ?: PENDING
        }
    }
}

enum class TaskStatus(val label: String) {
    PENDING("Pending"),
    TO_DO("To Do"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    OVERDUE("Overdue");

    companion object {
        fun fromLabel(label: String): TaskStatus {
            return entries.firstOrNull { it.label == label } ?: PENDING
        }
    }
}

enum class DocumentCategory(val label: String) {
    DRAWING("Drawing"),
    QUOTATION("Quotation"),
    INVOICE("Invoice"),
    COMPLETION_REPORT("Completion Report"),
    CERTIFICATE("Certificate"),
    SITE_PHOTO("Site Photo"),
    PURCHASE_ORDER("Purchase Order"),
    WORK_ORDER("Work Order"),
    CAD_DRAWING("CAD Drawing"),
    INSPECTION_REPORT("Inspection Report"),
    FORM_B_NOC("Form B NOC"),
    COMPLETION_CERTIFICATE("Completion Certificate"),
    SERVICE_REPORT("Service Report"),
    OTHER("Other");

    companion object {
        fun fromLabel(label: String): DocumentCategory {
            return entries.firstOrNull { it.label == label } ?: OTHER
        }
    }
}

enum class AppView(val title: String) {
    DASHBOARD("Dashboard"),
    PROJECTS("Projects"),
    PROJECT_DETAIL("Project Detail"),
    TASKS("Tasks"),
    CLIENTS("Clients"),
    CLIENT_PORTAL("Client Portal"),
    EMPLOYEE_PORTAL("My Workspace"),
    DOCUMENTS("Documents"),
    EMPLOYEES("Team & Staff"),
    VIEW_EMPLOYEE("Employee Details"),
    REPORTS("Reports & Analytics"),
    CLIENT_IMPORT("Zoho CRM Import"),
    SETTINGS("Settings")
}
