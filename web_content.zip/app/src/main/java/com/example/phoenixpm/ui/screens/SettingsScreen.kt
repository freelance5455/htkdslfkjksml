package com.example.phoenixpm.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.PluginSettings
import com.example.phoenixpm.ui.theme.*

@Composable
fun SettingsScreen(
    settings: PluginSettings,
    onUpdateSettings: (PluginSettings) -> Unit,
    onResetData: () -> Unit,
    modifier: Modifier = Modifier
) {
    var zohoUrl by remember { mutableStateOf(settings.zohoUrl) }
    var emailNotifs by remember { mutableStateOf(settings.emailNotifications) }
    var smsAlerts by remember { mutableStateOf(settings.smsAlerts) }
    var showResetConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "System & Integration Settings",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Configure Zoho Books ERP, automated audit alerts, and company master data",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryDark
                )
            }
        }

        // Company Master Profile
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Company Profile",
                        color = PhoenixSky,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Company: Phoenix Fire Safety Equipments Pvt. Ltd.", color = TextPrimaryDark, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("Headquarters: Chennai, Tamil Nadu, India", color = TextSecondaryDark, fontSize = 12.sp)
                    Text("Statutory Baseline: IS 3844 / NBC 2016 Compliant", color = PhoenixEmerald, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Text("State Fire Department: Tamil Nadu Fire and Rescue Services (TNFRS)", color = TextMutedDark, fontSize = 11.sp)
                }
            }
        }

        // Zoho Books Integration
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CloudSync, contentDescription = null, tint = PhoenixSky)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Zoho Books / CRM Endpoint",
                            color = TextPrimaryDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = zohoUrl,
                        onValueChange = {
                            zohoUrl = it
                            onUpdateSettings(settings.copy(zohoUrl = it))
                        },
                        label = { Text("Zoho CRM / Books Webhook URL") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Allows real-time sync of clients, contact persons, invoices, and purchase orders.",
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Notifications Preferences
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Audit & Dispatch Alerts",
                        color = PhoenixAmber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Email Inspection Reports", color = TextPrimaryDark, fontSize = 13.sp)
                            Text("Send PDF summary to client after milestone sign-off", color = TextSecondaryDark, fontSize = 11.sp)
                        }
                        Switch(
                            checked = emailNotifs,
                            onCheckedChange = {
                                emailNotifs = it
                                onUpdateSettings(settings.copy(emailNotifications = it))
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PhoenixRed, checkedTrackColor = PhoenixRedDark)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("SMS Critical Alerts", color = TextPrimaryDark, fontSize = 13.sp)
                            Text("Night shift sensor tests & pressure drop warnings", color = TextSecondaryDark, fontSize = 11.sp)
                        }
                        Switch(
                            checked = smsAlerts,
                            onCheckedChange = {
                                smsAlerts = it
                                onUpdateSettings(settings.copy(smsAlerts = it))
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PhoenixRed, checkedTrackColor = PhoenixRedDark)
                        )
                    }
                }
            }
        }

        // Reset Data
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Data Management",
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Restore default Chennai fire safety projects (Apollo Hospitals, Hyundai, Olympia Tech Park) and sample voice recordings.",
                        color = TextSecondaryDark,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = { showResetConfirm = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PhoenixRed),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset to Sample Data")
                    }
                }
            }
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text("Confirm Data Reset") },
            text = { Text("This will restore initial sample records for Phoenix Fire Safety Equipments Pvt. Ltd. Continue?") },
            confirmButton = {
                Button(
                    onClick = {
                        onResetData()
                        showResetConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed)
                ) {
                    Text("Confirm Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
