package com.example.phoenixpm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.phoenixpm.ui.PhoenixApp
import com.example.phoenixpm.ui.theme.PhoenixPMTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PhoenixPMTheme {
                PhoenixApp()
            }
        }
    }
}
