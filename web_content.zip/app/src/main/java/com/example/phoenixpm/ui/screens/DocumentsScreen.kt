package com.example.phoenixpm.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.DocumentCategory
import com.example.phoenixpm.model.ProjectDocument
import com.example.phoenixpm.ui.theme.*

@Composable
fun DocumentsScreen(
    documents: List<ProjectDocument>,
    onOpenDocumentPreview: (ProjectDocument) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<DocumentCategory?>(null) }

    val filteredDocs = documents.filter { doc ->
        val matchesSearch = doc.title.contains(searchQuery, ignoreCase = true) ||
                doc.filename.contains(searchQuery, ignoreCase = true) ||
                doc.projectReference.contains(searchQuery, ignoreCase = true) ||
                doc.uploadedBy.contains(searchQuery, ignoreCase = true)

        val matchesCategory = selectedCategory == null || doc.category == selectedCategory

        matchesSearch && matchesCategory
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Engineering & Statutory Documents",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimaryDark
                )
                Text(
                    text = "CAD Blueprints, Hydraulic Reports, Form B NOC, & Handover Certificates",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryDark
                )
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search blueprint, NOC, certificate, or project ref...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondaryDark) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    label = { Text("All (${documents.size})") }
                )

                DocumentCategory.entries.take(8).forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                        label = { Text(cat.label) }
                    )
                }
            }
        }

        // Document Items
        items(filteredDocs) { doc ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                    .clickable { onOpenDocumentPreview(doc) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(
                                if (doc.fileType == "pdf") PhoenixRed.copy(alpha = 0.15f) else PhoenixSky.copy(alpha = 0.15f),
                                RoundedCornerShape(10.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (doc.fileType) {
                                "pdf" -> Icons.Default.PictureAsPdf
                                "dwg" -> Icons.Default.Architecture
                                else -> Icons.Default.Description
                            },
                            contentDescription = null,
                            tint = if (doc.fileType == "pdf") PhoenixRed else PhoenixSky,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = doc.projectReference,
                                color = PhoenixRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Box(
                                modifier = Modifier
                                    .background(PhoenixNavyElevated, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = doc.accessLevel,
                                    color = if (doc.accessLevel == "Client Shared") PhoenixEmerald else PhoenixAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(doc.title, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("${doc.filename} • ${doc.fileSize} • ${doc.category.label}", color = TextSecondaryDark, fontSize = 11.sp)
                        Text("Uploaded by ${doc.uploadedBy} on ${doc.uploadDate}", color = TextMutedDark, fontSize = 10.sp)
                    }

                    IconButton(onClick = { onOpenDocumentPreview(doc) }) {
                        Icon(Icons.Default.Visibility, contentDescription = "Preview", tint = PhoenixSky)
                    }
                }
            }
        }
    }
}
