package com.example.phoenixpm.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.*
import com.example.phoenixpm.ui.components.PriorityBadge
import com.example.phoenixpm.ui.components.TaskStatusBadge
import com.example.phoenixpm.ui.theme.*

@Composable
fun EmployeePortalScreen(
    currentUser: User,
    employees: List<Employee>,
    tasks: List<Task>,
    projects: List<Project>,
    onToggleTaskStatus: (String, TaskStatus) -> Unit,
    onOpenProjectDetail: (String) -> Unit,
    onOpenProgressDialog: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val employee = employees.firstOrNull { it.id == currentUser.employeeId } ?: employees.firstOrNull()
    val empId = employee?.id ?: "emp-1"

    val myTasks = tasks.filter { it.assignedToEmployeeId == empId }
    val myProjects = projects.filter { it.assignedEmployeeIds.contains(empId) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Engineer Header Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = employee?.employeeCode ?: "PFS-0001",
                            color = PhoenixRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = employee?.department ?: "Fire Engineering",
                            color = PhoenixSky,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentUser.name,
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = currentUser.designation,
                        color = TextSecondaryDark,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("Tasks: ${myTasks.count { it.status == TaskStatus.COMPLETED }}/${myTasks.size} Done", color = PhoenixEmerald, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("Assigned Projects: ${myProjects.size}", color = TextSecondaryDark, fontSize = 12.sp)
                    }
                }
            }
        }

        // My Tasks Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "My Allocated Work Items (${myTasks.size})",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimaryDark
                )
                Text(
                    text = "${myTasks.count { it.status != TaskStatus.COMPLETED }} Pending",
                    color = PhoenixAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        items(myTasks) { task ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = task.status == TaskStatus.COMPLETED,
                        onCheckedChange = { isChecked ->
                            onToggleTaskStatus(
                                task.id,
                                if (isChecked) TaskStatus.COMPLETED else TaskStatus.IN_PROGRESS
                            )
                        },
                        colors = CheckboxDefaults.colors(
                            checkedColor = PhoenixEmerald,
                            checkmarkColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(task.projectReference, color = PhoenixRed, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            PriorityBadge(priority = task.priority)
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(task.title, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(task.description, color = TextSecondaryDark, fontSize = 11.sp)
                        Text("Due: ${task.deadline} • Remarks: ${task.remarks}", color = TextMutedDark, fontSize = 10.sp)
                    }

                    Spacer(modifier = Modifier.width(6.dp))
                    TaskStatusBadge(status = task.status)
                }
            }
        }

        // My Projects Section
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "My Assigned Site Installations",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimaryDark
            )
        }

        items(myProjects) { project ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                    .clickable { onOpenProjectDetail(project.id) }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(project.reference, color = PhoenixRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Button(
                            onClick = { onOpenProgressDialog(project.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = PhoenixEmerald),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Log Report", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(project.name, color = TextPrimaryDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Client: ${project.clientCompanyName} • Site: ${project.siteLocation}", color = TextSecondaryDark, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { project.progressPercentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = PhoenixEmerald,
                        trackColor = PhoenixNavyElevated
                    )
                }
            }
        }
    }
}
