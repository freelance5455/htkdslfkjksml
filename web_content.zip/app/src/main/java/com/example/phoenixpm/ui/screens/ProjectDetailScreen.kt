package com.example.phoenixpm.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.*
import com.example.phoenixpm.ui.components.PriorityBadge
import com.example.phoenixpm.ui.components.StatusBadge
import com.example.phoenixpm.ui.components.TaskStatusBadge
import com.example.phoenixpm.ui.components.VoiceMessageItem
import com.example.phoenixpm.ui.theme.*

@Composable
fun ProjectDetailScreen(
    projectId: String,
    projects: List<Project>,
    tasks: List<Task>,
    documents: List<ProjectDocument>,
    messages: List<ConversationMessage>,
    progressUpdates: List<ProgressUpdate>,
    currentUser: User,
    onBack: () -> Unit,
    onToggleMilestone: (String, String) -> Unit,
    onToggleTaskStatus: (String, TaskStatus) -> Unit,
    onOpenNewTask: (String) -> Unit,
    onOpenProgressDialog: (String) -> Unit,
    onOpenDocumentPreview: (ProjectDocument) -> Unit,
    onSendMessage: (projectId: String, content: String, type: String, duration: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val project = projects.firstOrNull { it.id == projectId } ?: projects.firstOrNull()
    if (project == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Project not found", color = TextSecondaryDark)
        }
        return
    }

    val projectTasks = tasks.filter { it.projectId == project.id }
    val projectDocs = documents.filter { it.projectId == project.id }
    val projectMsgs = messages.filter { it.projectId == project.id }
    val projectUpdates = progressUpdates.filter { it.projectId == project.id }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabTitles = listOf("Milestones", "Tasks (${projectTasks.size})", "Feed", "Documents (${projectDocs.size})", "Messages")

    var chatInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Top Nav bar with Back arrow
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimaryDark
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = project.reference,
                    color = PhoenixRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = project.name,
                    color = TextPrimaryDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    maxLines = 1
                )
            }
            StatusBadge(status = project.status)
        }

        // Summary Card
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(project.clientCompanyName, color = PhoenixSky, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    PriorityBadge(priority = project.priority)
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text("Site: ${project.siteLocation}", color = TextSecondaryDark, fontSize = 12.sp)
                Text("Contract Value: ₹${project.contractValueINR / 100000.0} Lakhs • IS 3844 Standard", color = TextMutedDark, fontSize = 11.sp)

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Overall Completion", color = TextSecondaryDark, fontSize = 12.sp)
                    Text("${project.progressPercentage}%", color = PhoenixEmerald, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { project.progressPercentage / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = PhoenixEmerald,
                    trackColor = PhoenixNavyElevated
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = PhoenixNavyDark,
            contentColor = PhoenixRed,
            edgePadding = 0.dp
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            color = if (selectedTabIndex == index) PhoenixRed else TextSecondaryDark,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Tab Content
        Box(modifier = Modifier.weight(1f)) {
            when (selectedTabIndex) {
                // 0: Milestones
                0 -> {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 16.dp)
                    ) {
                        item {
                            Text(
                                text = "Contract Milestones Checklist",
                                color = TextPrimaryDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Toggling milestones updates project progress automatically per engineering schedule.",
                                color = TextSecondaryDark,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        items(project.milestones) { milestone ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (milestone.completed) PhoenixEmerald.copy(alpha = 0.08f) else SurfaceCard
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        1.dp,
                                        if (milestone.completed) PhoenixEmerald.copy(alpha = 0.4f) else BorderSubtle,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { onToggleMilestone(project.id, milestone.id) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = milestone.completed,
                                        onCheckedChange = { onToggleMilestone(project.id, milestone.id) },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = PhoenixEmerald,
                                            checkmarkColor = Color.White
                                        )
                                    )

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = milestone.title,
                                            color = TextPrimaryDark,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = milestone.description,
                                            color = TextSecondaryDark,
                                            fontSize = 11.sp
                                        )
                                        Text(
                                            text = if (milestone.completed) "Completed on ${milestone.completedDate ?: "record"}" else "Due date: ${milestone.dueDate}",
                                            color = if (milestone.completed) PhoenixEmerald else TextMutedDark,
                                            fontSize = 11.sp,
                                            fontWeight = if (milestone.completed) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 1: Tasks
                1 -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Work Items Allocated", color = TextPrimaryDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(
                                onClick = { onOpenNewTask(project.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Task", fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 16.dp)
                        ) {
                            items(projectTasks) { task ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = task.status == TaskStatus.COMPLETED,
                                            onCheckedChange = { isChecked ->
                                                onToggleTaskStatus(
                                                    task.id,
                                                    if (isChecked) TaskStatus.COMPLETED else TaskStatus.IN_PROGRESS
                                                )
                                            },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = PhoenixEmerald,
                                                checkmarkColor = Color.White
                                            )
                                        )

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(task.title, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text(task.description, color = TextSecondaryDark, fontSize = 11.sp, maxLines = 2)
                                            Text("Assignee: ${task.assignedToName} • Due: ${task.deadline}", color = TextMutedDark, fontSize = 11.sp)
                                        }

                                        TaskStatusBadge(status = task.status)
                                    }
                                }
                            }
                        }
                    }
                }

                // 2: Feed / Progress Updates
                2 -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Field Inspection Reports", color = TextPrimaryDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(
                                onClick = { onOpenProgressDialog(project.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = PhoenixEmerald),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Log Progress", fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 16.dp)
                        ) {
                            items(projectUpdates) { update ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("${update.submittedByName} (${update.userRole.name})", color = PhoenixSky, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text(update.timestamp, color = TextMutedDark, fontSize = 11.sp)
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Reported Progress: ${update.percentageReported}%",
                                            color = PhoenixEmerald,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(update.notes, color = TextPrimaryDark, fontSize = 12.sp, lineHeight = 18.sp)

                                        if (!update.attachmentName.isNullOrBlank()) {
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier
                                                    .background(PhoenixNavyDark, RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Icon(Icons.Default.AttachFile, contentDescription = null, tint = PhoenixAmber, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(update.attachmentName, color = TextSecondaryDark, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 3: Documents
                3 -> {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 16.dp)
                    ) {
                        items(projectDocs) { doc ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                                    .clickable { onOpenDocumentPreview(doc) }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = when (doc.fileType) {
                                            "dwg" -> Icons.Default.Architecture
                                            "pdf" -> Icons.Default.PictureAsPdf
                                            else -> Icons.Default.Description
                                        },
                                        contentDescription = null,
                                        tint = if (doc.fileType == "pdf") PhoenixRed else PhoenixSky,
                                        modifier = Modifier.size(32.dp)
                                    )

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(doc.title, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                        Text("${doc.filename} • ${doc.fileSize} • ${doc.category.label}", color = TextSecondaryDark, fontSize = 11.sp)
                                        Text("Uploaded by ${doc.uploadedBy} on ${doc.uploadDate}", color = TextMutedDark, fontSize = 10.sp)
                                    }

                                    IconButton(onClick = { onOpenDocumentPreview(doc) }) {
                                        Icon(Icons.Default.Visibility, contentDescription = "Preview", tint = PhoenixSky)
                                    }
                                }
                            }
                        }
                    }
                }

                // 4: Messages & Voice Notes
                4 -> {
                    Column(modifier = Modifier.fillMaxSize()) {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 12.dp)
                        ) {
                            items(projectMsgs) { msg ->
                                VoiceMessageItem(message = msg)
                            }
                        }

                        // Message Composer with Text and Voice note simulation button
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(PhoenixNavySurface, RoundedCornerShape(12.dp))
                                .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                                .padding(8.dp)
                        ) {
                            // Voice Record button
                            IconButton(
                                onClick = {
                                    onSendMessage(
                                        project.id,
                                        "[Voice Note - 0:07] 'Sensor loop 3 testing verified with BMS panel.'",
                                        "voice",
                                        7
                                    )
                                }
                            ) {
                                Icon(Icons.Default.Mic, contentDescription = "Send Voice Note", tint = PhoenixRed)
                            }

                            TextField(
                                value = chatInput,
                                onValueChange = { chatInput = it },
                                placeholder = { Text("Message team or record voice note...", fontSize = 12.sp) },
                                modifier = Modifier.weight(1f),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = TextPrimaryDark,
                                    unfocusedTextColor = TextPrimaryDark
                                )
                            )

                            IconButton(
                                onClick = {
                                    if (chatInput.isNotBlank()) {
                                        onSendMessage(project.id, chatInput, "text", 0)
                                        chatInput = ""
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = if (chatInput.isNotBlank()) PhoenixSky else TextMutedDark
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
