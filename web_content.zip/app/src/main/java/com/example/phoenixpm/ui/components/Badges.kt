package com.example.phoenixpm.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.*
import com.example.phoenixpm.ui.theme.*

@Composable
fun PriorityBadge(priority: ProjectPriority, modifier: Modifier = Modifier) {
    val (bg, fg) = when (priority) {
        ProjectPriority.Critical -> PhoenixRed.copy(alpha = 0.2f) to PhoenixRedLight
        ProjectPriority.High -> PhoenixAmber.copy(alpha = 0.2f) to PhoenixAmber
        ProjectPriority.Medium -> PhoenixSky.copy(alpha = 0.2f) to PhoenixSky
        ProjectPriority.Low -> Color.Gray.copy(alpha = 0.2f) to TextSecondaryDark
    }

    Box(
        modifier = modifier
            .background(bg, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = priority.name.uppercase(),
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun StatusBadge(status: ProjectStatus, modifier: Modifier = Modifier) {
    val (bg, fg) = when (status) {
        ProjectStatus.COMPLETED -> PhoenixEmerald.copy(alpha = 0.2f) to PhoenixEmerald
        ProjectStatus.IN_PROGRESS -> PhoenixSky.copy(alpha = 0.2f) to PhoenixSky
        ProjectStatus.PENDING -> PhoenixAmber.copy(alpha = 0.2f) to PhoenixAmber
        ProjectStatus.OVERDUE -> PhoenixRed.copy(alpha = 0.2f) to PhoenixRedLight
        ProjectStatus.ON_HOLD -> Color.Gray.copy(alpha = 0.2f) to TextSecondaryDark
    }

    Box(
        modifier = modifier
            .background(bg, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = status.label,
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun TaskStatusBadge(status: TaskStatus, modifier: Modifier = Modifier) {
    val (bg, fg) = when (status) {
        TaskStatus.COMPLETED -> PhoenixEmerald.copy(alpha = 0.2f) to PhoenixEmerald
        TaskStatus.IN_PROGRESS -> PhoenixSky.copy(alpha = 0.2f) to PhoenixSky
        TaskStatus.PENDING, TaskStatus.TO_DO -> PhoenixAmber.copy(alpha = 0.2f) to PhoenixAmber
        TaskStatus.OVERDUE -> PhoenixRed.copy(alpha = 0.2f) to PhoenixRedLight
    }

    Box(
        modifier = modifier
            .background(bg, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = status.label,
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun RoleBadge(role: UserRole, modifier: Modifier = Modifier) {
    val (bg, fg) = when (role) {
        UserRole.Admin -> PhoenixRed.copy(alpha = 0.2f) to PhoenixRedLight
        UserRole.Employee -> PhoenixSky.copy(alpha = 0.2f) to PhoenixSky
        UserRole.Client -> PhoenixAmber.copy(alpha = 0.2f) to PhoenixAmber
    }

    Box(
        modifier = modifier
            .background(bg, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = role.name,
            color = fg,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
