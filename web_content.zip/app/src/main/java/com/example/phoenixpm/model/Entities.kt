package com.example.phoenixpm.model

data class User(
    val id: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val designation: String,
    val clientId: String? = null,
    val employeeId: String? = null,
    val avatar: String? = null,
    val phone: String? = null
)

data class Employee(
    val id: String,
    val employeeCode: String, // e.g. PFS-0001
    val employeeName: String,
    val photo: String? = null,
    val aadhaarNumber: String? = null,
    val panNumber: String? = null,
    val phone: String,
    val alternatePhone: String? = null,
    val email: String,
    val designation: String,
    val department: String,
    val joiningDate: String,
    val bloodGroup: String? = null,
    val dateOfBirth: String? = null,
    val address: String? = null,
    val emergencyContactName: String? = null,
    val emergencyContactPhone: String? = null,
    val status: String = "Active",
    val createdAt: String
)

data class Client(
    val id: String,
    val companyName: String,
    val contactPerson: String,
    val email: String,
    val phone: String,
    val username: String,
    val password: String = "password123",
    val status: String = "Active",
    val address: String,
    val city: String,
    val gstin: String,
    val industry: String,
    val zohoContactId: String? = null,
    val zohoData: Map<String, String> = emptyMap(),
    val createdAt: String,
    val notes: String? = null
)

data class ProjectMilestone(
    val id: String,
    val title: String,
    val description: String,
    val completed: Boolean,
    val dueDate: String,
    val completedDate: String? = null
)

data class Project(
    val id: String,
    val reference: String, // e.g. PHX-2026-081
    val name: String,
    val clientId: String,
    val clientCompanyName: String,
    val description: String,
    val category: ProjectCategory,
    val startDate: String,
    val expectedCompletionDate: String,
    val assignedEmployeeIds: List<String> = emptyList(),
    val priority: ProjectPriority,
    val status: ProjectStatus,
    val progressPercentage: Int,
    val isManualProgress: Boolean = false,
    val contractValueINR: Long,
    val siteLocation: String,
    val milestones: List<ProjectMilestone> = emptyList(),
    val createdAt: String
)

data class Task(
    val id: String,
    val projectId: String,
    val projectReference: String,
    val title: String,
    val description: String,
    val assignedToEmployeeId: String,
    val assignedToName: String,
    val assignedToCode: String? = null,
    val deadline: String,
    val priority: ProjectPriority,
    val status: TaskStatus,
    val remarks: String = "",
    val visibleToClient: Boolean = true,
    val completedAt: String? = null,
    val createdAt: String
)

data class ProgressUpdate(
    val id: String,
    val projectId: String,
    val submittedByUserId: String,
    val submittedByName: String,
    val userRole: UserRole,
    val timestamp: String,
    val percentageReported: Int,
    val notes: String,
    val attachmentName: String? = null,
    val clientVisible: Boolean = true
)

data class ConversationMessage(
    val id: String,
    val projectId: String,
    val senderId: String,
    val senderName: String,
    val senderType: String, // "office" or "client"
    val senderRole: UserRole,
    val timestamp: String,
    val type: String, // "text" or "voice"
    val content: String = "",
    val audioDurationSeconds: Int = 0,
    val isRead: Boolean = true,
    val status: String = "Read"
)

data class ProjectDocument(
    val id: String,
    val projectId: String,
    val projectReference: String,
    val title: String,
    val filename: String,
    val fileType: String, // "pdf", "dwg", "image", "doc"
    val fileSize: String,
    val category: DocumentCategory,
    val uploadDate: String,
    val uploadedBy: String,
    val uploadedByRole: UserRole,
    val accessLevel: String, // "Client Shared" or "Internal Only"
    val previewText: String? = null
)

data class AppNotification(
    val id: String,
    val title: String,
    val message: String,
    val type: String, // "task", "project", "message", "voice", "document"
    val targetRole: String? = null,
    val targetUserId: String? = null,
    val projectId: String? = null,
    val taskId: String? = null,
    val read: Boolean = false,
    val timestamp: String
)

data class ActivityLog(
    val id: String,
    val projectId: String,
    val projectReference: String,
    val action: String,
    val details: String,
    val performedBy: String,
    val role: UserRole,
    val timestamp: String
)

data class PluginSettings(
    val zohoUrl: String = "https://www.zoho.com/crm/",
    val companyName: String = "Phoenix Fire Safety Equipments Pvt. Ltd.",
    val location: String = "Chennai, Tamil Nadu, India",
    val complianceStandard: String = "IS 3844 / NBC 2016 Compliant",
    val emailNotifications: Boolean = true,
    val smsAlerts: Boolean = true
)
