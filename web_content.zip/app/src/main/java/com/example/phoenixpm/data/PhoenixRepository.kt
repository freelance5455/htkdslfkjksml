package com.example.phoenixpm.data

import com.example.phoenixpm.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

class PhoenixRepository {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val dateTimeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())

    private fun getCurrentDate(): String = dateFormat.format(Date())
    private fun getCurrentDateTime(): String = dateTimeFormat.format(Date())

    // Initial Users
    private val initialUsers = listOf(
        User(
            id = "user-admin-1",
            name = "Rajesh Kumar",
            email = "rajesh.kumar@phoenixfiresafety.in",
            role = UserRole.Admin,
            designation = "Managing Director & Chief Safety Auditor",
            phone = "+91 98401 22841"
        ),
        User(
            id = "user-emp-1",
            name = "Senthil Nathan",
            email = "senthil.n@phoenixfiresafety.in",
            role = UserRole.Employee,
            designation = "Senior Project Engineer (Fire Protection)",
            employeeId = "emp-1",
            phone = "+91 94443 81920"
        ),
        User(
            id = "user-emp-2",
            name = "Priya Balan",
            email = "priya.b@phoenixfiresafety.in",
            role = UserRole.Employee,
            designation = "Lead MEP & Fire CAD Designer",
            employeeId = "emp-2",
            phone = "+91 98842 19283"
        ),
        User(
            id = "user-emp-3",
            name = "Murugan K.",
            email = "murugan.k@phoenixfiresafety.in",
            role = UserRole.Employee,
            designation = "Site Commissioning Supervisor",
            employeeId = "emp-3",
            phone = "+91 97909 33211"
        ),
        User(
            id = "user-client-1",
            name = "R. Sundararajan",
            email = "sundararajan.r@apollohospitals.com",
            role = UserRole.Client,
            designation = "Chief Facilities & Biomedical Officer",
            clientId = "client-apollo",
            phone = "+91 98410 77123"
        ),
        User(
            id = "user-client-2",
            name = "Ananya Roy",
            email = "ananya.roy@hyundai-india.com",
            role = UserRole.Client,
            designation = "EHS & Plant Safety Head",
            clientId = "client-hyundai",
            phone = "+91 99620 54321"
        ),
        User(
            id = "user-client-3",
            name = "Karthik V.",
            email = "karthik.v@olympiagroup.in",
            role = UserRole.Client,
            designation = "Infrastructure Director",
            clientId = "client-olympia",
            phone = "+91 98408 90112"
        )
    )

    // Initial Employees
    private val initialEmployees = listOf(
        Employee(
            id = "emp-1",
            employeeCode = "PFS-0001",
            employeeName = "Senthil Nathan",
            aadhaarNumber = "7829-4102-9912",
            panNumber = "ABCPS4102K",
            phone = "+91 94443 81920",
            alternatePhone = "+91 94440 12399",
            email = "senthil.n@phoenixfiresafety.in",
            designation = "Senior Project Engineer (Fire Protection)",
            department = "Fire Protection Engineering",
            joiningDate = "2022-03-15",
            bloodGroup = "O+",
            dateOfBirth = "1988-06-22",
            address = "No. 14, 2nd Main Road, Anna Nagar West, Chennai, Tamil Nadu 600040",
            emergencyContactName = "Meenakshi Nathan (Spouse)",
            emergencyContactPhone = "+91 94442 88102",
            status = "Active",
            createdAt = "2022-03-15"
        ),
        Employee(
            id = "emp-2",
            employeeCode = "PFS-0002",
            employeeName = "Priya Balan",
            aadhaarNumber = "6610-8819-2391",
            panNumber = "BKPBL2391M",
            phone = "+91 98842 19283",
            alternatePhone = "+91 98840 99110",
            email = "priya.b@phoenixfiresafety.in",
            designation = "Lead MEP & Fire CAD Designer",
            department = "Design & Drafting",
            joiningDate = "2023-01-10",
            bloodGroup = "B+",
            dateOfBirth = "1992-11-14",
            address = "Flat 3B, Shanthi Apartments, T. Nagar, Chennai, Tamil Nadu 600017",
            emergencyContactName = "R. Balan (Father)",
            emergencyContactPhone = "+91 98841 00291",
            status = "Active",
            createdAt = "2023-01-10"
        ),
        Employee(
            id = "emp-3",
            employeeCode = "PFS-0003",
            employeeName = "Murugan K.",
            aadhaarNumber = "9102-3341-8820",
            panNumber = "CPMKR8820F",
            phone = "+91 97909 33211",
            alternatePhone = "+91 97900 44100",
            email = "murugan.k@phoenixfiresafety.in",
            designation = "Site Commissioning Supervisor",
            department = "Field Installation & Testing",
            joiningDate = "2021-08-01",
            bloodGroup = "A+",
            dateOfBirth = "1985-04-18",
            address = "Plot 42, SIDCO Nagar, Villivakkam, Chennai, Tamil Nadu 600049",
            emergencyContactName = "Lakshmi Murugan (Spouse)",
            emergencyContactPhone = "+91 97908 11922",
            status = "Active",
            createdAt = "2021-08-01"
        ),
        Employee(
            id = "emp-4",
            employeeCode = "PFS-0004",
            employeeName = "Kavitha Sundaram",
            aadhaarNumber = "4491-0283-7719",
            panNumber = "DFPKS7719Q",
            phone = "+91 98409 66120",
            alternatePhone = "+91 98400 33819",
            email = "kavitha.s@phoenixfiresafety.in",
            designation = "Compliance & Audit Manager",
            department = "Statutory TNFRS Approvals",
            joiningDate = "2023-06-01",
            bloodGroup = "AB+",
            dateOfBirth = "1990-09-05",
            address = "No. 8, Gandhi Road, Alwarpet, Chennai, Tamil Nadu 600018",
            emergencyContactName = "K. Sundaram (Spouse)",
            emergencyContactPhone = "+91 98408 22109",
            status = "Active",
            createdAt = "2023-06-01"
        )
    )

    // Initial Clients
    private val initialClients = listOf(
        Client(
            id = "client-apollo",
            companyName = "Apollo Hospitals Enterprise Ltd.",
            contactPerson = "R. Sundararajan",
            email = "sundararajan.r@apollohospitals.com",
            phone = "+91 98410 77123",
            username = "sundararajan.r",
            address = "No. 21, Greams Lane, Off Greams Road, Thousand Lights",
            city = "Chennai, Tamil Nadu 600006",
            gstin = "33AABCA1294F1Z8",
            industry = "Healthcare & Multispeciality Hospitals",
            zohoContactId = "ZC-8819234",
            zohoData = mapOf("Payment Terms" to "Due on Receipt", "Currency" to "INR"),
            createdAt = "2025-04-12",
            notes = "Key hospital campus requiring zero downtime during alarm panel switchover."
        ),
        Client(
            id = "client-hyundai",
            companyName = "Hyundai Motor India Ltd.",
            contactPerson = "Ananya Roy",
            email = "ananya.roy@hyundai-india.com",
            phone = "+91 99620 54321",
            username = "ananya.roy",
            address = "Plot No. H-1, SIPCOT Industrial Park, Irungattukottai",
            city = "Sriperumbudur, Tamil Nadu 602117",
            gstin = "33AAACH2391Q1ZP",
            industry = "Automobile Manufacturing & Assembly",
            zohoContactId = "ZC-9120441",
            zohoData = mapOf("Payment Terms" to "Net 30", "Currency" to "INR"),
            createdAt = "2025-06-18",
            notes = "Industrial paint shop and battery storage protection standards required."
        ),
        Client(
            id = "client-olympia",
            companyName = "Olympia Tech Park (Guindy)",
            contactPerson = "Karthik V.",
            email = "karthik.v@olympiagroup.in",
            phone = "+91 98408 90112",
            username = "karthik.v",
            address = "SIDCO Industrial Estate, Guindy",
            city = "Chennai, Tamil Nadu 600032",
            gstin = "33AAAFO9182L1ZX",
            industry = "Commercial IT Park & Data Centers",
            zohoContactId = "ZC-7731802",
            createdAt = "2025-08-04",
            notes = "Novec 1230 gas suppression for Tier-3 data center floors."
        ),
        Client(
            id = "client-express",
            companyName = "Express Avenue Commercial Complex",
            contactPerson = "Deepak Mehrotra",
            email = "deepak.m@expressavenue.in",
            phone = "+91 98402 11990",
            username = "deepak.m",
            address = "Club House Road, Royapettah",
            city = "Chennai, Tamil Nadu 600002",
            gstin = "33AACCE4482B1ZM",
            industry = "Retail Mall & Multiplex",
            zohoContactId = "ZC-6019488",
            createdAt = "2025-09-15",
            notes = "Annual AMC and Form B NOC renewal with Chennai Regional Fire Office."
        ),
        Client(
            id = "client-mmm",
            companyName = "Madras Medical Mission (MMM Hospital)",
            contactPerson = "Dr. Joseph Thomas",
            email = "facilities@mmmhospital.org",
            phone = "+91 94441 55678",
            username = "facilities.mmm",
            address = "4-A, Dr J.J. Nagar, Mogappair",
            city = "Chennai, Tamil Nadu 600037",
            gstin = "33AAATM5591C1ZT",
            industry = "Cardiac & Speciality Hospital",
            zohoContactId = "ZC-5519201",
            createdAt = "2025-11-20",
            notes = "ICU and Cath Lab pre-action sprinkler systems."
        )
    )

    // Initial Projects
    private val initialProjects = listOf(
        Project(
            id = "proj-1",
            reference = "PHX-2026-081",
            name = "Emergency Fire Alarm & Voice Evacuation System Upgrade",
            clientId = "client-apollo",
            clientCompanyName = "Apollo Hospitals Enterprise Ltd.",
            description = "Complete replacement of legacy smoke detectors with addressable optical sensors, dual optical/heat multisensors in critical care units, and multi-zone voice evacuation panels connected to Tamil Nadu Fire Services repeater.",
            category = ProjectCategory.FIRE_ALARM,
            startDate = "2026-01-10",
            expectedCompletionDate = "2026-11-25",
            assignedEmployeeIds = listOf("emp-1", "emp-2"),
            priority = ProjectPriority.Critical,
            status = ProjectStatus.IN_PROGRESS,
            progressPercentage = 75,
            isManualProgress = false,
            contractValueINR = 2450000L,
            siteLocation = "Main Hospital Block, Greams Road, Chennai",
            createdAt = "2026-01-05",
            milestones = listOf(
                ProjectMilestone("m1-1", "Site Inspection & CAD Rerouting Drawing", "Survey of 8 floors and cable duct pathways", true, "2026-01-28", "2026-01-25"),
                ProjectMilestone("m1-2", "Material Dispatch & Sensor Delivery", "340 addressable smoke detectors & sounders", true, "2026-02-20", "2026-02-18"),
                ProjectMilestone("m1-3", "Zone 1-4 Cable Conduit & Erection", "OPD, ICU, and surgical wards cabling", true, "2026-05-15", "2026-05-12"),
                ProjectMilestone("m1-4", "Main Control Panel Integration & Testing", "Central command console in Security BMS room", false, "2026-10-30"),
                ProjectMilestone("m1-5", "TNFRS Final Inspection & Handover", "Statutory compliance demonstration with Fire Officer", false, "2026-11-25")
            )
        ),
        Project(
            id = "proj-2",
            reference = "PHX-2026-089",
            name = "High-Pressure Sprinkler & Hydrant Network Expansion",
            clientId = "client-hyundai",
            clientCompanyName = "Hyundai Motor India Ltd.",
            description = "Turnkey hydraulic calculation, ring main piping (150mm MS class C), deluge sprinkler installation in assembly bay 4, and high-velocity water spray system for transformer yard.",
            category = ProjectCategory.HYDRANT_SPRINKLER,
            startDate = "2026-02-01",
            expectedCompletionDate = "2026-12-15",
            assignedEmployeeIds = listOf("emp-1", "emp-3"),
            priority = ProjectPriority.High,
            status = ProjectStatus.IN_PROGRESS,
            progressPercentage = 45,
            isManualProgress = false,
            contractValueINR = 5800000L,
            siteLocation = "Assembly Plant Unit 2, Irungattukottai, Sriperumbudur",
            createdAt = "2026-01-20",
            milestones = listOf(
                ProjectMilestone("m2-1", "Hydraulic Calculations & NFPA 13 Review", "Design signoff with Hyundai Korean Engineering Team", true, "2026-02-28", "2026-02-27"),
                ProjectMilestone("m2-2", "Main Yard Ring Pipeline Laying", "Trenching, pipe wrapping, and underground laying", true, "2026-06-15", "2026-06-10"),
                ProjectMilestone("m2-3", "Deluge Valve & Overhead Sprinkler Droppers", "Fitting 850 quick-response pendant sprinklers", false, "2026-11-10"),
                ProjectMilestone("m2-4", "Hydrostatic Pressure Test (14 Bar)", "4-hour hold test with independent auditor", false, "2026-11-30"),
                ProjectMilestone("m2-5", "Commissioning & Safety Cert handover", "Final commissioning and pump house automation", false, "2026-12-15")
            )
        ),
        Project(
            id = "proj-3",
            reference = "PHX-2026-077",
            name = "Clean Agent Novec 1230 Server Room Suppression",
            clientId = "client-olympia",
            clientCompanyName = "Olympia Tech Park (Guindy)",
            description = "Design and installation of total flooding Novec 1230 gas cylinder bank, cross-zoned VESDA (Very Early Smoke Detection Apparatus) aspirating sensors, and abort switches for main data hall.",
            category = ProjectCategory.CO2_CLEAN_AGENT,
            startDate = "2026-09-01",
            expectedCompletionDate = "2026-12-30",
            assignedEmployeeIds = listOf("emp-2", "emp-3"),
            priority = ProjectPriority.Medium,
            status = ProjectStatus.PENDING,
            progressPercentage = 15,
            isManualProgress = false,
            contractValueINR = 1950000L,
            siteLocation = "C-Wing 4th Floor Data Hall, Guindy, Chennai",
            createdAt = "2026-08-25",
            milestones = listOf(
                ProjectMilestone("m3-1", "Room Integrity Test & Volumetric Measure", "Fan pressurization testing for room air tightness", true, "2026-09-20", "2026-09-18"),
                ProjectMilestone("m3-2", "Gas Cylinder Manifold Fabrication", "High-strength steel manifold rack and discharge piping", false, "2026-11-05"),
                ProjectMilestone("m3-3", "VESDA Laser Pipe Network Installation", "Aspirating capillary tubes above server racks", false, "2026-11-28"),
                ProjectMilestone("m3-4", "Electrical Actuator & Abort Switch Wiring", "Failsafe interlock with HVAC dampers", false, "2026-12-20")
            )
        ),
        Project(
            id = "proj-4",
            reference = "PHX-2026-064",
            name = "Mall Fire Extinguisher AMC & Form B Compliance Renewal",
            clientId = "client-express",
            clientCompanyName = "Express Avenue Commercial Complex",
            description = "Annual inspection and hydrostatic pressure testing of 420 portable fire extinguishers (ABC Dry Powder, CO2 4.5kg, Mechanical Foam), replacement of discharge hoses, and TNFRS compliance renewal.",
            category = ProjectCategory.EXTINGUISHER_AMC,
            startDate = "2026-01-02",
            expectedCompletionDate = "2026-03-30",
            assignedEmployeeIds = listOf("emp-1"),
            priority = ProjectPriority.High,
            status = ProjectStatus.OVERDUE,
            progressPercentage = 80,
            isManualProgress = false,
            contractValueINR = 480000L,
            siteLocation = "Royapettah, Chennai",
            createdAt = "2025-12-28",
            milestones = listOf(
                ProjectMilestone("m4-1", "Floor-by-Floor Extinguisher Audit", "Tagging and QR barcode logging of 420 units", true, "2026-01-20", "2026-01-19"),
                ProjectMilestone("m4-2", "Refilling & Cartridge Hydro Testing", "Batch refilling at Phoenix Ambattur factory", true, "2026-02-15", "2026-02-14"),
                ProjectMilestone("m4-3", "Multiplex Zone Form B Application", "Joint submission to Central Chennai Fire Division", false, "2026-03-15"),
                ProjectMilestone("m4-4", "Final Inspection & Certificate Dispatch", "Pending receipt of signed Form B clearance certificate", false, "2026-03-30")
            )
        ),
        Project(
            id = "proj-5",
            reference = "PHX-2026-052",
            name = "Cardiac Care Block Wet Riser & Yard Hydrant Commissioning",
            clientId = "client-mmm",
            clientCompanyName = "Madras Medical Mission (MMM Hospital)",
            description = "Comprehensive installation of double-headed landing valves, 1000 LPM diesel standby fire pump integration, hose reel drums, and water flow test according to IS 3844.",
            category = ProjectCategory.HYDRANT_SPRINKLER,
            startDate = "2025-11-01",
            expectedCompletionDate = "2026-02-28",
            assignedEmployeeIds = listOf("emp-1", "emp-2", "emp-3"),
            priority = ProjectPriority.Medium,
            status = ProjectStatus.COMPLETED,
            progressPercentage = 100,
            isManualProgress = false,
            contractValueINR = 3200000L,
            siteLocation = "Mogappair Campus, Chennai",
            createdAt = "2025-10-25",
            milestones = listOf(
                ProjectMilestone("m5-1", "Underground Pump House Installation", "Main electric, jockey, and diesel backup pump set", true, "2025-12-10", "2025-12-08"),
                ProjectMilestone("m5-2", "Wet Riser Pipe Erection (Floors 1-6)", "Heavy duty C-class galvanized risers and valves", true, "2026-01-15", "2026-01-14"),
                ProjectMilestone("m5-3", "Full Flow Pressure Test at Roof Hydrant", "Achieved 4.5 kg/cm2 at top terrace outlet", true, "2026-02-10", "2026-02-09"),
                ProjectMilestone("m5-4", "Staff Fire Drill & Handover Training", "Hospital engineering & security staff mock drill", true, "2026-02-25", "2026-02-24")
            )
        )
    )

    // Initial Tasks
    private val initialTasks = listOf(
        Task(
            id = "task-101",
            projectId = "proj-1",
            projectReference = "PHX-2026-081",
            title = "Install Addressable Optical Detectors in ICU Wing 3",
            description = "Mount 48 dual optical-heat detectors and verify address DIP switch mapping against Phoenix drawing PHX-DWG-APL-03.",
            assignedToEmployeeId = "emp-1",
            assignedToName = "Senthil Nathan",
            assignedToCode = "PFS-0001",
            deadline = "2026-10-20",
            priority = ProjectPriority.Critical,
            status = TaskStatus.IN_PROGRESS,
            remarks = "ICU coordinator granted night window 10 PM - 5 AM for quiet installation.",
            visibleToClient = true,
            createdAt = "2026-10-01"
        ),
        Task(
            id = "task-102",
            projectId = "proj-1",
            projectReference = "PHX-2026-081",
            title = "Update Master As-Built CAD Layout with Sounder Locations",
            description = "Mark all 32 strobe-cum-sounder wall positions and cable loops on the architectural layout for client signoff.",
            assignedToEmployeeId = "emp-2",
            assignedToName = "Priya Balan",
            assignedToCode = "PFS-0002",
            deadline = "2026-10-18",
            priority = ProjectPriority.High,
            status = TaskStatus.COMPLETED,
            remarks = "CAD revision 4 completed and shared with Apollo facilities desk.",
            visibleToClient = true,
            completedAt = "2026-10-12",
            createdAt = "2026-10-02"
        ),
        Task(
            id = "task-103",
            projectId = "proj-1",
            projectReference = "PHX-2026-081",
            title = "BMS Interlock Relay Testing in Main Security Console",
            description = "Ensure alarm panel trigger opens stairwell magnetic fire doors and shuts down HVAC AHUs.",
            assignedToEmployeeId = "emp-1",
            assignedToName = "Senthil Nathan",
            assignedToCode = "PFS-0001",
            deadline = "2026-10-28",
            priority = ProjectPriority.High,
            status = TaskStatus.PENDING,
            remarks = "Awaiting BMS engineer presence from Johnson Controls.",
            visibleToClient = false,
            createdAt = "2026-10-05"
        ),
        Task(
            id = "task-104",
            projectId = "proj-2",
            projectReference = "PHX-2026-089",
            title = "Fabricate 150mm Header Flange for Deluge Valve Station 2",
            description = "Weld class C carbon steel flange, perform ultrasonic weld flaw test before shipping to Hyundai site.",
            assignedToEmployeeId = "emp-3",
            assignedToName = "Murugan K.",
            assignedToCode = "PFS-0003",
            deadline = "2026-10-22",
            priority = ProjectPriority.High,
            status = TaskStatus.IN_PROGRESS,
            remarks = "Hydro-weld testing at Ambattur fabrication workshop underway.",
            visibleToClient = true,
            createdAt = "2026-10-03"
        ),
        Task(
            id = "task-105",
            projectId = "proj-2",
            projectReference = "PHX-2026-089",
            title = "Delivery of 850 UL-Listed Pendant Sprinkler Heads",
            description = "Verify 68°C red bulb rating, CE and UL markings with shipping manifest.",
            assignedToEmployeeId = "emp-1",
            assignedToName = "Senthil Nathan",
            assignedToCode = "PFS-0001",
            deadline = "2026-10-25",
            priority = ProjectPriority.Medium,
            status = TaskStatus.PENDING,
            remarks = "Consignment arrived at Chennai port warehouse.",
            visibleToClient = true,
            createdAt = "2026-10-04"
        ),
        Task(
            id = "task-106",
            projectId = "proj-4",
            projectReference = "PHX-2026-064",
            title = "Resubmit Form B Clarification Letter to Chennai Fire Officer",
            description = "Submit revised fire exit corridor width calculation requested by District Fire Officer, Central Chennai.",
            assignedToEmployeeId = "emp-1",
            assignedToName = "Senthil Nathan",
            assignedToCode = "PFS-0001",
            deadline = "2026-03-25",
            priority = ProjectPriority.Critical,
            status = TaskStatus.OVERDUE,
            remarks = "Awaiting updated architect plan from Express Avenue mall management.",
            visibleToClient = true,
            createdAt = "2026-03-10"
        ),
        Task(
            id = "task-107",
            projectId = "proj-3",
            projectReference = "PHX-2026-077",
            title = "Server Room Air Tightness Room Integrity Test",
            description = "Run door fan pressurization test to verify 10-minute gas retention concentration per NFPA 2001.",
            assignedToEmployeeId = "emp-3",
            assignedToName = "Murugan K.",
            assignedToCode = "PFS-0003",
            deadline = "2026-09-18",
            priority = ProjectPriority.Medium,
            status = TaskStatus.COMPLETED,
            remarks = "Retention time measured at 11.4 minutes, meeting NFPA requirements.",
            visibleToClient = true,
            completedAt = "2026-09-18",
            createdAt = "2026-09-02"
        )
    )

    // Initial Progress Updates
    private val initialProgressUpdates = listOf(
        ProgressUpdate(
            id = "upd-1",
            projectId = "proj-1",
            submittedByUserId = "emp-1",
            submittedByName = "Senthil Nathan",
            userRole = UserRole.Employee,
            timestamp = "2026-10-12 16:30",
            percentageReported = 75,
            notes = "Completed loop wiring for 4th and 5th floors. Loop resistance measured at 14.2 ohms, well within 25 ohm ceiling. Commencing smoke sensor clipping tonight in ICU corridor.",
            attachmentName = "Apollo_Loop_Resistance_Log_Oct12.pdf",
            clientVisible = true
        ),
        ProgressUpdate(
            id = "upd-2",
            projectId = "proj-1",
            submittedByUserId = "emp-2",
            submittedByName = "Priya Balan",
            userRole = UserRole.Employee,
            timestamp = "2026-10-08 11:15",
            percentageReported = 70,
            notes = "Uploaded revision 4 of the architectural CAD overlay highlighting the relocation of the secondary repeater panel to the nursing station as requested by Dr. Sundararajan.",
            attachmentName = "PHX_APL_Nursing_Station_Repeater_Rev4.dwg",
            clientVisible = true
        ),
        ProgressUpdate(
            id = "upd-3",
            projectId = "proj-2",
            submittedByUserId = "emp-3",
            submittedByName = "Murugan K.",
            userRole = UserRole.Employee,
            timestamp = "2026-10-10 14:00",
            percentageReported = 45,
            notes = "Underground yard hydrant pipeline trenching finished. Concrete thrust blocks cast at all 90-degree elbows. Ready for pre-pressure leak check.",
            attachmentName = "Hyundai_Trench_ThrustBlock_Photos.zip",
            clientVisible = true
        )
    )

    // Initial Messages
    private val initialMessages = listOf(
        ConversationMessage(
            id = "msg-1",
            projectId = "proj-1",
            senderId = "client-apollo",
            senderName = "R. Sundararajan",
            senderType = "client",
            senderRole = UserRole.Client,
            timestamp = "2026-10-11 09:40",
            type = "text",
            content = "Good morning Senthil. Please confirm that the night shift team will not generate any loud drilling noise near the Cardiac ICU between 1 AM and 4 AM.",
            isRead = true,
            status = "Read"
        ),
        ConversationMessage(
            id = "msg-2",
            projectId = "proj-1",
            senderId = "emp-1",
            senderName = "Senthil Nathan (Phoenix Fire Safety)",
            senderType = "office",
            senderRole = UserRole.Employee,
            timestamp = "2026-10-11 10:05",
            type = "voice",
            content = "[Voice Note - 0:06] 'Good morning Sir. Yes, all heavy anchor drilling for cable trays will be finished strictly by 11:30 PM. From midnight onwards we will only be doing quiet optical sensor snapping and wire loop crimping.'",
            audioDurationSeconds = 6,
            isRead = true,
            status = "Read"
        ),
        ConversationMessage(
            id = "msg-3",
            projectId = "proj-1",
            senderId = "client-apollo",
            senderName = "R. Sundararajan",
            senderType = "client",
            senderRole = UserRole.Client,
            timestamp = "2026-10-11 10:20",
            type = "voice",
            content = "[Voice Note - 0:08] 'Understood and appreciated Senthil. Also, our medical director requested an extra manual call point right near the dialysis suite exit. Can you verify if that loop has spare capacity?'",
            audioDurationSeconds = 8,
            isRead = true,
            status = "Read"
        ),
        ConversationMessage(
            id = "msg-4",
            projectId = "proj-1",
            senderId = "user-admin-1",
            senderName = "Rajesh Kumar (Managing Director)",
            senderType = "office",
            senderRole = UserRole.Admin,
            timestamp = "2026-10-11 11:00",
            type = "text",
            content = "Hello Dr. Sundararajan. Loop 3 has 84 available addresses out of 127. We will instruct Priya to add the MCP at the dialysis exit on the as-built schematic immediately without delay.",
            isRead = true,
            status = "Read"
        ),
        ConversationMessage(
            id = "msg-5",
            projectId = "proj-2",
            senderId = "emp-3",
            senderName = "Murugan K. (Site Supervisor)",
            senderType = "office",
            senderRole = UserRole.Employee,
            timestamp = "2026-10-10 16:30",
            type = "voice",
            content = "[Voice Note - 0:05] 'Trenching inspection completed at Hyundai Bay 4. All concrete thrust blocks cured. Ready for hydrostatic test.'",
            audioDurationSeconds = 5,
            isRead = true,
            status = "Read"
        )
    )

    // Initial Documents
    private val initialDocuments = listOf(
        ProjectDocument(
            id = "doc-1",
            projectId = "proj-1",
            projectReference = "PHX-2026-081",
            title = "Apollo Main Hospital CAD Floor Layout Rev 4",
            filename = "PHX_DWG_APL_Hospital_Rev4.dwg",
            fileType = "dwg",
            fileSize = "14.8 MB",
            category = DocumentCategory.CAD_DRAWING,
            uploadDate = "2026-10-08",
            uploadedBy = "Priya Balan",
            uploadedByRole = UserRole.Employee,
            accessLevel = "Client Shared",
            previewText = "Architectural CAD blueprint with overlay showing 340 addressable smoke detectors, 32 wall sounders, and dual optical-heat detectors across floors 1-8."
        ),
        ProjectDocument(
            id = "doc-2",
            projectId = "proj-1",
            projectReference = "PHX-2026-081",
            title = "Apollo Loop Resistance & Continuity Test Report",
            filename = "Apollo_Loop_Resistance_Log_Oct12.pdf",
            fileType = "pdf",
            fileSize = "2.1 MB",
            category = DocumentCategory.INSPECTION_REPORT,
            uploadDate = "2026-10-12",
            uploadedBy = "Senthil Nathan",
            uploadedByRole = UserRole.Employee,
            accessLevel = "Client Shared",
            previewText = "Testing certificate verifying Loop 1-4 continuity. Measured resistance 14.2 ohms (limit 25.0 ohms). Zero ground faults detected across ICU zones."
        ),
        ProjectDocument(
            id = "doc-3",
            projectId = "proj-1",
            projectReference = "PHX-2026-081",
            title = "Signed Purchase Order & Scope of Works",
            filename = "PO_Apollo_PHX_2026_081_Signed.pdf",
            fileType = "pdf",
            fileSize = "3.4 MB",
            category = DocumentCategory.PURCHASE_ORDER,
            uploadDate = "2026-01-08",
            uploadedBy = "Rajesh Kumar",
            uploadedByRole = UserRole.Admin,
            accessLevel = "Internal Only",
            previewText = "Commercial Purchase Order #APL-PO-2026-4410 valued at INR 24,50,000 for Addressable Fire Alarm and Voice Evacuation System turnkey modernization."
        ),
        ProjectDocument(
            id = "doc-4",
            projectId = "proj-2",
            projectReference = "PHX-2026-089",
            title = "NFPA 13 Hydraulic Calculation & Pressure Drop Analysis",
            filename = "Hyundai_Unit2_Sprinkler_Hydraulics_Rev2.pdf",
            fileType = "pdf",
            fileSize = "5.6 MB",
            category = DocumentCategory.DRAWING,
            uploadDate = "2026-02-25",
            uploadedBy = "Senthil Nathan",
            uploadedByRole = UserRole.Employee,
            accessLevel = "Client Shared",
            previewText = "Computerized hydraulic calculation per NFPA 13 density/area curve: 0.30 gpm/sq.ft over 3,000 sq.ft design area. Demands 1,280 GPM at 6.8 bar."
        ),
        ProjectDocument(
            id = "doc-5",
            projectId = "proj-3",
            projectReference = "PHX-2026-077",
            title = "Novec 1230 Server Room Integrity Test Certificate",
            filename = "Olympia_Room_Integrity_Cert_Sept2026.pdf",
            fileType = "pdf",
            fileSize = "1.8 MB",
            category = DocumentCategory.CERTIFICATE,
            uploadDate = "2026-09-18",
            uploadedBy = "Murugan K.",
            uploadedByRole = UserRole.Employee,
            accessLevel = "Client Shared",
            previewText = "Retrotec door fan test certificate. Enclosure volume 1,420 m3. Verified hold time 11.4 minutes against NFPA 2001 statutory requirement of 10.0 minutes."
        ),
        ProjectDocument(
            id = "doc-6",
            projectId = "proj-4",
            projectReference = "PHX-2026-064",
            title = "Form B NOC Renewal Application & Inspection Dossier",
            filename = "Form_B_NOC_Application_ExpressAvenue_2026.pdf",
            fileType = "pdf",
            fileSize = "4.2 MB",
            category = DocumentCategory.FORM_B_NOC,
            uploadDate = "2026-03-05",
            uploadedBy = "Kavitha Sundaram",
            uploadedByRole = UserRole.Employee,
            accessLevel = "Client Shared",
            previewText = "Statutory Form B renewal documentation submitted to Tamil Nadu Fire and Rescue Services (TNFRS), Central Division, Chennai."
        ),
        ProjectDocument(
            id = "doc-7",
            projectId = "proj-5",
            projectReference = "PHX-2026-052",
            title = "MMM Hospital Wet Riser Completion Certificate",
            filename = "MMM_WetRiser_Completion_Handover_Cert.pdf",
            fileType = "pdf",
            fileSize = "2.9 MB",
            category = DocumentCategory.COMPLETION_CERTIFICATE,
            uploadDate = "2026-02-28",
            uploadedBy = "Rajesh Kumar",
            uploadedByRole = UserRole.Admin,
            accessLevel = "Client Shared",
            previewText = "Handover certificate for 1000 LPM diesel standby pump set and 6-floor wet riser installation according to IS 3844."
        )
    )

    // Initial Notifications
    private val initialNotifications = listOf(
        AppNotification(
            id = "notif-1",
            title = "ICU Wing 3 Night Shift Alert",
            message = "Task PFS-0001: Addressable optical detector installation scheduled tonight 10 PM - 5 AM.",
            type = "task",
            projectId = "proj-1",
            taskId = "task-101",
            read = false,
            timestamp = "2026-10-20 09:00"
        ),
        AppNotification(
            id = "notif-2",
            title = "Form B Overdue Warning",
            message = "Project PHX-2026-064 (Express Avenue) requires signed Form B clearance certificate from Regional Fire Office.",
            type = "project",
            projectId = "proj-4",
            read = false,
            timestamp = "2026-10-19 14:15"
        ),
        AppNotification(
            id = "notif-3",
            title = "New Voice Message from Apollo Hospitals",
            message = "Dr. Sundararajan sent a voice note regarding dialysis suite MCP installation.",
            type = "voice",
            projectId = "proj-1",
            read = true,
            timestamp = "2026-10-11 10:20"
        )
    )

    // State Flows
    private val _users = MutableStateFlow(initialUsers)
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private val _currentUser = MutableStateFlow(initialUsers[0])
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    private val _employees = MutableStateFlow(initialEmployees)
    val employees: StateFlow<List<Employee>> = _employees.asStateFlow()

    private val _clients = MutableStateFlow(initialClients)
    val clients: StateFlow<List<Client>> = _clients.asStateFlow()

    private val _projects = MutableStateFlow(initialProjects)
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    private val _tasks = MutableStateFlow(initialTasks)
    val tasks: StateFlow<List<Task>> = _tasks.asStateFlow()

    private val _progressUpdates = MutableStateFlow(initialProgressUpdates)
    val progressUpdates: StateFlow<List<ProgressUpdate>> = _progressUpdates.asStateFlow()

    private val _messages = MutableStateFlow(initialMessages)
    val messages: StateFlow<List<ConversationMessage>> = _messages.asStateFlow()

    private val _documents = MutableStateFlow(initialDocuments)
    val documents: StateFlow<List<ProjectDocument>> = _documents.asStateFlow()

    private val _notifications = MutableStateFlow(initialNotifications)
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _settings = MutableStateFlow(PluginSettings())
    val settings: StateFlow<PluginSettings> = _settings.asStateFlow()

    fun switchUser(userId: String) {
        val user = _users.value.firstOrNull { it.id == userId }
        if (user != null) {
            _currentUser.value = user
        }
    }

    // Projects CRUD
    fun createProject(
        name: String,
        clientId: String,
        category: ProjectCategory,
        priority: ProjectPriority,
        startDate: String,
        expectedCompletionDate: String,
        contractValueINR: Long,
        siteLocation: String,
        description: String,
        assignedEmployeeIds: List<String>,
        initialMilestones: List<String>
    ): Project {
        val client = _clients.value.firstOrNull { it.id == clientId }
        val clientName = client?.companyName ?: "Corporate Client"
        val refNumber = (100..999).random()
        val reference = "PHX-2026-$refNumber"
        val projId = "proj-${UUID.randomUUID().toString().take(6)}"

        val milestonesList = initialMilestones.mapIndexed { idx, title ->
            ProjectMilestone(
                id = "m-${projId}-$idx",
                title = title,
                description = "Standard compliance milestone",
                completed = false,
                dueDate = expectedCompletionDate
            )
        }

        val newProject = Project(
            id = projId,
            reference = reference,
            name = name,
            clientId = clientId,
            clientCompanyName = clientName,
            description = description,
            category = category,
            startDate = startDate,
            expectedCompletionDate = expectedCompletionDate,
            assignedEmployeeIds = assignedEmployeeIds,
            priority = priority,
            status = ProjectStatus.PENDING,
            progressPercentage = 0,
            isManualProgress = false,
            contractValueINR = contractValueINR,
            siteLocation = siteLocation,
            milestones = milestonesList,
            createdAt = getCurrentDate()
        )

        _projects.value = listOf(newProject) + _projects.value
        return newProject
    }

    fun updateProject(id: String, updated: Project) {
        _projects.value = _projects.value.map { if (it.id == id) updated else it }
    }

    fun deleteProject(id: String) {
        _projects.value = _projects.value.filter { it.id != id }
        _tasks.value = _tasks.value.filter { it.projectId != id }
        _documents.value = _documents.value.filter { it.projectId != id }
    }

    fun toggleMilestone(projectId: String, milestoneId: String) {
        _projects.value = _projects.value.map { proj ->
            if (proj.id == projectId) {
                val updatedMilestones = proj.milestones.map { m ->
                    if (m.id == milestoneId) {
                        m.copy(
                            completed = !m.completed,
                            completedDate = if (!m.completed) getCurrentDate() else null
                        )
                    } else m
                }

                val newPercentage = if (!proj.isManualProgress && updatedMilestones.isNotEmpty()) {
                    val completedCount = updatedMilestones.count { it.completed }
                    (completedCount * 100) / updatedMilestones.size
                } else proj.progressPercentage

                val newStatus = when {
                    newPercentage >= 100 -> ProjectStatus.COMPLETED
                    newPercentage > 0 -> ProjectStatus.IN_PROGRESS
                    else -> proj.status
                }

                proj.copy(
                    milestones = updatedMilestones,
                    progressPercentage = newPercentage,
                    status = newStatus
                )
            } else proj
        }
    }

    fun updateProjectProgress(projectId: String, progress: Int, isManual: Boolean) {
        _projects.value = _projects.value.map { proj ->
            if (proj.id == projectId) {
                val clamped = progress.coerceIn(0, 100)
                val status = when {
                    clamped >= 100 -> ProjectStatus.COMPLETED
                    clamped > 0 -> ProjectStatus.IN_PROGRESS
                    else -> proj.status
                }
                proj.copy(
                    progressPercentage = clamped,
                    isManualProgress = isManual,
                    status = status
                )
            } else proj
        }
    }

    // Tasks CRUD
    fun createTask(
        projectId: String,
        title: String,
        description: String,
        assignedToEmployeeId: String,
        deadline: String,
        priority: ProjectPriority,
        visibleToClient: Boolean,
        remarks: String
    ): Task {
        val proj = _projects.value.firstOrNull { it.id == projectId }
        val emp = _employees.value.firstOrNull { it.id == assignedToEmployeeId }
        val taskId = "task-${(110..999).random()}"

        val newTask = Task(
            id = taskId,
            projectId = projectId,
            projectReference = proj?.reference ?: "PHX-2026",
            title = title,
            description = description,
            assignedToEmployeeId = assignedToEmployeeId,
            assignedToName = emp?.employeeName ?: "Assigned Engineer",
            assignedToCode = emp?.employeeCode ?: "PFS-0000",
            deadline = deadline,
            priority = priority,
            status = TaskStatus.PENDING,
            remarks = remarks,
            visibleToClient = visibleToClient,
            createdAt = getCurrentDate()
        )

        _tasks.value = listOf(newTask) + _tasks.value
        return newTask
    }

    fun updateTask(id: String, updated: Task) {
        _tasks.value = _tasks.value.map { if (it.id == id) updated else it }
    }

    fun updateTaskStatus(id: String, status: TaskStatus) {
        _tasks.value = _tasks.value.map { task ->
            if (task.id == id) {
                task.copy(
                    status = status,
                    completedAt = if (status == TaskStatus.COMPLETED) getCurrentDate() else null
                )
            } else task
        }
    }

    fun deleteTask(id: String) {
        _tasks.value = _tasks.value.filter { it.id != id }
    }

    // Progress Reports
    fun submitProgressUpdate(
        projectId: String,
        percentageReported: Int,
        notes: String,
        attachmentName: String?,
        clientVisible: Boolean
    ) {
        val user = _currentUser.value
        val updateId = "upd-${UUID.randomUUID().toString().take(6)}"

        val update = ProgressUpdate(
            id = updateId,
            projectId = projectId,
            submittedByUserId = user.id,
            submittedByName = user.name,
            userRole = user.role,
            timestamp = getCurrentDateTime(),
            percentageReported = percentageReported,
            notes = notes,
            attachmentName = attachmentName,
            clientVisible = clientVisible
        )

        _progressUpdates.value = listOf(update) + _progressUpdates.value
        updateProjectProgress(projectId, percentageReported, isManual = true)
    }

    // Conversations & Voice Messaging
    fun sendMessage(
        projectId: String,
        content: String,
        type: String = "text",
        audioDurationSeconds: Int = 0
    ) {
        val user = _currentUser.value
        val senderType = if (user.role == UserRole.Client) "client" else "office"
        val msgId = "msg-${UUID.randomUUID().toString().take(6)}"

        val msg = ConversationMessage(
            id = msgId,
            projectId = projectId,
            senderId = user.id,
            senderName = user.name + if (senderType == "office") " (Phoenix Fire Safety)" else "",
            senderType = senderType,
            senderRole = user.role,
            timestamp = getCurrentDateTime(),
            type = type,
            content = content,
            audioDurationSeconds = audioDurationSeconds,
            isRead = true,
            status = "Sent"
        )

        _messages.value = _messages.value + msg
    }

    // Documents
    fun uploadDocument(
        projectId: String,
        title: String,
        filename: String,
        fileType: String,
        category: DocumentCategory,
        accessLevel: String,
        fileSize: String,
        previewText: String
    ) {
        val proj = _projects.value.firstOrNull { it.id == projectId }
        val user = _currentUser.value
        val docId = "doc-${UUID.randomUUID().toString().take(6)}"

        val doc = ProjectDocument(
            id = docId,
            projectId = projectId,
            projectReference = proj?.reference ?: "PHX-2026",
            title = title,
            filename = filename,
            fileType = fileType,
            fileSize = fileSize,
            category = category,
            uploadDate = getCurrentDate(),
            uploadedBy = user.name,
            uploadedByRole = user.role,
            accessLevel = accessLevel,
            previewText = previewText
        )

        _documents.value = listOf(doc) + _documents.value
    }

    fun deleteDocument(id: String) {
        _documents.value = _documents.value.filter { it.id != id }
    }

    // Employees
    fun addEmployee(emp: Employee) {
        _employees.value = listOf(emp) + _employees.value
    }

    fun updateEmployee(id: String, updated: Employee) {
        _employees.value = _employees.value.map { if (it.id == id) updated else it }
    }

    fun deleteEmployee(id: String) {
        _employees.value = _employees.value.filter { it.id != id }
    }

    // Clients
    fun addClient(client: Client) {
        _clients.value = listOf(client) + _clients.value
    }

    fun updateClient(id: String, updated: Client) {
        _clients.value = _clients.value.map { if (it.id == id) updated else it }
    }

    fun deleteClient(id: String) {
        _clients.value = _clients.value.filter { it.id != id }
    }

    fun importZohoClients(imported: List<Client>) {
        _clients.value = imported + _clients.value
    }

    // Settings
    fun updateSettings(newSettings: PluginSettings) {
        _settings.value = newSettings
    }

    // Notifications
    fun markNotificationAsRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(read = true) else it
        }
    }

    fun markAllNotificationsAsRead() {
        _notifications.value = _notifications.value.map { it.copy(read = true) }
    }

    // Reset Data
    fun resetToDefaults() {
        _users.value = initialUsers
        _currentUser.value = initialUsers[0]
        _employees.value = initialEmployees
        _clients.value = initialClients
        _projects.value = initialProjects
        _tasks.value = initialTasks
        _progressUpdates.value = initialProgressUpdates
        _messages.value = initialMessages
        _documents.value = initialDocuments
        _notifications.value = initialNotifications
        _settings.value = PluginSettings()
    }
}
