package com.example.phoenixpm.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.ConversationMessage
import com.example.phoenixpm.model.UserRole
import com.example.phoenixpm.ui.theme.*

@Composable
fun VoiceMessageItem(
    message: ConversationMessage,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(false) }
    var currentProgress by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            val totalSeconds = if (message.audioDurationSeconds > 0) message.audioDurationSeconds else 6
            val stepTime = 100L
            val totalSteps = (totalSeconds * 1000L) / stepTime
            for (i in 0..totalSteps) {
                currentProgress = i.toFloat() / totalSteps.toFloat()
                kotlinx.coroutines.delay(stepTime)
            }
            isPlaying = false
            currentProgress = 0f
        }
    }

    val isClient = message.senderRole == UserRole.Client
    val bubbleColor = if (isClient) PhoenixNavyElevated else PhoenixNavySurface

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = if (isClient) Alignment.Start else Alignment.End
    ) {
        Text(
            text = "${message.senderName} • ${message.timestamp}",
            color = TextMutedDark,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )

        Box(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .background(bubbleColor, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Column {
                if (message.type == "voice") {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(PhoenixRed)
                                .clickable { isPlaying = !isPlaying },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Pause voice note" else "Play voice note",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            // Waveform bars
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(24.dp),
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val heights = listOf(8, 14, 22, 12, 18, 24, 16, 10, 20, 14, 8, 16, 22, 18, 12)
                                heights.forEachIndexed { index, h ->
                                    val barProgress = index.toFloat() / heights.size.toFloat()
                                    val barColor = if (currentProgress >= barProgress) PhoenixRedLight else PhoenixNavyElevated
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(h.dp)
                                            .background(barColor, RoundedCornerShape(2.dp))
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (isPlaying) "Playing..." else "Voice Note",
                                    color = TextSecondaryDark,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "0:0${message.audioDurationSeconds}",
                                    color = TextMutedDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (message.content.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = message.content,
                            color = TextPrimaryDark,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                } else {
                    Text(
                        text = message.content,
                        color = TextPrimaryDark,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
