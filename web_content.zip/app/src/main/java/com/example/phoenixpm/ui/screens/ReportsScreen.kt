package com.example.phoenixpm.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.*
import com.example.phoenixpm.ui.components.StatCard
import com.example.phoenixpm.ui.theme.*

@Composable
fun ReportsScreen(
    projects: List<Project>,
    tasks: List<Task>,
    clients: List<Client>,
    modifier: Modifier = Modifier
) {
    val totalContractINR = projects.sumOf { it.contractValueINR }
    val completedProjects = projects.count { it.status == ProjectStatus.COMPLETED }
    val inProgressProjects = projects.count { it.status == ProjectStatus.IN_PROGRESS }
    val overdueProjects = projects.count { it.status == ProjectStatus.OVERDUE }

    val completedTasks = tasks.count { it.status == TaskStatus.COMPLETED }
    val totalTasks = tasks.size
    val taskRate = if (totalTasks > 0) (completedTasks * 100) / totalTasks else 0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Executive Reports & Audit",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Comprehensive performance, contract values, and statutory inspection analytics",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryDark
                )
            }
        }

        // Top Financial & Progress Stats
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Total Contract Value",
                    value = "₹${"%.2f".format(totalContractINR / 10000000.0)} Cr",
                    subtitle = "Across ${projects.size} projects",
                    icon = Icons.Default.CurrencyRupee,
                    iconTint = PhoenixEmerald,
                    modifier = Modifier.weight(1f)
                )

                StatCard(
                    title = "Task Success Rate",
                    value = "$taskRate%",
                    subtitle = "$completedTasks of $totalTasks items delivered",
                    icon = Icons.Default.CheckCircle,
                    iconTint = PhoenixSky,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Status Distribution Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Project Execution Health",
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    StatusProgressBar("In Progress", inProgressProjects, projects.size, PhoenixSky)
                    Spacer(modifier = Modifier.height(8.dp))
                    StatusProgressBar("Completed & Handed Over", completedProjects, projects.size, PhoenixEmerald)
                    Spacer(modifier = Modifier.height(8.dp))
                    StatusProgressBar("Overdue Statutory Audit", overdueProjects, projects.size, PhoenixRed)
                }
            }
        }

        // Category Portfolio Breakdown
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "System Category Allocation",
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ProjectCategory.entries.forEach { cat ->
                        val count = projects.count { it.category == cat }
                        val valueSum = projects.filter { it.category == cat }.sumOf { it.contractValueINR }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(cat.label, color = TextPrimaryDark, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("$count project(s)", color = TextSecondaryDark, fontSize = 11.sp)
                            }
                            Text("₹${valueSum / 100000.0}L", color = PhoenixSky, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
                    }
                }
            }
        }

        // Compliance Certificate Notice
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PhoenixNavySurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, PhoenixEmerald.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Verified, contentDescription = null, tint = PhoenixEmerald, modifier = Modifier.size(32.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Statutory Standards Compliance",
                            color = PhoenixEmerald,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "All active sites audited under IS 3844 Code of Practice for Fire Safety in Buildings and NBC 2016 Part 4 Fire and Life Safety.",
                            color = TextSecondaryDark,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusProgressBar(label: String, count: Int, total: Int, color: Color) {
    val fraction = if (total > 0) count.toFloat() / total.toFloat() else 0f
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = TextSecondaryDark, fontSize = 12.sp)
            Text("$count ($count of $total)", color = color, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = PhoenixNavyElevated
        )
    }
}
