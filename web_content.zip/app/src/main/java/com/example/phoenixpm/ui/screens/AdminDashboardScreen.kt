package com.example.phoenixpm.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.phoenixpm.model.*
import com.example.phoenixpm.ui.components.PriorityBadge
import com.example.phoenixpm.ui.components.StatCard
import com.example.phoenixpm.ui.components.StatusBadge
import com.example.phoenixpm.ui.components.TaskStatusBadge
import com.example.phoenixpm.ui.theme.*

@Composable
fun AdminDashboardScreen(
    projects: List<Project>,
    tasks: List<Task>,
    clients: List<Client>,
    onOpenProjectDetail: (String) -> Unit,
    onOpenNewProject: () -> Unit,
    onOpenNewTask: () -> Unit,
    onOpenAddClient: () -> Unit,
    onOpenZohoImport: () -> Unit,
    onToggleTaskStatus: (String, TaskStatus) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeProjects = projects.filter { it.status == ProjectStatus.IN_PROGRESS }
    val overdueTasks = tasks.filter { it.status == TaskStatus.OVERDUE }
    val totalContractValue = projects.sumOf { it.contractValueINR }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Welcome Header
        item {
            Column {
                Text(
                    text = "Engineering Operations Command",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimaryDark
                )
                Text(
                    text = "Phoenix Fire Safety Equipments • Industrial & Healthcare Protection",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryDark
                )
            }
        }

        // Overdue Alert Banner if present
        if (overdueTasks.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PhoenixRedDark.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                        .border(1.dp, PhoenixRed, RoundedCornerShape(10.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Alert",
                        tint = PhoenixRedLight,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${overdueTasks.size} Tasks Overdue Critical Deadline",
                            color = PhoenixRedLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Includes statutory Form B submission for Express Avenue.",
                            color = TextSecondaryDark,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Stat Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Active Projects",
                    value = "${activeProjects.size}",
                    subtitle = "₹${totalContractValue / 100000} Lakhs total",
                    icon = Icons.Default.Business,
                    iconTint = PhoenixSky,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Tasks In Flight",
                    value = "${tasks.count { it.status != TaskStatus.COMPLETED }}",
                    subtitle = "${tasks.count { it.status == TaskStatus.COMPLETED }} completed",
                    icon = Icons.Default.Assignment,
                    iconTint = PhoenixAmber,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Client Accounts",
                    value = "${clients.size}",
                    subtitle = "Zoho Books Linked",
                    icon = Icons.Default.People,
                    iconTint = PhoenixEmerald,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Safety Standard",
                    value = "IS 3844",
                    subtitle = "NBC 2016 Compliant",
                    icon = Icons.Default.Verified,
                    iconTint = PhoenixRed,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Action Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpenNewProject,
                    colors = ButtonDefaults.buttonColors(containerColor = PhoenixRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Project", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onOpenNewTask,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimaryDark),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Assignment, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Task", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onOpenZohoImport,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PhoenixSky),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Zoho Sync", fontSize = 12.sp)
                }
            }
        }

        // Active Projects Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Key Fire Safety Projects",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimaryDark
                )
                Text(
                    text = "${projects.size} Projects",
                    color = TextSecondaryDark,
                    fontSize = 12.sp
                )
            }
        }

        items(projects) { project ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                    .clickable { onOpenProjectDetail(project.id) }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = project.reference,
                            color = PhoenixRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PriorityBadge(priority = project.priority)
                            StatusBadge(status = project.status)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = project.name,
                        color = TextPrimaryDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Client: ${project.clientCompanyName}",
                        color = TextSecondaryDark,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "Site: ${project.siteLocation}",
                        color = TextMutedDark,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Progress Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Milestone Progress",
                            color = TextSecondaryDark,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${project.progressPercentage}%",
                            color = PhoenixEmerald,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    LinearProgressIndicator(
                        progress = { project.progressPercentage / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = PhoenixEmerald,
                        trackColor = PhoenixNavyElevated
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Value: ₹${project.contractValueINR / 100000.0}L",
                            color = TextPrimaryDark,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Target: ${project.expectedCompletionDate}",
                            color = TextSecondaryDark,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Recent High Priority Tasks
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Critical Engineering Tasks",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimaryDark
            )
        }

        items(tasks.take(4)) { task ->
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = task.status == TaskStatus.COMPLETED,
                        onCheckedChange = { isChecked ->
                            onToggleTaskStatus(
                                task.id,
                                if (isChecked) TaskStatus.COMPLETED else TaskStatus.IN_PROGRESS
                            )
                        },
                        colors = CheckboxDefaults.colors(
                            checkedColor = PhoenixEmerald,
                            checkmarkColor = Color.White
                        )
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            color = TextPrimaryDark,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Assigned: ${task.assignedToName} (${task.assignedToCode}) • Due: ${task.deadline}",
                            color = TextSecondaryDark,
                            fontSize = 11.sp
                        )
                    }

                    TaskStatusBadge(status = task.status)
                }
            }
        }
    }
}
