package com.example.neontap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue

data class TapPoint(val x: Float, val y: Float)

class TapAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapAccessibilityService? = null
        fun parsePoints(raw: String): List<TapPoint> = raw.split(';').mapNotNull { part ->
            val values = part.trim().split(',')
            if (values.size != 2) null else {
                val x = values[0].trim().toFloatOrNull()
                val y = values[1].trim().toFloatOrNull()
                if (x == null || y == null || x < 0 || y < 0) null else TapPoint(x, y)
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null
    private var panel: View? = null
    private var running = false
    private var paused = false
    private var intervalMs = 500L
    private var repeatLimit = 0
    private var points: List<TapPoint> = listOf(TapPoint(500f, 900f))
    private var totalClicks = 0L
    private var completedCycles = 0
    private var pointIndex = 0
    private var statusView: TextView? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        reloadSettings()
        if (Settings.canDrawOverlays(this)) showFloatingPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopClicking() }

    fun reloadSettings() {
        val prefs = getSharedPreferences("neontap", Context.MODE_PRIVATE)
        intervalMs = prefs.getLong("interval", 500L).coerceIn(100L, 60000L)
        repeatLimit = prefs.getInt("repeat", 0).coerceAtLeast(0)
        points = parsePoints(prefs.getString("points", "500,900") ?: "500,900")
            .ifEmpty { listOf(TapPoint(500f, 900f)) }
        pointIndex = 0
        updateStatus()
    }

    fun showFloatingPanel() {
        if (!Settings.canDrawOverlays(this) || panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(0xEE15192A.toInt(), dp(18).toFloat())
        }
        val heading = TextView(this).apply {
            text = "✦ NEONTAP"
            setTextColor(Color.rgb(66, 215, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(2), dp(0), dp(2), dp(8))
        }
        statusView = TextView(this).apply {
            setTextColor(Color.WHITE); setTextSize(12f); text = "Ready • 0 clicks"
            setPadding(dp(2), dp(0), dp(2), dp(8))
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(makeButton("START") { startClicking() }, weightedParams())
        controls.addView(makeButton("PAUSE") { togglePause() }, weightedParams())
        controls.addView(makeButton("STOP") { stopClicking() }, weightedParams())
        val close = makeButton("HIDE") { hideFloatingPanel() }
        root.addView(heading); root.addView(statusView); root.addView(controls)
        root.addView(close)
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(120) }
        try {
            windowManager?.addView(root, params)
            panel = root
        } catch (_: Exception) {
            panel = null
        }
        updateStatus()
    }

    private fun hideFloatingPanel() {
        stopClicking()
        try { panel?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        panel = null
        statusView = null
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 10f
            isAllCaps = true
            background = rounded(if (label == "START") 0xFF4A8DFF.toInt() else 0xFF292E46.toInt(), dp(10).toFloat())
            setOnClickListener { action() }
            minimumWidth = 0
            minWidth = 0
            setPadding(dp(5), dp(2), dp(5), dp(2))
        }

    private fun weightedParams() = LinearLayout.LayoutParams(0, dp(42), 1f).apply {
        marginEnd = dp(4)
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun startClicking() {
        if (points.isEmpty()) { updateStatus("No valid points"); return }
        if (running && paused) { paused = false; updateStatus(); scheduleTap(0); return }
        if (running) return
        running = true; paused = false; completedCycles = 0; pointIndex = 0
        updateStatus()
        scheduleTap(0)
    }

    private fun togglePause() {
        if (!running) return
        paused = !paused
        if (!paused) scheduleTap(0)
        updateStatus()
    }

    private fun stopClicking() {
        running = false; paused = false
        handler.removeCallbacksAndMessages(null)
        updateStatus()
    }

    private fun scheduleTap(delay: Long) {
        handler.postDelayed({
            if (!running || paused) return@postDelayed
            if (repeatLimit > 0 && completedCycles >= repeatLimit) {
                stopClicking(); updateStatus("Completed"); return@postDelayed
            }
            val point = points[pointIndex % points.size]
            val path = Path().apply { moveTo(point.x, point.y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 45))
                .build()
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    totalClicks++
                    pointIndex++
                    if (pointIndex % points.size == 0) completedCycles++
                    updateStatus()
                    if (running && !paused) scheduleTap((intervalMs - 45).coerceAtLeast(55L))
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (running && !paused) scheduleTap(intervalMs)
                }
            }, null)
            if (!accepted && running && !paused) scheduleTap(intervalMs)
        }, delay)
    }

    private fun updateStatus(message: String? = null) {
        statusView?.text = message ?: when {
            running && paused -> "Paused • $totalClicks clicks"
            running -> "Running • $totalClicks clicks"
            else -> "Ready • $totalClicks clicks"
        }
    }

    override fun onDestroy() {
        stopClicking()
        hideFloatingPanel()
        instance = null
        super.onDestroy()
    }
}
