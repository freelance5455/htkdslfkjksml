package com.example.bluetoothpenalty;
import android.app.*; import android.os.*; import android.bluetooth.*; import android.content.*; import android.webkit.*; import android.widget.*; import java.io.*; import java.util.*; import java.util.UUID;
public class MainActivity extends Activity {
 static final UUID ID=UUID.fromString("7a1b2c30-4d5e-4f60-9a70-112233445566");
 BluetoothAdapter adapter; BluetoothSocket socket; BluetoothServerSocket server; PrintWriter out; WebView web; TextView status; Handler h=new Handler(Looper.getMainLooper()); ArrayList<BluetoothDevice> devices=new ArrayList<>();
 public void onCreate(Bundle b){super.onCreate(b);adapter=BluetoothAdapter.getDefaultAdapter();
 LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(10,8,10,4);
 status=new TextView(this);status.setText("اقرن الهاتفين من إعدادات Bluetooth أولاً.");root.addView(status);
 LinearLayout row=new LinearLayout(this);Button host=new Button(this);host.setText("استضافة مباراة");Button join=new Button(this);join.setText("الاتصال بجهاز مقترن");row.addView(host,new LinearLayout.LayoutParams(0,-2,1));row.addView(join,new LinearLayout.LayoutParams(0,-2,1));root.addView(row);
 web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.addJavascriptInterface(new Bridge(),"AndroidBluetooth");root.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);web.loadUrl("file:///android_asset/index.html");
 host.setOnClickListener(v->host());join.setOnClickListener(v->choose());
 if(adapter==null)status.setText("الجهاز لا يدعم Bluetooth.");else if(!adapter.isEnabled())startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),1);}
 String q(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ")+"\"";}
 void stat(String s){h.post(()->{status.setText(s);if(web!=null)web.evaluateJavascript("setConnectionStatus("+q(s)+")",null);});}
 void host(){new Thread(()->{try{server=adapter.listenUsingRfcommWithServiceRecord("BluetoothPenalty",ID);stat("بانتظار اتصال صديقك…");socket=server.accept();server.close();streams();stat("متصل بصديقك ✓");}catch(Exception e){stat("تعذرت الاستضافة: "+e.getMessage());}}).start();}
 void choose(){try{devices.clear();devices.addAll(adapter.getBondedDevices());if(devices.isEmpty()){stat("اقرن الهاتف الآخر من إعدادات Bluetooth أولاً.");return;}String[] names=new String[devices.size()];for(int i=0;i<names.length;i++)names[i]=devices.get(i).getName()+" — "+devices.get(i).getAddress();new AlertDialog.Builder(this).setTitle("اختر هاتف صديقك").setItems(names,(d,n)->join(devices.get(n))).setNegativeButton("إلغاء",null).show();}catch(Exception e){stat("تعذر عرض الأجهزة: "+e.getMessage());}}
 void join(BluetoothDevice d){new Thread(()->{try{stat("جارٍ الاتصال…");socket=d.createRfcommSocketToServiceRecord(ID);adapter.cancelDiscovery();socket.connect();streams();stat("متصل بصديقك ✓");}catch(Exception e){stat("فشل الاتصال. تأكد أن صديقك يستضيف المباراة وأن الهاتفين مقترنان.");}}).start();}
 void streams()throws IOException{BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),"UTF-8"));out=new PrintWriter(new OutputStreamWriter(socket.getOutputStream(),"UTF-8"),true);new Thread(()->{try{String line;while((line=in.readLine())!=null){String m=line;h.post(()->web.evaluateJavascript("receiveBluetoothMessage("+q(m)+")",null));}}catch(Exception e){stat("انقطع اتصال Bluetooth.");}}).start();}
 class Bridge{@JavascriptInterface public void send(String s){new Thread(()->{if(out!=null)out.println(s);}).start();}@JavascriptInterface public boolean isConnected(){return socket!=null&&socket.isConnected()&&out!=null;}}
 public void onDestroy(){try{if(socket!=null)socket.close();if(server!=null)server.close();}catch(Exception e){}super.onDestroy();}
}
