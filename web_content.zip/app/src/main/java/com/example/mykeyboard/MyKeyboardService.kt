package com.example.mykeyboard

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MyKeyboardService : InputMethodService() {
    private lateinit var web: WebView

    override fun onCreateInputView(): View {
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_NO_CACHE
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(this), "AndroidKeyboard")
        web.loadUrl("file:///android_asset/keyboard.html")
        return web
    }

    private fun commit(value: String) {
        val ic = currentInputConnection ?: return
        when (value) {
            "BACKSPACE" -> {
                val selected = ic.getSelectedText(0)
                if (!selected.isNullOrEmpty()) {
                    ic.commitText("", 1)
                } else {
                    ic.deleteSurroundingText(1, 0)
                }
            }
            "ENTER" -> ic.sendKeyEvent(android.view.KeyEvent(
                android.view.KeyEvent.ACTION_DOWN,
                android.view.KeyEvent.KEYCODE_ENTER
            ))
            else -> ic.commitText(value, 1)
        }
    }

    private class Bridge(private val service: MyKeyboardService) {
        @JavascriptInterface
        fun type(value: String) {
            service.commit(value)
        }

        @JavascriptInterface
        fun voice() {
            service.toast("Use your phone's voice input service from the keyboard/app.")
        }
    }

    private fun toast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
