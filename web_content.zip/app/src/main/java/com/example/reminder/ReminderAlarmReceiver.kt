package com.example.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.RaynoxDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderAlarmReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "ReminderReceiver"
        const val CHANNEL_ID = "raynox_reminders_channel"
        const val CHANNEL_NAME = "Raynox AI Reminders"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d(TAG, "Received broadcast action: $action")

        if (action == Intent.ACTION_BOOT_COMPLETED) {
            // Reschedule active reminders after phone reboot
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = RaynoxDatabase.getInstance(context)
                    val upcoming = db.reminderDao().getUpcomingActiveReminders(System.currentTimeMillis())
                    for (reminder in upcoming) {
                        ReminderScheduler.scheduleReminder(
                            context = context,
                            reminderId = reminder.id,
                            title = reminder.title,
                            timeEpochMs = reminder.scheduledTimeMs
                        )
                    }
                    Log.d(TAG, "Rescheduled ${upcoming.size} reminders after reboot")
                } catch (e: Exception) {
                    Log.e(TAG, "Error rescheduling reminders on boot: ${e.message}")
                } finally {
                    pendingResult.finish()
                }
            }
            return
        }

        if (action == ReminderScheduler.ACTION_REMINDER_ALERT) {
            val reminderId = intent.getLongExtra(ReminderScheduler.EXTRA_REMINDER_ID, 0L)
            val title = intent.getStringExtra(ReminderScheduler.EXTRA_REMINDER_TITLE) ?: "Reminder from RAYNOX AI"

            showNotification(context, reminderId, title)

            // Mark reminder as triggered in DB
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = RaynoxDatabase.getInstance(context)
                    db.reminderDao().setCompleted(reminderId, true)
                } catch (e: Exception) {
                    Log.w(TAG, "Could not mark reminder as completed: ${e.message}")
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }

    private fun showNotification(context: Context, reminderId: Long, title: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for RAYNOX AI scheduled reminders"
                enableVibration(true)
                enableLights(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.createChooser(this, "").flags or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            reminderId.toInt(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("RAYNOX AI Reminder")
            .setContentText(title)
            .setStyle(NotificationCompat.BigTextStyle().bigText(title))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(soundUri)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify((1000 + reminderId).toInt(), notification)
    }
}
