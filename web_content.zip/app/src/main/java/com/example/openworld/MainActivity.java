package com.example.openworld;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.InputStream;

public class MainActivity extends Activity {
 WebView w;
 @Override public void onCreate(Bundle b){
  setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
  super.onCreate(b);
  getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  if(android.os.Build.VERSION.SDK_INT>=28){getWindow().getAttributes().layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;}
  setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
  w=new WebView(this);
  w.setBackgroundColor(Color.rgb(155,215,255));
  WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  w.setOverScrollMode(View.OVER_SCROLL_NEVER);
  // تقديم ملفات assets عبر عنوان https وهمي: يحل مشكلة تحميل character.glb (fetch لا يعمل مع file://)
  w.setWebViewClient(new WebViewClient(){
   @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r){
    String host=r.getUrl().getHost();
    if(!"appassets.androidplatform.net".equals(host) && !"appassets.local".equals(host)) return null;
    String p=r.getUrl().getPath();
    if(p==null||p.equals("/")||p.equals("/web/")||p.equals("/web")) p="/index.html";
    else if(p.startsWith("/web/")) p=p.substring(4);
    try{
     InputStream in=getAssets().open(p.substring(1));
     String m=p.endsWith(".html")?"text/html":p.endsWith(".js")?"text/javascript":p.endsWith(".glb")?"model/gltf-binary":"application/octet-stream";
     return new WebResourceResponse(m,"UTF-8",in);
    }catch(Exception e){return null;}
   }
  });
  w.addJavascriptInterface(new Object(){
   @JavascriptInterface public void exit(){runOnUiThread(new Runnable(){public void run(){finish();}});}
   @JavascriptInterface public void flipLandscape(){runOnUiThread(new Runnable(){public void run(){
    reverseLandscape=!reverseLandscape;
    setRequestedOrientation(reverseLandscape ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
   }});}
  },"Android");
  w.loadUrl("https://appassets.androidplatform.net/web/index.html");
  setContentView(w);
 }
 @Override public void onWindowFocusChanged(boolean f){
  super.onWindowFocusChanged(f);
  if(f) getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
 }
 @Override public void onConfigurationChanged(android.content.res.Configuration c){super.onConfigurationChanged(c); w.post(new Runnable(){public void run(){w.evaluateJavascript("dispatchEvent(new Event('resize'))",null);}});}
 @Override public void onBackPressed(){
  w.evaluateJavascript("window.nativeBack&&window.nativeBack()",new android.webkit.ValueCallback<String>(){public void onReceiveValue(String v){if("true".equals(v)||"null".equals(v))finish();}});
 }
 @Override protected void onPause(){super.onPause(); w.onPause();}
 @Override protected void onResume(){super.onResume(); setRequestedOrientation(reverseLandscape ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); w.onResume();}
 @Override protected void onDestroy(){w.destroy(); super.onDestroy();}
}
