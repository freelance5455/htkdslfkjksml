package com.example.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.model.VoiceLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

class NovaVoiceManager(
    private val context: Context,
    private val onFinalTranscript: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _partialTranscript = MutableStateFlow("")
    val partialTranscript: StateFlow<String> = _partialTranscript.asStateFlow()

    private val _voiceError = MutableStateFlow<String?>(null)
    val voiceError: StateFlow<String?> = _voiceError.asStateFlow()

    private val _speechRate = MutableStateFlow(1.0f)
    val speechRate: StateFlow<Float> = _speechRate.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(VoiceLanguage.AUTO_HINGLISH)
    val selectedLanguage: StateFlow<VoiceLanguage> = _selectedLanguage.asStateFlow()

    init {
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isTtsInitialized = true
                    applyTtsLocale(_selectedLanguage.value)
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _isSpeaking.value = true
                        }

                        override fun onDone(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _isSpeaking.value = false
                        }
                    })
                }
            }
        } catch (_: Exception) {
            isTtsInitialized = false
        }
    }

    private fun applyTtsLocale(voiceLang: VoiceLanguage) {
        val locale = Locale.forLanguageTag(voiceLang.bcp47Tag)
        val res = tts?.setLanguage(locale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }
    }

    fun setVoiceLanguage(language: VoiceLanguage) {
        _selectedLanguage.value = language
        if (isTtsInitialized) {
            applyTtsLocale(language)
        }
    }

    fun setSpeakingSpeed(rate: Float) {
        val clamped = rate.coerceIn(0.6f, 1.8f)
        _speechRate.value = clamped
        tts?.setSpeechRate(clamped)
    }

    fun startListening() {
        stopSpeaking()
        _voiceError.value = null
        _partialTranscript.value = ""

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceError.value = "Speech recognition service is not available on this device. You can type your message below."
            _isListening.value = false
            return
        }

        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _isListening.value = true
                            _voiceError.value = null
                        }

                        override fun onBeginningOfSpeech() {
                            _isListening.value = true
                        }

                        override fun onRmsChanged(rmsdB: Float) {}

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            _isListening.value = false
                        }

                        override fun onError(error: Int) {
                            _isListening.value = false
                            val message = when (error) {
                                SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap the mic to speak again."
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Tap the mic to retry."
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required for voice input."
                                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error during speech recognition."
                                else -> "Voice recognition paused (Code $error). Tap mic or use text input."
                            }
                            _voiceError.value = message
                        }

                        override fun onResults(results: Bundle?) {
                            _isListening.value = false
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val best = matches?.firstOrNull()?.trim().orEmpty()
                            _partialTranscript.value = best
                            if (best.isNotEmpty()) {
                                onFinalTranscript(best)
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val partial = matches?.firstOrNull()?.trim().orEmpty()
                            if (partial.isNotEmpty()) {
                                _partialTranscript.value = partial
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }

            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, _selectedLanguage.value.bcp47Tag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            speechRecognizer?.startListening(recognizerIntent)
            _isListening.value = true
        } catch (e: Exception) {
            _isListening.value = false
            _voiceError.value = "Unable to start microphone: ${e.localizedMessage ?: "Unknown error"}"
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {
        }
        _isListening.value = false
    }

    fun speak(rawMarkdownText: String) {
        if (!isTtsInitialized) return
        // Clean markdown symbols so spoken output sounds natural
        val cleanSpeech = rawMarkdownText
            .replace(Regex("```[\\s\\S]*?```"), "Code block provided on screen.")
            .replace(Regex("[*_#`~>|]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(1800)

        if (cleanSpeech.isEmpty()) return

        // Auto-switch TTS locale if Devanagari script is present
        val hasDevanagari = cleanSpeech.any { it in '\u0900'..'\u097F' }
        if (hasDevanagari) {
            tts?.setLanguage(Locale.forLanguageTag("hi-IN"))
        } else {
            applyTtsLocale(_selectedLanguage.value)
        }
        tts?.setSpeechRate(_speechRate.value)
        _isSpeaking.value = true
        tts?.speak(cleanSpeech, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stopSpeaking() {
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
            }
        } catch (_: Exception) {
        }
        _isSpeaking.value = false
    }

    fun clearError() {
        _voiceError.value = null
    }

    fun release() {
        stopListening()
        stopSpeaking()
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
    }
}
