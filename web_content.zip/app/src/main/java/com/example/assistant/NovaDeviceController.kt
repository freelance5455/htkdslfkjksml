package com.example.assistant

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.data.model.ContactItem
import com.example.data.model.DeviceInfoSnapshot
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface ParsedVoiceIntent {
    data class DeviceQuery(val title: String, val spokenResponse: String) : ParsedVoiceIntent
    data class CallContactQuery(val rawNameOrNumber: String) : ParsedVoiceIntent
    data class OpenDialer(val number: String = "") : ParsedVoiceIntent
    data class SystemAction(val description: String, val execute: () -> Boolean) : ParsedVoiceIntent
    data object None : ParsedVoiceIntent
}

class NovaDeviceController(private val context: Context) {

    fun captureDeviceSnapshot(): DeviceInfoSnapshot {
        val appContext = context.applicationContext

        // 1. Battery & Charging
        val batteryIntent = appContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) (level * 100) / scale else 0

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val chargePlug = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        val chargingSource = when (chargePlug) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Wall Charger"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB Port"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Pad"
            else -> if (isCharging) "Power Source" else "Battery Power"
        }

        // 2. Internal Storage
        val statFs = StatFs(Environment.getDataDirectory().path)
        val availBytes = statFs.availableBytes
        val totalBytes = statFs.totalBytes
        val availGb = String.format(Locale.US, "%.1f", availBytes / (1024.0 * 1024.0 * 1024.0))
        val totalGb = String.format(Locale.US, "%.1f", totalBytes / (1024.0 * 1024.0 * 1024.0))

        // 3. Network & Wi-Fi
        val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = cm?.activeNetwork
        val caps = if (activeNetwork != null) cm.getNetworkCapabilities(activeNetwork) else null
        val isInternetConnected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true

        val transport = when {
            caps == null -> "Disconnected"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected Network"
        }

        val wifiManager = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val isWifiEnabled = try {
            wifiManager?.isWifiEnabled == true || caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        } catch (_: Exception) {
            caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }

        // 4. Bluetooth
        val btManager = appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val isBluetoothEnabled = try {
            btManager?.adapter?.isEnabled == true
        } catch (_: SecurityException) {
            false
        }

        // 5. Time & Date
        val now = Date()
        val timeFmt = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(now)
        val dateFmt = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(now)

        val deviceModel = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
        val androidVer = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"

        return DeviceInfoSnapshot(
            batteryPercentage = batteryPct,
            isCharging = isCharging,
            chargingSource = chargingSource,
            availableStorageGb = availGb,
            totalStorageGb = totalGb,
            isInternetConnected = isInternetConnected,
            networkTransport = transport,
            isWifiEnabled = isWifiEnabled,
            isBluetoothEnabled = isBluetoothEnabled,
            currentTimeFormatted = timeFmt,
            currentDateFormatted = dateFmt,
            deviceModel = deviceModel,
            androidVersion = androidVer
        )
    }

    /**
     * Evaluates natural-language Hindi, Hinglish, and English voice/text commands
     * for instant factual device telemetry or phone actions.
     */
    fun parseNaturalCommand(rawInput: String): ParsedVoiceIntent {
        val text = rawInput.trim().lowercase(Locale.ROOT)
        val snap = captureDeviceSnapshot()

        // 1. Battery / Charging checks
        if (text.contains("battery kitni") ||
            text.contains("battery percentage") ||
            text.contains("battery level") ||
            text.contains("how much battery") ||
            (text.contains("battery") && (text.contains("kitna") || text.contains("status") || text.contains("check")))
        ) {
            val chargeText = if (snap.isCharging) {
                "aur phone abhi ${snap.chargingSource} se charge ho raha hai."
            } else {
                "aur phone abhi charging par nahi hai."
            }
            return ParsedVoiceIntent.DeviceQuery(
                title = "Battery Telemetry",
                spokenResponse = "Aapke phone ki battery abhi **${snap.batteryPercentage}%** hai, $chargeText"
            )
        }

        if (text.contains("charging par hai") || text.contains("is phone charging") || text.contains("charge ho raha")) {
            val msg = if (snap.isCharging) {
                "Haan, aapka phone abhi **${snap.chargingSource}** par charge ho raha hai (Battery: **${snap.batteryPercentage}%**)."
            } else {
                "Nahi, aapka phone abhi charging par nahi hai. Current battery **${snap.batteryPercentage}%** hai."
            }
            return ParsedVoiceIntent.DeviceQuery("Charging Status", msg)
        }

        // 2. Storage check
        if (text.contains("storage kitni") || text.contains("free space") || text.contains("storage bachi") || text.contains("how much storage")) {
            return ParsedVoiceIntent.DeviceQuery(
                title = "Internal Storage",
                spokenResponse = "Aapke phone mein **${snap.availableStorageGb} GB** free storage bachi hai (Total storage: **${snap.totalStorageGb} GB**)."
            )
        }

        // 3. Wi-Fi / Internet / Bluetooth
        if (text.contains("wi-fi connected") || text.contains("wifi connected") || text.contains("wifi on hai")) {
            val msg = if (snap.isWifiEnabled && snap.networkTransport == "Wi-Fi") {
                "Haan, Wi-Fi ON hai aur internet se connected hai."
            } else if (snap.isWifiEnabled) {
                "Wi-Fi radio ON hai, lekin active internet transport abhi **${snap.networkTransport}** hai."
            } else {
                "Nahi, Wi-Fi abhi OFF ya disconnected hai."
            }
            return ParsedVoiceIntent.DeviceQuery("Wi-Fi Status", msg)
        }

        if (text.contains("bluetooth on hai") || text.contains("is bluetooth on") || text.contains("bluetooth status")) {
            val msg = if (snap.isBluetoothEnabled) {
                "Haan, aapke phone ka Bluetooth abhi **ON** hai."
            } else {
                "Nahi, Bluetooth abhi **OFF** hai."
            }
            return ParsedVoiceIntent.DeviceQuery("Bluetooth Status", msg)
        }

        if (text.contains("internet connected") || text.contains("net chal raha") || text.contains("is internet working")) {
            val msg = if (snap.isInternetConnected) {
                "Haan, internet connected hai (**${snap.networkTransport}** ke zariye)."
            } else {
                "Nahi, internet abhi disconnected hai."
            }
            return ParsedVoiceIntent.DeviceQuery("Internet Connectivity", msg)
        }

        // 4. Time & Date
        if (text.contains("kitna time hua") || text.contains("kya time hua") || text.contains("what time is it") || text.contains("current time")) {
            return ParsedVoiceIntent.DeviceQuery(
                title = "Current Time",
                spokenResponse = "Abhi samay **${snap.currentTimeFormatted}** hua hai."
            )
        }

        if (text.contains("aaj kya date hai") || text.contains("what is today's date") || text.contains("aaj ki tarikh") || text.contains("current date")) {
            return ParsedVoiceIntent.DeviceQuery(
                title = "Today's Date",
                spokenResponse = "Aaj ki date **${snap.currentDateFormatted}** hai."
            )
        }

        // 5. Dialer / Calling commands
        if (text.contains("dialer kholo") || text.contains("open dialer")) {
            return ParsedVoiceIntent.OpenDialer("")
        }

        // Match patterns like "papa ko call lagao", "mummy ko phone karo", "call rahul"
        val hindiCallRegex = Regex("""(.+?)\s+ko\s+(call|phone)\s+(lagao|karo|mila|milao)""")
        val hindiMatch = hindiCallRegex.find(text)
        if (hindiMatch != null) {
            val target = hindiMatch.groupValues[1]
                .replace("hello aura", "")
                .replace("hello nova", "")
                .replace("aura", "")
                .replace("nova", "")
                .trim()
            if (target.isNotEmpty()) {
                return ParsedVoiceIntent.CallContactQuery(target)
            }
        }

        val englishCallRegex = Regex("""^(?:hello (?:aura|nova)\s*)?(?:please\s*)?(?:call|dial|phone)\s+(.+)$""")
        val englishMatch = englishCallRegex.find(text)
        if (englishMatch != null) {
            val target = englishMatch.groupValues[1].trim()
            if (target.isNotEmpty() && !target.contains("function") && !target.contains("api")) {
                return ParsedVoiceIntent.CallContactQuery(target)
            }
        }

        // 6. System Settings & Hardware Shortcuts
        if (text.contains("wifi settings") || text.contains("wi-fi settings") || text.contains("wifi kholo")) {
            return ParsedVoiceIntent.SystemAction("Opening Wi-Fi Settings") { openWifiSettings() }
        }
        if (text.contains("bluetooth settings") || text.contains("bluetooth kholo")) {
            return ParsedVoiceIntent.SystemAction("Opening Bluetooth Settings") { openBluetoothSettings() }
        }
        if (text.contains("battery settings")) {
            return ParsedVoiceIntent.SystemAction("Opening Battery Settings") { openBatterySettings() }
        }
        if (text.contains("open settings") || text.contains("settings kholo") || text.contains("phone settings")) {
            return ParsedVoiceIntent.SystemAction("Opening Android Settings") { openSystemSettings() }
        }
        if (text.contains("open camera") || text.contains("camera kholo")) {
            return ParsedVoiceIntent.SystemAction("Opening Camera") { openCameraApp() }
        }

        return ParsedVoiceIntent.None
    }

    // --- CONTACTS & CALLING ---

    fun hasContactsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun hasCallPhonePermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun searchContacts(query: String): List<ContactItem> {
        if (!hasContactsPermission()) return emptyList()
        val cleanQuery = query.trim()
        val results = mutableListOf<ContactItem>()
        val resolver = context.contentResolver
        val selection = if (cleanQuery.isNotEmpty()) {
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY} LIKE ? OR ${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?"
        } else {
            null
        }
        val selectionArgs = if (cleanQuery.isNotEmpty()) {
            arrayOf("%$cleanQuery%", "%$cleanQuery%")
        } else {
            null
        }

        try {
            resolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                selection,
                selectionArgs,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY} ASC"
            )?.use { cursor ->
                val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (cursor.moveToNext() && results.size < 25) {
                    val id = if (idIdx >= 0) cursor.getString(idIdx).orEmpty() else ""
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx).orEmpty() else "Unknown"
                    val number = if (numIdx >= 0) cursor.getString(numIdx).orEmpty() else ""
                    if (number.isNotBlank()) {
                        results.add(ContactItem(id = id, displayName = name, phoneNumber = number))
                    }
                }
            }
        } catch (_: Exception) {
            // Ignore provider errors
        }
        return results.distinctBy { "${it.displayName}_${it.phoneNumber.replace(" ", "")}" }
    }

    fun openDialer(phoneNumber: String = ""): Boolean {
        return try {
            val uri = if (phoneNumber.isNotBlank()) {
                Uri.parse("tel:${Uri.encode(phoneNumber.trim())}")
            } else {
                Uri.parse("tel:")
            }
            val intent = Intent(Intent.ACTION_DIAL, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun placeDirectCall(phoneNumber: String): Boolean {
        if (phoneNumber.isBlank()) return false
        if (!hasCallPhonePermission()) {
            return openDialer(phoneNumber)
        }
        return try {
            val uri = Uri.parse("tel:${Uri.encode(phoneNumber.trim())}")
            val intent = Intent(Intent.ACTION_CALL, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            openDialer(phoneNumber)
        }
    }

    // --- OTHER PHONE ACTIONS ---

    fun openSystemSettings(): Boolean = startSafeIntent(Intent(Settings.ACTION_SETTINGS))

    fun openWifiSettings(): Boolean = startSafeIntent(Intent(Settings.ACTION_WIFI_SETTINGS))

    fun openBluetoothSettings(): Boolean = startSafeIntent(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))

    fun openBatterySettings(): Boolean = startSafeIntent(Intent(Intent.ACTION_POWER_USAGE_SUMMARY))

    fun openCameraApp(): Boolean = startSafeIntent(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))

    fun startMapNavigation(destinationQuery: String): Boolean {
        val encoded = Uri.encode(destinationQuery.trim().ifEmpty { "nearby restaurants" })
        val uri = Uri.parse("geo:0,0?q=$encoded")
        return startSafeIntent(Intent(Intent.ACTION_VIEW, uri))
    }

    fun setDeviceTimer(seconds: Int, message: String = "AURA AI Timer"): Boolean {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds.coerceAtLeast(5))
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        }
        return startSafeIntent(intent)
    }

    fun createCalendarEvent(title: String, description: String = "Created by AURA AI"): Boolean {
        val startMillis = System.currentTimeMillis() + 3600_000L
        val endMillis = startMillis + 3600_000L
        val intent = Intent(Intent.ACTION_INSERT).apply {
            data = CalendarContract.Events.CONTENT_URI
            putExtra(CalendarContract.Events.TITLE, title.ifBlank { "AURA AI Reminder" })
            putExtra(CalendarContract.Events.DESCRIPTION, description)
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
        }
        return startSafeIntent(intent)
    }

    fun draftSmsMessage(phoneNumber: String, body: String): Boolean {
        val uri = Uri.parse("smsto:${Uri.encode(phoneNumber.trim())}")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", body)
        }
        return startSafeIntent(intent)
    }

    fun launchAppByName(appNameQuery: String): Boolean {
        val pm = context.packageManager
        val clean = appNameQuery.trim().lowercase(Locale.ROOT)
        if (clean.isEmpty()) return false
        return try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
            val match = resolveInfos.firstOrNull { info ->
                val label = info.loadLabel(pm).toString().lowercase(Locale.ROOT)
                val pkg = info.activityInfo.packageName.lowercase(Locale.ROOT)
                label.contains(clean) || pkg.contains(clean)
            }
            if (match != null) {
                val launchIntent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return true
                }
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun startSafeIntent(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
