package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class JarvisNativeBridge(
  private val context: Context,
  private val webViewProvider: () -> WebView?,
  private val onRequestPermissions: (Array<String>, (Map<String, Boolean>) -> Unit) -> Unit,
  private val onToggleFullscreen: (Boolean) -> Unit,
) {
  private val mainHandler = Handler(Looper.getMainLooper())
  private var speechRecognizer: SpeechRecognizer? = null
  private var tts: TextToSpeech? = null
  private var ttsReady = false
  private var activeLocationListener: LocationListener? = null

  companion object {
    private const val CHANNEL_ID = "jarvis_alerts"
  }

  init {
    ensureNotificationChannel()
    initTts()
  }

  private fun initTts() {
    tts =
      TextToSpeech(context.applicationContext) { status ->
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
          tts?.setOnUtteranceProgressListener(
            object : UtteranceProgressListener() {
              override fun onStart(utteranceId: String?) {
                val safeId = JSONObject.quote(utteranceId ?: "")
                evalJs("window.__jarvisNativeTtsStart && window.__jarvisNativeTtsStart($safeId);")
              }

              override fun onDone(utteranceId: String?) {
                val safeId = JSONObject.quote(utteranceId ?: "")
                evalJs("window.__jarvisNativeTtsDone && window.__jarvisNativeTtsDone($safeId);")
              }

              @Deprecated("Deprecated in Java")
              override fun onError(utteranceId: String?) {
                val safeId = JSONObject.quote(utteranceId ?: "")
                evalJs("window.__jarvisNativeTtsError && window.__jarvisNativeTtsError($safeId);")
              }

              override fun onError(utteranceId: String?, errorCode: Int) {
                val safeId = JSONObject.quote(utteranceId ?: "")
                evalJs("window.__jarvisNativeTtsError && window.__jarvisNativeTtsError($safeId);")
              }
            }
          )
        }
      }
  }

  private fun ensureNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      if (manager != null && manager.getNotificationChannel(CHANNEL_ID) == null) {
        val channel =
          NotificationChannel(
            CHANNEL_ID,
            "JARVIS Reminders & Timers",
            NotificationManager.IMPORTANCE_HIGH,
          ).apply {
            description = "Notifications for JARVIS timers, alarms, and reminders"
          }
        manager.createNotificationChannel(channel)
      }
    }
  }

  private fun evalJs(script: String) {
    mainHandler.post { webViewProvider()?.evaluateJavascript(script, null) }
  }

  @JavascriptInterface
  fun isNativeHost(): Boolean = true

  @JavascriptInterface
  fun getGeminiApiKey(): String {
    val key = BuildConfig.GEMINI_API_KEY
    return if (key.isNullOrBlank() || key == "MY_GEMINI_API_KEY") "" else key.trim()
  }

  @JavascriptInterface
  fun isSpeechRecognitionAvailable(): Boolean {
    return SpeechRecognizer.isRecognitionAvailable(context)
  }

  @JavascriptInterface
  fun requestMicAndCameraPermissions() {
    val needed = mutableListOf<String>()
    if (
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) !=
        PackageManager.PERMISSION_GRANTED
    ) {
      needed.add(Manifest.permission.RECORD_AUDIO)
    }
    if (
      ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) !=
        PackageManager.PERMISSION_GRANTED
    ) {
      needed.add(Manifest.permission.CAMERA)
    }
    if (needed.isEmpty()) {
      evalJs("window.__jarvisNativePermission && window.__jarvisNativePermission('media', true);")
      return
    }
    mainHandler.post {
      onRequestPermissions(needed.toTypedArray()) { results ->
        val micOk =
          ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        evalJs(
          "window.__jarvisNativePermission && window.__jarvisNativePermission('mic', $micOk);"
        )
      }
    }
  }

  @JavascriptInterface
  fun startNativeListening(langTag: String) {
    mainHandler.post {
      val hasMic =
        ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
          PackageManager.PERMISSION_GRANTED
      if (!hasMic) {
        onRequestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO)) { results ->
          val granted = results[Manifest.permission.RECORD_AUDIO] == true
          evalJs(
            "window.__jarvisNativePermission && window.__jarvisNativePermission('mic', $granted);"
          )
          if (granted) {
            beginSpeechRecognizer(langTag)
          } else {
            evalJs(
              "window.__jarvisNativeSpeechError && window.__jarvisNativeSpeechError('not-allowed', 'Microphone permission denied');"
            )
          }
        }
      } else {
        beginSpeechRecognizer(langTag)
      }
    }
  }

  private fun beginSpeechRecognizer(langTag: String) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
      evalJs(
        "window.__jarvisNativeSpeechError && window.__jarvisNativeSpeechError('unavailable', 'Android speech recognition service is unavailable on this device');"
      )
      return
    }
    try {
      speechRecognizer?.destroy()
      speechRecognizer =
        SpeechRecognizer.createSpeechRecognizer(context).apply {
          setRecognitionListener(
            object : RecognitionListener {
              override fun onReadyForSpeech(params: Bundle?) {
                evalJs("window.__jarvisNativeSpeechReady && window.__jarvisNativeSpeechReady();")
              }

              override fun onBeginningOfSpeech() {
                evalJs("window.__jarvisNativeSpeechStart && window.__jarvisNativeSpeechStart();")
              }

              override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
                evalJs("window.__jarvisNativeRms && window.__jarvisNativeRms($normalized);")
              }

              override fun onBufferReceived(buffer: ByteArray?) {}

              override fun onEndOfSpeech() {
                evalJs("window.__jarvisNativeSpeechEnd && window.__jarvisNativeSpeechEnd();")
              }

              override fun onError(error: Int) {
                val code =
                  when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "network"
                    SpeechRecognizer.ERROR_AUDIO -> "audio-capture"
                    else -> "error-$error"
                  }
                val msg = JSONObject.quote("Speech error ($code)")
                evalJs(
                  "window.__jarvisNativeSpeechError && window.__jarvisNativeSpeechError('$code', $msg);"
                )
              }

              override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                val safeText = JSONObject.quote(text)
                evalJs(
                  "window.__jarvisNativeSpeechResult && window.__jarvisNativeSpeechResult($safeText);"
                )
              }

              override fun onPartialResults(partialResults: Bundle?) {
                val matches =
                  partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                if (text.isNotEmpty()) {
                  val safeText = JSONObject.quote(text)
                  evalJs(
                    "window.__jarvisNativeSpeechPartial && window.__jarvisNativeSpeechPartial($safeText);"
                  )
                }
              }

              override fun onEvent(eventType: Int, params: Bundle?) {}
            }
          )
        }

      val intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
          putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
          )
          putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
          putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
          if (langTag.isNotBlank() && langTag != "auto") {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
          }
        }
      speechRecognizer?.startListening(intent)
    } catch (e: Exception) {
      val msg = JSONObject.quote(e.message ?: "Failed to start recognizer")
      evalJs(
        "window.__jarvisNativeSpeechError && window.__jarvisNativeSpeechError('exception', $msg);"
      )
    }
  }

  @JavascriptInterface
  fun stopNativeListening() {
    mainHandler.post {
      try {
        speechRecognizer?.stopListening()
        speechRecognizer?.cancel()
      } catch (_: Exception) {}
    }
  }

  @JavascriptInterface
  fun speakNative(utteranceId: String, text: String, langTag: String, rate: Float, pitch: Float) {
    mainHandler.post {
      val engine = tts
      if (engine == null || !ttsReady) {
        val safeId = JSONObject.quote(utteranceId)
        evalJs("window.__jarvisNativeTtsError && window.__jarvisNativeTtsError($safeId);")
        return@post
      }
      try {
        val locale =
          if (langTag.isNotBlank() && langTag != "auto") Locale.forLanguageTag(langTag)
          else Locale.getDefault()
        val langSupport = engine.isLanguageAvailable(locale)
        if (langSupport >= TextToSpeech.LANG_AVAILABLE) {
          engine.language = locale
        }
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        engine.setPitch(pitch.coerceIn(0.5f, 2.0f))
        val params = Bundle().apply { putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId) }
        engine.speak(text, TextToSpeech.QUEUE_ADD, params, utteranceId)
      } catch (_: Exception) {
        val safeId = JSONObject.quote(utteranceId)
        evalJs("window.__jarvisNativeTtsError && window.__jarvisNativeTtsError($safeId);")
      }
    }
  }

  @JavascriptInterface
  fun stopNativeSpeaking() {
    mainHandler.post {
      try {
        tts?.stop()
      } catch (_: Exception) {}
    }
  }

  @JavascriptInterface
  fun getNativeVoices(): String {
    val arr = JSONArray()
    try {
      val voices = tts?.voices ?: emptySet()
      for (v in voices) {
        val obj = JSONObject()
        obj.put("name", v.name)
        obj.put("lang", v.locale.toLanguageTag())
        arr.put(obj)
      }
    } catch (_: Exception) {}
    return arr.toString()
  }

  @JavascriptInterface
  fun getSystemTelemetry(): String {
    val obj = JSONObject()
    try {
      val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
      val batLevel = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
      val isCharging = bm?.isCharging ?: false
      obj.put("batteryLevel", if (batLevel in 0..100) batLevel else -1)
      obj.put("batteryCharging", isCharging)

      val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      val memInfo = ActivityManager.MemoryInfo()
      if (am != null) {
        am.getMemoryInfo(memInfo)
        val totalMb = memInfo.totalMem / (1024.0 * 1024.0)
        val availMb = memInfo.availMem / (1024.0 * 1024.0)
        val usedMb = (totalMb - availMb).coerceAtLeast(0.0)
        val pct = if (totalMb > 0) ((usedMb / totalMb) * 100.0) else 0.0
        obj.put("ramUsedMb", Math.round(usedMb))
        obj.put("ramTotalMb", Math.round(totalMb))
        obj.put("ramPercent", Math.round(pct))
      }

      val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
      val network = cm?.activeNetwork
      val caps = if (network != null) cm.getNetworkCapabilities(network) else null
      val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
      val downMbps =
        if (caps != null && caps.linkDownstreamBandwidthKbps > 0)
          caps.linkDownstreamBandwidthKbps / 1000.0
        else 0.0
      val upMbps =
        if (caps != null && caps.linkUpstreamBandwidthKbps > 0)
          caps.linkUpstreamBandwidthKbps / 1000.0
        else 0.0
      val netType =
        when {
          caps == null -> "offline"
          caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
          caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
          caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
          else -> "other"
        }
      obj.put("networkOnline", online)
      obj.put("downlinkMbps", Math.round(downMbps * 10.0) / 10.0)
      obj.put("uplinkMbps", Math.round(upMbps * 10.0) / 10.0)
      obj.put("networkType", netType)
    } catch (_: Exception) {}
    return obj.toString()
  }

  @JavascriptInterface
  fun requestLocation() {
    mainHandler.post {
      val hasCoarse =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
          PackageManager.PERMISSION_GRANTED
      if (!hasCoarse) {
        onRequestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION)) { results ->
          val granted = results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
          if (granted) {
            fetchBestLocation()
          } else {
            evalJs(
              "window.__jarvisNativeLocationError && window.__jarvisNativeLocationError('Location permission denied');"
            )
          }
        }
      } else {
        fetchBestLocation()
      }
    }
  }

  @SuppressLint("MissingPermission")
  private fun fetchBestLocation() {
    try {
      val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
      if (lm == null) {
        evalJs(
          "window.__jarvisNativeLocationError && window.__jarvisNativeLocationError('Location service unavailable');"
        )
        return
      }
      val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
      var best: Location? = null
      for (p in providers) {
        if (lm.isProviderEnabled(p)) {
          val loc = lm.getLastKnownLocation(p)
          if (loc != null && (best == null || loc.time > best.time)) {
            best = loc
          }
        }
      }
      if (best != null) {
        evalJs(
          "window.__jarvisNativeLocation && window.__jarvisNativeLocation(${best.latitude}, ${best.longitude});"
        )
        return
      }
      val activeProvider = providers.firstOrNull { lm.isProviderEnabled(it) }
      if (activeProvider == null) {
        evalJs(
          "window.__jarvisNativeLocationError && window.__jarvisNativeLocationError('Location providers are disabled');"
        )
        return
      }
      val listener =
        object : LocationListener {
          override fun onLocationChanged(location: Location) {
            lm.removeUpdates(this)
            activeLocationListener = null
            evalJs(
              "window.__jarvisNativeLocation && window.__jarvisNativeLocation(${location.latitude}, ${location.longitude});"
            )
          }
        }
      activeLocationListener = listener
      lm.requestLocationUpdates(activeProvider, 0L, 0f, listener, Looper.getMainLooper())
      mainHandler.postDelayed(
        {
          activeLocationListener?.let {
            lm.removeUpdates(it)
            activeLocationListener = null
            evalJs(
              "window.__jarvisNativeLocationError && window.__jarvisNativeLocationError('Location request timed out');"
            )
          }
        },
        8000L,
      )
    } catch (e: Exception) {
      val msg = JSONObject.quote(e.message ?: "Location error")
      evalJs("window.__jarvisNativeLocationError && window.__jarvisNativeLocationError($msg);")
    }
  }

  @JavascriptInterface
  fun showNotification(title: String, body: String) {
    mainHandler.post {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val granted =
          ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) {
          onRequestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS)) { results ->
            if (results[Manifest.permission.POST_NOTIFICATIONS] == true) {
              postNotification(title, body)
            }
          }
          return@post
        }
      }
      postNotification(title, body)
    }
  }

  private fun postNotification(title: String, body: String) {
    try {
      val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      val notification =
        NotificationCompat.Builder(context, CHANNEL_ID)
          .setSmallIcon(R.mipmap.ic_launcher)
          .setContentTitle(title)
          .setContentText(body)
          .setPriority(NotificationCompat.PRIORITY_HIGH)
          .setAutoCancel(true)
          .build()
      manager?.notify((System.currentTimeMillis() % 100000).toInt(), notification)
    } catch (_: Exception) {}
  }

  @JavascriptInterface
  fun openExternalUrl(url: String) {
    mainHandler.post {
      try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
      } catch (_: Exception) {}
    }
  }

  @JavascriptInterface
  fun setFullscreen(enabled: Boolean) {
    mainHandler.post { onToggleFullscreen(enabled) }
  }

  fun destroy() {
    mainHandler.post {
      try {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
      } catch (_: Exception) {}
    }
  }
}
