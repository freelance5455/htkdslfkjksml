package com.example.player

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

data class PlaybackState(
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val isLoaded: Boolean = false,
    val activeFile: File? = null,
    val volume: Float = 1.0f
)

class AudioPlayerManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "AudioPlayerManager"
    }

    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    fun loadFile(file: File, autoPlay: Boolean = false) {
        if (!file.exists() || file.length() == 0L) {
            Log.e(TAG, "Audio file does not exist or is empty: ${file.absolutePath}")
            return
        }

        releasePlayer()

        try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(context, Uri.fromFile(file))
                prepare()
                setVolume(_playbackState.value.volume, _playbackState.value.volume)

                setOnCompletionListener {
                    _playbackState.value = _playbackState.value.copy(
                        isPlaying = false,
                        currentPositionMs = duration.toLong()
                    )
                    stopProgressTracking()
                }

                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
                    _playbackState.value = _playbackState.value.copy(isPlaying = false)
                    stopProgressTracking()
                    true
                }
            }

            mediaPlayer = player
            val duration = player.duration.toLong().coerceAtLeast(0L)

            _playbackState.value = _playbackState.value.copy(
                isLoaded = true,
                isPlaying = false,
                currentPositionMs = 0L,
                totalDurationMs = duration,
                activeFile = file
            )

            if (autoPlay) {
                play()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load audio file in MediaPlayer", e)
        }
    }

    fun play() {
        val player = mediaPlayer ?: return
        try {
            if (!player.isPlaying) {
                player.start()
                _playbackState.value = _playbackState.value.copy(isPlaying = true)
                startProgressTracking()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio", e)
        }
    }

    fun pause() {
        val player = mediaPlayer ?: return
        try {
            if (player.isPlaying) {
                player.pause()
                _playbackState.value = _playbackState.value.copy(
                    isPlaying = false,
                    currentPositionMs = player.currentPosition.toLong()
                )
                stopProgressTracking()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error pausing audio", e)
        }
    }

    fun togglePlayPause() {
        if (_playbackState.value.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun seekTo(positionMs: Long) {
        val player = mediaPlayer ?: return
        try {
            val clamped = positionMs.coerceIn(0L, _playbackState.value.totalDurationMs)
            player.seekTo(clamped.toInt())
            _playbackState.value = _playbackState.value.copy(currentPositionMs = clamped)
        } catch (e: Exception) {
            Log.e(TAG, "Error seeking", e)
        }
    }

    fun seekBy(deltaMs: Long) {
        val current = _playbackState.value.currentPositionMs
        seekTo(current + deltaMs)
    }

    fun setVolume(volume: Float) {
        val clamped = volume.coerceIn(0f, 1f)
        try {
            mediaPlayer?.setVolume(clamped, clamped)
            _playbackState.value = _playbackState.value.copy(volume = clamped)
        } catch (e: Exception) {
            Log.e(TAG, "Error setting volume", e)
        }
    }

    private fun startProgressTracking() {
        stopProgressTracking()
        progressJob = scope.launch(Dispatchers.Main) {
            while (isActive && _playbackState.value.isPlaying) {
                mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        _playbackState.value = _playbackState.value.copy(
                            currentPositionMs = player.currentPosition.toLong()
                        )
                    }
                }
                delay(100L)
            }
        }
    }

    private fun stopProgressTracking() {
        progressJob?.cancel()
        progressJob = null
    }

    private fun releasePlayer() {
        stopProgressTracking()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing MediaPlayer: ${e.message}")
        }
        mediaPlayer = null
    }

    fun release() {
        releasePlayer()
        _playbackState.value = PlaybackState()
    }
}
