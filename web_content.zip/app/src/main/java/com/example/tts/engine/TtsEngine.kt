package com.example.tts.engine

import com.example.tts.model.VoiceInfo
import java.io.File

/**
 * Abstraction layer for Text-to-Speech engines.
 * Allows switching between Android on-device TTS, local/self-hosted engines (Piper/Sherpa),
 * or remote cloud TTS without rewriting the application logic.
 */
interface TtsEngine {
    val engineId: String
    val engineDisplayName: String
    val isReady: Boolean

    suspend fun initialize(): Boolean
    suspend fun getAvailableVoices(): List<VoiceInfo>
    suspend fun synthesizeChunk(
        text: String,
        voice: VoiceInfo,
        speed: Float,
        pitch: Float,
        outputFile: File
    ): Result<File>

    fun previewVoice(
        text: String,
        voice: VoiceInfo,
        speed: Float,
        pitch: Float,
        onDone: () -> Unit = {}
    )

    fun stopPreview()
    fun shutdown()
}
