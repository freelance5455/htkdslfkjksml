package com.example.tts.model

enum class NarrationArchetype(val displayName: String, val iconName: String) {
    DOCUMENTARY("Documentary & Lore", "HistoryEdu"),
    AUDIOBOOK("Audiobook & Story", "AutoStories"),
    EXPLAINER("YouTube & Explainer", "OndemandVideo"),
    BROADCAST("News & Broadcast", "Podcasts"),
    ATMOSPHERIC("Mystery & Sci-Fi", "Nightlight"),
    CONVERSATIONAL("Conversational", "ChatBubble"),
    ACADEMIC("Academic & Guide", "School"),
    DRAMATIC("Dramatic Theater", "TheaterComedy")
}

data class NarrationVoiceModel(
    val id: String,
    val name: String,
    val persona: String,
    val description: String,
    val archetype: NarrationArchetype,
    val gender: VoiceGender,
    val timbre: String,
    val defaultSpeed: Float,
    val defaultPitch: Float,
    val defaultPauseMs: Int,
    val showcaseSample: String,
    val targetLocale: String = "en-US",
    val preferredVoicePatterns: List<String> = emptyList(),
    val tags: List<String> = emptyList()
)

object NarrationVoiceModels {
    val models = listOf(
        NarrationVoiceModel(
            id = "model_atlas",
            name = "Atlas",
            persona = "Cinematic & Resonant Baritone",
            description = "Deep, commanding gravitas tailored for historical documentaries, oceanic mysteries, and investigative epics.",
            archetype = NarrationArchetype.DOCUMENTARY,
            gender = VoiceGender.MALE,
            timbre = "Deep Baritone • Authoritative",
            defaultSpeed = 0.95f,
            defaultPitch = 0.85f,
            defaultPauseMs = 350,
            showcaseSample = "Deep beneath the western Pacific, the abyss remains shrouded in perpetual silence and immense pressure.",
            targetLocale = "en-US",
            preferredVoicePatterns = listOf("en-us-x-tpd", "male", "en-us-x-sfg"),
            tags = listOf("Documentary", "History", "Deep Tone", "Cinematic")
        ),
        NarrationVoiceModel(
            id = "model_eleanor",
            name = "Eleanor",
            persona = "Warm Storyteller & Melodic Cadence",
            description = "Gentle, expressive cadence with rich literary pacing. Crafted for fiction audiobooks, fantasy epics, and bedtime stories.",
            archetype = NarrationArchetype.AUDIOBOOK,
            gender = VoiceGender.FEMALE,
            timbre = "Warm Alto • Expressive",
            defaultSpeed = 1.0f,
            defaultPitch = 1.05f,
            defaultPauseMs = 300,
            showcaseSample = "The cobblestone streets of Prague glistened in the evening twilight as Master Mikuláš turned the ancient key.",
            targetLocale = "en-US",
            preferredVoicePatterns = listOf("en-us-x-sfg", "female", "en-us-x-tpd"),
            tags = listOf("Audiobook", "Storytelling", "Warm", "Fiction")
        ),
        NarrationVoiceModel(
            id = "model_nova",
            name = "Nova",
            persona = "Energetic & Articulate Video Essayist",
            description = "High-retention modern delivery engineered for YouTube scripts, viral explainers, and fast-paced tech reviews.",
            archetype = NarrationArchetype.EXPLAINER,
            gender = VoiceGender.FEMALE,
            timbre = "Bright Soprano • Engaging",
            defaultSpeed = 1.10f,
            defaultPitch = 1.02f,
            defaultPauseMs = 200,
            showcaseSample = "Welcome back to Apex Tech! Today we are decoding quantum computing into simple, intuitive concepts.",
            targetLocale = "en-US",
            preferredVoicePatterns = listOf("female", "en-us-x-sfg"),
            tags = listOf("YouTube", "Tech Explainer", "High Energy", "Modern")
        ),
        NarrationVoiceModel(
            id = "model_sterling",
            name = "Sterling",
            persona = "Authoritative Broadcast Anchor",
            description = "Crisp, balanced diction for morning news digests, financial briefings, white papers, and corporate narrations.",
            archetype = NarrationArchetype.BROADCAST,
            gender = VoiceGender.MALE,
            timbre = "Crisp Tenor • Objective",
            defaultSpeed = 1.05f,
            defaultPitch = 0.95f,
            defaultPauseMs = 220,
            showcaseSample = "Global financial markets opened higher this morning as manufacturing indices posted resilient quarterly gains.",
            targetLocale = "en-US",
            preferredVoicePatterns = listOf("male", "en-us-x-tpd"),
            tags = listOf("Broadcast", "News", "Business", "Neutral")
        ),
        NarrationVoiceModel(
            id = "model_orion",
            name = "Orion",
            persona = "Low-Frequency Ambient Narrator",
            description = "Atmospheric gravitas with measured pauses. Perfect for sci-fi lore, psychological thrillers, and cosmic stories.",
            archetype = NarrationArchetype.ATMOSPHERIC,
            gender = VoiceGender.MALE,
            timbre = "Smoky Bass • Deliberate",
            defaultSpeed = 0.90f,
            defaultPitch = 0.80f,
            defaultPauseMs = 420,
            showcaseSample = "At the edge of the charted universe, an ancient beacon pulsed through the infinite cold vacuum of space.",
            targetLocale = "en-US",
            preferredVoicePatterns = listOf("male", "en-us-x-tpd"),
            tags = listOf("Sci-Fi", "Mystery", "Atmospheric", "Slow Pace")
        ),
        NarrationVoiceModel(
            id = "model_aria",
            name = "Aria",
            persona = "Intimate Companion & Podcast Host",
            description = "Natural conversational inflection and soothing presence. Suited for guided mindfulness, personal essays, and lifestyle podcasts.",
            archetype = NarrationArchetype.CONVERSATIONAL,
            gender = VoiceGender.FEMALE,
            timbre = "Silky & Intimate • Conversational",
            defaultSpeed = 0.98f,
            defaultPitch = 1.08f,
            defaultPauseMs = 260,
            showcaseSample = "Take a slow, deep breath. Today, give yourself permission to step back and reflect on your journey.",
            targetLocale = "en-US",
            preferredVoicePatterns = listOf("female", "en-us-x-sfg"),
            tags = listOf("Podcast", "Lifestyle", "Relaxing", "Intimate")
        ),
        NarrationVoiceModel(
            id = "model_arthur",
            name = "Arthur",
            persona = "Scholarly & Measured Professor",
            description = "Patient enunciation and scholarly warmth. Ideal for online courses, scientific lectures, and technical tutorials.",
            archetype = NarrationArchetype.ACADEMIC,
            gender = VoiceGender.MALE,
            timbre = "Warm Baritone • Scholarly",
            defaultSpeed = 0.95f,
            defaultPitch = 0.92f,
            defaultPauseMs = 300,
            showcaseSample = "Consider the fundamental laws of thermodynamics: energy can neither be created nor destroyed, merely transformed.",
            targetLocale = "en-US",
            preferredVoicePatterns = listOf("male", "en-us-x-tpd"),
            tags = listOf("Education", "Academic", "Tutorial", "Patient")
        ),
        NarrationVoiceModel(
            id = "model_seraphina",
            name = "Seraphina",
            persona = "Theatrical Performing Artist",
            description = "Vibrant emotional dynamic range for radio dramas, character monologues, poetic narratives, and high fantasy dialogues.",
            archetype = NarrationArchetype.DRAMATIC,
            gender = VoiceGender.FEMALE,
            timbre = "Rich Mezzo • Theatrical",
            defaultSpeed = 1.02f,
            defaultPitch = 1.12f,
            defaultPauseMs = 320,
            showcaseSample = "The thunder cracked across the jagged cliffs, answering the battle cry of the forgotten guardian.",
            targetLocale = "en-US",
            preferredVoicePatterns = listOf("female", "en-us-x-sfg"),
            tags = listOf("Dramatic", "Character", "Poetry", "Emotional")
        )
    )

    fun findModelForVoice(voice: VoiceInfo?): NarrationVoiceModel? {
        if (voice == null) return null
        return models.find { model ->
            voice.id.contains(model.name, ignoreCase = true) ||
            model.preferredVoicePatterns.any { pattern -> voice.id.contains(pattern, ignoreCase = true) }
        } ?: models.firstOrNull { it.gender == voice.gender }
    }

    fun resolveBestSystemVoice(model: NarrationVoiceModel, availableVoices: List<VoiceInfo>): VoiceInfo? {
        if (availableVoices.isEmpty()) return null

        // Try exact match on name/id
        availableVoices.find { it.id.contains(model.name, ignoreCase = true) }?.let { return it }

        // Try preferred patterns matching gender and locale
        val matchingLocale = availableVoices.filter { 
            it.localeTag.startsWith(model.targetLocale.take(2), ignoreCase = true) 
        }

        val pool = if (matchingLocale.isNotEmpty()) matchingLocale else availableVoices

        for (pattern in model.preferredVoicePatterns) {
            val matched = pool.find { 
                it.id.contains(pattern, ignoreCase = true) && (model.gender == VoiceGender.NEUTRAL || it.gender == model.gender)
            }
            if (matched != null) return matched
        }

        // Fallback by gender
        val byGender = pool.find { it.gender == model.gender }
        if (byGender != null) return byGender

        return pool.firstOrNull()
    }
}
