package com.example.tts.engine

import android.content.Context
import com.example.tts.model.VoiceGender
import com.example.tts.model.VoiceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * Open-Source / Self-Hosted REST API TTS Engine (compatible with Piper HTTP server,
 * Kokoro, XTTS v2, and OpenAI-compatible speech endpoints).
 */
class CustomApiTtsEngine(
    var endpointUrl: String = "http://127.0.0.1:5000/v1/audio/speech",
    var apiKey: String = ""
) : TtsEngine {

    override val engineId: String = "custom_api_tts"
    override val engineDisplayName: String = "Self-Hosted / Open-Source Engine (Piper / Kokoro / XTTS)"

    override var isReady: Boolean = true
        private set

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    override suspend fun initialize(): Boolean {
        isReady = endpointUrl.isNotBlank()
        return isReady
    }

    override suspend fun getAvailableVoices(): List<VoiceInfo> {
        return listOf(
            VoiceInfo("alloy", "Alloy (Neutral Narrator)", "en-US", "English (US)", VoiceGender.NEUTRAL, true, "Studio Neural"),
            VoiceInfo("echo", "Echo (Deep Male)", "en-US", "English (US)", VoiceGender.MALE, true, "Studio Neural"),
            VoiceInfo("fable", "Fable (Warm Storyteller)", "en-GB", "English (UK)", VoiceGender.NEUTRAL, true, "Studio Neural"),
            VoiceInfo("onyx", "Onyx (Authoritative Male)", "en-US", "English (US)", VoiceGender.MALE, true, "Studio Neural"),
            VoiceInfo("nova", "Nova (Expressive Female)", "en-US", "English (US)", VoiceGender.FEMALE, true, "Studio Neural"),
            VoiceInfo("shimmer", "Shimmer (Clear Female)", "en-US", "English (US)", VoiceGender.FEMALE, true, "Studio Neural")
        )
    }

    override suspend fun synthesizeChunk(
        text: String,
        voice: VoiceInfo,
        speed: Float,
        pitch: Float,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject().apply {
                put("model", "tts-1")
                put("input", text)
                put("voice", voice.id)
                put("speed", speed.toDouble())
                put("response_format", "wav")
            }

            val requestBuilder = Request.Builder()
                .url(endpointUrl)
                .post(json.toString().toRequestBody("application/json".toMediaTypeOrNull()))

            if (apiKey.isNotBlank()) {
                requestBuilder.addHeader("Authorization", "Bearer $apiKey")
            }

            val response = httpClient.newCall(requestBuilder.build()).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(
                    IllegalStateException("Server returned HTTP ${response.code}: ${response.message}")
                )
            }

            val body = response.body ?: return@withContext Result.failure(IllegalStateException("Empty response from server"))
            outputFile.parentFile?.mkdirs()
            FileOutputStream(outputFile).use { fos ->
                body.byteStream().use { input ->
                    input.copyTo(fos)
                }
            }
            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override fun previewVoice(
        text: String,
        voice: VoiceInfo,
        speed: Float,
        pitch: Float,
        onDone: () -> Unit
    ) {
        // Can be previewed through custom stream or left to onDone
        onDone()
    }

    override fun stopPreview() {}

    override fun shutdown() {}
}
