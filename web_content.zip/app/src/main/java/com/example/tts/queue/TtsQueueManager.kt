package com.example.tts.queue

import android.content.Context
import android.util.Log
import com.example.tts.AudioStitcher
import com.example.tts.engine.TtsEngine
import com.example.tts.model.ChunkStatus
import com.example.tts.model.TtsChunk
import com.example.tts.model.VoiceInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class QueueProgressState(
    val isRunning: Boolean = false,
    val currentChunkIndex: Int = 0,
    val totalChunks: Int = 0,
    val progressPercentage: Int = 0,
    val currentSectionPreview: String = "",
    val estimatedRemainingSeconds: Long = 0L,
    val chunks: List<TtsChunk> = emptyList(),
    val completedMasterFile: File? = null,
    val totalAudioDurationMs: Long = 0L,
    val failedChunkIndex: Int? = null,
    val errorMessage: String? = null
)

class TtsQueueManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    companion object {
        private const val TAG = "TtsQueueManager"
        private const val MAX_RETRIES = 2
    }

    private val _queueState = MutableStateFlow(QueueProgressState())
    val queueState: StateFlow<QueueProgressState> = _queueState.asStateFlow()

    private var activeJob: Job? = null
    private var currentEngine: TtsEngine? = null
    private var currentVoice: VoiceInfo? = null
    private var currentSpeed: Float = 1.0f
    private var currentPitch: Float = 1.0f
    private var currentPauseBetweenChunksMs: Int = 250
    private var targetOutputFile: File? = null

    fun startQueue(
        chunks: List<TtsChunk>,
        engine: TtsEngine,
        voice: VoiceInfo,
        speed: Float,
        pitch: Float,
        pauseBetweenChunksMs: Int,
        outputFile: File
    ) {
        cancelQueue()

        currentEngine = engine
        currentVoice = voice
        currentSpeed = speed
        currentPitch = pitch
        currentPauseBetweenChunksMs = pauseBetweenChunksMs
        targetOutputFile = outputFile

        val initialChunks = chunks.map { it.copy(status = ChunkStatus.PENDING, errorMessage = null) }

        _queueState.value = QueueProgressState(
            isRunning = true,
            currentChunkIndex = 0,
            totalChunks = initialChunks.size,
            progressPercentage = 0,
            currentSectionPreview = initialChunks.firstOrNull()?.text?.take(80) ?: "",
            chunks = initialChunks
        )

        activeJob = scope.launch(Dispatchers.IO) {
            processQueueInternal(initialChunks)
        }
    }

    fun retryFailedChunk(chunkIndex: Int) {
        val currentState = _queueState.value
        val chunks = currentState.chunks.toMutableList()
        if (chunkIndex in chunks.indices) {
            chunks[chunkIndex] = chunks[chunkIndex].copy(
                status = ChunkStatus.PENDING,
                errorMessage = null,
                retryCount = 0
            )

            _queueState.value = currentState.copy(
                isRunning = true,
                failedChunkIndex = null,
                errorMessage = null,
                chunks = chunks
            )

            activeJob?.cancel()
            activeJob = scope.launch(Dispatchers.IO) {
                processQueueInternal(chunks)
            }
        }
    }

    private suspend fun processQueueInternal(inputChunks: List<TtsChunk>) {
        val engine = currentEngine ?: return
        val voice = currentVoice ?: return
        val outputFile = targetOutputFile ?: return

        val chunks = inputChunks.map { it.copy() }.toMutableList()
        val tempDir = File(context.cacheDir, "tts_chunks_${System.currentTimeMillis()}").apply { mkdirs() }

        val startTimeMs = System.currentTimeMillis()
        var completedChunksCount = chunks.count { it.status == ChunkStatus.COMPLETED }

        try {
            for (i in chunks.indices) {
                if (!coroutineScopeActive()) break

                val chunk = chunks[i]
                if (chunk.status == ChunkStatus.COMPLETED && chunk.audioFile?.exists() == true) {
                    continue
                }

                // Update current chunk to processing
                chunk.status = ChunkStatus.PROCESSING
                chunk.errorMessage = null
                chunks[i] = chunk

                val elapsed = System.currentTimeMillis() - startTimeMs
                val avgTimePerChunk = if (completedChunksCount > 0) elapsed / completedChunksCount else 1800L
                val remainingChunks = (chunks.size - completedChunksCount).coerceAtLeast(0)
                val etaSeconds = (remainingChunks * avgTimePerChunk) / 1000L

                val progress = if (chunks.isNotEmpty()) (completedChunksCount * 90) / chunks.size else 0

                _queueState.value = _queueState.value.copy(
                    isRunning = true,
                    currentChunkIndex = i,
                    totalChunks = chunks.size,
                    progressPercentage = progress,
                    currentSectionPreview = chunk.text.take(90),
                    estimatedRemainingSeconds = etaSeconds,
                    chunks = chunks.toList(),
                    failedChunkIndex = null,
                    errorMessage = null
                )

                val chunkFile = File(tempDir, "chunk_${i}.wav")
                var synthesisSuccess = false
                var lastError: String? = null

                while (chunk.retryCount <= MAX_RETRIES && !synthesisSuccess && coroutineScopeActive()) {
                    val result = engine.synthesizeChunk(
                        text = chunk.text,
                        voice = voice,
                        speed = currentSpeed,
                        pitch = currentPitch,
                        outputFile = chunkFile
                    )

                    if (result.isSuccess && chunkFile.exists() && chunkFile.length() > 44) {
                        synthesisSuccess = true
                        chunk.audioFile = chunkFile
                        chunk.durationMs = AudioStitcher.getAudioDurationMs(chunkFile)
                        chunk.status = ChunkStatus.COMPLETED
                        chunk.errorMessage = null
                        completedChunksCount++
                    } else {
                        chunk.retryCount++
                        lastError = result.exceptionOrNull()?.message ?: "Synthesis failed for segment $i"
                        Log.w(TAG, "Chunk $i failed (attempt ${chunk.retryCount}): $lastError")
                    }
                }

                if (!synthesisSuccess) {
                    chunk.status = ChunkStatus.FAILED
                    chunk.errorMessage = lastError ?: "Failed after $MAX_RETRIES retries"
                    chunks[i] = chunk

                    _queueState.value = _queueState.value.copy(
                        isRunning = false,
                        failedChunkIndex = i,
                        errorMessage = "Chunk ${i + 1} of ${chunks.size} failed: ${chunk.errorMessage}. Tap Retry to resume.",
                        chunks = chunks.toList()
                    )
                    return
                }

                chunks[i] = chunk
            }

            // All chunks completed successfully, now stitch
            _queueState.value = _queueState.value.copy(
                progressPercentage = 95,
                currentSectionPreview = "Stitching master audio file...",
                estimatedRemainingSeconds = 1L
            )

            val chunkAudioFiles = chunks.mapNotNull { it.audioFile }
            val stitchResult = AudioStitcher.stitchWavFiles(
                chunkFiles = chunkAudioFiles,
                outputFile = outputFile,
                pauseBetweenChunksMs = currentPauseBetweenChunksMs
            )

            if (stitchResult.isSuccess) {
                val totalDuration = AudioStitcher.getAudioDurationMs(outputFile)
                // Clean up temporary chunk files safely
                tempDir.deleteRecursively()

                _queueState.value = _queueState.value.copy(
                    isRunning = false,
                    progressPercentage = 100,
                    currentSectionPreview = "Generation Complete!",
                    estimatedRemainingSeconds = 0L,
                    chunks = chunks.toList(),
                    completedMasterFile = outputFile,
                    totalAudioDurationMs = totalDuration,
                    failedChunkIndex = null,
                    errorMessage = null
                )
            } else {
                _queueState.value = _queueState.value.copy(
                    isRunning = false,
                    errorMessage = "Failed to stitch audio files: ${stitchResult.exceptionOrNull()?.message}"
                )
            }

        } catch (e: CancellationException) {
            Log.d(TAG, "Queue cancelled")
            tempDir.deleteRecursively()
            _queueState.value = _queueState.value.copy(isRunning = false)
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error in TTS queue", e)
            _queueState.value = _queueState.value.copy(
                isRunning = false,
                errorMessage = "Queue error: ${e.message}"
            )
        }
    }

    private suspend fun coroutineScopeActive(): Boolean = withContext(Dispatchers.IO) {
        kotlin.coroutines.coroutineContext.isActive
    }

    fun cancelQueue() {
        activeJob?.cancel()
        activeJob = null
        _queueState.value = _queueState.value.copy(isRunning = false)
    }

    fun resetState() {
        cancelQueue()
        _queueState.value = QueueProgressState()
    }
}
