package com.example.tts.model

import java.io.File

enum class VoiceGender {
    MALE,
    FEMALE,
    NEUTRAL
}

data class VoiceInfo(
    val id: String,
    val displayName: String,
    val localeTag: String,
    val languageDisplayName: String,
    val gender: VoiceGender = VoiceGender.NEUTRAL,
    val isNetworkRequired: Boolean = false,
    val quality: String = "High",
    val enginePackage: String = ""
)

enum class ChunkStatus {
    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}

data class TtsChunk(
    val index: Int,
    val text: String,
    var audioFile: File? = null,
    var durationMs: Long = 0L,
    var status: ChunkStatus = ChunkStatus.PENDING,
    var errorMessage: String? = null,
    var retryCount: Int = 0
)
