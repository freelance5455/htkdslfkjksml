package com.example.tts.engine

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.tts.model.VoiceGender
import com.example.tts.model.VoiceInfo
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import java.util.UUID

class AndroidSystemTtsEngine(private val context: Context) : TtsEngine {

    companion object {
        private const val TAG = "AndroidSystemTtsEngine"
        private const val CHUNK_SYNTHESIS_TIMEOUT_MS = 30_000L
    }

    override val engineId: String = "android_system_tts"
    override val engineDisplayName: String = "System Studio Engine (On-Device Unlimited)"

    private var textToSpeech: TextToSpeech? = null
    private val initDeferred = CompletableDeferred<Boolean>()
    private val mutex = Mutex()

    @Volatile
    override var isReady: Boolean = false
        private set

    private val activeUtteranceCallbacks = mutableMapOf<String, UtteranceCallback>()
    private var previewDoneCallback: (() -> Unit)? = null

    private data class UtteranceCallback(
        val onDone: () -> Unit,
        val onError: (String) -> Unit
    )

    override suspend fun initialize(): Boolean = withContext(Dispatchers.Main) {
        if (isReady && textToSpeech != null) return@withContext true

        try {
            textToSpeech = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            Log.d(TAG, "Synthesis started: $utteranceId")
                        }

                        override fun onDone(utteranceId: String?) {
                            Log.d(TAG, "Synthesis done: $utteranceId")
                            if (utteranceId?.startsWith("preview_") == true) {
                                previewDoneCallback?.invoke()
                                previewDoneCallback = null
                            } else if (utteranceId != null) {
                                activeUtteranceCallbacks.remove(utteranceId)?.onDone?.invoke()
                            }
                        }

                        override fun onError(utteranceId: String?) {
                            onError(utteranceId, TextToSpeech.ERROR)
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            Log.e(TAG, "Synthesis error for $utteranceId code: $errorCode")
                            if (utteranceId?.startsWith("preview_") == true) {
                                previewDoneCallback?.invoke()
                                previewDoneCallback = null
                            } else if (utteranceId != null) {
                                val errorDesc = when (errorCode) {
                                    TextToSpeech.ERROR_SYNTHESIS -> "Speech synthesis failed"
                                    TextToSpeech.ERROR_SERVICE -> "TTS service disconnected"
                                    TextToSpeech.ERROR_OUTPUT -> "Audio output device error"
                                    TextToSpeech.ERROR_NETWORK -> "Network required for this voice"
                                    TextToSpeech.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                                    TextToSpeech.ERROR_INVALID_REQUEST -> "Invalid TTS request"
                                    TextToSpeech.ERROR_NOT_INSTALLED_YET -> "Voice data not installed"
                                    else -> "Synthesis error code: $errorCode"
                                }
                                activeUtteranceCallbacks.remove(utteranceId)?.onError?.invoke(errorDesc)
                            }
                        }
                    })
                    isReady = true
                    initDeferred.complete(true)
                } else {
                    Log.e(TAG, "TTS Initialization failed status: $status")
                    isReady = false
                    initDeferred.complete(false)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception initializing TTS", e)
            initDeferred.complete(false)
        }

        withTimeoutOrNull(8000L) {
            initDeferred.await()
        } ?: false
    }

    override suspend fun getAvailableVoices(): List<VoiceInfo> = withContext(Dispatchers.Default) {
        if (!isReady) {
            initialize()
        }
        val tts = textToSpeech ?: return@withContext emptyList()

        try {
            val systemVoices = tts.voices
            if (systemVoices.isNullOrEmpty()) {
                // Fallback to default locale
                val defaultLocale = tts.defaultVoice?.locale ?: Locale.getDefault()
                return@withContext listOf(
                    VoiceInfo(
                        id = "default",
                        displayName = "Default Device Voice (${defaultLocale.displayLanguage})",
                        localeTag = defaultLocale.toLanguageTag(),
                        languageDisplayName = defaultLocale.displayName,
                        gender = VoiceGender.NEUTRAL,
                        isNetworkRequired = false,
                        quality = "Standard"
                    )
                )
            }

            return@withContext systemVoices
                .filter { !it.isNetworkConnectionRequired || true } // keep all voices
                .map { voice ->
                    val nameLower = voice.name.lowercase(Locale.ROOT)
                    val gender = when {
                        nameLower.contains("female") || nameLower.contains("-f-") || nameLower.contains("woman") -> VoiceGender.FEMALE
                        nameLower.contains("male") || nameLower.contains("-m-") || nameLower.contains("man") -> VoiceGender.MALE
                        else -> VoiceGender.NEUTRAL
                    }

                    val quality = when (voice.quality) {
                        Voice.QUALITY_VERY_HIGH -> "Studio Ultra HD"
                        Voice.QUALITY_HIGH -> "Studio High"
                        Voice.QUALITY_NORMAL -> "Natural"
                        Voice.QUALITY_LOW -> "Compact"
                        else -> "Standard"
                    }

                    // Format readable display name
                    val lang = voice.locale.displayLanguage
                    val country = voice.locale.displayCountry
                    val subName = voice.name.substringAfterLast("/").substringAfterLast(":")
                    val prettyName = if (country.isNotBlank()) "$lang ($country) • $subName" else "$lang • $subName"

                    VoiceInfo(
                        id = voice.name,
                        displayName = prettyName,
                        localeTag = voice.locale.toLanguageTag(),
                        languageDisplayName = "$lang ${if (country.isNotBlank()) "($country)" else ""}".trim(),
                        gender = gender,
                        isNetworkRequired = voice.isNetworkConnectionRequired,
                        quality = quality,
                        enginePackage = ""
                    )
                }
                .sortedWith(
                    compareBy<VoiceInfo> { it.languageDisplayName }
                        .thenBy { it.gender.name }
                        .thenBy { it.displayName }
                )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to query TTS voices", e)
            emptyList()
        }
    }

    override suspend fun synthesizeChunk(
        text: String,
        voice: VoiceInfo,
        speed: Float,
        pitch: Float,
        outputFile: File
    ): Result<File> = withContext(Dispatchers.IO) {
        if (!isReady) {
            val initialized = initialize()
            if (!initialized) {
                return@withContext Result.failure(IllegalStateException("TTS Engine failed to initialize on device"))
            }
        }
        val tts = textToSpeech
            ?: return@withContext Result.failure(IllegalStateException("TTS instance is null"))

        mutex.withLock {
            val utteranceId = "chunk_${UUID.randomUUID()}"
            val completionDeferred = CompletableDeferred<Result<File>>()

            // Configure voice, speed, pitch
            withContext(Dispatchers.Main) {
                try {
                    tts.setSpeechRate(speed.coerceIn(0.5f, 2.5f))
                    tts.setPitch(pitch.coerceIn(0.5f, 2.0f))

                    // Find and set matching voice if possible
                    if (voice.id.isNotBlank() && voice.id != "default") {
                        val matchingVoice = tts.voices?.find { it.name == voice.id }
                        if (matchingVoice != null) {
                            tts.voice = matchingVoice
                        } else {
                            val locale = Locale.forLanguageTag(voice.localeTag)
                            tts.language = locale
                        }
                    } else {
                        val locale = Locale.forLanguageTag(voice.localeTag)
                        tts.language = locale
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error configuring TTS params: ${e.message}")
                }
            }

            activeUtteranceCallbacks[utteranceId] = UtteranceCallback(
                onDone = {
                    if (outputFile.exists() && outputFile.length() > 44) {
                        completionDeferred.complete(Result.success(outputFile))
                    } else {
                        completionDeferred.complete(Result.failure(IllegalStateException("Output audio file is missing or empty")))
                    }
                },
                onError = { reason ->
                    completionDeferred.complete(Result.failure(IllegalStateException("TTS synthesis failed: $reason")))
                }
            )

            if (outputFile.exists()) {
                outputFile.delete()
            }
            outputFile.parentFile?.mkdirs()

            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            }

            val result = tts.synthesizeToFile(text, params, outputFile, utteranceId)
            if (result != TextToSpeech.SUCCESS) {
                activeUtteranceCallbacks.remove(utteranceId)
                return@withContext Result.failure(IllegalStateException("TTS synthesizeToFile returned error code: $result"))
            }

            val timeoutResult = withTimeoutOrNull(CHUNK_SYNTHESIS_TIMEOUT_MS) {
                completionDeferred.await()
            }

            activeUtteranceCallbacks.remove(utteranceId)

            return@withContext timeoutResult
                ?: Result.failure(IllegalStateException("Synthesis timed out after ${CHUNK_SYNTHESIS_TIMEOUT_MS / 1000} seconds for chunk"))
        }
    }

    override fun previewVoice(
        text: String,
        voice: VoiceInfo,
        speed: Float,
        pitch: Float,
        onDone: () -> Unit
    ) {
        val tts = textToSpeech ?: return
        if (!isReady) return

        try {
            stopPreview()
            previewDoneCallback = onDone
            tts.setSpeechRate(speed.coerceIn(0.5f, 2.5f))
            tts.setPitch(pitch.coerceIn(0.5f, 2.0f))

            if (voice.id.isNotBlank() && voice.id != "default") {
                val matchingVoice = tts.voices?.find { it.name == voice.id }
                if (matchingVoice != null) {
                    tts.voice = matchingVoice
                } else {
                    tts.language = Locale.forLanguageTag(voice.localeTag)
                }
            } else {
                tts.language = Locale.forLanguageTag(voice.localeTag)
            }

            val previewId = "preview_${System.currentTimeMillis()}"
            val params = Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, previewId)
            }

            val sample = if (text.isNotBlank()) {
                text.take(120)
            } else {
                "Hello, this is a sample preview of ${voice.displayName}."
            }

            tts.speak(sample, TextToSpeech.QUEUE_FLUSH, params, previewId)
        } catch (e: Exception) {
            Log.e(TAG, "Error in voice preview", e)
            onDone()
        }
    }

    override fun stopPreview() {
        try {
            textToSpeech?.stop()
            previewDoneCallback?.invoke()
            previewDoneCallback = null
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping preview: ${e.message}")
        }
    }

    override fun shutdown() {
        try {
            stopPreview()
            textToSpeech?.shutdown()
            textToSpeech = null
            isReady = false
        } catch (e: Exception) {
            Log.w(TAG, "Error shutting down TTS: ${e.message}")
        }
    }
}
