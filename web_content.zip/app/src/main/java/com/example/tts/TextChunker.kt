package com.example.tts

import com.example.tts.model.TtsChunk

object TextChunker {

    private const val TARGET_CHUNK_CHARS = 320
    private const val MAX_CHUNK_CHARS = 450

    /**
     * Splits long-form text into semantically cohesive chunks for TTS processing.
     * Respects paragraph and sentence boundaries so audio flows naturally without abrupt cuts.
     */
    fun chunkText(rawText: String): List<TtsChunk> {
        val cleanText = rawText.trim()
        if (cleanText.isEmpty()) return emptyList()

        val paragraphs = cleanText.split(Regex("(\r?\n)+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        val rawChunks = mutableListOf<String>()

        for (paragraph in paragraphs) {
            if (paragraph.length <= TARGET_CHUNK_CHARS) {
                rawChunks.add(paragraph)
            } else {
                // Split paragraph into sentences
                val sentences = splitIntoSentences(paragraph)
                var currentBuffer = StringBuilder()

                for (sentence in sentences) {
                    if (sentence.length > MAX_CHUNK_CHARS) {
                        // Very long sentence without punctuation, split at clause or word boundaries
                        if (currentBuffer.isNotEmpty()) {
                            rawChunks.add(currentBuffer.toString().trim())
                            currentBuffer = StringBuilder()
                        }
                        val subParts = splitLongSentence(sentence, TARGET_CHUNK_CHARS)
                        rawChunks.addAll(subParts)
                    } else if (currentBuffer.length + sentence.length + 1 <= TARGET_CHUNK_CHARS) {
                        if (currentBuffer.isNotEmpty()) currentBuffer.append(" ")
                        currentBuffer.append(sentence)
                    } else {
                        if (currentBuffer.isNotEmpty()) {
                            rawChunks.add(currentBuffer.toString().trim())
                        }
                        currentBuffer = StringBuilder(sentence)
                    }
                }
                if (currentBuffer.isNotEmpty()) {
                    rawChunks.add(currentBuffer.toString().trim())
                }
            }
        }

        return rawChunks
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .mapIndexed { index, chunkText ->
                TtsChunk(
                    index = index,
                    text = chunkText
                )
            }
    }

    private fun splitIntoSentences(text: String): List<String> {
        // Match sentence terminators (. ? ! ; :) followed by whitespace or end of string
        val pattern = Regex("(?<=[.?!;:])\\s+")
        return text.split(pattern).map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun splitLongSentence(sentence: String, maxChars: Int): List<String> {
        // Try splitting by commas first
        val clauses = sentence.split(Regex("(?<=,)\\s+"))
        val result = mutableListOf<String>()
        var buffer = StringBuilder()

        for (clause in clauses) {
            if (clause.length > maxChars) {
                if (buffer.isNotEmpty()) {
                    result.add(buffer.toString().trim())
                    buffer = StringBuilder()
                }
                // Fallback to word splitting
                val words = clause.split(Regex("\\s+"))
                var wordBuffer = StringBuilder()
                for (word in words) {
                    if (wordBuffer.length + word.length + 1 > maxChars && wordBuffer.isNotEmpty()) {
                        result.add(wordBuffer.toString().trim())
                        wordBuffer = StringBuilder(word)
                    } else {
                        if (wordBuffer.isNotEmpty()) wordBuffer.append(" ")
                        wordBuffer.append(word)
                    }
                }
                if (wordBuffer.isNotEmpty()) {
                    result.add(wordBuffer.toString().trim())
                }
            } else if (buffer.length + clause.length + 1 <= maxChars) {
                if (buffer.isNotEmpty()) buffer.append(" ")
                buffer.append(clause)
            } else {
                if (buffer.isNotEmpty()) {
                    result.add(buffer.toString().trim())
                }
                buffer = StringBuilder(clause)
            }
        }
        if (buffer.isNotEmpty()) {
            result.add(buffer.toString().trim())
        }
        return result
    }

    fun countWords(text: String): Int {
        if (text.isBlank()) return 0
        return text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.size
    }

    fun countCharacters(text: String): Int {
        return text.length
    }

    /**
     * Estimates audio duration in milliseconds based on average speaking rate (~150 WPM at 1.0x speed).
     */
    fun estimateDurationMs(wordCount: Int, speed: Float): Long {
        if (wordCount <= 0 || speed <= 0f) return 0L
        val effectiveSpeed = speed.coerceIn(0.5f, 3.0f)
        val minutes = (wordCount.toDouble() / 150.0) / effectiveSpeed
        return (minutes * 60.0 * 1000.0).toLong()
    }

    fun formatDuration(durationMs: Long): String {
        val totalSeconds = (durationMs / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }
}
