package com.example.tts

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

object AudioStitcher {

    data class WavHeaderInfo(
        val channels: Short,
        val sampleRate: Int,
        val byteRate: Int,
        val blockAlign: Short,
        val bitsPerSample: Short,
        val dataOffset: Int,
        val dataSize: Int
    )

    /**
     * Parses the RIFF WAV file to find audio format and where PCM data begins.
     */
    fun parseWavHeader(file: File): WavHeaderInfo? {
        if (!file.exists() || file.length() < 44) return null
        return try {
            val bytes = ByteArray(minOf(file.length().toInt(), 1024))
            FileInputStream(file).use { it.read(bytes) }

            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

            // Check RIFF
            val riff = String(bytes, 0, 4)
            if (riff != "RIFF") return null

            // Check WAVE
            val wave = String(bytes, 8, 4)
            if (wave != "WAVE") return null

            // Scan chunks for 'fmt ' and 'data'
            var offset = 12
            var channels: Short = 1
            var sampleRate = 22050
            var byteRate = sampleRate * 2
            var blockAlign: Short = 2
            var bitsPerSample: Short = 16
            var dataOffset = -1
            var dataSize = 0

            while (offset + 8 <= bytes.size) {
                val chunkId = String(bytes, offset, 4)
                val chunkSize = buffer.getInt(offset + 4)
                val chunkDataStart = offset + 8

                if (chunkId == "fmt ") {
                    channels = buffer.getShort(chunkDataStart + 2)
                    sampleRate = buffer.getInt(chunkDataStart + 4)
                    byteRate = buffer.getInt(chunkDataStart + 8)
                    blockAlign = buffer.getShort(chunkDataStart + 12)
                    bitsPerSample = buffer.getShort(chunkDataStart + 14)
                } else if (chunkId == "data") {
                    dataOffset = chunkDataStart
                    dataSize = chunkSize
                    break
                }
                offset = chunkDataStart + chunkSize
            }

            if (dataOffset == -1) {
                // Standard fallback at 44 bytes
                dataOffset = 44
                dataSize = (file.length() - 44).toInt()
            }

            WavHeaderInfo(
                channels = channels,
                sampleRate = sampleRate,
                byteRate = byteRate,
                blockAlign = blockAlign,
                bitsPerSample = bitsPerSample,
                dataOffset = dataOffset,
                dataSize = dataSize
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Stitches multiple RIFF WAV chunks sequentially into a single cohesive master WAV file.
     * Inserts optional zero-amplitude PCM silence between sentences/chunks for natural cadence.
     */
    fun stitchWavFiles(
        chunkFiles: List<File>,
        outputFile: File,
        pauseBetweenChunksMs: Int = 200,
        onProgress: (progressPercent: Int) -> Unit = {}
    ): Result<File> {
        if (chunkFiles.isEmpty()) {
            return Result.failure(IllegalArgumentException("No audio chunks to stitch"))
        }

        // Filter valid existing files
        val validFiles = chunkFiles.filter { it.exists() && it.length() > 44 }
        if (validFiles.isEmpty()) {
            return Result.failure(IllegalStateException("No valid WAV files generated"))
        }

        val baseHeader = parseWavHeader(validFiles.first())
            ?: return Result.failure(IllegalStateException("Failed to parse WAV header from first chunk"))

        if (outputFile.exists()) {
            outputFile.delete()
        }
        outputFile.parentFile?.mkdirs()

        try {
            var totalPcmBytes = 0L

            // Silence buffer
            val bytesPerSample = baseHeader.bitsPerSample / 8
            val silenceBytesCount = if (pauseBetweenChunksMs > 0) {
                (baseHeader.sampleRate.toLong() * baseHeader.channels * bytesPerSample * pauseBetweenChunksMs / 1000).toInt()
            } else 0
            val silenceBuffer = if (silenceBytesCount > 0) ByteArray(silenceBytesCount) else null

            FileOutputStream(outputFile).use { fos ->
                BufferedOutputStream(fos, 64 * 1024).use { bos ->
                    // Reserve 44 bytes for RIFF header
                    bos.write(ByteArray(44))

                    val readBuffer = ByteArray(16 * 1024)

                    validFiles.forEachIndexed { index, file ->
                        val header = parseWavHeader(file) ?: baseHeader
                        FileInputStream(file).use { fis ->
                            BufferedInputStream(fis, 32 * 1024).use { bis ->
                                // Skip to data chunk
                                bis.skip(header.dataOffset.toLong())

                                var read: Int
                                while (bis.read(readBuffer).also { read = it } != -1) {
                                    bos.write(readBuffer, 0, read)
                                    totalPcmBytes += read
                                }
                            }
                        }

                        // Insert natural silence between chunks (except after the final chunk)
                        if (silenceBuffer != null && index < validFiles.size - 1) {
                            bos.write(silenceBuffer)
                            totalPcmBytes += silenceBuffer.size
                        }

                        val progress = ((index + 1) * 100) / validFiles.size
                        onProgress(progress)
                    }
                    bos.flush()
                }
            }

            // Write final RIFF WAVE 44-byte header
            RandomAccessFile(outputFile, "rw").use { raf ->
                raf.seek(0)
                val headerBytes = createWavHeader(
                    totalAudioLen = totalPcmBytes,
                    totalDataLen = totalPcmBytes + 36,
                    longSampleRate = baseHeader.sampleRate.toLong(),
                    channels = baseHeader.channels.toInt(),
                    byteRate = baseHeader.byteRate.toLong(),
                    bitsPerSample = baseHeader.bitsPerSample.toInt()
                )
                raf.write(headerBytes)
            }

            return Result.success(outputFile)
        } catch (e: Exception) {
            outputFile.delete()
            return Result.failure(e)
        }
    }

    private fun createWavHeader(
        totalAudioLen: Long,
        totalDataLen: Long,
        longSampleRate: Long,
        channels: Int,
        byteRate: Long,
        bitsPerSample: Int
    ): ByteArray {
        val header = ByteArray(44)
        val buffer = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)

        // RIFF/WAVE header
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()

        buffer.putInt(4, totalDataLen.toInt())

        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()

        // 'fmt ' chunk
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()

        buffer.putInt(16, 16) // Subchunk1Size for PCM
        buffer.putShort(20, 1) // AudioFormat 1 = PCM
        buffer.putShort(22, channels.toShort())
        buffer.putInt(24, longSampleRate.toInt())
        buffer.putInt(28, byteRate.toInt())
        buffer.putShort(32, (channels * bitsPerSample / 8).toShort()) // BlockAlign
        buffer.putShort(34, bitsPerSample.toShort()) // BitsPerSample

        // 'data' chunk
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()

        buffer.putInt(40, totalAudioLen.toInt())

        return header
    }

    /**
     * Computes audio duration in milliseconds from a WAV file.
     */
    fun getAudioDurationMs(file: File): Long {
        val header = parseWavHeader(file) ?: return 0L
        if (header.byteRate <= 0) return 0L
        val pcmSize = file.length() - header.dataOffset
        return (pcmSize * 1000L) / header.byteRate
    }
}
