package com.example.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object DeviceToolsManager {

    private const val TAG = "RaynoxDeviceTools"

    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    private var isTorchCallbackRegistered = false

    data class BatteryInfo(
        val percentage: Int,
        val isCharging: Boolean,
        val powerSource: String,
        val health: String,
        val temperatureCelsius: Float
    )

    data class VolumeInfo(
        val musicVolume: Int,
        val maxMusicVolume: Int,
        val ringerMode: String // "Normal", "Vibrate", "Silent"
    )

    data class DeviceActionResult(
        val isHandled: Boolean,
        val feedbackMessage: String,
        val actionType: String
    )

    /**
     * Initializes CameraManager torch callback to monitor flashlight status.
     */
    fun initTorchMonitor(context: Context) {
        if (isTorchCallbackRegistered) return
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return
            cameraManager.registerTorchCallback(
                object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                        _isTorchOn.value = enabled
                    }
                },
                null
            )
            isTorchCallbackRegistered = true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to register torch callback: ${e.message}")
        }
    }

    /**
     * Toggles the device flashlight.
     */
    fun toggleTorch(context: Context, forceState: Boolean? = null): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return false
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: cameraManager.cameraIdList.firstOrNull() ?: return false

            val targetState = forceState ?: !_isTorchOn.value
            cameraManager.setTorchMode(cameraId, targetState)
            _isTorchOn.value = targetState
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle torch: ${e.message}")
            false
        }
    }

    /**
     * Queries current battery percentage, charging status, and health.
     */
    fun getBatteryInfo(context: Context): BatteryInfo {
        return try {
            val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val batteryStatus: Intent? = context.registerReceiver(null, intentFilter)

            val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level != -1 && scale != -1) ((level / scale.toFloat()) * 100).toInt() else 0

            val status: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging: Boolean = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

            val chargePlug: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
            val powerSource = when (chargePlug) {
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_AC -> "AC Adapter"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                else -> if (isCharging) "Charging" else "Unplugged"
            }

            val healthInt: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1
            val health = when (healthInt) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheated"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
                else -> "Normal"
            }

            val tempTenths = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            val tempCelsius = tempTenths / 10.0f

            BatteryInfo(
                percentage = batteryPct,
                isCharging = isCharging,
                powerSource = powerSource,
                health = health,
                temperatureCelsius = tempCelsius
            )
        } catch (e: Exception) {
            BatteryInfo(50, false, "Unknown", "Normal", 25.0f)
        }
    }

    /**
     * Reads current media volume and ringer mode.
     */
    fun getVolumeInfo(context: Context): VolumeInfo {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                ?: return VolumeInfo(7, 15, "Normal")
            val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val ringerModeStr = when (audioManager.ringerMode) {
                AudioManager.RINGER_MODE_SILENT -> "Silent"
                AudioManager.RINGER_MODE_VIBRATE -> "Vibrate"
                else -> "Normal"
            }
            VolumeInfo(currentVol, maxVol, ringerModeStr)
        } catch (e: Exception) {
            VolumeInfo(7, 15, "Normal")
        }
    }

    /**
     * Changes media volume by index.
     */
    fun setMediaVolume(context: Context, level: Int) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val clamped = level.coerceIn(0, max)
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, clamped, AudioManager.FLAG_SHOW_UI)
        } catch (e: Exception) {
            Log.w(TAG, "Could not set volume: ${e.message}")
        }
    }

    /**
     * Opens a known application or web/store fallback.
     */
    fun openApp(context: Context, appKey: String): Boolean {
        return try {
            val packageManager = context.packageManager
            when (appKey.lowercase()) {
                "youtube" -> {
                    val intent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    true
                }
                "whatsapp" -> {
                    val intent = packageManager.getLaunchIntentForPackage("com.whatsapp")
                        ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://web.whatsapp.com"))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    true
                }
                "camera" -> {
                    val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(packageManager) != null) {
                        context.startActivity(intent)
                        true
                    } else {
                        false
                    }
                }
                "calculator" -> {
                    val intent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_APP_CALCULATOR)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(packageManager) != null) {
                        context.startActivity(intent)
                        true
                    } else {
                        // Fallback common package
                        val calcPkg = packageManager.getLaunchIntentForPackage("com.google.android.calculator")
                        if (calcPkg != null) {
                            calcPkg.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(calcPkg)
                            true
                        } else {
                            false
                        }
                    }
                }
                "maps" -> {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    true
                }
                "chrome", "browser" -> {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    true
                }
                "settings" -> {
                    val intent = Intent(Settings.ACTION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    true
                }
                else -> false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening app $appKey: ${e.message}")
            false
        }
    }

    /**
     * Opens system settings screens.
     */
    fun openSettingsScreen(context: Context, type: String): Boolean {
        return try {
            val action = when (type.lowercase()) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS
                "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
                "battery" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                    Settings.ACTION_BATTERY_SAVER_SETTINGS
                } else {
                    Settings.ACTION_SETTINGS
                }
                else -> Settings.ACTION_SETTINGS
            }
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error opening settings $type: ${e.message}")
            false
        }
    }

    /**
     * Safely opens phone dialer with a prefilled number (never places direct calls without user review).
     */
    fun openDialer(context: Context, phoneNumber: String): Boolean {
        return try {
            val cleanNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanNumber")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open dialer: ${e.message}")
            false
        }
    }

    /**
     * Opens SMS app with prefilled text and recipient.
     */
    fun draftSms(context: Context, phoneNumber: String, messageText: String): Boolean {
        return try {
            val cleanNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$cleanNumber")).apply {
                putExtra("sms_body", messageText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open SMS app: ${e.message}")
            false
        }
    }

    /**
     * Sets an alarm using the Android AlarmClock intent.
     */
    fun setAlarm(context: Context, hour: Int, minutes: Int, message: String): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minutes)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set alarm: ${e.message}")
            false
        }
    }

    /**
     * Sets a countdown timer in seconds using Android AlarmClock intent.
     */
    fun setTimer(context: Context, lengthSeconds: Int, message: String): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, lengthSeconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set timer: ${e.message}")
            false
        }
    }

    /**
     * Parses user commands in Hindi, Hinglish, or English to execute immediate local phone actions.
     */
    fun detectAndExecuteQuickDeviceAction(context: Context, input: String): DeviceActionResult? {
        val lower = input.lowercase().trim()

        // 1. Flashlight / Torch
        if (lower.contains("torch on") || lower.contains("flashlight on") ||
            lower.contains("torch chalu") || lower.contains("torch jalao") ||
            lower.contains("turn on torch") || lower.contains("turn on flashlight")
        ) {
            val ok = toggleTorch(context, true)
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = if (ok) "Flashlight turned ON 🔦" else "Unable to turn on flashlight on this device.",
                actionType = "TORCH_ON"
            )
        }

        if (lower.contains("torch off") || lower.contains("flashlight off") ||
            lower.contains("torch band") || lower.contains("turn off torch") ||
            lower.contains("turn off flashlight")
        ) {
            val ok = toggleTorch(context, false)
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = if (ok) "Flashlight turned OFF 🔦" else "Flashlight already off.",
                actionType = "TORCH_OFF"
            )
        }

        // 2. Battery status
        if (lower.contains("battery") && (lower.contains("kitni") || lower.contains("status") ||
                lower.contains("percentage") || lower.contains("level") || lower.contains("check"))
        ) {
            val b = getBatteryInfo(context)
            val chargingStatus = if (b.isCharging) "Charging (${b.powerSource}) ⚡" else "Discharging 🔋"
            val msg = "Battery is at **${b.percentage}%** • $chargingStatus\nHealth: ${b.health} • Temp: ${b.temperatureCelsius}°C"
            return DeviceActionResult(isHandled = true, feedbackMessage = msg, actionType = "BATTERY_STATUS")
        }

        // 3. Open apps
        if (lower.contains("open youtube") || lower.contains("youtube kholo") || lower.contains("start youtube")) {
            val ok = openApp(context, "youtube")
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = if (ok) "Opening YouTube ▶️…" else "YouTube app not found.",
                actionType = "OPEN_YOUTUBE"
            )
        }

        if (lower.contains("open whatsapp") || lower.contains("whatsapp kholo") || lower.contains("start whatsapp")) {
            val ok = openApp(context, "whatsapp")
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = if (ok) "Opening WhatsApp 💬…" else "WhatsApp not found.",
                actionType = "OPEN_WHATSAPP"
            )
        }

        if (lower.contains("open camera") || lower.contains("camera kholo") || lower.contains("take photo")) {
            val ok = openApp(context, "camera")
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = if (ok) "Opening Camera 📸…" else "Camera app not found.",
                actionType = "OPEN_CAMERA"
            )
        }

        if (lower.contains("open calculator") || lower.contains("calculator kholo")) {
            val ok = openApp(context, "calculator")
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = if (ok) "Opening Calculator 🧮…" else "Calculator not found.",
                actionType = "OPEN_CALCULATOR"
            )
        }

        if (lower.contains("open maps") || lower.contains("maps kholo") || lower.contains("google maps")) {
            val ok = openApp(context, "maps")
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = if (ok) "Opening Google Maps 🗺️…" else "Maps not found.",
                actionType = "OPEN_MAPS"
            )
        }

        if (lower.contains("open settings") || lower.contains("phone settings") || lower.contains("setting kholo")) {
            val ok = openApp(context, "settings")
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = if (ok) "Opening System Settings ⚙️…" else "Settings could not be opened.",
                actionType = "OPEN_SETTINGS"
            )
        }

        // 4. Quick Settings shortcuts
        if (lower.contains("wifi setting") || lower.contains("wi-fi setting")) {
            openSettingsScreen(context, "wifi")
            return DeviceActionResult(isHandled = true, feedbackMessage = "Opening Wi-Fi settings 📶…", actionType = "SETTINGS_WIFI")
        }

        if (lower.contains("bluetooth setting")) {
            openSettingsScreen(context, "bluetooth")
            return DeviceActionResult(isHandled = true, feedbackMessage = "Opening Bluetooth settings ᛒ…", actionType = "SETTINGS_BLUETOOTH")
        }

        // 5. Phone call / dialer
        val dialMatch = Regex("(?:call|dial|dialer)\\s+([0-9+ ]{4,16})", RegexOption.IGNORE_CASE).find(lower)
        if (dialMatch != null) {
            val number = dialMatch.groupValues[1].trim()
            openDialer(context, number)
            return DeviceActionResult(
                isHandled = true,
                feedbackMessage = "Opening phone dialer with **$number** 📞",
                actionType = "DIAL_NUMBER"
            )
        }

        return null
    }
}
