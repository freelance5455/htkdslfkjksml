package com.example

import android.app.Application
import com.example.data.database.AppDatabase
import com.example.data.repository.ProjectRepository
import com.example.player.AudioPlayerManager
import com.example.tts.engine.AndroidSystemTtsEngine
import com.example.tts.queue.TtsQueueManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class OmniVoiceApp : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val database by lazy { AppDatabase.getDatabase(this) }
    val projectRepository by lazy { ProjectRepository(database.projectDao()) }
    val systemTtsEngine by lazy { AndroidSystemTtsEngine(this) }
    val ttsQueueManager by lazy { TtsQueueManager(this, applicationScope) }
    val audioPlayerManager by lazy { AudioPlayerManager(this, applicationScope) }

    override fun onCreate() {
        super.onCreate()
    }
}
