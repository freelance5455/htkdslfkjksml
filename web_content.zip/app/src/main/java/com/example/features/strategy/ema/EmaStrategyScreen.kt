package com.example.features.strategy.ema

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Timeframe
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.PageContainer
import com.example.ui.theme.BearRed
import com.example.ui.theme.BearRedBg
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.BullGreenBg
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg
import com.example.viewmodel.MainUiState
import java.util.Locale

@Composable
fun EmaStrategyScreen(
    state: MainUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val persistence = remember(context) { EmaStrategyPersistenceManager(context) }
    var config by remember { mutableStateOf(persistence.loadConfig()) }

    // Intercept Android back press to return to More screen
    BackHandler {
        onBack()
    }

    // Extract relevant data from existing app state
    val candles = state.chartDataState.candles
    val currentPrice = state.chartDataState.currentPrice ?: state.chartDataState.candles.lastOrNull()?.close ?: 0.0
    val symbol = state.selectedSymbol
    val higherTfScore = (state.completeAnalysisResult?.coreSnapshot?.timeframeScores ?: state.analysisScoreSnapshot?.timeframeScores)
        ?.firstOrNull { it.timeframe.equals("1h", ignoreCase = true) || it.timeframe.equals("4h", ignoreCase = true) }
    val mtfBias = higherTfScore?.direction

    // Evaluate strategy using existing candles and isolated engine
    val evaluation = remember(candles, config, mtfBias, currentPrice, symbol) {
        EmaStrategyEngine.evaluate(
            candles = candles,
            config = config,
            symbol = symbol,
            currentPriceOverride = currentPrice,
            mtfBias = mtfBias
        )
    }

    val scrollState = rememberScrollState()

    PageContainer(
        modifier = modifier
            .fillMaxSize()
            .testTag("ema_strategy_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Bar with Back navigation
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("ema_strategy_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to More",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "EMA 9/21 STRATEGY",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Trend Crossover • ADX Primary Filter • Analysis Only",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            // ==========================================
            // 1. PROMINENT RESULT CARD (Primary Hero)
            // ==========================================
            EmaResultHeroCard(
                evaluation = evaluation,
                modifier = Modifier.testTag("ema_signal_result_card")
            )

            // ==========================================
            // 2. "WHY THIS SIGNAL?" EXPLANATION
            // ==========================================
            EmaExplanationCard(
                evaluation = evaluation,
                modifier = Modifier.testTag("ema_explanation_card")
            )

            // ==========================================
            // 3. KEY METRICS & INDICATORS
            // ==========================================
            EmaMetricsCard(
                evaluation = evaluation,
                modifier = Modifier.testTag("ema_metrics_card")
            )

            // ==========================================
            // 4. CONFIRMATION LAYERS STATUS
            // ==========================================
            EmaConfirmationLayersCard(
                confirmations = evaluation.confirmations,
                modifier = Modifier.testTag("ema_confirmation_card")
            )

            // ==========================================
            // 5. STRATEGY CONFIGURATION (Isolated Persistence)
            // ==========================================
            EmaSettingsCard(
                config = config,
                onConfigChanged = { updated ->
                    config = updated
                    persistence.saveConfig(updated)
                },
                modifier = Modifier.testTag("ema_settings_card")
            )

            // ==========================================
            // 6. BACKTEST COMING LATER CARD (Requirement 7)
            // ==========================================
            EmaBacktestPlaceholderCard(
                modifier = Modifier.testTag("ema_backtest_card")
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun EmaResultHeroCard(
    evaluation: EmaStrategyEvaluation,
    modifier: Modifier = Modifier
) {
    val (badgeBg, badgeBorder, badgeTextColor, statusIcon) = when (evaluation.result) {
        EmaSignalResult.BUY -> Quadruple(BullGreenBg, BullGreen, BullGreen, Icons.Default.CheckCircle)
        EmaSignalResult.SELL -> Quadruple(BearRedBg, BearRed, BearRed, Icons.Default.Warning)
        EmaSignalResult.WAIT -> Quadruple(WarningAmberBg, WarningAmber, WarningAmber, Icons.Default.HourglassEmpty)
    }

    AppCard(
        modifier = modifier.fillMaxWidth(),
        variant = CardVariant.DEFAULT,
        border = BorderStroke(1.5.dp, badgeBorder.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Symbol and Timeframe badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = SurfaceElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Text(
                        text = evaluation.symbol,
                        color = CyanAccent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Surface(
                    color = SurfaceElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, BorderSubtle)
                ) {
                    Text(
                        text = evaluation.timeframe.label,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                }
            }

            // Current price
            Text(
                text = if (evaluation.currentPrice > 0) {
                    "$${String.format(Locale.US, "%,.2f", evaluation.currentPrice)}"
                } else {
                    "—"
                },
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Prominent Result Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = badgeBg,
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, badgeBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = statusIcon,
                    contentDescription = null,
                    tint = badgeTextColor,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = evaluation.result.badgeText,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = badgeTextColor,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Candle Completion Sub-Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CANDLE FILTER:",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TextTertiary
            )
            Text(
                text = if (evaluation.isLiveCandleIncomplete) {
                    "Live Incomplete Candle (Monitoring Only)"
                } else {
                    "Closed Candle Confirmed (No Repaint)"
                },
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (evaluation.isLiveCandleIncomplete) WarningAmber else BullGreen
            )
        }
    }
}

@Composable
private fun EmaExplanationCard(
    evaluation: EmaStrategyEvaluation,
    modifier: Modifier = Modifier
) {
    AppCard(
        modifier = modifier.fillMaxWidth(),
        variant = CardVariant.DEFAULT
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = CyanAccent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "WHY THIS SIGNAL?",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = evaluation.explanation,
            fontSize = 13.sp,
            color = TextSecondary,
            lineHeight = 19.sp
        )
    }
}

@Composable
private fun EmaMetricsCard(
    evaluation: EmaStrategyEvaluation,
    modifier: Modifier = Modifier
) {
    AppCard(
        modifier = modifier.fillMaxWidth(),
        variant = CardVariant.DEFAULT
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.ShowChart,
                contentDescription = null,
                tint = CyanAccent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "INDICATOR METRICS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Fast EMA & Slow EMA
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricTile(
                label = "EMA 9 (Fast)",
                value = evaluation.fastEma?.let { String.format(Locale.US, "%,.2f", it) } ?: "—",
                color = CyanAccent,
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                label = "EMA 21 (Slow)",
                value = evaluation.slowEma?.let { String.format(Locale.US, "%,.2f", it) } ?: "—",
                color = WarningAmber,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // ADX & ADX Threshold
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val adxConfirmed = evaluation.confirmations.adxConfirmed
            MetricTile(
                label = "ADX (14)",
                value = evaluation.adx?.let { String.format(Locale.US, "%.1f", it) } ?: "—",
                color = if (adxConfirmed) BullGreen else WarningAmber,
                badge = if (adxConfirmed) "PASSED" else "WEAK TREND",
                modifier = Modifier.weight(1f)
            )
            MetricTile(
                label = "ADX Threshold",
                value = String.format(Locale.US, "%.1f", evaluation.adxThreshold),
                color = TextPrimary,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun MetricTile(
    label: String,
    value: String,
    color: Color,
    badge: String? = null,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = SurfaceElevated,
        border = BorderStroke(1.dp, BorderSubtle)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = label, fontSize = 10.sp, color = TextTertiary, fontWeight = FontWeight.SemiBold)
                if (badge != null) {
                    Text(
                        text = badge,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
private fun EmaConfirmationLayersCard(
    confirmations: EmaConfirmationLayers,
    modifier: Modifier = Modifier
) {
    AppCard(
        modifier = modifier.fillMaxWidth(),
        variant = CardVariant.DEFAULT
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Tune,
                contentDescription = null,
                tint = CyanAccent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "CONFIRMATION & FILTER LAYERS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        ConfirmationRow(
            label = "ADX Primary Trend Filter",
            detail = if (confirmations.adxValue != null) {
                "${String.format(Locale.US, "%.1f", confirmations.adxValue)} (Threshold: ${String.format(Locale.US, "%.1f", confirmations.adxThreshold)})"
            } else {
                "Calculating..."
            },
            isAligned = confirmations.adxConfirmed,
            statusText = if (confirmations.adxConfirmed) "PASSED" else "FILTERED"
        )

        ConfirmationRow(
            label = "Multi-Timeframe Confirmation",
            detail = confirmations.mtfConfirmation,
            isAligned = confirmations.mtfAligned,
            statusText = if (confirmations.mtfAligned) "ALIGNED" else "CONFLICT"
        )

        ConfirmationRow(
            label = "Market Structure Engine",
            detail = confirmations.marketStructure,
            isAligned = confirmations.marketStructureAligned,
            statusText = if (confirmations.marketStructureAligned) "ALIGNED" else "CONFLICT"
        )

        ConfirmationRow(
            label = "Candlestick Pattern Engine",
            detail = confirmations.candlePattern,
            isAligned = confirmations.candlePatternAligned,
            statusText = if (confirmations.candlePatternAligned) "CLEAR" else "OPPOSING"
        )

        ConfirmationRow(
            label = "Volatility / ATR Environment",
            detail = confirmations.volatilityStatus,
            isAligned = confirmations.volatilityAcceptable,
            statusText = if (confirmations.volatilityAcceptable) "NORMAL" else "EXTREME"
        )

        ConfirmationRow(
            label = "Support & Resistance",
            detail = confirmations.supportResistance,
            isAligned = confirmations.supportResistanceClear,
            statusText = if (confirmations.supportResistanceClear) "CLEAR" else "NEAR S/R"
        )

        ConfirmationRow(
            label = "Volume Status",
            detail = confirmations.volumeStatus,
            isAligned = confirmations.volumeAcceptable,
            statusText = confirmations.volumeStatus
        )
    }
}

@Composable
private fun ConfirmationRow(
    label: String,
    detail: String,
    isAligned: Boolean,
    statusText: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Text(text = detail, fontSize = 10.sp, color = TextSecondary)
        }

        Surface(
            color = if (isAligned) BullGreenBg else WarningAmberBg,
            shape = RoundedCornerShape(4.dp),
            border = BorderStroke(1.dp, if (isAligned) BullGreen else WarningAmber)
        ) {
            Text(
                text = statusText,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (isAligned) BullGreen else WarningAmber,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
private fun EmaSettingsCard(
    config: EmaStrategyConfig,
    onConfigChanged: (EmaStrategyConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    AppCard(
        modifier = modifier.fillMaxWidth(),
        variant = CardVariant.DEFAULT
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = null,
                tint = CyanAccent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "STRATEGY SETTINGS (PERSISTENT)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Timeframe selector
        Text(text = "ANALYSIS TIMEFRAME", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiary)
        Spacer(modifier = Modifier.height(6.dp))

        val commonTimeframes = listOf(Timeframe.M1, Timeframe.M5, Timeframe.M15, Timeframe.H1, Timeframe.H4, Timeframe.D1)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            commonTimeframes.forEach { tf ->
                val isSelected = config.timeframe == tf
                Surface(
                    color = if (isSelected) CyanAccent else SurfaceElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (isSelected) CyanAccent else BorderSubtle),
                    modifier = Modifier
                        .clickable { onConfigChanged(config.copy(timeframe = tf)) }
                        .testTag("tf_picker_${tf.label}")
                ) {
                    Text(
                        text = tf.label,
                        color = if (isSelected) Color.Black else TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // ADX Threshold Selector
        Text(text = "ADX PRIMARY THRESHOLD", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextTertiary)
        Spacer(modifier = Modifier.height(6.dp))

        val adxThresholds = listOf(15.0, 20.0, 25.0, 30.0)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            adxThresholds.forEach { th ->
                val isSelected = config.adxThreshold == th
                Surface(
                    color = if (isSelected) CyanAccent else SurfaceElevated,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (isSelected) CyanAccent else BorderSubtle),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onConfigChanged(config.copy(adxThreshold = th)) }
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${th.toInt()}",
                            color = if (isSelected) Color.Black else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "EMA Periods: Fast ${config.fastEmaPeriod} • Slow ${config.slowEmaPeriod} • ADX Period: ${config.adxPeriod}",
            fontSize = 10.sp,
            color = TextTertiary
        )
    }
}

@Composable
private fun EmaBacktestPlaceholderCard(
    modifier: Modifier = Modifier
) {
    AppCard(
        modifier = modifier.fillMaxWidth(),
        variant = CardVariant.DEFAULT
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.QueryStats,
                contentDescription = null,
                tint = TextTertiary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "BACKTEST — COMING LATER",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "A dedicated historical backtesting simulator for the EMA 9/21 strategy is scheduled for a future modular release. This screen currently operates exclusively in real-time completed-candle analysis mode.",
            fontSize = 11.sp,
            color = TextTertiary,
            lineHeight = 16.sp
        )
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
