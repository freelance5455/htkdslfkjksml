package com.example.features.notifications

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.network.whatsapp.WhatsAppSendResult
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.AppToggle
import com.example.core.ui.components.ButtonStyle
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.SectionHeader
import com.example.core.ui.components.StatusIndicator
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.launch

/**
 * Validates international phone numbers, specifically supporting Pakistani WhatsApp numbers (+923XXXXXXXXX).
 * General international format supported: + followed by 7 to 15 digits.
 * Pakistani numbers: +92 followed by 10 digits (typically starting with 3, e.g., +923001234567).
 */
fun isValidWhatsAppNumber(number: String): Boolean {
    val trimmed = number.trim().replace(" ", "").replace("-", "")
    // Strictly validate + followed by 7 to 15 digits
    val internationalRegex = Regex("^\\+[1-9]\\d{6,14}$")
    return internationalRegex.matches(trimmed)
}

@Composable
fun WhatsAppNotificationsScreen(
    savedPhoneNumber: String? = null,
    savedApiKey: String? = null,
    savedPhoneNumberId: String? = null,
    connectionStatus: WhatsAppConnectionStatus = WhatsAppConnectionStatus.Disconnected,
    connectionMethod: WhatsAppConnectionMethod = WhatsAppConnectionMethod.META_CLOUD_API,
    lastVerifiedTime: String? = null,
    connectedAccount: String? = null,
    preferences: WhatsAppPreferences = WhatsAppPreferences(),
    onSaveConfig: (String, String, String) -> Unit = { _, _, _ -> },
    onVerifyAndConnect: (suspend (String, String, String) -> WhatsAppVerificationResult)? = null,
    onDisconnect: () -> Unit = {},
    onSelectMethod: (WhatsAppConnectionMethod) -> Unit = {},
    onClearConfig: () -> Unit = {},
    onUpdatePreferences: (WhatsAppPreferences) -> Unit = {},
    onSendTestAlert: (suspend (String, String, String) -> WhatsAppSendResult)? = null,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val focusManager = LocalFocusManager.current
    val coroutineScope = rememberCoroutineScope()

    var isEnabled by remember { mutableStateOf(preferences.isServiceEnabled) }
    var phoneNumberInput by remember { mutableStateOf(savedPhoneNumber ?: "") }
    var apiKeyInput by remember { mutableStateOf(savedApiKey ?: "") }
    var phoneNumberIdInput by remember { mutableStateOf(savedPhoneNumberId ?: "") }
    var showApiKey by remember { mutableStateOf(false) }

    var notifyOnTradeSignal by remember { mutableStateOf(preferences.notifyOnTradeSignal) }
    var notifyOnPriceAlert by remember { mutableStateOf(preferences.notifyOnPriceAlert) }
    var notifyOnStopLossTakeProfit by remember { mutableStateOf(preferences.notifyOnStopLossTakeProfit) }
    var notifyOnNews by remember { mutableStateOf(preferences.notifyOnNews) }

    var savedSuccessBanner by remember { mutableStateOf(false) }
    var verificationResultBanner by remember { mutableStateOf<WhatsAppVerificationResult?>(null) }
    var isVerifying by remember { mutableStateOf(false) }
    var testResultBanner by remember { mutableStateOf<WhatsAppSendResult?>(null) }
    var isSendingTest by remember { mutableStateOf(false) }
    var phoneValidationError by remember { mutableStateOf<String?>(null) }

    // Keep inputs synced when persistent state loads or changes
    LaunchedEffect(savedPhoneNumber) {
        if (savedPhoneNumber != null && phoneNumberInput.isEmpty()) {
            phoneNumberInput = savedPhoneNumber
        }
    }
    LaunchedEffect(savedApiKey) {
        if (savedApiKey != null && apiKeyInput.isEmpty()) {
            apiKeyInput = savedApiKey
        }
    }
    LaunchedEffect(savedPhoneNumberId) {
        if (savedPhoneNumberId != null && phoneNumberIdInput.isEmpty()) {
            phoneNumberIdInput = savedPhoneNumberId
        }
    }
    LaunchedEffect(preferences) {
        isEnabled = preferences.isServiceEnabled
        notifyOnTradeSignal = preferences.notifyOnTradeSignal
        notifyOnPriceAlert = preferences.notifyOnPriceAlert
        notifyOnStopLossTakeProfit = preferences.notifyOnStopLossTakeProfit
        notifyOnNews = preferences.notifyOnNews
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionHeader(
            title = "WhatsApp Notifications",
            subtitle = "Direct instant trading alerts and persistent risk dispatches to your WhatsApp"
        )

        // Safety & Protocol Card
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "DISPATCH & SECURITY PROTOCOL",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "IQTrade Pro WhatsApp gateway dispatches persistent real-time alerts for confirmed trade signals, price crossings, risk limits, and breaking news.\n\n• Notification triggers are one-way informational alerts only\n• Messages NEVER automatically execute trades on your account\n• API tokens and credentials are encrypted locally with Android Keystore\n• Multi-dispatch deduplication prevents repetitive alert spam",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 18.sp
            )
        }

        // Connection Method Selection Card
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Text(
                text = "CONNECTION METHOD",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceDark, RoundedCornerShape(8.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Meta Cloud API Tab
                val isMetaSelected = connectionMethod == WhatsAppConnectionMethod.META_CLOUD_API
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isMetaSelected) CyanAccent.copy(alpha = 0.15f) else SurfaceDark)
                        .border(
                            width = 1.dp,
                            color = if (isMetaSelected) CyanAccent else BorderSubtle.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectMethod(WhatsAppConnectionMethod.META_CLOUD_API) }
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Meta Cloud API",
                            fontSize = 12.sp,
                            fontWeight = if (isMetaSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isMetaSelected) CyanAccent else TextSecondary
                        )
                        Text(
                            text = "Official • Supported",
                            fontSize = 9.sp,
                            color = if (isMetaSelected) BullGreen else TextDisabled
                        )
                    }
                }

                // QR Connection Tab
                val isQrSelected = connectionMethod == WhatsAppConnectionMethod.QR_CONNECTION
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isQrSelected) WarningAmber.copy(alpha = 0.12f) else SurfaceDark)
                        .border(
                            width = 1.dp,
                            color = if (isQrSelected) WarningAmber else BorderSubtle.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectMethod(WhatsAppConnectionMethod.QR_CONNECTION) }
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "QR Connection",
                            fontSize = 12.sp,
                            fontWeight = if (isQrSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isQrSelected) WarningAmber else TextSecondary
                        )
                        Text(
                            text = "Platform Architecture",
                            fontSize = 9.sp,
                            color = if (isQrSelected) WarningAmber else TextDisabled
                        )
                    }
                }
            }

            // QR Connection architectural notice
            if (connectionMethod == WhatsAppConnectionMethod.QR_CONNECTION) {
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceElevated, RoundedCornerShape(8.dp))
                        .border(1.dp, WarningAmber.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = WarningAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "OFFICIAL META ARCHITECTURE STATUS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarningAmber
                            )
                        }

                        Text(
                            text = "The official WhatsApp Business Platform (Meta Cloud API) operates strictly as a server-to-server REST API utilizing Access Tokens and Phone Number IDs. It does not provide QR-based device linking for programmatic cloud dispatch.",
                            fontSize = 11.sp,
                            color = TextPrimary,
                            lineHeight = 16.sp
                        )

                        Text(
                            text = "• Personal WhatsApp Web QR scraping, browser automation, and reverse-engineered session hijacking are strictly prohibited to ensure account safety and compliance with Meta policies.\n• Please use the official Meta Cloud API option to link and authenticate securely.",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )

                        AppButton(
                            text = "Switch to Meta Cloud API (Official)",
                            onClick = { onSelectMethod(WhatsAppConnectionMethod.META_CLOUD_API) },
                            style = ButtonStyle.PRIMARY,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Live Gateway & Connection Status Card
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Chat,
                        contentDescription = null,
                        tint = BullGreen,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "WHATSAPP CONNECTION STATUS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Dynamic Status Badge
                val statusLabel = when (connectionStatus) {
                    is WhatsAppConnectionStatus.Connected -> "Connected"
                    is WhatsAppConnectionStatus.Connecting -> "Verifying..."
                    is WhatsAppConnectionStatus.AuthenticationRequired -> "Auth Required"
                    is WhatsAppConnectionStatus.Unavailable -> "Unavailable"
                    is WhatsAppConnectionStatus.Disconnected -> if (isEnabled) "Standby" else "Disconnected"
                }
                val statusColor = when (connectionStatus) {
                    is WhatsAppConnectionStatus.Connected -> BullGreen
                    is WhatsAppConnectionStatus.Connecting -> CyanAccent
                    is WhatsAppConnectionStatus.AuthenticationRequired -> WarningAmber
                    is WhatsAppConnectionStatus.Unavailable -> TextDisabled
                    is WhatsAppConnectionStatus.Disconnected -> if (isEnabled) CyanAccent else TextDisabled
                }

                StatusIndicator(
                    label = statusLabel,
                    dotColor = statusColor
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Information Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceElevated, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "METHOD", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = if (connectionMethod == WhatsAppConnectionMethod.META_CLOUD_API) "Meta Cloud API" else "QR Link",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column {
                    Text(text = "DESTINATION", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = if (phoneNumberInput.isNotBlank()) phoneNumberInput else "Not set",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (phoneNumberInput.isNotBlank()) CyanAccent else TextDisabled
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "SERVICE STATE", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = if (isEnabled) "Active" else "Paused",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isEnabled) BullGreen else WarningAmber
                    )
                }
            }

            // Connection Details (Account and Last Verified)
            if (connectionStatus is WhatsAppConnectionStatus.Connected || !connectedAccount.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BullGreen.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = BullGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Verified Account: ${connectedAccount ?: "Meta Verified Business"}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = BullGreen
                            )
                        }
                        if (!lastVerifiedTime.isNullOrBlank()) {
                            Text(
                                text = "Last Verified: $lastVerifiedTime",
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // Authentication Required Notice
            if (connectionStatus is WhatsAppConnectionStatus.AuthenticationRequired) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(WarningAmber.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = connectionStatus.reason,
                        fontSize = 11.sp,
                        color = WarningAmber
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Master Service Toggle
            AppToggle(
                title = "Enable WhatsApp Alerts",
                description = if (isEnabled)
                    "Service active — notifications will be dispatched to destination number"
                else
                    "Service inactive — notifications currently paused",
                checked = isEnabled,
                onCheckedChange = {
                    isEnabled = it
                    onUpdatePreferences(
                        preferences.copy(
                            isServiceEnabled = it,
                            notifyOnTradeSignal = notifyOnTradeSignal,
                            notifyOnPriceAlert = notifyOnPriceAlert,
                            notifyOnStopLossTakeProfit = notifyOnStopLossTakeProfit,
                            notifyOnNews = notifyOnNews
                        )
                    )
                },
                testTag = "toggle_whatsapp_alerts"
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Connection Action Buttons (Verify & Connect / Disconnect)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppButton(
                    text = if (isVerifying) "Verifying Gateway..." else "Verify & Connect",
                    onClick = {
                        val phone = phoneNumberInput.trim()
                        val key = apiKeyInput.trim()
                        val phoneId = phoneNumberIdInput.trim()
                        if (phone.isBlank() || key.isBlank() || phoneId.isBlank()) {
                            phoneValidationError = "Please fill in recipient number, Phone ID, and Access Token."
                            return@AppButton
                        }
                        phoneValidationError = null
                        isVerifying = true
                        verificationResultBanner = null
                        coroutineScope.launch {
                            try {
                                if (onVerifyAndConnect != null) {
                                    val res = onVerifyAndConnect(phone, key, phoneId)
                                    verificationResultBanner = res
                                }
                            } finally {
                                isVerifying = false
                            }
                        }
                    },
                    style = ButtonStyle.PRIMARY,
                    enabled = !isVerifying,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_verify_whatsapp_connection"
                )

                if (connectionStatus is WhatsAppConnectionStatus.Connected) {
                    AppButton(
                        text = "Disconnect",
                        onClick = { onDisconnect() },
                        style = ButtonStyle.OUTLINE,
                        modifier = Modifier.weight(0.7f),
                        testTag = "btn_disconnect_whatsapp"
                    )
                }
            }

            // Verification Result Banner
            verificationResultBanner?.let { vResult ->
                Spacer(modifier = Modifier.height(8.dp))
                when (vResult) {
                    is WhatsAppVerificationResult.Success -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BullGreen.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BullGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Meta Cloud API verified: ${vResult.displayPhoneNumber} (${vResult.verifiedName.ifBlank { "Verified Account" }})",
                                fontSize = 11.sp,
                                color = BullGreen
                            )
                        }
                    }
                    is WhatsAppVerificationResult.Failure -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BearRed.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = BearRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Verification failed: ${vResult.errorMessage}",
                                fontSize = 11.sp,
                                color = BearRed
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Test dispatch button
            AppButton(
                text = if (isSendingTest) "Sending Test Alert..." else "Send Test Alert to WhatsApp",
                onClick = {
                    val trimmedPhone = phoneNumberInput.trim()
                    if (!isValidWhatsAppNumber(trimmedPhone)) {
                        phoneValidationError = "Enter a valid recipient phone number before sending a test alert."
                        return@AppButton
                    }
                    phoneValidationError = null
                    isSendingTest = true
                    testResultBanner = null
                    savedSuccessBanner = false
                    coroutineScope.launch {
                        try {
                            if (onSendTestAlert != null) {
                                val res = onSendTestAlert(trimmedPhone, apiKeyInput.trim(), phoneNumberIdInput.trim())
                                testResultBanner = res
                            } else {
                                testResultBanner = WhatsAppSendResult.Failure(
                                    httpCode = 0,
                                    errorMessage = "WhatsApp service not initialized"
                                )
                            }
                        } catch (e: Exception) {
                            testResultBanner = WhatsAppSendResult.Failure(
                                errorMessage = "Failed to dispatch: ${e.message}"
                            )
                        } finally {
                            isSendingTest = false
                        }
                    }
                },
                style = ButtonStyle.OUTLINE,
                enabled = isEnabled && !isSendingTest,
                modifier = Modifier.fillMaxWidth(),
                testTag = "btn_test_whatsapp_alert"
            )

            testResultBanner?.let { result ->
                Spacer(modifier = Modifier.height(10.dp))
                when (result) {
                    is WhatsAppSendResult.Success -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = BullGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Meta WhatsApp Cloud API delivered: Message ID ${result.messageId.take(18)}...",
                                fontSize = 11.sp,
                                color = BullGreen
                            )
                        }
                    }
                    is WhatsAppSendResult.Failure -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = BearRed,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            val codeDisplay = if (result.httpCode != null && result.httpCode != 0) " (${result.httpCode})" else ""
                            Text(
                                text = "WhatsApp Delivery Failed$codeDisplay: ${result.errorMessage}",
                                fontSize = 11.sp,
                                color = BearRed
                            )
                        }
                    }
                }
            }
        }

        // Alert Trigger Preferences Card
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ALERT TRIGGER FILTERS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            AppToggle(
                title = "Trade & Signal Triggers",
                description = "Notify on confirmed Bullish (Buy), Bearish (Sell), or Neutral signals",
                checked = notifyOnTradeSignal,
                onCheckedChange = {
                    notifyOnTradeSignal = it
                    onUpdatePreferences(
                        preferences.copy(
                            isServiceEnabled = isEnabled,
                            notifyOnTradeSignal = it,
                            notifyOnPriceAlert = notifyOnPriceAlert,
                            notifyOnStopLossTakeProfit = notifyOnStopLossTakeProfit,
                            notifyOnNews = notifyOnNews
                        )
                    )
                },
                testTag = "toggle_notify_trade_signal"
            )

            Spacer(modifier = Modifier.height(8.dp))

            AppToggle(
                title = "Horizontal Price Line Alerts",
                description = "Notify immediately when chart price crosses drawn price lines",
                checked = notifyOnPriceAlert,
                onCheckedChange = {
                    notifyOnPriceAlert = it
                    onUpdatePreferences(
                        preferences.copy(
                            isServiceEnabled = isEnabled,
                            notifyOnTradeSignal = notifyOnTradeSignal,
                            notifyOnPriceAlert = it,
                            notifyOnStopLossTakeProfit = notifyOnStopLossTakeProfit,
                            notifyOnNews = notifyOnNews
                        )
                    )
                },
                testTag = "toggle_notify_price_alert"
            )

            Spacer(modifier = Modifier.height(8.dp))

            AppToggle(
                title = "SL / TP Risk Boundaries",
                description = "Notify upon Stop Loss, Trailing Stop, or Take Profit execution",
                checked = notifyOnStopLossTakeProfit,
                onCheckedChange = {
                    notifyOnStopLossTakeProfit = it
                    onUpdatePreferences(
                        preferences.copy(
                            isServiceEnabled = isEnabled,
                            notifyOnTradeSignal = notifyOnTradeSignal,
                            notifyOnPriceAlert = notifyOnPriceAlert,
                            notifyOnStopLossTakeProfit = it,
                            notifyOnNews = notifyOnNews
                        )
                    )
                },
                testTag = "toggle_notify_sltp"
            )

            Spacer(modifier = Modifier.height(8.dp))

            AppToggle(
                title = "News & Market Intelligence Alerts",
                description = "Notify when high-impact breaking market news is received",
                checked = notifyOnNews,
                onCheckedChange = {
                    notifyOnNews = it
                    onUpdatePreferences(
                        preferences.copy(
                            isServiceEnabled = isEnabled,
                            notifyOnTradeSignal = notifyOnTradeSignal,
                            notifyOnPriceAlert = notifyOnPriceAlert,
                            notifyOnStopLossTakeProfit = notifyOnStopLossTakeProfit,
                            notifyOnNews = it
                        )
                    )
                },
                testTag = "toggle_notify_news"
            )
        }

        // WhatsApp Gateway Credentials Card
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "GATEWAY CONFIGURATION & RECIPIENT",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Enter recipient WhatsApp number in international format (+ country code, e.g. +923001234567 for Pakistan), Phone Number ID, and Meta Cloud API Token.",
                fontSize = 11.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Phone Number Field
            OutlinedTextField(
                value = phoneNumberInput,
                onValueChange = { input ->
                    phoneNumberInput = input
                    // Clear error immediately when user edits or types a valid format
                    if (phoneValidationError != null) {
                        phoneValidationError = if (input.isNotBlank() && !isValidWhatsAppNumber(input)) {
                            "Invalid format. Use international format (e.g. +923001234567 or +15551234567)"
                        } else {
                            null
                        }
                    }
                },
                label = { Text("Recipient WhatsApp Number") },
                placeholder = { Text("+923001234567") },
                singleLine = true,
                isError = phoneValidationError != null,
                supportingText = {
                    if (phoneValidationError != null) {
                        Text(
                            text = phoneValidationError!!,
                            color = BearRed,
                            fontSize = 11.sp
                        )
                    } else {
                        Text(
                            text = "Pakistani numbers: +92XXXXXXXXXX (e.g., +923001234567). Must start with + country code.",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_whatsapp_phone"),
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = if (phoneValidationError != null) BearRed else TextSecondary
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = BorderSubtle,
                    errorBorderColor = BearRed,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Phone Number ID Field (Meta WhatsApp Cloud API)
            OutlinedTextField(
                value = phoneNumberIdInput,
                onValueChange = { phoneNumberIdInput = it },
                label = { Text("Phone Number ID (Meta Cloud API)") },
                placeholder = { Text("e.g. 104589234892348") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_whatsapp_phone_number_id"),
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = TextSecondary)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // API Token Field
            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = { apiKeyInput = it },
                label = { Text("WhatsApp API Access Token / Key") },
                placeholder = { Text("Enter Meta System User Token") },
                singleLine = true,
                visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_whatsapp_api_key"),
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = TextSecondary)
                },
                trailingIcon = {
                    IconButton(onClick = { showApiKey = !showApiKey }) {
                        Icon(
                            imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (showApiKey) "Hide Key" else "Show Key",
                            tint = TextSecondary
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppButton(
                    text = "Save Configuration",
                    onClick = {
                        val trimmedNumber = phoneNumberInput.trim()
                        if (trimmedNumber.isBlank()) {
                            phoneValidationError = "Phone number is required"
                            savedSuccessBanner = false
                            return@AppButton
                        }
                        if (!isValidWhatsAppNumber(trimmedNumber)) {
                            phoneValidationError = "Invalid format. Expected international format (e.g., +923001234567)"
                            savedSuccessBanner = false
                            return@AppButton
                        }
                        // Format is valid: clear any error, invoke persistent storage callback
                        phoneValidationError = null
                        savedSuccessBanner = true
                        testResultBanner = null
                        onSaveConfig(trimmedNumber, apiKeyInput.trim(), phoneNumberIdInput.trim())
                        onUpdatePreferences(
                            preferences.copy(
                                isServiceEnabled = isEnabled,
                                notifyOnTradeSignal = notifyOnTradeSignal,
                                notifyOnPriceAlert = notifyOnPriceAlert,
                                notifyOnStopLossTakeProfit = notifyOnStopLossTakeProfit,
                                notifyOnNews = notifyOnNews
                            )
                        )
                        focusManager.clearFocus()
                    },
                    style = ButtonStyle.SUCCESS,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_save_whatsapp_config"
                )

                AppButton(
                    text = "Clear",
                    onClick = {
                        phoneNumberInput = ""
                        apiKeyInput = ""
                        phoneNumberIdInput = ""
                        phoneValidationError = null
                        savedSuccessBanner = false
                        testResultBanner = null
                        verificationResultBanner = null
                        onClearConfig()
                        focusManager.clearFocus()
                    },
                    style = ButtonStyle.DANGER,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_clear_whatsapp_config"
                )
            }

            if (savedSuccessBanner) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = BullGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "WhatsApp configuration saved securely.",
                        fontSize = 11.sp,
                        color = BullGreen
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
