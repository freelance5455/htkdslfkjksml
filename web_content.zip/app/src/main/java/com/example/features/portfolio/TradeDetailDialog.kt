package com.example.features.portfolio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.local.entity.TradeRecordEntity
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.ButtonStyle
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeDetailDialog(
    trade: TradeRecordEntity,
    currentMarketPrice: Double = 0.0,
    onDismiss: () -> Unit,
    onClosePosition: ((Long) -> Unit)? = null
) {
    val isLong = trade.side.equals("BUY", ignoreCase = true)
    val isPaper = trade.isPaper
    val marketCat = PortfolioFilterState.resolveMarketCategory(trade.symbol)
    val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    // Calculate effective PnL
    val effectivePnl = if (trade.isOpen) {
        val exitP = if (currentMarketPrice > 0.0) currentMarketPrice else trade.price
        if (isLong) (exitP - trade.price) * trade.quantity else (trade.price - exitP) * trade.quantity
    } else {
        trade.realizedPnl ?: 0.0
    }
    val fees = trade.commission ?: 0.0
    val netPnl = effectivePnl - fees

    val durationStr = run {
        val end = trade.closeTimestamp ?: trade.updatedTimestamp ?: System.currentTimeMillis()
        val diff = (end - trade.timestamp).coerceAtLeast(0L)
        val s = diff / 1000
        val m = s / 60
        val h = m / 60
        if (trade.isOpen) {
            "Active (${m}m ${s % 60}s)"
        } else {
            when {
                h > 0 -> "${h}h ${m % 60}m"
                m > 0 -> "${m}m ${s % 60}s"
                else -> "${s}s"
            }
        }
    }

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(SurfaceDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
            .testTag("trade_detail_dialog")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row: Badge & Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Visually Prominent Mode Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isPaper) CyanAccent.copy(alpha = 0.2f) else WarningAmber.copy(alpha = 0.2f))
                            .border(1.dp, if (isPaper) CyanAccent else WarningAmber, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag(if (isPaper) "badge_paper_trade" else "badge_live_trade")
                    ) {
                        Text(
                            text = if (isPaper) "PAPER TRADE" else "LIVE TRADE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = if (isPaper) CyanAccent else WarningAmber,
                            letterSpacing = 0.5.sp
                        )
                    }

                    // Market Tag
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SurfaceElevated)
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = marketCat,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("btn_close_trade_detail")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary
                    )
                }
            }

            // Symbol & Direction Hero
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = trade.symbol,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (isLong) "BUY / LONG" else "SELL / SHORT",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isLong) BullGreen else BearRed
                        )
                        Text(
                            text = "•",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = trade.orderType,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    }
                }

                // Execution Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when (trade.status) {
                                "FILLED" -> BullGreen.copy(alpha = 0.15f)
                                "PARTIALLY_FILLED" -> WarningAmber.copy(alpha = 0.15f)
                                "CANCELED", "REJECTED" -> BearRed.copy(alpha = 0.15f)
                                else -> SurfaceElevated
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (trade.isOpen) "OPEN" else trade.status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (trade.status) {
                            "FILLED" -> if (trade.isOpen) CyanAccent else BullGreen
                            "PARTIALLY_FILLED" -> WarningAmber
                            "CANCELED", "REJECTED" -> BearRed
                            else -> TextSecondary
                        }
                    )
                }
            }

            // P&L Breakdown Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailRow(
                    label = if (trade.isOpen) "Unrealized P&L" else "Gross Realized P&L",
                    value = run {
                        val sign = if (effectivePnl > 0.0) "+" else ""
                        "$sign$${String.format(Locale.US, "%,.2f", effectivePnl)}"
                    },
                    valueColor = when {
                        effectivePnl > 0.0 -> BullGreen
                        effectivePnl < 0.0 -> BearRed
                        else -> TextSecondary
                    },
                    isBold = true
                )
                DetailRow(
                    label = "Trading Fees",
                    value = if (fees > 0.0) {
                        "-$${String.format(Locale.US, "%.4f", fees)} ${trade.commissionAsset ?: "USDT"}"
                    } else "$0.00",
                    valueColor = if (fees > 0.0) WarningAmber else TextSecondary
                )
                DetailRow(
                    label = "Net P&L",
                    value = run {
                        val sign = if (netPnl > 0.0) "+" else ""
                        "$sign$${String.format(Locale.US, "%,.2f", netPnl)}"
                    },
                    valueColor = when {
                        netPnl > 0.0 -> BullGreen
                        netPnl < 0.0 -> BearRed
                        else -> TextSecondary
                    },
                    isBold = true
                )
            }

            // Price & Quantity Details
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailRow(
                    label = "Entry Price",
                    value = "$${String.format(Locale.US, "%,.2f", trade.price)}"
                )
                if (!trade.isOpen && trade.closePrice != null) {
                    DetailRow(
                        label = "Exit / Close Price",
                        value = "$${String.format(Locale.US, "%,.2f", trade.closePrice)}"
                    )
                }
                DetailRow(
                    label = "Order Quantity",
                    value = "${String.format(Locale.US, "%.4f", trade.quantity)}"
                )
                if (trade.executedQuantity != null) {
                    DetailRow(
                        label = "Executed Quantity",
                        value = "${String.format(Locale.US, "%.4f", trade.executedQuantity)}"
                    )
                }
                if (trade.averageFillPrice != null && trade.averageFillPrice > 0.0) {
                    DetailRow(
                        label = "Average Fill Price",
                        value = "$${String.format(Locale.US, "%,.2f", trade.averageFillPrice)}"
                    )
                }
                DetailRow(
                    label = "Total Notional",
                    value = "$${String.format(Locale.US, "%,.2f", trade.total)}"
                )
            }

            // Protection Details
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailRow(
                    label = "Stop Loss",
                    value = trade.stopLoss?.let { "$${String.format(Locale.US, "%,.2f", it)}" } ?: "None",
                    valueColor = if (trade.stopLoss != null) BearRed else TextSecondary
                )
                DetailRow(
                    label = "Take Profit",
                    value = trade.takeProfit?.let { "$${String.format(Locale.US, "%,.2f", it)}" } ?: "None",
                    valueColor = if (trade.takeProfit != null) BullGreen else TextSecondary
                )
            }

            // Timeline & Durations
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailRow(
                    label = "Open Time",
                    value = dateFormat.format(Date(trade.timestamp))
                )
                if (trade.closeTimestamp != null) {
                    DetailRow(
                        label = "Close Time",
                        value = dateFormat.format(Date(trade.closeTimestamp))
                    )
                }
                DetailRow(
                    label = "Duration",
                    value = durationStr
                )
            }

            // Order Identifiers (Strict real vs paper metadata)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DetailRow(
                    label = "Database Trade ID",
                    value = "#${trade.id}"
                )
                trade.clientOrderId?.let { clientOrderId ->
                    DetailRow(
                        label = "Client Order ID",
                        value = clientOrderId
                    )
                }
                DetailRow(
                    label = "Exchange Order ID",
                    value = trade.exchangeOrderId ?: if (isPaper) "N/A (Paper Simulated)" else "Unavailable"
                )
            }

            // Action: Close position if open
            if (trade.isOpen && onClosePosition != null) {
                AppButton(
                    text = "CLOSE POSITION",
                    onClick = {
                        onClosePosition(trade.id)
                        onDismiss()
                    },
                    style = ButtonStyle.DANGER,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_dialog_close_position"
                )
            }

            AppButton(
                text = "DISMISS",
                onClick = onDismiss,
                style = ButtonStyle.OUTLINE,
                modifier = Modifier.fillMaxWidth(),
                testTag = "btn_dialog_dismiss"
            )
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    valueColor: androidx.compose.ui.graphics.Color = TextPrimary,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondary
        )
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = valueColor,
            fontFamily = FontFamily.Monospace
        )
    }
}
