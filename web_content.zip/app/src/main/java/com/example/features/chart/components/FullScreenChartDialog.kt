package com.example.features.chart.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.core.chart.ChartExportHelper
import com.example.core.chart.IQTradeChart
import com.example.core.chart.IQTradeChartController
import com.example.core.model.MarketCategory
import com.example.core.model.Timeframe
import com.example.core.model.chart.Candle
import com.example.core.model.chart.ChartConnectionState
import com.example.core.model.chart.ChartDrawing
import com.example.core.model.chart.DrawingType
import com.example.core.model.chart.ExecutedTradeMarker
import com.example.core.model.chart.IndicatorInstance
import com.example.core.model.chart.PriceAlertEvent
import com.example.core.model.chart.SignalMarker
import com.example.core.model.chart.TradeProtectionState
import com.example.core.model.chart.TradeSide
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark

@Composable
fun FullScreenChartDialog(
    isOpen: Boolean,
    symbol: String,
    market: MarketCategory,
    timeframe: Timeframe,
    currentPrice: Double?,
    tradingMode: String,
    candles: List<Candle>,
    latestCandle: Candle?,
    connectionState: ChartConnectionState,
    showVolume: Boolean,
    onToggleVolume: () -> Unit,
    showIndicators: Boolean,
    indicators: List<IndicatorInstance>,
    onOpenIndicators: () -> Unit,
    showSignals: Boolean,
    onToggleSignals: () -> Unit,
    signalMarkers: List<SignalMarker>,
    executedTrades: List<ExecutedTradeMarker>,
    protectionState: TradeProtectionState?,
    activeDrawingTool: DrawingType,
    onOpenDrawingTools: () -> Unit,
    onClearDrawings: () -> Unit,
    drawings: List<ChartDrawing>,
    onDrawingCreated: (ChartDrawing) -> Unit,
    onCrosshairMoved: (time: Long, o: Double, h: Double, l: Double, c: Double) -> Unit,
    onOpenSymbolPicker: () -> Unit,
    onOpenTimeframePicker: () -> Unit,
    onOpenOrderEntry: (TradeSide) -> Unit,
    onCloseFullscreen: () -> Unit,
    onReloadData: (() -> Unit)? = null,
    activePriceAlert: PriceAlertEvent? = null,
    onDismissPriceAlert: () -> Unit = {},
    onPriceAlert: ((PriceAlertEvent) -> Unit)? = null
) {
    if (!isOpen) return

    val context = LocalContext.current
    val chartController = remember { IQTradeChartController() }
    var localAlert by remember { mutableStateOf<PriceAlertEvent?>(null) }
    val effectiveAlert = activePriceAlert ?: localAlert

    LaunchedEffect(localAlert) {
        if (localAlert != null) {
            kotlinx.coroutines.delay(6000)
            localAlert = null
        }
    }

    val onExportAction: () -> Unit = {
        chartController.exportCanvasAsBase64 { base64 ->
            if (base64 != null) {
                ChartExportHelper.shareChart(context, base64, symbol, timeframe.label)
            }
        }
    }

    Dialog(
        onDismissRequest = onCloseFullscreen,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(SurfaceDark)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Header with BUY / SELL controls
                ChartTopHeader(
                    symbol = symbol,
                    market = market,
                    timeframe = timeframe,
                    currentPrice = currentPrice,
                    tradingMode = tradingMode,
                    isFullscreen = true,
                    onOpenSymbolPicker = onOpenSymbolPicker,
                    onOpenTimeframePicker = onOpenTimeframePicker,
                    onOpenOrderEntry = onOpenOrderEntry,
                    onToggleFullscreen = onCloseFullscreen,
                    onFloatClick = {},
                    onExportClick = onExportAction,
                    modifier = Modifier
                )

                // Secondary Toolbar
                ChartSecondaryToolbar(
                    showVolume = showVolume,
                    onToggleVolume = onToggleVolume,
                    showIndicators = showIndicators,
                    activeIndicatorsCount = indicators.count { it.isEnabled },
                    onOpenIndicators = onOpenIndicators,
                    activeDrawingTool = activeDrawingTool,
                    onOpenDrawingTools = onOpenDrawingTools,
                    onClearDrawings = onClearDrawings,
                    drawingsCount = drawings.size,
                    showSignals = showSignals,
                    onToggleSignals = onToggleSignals,
                    onExportChart = onExportAction
                )

                // Real-time Price Crossing Alert Banner
                if (effectiveAlert != null) {
                    PriceAlertBanner(
                        alert = effectiveAlert,
                        onDismiss = {
                            localAlert = null
                            onDismissPriceAlert()
                        }
                    )
                }

                // Chart Canvas Viewport
                IQTradeChart(
                    symbol = symbol,
                    timeframe = timeframe.label,
                    candles = candles,
                    latestCandle = latestCandle,
                    connectionState = connectionState,
                    showVolume = showVolume,
                    showIndicators = showIndicators,
                    indicators = indicators,
                    showSignals = showSignals,
                    signalMarkers = signalMarkers,
                    executedTrades = executedTrades,
                    protectionState = protectionState,
                    activeDrawingTool = activeDrawingTool,
                    drawings = drawings,
                    onDrawingCreated = onDrawingCreated,
                    onCrosshairMoved = onCrosshairMoved,
                    onPriceAlert = { event ->
                        localAlert = event
                        onPriceAlert?.invoke(event)
                    },
                    onReloadData = onReloadData,
                    chartController = chartController,
                    modifier = Modifier.weight(1f)
                )
            }

            // Quick Floating Exit Button
            FloatingActionButton(
                onClick = onCloseFullscreen,
                containerColor = SurfaceDark.copy(alpha = 0.85f),
                contentColor = CyanAccent,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FullscreenExit,
                    contentDescription = "Exit Fullscreen",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
