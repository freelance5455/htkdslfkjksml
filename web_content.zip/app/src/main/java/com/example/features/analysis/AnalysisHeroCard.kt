package com.example.features.analysis

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.analysis.CompleteAnalysisResult
import com.example.core.model.analysis.FinalAnalysisSignal
import com.example.core.model.indicator.IndicatorDirection
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.CardVariant
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber

/**
 * Top Hero Card for Module #6 Complete Analysis Engine.
 * Displays authoritative BUY / SELL / WAIT bias, confidence percentage,
 * component contribution breakdown, and live refresh controls.
 */
@Composable
fun AnalysisHeroCard(
    result: CompleteAnalysisResult,
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showBreakdown by remember { mutableStateOf(false) }

    val signalColor = when (result.overallSignal) {
        FinalAnalysisSignal.BULLISH_BUY -> BullGreen
        FinalAnalysisSignal.BEARISH_SELL -> BearRed
        FinalAnalysisSignal.NEUTRAL_WAIT -> WarningAmber
    }

    val signalBg = signalColor.copy(alpha = 0.12f)
    val signalText = result.overallSignal.label

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val mtfBullish = result.coreSnapshot.timeframeScores.count { it.direction == IndicatorDirection.BULLISH }
    val mtfBearish = result.coreSnapshot.timeframeScores.count { it.direction == IndicatorDirection.BEARISH }

    AppCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("analysis_hero_card"),
        variant = CardVariant.DEFAULT
    ) {
        // Header Row: Symbol, Market, Live Pulse & Refresh Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = result.symbol,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyanAccent.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = result.market.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanAccent
                            )
                        }
                    }
                    Text(
                        text = if (result.currentPrice > 0) "$%.2f".format(result.currentPrice) else "Live Quotes Active",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Live Indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceDark)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(BullGreen.copy(alpha = pulseAlpha))
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LIVE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = BullGreen
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Refresh Button
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceElevated)
                        .clickable(enabled = !isRefreshing) { onRefresh() }
                        .padding(8.dp)
                        .testTag("btn_refresh_analysis"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isRefreshing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = CyanAccent,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Analysis",
                            tint = CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Prominent Final Analysis Signal Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(signalBg)
                .border(1.5.dp, signalColor, RoundedCornerShape(10.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp)
                .testTag("analysis_signal_banner")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "OVERALL ANALYSIS SIGNAL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = signalColor,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = signalText,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = signalColor
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${result.overallConfidencePct}%",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = signalColor
                    )
                    Text(
                        text = if (result.overallConfidencePct >= 80) "HIGH CONFIDENCE" else if (result.overallConfidencePct >= 60) "MODERATE" else "LOW / NEUTRAL",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = signalColor.copy(alpha = 0.85f),
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Confidence progress bar
        LinearProgressIndicator(
            progress = { result.overallConfidencePct / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = signalColor,
            trackColor = SurfaceDark
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Key Quick Metrics Summary Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceDark)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricChip(
                    label = "Core >= 80%",
                    value = result.coreConfirmationRatioText,
                    isPositive = result.isConfirmedCoreMet,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                MetricChip(
                    label = "MTF Alignment",
                    value = "${mtfBullish}B / ${mtfBearish}S",
                    isPositive = mtfBullish > mtfBearish,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricChip(
                    label = "Structure Trend",
                    value = result.structureResult.trend.label,
                    isPositive = result.structureResult.trend.name.startsWith("UP"),
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                MetricChip(
                    label = "Risk / Reward",
                    value = if (result.riskRewardResult.isValid) result.riskRewardResult.ratioText else "Pending data",
                    isPositive = result.riskRewardResult.isValid && result.riskRewardResult.ratioValue >= 1.5,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Toggleable Component Contribution Breakdown
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(SurfaceElevated)
                .clickable { showBreakdown = !showBreakdown }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "COMPONENT CONTRIBUTION BREAKDOWN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
            Text(
                text = if (showBreakdown) "HIDE ▲" else "SHOW ▼",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = CyanAccent
            )
        }

        if (showBreakdown) {
            Spacer(modifier = Modifier.height(8.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "Module contribution weights to final score:",
                    fontSize = 10.sp,
                    color = TextSecondary
                )
                result.contributions.forEach { contribution ->
                    val color = when (contribution.direction) {
                        IndicatorDirection.BULLISH -> BullGreen
                        IndicatorDirection.BEARISH -> BearRed
                        IndicatorDirection.NEUTRAL -> WarningAmber
                    }
                    ContributionRow(
                        label = contribution.componentName,
                        weight = "${contribution.weightPercent}%",
                        score = "${contribution.scorePercent}%",
                        color = color
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricChip(
    label: String,
    value: String,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(SurfaceElevated)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column {
            Text(
                text = label,
                fontSize = 9.sp,
                color = TextTertiary,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isPositive) BullGreen else TextPrimary,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ContributionRow(
    label: String,
    weight: String,
    score: String,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$label ($weight)",
            fontSize = 10.sp,
            color = TextSecondary,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = score,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
