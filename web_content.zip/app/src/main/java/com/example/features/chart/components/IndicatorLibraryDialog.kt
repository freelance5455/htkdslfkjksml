package com.example.features.chart.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.indicator.persistence.IndicatorPersistenceManager
import com.example.core.model.chart.IndicatorInstance
import com.example.core.model.chart.IndicatorType
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.SurfaceHighlight
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber

/**
 * Modal dialog that presents a categorized, searchable library of technical indicators
 * (e.g., RSI, MACD, Moving Averages: EMA, SMA, Bollinger Bands, ATR, VWAP)
 * with individual on/off toggle switches that immediately sync with the chart engine's
 * indicatorSeriesMap.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IndicatorLibraryDialog(
    isOpen: Boolean,
    activeIndicators: List<IndicatorInstance>,
    onAddIndicator: (IndicatorType, Int, String) -> Unit,
    onRemoveIndicator: (String) -> Unit,
    onToggleIndicator: (String, Boolean) -> Unit,
    onUpdateIndicatorPeriod: (String, Int) -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val context = LocalContext.current
    val persistenceManager = remember { IndicatorPersistenceManager(context) }
    var favoriteCodes by remember { mutableStateOf(persistenceManager.getFavoriteCodes()) }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedForEdit by remember { mutableStateOf<IndicatorInstance?>(null) }

    val categories = listOf(
        "All",
        "⭐ Favorites",
        "Moving Average",
        "Trend",
        "Momentum",
        "Oscillator",
        "Volatility",
        "Volume",
        "Channel",
        "Support & Resistance",
        "Bill Williams",
        "Statistical"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        dragHandle = null,
        modifier = Modifier.testTag("indicator_library_dialog")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.90f)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyanAccent.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShowChart,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "INDICATOR LIBRARY",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            val enabledCount = activeIndicators.count { it.isEnabled }
                            if (enabledCount > 0) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(CyanAccent.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "$enabledCount Active",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyanAccent
                                    )
                                }
                            }
                        }
                        Text(
                            text = "Toggle indicators to update chart series map",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("btn_close_indicator_library")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_indicators_input"),
                placeholder = {
                    Text(
                        "Search indicators (RSI, MACD, Moving Averages...)",
                        fontSize = 12.sp,
                        color = TextTertiary
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear search",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = SurfaceElevated,
                    unfocusedContainerColor = SurfaceElevated,
                    focusedIndicatorColor = CyanAccent,
                    unfocusedIndicatorColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Category Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategory == category
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = category },
                        label = {
                            Text(
                                text = category,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = SurfaceElevated,
                            labelColor = TextSecondary,
                            selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                            selectedLabelColor = CyanAccent
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = BorderSubtle,
                            selectedBorderColor = CyanAccent
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("category_chip_${category.lowercase().replace(" ", "_")}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Filtered Indicators
            val filteredIndicators = IndicatorType.entries.filter { type ->
                val matchesCategory = when (selectedCategory) {
                    "All" -> true
                    "⭐ Favorites" -> favoriteCodes.contains(type.code)
                    "Moving Average" -> type.category.contains("Moving Average", ignoreCase = true) || type == IndicatorType.EMA || type == IndicatorType.SMA
                    else -> type.category.equals(selectedCategory, ignoreCase = true)
                }
                val query = searchQuery.trim()
                val matchesSearch = query.isEmpty() ||
                        type.code.contains(query, ignoreCase = true) ||
                        type.title.contains(query, ignoreCase = true) ||
                        type.category.contains(query, ignoreCase = true) ||
                        type.description.contains(query, ignoreCase = true) ||
                        (query.contains("moving", ignoreCase = true) && (type == IndicatorType.EMA || type == IndicatorType.SMA))

                matchesCategory && matchesSearch
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Section 1: Active Overlays on Chart
                if (activeIndicators.isNotEmpty()) {
                    item {
                        Text(
                            text = "ACTIVE ON CHART (${activeIndicators.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent,
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                        )
                    }

                    items(activeIndicators, key = { it.id }) { ind ->
                        ActiveIndicatorItem(
                            indicator = ind,
                            onToggle = { isEnabled -> onToggleIndicator(ind.id, isEnabled) },
                            onEditSettings = { selectedForEdit = ind },
                            onRemove = { onRemoveIndicator(ind.id) }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                // Section 2: Indicator Catalog
                item {
                    Text(
                        text = "AVAILABLE TECHNICAL INDICATORS (${filteredIndicators.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent,
                        letterSpacing = 0.5.sp,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }

                items(filteredIndicators, key = { it.name }) { type ->
                    val activeInstance = activeIndicators.firstOrNull { it.type == type }
                    val isToggledOn = activeInstance?.isEnabled == true
                    val defaultColor = getDefaultIndicatorColor(type)
                    val isFav = favoriteCodes.contains(type.code)

                    AvailableIndicatorItem(
                        type = type,
                        activeInstance = activeInstance,
                        isToggledOn = isToggledOn,
                        isFavorite = isFav,
                        defaultColor = defaultColor,
                        onToggleFavorite = {
                            persistenceManager.toggleFavorite(type.code)
                            favoriteCodes = persistenceManager.getFavoriteCodes()
                        },
                        onToggle = { enable ->
                            if (enable) {
                                if (activeInstance != null) {
                                    onToggleIndicator(activeInstance.id, true)
                                } else {
                                    onAddIndicator(type, type.defaultPeriod, defaultColor)
                                }
                            } else {
                                if (activeInstance != null) {
                                    onToggleIndicator(activeInstance.id, false)
                                }
                            }
                        },
                        onEditSettings = {
                            if (activeInstance != null) {
                                selectedForEdit = activeInstance
                            } else {
                                // Add first and open edit
                                onAddIndicator(type, type.defaultPeriod, defaultColor)
                            }
                        }
                    )
                }
            }
        }
    }

    // Parameters Edit Dialog
    selectedForEdit?.let { ind ->
        EditIndicatorParametersDialog(
            indicator = ind,
            onSave = { newPeriod ->
                onUpdateIndicatorPeriod(ind.id, newPeriod)
                selectedForEdit = null
            },
            onDismiss = { selectedForEdit = null }
        )
    }
}

/**
 * Row card representing an indicator in the available catalog with a high-contrast M3 Switch and Favorite toggle.
 */
@Composable
private fun AvailableIndicatorItem(
    type: IndicatorType,
    activeInstance: IndicatorInstance?,
    isToggledOn: Boolean,
    isFavorite: Boolean,
    defaultColor: String,
    onToggleFavorite: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onEditSettings: () -> Unit
) {
    val indicatorColor = try {
        Color(android.graphics.Color.parseColor(activeInstance?.color ?: defaultColor))
    } catch (_: Throwable) {
        CyanAccent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(SurfaceElevated)
            .border(
                width = 1.dp,
                color = if (isToggledOn) CyanAccent.copy(alpha = 0.5f) else BorderSubtle,
                shape = RoundedCornerShape(10.dp)
            )
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Color pill indicator
            Box(
                modifier = Modifier
                    .size(width = 4.dp, height = 36.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(indicatorColor)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = type.code,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isToggledOn) CyanAccent else TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(SurfaceHighlight, RoundedCornerShape(4.dp))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = type.category,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary
                        )
                    }
                    if (activeInstance != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "(${activeInstance.period})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = indicatorColor
                        )
                    }
                }

                Text(
                    text = type.title,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    modifier = Modifier.padding(top = 1.dp)
                )

                Text(
                    text = type.description,
                    fontSize = 10.sp,
                    color = TextTertiary,
                    maxLines = 2,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("fav_indicator_${type.code.lowercase()}")
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "Favorite",
                    tint = if (isFavorite) WarningAmber else TextDisabled,
                    modifier = Modifier.size(18.dp)
                )
            }

            if (activeInstance != null) {
                IconButton(
                    onClick = onEditSettings,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("settings_indicator_${type.code.lowercase()}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Configure Parameters",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Switch(
                checked = isToggledOn,
                onCheckedChange = onToggle,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("switch_indicator_${type.code.lowercase()}"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = CyanAccent,
                    checkedTrackColor = CyanAccent.copy(alpha = 0.35f),
                    checkedBorderColor = CyanAccent,
                    uncheckedThumbColor = TextDisabled,
                    uncheckedTrackColor = SurfaceDark,
                    uncheckedBorderColor = BorderSubtle
                )
            )
        }
    }
}

/**
 * Row card displaying an indicator currently active on the chart with fast visibility and delete controls.
 */
@Composable
private fun ActiveIndicatorItem(
    indicator: IndicatorInstance,
    onToggle: (Boolean) -> Unit,
    onEditSettings: () -> Unit,
    onRemove: () -> Unit
) {
    val indicatorColor = try {
        Color(android.graphics.Color.parseColor(indicator.color))
    } catch (_: Throwable) {
        CyanAccent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceElevated)
            .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(indicatorColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = indicator.displayLabel,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (indicator.isEnabled) TextPrimary else TextDisabled
                )
                Text(
                    text = "${indicator.type.title} • ${if (indicator.isEnabled) "Plotting" else "Hidden"}",
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = { onToggle(!indicator.isEnabled) },
                modifier = Modifier
                    .size(36.dp)
                    .testTag("btn_toggle_ind_${indicator.id}")
            ) {
                Icon(
                    imageVector = if (indicator.isEnabled) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    contentDescription = "Toggle Visibility",
                    tint = if (indicator.isEnabled) CyanAccent else TextDisabled,
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onEditSettings,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("btn_settings_ind_${indicator.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("btn_remove_ind_${indicator.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Remove",
                    tint = BearRed,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/**
 * Parameter customization dialog for an active indicator.
 */
@Composable
private fun EditIndicatorParametersDialog(
    indicator: IndicatorInstance,
    onSave: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var periodInput by remember { mutableStateOf(indicator.period.toString()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${indicator.type.code} Parameters",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "Configure calculation period for ${indicator.type.title}:",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = periodInput,
                    onValueChange = {
                        periodInput = it
                        errorMessage = null
                    },
                    label = { Text("Period (bars)") },
                    singleLine = true,
                    isError = errorMessage != null,
                    supportingText = {
                        errorMessage?.let { Text(it, color = BearRed, fontSize = 11.sp) }
                    },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SurfaceElevated,
                        unfocusedContainerColor = SurfaceElevated,
                        focusedIndicatorColor = CyanAccent,
                        unfocusedIndicatorColor = BorderSubtle,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_ind_period_input")
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val p = periodInput.toIntOrNull()
                    if (p != null && p in 1..500) {
                        onSave(p)
                    } else {
                        errorMessage = "Please enter a valid period between 1 and 500"
                    }
                },
                modifier = Modifier.testTag("btn_save_indicator_params")
            ) {
                Text("SAVE & APPLY", color = CyanAccent, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = TextSecondary)
            }
        },
        containerColor = SurfaceDark,
        shape = RoundedCornerShape(12.dp)
    )
}

/**
 * Returns canonical trading terminal plot colors for each indicator type.
 */
private fun getDefaultIndicatorColor(type: IndicatorType): String = when (type) {
    IndicatorType.EMA -> "#00E5FF"           // Cyan Accent
    IndicatorType.SMA -> "#F0B90B"           // Warning Amber / Gold
    IndicatorType.WMA -> "#00B0FF"
    IndicatorType.HMA -> "#00E676"
    IndicatorType.DEMA -> "#76FF03"
    IndicatorType.TEMA -> "#1DE9B6"
    IndicatorType.SUPERTREND -> "#FF5252"
    IndicatorType.PSAR -> "#FFD740"
    IndicatorType.AROON -> "#E040FB"
    IndicatorType.ADX -> "#FF6E40"
    IndicatorType.BOLLINGER_BANDS -> "#9C27B0" // Volatility Purple
    IndicatorType.RSI -> "#E91E63"           // Momentum Magenta
    IndicatorType.MACD -> "#0ECB81"          // Bull Green
    IndicatorType.STOCH -> "#FF4081"
    IndicatorType.WPR -> "#7C4DFF"
    IndicatorType.ROC -> "#536DFE"
    IndicatorType.CCI -> "#40C4FF"
    IndicatorType.CMO -> "#18FFFF"
    IndicatorType.AO -> "#64FFDA"
    IndicatorType.ATR -> "#FF9800"           // Range Orange
    IndicatorType.KC -> "#B388FF"
    IndicatorType.DC -> "#8C9EFF"
    IndicatorType.STDDEV -> "#FFAB40"
    IndicatorType.ENV -> "#FF80AB"
    IndicatorType.VWAP -> "#2196F3"          // Volume Blue
    IndicatorType.OBV -> "#00E676"
    IndicatorType.CMF -> "#00B0FF"
    IndicatorType.MFI -> "#E040FB"
    IndicatorType.VOLOSC -> "#FFD740"
    IndicatorType.PIVOT -> "#FFD700"
    IndicatorType.FIBPIVOT -> "#FFA000"
    IndicatorType.HLBANDS -> "#FF6D00"
    IndicatorType.ALLIGATOR -> "#00E5FF"
    IndicatorType.FRACTALS -> "#FF5252"
    IndicatorType.LINREG -> "#69F0AE"
    IndicatorType.HISTVOL -> "#B2FF59"
    else -> "#00E5FF"
}
