package com.example.features.strategy.ema

import com.example.core.model.Timeframe

/**
 * Isolated data models for the EMA 9/21 Strategy with ADX Primary Filter.
 * Strictly decoupled from Order Entry, AutoTrade, Paper/Live trading, and core scoring.
 */
enum class EmaSignalResult(val label: String, val badgeText: String) {
    BUY("BUY / BULLISH", "🟢 BUY / BULLISH"),
    SELL("SELL / BEARISH", "🔴 SELL / BEARISH"),
    WAIT("WAIT / NO SIGNAL", "🟡 WAIT / NO SIGNAL")
}

data class EmaStrategyConfig(
    val fastEmaPeriod: Int = 9,
    val slowEmaPeriod: Int = 21,
    val adxPeriod: Int = 14,
    val adxThreshold: Double = 20.0,
    val timeframe: Timeframe = Timeframe.M15
)

data class EmaConfirmationLayers(
    val adxValue: Double? = null,
    val adxThreshold: Double = 20.0,
    val adxConfirmed: Boolean = false,
    val mtfConfirmation: String = "Neutral",
    val mtfAligned: Boolean = false,
    val marketStructure: String = "Neutral",
    val marketStructureAligned: Boolean = true,
    val candlePattern: String = "No Conflicting Pattern",
    val candlePatternAligned: Boolean = true,
    val volatilityStatus: String = "Normal Volatility",
    val volatilityAcceptable: Boolean = true,
    val supportResistance: String = "Clear Path",
    val supportResistanceClear: Boolean = true,
    val volumeStatus: String = "Unavailable",
    val volumeAcceptable: Boolean = true
)

data class EmaStrategyEvaluation(
    val symbol: String,
    val currentPrice: Double,
    val timeframe: Timeframe,
    val fastEma: Double?,
    val slowEma: Double?,
    val adx: Double?,
    val adxThreshold: Double,
    val result: EmaSignalResult,
    val confirmations: EmaConfirmationLayers,
    val explanation: String,
    val isLiveCandleIncomplete: Boolean,
    val lastCompletedCandleTime: Long,
    val dataTimestamp: Long = System.currentTimeMillis()
)
