package com.example.features.news

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.RssFeed
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ConnectionState
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.AppToggle
import com.example.core.ui.components.ButtonStyle
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.ConnectionStatusBadge
import com.example.core.ui.components.SectionHeader
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MainUiState

@Composable
fun NewsApiConfigScreen(
    state: MainUiState,
    onSaveApiKey: (String) -> Unit,
    onToggleConnection: (Boolean) -> Unit,
    onClearApiKey: () -> Unit,
    onOpenNewsFeed: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val focusManager = LocalFocusManager.current

    var apiKeyInput by remember { mutableStateOf("") }
    var showApiKey by remember { mutableStateOf(false) }
    var keySavedNotification by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SectionHeader(
            title = "News API Configuration",
            subtitle = "Market sentiment feeds, economic releases & real-time crypto news"
        )

        // News API Safety & Architecture Card
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "NEWS FEED & SENTIMENT PROTOCOL",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Connecting the News API streams financial headlines and macroeconomic releases directly to your trading terminal.\n\n• API keys are securely stored in encrypted local storage\n• News feeds provide informational sentiment signals only\n• Connecting or toggling feeds does NOT execute automated trades",
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 18.sp
            )
        }

        // Connection Status & Switch Card
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RssFeed,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NEWS FEED STATUS",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                ConnectionStatusBadge(
                    connectionState = state.newsApiConnectionState,
                    serviceName = "News API"
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Endpoint and Key Status Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceElevated, RoundedCornerShape(8.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "FEED SOURCE", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = if (state.newsApiConnectionState.isConnected) "Live Stream Active" else "Offline",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (state.newsApiConnectionState.isConnected) BullGreen else TextDisabled
                    )
                }
                Column {
                    Text(text = "API PROVIDER", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = "newsapi.org / v2",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "SAVED KEY", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = if (state.hasSavedNewsApiKey) "Encrypted" else "None",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (state.hasSavedNewsApiKey) CyanAccent else TextDisabled
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Direct Connection Toggle
            AppToggle(
                title = "News API Connection Feed",
                description = if (state.newsApiConnectionState.isConnected)
                    "Feed active — receiving real-time headlines & sentiment"
                else
                    "Feed inactive — toggle to connect and test feed",
                checked = state.newsApiConnectionState.isConnected,
                onCheckedChange = { isChecked ->
                    onToggleConnection(isChecked)
                },
                enabled = !state.isLoading,
                testTag = "toggle_news_api_connection"
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Connection Action Buttons
            if (state.newsApiConnectionState.isConnected) {
                AppButton(
                    text = "Disconnect News API Feed",
                    onClick = { onToggleConnection(false) },
                    style = ButtonStyle.OUTLINE,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_disconnect_news_api"
                )
                Spacer(modifier = Modifier.height(8.dp))
                AppButton(
                    text = "Open Live News Feed",
                    onClick = onOpenNewsFeed,
                    style = ButtonStyle.SUCCESS,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_open_live_news_feed"
                )
            } else {
                AppButton(
                    text = if (state.isLoading) "Connecting to News API..." else "Connect & Test News Feed",
                    onClick = { onToggleConnection(true) },
                    style = ButtonStyle.PRIMARY,
                    enabled = !state.isLoading,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_connect_news_api"
                )
                if (state.hasSavedNewsApiKey) {
                    Spacer(modifier = Modifier.height(8.dp))
                    AppButton(
                        text = "View News Feed (Cached/Live)",
                        onClick = onOpenNewsFeed,
                        style = ButtonStyle.OUTLINE,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "btn_open_news_feed_cached"
                    )
                }
            }
        }

        // Credentials Vault Card
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "NEWS API CREDENTIALS VAULT",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Store your News API key (e.g., from NewsAPI.org or CryptoPanic). Encrypted locally via Android Keystore.",
                fontSize = 11.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            // API Key Input Field
            OutlinedTextField(
                value = apiKeyInput,
                onValueChange = { apiKeyInput = it },
                label = { Text("News API Key") },
                placeholder = { Text("Enter your News API key") },
                singleLine = true,
                visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_news_api_key"),
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = TextSecondary)
                },
                trailingIcon = {
                    IconButton(onClick = { showApiKey = !showApiKey }) {
                        Icon(
                            imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = if (showApiKey) "Hide Key" else "Show Key",
                            tint = TextSecondary
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppButton(
                    text = "Save Key",
                    onClick = {
                        if (apiKeyInput.isNotBlank()) {
                            onSaveApiKey(apiKeyInput)
                            keySavedNotification = true
                            apiKeyInput = ""
                            focusManager.clearFocus()
                        }
                    },
                    style = ButtonStyle.SUCCESS,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_save_news_api_key"
                )

                if (state.hasSavedNewsApiKey) {
                    AppButton(
                        text = "Clear Vault",
                        onClick = onClearApiKey,
                        style = ButtonStyle.DANGER,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_clear_news_api_key"
                    )
                }
            }

            if (keySavedNotification) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = BullGreen,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "News API Key securely encrypted in vault.",
                        fontSize = 11.sp,
                        color = BullGreen
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
