package com.example.features.portfolio

import com.example.core.data.local.entity.TradeRecordEntity

enum class MarketFilter(val label: String) {
    ALL("All Markets"),
    CRYPTO("Crypto"),
    FOREX("Forex"),
    GOLD("Gold")
}

enum class SideFilter(val label: String) {
    ALL("All Sides"),
    BUY("Buy / Long"),
    SELL("Sell / Short")
}

enum class PositionStateFilter(val label: String) {
    ALL("All"),
    OPEN("Open"),
    CLOSED("Closed")
}

enum class OutcomeFilter(val label: String) {
    ALL("All Outcomes"),
    PROFITABLE("Profitable"),
    LOSING("Losing")
}

enum class OrderTypeFilter(val label: String) {
    ALL("All Types"),
    MARKET("Market"),
    LIMIT("Limit"),
    STOP("Stop / Trigger")
}

/**
 * Filter configuration for Trade History review (Module #10).
 * Filters do not alter database records; they provide non-destructive UI querying.
 */
data class PortfolioFilterState(
    val searchQuery: String = "",
    val marketFilter: MarketFilter = MarketFilter.ALL,
    val sideFilter: SideFilter = SideFilter.ALL,
    val stateFilter: PositionStateFilter = PositionStateFilter.ALL,
    val outcomeFilter: OutcomeFilter = OutcomeFilter.ALL,
    val orderTypeFilter: OrderTypeFilter = OrderTypeFilter.ALL
) {
    val isActive: Boolean
        get() = searchQuery.isNotBlank() ||
                marketFilter != MarketFilter.ALL ||
                sideFilter != SideFilter.ALL ||
                stateFilter != PositionStateFilter.ALL ||
                outcomeFilter != OutcomeFilter.ALL ||
                orderTypeFilter != OrderTypeFilter.ALL

    fun apply(trades: List<TradeRecordEntity>): List<TradeRecordEntity> {
        return trades.filter { trade ->
            // Search query (symbol or order ID)
            if (searchQuery.isNotBlank()) {
                val q = searchQuery.trim().lowercase()
                val matchSymbol = trade.symbol.lowercase().contains(q)
                val matchClient = trade.clientOrderId?.lowercase()?.contains(q) == true
                val matchExchange = trade.exchangeOrderId?.lowercase()?.contains(q) == true
                val matchId = trade.id.toString().contains(q)
                if (!matchSymbol && !matchClient && !matchExchange && !matchId) return@filter false
            }

            // Market
            when (marketFilter) {
                MarketFilter.ALL -> {}
                MarketFilter.CRYPTO -> {
                    if (isForexSymbol(trade.symbol) || isGoldSymbol(trade.symbol)) return@filter false
                }
                MarketFilter.FOREX -> {
                    if (!isForexSymbol(trade.symbol)) return@filter false
                }
                MarketFilter.GOLD -> {
                    if (!isGoldSymbol(trade.symbol)) return@filter false
                }
            }

            // Side
            when (sideFilter) {
                SideFilter.ALL -> {}
                SideFilter.BUY -> if (!trade.side.equals("BUY", ignoreCase = true)) return@filter false
                SideFilter.SELL -> if (!trade.side.equals("SELL", ignoreCase = true)) return@filter false
            }

            // State (Open / Closed)
            when (stateFilter) {
                PositionStateFilter.ALL -> {}
                PositionStateFilter.OPEN -> if (!trade.isOpen) return@filter false
                PositionStateFilter.CLOSED -> if (trade.isOpen) return@filter false
            }

            // Outcome
            when (outcomeFilter) {
                OutcomeFilter.ALL -> {}
                OutcomeFilter.PROFITABLE -> {
                    val pnl = trade.realizedPnl ?: 0.0
                    if (trade.isOpen || pnl <= 0.0) return@filter false
                }
                OutcomeFilter.LOSING -> {
                    val pnl = trade.realizedPnl ?: 0.0
                    if (trade.isOpen || pnl >= 0.0) return@filter false
                }
            }

            // Order Type
            when (orderTypeFilter) {
                OrderTypeFilter.ALL -> {}
                OrderTypeFilter.MARKET -> if (!trade.orderType.equals("MARKET", ignoreCase = true)) return@filter false
                OrderTypeFilter.LIMIT -> if (!trade.orderType.equals("LIMIT", ignoreCase = true)) return@filter false
                OrderTypeFilter.STOP -> if (!trade.orderType.contains("STOP", ignoreCase = true) && !trade.orderType.contains("TRIGGER", ignoreCase = true)) return@filter false
            }

            true
        }
    }

    companion object {
        fun isForexSymbol(symbol: String): Boolean {
            val s = symbol.uppercase()
            return s.contains("EUR") || s.contains("GBP") || s.contains("USDJPY") ||
                    s.contains("AUD") || s.contains("NZD") || s.contains("CAD") || s.contains("CHF")
        }

        fun isGoldSymbol(symbol: String): Boolean {
            val s = symbol.uppercase()
            return s.contains("XAU") || s.contains("GOLD") || s.contains("XAG")
        }

        fun resolveMarketCategory(symbol: String): String {
            return when {
                isGoldSymbol(symbol) -> "GOLD"
                isForexSymbol(symbol) -> "FOREX"
                else -> "CRYPTO"
            }
        }
    }
}
