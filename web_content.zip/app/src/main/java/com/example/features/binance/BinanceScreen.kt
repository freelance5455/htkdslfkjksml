package com.example.features.binance

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.ConnectionState
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.ButtonStyle
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.ConnectionStatusBadge
import com.example.core.ui.components.PageContainer
import com.example.core.ui.components.SectionHeader
import com.example.core.ui.components.StatusIndicator
import com.example.features.news.NewsApiConfigScreen
import com.example.core.network.whatsapp.WhatsAppSendResult
import com.example.features.notifications.WhatsAppNotificationsScreen
import com.example.features.notifications.WhatsAppPreferences
import com.example.features.notifications.WhatsAppConnectionMethod
import com.example.features.notifications.WhatsAppVerificationResult
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MainUiState

@Composable
fun BinanceScreen(
    state: MainUiState,
    onSaveCredentials: (String, String) -> Unit,
    onConnectTest: () -> Unit,
    onDisconnect: () -> Unit,
    onClearCredentials: () -> Unit,
    onSaveNewsApiKey: (String) -> Unit = {},
    onToggleNewsApiConnection: (Boolean) -> Unit = {},
    onClearNewsApiKey: () -> Unit = {},
    onOpenNewsFeed: () -> Unit = {},
    onSaveWhatsAppConfig: (String, String, String) -> Unit = { _, _, _ -> },
    onVerifyAndConnectWhatsApp: (suspend (String, String, String) -> WhatsAppVerificationResult)? = null,
    onDisconnectWhatsApp: () -> Unit = {},
    onSelectWhatsAppMethod: (WhatsAppConnectionMethod) -> Unit = {},
    onClearWhatsAppConfig: () -> Unit = {},
    onUpdateWhatsAppPreferences: (WhatsAppPreferences) -> Unit = {},
    onSendWhatsAppTestAlert: (suspend (String, String, String) -> WhatsAppSendResult)? = null,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val focusManager = LocalFocusManager.current

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Binance API", "News API", "WhatsApp")

    var apiKeyInput by remember { mutableStateOf("") }
    var secretKeyInput by remember { mutableStateOf("") }
    var showSecret by remember { mutableStateOf(false) }
    var credentialSavedNotification by remember { mutableStateOf(false) }

    PageContainer(modifier = modifier) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Tab Selector Row for APIs in Section B
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = SurfaceDark,
                contentColor = CyanAccent,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = CyanAccent
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                tabs.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    val tabIcon = when (index) {
                        0 -> Icons.Default.CurrencyBitcoin
                        1 -> Icons.Default.Newspaper
                        else -> Icons.AutoMirrored.Filled.Chat
                    }
                    Tab(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        text = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = tabIcon,
                                    contentDescription = null,
                                    tint = if (isSelected) CyanAccent else TextDisabled,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = title,
                                    color = if (isSelected) CyanAccent else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_api_${index}")
                    )
                }
            }

            when (selectedTab) {
                1 -> {
                    // News API Configuration Screen
                    NewsApiConfigScreen(
                        state = state,
                        onSaveApiKey = onSaveNewsApiKey,
                        onToggleConnection = onToggleNewsApiConnection,
                        onClearApiKey = onClearNewsApiKey,
                        onOpenNewsFeed = onOpenNewsFeed,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                2 -> {
                    // WhatsApp Notifications UI
                    WhatsAppNotificationsScreen(
                        savedPhoneNumber = state.savedWhatsAppPhoneNumber,
                        savedApiKey = state.savedWhatsAppApiKey,
                        savedPhoneNumberId = state.savedWhatsAppPhoneNumberId,
                        connectionStatus = state.whatsAppConnectionStatus,
                        connectionMethod = state.whatsAppConnectionMethod,
                        lastVerifiedTime = state.whatsAppLastVerifiedTime,
                        connectedAccount = state.whatsAppConnectedAccount,
                        preferences = state.whatsAppPreferences,
                        onSaveConfig = onSaveWhatsAppConfig,
                        onVerifyAndConnect = onVerifyAndConnectWhatsApp,
                        onDisconnect = onDisconnectWhatsApp,
                        onSelectMethod = onSelectWhatsAppMethod,
                        onClearConfig = onClearWhatsAppConfig,
                        onUpdatePreferences = onUpdateWhatsAppPreferences,
                        onSendTestAlert = onSendWhatsAppTestAlert,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                else -> {
                    // Binance API Configuration
                    Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    SectionHeader(
                        title = "Binance API & Feed",
                        subtitle = "API configuration, connection testing & credential security"
                    )

                    // CRITICAL BINANCE API SAFETY RULE CARD
                    AppCard(
                        modifier = Modifier.fillMaxWidth(),
                        variant = CardVariant.DEFAULT
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "BINANCE API SAFETY PROTOCOL",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanAccent,
                                letterSpacing = 0.5.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Connecting Binance API credentials NEVER automatically enables trading.\n\nThese states remain strictly independent:\n• Binance API: Connected\n• Smart Mode: OFF\n• Auto Trading: OFF\n• Live Trading: OFF\n\nSimply entering or testing keys will NOT place an order or enable algorithmic trading.",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 18.sp
                        )
                    }

                    // Connection State Live Card
                    AppCard(
                        modifier = Modifier.fillMaxWidth(),
                        variant = CardVariant.DEFAULT
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CurrencyBitcoin,
                                    contentDescription = null,
                                    tint = WarningAmber,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "DATA CONNECTION STATUS",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }

                            ConnectionStatusBadge(connectionState = state.binanceConnectionState)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceElevated, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "WEBSOCKET STREAM", fontSize = 10.sp, color = TextSecondary)
                                Text(
                                    text = if (state.binanceConnectionState.isConnected) "Ready (Module #4)" else "Disconnected",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (state.binanceConnectionState.isConnected) BullGreen else TextDisabled
                                )
                            }
                            Column {
                                Text(text = "REST ENDPOINT", fontSize = 10.sp, color = TextSecondary)
                                Text(
                                    text = "api.binance.com",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "SAVED KEYS", fontSize = 10.sp, color = TextSecondary)
                                Text(
                                    text = if (state.hasSavedBinanceCredentials) "Encrypted" else "None",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (state.hasSavedBinanceCredentials) CyanAccent else TextDisabled
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Connection test buttons
                        if (state.binanceConnectionState.isConnected) {
                            AppButton(
                                text = "Disconnect Binance Feed",
                                onClick = onDisconnect,
                                style = ButtonStyle.OUTLINE,
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "btn_disconnect_binance"
                            )
                        } else {
                            AppButton(
                                text = if (state.isLoading) "Connecting..." else "Test Connection Feed",
                                onClick = onConnectTest,
                                style = ButtonStyle.PRIMARY,
                                enabled = !state.isLoading,
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "btn_test_binance"
                            )
                        }
                    }

                    // Secure Credential Vault Card
                    AppCard(
                        modifier = Modifier.fillMaxWidth(),
                        variant = CardVariant.DEFAULT
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "SECURE CREDENTIAL VAULT",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Stored locally using Android Keystore encryption. Never hardcoded into source code.",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // API Key Field
                        OutlinedTextField(
                            value = apiKeyInput,
                            onValueChange = { apiKeyInput = it },
                            label = { Text("Binance API Key") },
                            placeholder = { Text("Enter API Key") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_binance_api_key"),
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = TextSecondary)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = BorderSubtle,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Next)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Secret Key Field
                        OutlinedTextField(
                            value = secretKeyInput,
                            onValueChange = { secretKeyInput = it },
                            label = { Text("Binance Secret Key") },
                            placeholder = { Text("Enter Secret Key") },
                            singleLine = true,
                            visualTransformation = if (showSecret) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_binance_secret_key"),
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = TextSecondary)
                            },
                            trailingIcon = {
                                IconButton(onClick = { showSecret = !showSecret }) {
                                    Icon(
                                        imageVector = if (showSecret) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (showSecret) "Hide Secret" else "Show Secret",
                                        tint = TextSecondary
                                    )
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyanAccent,
                                unfocusedBorderColor = BorderSubtle,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() })
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AppButton(
                                text = "Save Credentials",
                                onClick = {
                                    if (apiKeyInput.isNotBlank() && secretKeyInput.isNotBlank()) {
                                        onSaveCredentials(apiKeyInput, secretKeyInput)
                                        credentialSavedNotification = true
                                        apiKeyInput = ""
                                        secretKeyInput = ""
                                        focusManager.clearFocus()
                                    }
                                },
                                style = ButtonStyle.SUCCESS,
                                modifier = Modifier.weight(1f),
                                testTag = "btn_save_binance_credentials"
                            )

                            if (state.hasSavedBinanceCredentials) {
                                AppButton(
                                    text = "Clear Vault",
                                    onClick = onClearCredentials,
                                    style = ButtonStyle.DANGER,
                                    modifier = Modifier.weight(1f),
                                    testTag = "btn_clear_binance_credentials"
                                )
                            }
                        }

                        if (credentialSavedNotification) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = BullGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Credentials securely encrypted. Trading remains OFF.",
                                    fontSize = 11.sp,
                                    color = BullGreen
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
}
