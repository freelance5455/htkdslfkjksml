package com.example.features.market

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.MarketCategory
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Clean, touch-friendly market switcher for Crypto ↔ Forex ↔ Gold.
 * Meets Android accessibility guidelines with >=48dp touch targets.
 */
@Composable
fun MarketSwitcher(
    selectedMarket: MarketCategory,
    onMarketSelected: (MarketCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        MarketCategory.entries.forEach { category ->
            val isSelected = selectedMarket == category
            val tabBgColor by animateColorAsState(
                targetValue = if (isSelected) Color(0xFF00384D) else Color.Transparent,
                label = "market_tab_bg"
            )
            val tabBorderColor by animateColorAsState(
                targetValue = if (isSelected) CyanAccent.copy(alpha = 0.6f) else Color.Transparent,
                label = "market_tab_border"
            )
            val textColor by animateColorAsState(
                targetValue = if (isSelected) CyanAccent else TextSecondary,
                label = "market_tab_text"
            )

            val icon: ImageVector = when (category) {
                MarketCategory.CRYPTO -> Icons.Default.CurrencyBitcoin
                MarketCategory.FOREX -> Icons.Default.CurrencyExchange
                MarketCategory.GOLD -> Icons.Default.MonetizationOn
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(tabBgColor)
                    .border(1.dp, tabBorderColor, RoundedCornerShape(8.dp))
                    .clickable { onMarketSelected(category) }
                    .padding(horizontal = 8.dp, vertical = 10.dp)
                    .testTag("market_tab_${category.id}"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = category.displayName,
                        tint = textColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = category.displayName,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = textColor
                    )
                }
            }
        }
    }
}
