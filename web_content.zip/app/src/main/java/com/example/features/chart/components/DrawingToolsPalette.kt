package com.example.features.chart.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.HorizontalRule
import androidx.compose.material.icons.filled.LinearScale
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.ViewStream
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.chart.DrawingType
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrawingToolsPalette(
    isOpen: Boolean,
    currentTool: DrawingType,
    onSelectTool: (DrawingType) -> Unit,
    onClearAll: () -> Unit,
    drawingsCount: Int,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Brush,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TECHNICAL DRAWING TOOLS",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Text(
                text = "Tap a drawing tool to activate. Touch and drag across the chart canvas to anchor your markings.",
                fontSize = 11.sp,
                color = TextSecondary,
                modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
            )

            // Drawing Tools List
            val tools = listOf(
                Triple(DrawingType.NONE, "Pan / Pointer", Icons.Default.Close),
                Triple(DrawingType.HORIZONTAL_LINE, "Horizontal Price Line", Icons.Default.HorizontalRule),
                Triple(DrawingType.TREND_LINE, "Trend Line", Icons.Default.ShowChart),
                Triple(DrawingType.VERTICAL_LINE, "Vertical Time Line", Icons.Default.MoreHoriz),
                Triple(DrawingType.SUPPORT_RESISTANCE_ZONE, "Support / Resistance Zone", Icons.Default.ViewStream),
                Triple(DrawingType.FIBONACCI_RETRACEMENT, "Fibonacci Retracement (0 - 100%)", Icons.Default.LinearScale)
            )

            tools.forEach { (type, label, icon) ->
                val isSelected = currentTool == type
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyanAccent.copy(alpha = 0.2f) else SurfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) CyanAccent else BorderSubtle,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable {
                            onSelectTool(type)
                            onDismiss()
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("drawing_tool_${type.name}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) CyanAccent else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = label,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) CyanAccent else TextPrimary
                    )
                }
            }

            if (drawingsCount > 0) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(BearRed.copy(alpha = 0.15f))
                        .border(1.dp, BearRed.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .clickable {
                            onClearAll()
                            onDismiss()
                        }
                        .padding(12.dp)
                        .testTag("btn_clear_all_drawings"),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Clear All",
                        tint = BearRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Clear All Drawings ($drawingsCount)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = BearRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
