package com.example.features.portfolio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.data.local.entity.TradeRecordEntity
import com.example.core.model.LiveTradingState
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.AppConfirmationDialog
import com.example.core.ui.components.ButtonStyle
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.EmptyState
import com.example.core.ui.components.PageContainer
import com.example.core.ui.components.SectionHeader
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MainUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PortfolioScreen(
    state: MainUiState,
    onResetAccount: () -> Unit,
    onClosePosition: (Long) -> Unit = {},
    onEmergencyStop: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var showResetDialog by remember { mutableStateOf(false) }
    var showPanicStopDialog by remember { mutableStateOf(false) }

    // Mode Selector: 0 = Paper Portfolio, 1 = Live Portfolio (STRICT ISOLATION)
    var portfolioMode by remember { mutableIntStateOf(if (state.isLiveTradingEnabled) 1 else 0) }

    // Sub-tab: 0 = Open Positions, 1 = Trade History, 2 = Statistics & Analytics
    var activeSubTab by remember { mutableIntStateOf(0) }

    // Selected trade for detail modal
    var selectedTradeForDetail by remember { mutableStateOf<TradeRecordEntity?>(null) }

    // Filter state for Trade History
    var filterState by remember { mutableStateOf(PortfolioFilterState()) }

    // Separate datasets strictly by mode
    val currentModeTrades = remember(state.trades, portfolioMode) {
        if (portfolioMode == 0) {
            state.trades.filter { it.isPaper }
        } else {
            state.trades.filter { !it.isPaper }
        }
    }

    val currentOpenTrades = remember(currentModeTrades) {
        currentModeTrades.filter { it.isOpen }
    }

    val currentClosedTrades = remember(currentModeTrades) {
        currentModeTrades.filter { !it.isOpen }
    }

    val currentFilteredTrades = remember(currentModeTrades, filterState) {
        filterState.apply(currentModeTrades)
    }

    val currentStats = remember(currentModeTrades) {
        calculatePortfolioStatistics(currentModeTrades)
    }

    // Dialogs
    if (showResetDialog) {
        AppConfirmationDialog(
            title = "Reset Paper Account?",
            message = "This will restore your starting Paper balance to $10,000.00 USDT and reset test paper trade records. This action cannot be undone.",
            confirmText = "Reset to $10,000",
            cancelText = "Keep Current",
            isDestructive = true,
            onConfirm = {
                onResetAccount()
                showResetDialog = false
            },
            onDismiss = { showResetDialog = false }
        )
    }

    if (showPanicStopDialog) {
        val count = currentOpenTrades.size
        val modeStr = if (portfolioMode == 0) "PAPER" else "LIVE"
        AppConfirmationDialog(
            title = "EMERGENCY PANIC CLOSE ($modeStr)",
            message = "This will instantly close all $count open $modeStr position(s) at market price and disarm active trading. Are you sure?",
            confirmText = "PANIC CLOSE ALL ($count)",
            cancelText = "CANCEL",
            isDestructive = true,
            onConfirm = {
                onEmergencyStop()
                showPanicStopDialog = false
            },
            onDismiss = { showPanicStopDialog = false }
        )
    }

    selectedTradeForDetail?.let { trade ->
        TradeDetailDialog(
            trade = trade,
            currentMarketPrice = state.currentMarketPrice,
            onDismiss = { selectedTradeForDetail = null },
            onClosePosition = if (trade.isOpen) onClosePosition else null
        )
    }

    PageContainer(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = "Portfolio & Trade History",
                subtitle = "Comprehensive persistent ledger, positions & performance"
            )

            // Primary Mode Selector: [ PAPER PORTFOLIO ] vs [ LIVE PORTFOLIO ]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                    .padding(4.dp)
                    .testTag("portfolio_mode_selector"),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Paper Selector
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (portfolioMode == 0) CyanAccent else Color.Transparent)
                        .clickable { portfolioMode = 0 }
                        .padding(vertical = 10.dp)
                        .testTag("tab_paper_portfolio"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "PAPER PORTFOLIO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = if (portfolioMode == 0) SurfaceDark else TextSecondary,
                        letterSpacing = 0.5.sp
                    )
                }

                // Live Selector
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (portfolioMode == 1) WarningAmber else Color.Transparent)
                        .clickable { portfolioMode = 1 }
                        .padding(vertical = 10.dp)
                        .testTag("tab_live_portfolio"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "LIVE PORTFOLIO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        color = if (portfolioMode == 1) SurfaceDark else TextSecondary,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Mode Overview Card (STRICT ISOLATION)
            if (portfolioMode == 0) {
                // Dedicated Paper Portfolio Card
                PaperPortfolioCard(
                    state = state,
                    openCount = currentOpenTrades.size,
                    stats = currentStats,
                    onShowResetDialog = { showResetDialog = true },
                    onShowPanicDialog = { showPanicStopDialog = true }
                )
            } else {
                // Dedicated Live Portfolio Card
                LivePortfolioCard(
                    state = state,
                    openCount = currentOpenTrades.size,
                    stats = currentStats,
                    onShowPanicDialog = { showPanicStopDialog = true }
                )
            }

            // Sub-tabs: Open Positions (N) | Trade History (N) | Performance Analytics
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceElevated, RoundedCornerShape(8.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (activeSubTab == 0) (if (portfolioMode == 0) CyanAccent else WarningAmber) else Color.Transparent)
                        .clickable { activeSubTab = 0 }
                        .padding(vertical = 8.dp)
                        .testTag("subtab_open_positions"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Open (${currentOpenTrades.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeSubTab == 0) SurfaceDark else TextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (activeSubTab == 1) (if (portfolioMode == 0) CyanAccent else WarningAmber) else Color.Transparent)
                        .clickable { activeSubTab = 1 }
                        .padding(vertical = 8.dp)
                        .testTag("subtab_history"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "History (${currentModeTrades.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeSubTab == 1) SurfaceDark else TextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (activeSubTab == 2) (if (portfolioMode == 0) CyanAccent else WarningAmber) else Color.Transparent)
                        .clickable { activeSubTab = 2 }
                        .padding(vertical = 8.dp)
                        .testTag("subtab_analytics"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Analytics",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeSubTab == 2) SurfaceDark else TextPrimary
                    )
                }
            }

            // Sub-tab Content
            when (activeSubTab) {
                0 -> {
                    // TAB 0: OPEN POSITIONS
                    OpenPositionsView(
                        openTrades = currentOpenTrades,
                        currentMarketPrice = state.currentMarketPrice,
                        selectedSymbol = state.selectedSymbol,
                        isPaper = portfolioMode == 0,
                        onSelectTrade = { selectedTradeForDetail = it },
                        onClosePosition = onClosePosition
                    )
                }
                1 -> {
                    // TAB 1: TRADE HISTORY
                    TradeHistoryView(
                        trades = currentFilteredTrades,
                        totalCount = currentModeTrades.size,
                        isPaper = portfolioMode == 0,
                        filterState = filterState,
                        onFilterChange = { filterState = it },
                        onSelectTrade = { selectedTradeForDetail = it }
                    )
                }
                2 -> {
                    // TAB 2: STATISTICS & ANALYTICS
                    PortfolioAnalyticsView(
                        stats = currentStats,
                        isPaper = portfolioMode == 0,
                        balance = if (portfolioMode == 0) state.paperBalance else state.liveBalance,
                        equity = if (portfolioMode == 0) state.paperEquity else state.liveEquity
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

// ----------------------------------------------------------------------------
// Dedicated Mode Header Cards (Paper vs Live)
// ----------------------------------------------------------------------------

@Composable
private fun PaperPortfolioCard(
    state: MainUiState,
    openCount: Int,
    stats: PortfolioStatistics,
    onShowResetDialog: () -> Unit,
    onShowPanicDialog: () -> Unit
) {
    AppCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("paper_portfolio_card"),
        variant = CardVariant.DEFAULT
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PAPER NET EQUITY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(CyanAccent.copy(alpha = 0.2f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "VIRTUAL ACCOUNT",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "$${String.format(Locale.US, "%,.2f", state.paperEquity)}",
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            letterSpacing = (-0.5).sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Available Cash: $${String.format(Locale.US, "%,.2f", state.paperBalance)} USDT",
                fontSize = 11.sp,
                color = TextSecondary
            )

            if (stats.closedTradesCount > 0) {
                Text(
                    text = "Win Rate: ${String.format(Locale.US, "%.1f", stats.winRatePct)}%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (stats.winRatePct >= 50.0) BullGreen else WarningAmber
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Breakdown Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceElevated, RoundedCornerShape(8.dp))
                .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "UNREALIZED P&L", fontSize = 10.sp, color = TextSecondary)
                val color = when {
                    state.unrealizedPnl > 0.0 -> BullGreen
                    state.unrealizedPnl < 0.0 -> BearRed
                    else -> TextSecondary
                }
                val sign = if (state.unrealizedPnl > 0.0) "+" else ""
                Text(
                    text = "$sign$${String.format(Locale.US, "%,.2f", state.unrealizedPnl)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = color,
                    fontFamily = FontFamily.Monospace
                )
            }
            Column {
                Text(text = "REALIZED P&L", fontSize = 10.sp, color = TextSecondary)
                val color = when {
                    state.realizedPnl > 0.0 -> BullGreen
                    state.realizedPnl < 0.0 -> BearRed
                    else -> TextSecondary
                }
                val sign = if (state.realizedPnl > 0.0) "+" else ""
                Text(
                    text = "$sign$${String.format(Locale.US, "%,.2f", state.realizedPnl)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = color,
                    fontFamily = FontFamily.Monospace
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "NET P&L (FEES)", fontSize = 10.sp, color = TextSecondary)
                val net = stats.netPnl
                val color = when {
                    net > 0.0 -> BullGreen
                    net < 0.0 -> BearRed
                    else -> TextSecondary
                }
                val sign = if (net > 0.0) "+" else ""
                Text(
                    text = "$sign$${String.format(Locale.US, "%,.2f", net)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Action Buttons Row: Reset & Panic Stop
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AppButton(
                text = "Reset Balance",
                onClick = onShowResetDialog,
                style = ButtonStyle.OUTLINE,
                modifier = Modifier.weight(1f),
                testTag = "btn_reset_paper_account"
            )

            if (openCount > 0) {
                AppButton(
                    text = "Panic Close All ($openCount)",
                    onClick = onShowPanicDialog,
                    style = ButtonStyle.DANGER,
                    modifier = Modifier.weight(1f),
                    testTag = "btn_portfolio_panic_close_paper"
                )
            }
        }
    }
}

@Composable
private fun LivePortfolioCard(
    state: MainUiState,
    openCount: Int,
    stats: PortfolioStatistics,
    onShowPanicDialog: () -> Unit
) {
    AppCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("live_portfolio_card"),
        variant = CardVariant.DEFAULT
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = WarningAmber,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "BINANCE LIVE EQUITY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary,
                    letterSpacing = 0.5.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (state.isLiveTradingEnabled) BullGreen.copy(alpha = 0.2f) else BorderSubtle)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = if (state.isLiveTradingEnabled) "LIVE ARMED" else "LIVE OFF",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (state.isLiveTradingEnabled) BullGreen else TextDisabled
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "$${String.format(Locale.US, "%,.2f", state.liveEquity)}",
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            letterSpacing = (-0.5).sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Available Quote: $${String.format(Locale.US, "%,.2f", state.liveAvailableBalance)} USDT",
                fontSize = 11.sp,
                color = TextSecondary
            )

            Text(
                text = "Total Fees: $${String.format(Locale.US, "%.4f", state.liveTotalFees)}",
                fontSize = 11.sp,
                color = WarningAmber
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Breakdown Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceElevated, RoundedCornerShape(8.dp))
                .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(text = "UNREALIZED P&L", fontSize = 10.sp, color = TextSecondary)
                val color = when {
                    state.liveUnrealizedPnl > 0.0 -> BullGreen
                    state.liveUnrealizedPnl < 0.0 -> BearRed
                    else -> TextSecondary
                }
                val sign = if (state.liveUnrealizedPnl > 0.0) "+" else ""
                Text(
                    text = "$sign$${String.format(Locale.US, "%,.2f", state.liveUnrealizedPnl)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = color,
                    fontFamily = FontFamily.Monospace
                )
            }
            Column {
                Text(text = "REALIZED P&L", fontSize = 10.sp, color = TextSecondary)
                val color = when {
                    state.liveRealizedPnl > 0.0 -> BullGreen
                    state.liveRealizedPnl < 0.0 -> BearRed
                    else -> TextSecondary
                }
                val sign = if (state.liveRealizedPnl > 0.0) "+" else ""
                Text(
                    text = "$sign$${String.format(Locale.US, "%,.2f", state.liveRealizedPnl)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = color,
                    fontFamily = FontFamily.Monospace
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "NET P&L", fontSize = 10.sp, color = TextSecondary)
                val net = state.liveRealizedPnl - state.liveTotalFees
                val color = when {
                    net > 0.0 -> BullGreen
                    net < 0.0 -> BearRed
                    else -> TextSecondary
                }
                val sign = if (net > 0.0) "+" else ""
                Text(
                    text = "$sign$${String.format(Locale.US, "%,.2f", net)}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        if (openCount > 0) {
            Spacer(modifier = Modifier.height(14.dp))
            AppButton(
                text = "Panic Close All Live ($openCount)",
                onClick = onShowPanicDialog,
                style = ButtonStyle.DANGER,
                modifier = Modifier.fillMaxWidth(),
                testTag = "btn_portfolio_panic_close_live"
            )
        }
    }
}

// ----------------------------------------------------------------------------
// Open Positions View (Sub-Tab 0)
// ----------------------------------------------------------------------------

@Composable
private fun OpenPositionsView(
    openTrades: List<TradeRecordEntity>,
    currentMarketPrice: Double,
    selectedSymbol: String,
    isPaper: Boolean,
    onSelectTrade: (TradeRecordEntity) -> Unit,
    onClosePosition: (Long) -> Unit
) {
    AppCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("open_positions_card"),
        variant = CardVariant.DEFAULT
    ) {
        Text(
            text = if (isPaper) "ACTIVE PAPER POSITIONS (${openTrades.size})" else "ACTIVE LIVE POSITIONS (${openTrades.size})",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(10.dp))

        if (openTrades.isEmpty()) {
            EmptyState(
                icon = Icons.Default.Info,
                title = if (isPaper) "No Open Paper Positions" else "No Open Live Positions",
                description = "Open positions appear here with real-time mark-to-market P&L."
            )
        } else {
            openTrades.forEach { trade ->
                val isLong = trade.side.equals("BUY", ignoreCase = true)
                val effectivePrice = if (trade.symbol.equals(selectedSymbol, ignoreCase = true) && currentMarketPrice > 0.0) {
                    currentMarketPrice
                } else {
                    trade.price
                }
                val pnl = if (isLong) {
                    (effectivePrice - trade.price) * trade.quantity
                } else {
                    (trade.price - effectivePrice) * trade.quantity
                }
                val pnlPct = if (trade.price > 0.0) (pnl / (trade.price * trade.quantity)) * 100.0 else 0.0
                val pnlColor = if (pnl >= 0.0) BullGreen else BearRed
                val sign = if (pnl >= 0.0) "+" else ""

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceElevated)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                        .clickable { onSelectTrade(trade) }
                        .padding(12.dp)
                        .testTag("open_position_item_${trade.id}"),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isLong) BullGreen.copy(alpha = 0.2f) else BearRed.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isLong) "BUY / LONG" else "SELL / SHORT",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isLong) BullGreen else BearRed
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = trade.symbol,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Text(
                            text = "$sign$${String.format(Locale.US, "%,.2f", pnl)} (${String.format(Locale.US, "%.2f", pnlPct)}%)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = pnlColor,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "Entry", fontSize = 10.sp, color = TextSecondary)
                            Text(
                                text = "$${String.format(Locale.US, "%,.2f", trade.price)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column {
                            Text(text = "Current", fontSize = 10.sp, color = TextSecondary)
                            Text(
                                text = "$${String.format(Locale.US, "%,.2f", effectivePrice)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Size", fontSize = 10.sp, color = TextSecondary)
                            Text(
                                text = "${String.format(Locale.US, "%.4f", trade.quantity)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }
                    }

                    // SL/TP Display
                    if (trade.stopLoss != null || trade.takeProfit != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            trade.stopLoss?.let { sl ->
                                Text(
                                    text = "SL: $${String.format(Locale.US, "%,.2f", sl)}",
                                    fontSize = 10.sp,
                                    color = BearRed
                                )
                            }
                            trade.takeProfit?.let { tp ->
                                Text(
                                    text = "TP: $${String.format(Locale.US, "%,.2f", tp)}",
                                    fontSize = 10.sp,
                                    color = BullGreen
                                )
                            }
                        }
                    }

                    // Close Position Button
                    AppButton(
                        text = "CLOSE POSITION",
                        onClick = { onClosePosition(trade.id) },
                        style = ButtonStyle.OUTLINE,
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "btn_close_trade_${trade.id}"
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// Trade History View (Sub-Tab 1)
// ----------------------------------------------------------------------------

@Composable
private fun TradeHistoryView(
    trades: List<TradeRecordEntity>,
    totalCount: Int,
    isPaper: Boolean,
    filterState: PortfolioFilterState,
    onFilterChange: (PortfolioFilterState) -> Unit,
    onSelectTrade: (TradeRecordEntity) -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())

    AppCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("trade_history_card"),
        variant = CardVariant.DEFAULT
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = null,
                    tint = if (isPaper) CyanAccent else WarningAmber,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isPaper) "PAPER TRADE HISTORY" else "LIVE TRADE HISTORY",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Text(
                text = "${trades.size} of $totalCount Records",
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar & Filter Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceElevated)
                .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            BasicTextField(
                value = filterState.searchQuery,
                onValueChange = { onFilterChange(filterState.copy(searchQuery = it)) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("history_search_input"),
                textStyle = TextStyle(color = TextPrimary, fontSize = 12.sp),
                cursorBrush = SolidColor(if (isPaper) CyanAccent else WarningAmber),
                singleLine = true,
                decorationBox = { innerTextField ->
                    if (filterState.searchQuery.isEmpty()) {
                        Text("Search symbol or order ID...", fontSize = 12.sp, color = TextDisabled)
                    }
                    innerTextField()
                }
            )
            if (filterState.searchQuery.isNotEmpty()) {
                IconButton(
                    onClick = { onFilterChange(filterState.copy(searchQuery = "")) },
                    modifier = Modifier.size(20.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = "Clear search",
                        tint = TextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Horizontal Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Market Filter Chip
            FilterChipItem(
                label = filterState.marketFilter.label,
                isSelected = filterState.marketFilter != MarketFilter.ALL,
                onClick = {
                    val next = when (filterState.marketFilter) {
                        MarketFilter.ALL -> MarketFilter.CRYPTO
                        MarketFilter.CRYPTO -> MarketFilter.FOREX
                        MarketFilter.FOREX -> MarketFilter.GOLD
                        MarketFilter.GOLD -> MarketFilter.ALL
                    }
                    onFilterChange(filterState.copy(marketFilter = next))
                }
            )

            // Side Filter Chip
            FilterChipItem(
                label = filterState.sideFilter.label,
                isSelected = filterState.sideFilter != SideFilter.ALL,
                onClick = {
                    val next = when (filterState.sideFilter) {
                        SideFilter.ALL -> SideFilter.BUY
                        SideFilter.BUY -> SideFilter.SELL
                        SideFilter.SELL -> SideFilter.ALL
                    }
                    onFilterChange(filterState.copy(sideFilter = next))
                }
            )

            // State (Open/Closed) Filter Chip
            FilterChipItem(
                label = filterState.stateFilter.label,
                isSelected = filterState.stateFilter != PositionStateFilter.ALL,
                onClick = {
                    val next = when (filterState.stateFilter) {
                        PositionStateFilter.ALL -> PositionStateFilter.OPEN
                        PositionStateFilter.OPEN -> PositionStateFilter.CLOSED
                        PositionStateFilter.CLOSED -> PositionStateFilter.ALL
                    }
                    onFilterChange(filterState.copy(stateFilter = next))
                }
            )

            // Outcome Filter Chip
            FilterChipItem(
                label = filterState.outcomeFilter.label,
                isSelected = filterState.outcomeFilter != OutcomeFilter.ALL,
                onClick = {
                    val next = when (filterState.outcomeFilter) {
                        OutcomeFilter.ALL -> OutcomeFilter.PROFITABLE
                        OutcomeFilter.PROFITABLE -> OutcomeFilter.LOSING
                        OutcomeFilter.LOSING -> OutcomeFilter.ALL
                    }
                    onFilterChange(filterState.copy(outcomeFilter = next))
                }
            )

            // Reset filters if active
            if (filterState.isActive) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(SurfaceElevated)
                        .border(1.dp, BearRed.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .clickable { onFilterChange(PortfolioFilterState()) }
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Reset Filters", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = BearRed)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Trades List
        if (trades.isEmpty()) {
            EmptyState(
                icon = Icons.Default.Info,
                title = if (totalCount == 0) (if (isPaper) "No Paper Trades Yet" else "No Live Trades Yet") else "No Matching Trades",
                description = if (totalCount == 0) "Completed trades are logged permanently in the Room database." else "Try adjusting or clearing active search filters."
            )
        } else {
            trades.forEach { trade ->
                val isLong = trade.side.equals("BUY", ignoreCase = true)
                val marketCat = PortfolioFilterState.resolveMarketCategory(trade.symbol)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceElevated)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                        .clickable { onSelectTrade(trade) }
                        .padding(10.dp)
                        .testTag("history_item_${trade.id}"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = trade.side,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isLong) BullGreen else BearRed
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = trade.symbol,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(SurfaceDark)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = marketCat,
                                    fontSize = 8.sp,
                                    color = TextSecondary
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (trade.isOpen) "OPEN" else trade.status,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (trade.isOpen) CyanAccent else TextDisabled
                            )
                        }
                        Text(
                            text = dateFormat.format(Date(trade.timestamp)),
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        if (!trade.isOpen && trade.realizedPnl != null) {
                            val pnl = trade.realizedPnl
                            val color = if (pnl >= 0.0) BullGreen else BearRed
                            val sign = if (pnl >= 0.0) "+" else ""
                            Text(
                                text = "$sign$${String.format(Locale.US, "%,.2f", pnl)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = color,
                                fontFamily = FontFamily.Monospace
                            )
                        } else {
                            Text(
                                text = "$${String.format(Locale.US, "%,.2f", trade.total)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Text(
                            text = "${String.format(Locale.US, "%.4f", trade.quantity)} @ $${String.format(Locale.US, "%,.2f", trade.price)}",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterChipItem(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isSelected) CyanAccent.copy(alpha = 0.2f) else SurfaceElevated)
            .border(1.dp, if (isSelected) CyanAccent else BorderSubtle, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) CyanAccent else TextSecondary
        )
    }
}

// ----------------------------------------------------------------------------
// Statistics & Analytics View (Sub-Tab 2)
// ----------------------------------------------------------------------------

@Composable
private fun PortfolioAnalyticsView(
    stats: PortfolioStatistics,
    isPaper: Boolean,
    balance: Double,
    equity: Double
) {
    AppCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("portfolio_analytics_card"),
        variant = CardVariant.DEFAULT
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.BarChart,
                    contentDescription = null,
                    tint = if (isPaper) CyanAccent else WarningAmber,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isPaper) "PAPER PERFORMANCE ANALYTICS" else "LIVE PERFORMANCE ANALYTICS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(SurfaceElevated)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "${stats.totalTrades} Total Trades",
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Win Rate & Profit Factor Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Win Rate
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(text = "WIN RATE", fontSize = 10.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${String.format(Locale.US, "%.1f", stats.winRatePct)}%",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = if (stats.winRatePct >= 50.0) BullGreen else WarningAmber,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "${stats.winningTrades}W / ${stats.losingTrades}L",
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }

            // Profit Factor
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(text = "PROFIT FACTOR", fontSize = 10.sp, color = TextSecondary)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = String.format(Locale.US, "%.2f", stats.profitFactor),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = if (stats.profitFactor >= 1.5) BullGreen else TextPrimary,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Gross Win / Loss",
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // P&L Metrics Grid
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceElevated)
                .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AnalyticsRow("Gross Realized Profit", "+$${String.format(Locale.US, "%,.2f", stats.totalGrossProfit)}", BullGreen)
            AnalyticsRow("Gross Realized Loss", "-$${String.format(Locale.US, "%,.2f", stats.totalGrossLoss)}", BearRed)
            AnalyticsRow("Total Commissions / Fees", "-$${String.format(Locale.US, "%,.2f", stats.totalFees)}", WarningAmber)
            AnalyticsRow(
                "Net Performance",
                "${if (stats.netPnl >= 0.0) "+" else ""}$${String.format(Locale.US, "%,.2f", stats.netPnl)}",
                if (stats.netPnl >= 0.0) BullGreen else BearRed,
                isBold = true
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Trade Size & Duration Analytics
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceElevated)
                .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AnalyticsRow("Average Winning Trade", "+$${String.format(Locale.US, "%,.2f", stats.averageWinningTrade)}", BullGreen)
            AnalyticsRow("Average Losing Trade", "-$${String.format(Locale.US, "%,.2f", stats.averageLosingTrade)}", BearRed)
            AnalyticsRow("Largest Winning Trade", "+$${String.format(Locale.US, "%,.2f", stats.largestWinningTrade)}", BullGreen)
            AnalyticsRow("Largest Losing Trade", "$${String.format(Locale.US, "%,.2f", stats.largestLosingTrade)}", BearRed)
            AnalyticsRow("Average Trade Duration", stats.averageDurationFormatted, TextPrimary)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Equity Progression Summary
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceElevated)
                .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(text = "PORTFOLIO PROGRESSION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
            AnalyticsRow("Current Cash Balance", "$${String.format(Locale.US, "%,.2f", balance)} USDT", TextPrimary)
            AnalyticsRow("Current Net Equity", "$${String.format(Locale.US, "%,.2f", equity)} USDT", TextPrimary, isBold = true)
        }
    }
}

@Composable
private fun AnalyticsRow(
    label: String,
    value: String,
    valueColor: Color,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.sp, color = TextSecondary)
        Text(
            text = value,
            fontSize = 11.sp,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = valueColor,
            fontFamily = FontFamily.Monospace
        )
    }
}
