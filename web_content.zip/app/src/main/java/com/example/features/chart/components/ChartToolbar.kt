package com.example.features.chart.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.MarketCategory
import com.example.core.model.Timeframe
import com.example.core.model.chart.DrawingType
import com.example.core.model.chart.TradeSide
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ChartTopHeader(
    symbol: String,
    market: MarketCategory,
    timeframe: Timeframe,
    currentPrice: Double?,
    tradingMode: String,
    isFullscreen: Boolean,
    onOpenSymbolPicker: () -> Unit,
    onOpenTimeframePicker: () -> Unit,
    onOpenOrderEntry: (TradeSide) -> Unit,
    onToggleFullscreen: () -> Unit,
    onFloatClick: () -> Unit,
    onExportClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceDark)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Symbol & Market Badge Clickable Selector
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .clickable { onOpenSymbolPicker() }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag("chart_symbol_selector")
            ) {
                Box(
                    modifier = Modifier
                        .background(CyanAccent.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = market.displayName.take(4).uppercase(),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = symbol,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            // Timeframe quick pill (opens 15-timeframe sheet)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .clickable { onOpenTimeframePicker() }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag("chart_timeframe_selector")
            ) {
                Text(
                    text = timeframe.label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "▼",
                    fontSize = 8.sp,
                    color = TextSecondary
                )
            }

            // Real-time Current Price Readout
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (currentPrice != null) "%.2f".format(currentPrice) else "...",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = BullGreen,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = tradingMode,
                    fontSize = 9.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Fullscreen & Float Actions
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onExportClick != null) {
                    IconButton(
                        onClick = onExportClick,
                        modifier = Modifier.size(36.dp).testTag("btn_chart_export")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share Chart Snapshot",
                            tint = CyanAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                IconButton(
                    onClick = onFloatClick,
                    modifier = Modifier.size(36.dp).testTag("btn_chart_float")
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Float Chart",
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onToggleFullscreen,
                    modifier = Modifier.size(36.dp).testTag("btn_chart_fullscreen")
                ) {
                    Icon(
                        imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                        contentDescription = if (isFullscreen) "Exit Fullscreen" else "Fullscreen",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Direct BUY and SELL trading controls directly on the chart
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // BUY button
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(BullGreen)
                    .clickable { onOpenOrderEntry(TradeSide.BUY) }
                    .testTag("chart_buy_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "BUY",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.Black,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (currentPrice != null) "%.2f".format(currentPrice) else "",
                        fontSize = 10.sp,
                        color = Color.Black.copy(alpha = 0.8f),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // SELL button
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(BearRed)
                    .clickable { onOpenOrderEntry(TradeSide.SELL) }
                    .testTag("chart_sell_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SELL",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (currentPrice != null) "%.2f".format(currentPrice) else "",
                        fontSize = 10.sp,
                        color = Color.White.copy(alpha = 0.8f),
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun ChartSecondaryToolbar(
    showVolume: Boolean,
    onToggleVolume: () -> Unit,
    showIndicators: Boolean,
    activeIndicatorsCount: Int,
    onOpenIndicators: () -> Unit,
    activeDrawingTool: DrawingType,
    onOpenDrawingTools: () -> Unit,
    onClearDrawings: () -> Unit,
    drawingsCount: Int,
    showSignals: Boolean,
    onToggleSignals: () -> Unit,
    onExportChart: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(SurfaceElevated)
            .border(1.dp, BorderSubtle, RoundedCornerShape(0.dp))
            .horizontalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Snapshot / Export Button
        if (onExportChart != null) {
            ToolbarButton(
                label = "Export",
                isActive = false,
                icon = Icons.Default.CameraAlt,
                onClick = onExportChart,
                tint = CyanAccent,
                testTag = "toolbar_btn_export"
            )
        }

        // Indicators Button with Active Count Badge
        ToolbarButton(
            label = if (activeIndicatorsCount > 0 && showIndicators) "Indicators ($activeIndicatorsCount)" else "Indicators",
            isActive = showIndicators,
            icon = Icons.Default.ShowChart,
            onClick = onOpenIndicators,
            testTag = "toolbar_btn_indicators"
        )

        // Volume Toggle (Default OFF)
        ToolbarButton(
            label = "Volume",
            isActive = showVolume,
            icon = Icons.Default.BarChart,
            onClick = onToggleVolume,
            testTag = "toolbar_btn_volume"
        )

        // Drawing Tools Palette Button
        ToolbarButton(
            label = if (activeDrawingTool != DrawingType.NONE) activeDrawingTool.label else "Draw",
            isActive = activeDrawingTool != DrawingType.NONE,
            icon = Icons.Default.Brush,
            onClick = onOpenDrawingTools,
            testTag = "toolbar_btn_draw"
        )

        // Clear Drawings Button (if any drawings exist)
        if (drawingsCount > 0) {
            ToolbarButton(
                label = "Clear ($drawingsCount)",
                isActive = false,
                icon = Icons.Default.DeleteOutline,
                onClick = onClearDrawings,
                tint = TextSecondary,
                testTag = "toolbar_btn_clear_drawings"
            )
        }

        // Signals Toggle Button
        ToolbarButton(
            label = "Signals",
            isActive = showSignals,
            icon = Icons.Default.Layers,
            onClick = onToggleSignals,
            testTag = "toolbar_btn_signals"
        )
    }
}

@Composable
private fun ToolbarButton(
    label: String,
    isActive: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color? = null,
    testTag: String = ""
) {
    val activeBg by animateColorAsState(
        targetValue = if (isActive) CyanAccent.copy(alpha = 0.2f) else Color.Transparent,
        label = "bg"
    )
    val activeBorder by animateColorAsState(
        targetValue = if (isActive) CyanAccent else BorderSubtle,
        label = "border"
    )
    val contentColor = tint ?: if (isActive) CyanAccent else TextSecondary

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(activeBg)
            .border(1.dp, activeBorder, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 5.dp)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = contentColor,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
            color = contentColor
        )
    }
}
