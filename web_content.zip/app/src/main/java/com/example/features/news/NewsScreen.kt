package com.example.features.news

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RssFeed
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.MarketCategory
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.ButtonStyle
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.PageContainer
import com.example.core.ui.components.SectionHeader
import com.example.features.news.model.NewsArticle
import com.example.features.news.model.NewsImpact
import com.example.features.news.model.NewsSentiment
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MainUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NewsScreen(
    state: MainUiState,
    onBack: () -> Unit,
    onRefreshNews: () -> Unit,
    onSearchQueryChanged: (String) -> Unit,
    onMarketFilterSelected: (MarketCategory?) -> Unit,
    onSentimentFilterSelected: (NewsSentiment?) -> Unit,
    onImpactFilterSelected: (NewsImpact?) -> Unit,
    onToggleOnlySelectedSymbol: (Boolean) -> Unit,
    onToggleOnlyBreaking: (Boolean) -> Unit,
    onNavigateToConfig: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val horizontalScroll = rememberScrollState()

    PageContainer(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("btn_news_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = CyanAccent
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(
                            text = "LIVE MARKET NEWS",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = if (state.isNewsCache) "Offline Cached Feed" else "Real-time Macro Intelligence",
                            fontSize = 11.sp,
                            color = if (state.isNewsCache) WarningAmber else TextSecondary
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Status Badge
                    val statusText = when {
                        state.isNewsCache -> "CACHED"
                        state.newsApiConnectionState.isConnected -> "LIVE"
                        state.isNewsLoading -> "FETCHING"
                        else -> "OFFLINE"
                    }
                    val statusColor = when {
                        state.isNewsCache -> WarningAmber
                        state.newsApiConnectionState.isConnected -> BullGreen
                        state.isNewsLoading -> CyanAccent
                        else -> TextDisabled
                    }

                    Box(
                        modifier = Modifier
                            .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = statusText,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusColor
                        )
                    }

                    // Refresh Button
                    IconButton(
                        onClick = onRefreshNews,
                        enabled = !state.isNewsLoading,
                        modifier = Modifier.testTag("btn_refresh_news")
                    ) {
                        if (state.isNewsLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = CyanAccent,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh News",
                                tint = CyanAccent
                            )
                        }
                    }
                }
            }

            // Warning Banner if API key not saved
            if (!state.hasSavedNewsApiKey) {
                AppCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .testTag("card_news_key_missing"),
                    variant = CardVariant.DEFAULT
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = WarningAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "News API Key Required",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarningAmber
                            )
                            Text(
                                text = "Configure your News API key in Binance > News API to unlock live headlines and sentiment streams.",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 15.sp
                            )
                        }
                        AppButton(
                            text = "Configure",
                            onClick = onNavigateToConfig,
                            style = ButtonStyle.OUTLINE,
                            modifier = Modifier.width(90.dp),
                            testTag = "btn_nav_news_config"
                        )
                    }
                }
            } else if (state.isNewsCache) {
                // Offline Cache notice
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(WarningAmber.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                        .border(1.dp, WarningAmber.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .padding(bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudOff,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Viewing cached news. Live stream unavailable or disconnected.",
                        fontSize = 11.sp,
                        color = WarningAmber
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Search Bar
            OutlinedTextField(
                value = state.newsSearchQuery,
                onValueChange = onSearchQueryChanged,
                placeholder = { Text("Search headlines, symbols, sources...", fontSize = 12.sp) },
                singleLine = true,
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (state.newsSearchQuery.isNotBlank()) {
                        IconButton(onClick = { onSearchQueryChanged("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear search",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = BorderSubtle,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_news_search")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Market Category Filter Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MarketTabChip(
                    label = "ALL",
                    isSelected = state.selectedNewsMarket == null,
                    onClick = { onMarketFilterSelected(null) },
                    modifier = Modifier.weight(1f),
                    testTag = "filter_market_all"
                )
                MarketTabChip(
                    label = "CRYPTO",
                    isSelected = state.selectedNewsMarket == MarketCategory.CRYPTO,
                    onClick = { onMarketFilterSelected(MarketCategory.CRYPTO) },
                    modifier = Modifier.weight(1f),
                    testTag = "filter_market_crypto"
                )
                MarketTabChip(
                    label = "FOREX",
                    isSelected = state.selectedNewsMarket == MarketCategory.FOREX,
                    onClick = { onMarketFilterSelected(MarketCategory.FOREX) },
                    modifier = Modifier.weight(1f),
                    testTag = "filter_market_forex"
                )
                MarketTabChip(
                    label = "GOLD",
                    isSelected = state.selectedNewsMarket == MarketCategory.GOLD,
                    onClick = { onMarketFilterSelected(MarketCategory.GOLD) },
                    modifier = Modifier.weight(1f),
                    testTag = "filter_market_gold"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Secondary Quick Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(horizontalScroll),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Symbol Filter
                FilterChip(
                    selected = state.filterOnlySelectedSymbol,
                    onClick = { onToggleOnlySelectedSymbol(!state.filterOnlySelectedSymbol) },
                    label = { Text("${state.selectedSymbol} Only", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyanAccent.copy(alpha = 0.2f),
                        selectedLabelColor = CyanAccent
                    ),
                    modifier = Modifier.testTag("filter_selected_symbol")
                )

                // Breaking Filter
                FilterChip(
                    selected = state.selectedNewsImpact == NewsImpact.HIGH,
                    onClick = {
                        val next = if (state.selectedNewsImpact == NewsImpact.HIGH) null else NewsImpact.HIGH
                        onImpactFilterSelected(next)
                    },
                    label = { Text("⚡ High Impact", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BearRed.copy(alpha = 0.2f),
                        selectedLabelColor = BearRed
                    ),
                    modifier = Modifier.testTag("filter_high_impact")
                )

                // Sentiment Filters
                FilterChip(
                    selected = state.selectedNewsSentiment == NewsSentiment.BULLISH,
                    onClick = {
                        val next = if (state.selectedNewsSentiment == NewsSentiment.BULLISH) null else NewsSentiment.BULLISH
                        onSentimentFilterSelected(next)
                    },
                    label = { Text("🟢 Bullish", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BullGreen.copy(alpha = 0.2f),
                        selectedLabelColor = BullGreen
                    ),
                    modifier = Modifier.testTag("filter_bullish")
                )

                FilterChip(
                    selected = state.selectedNewsSentiment == NewsSentiment.BEARISH,
                    onClick = {
                        val next = if (state.selectedNewsSentiment == NewsSentiment.BEARISH) null else NewsSentiment.BEARISH
                        onSentimentFilterSelected(next)
                    },
                    label = { Text("🔴 Bearish", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BearRed.copy(alpha = 0.2f),
                        selectedLabelColor = BearRed
                    ),
                    modifier = Modifier.testTag("filter_bearish")
                )

                FilterChip(
                    selected = state.selectedNewsSentiment == NewsSentiment.NEUTRAL,
                    onClick = {
                        val next = if (state.selectedNewsSentiment == NewsSentiment.NEUTRAL) null else NewsSentiment.NEUTRAL
                        onSentimentFilterSelected(next)
                    },
                    label = { Text("🟡 Neutral", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = WarningAmber.copy(alpha = 0.2f),
                        selectedLabelColor = WarningAmber
                    ),
                    modifier = Modifier.testTag("filter_neutral")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Articles List
            val articles = state.filteredNewsArticles
            if (state.isNewsLoading && articles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = CyanAccent)
                        Text(
                            text = "Streaming live news intelligence...",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }
            } else if (articles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Newspaper,
                            contentDescription = null,
                            tint = TextDisabled,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = if (state.newsErrorMessage != null) "Feed Unavailable" else "No News Found",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = state.newsErrorMessage ?: "No articles match the current filter or search criteria.",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        if (state.hasSavedNewsApiKey) {
                            Spacer(modifier = Modifier.height(8.dp))
                            AppButton(
                                text = "Refresh Feed",
                                onClick = onRefreshNews,
                                style = ButtonStyle.PRIMARY,
                                modifier = Modifier.width(140.dp),
                                testTag = "btn_retry_news_fetch"
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("news_articles_list"),
                    contentPadding = PaddingValues(vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(articles, key = { it.id }) { article ->
                        NewsArticleItem(
                            article = article,
                            onOpenUrl = { url ->
                                if (url.isNotBlank()) {
                                    try {
                                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                        context.startActivity(browserIntent)
                                    } catch (_: Exception) {}
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MarketTabChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) CyanAccent else SurfaceDark)
            .border(
                1.dp,
                if (isSelected) CyanAccent else BorderSubtle,
                RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) SurfaceDark else TextSecondary
        )
    }
}

@Composable
fun NewsArticleItem(
    article: NewsArticle,
    onOpenUrl: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    AppCard(
        modifier = modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .testTag("news_article_${article.id}"),
        variant = CardVariant.DEFAULT
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row: Category Badge + Symbols + Impact + Time
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Category Tag
                    val categoryColor = when (article.marketCategory) {
                        MarketCategory.CRYPTO -> CyanAccent
                        MarketCategory.FOREX -> Color(0xFF64B5F6)
                        MarketCategory.GOLD -> WarningAmber
                    }
                    Box(
                        modifier = Modifier
                            .background(categoryColor.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = article.marketCategory.name,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = categoryColor
                        )
                    }

                    // Breaking Badge
                    if (article.isBreaking) {
                        Box(
                            modifier = Modifier
                                .background(BearRed.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .border(1.dp, BearRed, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "⚡ BREAKING",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = BearRed
                            )
                        }
                    } else if (article.impact == NewsImpact.HIGH) {
                        Box(
                            modifier = Modifier
                                .background(WarningAmber.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "HIGH IMPACT",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = WarningAmber
                            )
                        }
                    }

                    // Relevant Symbols tags
                    article.relevantSymbols.take(3).forEach { sym ->
                        Text(
                            text = "#$sym",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    }
                }

                // Relative time
                Text(
                    text = formatRelativeTime(article.publishedAt),
                    fontSize = 10.sp,
                    color = TextTertiary,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Headline
            Text(
                text = article.headline,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                lineHeight = 18.sp
            )

            // Description
            article.description?.let { desc ->
                if (desc.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = desc,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp,
                        maxLines = if (expanded) 10 else 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer Row: Source + Sentiment Badge + Open Link
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Source
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Newspaper,
                        contentDescription = null,
                        tint = TextTertiary,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = article.source,
                        fontSize = 10.sp,
                        color = TextTertiary,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Sentiment Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(article.sentiment.color.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .border(1.dp, article.sentiment.color.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${article.sentiment.displayBadge} (${article.sentimentScore}%)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = article.sentiment.color
                        )
                    }

                    if (article.url.isNotBlank()) {
                        IconButton(
                            onClick = { onOpenUrl(article.url) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = "Open Source Article",
                                tint = CyanAccent,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatRelativeTime(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    if (diff < 0) return "just now"
    val mins = diff / (60 * 1000L)
    if (mins < 1) return "just now"
    if (mins < 60) return "${mins}m ago"
    val hours = mins / 60
    if (hours < 24) return "${hours}h ago"
    val days = hours / 24
    if (days < 7) return "${days}d ago"
    val sdf = SimpleDateFormat("MMM d", Locale.US)
    return sdf.format(Date(timestamp))
}
