package com.example.features.news.model

import androidx.compose.ui.graphics.Color
import com.example.core.model.MarketCategory
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.WarningAmber

enum class NewsSentiment(
    val label: String,
    val displayBadge: String,
    val color: Color
) {
    BULLISH("Bullish", "🟢 BULLISH", BullGreen),
    BEARISH("Bearish", "🔴 BEARISH", BearRed),
    NEUTRAL("Neutral", "🟡 NEUTRAL", WarningAmber),
    UNAVAILABLE("Unavailable", "⚪ UNAVAILABLE", TextDisabled);

    companion object {
        fun fromScore(score: Int?): NewsSentiment {
            if (score == null) return UNAVAILABLE
            return when {
                score >= 60 -> BULLISH
                score <= 40 -> BEARISH
                else -> NEUTRAL
            }
        }
    }
}

enum class NewsImpact(
    val label: String,
    val color: Color
) {
    HIGH("HIGH IMPACT", BearRed),
    MEDIUM("MEDIUM IMPACT", WarningAmber),
    LOW("LOW IMPACT", TextDisabled)
}

data class NewsArticle(
    val id: String,
    val headline: String,
    val source: String,
    val publishedAt: Long,
    val url: String,
    val urlToImage: String? = null,
    val description: String? = null,
    val marketCategory: MarketCategory = MarketCategory.CRYPTO,
    val relevantSymbols: List<String> = emptyList(),
    val sentiment: NewsSentiment = NewsSentiment.NEUTRAL,
    val sentimentScore: Int = 50,
    val sentimentConfidence: Int = 70,
    val impact: NewsImpact = NewsImpact.MEDIUM,
    val isBreaking: Boolean = false,
    val cachedAt: Long = System.currentTimeMillis()
) {
    fun matchesQuery(query: String): Boolean {
        if (query.isBlank()) return true
        val q = query.trim().lowercase()
        return headline.lowercase().contains(q) ||
                (description?.lowercase()?.contains(q) == true) ||
                source.lowercase().contains(q) ||
                marketCategory.name.lowercase().contains(q) ||
                relevantSymbols.any { it.lowercase().contains(q) }
    }
}

data class NewsFilterState(
    val market: MarketCategory? = null,
    val onlySelectedSymbol: Boolean = false,
    val selectedSymbol: String? = null,
    val sentiment: NewsSentiment? = null,
    val impact: NewsImpact? = null,
    val onlyBreaking: Boolean = false,
    val searchQuery: String = ""
)
