package com.example.features.chart

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.chart.ChartExportHelper
import com.example.core.chart.IQTradeChart
import com.example.core.chart.IQTradeChartController
import com.example.core.data.chart.ChartDataState
import com.example.core.model.MarketCategory
import com.example.core.model.Timeframe
import com.example.core.model.chart.ChartConnectionState
import com.example.core.model.chart.ChartDrawing
import com.example.core.model.chart.DrawingType
import com.example.core.model.chart.ExecutedTradeMarker
import com.example.core.model.chart.IndicatorInstance
import com.example.core.model.chart.IndicatorType
import com.example.core.model.chart.OrderType
import com.example.core.model.chart.PriceAlertEvent
import com.example.core.model.chart.SignalMarker
import com.example.core.model.chart.TradeProtectionState
import com.example.core.model.chart.TradeSide
import com.example.features.chart.components.ChartSecondaryToolbar
import com.example.features.chart.components.ChartTopHeader
import com.example.features.chart.components.DrawingToolsPalette
import com.example.features.chart.components.FullScreenChartDialog
import com.example.features.chart.components.IndicatorLibraryDialog
import com.example.features.chart.components.PriceAlertBanner
import com.example.features.chart.components.TimeframePickerSheet
import com.example.features.chart.trading.OrderEntryDialog
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun ProfessionalChartSection(
    chartState: ChartDataState,
    tradingMode: String,
    availableBalance: Double,
    showVolume: Boolean,
    onToggleVolume: (Boolean) -> Unit,
    showIndicators: Boolean,
    onToggleIndicators: (Boolean) -> Unit,
    indicators: List<IndicatorInstance>,
    onAddIndicator: (IndicatorType, Int, String) -> Unit,
    onRemoveIndicator: (String) -> Unit,
    onToggleIndicator: (String, Boolean) -> Unit,
    onUpdateIndicatorPeriod: (String, Int) -> Unit,
    showSignals: Boolean,
    onToggleSignals: (Boolean) -> Unit,
    signalMarkers: List<SignalMarker>,
    executedTrades: List<ExecutedTradeMarker>,
    protectionState: TradeProtectionState?,
    defaultProtection: TradeProtectionState,
    activeDrawingTool: DrawingType,
    onSelectDrawingTool: (DrawingType) -> Unit,
    onClearAllDrawings: () -> Unit,
    drawings: List<ChartDrawing>,
    onDrawingCreated: (ChartDrawing) -> Unit,
    onOpenSymbolPicker: () -> Unit,
    onTimeframeSelected: (Timeframe) -> Unit,
    onExecuteOrder: (side: TradeSide, orderType: OrderType, entryPrice: Double, quantity: Double, protection: TradeProtectionState) -> Unit,
    onFloatClick: () -> Unit,
    onReloadData: () -> Unit,
    modifier: Modifier = Modifier,
    chartHeightDp: Int = 340,
    activePriceAlert: PriceAlertEvent? = null,
    onDismissPriceAlert: () -> Unit = {},
    onPriceAlert: ((PriceAlertEvent) -> Unit)? = null
) {
    var isTimeframeSheetOpen by remember { mutableStateOf(false) }
    var isIndicatorSheetOpen by remember { mutableStateOf(false) }
    var isDrawingPaletteOpen by remember { mutableStateOf(false) }
    var isFullscreenOpen by remember { mutableStateOf(false) }
    var orderEntrySide by remember { mutableStateOf<TradeSide?>(null) }
    var localAlert by remember { mutableStateOf<PriceAlertEvent?>(null) }
    val effectiveAlert = activePriceAlert ?: localAlert

    androidx.compose.runtime.LaunchedEffect(localAlert) {
        if (localAlert != null) {
            kotlinx.coroutines.delay(6000)
            localAlert = null
        }
    }

    val context = LocalContext.current
    val chartController = remember { IQTradeChartController() }
    val onExportAction: () -> Unit = {
        chartController.exportCanvasAsBase64 { base64 ->
            if (base64 != null) {
                ChartExportHelper.shareChart(
                    context = context,
                    base64Str = base64,
                    symbol = chartState.selectedSymbol,
                    timeframe = chartState.selectedTimeframe.label
                )
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceDark)
            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
    ) {
        // Top Header Toolbar with direct BUY and SELL buttons
        ChartTopHeader(
            symbol = chartState.selectedSymbol,
            market = chartState.selectedMarket,
            timeframe = chartState.selectedTimeframe,
            currentPrice = chartState.currentPrice,
            tradingMode = tradingMode,
            isFullscreen = false,
            onOpenSymbolPicker = onOpenSymbolPicker,
            onOpenTimeframePicker = { isTimeframeSheetOpen = true },
            onOpenOrderEntry = { side -> orderEntrySide = side },
            onToggleFullscreen = { isFullscreenOpen = true },
            onFloatClick = onFloatClick,
            onExportClick = onExportAction
        )

        // Secondary Toolbar (Indicators, Volume, Drawings, Signals)
        ChartSecondaryToolbar(
            showVolume = showVolume,
            onToggleVolume = { onToggleVolume(!showVolume) },
            showIndicators = showIndicators,
            activeIndicatorsCount = indicators.count { it.isEnabled },
            onOpenIndicators = { isIndicatorSheetOpen = true },
            activeDrawingTool = activeDrawingTool,
            onOpenDrawingTools = { isDrawingPaletteOpen = true },
            onClearDrawings = onClearAllDrawings,
            drawingsCount = drawings.size,
            showSignals = showSignals,
            onToggleSignals = { onToggleSignals(!showSignals) },
            onExportChart = onExportAction
        )

        // Connection / Data Status Banner if offline, error, stale or reconnecting
        val conn = chartState.connectionState
        if (conn.isError) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BearRed.copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = BearRed, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(conn.label, fontSize = 11.sp, color = BearRed, maxLines = 1)
                }
                IconButton(onClick = onReloadData, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = "Retry", tint = BearRed, modifier = Modifier.size(14.dp))
                }
            }
        } else if (conn is ChartConnectionState.Stale) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(WarningAmber.copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(conn.label, fontSize = 11.sp, color = WarningAmber)
                }
                IconButton(onClick = onReloadData, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = WarningAmber, modifier = Modifier.size(14.dp))
                }
            }
        } else if (conn is ChartConnectionState.Reconnecting || conn is ChartConnectionState.ReconnectingAttempt) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(WarningAmber.copy(alpha = 0.12f))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(color = WarningAmber, strokeWidth = 1.5.dp, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(conn.label, fontSize = 11.sp, color = WarningAmber)
            }
        } else if (conn is ChartConnectionState.Disconnected) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(WarningAmber.copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudOff, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(conn.label, fontSize = 11.sp, color = WarningAmber)
                }
                IconButton(onClick = onReloadData, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = "Connect", tint = WarningAmber, modifier = Modifier.size(14.dp))
                }
            }
        }

        // Real-time Price Alert Banner
        if (effectiveAlert != null) {
            PriceAlertBanner(
                alert = effectiveAlert,
                onDismiss = {
                    localAlert = null
                    onDismissPriceAlert()
                }
            )
        }

        // Lightweight Charts Engine Viewport
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(chartHeightDp.dp)
        ) {
            IQTradeChart(
                symbol = chartState.selectedSymbol,
                timeframe = chartState.selectedTimeframe.label,
                candles = chartState.candles,
                latestCandle = chartState.latestCandle,
                connectionState = chartState.connectionState,
                showVolume = showVolume,
                showIndicators = showIndicators,
                indicators = indicators,
                showSignals = showSignals,
                signalMarkers = signalMarkers,
                executedTrades = executedTrades,
                protectionState = protectionState,
                activeDrawingTool = activeDrawingTool,
                drawings = drawings,
                onDrawingCreated = onDrawingCreated,
                onCrosshairMoved = { _, _, _, _, _ -> },
                onPriceAlert = { event ->
                    localAlert = event
                    onPriceAlert?.invoke(event)
                },
                onReloadData = onReloadData,
                chartController = chartController,
                modifier = Modifier.matchParentSize()
            )
        }
    }

    // Modal: 15 Timeframes Picker
    TimeframePickerSheet(
        isOpen = isTimeframeSheetOpen,
        currentTimeframe = chartState.selectedTimeframe,
        onTimeframeSelected = { tf ->
            onTimeframeSelected(tf)
            isTimeframeSheetOpen = false
        },
        onDismiss = { isTimeframeSheetOpen = false }
    )

    // Modal: Indicator Library & Configuration
    IndicatorLibraryDialog(
        isOpen = isIndicatorSheetOpen,
        activeIndicators = indicators,
        onAddIndicator = { type, period, color ->
            onAddIndicator(type, period, color)
            onToggleIndicators(true)
        },
        onRemoveIndicator = onRemoveIndicator,
        onToggleIndicator = onToggleIndicator,
        onUpdateIndicatorPeriod = onUpdateIndicatorPeriod,
        onDismiss = { isIndicatorSheetOpen = false }
    )

    // Modal: Technical Drawing Tools Palette
    DrawingToolsPalette(
        isOpen = isDrawingPaletteOpen,
        currentTool = activeDrawingTool,
        onSelectTool = onSelectDrawingTool,
        onClearAll = onClearAllDrawings,
        drawingsCount = drawings.size,
        onDismiss = { isDrawingPaletteOpen = false }
    )

    // Modal: Order Entry Popup (BUY / SELL)
    orderEntrySide?.let { side ->
        OrderEntryDialog(
            isOpen = true,
            symbol = chartState.selectedSymbol,
            initialSide = side,
            currentPrice = chartState.currentPrice ?: 0.0,
            availableBalance = availableBalance,
            defaultProtection = defaultProtection,
            onExecuteOrder = { orderSide, orderType, price, qty, protection ->
                onExecuteOrder(orderSide, orderType, price, qty, protection)
                orderEntrySide = null
            },
            onDismiss = { orderEntrySide = null }
        )
    }

    // Modal: Full Screen Chart View
    if (isFullscreenOpen) {
        FullScreenChartDialog(
            isOpen = true,
            symbol = chartState.selectedSymbol,
            market = chartState.selectedMarket,
            timeframe = chartState.selectedTimeframe,
            currentPrice = chartState.currentPrice,
            tradingMode = tradingMode,
            candles = chartState.candles,
            latestCandle = chartState.latestCandle,
            connectionState = chartState.connectionState,
            showVolume = showVolume,
            onToggleVolume = { onToggleVolume(!showVolume) },
            showIndicators = showIndicators,
            indicators = indicators,
            onOpenIndicators = { isIndicatorSheetOpen = true },
            showSignals = showSignals,
            onToggleSignals = { onToggleSignals(!showSignals) },
            signalMarkers = signalMarkers,
            executedTrades = executedTrades,
            protectionState = protectionState,
            activeDrawingTool = activeDrawingTool,
            onOpenDrawingTools = { isDrawingPaletteOpen = true },
            onClearDrawings = onClearAllDrawings,
            drawings = drawings,
            onDrawingCreated = onDrawingCreated,
            onCrosshairMoved = { _, _, _, _, _ -> },
            onOpenSymbolPicker = onOpenSymbolPicker,
            onOpenTimeframePicker = { isTimeframeSheetOpen = true },
            onOpenOrderEntry = { side -> orderEntrySide = side },
            onCloseFullscreen = { isFullscreenOpen = false },
            onReloadData = onReloadData,
            activePriceAlert = effectiveAlert,
            onDismissPriceAlert = {
                localAlert = null
                onDismissPriceAlert()
            },
            onPriceAlert = { event ->
                localAlert = event
                onPriceAlert?.invoke(event)
            }
        )
    }
}
