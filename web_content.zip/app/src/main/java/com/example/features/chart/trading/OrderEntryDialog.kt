package com.example.features.chart.trading

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.chart.OrderType
import com.example.core.model.chart.TradeProtectionState
import com.example.core.model.chart.TradeSide
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.ButtonStyle
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderEntryDialog(
    isOpen: Boolean,
    symbol: String,
    initialSide: TradeSide,
    currentPrice: Double,
    availableBalance: Double,
    defaultProtection: TradeProtectionState,
    onExecuteOrder: (side: TradeSide, orderType: OrderType, entryPrice: Double, quantity: Double, protection: TradeProtectionState) -> Unit,
    onDismiss: () -> Unit,
    isLiveMode: Boolean = false
) {
    if (!isOpen) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    var side by remember { mutableStateOf(initialSide) }
    var orderType by remember { mutableStateOf(OrderType.MARKET) }
    var limitPriceInput by remember { mutableStateOf(if (currentPrice > 0) "%.2f".format(currentPrice) else "") }
    var quantityInput by remember { mutableStateOf("0.01") }
    var showProtectionDialog by remember { mutableStateOf(false) }

    // Active trade protection configured specifically for this order
    var protectionState by remember {
        mutableStateOf(
            defaultProtection.copy(
                entryPrice = currentPrice,
                currentPrice = currentPrice,
                side = side,
                quantity = 0.01
            )
        )
    }

    val parsedPrice = if (orderType == OrderType.MARKET) currentPrice else limitPriceInput.toDoubleOrNull() ?: currentPrice
    val parsedQty = quantityInput.toDoubleOrNull() ?: 0.0
    val totalCost = parsedPrice * parsedQty
    val hasSufficientBalance = totalCost <= availableBalance

    // Keep protection entry price in sync with current pricing
    val liveProtection = protectionState.copy(
        entryPrice = parsedPrice,
        currentPrice = currentPrice,
        side = side,
        quantity = parsedQty
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(scrollState)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ORDER ENTRY",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = if (isLiveMode) "$symbol • Live Market Order" else "$symbol • Paper Simulated Order",
                        fontSize = 11.sp,
                        color = if (isLiveMode) WarningAmber else CyanAccent
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // BUY / SELL Side Switcher Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (side == TradeSide.BUY) BullGreen else SurfaceElevated)
                        .clickable { side = TradeSide.BUY }
                        .padding(vertical = 10.dp)
                        .testTag("tab_order_side_buy"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "BUY / LONG",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (side == TradeSide.BUY) Color.Black else TextSecondary
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (side == TradeSide.SELL) BearRed else SurfaceElevated)
                        .clickable { side = TradeSide.SELL }
                        .padding(vertical = 10.dp)
                        .testTag("tab_order_side_sell"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "SELL / SHORT",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (side == TradeSide.SELL) Color.White else TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Order Type Selector (Market, Limit, Stop/Trigger)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(OrderType.MARKET, OrderType.LIMIT, OrderType.STOP_TRIGGER).forEach { type ->
                    val isSelected = orderType == type
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) CyanAccent.copy(alpha = 0.2f) else SurfaceElevated)
                            .border(
                                1.dp,
                                if (isSelected) CyanAccent else BorderSubtle,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { orderType = type }
                            .padding(vertical = 7.dp)
                            .testTag("order_type_${type.name}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = type.label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) CyanAccent else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Limit / Trigger Price Input if not Market order
            if (orderType != OrderType.MARKET) {
                OutlinedTextField(
                    value = limitPriceInput,
                    onValueChange = { limitPriceInput = it },
                    label = { Text("${orderType.label} Price") },
                    modifier = Modifier.fillMaxWidth().testTag("input_order_limit_price"),
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SurfaceElevated,
                        unfocusedContainerColor = SurfaceElevated,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Quantity / Position Size Input
            OutlinedTextField(
                value = quantityInput,
                onValueChange = { quantityInput = it },
                label = { Text("Quantity ($symbol)") },
                modifier = Modifier.fillMaxWidth().testTag("input_order_quantity"),
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = SurfaceElevated,
                    unfocusedContainerColor = SurfaceElevated,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Quick Percentage Chips (25%, 50%, 75%, 100%)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(0.25 to "25%", 0.50 to "50%", 0.75 to "75%", 1.0 to "100%").forEach { (ratio, label) ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceElevated)
                            .border(1.dp, BorderSubtle, RoundedCornerShape(6.dp))
                            .clickable {
                                if (parsedPrice > 0) {
                                    val calculated = (availableBalance * ratio) / parsedPrice
                                    quantityInput = "%.4f".format(calculated)
                                }
                            }
                            .padding(vertical = 5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = label, fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Account Balance & Order Value Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Available Balance:", fontSize = 11.sp, color = TextSecondary)
                    Text(
                        text = "$%.2f USDT".format(availableBalance),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Total Order Cost:", fontSize = 11.sp, color = TextSecondary)
                    Text(
                        text = "$%.2f USDT".format(totalCost),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (hasSufficientBalance) CyanAccent else BearRed,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Trade Protection Configurator Banner (SL / TP)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .clickable { showProtectionDialog = true }
                    .padding(12.dp)
                    .testTag("btn_open_protection_popup"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Trade Protection (SL / TP)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        val slLabel = liveProtection.effectiveStopLossPrice?.let { "SL: %.2f".format(it) } ?: "No SL"
                        val tpLabel = liveProtection.effectiveTakeProfitPrice?.let { "TP: %.2f".format(it) } ?: "No TP"
                        Text(
                            text = "$slLabel • $tpLabel • Risk: $%.2f".format(liveProtection.estimatedRiskUsdt),
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }

                Text(
                    text = "EDIT >",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Execute Button
            val buttonText = if (isLiveMode) {
                if (side == TradeSide.BUY) "EXECUTE LIVE BUY" else "EXECUTE LIVE SELL"
            } else {
                if (side == TradeSide.BUY) "EXECUTE PAPER BUY" else "EXECUTE PAPER SELL"
            }
            AppButton(
                text = buttonText,
                onClick = {
                    onExecuteOrder(side, orderType, parsedPrice, parsedQty, liveProtection)
                    onDismiss()
                },
                style = if (side == TradeSide.BUY) ButtonStyle.PRIMARY else ButtonStyle.DANGER,
                modifier = Modifier.fillMaxWidth(),
                enabled = hasSufficientBalance && parsedQty > 0,
                testTag = "btn_execute_order"
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Trade Protection Sub-Dialog
    if (showProtectionDialog) {
        TradeProtectionDialog(
            isOpen = true,
            initialState = liveProtection,
            onSaveProtection = { newProtection ->
                protectionState = newProtection
                showProtectionDialog = false
            },
            onDismiss = { showProtectionDialog = false }
        )
    }
}
