package com.example.features.analysis

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingFlat
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.analysis.MarketStructureResult
import com.example.core.model.analysis.MarketTrendType
import com.example.core.model.analysis.SupportResistanceLevel
import com.example.core.model.analysis.SupportResistanceResult
import com.example.core.model.indicator.IndicatorDirection
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.CardVariant
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber

/**
 * Visual presentation of Module #6 Market Structure & S/R engine.
 * Displays Trend, Structure State, Swing counts (HH, HL, LH, LL),
 * and calculated Resistance and Support levels with distance metrics.
 */
@Composable
fun AnalysisStructureCard(
    structure: MarketStructureResult,
    sr: SupportResistanceResult,
    currentPrice: Double,
    modifier: Modifier = Modifier
) {
    val trendColor = when (structure.structuralBias) {
        IndicatorDirection.BULLISH -> BullGreen
        IndicatorDirection.BEARISH -> BearRed
        IndicatorDirection.NEUTRAL -> WarningAmber
    }

    val trendIcon = when (structure.trend) {
        MarketTrendType.UPTREND -> Icons.Default.TrendingUp
        MarketTrendType.DOWNTREND -> Icons.Default.TrendingDown
        MarketTrendType.RANGE_SIDEWAYS -> Icons.Default.TrendingFlat
    }

    AppCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("analysis_structure_card"),
        variant = CardVariant.DEFAULT
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AccountTree,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MARKET STRUCTURE & S/R",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(trendColor.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = trendIcon,
                        contentDescription = null,
                        tint = trendColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = structure.trend.label.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = trendColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Structural State Highlight
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceDark)
                .padding(10.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "STATE: ${structure.state.label}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent
                    )
                    Text(
                        text = structure.structuralBias.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = trendColor
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = structure.supportingInformation,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    lineHeight = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Swing Points Matrix (HH, HL, LH, LL)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SwingCounterBox(code = "HH", label = "Higher Highs", count = structure.higherHighsCount, color = BullGreen, modifier = Modifier.weight(1f))
            SwingCounterBox(code = "HL", label = "Higher Lows", count = structure.higherLowsCount, color = BullGreen, modifier = Modifier.weight(1f))
            SwingCounterBox(code = "LH", label = "Lower Highs", count = structure.lowerHighsCount, color = BearRed, modifier = Modifier.weight(1f))
            SwingCounterBox(code = "LL", label = "Lower Lows", count = structure.lowerLowsCount, color = BearRed, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Key Swings: High & Low
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Key Swing High: " + if (structure.keySwingHigh > 0) "$%.2f".format(structure.keySwingHigh) else "--",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = BearRed
            )
            Text(
                text = "Key Swing Low: " + if (structure.keySwingLow > 0) "$%.2f".format(structure.keySwingLow) else "--",
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = BullGreen
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Support & Resistance Levels Sub-Section
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Layers,
                contentDescription = null,
                tint = CyanAccent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "CALCULATED SUPPORT & RESISTANCE LEVELS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Resistance Levels (Descending order above current price)
        if (sr.resistanceLevels.isNotEmpty()) {
            Text(
                text = "RESISTANCE LEVELS (CEILING):",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = BearRed,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                sr.resistanceLevels.forEachIndexed { idx, level ->
                    LevelRow(
                        prefix = "R${idx + 1}",
                        level = level,
                        color = BearRed
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Current Price Marker
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(SurfaceElevated)
                .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "● CURRENT PRICE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
                Text(
                    text = "$%.2f".format(currentPrice),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Support Levels (Descending order below current price)
        if (sr.supportLevels.isNotEmpty()) {
            Text(
                text = "SUPPORT LEVELS (FLOOR):",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = BullGreen,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                sr.supportLevels.forEachIndexed { idx, level ->
                    LevelRow(
                        prefix = "S${idx + 1}",
                        level = level,
                        color = BullGreen
                    )
                }
            }
        }
    }
}

@Composable
private fun SwingCounterBox(
    code: String,
    label: String,
    count: Int,
    color: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(SurfaceDark)
            .padding(vertical = 6.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = code,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = "$count",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }
}

@Composable
private fun LevelRow(
    prefix: String,
    level: SupportResistanceLevel,
    color: androidx.compose.ui.graphics.Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(SurfaceDark)
            .padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = prefix,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "$%.2f".format(level.price),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "(${level.strength}, ${level.touches} touches)",
                fontSize = 9.sp,
                color = TextTertiary
            )
        }

        val sign = if (level.isSupport) "-" else "+"
        val pctStr = String.format(java.util.Locale.US, "%.2f", level.distancePct)
        val absStr = String.format(java.util.Locale.US, "$%.2f", level.distanceAbsolute)
        Text(
            text = "$sign$pctStr% ($absStr)",
            fontSize = 9.sp,
            fontWeight = FontWeight.Medium,
            color = color
        )
    }
}
