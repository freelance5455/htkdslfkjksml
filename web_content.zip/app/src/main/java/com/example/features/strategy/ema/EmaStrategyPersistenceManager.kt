package com.example.features.strategy.ema

import android.content.Context
import android.content.SharedPreferences
import com.example.core.model.Timeframe

/**
 * Isolated persistence manager for EMA 9/21 Strategy preferences.
 * Persists user configuration across app restarts without affecting other application settings.
 */
class EmaStrategyPersistenceManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val PREFS_NAME = "iqtrade_ema_strategy_prefs"
        private const val KEY_FAST_EMA = "key_ema_fast_period"
        private const val KEY_SLOW_EMA = "key_ema_slow_period"
        private const val KEY_ADX_PERIOD = "key_ema_adx_period"
        private const val KEY_ADX_THRESHOLD = "key_ema_adx_threshold"
        private const val KEY_TIMEFRAME = "key_ema_timeframe"

        const val DEFAULT_FAST_EMA = 9
        const val DEFAULT_SLOW_EMA = 21
        const val DEFAULT_ADX_PERIOD = 14
        const val DEFAULT_ADX_THRESHOLD = 20.0
        const val DEFAULT_TIMEFRAME = "15m"
    }

    fun getFastEma(): Int = prefs.getInt(KEY_FAST_EMA, DEFAULT_FAST_EMA)

    fun saveFastEma(period: Int) {
        prefs.edit().putInt(KEY_FAST_EMA, period.coerceIn(2, 100)).apply()
    }

    fun getSlowEma(): Int = prefs.getInt(KEY_SLOW_EMA, DEFAULT_SLOW_EMA)

    fun saveSlowEma(period: Int) {
        prefs.edit().putInt(KEY_SLOW_EMA, period.coerceIn(5, 200)).apply()
    }

    fun getAdxPeriod(): Int = prefs.getInt(KEY_ADX_PERIOD, DEFAULT_ADX_PERIOD)

    fun saveAdxPeriod(period: Int) {
        prefs.edit().putInt(KEY_ADX_PERIOD, period.coerceIn(5, 50)).apply()
    }

    fun getAdxThreshold(): Double = prefs.getFloat(KEY_ADX_THRESHOLD, DEFAULT_ADX_THRESHOLD.toFloat()).toDouble()

    fun saveAdxThreshold(threshold: Double) {
        prefs.edit().putFloat(KEY_ADX_THRESHOLD, threshold.toFloat().coerceIn(10f, 50f)).apply()
    }

    fun getTimeframe(): Timeframe {
        val label = prefs.getString(KEY_TIMEFRAME, DEFAULT_TIMEFRAME) ?: DEFAULT_TIMEFRAME
        return Timeframe.fromLabel(label)
    }

    fun saveTimeframe(timeframe: Timeframe) {
        prefs.edit().putString(KEY_TIMEFRAME, timeframe.label).apply()
    }

    fun loadConfig(): EmaStrategyConfig {
        return EmaStrategyConfig(
            fastEmaPeriod = getFastEma(),
            slowEmaPeriod = getSlowEma(),
            adxPeriod = getAdxPeriod(),
            adxThreshold = getAdxThreshold(),
            timeframe = getTimeframe()
        )
    }

    fun saveConfig(config: EmaStrategyConfig) {
        prefs.edit()
            .putInt(KEY_FAST_EMA, config.fastEmaPeriod)
            .putInt(KEY_SLOW_EMA, config.slowEmaPeriod)
            .putInt(KEY_ADX_PERIOD, config.adxPeriod)
            .putFloat(KEY_ADX_THRESHOLD, config.adxThreshold.toFloat())
            .putString(KEY_TIMEFRAME, config.timeframe.label)
            .apply()
    }
}
