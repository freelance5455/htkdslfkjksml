package com.example.features.more

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.floating.OverlayPermissionHelper
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.AppConfirmationDialog
import com.example.core.ui.components.ButtonStyle
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.PageContainer
import com.example.core.ui.components.SectionHeader
import com.example.core.ui.components.StatusIndicator
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MainUiState
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.testTag
import com.example.features.strategy.ema.EmaStrategyScreen

@Composable
fun MoreScreen(
    state: MainUiState,
    onResetPaperAccount: () -> Unit,
    onNavigateToAnalysis: () -> Unit = {},
    onOpenNewsFeed: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var showResetDialog by remember { mutableStateOf(false) }
    var showFloatingArchitectureDialog by remember { mutableStateOf(false) }
    var showEmaStrategyScreen by rememberSaveable { mutableStateOf(false) }

    if (showEmaStrategyScreen) {
        EmaStrategyScreen(
            state = state,
            onBack = { showEmaStrategyScreen = false },
            modifier = modifier
        )
        return
    }

    val hasOverlayPermission = remember(context) {
        OverlayPermissionHelper.hasOverlayPermission(context)
    }

    if (showResetDialog) {
        AppConfirmationDialog(
            title = "Reset Persistent Storage?",
            message = "This will reset all user preferences and restore paper account balance to $10,000.00.",
            confirmText = "Confirm Reset",
            isDestructive = true,
            onConfirm = { onResetPaperAccount() },
            onDismiss = { showResetDialog = false }
        )
    }

    if (showFloatingArchitectureDialog) {
        AppConfirmationDialog(
            title = "Floating System Architecture",
            message = "Module #12 will provide a floating mini-terminal overlay window using Android SYSTEM_ALERT_WINDOW and a Foreground Service with sticky notification. The permissions and service contracts are already registered in the Android manifest.",
            confirmText = "Understood",
            cancelText = "Close",
            isDestructive = false,
            onConfirm = {},
            onDismiss = { showFloatingArchitectureDialog = false }
        )
    }

    PageContainer(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionHeader(
                title = "Application Settings & More",
                subtitle = "System permissions, storage architecture & APK build info"
            )

            // EMA 9/21 Strategy Card (More -> EMA 9/21 Strategy)
            AppCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("more_item_ema_strategy"),
                variant = CardVariant.DEFAULT,
                onClick = { showEmaStrategyScreen = true }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "EMA 9/21 STRATEGY",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Trend Crossover • ADX Primary Filter",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Open Strategy",
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Monitors completed-candle EMA 9 & 21 crossovers with primary ADX trend momentum filtering and multi-layer confirmations.",
                    fontSize = 11.sp,
                    color = TextTertiary,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                AppButton(
                    text = "Open EMA 9/21 Strategy",
                    onClick = { showEmaStrategyScreen = true },
                    style = ButtonStyle.PRIMARY,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_open_ema_strategy"
                )
            }

            // Market News & Intelligence Card (More -> News Feed)
            AppCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("more_item_news_feed"),
                variant = CardVariant.DEFAULT,
                onClick = onOpenNewsFeed
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Newspaper,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "MARKET NEWS & INTELLIGENCE",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = if (state.isNewsCache) "Cached Data Available • Disconnected" else if (state.newsApiConnectionState.isConnected) "Live Stream Active • Sentiment Online" else "Financial Wire & Macro Feed",
                                fontSize = 11.sp,
                                color = if (state.newsApiConnectionState.isConnected) BullGreen else TextSecondary
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Open News",
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Streams real-time financial headlines, macroeconomic developments, and automated bullish/bearish sentiment scoring for Crypto, Forex, and Gold markets.",
                    fontSize = 11.sp,
                    color = TextTertiary,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                AppButton(
                    text = "Open Live News Feed",
                    onClick = onOpenNewsFeed,
                    style = ButtonStyle.PRIMARY,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_more_open_news_feed"
                )
            }

            // Future Floating System Card (More -> Floating)
            AppCard(
                modifier = Modifier.fillMaxWidth(),
                variant = CardVariant.DEFAULT
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PictureInPicture,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "FLOATING WINDOW SYSTEM",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    StatusIndicator(
                        label = if (hasOverlayPermission) "OVERLAY ALLOWED" else "PERMISSION PENDING",
                        dotColor = if (hasOverlayPermission) BullGreen else WarningAmber
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Prepared for Module #12 (Floating System). Allows price ticker and quick-order windows to float over other Android applications.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 17.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppButton(
                        text = if (hasOverlayPermission) "Overlay Ready" else "Request Permission",
                        onClick = {
                            val intent = OverlayPermissionHelper.createRequestOverlayPermissionIntent(context)
                            if (intent != null) {
                                try {
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    showFloatingArchitectureDialog = true
                                }
                            } else {
                                showFloatingArchitectureDialog = true
                            }
                        },
                        style = if (hasOverlayPermission) ButtonStyle.OUTLINE else ButtonStyle.PRIMARY,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_floating_permission"
                    )

                    AppButton(
                        text = "View Specs",
                        onClick = { showFloatingArchitectureDialog = true },
                        style = ButtonStyle.OUTLINE,
                        modifier = Modifier.weight(1f),
                        testTag = "btn_floating_specs"
                    )
                }
            }

            // Android-First Architecture Checklist
            AppCard(
                modifier = Modifier.fillMaxWidth(),
                variant = CardVariant.DEFAULT
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ANDROID ARCHITECTURE FOUNDATION",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val features = listOf(
                    Pair("Room Local Database", "Survives app restarts & phone reboot"),
                    Pair("Secure Keystore Storage", "Zero plaintext secret key leakage"),
                    Pair("Network Connectivity Monitor", "Reactive connection state callbacks"),
                    Pair("Lifecycle Manager", "Foreground / background state coordination"),
                    Pair("System Overlay Manifest", "SYSTEM_ALERT_WINDOW & FOREGROUND_SERVICE"),
                    Pair("Clean Modular Architecture", "100% Android Native Kotlin & Compose")
                )

                features.forEach { (name, note) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = BullGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Text(text = note, fontSize = 10.sp, color = TextSecondary)
                        }
                    }
                }
            }

            // Storage Operations Card
            AppCard(
                modifier = Modifier.fillMaxWidth(),
                variant = CardVariant.DEFAULT
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Storage,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DATA PERSISTENCE & STORAGE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Room SQLite Database: 'iqtrade_pro.db'\nPaper Account Balance: $${String.format("%,.2f", state.paperBalance)} USDT\nStored Trade Records: ${state.trades.size}",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                AppButton(
                    text = "Reset Paper Account Data",
                    onClick = { showResetDialog = true },
                    style = ButtonStyle.DANGER,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_reset_storage"
                )
            }

            // Application Identity & Build Info
            AppCard(
                modifier = Modifier.fillMaxWidth(),
                variant = CardVariant.DEFAULT
            ) {
                Text(
                    text = "APPLICATION IDENTITY",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "App Name: IQTrade Pro\nPackage: com.aistudio.iqtradepro.mbvqtr\nTarget Platform: Android 14+ / compileSdk 36\nBuild Type: Debug & Release APK Ready\nModule Status: Module #1 — Core Structure Verified",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
