package com.example.features.chart.trading

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.chart.StopLossMode
import com.example.core.model.chart.TradeProtectionState
import com.example.core.model.chart.TradeSide
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.ButtonStyle
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TradeProtectionDialog(
    isOpen: Boolean,
    initialState: TradeProtectionState,
    onSaveProtection: (TradeProtectionState) -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    var stopLossMode by remember { mutableStateOf(initialState.stopLossMode) }
    var fixedPercentage by remember { mutableStateOf(initialState.stopLossPercentage.toString()) }
    var trailingDistance by remember { mutableStateOf(initialState.trailingDistancePct.toString()) }
    var balanceRiskPct by remember { mutableStateOf(initialState.maxRiskAccountPercentage.toString()) }
    var strictRiskRewardEnabled by remember { mutableStateOf(initialState.strictRiskRewardEnabled) }
    var targetRrRatio by remember { mutableStateOf(initialState.targetRiskRewardRatio.toString()) }
    var manualSlPrice by remember {
        mutableStateOf(
            initialState.stopLossPrice?.toString() ?: if (initialState.entryPrice > 0) {
                if (initialState.side == TradeSide.BUY) "%.2f".format(initialState.entryPrice * 0.985)
                else "%.2f".format(initialState.entryPrice * 1.015)
            } else ""
        )
    }

    var isTakeProfitEnabled by remember { mutableStateOf(initialState.isTakeProfitEnabled) }
    var tpPercentage by remember { mutableStateOf(initialState.takeProfitPercentage.toString()) }
    var manualTpPrice by remember {
        mutableStateOf(
            initialState.takeProfitPrice?.toString() ?: if (initialState.entryPrice > 0) {
                if (initialState.side == TradeSide.BUY) "%.2f".format(initialState.entryPrice * 1.03)
                else "%.2f".format(initialState.entryPrice * 0.97)
            } else ""
        )
    }

    // Dynamic Live Preview State
    val parsedFixedPct = fixedPercentage.toDoubleOrNull() ?: initialState.stopLossPercentage
    val parsedTrailingDist = trailingDistance.toDoubleOrNull() ?: initialState.trailingDistancePct
    val parsedBalanceRiskPct = balanceRiskPct.toDoubleOrNull() ?: initialState.maxRiskAccountPercentage
    val parsedTargetRr = targetRrRatio.toDoubleOrNull() ?: initialState.targetRiskRewardRatio
    val parsedManualSl = manualSlPrice.toDoubleOrNull()
    val parsedTpPct = tpPercentage.toDoubleOrNull() ?: initialState.takeProfitPercentage
    val parsedManualTp = manualTpPrice.toDoubleOrNull()

    val currentPreview = initialState.copy(
        stopLossMode = stopLossMode,
        stopLossPercentage = parsedFixedPct,
        trailingDistancePct = parsedTrailingDist,
        maxRiskAccountPercentage = parsedBalanceRiskPct,
        strictRiskRewardEnabled = strictRiskRewardEnabled,
        targetRiskRewardRatio = parsedTargetRr,
        stopLossPrice = if (stopLossMode == StopLossMode.MANUAL) parsedManualSl else null,
        isTakeProfitEnabled = isTakeProfitEnabled,
        takeProfitPercentage = parsedTpPct,
        takeProfitPrice = if (parsedManualTp != null && parsedManualTp > 0) parsedManualTp else null
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(scrollState)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TRADE PROTECTION (SL / TP)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Trade Summary Context Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "ENTRY PRICE", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = "%.2f".format(initialState.entryPrice),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column {
                    Text(text = "QUANTITY", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = "%.4f".format(initialState.quantity),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "RISK / REWARD", fontSize = 10.sp, color = TextSecondary)
                    Text(
                        text = "1 : %.2f".format(currentPreview.riskRewardRatio),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (currentPreview.riskRewardRatio >= 1.5) BullGreen else WarningAmber,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // STOP LOSS SECTION
            Text(
                text = "STOP LOSS CONFIGURATION",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = BearRed,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Stop Loss Modes Segmented Selector (Scrollable or 2-row flow)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        StopLossMode.FIXED to "Fixed Stop",
                        StopLossMode.TRAILING to "Trailing Stop",
                        StopLossMode.MANUAL to "Manual Stop"
                    ).forEach { (mode, label) ->
                        val isSelected = stopLossMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) BearRed.copy(alpha = 0.25f) else SurfaceElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) BearRed else BorderSubtle,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { stopLossMode = mode }
                                .padding(vertical = 8.dp)
                                .testTag("sl_mode_${mode.name}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) BearRed else TextSecondary
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        StopLossMode.AUTO to "Auto Stop (Swing)",
                        StopLossMode.BALANCE_RISK to "Balance / Risk Stop"
                    ).forEach { (mode, label) ->
                        val isSelected = stopLossMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) BearRed.copy(alpha = 0.25f) else SurfaceElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) BearRed else BorderSubtle,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { stopLossMode = mode }
                                .padding(vertical = 8.dp)
                                .testTag("sl_mode_${mode.name}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) BearRed else TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Stop Loss Mode Parameter Inputs
            when (stopLossMode) {
                StopLossMode.FIXED -> {
                    OutlinedTextField(
                        value = fixedPercentage,
                        onValueChange = { fixedPercentage = it },
                        label = { Text("Fixed Stop Distance (%)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_sl_fixed_pct"),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = SurfaceElevated,
                            unfocusedContainerColor = SurfaceElevated,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
                StopLossMode.TRAILING -> {
                    OutlinedTextField(
                        value = trailingDistance,
                        onValueChange = { trailingDistance = it },
                        label = { Text("Trailing Distance (%)") },
                        modifier = Modifier.fillMaxWidth().testTag("input_sl_trailing_dist"),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = SurfaceElevated,
                            unfocusedContainerColor = SurfaceElevated,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Text(
                        text = "Dynamic stop that trails highest market price by ${trailingDistance}%.",
                        fontSize = 10.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
                StopLossMode.MANUAL -> {
                    OutlinedTextField(
                        value = manualSlPrice,
                        onValueChange = { manualSlPrice = it },
                        label = { Text("Exact Stop Loss Price") },
                        modifier = Modifier.fillMaxWidth().testTag("input_sl_manual_price"),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = SurfaceElevated,
                            unfocusedContainerColor = SurfaceElevated,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }
                StopLossMode.AUTO -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceElevated, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "Auto Algorithmic Stop (Swing Support/Resistance)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Dynamically places stop loss at calculated local swing high/low with a 1.2% volatility buffer to protect capital while preventing stop hunts.",
                            fontSize = 10.sp,
                            color = TextSecondary,
                            lineHeight = 14.sp
                        )
                    }
                }
                StopLossMode.BALANCE_RISK -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceElevated, RoundedCornerShape(8.dp))
                            .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "Balance / Risk Based Automatic Stop",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WarningAmber
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = balanceRiskPct,
                            onValueChange = { balanceRiskPct = it },
                            label = { Text("Max Risk of Account Balance (%)") },
                            modifier = Modifier.fillMaxWidth().testTag("input_sl_balance_risk_pct"),
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = SurfaceDark,
                                unfocusedContainerColor = SurfaceDark,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        val allowedDollar = initialState.accountBalance * (parsedBalanceRiskPct / 100.0)
                        Text(
                            text = "Account: $%.2f | Max Allowed Loss: $%.2f USDT".format(initialState.accountBalance, allowedDollar),
                            fontSize = 10.sp,
                            color = BullGreen
                        )
                    }
                }
                StopLossMode.NONE -> Unit
            }

            // Effective SL & Risk readout
            val effSl = currentPreview.effectiveStopLossPrice
            if (effSl != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Effective SL Price: %.2f".format(effSl),
                        fontSize = 11.sp,
                        color = BearRed,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Est. Risk: $%.2f USDT".format(currentPreview.estimatedRiskUsdt),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = BearRed,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // TAKE PROFIT SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TAKE PROFIT CONFIGURATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = BullGreen,
                    letterSpacing = 0.5.sp
                )

                Switch(
                    checked = isTakeProfitEnabled,
                    onCheckedChange = { isTakeProfitEnabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = BullGreen
                    ),
                    modifier = Modifier.testTag("switch_tp_enabled")
                )
            }

            if (isTakeProfitEnabled) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = tpPercentage,
                        onValueChange = { tpPercentage = it },
                        label = { Text("Target (%)") },
                        modifier = Modifier.weight(1f).testTag("input_tp_pct"),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = SurfaceElevated,
                            unfocusedContainerColor = SurfaceElevated,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = manualTpPrice,
                        onValueChange = { manualTpPrice = it },
                        label = { Text("TP Target Price") },
                        modifier = Modifier.weight(1.2f).testTag("input_tp_price"),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = SurfaceElevated,
                            unfocusedContainerColor = SurfaceElevated,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                }

                val effTp = currentPreview.effectiveTakeProfitPrice
                if (effTp != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Effective TP Price: %.2f".format(effTp),
                            fontSize = 11.sp,
                            color = BullGreen,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Est. Reward: $%.2f USDT".format(currentPreview.estimatedRewardUsdt),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BullGreen,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // STRICT RISK / REWARD PROTECTION SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "STRICT RISK / REWARD PROTECTION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Enforces minimum Reward:Risk ratio (e.g. 1:2.0). Auto-adjusts TP to meet target.",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }

                Switch(
                    checked = strictRiskRewardEnabled,
                    onCheckedChange = { strictRiskRewardEnabled = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = CyanAccent
                    ),
                    modifier = Modifier.testTag("switch_strict_rr")
                )
            }

            if (strictRiskRewardEnabled) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("1.5" to "1 : 1.5", "2.0" to "1 : 2.0", "3.0" to "1 : 3.0", "4.0" to "1 : 4.0").forEach { (valStr, label) ->
                        val isSelected = targetRrRatio == valStr
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) CyanAccent.copy(alpha = 0.25f) else SurfaceElevated)
                                .border(
                                    1.dp,
                                    if (isSelected) CyanAccent else BorderSubtle,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { targetRrRatio = valStr }
                                .padding(vertical = 6.dp)
                                .testTag("rr_ratio_$valStr"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) CyanAccent else TextSecondary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Save / Apply Button
            AppButton(
                text = "APPLY TRADE PROTECTION",
                onClick = {
                    onSaveProtection(currentPreview)
                    onDismiss()
                },
                style = ButtonStyle.PRIMARY,
                modifier = Modifier.fillMaxWidth(),
                testTag = "btn_apply_trade_protection"
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
