package com.example.features.analysis

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.analysis.RiskRewardResult
import com.example.core.model.analysis.VolatilityAnalysisResult
import com.example.core.model.analysis.VolatilityEnvironment
import com.example.core.model.indicator.IndicatorDirection
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.CardVariant
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber

/**
 * Visual presentation of Module #6 Volatility & Risk/Reward engine.
 * Displays ATR, Volatility Environment, Stop Loss, Take Profit, and Risk-to-Reward ratio.
 */
@Composable
fun AnalysisRiskRewardCard(
    volatility: VolatilityAnalysisResult,
    riskReward: RiskRewardResult,
    modifier: Modifier = Modifier
) {
    val volColor = when (volatility.environment) {
        VolatilityEnvironment.LOW -> CyanAccent
        VolatilityEnvironment.NORMAL -> BullGreen
        VolatilityEnvironment.HIGH -> WarningAmber
        VolatilityEnvironment.EXTREME -> BearRed
    }

    AppCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("analysis_risk_reward_card"),
        variant = CardVariant.DEFAULT
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Balance,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "VOLATILITY & RISK / REWARD",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(volColor.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = volatility.environment.name,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = volColor
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Volatility Environment Detail
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceDark)
                .padding(10.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = volatility.environment.label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = volColor
                    )
                    val atrPrice = String.format(java.util.Locale.US, "$%.2f", volatility.atrValue)
                    val atrPct = String.format(java.util.Locale.US, "%.2f", volatility.atrPercentOfPrice)
                    Text(
                        text = "ATR: $atrPrice ($atrPct%)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = volatility.contextDescription,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    lineHeight = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Risk / Reward Ratio Section
        if (riskReward.isValid) {
            val setupColor = when (riskReward.setupBias) {
                IndicatorDirection.BULLISH -> BullGreen
                IndicatorDirection.BEARISH -> BearRed
                IndicatorDirection.NEUTRAL -> WarningAmber
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(setupColor.copy(alpha = 0.12f))
                    .border(1.dp, setupColor.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${riskReward.setupBias.name} SETUP RATIO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = setupColor
                        )
                        Text(
                            text = riskReward.ratioText,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = setupColor
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("RECOMMENDED ENTRY", fontSize = 9.sp, color = TextTertiary, fontWeight = FontWeight.Bold)
                            Text("$%.2f".format(riskReward.entryPrice), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val slPrice = String.format(java.util.Locale.US, "$%.2f", riskReward.stopLossPrice)
                            val riskPct = String.format(java.util.Locale.US, "%.2f", riskReward.riskPercent)
                            Text("STOP LOSS (RISK)", fontSize = 9.sp, color = BearRed, fontWeight = FontWeight.Bold)
                            Text("$slPrice (-$riskPct%)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BearRed)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            val tpPrice = String.format(java.util.Locale.US, "$%.2f", riskReward.takeProfitPrice)
                            val rewardPct = String.format(java.util.Locale.US, "%.2f", riskReward.rewardPercent)
                            Text("TAKE PROFIT (REWARD)", fontSize = 9.sp, color = BullGreen, fontWeight = FontWeight.Bold)
                            Text("$tpPrice (+$rewardPct%)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BullGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = riskReward.message,
                        fontSize = 10.sp,
                        color = TextSecondary,
                        lineHeight = 14.sp
                    )
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "RISK / REWARD RATIO: ${riskReward.ratioText}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WarningAmber
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = riskReward.message,
                        fontSize = 10.sp,
                        color = TextSecondary,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}
