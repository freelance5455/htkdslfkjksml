package com.example.features.analysis

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.analysis.pipeline.CompleteAnalysisPipeline
import com.example.core.model.analysis.CompleteAnalysisResult
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.PageContainer
import com.example.core.ui.components.SectionHeader
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MainUiState

private enum class AnalysisTab(val title: String) {
    ALL("Overview"),
    CORE_MTF("Core & MTF"),
    PATTERNS("Candlestick"),
    STRUCTURE("Structure & S/R"),
    FIBONACCI("Fibonacci"),
    RISK_REWARD("Risk / Reward")
}

/**
 * Module #6 — Dedicated Complete Analysis Engine Screen.
 *
 * Direct home for:
 * - Overall authorative analysis signals (BUY / SELL / WAIT) and Confidence %
 * - 8 Core Technical Indicators (80% confirmation rule)
 * - 10 Multi-Timeframe Analysis Matrix (5M to 1D)
 * - 17 Candlestick Pattern Recognition Engine
 * - Market Trend & Dynamic Structure (HH, HL, LH, LL, Breakout)
 * - Calculated Support & Resistance Levels
 * - Fibonacci Retracement Zones (Golden Pocket)
 * - Volatility & Risk/Reward Architecture
 * - News & Sentiment Score
 */
@Composable
fun AnalysisScreen(
    state: MainUiState,
    onRefreshAnalysis: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    var selectedTab by remember { mutableStateOf(AnalysisTab.ALL) }

    // Resolve authoritative CompleteAnalysisResult or calculate on-demand
    val analysisResult: CompleteAnalysisResult = state.completeAnalysisResult
        ?: remember(state.selectedSymbol, state.chartDataState.candles) {
            CompleteAnalysisPipeline.executeAnalysis(
                symbol = state.selectedSymbol,
                market = state.selectedMarket.displayName,
                candles = state.chartDataState.candles,
                isNewsConnected = state.hasSavedNewsApiKey,
                activeTimeframe = state.selectedTimeframe
            )
        }

    PageContainer(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .testTag("analysis_screen_scroll"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SectionHeader(
                    title = "Complete Analysis Engine",
                    subtitle = "Comprehensive multi-factor technical analysis & live signals"
                )
            }

            // Top Hero Card: Overall Signal, Confidence %, Key Metrics & Contribution Breakdown
            item {
                AnalysisHeroCard(
                    result = analysisResult,
                    isRefreshing = state.isAnalysisRefreshing,
                    onRefresh = onRefreshAnalysis
                )
            }

            // Section Filter Tabs
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AnalysisTab.values().forEach { tab ->
                        val isSelected = selectedTab == tab
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) CyanAccent else SurfaceElevated)
                                .clickable { selectedTab = tab }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .testTag("analysis_tab_${tab.name.lowercase()}")
                        ) {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) SurfaceDark else TextPrimary
                            )
                        }
                    }
                }
            }

            // Component Views Based on Active Filter Tab
            when (selectedTab) {
                AnalysisTab.ALL -> {
                    item {
                        AnalysisScoreContent(snapshot = analysisResult.coreSnapshot)
                    }
                    item {
                        AnalysisCandlestickCard(result = analysisResult.candlestickResult)
                    }
                    item {
                        AnalysisStructureCard(
                            structure = analysisResult.structureResult,
                            sr = analysisResult.supportResistanceResult,
                            currentPrice = analysisResult.currentPrice
                        )
                    }
                    item {
                        AnalysisFibonacciCard(
                            fibonacci = analysisResult.fibonacciResult,
                            currentPrice = analysisResult.currentPrice
                        )
                    }
                    item {
                        AnalysisRiskRewardCard(
                            volatility = analysisResult.volatilityResult,
                            riskReward = analysisResult.riskRewardResult
                        )
                    }
                }
                AnalysisTab.CORE_MTF -> {
                    item {
                        AnalysisScoreContent(snapshot = analysisResult.coreSnapshot)
                    }
                }
                AnalysisTab.PATTERNS -> {
                    item {
                        AnalysisCandlestickCard(result = analysisResult.candlestickResult)
                    }
                }
                AnalysisTab.STRUCTURE -> {
                    item {
                        AnalysisStructureCard(
                            structure = analysisResult.structureResult,
                            sr = analysisResult.supportResistanceResult,
                            currentPrice = analysisResult.currentPrice
                        )
                    }
                }
                AnalysisTab.FIBONACCI -> {
                    item {
                        AnalysisFibonacciCard(
                            fibonacci = analysisResult.fibonacciResult,
                            currentPrice = analysisResult.currentPrice
                        )
                    }
                }
                AnalysisTab.RISK_REWARD -> {
                    item {
                        AnalysisRiskRewardCard(
                            volatility = analysisResult.volatilityResult,
                            riskReward = analysisResult.riskRewardResult
                        )
                    }
                }
            }

            // Architectural Separation of Permissions Notice
            item {
                AppCard(
                    modifier = Modifier.fillMaxWidth(),
                    variant = CardVariant.DEFAULT
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = WarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ARCHITECTURAL SEPARATION & ZERO TRADE GUARANTEE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = WarningAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "• Terminal Chart Independence: Adding, removing, or changing indicators on the Terminal chart NEVER alters the Analysis Engine state.\n• Non-Execution Guarantee: The Analysis Engine evaluates market condition purely for analytical intelligence. It NEVER places automatic trades.\n• 80% Rule Verification: At least 5 of the 8 Core Indicators must score >= 80% for technical confirmation.\n• Background Execution: Runs asynchronously on background dispatchers to guarantee zero UI frame freezes.",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
