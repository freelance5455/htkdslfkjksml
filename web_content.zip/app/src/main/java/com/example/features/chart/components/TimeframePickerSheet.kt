package com.example.features.chart.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Timeframe
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeframePickerSheet(
    isOpen: Boolean,
    currentTimeframe: Timeframe,
    onTimeframeSelected: (Timeframe) -> Unit,
    onDismiss: () -> Unit
) {
    if (!isOpen) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "CHART TIMEFRAME",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Text(
                text = "Select visible chart interval. Multi-Timeframe Analysis engine analyzes all intervals independently.",
                fontSize = 11.sp,
                color = TextSecondary,
                modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
            )

            // Group 1: Minutes (1m, 3m, 5m, 15m, 30m)
            TimeframeCategorySection(
                title = "MINUTES",
                timeframes = listOf(Timeframe.M1, Timeframe.M3, Timeframe.M5, Timeframe.M15, Timeframe.M30),
                selectedTimeframe = currentTimeframe,
                onSelect = {
                    onTimeframeSelected(it)
                    onDismiss()
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Group 2: Hours (1h, 2h, 4h, 6h, 8h, 12h)
            TimeframeCategorySection(
                title = "HOURS",
                timeframes = listOf(Timeframe.H1, Timeframe.H2, Timeframe.H4, Timeframe.H6, Timeframe.H8, Timeframe.H12),
                selectedTimeframe = currentTimeframe,
                onSelect = {
                    onTimeframeSelected(it)
                    onDismiss()
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Group 3: Days, Weeks & Months (1D, 3D, 1W, 1M)
            TimeframeCategorySection(
                title = "DAYS / WEEKS / MONTHS",
                timeframes = listOf(Timeframe.D1, Timeframe.D3, Timeframe.W1, Timeframe.MN1),
                selectedTimeframe = currentTimeframe,
                onSelect = {
                    onTimeframeSelected(it)
                    onDismiss()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun TimeframeCategorySection(
    title: String,
    timeframes: List<Timeframe>,
    selectedTimeframe: Timeframe,
    onSelect: (Timeframe) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = CyanAccent,
            letterSpacing = 0.5.sp,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            timeframes.forEach { tf ->
                val isSelected = tf == selectedTimeframe
                val isSpecialDistinction = tf.isMinute || tf.isMonth

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyanAccent.copy(alpha = 0.25f) else SurfaceElevated)
                        .border(
                            1.dp,
                            if (isSelected) CyanAccent else BorderSubtle,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { onSelect(tf) }
                        .padding(vertical = 8.dp)
                        .testTag("tf_item_${tf.label}"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = tf.label,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) CyanAccent else TextPrimary
                        )
                        if (isSpecialDistinction) {
                            Text(
                                text = if (tf.isMinute) "Min" else "Month",
                                fontSize = 8.sp,
                                color = if (isSelected) CyanAccent else TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
