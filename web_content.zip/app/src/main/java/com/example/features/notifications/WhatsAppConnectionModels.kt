package com.example.features.notifications

/**
 * Supported connection methods for WhatsApp integration.
 */
enum class WhatsAppConnectionMethod(val label: String, val isSupported: Boolean) {
    META_CLOUD_API("Meta Cloud API", true),
    QR_CONNECTION("QR / WhatsApp Connection", false);

    companion object {
        fun fromString(value: String?): WhatsAppConnectionMethod {
            return entries.find { it.name.equals(value, ignoreCase = true) } ?: META_CLOUD_API
        }
    }
}

/**
 * Real-time connection status for WhatsApp integration.
 */
sealed class WhatsAppConnectionStatus {
    object Connected : WhatsAppConnectionStatus() {
        override fun toString(): String = "Connected"
    }

    object Connecting : WhatsAppConnectionStatus() {
        override fun toString(): String = "Connecting"
    }

    object Disconnected : WhatsAppConnectionStatus() {
        override fun toString(): String = "Disconnected"
    }

    data class AuthenticationRequired(val reason: String = "Authentication Required: Invalid or expired Meta Access Token") : WhatsAppConnectionStatus() {
        override fun toString(): String = "Authentication Required"
    }

    data class Unavailable(val reason: String) : WhatsAppConnectionStatus() {
        override fun toString(): String = "Unavailable"
    }

    companion object {
        fun fromString(value: String?, reason: String? = null): WhatsAppConnectionStatus {
            return when (value?.lowercase()) {
                "connected" -> Connected
                "auth_required", "authentication_required" -> AuthenticationRequired(reason ?: "Token expired or unauthorized")
                "unavailable" -> Unavailable(reason ?: "Architecture limitation")
                else -> Disconnected
            }
        }
    }
}

/**
 * Result of active connection verification with Meta WhatsApp Cloud API.
 */
sealed class WhatsAppVerificationResult {
    data class Success(
        val displayPhoneNumber: String,
        val verifiedName: String,
        val verifiedAt: String
    ) : WhatsAppVerificationResult()

    data class Failure(
        val errorMessage: String,
        val httpCode: Int? = null,
        val isAuthFailure: Boolean = false
    ) : WhatsAppVerificationResult()
}
