package com.example.features.analysis

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.indicator.AnalysisScoreSnapshot
import com.example.core.model.indicator.CoreIndicatorScore
import com.example.core.model.indicator.IndicatorDirection
import com.example.core.model.indicator.TimeframeAnalysisScore
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.CardVariant
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.SurfaceHighlight
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber

/**
 * Dedicated Analysis Score Screen Content (Accessible via More -> Analysis Score and NavSection.ANALYSIS).
 *
 * ARCHITECTURAL INDEPENDENCE:
 * This screen is NOT a chart screen. It does not embed a chart or rely on chart scrolling/indicators.
 * Displays:
 * A) 8 Core Indicator Scores (with confirmation rule: >= 5 must score >= 80%)
 * B) Multi-Timeframe Analysis Scores (5M, 15M, 30M, 1H, 2H, 4H, 6H, 8H, 12H, 1D)
 * C) News / Sentiment Score
 */
@Composable
fun AnalysisScoreContent(
    snapshot: AnalysisScoreSnapshot?,
    modifier: Modifier = Modifier
) {
    val activeSnapshot = snapshot ?: com.example.core.indicator.analysis.CoreAnalysisEngine.createSnapshot(
        symbol = "BTCUSDT",
        currentPrice = 65420.0,
        candles = emptyList()
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("analysis_score_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header Card: Symbol & Composite Bias
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = activeSnapshot.symbol,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyanAccent.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "CORE ANALYSIS",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanAccent
                            )
                        }
                    }
                    Text(
                        text = if (activeSnapshot.currentPrice > 0) "$%.2f".format(activeSnapshot.currentPrice) else "Live Quotes Active",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                // Composite Overall Score Badge
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${activeSnapshot.overallCompositeScore}%",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (activeSnapshot.overallCompositeScore >= 75) BullGreen else CyanAccent
                    )
                    Text(
                        text = "COMPOSITE BIAS",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextTertiary,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // ==========================================
        // SECTION A: 8 CORE INDICATOR SCORES
        // ==========================================
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            // Section Header & 80% Confirmation Ratio
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "8 CORE INDICATORS",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Confirmation Badge: >= 5 of 8 must score >= 80%
                val isConfirmed = activeSnapshot.isConfirmationConditionMet
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isConfirmed) BullGreen.copy(alpha = 0.15f) else WarningAmber.copy(alpha = 0.15f))
                        .border(1.dp, if (isConfirmed) BullGreen else WarningAmber, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("core_confirmation_badge")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isConfirmed) Icons.Default.CheckCircle else Icons.Default.HourglassEmpty,
                            contentDescription = null,
                            tint = if (isConfirmed) BullGreen else WarningAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Core >= 80%: ${activeSnapshot.confirmationRatioText}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isConfirmed) BullGreen else WarningAmber
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Centralized analysis indicators evaluated independently of chart viewport. At least 5 of 8 must score >= 80% for signal confirmation.",
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            // The 8 Core Indicator Rows
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                activeSnapshot.coreScores.forEach { core ->
                    CoreIndicatorRowItem(core = core)
                }
            }
        }

        // ==========================================
        // SECTION B: MULTI-TIMEFRAME ANALYSIS SCORES
        // ==========================================
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timeline,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "MULTI-TIMEFRAME ANALYSIS",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Text(
                    text = "10 Timeframes (5M to 1D)",
                    fontSize = 10.sp,
                    color = TextTertiary
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Separate score for EACH required timeframe. Scores are never collapsed into a single hidden value.",
                fontSize = 11.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Display all 10 required timeframes individually
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                activeSnapshot.timeframeScores.forEach { tfScore ->
                    TimeframeScoreRowItem(item = tfScore)
                }
            }
        }

        // ==========================================
        // SECTION C: NEWS / SENTIMENT SCORE
        // ==========================================
        AppCard(
            modifier = Modifier.fillMaxWidth(),
            variant = CardVariant.DEFAULT
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Newspaper,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NEWS / SENTIMENT SCORE",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Explicit News / Sentiment Score
                Text(
                    text = "News/Sentiment — ${activeSnapshot.newsSentimentScore}%",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (activeSnapshot.newsSentimentScore >= 60) BullGreen else if (activeSnapshot.newsSentimentScore <= 40) BearRed else WarningAmber,
                    modifier = Modifier.testTag("news_sentiment_score_value")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { activeSnapshot.newsSentimentScore / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (activeSnapshot.newsSentimentScore >= 60) BullGreen else if (activeSnapshot.newsSentimentScore <= 40) BearRed else WarningAmber,
                trackColor = SurfaceDark
            )

            Spacer(modifier = Modifier.height(10.dp))

            activeSnapshot.newsHeadlineSample?.let { headline ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(SurfaceDark)
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "LATEST SENTIMENT FEEDBACK",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = headline,
                            fontSize = 11.sp,
                            color = TextPrimary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Individual row displaying one of the 8 Core Indicators.
 */
@Composable
private fun CoreIndicatorRowItem(core: CoreIndicatorScore) {
    val dirColor = when (core.direction) {
        IndicatorDirection.BULLISH -> BullGreen
        IndicatorDirection.BEARISH -> BearRed
        IndicatorDirection.NEUTRAL -> WarningAmber
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceElevated)
            .border(
                1.dp,
                if (core.isConfirmed) BullGreen.copy(alpha = 0.4f) else BorderSubtle,
                RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .testTag("core_indicator_row_${core.coreIndex}"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Indicator ${core.coreIndex}: ${core.name}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                if (core.isConfirmed) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = ">=80% Confirmed",
                        tint = BullGreen,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Text(
                text = core.interpretation,
                fontSize = 10.sp,
                color = TextSecondary,
                lineHeight = 14.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "${core.scorePct}%",
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (core.isConfirmed) BullGreen else dirColor
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(dirColor.copy(alpha = 0.15f))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
            ) {
                Text(
                    text = core.direction.name,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = dirColor
                )
            }
        }
    }
}

/**
 * Individual row displaying a specific timeframe score from 5M to 1D.
 */
@Composable
private fun TimeframeScoreRowItem(item: TimeframeAnalysisScore) {
    val dirColor = when (item.direction) {
        IndicatorDirection.BULLISH -> BullGreen
        IndicatorDirection.BEARISH -> BearRed
        IndicatorDirection.NEUTRAL -> WarningAmber
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(SurfaceDark)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("mtf_score_${item.timeframe.lowercase()}"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(width = 34.dp, height = 22.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(CyanAccent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.timeframe,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyanAccent
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = item.summaryText,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "${item.scorePct}%",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = dirColor
            )
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dirColor)
            )
        }
    }
}
