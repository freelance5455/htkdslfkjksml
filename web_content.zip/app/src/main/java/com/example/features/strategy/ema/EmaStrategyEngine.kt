package com.example.features.strategy.ema

import com.example.core.analysis.candlestick.CandlestickPatternEngine
import com.example.core.analysis.levels.SupportResistanceEngine
import com.example.core.analysis.risk.RiskRewardEngine
import com.example.core.analysis.structure.MarketStructureEngine
import com.example.core.indicator.engine.ComprehensiveIndicatorEngine
import com.example.core.model.analysis.VolatilityEnvironment
import com.example.core.model.chart.Candle
import com.example.core.model.indicator.IndicatorDirection
import java.util.Locale
import kotlin.math.abs

/**
 * Isolated calculation engine for the EMA 9/21 Strategy with ADX Primary Filter.
 *
 * Rules:
 * - EMA 9 = Fast EMA, EMA 21 = Slow EMA
 * - ADX = PRIMARY FILTER (adx >= threshold)
 * - Confirmation layers: Market Structure, Candle Patterns, Support/Resistance, Volatility, MTF
 * - NO REPAINTING: Only completed candles can create a CONFIRMED signal.
 *   Live/incomplete candles may be monitored for developing setups but NEVER produce a confirmed BUY/SELL.
 * - NO LOOK-AHEAD BIAS: Strict chronological processing up to the last closed candle.
 * - Strictly isolated: Never places orders, alters account states, or mutates other indicators.
 */
object EmaStrategyEngine {

    fun evaluate(
        candles: List<Candle>,
        config: EmaStrategyConfig,
        symbol: String,
        currentPriceOverride: Double? = null,
        mtfBias: IndicatorDirection? = null
    ): EmaStrategyEvaluation {
        val now = System.currentTimeMillis()

        if (candles.isEmpty()) {
            return createUnavailableEvaluation(
                symbol = symbol,
                timeframe = config.timeframe,
                adxThreshold = config.adxThreshold,
                reason = "No market candle data available."
            )
        }

        val lastRawCandle = candles.last()
        val isLastCandleLive = !lastRawCandle.isClosed

        // Separate completed candles for CONFIRMED signal calculation (No Repainting mandate)
        val completedCandles = if (isLastCandleLive) {
            candles.dropLast(1)
        } else {
            candles
        }

        val lastCompletedTimestamp = completedCandles.lastOrNull()?.timestamp ?: 0L
        val effectivePrice = currentPriceOverride ?: (candles.lastOrNull()?.close ?: 0.0)

        val minCandlesRequired = maxOf(config.slowEmaPeriod + 5, config.adxPeriod * 2)
        if (completedCandles.size < minCandlesRequired) {
            return EmaStrategyEvaluation(
                symbol = symbol,
                currentPrice = effectivePrice,
                timeframe = config.timeframe,
                fastEma = null,
                slowEma = null,
                adx = null,
                adxThreshold = config.adxThreshold,
                result = EmaSignalResult.WAIT,
                confirmations = EmaConfirmationLayers(
                    adxThreshold = config.adxThreshold,
                    adxConfirmed = false,
                    mtfConfirmation = "Unavailable",
                    marketStructure = "Insufficient History",
                    candlePattern = "Insufficient History",
                    volatilityStatus = "Insufficient History",
                    supportResistance = "Unavailable",
                    volumeStatus = "Unavailable"
                ),
                explanation = "Waiting for data. Insufficient completed candles (${completedCandles.size}/$minCandlesRequired required) for EMA ${config.fastEmaPeriod}/${config.slowEmaPeriod} & ADX(${config.adxPeriod}).",
                isLiveCandleIncomplete = isLastCandleLive,
                lastCompletedCandleTime = lastCompletedTimestamp,
                dataTimestamp = now
            )
        }

        // 1. Calculate Fast EMA (9) and Slow EMA (21) series on completed candles
        val fastEmaSeries = ComprehensiveIndicatorEngine.calculateEMA(completedCandles, config.fastEmaPeriod)
        val slowEmaSeries = ComprehensiveIndicatorEngine.calculateEMA(completedCandles, config.slowEmaPeriod)
        val adxSeries = ComprehensiveIndicatorEngine.calculateADX(completedCandles, config.adxPeriod)

        if (fastEmaSeries.size < 2 || slowEmaSeries.size < 2) {
            return createUnavailableEvaluation(
                symbol = symbol,
                timeframe = config.timeframe,
                adxThreshold = config.adxThreshold,
                reason = "Unable to compute EMA series from completed candles."
            )
        }

        val latestFastEma = fastEmaSeries.last().value
        val prevFastEma = fastEmaSeries[fastEmaSeries.size - 2].value

        val latestSlowEma = slowEmaSeries.last().value
        val prevSlowEma = slowEmaSeries[slowEmaSeries.size - 2].value

        val latestAdx = adxSeries.lastOrNull()?.value

        // 2. Check for crossover on COMPLETED candles
        val isBullishCrossover = (prevFastEma <= prevSlowEma && latestFastEma > latestSlowEma)
        val isBearishCrossover = (prevFastEma >= prevSlowEma && latestFastEma < latestSlowEma)

        // 3. Monitor live developing candle (if present) for informational display only
        var isDevelopingLiveCrossover = false
        if (isLastCandleLive && !isBullishCrossover && !isBearishCrossover) {
            val liveFast = ComprehensiveIndicatorEngine.calculateEMA(candles, config.fastEmaPeriod).lastOrNull()?.value
            val liveSlow = ComprehensiveIndicatorEngine.calculateEMA(candles, config.slowEmaPeriod).lastOrNull()?.value
            if (liveFast != null && liveSlow != null) {
                val liveBullish = latestFastEma <= latestSlowEma && liveFast > liveSlow
                val liveBearish = latestFastEma >= latestSlowEma && liveFast < liveSlow
                isDevelopingLiveCrossover = liveBullish || liveBearish
            }
        }

        // 4. Primary Filter: ADX (must be >= threshold)
        val adxThreshold = config.adxThreshold
        val adxValue = latestAdx ?: 0.0
        val isAdxSufficient = latestAdx != null && latestAdx >= adxThreshold

        // 5. Existing Confirmation Layers
        // A) Multi-Timeframe Alignment
        val mtfDesc = when (mtfBias) {
            IndicatorDirection.BULLISH -> "Higher TF Bullish"
            IndicatorDirection.BEARISH -> "Higher TF Bearish"
            IndicatorDirection.NEUTRAL -> "Higher TF Neutral"
            null -> "Single TF Mode"
        }
        val isMtfBullishAligned = mtfBias == null || mtfBias == IndicatorDirection.BULLISH || mtfBias == IndicatorDirection.NEUTRAL
        val isMtfBearishAligned = mtfBias == null || mtfBias == IndicatorDirection.BEARISH || mtfBias == IndicatorDirection.NEUTRAL

        // B) Market Structure
        val structureResult = MarketStructureEngine.analyzeStructure(completedCandles)
        val structureDesc = "${structureResult.trend.label} • ${structureResult.state.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }}"
        val isStructureBullish = structureResult.structuralBias != IndicatorDirection.BEARISH
        val isStructureBearish = structureResult.structuralBias != IndicatorDirection.BULLISH

        // C) Candlestick Patterns
        val candlePatterns = CandlestickPatternEngine.detectPatterns(completedCandles, config.timeframe.label)
        val hasOpposingBearishPattern = candlePatterns.detectedPatterns.any { it.classification == IndicatorDirection.BEARISH && it.confidencePct >= 70 }
        val hasOpposingBullishPattern = candlePatterns.detectedPatterns.any { it.classification == IndicatorDirection.BULLISH && it.confidencePct >= 70 }
        val patternDesc = if (candlePatterns.detectedPatterns.isNotEmpty()) {
            candlePatterns.detectedPatterns.take(2).joinToString { it.name }
        } else {
            "No conflicting patterns"
        }

        // D) Volatility / ATR
        val volatility = RiskRewardEngine.analyzeVolatility(completedCandles)
        val isVolatilityAcceptable = volatility.environment != VolatilityEnvironment.EXTREME
        val volDesc = "${volatility.environment.name} (ATR: ${String.format(Locale.US, "%.2f", volatility.atrValue)})"

        // E) Support / Resistance
        val srResult = SupportResistanceEngine.calculateLevels(completedCandles)
        val srDesc = when {
            srResult.nearestResistance != null && srResult.nearestSupport != null ->
                "S: ${String.format(Locale.US, "%,.2f", srResult.nearestSupport.price)} | R: ${String.format(Locale.US, "%,.2f", srResult.nearestResistance.price)}"
            srResult.nearestResistance != null ->
                "R: ${String.format(Locale.US, "%,.2f", srResult.nearestResistance.price)}"
            srResult.nearestSupport != null ->
                "S: ${String.format(Locale.US, "%,.2f", srResult.nearestSupport.price)}"
            else -> "Open Range"
        }

        // Check if price is colliding immediately into major S/R
        var isSrClearForBuy = true
        var isSrClearForSell = true
        if (srResult.nearestResistance != null && effectivePrice > 0) {
            val distToResPct = (srResult.nearestResistance.price - effectivePrice) / effectivePrice
            if (distToResPct in 0.0..0.001) {
                isSrClearForBuy = false
            }
        }
        if (srResult.nearestSupport != null && effectivePrice > 0) {
            val distToSuppPct = (effectivePrice - srResult.nearestSupport.price) / effectivePrice
            if (distToSuppPct in 0.0..0.001) {
                isSrClearForSell = false
            }
        }

        // F) Volume status
        val recentVolumes = completedCandles.takeLast(10).map { it.volume }
        val avgVolume = if (recentVolumes.isNotEmpty()) recentVolumes.average() else 0.0
        val lastVolume = completedCandles.last().volume
        val volumeDesc = when {
            avgVolume <= 0.0 -> "Volume N/A"
            lastVolume >= avgVolume * 1.2 -> "Above Average (${String.format(Locale.US, "%.1f", lastVolume / avgVolume)}x)"
            lastVolume >= avgVolume * 0.8 -> "Normal Volume"
            else -> "Low Volume"
        }

        // Build Confirmation Layers model
        val confirmationLayers = EmaConfirmationLayers(
            adxValue = latestAdx,
            adxThreshold = adxThreshold,
            adxConfirmed = isAdxSufficient,
            mtfConfirmation = mtfDesc,
            mtfAligned = when {
                isBullishCrossover || latestFastEma > latestSlowEma -> isMtfBullishAligned
                isBearishCrossover || latestFastEma < latestSlowEma -> isMtfBearishAligned
                else -> true
            },
            marketStructure = structureDesc,
            marketStructureAligned = if (isBullishCrossover) isStructureBullish else if (isBearishCrossover) isStructureBearish else true,
            candlePattern = patternDesc,
            candlePatternAligned = if (isBullishCrossover) (!hasOpposingBearishPattern) else if (isBearishCrossover) (!hasOpposingBullishPattern) else true,
            volatilityStatus = volDesc,
            volatilityAcceptable = isVolatilityAcceptable,
            supportResistance = srDesc,
            supportResistanceClear = if (isBullishCrossover) isSrClearForBuy else if (isBearishCrossover) isSrClearForSell else true,
            volumeStatus = volumeDesc,
            volumeAcceptable = true
        )

        // 6. Final Signal Decision Logic
        val (finalResult, explanation) = when {
            // Live candle developing crossover (unconfirmed, must NOT produce BUY/SELL)
            isDevelopingLiveCrossover -> {
                Pair(
                    EmaSignalResult.WAIT,
                    "Live/incomplete candle is currently forming an EMA crossover. Waiting for completed candle close to confirm signal (No Repainting)."
                )
            }

            // Confirmed Bullish Crossover on completed candle
            isBullishCrossover -> {
                when {
                    !isAdxSufficient -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9 crossed above EMA 21, but ADX (${String.format(Locale.US, "%.1f", adxValue)}) is below primary filter threshold (${String.format(Locale.US, "%.1f", adxThreshold)}). Trend momentum is insufficient."
                        )
                    }
                    !isMtfBullishAligned -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bullish crossover filtered by opposing higher-timeframe bearish bias."
                        )
                    }
                    !isStructureBullish -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bullish crossover filtered: market structure is Bearish (Lower Highs / Lower Lows)."
                        )
                    }
                    hasOpposingBearishPattern -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bullish crossover filtered: strong opposing bearish candlestick pattern detected."
                        )
                    }
                    !isVolatilityAcceptable -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bullish crossover filtered: abnormal extreme market volatility."
                        )
                    }
                    !isSrClearForBuy -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bullish crossover filtered: price is immediately colliding into major overhead resistance ($srDesc)."
                        )
                    }
                    else -> {
                        Pair(
                            EmaSignalResult.BUY,
                            "Confirmed EMA 9 (${String.format(Locale.US, "%,.2f", latestFastEma)}) crossed above EMA 21 (${String.format(Locale.US, "%,.2f", latestSlowEma)}) on closed candle. ADX (${String.format(Locale.US, "%.1f", adxValue)} >= ${String.format(Locale.US, "%.1f", adxThreshold)}) confirms strong trend momentum with supportive market structure."
                        )
                    }
                }
            }

            // Confirmed Bearish Crossover on completed candle
            isBearishCrossover -> {
                when {
                    !isAdxSufficient -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9 crossed below EMA 21, but ADX (${String.format(Locale.US, "%.1f", adxValue)}) is below primary filter threshold (${String.format(Locale.US, "%.1f", adxThreshold)}). Trend momentum is insufficient."
                        )
                    }
                    !isMtfBearishAligned -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bearish crossover filtered by opposing higher-timeframe bullish bias."
                        )
                    }
                    !isStructureBearish -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bearish crossover filtered: market structure is Bullish (Higher Highs / Higher Lows)."
                        )
                    }
                    hasOpposingBullishPattern -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bearish crossover filtered: strong opposing bullish candlestick pattern detected."
                        )
                    }
                    !isVolatilityAcceptable -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bearish crossover filtered: abnormal extreme market volatility."
                        )
                    }
                    !isSrClearForSell -> {
                        Pair(
                            EmaSignalResult.WAIT,
                            "EMA 9/21 bearish crossover filtered: price is immediately colliding into major support ($srDesc)."
                        )
                    }
                    else -> {
                        Pair(
                            EmaSignalResult.SELL,
                            "Confirmed EMA 9 (${String.format(Locale.US, "%,.2f", latestFastEma)}) crossed below EMA 21 (${String.format(Locale.US, "%,.2f", latestSlowEma)}) on closed candle. ADX (${String.format(Locale.US, "%.1f", adxValue)} >= ${String.format(Locale.US, "%.1f", adxThreshold)}) confirms strong downward momentum with supportive market structure."
                        )
                    }
                }
            }

            // No crossover
            else -> {
                val stateText = if (latestFastEma > latestSlowEma) {
                    "EMA 9 (${String.format(Locale.US, "%,.2f", latestFastEma)}) is currently above EMA 21 (${String.format(Locale.US, "%,.2f", latestSlowEma)}). No fresh crossover on latest completed candle."
                } else if (latestFastEma < latestSlowEma) {
                    "EMA 9 (${String.format(Locale.US, "%,.2f", latestFastEma)}) is currently below EMA 21 (${String.format(Locale.US, "%,.2f", latestSlowEma)}). No fresh crossover on latest completed candle."
                } else {
                    "EMA 9 and EMA 21 are converging. Waiting for confirmed completed-candle crossover."
                }
                val adxText = if (latestAdx != null) " ADX: ${String.format(Locale.US, "%.1f", latestAdx)} (threshold ${String.format(Locale.US, "%.1f", adxThreshold)})." else ""
                Pair(
                    EmaSignalResult.WAIT,
                    "Waiting for setup. $stateText$adxText Never forcing a signal."
                )
            }
        }

        return EmaStrategyEvaluation(
            symbol = symbol,
            currentPrice = effectivePrice,
            timeframe = config.timeframe,
            fastEma = latestFastEma,
            slowEma = latestSlowEma,
            adx = latestAdx,
            adxThreshold = adxThreshold,
            result = finalResult,
            confirmations = confirmationLayers,
            explanation = explanation,
            isLiveCandleIncomplete = isLastCandleLive,
            lastCompletedCandleTime = lastCompletedTimestamp,
            dataTimestamp = now
        )
    }

    private fun createUnavailableEvaluation(
        symbol: String,
        timeframe: com.example.core.model.Timeframe,
        adxThreshold: Double,
        reason: String
    ): EmaStrategyEvaluation {
        return EmaStrategyEvaluation(
            symbol = symbol,
            currentPrice = 0.0,
            timeframe = timeframe,
            fastEma = null,
            slowEma = null,
            adx = null,
            adxThreshold = adxThreshold,
            result = EmaSignalResult.WAIT,
            confirmations = EmaConfirmationLayers(
                adxThreshold = adxThreshold,
                adxConfirmed = false,
                mtfConfirmation = "Unavailable",
                marketStructure = "Unavailable",
                candlePattern = "Unavailable",
                volatilityStatus = "Unavailable",
                supportResistance = "Unavailable",
                volumeStatus = "Unavailable"
            ),
            explanation = "Waiting for market data: $reason",
            isLiveCandleIncomplete = false,
            lastCompletedCandleTime = 0L,
            dataTimestamp = System.currentTimeMillis()
        )
    }
}
