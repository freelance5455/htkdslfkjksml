package com.example.features.terminal

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.chart.ChartExportHelper
import com.example.core.chart.IQTradeChart
import com.example.core.chart.IQTradeChartController
import com.example.core.model.Instrument
import com.example.core.model.MarketCategory
import com.example.core.model.chart.ChartConnectionState
import com.example.core.model.chart.ChartDrawing
import com.example.core.model.chart.DrawingType
import com.example.core.model.chart.IndicatorType
import com.example.core.model.chart.OrderType
import com.example.core.model.chart.PriceAlertEvent
import com.example.core.model.chart.TradeProtectionState
import com.example.core.model.chart.TradeSide
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.AppToggle
import com.example.core.ui.components.ButtonStyle
import com.example.core.ui.components.CardVariant
import com.example.core.ui.components.PageContainer
import com.example.features.chart.components.DrawingToolsPalette
import com.example.features.chart.components.FullScreenChartDialog
import com.example.features.chart.components.IndicatorLibraryDialog
import com.example.features.chart.components.PriceAlertBanner
import com.example.features.chart.components.TimeframePickerSheet
import com.example.features.chart.trading.OrderEntryDialog
import com.example.features.market.SymbolSearchSheet
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MainUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(
    state: MainUiState,
    onMarketSelected: (MarketCategory) -> Unit,
    onInstrumentSelected: (Instrument) -> Unit,
    onOpenSymbolPicker: () -> Unit,
    onCloseSymbolPicker: () -> Unit,
    onSearchQueryChanged: (String) -> Unit,
    onQuoteFilterSelected: (String?) -> Unit,
    onRefreshSymbols: () -> Unit,
    onTimeframeSelected: (String) -> Unit,
    onToggleIndicators: (Boolean) -> Unit,
    onToggleVolume: (Boolean) -> Unit,
    onToggleSignals: (Boolean) -> Unit,
    onSimulatePaperTrade: (String, Double) -> Unit,
    onAddIndicator: (IndicatorType, Int, String) -> Unit = { _, _, _ -> },
    onRemoveIndicator: (String) -> Unit = {},
    onToggleIndicator: (String, Boolean) -> Unit = { _, _ -> },
    onUpdateIndicatorPeriod: (String, Int) -> Unit = { _, _ -> },
    onSelectDrawingTool: (DrawingType) -> Unit = {},
    onClearAllDrawings: () -> Unit = {},
    onDrawingCreated: (ChartDrawing) -> Unit = {},
    onExecuteOrder: (side: TradeSide, orderType: OrderType, entryPrice: Double, quantity: Double, protection: TradeProtectionState) -> Unit = { _, _, _, _, _ -> },
    onFloatClick: () -> Unit = {},
    onReloadChartData: () -> Unit = {},
    onPriceAlert: (PriceAlertEvent) -> Unit = {},
    onDismissPriceAlert: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val chartController = remember { IQTradeChartController() }

    var isTimeframeSheetOpen by remember { mutableStateOf(false) }
    var isIndicatorSheetOpen by remember { mutableStateOf(false) }
    var isDrawingPaletteOpen by remember { mutableStateOf(false) }
    var isFullscreenOpen by remember { mutableStateOf(false) }
    var isSettingsSheetOpen by remember { mutableStateOf(false) }
    var orderEntrySide by remember { mutableStateOf<TradeSide?>(null) }
    var localAlert by remember { mutableStateOf<PriceAlertEvent?>(null) }
    val effectiveAlert = state.activePriceAlert ?: localAlert

    LaunchedEffect(localAlert) {
        if (localAlert != null) {
            kotlinx.coroutines.delay(6000)
            localAlert = null
        }
    }

    val onExportAction: () -> Unit = {
        chartController.exportCanvasAsBase64 { base64 ->
            if (base64 != null) {
                ChartExportHelper.shareChart(
                    context = context,
                    base64Str = base64,
                    symbol = state.chartDataState.selectedSymbol,
                    timeframe = state.chartDataState.selectedTimeframe.label
                )
            }
        }
    }

    PageContainer(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .testTag("terminal_workspace_column")
        ) {
            // ================= 1. COMPACT TOP CONTROLS BAR =================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceDark)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag("terminal_top_controls_bar"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Market switcher & Symbol picker & Timeframe picker
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    // Market category dropdown pill (Crypto / Forex / Gold)
                    Box {
                        var marketMenuExpanded by remember { mutableStateOf(false) }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyanAccent.copy(alpha = 0.15f))
                                .border(1.dp, CyanAccent.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                .clickable { marketMenuExpanded = true }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = state.selectedMarket.displayName.take(4).uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanAccent
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(text = "▼", fontSize = 7.sp, color = CyanAccent)
                        }
                        DropdownMenu(
                            expanded = marketMenuExpanded,
                            onDismissRequest = { marketMenuExpanded = false },
                            modifier = Modifier.background(SurfaceDark)
                        ) {
                            MarketCategory.entries.forEach { market ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = market.displayName,
                                            color = if (market == state.selectedMarket) CyanAccent else TextPrimary,
                                            fontWeight = if (market == state.selectedMarket) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp
                                        )
                                    },
                                    onClick = {
                                        onMarketSelected(market)
                                        marketMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Active Symbol Selector Pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceElevated)
                            .border(1.dp, BorderSubtle, RoundedCornerShape(6.dp))
                            .clickable { onOpenSymbolPicker() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("chart_symbol_selector")
                    ) {
                        Text(
                            text = state.selectedSymbol,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "▼", fontSize = 7.sp, color = TextSecondary)
                    }

                    // Timeframe selector pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceElevated)
                            .border(1.dp, BorderSubtle, RoundedCornerShape(6.dp))
                            .clickable { isTimeframeSheetOpen = true }
                            .padding(horizontal = 7.dp, vertical = 4.dp)
                            .testTag("chart_timeframe_selector")
                    ) {
                        Text(
                            text = state.selectedTimeframe,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = "▼", fontSize = 7.sp, color = TextSecondary)
                    }

                    // Paper Mode Badge
                    if (!state.isLiveTradingEnabled || state.tradingMode.contains("PAPER", ignoreCase = true)) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyanAccent.copy(alpha = 0.15f))
                                .border(1.dp, CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                                .testTag("chart_paper_mode_badge"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "PAPER MODE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = CyanAccent,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                // Right: Real-time Price readout & compact action icons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    state.chartDataState.currentPrice?.let { price ->
                        Text(
                            text = "%.2f".format(price),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = BullGreen,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }

                    IconButton(
                        onClick = onExportAction,
                        modifier = Modifier.size(30.dp).testTag("btn_chart_export")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Snapshot",
                            tint = CyanAccent,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = onFloatClick,
                        modifier = Modifier.size(30.dp).testTag("btn_chart_float")
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "Float Chart",
                            tint = CyanAccent,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = { isFullscreenOpen = true },
                        modifier = Modifier.size(30.dp).testTag("btn_chart_fullscreen")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fullscreen,
                            contentDescription = "Fullscreen",
                            tint = TextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { isSettingsSheetOpen = true },
                        modifier = Modifier.size(30.dp).testTag("btn_chart_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // ================= 2. COMPACT SECONDARY TOOLBAR =================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceElevated)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(0.dp))
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quick Timeframes
                val quickTimeframes = listOf("1m", "5m", "15m", "1h", "4h", "1D")
                quickTimeframes.forEach { tf ->
                    val isSelected = state.selectedTimeframe == tf
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) CyanAccent.copy(alpha = 0.2f) else Color.Transparent)
                            .clickable { onTimeframeSelected(tf) }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = tf,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) CyanAccent else TextSecondary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(14.dp)
                        .background(BorderSubtle)
                )

                // Indicators button
                val activeIndicatorsCount = state.indicators.count { it.isEnabled }
                CompactToolbarChip(
                    label = if (activeIndicatorsCount > 0 && state.showIndicators) "Indicators ($activeIndicatorsCount)" else "Indicators",
                    isActive = state.showIndicators,
                    icon = Icons.Default.ShowChart,
                    onClick = { isIndicatorSheetOpen = true },
                    testTag = "toolbar_btn_indicators"
                )

                // Volume toggle button
                CompactToolbarChip(
                    label = "Volume",
                    isActive = state.showVolume,
                    icon = Icons.Default.BarChart,
                    onClick = { onToggleVolume(!state.showVolume) },
                    testTag = "toolbar_btn_volume"
                )

                // Drawing tool palette button
                CompactToolbarChip(
                    label = if (state.activeDrawingTool != DrawingType.NONE) state.activeDrawingTool.label else "Draw",
                    isActive = state.activeDrawingTool != DrawingType.NONE,
                    icon = Icons.Default.Brush,
                    onClick = { isDrawingPaletteOpen = true },
                    testTag = "toolbar_btn_draw"
                )

                // Clear drawings button (if any drawings exist)
                if (state.drawings.isNotEmpty()) {
                    CompactToolbarChip(
                        label = "Clear (${state.drawings.size})",
                        isActive = false,
                        icon = Icons.Default.DeleteOutline,
                        onClick = onClearAllDrawings,
                        tint = TextSecondary,
                        testTag = "toolbar_btn_clear_drawings"
                    )
                }

                // Signals toggle button
                CompactToolbarChip(
                    label = "Signals",
                    isActive = state.showSignalPlotting,
                    icon = Icons.Default.Layers,
                    onClick = { onToggleSignals(!state.showSignalPlotting) },
                    testTag = "toolbar_btn_signals"
                )
            }

            // ================= 3. COMPACT STATUS / ALERT BANNER =================
            val conn = state.chartDataState.connectionState
            if (conn.isError || conn is ChartConnectionState.Stale || conn is ChartConnectionState.Reconnecting || conn is ChartConnectionState.ReconnectingAttempt || conn is ChartConnectionState.Disconnected) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (conn.isError) BearRed.copy(alpha = 0.2f) else WarningAmber.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            if (conn.isError) Icons.Default.Warning else Icons.Default.CloudOff,
                            contentDescription = null,
                            tint = if (conn.isError) BearRed else WarningAmber,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            conn.label,
                            fontSize = 10.sp,
                            color = if (conn.isError) BearRed else WarningAmber,
                            maxLines = 1
                        )
                    }
                    if (conn is ChartConnectionState.Reconnecting || conn is ChartConnectionState.ReconnectingAttempt) {
                        CircularProgressIndicator(
                            color = WarningAmber,
                            strokeWidth = 1.5.dp,
                            modifier = Modifier.size(12.dp)
                        )
                    } else {
                        IconButton(onClick = onReloadChartData, modifier = Modifier.size(20.dp)) {
                            Icon(
                                Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = if (conn.isError) BearRed else WarningAmber,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }

            if (effectiveAlert != null) {
                PriceAlertBanner(
                    alert = effectiveAlert,
                    onDismiss = {
                        localAlert = null
                        onDismissPriceAlert()
                    }
                )
            }

            // ================= 4. DOMINANT CHART WORKSPACE (FLEXIBLE HEIGHT) =================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("terminal_chart_container")
            ) {
                // Primary Candlestick Chart
                IQTradeChart(
                    symbol = state.chartDataState.selectedSymbol,
                    timeframe = state.chartDataState.selectedTimeframe.label,
                    candles = state.chartDataState.candles,
                    latestCandle = state.chartDataState.latestCandle,
                    connectionState = state.chartDataState.connectionState,
                    showVolume = state.showVolume,
                    showIndicators = state.showIndicators,
                    indicators = state.indicators,
                    showSignals = state.showSignalPlotting,
                    signalMarkers = state.signalMarkers,
                    executedTrades = state.executedTradeMarkers,
                    protectionState = state.activeProtectionState,
                    activeDrawingTool = state.activeDrawingTool,
                    drawings = state.drawings,
                    onDrawingCreated = onDrawingCreated,
                    onCrosshairMoved = { _, _, _, _, _ -> },
                    onPriceAlert = { event ->
                        localAlert = event
                        onPriceAlert(event)
                    },
                    onReloadData = onReloadChartData,
                    chartController = chartController,
                    modifier = Modifier.fillMaxSize()
                )

                // Active Drawing Tool Floating Banner
                if (state.activeDrawingTool != DrawingType.NONE) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(SurfaceDark.copy(alpha = 0.88f))
                            .border(1.dp, CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tool: ${state.activeDrawingTool.label}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "✕",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            modifier = Modifier.clickable { onSelectDrawingTool(DrawingType.NONE) }
                        )
                    }
                }

                // Floating Compact BUY / SELL Overlay Bar
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 10.dp, start = 12.dp, end = 12.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(SurfaceDark.copy(alpha = 0.92f))
                        .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
                        .padding(horizontal = 6.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // BUY button
                    Box(
                        modifier = Modifier
                            .height(34.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(BullGreen)
                            .clickable { orderEntrySide = TradeSide.BUY }
                            .padding(horizontal = 14.dp)
                            .testTag("chart_buy_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "BUY",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black
                            )
                            state.chartDataState.currentPrice?.let { p ->
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "%.2f".format(p),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black.copy(alpha = 0.85f),
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    // Center Balance / Mode info pill
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Text(
                            text = "$${String.format("%,.0f", state.paperBalance)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BullGreen,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = if (state.tradingMode.contains("LIVE", ignoreCase = true)) "LIVE" else "PAPER",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondary
                        )
                    }

                    // SELL button
                    Box(
                        modifier = Modifier
                            .height(34.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(BearRed)
                            .clickable { orderEntrySide = TradeSide.SELL }
                            .padding(horizontal = 14.dp)
                            .testTag("chart_sell_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SELL",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            state.chartDataState.currentPrice?.let { p ->
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "%.2f".format(p),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // ================= 5. POPUP DIALOGS & BOTTOM SHEETS =================

        // 15 Timeframe Picker Sheet
        TimeframePickerSheet(
            isOpen = isTimeframeSheetOpen,
            currentTimeframe = state.chartDataState.selectedTimeframe,
            onTimeframeSelected = { tf ->
                onTimeframeSelected(tf.label)
                isTimeframeSheetOpen = false
            },
            onDismiss = { isTimeframeSheetOpen = false }
        )

        // Indicator Library Dialog
        IndicatorLibraryDialog(
            isOpen = isIndicatorSheetOpen,
            activeIndicators = state.indicators,
            onAddIndicator = { type, period, color ->
                onAddIndicator(type, period, color)
                onToggleIndicators(true)
            },
            onRemoveIndicator = onRemoveIndicator,
            onToggleIndicator = onToggleIndicator,
            onUpdateIndicatorPeriod = onUpdateIndicatorPeriod,
            onDismiss = { isIndicatorSheetOpen = false }
        )

        // Drawing Tools Palette Dialog
        DrawingToolsPalette(
            isOpen = isDrawingPaletteOpen,
            currentTool = state.activeDrawingTool,
            onSelectTool = onSelectDrawingTool,
            onClearAll = onClearAllDrawings,
            drawingsCount = state.drawings.size,
            onDismiss = { isDrawingPaletteOpen = false }
        )

        // Full Order Entry Dialog (BUY / SELL)
        orderEntrySide?.let { side ->
            OrderEntryDialog(
                isOpen = true,
                symbol = state.chartDataState.selectedSymbol,
                initialSide = side,
                currentPrice = state.chartDataState.currentPrice ?: 0.0,
                availableBalance = state.paperBalance,
                defaultProtection = state.defaultProtectionState,
                isLiveMode = state.isLiveTradingEnabled && state.tradingMode.contains("LIVE", ignoreCase = true),
                onExecuteOrder = { orderSide, orderType, price, qty, protection ->
                    onExecuteOrder(orderSide, orderType, price, qty, protection)
                    orderEntrySide = null
                },
                onDismiss = { orderEntrySide = null }
            )
        }

        // Full Screen Chart Dialog
        if (isFullscreenOpen) {
            FullScreenChartDialog(
                isOpen = true,
                symbol = state.chartDataState.selectedSymbol,
                market = state.chartDataState.selectedMarket,
                timeframe = state.chartDataState.selectedTimeframe,
                currentPrice = state.chartDataState.currentPrice,
                tradingMode = state.tradingMode,
                candles = state.chartDataState.candles,
                latestCandle = state.chartDataState.latestCandle,
                connectionState = state.chartDataState.connectionState,
                showVolume = state.showVolume,
                onToggleVolume = { onToggleVolume(!state.showVolume) },
                showIndicators = state.showIndicators,
                indicators = state.indicators,
                onOpenIndicators = { isIndicatorSheetOpen = true },
                showSignals = state.showSignalPlotting,
                onToggleSignals = { onToggleSignals(!state.showSignalPlotting) },
                signalMarkers = state.signalMarkers,
                executedTrades = state.executedTradeMarkers,
                protectionState = state.activeProtectionState,
                activeDrawingTool = state.activeDrawingTool,
                onOpenDrawingTools = { isDrawingPaletteOpen = true },
                onClearDrawings = onClearAllDrawings,
                drawings = state.drawings,
                onDrawingCreated = onDrawingCreated,
                onCrosshairMoved = { _, _, _, _, _ -> },
                onOpenSymbolPicker = onOpenSymbolPicker,
                onOpenTimeframePicker = { isTimeframeSheetOpen = true },
                onOpenOrderEntry = { side -> orderEntrySide = side },
                onCloseFullscreen = { isFullscreenOpen = false },
                onReloadData = onReloadChartData,
                activePriceAlert = effectiveAlert,
                onDismissPriceAlert = {
                    localAlert = null
                    onDismissPriceAlert()
                },
                onPriceAlert = { event ->
                    localAlert = event
                    onPriceAlert(event)
                }
            )
        }

        // Symbol Search Sheet
        SymbolSearchSheet(
            isOpen = state.isSymbolSearchOpen,
            onDismiss = onCloseSymbolPicker,
            selectedMarket = state.selectedMarket,
            onMarketSelected = onMarketSelected,
            selectedSymbolId = state.selectedSymbol,
            symbols = state.filteredSymbols,
            searchQuery = state.symbolSearchQuery,
            onSearchQueryChanged = onSearchQueryChanged,
            selectedQuoteFilter = state.selectedQuoteFilter,
            onQuoteFilterSelected = onQuoteFilterSelected,
            onInstrumentSelected = onInstrumentSelected,
            onRefresh = onRefreshSymbols,
            isLoading = state.isSymbolsLoading,
            isStale = state.isSymbolDataStale,
            lastUpdateTimestamp = state.lastSymbolUpdateTimestamp,
            errorMessage = state.symbolError
        )

        // Terminal Settings & Specifications Sheet
        if (isSettingsSheetOpen) {
            ModalBottomSheet(
                onDismissRequest = { isSettingsSheetOpen = false },
                containerColor = SurfaceDark,
                dragHandle = {
                    Box(
                        modifier = Modifier
                            .padding(top = 10.dp, bottom = 6.dp)
                            .width(36.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(BorderSubtle)
                    )
                },
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Instrument & Chart Settings",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        IconButton(
                            onClick = { isSettingsSheetOpen = false },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Base / Quote & Tick Precision & Data Provider
                    AppCard(
                        modifier = Modifier.fillMaxWidth(),
                        variant = CardVariant.DEFAULT
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "BASE / QUOTE", fontSize = 10.sp, color = TextSecondary)
                                val base = state.selectedInstrument?.baseAsset ?: "-"
                                val quote = state.selectedInstrument?.quoteAsset ?: "-"
                                Text(text = "$base / $quote", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Column {
                                Text(text = "TICK PRECISION", fontSize = 10.sp, color = TextSecondary)
                                val tick = state.selectedInstrument?.tickSize?.toString() ?: "0.01"
                                Text(text = tick, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = BullGreen, fontFamily = FontFamily.Monospace)
                            }
                            Column {
                                Text(text = "MIN LOT", fontSize = 10.sp, color = TextSecondary)
                                val lot = state.selectedInstrument?.minLotSize?.toString() ?: "0.001"
                                Text(text = lot, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontFamily = FontFamily.Monospace)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "DATA PROVIDER", fontSize = 10.sp, color = TextSecondary)
                                Text(text = state.selectedInstrument?.providerName ?: "Standard Feed", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyanAccent)
                            }
                        }
                    }

                    // Chart Overlays & Controls (Safe defaults preserved)
                    AppCard(
                        modifier = Modifier.fillMaxWidth(),
                        variant = CardVariant.DEFAULT
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Layers,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CHART OVERLAYS & CONTROLS",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        AppToggle(
                            title = "Technical Indicators",
                            description = "EMA, Bollinger Bands, and MACD overlays.",
                            checked = state.showIndicators,
                            onCheckedChange = onToggleIndicators,
                            testTag = "toggle_indicators"
                        )

                        AppToggle(
                            title = "Volume Bar Profile",
                            description = "Real-time trading volume histogram.",
                            checked = state.showVolume,
                            onCheckedChange = onToggleVolume,
                            testTag = "toggle_volume"
                        )

                        AppToggle(
                            title = "Signal Plotting",
                            description = "Analytical signal arrows and markers.",
                            checked = state.showSignalPlotting,
                            onCheckedChange = onToggleSignals,
                            testTag = "toggle_signals"
                        )
                    }

                    // Paper Account Quick Testing
                    AppCard(
                        modifier = Modifier.fillMaxWidth(),
                        variant = CardVariant.DEFAULT
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "ACTIVE ACCOUNT", fontSize = 10.sp, color = TextSecondary)
                                Text(text = "Paper Account", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = CyanAccent)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "AVAILABLE BALANCE", fontSize = 10.sp, color = TextSecondary)
                                Text(
                                    text = "$${String.format("%,.2f", state.paperBalance)} USDT",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = BullGreen,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AppButton(
                                text = "BUY (Test $500)",
                                onClick = { onSimulatePaperTrade("BUY", 500.0) },
                                style = ButtonStyle.SUCCESS,
                                modifier = Modifier.weight(1f),
                                testTag = "btn_paper_buy"
                            )

                            AppButton(
                                text = "SELL (Test $500)",
                                onClick = { onSimulatePaperTrade("SELL", 500.0) },
                                style = ButtonStyle.DANGER,
                                modifier = Modifier.weight(1f),
                                testTag = "btn_paper_sell"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun CompactToolbarChip(
    label: String,
    isActive: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color? = null,
    testTag: String = ""
) {
    val activeBg by animateColorAsState(
        targetValue = if (isActive) CyanAccent.copy(alpha = 0.2f) else Color.Transparent,
        label = "bg"
    )
    val activeBorder by animateColorAsState(
        targetValue = if (isActive) CyanAccent else BorderSubtle,
        label = "border"
    )
    val contentColor = tint ?: if (isActive) CyanAccent else TextSecondary

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .clip(RoundedCornerShape(5.dp))
            .background(activeBg)
            .border(1.dp, activeBorder, RoundedCornerShape(5.dp))
            .clickable { onClick() }
            .padding(horizontal = 7.dp, vertical = 4.dp)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = contentColor,
            modifier = Modifier.size(13.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
            color = contentColor
        )
    }
}

