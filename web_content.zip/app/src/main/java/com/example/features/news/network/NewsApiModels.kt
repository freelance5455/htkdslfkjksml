package com.example.features.news.network

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class NewsApiRawResponse(
    val status: String? = null,
    val code: String? = null,
    val message: String? = null,
    val totalResults: Int? = null,
    val articles: List<NewsApiRawArticle>? = null
)

@JsonClass(generateAdapter = true)
data class NewsApiRawArticle(
    val source: NewsApiRawSource? = null,
    val author: String? = null,
    val title: String? = null,
    val description: String? = null,
    val url: String? = null,
    val urlToImage: String? = null,
    val publishedAt: String? = null,
    val content: String? = null
)

@JsonClass(generateAdapter = true)
data class NewsApiRawSource(
    val id: String? = null,
    val name: String? = null
)

sealed class NewsApiResult {
    data class Success(val articles: List<com.example.features.news.model.NewsArticle>) : NewsApiResult()
    data class Error(val message: String, val statusCode: Int? = null) : NewsApiResult()
    data class NetworkError(val message: String) : NewsApiResult()
}
