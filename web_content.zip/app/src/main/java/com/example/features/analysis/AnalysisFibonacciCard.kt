package com.example.features.analysis

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.analysis.FibonacciAnalysisResult
import com.example.core.model.analysis.FibonacciLevel
import com.example.core.model.indicator.IndicatorDirection
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.CardVariant
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber

/**
 * Visual presentation of Module #6 Fibonacci Retracement engine.
 * Displays Swing High/Low anchors, Golden Pocket (61.8%), all 7 key levels,
 * and current price location in retracement zone.
 */
@Composable
fun AnalysisFibonacciCard(
    fibonacci: FibonacciAnalysisResult,
    currentPrice: Double,
    modifier: Modifier = Modifier
) {
    val biasColor = when (fibonacci.contextBias) {
        IndicatorDirection.BULLISH -> BullGreen
        IndicatorDirection.BEARISH -> BearRed
        IndicatorDirection.NEUTRAL -> WarningAmber
    }

    AppCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("analysis_fibonacci_card"),
        variant = CardVariant.DEFAULT
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.SquareFoot,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "FIBONACCI RETRACEMENT",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(biasColor.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = if (fibonacci.isUptrendRetracement) "BULLISH RETRACEMENT" else "BEARISH RETRACEMENT",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = biasColor
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Swing Anchors and Current Zone
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(SurfaceDark)
                .padding(10.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Current Zone: ${fibonacci.currentZone}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanAccent
                    )
                    fibonacci.nearestLevel?.let { nearest ->
                        val priceFormatted = String.format(java.util.Locale.US, "$%.2f", nearest.price)
                        Text(
                            text = "Nearest: ${nearest.percentageLabel} ($priceFormatted)",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = fibonacci.explanation,
                    fontSize = 10.sp,
                    color = TextSecondary,
                    lineHeight = 14.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Anchor High: $%.2f".format(fibonacci.swingHigh),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = BearRed
                    )
                    Text(
                        text = "Anchor Low: $%.2f".format(fibonacci.swingLow),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = BullGreen
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 7 Key Fibonacci Retracement Levels
        Text(
            text = "RETRACEMENT LEVELS (0.0% TO 100.0%):",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = TextTertiary,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            fibonacci.levels.forEach { level ->
                FibonacciLevelRow(
                    level = level,
                    currentPrice = currentPrice
                )
            }
        }
    }
}

@Composable
private fun FibonacciLevelRow(
    level: FibonacciLevel,
    currentPrice: Double
) {
    val isGolden = level.isGoldenPocket
    val diff = currentPrice - level.price
    val diffPct = if (currentPrice > 0) (diff / currentPrice) * 100.0 else 0.0

    val rowBg = if (isGolden) WarningAmber.copy(alpha = 0.12f) else SurfaceDark
    val rowBorderColor = if (isGolden) WarningAmber.copy(alpha = 0.6f) else SurfaceElevated

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(rowBg)
            .border(if (isGolden) 1.dp else 0.5.dp, rowBorderColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = level.percentageLabel,
                    fontSize = 11.sp,
                    fontWeight = if (isGolden) FontWeight.Black else FontWeight.Bold,
                    color = if (isGolden) WarningAmber else CyanAccent
                )
                if (isGolden) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(WarningAmber.copy(alpha = 0.25f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "GOLDEN POCKET",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = WarningAmber
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                val priceFormatted = String.format(java.util.Locale.US, "$%.2f", level.price)
                val diffFormatted = String.format(java.util.Locale.US, "$%.2f", kotlin.math.abs(diff))
                val pctFormatted = String.format(java.util.Locale.US, "%.1f", diffPct)
                val sign = if (diff >= 0) "+" else "-"
                Text(
                    text = priceFormatted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$sign$diffFormatted ($pctFormatted%)",
                    fontSize = 9.sp,
                    color = if (diff >= 0) BullGreen else BearRed
                )
            }
        }
    }
}
