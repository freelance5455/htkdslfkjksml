package com.example.features.notifications

import android.util.Log
import com.example.core.network.whatsapp.WhatsAppCloudApiService
import com.example.core.network.whatsapp.WhatsAppSendResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Thread-safe Event Dispatcher and Deduplication Pipeline for Meta WhatsApp Cloud API.
 *
 * Requirements guaranteed:
 * 1. Dispatches real Meta WhatsApp Cloud API messages via WhatsAppCloudApiService
 * 2. Deduplicates repeated alerts within a configured cool-down window (e.g., 60 seconds)
 * 3. Never executes, modifies, or closes trades (strictly informational only)
 * 4. Never exposes or logs access tokens or secrets
 */
class WhatsAppNotificationDispatcher(
    private val apiService: WhatsAppCloudApiService = WhatsAppCloudApiService(),
    private val scope: CoroutineScope,
    private val isDeduplicatedChecker: ((eventKey: String, nowMs: Long, windowMs: Long) -> Boolean)? = null,
    private val recordEventSentAction: ((eventKey: String, timestamp: Long) -> Unit)? = null
) {
    companion object {
        private const val TAG = "WhatsAppDispatcher"
        const val DEDUP_WINDOW_MS = 60_000L // 60s duplicate suppression
    }

    // In-memory fallback cache: key -> last sent epoch timestamp
    private val sentEventTimestamps = ConcurrentHashMap<String, Long>()

    /**
     * Dispatch an informational notification to WhatsApp with persistent deduplication check.
     */
    fun dispatchNotification(
        category: WhatsAppNotificationCategory,
        eventKey: String,
        message: String,
        preferences: WhatsAppPreferences,
        recipientPhone: String?,
        apiKey: String?,
        phoneNumberId: String?,
        onDeliveryResult: ((WhatsAppSendResult) -> Unit)? = null
    ) {
        if (!preferences.isServiceEnabled) {
            return
        }

        // Check category toggle
        val isCategoryEnabled = when (category) {
            WhatsAppNotificationCategory.TRADE_SIGNAL -> preferences.notifyOnTradeSignal
            WhatsAppNotificationCategory.PRICE_ALERT -> preferences.notifyOnPriceAlert
            WhatsAppNotificationCategory.STOP_LOSS -> preferences.notifyOnStopLossTakeProfit
            WhatsAppNotificationCategory.TAKE_PROFIT -> preferences.notifyOnStopLossTakeProfit
            WhatsAppNotificationCategory.TRAILING_STOP -> preferences.notifyOnTrailingStop
            WhatsAppNotificationCategory.MANUAL_STOP -> preferences.notifyOnManualStop
            WhatsAppNotificationCategory.CONFIRMED_TRADE -> preferences.notifyOnConfirmedTrade
            WhatsAppNotificationCategory.NEWS_ALERT -> preferences.notifyOnNews
        }

        if (!isCategoryEnabled) {
            return
        }

        val phone = recipientPhone?.trim().orEmpty()
        val token = apiKey?.trim().orEmpty()
        val phoneId = phoneNumberId?.trim().orEmpty()

        if (phone.isBlank() || token.isBlank()) {
            return
        }

        val effectivePhoneId = if (phoneId.isNotBlank()) phoneId else "me"

        // Deduplication check: check persistent store first, then in-memory cache
        val now = System.currentTimeMillis()
        val persistentDedup = isDeduplicatedChecker?.invoke(eventKey, now, DEDUP_WINDOW_MS) ?: false
        val memoryLastSent = sentEventTimestamps[eventKey] ?: 0L
        if (persistentDedup || (now - memoryLastSent < DEDUP_WINDOW_MS)) {
            // Suppress duplicate alert
            return
        }

        sentEventTimestamps[eventKey] = now
        recordEventSentAction?.invoke(eventKey, now)
        cleanupOldDedupKeys(now)

        scope.launch(Dispatchers.IO) {
            try {
                val formattedMessage = formatWhatsAppMessage(category, message)
                val result = apiService.sendTextMessage(
                    phoneNumberId = effectivePhoneId,
                    accessToken = token,
                    recipientPhone = phone,
                    messageBody = formattedMessage
                )
                onDeliveryResult?.invoke(result)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to dispatch WhatsApp alert for $category: ${e.message}")
                onDeliveryResult?.invoke(WhatsAppSendResult.Failure("Dispatch error: ${e.message}"))
            }
        }
    }

    private fun cleanupOldDedupKeys(now: Long) {
        if (sentEventTimestamps.size > 200) {
            val iterator = sentEventTimestamps.entries.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                if (now - entry.value > DEDUP_WINDOW_MS * 2) {
                    iterator.remove()
                }
            }
        }
    }

    private fun formatWhatsAppMessage(category: WhatsAppNotificationCategory, body: String): String {
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val title = when (category) {
            WhatsAppNotificationCategory.TRADE_SIGNAL -> "🚨 [IQTrade Pro] Trade Signal"
            WhatsAppNotificationCategory.PRICE_ALERT -> "🔔 [IQTrade Pro] Price Alert"
            WhatsAppNotificationCategory.STOP_LOSS -> "🛡️ [IQTrade Pro] Stop Loss"
            WhatsAppNotificationCategory.TAKE_PROFIT -> "🎯 [IQTrade Pro] Take Profit"
            WhatsAppNotificationCategory.TRAILING_STOP -> "📈 [IQTrade Pro] Trailing Stop"
            WhatsAppNotificationCategory.MANUAL_STOP -> "🛑 [IQTrade Pro] Manual Stop"
            WhatsAppNotificationCategory.CONFIRMED_TRADE -> "💼 [IQTrade Pro] Trade Confirmed"
            WhatsAppNotificationCategory.NEWS_ALERT -> "📰 [IQTrade Pro] Market News Alert"
        }
        return "$title\nTime: $timeStr UTC\n\n$body\n\n*Notice: Informational notification only. No automated trade execution was triggered.*"
    }
}
