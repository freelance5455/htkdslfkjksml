package com.example.features.news.network

import com.example.features.news.analyzer.NewsSentimentAnalyzer
import com.example.features.news.model.NewsArticle
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

open class NewsApiGateway(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build(),
    private val baseUrl: String = "https://newsapi.org/v2/everything"
) {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val responseAdapter = moshi.adapter(NewsApiRawResponse::class.java)

    private val isoDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private val isoDateFormatWithMillis = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    open suspend fun fetchNews(
        apiKey: String,
        query: String = "crypto OR bitcoin OR forex OR gold OR \"federal reserve\" OR \"interest rate\"",
        pageSize: Int = 40
    ): NewsApiResult = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isBlank()) {
            return@withContext NewsApiResult.Error("API Key Required: Enter your News API key to stream live market feeds")
        }

        val urlBuilder = baseUrl.toHttpUrlOrNull()?.newBuilder()
            ?: return@withContext NewsApiResult.Error("Invalid News API endpoint URL: $baseUrl")

        urlBuilder.addQueryParameter("q", query)
        urlBuilder.addQueryParameter("language", "en")
        urlBuilder.addQueryParameter("sortBy", "publishedAt")
        urlBuilder.addQueryParameter("pageSize", pageSize.toString())
        urlBuilder.addQueryParameter("apiKey", trimmedKey)

        val request = Request.Builder()
            .url(urlBuilder.build())
            .header("User-Agent", "IQTradePro-Android/1.0")
            .get()
            .build()

        try {
            val response = client.newCall(request).execute()
            val code = response.code
            val bodyString = response.body?.string().orEmpty()

            when (code) {
                200 -> {
                    val raw = try {
                        responseAdapter.fromJson(bodyString)
                    } catch (e: Exception) {
                        return@withContext NewsApiResult.Error("JSON Parsing Error: ${e.message}")
                    }

                    if (raw == null || raw.status != "ok") {
                        val errMsg = raw?.message ?: "Unknown News API error"
                        return@withContext NewsApiResult.Error("News API Error: $errMsg", code)
                    }

                    val rawArticles = raw.articles.orEmpty()
                    val articles = rawArticles.mapIndexedNotNull { index, rawItem ->
                        val headline = rawItem.title?.trim().orEmpty()
                        if (headline.isBlank() || headline == "[Removed]") return@mapIndexedNotNull null

                        val publishedAt = parsePublishedAt(rawItem.publishedAt)
                        val id = rawItem.url?.hashCode()?.toString()
                            ?: "${headline.hashCode()}_${publishedAt}_$index"

                        NewsSentimentAnalyzer.analyze(
                            id = id,
                            headline = headline,
                            source = rawItem.source?.name?.trim().orEmpty().ifEmpty { "Financial Wire" },
                            publishedAt = publishedAt,
                            url = rawItem.url.orEmpty(),
                            urlToImage = rawItem.urlToImage,
                            description = rawItem.description
                        )
                    }.sortedByDescending { it.publishedAt }

                    NewsApiResult.Success(articles)
                }
                401 -> NewsApiResult.Error("Invalid API Key (HTTP 401): Please verify your News API key in Binance > News API", 401)
                403 -> NewsApiResult.Error("Access Forbidden (HTTP 403): Your News API plan does not allow this request", 403)
                429 -> NewsApiResult.Error("Rate Limit Exceeded (HTTP 429): Free tier limit reached. Please wait before refreshing", 429)
                500, 502, 503 -> NewsApiResult.Error("News API Service Unavailable (HTTP $code). Please try again shortly", code)
                else -> NewsApiResult.Error("News API request failed with HTTP status $code", code)
            }
        } catch (e: IOException) {
            NewsApiResult.NetworkError("Network Unreachable: ${e.message ?: "Check your internet connection"}")
        } catch (e: Exception) {
            NewsApiResult.Error("Unexpected error fetching news: ${e.message ?: "Unknown"}")
        }
    }

    private fun parsePublishedAt(rawDate: String?): Long {
        if (rawDate.isNullOrBlank()) return System.currentTimeMillis()
        return try {
            isoDateFormat.parse(rawDate)?.time
                ?: isoDateFormatWithMillis.parse(rawDate)?.time
                ?: System.currentTimeMillis()
        } catch (_: Exception) {
            System.currentTimeMillis()
        }
    }
}
