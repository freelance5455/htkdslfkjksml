package com.example.features.market

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.Instrument
import com.example.core.model.MarketCategory
import com.example.core.ui.components.AppButton
import com.example.core.ui.components.ButtonStyle
import com.example.core.ui.components.EmptyState
import com.example.ui.theme.BackgroundDark
import com.example.ui.theme.BearRed
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SymbolSearchSheet(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    selectedMarket: MarketCategory,
    onMarketSelected: (MarketCategory) -> Unit,
    selectedSymbolId: String,
    symbols: List<Instrument>,
    searchQuery: String,
    onSearchQueryChanged: (String) -> Unit,
    selectedQuoteFilter: String?,
    onQuoteFilterSelected: (String?) -> Unit,
    onInstrumentSelected: (Instrument) -> Unit,
    onRefresh: () -> Unit,
    isLoading: Boolean,
    isStale: Boolean,
    lastUpdateTimestamp: Long?,
    errorMessage: String?,
    modifier: Modifier = Modifier,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
    if (!isOpen) return

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = BackgroundDark,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .size(width = 36.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(BorderSubtle)
            )
        },
        modifier = modifier.testTag("symbol_search_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header: Title & Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SELECT INSTRUMENT",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "${selectedMarket.displayName} Market • ${symbols.size} available",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("btn_close_symbol_picker")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Market Switcher: Crypto ↔ Forex ↔ Gold
            MarketSwitcher(
                selectedMarket = selectedMarket,
                onMarketSelected = {
                    onMarketSelected(it)
                    onQuoteFilterSelected(null)
                }
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Fast Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChanged,
                placeholder = {
                    Text(
                        text = "Search symbol, asset (e.g. BTC, EUR, XAU)...",
                        fontSize = 13.sp,
                        color = TextDisabled
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = CyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChanged("") }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear",
                                tint = TextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanAccent,
                    unfocusedBorderColor = BorderSubtle,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("symbol_search_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Quote asset filter chips based on market
            val quoteFilters = when (selectedMarket) {
                MarketCategory.CRYPTO -> listOf("ALL", "USDT", "BTC")
                MarketCategory.FOREX -> listOf("ALL", "USD", "EUR", "JPY", "GBP")
                MarketCategory.GOLD -> listOf("ALL", "USD", "EUR", "JPY", "Bullion")
            }

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(quoteFilters) { filter ->
                    val isAll = filter == "ALL"
                    val isSelected = if (isAll) selectedQuoteFilter == null else selectedQuoteFilter.equals(filter, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .heightIn(min = 36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color(0xFF00384D) else SurfaceDark)
                            .border(1.dp, if (isSelected) CyanAccent else BorderSubtle, RoundedCornerShape(8.dp))
                            .clickable {
                                onQuoteFilterSelected(if (isAll) null else filter)
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = filter,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) CyanAccent else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Cache / Stale / Loading status banner
            if (isStale || isLoading || errorMessage != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (errorMessage != null) Color(0x22F6465D) else Color(0x22F0B90B))
                        .border(
                            1.dp,
                            if (errorMessage != null) BearRed.copy(alpha = 0.5f) else WarningAmber.copy(alpha = 0.5f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (errorMessage != null) Icons.Default.CloudOff else Icons.Default.Refresh,
                            contentDescription = null,
                            tint = if (errorMessage != null) BearRed else WarningAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        val statusText = when {
                            errorMessage != null -> "Provider Offline: $errorMessage"
                            isStale && lastUpdateTimestamp != null -> {
                                val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(lastUpdateTimestamp))
                                "Using Local Cache (Synced $timeStr)"
                            }
                            isStale -> "Using Local Cached Metadata"
                            else -> "Syncing Symbol Universe..."
                        }
                        Text(
                            text = statusText,
                            fontSize = 11.sp,
                            color = if (errorMessage != null) BearRed else WarningAmber
                        )
                    }

                    if (isLoading) {
                        CircularProgressIndicator(
                            color = CyanAccent,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        IconButton(
                            onClick = onRefresh,
                            modifier = Modifier
                                .size(24.dp)
                                .testTag("symbol_refresh_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = CyanAccent,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Symbol List / Empty State / Error State
            Box(modifier = Modifier.fillMaxSize()) {
                if (symbols.isEmpty()) {
                    if (errorMessage != null && !isLoading) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudOff,
                                contentDescription = null,
                                tint = BearRed,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Symbol Provider Unavailable",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = errorMessage,
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            AppButton(
                                text = "Retry Fetching Symbols",
                                onClick = onRefresh,
                                style = ButtonStyle.PRIMARY,
                                testTag = "symbol_error_retry"
                            )
                        }
                    } else {
                        EmptyState(
                            title = "No Instruments Found",
                            description = if (searchQuery.isNotBlank()) "No instruments match \"$searchQuery\" in ${selectedMarket.displayName}" else "No symbols available for this market",
                            icon = Icons.Default.SearchOff,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(symbols, key = { "${it.marketCategory.id}_${it.symbolId}" }) { instrument ->
                            val isCurrentSelected = instrument.symbolId.equals(selectedSymbolId, ignoreCase = true)
                            SymbolItemRow(
                                instrument = instrument,
                                isSelected = isCurrentSelected,
                                onClick = {
                                    onInstrumentSelected(instrument)
                                    onDismiss()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SymbolItemRow(
    instrument: Instrument,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) Color(0xFF071B2B) else SurfaceDark)
            .border(
                1.dp,
                if (isSelected) CyanAccent.copy(alpha = 0.8f) else BorderSubtle,
                RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("symbol_item_${instrument.symbolId}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Symbol Name + Base/Quote
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = instrument.displayName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) CyanAccent else TextPrimary,
                        letterSpacing = 0.2.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SurfaceElevated)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${instrument.baseAsset}/${instrument.quoteAsset}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextSecondary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = instrument.description.ifEmpty { "${instrument.baseAsset} on ${instrument.providerName}" },
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            // Right: Provider Info & Precision / Checkmark
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = instrument.providerName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondary
                    )
                    Text(
                        text = "Tick: ${instrument.tickSize}",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextDisabled
                    )
                }

                if (isSelected) {
                    Spacer(modifier = Modifier.width(10.dp))
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(CyanAccent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = Color(0xFF070B12),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
