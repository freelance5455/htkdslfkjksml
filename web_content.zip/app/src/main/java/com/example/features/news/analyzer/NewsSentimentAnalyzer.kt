package com.example.features.news.analyzer

import com.example.core.model.MarketCategory
import com.example.features.news.model.NewsArticle
import com.example.features.news.model.NewsImpact
import com.example.features.news.model.NewsSentiment
import java.util.Locale

/**
 * Deterministic Financial NLP & Sentiment Analysis Engine.
 * Analyzes real financial headlines and descriptions to extract:
 * 1. Market Category (Crypto, Forex, Gold)
 * 2. Relevant Symbols (e.g. BTC, ETH, SOL, EUR/USD, XAU/USD)
 * 3. Sentiment Classification (BULLISH, BEARISH, NEUTRAL)
 * 4. Sentiment Score (0-100) & Confidence Percentage (50-95%)
 * 5. Impact Level (HIGH, MEDIUM, LOW) & Breaking News status
 */
object NewsSentimentAnalyzer {

    private val BULLISH_KEYWORDS = setOf(
        "surge", "surges", "surging", "surged",
        "soar", "soars", "soaring", "soared",
        "rally", "rallies", "rallying", "rallied",
        "breakout", "breakouts", "all-time high", "record high", "ath",
        "gain", "gains", "gaining", "gained",
        "inflow", "inflows", "adoption", "adopted",
        "approved", "approval", "approves", "greenlight",
        "bull", "bullish", "rate cut", "rate cuts",
        "dovish", "liquidity injection", "stimulus",
        "expansion", "expanding", "profit", "profits",
        "outperform", "outperforming", "upgrade", "upgraded",
        "accumulation", "accumulating", "reserve asset",
        "rebound", "rebounds", "rebounding", "optimism"
    )

    private val BEARISH_KEYWORDS = setOf(
        "crash", "crashes", "crashing", "crashed",
        "plunge", "plunges", "plunging", "plunged",
        "dump", "dumps", "dumping", "dumped",
        "drop", "drops", "dropping", "dropped",
        "slump", "slumps", "slumping", "slumped",
        "fall", "falls", "falling", "fell",
        "decline", "declines", "declining", "declined",
        "ban", "banned", "banning", "bans",
        "lawsuit", "sues", "sued", "suing",
        "sec charges", "charges", "indictment", "probe", "investigation",
        "hack", "hacked", "hacking", "exploit", "exploited",
        "liquidation", "liquidations", "liquidated",
        "outflow", "outflows", "selloff", "sell-off",
        "bear", "bearish", "rate hike", "rate hikes",
        "hawkish", "inflation spike", "recession", "recessionary",
        "war", "conflict", "sanction", "sanctions",
        "default", "defaults", "insolvent", "insolvency", "bankruptcy",
        "fraud", "collapse", "collapsed", "fear", "panic"
    )

    private val HIGH_IMPACT_KEYWORDS = setOf(
        "breaking", "emergency", "fomc", "federal reserve", "interest rate",
        "cpi", "inflation", "sec approval", "etf approval", "black swan",
        "war", "geopolitical", "flash crash", "rate cut", "rate hike",
        "crisis", "bank run", "default", "sanctions", "ecb", "powell"
    )

    private val CRYPTO_KEYWORDS = listOf(
        "crypto", "cryptocurrency", "bitcoin", "btc", "ethereum", "eth",
        "solana", "sol", "binance", "bnb", "altcoin", "altcoins",
        "blockchain", "defi", "web3", "tether", "usdt", "ripple", "xrp",
        "doge", "cardano", "ada", "coinbase"
    )

    private val FOREX_KEYWORDS = listOf(
        "forex", "fx", "currency", "currencies", "dollar", "usd", "dxy",
        "euro", "eur", "pound", "gbp", "yen", "jpy", "central bank",
        "federal reserve", "fed", "fomc", "ecb", "boj", "interest rate",
        "treasury", "yield", "cpi", "inflation"
    )

    private val GOLD_KEYWORDS = listOf(
        "gold", "xau", "xau/usd", "xauusd", "bullion", "precious metal",
        "precious metals", "silver", "xag", "safe haven"
    )

    fun analyze(
        id: String,
        headline: String,
        source: String,
        publishedAt: Long,
        url: String,
        urlToImage: String? = null,
        description: String? = null
    ): NewsArticle {
        val combinedText = "$headline ${description.orEmpty()}".lowercase(Locale.ROOT)

        // 1. Detect Market Category
        val marketCategory = detectMarketCategory(combinedText)

        // 2. Detect Relevant Symbols
        val symbols = detectRelevantSymbols(combinedText, marketCategory)

        // 3. Calculate Sentiment & Confidence
        val (sentiment, score, confidence) = calculateSentiment(combinedText)

        // 4. Calculate Impact & Breaking News Flag
        val (impact, isBreaking) = calculateImpact(combinedText, publishedAt)

        return NewsArticle(
            id = id,
            headline = headline.trim(),
            source = source.trim().ifEmpty { "Financial News" },
            publishedAt = publishedAt,
            url = url,
            urlToImage = urlToImage,
            description = description?.trim(),
            marketCategory = marketCategory,
            relevantSymbols = symbols,
            sentiment = sentiment,
            sentimentScore = score,
            sentimentConfidence = confidence,
            impact = impact,
            isBreaking = isBreaking,
            cachedAt = System.currentTimeMillis()
        )
    }

    private fun detectMarketCategory(text: String): MarketCategory {
        var cryptoScore = 0
        var forexScore = 0
        var goldScore = 0

        for (kw in GOLD_KEYWORDS) {
            if (containsWordOrPhrase(text, kw)) goldScore += 2
        }
        for (kw in CRYPTO_KEYWORDS) {
            if (containsWordOrPhrase(text, kw)) cryptoScore++
        }
        for (kw in FOREX_KEYWORDS) {
            if (containsWordOrPhrase(text, kw)) forexScore++
        }

        return when {
            goldScore > 0 && goldScore >= cryptoScore && goldScore >= forexScore -> MarketCategory.GOLD
            cryptoScore >= forexScore && cryptoScore > 0 -> MarketCategory.CRYPTO
            forexScore > 0 -> MarketCategory.FOREX
            else -> MarketCategory.CRYPTO // Default fallback
        }
    }

    private fun detectRelevantSymbols(text: String, market: MarketCategory): List<String> {
        val symbols = mutableSetOf<String>()

        // Crypto symbol mappings
        if (market == MarketCategory.CRYPTO || containsWordOrPhrase(text, "crypto")) {
            if (containsWordOrPhrase(text, "bitcoin") || containsWordOrPhrase(text, "btc")) {
                symbols.add("BTC")
                symbols.add("BTCUSDT")
            }
            if (containsWordOrPhrase(text, "ethereum") || containsWordOrPhrase(text, "eth")) {
                symbols.add("ETH")
                symbols.add("ETHUSDT")
            }
            if (containsWordOrPhrase(text, "solana") || containsWordOrPhrase(text, "sol")) {
                symbols.add("SOL")
                symbols.add("SOLUSDT")
            }
            if (containsWordOrPhrase(text, "binance") || containsWordOrPhrase(text, "bnb")) {
                symbols.add("BNB")
                symbols.add("BNBUSDT")
            }
            if (containsWordOrPhrase(text, "ripple") || containsWordOrPhrase(text, "xrp")) {
                symbols.add("XRP")
                symbols.add("XRPUSDT")
            }
            if (containsWordOrPhrase(text, "cardano") || containsWordOrPhrase(text, "ada")) {
                symbols.add("ADA")
                symbols.add("ADAUSDT")
            }
            if (containsWordOrPhrase(text, "doge") || containsWordOrPhrase(text, "dogecoin")) {
                symbols.add("DOGE")
                symbols.add("DOGEUSDT")
            }
        }

        // Forex symbol mappings
        if (market == MarketCategory.FOREX || containsWordOrPhrase(text, "forex") || containsWordOrPhrase(text, "currency")) {
            if (containsWordOrPhrase(text, "eur/usd") || containsWordOrPhrase(text, "eurusd") || (containsWordOrPhrase(text, "euro") && containsWordOrPhrase(text, "dollar"))) {
                symbols.add("EUR/USD")
                symbols.add("EURUSD")
            }
            if (containsWordOrPhrase(text, "gbp/usd") || containsWordOrPhrase(text, "gbpusd") || (containsWordOrPhrase(text, "pound") && containsWordOrPhrase(text, "dollar"))) {
                symbols.add("GBP/USD")
                symbols.add("GBPUSD")
            }
            if (containsWordOrPhrase(text, "usd/jpy") || containsWordOrPhrase(text, "usdjpy") || (containsWordOrPhrase(text, "yen") && containsWordOrPhrase(text, "dollar"))) {
                symbols.add("USD/JPY")
                symbols.add("USDJPY")
            }
            if (containsWordOrPhrase(text, "aud/usd") || containsWordOrPhrase(text, "audusd")) {
                symbols.add("AUD/USD")
                symbols.add("AUDUSD")
            }
        }

        // Gold symbol mappings
        if (market == MarketCategory.GOLD || containsWordOrPhrase(text, "gold") || containsWordOrPhrase(text, "xau")) {
            symbols.add("XAU/USD")
            symbols.add("XAUUSD")
            symbols.add("GOLD")
        }

        return symbols.toList()
    }

    private fun calculateSentiment(text: String): Triple<NewsSentiment, Int, Int> {
        var bullHits = 0
        var bearHits = 0

        for (bull in BULLISH_KEYWORDS) {
            if (containsWordOrPhrase(text, bull)) bullHits++
        }
        for (bear in BEARISH_KEYWORDS) {
            if (containsWordOrPhrase(text, bear)) bearHits++
        }

        val totalHits = bullHits + bearHits
        if (totalHits == 0) {
            return Triple(NewsSentiment.NEUTRAL, 50, 70)
        }

        val diff = bullHits - bearHits
        return when {
            diff > 0 -> {
                val score = (50 + (diff * 12)).coerceAtMost(95)
                val confidence = (60 + (bullHits * 10)).coerceIn(65, 95)
                Triple(NewsSentiment.BULLISH, score, confidence)
            }
            diff < 0 -> {
                val score = (50 - (-diff * 12)).coerceAtLeast(5)
                val confidence = (60 + (bearHits * 10)).coerceIn(65, 95)
                Triple(NewsSentiment.BEARISH, score, confidence)
            }
            else -> {
                Triple(NewsSentiment.NEUTRAL, 50, 70)
            }
        }
    }

    private fun calculateImpact(text: String, publishedAt: Long): Pair<NewsImpact, Boolean> {
        var highHits = 0
        for (hk in HIGH_IMPACT_KEYWORDS) {
            if (containsWordOrPhrase(text, hk)) highHits++
        }

        val isHigh = highHits > 0
        val impact = when {
            isHigh -> NewsImpact.HIGH
            text.length > 250 -> NewsImpact.MEDIUM
            else -> NewsImpact.LOW
        }

        // Breaking news criteria: high impact keyword and published within last 4 hours
        val fourHoursMs = 4 * 60 * 60 * 1000L
        val isRecent = (System.currentTimeMillis() - publishedAt) in 0..fourHoursMs
        val isBreaking = isHigh && isRecent

        return Pair(impact, isBreaking)
    }

    private fun containsWordOrPhrase(source: String, target: String): Boolean {
        if (!source.contains(target)) return false
        val regex = Regex("(?:^|[^a-zA-Z0-9/])${Regex.escape(target)}(?:$|[^a-zA-Z0-9/])")
        return regex.containsMatchIn(source)
    }
}
