package com.example.features.notifications

/**
 * Event notification categories for WhatsApp dispatches.
 */
enum class WhatsAppNotificationCategory {
    TRADE_SIGNAL,
    PRICE_ALERT,
    STOP_LOSS,
    TAKE_PROFIT,
    TRAILING_STOP,
    MANUAL_STOP,
    CONFIRMED_TRADE,
    NEWS_ALERT
}

/**
 * Persistent preferences for WhatsApp notification toggles.
 */
data class WhatsAppPreferences(
    val isServiceEnabled: Boolean = false,
    val notifyOnTradeSignal: Boolean = true,
    val notifyOnPriceAlert: Boolean = true,
    val notifyOnStopLossTakeProfit: Boolean = true,
    val notifyOnTrailingStop: Boolean = true,
    val notifyOnManualStop: Boolean = true,
    val notifyOnConfirmedTrade: Boolean = true,
    val notifyOnNews: Boolean = true
)
