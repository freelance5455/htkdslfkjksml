package com.example.features.analysis

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CandlestickChart
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.analysis.CandlestickAnalysisResult
import com.example.core.model.analysis.CandlestickPatternMatch
import com.example.core.model.analysis.CandlestickPatternType
import com.example.core.model.indicator.IndicatorDirection
import com.example.core.ui.components.AppCard
import com.example.core.ui.components.CardVariant
import com.example.ui.theme.BearRed
import com.example.ui.theme.BullGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDisabled
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Visual presentation of Module #6 Candlestick Pattern Recognition engine.
 * Displays detected matches among the 17 standard patterns, dominant pattern,
 * and pattern classification.
 */
@Composable
fun AnalysisCandlestickCard(
    result: CandlestickAnalysisResult,
    modifier: Modifier = Modifier
) {
    AppCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("analysis_candlestick_card"),
        variant = CardVariant.DEFAULT
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CandlestickChart,
                    contentDescription = null,
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CANDLESTICK PATTERNS (17 SUITE)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            val biasColor = when (result.overallBias) {
                IndicatorDirection.BULLISH -> BullGreen
                IndicatorDirection.BEARISH -> BearRed
                IndicatorDirection.NEUTRAL -> WarningAmber
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(biasColor.copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = result.overallBias.name,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = biasColor
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Dominant Pattern Highlight
        val dominant = result.dominantPattern
        if (dominant != null) {
            val domColor = when (dominant.classification) {
                IndicatorDirection.BULLISH -> BullGreen
                IndicatorDirection.BEARISH -> BearRed
                IndicatorDirection.NEUTRAL -> WarningAmber
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(domColor.copy(alpha = 0.12f))
                    .border(1.dp, domColor, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = domColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "DOMINANT: ${dominant.name.uppercase()}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = domColor
                            )
                        }

                        Text(
                            text = "${dominant.confidencePct}% CONFIDENCE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = domColor
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = dominant.description,
                        fontSize = 11.sp,
                        color = TextPrimary,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Strength: ${dominant.strength}",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = "Timeframe: ${dominant.timeframe}",
                            fontSize = 10.sp,
                            color = CyanAccent
                        )
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfaceDark)
                    .padding(12.dp)
            ) {
                Text(
                    text = result.summaryText,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Pattern Matches List
        if (result.detectedPatterns.isNotEmpty()) {
            Text(
                text = "DETECTED PATTERNS (${result.detectedPatterns.size})",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TextTertiary,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                result.detectedPatterns.forEach { match ->
                    PatternMatchRow(match)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 17 Supported Patterns Reference Chips
        Text(
            text = "ALL 17 SUPPORTED PATTERNS:",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = TextTertiary,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        val patterns = CandlestickPatternType.values()
        val chunked = patterns.toList().chunked(3)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(SurfaceDark)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            chunked.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    row.forEach { type ->
                        val isDetected = result.detectedPatterns.any { it.patternType == type }
                        val textColor = if (isDetected) CyanAccent else TextDisabled
                        Text(
                            text = "• ${type.displayName}",
                            fontSize = 9.sp,
                            fontWeight = if (isDetected) FontWeight.Bold else FontWeight.Normal,
                            color = textColor,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (row.size < 3) {
                        repeat(3 - row.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PatternMatchRow(match: CandlestickPatternMatch) {
    val dirColor = when (match.classification) {
        IndicatorDirection.BULLISH -> BullGreen
        IndicatorDirection.BEARISH -> BearRed
        IndicatorDirection.NEUTRAL -> WarningAmber
    }

    val timeStr = remember(match.detectionTimestamp) {
        if (match.detectionTimestamp > 0) {
            SimpleDateFormat("HH:mm:ss", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }.format(Date(match.detectionTimestamp))
        } else "--:--"
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(SurfaceDark)
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(dirColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = match.classification.name,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = dirColor
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = match.name,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Text(
                    text = "${match.confidencePct}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = dirColor
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = match.description,
                fontSize = 10.sp,
                color = TextSecondary,
                lineHeight = 14.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Strength: ${match.strength}",
                    fontSize = 9.sp,
                    color = TextTertiary
                )
                Text(
                    text = "Detected at $timeStr UTC",
                    fontSize = 9.sp,
                    color = TextTertiary
                )
            }
        }
    }
}
