package com.example.features.portfolio

import com.example.core.data.local.entity.TradeRecordEntity
import kotlin.math.abs

/**
 * Portfolio and Trade History Performance Statistics (Module #10).
 * Strictly calculated per mode (Paper vs Live) with zero cross-contamination.
 */
data class PortfolioStatistics(
    val totalTrades: Int = 0,
    val openTradesCount: Int = 0,
    val closedTradesCount: Int = 0,
    val winningTrades: Int = 0,
    val losingTrades: Int = 0,
    val breakEvenTrades: Int = 0,
    val winRatePct: Double = 0.0,
    val totalGrossProfit: Double = 0.0,
    val totalGrossLoss: Double = 0.0,
    val netPnl: Double = 0.0,
    val totalFees: Double = 0.0,
    val averageWinningTrade: Double = 0.0,
    val averageLosingTrade: Double = 0.0,
    val largestWinningTrade: Double = 0.0,
    val largestLosingTrade: Double = 0.0,
    val averageDurationMillis: Long = 0L,
    val profitFactor: Double = 0.0
) {
    val averageDurationFormatted: String
        get() {
            if (averageDurationMillis <= 0L) return "—"
            val totalSeconds = averageDurationMillis / 1000
            val minutes = totalSeconds / 60
            val hours = minutes / 60
            val days = hours / 24
            return when {
                days > 0 -> "${days}d ${hours % 24}h"
                hours > 0 -> "${hours}h ${minutes % 60}m"
                minutes > 0 -> "${minutes}m ${totalSeconds % 60}s"
                else -> "${totalSeconds}s"
            }
        }
}

/**
 * Calculates comprehensive portfolio performance statistics for a given set of trades.
 */
fun calculatePortfolioStatistics(trades: List<TradeRecordEntity>): PortfolioStatistics {
    val totalTrades = trades.size
    val openTrades = trades.filter { it.isOpen }
    val closedTrades = trades.filter { !it.isOpen }
    val closedWithPnl = closedTrades.filter { it.realizedPnl != null }

    val winningTrades = closedWithPnl.filter { (it.realizedPnl ?: 0.0) > 0.0 }
    val losingTrades = closedWithPnl.filter { (it.realizedPnl ?: 0.0) < 0.0 }
    val breakEvenTrades = closedWithPnl.filter { (it.realizedPnl ?: 0.0) == 0.0 }

    val totalGrossProfit = winningTrades.sumOf { it.realizedPnl ?: 0.0 }
    val totalGrossLoss = losingTrades.sumOf { abs(it.realizedPnl ?: 0.0) }
    val totalFees = trades.sumOf { it.commission ?: 0.0 }
    val grossPnl = closedTrades.sumOf { it.realizedPnl ?: 0.0 }
    val netPnl = grossPnl - totalFees

    val winRatePct = if (closedWithPnl.isNotEmpty()) {
        (winningTrades.size.toDouble() / closedWithPnl.size.toDouble()) * 100.0
    } else 0.0

    val averageWinningTrade = if (winningTrades.isNotEmpty()) {
        totalGrossProfit / winningTrades.size.toDouble()
    } else 0.0

    val averageLosingTrade = if (losingTrades.isNotEmpty()) {
        totalGrossLoss / losingTrades.size.toDouble()
    } else 0.0

    val largestWinningTrade = winningTrades.maxOfOrNull { it.realizedPnl ?: 0.0 } ?: 0.0
    val largestLosingTrade = losingTrades.minOfOrNull { it.realizedPnl ?: 0.0 } ?: 0.0

    val profitFactor = if (totalGrossLoss > 0.0) {
        totalGrossProfit / totalGrossLoss
    } else if (totalGrossProfit > 0.0) 99.9 else 0.0

    val closedWithDurations = closedTrades.mapNotNull { trade ->
        val closeT = trade.closeTimestamp ?: trade.updatedTimestamp
        if (closeT != null && closeT >= trade.timestamp) {
            closeT - trade.timestamp
        } else null
    }

    val averageDurationMillis = if (closedWithDurations.isNotEmpty()) {
        closedWithDurations.average().toLong()
    } else 0L

    return PortfolioStatistics(
        totalTrades = totalTrades,
        openTradesCount = openTrades.size,
        closedTradesCount = closedTrades.size,
        winningTrades = winningTrades.size,
        losingTrades = losingTrades.size,
        breakEvenTrades = breakEvenTrades.size,
        winRatePct = winRatePct,
        totalGrossProfit = totalGrossProfit,
        totalGrossLoss = totalGrossLoss,
        netPnl = netPnl,
        totalFees = totalFees,
        averageWinningTrade = averageWinningTrade,
        averageLosingTrade = averageLosingTrade,
        largestWinningTrade = largestWinningTrade,
        largestLosingTrade = largestLosingTrade,
        averageDurationMillis = averageDurationMillis,
        profitFactor = profitFactor
    )
}
