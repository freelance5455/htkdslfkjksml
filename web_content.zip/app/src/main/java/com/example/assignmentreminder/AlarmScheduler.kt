package com.example.assignmentreminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

object AlarmScheduler {
    private const val EXTRA_ID = "id"
    private const val EXTRA_SUBJECT = "subject"
    private const val EXTRA_TASK = "task"

    fun schedule(context: Context, id: String, subject: String, task: String, date: String, time: String) {
        try {
            val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
            format.timeZone = TimeZone.getDefault()
            val millis = format.parse("$date $time")?.time ?: return

            if (millis <= System.currentTimeMillis()) return

            val intent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra(EXTRA_ID, id)
                putExtra(EXTRA_SUBJECT, subject)
                putExtra(EXTRA_TASK, task)
            }

            val requestCode = stableRequestCode(id)
            val pending = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val alarmManager = context.getSystemService(AlarmManager::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 31 && !alarmManager.canScheduleExactAlarms()) {
                return
            }
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                millis,
                pending
            )
        } catch (_: Exception) {
        }
    }

    fun cancel(context: Context, id: String) {
        val intent = Intent(context, AlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context,
            stableRequestCode(id),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pending != null) {
            context.getSystemService(AlarmManager::class.java).cancel(pending)
            pending.cancel()
        }
    }

    private fun stableRequestCode(id: String): Int {
        return id.hashCode() and 0x7fffffff
    }
}
