package com.example.assignmentreminder

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        createNotificationChannels()
        requestNotificationPermission()
        requestExactAlarmPermissionIfNeeded()

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidAlarmBridge(this), "AndroidAlarm")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < 26) return

        val alarmChannel = NotificationChannel(
            AlarmChannels.ALARM_ID,
            "Assignment alarm",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Sound and vibration for assignment reminders"
            val soundUri = android.net.Uri.parse("android.resource://$packageName/${R.raw.reminder}")
            val audioAttributes = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            setSound(soundUri, audioAttributes)
            enableVibration(true)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        }

        getSystemService(NotificationManager::class.java).createNotificationChannel(alarmChannel)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    private fun requestExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val alarmManager = getSystemService(AlarmManager::class.java)
            if (!alarmManager.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            }
        }
    }
}

object AlarmChannels {
    // New ID ensures Android does not reuse an old channel's saved sound settings.
    const val ALARM_ID = "assignment_alarm_v2"
}

class AndroidAlarmBridge(private val context: Context) {
    @JavascriptInterface
    fun scheduleAlarm(id: String, subject: String, taskName: String, date: String, time: String) {
        AlarmScheduler.schedule(context, id, subject, taskName, date, time)
    }

    @JavascriptInterface
    fun cancelAlarm(id: String) {
        AlarmScheduler.cancel(context, id)
    }
}
