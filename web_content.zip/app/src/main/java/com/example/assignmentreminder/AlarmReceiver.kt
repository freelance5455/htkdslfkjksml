package com.example.assignmentreminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val serviceIntent = Intent(context, AlarmService::class.java).apply {
            action = AlarmService.ACTION_START
            putExtra("subject", intent.getStringExtra("subject") ?: "Assignment")
            putExtra("task", intent.getStringExtra("task") ?: "Reminder")
        }
        try {
            ContextCompat.startForegroundService(context, serviceIntent)
        } catch (_: Exception) {
            // If the foreground service cannot start, the receiver exits safely.
        }
    }
}
