package com.example.assignmentreminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONArray

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        val prefs = context.getSharedPreferences("assignment_reminders", Context.MODE_PRIVATE)
        val raw = prefs.getString("pending_alarms", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                AlarmScheduler.schedule(
                    context,
                    o.getString("id"),
                    o.getString("subject"),
                    o.getString("task"),
                    o.getString("date"),
                    o.getString("time")
                )
            }
        } catch (_: Exception) {}
    }
}
