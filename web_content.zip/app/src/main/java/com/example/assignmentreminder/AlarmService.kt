package com.example.assignmentreminder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class AlarmService : Service() {
    companion object {
        const val ACTION_START = "com.example.assignmentreminder.START_ALARM"
        const val ACTION_STOP = "com.example.assignmentreminder.STOP_ALARM"
        const val CHANNEL_ID = "alarm_playback_v2"
        private const val NOTIFICATION_ID = 9001
    }

    private var player: MediaPlayer? = null
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null

    override fun onCreate() {
        super.onCreate()
        createServiceChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAlarm()
            stopSelf()
            return START_NOT_STICKY
        }

        val subject = intent?.getStringExtra("subject") ?: "Assignment"
        val task = intent?.getStringExtra("task") ?: "Reminder"

        startForeground(NOTIFICATION_ID, buildNotification(subject, task))
        startSound()
        return START_NOT_STICKY
    }

    private fun startSound() {
        stopPlayerOnly()
        try {
            audioManager = getSystemService(AudioManager::class.java)
            requestAudioFocus()

            val uri = android.net.Uri.parse("android.resource://$packageName/${R.raw.reminder}")
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                setVolume(1.0f, 1.0f)
                prepare()
                start()
            }
        } catch (_: Exception) {
            // Notification remains visible even if direct playback fails.
        }
    }

    private fun requestAudioFocus() {
        val manager = audioManager ?: return
        val listener = AudioManager.OnAudioFocusChangeListener { }
        if (Build.VERSION.SDK_INT >= 26) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setOnAudioFocusChangeListener(listener)
                .build()
            audioFocusRequest = request
            manager.requestAudioFocus(request)
        } else {
            @Suppress("DEPRECATION")
            manager.requestAudioFocus(listener, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
        }
    }

    private fun stopPlayerOnly() {
        try {
            player?.stop()
            player?.release()
        } catch (_: Exception) { }
        player = null
    }

    private fun stopAlarm() {
        stopPlayerOnly()
        val manager = audioManager
        val request = audioFocusRequest
        if (Build.VERSION.SDK_INT >= 26 && manager != null && request != null) {
            manager.abandonAudioFocusRequest(request)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun createServiceChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Active assignment alarm",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows while an assignment alarm is playing"
                setSound(null, null)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(subject: String, task: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, AlarmService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Assignment reminder")
            .setContentText("$subject: $task")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_media_pause, "Stop alarm", stopPending)
            .build()
    }

    override fun onDestroy() {
        stopAlarm()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
