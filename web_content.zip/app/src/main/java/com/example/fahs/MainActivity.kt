package com.example.fahs

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    // Native barcode scanner: returns the decoded barcode text
    private val barcodeLauncher = registerForActivityResult(ScanContract()) { result ->
        val code = result.contents
        if (!code.isNullOrBlank()) {
            val digits = code.filter { it.isDigit() }
            webView.post {
                webView.evaluateJavascript("window.onBarcodeScanned && window.onBarcodeScanned('$digits');", null)
            }
        }
    }

    // Exposed to JavaScript as window.Android
    inner class ScanBridge {
        @JavascriptInterface
        fun scan() {
            runOnUiThread {
                val options = ScanOptions()
                    .setDesiredBarcodeFormats(
                        ScanOptions.EAN_13, ScanOptions.EAN_8,
                        ScanOptions.UPC_A, ScanOptions.UPC_E
                    )
                    .setPrompt("وجّه الكاميرا نحو الباركود")
                    .setBeepEnabled(true)
                    .setOrientationLocked(false)
                barcodeLauncher.launch(options)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(ScanBridge(), "Android")
        }
        setContentView(webView)

        // App bundled in assets; product lookup uses the internet (Open Food Facts)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
