package com.example.quizofppt;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.SharedPreferences;
import android.util.Base64;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;

import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {

    private WebView webView;
    private ValueCallback<android.net.Uri[]> filePathCallback;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new OpenAIBridge(), "OpenAI");
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);

        final WebViewAssetLoader assetLoader =
                new WebViewAssetLoader.Builder()
                        .addPathHandler("/web/",
                                new WebViewAssetLoader.AssetsPathHandler(this))
                        .build();

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<android.net.Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, 1001); }
                catch (Exception e) { filePathCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public WebResourceResponse shouldInterceptRequest(
                    WebView view, String url) {
                return assetLoader.shouldInterceptRequest(android.net.Uri.parse(url));
            }
        });

        // Load the bundled HTML directly. This avoids WebViewAssetLoader failures on some Android/WebView versions.
        try {
            InputStream in = getAssets().open("web/index.html");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            in.close();
            String html = new String(out.toByteArray(), StandardCharsets.UTF_8);
            webView.loadDataWithBaseURL(
                    "https://appassets.androidplatform.net/web/",
                    html, "text/html", "UTF-8", null);
        } catch (Exception e) {
            webView.loadData("<h2>تعذر تحميل التطبيق</h2><p>" + e.getMessage() + "</p>", "text/html", "UTF-8");
        }
    }

    public class OpenAIBridge {
        private final SharedPreferences prefs = getSharedPreferences("ai", MODE_PRIVATE);

        @JavascriptInterface public boolean hasKey() { return !prefs.getString("key", "").isEmpty(); }
        @JavascriptInterface public void setKey(String key) { prefs.edit().putString("key", key == null ? "" : key.trim()).apply(); }
        @JavascriptInterface public void clearKey() { prefs.edit().remove("key").apply(); }

        @JavascriptInterface public void ask(final String text, final String imageData, final String callback) {
            final String key = prefs.getString("key", "");
            new Thread(() -> {
                String result;
                if (key.isEmpty()) { result = "__NO_KEY__"; }
                else {
                    try {
                        URL url = new URL("https://api.openai.com/v1/responses");
                        HttpURLConnection c = (HttpURLConnection) url.openConnection();
                        c.setRequestMethod("POST"); c.setDoOutput(true);
                        c.setRequestProperty("Authorization", "Bearer " + key);
                        c.setRequestProperty("Content-Type", "application/json");
                        JSONObject body = new JSONObject();
                        body.put("model", "gpt-5.6-luna");
                        JSONArray input = new JSONArray();
                        JSONObject msg = new JSONObject(); msg.put("role", "user");
                        JSONArray content = new JSONArray();
                        JSONObject tx = new JSONObject(); tx.put("type", "input_text"); tx.put("text", text); content.put(tx);
                        if (imageData != null && !imageData.isEmpty()) {
                            JSONObject im = new JSONObject(); im.put("type", "input_image"); im.put("image_url", imageData); content.put(im);
                        }
                        msg.put("content", content); input.put(msg); body.put("input", input);
                        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                        try(OutputStream os=c.getOutputStream()){os.write(bytes);}
                        int code=c.getResponseCode();
                        InputStream is=code>=200 && code<300 ? c.getInputStream() : c.getErrorStream();
                        BufferedReader br=new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
                        StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null) sb.append(line);
                        if(code<200 || code>=300) result="__ERR__"+sb.toString();
                        else result=extractText(new JSONObject(sb.toString()));
                    } catch(Exception e) { result="__ERR__"+e.getMessage(); }
                }
                final String out=result.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "");
                new Handler(Looper.getMainLooper()).post(() -> webView.evaluateJavascript(callback + "('" + out + "')", null));
            }).start();
        }

        private String extractText(JSONObject root) throws Exception {
            if(root.has("output_text")) return root.optString("output_text");
            StringBuilder out=new StringBuilder(); JSONArray arr=root.optJSONArray("output");
            if(arr!=null) for(int i=0;i<arr.length();i++){ JSONObject item=arr.optJSONObject(i); JSONArray cont=item==null?null:item.optJSONArray("content"); if(cont!=null) for(int j=0;j<cont.length();j++){ JSONObject x=cont.optJSONObject(j); if(x!=null && x.has("text")) out.append(x.optString("text")); }}
            return out.length()>0?out.toString():"لم أستطع قراءة جواب المساعد.";
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && filePathCallback != null) {
            android.net.Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
