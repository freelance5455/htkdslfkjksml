package com.example.repository

import android.content.Context
import com.example.model.AudioEffectsConfig
import com.example.model.AudioPreset
import com.example.model.BitDepth
import com.example.model.ReverbType
import org.json.JSONArray
import org.json.JSONObject

class PresetsRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("dd3_presets", Context.MODE_PRIVATE)

    val builtInPresets: List<AudioPreset> = listOf(
        AudioPreset(
            id = "preset_classic_dd3",
            name = "Classic DD-3 Naat",
            subtitle = "Authentic Naat Khawan warm delay & sacred hall",
            config = AudioEffectsConfig(
                echoLevel = 0.65f,
                delayTimeMs = 280,
                feedback = 0.48f,
                toneDamp = 0.65f,
                reverbType = ReverbType.SACRED_HALL,
                reverbLevel = 0.35f,
                reverbDecay = 0.65f,
                dryLevel = 0.95f,
                wetLevel = 0.65f,
                masterGain = 1.0f
            ),
            isBuiltIn = true
        ),
        AudioPreset(
            id = "preset_madinah_studio",
            name = "Madinah Studio Vocal",
            subtitle = "Crisp, pristine presence with studio room reflection",
            config = AudioEffectsConfig(
                echoLevel = 0.50f,
                delayTimeMs = 200,
                feedback = 0.35f,
                toneDamp = 0.85f,
                reverbType = ReverbType.STUDIO_ROOM,
                reverbLevel = 0.40f,
                reverbDecay = 0.50f,
                dryLevel = 1.0f,
                wetLevel = 0.55f,
                masterGain = 1.05f
            ),
            isBuiltIn = true
        ),
        AudioPreset(
            id = "preset_grand_masjid",
            name = "Grand Masjid Acoustic",
            subtitle = "Cavernous cathedral-scale prayer hall ambiance",
            config = AudioEffectsConfig(
                echoLevel = 0.70f,
                delayTimeMs = 420,
                feedback = 0.58f,
                toneDamp = 0.55f,
                reverbType = ReverbType.GRAND_MASJID,
                reverbLevel = 0.65f,
                reverbDecay = 0.85f,
                dryLevel = 0.85f,
                wetLevel = 0.75f,
                masterGain = 0.95f
            ),
            isBuiltIn = true
        ),
        AudioPreset(
            id = "preset_mehfil_slapback",
            name = "Mehfil Slapback Warm",
            subtitle = "Tight 110ms slapback for lively mehfil recitations",
            config = AudioEffectsConfig(
                echoLevel = 0.55f,
                delayTimeMs = 110,
                feedback = 0.25f,
                toneDamp = 0.70f,
                reverbType = ReverbType.STUDIO_ROOM,
                reverbLevel = 0.25f,
                reverbDecay = 0.40f,
                dryLevel = 1.0f,
                wetLevel = 0.45f,
                masterGain = 1.0f
            ),
            isBuiltIn = true
        ),
        AudioPreset(
            id = "preset_sufi_ambient",
            name = "Sufi Ambient Drone",
            subtitle = "Extended 580ms spiritual tails and transcendent space",
            config = AudioEffectsConfig(
                echoLevel = 0.80f,
                delayTimeMs = 580,
                feedback = 0.72f,
                toneDamp = 0.45f,
                reverbType = ReverbType.GRAND_MASJID,
                reverbLevel = 0.80f,
                reverbDecay = 0.90f,
                dryLevel = 0.80f,
                wetLevel = 0.85f,
                masterGain = 0.90f
            ),
            isBuiltIn = true
        )
    )

    fun getAllPresets(): List<AudioPreset> {
        val list = mutableListOf<AudioPreset>()
        list.addAll(builtInPresets)
        list.addAll(loadCustomPresets())
        return list
    }

    fun saveCustomPreset(name: String, subtitle: String, config: AudioEffectsConfig): AudioPreset {
        val id = "custom_" + System.currentTimeMillis()
        val preset = AudioPreset(
            id = id,
            name = name.trim(),
            subtitle = subtitle.ifBlank { "Custom Studio User Preset" },
            config = config,
            isBuiltIn = false
        )
        val current = loadCustomPresets().toMutableList()
        current.add(0, preset)
        saveCustomPresets(current)
        return preset
    }

    fun deleteCustomPreset(id: String) {
        val current = loadCustomPresets().filter { it.id != id }
        saveCustomPresets(current)
    }

    private fun loadCustomPresets(): List<AudioPreset> {
        val json = prefs.getString("custom_presets_list", null) ?: return emptyList()
        return try {
            val array = JSONArray(json)
            val list = mutableListOf<AudioPreset>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val configObj = obj.getJSONObject("config")
                val config = AudioEffectsConfig(
                    echoLevel = configObj.optDouble("echoLevel", 0.6).toFloat(),
                    delayTimeMs = configObj.optInt("delayTimeMs", 280),
                    feedback = configObj.optDouble("feedback", 0.48).toFloat(),
                    toneDamp = configObj.optDouble("toneDamp", 0.65).toFloat(),
                    reverbType = try {
                        ReverbType.valueOf(configObj.optString("reverbType", ReverbType.SACRED_HALL.name))
                    } catch (_: Exception) {
                        ReverbType.SACRED_HALL
                    },
                    reverbLevel = configObj.optDouble("reverbLevel", 0.35).toFloat(),
                    reverbDecay = configObj.optDouble("reverbDecay", 0.65).toFloat(),
                    dryLevel = configObj.optDouble("dryLevel", 0.95).toFloat(),
                    wetLevel = configObj.optDouble("wetLevel", 0.65).toFloat(),
                    masterGain = configObj.optDouble("masterGain", 1.0).toFloat(),
                    bitDepth = try {
                        BitDepth.valueOf(configObj.optString("bitDepth", BitDepth.BIT_16.name))
                    } catch (_: Exception) {
                        BitDepth.BIT_16
                    }
                )
                list.add(
                    AudioPreset(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        subtitle = obj.optString("subtitle", "Custom Preset"),
                        config = config,
                        isBuiltIn = false
                    )
                )
            }
            list
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    private fun saveCustomPresets(presets: List<AudioPreset>) {
        val array = JSONArray()
        for (preset in presets) {
            val obj = JSONObject()
            obj.put("id", preset.id)
            obj.put("name", preset.name)
            obj.put("subtitle", preset.subtitle)

            val c = preset.config
            val configObj = JSONObject().apply {
                put("echoLevel", c.echoLevel.toDouble())
                put("delayTimeMs", c.delayTimeMs)
                put("feedback", c.feedback.toDouble())
                put("toneDamp", c.toneDamp.toDouble())
                put("reverbType", c.reverbType.name)
                put("reverbLevel", c.reverbLevel.toDouble())
                put("reverbDecay", c.reverbDecay.toDouble())
                put("dryLevel", c.dryLevel.toDouble())
                put("wetLevel", c.wetLevel.toDouble())
                put("masterGain", c.masterGain.toDouble())
                put("bitDepth", c.bitDepth.name)
            }
            obj.put("config", configObj)
            array.put(obj)
        }
        prefs.edit().putString("custom_presets_list", array.toString()).apply()
    }
}
