package com.example.repository

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import androidx.core.content.FileProvider
import com.example.model.BitDepth
import com.example.model.RecordingItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingsRepository(private val context: Context) {

    private val recordingsDir: File by lazy {
        val externalMusic = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
        val dir = File(externalMusic ?: context.filesDir, "DD3EchoStudio")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        dir
    }

    suspend fun createNewRecordingFile(bitDepth: BitDepth): File = withContext(Dispatchers.IO) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val depthSuffix = if (bitDepth == BitDepth.BIT_24) "24bit" else "16bit"
        val fileName = "DD3_Naat_${timeStamp}_$depthSuffix.wav"
        File(recordingsDir, fileName)
    }

    suspend fun loadAllRecordings(): List<RecordingItem> = withContext(Dispatchers.IO) {
        val files = recordingsDir.listFiles { file ->
            file.isFile && file.name.endsWith(".wav", ignoreCase = true)
        } ?: emptyArray()

        files.sortedByDescending { it.lastModified() }.map { file ->
            parseRecordingItem(file)
        }
    }

    private fun parseRecordingItem(file: File): RecordingItem {
        var durationMs = 0L
        var sampleRate = 44100
        var bitDepth = BitDepth.BIT_16

        try {
            if (file.length() >= 44) {
                RandomAccessFile(file, "r").use { raf ->
                    val header = ByteArray(44)
                    raf.readFully(header)
                    val bb = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)

                    sampleRate = bb.getInt(24)
                    val bits = bb.getShort(34).toInt()
                    val dataSize = bb.getInt(40).toLong() and 0xFFFFFFFFL

                    bitDepth = if (bits == 24) BitDepth.BIT_24 else BitDepth.BIT_16
                    val bytesPerSample = bitDepth.bytesPerSample
                    val totalSamples = dataSize / bytesPerSample
                    if (sampleRate > 0) {
                        durationMs = (totalSamples * 1000L) / sampleRate
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return RecordingItem(
            id = file.absolutePath,
            fileName = file.name,
            filePath = file.absolutePath,
            durationMs = durationMs,
            timestamp = file.lastModified(),
            fileSizeBytes = file.length(),
            bitDepth = bitDepth,
            sampleRate = sampleRate
        )
    }

    suspend fun renameRecording(item: RecordingItem, newNameWithoutExt: String): RecordingItem? =
        withContext(Dispatchers.IO) {
            val sanitized = newNameWithoutExt.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
            if (sanitized.isBlank()) return@withContext null

            val currentFile = File(item.filePath)
            if (!currentFile.exists()) return@withContext null

            val finalName = if (sanitized.endsWith(".wav", ignoreCase = true)) sanitized else "$sanitized.wav"
            val targetFile = File(currentFile.parentFile, finalName)

            if (currentFile.renameTo(targetFile)) {
                parseRecordingItem(targetFile)
            } else {
                null
            }
        }

    suspend fun deleteRecording(item: RecordingItem): Boolean = withContext(Dispatchers.IO) {
        val file = File(item.filePath)
        if (file.exists()) {
            file.delete()
        } else {
            true
        }
    }

    fun createShareIntent(item: RecordingItem): Intent {
        val file = File(item.filePath)
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/wav"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, item.fileName)
            putExtra(Intent.EXTRA_TEXT, "Audio recorded with DD3 Echo Studio")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Intent.createChooser(intent, "Share Naat Recording")
    }
}
