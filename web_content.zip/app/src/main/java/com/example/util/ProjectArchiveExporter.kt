package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.model.StudioProject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class ArchiveExportSummary(
    val archiveFileName: String,
    val totalBytes: Int,
    val packagedFiles: List<String>,
    val destinationDescription: String
)

data class DirectDownloadResult(
    val fileName: String,
    val displayPath: String,
    val totalBytes: Long,
    val contentUri: Uri?,
    val mimeType: String
)

object ProjectArchiveExporter {

    fun suggestedArchiveFileName(project: StudioProject): String {
        val slug = project.title
            .lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
            .ifBlank { "omniprompt-project" }
        val suffix = if (project.isWebsiteProject()) "website-bundle.zip" else "studio-archive.zip"
        return "$slug-$suffix"
    }

    fun buildArchiveEntries(
        project: StudioProject,
        includeFullGradleScaffold: Boolean = true
    ): Map<String, String> {
        if (project.isWebsiteProject()) {
            return buildWebsiteArchiveEntries(project, includeFullGradleScaffold)
        }

        val metadataJson = JSONObject().apply {
            put("title", project.title)
            put("projectTarget", "ANDROID_APP")
            put("provider", project.provider)
            put("modelId", project.modelId)
            put("prompt", project.prompt)
            put("summary", project.summary)
            put("includeFullGradleScaffold", includeFullGradleScaffold)
            put("exportedBy", "OmniPrompt Studio Android")
        }.toString(2)

        val readmeMd = """
            # ${project.title}

            ${project.summary}

            ## Synthesis Metadata
            - **AI Provider**: ${project.provider}
            - **Model**: `${project.modelId}`
            - **Original Specification Prompt**:
              > ${project.prompt}

            ## Project Structure
            - `README.md` — Architecture & build documentation
            - `project-config.json` — Synthesis & model configuration metadata
            - `sandbox-spec.json` — Live Sandbox interactive widget specification
            - `app/build.gradle.kts` — Android Gradle Kotlin DSL build configuration
            - `app/src/main/AndroidManifest.xml` — Application manifest
            - `app/src/main/java/com/example/MainActivity.kt` — Jetpack Compose UI implementation
        """.trimIndent()

        val appMintPackageJson = JSONObject().apply {
            put("name", project.title.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "omniprompt-app" })
            put("private", true)
            put("version", "1.0.0")
            put("description", "${project.title} — Built with OmniPrompt Studio")
            put("main", "index.html")
            put("scripts", JSONObject().apply {
                put("dev", "echo \"Ready\"")
                put("build", "node -e \"const fs=require('fs');fs.mkdirSync('dist',{recursive:true});fs.copyFileSync('index.html','dist/index.html');\"")
            })
            put("dependencies", JSONObject())
            put("devDependencies", JSONObject())
        }.toString(2)

        val fallbackIndexHtml = """
            <!DOCTYPE html>
            <html lang="en">
            <head>
              <meta charset="UTF-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1.0" />
              <title>${project.title}</title>
              <style>
                body { font-family: system-ui, sans-serif; background: #080C16; color: #F8FAFC; margin: 0; padding: 18px; }
                .card { background: #111827; border: 1px solid #38BDF8; border-radius: 16px; padding: 18px; margin-bottom: 14px; }
                .badge { display: inline-block; padding: 4px 10px; border-radius: 999px; background: rgba(56,189,248,0.16); color: #38BDF8; font-size: 12px; font-weight: 700; }
              </style>
            </head>
            <body>
              <div class="card">
                <span class="badge">${project.provider} • ${project.modelId}</span>
                <h2>${project.title}</h2>
                <p>${project.summary}</p>
              </div>
            </body>
            </html>
        """.trimIndent()

        val baseMap = linkedMapOf(
            "package.json" to appMintPackageJson,
            "index.html" to fallbackIndexHtml,
            "README.md" to readmeMd,
            "project-config.json" to metadataJson,
            "sandbox-spec.json" to project.sandboxSpecJson,
            "app/build.gradle.kts" to project.buildGradleKts,
            "app/src/main/AndroidManifest.xml" to project.manifestXml,
            "app/src/main/java/com/example/MainActivity.kt" to project.kotlinCode
        )

        if (includeFullGradleScaffold) {
            baseMap["settings.gradle.kts"] = """
                pluginManagement {
                    repositories {
                        google()
                        mavenCentral()
                        gradlePluginPortal()
                    }
                }
                dependencyResolutionManagement {
                    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                    repositories {
                        google()
                        mavenCentral()
                    }
                }
                rootProject.name = "${project.title.replace("\"", "")}"
                include(":app")
            """.trimIndent()

            baseMap["gradle.properties"] = """
                org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
                android.useAndroidX=true
                kotlin.code.style=official
                android.nonTransitiveRClass=true
            """.trimIndent()

            baseMap[".gitignore"] = """
                *.iml
                .gradle
                /local.properties
                /.idea
                /build
                .DS_Store
            """.trimIndent()
        }

        return baseMap
    }

    private fun buildWebsiteArchiveEntries(
        project: StudioProject,
        includeDeployConfigs: Boolean
    ): Map<String, String> {
        val metadataJson = JSONObject().apply {
            put("title", project.title)
            put("projectTarget", "WEBSITE")
            put("provider", project.provider)
            put("modelId", project.modelId)
            put("prompt", project.prompt)
            put("summary", project.summary)
            put("exportedBy", "OmniPrompt Studio Website Maker")
        }.toString(2)

        val packageJson = JSONObject().apply {
            put("name", project.title.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifBlank { "omniprompt-web" })
            put("private", true)
            put("version", "1.0.0")
            put("description", "${project.title} — Built with OmniPrompt Studio")
            put("main", "index.html")
            put("scripts", JSONObject().apply {
                put("dev", "echo \"Ready\"")
                put("build", "node -e \"const fs=require('fs');fs.mkdirSync('dist',{recursive:true});fs.copyFileSync('index.html','dist/index.html');\"")
            })
            put("dependencies", JSONObject())
            put("devDependencies", JSONObject())
        }.toString(2)

        val readmeMd = """
            # ${project.title} — Static Website Bundle

            ${project.summary}

            ## Synthesis Metadata
            - **AI Provider**: ${project.provider}
            - **Model**: `${project.modelId}`
            - **Website Prompt**:
              > ${project.prompt}

            ## Bundle Structure
            - `package.json` — AppMint & Node web bundle manifest
            - `index.html` — Semantic HTML5 responsive entry page
            - `styles.css` — Mobile-first CSS3 stylesheet with custom properties
            - `app.js` — Interactive Vanilla ES6 JavaScript controller
            - `website-spec.json` — Structured website section & theme blueprint
            - `project-config.json` — Provider & model synthesis metadata
        """.trimIndent()

        val webMap = linkedMapOf(
            "package.json" to packageJson,
            "README.md" to readmeMd,
            "project-config.json" to metadataJson,
            "website-spec.json" to project.sandboxSpecJson,
            "index.html" to project.kotlinCode,
            "styles.css" to project.manifestXml,
            "app.js" to project.buildGradleKts
        )

        if (includeDeployConfigs) {
            webMap["netlify.toml"] = """
                [build]
                  publish = "."
                [[headers]]
                  for = "/*"
                  [headers.values]
                    X-Frame-Options = "SAMEORIGIN"
                    X-Content-Type-Options = "nosniff"
            """.trimIndent()

            webMap["vercel.json"] = """
                {
                  "version": 2,
                  "cleanUrls": true
                }
            """.trimIndent()
        }

        return webMap
    }

    fun shareProjectBlueprint(context: Context, project: StudioProject) {
        val shareBody = if (project.isWebsiteProject()) {
            """
            # ${project.title} — Website Blueprint (${project.provider} • ${project.modelId})
            ${project.summary}

            ## Website Prompt
            ${project.prompt}

            ## index.html
            ${project.kotlinCode}

            ## styles.css
            ${project.manifestXml}

            ## app.js
            ${project.buildGradleKts}
            """.trimIndent()
        } else {
            """
            # ${project.title} (${project.provider} • ${project.modelId})
            ${project.summary}

            ## Specification Prompt
            ${project.prompt}

            ## MainActivity.kt
            ${project.kotlinCode}
            """.trimIndent()
        }

        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "OmniPrompt Studio — ${project.title}")
            putExtra(Intent.EXTRA_TEXT, shareBody)
        }
        val chooser = Intent.createChooser(sendIntent, "Share ${project.title} Blueprint").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    private fun writeZipToStream(entries: Map<String, String>, outputStream: OutputStream) {
        ZipOutputStream(outputStream).use { zipOut ->
            entries.forEach { (path, content) ->
                val entry = ZipEntry(path)
                zipOut.putNextEntry(entry)
                val bytes = content.toByteArray(StandardCharsets.UTF_8)
                zipOut.write(bytes)
                zipOut.closeEntry()
            }
        }
    }

    suspend fun exportToUri(
        context: Context,
        project: StudioProject,
        targetUri: Uri,
        includeFullGradleScaffold: Boolean = true
    ): Result<ArchiveExportSummary> = withContext(Dispatchers.IO) {
        try {
            val entries = buildArchiveEntries(project, includeFullGradleScaffold)
            val byteBuffer = ByteArrayOutputStream()
            writeZipToStream(entries, byteBuffer)
            val zipBytes = byteBuffer.toByteArray()

            context.contentResolver.openOutputStream(targetUri)?.use { out ->
                out.write(zipBytes)
                out.flush()
            } ?: throw IllegalStateException("Unable to open output stream for selected URI.")

            val fileName = suggestedArchiveFileName(project)
            Result.success(
                ArchiveExportSummary(
                    archiveFileName = fileName,
                    totalBytes = zipBytes.size,
                    packagedFiles = entries.keys.toList(),
                    destinationDescription = "Saved to device storage ($fileName)"
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun exportToInternalWorkspace(
        context: Context,
        project: StudioProject,
        includeFullGradleScaffold: Boolean = true
    ): Result<ArchiveExportSummary> = withContext(Dispatchers.IO) {
        try {
            val entries = buildArchiveEntries(project, includeFullGradleScaffold)
            val exportDir = File(context.filesDir, "exported_archives").apply { mkdirs() }
            val fileName = suggestedArchiveFileName(project)
            val targetFile = File(exportDir, fileName)

            val byteBuffer = ByteArrayOutputStream()
            writeZipToStream(entries, byteBuffer)
            val zipBytes = byteBuffer.toByteArray()

            FileOutputStream(targetFile).use { out ->
                out.write(zipBytes)
                out.flush()
            }

            Result.success(
                ArchiveExportSummary(
                    archiveFileName = fileName,
                    totalBytes = zipBytes.size,
                    packagedFiles = entries.keys.toList(),
                    destinationDescription = targetFile.absolutePath
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Exports the currently installed & signed OmniPrompt Studio APK binary directly to the
     * user's chosen device storage URI.
     */
    suspend fun exportInstalledStudioApkToUri(
        context: Context,
        targetUri: Uri
    ): Result<ArchiveExportSummary> = withContext(Dispatchers.IO) {
        try {
            val sourceApkFile = File(context.applicationInfo.sourceDir)
            if (!sourceApkFile.exists()) {
                return@withContext Result.failure(
                    IllegalStateException("Installed APK binary could not be located at ${sourceApkFile.absolutePath}")
                )
            }
            var copiedBytes = 0L
            sourceApkFile.inputStream().use { input ->
                context.contentResolver.openOutputStream(targetUri)?.use { output ->
                    copiedBytes = input.copyTo(output)
                    output.flush()
                } ?: throw IllegalStateException("Unable to open output stream for selected APK destination.")
            }

            val fileName = "OmniPromptStudio-v1.0-signed.apk"
            Result.success(
                ArchiveExportSummary(
                    archiveFileName = fileName,
                    totalBytes = copiedBytes.toInt(),
                    packagedFiles = listOf(fileName),
                    destinationDescription = "Signed APK saved to device storage ($fileName)"
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Exports a full master ZIP archive containing the signed OmniPrompt Studio APK,
     * build configuration, and all Studio workspace projects.
     */
    suspend fun exportFullStudioBundleZipToUri(
        context: Context,
        projects: List<StudioProject>,
        targetUri: Uri
    ): Result<ArchiveExportSummary> = withContext(Dispatchers.IO) {
        try {
            var totalBytes = 0L
            context.contentResolver.openOutputStream(targetUri)?.use { rawOut ->
                totalBytes = writeMasterStudioZipStream(context, projects, rawOut)
            } ?: throw IllegalStateException("Unable to open output stream for selected ZIP destination.")

            val fileName = "OmniPromptStudio-Full-App-and-APK.zip"
            Result.success(
                ArchiveExportSummary(
                    archiveFileName = fileName,
                    totalBytes = totalBytes.toInt(),
                    packagedFiles = listOf("package.json", "index.html", "apk/OmniPromptStudio-v1.0-signed.apk", "README.md"),
                    destinationDescription = "Full App + APK ZIP saved to device storage"
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 1-Tap Phone-Only Direct Save: Writes the signed OmniPrompt Studio APK directly into
     * the phone's public `Downloads/` folder via MediaStore.Downloads (no computer or folder picker required).
     */
    suspend fun saveApkDirectlyToDownloads(
        context: Context
    ): Result<DirectDownloadResult> = withContext(Dispatchers.IO) {
        try {
            val sourceApkFile = File(context.applicationInfo.sourceDir)
            if (!sourceApkFile.exists()) {
                return@withContext Result.failure(
                    IllegalStateException("Installed APK binary could not be located at ${sourceApkFile.absolutePath}")
                )
            }

            val fileName = "OmniPromptStudio-v1.0-signed.apk"
            val mimeType = "application/vnd.android.package-archive"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create APK entry in Phone Downloads folder.")

                var copiedBytes = 0L
                sourceApkFile.inputStream().use { input ->
                    resolver.openOutputStream(itemUri)?.use { output ->
                        copiedBytes = input.copyTo(output)
                        output.flush()
                    } ?: throw IllegalStateException("Could not open Downloads output stream for APK.")
                }

                val completeValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                resolver.update(itemUri, completeValues, null, null)

                Result.success(
                    DirectDownloadResult(
                        fileName = fileName,
                        displayPath = "Downloads/$fileName",
                        totalBytes = copiedBytes,
                        contentUri = itemUri,
                        mimeType = mimeType
                    )
                )
            } else {
                val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                    ?: File(context.filesDir, "Downloads").apply { mkdirs() }
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val targetFile = File(downloadsDir, fileName)
                val copiedBytes = sourceApkFile.inputStream().use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }
                Result.success(
                    DirectDownloadResult(
                        fileName = fileName,
                        displayPath = "Downloads/$fileName",
                        totalBytes = copiedBytes,
                        contentUri = null,
                        mimeType = mimeType
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * 1-Tap Phone-Only Direct Save: Packages the signed OmniPrompt Studio APK, main app Gradle
     * project scaffold, and all Studio workspace projects directly into `Downloads/OmniPromptStudio-Full-App-and-APK.zip`.
     */
    suspend fun saveFullZipDirectlyToDownloads(
        context: Context,
        projects: List<StudioProject>
    ): Result<DirectDownloadResult> = withContext(Dispatchers.IO) {
        try {
            val fileName = "OmniPromptStudio-Full-App-and-APK.zip"
            val mimeType = "application/zip"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }

                val itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create ZIP entry in Phone Downloads folder.")

                var totalBytes = 0L
                resolver.openOutputStream(itemUri)?.use { rawOut ->
                    totalBytes = writeMasterStudioZipStream(context, projects, rawOut)
                } ?: throw IllegalStateException("Could not open Downloads output stream for Full App ZIP.")

                val completeValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                resolver.update(itemUri, completeValues, null, null)

                Result.success(
                    DirectDownloadResult(
                        fileName = fileName,
                        displayPath = "Downloads/$fileName",
                        totalBytes = totalBytes,
                        contentUri = itemUri,
                        mimeType = mimeType
                    )
                )
            } else {
                val downloadsDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                    ?: File(context.filesDir, "Downloads").apply { mkdirs() }
                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                val targetFile = File(downloadsDir, fileName)
                val totalBytes = FileOutputStream(targetFile).use { rawOut ->
                    writeMasterStudioZipStream(context, projects, rawOut)
                }
                Result.success(
                    DirectDownloadResult(
                        fileName = fileName,
                        displayPath = "Downloads/$fileName",
                        totalBytes = totalBytes,
                        contentUri = null,
                        mimeType = mimeType
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun writeMasterStudioZipStream(
        context: Context,
        projects: List<StudioProject>,
        rawOut: OutputStream
    ): Long {
        var totalBytes = 0L
        ZipOutputStream(rawOut).use { zos ->
            // 1. Signed OmniPrompt Studio APK inside apk/
            val sourceApkFile = File(context.applicationInfo.sourceDir)
            if (sourceApkFile.exists() && sourceApkFile.canRead()) {
                val apkEntryName = "apk/OmniPromptStudio-v1.0-signed.apk"
                zos.putNextEntry(ZipEntry(apkEntryName))
                val copied = sourceApkFile.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
                totalBytes += copied
            }

            // 2. Main OmniPrompt Studio Project Configuration & Manifest
            val studioScaffoldEntries = mapOf(
                "omniprompt_studio_project/settings.gradle.kts" to """
                    pluginManagement {
                        repositories {
                            google()
                            mavenCentral()
                            gradlePluginPortal()
                        }
                    }
                    dependencyResolutionManagement {
                        repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                        repositories {
                            google()
                            mavenCentral()
                        }
                    }
                    rootProject.name = "OmniPromptStudio"
                    include(":app")
                """.trimIndent(),
                "omniprompt_studio_project/app/build.gradle.kts" to """
                    plugins {
                        id("com.android.application")
                        id("org.jetbrains.kotlin.android")
                        id("org.jetbrains.kotlin.plugin.compose")
                    }

                    android {
                        namespace = "com.example"
                        compileSdk = 35

                        defaultConfig {
                            applicationId = "com.aistudio.omnipromptstudio.vpxkqm"
                            minSdk = 26
                            targetSdk = 35
                            versionCode = 1
                            versionName = "1.0.0"
                        }

                        buildFeatures {
                            compose = true
                        }
                    }
                """.trimIndent(),
                "omniprompt_studio_project/app/src/main/AndroidManifest.xml" to """
                    <?xml version="1.0" encoding="utf-8"?>
                    <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                        <uses-permission android:name="android.permission.INTERNET" />
                        <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
                        <application
                            android:label="OmniPrompt"
                            android:usesCleartextTraffic="true"
                            android:supportsRtl="true"
                            android:theme="@style/Theme.MyApplication">
                            <activity
                                android:name=".MainActivity"
                                android:exported="true">
                                <intent-filter>
                                    <action android:name="android.intent.action.MAIN" />
                                    <category android:name="android.intent.action.LAUNCHER" />
                                </intent-filter>
                            </activity>
                        </application>
                    </manifest>
                """.trimIndent()
            )
            studioScaffoldEntries.forEach { (entryPath, content) ->
                val bytes = content.toByteArray(StandardCharsets.UTF_8)
                zos.putNextEntry(ZipEntry(entryPath))
                zos.write(bytes)
                zos.closeEntry()
                totalBytes += bytes.size
            }

            // 3. All Saved Studio & Converted Projects
            projects.forEachIndexed { index, project ->
                val slug = project.title
                    .lowercase()
                    .replace(Regex("[^a-z0-9]+"), "-")
                    .trim('-')
                    .ifBlank { "project-${index + 1}" }
                val entries = buildArchiveEntries(project, includeFullGradleScaffold = true)
                entries.forEach { (relPath, content) ->
                    val fullPath = "workspace_projects/$slug/$relPath"
                    val bytes = content.toByteArray(StandardCharsets.UTF_8)
                    zos.putNextEntry(ZipEntry(fullPath))
                    zos.write(bytes)
                    zos.closeEntry()
                    totalBytes += bytes.size
                }
            }

            // 4. Root package.json and index.html for AppMint / Mobile Web Builders
            val rootPackageJson = """
                {
                  "name": "omniprompt-studio",
                  "private": true,
                  "version": "1.0.0",
                  "type": "module",
                  "description": "OmniPrompt Studio — AI App & Website Synthesis, HTML/ZIP to Android App Converter, Live Sandbox & API Hub",
                  "main": "index.html",
                  "scripts": {
                    "dev": "vite",
                    "build": "vite build",
                    "preview": "vite preview"
                  },
                  "dependencies": {
                    "react": "^19.0.0",
                    "react-dom": "^19.0.0"
                  },
                  "devDependencies": {
                    "@types/react": "^19.0.0",
                    "@types/react-dom": "^19.0.0",
                    "@vitejs/plugin-react": "^4.3.4",
                    "typescript": "~5.6.2",
                    "vite": "^6.0.0"
                  }
                }
            """.trimIndent().toByteArray(StandardCharsets.UTF_8)
            zos.putNextEntry(ZipEntry("package.json"))
            zos.write(rootPackageJson)
            zos.closeEntry()
            totalBytes += rootPackageJson.size

            val rootIndexHtml = try {
                context.assets.open("index.html").use { it.readBytes() }
            } catch (_: Exception) {
                """
                <!DOCTYPE html>
                <html lang="en">
                <head>
                  <meta charset="UTF-8" />
                  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                  <title>OmniPrompt Studio</title>
                  <style>
                    body { font-family: system-ui, sans-serif; background: #080C16; color: #F8FAFC; margin: 0; padding: 18px; }
                    .card { background: #111827; border: 1px solid #38BDF8; border-radius: 16px; padding: 18px; margin-bottom: 14px; }
                  </style>
                </head>
                <body>
                  <div id="root">
                    <div class="card">
                      <h2>⚡ OmniPrompt Studio</h2>
                      <p>AI App Synthesizer, Web Maker, HTML/ZIP to Android App Converter &amp; Live Sandbox (${projects.size} Workspace Projects).</p>
                    </div>
                  </div>
                </body>
                </html>
                """.trimIndent().toByteArray(StandardCharsets.UTF_8)
            }
            zos.putNextEntry(ZipEntry("index.html"))
            zos.write(rootIndexHtml)
            zos.closeEntry()
            totalBytes += rootIndexHtml.size

            // 5. Master Phone-First Installation & Usage Guide
            val readmeBytes = """
                # OmniPrompt Studio — Full App & Signed APK Bundle
                
                ## 1. Installing on Your Android Phone (No Computer Needed)
                - Open your phone's **Files** or **My Files** app and go to **Downloads**.
                - Extract `OmniPromptStudio-Full-App-and-APK.zip` (or tap `OmniPromptStudio-v1.0-signed.apk` directly in `Downloads/`).
                - Tap `apk/OmniPromptStudio-v1.0-signed.apk` and select **Install**.
                
                ## 2. Included Folders & Files
                - `package.json` & `index.html` — Root AppMint & mobile builder manifest + entry point.
                - `apk/OmniPromptStudio-v1.0-signed.apk` — Ready-to-install signed Android APK of OmniPrompt Studio.
                - `omniprompt_studio_project/` — Root Android Gradle configuration and Manifest for OmniPrompt Studio.
                - `workspace_projects/` — All AI-generated apps, websites, and converted HTML/ZIP Android projects (${projects.size} project(s)).
            """.trimIndent().toByteArray(StandardCharsets.UTF_8)
            zos.putNextEntry(ZipEntry("README.md"))
            zos.write(readmeBytes)
            zos.closeEntry()
            totalBytes += readmeBytes.size
        }
        return totalBytes
    }

    /**
     * Shares a saved APK or Full ZIP from `Downloads/` via the native Android Share Sheet
     * (WhatsApp, Telegram, Drive, Files, Nearby Share) without needing a computer.
     */
    fun shareSavedDownloadFile(context: Context, result: DirectDownloadResult) {
        val uri = result.contentUri ?: return
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = result.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, result.fileName)
            putExtra(
                Intent.EXTRA_TEXT,
                "OmniPrompt Studio (${result.fileName}) — saved in ${result.displayPath}"
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "Share ${result.fileName}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }
}
