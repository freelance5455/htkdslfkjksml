package com.example.util

import java.util.Calendar
import kotlin.math.abs

private val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

fun Int.toPersianDigits(): String = this.toString().toPersianDigits()

fun Long.toPersianDigits(): String = this.toString().toPersianDigits()

fun String.toPersianDigits(): String {
    val sb = StringBuilder(length)
    for (ch in this) {
        if (ch in '0'..'9') {
            sb.append(persianDigits[ch - '0'])
        } else {
            sb.append(ch)
        }
    }
    return sb.toString()
}

fun formatDurationPersian(minutes: Int): String {
    if (minutes <= 0) return "۰ دقیقه"
    val hours = minutes / 60
    val rem = minutes % 60
    return when {
        hours > 0 && rem > 0 -> "${hours.toPersianDigits()} ساعت و ${rem.toPersianDigits()} دقیقه"
        hours > 0 -> "${hours.toPersianDigits()} ساعت"
        else -> "${rem.toPersianDigits()} دقیقه"
    }
}

fun formatTimerClock(totalSeconds: Int): String {
    val mins = totalSeconds / 60
    val secs = totalSeconds % 60
    val raw = "%02d:%02d".format(mins, secs)
    return raw.toPersianDigits()
}

fun startOfDayMillis(timeMillis: Long): Long {
    val cal = Calendar.getInstance().apply {
        timeInMillis = timeMillis
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return cal.timeInMillis
}

fun formatRelativeDateFa(targetMillis: Long?): String {
    if (targetMillis == null) return "بدون تاریخ"
    val todayStart = startOfDayMillis(System.currentTimeMillis())
    val targetStart = startOfDayMillis(targetMillis)
    val diffDays = ((targetStart - todayStart) / 86_400_000L).toInt()
    return when {
        diffDays == 0 -> "امروز"
        diffDays == 1 -> "فردا"
        diffDays == -1 -> "دیروز (عقب‌افتاده)"
        diffDays < -1 -> "${abs(diffDays).toPersianDigits()} روز تأخیر"
        diffDays <= 7 -> "${diffDays.toPersianDigits()} روز مانده"
        else -> {
            val cal = Calendar.getInstance().apply { timeInMillis = targetMillis }
            val monthNames = arrayOf(
                "ژانویه", "فوریه", "مارس", "آوریل", "مه", "ژوئن",
                "ژوئیه", "اوت", "سپتامبر", "اکتبر", "نوامبر", "دسامبر"
            )
            val day = cal.get(Calendar.DAY_OF_MONTH).toPersianDigits()
            val month = monthNames[cal.get(Calendar.MONTH)]
            "$day $month"
        }
    }
}

fun isOverdue(targetMillis: Long?): Boolean {
    if (targetMillis == null) return false
    val todayStart = startOfDayMillis(System.currentTimeMillis())
    return startOfDayMillis(targetMillis) < todayStart
}
