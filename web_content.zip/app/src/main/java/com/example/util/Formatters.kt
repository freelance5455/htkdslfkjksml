package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.google.firebase.Timestamp
import java.io.ByteArrayOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

const val FEATURED_AUCTION_FEE_NAIRA = 2000L
const val PLATFORM_COMMISSION_RATE = 3L
const val ADMIN_BOOTSTRAP_EMAIL = "orjimodesty@gmail.com"

val AUCTION_CATEGORIES = listOf(
    "All",
    "Watches",
    "Art",
    "Electronics",
    "Vehicles",
    "Collectibles",
    "Real Estate",
    "Fashion"
)

data class CountdownParts(
    val label: String,
    val ended: Boolean,
    val urgent: Boolean
)

fun formatNaira(amount: Long): String {
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    return "₦${formatter.format(amount)}"
}

fun calculateCommission(grossAmount: Long): Long =
    (grossAmount * PLATFORM_COMMISSION_RATE) / 100L

fun formatCountdown(endsAt: Timestamp?, nowMillis: Long, status: String = "ACTIVE"): CountdownParts {
    if (status == "SETTLED") return CountdownParts("Settled", ended = true, urgent = false)
    if (status == "CANCELLED") return CountdownParts("Cancelled", ended = true, urgent = false)
    if (status == "PAUSED") return CountdownParts("Paused", ended = false, urgent = false)
    if (endsAt == null) return CountdownParts("--:--", ended = false, urgent = false)

    val diffMs = endsAt.toDate().time - nowMillis
    if (diffMs <= 0L || status == "ENDED") {
        return CountdownParts("Ended", ended = true, urgent = false)
    }

    val totalSeconds = diffMs / 1000L
    val days = totalSeconds / 86400L
    val hours = (totalSeconds % 86400L) / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L

    val label = when {
        days > 0 -> String.format(Locale.US, "%dd %02dh %02dm", days, hours, minutes)
        hours > 0 -> String.format(Locale.US, "%02dh %02dm %02ds", hours, minutes, seconds)
        else -> String.format(Locale.US, "%02dm %02ds", minutes, seconds)
    }
    return CountdownParts(
        label = label,
        ended = false,
        urgent = totalSeconds <= 300L
    )
}

fun formatTimestamp(timestamp: Timestamp?): String {
    val date = timestamp?.toDate() ?: Date()
    val fmt = SimpleDateFormat("dd MMM, HH:mm", Locale.US)
    return fmt.format(date)
}

fun compressImageUriToDataUrl(context: Context, uri: Uri, maxDim: Int = 560): String? {
    return try {
        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOpts)
        }
        val origMax = max(boundsOpts.outWidth, boundsOpts.outHeight)
        var sampleSize = 1
        while (origMax / sampleSize > maxDim * 2) {
            sampleSize *= 2
        }
        val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val decoded = context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOpts)
        } ?: return null

        val scale = if (max(decoded.width, decoded.height) > maxDim) {
            maxDim.toFloat() / max(decoded.width, decoded.height).toFloat()
        } else 1f
        val targetW = max(1, (decoded.width * scale).toInt())
        val targetH = max(1, (decoded.height * scale).toInt())
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(decoded, targetW, targetH, true).also {
                if (it !== decoded) decoded.recycle()
            }
        } else decoded

        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 72, out)
        scaled.recycle()
        val bytes = out.toByteArray()
        if (bytes.size > 170_000) return null
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        "data:image/jpeg;base64,$b64"
    } catch (_: Exception) {
        null
    }
}
