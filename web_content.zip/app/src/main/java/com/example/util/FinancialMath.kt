package com.example.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

data class ValidationResult(
    val isValid: Boolean,
    val errorMessage: String? = null,
    val warningMessage: String? = null
)

data class WithdrawalCalculationResult(
    val withdrawalAmount: Double,
    val platformFeePercent: Double,
    val platformFeeAmount: Double,
    val commissionPercent: Double,
    val commissionAmount: Double,
    val transactionCharge: Double,
    val otherCosts: Double,
    val customerPayout: Double,
    val grossProfit: Double,
    val netProfit: Double
)

data class BillPaymentCalculationResult(
    val billAmount: Double,
    val platformFeePercent: Double,
    val platformFeeAmount: Double,
    val isManualFee: Boolean,
    val serviceChargePercent: Double,
    val serviceChargeAmount: Double,
    val totalCustomerCharge: Double,
    val totalCustomerChargePercent: Double,
    val commissionPercent: Double,
    val commissionAmount: Double,
    val otherCosts: Double,
    val grossProfit: Double,
    val netProfit: Double
)

object FinancialMath {

    private val inrSymbols = DecimalFormatSymbols(Locale("en", "IN")).apply {
        currencySymbol = "₹"
    }

    fun roundToTwoDecimals(value: Double): Double {
        return BigDecimal.valueOf(value)
            .setScale(2, RoundingMode.HALF_UP)
            .toDouble()
    }

    fun roundToFourDecimals(value: Double): Double {
        return BigDecimal.valueOf(value)
            .setScale(4, RoundingMode.HALF_UP)
            .toDouble()
    }

    /**
     * Formats amount according to Indian numbering system (e.g. ₹1,00,000.00).
     * Handles negative values properly as -₹110.00.
     */
    fun formatInr(amount: Double, includeSymbol: Boolean = true): String {
        val isNegative = amount < 0
        val absVal = Math.abs(amount)
        val df = DecimalFormat("##,##,##0.00", inrSymbols)
        val formatted = df.format(absVal)
        val prefix = if (includeSymbol) "₹" else ""
        return if (isNegative) "-$prefix$formatted" else "$prefix$formatted"
    }

    fun formatPercent(percent: Double): String {
        return String.format(Locale.US, "%.2f%%", percent)
    }

    /**
     * Parse double safely from text, stripping out commas and currency symbols.
     */
    fun parseDoubleOrNull(input: String): Double? {
        val sanitized = input.trim()
            .replace("₹", "")
            .replace(",", "")
            .replace("%", "")
            .trim()
        if (sanitized.isEmpty()) return null
        return sanitized.toDoubleOrNull()
    }

    // --- Validation Methods ---

    fun validateAmount(
        input: String,
        fieldName: String = "Amount",
        allowZero: Boolean = false,
        maxLimit: Double = 100_000_000.0
    ): ValidationResult {
        val trimmed = input.trim().replace("₹", "").replace(",", "").trim()
        if (trimmed.isEmpty()) {
            return ValidationResult(isValid = false, errorMessage = "$fieldName is required")
        }
        val value = trimmed.toDoubleOrNull()
            ?: return ValidationResult(isValid = false, errorMessage = "Enter a valid decimal number")

        if (value < 0.0) {
            return ValidationResult(isValid = false, errorMessage = "$fieldName cannot be negative")
        }
        if (!allowZero && value == 0.0) {
            return ValidationResult(isValid = false, errorMessage = "$fieldName must be greater than zero")
        }
        if (value > maxLimit) {
            return ValidationResult(
                isValid = true,
                warningMessage = "Unusually high $fieldName entered (₹${formatInr(value, false)}). Verify carefully."
            )
        }
        return ValidationResult(isValid = true)
    }

    fun validatePercentage(
        input: String,
        fieldName: String = "Percentage",
        min: Double = 0.0,
        max: Double = 100.0
    ): ValidationResult {
        val trimmed = input.trim().replace("%", "").trim()
        if (trimmed.isEmpty()) {
            return ValidationResult(isValid = false, errorMessage = "$fieldName is required")
        }
        val value = trimmed.toDoubleOrNull()
            ?: return ValidationResult(isValid = false, errorMessage = "Enter a valid decimal percentage")

        if (value < min || value > max) {
            return ValidationResult(
                isValid = false,
                errorMessage = "$fieldName must be between $min% and $max%"
            )
        }
        if (value > 25.0) {
            return ValidationResult(
                isValid = true,
                warningMessage = "High rate of ${formatPercent(value)} specified. Verify if intended."
            )
        }
        return ValidationResult(isValid = true)
    }

    fun validateCharge(
        input: String,
        fieldName: String = "Charge",
        allowEmptyAsZero: Boolean = true
    ): ValidationResult {
        val trimmed = input.trim().replace("₹", "").replace(",", "").trim()
        if (trimmed.isEmpty()) {
            return if (allowEmptyAsZero) {
                ValidationResult(isValid = true)
            } else {
                ValidationResult(isValid = false, errorMessage = "$fieldName is required")
            }
        }
        val value = trimmed.toDoubleOrNull()
            ?: return ValidationResult(isValid = false, errorMessage = "Enter a valid decimal number")

        if (value < 0.0) {
            return ValidationResult(isValid = false, errorMessage = "$fieldName cannot be negative")
        }
        return ValidationResult(isValid = true)
    }

    // --- Core Calculation Formulas ---

    /**
     * WITHDRAWAL FORMULA:
     * Platform Fee = Withdrawal Amount * Platform Fee Percentage / 100
     * Commission Received = Withdrawal Amount * Commission Percentage / 100
     * Customer Payout = Withdrawal Amount - Platform Fee - Transaction Charge
     *
     * PROFIT RULE:
     * Commission received and transaction charge deducted are the profit to the business.
     * Since the platform fee is already deducted from the customer payout, the customer
     * bears the platform fee.
     *
     * Estimated Gross Profit:
     *   If retainChargeAsIncome: Commission Received + Transaction Charge
     *   Else: Commission Received
     * Estimated Net Profit = Gross Profit - Other Business Costs
     */
    fun calculateWithdrawal(
        amount: Double,
        platformFeePercent: Double,
        commissionPercent: Double,
        transactionCharge: Double,
        otherCosts: Double,
        retainChargeAsIncome: Boolean = true
    ): WithdrawalCalculationResult {
        val amt = BigDecimal.valueOf(amount)
        val pFeePct = BigDecimal.valueOf(platformFeePercent).divide(BigDecimal(100), 6, RoundingMode.HALF_UP)
        val commPct = BigDecimal.valueOf(commissionPercent).divide(BigDecimal(100), 6, RoundingMode.HALF_UP)
        val txCharge = BigDecimal.valueOf(transactionCharge)
        val other = BigDecimal.valueOf(otherCosts)

        val platformFee = amt.multiply(pFeePct).setScale(2, RoundingMode.HALF_UP)
        val commission = amt.multiply(commPct).setScale(2, RoundingMode.HALF_UP)

        // Customer payout: Amount - Platform Fee - Transaction Charge
        val customerPayout = amt.subtract(platformFee).subtract(txCharge).setScale(2, RoundingMode.HALF_UP)

        // Gross Profit: Commission Received + Transaction Charge Deducted
        val grossProfit = if (retainChargeAsIncome) {
            commission.add(txCharge).setScale(2, RoundingMode.HALF_UP)
        } else {
            commission.setScale(2, RoundingMode.HALF_UP)
        }

        // Net Profit: Gross Profit - Other Business Costs
        val netProfit = grossProfit.subtract(other).setScale(2, RoundingMode.HALF_UP)

        return WithdrawalCalculationResult(
            withdrawalAmount = roundToTwoDecimals(amount),
            platformFeePercent = roundToFourDecimals(platformFeePercent),
            platformFeeAmount = platformFee.toDouble(),
            commissionPercent = roundToFourDecimals(commissionPercent),
            commissionAmount = commission.toDouble(),
            transactionCharge = txCharge.setScale(2, RoundingMode.HALF_UP).toDouble(),
            otherCosts = other.setScale(2, RoundingMode.HALF_UP).toDouble(),
            customerPayout = customerPayout.toDouble(),
            grossProfit = grossProfit.toDouble(),
            netProfit = netProfit.toDouble()
        )
    }

    /**
     * BILL PAYMENT FORMULA:
     * Platform Fee = Bill Amount * Platform Fee % / 100 (or manual fee)
     * Service Charge = Bill Amount * Service Charge % / 100
     * Total Customer Charge = Platform Fee + Service Charge
     * Total Customer Charge % = Platform Fee % + Service Charge %
     * Commission Received = Bill Amount * Commission % / 100 (always on bill amount!)
     * Gross Profit = Service Charge + Commission Received
     * Net Profit = Gross Profit - Other Costs
     */
    fun calculateBillPayment(
        billAmount: Double,
        platformFeePercent: Double,
        isManualFee: Boolean,
        manualPlatformFee: Double,
        serviceChargePercent: Double,
        commissionPercent: Double,
        otherCosts: Double
    ): BillPaymentCalculationResult {
        val amt = BigDecimal.valueOf(billAmount)
        val servPct = BigDecimal.valueOf(serviceChargePercent).divide(BigDecimal(100), 6, RoundingMode.HALF_UP)
        val commPct = BigDecimal.valueOf(commissionPercent).divide(BigDecimal(100), 6, RoundingMode.HALF_UP)
        val other = BigDecimal.valueOf(otherCosts)

        val platformFee = if (isManualFee) {
            BigDecimal.valueOf(manualPlatformFee).setScale(2, RoundingMode.HALF_UP)
        } else {
            val pFeePct = BigDecimal.valueOf(platformFeePercent).divide(BigDecimal(100), 6, RoundingMode.HALF_UP)
            amt.multiply(pFeePct).setScale(2, RoundingMode.HALF_UP)
        }

        val effectivePlatformFeePercent = if (isManualFee && billAmount > 0.0) {
            platformFee.divide(amt, 6, RoundingMode.HALF_UP).multiply(BigDecimal(100)).toDouble()
        } else {
            platformFeePercent
        }

        val serviceCharge = amt.multiply(servPct).setScale(2, RoundingMode.HALF_UP)
        val totalCustomerCharge = platformFee.add(serviceCharge).setScale(2, RoundingMode.HALF_UP)
        val totalCustomerChargePercent = roundToTwoDecimals(effectivePlatformFeePercent + serviceChargePercent)

        // Commission on Bill Amount
        val commission = amt.multiply(commPct).setScale(2, RoundingMode.HALF_UP)

        // Estimated Gross Profit = Service Charge + Commission
        val grossProfit = serviceCharge.add(commission).setScale(2, RoundingMode.HALF_UP)

        // Net Profit = Gross Profit - Other Costs
        val netProfit = grossProfit.subtract(other).setScale(2, RoundingMode.HALF_UP)

        return BillPaymentCalculationResult(
            billAmount = roundToTwoDecimals(billAmount),
            platformFeePercent = roundToFourDecimals(effectivePlatformFeePercent),
            platformFeeAmount = platformFee.toDouble(),
            isManualFee = isManualFee,
            serviceChargePercent = roundToFourDecimals(serviceChargePercent),
            serviceChargeAmount = serviceCharge.toDouble(),
            totalCustomerCharge = totalCustomerCharge.toDouble(),
            totalCustomerChargePercent = totalCustomerChargePercent,
            commissionPercent = roundToFourDecimals(commissionPercent),
            commissionAmount = commission.toDouble(),
            otherCosts = other.setScale(2, RoundingMode.HALF_UP).toDouble(),
            grossProfit = grossProfit.toDouble(),
            netProfit = netProfit.toDouble()
        )
    }
}
