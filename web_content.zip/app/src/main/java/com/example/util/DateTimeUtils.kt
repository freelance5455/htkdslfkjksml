package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateTimeUtils {

    private val dayMap = mapOf(
        Calendar.SUNDAY to "الأحد",
        Calendar.MONDAY to "الإثنين",
        Calendar.TUESDAY to "الثلاثاء",
        Calendar.WEDNESDAY to "الأربعاء",
        Calendar.THURSDAY to "الخميس",
        Calendar.FRIDAY to "الجمعة",
        Calendar.SATURDAY to "السبت"
    )

    fun todayArabicDayName(): String {
        val cal = Calendar.getInstance()
        return dayMap[cal.get(Calendar.DAY_OF_WEEK)] ?: "السبت"
    }

    fun todayArabicFullDate(): String {
        return try {
            SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar", "EG")).format(Date())
        } catch (_: Exception) {
            todayArabicDayName()
        }
    }

    fun todayIsoKey(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    fun parseTo24h(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val s = raw.trim()
        if (Regex("^\\d{2}:\\d{2}$").matches(s)) return s
        val match = Regex("(\\d{1,2}):(\\d{2})").find(s) ?: return ""
        var h = match.groupValues[1].toIntOrNull() ?: return ""
        val m = match.groupValues[2]
        if ((s.contains("مساء") || s.contains("م")) && h < 12) h += 12
        if ((s.contains("صباح") || s.contains("ص")) && h == 12) h = 0
        return String.format(Locale.US, "%02d:%s", h.coerceIn(0, 23), m)
    }

    fun formatTime12h(raw: String?): String {
        val t24 = parseTo24h(raw)
        if (t24.isEmpty()) return raw.orEmpty()
        val parts = t24.split(":")
        val h24 = parts.getOrNull(0)?.toIntOrNull() ?: return t24
        val mins = parts.getOrNull(1) ?: "00"
        val period = if (h24 >= 12) "م" else "ص"
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        return "$h12:$mins $period"
    }

    fun countdownToExam(examDateIso: String): Pair<Long, Long> {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            val target = sdf.parse("$examDateIso 09:00:00") ?: return 0L to 0L
            val diff = (target.time - System.currentTimeMillis()).coerceAtLeast(0L)
            val days = diff / 86_400_000L
            val hours = (diff / 3_600_000L) % 24L
            days to hours
        } catch (_: Exception) {
            0L to 0L
        }
    }

    fun formatCountdownTimer(seconds: Int): String {
        val m = seconds / 60
        val s = seconds % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }
}
