package com.example.util

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs

object SoundPlayer {

    suspend fun playSuccessChime() = withContext(Dispatchers.Default) {
        try {
            val sampleRate = 22050
            val freqs = doubleArrayOf(523.25, 659.25, 783.99, 1046.5)
            val noteStepSamples = (sampleRate * 0.08).toInt()
            val noteDurSamples = (sampleRate * 0.30).toInt()
            val totalSamples = noteStepSamples * (freqs.size - 1) + noteDurSamples
            val mix = DoubleArray(totalSamples)

            freqs.forEachIndexed { idx, freq ->
                val start = idx * noteStepSamples
                for (i in 0 until noteDurSamples) {
                    val t = i.toDouble() / sampleRate
                    val env = (1.0 - (i.toDouble() / noteDurSamples)) * 0.14
                    val phase = (t * freq) % 1.0
                    val tri = 4.0 * abs(phase - 0.5) - 1.0
                    mix[start + i] += tri * env
                }
            }

            val pcm = ShortArray(totalSamples) { i ->
                (mix[i].coerceIn(-1.0, 1.0) * Short.MAX_VALUE).toInt().toShort()
            }

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(pcm, 0, pcm.size)
            track.play()
            kotlinx.coroutines.delay(650)
            track.stop()
            track.release()
        } catch (_: Exception) {
            // Audio unavailable on device/test environment
        }
    }
}
