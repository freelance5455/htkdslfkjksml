package com.example.util

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.core.graphics.createBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class PdfDocumentHolder(val file: File) : AutoCloseable {
    private var fileDescriptor: ParcelFileDescriptor? = null
    private var pdfRenderer: PdfRenderer? = null
    val pageCount: Int

    init {
        val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        fileDescriptor = pfd
        val renderer = PdfRenderer(pfd)
        pdfRenderer = renderer
        pageCount = renderer.pageCount
    }

    suspend fun renderPage(pageIndex: Int, targetWidth: Int = 1080): ImageBitmap? =
        withContext(Dispatchers.IO) {
            val renderer = pdfRenderer ?: return@withContext null
            if (pageIndex < 0 || pageIndex >= pageCount) return@withContext null

            synchronized(renderer) {
                var page: PdfRenderer.Page? = null
                try {
                    page = renderer.openPage(pageIndex)
                    val originalWidth = page.width
                    val originalHeight = page.height
                    val scale = targetWidth.toFloat() / originalWidth.toFloat()
                    val targetHeight = (originalHeight * scale).toInt().coerceAtLeast(1)

                    val bitmap = createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                    val canvas = android.graphics.Canvas(bitmap)
                    canvas.drawColor(Color.WHITE)

                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmap.asImageBitmap()
                } catch (e: Exception) {
                    e.printStackTrace()
                    null
                } finally {
                    page?.close()
                }
            }
        }

    override fun close() {
        try {
            pdfRenderer?.close()
            pdfRenderer = null
            fileDescriptor?.close()
            fileDescriptor = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
