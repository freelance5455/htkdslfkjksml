package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream

object AppDistributionHelper {
    const val DESKTOP_WEB_URL = "https://ais-pre-f4kouvh7kdud2cwfpehhmh-333293443408.us-west2.run.app"

    fun getAppVersionLabel(): String =
        "نسخه ${BuildConfig.VERSION_NAME.toPersianDigits()} (بیلد ${BuildConfig.VERSION_CODE.toPersianDigits()})"

    fun getInstalledApkSizeLabel(context: Context): String {
        val path = context.applicationInfo.publicSourceDir ?: context.applicationInfo.sourceDir ?: return "نامشخص"
        val file = File(path)
        if (!file.exists()) return "نامشخص"
        val mb = file.length().toDouble() / (1024.0 * 1024.0)
        return "${String.format("%.1f", mb).toPersianDigits()} مگابایت"
    }

    fun suggestedApkFileName(): String = "ProzheYar-v${BuildConfig.VERSION_NAME}.apk"

    fun suggestedWebsiteFileName(): String = "ProzheYar-Website.html"

    suspend fun copyBundledWebsiteToUri(context: Context, destinationUri: Uri): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                context.assets.open("website/index.html").use { input ->
                    context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                        input.copyTo(output, bufferSize = 32 * 1024)
                    } ?: return@withContext Result.failure(IllegalStateException("امکان ذخیره فایل سایت وجود ندارد"))
                }
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun copyInstalledApkToUri(context: Context, destinationUri: Uri): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val apkPath = context.applicationInfo.publicSourceDir ?: context.applicationInfo.sourceDir
                    ?: return@withContext Result.failure(IllegalStateException("فایل APK در مسیر نصب یافت نشد"))
                val sourceFile = File(apkPath)
                if (!sourceFile.exists()) {
                    return@withContext Result.failure(IllegalStateException("فایل APK قابل دسترس نیست"))
                }
                context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                    FileInputStream(sourceFile).use { input ->
                        input.copyTo(output, bufferSize = 64 * 1024)
                    }
                } ?: return@withContext Result.failure(IllegalStateException("امکان نوشتن فایل وجود ندارد"))
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun createShareApkIntent(context: Context): Result<Intent> =
        withContext(Dispatchers.IO) {
            try {
                val apkPath = context.applicationInfo.publicSourceDir ?: context.applicationInfo.sourceDir
                    ?: return@withContext Result.failure(IllegalStateException("فایل APK یافت نشد"))
                val sourceFile = File(apkPath)
                val cacheDir = File(context.cacheDir, "apk").apply { mkdirs() }
                val cachedApk = File(cacheDir, suggestedApkFileName())
                sourceFile.copyTo(cachedApk, overwrite = true)

                val contentUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    cachedApk
                )
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/vnd.android.package-archive"
                    putExtra(Intent.EXTRA_STREAM, contentUri)
                    putExtra(Intent.EXTRA_SUBJECT, "اپلیکیشن مدیریت پروژه پروژه‌یار")
                    putExtra(
                        Intent.EXTRA_TEXT,
                        "اپلیکیشن مدیریت پروژه «پروژه‌یار» (${getAppVersionLabel()})\nنسخه وب و دسکتاپ:\n$DESKTOP_WEB_URL"
                    )
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                Result.success(Intent.createChooser(shareIntent, "ارسال فایل APK پروژه‌یار"))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
