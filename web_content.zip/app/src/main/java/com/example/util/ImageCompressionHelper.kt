package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Base64
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.data.model.MediaChunk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

data class PreparedArkVideo(
    val thumbnailBase64: String,
    val durationMs: Long,
    val chunksBase64: List<String>,
    val localPreviewFile: File
)

object ImageCompressionHelper {
    suspend fun compressUriToBase64(
        context: Context,
        uri: Uri,
        maxDim: Int = 240,
        maxBytes: Int = 48_000
    ): String? = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
            val original = inputStream.use { BitmapFactory.decodeStream(it) } ?: return@withContext null
            compressBitmapToBase64(original, maxDim = maxDim, maxBytes = maxBytes, recycleInput = true)
        } catch (_: Exception) {
            null
        }
    }

    fun compressBitmapToBase64(
        original: Bitmap,
        maxDim: Int = 480,
        maxBytes: Int = 45_000,
        recycleInput: Boolean = false
    ): String? {
        return try {
            val scale = minOf(
                maxDim.toFloat() / original.width.coerceAtLeast(1),
                maxDim.toFloat() / original.height.coerceAtLeast(1),
                1f
            )
            val targetW = (original.width * scale).toInt().coerceAtLeast(1)
            val targetH = (original.height * scale).toInt().coerceAtLeast(1)
            val scaled = if (targetW != original.width || targetH != original.height) {
                Bitmap.createScaledBitmap(original, targetW, targetH, true)
            } else {
                original
            }

            var quality = 74
            var bytes: ByteArray
            do {
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, out)
                bytes = out.toByteArray()
                quality -= 12
            } while (bytes.size > maxBytes && quality >= 24)

            if (scaled != original) scaled.recycle()
            if (recycleInput) original.recycle()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (_: Exception) {
            null
        }
    }

    private val decodedImageCache = object : LruCache<String, ImageBitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ImageBitmap): Int {
            return (value.width * value.height * 4).coerceAtLeast(1)
        }
    }

    private fun cacheKey(base64: String): String =
        "${base64.length}_${base64.hashCode()}_${base64.take(16)}"

    fun getCachedImageBitmap(base64: String?): ImageBitmap? {
        if (base64.isNullOrBlank()) return null
        return decodedImageCache.get(cacheKey(base64))
    }

    fun decodeBase64ToBitmap(base64: String?): Bitmap? {
        if (base64.isNullOrBlank()) return null
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }

    suspend fun decodeBase64ToImageBitmapAsync(base64: String?): ImageBitmap? {
        if (base64.isNullOrBlank()) return null
        val key = cacheKey(base64)
        decodedImageCache.get(key)?.let { return it }
        return withContext(Dispatchers.Default) {
            decodedImageCache.get(key)?.let { return@withContext it }
            val imgBmp = decodeBase64ToBitmap(base64)?.asImageBitmap()
            if (imgBmp != null) {
                decodedImageCache.put(key, imgBmp)
            }
            imgBmp
        }
    }

    suspend fun extractVideoForArk(
        context: Context,
        uri: Uri,
        maxSizeBytes: Int = 7_200_000,
        chunkSizeBytes: Int = 480_000,
        maxChunks: Int = 16
    ): Result<PreparedArkVideo> = withContext(Dispatchers.IO) {
        runCatching {
            val cutoffMs = System.currentTimeMillis() - 30 * 60 * 1000L
            context.cacheDir.listFiles { file ->
                file.name.startsWith("ark_preview_") && file.name.endsWith(".mp4") && file.lastModified() < cutoffMs
            }?.forEach { runCatching { it.delete() } }

            val declaredLength = runCatching {
                context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            }.getOrDefault(-1L)
            if (declaredLength > maxSizeBytes.toLong()) {
                val sizeMb = String.format(java.util.Locale.US, "%.1f", declaredLength / (1024.0 * 1024.0))
                val capMb = String.format(java.util.Locale.US, "%.1f", maxSizeBytes / (1024.0 * 1024.0))
                throw IllegalArgumentException("Video is $sizeMb MB. Please pick a short clip under $capMb MB.")
            }

            val previewFile = File(context.cacheDir, "ark_preview_${System.currentTimeMillis()}.mp4")
            var totalBytes = 0L
            try {
                val input = context.contentResolver.openInputStream(uri)
                    ?: throw IllegalStateException("Unable to read selected video.")
                input.use { stream ->
                    previewFile.outputStream().use { out ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = stream.read(buffer)
                            if (read <= 0) break
                            totalBytes += read
                            if (totalBytes > maxSizeBytes.toLong()) {
                                val capMb = String.format(java.util.Locale.US, "%.1f", maxSizeBytes / (1024.0 * 1024.0))
                                throw IllegalArgumentException("Video is too large. Please pick a short clip under $capMb MB.")
                            }
                            out.write(buffer, 0, read)
                        }
                    }
                }
            } catch (t: Throwable) {
                runCatching { previewFile.delete() }
                throw t
            }

            require(totalBytes > 0L) {
                runCatching { previewFile.delete() }
                "Selected video is empty."
            }

            val retriever = MediaMetadataRetriever()
            var durationMs = 0L
            var thumbBase64: String? = null
            try {
                val sourceSet = runCatching { retriever.setDataSource(previewFile.absolutePath) }.isSuccess ||
                    runCatching { retriever.setDataSource(context, uri) }.isSuccess
                if (sourceSet) {
                    durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                        ?.toLongOrNull()
                        ?.coerceIn(0L, 60_000L) ?: 0L
                    val frame = runCatching {
                        retriever.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.getFrameAtTime(500_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.getFrameAtTime(-1L)
                    }.getOrNull()
                    if (frame != null) {
                        thumbBase64 = compressBitmapToBase64(frame, maxDim = 480, maxBytes = 42_000, recycleInput = true)
                    }
                }
            } finally {
                runCatching { retriever.release() }
            }

            val finalThumb = thumbBase64?.takeIf { it.isNotBlank() } ?: run {
                val fallback = Bitmap.createBitmap(160, 90, Bitmap.Config.ARGB_8888)
                fallback.eraseColor(android.graphics.Color.rgb(16, 28, 56))
                compressBitmapToBase64(fallback, maxDim = 160, maxBytes = 10_000, recycleInput = true) ?: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
            }

            val chunks = ArrayList<String>()
            previewFile.inputStream().use { fis ->
                val sliceBuf = ByteArray(chunkSizeBytes)
                while (chunks.size < maxChunks) {
                    var filled = 0
                    while (filled < chunkSizeBytes) {
                        val n = fis.read(sliceBuf, filled, chunkSizeBytes - filled)
                        if (n <= 0) break
                        filled += n
                    }
                    if (filled <= 0) break
                    chunks.add(Base64.encodeToString(sliceBuf, 0, filled, Base64.NO_WRAP))
                }
            }
            require(chunks.isNotEmpty()) { "Could not encode video chunks." }

            PreparedArkVideo(
                thumbnailBase64 = finalThumb,
                durationMs = durationMs,
                chunksBase64 = chunks,
                localPreviewFile = previewFile
            )
        }
    }

    suspend fun reconstructVideoToCache(
        context: Context,
        cacheKey: String,
        chunks: List<MediaChunk>
    ): File? = withContext(Dispatchers.IO) {
        try {
            val outFile = File(context.cacheDir, "ark_media_${cacheKey.replace(Regex("[^a-zA-Z0-9_-]"), "_")}.mp4")
            if (outFile.exists() && outFile.length() > 0L) return@withContext outFile
            val sorted = chunks.sortedBy { it.index }
            if (sorted.isEmpty()) return@withContext null
            val stream = ByteArrayOutputStream()
            sorted.forEach { chunk ->
                if (chunk.dataBase64.isNotBlank()) {
                    stream.write(Base64.decode(chunk.dataBase64, Base64.NO_WRAP))
                }
            }
            val bytes = stream.toByteArray()
            if (bytes.isEmpty()) return@withContext null
            outFile.writeBytes(bytes)
            outFile
        } catch (_: Exception) {
            null
        }
    }
}

@Composable
fun rememberDecodedImageBitmap(base64: String?): ImageBitmap? {
    val cached = if (base64.isNullOrBlank()) null else ImageCompressionHelper.getCachedImageBitmap(base64)
    val state by produceState(initialValue = cached, key1 = base64) {
        if (base64.isNullOrBlank()) {
            value = null
        } else if (value == null) {
            value = ImageCompressionHelper.decodeBase64ToImageBitmapAsync(base64)
        }
    }
    return state
}

