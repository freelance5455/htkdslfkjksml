package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID

data class Model3dAsset(
    val id: String,
    val fileName: String,
    val format: String,
    val sizeBytes: Long,
    val mimeType: String,
    val boundsText: String = "",
    val minY: Float? = null,
    val meshes: List<String> = emptyList(),
    val animations: List<String> = emptyList(),
    val vertices: Int = 0,
    val triangles: Int = 0,
    val localPath: String = ""
) {
    fun shortLabel(): String {
        val sizeStr = formatBytes(sizeBytes)
        return if (boundsText.isNotBlank()) "$format • $sizeStr • $boundsText" else "$format • $sizeStr"
    }

    companion object {
        fun formatBytes(bytes: Long): String = when {
            bytes < 1024L -> "$bytes B"
            bytes < 1024L * 1024L -> String.format("%.1f KB", bytes / 1024.0)
            else -> String.format("%.2f MB", bytes / (1024.0 * 1024.0))
        }
    }
}

object Model3dHelper {
    private val ALLOWED_EXTS = setOf("glb", "gltf", "obj", "stl")
    private const val MAX_FILE_BYTES = 20L * 1024L * 1024L

    fun isSupportedExtension(fileName: String): Boolean {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return ext in ALLOWED_EXTS
    }

    fun resolveDisplayName(context: Context, uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) name = cursor.getString(idx)
                }
            }
        } catch (_: Exception) {
        }
        return name?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/')
            ?: "model_${System.currentTimeMillis()}.glb"
    }

    fun importFromUri(
        context: Context,
        uri: Uri,
        conversationKey: String
    ): Result<Model3dAsset> {
        val fileName = resolveDisplayName(context, uri)
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext !in ALLOWED_EXTS) {
            return Result.failure(IllegalArgumentException("Desteklenen 3D formatlar: .glb, .gltf, .obj, .stl"))
        }

        val bytes = try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val data = stream.readBytes()
                if (data.size > MAX_FILE_BYTES) {
                    return Result.failure(IllegalArgumentException("3D model dosyası 20 MB sınırını aşıyor."))
                }
                data
            } ?: return Result.failure(IllegalStateException("3D model dosyası okunamadı."))
        } catch (e: Exception) {
            return Result.failure(e)
        }

        val dir = modelsDir(context, conversationKey)
        dir.mkdirs()
        val safeName = fileName.replace(Regex("[^a-zA-Z0-9._\\-]"), "_")
        val destFile = File(dir, safeName)
        destFile.writeBytes(bytes)

        val asset = inspectBytes(
            id = "m3d_${UUID.randomUUID().toString().take(8)}",
            fileName = fileName,
            bytes = bytes,
            localPath = destFile.absolutePath
        )
        saveAssetMeta(dir, asset)
        return Result.success(asset)
    }

    fun loadModelsForConversation(context: Context, conversationKey: String): List<Model3dAsset> {
        val dir = modelsDir(context, conversationKey)
        if (!dir.exists()) return emptyList()
        val metaFile = File(dir, "_meta.json")
        if (!metaFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(metaFile.readText())
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                val localPath = obj.optString("localPath", "")
                if (localPath.isBlank() || !File(localPath).exists()) return@mapNotNull null
                Model3dAsset(
                    id = obj.optString("id"),
                    fileName = obj.optString("fileName"),
                    format = obj.optString("format"),
                    sizeBytes = obj.optLong("sizeBytes"),
                    mimeType = obj.optString("mimeType"),
                    boundsText = obj.optString("boundsText", ""),
                    minY = if (obj.has("minY")) obj.optDouble("minY").toFloat() else null,
                    meshes = jsonArrayToStrings(obj.optJSONArray("meshes")),
                    animations = jsonArrayToStrings(obj.optJSONArray("animations")),
                    vertices = obj.optInt("vertices", 0),
                    triangles = obj.optInt("triangles", 0),
                    localPath = localPath
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun attachAssetsToConversation(
        context: Context,
        assets: List<Model3dAsset>,
        conversationKey: String
    ): List<Model3dAsset> {
        if (assets.isEmpty()) return loadModelsForConversation(context, conversationKey)
        val dir = modelsDir(context, conversationKey)
        dir.mkdirs()
        assets.forEach { asset ->
            val src = File(asset.localPath)
            val dest = File(dir, src.name.ifBlank { asset.fileName })
            if (src.exists() && src.absolutePath != dest.absolutePath) {
                src.copyTo(dest, overwrite = true)
            }
            saveAssetMeta(dir, asset.copy(localPath = dest.absolutePath))
        }
        return loadModelsForConversation(context, conversationKey)
    }

    fun deleteAsset(context: Context, conversationKey: String, assetId: String): List<Model3dAsset> {
        val dir = modelsDir(context, conversationKey)
        val existing = loadModelsForConversation(context, conversationKey)
        val target = existing.firstOrNull { it.id == assetId }
        if (target != null && target.localPath.isNotBlank()) {
            runCatching { File(target.localPath).delete() }
        }
        val remaining = existing.filterNot { it.id == assetId }
        writeMetaArray(dir, remaining)
        return remaining
    }

    fun readBase64(asset: Model3dAsset): String? {
        val file = File(asset.localPath)
        if (!file.exists()) return null
        return runCatching {
            Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        }.getOrNull()
    }

    fun buildModels3dPromptContext(models: List<Model3dAsset>): String {
        if (models.isEmpty()) return ""
        val listText = models.mapIndexed { idx, m ->
            buildString {
                append("${idx + 1}. Dosya: \"${m.fileName}\" | Format: ${m.format}")
                if (m.boundsText.isNotBlank()) append(" | Boyut(G×Y×D): ${m.boundsText}")
                if (m.minY != null) append(", minY: ${m.minY}")
                if (m.meshes.isNotEmpty()) append(" | Meshler: [${m.meshes.joinToString(", ")}]")
                if (m.animations.isNotEmpty()) append(" | Animasyonlar: [${m.animations.joinToString(", ")}]")
            }
        }.joinToString("\n")

        val sampleName = models.first().fileName
        val sOpen = "<" + "script"
        val sClose = "<" + "/script>"
        return """
            |
            |[EKLİ 3D MODEL VARLIKLARI - KULLANICININ YÜKLEDİĞİ MODELLER]
            |$listText
            |
            |3D MODEL ENTEGRASYON KURALLARI (ZORUNLU):
            |1) Kullanıcı bu modelleri bir oyuna, sahneye veya koda koymanı istediğinde ASLA model yerine basit küp/küre çizip geçme; mutlaka kullanıcının yüklediği gerçek modeli yükle.
            |2) HTML / Three.js oyun veya 3D sahne üretirken:
            |   - Tek dosya çalışabilir ```html yaz: $sOpen src="https://cdn.jsdelivr.net/npm/three@0.147.0/build/three.min.js">$sClose ve formatına göre GLTFLoader.js / OBJLoader.js / STLLoader.js + OrbitControls.js ekle.
            |   - Yükleyiciye dosya yolu olarak TAM OLARAK "{{MERKOP_MODEL:dosya_adi}}" ver (ör: loader.load("{{MERKOP_MODEL:$sampleName}}", ...)). Merkop canlı önizlemesi bunu otomatik olarak gerçek 3D modele bağlar!
            |   - Yüklenen modeli THREE.Box3().setFromObject(model) ile otomatik ölçekleyip ortala ve tabanını zemine (y = 0) hizala; animasyon varsa THREE.AnimationMixer ile oynat.
            |3) Python (Ursina/Panda3D/Pygame), Unity (C#) veya Godot (GDScript) kodu yazıyorsan dosya yolunu "models/dosya_adi" olarak ver.
        """.trimMargin()
    }

    fun inject3dModelsIntoHtml(rawHtml: String, models: List<Model3dAsset>): String {
        if (models.isEmpty()) return rawHtml
        val registry = JSONObject()
        var out = rawHtml
        for (m in models) {
            val b64 = readBase64(m) ?: continue
            val item = JSONObject().apply {
                put("mime", m.mimeType)
                put("b64", b64)
            }
            registry.put(m.fileName, item)
            val escaped = Regex.escape(m.fileName)
            out = out.replace(Regex("\\{\\{MERKOP_MODEL:$escaped\\}\\}", RegexOption.IGNORE_CASE), m.fileName)
        }
        val bridge = buildString {
            append("<script>(function(){")
            append("var M=").append(registry.toString()).append(";")
            append(
                """
                function lookupEntry(u){
                  if(!u)return null;
                  var s=String(u).split("?")[0].split("#")[0];
                  try{s=decodeURIComponent(s);}catch(e){}
                  var mm=s.match(/\{\{MERKOP_MODEL:([^}]+)\}\}/i);
                  if(mm&&M[mm[1].trim()])return {name:mm[1].trim(),item:M[mm[1].trim()]};
                  var base=s.replace(/^https?:\/\/[^\/]+\/__merkop_model__\//i,"").replace(/^\.\//,"").replace(/^models\//i,"").split("/").pop();
                  if(M[base])return {name:base,item:M[base]};
                  var keys=Object.keys(M);
                  for(var i=0;i<keys.length;i++){if(keys[i].toLowerCase()===base.toLowerCase())return {name:keys[i],item:M[keys[i]]};}
                  return null;
                }
                function lookup(u){var r=lookupEntry(u);return r?r.item:null;}
                function toBytes(b64){var bin=atob(b64),arr=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);return arr;}
                var OrigRequest=window.Request;
                if(typeof OrigRequest==="function"){
                  window.Request=function(input,init){
                    if(typeof input==="string"){
                      var e=lookupEntry(input);
                      if(e){input="https://merkop.local/__merkop_model__/"+encodeURIComponent(e.name);}
                    }
                    return new OrigRequest(input,init);
                  };
                  window.Request.prototype=OrigRequest.prototype;
                }
                var origFetch=window.fetch;
                window.fetch=function(input){
                  var url=(typeof input==="string")?input:(input&&input.url?input.url:"");
                  var hit=lookup(url);
                  if(hit){
                    var bytes=toBytes(hit.b64);
                    return Promise.resolve(new Response(bytes,{status:200,headers:{"Content-Type":hit.mime,"Content-Length":String(bytes.length)}}));
                  }
                  return origFetch.apply(this,arguments);
                };
                var origOpen=XMLHttpRequest.prototype.open;
                var origSend=XMLHttpRequest.prototype.send;
                XMLHttpRequest.prototype.open=function(m,url){this.__merkopHit=lookup(url);return origOpen.apply(this,arguments);};
                XMLHttpRequest.prototype.send=function(){
                  var hit=this.__merkopHit;
                  if(hit){
                    var self=this;
                    setTimeout(function(){
                      var bytes=toBytes(hit.b64);
                      var rt=self.responseType||"";
                      var val=bytes.buffer;
                      if(rt==="text"||rt==="")val=new TextDecoder().decode(bytes);
                      else if(rt==="blob")val=new Blob([bytes],{type:hit.mime});
                      else if(rt==="json"){try{val=JSON.parse(new TextDecoder().decode(bytes));}catch(e){}}
                      try{Object.defineProperty(self,"status",{configurable:true,get:function(){return 200;}});}catch(e){}
                      try{Object.defineProperty(self,"readyState",{configurable:true,get:function(){return 4;}});}catch(e){}
                      try{Object.defineProperty(self,"response",{configurable:true,get:function(){return val;}});}catch(e){}
                      if(rt===""||rt==="text"){try{Object.defineProperty(self,"responseText",{configurable:true,get:function(){return String(val);}});}catch(e){}}
                      if(typeof self.onreadystatechange==="function")self.onreadystatechange();
                      if(typeof self.onload==="function")self.onload({target:self,loaded:bytes.length,total:bytes.length,lengthComputable:true});
                      self.dispatchEvent(new Event("load"));
                    },0);
                    return;
                  }
                  return origSend.apply(this,arguments);
                };
                """.trimIndent()
            )
            append("})();</script>")
        }
        val headMatch = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(out)
        return if (headMatch != null) {
            val insertPos = headMatch.range.last + 1
            out.substring(0, insertPos) + bridge + out.substring(insertPos)
        } else {
            bridge + out
        }
    }

    fun buildPlayable3dGameHtml(asset: Model3dAsset): String {
        val ext = asset.format.lowercase()
        val loaderFile = when (ext) {
            "obj" -> "OBJLoader.js"
            "stl" -> "STLLoader.js"
            else -> "GLTFLoader.js"
        }
        val escapedName = JSONObject.quote("{{MERKOP_MODEL:${asset.fileName}}}")
        val displayTitle = HtmlEscaper.escape(asset.fileName)
        return """
            <!DOCTYPE html>
            <html lang="tr">
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
              <title>$displayTitle — Merkop 3D Arena</title>
              <style>
                html,body{margin:0;height:100%;overflow:hidden;background:#16100D;font-family:sans-serif;color:#fff;touch-action:none;user-select:none;}
                #hud{position:fixed;top:12px;left:12px;right:12px;display:flex;justify-content:space-between;align-items:center;pointer-events:none;z-index:10;}
                .pill{background:rgba(255,107,0,0.92);color:#fff;padding:7px 13px;border-radius:999px;font-size:13px;font-weight:800;box-shadow:0 4px 12px rgba(0,0,0,0.35);}
                #joy{position:fixed;bottom:22px;left:22px;width:112px;height:112px;border-radius:50%;background:rgba(255,255,255,0.12);border:2px solid rgba(255,107,0,0.7);z-index:10;touch-action:none;}
                #knob{position:absolute;left:50%;top:50%;width:44px;height:44px;margin:-22px 0 0 -22px;border-radius:50%;background:#FF6B00;box-shadow:0 4px 10px rgba(0,0,0,0.4);}
                #jumpBtn{position:fixed;bottom:34px;right:24px;width:76px;height:76px;border-radius:50%;border:2px solid #fff;background:#FF6B00;color:#fff;font-weight:800;font-size:13px;z-index:10;box-shadow:0 6px 16px rgba(255,107,0,0.45);}
                #status{position:fixed;bottom:12px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,0.65);padding:5px 12px;border-radius:999px;font-size:11px;color:#FFD6B8;z-index:10;white-space:nowrap;}
              </style>
              <script src="https://cdn.jsdelivr.net/npm/three@0.147.0/build/three.min.js"></script>
              <script src="https://cdn.jsdelivr.net/npm/three@0.147.0/examples/js/loaders/$loaderFile"></script>
            </head>
            <body>
              <div id="hud">
                <div class="pill">🧊 $displayTitle</div>
                <div class="pill" id="scorePill">⭐ Skor: 0</div>
              </div>
              <div id="joy"><div id="knob"></div></div>
              <button id="jumpBtn">ZIPLA</button>
              <div id="status">Model yükleniyor...</div>
              <script>
                const scene = new THREE.Scene();
                scene.background = new THREE.Color(0x16100D);
                scene.fog = new THREE.Fog(0x16100D, 16, 48);
                const camera = new THREE.PerspectiveCamera(52, innerWidth / innerHeight, 0.1, 150);
                const renderer = new THREE.WebGLRenderer({ antialias: true });
                renderer.setSize(innerWidth, innerHeight);
                renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
                document.body.appendChild(renderer.domElement);

                scene.add(new THREE.AmbientLight(0xffffff, 0.75));
                const sun = new THREE.DirectionalLight(0xffffff, 1.15);
                sun.position.set(8, 16, 10);
                scene.add(sun);
                scene.add(new THREE.GridHelper(60, 40, 0xff6b00, 0x3b2c24));

                const playerPivot = new THREE.Group();
                scene.add(playerPivot);
                let mixer = null;
                let vy = 0, grounded = true, score = 0;

                function mountLoaded(obj) {
                  const box = new THREE.Box3().setFromObject(obj);
                  const sz = box.getSize(new THREE.Vector3());
                  const mDim = Math.max(sz.x, sz.y, sz.z) || 1;
                  obj.scale.multiplyScalar(2.4 / mDim);
                  const box2 = new THREE.Box3().setFromObject(obj);
                  const c = box2.getCenter(new THREE.Vector3());
                  obj.position.x -= c.x; obj.position.z -= c.z; obj.position.y -= box2.min.y;
                  playerPivot.add(obj);
                  document.getElementById("status").textContent = "Hareket: Joystick / WASD • Kristalleri Topla!";
                }

                const modelUrl = $escapedName;
                const ext = ${JSONObject.quote(ext)};
                if (ext === "obj") {
                  new THREE.OBJLoader().load(modelUrl, mountLoaded, undefined, e => { document.getElementById("status").textContent = "Hata: " + e; });
                } else if (ext === "stl") {
                  new THREE.STLLoader().load(modelUrl, g => { g.computeVertexNormals(); mountLoaded(new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: 0xff7b1c, roughness: 0.4 }))); });
                } else {
                  new THREE.GLTFLoader().load(modelUrl, gltf => {
                    if (gltf.animations && gltf.animations.length) { mixer = new THREE.AnimationMixer(gltf.scene); gltf.animations.forEach(c => mixer.clipAction(c).play()); }
                    mountLoaded(gltf.scene);
                  }, undefined, e => { document.getElementById("status").textContent = "GLTF Hatası: " + e; });
                }

                const gems = [];
                const gemGeo = new THREE.OctahedronGeometry(0.45, 0);
                const gemMat = new THREE.MeshStandardMaterial({ color: 0xff852d, emissive: 0xff5500, emissiveIntensity: 0.45 });
                function spawnGem() {
                  const m = new THREE.Mesh(gemGeo, gemMat);
                  m.position.set((Math.random() - 0.5) * 26, 0.7, (Math.random() - 0.5) * 26);
                  scene.add(m); gems.push(m);
                }
                for (let i = 0; i < 8; i++) spawnGem();

                const keys = {};
                addEventListener("keydown", e => { keys[e.code] = true; if (e.code === "Space" && grounded) { vy = 0.24; grounded = false; } });
                addEventListener("keyup", e => { keys[e.code] = false; });

                let jx = 0, jy = 0;
                const joy = document.getElementById("joy"), knob = document.getElementById("knob");
                function updJoy(ev) {
                  const r = joy.getBoundingClientRect();
                  const t = ev.touches ? ev.touches[0] : ev;
                  let dx = (t.clientX - (r.left + r.width / 2)) / 36;
                  let dy = (t.clientY - (r.top + r.height / 2)) / 36;
                  const len = Math.hypot(dx, dy);
                  if (len > 1) { dx /= len; dy /= len; }
                  jx = dx; jy = dy;
                  knob.style.transform = `translate(${'$'}{dx * 32}px, ${'$'}{dy * 32}px)`;
                }
                joy.addEventListener("pointerdown", e => { joy.setPointerCapture(e.pointerId); updJoy(e); });
                joy.addEventListener("pointermove", e => { if (e.buttons || e.pointerType === "touch") updJoy(e); });
                joy.addEventListener("pointerup", () => { jx = 0; jy = 0; knob.style.transform = ""; });
                document.getElementById("jumpBtn").onclick = () => { if (grounded) { vy = 0.24; grounded = false; } };
                addEventListener("resize", () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });

                const clock = new THREE.Clock();
                (function loop() {
                  requestAnimationFrame(loop);
                  const dt = Math.min(clock.getDelta(), 0.05);
                  if (mixer) mixer.update(dt);
                  let mx = jx + (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0);
                  let mz = jy + (keys.KeyS || keys.ArrowDown ? 1 : 0) - (keys.KeyW || keys.ArrowUp ? 1 : 0);
                  if (mx || mz) {
                    const ang = Math.atan2(mx, mz);
                    playerPivot.rotation.y = ang;
                    const mag = Math.min(1, Math.hypot(mx, mz));
                    playerPivot.position.x += (mx / (Math.hypot(mx, mz) || 1)) * mag * 7.5 * dt;
                    playerPivot.position.z += (mz / (Math.hypot(mx, mz) || 1)) * mag * 7.5 * dt;
                  }
                  if (!grounded) {
                    playerPivot.position.y += vy;
                    vy -= 0.012;
                    if (playerPivot.position.y <= 0) { playerPivot.position.y = 0; vy = 0; grounded = true; }
                  }
                  for (let i = gems.length - 1; i >= 0; i--) {
                    gems[i].rotation.y += 2.2 * dt;
                    if (gems[i].position.distanceTo(playerPivot.position) < 1.55) {
                      gems[i].position.set((Math.random() - 0.5) * 26, 0.7, (Math.random() - 0.5) * 26);
                      score += 10;
                      document.getElementById("scorePill").textContent = "⭐ Skor: " + score;
                    }
                  }
                  camera.position.lerp(new THREE.Vector3(playerPivot.position.x, playerPivot.position.y + 5.5, playerPivot.position.z + 8.5), 0.12);
                  camera.lookAt(playerPivot.position.x, playerPivot.position.y + 1.0, playerPivot.position.z);
                  renderer.render(scene, camera);
                })();
              </script>
            </body>
            </html>
        """.trimIndent()
    }

    private object HtmlEscaper {
        fun escape(s: String): String = s
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
    }

    fun buildModelViewerHtml(asset: Model3dAsset, base64Data: String): String {
        val ext = asset.format.lowercase()
        val loaderFile = when (ext) {
            "obj" -> "OBJLoader.js"
            "stl" -> "STLLoader.js"
            else -> "GLTFLoader.js"
        }
        return """
            <!DOCTYPE html>
            <html>
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width,initial-scale=1">
              <style>
                html,body{margin:0;height:100%;overflow:hidden;background:#1B1512;font-family:sans-serif;color:#fff;}
                #hud{position:fixed;top:10px;left:10px;display:flex;gap:6px;z-index:5;}
                button{background:#FF6B00;color:#fff;border:none;border-radius:8px;padding:7px 11px;font-size:12px;font-weight:700;}
                #msg{position:fixed;bottom:12px;left:12px;background:rgba(0,0,0,0.65);padding:6px 10px;border-radius:8px;font-size:12px;color:#FFD6B8;}
              </style>
              <script src="https://cdn.jsdelivr.net/npm/three@0.147.0/build/three.min.js"></script>
              <script src="https://cdn.jsdelivr.net/npm/three@0.147.0/examples/js/controls/OrbitControls.js"></script>
              <script src="https://cdn.jsdelivr.net/npm/three@0.147.0/examples/js/loaders/$loaderFile"></script>
            </head>
            <body>
              <div id="hud">
                <button id="rotBtn">↻ Oto-Dönüş: Açık</button>
                <button id="wireBtn">◇ Tel Kafes</button>
              </div>
              <div id="msg">Model yükleniyor…</div>
              <script>
                var b64=${JSONObject.quote(base64Data)};
                var ext=${JSONObject.quote(ext)};
                function b64ToBuf(s){var bin=atob(s),a=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return a.buffer;}
                var scene=new THREE.Scene();scene.background=new THREE.Color(0x1B1512);
                var camera=new THREE.PerspectiveCamera(48,innerWidth/innerHeight,0.01,2000);
                var renderer=new THREE.WebGLRenderer({antialias:true});renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,2));document.body.appendChild(renderer.domElement);
                var controls=new THREE.OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.autoRotate=true;controls.autoRotateSpeed=2.2;
                scene.add(new THREE.AmbientLight(0xffffff,0.85));
                var dl=new THREE.DirectionalLight(0xffffff,1.1);dl.position.set(5,10,7);scene.add(dl);
                var dl2=new THREE.DirectionalLight(0xff852d,0.55);dl2.position.set(-5,4,-6);scene.add(dl2);
                scene.add(new THREE.GridHelper(10,20,0xff6b00,0x3d312b));
                var rootObj=null,wire=false,mixer=null;
                function placeObj(obj){
                  rootObj=obj;
                  var box=new THREE.Box3().setFromObject(obj);
                  var size=box.getSize(new THREE.Vector3());
                  var maxDim=Math.max(size.x,size.y,size.z)||1;
                  obj.scale.multiplyScalar(3.2/maxDim);
                  var box2=new THREE.Box3().setFromObject(obj);
                  var center=box2.getCenter(new THREE.Vector3());
                  obj.position.x-=center.x;obj.position.z-=center.z;obj.position.y-=box2.min.y;
                  scene.add(obj);
                  camera.position.set(3.8,2.6,4.4);controls.target.set(0,Math.max(0.5,(box2.max.y-box2.min.y)*0.45),0);controls.update();
                  document.getElementById("msg").textContent="Döndürmek için sürükle • Yakınlaştır";
                }
                var buf=b64ToBuf(b64);
                if(ext==="glb"||ext==="gltf"){
                  new THREE.GLTFLoader().parse(buf,"",function(gltf){
                    if(gltf.animations&&gltf.animations.length){mixer=new THREE.AnimationMixer(gltf.scene);gltf.animations.forEach(function(c){mixer.clipAction(c).play();});}
                    placeObj(gltf.scene);
                  },function(e){document.getElementById("msg").textContent="GLTF Hatası: "+(e&&e.message?e.message:e);});
                }else if(ext==="obj"){
                  placeObj(new THREE.OBJLoader().parse(new TextDecoder().decode(new Uint8Array(buf))));
                }else if(ext==="stl"){
                  var geom=new THREE.STLLoader().parse(buf);geom.computeVertexNormals();
                  placeObj(new THREE.Mesh(geom,new THREE.MeshStandardMaterial({color:0xff7b1c,roughness:0.45,metalness:0.15})));
                }
                document.getElementById("rotBtn").onclick=function(){controls.autoRotate=!controls.autoRotate;this.textContent="↻ Oto-Dönüş: "+(controls.autoRotate?"Açık":"Kapalı");};
                document.getElementById("wireBtn").onclick=function(){wire=!wire;if(rootObj)rootObj.traverse(function(c){if(c.isMesh&&c.material){(Array.isArray(c.material)?c.material:[c.material]).forEach(function(mt){mt.wireframe=wire;});}});};
                addEventListener("resize",function(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
                var clock=new THREE.Clock();
                (function anim(){requestAnimationFrame(anim);if(mixer)mixer.update(clock.getDelta());controls.update();renderer.render(scene,camera);})();
              </script>
            </body>
            </html>
        """.trimIndent()
    }

    private fun inspectBytes(
        id: String,
        fileName: String,
        bytes: ByteArray,
        localPath: String
    ): Model3dAsset {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val mime = when (ext) {
            "glb" -> "model/gltf-binary"
            "gltf" -> "model/gltf+json"
            "obj" -> "text/plain"
            else -> "application/octet-stream"
        }
        var meshes = emptyList<String>()
        var animations = emptyList<String>()
        var vertices = 0
        var triangles = 0
        var boundsText = ""
        var minY: Float? = null

        runCatching {
            when (ext) {
                "glb" -> {
                    val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                    if (bytes.size >= 20 && bb.getInt(0) == 0x46546C67) {
                        val jsonLen = bb.getInt(12)
                        val chunkType = bb.getInt(16)
                        if (chunkType == 0x4E4F534A && jsonLen > 0 && 20 + jsonLen <= bytes.size) {
                            val json = JSONObject(String(bytes, 20, jsonLen, Charsets.UTF_8))
                            val parsed = parseGltfJson(json)
                            meshes = parsed.meshes
                            animations = parsed.animations
                            vertices = parsed.vertices
                            boundsText = parsed.boundsText
                            minY = parsed.minY
                        }
                    }
                }
                "gltf" -> {
                    val json = JSONObject(String(bytes, Charsets.UTF_8))
                    val parsed = parseGltfJson(json)
                    meshes = parsed.meshes
                    animations = parsed.animations
                    vertices = parsed.vertices
                    boundsText = parsed.boundsText
                    minY = parsed.minY
                }
                "obj" -> {
                    val text = String(bytes, Charsets.UTF_8)
                    val meshSet = LinkedHashSet<String>()
                    var minX = Float.POSITIVE_INFINITY
                    var minYv = Float.POSITIVE_INFINITY
                    var minZ = Float.POSITIVE_INFINITY
                    var maxX = Float.NEGATIVE_INFINITY
                    var maxYv = Float.NEGATIVE_INFINITY
                    var maxZ = Float.NEGATIVE_INFINITY
                    text.lineSequence().forEach { raw ->
                        val line = raw.trim()
                        if (line.startsWith("v ")) {
                            val parts = line.split(Regex("\\s+"))
                            if (parts.size >= 4) {
                                val x = parts[1].toFloatOrNull()
                                val y = parts[2].toFloatOrNull()
                                val z = parts[3].toFloatOrNull()
                                if (x != null && y != null && z != null) {
                                    vertices++
                                    if (x < minX) minX = x; if (x > maxX) maxX = x
                                    if (y < minYv) minYv = y; if (y > maxYv) maxYv = y
                                    if (z < minZ) minZ = z; if (z > maxZ) maxZ = z
                                }
                            }
                        } else if (line.startsWith("f ")) {
                            triangles++
                        } else if ((line.startsWith("o ") || line.startsWith("g ")) && meshSet.size < 16) {
                            line.drop(2).trim().takeIf { it.isNotEmpty() }?.let { meshSet.add(it) }
                        }
                    }
                    meshes = meshSet.toList()
                    if (vertices > 0 && minX.isFinite()) {
                        boundsText = formatBounds(maxX - minX, maxYv - minYv, maxZ - minZ)
                        minY = minYv
                    }
                }
                "stl" -> {
                    if (bytes.size >= 84) {
                        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                        val triBin = bb.getInt(80)
                        if (triBin > 0 && bytes.size == 84 + triBin * 50) {
                            triangles = triBin
                            vertices = triBin * 3
                        } else {
                            val head = String(bytes, 0, minOf(256, bytes.size), Charsets.UTF_8)
                            if (head.trimStart().startsWith("solid", ignoreCase = true)) {
                                val text = String(bytes, Charsets.UTF_8)
                                triangles = Regex("facet\\s+normal", RegexOption.IGNORE_CASE).findAll(text).count()
                                vertices = triangles * 3
                            }
                        }
                    }
                }
            }
        }

        return Model3dAsset(
            id = id,
            fileName = fileName,
            format = ext.uppercase(),
            sizeBytes = bytes.size.toLong(),
            mimeType = mime,
            boundsText = boundsText,
            minY = minY,
            meshes = meshes,
            animations = animations,
            vertices = vertices,
            triangles = triangles,
            localPath = localPath
        )
    }

    private data class GltfMeta(
        val meshes: List<String>,
        val animations: List<String>,
        val vertices: Int,
        val boundsText: String,
        val minY: Float?
    )

    private fun parseGltfJson(gltf: JSONObject): GltfMeta {
        val meshesArr = gltf.optJSONArray("meshes")
        val animsArr = gltf.optJSONArray("animations")
        val accessors = gltf.optJSONArray("accessors")

        val meshes = mutableListOf<String>()
        var vTotal = 0
        var minX = Float.POSITIVE_INFINITY
        var minYv = Float.POSITIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxYv = Float.NEGATIVE_INFINITY
        var maxZ = Float.NEGATIVE_INFINITY

        if (meshesArr != null) {
            for (i in 0 until meshesArr.length()) {
                val m = meshesArr.optJSONObject(i) ?: continue
                if (meshes.size < 20) meshes.add(m.optString("name").ifBlank { "Mesh_$i" })
                val prims = m.optJSONArray("primitives") ?: continue
                for (j in 0 until prims.length()) {
                    val attrs = prims.optJSONObject(j)?.optJSONObject("attributes") ?: continue
                    if (attrs.has("POSITION") && accessors != null) {
                        val acc = accessors.optJSONObject(attrs.optInt("POSITION", -1)) ?: continue
                        vTotal += acc.optInt("count", 0)
                        val minArr = acc.optJSONArray("min")
                        val maxArr = acc.optJSONArray("max")
                        if (minArr != null && maxArr != null && minArr.length() >= 3 && maxArr.length() >= 3) {
                            minX = minOf(minX, minArr.optDouble(0).toFloat())
                            minYv = minOf(minYv, minArr.optDouble(1).toFloat())
                            minZ = minOf(minZ, minArr.optDouble(2).toFloat())
                            maxX = maxOf(maxX, maxArr.optDouble(0).toFloat())
                            maxYv = maxOf(maxYv, maxArr.optDouble(1).toFloat())
                            maxZ = maxOf(maxZ, maxArr.optDouble(2).toFloat())
                        }
                    }
                }
            }
        }

        val animations = mutableListOf<String>()
        if (animsArr != null) {
            for (i in 0 until minOf(animsArr.length(), 15)) {
                val a = animsArr.optJSONObject(i) ?: continue
                animations.add(a.optString("name").ifBlank { "Anim_$i" })
            }
        }

        val boundsText = if (minX.isFinite()) formatBounds(maxX - minX, maxYv - minYv, maxZ - minZ) else ""
        return GltfMeta(
            meshes = meshes,
            animations = animations,
            vertices = vTotal,
            boundsText = boundsText,
            minY = if (minYv.isFinite()) minYv else null
        )
    }

    private fun formatBounds(w: Float, h: Float, d: Float): String =
        String.format("%.2f×%.2f×%.2f", w, h, d)

    private fun modelsDir(context: Context, conversationKey: String): File {
        val safeKey = conversationKey.replace(Regex("[^a-zA-Z0-9._\\-]"), "_").ifBlank { "_draft" }
        return File(File(context.filesDir, "merkop_models"), safeKey)
    }

    private fun saveAssetMeta(dir: File, asset: Model3dAsset) {
        val existing = loadModelsFromDir(dir).filterNot { it.fileName == asset.fileName }.toMutableList()
        existing.add(asset)
        writeMetaArray(dir, existing)
    }

    private fun loadModelsFromDir(dir: File): List<Model3dAsset> {
        val metaFile = File(dir, "_meta.json")
        if (!metaFile.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(metaFile.readText())
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.optJSONObject(i) ?: return@mapNotNull null
                Model3dAsset(
                    id = obj.optString("id"),
                    fileName = obj.optString("fileName"),
                    format = obj.optString("format"),
                    sizeBytes = obj.optLong("sizeBytes"),
                    mimeType = obj.optString("mimeType"),
                    boundsText = obj.optString("boundsText", ""),
                    minY = if (obj.has("minY")) obj.optDouble("minY").toFloat() else null,
                    meshes = jsonArrayToStrings(obj.optJSONArray("meshes")),
                    animations = jsonArrayToStrings(obj.optJSONArray("animations")),
                    vertices = obj.optInt("vertices", 0),
                    triangles = obj.optInt("triangles", 0),
                    localPath = obj.optString("localPath", "")
                )
            }
        }.getOrDefault(emptyList())
    }

    private fun writeMetaArray(dir: File, list: List<Model3dAsset>) {
        dir.mkdirs()
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id)
                put("fileName", a.fileName)
                put("format", a.format)
                put("sizeBytes", a.sizeBytes)
                put("mimeType", a.mimeType)
                put("boundsText", a.boundsText)
                if (a.minY != null) put("minY", a.minY.toDouble())
                put("meshes", JSONArray(a.meshes))
                put("animations", JSONArray(a.animations))
                put("vertices", a.vertices)
                put("triangles", a.triangles)
                put("localPath", a.localPath)
            })
        }
        File(dir, "_meta.json").writeText(arr.toString())
    }

    private fun jsonArrayToStrings(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { arr.optString(it).takeIf { s -> s.isNotBlank() } }
    }
}
