package com.example.util

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PaymentSecurityManager {

    const val OFFICIAL_SUPPORT_EMAIL = "a46350272@gmail.com"

    private const val PREFS_NAME = "study_vip_security_prefs"
    private const val KEY_IS_VIP = "is_vip_active"
    private const val KEY_VIP_ACTIVATION_TIME = "vip_activation_time"
    private const val KEY_VIP_EXPIRY_TIME = "vip_expiry_time"
    private const val KEY_ACTIVE_LICENSE_KEY = "active_license_key"

    // Pending Verification Storage
    private const val KEY_PENDING_ORDER_ID = "pending_order_id"
    private const val KEY_PENDING_UTR = "pending_utr"
    private const val KEY_PENDING_TIMESTAMP = "pending_timestamp"

    // Brute-force protection
    private const val KEY_FAILED_ATTEMPTS = "failed_attempts"
    private const val KEY_LOCKOUT_UNTIL = "lockout_until"
    private const val MAX_FAILED_ATTEMPTS = 5
    private const val LOCKOUT_DURATION_MS = 5 * 60 * 1000L // 5 minutes

    // Admin / Owner master unlock secret
    private const val MASTER_ADMIN_PIN = "892144"
    private const val MASTER_ADMIN_KEY = "ADMIN-VIP-ACTIVATE"

    // Secret salt for cryptographic license validation
    private const val LICENSE_SALT = "AESTHETIC_STUDY_VIP_2026_SECRET"

    // Recognized authentic VIP promotional and merchant keys
    private val PRESET_VALID_KEYS = setOf(
        "VIP2026-PAID",
        "STUDY199-VERIFIED",
        "PINK-PRO-PASS",
        "FOCUS-2M-SECURE",
        "STUDY-VIP-60D"
    )

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Checks if VIP membership is currently active and not expired.
     */
    fun isVipActive(context: Context): Boolean {
        val prefs = getPrefs(context)
        val active = prefs.getBoolean(KEY_IS_VIP, false)
        if (!active) return false

        val expiry = prefs.getLong(KEY_VIP_EXPIRY_TIME, 0L)
        if (expiry > 0 && System.currentTimeMillis() > expiry) {
            // Expired after 60 days
            setVipActive(context, false)
            return false
        }
        return true
    }

    /**
     * Activates or revokes VIP membership with 60 days validity.
     */
    fun setVipActive(context: Context, active: Boolean, licenseKey: String = "") {
        val prefs = getPrefs(context)
        val editor = prefs.edit()
        editor.putBoolean(KEY_IS_VIP, active)
        if (active) {
            val now = System.currentTimeMillis()
            val expiry = now + (60L * 24L * 60L * 60L * 1000L) // 60 days (2 months)
            editor.putLong(KEY_VIP_ACTIVATION_TIME, now)
            editor.putLong(KEY_VIP_EXPIRY_TIME, expiry)
            editor.putString(KEY_ACTIVE_LICENSE_KEY, licenseKey)
            // Clear pending status once activated
            editor.remove(KEY_PENDING_ORDER_ID)
            editor.remove(KEY_PENDING_UTR)
            editor.remove(KEY_PENDING_TIMESTAMP)
        } else {
            editor.remove(KEY_VIP_ACTIVATION_TIME)
            editor.remove(KEY_VIP_EXPIRY_TIME)
            editor.remove(KEY_ACTIVE_LICENSE_KEY)
        }
        editor.apply()
    }

    /**
     * Checks if user is temporarily locked out due to multiple failed verification attempts.
     */
    fun getRemainingLockoutSeconds(context: Context): Long {
        val prefs = getPrefs(context)
        val lockoutUntil = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
        val diff = lockoutUntil - System.currentTimeMillis()
        return if (diff > 0) (diff / 1000) else 0L
    }

    private fun recordFailedAttempt(context: Context) {
        val prefs = getPrefs(context)
        val attempts = prefs.getInt(KEY_FAILED_ATTEMPTS, 0) + 1
        val editor = prefs.edit()
        editor.putInt(KEY_FAILED_ATTEMPTS, attempts)
        if (attempts >= MAX_FAILED_ATTEMPTS) {
            editor.putLong(KEY_LOCKOUT_UNTIL, System.currentTimeMillis() + LOCKOUT_DURATION_MS)
        }
        editor.apply()
    }

    private fun resetFailedAttempts(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_FAILED_ATTEMPTS)
            .remove(KEY_LOCKOUT_UNTIL)
            .apply()
    }

    /**
     * Validates a submitted 12-digit UPI Bank UTR.
     * CRITICAL: Submitting a valid UTR DOES NOT activate VIP immediately!
     * It registers the transaction as PENDING VERIFICATION for merchant ledger cross-check.
     */
    fun submitUtrForVerification(context: Context, rawUtr: String): VerificationResult {
        val lockoutSeconds = getRemainingLockoutSeconds(context)
        if (lockoutSeconds > 0) {
            return VerificationResult.Error("Too many attempts. Locked for ${lockoutSeconds}s for security.")
        }

        val cleanUtr = rawUtr.trim()

        // 1. Must be exact 12 digits numeric
        if (!cleanUtr.matches(Regex("^[0-9]{12}$"))) {
            recordFailedAttempt(context)
            return VerificationResult.Error("Invalid UTR: Bank reference must be exactly 12 numeric digits.")
        }

        // 2. Reject dummy / repeated digits (e.g. 000000000000, 111111111111, 999999999999)
        val distinctDigits = cleanUtr.toSet()
        if (distinctDigits.size <= 2) {
            recordFailedAttempt(context)
            return VerificationResult.Error("Invalid UTR: Dummy or repeated numbers are rejected by banking verification.")
        }

        // 3. Reject sequential runs (e.g. 123456789012, 987654321098, 012345678901)
        val sequentialAsc = "0123456789012345"
        val sequentialDesc = "9876543210987654"
        if (sequentialAsc.contains(cleanUtr) || sequentialDesc.contains(cleanUtr)) {
            recordFailedAttempt(context)
            return VerificationResult.Error("Invalid UTR: Sequential sample numbers cannot be verified.")
        }

        // Valid syntax: Record as Pending Verification
        val orderId = "VIP-2026-" + Math.abs(cleanUtr.hashCode()).toString().takeLast(6)
        val timestamp = System.currentTimeMillis()

        getPrefs(context).edit()
            .putString(KEY_PENDING_ORDER_ID, orderId)
            .putString(KEY_PENDING_UTR, cleanUtr)
            .putLong(KEY_PENDING_TIMESTAMP, timestamp)
            .apply()

        resetFailedAttempts(context)

        return VerificationResult.UtrPending(
            orderId = orderId,
            utr = cleanUtr,
            message = "Payment reference registered! Status is PENDING ledger verification. Premium will activate once the incoming ₹199 bank credit is verified by the creator."
        )
    }

    /**
     * Validates an official VIP Activation Key or Admin Passcode.
     * If authentic, instantly activates the 2-Month VIP pass!
     */
    fun verifyActivationKey(context: Context, rawKey: String): VerificationResult {
        val lockoutSeconds = getRemainingLockoutSeconds(context)
        if (lockoutSeconds > 0) {
            return VerificationResult.Error("Too many attempts. Locked for ${lockoutSeconds}s for security.")
        }

        val cleanKey = rawKey.trim().uppercase(Locale.US)

        if (cleanKey.isBlank()) {
            return VerificationResult.Error("Please enter an activation key or passcode.")
        }

        // Check Admin Master PIN / Key
        if (cleanKey == MASTER_ADMIN_KEY || cleanKey == MASTER_ADMIN_PIN) {
            resetFailedAttempts(context)
            setVipActive(context, true, cleanKey)
            return VerificationResult.Success(
                message = "👑 Master Admin Access: VIP Pass Activated for 60 Days!"
            )
        }

        // Check Predefined Authentic Promotional Keys
        if (PRESET_VALID_KEYS.contains(cleanKey)) {
            resetFailedAttempts(context)
            setVipActive(context, true, cleanKey)
            return VerificationResult.Success(
                message = "🎉 Official VIP Key Verified! 2-Month VIP Pass Activated!"
            )
        }

        // Check Algorithmic Key with cryptographic checksum
        // Format: VIP-XXXX-YYYY (e.g. VIP-PINK-9142)
        if (validateAlgorithmicKey(cleanKey)) {
            resetFailedAttempts(context)
            setVipActive(context, true, cleanKey)
            return VerificationResult.Success(
                message = "🎉 Verified Payment Voucher! 2-Month VIP Pass Activated!"
            )
        }

        // Invalid key
        recordFailedAttempt(context)
        return VerificationResult.Error("❌ Invalid VIP Key: Unrecognized code. Please submit your 12-digit bank UTR or obtain an official VIP key after payment.")
    }

    /**
     * Cryptographic checksum validator:
     * Generates and validates keys matching VIP-[PAYLOAD]-[CHECKSUM].
     */
    private fun validateAlgorithmicKey(key: String): Boolean {
        val parts = key.split("-")
        if (parts.size != 3 || parts[0] != "VIP") return false
        val payload = parts[1]
        val providedChecksum = parts[2]
        if (payload.length < 3 || providedChecksum.length != 4) return false

        val expectedChecksum = computeChecksum(payload)
        return providedChecksum == expectedChecksum
    }

    /**
     * Computes 4-character deterministic checksum for a payload token.
     */
    fun computeChecksum(payload: String): String {
        val input = payload + LICENSE_SALT
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(input.toByteArray())
        val num = Math.abs(bytes[0].toInt() * 256 + bytes[1].toInt()) % 9000 + 1000
        return num.toString()
    }

    /**
     * Generates a genuine customer VIP key that the creator can give to a paying buyer.
     * Example: VIP-OCT9-4821
     */
    fun generateCustomerKey(tag: String = "PAID"): String {
        val cleanTag = tag.trim().uppercase(Locale.US).take(4).ifBlank { "PRO" }
        val randomSuffix = (10..99).random().toString()
        val payload = "$cleanTag$randomSuffix"
        val checksum = computeChecksum(payload)
        return "VIP-$payload-$checksum"
    }

    /**
     * Returns pending payment verification info if exists.
     */
    fun getPendingVerification(context: Context): PendingPaymentInfo? {
        val prefs = getPrefs(context)
        val orderId = prefs.getString(KEY_PENDING_ORDER_ID, null) ?: return null
        val utr = prefs.getString(KEY_PENDING_UTR, "") ?: ""
        val timestamp = prefs.getLong(KEY_PENDING_TIMESTAMP, 0L)
        return PendingPaymentInfo(orderId, utr, timestamp)
    }

    /**
     * Admin/Creator manual approval of a pending UTR request.
     */
    fun approvePendingVerification(context: Context): Boolean {
        val pending = getPendingVerification(context) ?: return false
        setVipActive(context, true, "UTR_APPROVED_${pending.utr}")
        return true
    }

    /**
     * Admin/Creator manual rejection of a pending UTR request.
     */
    fun rejectPendingVerification(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_PENDING_ORDER_ID)
            .remove(KEY_PENDING_UTR)
            .remove(KEY_PENDING_TIMESTAMP)
            .apply()
    }

    /**
     * Builds standard email body for buyer to share proof to official creator email.
     */
    fun getBuyerProofEmailBody(orderId: String, utr: String): String {
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
        return """
Hello Study Timer Team,

I have completed payment of ₹199 via UPI for the 2-Month Study VIP Pass.
Please verify my payment proof and send me my official VIP Activation Key.

Payment Details:
• Order Reference: ${orderId.ifBlank { "VIP-2026" }}
• 12-Digit Bank UTR / Ref: ${utr.ifBlank { "[Please attach screenshot or write UTR]" }}
• Amount Paid: ₹199.00 (2 Months Access)
• Timestamp: $dateStr

(Payment screenshot from UPI app attached)

Thank you!
""".trimIndent()
    }

    /**
     * Creates an Intent to send proof directly to creator's email: a46350272@gmail.com
     */
    fun createBuyerProofEmailIntent(orderId: String, utr: String): Intent {
        val subject = "Study Timer VIP Payment Proof [${if (utr.isNotBlank()) utr else orderId}]"
        val body = getBuyerProofEmailBody(orderId, utr)
        return Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$OFFICIAL_SUPPORT_EMAIL")
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
    }

    /**
     * Builds ready-to-send reply email for creator to give the activation code to the buyer.
     */
    fun getSellerKeyEmailBody(key: String): String {
        return """
Hello!

Thank you for purchasing the 2-Month VIP Pass for Study Timer.
Your payment of ₹199 has been verified successfully.

Here is your official VIP Activation Key:
👉 $key

How to activate inside the app:
1. Open Study Timer.
2. Tap the '👑 VIP' badge at the top (or open Settings -> Study VIP Pass).
3. Switch to '2. Verify Payment'.
4. Paste this code under 'Instant Unlock with VIP Key / Voucher'.
5. Tap 'Verify & Activate VIP Key ✨'.

All 10+ holographic stickers, streak shield, and binaural soundscapes are now active for 60 days. Happy studying! 💖
""".trimIndent()
    }

    /**
     * Creates intent for creator to send the generated VIP key to the customer.
     */
    fun createSellerKeyEmailIntent(key: String, recipientEmail: String = ""): Intent {
        val subject = "Your Study Timer VIP 2-Month Activation Key 🎉"
        val body = getSellerKeyEmailBody(key)
        return if (recipientEmail.isNotBlank()) {
            Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$recipientEmail")
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
            }
        } else {
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
            }
        }
    }

    data class PendingPaymentInfo(
        val orderId: String,
        val utr: String,
        val timestamp: Long
    )

    sealed class VerificationResult {
        data class Success(val message: String) : VerificationResult()
        data class UtrPending(val orderId: String, val utr: String, val message: String) : VerificationResult()
        data class Error(val message: String) : VerificationResult()
    }
}
