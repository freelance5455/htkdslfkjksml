package com.example.util

import android.os.SystemClock

data class SanitizerResult(
    val text: String,
    val consumedSeq: Long,
    val time: Long,
    val character: Char?
)

object TextInputSanitizer {
    /**
     * Sanitizes incoming text from Compose TextField to eliminate duplicate character
     * repetitions caused by emulator/web streaming key-event and IME double-triggering.
     */
    fun sanitize(
        oldText: String,
        newText: String,
        keyPressSeq: Long = 0L,
        lastConsumedSeq: Long = 0L,
        lastTime: Long = 0L,
        lastChar: Char? = null,
        currentTimeOverride: Long? = null
    ): SanitizerResult {
        val now = currentTimeOverride ?: SystemClock.elapsedRealtime()

        // 1. If length decreased or remained same (backspace, delete, or selection replacement)
        if (newText.length <= oldText.length) {
            return SanitizerResult(
                text = newText,
                consumedSeq = lastConsumedSeq,
                time = now,
                character = null
            )
        }

        // 2. Check for simultaneous single-event doubling: length increased by 2, and both inserted characters are identical
        if (newText.length == oldText.length + 2) {
            var prefixLen = 0
            while (prefixLen < oldText.length && oldText[prefixLen] == newText[prefixLen]) {
                prefixLen++
            }
            var suffixLen = 0
            while (suffixLen < (oldText.length - prefixLen) &&
                oldText[oldText.length - 1 - suffixLen] == newText[newText.length - 1 - suffixLen]
            ) {
                suffixLen++
            }

            val inserted = newText.substring(prefixLen, newText.length - suffixLen)
            if (inserted.length == 2 && inserted[0] == inserted[1]) {
                // Collapsed the doubled character (e.g. "aa" -> "a")
                val collapsed = newText.substring(0, prefixLen) + inserted[0] + newText.substring(prefixLen + 2)
                return SanitizerResult(
                    text = collapsed,
                    consumedSeq = keyPressSeq,
                    time = now,
                    character = inserted[0]
                )
            }
        }

        // 3. Check for single character insertion (length increased by 1)
        if (newText.length == oldText.length + 1) {
            var prefixLen = 0
            while (prefixLen < oldText.length && oldText[prefixLen] == newText[prefixLen]) {
                prefixLen++
            }
            val insertedChar = newText[prefixLen]

            // Check if this insertion is a duplicate of the previous insertion:
            // Condition A: If a physical/emulator keyboard keyPressSeq is tracked,
            // and keyPressSeq has not incremented since the last consumed character of the same character.
            val isDuplicateKeyPress = (keyPressSeq > 0L && keyPressSeq == lastConsumedSeq && insertedChar == lastChar)

            // Condition B: Or if the exact same character was inserted within a rapid debounce window (280ms)
            val isRapidDuplicateTime = (insertedChar == lastChar && (now - lastTime) < 280L)

            if (isDuplicateKeyPress || isRapidDuplicateTime) {
                // Reject duplicate event and keep oldText
                return SanitizerResult(
                    text = oldText,
                    consumedSeq = lastConsumedSeq,
                    time = now,
                    character = lastChar
                )
            }

            // Valid insertion
            return SanitizerResult(
                text = newText,
                consumedSeq = keyPressSeq,
                time = now,
                character = insertedChar
            )
        }

        // 4. Normal paste or multi-character addition (> 2 characters)
        return SanitizerResult(
            text = newText,
            consumedSeq = keyPressSeq,
            time = now,
            character = null
        )
    }
}
