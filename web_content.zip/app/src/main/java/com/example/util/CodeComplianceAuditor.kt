package com.example.util

import com.example.data.model.SandboxSpec
import com.example.data.model.StudioProject
import com.example.data.model.WebsiteSpec

data class AuditCheckItem(
    val id: String,
    val title: String,
    val passed: Boolean,
    val detail: String
)

data class CodeAuditReport(
    val readinessScore: Int,
    val lineCount: Int,
    val composableCount: Int,
    val stateCount: Int,
    val widgetCount: Int,
    val checks: List<AuditCheckItem>
)

data class SandboxScenarioSnapshot(
    val id: String,
    val label: String,
    val computedResult: String,
    val unit: String,
    val numericSnapshot: Map<String, Float>,
    val toggleSnapshot: Map<String, Boolean>,
    val textSnapshot: Map<String, String>
)

object CodeComplianceAuditor {

    fun auditProject(project: StudioProject): CodeAuditReport {
        if (project.isWebsiteProject()) {
            return auditWebsiteProject(project)
        }

        val code = project.kotlinCode
        val manifest = project.manifestXml
        val gradle = project.buildGradleKts
        val spec = SandboxSpec.fromJsonString(project.sandboxSpecJson, project.title)

        val lines = code.lines().size
        val composables = Regex("@Composable").findAll(code).count()
        val stateHolders = Regex("remember|mutableStateOf|StateFlow|collectAsState").findAll(code).count()

        val hasFillMaxWidth = code.contains("fillMaxWidth")
        val noHorizontalScroll = !code.contains("horizontalScroll")
        val hasMaterial3 = code.contains("material3") || code.contains("Scaffold") || code.contains("Card")
        val hasStateManagement = stateHolders > 0 || spec.widgets.isNotEmpty()
        val hasValidManifest = manifest.contains("<manifest") && manifest.contains("<application")
        val hasComposeGradle = gradle.contains("compose") || gradle.contains("android")

        val checks = listOf(
            AuditCheckItem(
                id = "viewport_width",
                title = "Vertical Viewport Constraint (fillMaxWidth & Zero Horizontal Scroll)",
                passed = hasFillMaxWidth && noHorizontalScroll,
                detail = if (hasFillMaxWidth && noHorizontalScroll) {
                    "Verified Modifier.fillMaxWidth() usage with zero horizontalScroll calls."
                } else {
                    "Recommend adding Modifier.fillMaxWidth() and avoiding horizontalScroll."
                }
            ),
            AuditCheckItem(
                id = "material3_components",
                title = "Material Design 3 Component Hierarchy",
                passed = hasMaterial3,
                detail = if (hasMaterial3) {
                    "Detected Material 3 containers ($composables @Composable functions)."
                } else {
                    "Add Material 3 Scaffold, Card, or Surface primitives."
                }
            ),
            AuditCheckItem(
                id = "reactive_state",
                title = "Reactive State Hoisting & Sandbox Bindings",
                passed = hasStateManagement,
                detail = "Detected $stateHolders state bindings and ${spec.widgets.size} interactive sandbox widgets."
            ),
            AuditCheckItem(
                id = "manifest_integrity",
                title = "AndroidManifest & Activity Declaration",
                passed = hasValidManifest,
                detail = if (hasValidManifest) {
                    "AndroidManifest.xml declares valid <manifest> and <application> tags."
                } else {
                    "Manifest is missing standard <application> wrapper."
                }
            ),
            AuditCheckItem(
                id = "gradle_dsl",
                title = "Gradle Kotlin DSL Configuration",
                passed = hasComposeGradle,
                detail = if (hasComposeGradle) {
                    "app/build.gradle.kts includes Android & Compose build configuration."
                } else {
                    "Verify Compose plugin configuration in build.gradle.kts."
                }
            )
        )

        val passedCount = checks.count { it.passed }
        val score = ((passedCount.toFloat() / checks.size.toFloat()) * 100f).toInt()

        return CodeAuditReport(
            readinessScore = score,
            lineCount = lines,
            composableCount = composables.coerceAtLeast(1),
            stateCount = stateHolders,
            widgetCount = spec.widgets.size,
            checks = checks
        )
    }

    fun auditWebsiteProject(project: StudioProject): CodeAuditReport {
        val html = project.kotlinCode
        val css = project.manifestXml
        val js = project.buildGradleKts
        val spec = WebsiteSpec.fromJsonString(project.sandboxSpecJson, project.title)

        val totalLines = html.lines().size + css.lines().size + js.lines().size
        val semanticTags = Regex("<(header|main|section|nav|footer|article)").findAll(html).count()
        val jsFunctions = Regex("function\\s+|=>|addEventListener").findAll(js).count()

        val hasViewportMeta = html.contains("viewport", ignoreCase = true)
        val hasOverflowProtection = css.contains("box-sizing") || css.contains("max-width") || css.contains("100%")
        val hasSemanticLandmarks = semanticTags >= 2
        val hasSeoMeta = spec.seoMetaDescription.isNotBlank() || html.contains("description", ignoreCase = true)
        val hasInteractiveJs = js.isNotBlank() && (jsFunctions > 0 || spec.sections.isNotEmpty())
        val noLoremIpsum = !html.contains("lorem ipsum", ignoreCase = true)

        val checks = listOf(
            AuditCheckItem(
                id = "web_viewport",
                title = "Responsive Mobile Viewport & Zero Horizontal Overflow",
                passed = hasViewportMeta && hasOverflowProtection,
                detail = if (hasViewportMeta && hasOverflowProtection) {
                    "Verified responsive viewport meta tag and fluid CSS box-sizing/max-width rules."
                } else {
                    "Ensure <meta name=\"viewport\"> and max-width: 100% CSS rules are present."
                }
            ),
            AuditCheckItem(
                id = "web_semantics",
                title = "Semantic HTML5 Landmark Hierarchy",
                passed = hasSemanticLandmarks,
                detail = "Detected $semanticTags semantic HTML5 landmarks (<header>, <main>, <section>, <footer>)."
            ),
            AuditCheckItem(
                id = "web_seo",
                title = "SEO Meta Description & Document Title",
                passed = hasSeoMeta,
                detail = "SEO Meta: \"${spec.seoMetaDescription.take(80)}\""
            ),
            AuditCheckItem(
                id = "web_interactivity",
                title = "Interactive ES6 JavaScript & Section Architecture",
                passed = hasInteractiveJs,
                detail = "Detected $jsFunctions JS handlers and ${spec.sections.size} structured website sections."
            ),
            AuditCheckItem(
                id = "web_anti_dummy",
                title = "Real-World Domain Copy Verification (No Lorem Ipsum)",
                passed = noLoremIpsum,
                detail = if (noLoremIpsum) {
                    "Verified zero placeholder lorem ipsum strings across HTML5/CSS3/JS."
                } else {
                    "Replace placeholder text with real domain copy."
                }
            )
        )

        val passedCount = checks.count { it.passed }
        val score = ((passedCount.toFloat() / checks.size.toFloat()) * 100f).toInt()

        return CodeAuditReport(
            readinessScore = score,
            lineCount = totalLines,
            composableCount = semanticTags.coerceAtLeast(1),
            stateCount = jsFunctions,
            widgetCount = spec.sections.size,
            checks = checks
        )
    }
}
