package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.graphics.withTranslation
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.data.db.InformationRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class PdfElement {
    data class TextElement(
        val text: String,
        val style: TextStyle = TextStyle.BODY
    ) : PdfElement()

    data class ImageElement(
        val bitmap: Bitmap,
        val caption: String = ""
    ) : PdfElement()
}

enum class TextStyle {
    TITLE,
    HEADING,
    SUBHEADING,
    BODY,
    MONOSPACE
}

object PdfGenerator {
    private const val PAGE_WIDTH = 595 // Standard A4 width in points
    private const val PAGE_HEIGHT = 842 // Standard A4 height in points
    private const val MARGIN_HORIZONTAL = 48
    private const val MARGIN_TOP = 64
    private const val MARGIN_BOTTOM = 64
    private const val CONTENT_WIDTH = PAGE_WIDTH - (MARGIN_HORIZONTAL * 2)

    private fun formatDate(date: Date): String {
        return SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(date)
    }

    suspend fun createCustomPdf(
        context: Context,
        documentTitle: String,
        elements: List<PdfElement>
    ): Pair<File, Int> = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        val pdfDir = File(context.filesDir, "vault_pdfs").apply { if (!exists()) mkdirs() }
        val cleanTitle = documentTitle.trim().ifEmpty { "YM_Secret_Document" }
            .replace("[^a-zA-Z0-9_-]".toRegex(), "_")
        val outputFile = File(pdfDir, "${cleanTitle}_${System.currentTimeMillis()}.pdf")

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas
        var currentY = MARGIN_TOP.toFloat()

        fun drawHeaderAndFooter(c: Canvas, pNum: Int) {
            val paint = Paint().apply {
                isAntiAlias = true
                color = Color.rgb(30, 30, 30)
                textSize = 14f
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            }
            // Header
            c.drawText("YM SECRET", MARGIN_HORIZONTAL.toFloat(), 38f, paint)

            paint.textSize = 9f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.rgb(100, 100, 100)
            val dateStr = formatDate(Date())
            val dateWidth = paint.measureText(dateStr)
            c.drawText(dateStr, PAGE_WIDTH - MARGIN_HORIZONTAL - dateWidth, 38f, paint)

            // Header line
            val linePaint = Paint().apply {
                color = Color.rgb(180, 180, 180)
                strokeWidth = 1f
            }
            c.drawLine(
                MARGIN_HORIZONTAL.toFloat(),
                46f,
                (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(),
                46f,
                linePaint
            )

            // Footer line
            c.drawLine(
                MARGIN_HORIZONTAL.toFloat(),
                (PAGE_HEIGHT - 36).toFloat(),
                (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(),
                (PAGE_HEIGHT - 36).toFloat(),
                linePaint
            )

            // Footer text
            val footerText = "Page $pNum"
            val footerWidth = paint.measureText(footerText)
            c.drawText(
                footerText,
                (PAGE_WIDTH - footerWidth) / 2f,
                (PAGE_HEIGHT - 22).toFloat(),
                paint
            )
        }

        // Draw header on first page
        drawHeaderAndFooter(canvas, pageNumber)

        // Document Title
        val titlePaint = TextPaint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 22f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        val titleLayout = StaticLayout.Builder.obtain(
            documentTitle,
            0,
            documentTitle.length,
            titlePaint,
            CONTENT_WIDTH
        ).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

        titleLayout.draw(canvas)
        currentY += titleLayout.height + 24f

        for (element in elements) {
            when (element) {
                is PdfElement.TextElement -> {
                    val textPaint = TextPaint().apply {
                        isAntiAlias = true
                        when (element.style) {
                            TextStyle.TITLE -> {
                                textSize = 20f
                                color = Color.BLACK
                                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
                            }
                            TextStyle.HEADING -> {
                                textSize = 16f
                                color = Color.rgb(20, 20, 20)
                                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            }
                            TextStyle.SUBHEADING -> {
                                textSize = 13f
                                color = Color.rgb(60, 60, 60)
                                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                            }
                            TextStyle.BODY -> {
                                textSize = 11f
                                color = Color.rgb(20, 20, 20)
                                typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                            }
                            TextStyle.MONOSPACE -> {
                                textSize = 10f
                                color = Color.rgb(40, 40, 40)
                                typeface = Typeface.MONOSPACE
                            }
                        }
                    }

                    val textLayout = StaticLayout.Builder.obtain(
                        element.text,
                        0,
                        element.text.length,
                        textPaint,
                        CONTENT_WIDTH
                    ).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

                    val layoutHeight = textLayout.height
                    if (currentY + layoutHeight > PAGE_HEIGHT - MARGIN_BOTTOM) {
                        // Start new page
                        pdfDocument.finishPage(page)
                        pageNumber++
                        pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                        page = pdfDocument.startPage(pageInfo)
                        canvas = page.canvas
                        drawHeaderAndFooter(canvas, pageNumber)
                        currentY = MARGIN_TOP.toFloat()
                    }

                    canvas.withTranslation(MARGIN_HORIZONTAL.toFloat(), currentY) {
                        textLayout.draw(canvas)
                    }

                    currentY += layoutHeight + 14f
                }
                is PdfElement.ImageElement -> {
                    val originalBitmap = element.bitmap
                    val maxWidth = CONTENT_WIDTH.toFloat()
                    val maxHeight = 300f

                    val scale = minOf(maxWidth / originalBitmap.width, maxHeight / originalBitmap.height, 1.0f)
                    val targetWidth = (originalBitmap.width * scale).toInt()
                    val targetHeight = (originalBitmap.height * scale).toInt()

                    val captionPaint = TextPaint().apply {
                        isAntiAlias = true
                        textSize = 9f
                        color = Color.rgb(100, 100, 100)
                        typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
                    }

                    val captionHeight = if (element.caption.isNotEmpty()) 18f else 0f
                    val totalImageHeight = targetHeight + captionHeight + 12f

                    if (currentY + totalImageHeight > PAGE_HEIGHT - MARGIN_BOTTOM) {
                        pdfDocument.finishPage(page)
                        pageNumber++
                        pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                        page = pdfDocument.startPage(pageInfo)
                        canvas = page.canvas
                        drawHeaderAndFooter(canvas, pageNumber)
                        currentY = MARGIN_TOP.toFloat()
                    }

                    val left = MARGIN_HORIZONTAL + (CONTENT_WIDTH - targetWidth) / 2f
                    val destRect = Rect(
                        left.toInt(),
                        currentY.toInt(),
                        (left + targetWidth).toInt(),
                        (currentY + targetHeight).toInt()
                    )
                    canvas.drawBitmap(originalBitmap, null, destRect, null)
                    currentY += targetHeight + 6f

                    if (element.caption.isNotEmpty()) {
                        val captionWidth = captionPaint.measureText(element.caption)
                        val capLeft = MARGIN_HORIZONTAL + (CONTENT_WIDTH - captionWidth) / 2f
                        canvas.drawText(element.caption, capLeft, currentY + 8f, captionPaint)
                        currentY += 16f
                    }

                    currentY += 12f
                }
            }
        }

        pdfDocument.finishPage(page)

        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        Pair(outputFile, pageNumber)
    }

    suspend fun createInformationRecordPdf(
        context: Context,
        record: InformationRecord
    ): Pair<File, Int> = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        val pdfDir = File(context.filesDir, "vault_pdfs").apply { if (!exists()) mkdirs() }
        val fileName = "YM_Secret_Record_TX${record.transactionNumber}_${System.currentTimeMillis()}.pdf"
        val outputFile = File(pdfDir, fileName)

        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Background subtle border
        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.BLACK
            strokeWidth = 2f
        }
        canvas.drawRect(24f, 24f, (PAGE_WIDTH - 24).toFloat(), (PAGE_HEIGHT - 24).toFloat(), borderPaint)

        // Inner silver frame
        val innerFramePaint = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.rgb(180, 184, 190)
            strokeWidth = 1f
        }
        canvas.drawRect(28f, 28f, (PAGE_WIDTH - 28).toFloat(), (PAGE_HEIGHT - 28).toFloat(), innerFramePaint)

        // Header
        val brandPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 28f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("YM SECRET", PAGE_WIDTH / 2f, 75f, brandPaint)

        val subBrandPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(80, 80, 80)
            textSize = 12f
            letterSpacing = 0.2f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("OFFICIAL CONFIDENTIAL RECORD", PAGE_WIDTH / 2f, 96f, subBrandPaint)

        // Transaction badge
        val badgePaint = Paint().apply {
            color = Color.rgb(230, 232, 235)
            style = Paint.Style.FILL
        }
        canvas.drawRect(MARGIN_HORIZONTAL.toFloat(), 115f, (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(), 155f, badgePaint)
        canvas.drawRect(MARGIN_HORIZONTAL.toFloat(), 115f, (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(), 155f, borderPaint)

        val badgeTextPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 14f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        canvas.drawText("TRANSACTION NUMBER: #${record.transactionNumber}", MARGIN_HORIZONTAL + 16f, 140f, badgeTextPaint)

        val dateStr = formatDate(Date(record.createdAt))
        val datePaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(70, 70, 70)
            textSize = 10f
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("DATE: $dateStr", (PAGE_WIDTH - MARGIN_HORIZONTAL - 16).toFloat(), 140f, datePaint)

        // Fields Table / Cards
        val fields = listOf(
            "Name" to record.name,
            "The age" to record.age,
            "The place" to record.place,
            "The address" to record.address,
            "Phone number 1" to record.phone1,
            "Phone number 2" to record.phone2,
            "Email address" to record.email,
            "Transaction number" to "#${record.transactionNumber}"
        )

        var yPos = 180f
        val labelPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(90, 95, 102)
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val valuePaint = TextPaint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val cardBgPaint = Paint().apply {
            color = Color.rgb(245, 246, 248)
            style = Paint.Style.FILL
        }

        val cardBorderPaint = Paint().apply {
            color = Color.rgb(190, 195, 200)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }

        for ((label, value) in fields) {
            val textToDraw = value.ifEmpty { "—" }
            val textLayout = StaticLayout.Builder.obtain(
                textToDraw,
                0,
                textToDraw.length,
                valuePaint,
                CONTENT_WIDTH - 32
            ).build()

            val rowHeight = maxOf(48f, 28f + textLayout.height)

            canvas.drawRect(
                MARGIN_HORIZONTAL.toFloat(),
                yPos,
                (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(),
                yPos + rowHeight,
                cardBgPaint
            )
            canvas.drawRect(
                MARGIN_HORIZONTAL.toFloat(),
                yPos,
                (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(),
                yPos + rowHeight,
                cardBorderPaint
            )

            canvas.drawText(label.uppercase(Locale.getDefault()), MARGIN_HORIZONTAL + 16f, yPos + 18f, labelPaint)

            canvas.withTranslation(MARGIN_HORIZONTAL + 16f, yPos + 26f) {
                textLayout.draw(canvas)
            }

            yPos += rowHeight + 10f
        }

        // Security stamp footer
        val footerPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(60, 60, 60)
            textSize = 9f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("SECURE OFFLINE ARCHIVE • YM SECRET VAULT • AUTHORIZED LOCAL RECORD", PAGE_WIDTH / 2f, (PAGE_HEIGHT - 45).toFloat(), footerPaint)

        pdfDocument.finishPage(page)
        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        Pair(outputFile, 1)
    }

    suspend fun createSingleFieldPdf(
        context: Context,
        record: InformationRecord,
        fieldName: String,
        fieldValue: String
    ): Pair<File, Int> = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        val pdfDir = File(context.filesDir, "vault_pdfs").apply { if (!exists()) mkdirs() }
        val cleanFieldName = fieldName.replace("[^a-zA-Z0-9_-]".toRegex(), "_")
        val fileName = "YM_Secret_TX${record.transactionNumber}_$cleanFieldName.pdf"
        val outputFile = File(pdfDir, fileName)

        val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // Outer border
        val borderPaint = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.BLACK
            strokeWidth = 2f
        }
        canvas.drawRect(30f, 30f, (PAGE_WIDTH - 30).toFloat(), (PAGE_HEIGHT - 30).toFloat(), borderPaint)

        // Title
        val brandPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 30f
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("YM SECRET", PAGE_WIDTH / 2f, 100f, brandPaint)

        val subBrandPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(90, 90, 90)
            textSize = 12f
            letterSpacing = 0.2f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("INDIVIDUAL FIELD CERTIFICATE", PAGE_WIDTH / 2f, 125f, subBrandPaint)

        // Metadata box
        val metaPaint = Paint().apply {
            color = Color.rgb(235, 237, 240)
            style = Paint.Style.FILL
        }
        canvas.drawRect(MARGIN_HORIZONTAL.toFloat(), 155f, (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(), 205f, metaPaint)
        canvas.drawRect(MARGIN_HORIZONTAL.toFloat(), 155f, (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(), 205f, borderPaint)

        val metaTextPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 11f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }
        canvas.drawText("RECORD: #${record.transactionNumber}  •  CLIENT: ${record.name.ifEmpty { "N/A" }}", MARGIN_HORIZONTAL + 16f, 185f, metaTextPaint)

        // Main Field Box
        val boxTop = 240f
        val boxWidth = CONTENT_WIDTH.toFloat()

        val valPaint = TextPaint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val textLayout = StaticLayout.Builder.obtain(
            fieldValue.ifEmpty { "—" },
            0,
            fieldValue.ifEmpty { "—" }.length,
            valPaint,
            CONTENT_WIDTH - 48
        ).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

        val boxHeight = maxOf(140f, textLayout.height + 70f)

        val cardBg = Paint().apply {
            color = Color.rgb(248, 249, 250)
            style = Paint.Style.FILL
        }
        canvas.drawRect(MARGIN_HORIZONTAL.toFloat(), boxTop, (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(), boxTop + boxHeight, cardBg)
        canvas.drawRect(MARGIN_HORIZONTAL.toFloat(), boxTop, (PAGE_WIDTH - MARGIN_HORIZONTAL).toFloat(), boxTop + boxHeight, borderPaint)

        // Field Label Banner
        val fieldLabelPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(80, 85, 92)
            textSize = 12f
            letterSpacing = 0.15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText(fieldName.uppercase(Locale.getDefault()), MARGIN_HORIZONTAL + 24f, boxTop + 32f, fieldLabelPaint)

        val divPaint = Paint().apply {
            color = Color.rgb(200, 200, 200)
            strokeWidth = 1f
        }
        canvas.drawLine(MARGIN_HORIZONTAL + 24f, boxTop + 42f, (PAGE_WIDTH - MARGIN_HORIZONTAL - 24).toFloat(), boxTop + 42f, divPaint)

        canvas.withTranslation(MARGIN_HORIZONTAL + 24f, boxTop + 56f) {
            textLayout.draw(canvas)
        }

        // Additional Context Note
        val noteY = boxTop + boxHeight + 40f
        val notePaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(100, 100, 100)
            textSize = 10f
        }
        canvas.drawText("Associated Record Details:", MARGIN_HORIZONTAL.toFloat(), noteY, notePaint)
        canvas.drawText("Email: ${record.email}  |  Place: ${record.place}  |  Age: ${record.age}", MARGIN_HORIZONTAL.toFloat(), noteY + 18f, notePaint)
        canvas.drawText("Generated on ${formatDate(Date())}", MARGIN_HORIZONTAL.toFloat(), noteY + 36f, notePaint)

        // Stamp at bottom
        val stampPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 9f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("YM SECRET • VERIFIED LOCAL RECORD DATA • OFFLINE PRIVACY", PAGE_WIDTH / 2f, (PAGE_HEIGHT - 50).toFloat(), stampPaint)

        pdfDocument.finishPage(page)
        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        Pair(outputFile, 1)
    }
}
