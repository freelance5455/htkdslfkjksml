package com.example.util

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.StatusExpired
import com.example.ui.theme.StatusExpiredBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.StatusWarningBg
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

enum class ValidadeNivel {
    VENCIDO,
    A_VENCER_6_MESES,
    REGULAR
}

data class ValidadeInfo(
    val nivel: ValidadeNivel,
    val diasRestantes: Long,
    val label: String,
    val corTexto: Color,
    val corFundo: Color,
    val formatadaBr: String
)

object ValidadeUtil {
    private val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val brFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    // Período de alerta de validade configurado para 6 meses (~180 dias)
    const val DIAS_ALERTA_VENCIMENTO = 180L

    fun calcularValidade(dataIso: String): ValidadeInfo {
        val hojeCalendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val hoje = hojeCalendar.time

        val dataValidade: Date = try {
            isoFormat.parse(dataIso) ?: hoje
        } catch (e: Exception) {
            hoje
        }

        val dataValCalendar = Calendar.getInstance().apply {
            time = dataValidade
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val diffMillis = dataValCalendar.timeInMillis - hojeCalendar.timeInMillis
        val dias = TimeUnit.MILLISECONDS.toDays(diffMillis)
        val dataFormatadaBr = try {
            brFormat.format(dataValidade)
        } catch (e: Exception) {
            dataIso
        }

        return when {
            dias < 0 -> {
                val diasVencido = kotlin.math.abs(dias)
                ValidadeInfo(
                    nivel = ValidadeNivel.VENCIDO,
                    diasRestantes = dias,
                    label = if (diasVencido == 1L) "Venceu ontem" else "Venceu há $diasVencido dias",
                    corTexto = StatusExpired,
                    corFundo = StatusExpiredBg,
                    formatadaBr = dataFormatadaBr
                )
            }
            dias <= DIAS_ALERTA_VENCIMENTO -> {
                val labelTexto = when {
                    dias == 0L -> "Vence hoje!"
                    dias == 1L -> "Resta 1 dia"
                    dias < 30L -> "Restam $dias dias"
                    dias < 60L -> "Resta ~1 mês ($dias dias)"
                    else -> {
                        val meses = (dias / 30.0).roundToInt()
                        "Restam ~$meses meses ($dias dias)"
                    }
                }
                ValidadeInfo(
                    nivel = ValidadeNivel.A_VENCER_6_MESES,
                    diasRestantes = dias,
                    label = labelTexto,
                    corTexto = StatusWarning,
                    corFundo = StatusWarningBg,
                    formatadaBr = dataFormatadaBr
                )
            }
            else -> {
                ValidadeInfo(
                    nivel = ValidadeNivel.REGULAR,
                    diasRestantes = dias,
                    label = "Regular",
                    corTexto = StatusSuccess,
                    corFundo = StatusSuccessBg,
                    formatadaBr = dataFormatadaBr
                )
            }
        }
    }
}

object CurrencyUtil {
    private val brLocale = Locale("pt", "BR")
    private val formatter = NumberFormat.getCurrencyInstance(brLocale)

    fun formatarMoeda(valor: Double): String {
        return try {
            formatter.format(valor)
        } catch (e: Exception) {
            "R$ %.2f".format(Locale.US, valor).replace('.', ',')
        }
    }

    fun formatarDataHora(millis: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return sdf.format(Date(millis))
    }
}
