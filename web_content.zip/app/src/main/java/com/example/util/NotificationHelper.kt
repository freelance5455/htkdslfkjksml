package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.R
import com.example.data.AppDatabase
import com.example.data.model.NotificationEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class NotificationHelper(
    private val context: Context,
    private val database: AppDatabase,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val channelId = "appbundle_operations_channel"
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "عمليات تحويل وتوقيع التطبيقات",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعارات اكتمال عمليات التحويل والتوقيع والمزامنة السحابية"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun notifyOperationCompleted(title: String, message: String, isSuccess: Boolean = true) {
        // 1. Trigger haptic feedback
        triggerHaptic(isSuccess)

        // 2. Insert into in-app database
        scope.launch {
            database.notificationDao().insertNotification(
                NotificationEntity(
                    title = title,
                    message = message,
                    type = if (isSuccess) "BUILD_SUCCESS" else "BUILD_FAIL"
                )
            )
        }

        // 3. Post system status bar notification
        try {
            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()

            val notificationId = (System.currentTimeMillis() % 10000).toInt()
            notificationManager.notify(notificationId, notification)
        } catch (_: Exception) {
            // Notification permission might be pending on Android 13+
        }
    }

    private fun triggerHaptic(isSuccess: Boolean) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (isSuccess) {
                    // Double pulse for success
                    vibrator.vibrate(
                        VibrationEffect.createWaveform(
                            longArrayOf(0, 80, 50, 120),
                            -1
                        )
                    )
                } else {
                    vibrator.vibrate(
                        VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                }
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(if (isSuccess) 150 else 300)
            }
        } catch (_: Exception) {
            // Haptics not available on emulator or permission denied
        }
    }
}
