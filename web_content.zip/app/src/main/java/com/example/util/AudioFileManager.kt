package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream

object AudioFileManager {

    /**
     * Resolves the user-friendly display name of an audio Uri selected via system picker.
     */
    fun getDisplayName(context: Context, uri: Uri): String {
        var displayName: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0) {
                        displayName = cursor.getString(nameIndex)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return displayName ?: uri.lastPathSegment ?: "Custom Audio"
    }

    /**
     * Copies selected audio to app internal files so it can be reliably accessed anytime,
     * including in background services, after device reboot, and without permission expiration.
     */
    fun copyAudioToAppStorage(context: Context, uri: Uri, originalName: String): String? {
        return try {
            val audioDir = File(context.filesDir, "custom_ringtones").apply {
                if (!exists()) mkdirs()
            }
            val sanitized = originalName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val targetFile = File(audioDir, "${System.currentTimeMillis()}_$sanitized")

            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(targetFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            targetFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
