package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

data class CsvDownloadResult(
    val isSuccess: Boolean,
    val filePath: String,
    val fileName: String,
    val uri: Uri? = null,
    val errorMessage: String? = null
)

object CsvExportHelper {

    /**
     * Saves CSV file to device Downloads directory and cache,
     * providing both physical file persistence and sharing URI.
     */
    fun saveCsvToDownloads(
        context: Context,
        csvContent: String,
        fileName: String
    ): CsvDownloadResult {
        var savedPath = "Downloads/$fileName"
        var contentUri: Uri? = null

        try {
            // 1. Save to system Downloads via MediaStore on Android 10+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { os ->
                        os.write(csvContent.toByteArray(Charsets.UTF_8))
                        os.flush()
                    }
                    contentUri = uri
                }
            } else {
                // Pre-Android 10 legacy storage
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (downloadsDir.exists() || downloadsDir.mkdirs()) {
                    val file = File(downloadsDir, fileName)
                    FileOutputStream(file).use { os ->
                        os.write(csvContent.toByteArray(Charsets.UTF_8))
                        os.flush()
                    }
                    savedPath = file.absolutePath
                }
            }

            // 2. Also save to app cache for FileProvider access (reliable across all Android versions)
            val cacheFile = File(context.cacheDir, fileName)
            FileOutputStream(cacheFile).use { os ->
                os.write(csvContent.toByteArray(Charsets.UTF_8))
                os.flush()
            }

            val fileProviderUri = try {
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    cacheFile
                )
            } catch (e: Exception) {
                null
            }

            // Also save to app's external files directory as permanent fallback
            try {
                val extFilesDir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                if (extFilesDir != null) {
                    val extFile = File(extFilesDir, fileName)
                    FileOutputStream(extFile).use { os ->
                        os.write(csvContent.toByteArray(Charsets.UTF_8))
                        os.flush()
                    }
                    if (savedPath.startsWith("Downloads/")) {
                        savedPath = "Downloads/$fileName (and ${extFile.name})"
                    }
                }
            } catch (ignored: Exception) {}

            return CsvDownloadResult(
                isSuccess = true,
                filePath = savedPath,
                fileName = fileName,
                uri = fileProviderUri ?: contentUri
            )
        } catch (e: Exception) {
            e.printStackTrace()
            return CsvDownloadResult(
                isSuccess = false,
                filePath = "",
                fileName = fileName,
                errorMessage = e.localizedMessage ?: "Unknown file error"
            )
        }
    }

    /**
     * Downloads and opens the Android share sheet if supported.
     */
    fun downloadAndShareCsv(
        context: Context,
        csvContent: String,
        fileName: String,
        title: String = "Download CSV"
    ): CsvDownloadResult {
        val result = saveCsvToDownloads(context, csvContent, fileName)

        if (result.isSuccess) {
            Toast.makeText(context, "Saved to Downloads: $fileName", Toast.LENGTH_LONG).show()

            // Open share intent if URI available
            if (result.uri != null) {
                try {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/csv"
                        putExtra(Intent.EXTRA_STREAM, result.uri)
                        putExtra(Intent.EXTRA_SUBJECT, fileName)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    val chooser = Intent.createChooser(sendIntent, title).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(chooser)
                } catch (e: Exception) {
                    // Chooser failed or no compatible apps; fallback to copying or toast
                    e.printStackTrace()
                }
            }
        } else {
            Toast.makeText(context, "Failed to save: ${result.errorMessage}", Toast.LENGTH_SHORT).show()
        }

        return result
    }

    fun copyToClipboard(context: Context, text: String, label: String = "CredPay CSV") {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(label, text)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(context, "CSV copied to clipboard!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Could not copy to clipboard", Toast.LENGTH_SHORT).show()
        }
    }
}
