package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.AttachmentKind
import com.example.data.model.PendingAttachment
import com.example.data.model.ResolvedAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.ZipInputStream

object AttachmentReader {

    // Gemini inlineData total request limit is 20 MB; base64 adds ~33% overhead, so keep raw payload <= 13 MB.
    private const val MAX_TOTAL_RAW_BYTES = 13L * 1024L * 1024L
    private const val MAX_VIDEO_INLINE_BYTES = 11L * 1024L * 1024L
    private const val MAX_TEXT_CHARS = 120_000
    private const val MAX_IMAGE_DIM_PX = 1600
    private const val MAX_VIDEO_FRAME_DIM_PX = 1024
    private const val VIDEO_KEYFRAMES_COUNT = 6

    private val textExtensions = setOf(
        "txt", "md", "csv", "tsv", "json", "xml", "html", "htm", "css", "scss", "js", "jsx", "ts", "tsx",
        "kt", "kts", "java", "py", "c", "cpp", "h", "hpp", "rs", "go", "sh", "bat", "ps1", "rb", "php",
        "swift", "dart", "vue", "svg", "yaml", "yml", "toml", "properties", "gradle", "sql", "log", "ini",
        "conf", "cfg", "env", "rtf"
    )

    private val officeXmlExtensions = setOf("docx", "xlsx", "pptx", "odt", "ods", "odp")

    private val geminiInlineVideoMimes = setOf(
        "video/mp4", "video/mpeg", "video/mov", "video/quicktime", "video/avi",
        "video/x-flv", "video/mpg", "video/webm", "video/wmv", "video/3gpp"
    )

    fun inspectUri(context: Context, uri: Uri): PendingAttachment? {
        val resolver = context.contentResolver
        try {
            resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }

        var displayName = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() } ?: "file"
        var sizeBytes = 0L

        try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0) {
                        displayName = cursor.getString(nameIdx)?.takeIf { it.isNotBlank() } ?: displayName
                    }
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                        sizeBytes = cursor.getLong(sizeIdx).coerceAtLeast(0L)
                    }
                }
            }
        } catch (_: Exception) {
        }

        if (sizeBytes <= 0L) {
            sizeBytes = try {
                resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                    afd.length.takeIf { it > 0L } ?: 0L
                } ?: 0L
            } catch (_: Exception) {
                0L
            }
        }

        val rawMime = resolver.getType(uri)?.lowercase(Locale.ROOT)?.substringBefore(';')?.trim().orEmpty()
        val ext = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val effectiveMime = resolveMimeType(rawMime, ext)
        if (!displayName.contains('.') && effectiveMime != "application/octet-stream") {
            val inferredExt = extensionForMime(effectiveMime)
            if (inferredExt != null) displayName = "$displayName.$inferredExt"
        }
        val kind = classifyKind(effectiveMime, displayName.substringAfterLast('.', "").lowercase(Locale.ROOT))

        return PendingAttachment(
            uriString = uri.toString(),
            displayName = displayName,
            mimeType = effectiveMime,
            sizeBytes = sizeBytes,
            kind = kind
        )
    }

    suspend fun readAttachments(
        context: Context,
        items: List<PendingAttachment>
    ): List<ResolvedAttachment> = withContext(Dispatchers.IO) {
        var accumulatedBytes = 0L
        val resolved = mutableListOf<ResolvedAttachment>()

        for (item in items) {
            val uri = Uri.parse(item.uriString)
            val results = readSingle(context, uri, item)
            for (result in results) {
                val partSize = result.bytes?.size?.toLong() ?: (result.extractedText?.length?.toLong() ?: 0L)
                accumulatedBytes += partSize
                if (accumulatedBytes > MAX_TOTAL_RAW_BYTES) {
                    throw IllegalArgumentException(
                        "Общий размер вложений превышает допустимый лимит (~13 МБ для передачи в Gemini). Уменьшите количество файлов или их размер."
                    )
                }
                resolved.add(result)
            }
        }

        resolved
    }

    private fun readSingle(
        context: Context,
        uri: Uri,
        item: PendingAttachment
    ): List<ResolvedAttachment> {
        val resolver = context.contentResolver
        val ext = item.displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)

        if (item.kind == AttachmentKind.PHOTO) {
            val rawBytes = readBytesBounded(resolver, uri, item.displayName, 25L * 1024L * 1024L)
            val optimizedBytes = optimizeImageBytes(rawBytes, item.mimeType)
            val finalMime = if (optimizedBytes !== rawBytes || item.mimeType !in setOf("image/jpeg", "image/png", "image/webp")) {
                "image/jpeg"
            } else {
                item.mimeType
            }
            return listOf(
                ResolvedAttachment(
                    displayName = item.displayName,
                    mimeType = finalMime,
                    sizeBytes = optimizedBytes.size.toLong(),
                    kind = AttachmentKind.PHOTO,
                    bytes = optimizedBytes
                )
            )
        }

        if (item.kind == AttachmentKind.VIDEO) {
            val mimeNorm = normalizeVideoMime(item.mimeType, ext)
            val knownLarge = item.sizeBytes > MAX_VIDEO_INLINE_BYTES
            if (!knownLarge && mimeNorm in geminiInlineVideoMimes) {
                val inlineAttempt = readBytesUpTo(resolver, uri, MAX_VIDEO_INLINE_BYTES)
                if (inlineAttempt != null) {
                    return listOf(
                        ResolvedAttachment(
                            displayName = item.displayName,
                            mimeType = mimeNorm,
                            sizeBytes = inlineAttempt.size.toLong(),
                            kind = AttachmentKind.VIDEO,
                            bytes = inlineAttempt
                        )
                    )
                }
            }
            // Video exceeds inline payload cap or uses a container like MKV -> extract key frames locally
            return extractVideoFramesFallback(context, uri, item)
        }

        if (ext in officeXmlExtensions || isOfficeXmlMime(item.mimeType)) {
            val rawBytes = readBytesBounded(resolver, uri, item.displayName, 16L * 1024L * 1024L)
            val extracted = extractOfficeXmlText(rawBytes, ext)
            if (extracted.isNotBlank()) {
                return listOf(
                    ResolvedAttachment(
                        displayName = item.displayName,
                        mimeType = "text/plain",
                        sizeBytes = rawBytes.size.toLong(),
                        kind = AttachmentKind.DOCUMENT,
                        extractedText = extracted.take(MAX_TEXT_CHARS)
                    )
                )
            }
            throw IllegalArgumentException(
                "Документ «${item.displayName}» пуст или защищён от чтения. Попробуйте сохранить его в PDF или TXT."
            )
        }

        if (item.kind == AttachmentKind.TEXT || ext in textExtensions) {
            val rawBytes = readBytesBounded(resolver, uri, item.displayName, 4L * 1024L * 1024L)
            val text = rawBytes.toString(Charsets.UTF_8).take(MAX_TEXT_CHARS)
            return listOf(
                ResolvedAttachment(
                    displayName = item.displayName,
                    mimeType = "text/plain",
                    sizeBytes = rawBytes.size.toLong(),
                    kind = AttachmentKind.TEXT,
                    extractedText = text
                )
            )
        }

        if (item.kind == AttachmentKind.PDF) {
            val bytes = readBytesBounded(resolver, uri, item.displayName, MAX_TOTAL_RAW_BYTES)
            return listOf(
                ResolvedAttachment(
                    displayName = item.displayName,
                    mimeType = "application/pdf",
                    sizeBytes = bytes.size.toLong(),
                    kind = AttachmentKind.PDF,
                    bytes = bytes
                )
            )
        }

        if (item.kind == AttachmentKind.AUDIO) {
            val bytes = readBytesBounded(resolver, uri, item.displayName, MAX_TOTAL_RAW_BYTES)
            val safeAudioMime = normalizeAudioMime(item.mimeType, ext)
            return listOf(
                ResolvedAttachment(
                    displayName = item.displayName,
                    mimeType = safeAudioMime,
                    sizeBytes = bytes.size.toLong(),
                    kind = AttachmentKind.AUDIO,
                    bytes = bytes
                )
            )
        }

        // Generic unknown DOCUMENT: check if readable UTF-8 text or reject unsupported binary cleanly
        val probeBytes = readBytesBounded(resolver, uri, item.displayName, 4L * 1024L * 1024L)
        if (isMostlyPrintableText(probeBytes)) {
            return listOf(
                ResolvedAttachment(
                    displayName = item.displayName,
                    mimeType = "text/plain",
                    sizeBytes = probeBytes.size.toLong(),
                    kind = AttachmentKind.TEXT,
                    extractedText = probeBytes.toString(Charsets.UTF_8).take(MAX_TEXT_CHARS)
                )
            )
        }

        throw IllegalArgumentException(
            "Формат файла «${item.displayName}» (${item.mimeType}) не поддерживается для прямого анализа. Поддерживаются фото, видео, аудио, PDF, DOCX/XLSX/PPTX и текстовые/код-файлы."
        )
    }

    private fun extractVideoFramesFallback(
        context: Context,
        uri: Uri,
        item: PendingAttachment
    ): List<ResolvedAttachment> {
        val retriever = MediaMetadataRetriever()
        val results = mutableListOf<ResolvedAttachment>()
        try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH).orEmpty()
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT).orEmpty()

            val frameCount = if (durationMs > 2_000L) VIDEO_KEYFRAMES_COUNT else 3
            val safeDurationUs = maxOf(1_000_000L, durationMs * 1000L)

            var extractedFrames = 0
            for (i in 0 until frameCount) {
                val timeUs = ((i + 0.5) / frameCount.toDouble() * safeDurationUs).toLong()
                val rawBmp = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: retriever.getFrameAtTime(timeUs)
                    ?: continue
                val scaled = scaleBitmapDown(rawBmp, MAX_VIDEO_FRAME_DIM_PX)
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 78, out)
                if (scaled !== rawBmp) rawBmp.recycle()
                scaled.recycle()

                extractedFrames++
                results.add(
                    ResolvedAttachment(
                        displayName = "${item.displayName}_frame_$extractedFrames.jpg",
                        mimeType = "image/jpeg",
                        sizeBytes = out.size().toLong(),
                        kind = AttachmentKind.PHOTO,
                        bytes = out.toByteArray()
                    )
                )
            }

            if (extractedFrames == 0) {
                throw IllegalStateException("Не удалось извлечь кадры из видео.")
            }

            val durSec = (durationMs / 1000.0)
            val metaText = buildString {
                append("Видео «${item.displayName}» (${formatFileSize(item.sizeBytes)}) обработано через ключевые кадры. ")
                if (durationMs > 0) append(String.format(Locale.US, "Длительность: %.1f сек. ", durSec))
                if (width.isNotBlank() && height.isNotBlank()) append("Разрешение: ${width}x${height}. ")
                append("Приложено $extractedFrames последовательных ключевых кадров от начала до конца видео для визуального анализа.")
            }
            results.add(
                0,
                ResolvedAttachment(
                    displayName = "${item.displayName} (метаданные видео)",
                    mimeType = "text/plain",
                    sizeBytes = metaText.length.toLong(),
                    kind = AttachmentKind.TEXT,
                    extractedText = metaText
                )
            )
            return results
        } catch (e: Exception) {
            throw IllegalArgumentException(
                "Не удалось обработать видео «${item.displayName}» (${e.localizedMessage ?: "неподдерживаемый кодек"}). Попробуйте более короткий или MP4-ролик."
            )
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun readBytesUpTo(
        resolver: android.content.ContentResolver,
        uri: Uri,
        maxBytes: Long
    ): ByteArray? {
        return resolver.openInputStream(uri)?.use { stream ->
            val buffer = ByteArrayOutputStream()
            val chunk = ByteArray(16 * 1024)
            var total = 0L
            while (true) {
                val read = stream.read(chunk)
                if (read <= 0) break
                total += read
                if (total > maxBytes) {
                    return null
                }
                buffer.write(chunk, 0, read)
            }
            buffer.toByteArray()
        }
    }

    private fun readBytesBounded(
        resolver: android.content.ContentResolver,
        uri: Uri,
        displayName: String,
        maxBytes: Long
    ): ByteArray {
        return resolver.openInputStream(uri)?.use { stream ->
            val buffer = ByteArrayOutputStream()
            val chunk = ByteArray(16 * 1024)
            var total = 0L
            while (true) {
                val read = stream.read(chunk)
                if (read <= 0) break
                total += read
                if (total > maxBytes) {
                    throw IllegalArgumentException(
                        "Файл «$displayName» превышает допустимый лимит (${formatFileSize(maxBytes)})."
                    )
                }
                buffer.write(chunk, 0, read)
            }
            buffer.toByteArray()
        } ?: throw IllegalStateException("Нет доступа к файлу «$displayName». Попробуйте выбрать его повторно.")
    }

    private fun optimizeImageBytes(rawBytes: ByteArray, mimeType: String): ByteArray {
        val supportedDirect = mimeType == "image/jpeg" || mimeType == "image/png" || mimeType == "image/webp"
        if (rawBytes.size <= 1_100_000 && supportedDirect) {
            return rawBytes
        }
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return rawBytes

            var sampleSize = 1
            while (bounds.outWidth / sampleSize > MAX_IMAGE_DIM_PX || bounds.outHeight / sampleSize > MAX_IMAGE_DIM_PX) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val bitmap = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, decodeOpts) ?: return rawBytes
            val scaled = scaleBitmapDown(bitmap, MAX_IMAGE_DIM_PX)
            if (scaled !== bitmap) bitmap.recycle()
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 84, out)
            scaled.recycle()
            out.toByteArray()
        } catch (_: Exception) {
            rawBytes
        }
    }

    private fun scaleBitmapDown(bitmap: Bitmap, maxDim: Int): Bitmap {
        if (bitmap.width <= maxDim && bitmap.height <= maxDim) return bitmap
        val ratio = minOf(
            maxDim.toFloat() / bitmap.width,
            maxDim.toFloat() / bitmap.height
        )
        return Bitmap.createScaledBitmap(
            bitmap,
            maxOf(1, (bitmap.width * ratio).toInt()),
            maxOf(1, (bitmap.height * ratio).toInt()),
            true
        )
    }

    private fun extractOfficeXmlText(rawBytes: ByteArray, ext: String): String {
        val xmlTargets = when (ext) {
            "docx" -> setOf("word/document.xml", "word/header1.xml", "word/footer1.xml")
            "xlsx" -> setOf("xl/sharedStrings.xml", "xl/worksheets/sheet1.xml", "xl/worksheets/sheet2.xml")
            "pptx" -> null // collect ppt/slides/slide*.xml
            "odt", "ods", "odp" -> setOf("content.xml")
            else -> null
        }

        val collected = StringBuilder()
        try {
            ZipInputStream(rawBytes.inputStream()).use { zis ->
                while (true) {
                    val entry = zis.nextEntry ?: break
                    val name = entry.name
                    val matches = when {
                        entry.isDirectory -> false
                        xmlTargets != null -> name in xmlTargets || (ext == "xlsx" && name.startsWith("xl/worksheets/sheet") && name.endsWith(".xml"))
                        ext == "pptx" -> name.startsWith("ppt/slides/slide") && name.endsWith(".xml")
                        else -> name.endsWith(".xml") && !name.contains("_rels")
                    }
                    if (matches) {
                        val xmlStr = zis.readBytes().toString(Charsets.UTF_8)
                        val plain = xmlStr
                            .replace(Regex("</w:p>|</text:p>|</a:p>|</row>|</si>|</t>"), "\n")
                            .replace(Regex("<[^>]+>"), " ")
                            .replace("&amp;", "&")
                            .replace("&lt;", "<")
                            .replace("&gt;", ">")
                            .replace("&quot;", "\"")
                            .replace("&apos;", "'")
                            .replace(Regex("[ \\t]+"), " ")
                            .replace(Regex("\\n{3,}"), "\n\n")
                            .trim()
                        if (plain.isNotBlank()) {
                            collected.append(plain).append("\n\n")
                        }
                    }
                    zis.closeEntry()
                    if (collected.length >= MAX_TEXT_CHARS) break
                }
            }
        } catch (_: Exception) {
        }
        return collected.toString().trim()
    }

    private fun isMostlyPrintableText(bytes: ByteArray): Boolean {
        if (bytes.isEmpty()) return false
        val sample = bytes.take(minOf(bytes.size, 4096))
        var controlCount = 0
        for (b in sample) {
            val v = b.toInt() and 0xFF
            if (v == 0) return false
            if (v < 0x20 && v != 0x09 && v != 0x0A && v != 0x0D) {
                controlCount++
            }
        }
        return controlCount.toDouble() / sample.size < 0.05
    }

    private fun isOfficeXmlMime(mime: String): Boolean {
        return mime.contains("wordprocessingml") ||
            mime.contains("spreadsheetml") ||
            mime.contains("presentationml") ||
            mime.contains("oasis.opendocument")
    }

    private fun normalizeVideoMime(mime: String, ext: String): String {
        return when {
            ext == "mov" || mime == "video/quicktime" -> "video/mov"
            mime.startsWith("video/") && mime != "video/x-matroska" -> mime
            ext == "webm" -> "video/webm"
            ext == "3gp" -> "video/3gpp"
            ext == "avi" -> "video/avi"
            else -> "video/mp4"
        }
    }

    private fun normalizeAudioMime(mime: String, ext: String): String {
        return when {
            ext == "mp3" || mime == "audio/mpeg" -> "audio/mp3"
            ext == "wav" || mime == "audio/x-wav" || mime == "audio/vnd.wave" -> "audio/wav"
            ext == "m4a" || mime == "audio/x-m4a" -> "audio/mp4"
            ext == "aac" -> "audio/aac"
            ext == "ogg" || ext == "oga" -> "audio/ogg"
            ext == "flac" -> "audio/flac"
            mime.startsWith("audio/") -> mime
            else -> "audio/mp3"
        }
    }

    private fun extensionForMime(mime: String): String? = when (mime) {
        "image/jpeg" -> "jpg"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/gif" -> "gif"
        "video/mp4" -> "mp4"
        "video/quicktime", "video/mov" -> "mov"
        "video/webm" -> "webm"
        "audio/mpeg", "audio/mp3" -> "mp3"
        "audio/wav", "audio/x-wav" -> "wav"
        "audio/aac" -> "aac"
        "audio/ogg" -> "ogg"
        "application/pdf" -> "pdf"
        "text/plain" -> "txt"
        else -> null
    }

    private fun resolveMimeType(rawMime: String, ext: String): String {
        if (rawMime.isNotBlank() && rawMime != "application/octet-stream") return rawMime
        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "heic" -> "image/heic"
            "heif" -> "image/heif"
            "mp4" -> "video/mp4"
            "mov" -> "video/mov"
            "webm" -> "video/webm"
            "3gp" -> "video/3gpp"
            "avi" -> "video/avi"
            "mkv" -> "video/x-matroska"
            "mp3" -> "audio/mp3"
            "wav" -> "audio/wav"
            "m4a" -> "audio/mp4"
            "aac" -> "audio/aac"
            "ogg" -> "audio/ogg"
            "flac" -> "audio/flac"
            "pdf" -> "application/pdf"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            in textExtensions -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    private fun classifyKind(mime: String, ext: String): AttachmentKind {
        return when {
            mime.startsWith("image/") -> AttachmentKind.PHOTO
            mime.startsWith("video/") -> AttachmentKind.VIDEO
            mime.startsWith("audio/") -> AttachmentKind.AUDIO
            mime == "application/pdf" || ext == "pdf" -> AttachmentKind.PDF
            ext in officeXmlExtensions || isOfficeXmlMime(mime) -> AttachmentKind.DOCUMENT
            mime.startsWith("text/") || ext in textExtensions -> AttachmentKind.TEXT
            else -> AttachmentKind.DOCUMENT
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "файл"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format(Locale.US, "%.1f МБ", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.0f КБ", kb)
            else -> "$bytes Б"
        }
    }
}
