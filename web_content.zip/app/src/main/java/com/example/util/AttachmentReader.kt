package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.AttachmentKind
import com.example.data.model.PendingAttachment
import com.example.data.model.ResolvedAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Locale

object AttachmentReader {

    // Gemini inlineData total request limit is 20 MB; base64 adds ~33% overhead, so keep raw payload <= 14 MB.
    private const val MAX_TOTAL_RAW_BYTES = 14L * 1024L * 1024L
    private const val MAX_TEXT_CHARS = 120_000
    private const val MAX_IMAGE_DIM_PX = 2048

    private val textExtensions = setOf(
        "txt", "md", "csv", "json", "xml", "html", "htm", "css", "js", "ts",
        "kt", "kts", "java", "py", "c", "cpp", "h", "hpp", "rs", "go", "sh",
        "yaml", "yml", "toml", "properties", "gradle", "sql", "log", "ini", "env"
    )

    fun inspectUri(context: Context, uri: Uri): PendingAttachment? {
        val resolver = context.contentResolver
        var displayName = "file"
        var sizeBytes = 0L

        try {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx >= 0) {
                        displayName = cursor.getString(nameIdx)?.takeIf { it.isNotBlank() } ?: displayName
                    }
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                        sizeBytes = cursor.getLong(sizeIdx)
                    }
                }
            }
        } catch (_: Exception) {
        }

        val rawMime = resolver.getType(uri)?.lowercase(Locale.ROOT).orEmpty()
        val ext = displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        val effectiveMime = resolveMimeType(rawMime, ext)
        val kind = classifyKind(effectiveMime, ext)

        return PendingAttachment(
            uriString = uri.toString(),
            displayName = displayName,
            mimeType = effectiveMime,
            sizeBytes = sizeBytes,
            kind = kind
        )
    }

    suspend fun readAttachments(
        context: Context,
        items: List<PendingAttachment>
    ): List<ResolvedAttachment> = withContext(Dispatchers.IO) {
        var accumulatedBytes = 0L
        val resolved = mutableListOf<ResolvedAttachment>()

        for (item in items) {
            val uri = Uri.parse(item.uriString)
            val result = readSingle(context, uri, item)
            val partSize = result.bytes?.size?.toLong() ?: (result.extractedText?.length?.toLong() ?: 0L)
            accumulatedBytes += partSize
            if (accumulatedBytes > MAX_TOTAL_RAW_BYTES) {
                throw IllegalArgumentException(
                    "Общий размер вложений превышает допустимый лимит (~14 МБ для быстрой отправки в Gemini). Удалите лишний файл или сожмите видео."
                )
            }
            resolved.add(result)
        }

        resolved
    }

    private fun readSingle(
        context: Context,
        uri: Uri,
        item: PendingAttachment
    ): ResolvedAttachment {
        val resolver = context.contentResolver
        val ext = item.displayName.substringAfterLast('.', "").lowercase(Locale.ROOT)

        if (item.kind == AttachmentKind.TEXT || ext in textExtensions) {
            val rawBytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Не удалось прочитать файл «${item.displayName}».")
            if (rawBytes.size > 4 * 1024 * 1024) {
                throw IllegalArgumentException("Текстовый файл «${item.displayName}» слишком большой (максимум 4 МБ).")
            }
            val text = rawBytes.toString(Charsets.UTF_8).take(MAX_TEXT_CHARS)
            return ResolvedAttachment(
                displayName = item.displayName,
                mimeType = "text/plain",
                sizeBytes = rawBytes.size.toLong(),
                kind = AttachmentKind.TEXT,
                extractedText = text
            )
        }

        if (item.kind == AttachmentKind.PHOTO) {
            val rawBytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Не удалось открыть изображение «${item.displayName}».")
            val optimizedBytes = optimizeImageBytes(rawBytes, item.mimeType)
            val finalMime = if (optimizedBytes !== rawBytes) "image/jpeg" else item.mimeType
            return ResolvedAttachment(
                displayName = item.displayName,
                mimeType = finalMime,
                sizeBytes = optimizedBytes.size.toLong(),
                kind = AttachmentKind.PHOTO,
                bytes = optimizedBytes
            )
        }

        // Video, PDF, Audio, or generic binary document
        if (item.sizeBytes > MAX_TOTAL_RAW_BYTES) {
            throw IllegalArgumentException(
                "Файл «${item.displayName}» весит ${formatFileSize(item.sizeBytes)}. Максимальный размер для прямого анализа — 14 МБ."
            )
        }

        val bytes = resolver.openInputStream(uri)?.use { stream ->
            val buffer = ByteArrayOutputStream()
            val chunk = ByteArray(16 * 1024)
            var total = 0L
            while (true) {
                val read = stream.read(chunk)
                if (read <= 0) break
                total += read
                if (total > MAX_TOTAL_RAW_BYTES) {
                    throw IllegalArgumentException(
                        "Файл «${item.displayName}» превышает лимит 14 МБ для анализа."
                    )
                }
                buffer.write(chunk, 0, read)
            }
            buffer.toByteArray()
        } ?: throw IllegalStateException("Не удалось прочитать файл «${item.displayName}».")

        val safeMime = when {
            item.kind == AttachmentKind.PDF -> "application/pdf"
            item.mimeType.isNotBlank() && item.mimeType != "application/octet-stream" -> item.mimeType
            item.kind == AttachmentKind.VIDEO -> "video/mp4"
            item.kind == AttachmentKind.AUDIO -> "audio/mpeg"
            else -> "application/pdf"
        }

        return ResolvedAttachment(
            displayName = item.displayName,
            mimeType = safeMime,
            sizeBytes = bytes.size.toLong(),
            kind = item.kind,
            bytes = bytes
        )
    }

    private fun optimizeImageBytes(rawBytes: ByteArray, mimeType: String): ByteArray {
        if (rawBytes.size <= 1_400_000 && (mimeType == "image/jpeg" || mimeType == "image/png" || mimeType == "image/webp")) {
            return rawBytes
        }
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, bounds)
            var sampleSize = 1
            while (bounds.outWidth / sampleSize > MAX_IMAGE_DIM_PX || bounds.outHeight / sampleSize > MAX_IMAGE_DIM_PX) {
                sampleSize *= 2
            }
            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sampleSize }
            val bitmap = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size, decodeOpts) ?: return rawBytes
            val scaled = if (bitmap.width > MAX_IMAGE_DIM_PX || bitmap.height > MAX_IMAGE_DIM_PX) {
                val ratio = minOf(
                    MAX_IMAGE_DIM_PX.toFloat() / bitmap.width,
                    MAX_IMAGE_DIM_PX.toFloat() / bitmap.height
                )
                Bitmap.createScaledBitmap(
                    bitmap,
                    maxOf(1, (bitmap.width * ratio).toInt()),
                    maxOf(1, (bitmap.height * ratio).toInt()),
                    true
                ).also {
                    if (it !== bitmap) bitmap.recycle()
                }
            } else {
                bitmap
            }
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 86, out)
            scaled.recycle()
            out.toByteArray()
        } catch (_: Exception) {
            rawBytes
        }
    }

    private fun resolveMimeType(rawMime: String, ext: String): String {
        if (rawMime.isNotBlank() && rawMime != "application/octet-stream") return rawMime
        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "mp4" -> "video/mp4"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "3gp" -> "video/3gpp"
            "mkv" -> "video/x-matroska"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "m4a", "aac" -> "audio/aac"
            "ogg" -> "audio/ogg"
            "pdf" -> "application/pdf"
            in textExtensions -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    private fun classifyKind(mime: String, ext: String): AttachmentKind {
        return when {
            mime.startsWith("image/") -> AttachmentKind.PHOTO
            mime.startsWith("video/") -> AttachmentKind.VIDEO
            mime.startsWith("audio/") -> AttachmentKind.AUDIO
            mime == "application/pdf" || ext == "pdf" -> AttachmentKind.PDF
            mime.startsWith("text/") || ext in textExtensions -> AttachmentKind.TEXT
            else -> AttachmentKind.TEXT
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "файл"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format(Locale.US, "%.1f МБ", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.0f КБ", kb)
            else -> "$bytes Б"
        }
    }
}
