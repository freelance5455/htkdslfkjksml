package com.example.util

import android.content.Context
import android.net.Uri
import com.example.data.model.SandboxSpec
import com.example.data.model.SandboxWidget
import com.example.data.model.StudioProject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class ConverterSourceType(val id: String, val label: String) {
    MADE_HERE("MADE_HERE", "Apps/Websites Made Here"),
    PASTED_HTML("PASTED_HTML", "Paste / Edit HTML"),
    EXTERNAL_HTML("EXTERNAL_HTML", "Import .html File"),
    EXTERNAL_ZIP("EXTERNAL_ZIP", "Import .zip Archive")
}

enum class ConverterIconPreset(
    val id: String,
    val label: String,
    val bgHex: String,
    val fgHex: String,
    val glyphCode: String
) {
    ROCKET("ROCKET", "Launch Rocket", "#0F172A", "#38BDF8", "M12,2.5L6.5,11H10V21.5L17.5,13H14L12,2.5Z"),
    GLOBE("GLOBE", "Web Globe", "#064E3B", "#34D399", "M12,2A10,10 0 1,0 22,12A10,10 0 0,0 12,2M4,12H20M12,4A15,15 0 0,1 15,12A15,15 0 0,1 12,20A15,15 0 0,1 9,12A15,15 0 0,1 12,4Z"),
    SPARK("SPARK", "AI Spark", "#311042", "#F472B6", "M12,2L14.8,9.2L22,12L14.8,14.8L12,22L9.2,14.8L2,12L9.2,9.2L12,2Z"),
    CODE("CODE", "Dev Brackets", "#1E1B4B", "#818CF8", "M8,5L3,12L8,19M16,5L21,12L16,19"),
    COMMERCE("COMMERCE", "Storefront", "#451A03", "#FBBF24", "M4,6H20V9H4V6M5,11H19V20H5V11Z");

    companion object {
        fun fromId(id: String): ConverterIconPreset =
            entries.firstOrNull { it.id == id } ?: ROCKET
    }
}

data class ExtractedWebBundle(
    val sourceLabel: String,
    val entryHtmlFileName: String,
    val mainHtmlContent: String,
    val additionalFiles: Map<String, ByteArray> = emptyMap()
)

data class ConvertedAppConfig(
    val appName: String = "OmniWeb Native App",
    val packageName: String = "com.omniprompt.converted.app",
    val versionName: String = "1.0.0",
    val versionCode: Int = 1,
    val themeColorHex: String = "#38BDF8",
    val iconPresetId: String = ConverterIconPreset.ROCKET.id,
    val customIconBgHex: String = "#0F172A",
    val customIconFgHex: String = "#38BDF8",
    val customIconUriString: String = "",
    // AdMob / Monetization Controls
    val adsEnabled: Boolean = false,
    val adMobAppId: String = "",
    val bannerAdUnitId: String = "",
    val bannerPlacement: String = "BOTTOM", // "BOTTOM" or "TOP"
    val interstitialAdUnitId: String = "",
    val interstitialOnLaunch: Boolean = false,
    val rewardedAdUnitId: String = "",
    // Native WebView Shell Controls
    val orientation: String = "PORTRAIT", // "PORTRAIT", "LANDSCAPE", "SENSOR"
    val fullscreenImmersive: Boolean = false,
    val enablePullToRefresh: Boolean = true,
    val enableSplashHeader: Boolean = true,
    val enableJavaScript: Boolean = true,
    val enableDomStorage: Boolean = true,
    val enableOfflineCache: Boolean = true,
    val enableFileUpload: Boolean = true,
    val enableZoomControls: Boolean = false,
    // Permissions
    val permCamera: Boolean = false,
    val permLocation: Boolean = false,
    val permVibrate: Boolean = true,
    val permNotifications: Boolean = false
)

object WebToAndroidAppPackager {

    fun defaultStarterHtml(appName: String): String = """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>$appName</title>
  <style>
    :root { --accent: #38BDF8; --bg: #0B1120; --card: #1E293B; --text: #F8FAFC; }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, sans-serif; }
    body { background: var(--bg); color: var(--text); padding: 20px; line-height: 1.5; }
    .card { background: var(--card); border-radius: 16px; padding: 20px; border: 1px solid rgba(56,189,248,0.25); margin-bottom: 16px; }
    h1 { font-size: 1.4rem; color: var(--accent); margin-bottom: 8px; }
    p { font-size: 0.92rem; color: #94A3B8; margin-bottom: 14px; }
    button { background: var(--accent); color: #0F172A; border: none; border-radius: 10px; padding: 12px 16px; font-weight: 700; width: 100%; cursor: pointer; }
    .output { margin-top: 12px; font-weight: 600; color: #34D399; font-size: 0.9rem; }
  </style>
</head>
<body>
  <div class="card">
    <h1>$appName</h1>
    <p>Converted into a Native Android WebView App with custom icon, AdMob bridge, and offline asset packaging.</p>
    <button onclick="triggerNativeAction()">Test Native Android Bridge</button>
    <div id="status" class="output">Ready for interaction.</div>
  </div>
  <script>
    function triggerNativeAction() {
      const el = document.getElementById('status');
      el.textContent = 'Native Bridge Active • Timestamp: ' + new Date().toLocaleTimeString();
      if (window.OmniApp && window.OmniApp.showToast) {
        window.OmniApp.showToast('Hello from converted HTML5 app!');
      }
    }
  </script>
</body>
</html>
    """.trimIndent()

    suspend fun readExternalHtmlUri(
        context: Context,
        uri: Uri
    ): Result<ExtractedWebBundle> = withContext(Dispatchers.IO) {
        try {
            val content = context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.bufferedReader(Charsets.UTF_8).readText()
            } ?: throw IllegalStateException("Unable to read selected HTML file.")

            if (content.isBlank()) {
                throw IllegalArgumentException("Selected HTML file is empty.")
            }

            val fileName = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "index.html" } ?: "index.html"
            Result.success(
                ExtractedWebBundle(
                    sourceLabel = "Imported HTML ($fileName)",
                    entryHtmlFileName = "index.html",
                    mainHtmlContent = content,
                    additionalFiles = emptyMap()
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun parseExternalZipUri(
        context: Context,
        uri: Uri
    ): Result<ExtractedWebBundle> = withContext(Dispatchers.IO) {
        try {
            val extractedFiles = linkedMapOf<String, ByteArray>()
            var detectedHtmlEntryName: String? = null
            var detectedHtmlContent: String? = null

            context.contentResolver.openInputStream(uri)?.use { rawStream ->
                ZipInputStream(rawStream).use { zis ->
                    var entry: ZipEntry? = zis.nextEntry
                    var totalBytesRead = 0L
                    val maxTotalBytes = 15L * 1024L * 1024L // 15 MB safety cap

                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val cleanEntryName = entry.name
                                .replace("\\", "/")
                                .trimStart('/')
                                .takeIf { !it.contains("..") }

                            if (!cleanEntryName.isNullOrBlank()) {
                                val baos = ByteArrayOutputStream()
                                val buffer = ByteArray(4096)
                                var count: Int
                                while (zis.read(buffer).also { count = it } != -1) {
                                    totalBytesRead += count
                                    if (totalBytesRead > maxTotalBytes) {
                                        throw IllegalStateException("ZIP archive exceeds 15 MB in-memory bundle limit.")
                                    }
                                    baos.write(buffer, 0, count)
                                }
                                val bytes = baos.toByteArray()
                                extractedFiles[cleanEntryName] = bytes

                                val lower = cleanEntryName.lowercase(Locale.US)
                                if (lower.endsWith("index.html") || lower.endsWith("index.htm")) {
                                    detectedHtmlEntryName = cleanEntryName
                                    detectedHtmlContent = bytes.toString(Charsets.UTF_8)
                                } else if (detectedHtmlContent == null && (lower.endsWith(".html") || lower.endsWith(".htm"))) {
                                    detectedHtmlEntryName = cleanEntryName
                                    detectedHtmlContent = bytes.toString(Charsets.UTF_8)
                                }
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            } ?: throw IllegalStateException("Unable to open selected ZIP archive.")

            if (extractedFiles.isEmpty()) {
                throw IllegalArgumentException("Selected ZIP file does not contain any files.")
            }

            val finalHtml = detectedHtmlContent ?: buildFallbackZipIndexHtml(extractedFiles.keys.toList())
            val finalEntryName = detectedHtmlEntryName ?: "index.html"

            Result.success(
                ExtractedWebBundle(
                    sourceLabel = "Imported ZIP (${extractedFiles.size} files, entry: $finalEntryName)",
                    entryHtmlFileName = finalEntryName,
                    mainHtmlContent = finalHtml,
                    additionalFiles = extractedFiles
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun extractFromStudioProject(project: StudioProject): ExtractedWebBundle {
        val isWebsite = project.isWebsiteProject() || project.kotlinCode.trimStart().startsWith("<!DOCTYPE", ignoreCase = true) ||
            project.kotlinCode.trimStart().startsWith("<html", ignoreCase = true)

        val html = if (isWebsite) {
            project.kotlinCode
        } else {
            val spec = SandboxSpec.fromJsonString(project.sandboxSpecJson, project.title)
            buildHtmlFromSandboxSpec(project, spec)
        }

        return ExtractedWebBundle(
            sourceLabel = "Studio Project: ${project.title}",
            entryHtmlFileName = "index.html",
            mainHtmlContent = html,
            additionalFiles = emptyMap()
        )
    }

    private fun buildFallbackZipIndexHtml(fileNames: List<String>): String {
        val listItems = fileNames.take(30).joinToString("\n") { "<li><code>$it</code></li>" }
        return """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Converted ZIP Bundle</title>
  <style>
    body { background: #0B1120; color: #F8FAFC; font-family: system-ui, sans-serif; padding: 20px; }
    .box { background: #1E293B; border-radius: 14px; padding: 18px; border: 1px solid #38BDF8; }
    h2 { color: #38BDF8; margin-bottom: 10px; }
    ul { padding-left: 20px; color: #94A3B8; font-size: 0.9rem; }
  </style>
</head>
<body>
  <div class="box">
    <h2>ZIP Bundle Packaged (${fileNames.size} files)</h2>
    <p>All archive files have been bundled into <code>assets/www/</code>:</p>
    <ul>$listItems</ul>
  </div>
</body>
</html>
        """.trimIndent()
    }

    private fun buildHtmlFromSandboxSpec(project: StudioProject, spec: SandboxSpec): String {
        val controlsHtml = spec.widgets.joinToString("\n") { w ->
            """
            <div style="margin-bottom:14px;">
              <label style="display:block;font-weight:600;margin-bottom:4px;color:#E2E8F0;">${w.label} (${w.unit})</label>
              <input type="number" class="calc-input" value="${w.defaultValue.toDoubleOrNull() ?: 10.0}" oninput="recalc()" style="width:100%;padding:10px;border-radius:8px;border:1px solid #334155;background:#0F172A;color:#F8FAFC;" />
            </div>
            """.trimIndent()
        }
        return """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${spec.appTitle}</title>
  <style>
    body { background: #0B1120; color: #F8FAFC; font-family: system-ui, sans-serif; padding: 18px; margin: 0; }
    .card { background: #1E293B; border-radius: 16px; padding: 18px; border: 1px solid ${spec.themeAccentHex}; margin-bottom: 16px; }
    h1 { font-size: 1.35rem; color: ${spec.themeAccentHex}; margin: 0 0 6px 0; }
    p { font-size: 0.88rem; color: #94A3B8; margin: 0 0 14px 0; }
    .result-box { background: #0F172A; padding: 14px; border-radius: 12px; text-align: center; border: 1px solid #334155; }
    .result-val { font-size: 1.5rem; font-weight: 800; color: ${spec.themeAccentHex}; }
  </style>
</head>
<body>
  <div class="card">
    <h1>${spec.appTitle}</h1>
    <p>${project.summary}</p>
    $controlsHtml
    <div class="result-box">
      <div style="font-size:0.8rem;color:#94A3B8;">${spec.primaryFormulaLabel}</div>
      <div id="outVal" class="result-val">0.00 ${spec.primaryFormulaUnit}</div>
    </div>
  </div>
  <script>
    function recalc() {
      const inputs = document.querySelectorAll('.calc-input');
      let acc = 1;
      inputs.forEach((inp, idx) => {
        const v = parseFloat(inp.value) || 0;
        acc = idx === 0 ? v : acc * v;
      });
      document.getElementById('outVal').textContent = acc.toFixed(2) + ' ${spec.primaryFormulaUnit}';
    }
    recalc();
  </script>
</body>
</html>
        """.trimIndent()
    }

    fun generateConvertedMainActivityKt(config: ConvertedAppConfig, entryHtmlPath: String): String {
        val cleanPkg = sanitizePackageName(config.packageName)
        val adMobImports = if (config.adsEnabled) {
            """
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
            """.trimIndent()
        } else {
            ""
        }

        val adMobInit = if (config.adsEnabled) {
            "MobileAds.initialize(this) {}"
        } else {
            "// AdMob disabled in converter configuration"
        }

        val bannerComposable = if (config.adsEnabled) {
            val effectiveBannerUnit = config.bannerAdUnitId.ifBlank { "ca-app-pub-3940256099942544/6300978111" }
            """
@Composable
fun ConvertedAppAdBanner(modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { context ->
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = "$effectiveBannerUnit"
                loadAd(AdRequest.Builder().build())
            }
        }
    )
}
            """.trimIndent()
        } else {
            ""
        }

        return """
package $cleanPkg

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
$adMobImports

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        $adMobInit

        if (${config.fullscreenImmersive}) {
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }

        setContent {
            MaterialTheme {
                ConvertedWebAppScreen()
            }
        }
    }
}

class OmniNativeJsBridge(private val activityContext: android.content.Context) {
    @JavascriptInterface
    fun showToast(message: String) {
        Toast.makeText(activityContext, message, Toast.LENGTH_SHORT).show()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ConvertedWebAppScreen() {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    BackHandler(enabled = webViewRef?.canGoBack() == true) {
        webViewRef?.goBack()
    }

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            ${if (config.adsEnabled && config.bannerPlacement == "TOP") "ConvertedAppAdBanner()" else ""}
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = ${config.enableJavaScript}
                        settings.domStorageEnabled = ${config.enableDomStorage}
                        settings.allowFileAccess = ${config.enableFileUpload}
                        settings.builtInZoomControls = ${config.enableZoomControls}
                        settings.displayZoomControls = false
                        settings.cacheMode = if (${config.enableOfflineCache}) {
                            WebSettings.LOAD_DEFAULT
                        } else {
                            WebSettings.LOAD_NO_CACHE
                        }
                        addJavascriptInterface(OmniNativeJsBridge(ctx), "OmniApp")
                        webViewClient = WebViewClient()
                        webChromeClient = WebChromeClient()
                        loadUrl("file:///android_asset/www/$entryHtmlPath")
                        webViewRef = this
                    }
                }
            )
            ${if (config.adsEnabled && config.bannerPlacement == "BOTTOM") "ConvertedAppAdBanner()" else ""}
        }
    }
}

$bannerComposable
        """.trimIndent()
    }

    fun generateConvertedManifestXml(config: ConvertedAppConfig): String {
        val cleanPkg = sanitizePackageName(config.packageName)
        val orientationAttr = when (config.orientation) {
            "LANDSCAPE" -> "android:screenOrientation=\"landscape\""
            "SENSOR" -> "android:screenOrientation=\"fullSensor\""
            else -> "android:screenOrientation=\"portrait\""
        }

        val extraPerms = buildString {
            appendLine("    <uses-permission android:name=\"android.permission.INTERNET\" />")
            appendLine("    <uses-permission android:name=\"android.permission.ACCESS_NETWORK_STATE\" />")
            if (config.permCamera) appendLine("    <uses-permission android:name=\"android.permission.CAMERA\" />")
            if (config.permLocation) appendLine("    <uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\" />")
            if (config.permVibrate) appendLine("    <uses-permission android:name=\"android.permission.VIBRATE\" />")
            if (config.permNotifications) appendLine("    <uses-permission android:name=\"android.permission.POST_NOTIFICATIONS\" />")
        }.trimEnd()

        val adMobMeta = if (config.adsEnabled) {
            val effectiveAppId = config.adMobAppId.ifBlank { "ca-app-pub-3940256099942544~3347511713" }
            """
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="$effectiveAppId" />
            """.trimIndent()
        } else {
            ""
        }

        return """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="$cleanPkg">

$extraPerms

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:label="${config.appName.replace("\"", "")}"
        android:usesCleartextTraffic="true"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.DeviceDefault.NoActionBar">
$adMobMeta
        <activity
            android:name=".MainActivity"
            android:exported="true"
            $orientationAttr
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
        """.trimIndent()
    }

    fun generateConvertedBuildGradleKts(config: ConvertedAppConfig): String {
        val cleanPkg = sanitizePackageName(config.packageName)
        val adsDep = if (config.adsEnabled) {
            "    implementation(\"com.google.android.gms:play-services-ads:23.3.0\")"
        } else {
            "    // AdMob disabled"
        }
        return """
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "$cleanPkg"
    compileSdk = 35

    defaultConfig {
        applicationId = "$cleanPkg"
        minSdk = 24
        targetSdk = 35
        versionCode = ${config.versionCode.coerceAtLeast(1)}
        versionName = "${config.versionName.ifBlank { "1.0.0" }}"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
$adsDep
}
        """.trimIndent()
    }

    fun generateAdaptiveIconForegroundXml(config: ConvertedAppConfig): String {
        val preset = ConverterIconPreset.fromId(config.iconPresetId)
        val fgColor = config.customIconFgHex.ifBlank { preset.fgHex }
        return """
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <group
        android:scaleX="0.55"
        android:scaleY="0.55"
        android:translateX="5.4"
        android:translateY="5.4">
        <path
            android:fillColor="$fgColor"
            android:pathData="${preset.glyphCode}" />
    </group>
</vector>
        """.trimIndent()
    }

    fun generateAdaptiveIconBackgroundXml(config: ConvertedAppConfig): String {
        val preset = ConverterIconPreset.fromId(config.iconPresetId)
        val bgColor = config.customIconBgHex.ifBlank { preset.bgHex }
        return """
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="$bgColor"
        android:pathData="M0,0h108v108h-108z" />
</vector>
        """.trimIndent()
    }

    fun buildStudioProjectFromConverter(
        userId: String,
        config: ConvertedAppConfig,
        bundle: ExtractedWebBundle,
        providerId: String,
        modelId: String
    ): StudioProject {
        val mainActivityKt = generateConvertedMainActivityKt(config, bundle.entryHtmlFileName)
        val manifestXml = generateConvertedManifestXml(config)
        val buildGradleKts = generateConvertedBuildGradleKts(config)

        val spec = SandboxSpec(
            appTitle = config.appName,
            tagline = "Converted HTML/ZIP App (${config.packageName}) • Ads: ${if (config.adsEnabled) "Enabled" else "Off"}",
            themeAccentHex = config.themeColorHex,
            primaryFormulaLabel = "Web-to-App Package Status",
            primaryFormulaUnit = "files",
            formulaMode = "ADD",
            widgets = listOf(
                SandboxWidget(
                    id = "bundled_assets_count",
                    type = "METRIC_CARD",
                    label = "Bundled Web Assets",
                    subtitle = bundle.sourceLabel,
                    defaultValue = (bundle.additionalFiles.size.coerceAtLeast(1)).toString(),
                    minValue = 1f,
                    maxValue = 500f,
                    unit = "files"
                ),
                SandboxWidget(
                    id = "admob_status_toggle",
                    type = "TOGGLE",
                    label = "AdMob Banner & Interstitial Bridge",
                    subtitle = if (config.adsEnabled) "Placement: ${config.bannerPlacement}" else "AdMob disabled",
                    defaultValue = config.adsEnabled.toString()
                )
            )
        )

        return StudioProject(
            id = "conv_${UUID.randomUUID().toString().replace("-", "").take(16)}",
            userId = userId,
            title = config.appName.take(110),
            prompt = "Converted HTML/ZIP to Native Android App (${bundle.sourceLabel}) • Package: ${config.packageName} • Ads: ${config.adsEnabled}",
            provider = providerId,
            modelId = modelId,
            summary = "Native Android WebView App converted from ${bundle.sourceLabel} with custom launcher icon, ${config.orientation.lowercase()} orientation, and ${if (config.adsEnabled) "AdMob (${config.bannerPlacement} banner)" else "ad-free"} configuration.",
            sandboxSpecJson = spec.toJsonString(),
            kotlinCode = mainActivityKt,
            manifestXml = manifestXml,
            buildGradleKts = buildGradleKts,
            isPinned = false
        )
    }

    suspend fun exportConvertedAppZipToUri(
        context: Context,
        config: ConvertedAppConfig,
        bundle: ExtractedWebBundle,
        targetUri: Uri
    ): Result<ArchiveExportSummary> = withContext(Dispatchers.IO) {
        try {
            val outStream = context.contentResolver.openOutputStream(targetUri)
                ?: throw IllegalStateException("Unable to open output stream for selected destination.")

            val fileName = "${sanitizeSlug(config.appName)}_android_app_project.zip"
            var totalBytes = 0L
            var entryCount = 0

            val entries = buildConvertedProjectZipEntries(context, config, bundle)
            outStream.use { raw ->
                ZipOutputStream(raw).use { zos ->
                    for ((path, bytes) in entries) {
                        val entry = ZipEntry(path)
                        zos.putNextEntry(entry)
                        zos.write(bytes)
                        zos.closeEntry()
                        totalBytes += bytes.size
                        entryCount++
                    }
                }
            }

            Result.success(
                ArchiveExportSummary(
                    archiveFileName = fileName,
                    totalBytes = totalBytes.toInt(),
                    packagedFiles = entries.keys.toList(),
                    destinationDescription = targetUri.lastPathSegment ?: "Device Storage"
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun exportConvertedAppZipToWorkspace(
        context: Context,
        config: ConvertedAppConfig,
        bundle: ExtractedWebBundle
    ): Result<ArchiveExportSummary> = withContext(Dispatchers.IO) {
        try {
            val exportDir = File(context.filesDir, "exported_archives").apply {
                if (!exists()) mkdirs()
            }
            val fileName = "${sanitizeSlug(config.appName)}_android_app_project.zip"
            val targetFile = File(exportDir, fileName)
            var totalBytes = 0L
            var entryCount = 0

            val entries = buildConvertedProjectZipEntries(context, config, bundle)
            FileOutputStream(targetFile).use { raw ->
                ZipOutputStream(raw).use { zos ->
                    for ((path, bytes) in entries) {
                        val entry = ZipEntry(path)
                        zos.putNextEntry(entry)
                        zos.write(bytes)
                        zos.closeEntry()
                        totalBytes += bytes.size
                        entryCount++
                    }
                }
            }

            Result.success(
                ArchiveExportSummary(
                    archiveFileName = fileName,
                    totalBytes = totalBytes.toInt(),
                    packagedFiles = entries.keys.toList(),
                    destinationDescription = targetFile.absolutePath
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun buildConvertedProjectZipEntries(
        context: Context,
        config: ConvertedAppConfig,
        bundle: ExtractedWebBundle
    ): Map<String, ByteArray> {
        val entries = linkedMapOf<String, ByteArray>()
        val cleanPkg = sanitizePackageName(config.packageName)
        val pkgPath = cleanPkg.replace('.', '/')

        // 0. Root package.json & index.html for AppMint and mobile ZIP-to-APK builders
        val appSlug = sanitizeSlug(config.appName).replace('_', '-')
        entries["package.json"] = """
{
  "name": "$appSlug",
  "private": true,
  "version": "${config.versionName.ifBlank { "1.0.0" }}",
  "description": "${config.appName.replace("\"", "'")} — Converted with OmniPrompt Studio",
  "main": "index.html",
  "scripts": {
    "dev": "echo \"Ready\"",
    "build": "node -e \"const fs=require('fs');fs.mkdirSync('dist',{recursive:true});fs.copyFileSync('index.html','dist/index.html');\""
  },
  "dependencies": {},
  "devDependencies": {}
}
        """.trimIndent().toByteArray(Charsets.UTF_8)
        entries["index.html"] = bundle.mainHtmlContent.toByteArray(Charsets.UTF_8)
        for ((relPath, fileBytes) in bundle.additionalFiles) {
            if (!entries.containsKey(relPath)) {
                entries[relPath] = fileBytes
            }
        }

        // 1. Native Android Kotlin Activity + Manifest + Gradle
        entries["app/src/main/java/$pkgPath/MainActivity.kt"] =
            generateConvertedMainActivityKt(config, bundle.entryHtmlFileName).toByteArray(Charsets.UTF_8)
        entries["app/src/main/AndroidManifest.xml"] =
            generateConvertedManifestXml(config).toByteArray(Charsets.UTF_8)
        entries["app/build.gradle.kts"] =
            generateConvertedBuildGradleKts(config).toByteArray(Charsets.UTF_8)
        entries["settings.gradle.kts"] =
            "rootProject.name = \"${config.appName.replace("\"", "")}\"\ninclude(\":app\")\n".toByteArray(Charsets.UTF_8)

        // 2. Custom Adaptive App Icon Resources
        entries["app/src/main/res/drawable/ic_launcher_foreground.xml"] =
            generateAdaptiveIconForegroundXml(config).toByteArray(Charsets.UTF_8)
        entries["app/src/main/res/drawable/ic_launcher_background.xml"] =
            generateAdaptiveIconBackgroundXml(config).toByteArray(Charsets.UTF_8)
        entries["app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml"] = """
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
        """.trimIndent().toByteArray(Charsets.UTF_8)

        if (config.customIconUriString.isNotBlank()) {
            try {
                val iconUri = Uri.parse(config.customIconUriString)
                context.contentResolver.openInputStream(iconUri)?.use { stream ->
                    entries["app/src/main/res/drawable/ic_custom_app_logo.png"] = stream.readBytes()
                }
            } catch (_: Exception) {
                // Keep vector adaptive icon if custom URI is no longer readable
            }
        }

        // 3. Web Assets under app/src/main/assets/www/
        entries["app/src/main/assets/www/${bundle.entryHtmlFileName}"] =
            bundle.mainHtmlContent.toByteArray(Charsets.UTF_8)
        for ((relPath, fileBytes) in bundle.additionalFiles) {
            entries["app/src/main/assets/www/$relPath"] = fileBytes
        }

        // 4. README with Build & Signing Instructions
        entries["README.md"] = """
# ${config.appName} — Converted Android App Project

- **Package Name**: `$cleanPkg`
- **Version**: `${config.versionName}` (`${config.versionCode}`)
- **Source Bundle**: ${bundle.sourceLabel}
- **Entry HTML**: `index.html` & `app/src/main/assets/www/${bundle.entryHtmlFileName}`
- **AdMob Enabled**: `${config.adsEnabled}` (${if (config.adsEnabled) "Banner Placement: ${config.bannerPlacement}" else "Ad-Free"})
- **Orientation**: `${config.orientation}` | **Fullscreen**: `${config.fullscreenImmersive}`

## Building APK / AAB
Open this folder in **AppMint** (uses root `package.json` + `index.html`) or **Android Studio** (`./gradlew assembleDebug`).
        """.trimIndent().toByteArray(Charsets.UTF_8)

        return entries
    }

    private fun sanitizePackageName(raw: String): String {
        val parts = raw.trim().lowercase(Locale.US)
            .split(".")
            .map { segment ->
                val clean = segment.filter { it.isLetterOrDigit() || it == '_' }
                if (clean.isEmpty() || clean.first().isDigit()) "app$clean" else clean
            }
            .filter { it.isNotEmpty() }

        return if (parts.size >= 2) {
            parts.joinToString(".")
        } else {
            "com.omniprompt.converted.app"
        }
    }

    private fun sanitizeSlug(raw: String): String {
        return raw.trim().lowercase(Locale.US)
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "converted_web_app" }
    }
}
