package com.example.util

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

enum class AppLanguage {
    NEPALI,
    ENGLISH
}

object AppSettings {
    private const val PREFS_NAME = "mero_sewa_prefs"
    private const val KEY_THEME_MODE = "theme_mode"
    private const val KEY_APP_LANGUAGE = "app_language"

    var currentThemeMode by mutableStateOf(ThemeMode.SYSTEM)
        private set

    var currentLanguage by mutableStateOf(AppLanguage.NEPALI)
        private set

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedTheme = prefs.getString(KEY_THEME_MODE, ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name
        val savedLang = prefs.getString(KEY_APP_LANGUAGE, AppLanguage.NEPALI.name) ?: AppLanguage.NEPALI.name

        currentThemeMode = try {
            ThemeMode.valueOf(savedTheme)
        } catch (_: Exception) {
            ThemeMode.SYSTEM
        }

        currentLanguage = try {
            AppLanguage.valueOf(savedLang)
        } catch (_: Exception) {
            AppLanguage.NEPALI
        }
    }

    fun setThemeMode(context: Context, mode: ThemeMode) {
        currentThemeMode = mode
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_THEME_MODE, mode.name).apply()
    }

    fun setLanguage(context: Context, language: AppLanguage) {
        currentLanguage = language
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_APP_LANGUAGE, language.name).apply()
    }
}

object Strings {
    // App Bar & Brand
    fun appTitle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "मेरो सेवा नेपाल"
        AppLanguage.ENGLISH -> "Mero Sewa Nepal"
    }

    fun appSubtitle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "स्थानीय सेवा बजार — तुलसीपुर, दाङ"
        AppLanguage.ENGLISH -> "Local Services — Dang, Nepal"
    }

    // Navigation Tabs
    fun navServices(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सेवाहरू"
        AppLanguage.ENGLISH -> "Services"
    }

    fun navBookings(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "मेरो अर्डर"
        AppLanguage.ENGLISH -> "My Bookings"
    }

    fun navAdmin(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "व्यवस्थापक"
        AppLanguage.ENGLISH -> "Admin"
    }

    fun navProfile(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सेटिङ / प्रोफाइल"
        AppLanguage.ENGLISH -> "Profile & Settings"
    }

    // Search & Filter
    fun searchPlaceholder(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "प्राविधिकको नाम वा सेवा खोज्नुहोस्..."
        AppLanguage.ENGLISH -> "Search provider or service..."
    }

    fun allCities(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सबै स्थान"
        AppLanguage.ENGLISH -> "All Cities"
    }

    fun allCategories(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सबै सेवा"
        AppLanguage.ENGLISH -> "All Services"
    }

    fun categoryElectrician(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "इलेक्ट्रिसियन"
        AppLanguage.ENGLISH -> "Electrician"
    }

    fun categoryPlumber(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "प्लम्बर"
        AppLanguage.ENGLISH -> "Plumber"
    }

    fun categoryOther(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "अन्य मर्मत"
        AppLanguage.ENGLISH -> "Other Repairs"
    }

    // Actions & Buttons
    fun bookNow(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सेवा बुक गर्नुहोस्"
        AppLanguage.ENGLISH -> "Book Service"
    }

    fun quickBookFAB(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "अर्डर गर्नुहोस्"
        AppLanguage.ENGLISH -> "Book Now"
    }

    fun callNow(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सम्पर्क"
        AppLanguage.ENGLISH -> "Call"
    }

    fun phoneHidden(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "गोप्य नम्बर"
        AppLanguage.ENGLISH -> "Private Phone"
    }

    fun phonePublic(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सार्वजनिक"
        AppLanguage.ENGLISH -> "Public"
    }

    fun yearsExperience(exp: Long): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "$exp वर्ष अनुभव"
        AppLanguage.ENGLISH -> "$exp yrs exp"
    }

    // Status Badges
    fun statusPending(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "प्रतीक्षारत"
        AppLanguage.ENGLISH -> "Pending"
    }

    fun statusAccepted(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "स्वीकृत"
        AppLanguage.ENGLISH -> "Accepted"
    }

    fun statusCompleted(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सम्पन्न"
        AppLanguage.ENGLISH -> "Completed"
    }

    fun statusCancelled(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "रद्द"
        AppLanguage.ENGLISH -> "Cancelled"
    }

    // Profile & Settings
    fun themeSettingsTitle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "थिम मोड (Theme Mode)"
        AppLanguage.ENGLISH -> "Theme Mode"
    }

    fun themeSystem(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सिस्टम (System)"
        AppLanguage.ENGLISH -> "System"
    }

    fun themeLight(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "लाइट (Light)"
        AppLanguage.ENGLISH -> "Light"
    }

    fun themeDark(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "डार्क (Dark)"
        AppLanguage.ENGLISH -> "Dark"
    }

    fun languageSettingsTitle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "भाषा (Language)"
        AppLanguage.ENGLISH -> "Language (भाषा)"
    }

    fun languageNepali(): String = "नेपाली"
    fun languageEnglish(): String = "English"

    fun emergencySupportTitle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "स्थानीय आकस्मिक सहयोग (Dang / Tulsipur)"
        AppLanguage.ENGLISH -> "Local Emergency Helpline (Dang / Tulsipur)"
    }

    fun emergencyHelplines(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "• नेपाल विद्युत प्राधिकरण (NEA Helpline): 1153\n• खानेपानी उपभोक्ता संस्था, तुलसीपुर: 082-520111\n• मेरो सेवा नेपाल सहायता केन्द्र: 9847800000"
        AppLanguage.ENGLISH -> "• Nepal Electricity Authority (NEA): 1153\n• Water Supply Board, Tulsipur: 082-520111\n• Mero Sewa Nepal Support: 9847800000"
    }

    fun privacyTitle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "सुरक्षा र गोपनीयता"
        AppLanguage.ENGLISH -> "Security & Privacy"
    }

    fun privacyText(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "तपाईंको फोन नम्बर तथा ठेगाना चयन गरिएको सेवा प्रदायक र आधिकारिक व्यवस्थापकलाई मात्र सेवा प्रवाह प्रयोजनका लागि प्रदान गरिन्छ। सम्पूर्ण डेटा क्लाउड फायरस्टोरमा सुरक्षित छ।"
        AppLanguage.ENGLISH -> "Your phone and location are shared only with the assigned provider and admin for service delivery. All data is protected with Firestore security rules."
    }

    fun signOutButton(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "साइन आउट गर्नुहोस् (Sign Out)"
        AppLanguage.ENGLISH -> "Sign Out"
    }

    fun signOutConfirmTitle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "साइन आउट गर्ने?"
        AppLanguage.ENGLISH -> "Sign Out?"
    }

    fun signOutConfirmMessage(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "के तपाईं मेरो सेवा नेपालबाट साइन आउट गर्न निश्चित हुनुहुन्छ?"
        AppLanguage.ENGLISH -> "Are you sure you want to sign out from Mero Sewa Nepal?"
    }

    fun cancel(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "रद्द"
        AppLanguage.ENGLISH -> "Cancel"
    }

    fun confirm(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "पुष्टि"
        AppLanguage.ENGLISH -> "Confirm"
    }

    // Auth Screen
    fun authHeadline(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "तपाईंको घरदैलोमै भरपर्दो इलेक्ट्रिसियन, प्लम्बर र मर्मत प्राविधिकहरू। तुलसीपुर, घोराही र दाङका सबै ठाउँमा उपलब्ध।"
        AppLanguage.ENGLISH -> "Trusted electricians, plumbers, and repair workers at your doorstep in Tulsipur, Ghorahi, and Dang."
    }

    fun authTabSignIn(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "प्रयोगकर्ता लगइन"
        AppLanguage.ENGLISH -> "Sign In"
    }

    fun authTabRegister(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "नयाँ खाता दर्ता (Register)"
        AppLanguage.ENGLISH -> "Register Account"
    }

    fun authFullNameLabel(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "तपाईंको पूरा नाम (Full Name)"
        AppLanguage.ENGLISH -> "Full Name"
    }

    fun authPhoneLabel(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "मोबाइल नम्बर (Phone Number, उदा. ९८४७...)"
        AppLanguage.ENGLISH -> "Phone Number (e.g. 9847...)"
    }

    fun authEmailLabel(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "इमेल ठेगाना (Email Address)"
        AppLanguage.ENGLISH -> "Email Address"
    }

    fun authPasswordLabel(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "पासवर्ड (Password — कम्तीमा ६ अक्षर)"
        AppLanguage.ENGLISH -> "Password (min 6 characters)"
    }

    fun authConfirmPasswordLabel(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "पासवर्ड पुन: लेख्नुहोस् (Confirm Password)"
        AppLanguage.ENGLISH -> "Confirm Password"
    }

    fun authRegisterButton(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "नयाँ खाता सिर्जना गर्नुहोस्"
        AppLanguage.ENGLISH -> "Create Account"
    }

    fun authLoginButton(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "लगइन गर्नुहोस्"
        AppLanguage.ENGLISH -> "Sign In"
    }

    fun authSwitchToRegister(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "नयाँ प्रयोगकर्ता हुनुहुन्छ? नयाँ खाता दर्ता गर्नुहोस्"
        AppLanguage.ENGLISH -> "New user? Register an account here"
    }

    fun authSwitchToSignIn(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "पहिले नै खाता छ? यहाँ लगइन गर्नुहोस्"
        AppLanguage.ENGLISH -> "Already have an account? Sign In"
    }

    fun authPasswordMismatch(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "पासवर्ड र पुष्टि पासवर्ड मिलेन।"
        AppLanguage.ENGLISH -> "Passwords do not match."
    }

    fun authPasswordTooShort(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "पासवर्ड कम्तीमा ६ अक्षरको हुनुपर्छ।"
        AppLanguage.ENGLISH -> "Password must be at least 6 characters."
    }

    fun authFillAllFields(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "कृपया आवश्यक सबै विवरण भर्नुहोस्।"
        AppLanguage.ENGLISH -> "Please fill all required fields."
    }

    fun authInvalidEmail(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "कृपया मान्य इमेल ठेगाना लेख्नुहोस्।"
        AppLanguage.ENGLISH -> "Please enter a valid email address."
    }

    fun authOrGoogle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "वा Google मार्फत छिटो सुरु गर्नुहोस्"
        AppLanguage.ENGLISH -> "Or continue with Google"
    }

    fun authGoogleButton(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "Google मार्फत १-क्लिक सुरु गर्नुहोस्"
        AppLanguage.ENGLISH -> "Continue with Google"
    }

    fun authEmailTabTitle(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "इमेल र पासवर्ड प्रमाणीकरण"
        AppLanguage.ENGLISH -> "Email & Password Authentication"
    }

    fun authTerms(): String = when (AppSettings.currentLanguage) {
        AppLanguage.NEPALI -> "साइन इन वा दर्ता गरेर तपाईं मेरो सेवा नेपालका नियमहरू स्वीकार गर्नुहुन्छ।"
        AppLanguage.ENGLISH -> "By continuing, you agree to Mero Sewa Nepal Terms."
    }
}

