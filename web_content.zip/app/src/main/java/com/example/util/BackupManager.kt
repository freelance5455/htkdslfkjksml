package com.example.util

import com.example.data.model.BusinessSettings
import com.example.data.model.ExpenseEntity
import com.example.data.model.TransactionEntity
import org.json.JSONArray
import org.json.JSONObject

object BackupManager {

    fun generateBackupJson(
        settings: BusinessSettings,
        transactions: List<TransactionEntity>,
        expenses: List<ExpenseEntity>
    ): String {
        val root = JSONObject()
        root.put("version", 1)
        root.put("exportTimestamp", System.currentTimeMillis())
        root.put("exportDate", DateUtils.formatDateTime(System.currentTimeMillis()))
        root.put("businessName", settings.businessName)

        val settingsObj = JSONObject().apply {
            put("businessName", settings.businessName)
            put("defaultWithdrawalPlatformFeePercent", settings.defaultWithdrawalPlatformFeePercent)
            put("defaultWithdrawalCommissionPercent", settings.defaultWithdrawalCommissionPercent)
            put("defaultWithdrawalTransactionCharge", settings.defaultWithdrawalTransactionCharge)
            put("defaultWithdrawalRetainChargeAsIncome", settings.defaultWithdrawalRetainChargeAsIncome)
            put("defaultBillPlatformFeePercent", settings.defaultBillPlatformFeePercent)
            put("defaultBillServiceChargePercent", settings.defaultBillServiceChargePercent)
            put("defaultBillCommissionPercent", settings.defaultBillCommissionPercent)
            put("defaultGstRatePercent", settings.defaultGstRatePercent)
            put("isGstEnabled", settings.isGstEnabled)
            put("currencySymbol", settings.currencySymbol)
        }
        root.put("settings", settingsObj)

        val txArray = JSONArray()
        transactions.forEach { tx ->
            val txObj = JSONObject().apply {
                put("txId", tx.txId)
                put("type", tx.type)
                put("timestamp", tx.timestamp)
                put("amount", tx.amount)
                put("platformFeePercent", tx.platformFeePercent)
                put("platformFeeAmount", tx.platformFeeAmount)
                put("isManualPlatformFee", tx.isManualPlatformFee)
                put("commissionPercent", tx.commissionPercent)
                put("commissionAmount", tx.commissionAmount)
                put("serviceChargePercent", tx.serviceChargePercent)
                put("serviceChargeAmount", tx.serviceChargeAmount)
                put("transactionCharge", tx.transactionCharge)
                put("otherCosts", tx.otherCosts)
                put("customerPayoutOrCharge", tx.customerPayoutOrCharge)
                put("grossProfit", tx.grossProfit)
                put("netProfit", tx.netProfit)
                put("status", tx.status)
                put("notes", tx.notes)
                put("isTransactionChargeRetained", tx.isTransactionChargeRetained)
            }
            txArray.put(txObj)
        }
        root.put("transactions", txArray)

        val expArray = JSONArray()
        expenses.forEach { exp ->
            val expObj = JSONObject().apply {
                put("name", exp.name)
                put("category", exp.category)
                put("amount", exp.amount)
                put("date", exp.date)
                put("paymentMethod", exp.paymentMethod)
                put("isPaid", exp.isPaid)
                put("notes", exp.notes)
                put("recurrence", exp.recurrence)
                put("startDate", exp.startDate)
                put("endDate", exp.endDate ?: JSONObject.NULL)
                put("isRecurringActive", exp.isRecurringActive)
                put("linkedTransactionId", exp.linkedTransactionId ?: JSONObject.NULL)
            }
            expArray.put(expObj)
        }
        root.put("expenses", expArray)

        return root.toString(2)
    }

    data class ParsedBackup(
        val settings: BusinessSettings?,
        val transactions: List<TransactionEntity>,
        val expenses: List<ExpenseEntity>
    )

    fun parseBackupJson(jsonString: String): Result<ParsedBackup> {
        return try {
            val root = JSONObject(jsonString)
            var settings: BusinessSettings? = null
            if (root.has("settings")) {
                val s = root.getJSONObject("settings")
                settings = BusinessSettings(
                    id = 1,
                    businessName = s.optString("businessName", "Apex Card & Bill Services"),
                    defaultWithdrawalPlatformFeePercent = s.optDouble("defaultWithdrawalPlatformFeePercent", 1.5),
                    defaultWithdrawalCommissionPercent = s.optDouble("defaultWithdrawalCommissionPercent", 0.2),
                    defaultWithdrawalTransactionCharge = s.optDouble("defaultWithdrawalTransactionCharge", 20.0),
                    defaultWithdrawalRetainChargeAsIncome = s.optBoolean("defaultWithdrawalRetainChargeAsIncome", true),
                    defaultBillPlatformFeePercent = s.optDouble("defaultBillPlatformFeePercent", 1.5),
                    defaultBillServiceChargePercent = s.optDouble("defaultBillServiceChargePercent", 1.5),
                    defaultBillCommissionPercent = s.optDouble("defaultBillCommissionPercent", 0.2),
                    defaultGstRatePercent = s.optDouble("defaultGstRatePercent", 18.0),
                    isGstEnabled = s.optBoolean("isGstEnabled", true),
                    currencySymbol = s.optString("currencySymbol", "₹")
                )
            }

            val transactions = mutableListOf<TransactionEntity>()
            if (root.has("transactions")) {
                val txArray = root.getJSONArray("transactions")
                for (i in 0 until txArray.length()) {
                    val obj = txArray.getJSONObject(i)
                    transactions.add(
                        TransactionEntity(
                            id = 0,
                            txId = obj.optString("txId", "TXN-${System.currentTimeMillis()}-$i"),
                            type = obj.optString("type", "WITHDRAWAL"),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            amount = obj.optDouble("amount", 0.0),
                            platformFeePercent = obj.optDouble("platformFeePercent", 0.0),
                            platformFeeAmount = obj.optDouble("platformFeeAmount", 0.0),
                            isManualPlatformFee = obj.optBoolean("isManualPlatformFee", false),
                            commissionPercent = obj.optDouble("commissionPercent", 0.0),
                            commissionAmount = obj.optDouble("commissionAmount", 0.0),
                            serviceChargePercent = obj.optDouble("serviceChargePercent", 0.0),
                            serviceChargeAmount = obj.optDouble("serviceChargeAmount", 0.0),
                            transactionCharge = obj.optDouble("transactionCharge", 0.0),
                            otherCosts = obj.optDouble("otherCosts", 0.0),
                            customerPayoutOrCharge = obj.optDouble("customerPayoutOrCharge", 0.0),
                            grossProfit = obj.optDouble("grossProfit", 0.0),
                            netProfit = obj.optDouble("netProfit", 0.0),
                            status = obj.optString("status", "COMPLETED"),
                            notes = obj.optString("notes", ""),
                            isTransactionChargeRetained = obj.optBoolean("isTransactionChargeRetained", true)
                        )
                    )
                }
            }

            val expenses = mutableListOf<ExpenseEntity>()
            if (root.has("expenses")) {
                val expArray = root.getJSONArray("expenses")
                for (i in 0 until expArray.length()) {
                    val obj = expArray.getJSONObject(i)
                    val endVal = if (obj.isNull("endDate")) null else obj.optLong("endDate")
                    val linked = if (obj.isNull("linkedTransactionId")) null else obj.optString("linkedTransactionId")
                    expenses.add(
                        ExpenseEntity(
                            id = 0,
                            name = obj.optString("name", "Expense"),
                            category = obj.optString("category", "Other operating expenses"),
                            amount = obj.optDouble("amount", 0.0),
                            date = obj.optLong("date", System.currentTimeMillis()),
                            paymentMethod = obj.optString("paymentMethod", "UPI"),
                            isPaid = obj.optBoolean("isPaid", true),
                            notes = obj.optString("notes", ""),
                            recurrence = obj.optString("recurrence", "ONE_TIME"),
                            startDate = obj.optLong("startDate", System.currentTimeMillis()),
                            endDate = endVal,
                            isRecurringActive = obj.optBoolean("isRecurringActive", true),
                            linkedTransactionId = linked
                        )
                    )
                }
            }

            Result.success(ParsedBackup(settings, transactions, expenses))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun exportTransactionsToCsv(transactions: List<TransactionEntity>): String {
        val sb = StringBuilder()
        sb.append("Transaction ID,Type,Date & Time,Amount (INR),Platform Fee %,Platform Fee (INR),Commission %,Commission (INR),Service Charge %,Service Charge (INR),Transaction Charge (INR),Other Costs (INR),Customer Payout / Charge (INR),Gross Profit (INR),Net Profit (INR),Status,Notes\n")
        transactions.forEach { tx ->
            val dateStr = DateUtils.formatDateTime(tx.timestamp).replace(",", " ")
            val cleanNotes = tx.notes.replace("\"", "\"\"").replace("\n", " ")
            sb.append("\"${tx.txId}\",")
            sb.append("\"${tx.type}\",")
            sb.append("\"$dateStr\",")
            sb.append("${tx.amount},")
            sb.append("${tx.platformFeePercent},")
            sb.append("${tx.platformFeeAmount},")
            sb.append("${tx.commissionPercent},")
            sb.append("${tx.commissionAmount},")
            sb.append("${tx.serviceChargePercent},")
            sb.append("${tx.serviceChargeAmount},")
            sb.append("${tx.transactionCharge},")
            sb.append("${tx.otherCosts},")
            sb.append("${tx.customerPayoutOrCharge},")
            sb.append("${tx.grossProfit},")
            sb.append("${tx.netProfit},")
            sb.append("\"${tx.status}\",")
            sb.append("\"$cleanNotes\"\n")
        }
        return sb.toString()
    }

    fun exportExpensesToCsv(expenses: List<ExpenseEntity>): String {
        val sb = StringBuilder()
        sb.append("Expense Name,Category,Amount (INR),Date,Payment Method,Paid Status,Recurrence,Linked TX ID,Notes\n")
        expenses.forEach { exp ->
            val dateStr = DateUtils.formatDate(exp.date).replace(",", " ")
            val cleanNotes = exp.notes.replace("\"", "\"\"").replace("\n", " ")
            sb.append("\"${exp.name}\",")
            sb.append("\"${exp.category}\",")
            sb.append("${exp.amount},")
            sb.append("\"$dateStr\",")
            sb.append("\"${exp.paymentMethod}\",")
            sb.append(if (exp.isPaid) "PAID" else "UNPAID").append(",")
            sb.append("\"${exp.recurrence}\",")
            sb.append("\"${exp.linkedTransactionId ?: ""}\",")
            sb.append("\"$cleanNotes\"\n")
        }
        return sb.toString()
    }
}
