package com.example.util

import com.example.model.UrlMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object UrlMetadataFetcher {

    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    // Title regex pattern case-insensitive, dotall
    private val TITLE_PATTERN = Pattern.compile("<title[^>]*>(.*?)</title>", Pattern.CASE_INSENSITIVE or Pattern.DOTALL)
    private val FAVICON_PATTERN = Pattern.compile("<link[^>]+rel=[\"'](?:shortcut )?icon[\"'][^>]+href=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
    private val OG_TITLE_PATTERN = Pattern.compile("<meta[^>]+property=[\"']og:title[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
    private val OG_DESC_PATTERN = Pattern.compile("<meta[^>]+property=[\"']og:description[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)
    private val META_DESC_PATTERN = Pattern.compile("<meta[^>]+name=[\"']description[\"'][^>]+content=[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE)

    fun getDefaultFaviconUrl(host: String): String {
        return "https://www.google.com/s2/favicons?sz=128&domain=$host"
    }

    suspend fun fetchMetadata(rawUrl: String): UrlMetadata = withContext(Dispatchers.IO) {
        val normalizedUrl = if (!rawUrl.startsWith("http://", ignoreCase = true) && !rawUrl.startsWith("https://", ignoreCase = true)) {
            "https://$rawUrl"
        } else {
            rawUrl
        }

        val host = runCatching { URI(normalizedUrl).host ?: normalizedUrl }.getOrDefault(normalizedUrl)
        val defaultFavicon = getDefaultFaviconUrl(host)

        try {
            val request = Request.Builder()
                .url(normalizedUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 Scanova/1.0")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext UrlMetadata(
                        url = normalizedUrl,
                        host = host,
                        faviconUrl = defaultFavicon,
                        title = host,
                        isLoading = false,
                        error = "HTTP ${response.code}"
                    )
                }

                // Read only the first 64KB of HTML to quickly extract meta tags without memory overhead
                val bodyStream = response.body?.byteStream()
                val buffer = ByteArray(64 * 1024)
                val bytesRead = bodyStream?.read(buffer) ?: 0
                val htmlHead = if (bytesRead > 0) String(buffer, 0, bytesRead, Charsets.UTF_8) else ""

                var pageTitle: String? = null
                var pageDesc: String? = null
                var extractedFavicon: String? = null

                // Extract og:title or <title>
                val ogTitleMatcher = OG_TITLE_PATTERN.matcher(htmlHead)
                if (ogTitleMatcher.find()) {
                    pageTitle = cleanHtmlEntities(ogTitleMatcher.group(1)?.trim())
                }

                if (pageTitle.isNullOrBlank()) {
                    val titleMatcher = TITLE_PATTERN.matcher(htmlHead)
                    if (titleMatcher.find()) {
                        pageTitle = cleanHtmlEntities(titleMatcher.group(1)?.trim())
                    }
                }

                // Extract description
                val ogDescMatcher = OG_DESC_PATTERN.matcher(htmlHead)
                if (ogDescMatcher.find()) {
                    pageDesc = cleanHtmlEntities(ogDescMatcher.group(1)?.trim())
                } else {
                    val metaDescMatcher = META_DESC_PATTERN.matcher(htmlHead)
                    if (metaDescMatcher.find()) {
                        pageDesc = cleanHtmlEntities(metaDescMatcher.group(1)?.trim())
                    }
                }

                // Extract favicon link
                val faviconMatcher = FAVICON_PATTERN.matcher(htmlHead)
                if (faviconMatcher.find()) {
                    val rawFav = faviconMatcher.group(1)?.trim()
                    if (!rawFav.isNullOrBlank()) {
                        extractedFavicon = resolveUrl(normalizedUrl, rawFav)
                    }
                }

                val finalFavicon = extractedFavicon ?: defaultFavicon
                val finalTitle = if (!pageTitle.isNullOrBlank()) pageTitle else host

                UrlMetadata(
                    url = normalizedUrl,
                    title = finalTitle,
                    description = pageDesc,
                    faviconUrl = finalFavicon,
                    host = host,
                    isLoading = false,
                    error = null
                )
            }
        } catch (e: Exception) {
            // Even if network fails or times out in isolated test runner, provide Google Favicon service & host preview
            UrlMetadata(
                url = normalizedUrl,
                host = host,
                title = host,
                faviconUrl = defaultFavicon,
                isLoading = false,
                error = e.localizedMessage
            )
        }
    }

    fun parseHtmlForTesting(html: String, baseUrl: String): UrlMetadata {
        val host = runCatching { URI(baseUrl).host ?: baseUrl }.getOrDefault(baseUrl)
        val defaultFavicon = getDefaultFaviconUrl(host)

        var pageTitle: String? = null
        var pageDesc: String? = null
        var extractedFavicon: String? = null

        val ogTitleMatcher = OG_TITLE_PATTERN.matcher(html)
        if (ogTitleMatcher.find()) {
            pageTitle = cleanHtmlEntities(ogTitleMatcher.group(1)?.trim())
        }

        if (pageTitle.isNullOrBlank()) {
            val titleMatcher = TITLE_PATTERN.matcher(html)
            if (titleMatcher.find()) {
                pageTitle = cleanHtmlEntities(titleMatcher.group(1)?.trim())
            }
        }

        val ogDescMatcher = OG_DESC_PATTERN.matcher(html)
        if (ogDescMatcher.find()) {
            pageDesc = cleanHtmlEntities(ogDescMatcher.group(1)?.trim())
        }

        val faviconMatcher = FAVICON_PATTERN.matcher(html)
        if (faviconMatcher.find()) {
            val rawFav = faviconMatcher.group(1)?.trim()
            if (!rawFav.isNullOrBlank()) {
                extractedFavicon = resolveUrl(baseUrl, rawFav)
            }
        }

        return UrlMetadata(
            url = baseUrl,
            title = pageTitle ?: host,
            description = pageDesc,
            faviconUrl = extractedFavicon ?: defaultFavicon,
            host = host,
            isLoading = false
        )
    }

    private fun resolveUrl(baseUrl: String, relativeUrl: String): String {
        return try {
            val baseUri = URI(baseUrl)
            baseUri.resolve(relativeUrl).toString()
        } catch (_: Exception) {
            relativeUrl
        }
    }

    private fun cleanHtmlEntities(text: String?): String? {
        if (text == null) return null
        return text
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}
