package com.example.util

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View
import com.example.model.HapticFeedbackStyle

object FeedbackHelper {

    /**
     * Triggers tactile haptic feedback using modern VibrationEffect primitives
     * or fallback waveforms with multiple intensity patterns.
     */
    fun vibrate(context: Context, style: HapticFeedbackStyle = HapticFeedbackStyle.CRISP_CLICK) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val effect = when (style) {
                        HapticFeedbackStyle.LIGHT_TICK -> {
                            VibrationEffect.createPredefined(VibrationEffect.EFFECT_TICK)
                        }
                        HapticFeedbackStyle.CRISP_CLICK -> {
                            VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                        }
                        HapticFeedbackStyle.DOUBLE_TAP -> {
                            VibrationEffect.createPredefined(VibrationEffect.EFFECT_DOUBLE_CLICK)
                        }
                        HapticFeedbackStyle.HEAVY_CONFIRM -> {
                            VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK)
                        }
                    }
                    vibrator.vibrate(effect)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val (timings, amplitudes) = when (style) {
                        HapticFeedbackStyle.LIGHT_TICK -> {
                            longArrayOf(0, 20) to intArrayOf(0, 100)
                        }
                        HapticFeedbackStyle.CRISP_CLICK -> {
                            longArrayOf(0, 45) to intArrayOf(0, 180)
                        }
                        HapticFeedbackStyle.DOUBLE_TAP -> {
                            longArrayOf(0, 30, 40, 35) to intArrayOf(0, 180, 0, 220)
                        }
                        HapticFeedbackStyle.HEAVY_CONFIRM -> {
                            longArrayOf(0, 80) to intArrayOf(0, 255)
                        }
                    }
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
                } else {
                    @Suppress("DEPRECATION")
                    val duration = when (style) {
                        HapticFeedbackStyle.LIGHT_TICK -> 25L
                        HapticFeedbackStyle.CRISP_CLICK -> 45L
                        HapticFeedbackStyle.DOUBLE_TAP -> 80L
                        HapticFeedbackStyle.HEAVY_CONFIRM -> 100L
                    }
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(duration)
                }
            }
        } catch (_: Exception) {
            // Ignore vibration errors if hardware or system haptics disabled
        }
    }

    /**
     * View-based haptic fallback for UI touches and immediate tactile sensation
     */
    fun performViewHaptic(view: View?, style: HapticFeedbackStyle = HapticFeedbackStyle.CRISP_CLICK) {
        if (view == null) return
        try {
            val feedbackConstant = when (style) {
                HapticFeedbackStyle.LIGHT_TICK -> HapticFeedbackConstants.CLOCK_TICK
                HapticFeedbackStyle.CRISP_CLICK -> HapticFeedbackConstants.KEYBOARD_TAP
                HapticFeedbackStyle.DOUBLE_TAP -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        HapticFeedbackConstants.CONFIRM
                    } else {
                        HapticFeedbackConstants.CONTEXT_CLICK
                    }
                }
                HapticFeedbackStyle.HEAVY_CONFIRM -> HapticFeedbackConstants.LONG_PRESS
            }
            view.performHapticFeedback(feedbackConstant, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)
        } catch (_: Exception) {}
    }

    fun playBeep() {
        try {
            val toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP, 100)
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try {
                    toneGenerator.release()
                } catch (_: Exception) {}
            }, 200)
        } catch (_: Exception) {
            // Ignore audio tone exceptions
        }
    }
}
