package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Manages strictly private, on-device storage for user personal photos and AI virtual try-on
 * previews inside the app's sandboxed internal directory (`context.filesDir`).
 * Personal photos are never uploaded to public buckets or exposed outside the app.
 */
object PrivatePhotoStorage {

    private const val USER_PHOTO_FILENAME = "private_user_personal_photo.jpg"
    private const val TRYON_DIR = "private_tryon_previews"

    suspend fun saveUserPersonalPhoto(context: Context, bitmap: Bitmap): File = withContext(Dispatchers.IO) {
        val scaled = scaleBitmapDown(bitmap, 1024)
        val targetFile = File(context.filesDir, USER_PHOTO_FILENAME)
        FileOutputStream(targetFile).use { out ->
            scaled.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }
        targetFile
    }

    suspend fun saveUserPhotoFromUri(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val rawBitmap = context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream)
            } ?: return@withContext null
            val scaled = scaleBitmapDown(rawBitmap, 1024)
            saveUserPersonalPhoto(context, scaled)
            scaled
        } catch (e: Exception) {
            null
        }
    }

    suspend fun loadUserPersonalPhoto(context: Context): Bitmap? = withContext(Dispatchers.IO) {
        val targetFile = File(context.filesDir, USER_PHOTO_FILENAME)
        if (!targetFile.exists()) return@withContext null
        BitmapFactory.decodeFile(targetFile.absolutePath)
    }

    suspend fun deleteUserPersonalPhoto(context: Context): Boolean = withContext(Dispatchers.IO) {
        val targetFile = File(context.filesDir, USER_PHOTO_FILENAME)
        if (targetFile.exists()) targetFile.delete() else true
    }

    suspend fun saveTryOnPreviewBitmap(context: Context, sessionId: String, bitmap: Bitmap): String = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, TRYON_DIR)
        if (!dir.exists()) dir.mkdirs()
        val safeName = "tryon_${sessionId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")}.png"
        val file = File(dir, safeName)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
        }
        safeName
    }

    suspend fun loadTryOnPreviewBitmap(context: Context, filename: String): Bitmap? = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, TRYON_DIR)
        val file = File(dir, filename)
        if (!file.exists()) return@withContext null
        BitmapFactory.decodeFile(file.absolutePath)
    }

    suspend fun clearAllPrivatePhotos(context: Context) = withContext(Dispatchers.IO) {
        deleteUserPersonalPhoto(context)
        val dir = File(context.filesDir, TRYON_DIR)
        if (dir.exists()) {
            dir.listFiles()?.forEach { it.delete() }
            dir.delete()
        }
    }

    private fun scaleBitmapDown(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap
        val ratio = width.toFloat() / height.toFloat()
        val (newW, newH) = if (ratio > 1f) {
            maxDimension to (maxDimension / ratio).toInt().coerceAtLeast(1)
        } else {
            (maxDimension * ratio).toInt().coerceAtLeast(1) to maxDimension
        }
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }
}
