package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Manages strictly private, on-device storage for user personal photos and AI virtual try-on
 * previews inside the app's sandboxed internal directory (`context.filesDir`).
 * Personal photos are never uploaded to public buckets or exposed outside the app.
 */
object PrivatePhotoStorage {

    private const val TAG = "PrivatePhotoStorage"
    private const val USER_PHOTO_FILENAME = "private_user_personal_photo.jpg"
    private const val TRYON_DIR = "private_tryon_previews"

    suspend fun saveUserPersonalPhoto(context: Context, bitmap: Bitmap): Bitmap = withContext(Dispatchers.IO) {
        val softwareBmp = ensureSoftwareBitmap(bitmap)
        val scaled = scaleBitmapDown(softwareBmp, 1024)
        val targetFile = File(context.filesDir, USER_PHOTO_FILENAME)
        FileOutputStream(targetFile).use { out ->
            scaled.compress(Bitmap.CompressFormat.JPEG, 92, out)
        }
        scaled
    }

    suspend fun saveUserPhotoFromUri(context: Context, uri: Uri): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val bytes = context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.readBytes()
            }
            val decoded = if (bytes != null && bytes.isNotEmpty()) {
                val opts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                    inMutable = true
                }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            } else {
                null
            } ?: context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                val opts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                BitmapFactory.decodeFileDescriptor(pfd.fileDescriptor, null, opts)
            }

            if (decoded == null) {
                Log.w(TAG, "URI decode returned null for $uri")
                return@withContext null
            }

            saveUserPersonalPhoto(context, decoded)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to decode photo from URI: $uri", e)
            null
        }
    }

    suspend fun saveStudioModelPhotoPreset(
        context: Context,
        presetType: String
    ): Bitmap = withContext(Dispatchers.IO) {
        val generated = generateStudioPortraitBitmap(presetType)
        saveUserPersonalPhoto(context, generated)
    }

    suspend fun loadUserPersonalPhoto(context: Context): Bitmap? = withContext(Dispatchers.IO) {
        val targetFile = File(context.filesDir, USER_PHOTO_FILENAME)
        if (!targetFile.exists()) return@withContext null
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        BitmapFactory.decodeFile(targetFile.absolutePath, opts)?.let { ensureSoftwareBitmap(it) }
    }

    suspend fun deleteUserPersonalPhoto(context: Context): Boolean = withContext(Dispatchers.IO) {
        val targetFile = File(context.filesDir, USER_PHOTO_FILENAME)
        if (targetFile.exists()) targetFile.delete() else true
    }

    suspend fun saveTryOnPreviewBitmap(context: Context, sessionId: String, bitmap: Bitmap): String = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, TRYON_DIR)
        if (!dir.exists()) dir.mkdirs()
        val safeName = "tryon_${sessionId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")}.png"
        val file = File(dir, safeName)
        val softwareBmp = ensureSoftwareBitmap(bitmap)
        FileOutputStream(file).use { out ->
            softwareBmp.compress(Bitmap.CompressFormat.PNG, 95, out)
        }
        safeName
    }

    suspend fun loadTryOnPreviewBitmap(context: Context, filename: String): Bitmap? = withContext(Dispatchers.IO) {
        val dir = File(context.filesDir, TRYON_DIR)
        val file = File(dir, filename)
        if (!file.exists()) return@withContext null
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        BitmapFactory.decodeFile(file.absolutePath, opts)?.let { ensureSoftwareBitmap(it) }
    }

    suspend fun clearAllPrivatePhotos(context: Context) = withContext(Dispatchers.IO) {
        deleteUserPersonalPhoto(context)
        val dir = File(context.filesDir, TRYON_DIR)
        if (dir.exists()) {
            dir.listFiles()?.forEach { it.delete() }
            dir.delete()
        }
    }

    fun ensureSoftwareBitmap(bitmap: Bitmap): Bitmap {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bitmap.config == Bitmap.Config.HARDWARE) {
            return bitmap.copy(Bitmap.Config.ARGB_8888, true)
        }
        if (bitmap.config != Bitmap.Config.ARGB_8888) {
            return bitmap.copy(Bitmap.Config.ARGB_8888, true)
        }
        return bitmap
    }

    /**
     * Generates a high-resolution (720x960) full-torso studio portrait bitmap for instant photo upload
     * and virtual try-on testing (supports "MALE", "FEMALE", or "STREETWEAR" presets).
     */
    fun generateStudioPortraitBitmap(presetType: String): Bitmap {
        val width = 720
        val height = 960
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        val isFemale = presetType.uppercase().contains("FEMALE")
        val isStreet = presetType.uppercase().contains("STREET")

        // 1. Studio Backdrop Gradient
        val bgTop = when {
            isFemale -> Color.parseColor("#2A1B2E")
            isStreet -> Color.parseColor("#16222F")
            else -> Color.parseColor("#1A202C")
        }
        val bgBottom = when {
            isFemale -> Color.parseColor("#120D16")
            isStreet -> Color.parseColor("#0B1118")
            else -> Color.parseColor("#0D1117")
        }
        paint.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            bgTop, bgBottom, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.shader = null

        // 2. Soft Studio Key Light Halo
        paint.color = if (isFemale) Color.parseColor("#26F43F5E") else Color.parseColor("#2638BDF8")
        canvas.drawCircle(width * 0.5f, height * 0.34f, width * 0.42f, paint)

        // 3. Hair Back Layer (for Female / Longer hair)
        if (isFemale) {
            paint.color = Color.parseColor("#1C1412")
            val hairBack = RectF(width * 0.31f, height * 0.14f, width * 0.69f, height * 0.46f)
            canvas.drawRoundRect(hairBack, 90f, 90f, paint)
        }

        // 4. Neck & Collarbone
        val skinTone = when {
            isFemale -> Color.parseColor("#E5B899")
            isStreet -> Color.parseColor("#D69E72")
            else -> Color.parseColor("#DBA67B")
        }
        paint.color = skinTone
        canvas.drawRoundRect(
            RectF(width * 0.43f, height * 0.33f, width * 0.57f, height * 0.46f),
            28f, 28f, paint
        )

        // 5. Full Torso & Shoulders (Base Studio Tee / Kurta Silhouette ready for Virtual Try-On)
        val baseTopColor = when {
            isFemale -> Color.parseColor("#9D174D")
            isStreet -> Color.parseColor("#0284C7")
            else -> Color.parseColor("#1E293B")
        }
        paint.color = baseTopColor
        val torsoPath = Path().apply {
            moveTo(width * 0.16f, height * 0.96f)
            lineTo(width * 0.20f, height * 0.46f)
            quadTo(width * 0.23f, height * 0.40f, width * 0.42f, height * 0.40f)
            quadTo(width * 0.50f, height * 0.45f, width * 0.58f, height * 0.40f)
            quadTo(width * 0.77f, height * 0.40f, width * 0.80f, height * 0.46f)
            lineTo(width * 0.84f, height * 0.96f)
            close()
        }
        canvas.drawPath(torsoPath, paint)

        // Subtle Garment Lapel / Seam Detail
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4f
        paint.color = Color.parseColor("#55FFFFFF")
        canvas.drawLine(width * 0.50f, height * 0.43f, width * 0.50f, height * 0.92f, paint)
        paint.style = Paint.Style.FILL

        // 6. Head & Face Oval
        paint.color = skinTone
        val headRect = RectF(width * 0.37f, height * 0.15f, width * 0.63f, height * 0.37f)
        canvas.drawOval(headRect, paint)

        // 7. Hair Crown
        paint.color = Color.parseColor("#181210")
        val hairTop = Path().apply {
            moveTo(width * 0.36f, height * 0.24f)
            quadTo(width * 0.50f, height * 0.10f, width * 0.64f, height * 0.24f)
            quadTo(width * 0.58f, height * 0.17f, width * 0.50f, height * 0.17f)
            quadTo(width * 0.42f, height * 0.17f, width * 0.36f, height * 0.24f)
            close()
        }
        canvas.drawPath(hairTop, paint)

        // 8. Minimalist Editorial Facial Features (Eyes, Brows, Smile)
        paint.color = Color.parseColor("#2D1E18")
        canvas.drawCircle(width * 0.45f, height * 0.25f, 6.5f, paint)
        canvas.drawCircle(width * 0.55f, height * 0.25f, 6.5f, paint)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4.5f
        val smileRect = RectF(width * 0.46f, height * 0.29f, width * 0.54f, height * 0.33f)
        canvas.drawArc(smileRect, 15f, 150f, false, paint)
        paint.style = Paint.Style.FILL

        // 9. Studio Watermark Pill at Bottom
        paint.color = Color.parseColor("#AA090A0F")
        canvas.drawRoundRect(
            RectF(width * 0.18f, height * 0.89f, width * 0.82f, height * 0.945f),
            26f, 26f, paint
        )
        paint.color = Color.parseColor("#F59E0B")
        paint.textSize = 22f
        paint.textAlign = Paint.Align.CENTER
        val label = when {
            isFemale -> "STYLE AI • STUDIO PORTRAIT (FEMALE)"
            isStreet -> "STYLE AI • STREETWEAR PORTRAIT"
            else -> "STYLE AI • STUDIO PORTRAIT (MALE)"
        }
        canvas.drawText(label, width * 0.5f, height * 0.926f, paint)

        return bmp
    }

    private fun scaleBitmapDown(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap
        val ratio = width.toFloat() / height.toFloat()
        val (newW, newH) = if (ratio > 1f) {
            maxDimension to (maxDimension / ratio).toInt().coerceAtLeast(1)
        } else {
            (maxDimension * ratio).toInt().coerceAtLeast(1) to maxDimension
        }
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }
}

