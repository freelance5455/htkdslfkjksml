package com.example.util

import android.os.SystemClock
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Real-time dynamic temporal and calendar engine for RAYNOX AI.
 * Reads dynamically from Android's system clock with Asia/Kolkata (IST) as default.
 * Never uses hardcoded dates or times.
 */
object DateTimeHelper {

    const val TIMEZONE_IST = "Asia/Kolkata"

    data class TemporalContext(
        val istTime12h: String,
        val istTime24h: String,
        val istDateFormatted: String,
        val dayOfWeekEnglish: String,
        val dayOfWeekHindi: String,
        val timeZoneId: String,
        val timeZoneName: String,
        val todayDate: String,
        val yesterdayDate: String,
        val tomorrowDate: String,
        val dayAfterTomorrowDate: String,
        val currentYear: Int,
        val currentMonthNumber: Int,
        val currentMonthName: String,
        val daysInCurrentMonth: Int,
        val daysRemainingInMonth: Int,
        val dayOfMonth: Int,
        val isLeapYear: Boolean,
        val daysRemainingInYear: Int,
        val epochMillis: Long
    )

    data class NetworkTimeResult(
        val isVerified: Boolean,
        val serverDateString: String,
        val serverEpochMillis: Long,
        val offsetFromDeviceMs: Long,
        val message: String
    )

    /**
     * Obtains the live dynamic temporal context right now in Asia/Kolkata (IST).
     */
    fun getLiveTemporalContext(timeZoneId: String = TIMEZONE_IST): TemporalContext {
        val tz = TimeZone.getTimeZone(timeZoneId)
        val now = System.currentTimeMillis()

        val cal = Calendar.getInstance(tz).apply {
            timeInMillis = now
        }

        val year = cal.get(Calendar.YEAR)
        val monthNum = cal.get(Calendar.MONTH) + 1
        val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val daysRemainingInMonth = daysInMonth - dayOfMonth
        val isLeap = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)

        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val maxDaysInYear = if (isLeap) 366 else 365
        val daysRemainingInYear = maxDaysInYear - dayOfYear

        val time12Format = SimpleDateFormat("hh:mm:ss a", Locale.US).apply { timeZone = tz }
        val time24Format = SimpleDateFormat("HH:mm:ss", Locale.US).apply { timeZone = tz }
        val dateFullFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.US).apply { timeZone = tz }
        val dateStandardFormat = SimpleDateFormat("d MMMM yyyy", Locale.US).apply { timeZone = tz }
        val monthNameFormat = SimpleDateFormat("MMMM", Locale.US).apply { timeZone = tz }

        val istTime12h = time12Format.format(Date(now))
        val istTime24h = time24Format.format(Date(now))
        val istDateFormatted = dateFullFormat.format(Date(now))
        val todayStr = dateStandardFormat.format(Date(now))
        val monthName = monthNameFormat.format(Date(now))

        val dayOfWeekIndex = cal.get(Calendar.DAY_OF_WEEK)
        val (dayOfWeekEnglish, dayOfWeekHindi) = when (dayOfWeekIndex) {
            Calendar.SUNDAY -> "Sunday" to "Ravivar (रविवार)"
            Calendar.MONDAY -> "Monday" to "Somvar (सोमवार)"
            Calendar.TUESDAY -> "Tuesday" to "Mangalvar (मंगलवार)"
            Calendar.WEDNESDAY -> "Wednesday" to "Budhvar (बुधवार)"
            Calendar.THURSDAY -> "Thursday" to "Guruvar (गुरुवार)"
            Calendar.FRIDAY -> "Friday" to "Shukravar (शुक्रवार)"
            Calendar.SATURDAY -> "Saturday" to "Shanivar (शनिवार)"
            else -> "Unknown" to "Unknown"
        }

        // Relative dates: Yesterday (-1 day)
        val yCal = Calendar.getInstance(tz).apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, -1)
        }
        val yesterdayStr = dateFullFormat.format(yCal.time)

        // Tomorrow (+1 day)
        val tCal = Calendar.getInstance(tz).apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, 1)
        }
        val tomorrowStr = dateFullFormat.format(tCal.time)

        // Day after tomorrow (+2 days / Parson)
        val pCal = Calendar.getInstance(tz).apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, 2)
        }
        val dayAfterTomorrowStr = dateFullFormat.format(pCal.time)

        return TemporalContext(
            istTime12h = istTime12h,
            istTime24h = istTime24h,
            istDateFormatted = istDateFormatted,
            dayOfWeekEnglish = dayOfWeekEnglish,
            dayOfWeekHindi = dayOfWeekHindi,
            timeZoneId = timeZoneId,
            timeZoneName = "Indian Standard Time (IST, UTC+05:30)",
            todayDate = todayStr,
            yesterdayDate = yesterdayStr,
            tomorrowDate = tomorrowStr,
            dayAfterTomorrowDate = dayAfterTomorrowStr,
            currentYear = year,
            currentMonthNumber = monthNum,
            currentMonthName = monthName,
            daysInCurrentMonth = daysInMonth,
            daysRemainingInMonth = daysRemainingInMonth,
            dayOfMonth = dayOfMonth,
            isLeapYear = isLeap,
            daysRemainingInYear = daysRemainingInYear,
            epochMillis = now
        )
    }

    /**
     * Generates a dynamic temporal context header injected into the AI system instruction before each request.
     * Ensures the AI always has the live dynamic clock values and calendar details.
     */
    fun formatSystemPromptTemporalHeader(timeZoneId: String = TIMEZONE_IST): String {
        val ctx = getLiveTemporalContext(timeZoneId)
        return buildString {
            appendLine("=== LIVE DEVICE TEMPORAL CONTEXT (REAL-TIME SYSTEM CLOCK) ===")
            appendLine("Timezone: ${ctx.timeZoneName} [${ctx.timeZoneId}]")
            appendLine("Current Time (12-hour): ${ctx.istTime12h}")
            appendLine("Current Time (24-hour): ${ctx.istTime24h}")
            appendLine("Current Full Date: ${ctx.istDateFormatted}")
            appendLine("Weekday: ${ctx.dayOfWeekEnglish} (${ctx.dayOfWeekHindi})")
            appendLine("Today (Aaj): ${ctx.todayDate}")
            appendLine("Yesterday (Beeta hua kal): ${ctx.yesterdayDate}")
            appendLine("Tomorrow (Aane wala kal): ${ctx.tomorrowDate}")
            appendLine("Day after tomorrow (Parson): ${ctx.dayAfterTomorrowDate}")
            appendLine("Month: ${ctx.currentMonthName} (Month ${ctx.currentMonthNumber} of ${ctx.currentYear})")
            appendLine("Days in this month: ${ctx.daysInCurrentMonth} days (Days remaining: ${ctx.daysRemainingInMonth})")
            appendLine("Current Year: ${ctx.currentYear} (Leap Year: ${if (ctx.isLeapYear) "Yes" else "No"})")
            appendLine("Days remaining in ${ctx.currentYear}: ${ctx.daysRemainingInYear} days")
            appendLine("Instructions for Temporal Questions:")
            appendLine("- This temporal information comes directly from the user's live Android device system clock.")
            appendLine("- Always refer to this live context for any questions about 'today', 'now', 'time', 'date', 'kal', 'parson', 'yesterday', 'weekday', 'month', 'year'.")
            appendLine("- Hindi/Hinglish terms: 'aaj' = today, 'abhi' = right now, 'kal' = tomorrow or yesterday based on context, 'parson' = day after tomorrow or two days ago, 'kitne baje hain' = current time, 'kaunsa din hai' = day of week.")
            appendLine("- Calculate date arithmetic and countdowns accurately based on the current date (${ctx.todayDate}).")
            appendLine("==============================================================")
        }
    }

    /**
     * Calculates days between today and a target date in IST.
     */
    fun calculateDaysFromToday(targetYear: Int, targetMonth: Int, targetDay: Int): Long {
        val tz = TimeZone.getTimeZone(TIMEZONE_IST)
        val todayCal = Calendar.getInstance(tz).apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val targetCal = Calendar.getInstance(tz).apply {
            set(Calendar.YEAR, targetYear)
            set(Calendar.MONTH, targetMonth - 1)
            set(Calendar.DAY_OF_MONTH, targetDay)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val diffMs = targetCal.timeInMillis - todayCal.timeInMillis
        return diffMs / (1000 * 60 * 60 * 24)
    }

    /**
     * Queries network server time via HTTP Date header from a trusted endpoint.
     * Clearly distinguishes device clock time from server-verified time.
     */
    suspend fun fetchNetworkVerifiedTime(): NetworkTimeResult = withContext(Dispatchers.IO) {
        val urls = listOf("https://www.google.com", "https://clients3.google.com/generate_204")
        for (urlStr in urls) {
            try {
                val url = URL(urlStr)
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4000
                    readTimeout = 4000
                    requestMethod = "HEAD"
                    instanceFollowRedirects = false
                }
                val serverEpoch = conn.date
                conn.disconnect()

                if (serverEpoch > 0) {
                    val deviceEpoch = System.currentTimeMillis()
                    val offsetMs = serverEpoch - deviceEpoch
                    val tz = TimeZone.getTimeZone(TIMEZONE_IST)
                    val format = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm:ss a 'IST'", Locale.US).apply {
                        timeZone = tz
                    }
                    val formatted = format.format(Date(serverEpoch))
                    val diffSec = Math.abs(offsetMs) / 1000

                    return@withContext NetworkTimeResult(
                        isVerified = true,
                        serverDateString = formatted,
                        serverEpochMillis = serverEpoch,
                        offsetFromDeviceMs = offsetMs,
                        message = if (diffSec < 2) {
                            "Verified with online server: Device clock is accurate within 1-2 seconds ($formatted)."
                        } else {
                            "Verified with online server: Server time is $formatted (device clock is offset by ~${diffSec}s)."
                        }
                    )
                }
            } catch (_: Exception) {
                // Try next endpoint
            }
        }

        val fallback = getLiveTemporalContext()
        NetworkTimeResult(
            isVerified = false,
            serverDateString = "${fallback.istDateFormatted}, ${fallback.istTime12h}",
            serverEpochMillis = fallback.epochMillis,
            offsetFromDeviceMs = 0L,
            message = "Could not reach online time server. Showing device clock (${fallback.istDateFormatted}, ${fallback.istTime12h}). Device clock accuracy depends on system settings."
        )
    }
}
