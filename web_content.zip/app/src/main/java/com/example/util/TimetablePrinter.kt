package com.example.util

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.local.LessonEntity
import com.example.data.model.AppConstants
import com.example.data.model.LessonMode

object TimetablePrinter {

    private var activeWebView: WebView? = null

    fun printTimetable(context: Context, lessons: List<LessonEntity>) {
        val webView = WebView(context).apply {
            settings.javaScriptEnabled = false
        }
        activeWebView = webView

        val html = buildOfflinePrintableHtml(lessons)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
                val jobName = "جدول_دروس_الثانوية"
                val adapter = webView.createPrintDocumentAdapter(jobName)
                printManager.print(jobName, adapter, PrintAttributes.Builder().build())
                activeWebView = null
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    private fun escapeHtml(text: String): String =
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")

    private fun buildOfflinePrintableHtml(lessons: List<LessonEntity>): String {
        val dateStr = DateTimeUtils.todayArabicFullDate()
        val daysHtml = AppConstants.DAYS_OF_WEEK.joinToString("") { day ->
            val dayLessons = lessons
                .filter { it.day == day }
                .sortedBy {
                    DateTimeUtils.parseTo24h(it.time).ifEmpty { "99:99" }
                }
            val cardsHtml = if (dayLessons.isEmpty()) {
                "<div class='empty'>لا توجد دروس</div>"
            } else {
                dayLessons.joinToString("") { l ->
                    val mode = LessonMode.fromKey(l.mode).shortBadge
                    val time = DateTimeUtils.formatTime12h(l.time)
                    val safeHex = if (l.colorHex.matches(Regex("^#[0-9A-Fa-f]{6}$"))) l.colorHex else "#4f46e5"
                    """
                    <div class='lesson' style='border-right: 5px solid $safeHex;'>
                        <div class='row'>
                            <strong>${escapeHtml(l.subject)}</strong>
                            <span class='badge'>$mode</span>
                        </div>
                        ${if (l.teacher.isNotBlank()) "<div class='meta'>المدرس: ${escapeHtml(l.teacher)}</div>" else ""}
                        <div class='meta'>
                            ${if (time.isNotBlank()) "<span>الوقت: ${escapeHtml(time)}</span>" else ""}
                            ${if (l.location.isNotBlank()) "<span> | المكان: ${escapeHtml(l.location)}</span>" else ""}
                        </div>
                    </div>
                    """.trimIndent()
                }
            }
            """
            <div class='day-card'>
                <div class='day-header'>
                    <span>$day</span>
                    <span class='count'>${dayLessons.size}</span>
                </div>
                $cardsHtml
            </div>
            """.trimIndent()
        }

        return """
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: sans-serif; color: #0f172a; padding: 16px; margin: 0; }
                .header { text-align: center; border-bottom: 2px solid #0f172a; padding-bottom: 10px; margin-bottom: 16px; }
                .header h1 { margin: 0; font-size: 20px; }
                .header p { margin: 4px 0 0; font-size: 12px; color: #475569; }
                .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
                .day-card { border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px; break-inside: avoid; }
                .day-header { display: flex; justify-content: space-between; font-weight: bold; font-size: 14px; border-bottom: 1px solid #e2e8f0; padding-bottom: 6px; margin-bottom: 8px; }
                .count { background: #e2e8f0; border-radius: 99px; padding: 1px 8px; font-size: 11px; }
                .lesson { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 8px; margin-bottom: 6px; }
                .row { display: flex; justify-content: space-between; align-items: center; font-size: 13px; }
                .badge { font-size: 10px; background: #e0e7ff; color: #3730a3; padding: 2px 6px; border-radius: 6px; }
                .meta { font-size: 11px; color: #475569; margin-top: 3px; }
                .empty { text-align: center; color: #94a3b8; font-size: 12px; padding: 14px 0; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>جدول دروس الثانوية العامة الأسبوعي</h1>
                <p>تاريخ الطباعة: ${escapeHtml(dateStr)}</p>
            </div>
            <div class="grid">$daysHtml</div>
        </body>
        </html>
        """.trimIndent()
    }
}
