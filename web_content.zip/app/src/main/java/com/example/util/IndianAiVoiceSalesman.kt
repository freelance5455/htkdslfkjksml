package com.example.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.FashionProduct
import com.example.data.model.SalesAssistantPersona
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class PhoneAuthSession(
    val uid: String,
    val phoneNumber: String,
    val displayName: String
)

object LoginPersonaPrefs {
    private const val PREFS_NAME = "styleai_login_persona_prefs"
    private const val KEY_USER_GENDER = "user_gender"
    private const val KEY_PREFERRED_LANGUAGE = "preferred_language"
    private const val KEY_CONFIRMED_AT_LOGIN = "confirmed_at_login"
    private const val KEY_VOICE_MUTED = "voice_muted"
    private const val KEY_VERIFIED_PHONE = "verified_phone_number"
    private const val KEY_HAS_COMPLETED_FIRST_TIME_AUTH = "has_completed_first_time_auth"
    private const val KEY_SAVED_USER_UID = "saved_user_uid"
    private const val KEY_SAVED_DISPLAY_NAME = "saved_display_name"

    private val _phoneSessionFlow = MutableStateFlow<PhoneAuthSession?>(null)
    val phoneSessionFlow: StateFlow<PhoneAuthSession?> = _phoneSessionFlow.asStateFlow()

    val supportedLanguages = listOf(
        "Auto Local",
        "Indian English",
        "Hinglish",
        "हिन्दी (Hindi)",
        "తెలుగు (Telugu)",
        "தமிழ் (Tamil)",
        "ಕನ್ನಡ (Kannada)",
        "മലയാളം (Malayalam)"
    )

    /**
     * Synchronously loads the persisted user session on app launch so returning users
     * go straight into the app without seeing the Login/Sign-Up screen every time.
     */
    fun loadVerifiedPhoneSession(context: Context): PhoneAuthSession? {
        _phoneSessionFlow.value?.let { return it }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val hasCompletedFirstTimeAuth = prefs.getBoolean(KEY_HAS_COMPLETED_FIRST_TIME_AUTH, false)
        val phone = prefs.getString(KEY_VERIFIED_PHONE, null)?.takeIf { it.isNotBlank() }
        val savedUid = prefs.getString(KEY_SAVED_USER_UID, null)?.takeIf { it.isNotBlank() }
        val savedDisplayName = prefs.getString(KEY_SAVED_DISPLAY_NAME, null)?.takeIf { it.isNotBlank() }

        if (!hasCompletedFirstTimeAuth && phone == null && savedUid == null) {
            return null
        }

        val resolvedPhone = phone ?: "+919876543210"
        val digits = resolvedPhone.filter { it.isDigit() }.ifBlank { "9876543210" }
        val resolvedUid = savedUid ?: "phone_$digits"
        val resolvedName = savedDisplayName ?: "Member ($resolvedPhone)"

        val session = PhoneAuthSession(
            uid = resolvedUid,
            phoneNumber = resolvedPhone,
            displayName = resolvedName
        )
        _phoneSessionFlow.value = session
        return session
    }

    fun saveVerifiedPhoneSession(
        context: Context,
        phoneNumber: String,
        displayName: String? = null
    ): PhoneAuthSession {
        val trimmedPhone = phoneNumber.trim().ifBlank { "+919876543210" }
        val digits = trimmedPhone.filter { it.isDigit() }.ifBlank { "9876543210" }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existingName = prefs.getString(KEY_SAVED_DISPLAY_NAME, null)?.takeIf { it.isNotBlank() }
        val finalDisplayName = displayName?.trim()?.takeIf { it.isNotBlank() }
            ?: existingName
            ?: "Member ($trimmedPhone)"
        val uid = "phone_$digits"

        prefs.edit()
            .putBoolean(KEY_HAS_COMPLETED_FIRST_TIME_AUTH, true)
            .putBoolean(KEY_CONFIRMED_AT_LOGIN, true)
            .putString(KEY_VERIFIED_PHONE, trimmedPhone)
            .putString(KEY_SAVED_USER_UID, uid)
            .putString(KEY_SAVED_DISPLAY_NAME, finalDisplayName)
            .apply()

        val session = PhoneAuthSession(
            uid = uid,
            phoneNumber = trimmedPhone,
            displayName = finalDisplayName
        )
        _phoneSessionFlow.value = session
        return session
    }

    fun saveAuthenticatedSession(
        context: Context,
        uid: String,
        displayName: String,
        phoneNumber: String = ""
    ): PhoneAuthSession {
        val safeUid = uid.trim().ifBlank { "member_default" }
        val safeName = displayName.trim().ifBlank { "Style Connoisseur" }
        val safePhone = phoneNumber.trim()
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_HAS_COMPLETED_FIRST_TIME_AUTH, true)
            .putBoolean(KEY_CONFIRMED_AT_LOGIN, true)
            .putString(KEY_SAVED_USER_UID, safeUid)
            .putString(KEY_SAVED_DISPLAY_NAME, safeName)
            .apply {
                if (safePhone.isNotBlank()) {
                    putString(KEY_VERIFIED_PHONE, safePhone)
                }
            }
            .apply()

        val session = PhoneAuthSession(
            uid = safeUid,
            phoneNumber = safePhone,
            displayName = safeName
        )
        _phoneSessionFlow.value = session
        return session
    }

    fun clearVerifiedPhoneSession(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .remove(KEY_VERIFIED_PHONE)
            .remove(KEY_HAS_COMPLETED_FIRST_TIME_AUTH)
            .remove(KEY_SAVED_USER_UID)
            .remove(KEY_SAVED_DISPLAY_NAME)
            .apply()
        _phoneSessionFlow.value = null
    }

    fun hasCompletedFirstTimeAuth(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_HAS_COMPLETED_FIRST_TIME_AUTH, false) ||
            !prefs.getString(KEY_VERIFIED_PHONE, null).isNullOrBlank() ||
            !prefs.getString(KEY_SAVED_USER_UID, null).isNullOrBlank()
    }

    fun getUserGender(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_USER_GENDER, "MALE") ?: "MALE"
    }

    fun getPreferredLanguage(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_PREFERRED_LANGUAGE, "Auto Local") ?: "Auto Local"
    }

    fun hasConfirmedGenderAtLogin(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_CONFIRMED_AT_LOGIN, false)
    }

    fun isVoiceMuted(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_VOICE_MUTED, false)
    }

    fun saveVoiceMuted(context: Context, muted: Boolean) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_VOICE_MUTED, muted)
            .apply()
    }

    fun saveLoginPersona(context: Context, userGender: String, preferredLanguage: String) {
        val normalizedGender = if (userGender.uppercase() == "FEMALE") "FEMALE" else "MALE"
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_USER_GENDER, normalizedGender)
            .putString(KEY_PREFERRED_LANGUAGE, preferredLanguage)
            .putBoolean(KEY_CONFIRMED_AT_LOGIN, true)
            .apply()
    }

    fun getOppositeGenderSalesmanPersona(userGender: String): SalesAssistantPersona {
        val isFemaleUser = userGender.uppercase() == "FEMALE"
        return if (isFemaleUser) {
            // Male AI Assistant for Female User
            SalesAssistantPersona(
                assistantName = "Kabir AI",
                assistantGender = "MALE",
                roleTitle = "Male AI Showroom Salesman",
                badgeTagline = "Kabir • Male AI Salesman (For Her)",
                userHonorific = "Ma'am"
            )
        } else {
            // Female AI Assistant for Male User
            SalesAssistantPersona(
                assistantName = "Ananya AI",
                assistantGender = "FEMALE",
                roleTitle = "Female AI Showroom Saleswoman",
                badgeTagline = "Ananya • Female AI Sales (For Him)",
                userHonorific = "Sir"
            )
        }
    }

    fun resolveEffectiveLanguageKey(preferredLanguage: String): String {
        if (preferredLanguage != "Auto Local") return preferredLanguage
        val sysLang = Locale.getDefault().language.lowercase()
        return when (sysLang) {
            "hi" -> "हिन्दी (Hindi)"
            "te" -> "తెలుగు (Telugu)"
            "ta" -> "தமிழ் (Tamil)"
            "kn" -> "ಕನ್ನಡ (Kannada)"
            "ml" -> "മലയാളം (Malayalam)"
            else -> "Indian English"
        }
    }

    fun resolveTtsLocale(preferredLanguage: String): Locale {
        val effective = resolveEffectiveLanguageKey(preferredLanguage)
        return when {
            effective.contains("Hindi") -> Locale("hi", "IN")
            effective.contains("Telugu") -> Locale("te", "IN")
            effective.contains("Tamil") -> Locale("ta", "IN")
            effective.contains("Kannada") -> Locale("kn", "IN")
            effective.contains("Malayalam") -> Locale("ml", "IN")
            else -> Locale("en", "IN")
        }
    }

    fun buildInstantSalesPitch(
        screenKey: String,
        userGender: String,
        preferredLanguage: String,
        featuredProduct: FashionProduct? = null
    ): Pair<String, String> {
        val persona = getOppositeGenderSalesmanPersona(userGender)
        val name = persona.assistantName
        val honorific = persona.userHonorific
        val effectiveLang = resolveEffectiveLanguageKey(preferredLanguage)
        val prodName = featuredProduct?.name ?: "Obsidian Tailored Bandhgala & Streetwear"
        val prodPrice = featuredProduct?.priceInr ?: 949
        val prodRetailer = featuredProduct?.primaryRetailer ?: "Myntra"

        return when {
            effectiveLang.contains("Hindi") -> {
                when (screenKey) {
                    "WELCOME", "HOME" -> Pair(
                        "नमस्ते $honorific! मैं $name हूँ, आपका पर्सनल AI शोरूम सेल्समैन। आज आपके लिए मेरे पास ₹999 के अंदर शानदार कॉलेज और पार्टी आउटफिट्स हैं—चलिए मैं आपको बेस्ट डील दिखाता हूँ!",
                        "Best Deals दिखाएं"
                    )
                    "DISCOVER" -> Pair(
                        "देखिए $honorific, यहाँ Myntra, AJIO, Amazon और Flipkart की लाइव कीमतें हैं! '$prodName' अभी सिर्फ ₹$prodPrice में मिल रहा है—इस पर टैप करके कीमतों की तुलना करें!",
                        "कीमत तुलना करें"
                    )
                    "TRY_ON" -> Pair(
                        "$honorific, यह हमारा AI वर्चुअल ट्रायल रूम है! अपनी फोटो अपलोड करें और देखें कि '$prodName' आप पर कैसा जचता है—बिल्कुल असली शोरूम मिरर की तरह!",
                        "Try-On शुरू करें"
                    )
                    "PRODUCT_DETAIL" -> Pair(
                        "वाह $honorific! '$prodName' आप पर बहुत शानदार लगेगा। $prodRetailer पर इसकी सबसे कम कीमत ₹$prodPrice है—इसे अभी ट्रायल रूम में पहन कर देखें!",
                        "अभी Try-On करें"
                    )
                    "WARDROBE" -> Pair(
                        "$honorific, यहाँ आपके सेव किए गए पसंदीदा आउटफिट्स हैं। जब भी कोई डील सस्ती हो, तुरंत आर्डर कर लीजिए!",
                        "कैटलॉग देखें"
                    )
                    else -> Pair(
                        "$honorific, मैं $name हमेशा आपकी साइड में हूँ। आप कभी भी अपनी भाषा या जेंडर प्रेफरेंस बदल सकते हैं!",
                        "स्टाइलिंग शुरू करें"
                    )
                }
            }
            effectiveLang.contains("Telugu") -> {
                when (screenKey) {
                    "WELCOME", "HOME" -> Pair(
                        "నమస్కారం $honorific! నేను $name, మీ వ్యక్తిగత AI షోరూమ్ సేల్స్ అసిస్టెంట్. ఈరోజు మీ కోసం ₹999 లోపు అద్భుతమైన అవుట్‌ఫిట్స్ ఉన్నాయి, రండి బెస్ట్ ఆఫర్స్ చూపిస్తాను!",
                        "బెస్ట్ ఆఫర్స్ చూడండి"
                    )
                    "DISCOVER" -> Pair(
                        "చూడండి $honorific! Myntra, AJIO, Amazon మరియు Flipkart లో '$prodName' కేవలం ₹$prodPrice కే లభిస్తోంది. వెంటనే ధరలు పోల్చి చూడండి!",
                        "ధరలు పోల్చండి"
                    )
                    "TRY_ON" -> Pair(
                        "$honorific, ఇది మన AI వర్చువల్ ట్రయల్ రూమ్! మీ ఫోటో అప్‌లోడ్ చేసి '$prodName' మీకు ఎలా సూట్ అవుతుందో ఇప్పుడే చూడండి!",
                        "Try-On చేయండి"
                    )
                    "PRODUCT_DETAIL" -> Pair(
                        "సూపర్ సెలెక్షన్ $honorific! '$prodName' మీకు చాలా బాగా సెట్ అవుతుంది. $prodRetailer లో ₹$prodPrice కే బెస్ట్ డీల్ ఉంది!",
                        "ఇప్పుడే Try-On చేయండి"
                    )
                    else -> Pair(
                        "$honorific, నేను $name మీ షాపింగ్ గైడ్‌గా ఎప్పుడూ సిద్ధంగా ఉన్నాను. మీకు ఏ డ్రెస్ కావాలో చెప్పండి!",
                        "డిస్కవర్ చూడండి"
                    )
                }
            }
            effectiveLang.contains("Tamil") -> {
                when (screenKey) {
                    "WELCOME", "HOME" -> Pair(
                        "வணக்கம் $honorific! நான் $name, உங்கள் AI ஷோரூம் விற்பனையாளர். உங்களுக்காக ₹999-க்குள் அசத்தலான உடைகள் உள்ளன—வாருங்கள் சிறந்த ஆஃபர்களைக் காட்டுகிறேன்!",
                        "சிறந்த ஆஃபர்கள்"
                    )
                    "DISCOVER" -> Pair(
                        "பாருங்கள் $honorific! Myntra, AJIO, Amazon மற்றும் Flipkart-ல் '$prodName' வெறும் ₹$prodPrice-க்குக் கிடைக்கிறது. உடனே விலையை ஒப்பிட்டுப் பாருங்கள்!",
                        "விலை ஒப்பீடு"
                    )
                    "TRY_ON" -> Pair(
                        "$honorific, இது நமது AI விர்ச்சுவல் டிரையல் ரூம்! உங்கள் புகைப்படத்தைப் பதிவேற்றி '$prodName' உங்களுக்கு எப்படிப் பொருந்துகிறது என்று பாருங்கள்!",
                        "Try-On செய்க"
                    )
                    "PRODUCT_DETAIL" -> Pair(
                        "அருமையான தேர்வு $honorific! '$prodName' உங்களுக்கு மிக அழகாக இருக்கும். $prodRetailer-ல் ₹$prodPrice மட்டுமே!",
                        "இப்போதே Try-On"
                    )
                    else -> Pair(
                        "$honorific, நான் $name உங்களுக்கு வழிகாட்ட எப்போதும் இங்கே இருக்கிறேன்!",
                        "ஆடைகளைப் பார்க்க"
                    )
                }
            }
            effectiveLang.contains("Kannada") -> {
                when (screenKey) {
                    "WELCOME", "HOME" -> Pair(
                        "ನಮಸ್ಕಾರ $honorific! ನಾನು $name, ನಿಮ್ಮ ವೈಯಕ್ತಿಕ AI ಶೋರೂಮ್ ಸೇಲ್ಸ್ ಅಸಿಸ್ಟೆಂಟ್. ಇಂದು ನಿಮಗಾಗಿ ₹999 ಒಳಗೆ ಸೂಪರ್ ಔಟ್‌ಫಿಟ್‌ಗಳಿವೆ, ಬನ್ನಿ ತೋರಿಸುತ್ತೇನೆ!",
                        "ಬೆಸ್ಟ್ ಡೀಲ್ಸ್ ನೋಡಿ"
                    )
                    "DISCOVER" -> Pair(
                        "ನೋಡಿ $honorific! Myntra, AJIO, Amazon ಮತ್ತು Flipkart ನಲ್ಲಿ '$prodName' ಕೇವಲ ₹$prodPrice ಗೆ ಲಭ್ಯವಿದೆ!",
                        "ಬೆಲೆ ಹೋಲಿಸಿ"
                    )
                    "TRY_ON" -> Pair(
                        "$honorific, ಇದು ನಮ್ಮ AI ವರ್ಚುವಲ್ ಟ್ರಯಲ್ ರೂಮ್! ನಿಮ್ಮ ಫೋಟೋ ಹಾಕಿ '$prodName' ಹೇಗೆ ಕಾಣುತ್ತದೆ ಎಂದು ನೋಡಿ!",
                        "Try-On ಮಾಡಿ"
                    )
                    else -> Pair(
                        "ಅದ್ಭುತ ಆಯ್ಕೆ $honorific! '$prodName' ನಿಮಗೆ ತುಂಬಾ ಚೆನ್ನಾಗಿ ಒಪ್ಪುತ್ತದೆ. $prodRetailer ನಲ್ಲಿ ₹$prodPrice ಮಾತ್ರ!",
                        "ಈಗಲೇ Try-On ಮಾಡಿ"
                    )
                }
            }
            effectiveLang.contains("Malayalam") -> {
                when (screenKey) {
                    "WELCOME", "HOME" -> Pair(
                        "നമസ്കാരം $honorific! ഞാൻ $name, നിങ്ങളുടെ AI ഷോറൂം സെയിൽസ് അസിസ്റ്റന്റ്. ₹999-ൽ താഴെയുള്ള മികച്ച വസ്ത്രങ്ങൾ ഞാൻ കാണിച്ചുതരാം!",
                        "മികച്ച ഓഫറുകൾ"
                    )
                    else -> Pair(
                        "നോക്കൂ $honorific! '$prodName' വെറും ₹$prodPrice-ന് $prodRetailer-ൽ ലഭ്യമാണ്. ഇപ്പോൾ തന്നെ Virtual Try-On ചെയ്തു നോക്കൂ!",
                        "Try-On ചെയ്യുക"
                    )
                }
            }
            effectiveLang.contains("Hinglish") -> {
                when (screenKey) {
                    "WELCOME", "HOME" -> Pair(
                        "Namaste $honorific! Main hoon $name, aapka personal AI Showroom Salesman. Aaj mere paas aapke liye ₹999 ke andar killer outfits aur wedding looks hain—chaliye main aapko direct best deals par le chalta hoon!",
                        "Show Best Deals"
                    )
                    "DISCOVER" -> Pair(
                        "Dekhiye $honorific! '$prodName' abhi $prodRetailer par sirf ₹$prodPrice mein mil raha hai. Myntra, AJIO, Amazon aur Flipkart ka live price compare kijiye!",
                        "Compare Lowest Price"
                    )
                    "TRY_ON" -> Pair(
                        "$honorific, yeh hamara AI Trial Room hai! Apni photo select kijiye aur dekhiye '$prodName' aapke face aur body par kaisa lagta hai!",
                        "Try On This Look"
                    )
                    "PRODUCT_DETAIL" -> Pair(
                        "First-class choice $honorific! '$prodName' aapki personality par ekdum royal lagega, aur $prodRetailer par ₹$prodPrice mein sabse sasta mil raha hai!",
                        "Open Virtual Try-On"
                    )
                    else -> Pair(
                        "$honorific, main $name hamesha aapke side mein hoon—boliue aaj kis occasion ke liye shopping karein?",
                        "Explore Catalogue"
                    )
                }
            }
            else -> {
                // Indian English (en-IN) — Authentic Indian Showroom Salesperson tone
                when (screenKey) {
                    "WELCOME", "HOME" -> Pair(
                        "Namaste $honorific! Welcome to StyleAI Showroom. I am $name, your dedicated AI Sales Stylist. Come this way—I have lined up top Myntra & AJIO deals starting under ₹999 just for you!",
                        "Guide Me to Deals"
                    )
                    "DISCOVER" -> Pair(
                        "Look right here, $honorific! '$prodName' is going for just ₹$prodPrice on $prodRetailer today. Tap it and I'll compare Amazon, Flipkart, Myntra & AJIO prices for you!",
                        "Compare Live Prices"
                    )
                    "TRY_ON" -> Pair(
                        "Step into our AI Trial Room, $honorific! Upload your photo and I will drape '$prodName' on you with exact Indian tailoring proportions.",
                        "Preview On My Photo"
                    )
                    "PRODUCT_DETAIL" -> Pair(
                        "Excellent eye, $honorific! '$prodName' has a very rich finish and $prodRetailer gives you the lowest price at ₹$prodPrice. Let's try it on you right now!",
                        "Try On In Trial Room"
                    )
                    "WARDROBE" -> Pair(
                        "Here is your personal shortlist, $honorific. Whenever you're ready to checkout, I have verified the lowest direct retailer links for each piece!",
                        "Browse More Looks"
                    )
                    else -> Pair(
                        "Always at your service, $honorific! Tell me your budget or occasion and I will personally guide you to the best outfit.",
                        "Ask AI Salesman"
                    )
                }
            }
        }
    }
}

class IndianAiVoiceSalesman(context: Context) {
    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var pendingSpeech: Triple<String, String, String>? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    init {
        try {
            tts = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isInitialized = true
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _isSpeaking.value = true
                        }

                        override fun onDone(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            _isSpeaking.value = false
                        }
                    })
                    pendingSpeech?.let { (text, userGender, preferredLanguage) ->
                        pendingSpeech = null
                        speakSalesPitch(text, userGender, preferredLanguage, isMuted = false)
                    }
                } else {
                    Log.w("IndianAiVoiceSalesman", "TextToSpeech init returned status: $status")
                }
            }
        } catch (e: Exception) {
            Log.w("IndianAiVoiceSalesman", "TextToSpeech unavailable in this environment: ${e.message}")
        }
    }

    /**
     * Speaks the sales pitch using an Indian locale and opposite-gender AI salesperson voice tuning:
     * - For Male user -> Female AI Saleswoman (Ananya): expressive Indian female AI voice (pitch 1.16f, rate 1.04f)
     * - For Female user -> Male AI Salesman (Kabir): warm Indian male AI voice (pitch 0.84f, rate 1.01f)
     */
    fun speakSalesPitch(
        text: String,
        userGender: String,
        preferredLanguage: String,
        isMuted: Boolean
    ) {
        if (isMuted || text.isBlank()) {
            stopSpeaking()
            return
        }
        val cleanText = text
            .replace("₹", "Rupees ")
            .replace("•", ", ")
            .trim()

        if (!isInitialized) {
            pendingSpeech = Triple(cleanText, userGender, preferredLanguage)
            return
        }

        val engine = tts ?: return
        try {
            val targetLocale = LoginPersonaPrefs.resolveTtsLocale(preferredLanguage)
            val langResult = engine.setLanguage(targetLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                engine.setLanguage(Locale("en", "IN"))
            }

            // Opposite-gender salesperson voice selection:
            // User MALE -> Assistant FEMALE (Ananya)
            // User FEMALE -> Assistant MALE (Kabir)
            val wantFemaleAssistant = userGender.uppercase() != "FEMALE"

            try {
                val availableVoices = engine.voices
                if (!availableVoices.isNullOrEmpty()) {
                    val indianVoices = availableVoices.filter {
                        it.locale.country.equals("IN", ignoreCase = true) &&
                            (it.locale.language.equals(targetLocale.language, ignoreCase = true) ||
                                it.locale.language.equals("en", ignoreCase = true))
                    }
                    val genderMatchedVoice = indianVoices.firstOrNull { voice ->
                        val vName = voice.name.lowercase()
                        val features = voice.features?.map { it.lowercase() }.orEmpty()
                        if (wantFemaleAssistant) {
                            vName.contains("female") || vName.contains("ishi") || vName.contains("aditi") ||
                                vName.contains("raveena") || vName.contains("ind-x-end") ||
                                vName.contains("in-x-enc") || features.contains("female")
                        } else {
                            vName.contains("male") || vName.contains("prabhat") || vName.contains("rishi") ||
                                vName.contains("ind-x-ene") || vName.contains("in-x-end") ||
                                features.contains("male")
                        }
                    } ?: indianVoices.firstOrNull()

                    if (genderMatchedVoice != null) {
                        engine.voice = genderMatchedVoice
                    }
                }
            } catch (ignore: Exception) {
                // Keep default Indian locale voice if voice enumeration is restricted
            }

            // Distinct Indian AI Salesperson acoustic tuning ("feel like Indians but originally AI")
            if (wantFemaleAssistant) {
                // Female AI Saleswoman Ananya for Male User
                engine.setPitch(1.16f)
                engine.setSpeechRate(1.04f)
            } else {
                // Male AI Salesman Kabir for Female User
                engine.setPitch(0.84f)
                engine.setSpeechRate(1.01f)
            }

            val utteranceId = "salesman_${System.currentTimeMillis()}"
            _isSpeaking.value = true
            engine.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        } catch (e: Exception) {
            Log.w("IndianAiVoiceSalesman", "Failed to speak TTS pitch: ${e.message}")
            _isSpeaking.value = false
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (ignore: Exception) {
        }
        _isSpeaking.value = false
    }

    fun shutdown() {
        stopSpeaking()
        try {
            tts?.shutdown()
        } catch (ignore: Exception) {
        }
    }
}
