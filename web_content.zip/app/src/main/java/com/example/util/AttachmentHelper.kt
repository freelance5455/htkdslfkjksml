package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.example.data.model.AttachmentType
import com.example.data.model.PendingAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream

object AttachmentHelper {
    private const val MAX_FILE_SIZE_BYTES = 15L * 1024L * 1024L // 15 MB limit

    fun bitmapToPendingAttachment(bitmap: Bitmap, name: String = "camera_capture_${System.currentTimeMillis()}.jpg"): PendingAttachment {
        val scaled = scaleBitmapDown(bitmap, 1280)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
        val bytes = out.toByteArray()
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)

        return PendingAttachment(
            id = UUID.randomUUID().toString(),
            uri = null,
            fileName = name,
            mimeType = "image/jpeg",
            fileSizeBytes = bytes.size.toLong(),
            type = AttachmentType.IMAGE,
            bitmapPreview = scaled,
            base64Data = base64
        )
    }

    suspend fun uriToPendingAttachment(context: Context, uri: Uri): Result<PendingAttachment> = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        var fileName = "attachment"
        var fileSize = 0L

        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: "attachment"
                if (sizeIdx >= 0) fileSize = cursor.getLong(sizeIdx)
            }
        }

        if (fileSize > MAX_FILE_SIZE_BYTES) {
            return@withContext Result.failure(
                IllegalArgumentException("File '$fileName' (${formatFileSize(fileSize)}) exceeds the 15 MB limit.")
            )
        }

        val mimeType = resolver.getType(uri) ?: inferMimeTypeFromExtension(fileName)
        val lowerName = fileName.lowercase(Locale.ROOT)

        // 1. Image handling
        if (mimeType.startsWith("image/")) {
            return@withContext try {
                val rawBytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: return@withContext Result.failure(IllegalArgumentException("Could not read image file."))
                val decoded = BitmapFactory.decodeByteArray(rawBytes, 0, rawBytes.size)
                    ?: return@withContext Result.failure(IllegalArgumentException("Unsupported or corrupted image format."))
                val scaled = scaleBitmapDown(decoded, 1280)
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 82, out)
                val jpegBytes = out.toByteArray()
                val base64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP)

                Result.success(
                    PendingAttachment(
                        id = UUID.randomUUID().toString(),
                        uri = uri,
                        fileName = fileName,
                        mimeType = "image/jpeg",
                        fileSizeBytes = if (fileSize > 0) fileSize else jpegBytes.size.toLong(),
                        type = AttachmentType.IMAGE,
                        bitmapPreview = scaled,
                        base64Data = base64
                    )
                )
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

        // 2. PDF handling (render Page 1 as image preview + extract metadata)
        if (mimeType == "application/pdf" || lowerName.endsWith(".pdf")) {
            return@withContext try {
                var firstPageBitmap: Bitmap? = null
                var pageCount = 0
                resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        pageCount = renderer.pageCount
                        if (pageCount > 0) {
                            renderer.openPage(0).use { page ->
                                val bmp = Bitmap.createBitmap(
                                    page.width.coerceAtLeast(1),
                                    page.height.coerceAtLeast(1),
                                    Bitmap.Config.ARGB_8888
                                )
                                bmp.eraseColor(android.graphics.Color.WHITE)
                                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                firstPageBitmap = scaleBitmapDown(bmp, 1024)
                            }
                        }
                    }
                }
                val base64Page = firstPageBitmap?.let { bmp ->
                    val out = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
                    Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                }

                Result.success(
                    PendingAttachment(
                        id = UUID.randomUUID().toString(),
                        uri = uri,
                        fileName = fileName,
                        mimeType = "image/jpeg", // Send rendered page image for multimodal reading + metadata
                        fileSizeBytes = fileSize,
                        type = if (base64Page != null) AttachmentType.IMAGE else AttachmentType.DOCUMENT,
                        bitmapPreview = firstPageBitmap,
                        base64Data = base64Page,
                        extractedText = "PDF Document: $fileName ($pageCount page(s), ${formatFileSize(fileSize)})."
                    )
                )
            } catch (e: Exception) {
                Result.failure(IllegalArgumentException("Could not parse PDF '$fileName': ${e.localizedMessage}"))
            }
        }

        // 3. DOCX / XLSX (Office OpenXML zip containers)
        if (lowerName.endsWith(".docx") || lowerName.endsWith(".xlsx")) {
            return@withContext try {
                val extractedXmlText = extractTextFromOfficeZip(context, uri)
                if (extractedXmlText.isBlank()) {
                    Result.failure(IllegalArgumentException("No readable text found inside '$fileName'."))
                } else {
                    Result.success(
                        PendingAttachment(
                            id = UUID.randomUUID().toString(),
                            uri = uri,
                            fileName = fileName,
                            mimeType = mimeType,
                            fileSizeBytes = fileSize,
                            type = AttachmentType.DOCUMENT,
                            extractedText = extractedXmlText.take(35000)
                        )
                    )
                }
            } catch (e: Exception) {
                Result.failure(IllegalArgumentException("Failed to read Office file '$fileName': ${e.localizedMessage}"))
            }
        }

        // 4. Plain text, CSV, JSON, XML, Markdown, and Source Code files
        if (isTextOrCodeFile(mimeType, lowerName)) {
            return@withContext try {
                val contentBuilder = StringBuilder()
                resolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                        var line: String?
                        var totalChars = 0
                        while (reader.readLine().also { line = it } != null && totalChars < 35000) {
                            contentBuilder.appendLine(line)
                            totalChars += (line?.length ?: 0) + 1
                        }
                    }
                }
                val isCode = lowerName.endsWith(".kt") || lowerName.endsWith(".java") ||
                    lowerName.endsWith(".py") || lowerName.endsWith(".js") ||
                    lowerName.endsWith(".ts") || lowerName.endsWith(".cpp") ||
                    lowerName.endsWith(".c") || lowerName.endsWith(".html") ||
                    lowerName.endsWith(".css") || lowerName.endsWith(".sql")

                Result.success(
                    PendingAttachment(
                        id = UUID.randomUUID().toString(),
                        uri = uri,
                        fileName = fileName,
                        mimeType = mimeType,
                        fileSizeBytes = fileSize,
                        type = if (isCode) AttachmentType.CODE else AttachmentType.DOCUMENT,
                        extractedText = contentBuilder.toString()
                    )
                )
            } catch (e: Exception) {
                Result.failure(IllegalArgumentException("Could not read text file '$fileName': ${e.localizedMessage}"))
            }
        }

        Result.failure(
            IllegalArgumentException(
                "Unsupported file format for '$fileName' ($mimeType). Supported formats: Images (JPG, PNG, WEBP), PDF, DOCX, XLSX, TXT, CSV, JSON, XML, Markdown, and Code files (.py, .kt, .js, .ts, .java, .cpp, .html, .css, .sql)."
            )
        )
    }

    private fun extractTextFromOfficeZip(context: Context, uri: Uri): String {
        val sb = StringBuilder()
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name
                    if (name == "word/document.xml" || name == "xl/sharedStrings.xml" || name.startsWith("xl/worksheets/sheet")) {
                        val xml = zis.bufferedReader(Charsets.UTF_8).readText()
                        // Strip XML tags and preserve text runs
                        val stripped = xml.replace(Regex("<[^>]+>"), " ")
                            .replace(Regex("\\s+"), " ")
                            .trim()
                        if (stripped.isNotBlank()) {
                            sb.appendLine(stripped)
                        }
                    }
                    entry = zis.nextEntry
                }
            }
        }
        return sb.toString().trim()
    }

    private fun isTextOrCodeFile(mimeType: String, lowerName: String): Boolean {
        if (mimeType.startsWith("text/") ||
            mimeType == "application/json" ||
            mimeType == "application/xml" ||
            mimeType == "application/javascript"
        ) return true

        val supportedExts = listOf(
            ".txt", ".md", ".csv", ".tsv", ".json", ".xml", ".yaml", ".yml",
            ".py", ".js", ".ts", ".tsx", ".jsx", ".kt", ".kts", ".java",
            ".c", ".cpp", ".h", ".hpp", ".html", ".css", ".sql", ".sh", ".gradle", ".log"
        )
        return supportedExts.any { lowerName.endsWith(it) }
    }

    private fun inferMimeTypeFromExtension(fileName: String): String {
        val lower = fileName.lowercase(Locale.ROOT)
        return when {
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "image/jpeg"
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".webp") -> "image/webp"
            lower.endsWith(".pdf") -> "application/pdf"
            lower.endsWith(".json") -> "application/json"
            lower.endsWith(".xml") -> "application/xml"
            lower.endsWith(".csv") -> "text/csv"
            else -> "text/plain"
        }
    }

    private fun scaleBitmapDown(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap
        val ratio = width.toFloat() / height.toFloat()
        val newWidth: Int
        val newHeight: Int
        if (width > height) {
            newWidth = maxDimension
            newHeight = (maxDimension / ratio).toInt().coerceAtLeast(1)
        } else {
            newHeight = maxDimension
            newWidth = (maxDimension * ratio).toInt().coerceAtLeast(1)
        }
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb < 1024.0) {
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            String.format(Locale.US, "%.2f MB", kb / 1024.0)
        }
    }
}
