package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.UUID

data class SelectedAttachment(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val base64Data: String = "",
    val textContent: String? = null,
    val uriString: String? = null,
    val previewBitmap: Bitmap? = null
) {
    val isImage: Boolean
        get() = mimeType.startsWith("image/") || previewBitmap != null

    val isVideo: Boolean
        get() = mimeType.startsWith("video/")

    val isAudio: Boolean
        get() = mimeType.startsWith("audio/")

    val isPdf: Boolean
        get() = mimeType == "application/pdf" || name.endsWith(".pdf", ignoreCase = true)

    val isTextLike: Boolean
        get() = textContent != null ||
            mimeType.startsWith("text/") ||
            mimeType.contains("json") ||
            mimeType.contains("javascript") ||
            mimeType.contains("xml") ||
            name.substringAfterLast('.', "").lowercase() in setOf(
                "txt", "md", "log", "csv", "json", "js", "ts", "kt", "java", "py", "css", "html", "xml", "yml", "yaml", "ini", "cfg", "mcfunction"
            )

    val badgeEmoji: String
        get() = when {
            isImage -> "🖼️"
            isVideo -> "🎥"
            isAudio -> "🎵"
            isPdf -> "📄"
            isTextLike -> "📝"
            else -> "📎"
        }
}

object AttachmentHelper {
    private const val MAX_FILE_SIZE = 25L * 1024L * 1024L // 25 MB

    suspend fun readUriAsAttachment(context: Context, uri: Uri): Result<SelectedAttachment> =
        withContext(Dispatchers.IO) {
            try {
                val resolver = context.contentResolver
                var fileName = "Dosya_${System.currentTimeMillis()}"
                var fileSize = 0L

                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (nameIdx >= 0) {
                            cursor.getString(nameIdx)?.let { fileName = it }
                        }
                        if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                            fileSize = cursor.getLong(sizeIdx)
                        }
                    }
                }

                if (fileSize > MAX_FILE_SIZE) {
                    return@withContext Result.failure(
                        IllegalArgumentException("Bu dosya çok büyük (Maks 25MB): $fileName")
                    )
                }

                val rawMime = resolver.getType(uri) ?: guessMimeType(fileName)
                val bytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: return@withContext Result.failure(IllegalStateException("Dosya okunamadı: $fileName"))

                if (bytes.size > MAX_FILE_SIZE) {
                    return@withContext Result.failure(
                        IllegalArgumentException("Bu dosya çok büyük (Maks 25MB): $fileName")
                    )
                }

                val actualSize = if (fileSize > 0) fileSize else bytes.size.toLong()

                if (rawMime.startsWith("image/")) {
                    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    val scaled = decoded?.let { scaleBitmapIfNeeded(it, 1280) }
                    val jpegBase64 = scaled?.let { bitmapToBase64(it, 82) }
                        ?: Base64.encodeToString(bytes, Base64.NO_WRAP)
                    Result.success(
                        SelectedAttachment(
                            name = fileName,
                            mimeType = "image/jpeg",
                            sizeBytes = actualSize,
                            base64Data = jpegBase64,
                            uriString = uri.toString(),
                            previewBitmap = scaled
                        )
                    )
                } else {
                    val ext = fileName.substringAfterLast('.', "").lowercase()
                    val isText = rawMime.startsWith("text/") ||
                        rawMime.contains("json") ||
                        rawMime.contains("javascript") ||
                        rawMime.contains("xml") ||
                        ext in setOf(
                            "txt", "md", "log", "csv", "json", "js", "ts", "kt", "java",
                            "py", "css", "html", "xml", "yml", "yaml", "ini", "cfg", "mcfunction"
                        )
                    val extractedText = if (isText) {
                        runCatching { bytes.toString(Charsets.UTF_8).take(120_000) }.getOrNull()
                    } else null

                    val base64 = if (rawMime == "application/pdf" || bytes.size <= 8 * 1024 * 1024) {
                        Base64.encodeToString(bytes, Base64.NO_WRAP)
                    } else ""

                    Result.success(
                        SelectedAttachment(
                            name = fileName,
                            mimeType = rawMime,
                            sizeBytes = actualSize,
                            base64Data = base64,
                            textContent = extractedText,
                            uriString = uri.toString()
                        )
                    )
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun fromBitmap(bitmap: Bitmap, namePrefix: String = "Kamera"): SelectedAttachment {
        val scaled = scaleBitmapIfNeeded(bitmap, 1280)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
        val bytes = out.toByteArray()
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        return SelectedAttachment(
            name = "${namePrefix}_${System.currentTimeMillis() % 100000}.jpg",
            mimeType = "image/jpeg",
            sizeBytes = bytes.size.toLong(),
            base64Data = base64,
            previewBitmap = scaled
        )
    }

    fun bitmapToBase64(bitmap: Bitmap, quality: Int = 82): String {
        val scaled = scaleBitmapIfNeeded(bitmap, 1024)
        val outputStream = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, quality, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap
        val ratio = width.toFloat() / height.toFloat()
        val (newW, newH) = if (width >= height) {
            maxDimension to (maxDimension / ratio).toInt().coerceAtLeast(1)
        } else {
            (maxDimension * ratio).toInt().coerceAtLeast(1) to maxDimension
        }
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private fun guessMimeType(fileName: String): String {
        return when (fileName.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "pdf" -> "application/pdf"
            "mp4", "mkv", "webm" -> "video/mp4"
            "mp3", "wav", "ogg", "m4a" -> "audio/mpeg"
            "json" -> "application/json"
            "txt", "md", "log", "csv", "kt", "py", "js", "html", "css", "xml" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    fun serializeAttachmentMetadata(attachments: List<SelectedAttachment>): String {
        if (attachments.isEmpty()) return ""
        val arr = JSONArray()
        for (item in attachments) {
            val obj = JSONObject()
            obj.put("name", item.name)
            obj.put("mimeType", item.mimeType)
            obj.put("badge", item.badgeEmoji)
            obj.put("sizeBytes", item.sizeBytes)
            arr.put(obj)
        }
        return arr.toString()
    }

    fun parseAttachmentBadges(json: String): List<Pair<String, String>> {
        if (json.isBlank()) return emptyList()
        return runCatching {
            val arr = JSONArray(json)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val badge = obj.optString("badge", "📎")
                    val name = obj.optString("name", "Dosya")
                    add(badge to name)
                }
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Generates a rich visual canvas for testing Camera/Photo/Screen vision in environments
     * where physical camera feed is blank (e.g., cloud emulator) or when simulating game scenes.
     */
    fun generateInteractiveSceneBitmap(sceneType: Int): Bitmap {
        val width = 800
        val height = 500
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        when (sceneType % 3) {
            0 -> {
                // Minecraft Bedrock @Suesa_S bot HUD scene
                paint.shader = LinearGradient(
                    0f, 0f, 0f, height.toFloat(),
                    Color.parseColor("#3B82F6"), Color.parseColor("#1E3A8A"),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, width.toFloat(), height * 0.58f, paint)
                paint.shader = null

                // Grass & terrain blocks
                paint.color = Color.parseColor("#16A34A")
                canvas.drawRect(0f, height * 0.58f, width.toFloat(), height * 0.68f, paint)
                paint.color = Color.parseColor("#78350F")
                canvas.drawRect(0f, height * 0.68f, width.toFloat(), height.toFloat(), paint)

                // Oak tree blocks
                paint.color = Color.parseColor("#92400E")
                canvas.drawRect(560f, 190f, 610f, 300f, paint)
                paint.color = Color.parseColor("#15803D")
                canvas.drawRoundRect(RectF(495f, 110f, 675f, 210f), 12f, 12f, paint)

                // Bot character @Suesa_S
                paint.color = Color.parseColor("#7B3FF2")
                canvas.drawRoundRect(RectF(230f, 185f, 300f, 255f), 8f, 8f, paint)
                paint.color = Color.parseColor("#2563EB")
                canvas.drawRect(238f, 255f, 292f, 325f, paint)

                // Nametag above bot
                paint.color = Color.argb(180, 0, 0, 0)
                canvas.drawRoundRect(RectF(175f, 142f, 355f, 174f), 8f, 8f, paint)
                paint.color = Color.WHITE
                paint.textSize = 20f
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                canvas.drawText("@Suesa_S [Bot]", 195f, 165f, paint)

                // HUD Coordinates & Hotbar
                paint.color = Color.argb(170, 17, 17, 17)
                canvas.drawRoundRect(RectF(20f, 20f, 330f, 92f), 10f, 10f, paint)
                paint.color = Color.WHITE
                paint.textSize = 18f
                canvas.drawText("Konum: 142, 68, -309", 36f, 50f, paint)
                paint.color = Color.parseColor("#FBBF24")
                canvas.drawText("Can: 20/20 | Envanter: 32 Odun, 14 Elmas", 36f, 76f, paint)
            }
            1 -> {
                // Code / Terminal / Debug Screen Scene
                paint.color = Color.parseColor("#0F172A")
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)

                paint.color = Color.parseColor("#1E293B")
                canvas.drawRoundRect(RectF(28f, 28f, width - 28f, height - 28f), 18f, 18f, paint)

                paint.color = Color.parseColor("#38BDF8")
                paint.textSize = 22f
                paint.typeface = Typeface.MONOSPACE
                canvas.drawText("fun connectSuesaBridge(host: String) {", 56f, 90f, paint)
                paint.color = Color.parseColor("#F472B6")
                canvas.drawText("  val status = pingServer(\"mc.suesa.ai:19132\")", 56f, 130f, paint)
                paint.color = Color.parseColor("#A7F3D0")
                canvas.drawText("  // Hata: Satır 42 - NullPointerException!", 56f, 170f, paint)
                paint.color = Color.parseColor("#FBBF24")
                canvas.drawText("  println(\"Bot durumu: \" + status.botHealth)", 56f, 210f, paint)
                paint.color = Color.parseColor("#38BDF8")
                canvas.drawText("}", 56f, 250f, paint)

                paint.color = Color.parseColor("#EF4444")
                canvas.drawRoundRect(RectF(56f, 300f, width - 56f, 410f), 12f, 12f, paint)
                paint.color = Color.WHITE
                paint.textSize = 19f
                canvas.drawText("Konsol Çıktısı: Bağlantı zaman aşımı (Timeout 5000ms)", 78f, 348f, paint)
                canvas.drawText("Suesa AI Ekran Analizi için hazır.", 78f, 382f, paint)
            }
            else -> {
                // Desk / Hardware / Study Notes Scene
                paint.shader = LinearGradient(
                    0f, 0f, width.toFloat(), height.toFloat(),
                    Color.parseColor("#1E1B4B"), Color.parseColor("#311042"),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
                paint.shader = null

                paint.color = Color.parseColor("#FEF3C7")
                canvas.drawRoundRect(RectF(80f, 55f, width - 80f, height - 55f), 20f, 20f, paint)

                paint.color = Color.parseColor("#1F2937")
                paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                paint.textSize = 26f
                canvas.drawText("Günlük Görev Listesi & Notlar", 120f, 115f, paint)

                paint.typeface = Typeface.DEFAULT
                paint.textSize = 21f
                canvas.drawText("1. Minecraft sunucusunda otomatik odun farmı kur", 120f, 170f, paint)
                canvas.drawText("2. Suesa AI yüzen panel ile ekranı test et", 120f, 215f, paint)
                canvas.drawText("3. Matematik ödevi: 3x + 15 = 42 denklemini çöz", 120f, 260f, paint)
                canvas.drawText("4. Akşam saat 21:00'de ekip toplantısı", 120f, 305f, paint)
            }
        }
        return bmp
    }
}
