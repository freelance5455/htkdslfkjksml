package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PreparedAttachment(
    val localPath: String?,
    val previewImagePath: String?,
    val displayName: String,
    val mimeType: String,
    val attachmentType: String, // "IMAGE", "PDF", "TEXT"
    val fileSizeLabel: String,
    val extractedText: String? = null
)

object AttachmentHelper {
    private const val MAX_BINARY_SIZE_BYTES = 15L * 1024L * 1024L // 15 MB
    private const val MAX_TEXT_SIZE_BYTES = 512L * 1024L // 512 KB

    private val SUPPORTED_TEXT_EXTENSIONS = setOf(
        "txt", "md", "markdown", "json", "csv", "xml", "html", "htm", "css",
        "kt", "kts", "java", "py", "js", "ts", "tsx", "jsx", "c", "cpp", "h",
        "cs", "go", "rs", "rb", "php", "sh", "yaml", "yml", "toml", "sql", "gradle", "log"
    )

    suspend fun processUri(context: Context, uri: Uri): Result<PreparedAttachment> =
        withContext(Dispatchers.IO) {
            try {
                val contentResolver = context.contentResolver
                var fileName = "attachment"
                var fileSize = -1L

                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (nameIdx != -1) {
                            fileName = cursor.getString(nameIdx) ?: "attachment"
                        }
                        if (sizeIdx != -1 && !cursor.isNull(sizeIdx)) {
                            fileSize = cursor.getLong(sizeIdx)
                        }
                    }
                }

                val rawMime = contentResolver.getType(uri) ?: guessMimeFromName(fileName)
                val extension = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)

                val attachmentsDir = File(context.filesDir, "attachments").apply {
                    if (!exists()) mkdirs()
                }

                when {
                    rawMime.startsWith("image/") || extension in setOf("jpg", "jpeg", "png", "webp") -> {
                        if (fileSize > MAX_BINARY_SIZE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("Image exceeds the 15 MB maximum limit (${formatSize(fileSize)}).")
                            )
                        }
                        processImageAttachment(context, uri, fileName, attachmentsDir)
                    }

                    rawMime == "application/pdf" || extension == "pdf" -> {
                        if (fileSize > MAX_BINARY_SIZE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("PDF file exceeds the 15 MB maximum limit (${formatSize(fileSize)}).")
                            )
                        }
                        processPdfAttachment(context, uri, fileName, fileSize, attachmentsDir)
                    }

                    rawMime.startsWith("text/") ||
                        rawMime == "application/json" ||
                        rawMime == "application/xml" ||
                        rawMime == "application/javascript" ||
                        extension in SUPPORTED_TEXT_EXTENSIONS -> {
                        if (fileSize > MAX_TEXT_SIZE_BYTES) {
                            return@withContext Result.failure(
                                IllegalArgumentException("Text/code file exceeds the 500 KB limit (${formatSize(fileSize)}).")
                            )
                        }
                        processTextAttachment(context, uri, fileName, rawMime, fileSize)
                    }

                    else -> {
                        Result.failure(
                            IllegalArgumentException(
                                "Unsupported file format ($fileName). Supported formats: Images (PNG, JPG, WEBP), PDF documents, and Text/Code files (.txt, .md, .py, .kt, .js, .json, .csv, etc.)."
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                Result.failure(
                    IllegalStateException("Could not read attachment: ${e.message ?: "Unknown file error"}")
                )
            }
        }

    private fun processImageAttachment(
        context: Context,
        uri: Uri,
        fileName: String,
        attachmentsDir: File
    ): Result<PreparedAttachment> {
        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, boundsOptions)
        }

        val maxDim = 1280
        var sampleSize = 1
        while (boundsOptions.outWidth / sampleSize > maxDim || boundsOptions.outHeight / sampleSize > maxDim) {
            sampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        val decoded = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: return Result.failure(IllegalArgumentException("Unable to decode the selected image."))

        val scaled = scaleBitmapDown(decoded, maxDim)
        val outFile = File(attachmentsDir, "img_${UUID.randomUUID()}.jpg")
        FileOutputStream(outFile).use { fos ->
            scaled.compress(Bitmap.CompressFormat.JPEG, 85, fos)
        }

        return Result.success(
            PreparedAttachment(
                localPath = outFile.absolutePath,
                previewImagePath = outFile.absolutePath,
                displayName = fileName,
                mimeType = "image/jpeg",
                attachmentType = "IMAGE",
                fileSizeLabel = "${scaled.width}×${scaled.height} • ${formatSize(outFile.length())}"
            )
        )
    }

    private fun processPdfAttachment(
        context: Context,
        uri: Uri,
        fileName: String,
        fileSize: Long,
        attachmentsDir: File
    ): Result<PreparedAttachment> {
        val pdfFile = File(attachmentsDir, "doc_${UUID.randomUUID()}.pdf")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(pdfFile).use { output ->
                input.copyTo(output)
            }
        } ?: return Result.failure(IllegalArgumentException("Could not read PDF file stream."))

        if (pdfFile.length() > MAX_BINARY_SIZE_BYTES) {
            pdfFile.delete()
            return Result.failure(IllegalArgumentException("PDF file is larger than 15 MB."))
        }

        // Render first page preview thumbnail and get page count
        var pageCount = 1
        var previewPath: String? = null
        try {
            ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)?.use { pfd ->
                PdfRenderer(pfd).use { renderer ->
                    pageCount = renderer.pageCount
                    if (pageCount > 0) {
                        renderer.openPage(0).use { page ->
                            val width = 600
                            val height = (width.toFloat() / page.width.coerceAtLeast(1) * page.height).toInt().coerceAtLeast(400)
                            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            bitmap.eraseColor(android.graphics.Color.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            val previewFile = File(attachmentsDir, "pdf_prev_${UUID.randomUUID()}.jpg")
                            FileOutputStream(previewFile).use { fos ->
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 82, fos)
                            }
                            previewPath = previewFile.absolutePath
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Non-fatal if PDF preview image rendering fails
        }

        val actualSize = if (fileSize > 0) fileSize else pdfFile.length()
        return Result.success(
            PreparedAttachment(
                localPath = pdfFile.absolutePath,
                previewImagePath = previewPath,
                displayName = fileName,
                mimeType = "application/pdf",
                attachmentType = "PDF",
                fileSizeLabel = "PDF • $pageCount page${if (pageCount == 1) "" else "s"} • ${formatSize(actualSize)}"
            )
        )
    }

    private fun processTextAttachment(
        context: Context,
        uri: Uri,
        fileName: String,
        mimeType: String,
        fileSize: Long
    ): Result<PreparedAttachment> {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: return Result.failure(IllegalArgumentException("Unable to read text/code file."))

        if (bytes.size > MAX_TEXT_SIZE_BYTES) {
            return Result.failure(
                IllegalArgumentException("File exceeds 500 KB maximum size for text/code files.")
            )
        }

        val textContent = bytes.toString(Charsets.UTF_8).take(120_000)
        if (textContent.isBlank()) {
            return Result.failure(IllegalArgumentException("The selected file ($fileName) is empty."))
        }

        val lineCount = textContent.lines().size
        val sizeBytes = if (fileSize > 0) fileSize else bytes.size.toLong()
        return Result.success(
            PreparedAttachment(
                localPath = null,
                previewImagePath = null,
                displayName = fileName,
                mimeType = mimeType,
                attachmentType = "TEXT",
                fileSizeLabel = "$lineCount lines • ${formatSize(sizeBytes)}",
                extractedText = textContent
            )
        )
    }

    private fun scaleBitmapDown(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap
        val ratio = width.toFloat() / height.toFloat()
        val (newW, newH) = if (ratio > 1f) {
            maxDimension to (maxDimension / ratio).toInt().coerceAtLeast(1)
        } else {
            (maxDimension * ratio).toInt().coerceAtLeast(1) to maxDimension
        }
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private fun guessMimeFromName(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "pdf" -> "application/pdf"
            "json" -> "application/json"
            "xml" -> "application/xml"
            else -> "text/plain"
        }
    }

    fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb < 1024.0) {
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            String.format(Locale.US, "%.2f MB", kb / 1024.0)
        }
    }
}
