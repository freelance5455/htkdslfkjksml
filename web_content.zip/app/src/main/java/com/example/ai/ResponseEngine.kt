package com.example.ai

import com.example.data.api.ChatInputMessage
import com.example.data.api.GeminiApiClient

data class SuesaResponse(
    val text: String,
    val sourceTitle: String? = null,
    val sourceUrl: String? = null,
    val isAction: Boolean = false,
    val actionType: String? = null
)

/**
 * Yanıt Üretim Motoru (ResponseEngine).
 * ConversationEngine, WebSearchEngine ve (varsa) Gemini API sağlayıcısını koordine eder.
 * Kullanıcıya her zaman gerçek, bağlamsal ve doğal Türkçe cevap verir.
 * Asla tekrar eden "API anahtarı girin" fallback metni döndürmez!
 */
class ResponseEngine(
    private val conversationEngine: ConversationEngine,
    private val apiClient: GeminiApiClient = GeminiApiClient()
) {

    suspend fun generate(
        prompt: String,
        contextMessages: List<ChatInputMessage>,
        apiKey: String,
        webSearchResult: WebSearchResult? = null,
        imageBase64: String? = null,
        imageMimeType: String? = null
    ): SuesaResponse {
        // 1. Web arama sonucu varsa
        if (webSearchResult != null) {
            if (webSearchResult.isSuccess && webSearchResult.summary.isNotBlank()) {
                val fullText = buildString {
                    append(webSearchResult.summary)
                    if (!webSearchResult.sourceTitle.isNullOrBlank()) {
                        append("\n\n📍 *Kaynak: ${webSearchResult.sourceTitle}*")
                    }
                }
                return SuesaResponse(
                    text = fullText,
                    sourceTitle = webSearchResult.sourceTitle,
                    sourceUrl = webSearchResult.sourceUrl
                )
            } else {
                return SuesaResponse(
                    text = webSearchResult.summary,
                    sourceTitle = webSearchResult.sourceTitle
                )
            }
        }

        // 2. Eğer geçerli bir Gemini API anahtarı ayarlanmışsa gelişmiş modeli kullan
        if (apiKey.isNotBlank()) {
            val enrichedMessages = contextMessages.toMutableList()
            enrichedMessages.add(
                ChatInputMessage(
                    role = "user",
                    text = prompt,
                    imageBase64 = imageBase64,
                    imageMimeType = imageMimeType
                )
            )

            val apiResult = apiClient.generateChatResponse(enrichedMessages, apiKey)
            if (apiResult.isSuccess) {
                return SuesaResponse(text = apiResult.getOrThrow())
            }
            // API hatası olursa çökmek yerine yerel sohbet motoruna sorunsuz devret
        }

        // 3. Yerel Sohbet Motoru ile gerçek ve bağlamsal Türkçe cevap üret
        val localText = conversationEngine.generateResponse(prompt)
        return SuesaResponse(text = localText)
    }
}
