package com.example.ai

import android.graphics.Bitmap
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONArray

data class ChatTurn(
    val role: String,
    val text: String
)

class IchimatsuAiRepository {

    private val model by lazy {
        Firebase.ai(backend = GenerativeBackend.googleAI())
            .generativeModel(
                modelName = "gemini-3.8-flash",
                generationConfig = generationConfig {
                    temperature = 0.85f
                }
            )
    }

    fun parseMessagesJson(messagesJson: String): List<ChatTurn> {
        val array = JSONArray(messagesJson)
        val rawTurns = ArrayList<ChatTurn>(array.length())
        for (i in 0 until array.length()) {
            val obj = array.optJSONObject(i) ?: continue
            val role = when (obj.optString("role", "user").lowercase()) {
                "assistant", "model" -> "model"
                else -> "user"
            }
            val text = obj.optString("content", "")
            if (text.isNotBlank()) {
                rawTurns.add(ChatTurn(role = role, text = text))
            }
        }

        // Merge consecutive turns of the same role to guarantee alternating user/model content
        val normalized = mutableListOf<ChatTurn>()
        for (turn in rawTurns) {
            if (normalized.isEmpty()) {
                if (turn.role == "user") {
                    normalized.add(turn)
                }
            } else if (normalized.last().role == turn.role) {
                val prev = normalized.removeAt(normalized.lastIndex)
                normalized.add(prev.copy(text = "${prev.text}\n${turn.text}"))
            } else {
                normalized.add(turn)
            }
        }
        return normalized
    }

    fun streamReply(turns: List<ChatTurn>, imageBitmap: Bitmap?): Flow<String> = flow {
        val lastUserIdx = turns.indexOfLast { it.role == "user" }
        val contents: List<Content> = turns.mapIndexed { index, turn ->
            content(role = turn.role) {
                text(turn.text)
                if (index == lastUserIdx && imageBitmap != null) {
                    image(imageBitmap)
                }
            }
        }

        val accumulated = StringBuilder()
        withTimeout(60_000L) {
            model.generateContentStream(contents).collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    accumulated.append(chunkText)
                    emit(accumulated.toString())
                }
            }
        }
    }
}
