package com.example.ai

import com.example.data.api.ChatInputMessage
import com.example.data.local.ChatMessage

/**
 * Suesa AI Konuşma Hafızası (Conversation Memory).
 * Konuşmanın akışını ve bağlamını korur.
 */
class ConversationMemory {

    private val recentMessages = mutableListOf<ChatInputMessage>()

    fun addTurn(role: String, text: String, imageBase64: String? = null) {
        recentMessages.add(ChatInputMessage(role = role, text = text, imageBase64 = imageBase64))
        // Hafızada son 10 mesajı tutarak bağlamı koru
        if (recentMessages.size > 10) {
            recentMessages.removeAt(0)
        }
    }

    fun loadFromDatabase(messages: List<ChatMessage>) {
        recentMessages.clear()
        val tail = if (messages.size > 10) messages.takeLast(10) else messages
        for (m in tail) {
            recentMessages.add(
                ChatInputMessage(
                    role = if (m.role == "user") "user" else "model",
                    text = m.content
                )
            )
        }
    }

    fun getContextMessages(): List<ChatInputMessage> {
        return recentMessages.toList()
    }

    fun clear() {
        recentMessages.clear()
    }
}
