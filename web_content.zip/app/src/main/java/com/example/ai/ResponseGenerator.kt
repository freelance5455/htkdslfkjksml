package com.example.ai

import com.example.data.api.ChatInputMessage
import com.example.data.api.GeminiApiClient

data class GeneratedAnswer(
    val text: String,
    val sourceTitle: String? = null,
    val sourceUrl: String? = null,
    val isAction: Boolean = false,
    val actionType: String? = null
)

/**
 * Yanıt Üretici (Response Generator).
 * Yerel Bilgi, Web Araması sonuçları ve (varsa) Gemini API'yi sentezleyerek
 * doğal, samimi ve doğru Türkçe yanıt üretir.
 */
class ResponseGenerator(
    private val apiClient: GeminiApiClient
) {

    suspend fun generate(
        prompt: String,
        contextMessages: List<ChatInputMessage>,
        apiKey: String,
        webSearchResult: SearchResult? = null,
        imageBase64: String? = null,
        imageMimeType: String? = null
    ): GeneratedAnswer {
        // Eğer bir web arama sonucu varsa ve API anahtarı girilmemişse, web aramasını özet yanıt olarak dön
        if (webSearchResult != null && webSearchResult.isFound && apiKey.isBlank()) {
            val responseText = buildString {
                append(webSearchResult.summary)
                if (!webSearchResult.sourceTitle.isNullOrBlank()) {
                    append("\n\n📍 *Kaynak: ${webSearchResult.sourceTitle}*")
                }
            }
            return GeneratedAnswer(
                text = responseText,
                sourceTitle = webSearchResult.sourceTitle,
                sourceUrl = webSearchResult.sourceUrl
            )
        }

        // Eğer geçerli bir API anahtarı varsa Gemini 3.5 Flash ile zenginleştir
        if (apiKey.isNotBlank()) {
            val enrichedMessages = contextMessages.toMutableList()

            // Eğer web arama sonucu varsa bağlama sistem bilgisi olarak ekle
            if (webSearchResult != null && webSearchResult.isFound) {
                val searchSnippet = """
                    [Web Arama Sonucu]
                    Sorgu: ${webSearchResult.query}
                    Kaynak: ${webSearchResult.sourceTitle}
                    İçerik: ${webSearchResult.summary}
                    Lütfen bu güncel web bilgisini dikkate alarak kullanıcıya doğal, akıcı Türkçe ile cevap ver.
                """.trimIndent()
                enrichedMessages.add(
                    ChatInputMessage(
                        role = "user",
                        text = "$searchSnippet\n\nKullanıcı Sorusu: $prompt",
                        imageBase64 = imageBase64,
                        imageMimeType = imageMimeType
                    )
                )
            } else {
                enrichedMessages.add(
                    ChatInputMessage(
                        role = "user",
                        text = prompt,
                        imageBase64 = imageBase64,
                        imageMimeType = imageMimeType
                    )
                )
            }

            val apiResult = apiClient.generateChatResponse(enrichedMessages, apiKey)
            if (apiResult.isSuccess) {
                return GeneratedAnswer(
                    text = apiResult.getOrThrow(),
                    sourceTitle = webSearchResult?.sourceTitle,
                    sourceUrl = webSearchResult?.sourceUrl
                )
            }
        }

        // API anahtarı yoksa veya hata oluştuysa yerel bilgi tabanını kontrol et
        val local = LocalKnowledge.findAnswer(prompt)
        if (local != null) {
            return GeneratedAnswer(text = local)
        }

        // Web araması yapıldıysa ancak sonuç bulunamadıysa
        if (webSearchResult != null && !webSearchResult.isFound) {
            return GeneratedAnswer(
                text = "Bu konuda internette kesin ve güvenilir bir bilgiye ulaşamadım. Daha detaylı ya da farklı kelimelerle sormak ister misin?",
                sourceTitle = "Arama Motoru"
            )
        }

        // Genel offline yanıt
        return GeneratedAnswer(
            text = "Sorunu anladım. Daha kapsamlı ve derin yanıtlar alabilmek için Ayarlar menüsünden ücretsiz Gemini API anahtarını ekleyebilir veya internet bağlantını kontrol edebilirsin. Ayrıca bana 'YouTube'u aç', 'Ahmet'i ara' veya 'Wi-Fi ayarlarını aç' gibi telefon komutları da verebilirsin!"
        )
    }
}
