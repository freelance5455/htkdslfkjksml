package com.example.ai

import java.util.Locale

sealed class AppIntent {
    data class OpenApp(val appType: AppType, val parameter: String? = null) : AppIntent()
    data class CallContact(val targetNameOrNumber: String) : AppIntent()
    data class OpenSetting(val settingType: SettingType) : AppIntent()
    data class WebSearch(val query: String) : AppIntent()
    data class Conversational(val text: String) : AppIntent()
}

/**
 * Niyet Algılama Motoru (IntentEngine).
 * Kullanıcının Türkçe komutlarını analiz ederek telefon sistem eylemlerini,
 * web aramalarını ve sohbet niyetlerini ayrıştırır.
 */
class IntentEngine {

    fun parse(text: String, hasAttachedImage: Boolean = false): AppIntent {
        val q = text.lowercase(Locale.forLanguageTag("tr-TR")).trim()
        val trimmed = text.trim()

        if (hasAttachedImage) {
            return AppIntent.Conversational(text)
        }

        // 1. Telefon Arama Komutları: "Ahmet'i ara", "0532... ara", "Annemi ara"
        val callRegex = Regex(
            "(?:rehberden\\s+)?([a-zA-ZçğıöşüÇĞİÖŞÜ0-9\\+\\s]{2,})['’]?(?:i|ı|u|ü|yi|yı|yu|yü|'i|'ı)?\\s+(?:ara|telefon et|çağrı yap)$",
            RegexOption.IGNORE_CASE
        )
        val callMatch = callRegex.find(trimmed)
        if (callMatch != null) {
            val contact = callMatch.groupValues[1].trim()
            if (contact.isNotBlank() && !contact.equals("beni", ignoreCase = true) &&
                !contact.equals("internette", ignoreCase = true) && !contact.contains("google", ignoreCase = true)) {
                return AppIntent.CallContact(contact)
            }
        }
        if (q.startsWith("ara ") && trimmed.length > 4) {
            val contact = trimmed.substring(4).trim()
            if (!contact.contains("internet", ignoreCase = true) && !contact.contains("google", ignoreCase = true)) {
                return AppIntent.CallContact(contact)
            }
        }

        // 2. Google Komutları: "Google'ı aç", "Google aç", "Google başlat"
        if (q.contains("google") && (q.contains("aç") || q.contains("ac") || q.contains("başlat") || q.contains("baslat") || q.contains("gir"))) {
            return AppIntent.OpenApp(AppType.GOOGLE, "Google")
        }

        // 3. YouTube komutları: "YouTube'u aç", "Youtube aç", "Youtube başlat"
        if (q.contains("youtube") && (q.contains("aç") || q.contains("ac") || q.contains("başlat") || q.contains("baslat") || q.contains("izle"))) {
            return AppIntent.OpenApp(AppType.YOUTUBE, "YouTube")
        }

        // 4. Chrome komutları: "Chrome'u aç", "Chrome aç"
        if (q.contains("chrome") && (q.contains("aç") || q.contains("ac") || q.contains("başlat"))) {
            return AppIntent.OpenApp(AppType.CHROME, "Chrome")
        }

        // 5. WhatsApp komutları: "WhatsApp'ı aç", "Whatsapp aç"
        if (q.contains("whatsapp") && (q.contains("aç") || q.contains("ac") || q.contains("başlat"))) {
            return AppIntent.OpenApp(AppType.WHATSAPP, "WhatsApp")
        }

        // 6. Kamera komutları: "Kamerayı aç", "Kamera aç", "Fotoğraf çek", "Kamerayı başlat"
        if ((q.contains("kamera") || q.contains("fotoğraf")) && (q.contains("aç") || q.contains("ac") || q.contains("çek") || q.contains("başlat"))) {
            return AppIntent.OpenApp(AppType.CAMERA, "Kamera")
        }

        // 7. Galeri: "Galeri aç", "Galeriyi aç", "Fotoğrafları aç"
        if (q.contains("galeri") || q.contains("fotoğraflar") || q.contains("resimler")) {
            if (q.contains("aç") || q.contains("ac") || q.contains("göster") || q.contains("başlat")) {
                return AppIntent.OpenApp(AppType.GALLERY, "Galeri")
            }
        }

        // 8. Mesajlar: "Mesajları aç", "SMS aç", "Mesaj yaz"
        if ((q.contains("mesaj") || q.contains("sms")) && (q.contains("aç") || q.contains("ac") || q.contains("gönder") || q.contains("yaz"))) {
            return AppIntent.OpenApp(AppType.MESSAGES, "Mesajlar")
        }

        // 9. Telefon / Arama Ekranı: "Telefonu aç", "Arama ekranını aç"
        if ((q.contains("telefon") || q.contains("arama ekran")) && (q.contains("aç") || q.contains("ac") || q.contains("başlat"))) {
            return AppIntent.OpenApp(AppType.DIALER, "Telefon")
        }

        // 10. Alarm / Saat: "Alarm kur", "Saati aç", "Alarm aç"
        if (q.contains("alarm") || (q.contains("saat") && (q.contains("aç") || q.contains("ac")))) {
            return AppIntent.OpenApp(AppType.CLOCK_ALARM, "Saat")
        }

        // 11. Hesap Makinesi: "Hesap makinesini aç", "Hesap makinesi aç"
        if (q.contains("hesap makine") && (q.contains("aç") || q.contains("ac"))) {
            return AppIntent.OpenApp(AppType.CALCULATOR, "Hesap Makinesi")
        }

        // 12. Sistem Ayarları: "Wi-Fi aç", "Bluetooth aç", "Ayarları aç"
        if (q.contains("wi-fi") || q.contains("wifi") || q.contains("kablosuz ağ")) {
            if (q.contains("ayar") || q.contains("aç") || q.contains("git")) {
                return AppIntent.OpenSetting(SettingType.WIFI)
            }
        }
        if (q.contains("bluetooth")) {
            if (q.contains("ayar") || q.contains("aç") || q.contains("git")) {
                return AppIntent.OpenSetting(SettingType.BLUETOOTH)
            }
        }
        if (q.contains("ayar") && (q.contains("aç") || q.contains("git") || q.contains("göster"))) {
            return AppIntent.OpenSetting(SettingType.GENERAL)
        }

        // 13. Genel uygulama açma kalıpları: "[Uygulama Adı] uygulamasını aç" / "[Uygulama Adı] aç"
        val genericAppRegex = Regex("^([a-zA-ZçğıöşüÇĞİÖŞÜ0-9\\+\\s]+?)(?:'i|'ı|'u|'ü|i|ı|u|ü)?\\s+(?:uygulamasını\\s+)?(?:aç|ac|başlat)$", RegexOption.IGNORE_CASE)
        val genericMatch = genericAppRegex.find(trimmed)
        if (genericMatch != null) {
            val appName = genericMatch.groupValues[1].trim()
            if (appName.isNotBlank() && appName.length > 2 && !appName.equals("kapıyı", ignoreCase = true) && !appName.equals("pencereyi", ignoreCase = true)) {
                return AppIntent.OpenApp(AppType.CUSTOM, appName)
            }
        }

        // 14. Canlı Web Araması Gerektiren Sorular
        if (isWebSearchQuery(q)) {
            return AppIntent.WebSearch(trimmed)
        }

        // 15. Normal Sohbet / Bilgi Sorgusu
        return AppIntent.Conversational(trimmed)
    }

    private fun isWebSearchQuery(q: String): Boolean {
        if (q.contains("hava durumu") || q.contains("hava nasıl") || q.contains("kaç derece")) return true
        if (q.contains("bitcoin") || q.contains("btc") || q.contains("ethereum") || q.contains("kripto")) return true
        if (q.contains("dolar") || q.contains("euro") || q.contains("altın fiyatı") || q.contains("borsa")) return true
        if (q.contains("haberler") || q.contains("haber var") || q.contains("son dakika") || q.contains("gündem")) return true
        if (q.contains("internette ara") || q.contains("google'da ara") || q.contains("web'de ara") || q.contains("internette ne yazıyor")) return true
        if (q.contains("en son sürüm") && !q.contains("minecraft")) return true
        return false
    }
}
