package com.example.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

data class WebSearchResult(
    val query: String,
    val summary: String,
    val sourceTitle: String? = null,
    val sourceUrl: String? = null,
    val isSuccess: Boolean = true
)

/**
 * Web Arama Motoru (WebSearchEngine).
 * Güncel bilgi, hava durumu, döviz/kripto ve haber sorularını
 * güvenilir web kaynaklarından canlı olarak sorgular ve özetler.
 */
class WebSearchEngine {

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String): WebSearchResult = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()
        val lower = cleanQuery.lowercase()

        // 1. Kripto / Bitcoin fiyat kontrolü
        if (lower.contains("bitcoin") || lower.contains("btc")) {
            val btcResult = fetchCryptoPrice("bitcoin", "Bitcoin (BTC)")
            if (btcResult != null) return@withContext btcResult
        }

        // 2. Hava durumu sorgusu
        if (lower.contains("hava")) {
            val weatherResult = fetchWeather(cleanQuery)
            if (weatherResult != null) return@withContext weatherResult
        }

        // 3. Vikipedi Türkçe Arama
        val wikiResult = fetchWikipediaSummary(cleanQuery)
        if (wikiResult != null && wikiResult.summary.isNotBlank()) {
            return@withContext wikiResult
        }

        // 4. DuckDuckGo Anlık Bilgi Servisi
        val ddgResult = fetchDuckDuckGoInstantAnswer(cleanQuery)
        if (ddgResult != null && ddgResult.summary.isNotBlank()) {
            return@withContext ddgResult
        }

        // Bilgi bulunamadığında kullanıcıya açık ve anlaşılır bilgi ver (API uyarısı DEĞİL)
        WebSearchResult(
            query = cleanQuery,
            summary = "\"$cleanQuery\" hakkında internette güvenilir ve net bir bilgi kaynağına şu an ulaşılamadı. Arama terimini biraz daha detaylandırarak tekrar deneyebilirsin.",
            sourceTitle = "Web Arama",
            sourceUrl = null,
            isSuccess = false
        )
    }

    private fun fetchCryptoPrice(coinId: String, coinName: String): WebSearchResult? {
        return try {
            val url = "https://api.coingecko.com/api/v3/simple/price?ids=$coinId&vs_currencies=usd,try"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "SuesaAI/1.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val body = response.body?.string() ?: return null
            val json = JSONObject(body)
            val coinObj = json.optJSONObject(coinId) ?: return null

            val priceUsd = coinObj.optDouble("usd", 0.0)
            val priceTry = coinObj.optDouble("try", 0.0)

            val summary = """
                📊 **Güncel $coinName Fiyatı**:
                • USD: $%,.2f
                • TRY: ₺%,.2f
            """.trimIndent().format(priceUsd, priceTry)

            WebSearchResult(
                query = "$coinName fiyatı",
                summary = summary,
                sourceTitle = "CoinGecko Kripto Piyasaları",
                sourceUrl = "https://www.coingecko.com",
                isSuccess = true
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun fetchWeather(query: String): WebSearchResult? {
        return try {
            var city = "Istanbul"
            val cities = listOf(
                "Ankara", "Istanbul", "İzmir", "Izmir", "Bursa", "Antalya", "Adana", "Konya",
                "Gaziantep", "Trabzon", "Eskişehir", "Samsun", "Diyarbakır", "Mersin", "Kayseri"
            )
            for (c in cities) {
                if (query.contains(c, ignoreCase = true)) {
                    city = c.replace("İ", "I").replace("ı", "i")
                        .replace("ş", "s").replace("Ş", "S")
                        .replace("ğ", "g").replace("Ğ", "G")
                        .replace("ü", "u").replace("Ü", "U")
                        .replace("ö", "o").replace("Ö", "O")
                    break
                }
            }

            val url = "https://wttr.in/${city}?format=j1"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "curl/7.68.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val body = response.body?.string() ?: return null
            val json = JSONObject(body)
            val currentCondition = json.optJSONArray("current_condition")?.optJSONObject(0) ?: return null

            val tempC = currentCondition.optString("temp_C", "-")
            val feelsLike = currentCondition.optString("FeelsLikeC", "-")
            val humidity = currentCondition.optString("humidity", "-")
            val descArray = currentCondition.optJSONArray("weatherDesc")
            val weatherDescEn = descArray?.optJSONObject(0)?.optString("value") ?: "Açık"

            val weatherDescTr = translateWeather(weatherDescEn)

            val summary = """
                🌤️ **$city İçin Güncel Hava Durumu**:
                • Durum: $weatherDescTr
                • Sıcaklık: $tempC°C (Hissedilen: $feelsLike°C)
                • Nem: %$humidity
            """.trimIndent()

            WebSearchResult(
                query = query,
                summary = summary,
                sourceTitle = "Meteoroloji Servisi ($city)",
                sourceUrl = "https://wttr.in/$city",
                isSuccess = true
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun translateWeather(desc: String): String {
        val d = desc.lowercase()
        return when {
            d.contains("sunny") || d.contains("clear") -> "Güneşli ve Açık ☀️"
            d.contains("partly cloudy") -> "Parçalı Bulutlu ⛅"
            d.contains("cloudy") || d.contains("overcast") -> "Bulutlu / Kapalı ☁️"
            d.contains("rain") || d.contains("shower") -> "Yağmurlu 🌧️"
            d.contains("thunder") || d.contains("storm") -> "Gök Gürültülü Fırtına ⛈️"
            d.contains("snow") -> "Karlı ❄️"
            d.contains("mist") || d.contains("fog") -> "Sisli 🌫️"
            else -> desc
        }
    }

    private fun fetchWikipediaSummary(query: String): WebSearchResult? {
        return try {
            val cleanTerm = query
                .replace("hakkında bilgi ver", "")
                .replace("nedir", "")
                .replace("kimdir", "")
                .replace("ne demek", "")
                .replace("araştır", "")
                .replace("hakkında internette ne yazıyor", "")
                .replace("internette ne yazıyor", "")
                .replace("?", "")
                .trim()

            val encoded = URLEncoder.encode(cleanTerm, StandardCharsets.UTF_8.toString())
            val searchUrl = "https://tr.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encoded&utf8=&format=json"

            val request = Request.Builder().url(searchUrl)
                .header("User-Agent", "SuesaAI-Assistant/1.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val body = response.body?.string() ?: return null
            val json = JSONObject(body)
            val searchArr = json.optJSONObject("query")?.optJSONArray("search") ?: return null

            if (searchArr.length() == 0) return null

            val firstHit = searchArr.getJSONObject(0)
            val title = firstHit.optString("title")
            val snippet = firstHit.optString("snippet")
                .replace(Regex("<[^>]*>"), "")
                .replace("&quot;", "\"")
                .replace("&amp;", "&")

            if (title.isBlank()) return null

            val titleEncoded = URLEncoder.encode(title, StandardCharsets.UTF_8.toString())
            val summaryUrl = "https://tr.wikipedia.org/api/rest_v1/page/summary/$titleEncoded"
            val summaryReq = Request.Builder().url(summaryUrl)
                .header("User-Agent", "SuesaAI-Assistant/1.0")
                .build()

            val sumResp = httpClient.newCall(summaryReq).execute()
            var extract = ""
            var pageUrl = "https://tr.wikipedia.org/wiki/$titleEncoded"

            if (sumResp.isSuccessful) {
                val sumBody = sumResp.body?.string() ?: ""
                val sumJson = JSONObject(sumBody)
                extract = sumJson.optString("extract", "")
                val contentUrls = sumJson.optJSONObject("content_urls")
                val desktop = contentUrls?.optJSONObject("desktop")
                pageUrl = desktop?.optString("page", pageUrl) ?: pageUrl
            }

            val finalSummary = if (extract.isNotBlank()) extract else snippet

            if (finalSummary.isNotBlank()) {
                WebSearchResult(
                    query = query,
                    summary = finalSummary,
                    sourceTitle = "Vikipedi: $title",
                    sourceUrl = pageUrl,
                    isSuccess = true
                )
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun fetchDuckDuckGoInstantAnswer(query: String): WebSearchResult? {
        return try {
            val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
            val url = "https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1"

            val request = Request.Builder().url(url).build()
            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val body = response.body?.string() ?: return null
            val json = JSONObject(body)

            val abstractText = json.optString("AbstractText", "")
            val abstractSource = json.optString("AbstractSource", "DuckDuckGo Web")
            val abstractUrl = json.optString("AbstractURL", "")

            if (abstractText.isNotBlank()) {
                WebSearchResult(
                    query = query,
                    summary = abstractText,
                    sourceTitle = abstractSource,
                    sourceUrl = if (abstractUrl.isNotBlank()) abstractUrl else null,
                    isSuccess = true
                )
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
