package com.example.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

data class SearchResult(
    val query: String,
    val summary: String,
    val sourceTitle: String? = null,
    val sourceUrl: String? = null,
    val isFound: Boolean = true
)

/**
 * Suesa AI Gerçek Web Arama Servisi.
 * Güncel bilgi, hava durumu, haber veya bilinmeyen konularda
 * güvenilir web kaynaklarından canlı bilgi sorgular ve özetler.
 */
class WebSearch {

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun search(query: String): SearchResult = withContext(Dispatchers.IO) {
        val cleanQuery = query.trim()

        // 1. Hava durumu kontrolü
        if (cleanQuery.contains("hava", ignoreCase = true)) {
            val weatherResult = fetchWeather(cleanQuery)
            if (weatherResult != null) {
                return@withContext weatherResult
            }
        }

        // 2. Vikipedi Türkçe Arama
        val wikiResult = fetchWikipediaSummary(cleanQuery)
        if (wikiResult != null && wikiResult.summary.isNotBlank()) {
            return@withContext wikiResult
        }

        // 3. DuckDuckGo Anlık Bilgi Servisi
        val ddgResult = fetchDuckDuckGoInstantAnswer(cleanQuery)
        if (ddgResult != null && ddgResult.summary.isNotBlank()) {
            return@withContext ddgResult
        }

        // Bulunamadıysa dürüst cevap
        SearchResult(
            query = cleanQuery,
            summary = "Web üzerinde \"$cleanQuery\" konusu hakkında güvenilir ve kesin bir özet bulamadım. Bilgiyi doğrulamak için lütfen arama terimini daha spesifik belirtebilirsin.",
            sourceTitle = "Arama Motoru",
            sourceUrl = null,
            isFound = false
        )
    }

    private fun fetchWeather(query: String): SearchResult? {
        return try {
            // Şehir tespiti (Örn: "Ankara'da hava durumu", "İstanbul hava nasıl")
            var city = "Istanbul"
            val cities = listOf(
                "Ankara", "Istanbul", "İzmir", "Izmir", "Bursa", "Antalya", "Adana", "Konya",
                "Gaziantep", "Trabzon", "Eskişehir", "Samsun", "Diyarbakır", "Mersin", "Kayseri"
            )
            for (c in cities) {
                if (query.contains(c, ignoreCase = true)) {
                    city = c.replace("İ", "I").replace("ı", "i")
                        .replace("ş", "s").replace("Ş", "S")
                        .replace("ğ", "g").replace("Ğ", "G")
                        .replace("ü", "u").replace("Ü", "U")
                        .replace("ö", "o").replace("Ö", "O")
                    break
                }
            }

            val url = "https://wttr.in/${city}?format=j1"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "curl/7.68.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val body = response.body?.string() ?: return null
            val json = JSONObject(body)
            val currentCondition = json.optJSONArray("current_condition")?.optJSONObject(0) ?: return null

            val tempC = currentCondition.optString("temp_C", "-")
            val feelsLike = currentCondition.optString("FeelsLikeC", "-")
            val humidity = currentCondition.optString("humidity", "-")
            val descArray = currentCondition.optJSONArray("weatherDesc")
            val weatherDescEn = descArray?.optJSONObject(0)?.optString("value") ?: "Açık"

            val weatherDescTr = translateWeatherCondition(weatherDescEn)

            val summary = """
                Bulunduğun bölge ($city) için güncel hava durumu:
                • Durum: $weatherDescTr
                • Sıcaklık: $tempC°C (Hissedilen: $feelsLike°C)
                • Nem Oranı: %$humidity
            """.trimIndent()

            SearchResult(
                query = query,
                summary = summary,
                sourceTitle = "Canlı Meteoroloji Servisi ($city)",
                sourceUrl = "https://wttr.in/$city",
                isFound = true
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun translateWeatherCondition(desc: String): String {
        val d = desc.lowercase()
        return when {
            d.contains("sunny") || d.contains("clear") -> "Güneşli ve Açık ☀️"
            d.contains("partly cloudy") -> "Parçalı Bulutlu ⛅"
            d.contains("cloudy") || d.contains("overcast") -> "Bulutlu / Kapalı ☁️"
            d.contains("rain") || d.contains("shower") -> "Yağmurlu 🌧️"
            d.contains("thunder") || d.contains("storm") -> "Gök Gürültülü Fırtına ⛈️"
            d.contains("snow") -> "Karlı ❄️"
            d.contains("mist") || d.contains("fog") -> "Sisli 🌫️"
            else -> desc
        }
    }

    private fun fetchWikipediaSummary(query: String): SearchResult? {
        return try {
            // Arama sorgusunu optimize et
            val cleanTerm = query
                .replace("hakkında bilgi ver", "")
                .replace("nedir", "")
                .replace("kimdir", "")
                .replace("ne demek", "")
                .replace("araştır", "")
                .trim()

            val encoded = URLEncoder.encode(cleanTerm, StandardCharsets.UTF_8.toString())
            val searchUrl = "https://tr.wikipedia.org/w/api.php?action=query&list=search&srsearch=$encoded&utf8=&format=json"

            val request = Request.Builder().url(searchUrl)
                .header("User-Agent", "SuesaAI-Assistant/1.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val body = response.body?.string() ?: return null
            val json = JSONObject(body)
            val searchArr = json.optJSONObject("query")?.optJSONArray("search") ?: return null

            if (searchArr.length() == 0) return null

            val firstHit = searchArr.getJSONObject(0)
            val title = firstHit.optString("title")
            val snippet = firstHit.optString("snippet")
                .replace(Regex("<[^>]*>"), "") // HTML etiketlerini temizle
                .replace("&quot;", "\"")
                .replace("&amp;", "&")

            if (title.isBlank()) return null

            // Sayfa özetini çek
            val titleEncoded = URLEncoder.encode(title, StandardCharsets.UTF_8.toString())
            val summaryUrl = "https://tr.wikipedia.org/api/rest_v1/page/summary/$titleEncoded"
            val summaryReq = Request.Builder().url(summaryUrl)
                .header("User-Agent", "SuesaAI-Assistant/1.0")
                .build()

            val sumResp = httpClient.newCall(summaryReq).execute()
            var extract = ""
            var pageUrl = "https://tr.wikipedia.org/wiki/$titleEncoded"

            if (sumResp.isSuccessful) {
                val sumBody = sumResp.body?.string() ?: ""
                val sumJson = JSONObject(sumBody)
                extract = sumJson.optString("extract", "")
                val contentUrls = sumJson.optJSONObject("content_urls")
                val desktop = contentUrls?.optJSONObject("desktop")
                pageUrl = desktop?.optString("page", pageUrl) ?: pageUrl
            }

            val finalSummary = if (extract.isNotBlank()) extract else snippet

            if (finalSummary.isNotBlank()) {
                SearchResult(
                    query = query,
                    summary = finalSummary,
                    sourceTitle = "Vikipedi: $title",
                    sourceUrl = pageUrl,
                    isFound = true
                )
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun fetchDuckDuckGoInstantAnswer(query: String): SearchResult? {
        return try {
            val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.toString())
            val url = "https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1"

            val request = Request.Builder().url(url).build()
            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) return null

            val body = response.body?.string() ?: return null
            val json = JSONObject(body)

            val abstractText = json.optString("AbstractText", "")
            val abstractSource = json.optString("AbstractSource", "DuckDuckGo Web")
            val abstractUrl = json.optString("AbstractURL", "")

            if (abstractText.isNotBlank()) {
                SearchResult(
                    query = query,
                    summary = abstractText,
                    sourceTitle = abstractSource,
                    sourceUrl = if (abstractUrl.isNotBlank()) abstractUrl else null,
                    isFound = true
                )
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
