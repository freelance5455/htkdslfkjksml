package com.example.ai

import android.util.Log
import com.example.data.KeyboardLanguage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.InlineDataPart
import com.google.firebase.ai.type.PublicPreviewAPI
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.SpeechConfig
import com.google.firebase.ai.type.Voice
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "VelvetAiEngine"

sealed interface AiResult<out T> {
    data class Success<T>(val value: T) : AiResult<T>
    data class Error(val message: String) : AiResult<Nothing>
}

enum class AiWriteTone(val label: String, val instruction: String) {
    NATURAL("Natural", "warm, clear, and natural"),
    PROFESSIONAL("Pro", "polished, concise, and professional"),
    CASUAL("Casual", "relaxed, friendly, and conversational"),
    WITTY("Witty", "clever, upbeat, and engaging"),
    SHORTER("Shorter", "ultra-concise while keeping the core meaning")
}

data class SynthesizedAudio(
    val pcmBytes: ByteArray,
    val sampleRateHz: Int = 24000
)

class VelvetAiEngine {

    private val fastAiModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = generationConfig {
                temperature = 0.2f
            }
        )
    }

    private val writerAiModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                temperature = 0.45f
            }
        )
    }

    private val predictionSchema = Schema.obj(
        properties = mapOf(
            "predictions" to Schema.array(
                items = Schema.string(),
                description = "Up to 3 likely next words or slang continuations"
            )
        )
    )

    private val predictionModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.5-flash-lite",
            generationConfig = generationConfig {
                temperature = 0.25f
                responseMimeType = "application/json"
                responseSchema = predictionSchema
            }
        )
    }

    /**
     * Velvet AI Speech Synthesis powered by Gemini 3.1 Flash TTS.
     */
    @OptIn(PublicPreviewAPI::class)
    suspend fun synthesizeSpeechPcm(
        text: String,
        language: KeyboardLanguage,
        timeoutMs: Long = 20_000L
    ): AiResult<SynthesizedAudio> {
        val clean = text.trim()
        if (clean.isEmpty()) return AiResult.Error("Type some text first to read aloud.")

        val ttsLangCode = when (language) {
            KeyboardLanguage.EN -> "en-US"
            KeyboardLanguage.ES -> "es-ES"
            KeyboardLanguage.FR -> "fr-FR"
            KeyboardLanguage.DE -> "de-DE"
            KeyboardLanguage.PT -> "pt-BR"
            KeyboardLanguage.IT -> "it-IT"
            KeyboardLanguage.AR -> "ar-XA"
        }

        return try {
            val config = generationConfig {
                responseModalities = listOf(ResponseModality.AUDIO)
                speechConfig = SpeechConfig(
                    voice = Voice("Kore"),
                    languageCode = ttsLangCode
                )
            }
            val model = Firebase.ai(backend = GenerativeBackend.googleAI())
                .generativeModel(
                    modelName = "gemini-3.1-flash-tts-preview",
                    generationConfig = config
                )

            val response = withTimeout(timeoutMs) {
                model.generateContent("Read the following text clearly and naturally:\n$clean")
            }

            val parts = response.candidates.firstOrNull()?.content?.parts.orEmpty()
            val audioPart = parts.filterIsInstance<InlineDataPart>().firstOrNull {
                it.mimeType.startsWith("audio/", ignoreCase = true)
            } ?: parts.filterIsInstance<InlineDataPart>().firstOrNull()

            if (audioPart == null || audioPart.inlineData.isEmpty()) {
                return AiResult.Error("AI speech synthesizer returned empty audio.")
            }

            val rateMatch = Regex("rate=(\\d+)").find(audioPart.mimeType)
            val rateHz = rateMatch?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 24000
            AiResult.Success(SynthesizedAudio(pcmBytes = audioPart.inlineData, sampleRateHz = rateHz))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI TTS timed out", e)
            AiResult.Error("AI voice synthesis timed out.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI TTS failed", e)
            AiResult.Error(e.localizedMessage ?: "AI voice synthesis failed.")
        }
    }

    /**
     * Velvet Voice transcript refinement:
     * - Strips hesitation fillers and false starts
     * - Resolves mid-sentence self-corrections
     * - Fixes grammar & adds smart ? / ! punctuation while keeping user slang
     */
    suspend fun refineVoiceTranscript(
        rawTranscript: String,
        language: KeyboardLanguage,
        removeStarters: Boolean,
        autoPunctuate: Boolean,
        preserveSlang: Boolean
    ): AiResult<String> {
        val clean = rawTranscript.trim()
        if (clean.isEmpty()) return AiResult.Error("No speech detected.")

        val prompt = buildString {
            append("You are VelvetKey's built-in voice writing assistant for ${language.displayName}. ")
            append("Turn this raw spoken transcript into clean, well-punctuated, natural text. ")
            if (removeStarters) {
                append("Remove hesitation starters and filler words ('um', 'uh', 'er', 'like', 'so basically', 'you know', 'well'). ")
                append("Resolve mid-sentence self-corrections cleanly (e.g., 'meet at 4 no wait 5' -> 'meet at 5'). ")
            }
            if (preserveSlang) {
                append("Keep natural casual slang intact (do NOT over-formalize 'ngl', 'lowkey', 'bet', 'fr', 'vibes', 'tbh'). ")
            }
            if (autoPunctuate) {
                append("Fix capitalization, grammar, and add punctuation including question marks (?) and exclamation points (!). ")
            }
            append("Return ONLY the final text with no quotes or explanations.\n\nTranscript:\n$clean")
        }

        return try {
            val response = withTimeout(60_000L) {
                fastAiModel.generateContent(prompt)
            }
            val output = response.text?.trim().orEmpty()
            if (output.isBlank()) AiResult.Success(clean) else AiResult.Success(output)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Voice refine timed out", e)
            AiResult.Error("Velvet Voice timed out. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Voice refine failed", e)
            AiResult.Error(e.localizedMessage ?: "Velvet Voice processing failed.")
        }
    }

    /**
     * Fast multimodal audio transcription & grammar refinement.
     */
    suspend fun transcribeAndEnhanceAudio(
        wavBytes: ByteArray,
        contextPrefix: String,
        language: KeyboardLanguage,
        removeStarters: Boolean,
        autoPunctuate: Boolean,
        predictContinuation: Boolean,
        preserveSlang: Boolean
    ): AiResult<String> {
        if (wavBytes.size <= 44) {
            return AiResult.Error("No audio was captured. Speak closer to the mic and try again.")
        }

        val instructions = buildString {
            append("You are VelvetKey's custom built-in voice-to-text engine in ${language.displayName}. ")
            append("Transcribe the spoken audio accurately into clean, grammatically sound text. ")
            if (removeStarters) {
                append("Remove hesitation starters, filler words, and false starts ('um', 'uh', 'er', 'like', 'so basically', 'you know', 'I mean', 'well'). Resolve mid-sentence corrections cleanly. ")
            }
            if (preserveSlang) {
                append("Preserve natural slang and casual terms without over-formalizing them. ")
            }
            if (autoPunctuate) {
                append("Automatically add proper capitalization and expressive punctuation, especially question marks (?) for questions and exclamation points (!) for emphasis. ")
            }
            if (predictContinuation) {
                append("If the speaker trails off mid-phrase, subtly complete the obvious thought cleanly. ")
            }
            if (contextPrefix.isNotBlank()) {
                append("Prior typed text: \"${contextPrefix.takeLast(120)}\". Continue seamlessly without repeating it. ")
            }
            append("Return ONLY the final text with zero quotes or commentary.")
        }

        return try {
            val response = withTimeout(60_000L) {
                fastAiModel.generateContent(
                    content {
                        inlineData(wavBytes, "audio/wav")
                        text(instructions)
                    }
                )
            }
            val output = response.text?.trim().orEmpty()
            if (output.isBlank()) {
                AiResult.Error("Couldn't hear clear speech. Speak closer to the mic and try again.")
            } else {
                AiResult.Success(output)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Audio transcription timed out", e)
            AiResult.Error("Voice transcription timed out. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Audio transcription failed", e)
            AiResult.Error(e.localizedMessage ?: "Voice processing failed.")
        }
    }

    /**
     * Built-in Velvet AI Grammar & Clarity Corrector.
     */
    suspend fun fixGrammarAndClarity(
        rawText: String,
        language: KeyboardLanguage,
        preserveSlang: Boolean
    ): AiResult<String> {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) {
            return AiResult.Error("Type some text first to fix grammar.")
        }

        val prompt = buildString {
            append("Fix all grammar, spelling, verb tense, and punctuation errors in this ${language.displayName} text while making it read clearly and naturally. ")
            if (preserveSlang) {
                append("Keep intentional casual slang or acronyms ('ngl', 'lowkey', 'bet', 'fr', 'tbh') intact if they fit the message. ")
            }
            append("Add proper capitalization, commas, periods, question marks (?), and exclamation points (!) where appropriate. ")
            append("Return ONLY the corrected text with no quotes or commentary.\n\nText:\n$trimmed")
        }

        return try {
            val response = withTimeout(60_000L) {
                fastAiModel.generateContent(prompt)
            }
            val result = response.text?.trim()
            if (result.isNullOrBlank()) {
                AiResult.Error("Velvet AI returned an empty response.")
            } else {
                AiResult.Success(result)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Grammar fix timed out", e)
            AiResult.Error("Grammar check timed out. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Grammar fix failed", e)
            AiResult.Error(e.localizedMessage ?: "Grammar check failed.")
        }
    }

    /**
     * Built-in Velvet AI Polish & Starter Cleanup.
     */
    suspend fun polishText(
        rawText: String,
        language: KeyboardLanguage,
        removeStarters: Boolean,
        autoPunctuate: Boolean,
        preserveSlang: Boolean,
        tone: AiWriteTone = AiWriteTone.NATURAL
    ): AiResult<String> {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) {
            return AiResult.Error("Type or dictate some text first to improve it.")
        }

        val prompt = buildString {
            append("Improve and rewrite this ${language.displayName} message so its tone is ${tone.instruction} and it reads effortlessly. ")
            if (removeStarters) {
                append("Remove filler starters ('um', 'uh', 'like', 'so yeah', 'basically', 'you know', 'well'). ")
            }
            if (preserveSlang && tone != AiWriteTone.PROFESSIONAL) {
                append("Keep the user's natural slang and personality intact. ")
            }
            if (autoPunctuate) {
                append("Fix grammar, spelling, capitalization, and add clear punctuation (? and ! where natural). ")
            }
            append("Return ONLY the improved text with no explanations or quotes.\n\nText:\n$trimmed")
        }

        return try {
            val response = withTimeout(60_000L) {
                fastAiModel.generateContent(prompt)
            }
            val result = response.text?.trim()
            if (result.isNullOrBlank()) {
                AiResult.Error("Velvet AI returned an empty response.")
            } else {
                AiResult.Success(result)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI polish timed out", e)
            AiResult.Error("Velvet AI polish timed out. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI polish failed", e)
            AiResult.Error(e.localizedMessage ?: "Velvet AI polish failed.")
        }
    }

    /**
     * Built-in Velvet AI Auto-Writer: automatically composes ready-to-send text
     * from a short prompt or rough draft.
     */
    suspend fun autoGenerateText(
        promptOrDraft: String,
        language: KeyboardLanguage,
        tone: AiWriteTone = AiWriteTone.NATURAL
    ): AiResult<String> {
        val trimmed = promptOrDraft.trim()
        if (trimmed.isEmpty()) {
            return AiResult.Error("Enter a short idea or note for Velvet AI to write.")
        }

        val prompt = buildString {
            append("You are VelvetKey's built-in AI writer for ${language.displayName}. ")
            append("Write a complete, ready-to-send message based on the user's short note or request below. ")
            append("Tone: ${tone.instruction}. ")
            append("Fix any grammar, make it sound genuinely human and expressive, and do NOT include placeholders like [Name] unless essential. ")
            append("Return ONLY the finished message text with no quotes or preamble.\n\nRequest or draft:\n$trimmed")
        }

        return try {
            val response = withTimeout(60_000L) {
                writerAiModel.generateContent(prompt)
            }
            val result = response.text?.trim()
            if (result.isNullOrBlank()) {
                AiResult.Error("Velvet AI couldn't generate text. Try a clearer prompt.")
            } else {
                AiResult.Success(result)
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI auto-generate timed out", e)
            AiResult.Error("Velvet AI writer timed out. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI auto-generate failed", e)
            AiResult.Error(e.localizedMessage ?: "Velvet AI writer failed.")
        }
    }

    fun streamAutoGenerateText(
        promptOrDraft: String,
        language: KeyboardLanguage,
        tone: AiWriteTone = AiWriteTone.NATURAL
    ): Flow<String> = flow {
        val trimmed = promptOrDraft.trim()
        if (trimmed.isEmpty()) return@flow
        val prompt = buildString {
            append("You are VelvetKey's built-in AI writer for ${language.displayName}. ")
            append("Write a complete, ready-to-send message based on the user's short note or request below. ")
            append("Tone: ${tone.instruction}. ")
            append("Make it natural, grammatically crisp, and ready to send. Return ONLY the message.\n\nRequest:\n$trimmed")
        }
        val sb = StringBuilder()
        withTimeout(60_000L) {
            writerAiModel.generateContentStream(prompt).collect { chunk ->
                val part = chunk.text.orEmpty()
                if (part.isNotEmpty()) {
                    sb.append(part)
                    emit(sb.toString())
                }
            }
        }
    }

    suspend fun predictNextWords(
        recentContext: String,
        language: KeyboardLanguage,
        learnedSlang: List<String>
    ): AiResult<List<String>> {
        val clean = recentContext.trim()
        if (clean.length < 3) return AiResult.Success(emptyList())

        val slangHint = if (learnedSlang.isNotEmpty()) {
            " User's frequent slang/words: ${learnedSlang.take(10).joinToString(", ")}."
        } else ""

        val prompt = "Given the unfinished ${language.displayName} message below, suggest 3 likely next words.$slangHint\n\nMessage: \"${clean.takeLast(140)}\""

        return try {
            val response = withTimeout(30_000L) {
                predictionModel.generateContent(prompt)
            }
            val jsonText = response.text ?: return AiResult.Success(emptyList())
            val obj = JSONObject(jsonText)
            val arr = obj.optJSONArray("predictions") ?: return AiResult.Success(emptyList())
            val list = buildList {
                for (i in 0 until arr.length()) {
                    val word = arr.optString(i).trim()
                    if (word.isNotEmpty()) add(word)
                }
            }.take(3)
            AiResult.Success(list)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Prediction timed out", e)
            AiResult.Error("Prediction timed out.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "AI prediction failed", e)
            AiResult.Error(e.localizedMessage ?: "AI prediction failed.")
        }
    }
}
