package com.example.ai

import java.util.Locale

sealed class UserIntent {
    // Telefon Sistem Komutları
    data class OpenApp(val appType: AppType, val parameter: String? = null) : UserIntent()
    data class CallContact(val targetNameOrNumber: String) : UserIntent()
    data class OpenSetting(val settingType: SettingType) : UserIntent()

    // Bilgi ve Arama Komutları
    data class WebSearchQuery(val query: String) : UserIntent()
    data class LocalKnowledgeQuery(val query: String) : UserIntent()
    data class ImageAnalysisQuery(val prompt: String) : UserIntent()

    // Genel Sohbet
    data class GeneralChat(val text: String) : UserIntent()
}

enum class AppType {
    GOOGLE,
    CHROME,
    WHATSAPP,
    YOUTUBE,
    CAMERA,
    GALLERY,
    MESSAGES,
    CLOCK_ALARM,
    CALCULATOR,
    DIALER,
    SETTINGS,
    CUSTOM
}

enum class SettingType {
    GENERAL,
    WIFI,
    BLUETOOTH,
    SOUND,
    APPLICATIONS
}

/**
 * Kullanıcı girdisini analiz edip doğru niyeti (intent) belirleyen katman.
 */
object IntentDetection {

    fun detect(text: String, hasAttachedImage: Boolean = false): UserIntent {
        val q = text.lowercase(Locale.forLanguageTag("tr-TR")).trim()

        if (hasAttachedImage) {
            return UserIntent.ImageAnalysisQuery(text)
        }

        // 1. Arama intenti: "Ahmet'i ara", "Annemi ara", "Mustafa yı ara"
        val callRegex = Regex(
            "(?:rehberden\\s+)?([a-zA-ZçğıöşüÇĞİÖŞÜ0-9\\+\\s]+?)['’]?(?:i|ı|u|ü|yi|yı|yu|yü|'i|'ı)?\\s+(?:ara|telefon et|çağrı yap)$",
            RegexOption.IGNORE_CASE
        )
        val callMatch = callRegex.find(text.trim())
        if (callMatch != null) {
            val contact = callMatch.groupValues[1].trim()
            if (contact.isNotBlank() && !contact.equals("beni", ignoreCase = true) && !contact.equals("internette", ignoreCase = true)) {
                return UserIntent.CallContact(contact)
            }
        }
        if (q.startsWith("ara ") && text.trim().length > 4) {
            val contact = text.trim().substring(4).trim()
            if (!contact.contains("internet", ignoreCase = true) && !contact.contains("google", ignoreCase = true)) {
                return UserIntent.CallContact(contact)
            }
        }

        // 2. YouTube komutları: "YouTube'u aç", "Youtube aç", "Youtube başlat"
        if (q.contains("youtube") && (q.contains("aç") || q.contains("baslat") || q.contains("başlat") || q.contains("izle"))) {
            return UserIntent.OpenApp(AppType.YOUTUBE)
        }

        // 3. Kamera komutları: "Kamerayı aç", "Kamera aç", "Fotoğraf çek", "Kamerayı başlat"
        if ((q.contains("kamera") || q.contains("fotoğraf")) && (q.contains("aç") || q.contains("çek") || q.contains("başlat"))) {
            return UserIntent.OpenApp(AppType.CAMERA)
        }

        // 4. Galeri komutları: "Galeri aç", "Galeriyi aç", "Fotoğrafları aç"
        if (q.contains("galeri") || q.contains("fotoğraflar") || q.contains("resimler")) {
            if (q.contains("aç") || q.contains("göster") || q.contains("başlat")) {
                return UserIntent.OpenApp(AppType.GALLERY)
            }
        }

        // 5. Mesajlar / SMS: "Mesajları aç", "SMS aç", "Mesaj yaz"
        if ((q.contains("mesaj") || q.contains("sms")) && (q.contains("aç") || q.contains("gönder") || q.contains("yaz"))) {
            return UserIntent.OpenApp(AppType.MESSAGES)
        }

        // 6. Alarm / Saat: "Alarm kur", "Saati aç", "Alarm aç"
        if (q.contains("alarm") || (q.contains("saat") && q.contains("aç"))) {
            return UserIntent.OpenApp(AppType.CLOCK_ALARM)
        }

        // 7. Hesap Makinesi: "Hesap makinesini aç", "Hesap makinesi aç"
        if (q.contains("hesap makine") && q.contains("aç")) {
            return UserIntent.OpenApp(AppType.CALCULATOR)
        }

        // 8. Sistem Ayarları: "Wi-Fi aç", "Bluetooth aç", "Ayarları aç"
        if (q.contains("wi-fi") || q.contains("wifi") || q.contains("kablosuz ağ")) {
            if (q.contains("ayarlar") || q.contains("aç")) {
                return UserIntent.OpenSetting(SettingType.WIFI)
            }
        }
        if (q.contains("bluetooth")) {
            if (q.contains("ayarlar") || q.contains("aç")) {
                return UserIntent.OpenSetting(SettingType.BLUETOOTH)
            }
        }
        if (q.contains("ayar") && (q.contains("aç") || q.contains("git") || q.contains("göster"))) {
            return UserIntent.OpenSetting(SettingType.GENERAL)
        }

        // 9. Yerel Bilgi Kontrolü (Hızlı ve kesin cevaplar)
        val localMatch = LocalKnowledge.findAnswer(q)
        if (localMatch != null) {
            return UserIntent.LocalKnowledgeQuery(text)
        }

        // 10. Web Arama İhtiyacı Olan Sorular:
        // Hava durumu, güncel haber, fiyat, döviz, etkinlik, doğrudan arama isteği
        if (isWebSearchRequired(q)) {
            return UserIntent.WebSearchQuery(text)
        }

        // 11. Genel Sohbet ve Yanıt
        return UserIntent.GeneralChat(text)
    }

    private fun isWebSearchRequired(q: String): Boolean {
        if (q.contains("hava durumu") || q.contains("hava nasıl") || q.contains("kaç derece")) return true
        if (q.contains("internette ara") || q.contains("google'da ara") || q.contains("araştır") || q.contains("web'de ara")) return true
        if (q.contains("dolar") || q.contains("euro") || q.contains("altın fiyatı") || q.contains("borsa")) return true
        if (q.contains("son dakika") || q.contains("haberler") || q.contains("gündem")) return true
        if (q.contains("vizyondaki filmler") || q.contains("maç sonucu") || q.contains("lig tablosu")) return true
        if (q.contains("etkinlik") || q.contains("konser") || q.contains("fiyatı ne kadar")) return true
        if (q.contains("yeni çıkan") || q.contains("güncelleme notları") || q.contains("sürümünde neler var")) return true
        if (q.contains("nerede") && (q.contains("restoran") || q.contains("eczane") || q.contains("hastane"))) return true
        return false
    }
}
