package com.example.ai

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.example.data.KeyboardLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * VelvetKey inline voice dictation engine:
 * - Streams real-time headless SpeechRecognizer partials (no Google popup) when available
 * - Automatically falls back to 16kHz AudioRecord WAV + Velvet AI multimodal transcription
 * - Watchdog guard guarantees finishListening() never hangs indefinitely
 */
class VelvetVoiceEngine(
    private val context: Context,
    private val wavFallbackRecorder: CustomVoiceRecorder
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var usingFallbackWav = false
    private var activeScope: CoroutineScope? = null
    private var finishWatchdogJob: Job? = null
    private var sessionCompleted = false

    private val _partialText = MutableStateFlow("")
    val partialText: StateFlow<String> = _partialText.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isWavMode = MutableStateFlow(false)
    val isWavMode: StateFlow<Boolean> = _isWavMode.asStateFlow()

    fun hasMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun startListening(
        scope: CoroutineScope,
        language: KeyboardLanguage,
        preferPureAiMic: Boolean = false,
        onFinalRawTranscript: (String) -> Unit,
        onFallbackAudioReady: (ByteArray) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!hasMicPermission()) {
            onError("Microphone permission required for voice dictation.")
            return
        }

        stopInternal()
        activeScope = scope
        sessionCompleted = false
        _partialText.value = ""
        _rmsLevel.value = 0f

        val recognizerAvailable = !preferPureAiMic && try {
            SpeechRecognizer.isRecognitionAvailable(context)
        } catch (_: Throwable) {
            false
        }

        if (!recognizerAvailable) {
            startWavFallback(scope, onError)
            return
        }

        scope.launch(Dispatchers.Main.immediate) {
            try {
                val sr = SpeechRecognizer.createSpeechRecognizer(context)
                speechRecognizer = sr
                usingFallbackWav = false
                _isWavMode.value = false

                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        val norm = ((rmsdB + 2f) / 12f).coerceIn(0.05f, 1f)
                        _rmsLevel.value = norm
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _rmsLevel.value = 0f
                    }

                    override fun onError(error: Int) {
                        if (sessionCompleted) return
                        finishWatchdogJob?.cancel()
                        val currentPartial = _partialText.value.trim()
                        _isListening.value = false

                        if (currentPartial.isNotEmpty()) {
                            sessionCompleted = true
                            destroyRecognizer()
                            onFinalRawTranscript(currentPartial)
                            return
                        }

                        val shouldFallbackToWav = error == SpeechRecognizer.ERROR_CLIENT ||
                            error == SpeechRecognizer.ERROR_SERVER ||
                            error == SpeechRecognizer.ERROR_NETWORK ||
                            error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                            error == SpeechRecognizer.ERROR_AUDIO ||
                            error == SpeechRecognizer.ERROR_SERVER_DISCONNECTED ||
                            error == SpeechRecognizer.ERROR_TOO_MANY_REQUESTS ||
                            error == SpeechRecognizer.ERROR_CANNOT_CHECK_SUPPORT

                        if (shouldFallbackToWav) {
                            destroyRecognizer()
                            startWavFallback(scope, onError)
                        } else if (error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_NO_MATCH
                        ) {
                            sessionCompleted = true
                            destroyRecognizer()
                            onError("Didn't catch any speech. Tap mic and try again.")
                        } else {
                            sessionCompleted = true
                            destroyRecognizer()
                            onError("Voice capture error ($error). Tap mic to retry.")
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        if (sessionCompleted) return
                        finishWatchdogJob?.cancel()
                        sessionCompleted = true
                        _isListening.value = false

                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty()
                        val best = text.ifBlank { _partialText.value.trim() }
                        destroyRecognizer()

                        if (best.isNotEmpty()) {
                            _partialText.value = best
                            onFinalRawTranscript(best)
                        } else {
                            onError("Didn't catch any speech. Speak clearly into the mic.")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val partial = matches?.firstOrNull()?.trim().orEmpty()
                        if (partial.isNotEmpty()) {
                            _partialText.value = partial
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.bcp47Tag)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }

                _isListening.value = true
                sr.startListening(intent)
            } catch (_: Throwable) {
                destroyRecognizer()
                startWavFallback(scope, onError)
            }
        }
    }

    fun finishListening(
        onFinalRawTranscript: (String) -> Unit,
        onFallbackAudioReady: (ByteArray) -> Unit,
        onError: (String) -> Unit
    ) {
        if (usingFallbackWav) {
            sessionCompleted = true
            _isListening.value = false
            _isWavMode.value = false
            val wav = wavFallbackRecorder.stopAndBuildWav()
            if (wav.size <= 44) {
                onError("No audio captured. Check microphone and try again.")
            } else {
                onFallbackAudioReady(wav)
            }
            return
        }

        val partial = _partialText.value.trim()
        try {
            speechRecognizer?.stopListening()
        } catch (_: Throwable) {
            if (!sessionCompleted) {
                sessionCompleted = true
                _isListening.value = false
                destroyRecognizer()
                if (partial.isNotEmpty()) {
                    onFinalRawTranscript(partial)
                } else {
                    onError("Couldn't catch any speech. Tap mic to try again.")
                }
            }
            return
        }

        finishWatchdogJob?.cancel()
        finishWatchdogJob = activeScope?.launch(Dispatchers.Main.immediate) {
            delay(2500L)
            if (!sessionCompleted) {
                sessionCompleted = true
                _isListening.value = false
                val latestPartial = _partialText.value.trim()
                destroyRecognizer()
                if (latestPartial.isNotEmpty()) {
                    onFinalRawTranscript(latestPartial)
                } else {
                    onError("Speech service didn't respond. Tap mic to retry.")
                }
            }
        }
    }

    fun cancel() {
        stopInternal()
    }

    private fun startWavFallback(
        scope: CoroutineScope,
        onError: (String) -> Unit
    ) {
        usingFallbackWav = true
        _isWavMode.value = true
        val started = wavFallbackRecorder.startRecording(scope)
        if (started) {
            _isListening.value = true
            _partialText.value = ""
            scope.launch {
                wavFallbackRecorder.amplitude.collect { amp ->
                    if (usingFallbackWav && _isListening.value) {
                        _rmsLevel.value = amp
                    }
                }
            }
        } else {
            usingFallbackWav = false
            _isWavMode.value = false
            _isListening.value = false
            onError("Microphone unavailable. Check mic permissions or audio input.")
        }
    }

    private fun stopInternal() {
        sessionCompleted = true
        finishWatchdogJob?.cancel()
        finishWatchdogJob = null
        _isListening.value = false
        _isWavMode.value = false
        _rmsLevel.value = 0f
        if (usingFallbackWav) {
            wavFallbackRecorder.cancel()
            usingFallbackWav = false
        }
        destroyRecognizer()
    }

    private fun destroyRecognizer() {
        try {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (_: Throwable) {
        }
        speechRecognizer = null
    }
}
