package com.example.ai

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.KeyboardLanguage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private const val TAG = "CustomTtsSpeaker"

class CustomTtsSpeaker(
    context: Context,
    private val aiEngine: VelvetAiEngine? = null
) {
    private var tts: TextToSpeech? = null
    private var isLocalReady = false
    private var currentTrack: AudioTrack? = null
    private var playbackJob: Job? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isSynthesizing = MutableStateFlow(false)
    val isSynthesizing: StateFlow<Boolean> = _isSynthesizing.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                isLocalReady = (status == TextToSpeech.SUCCESS)
                if (isLocalReady) {
                    tts?.setSpeechRate(1.08f)
                    tts?.setPitch(1.0f)
                    tts?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _isSpeaking.value = true
                        }

                        override fun onDone(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            _isSpeaking.value = false
                        }
                    })
                } else {
                    Log.w(TAG, "System TextToSpeech init status=$status")
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "System TextToSpeech creation failed", t)
        }
    }

    /**
     * Speaks text cleanly:
     * - Tries Velvet AI Voice (Gemini 3.1 Flash TTS) with a fast timeout when local TTS is ready
     *   (or full 45s timeout if local TTS is unavailable), so Read Aloud never hangs or stalls!
     */
    fun speak(
        scope: CoroutineScope,
        text: String,
        language: KeyboardLanguage = KeyboardLanguage.EN,
        preferFastLocal: Boolean = false,
        onError: (String) -> Unit = {}
    ) {
        val clean = text.trim()
        if (clean.isEmpty()) {
            onError("Nothing to read aloud.")
            return
        }

        stop()

        if (preferFastLocal && isLocalReady) {
            if (speakWithLocalTts(clean, language)) return
        }

        val engine = aiEngine
        if (engine != null) {
            playbackJob = scope.launch {
                _isSynthesizing.value = true
                // Use 12s budget when instant local TTS fallback is ready, or 45s otherwise
                val timeoutBudget = if (isLocalReady) 12_000L else 45_000L
                when (val result = engine.synthesizeSpeechPcm(clean, language, timeoutBudget)) {
                    is AiResult.Success -> {
                        _isSynthesizing.value = false
                        playPcmBytes(result.value.pcmBytes, result.value.sampleRateHz, onError)
                    }

                    is AiResult.Error -> {
                        _isSynthesizing.value = false
                        Log.w(TAG, "AI TTS fallback (${result.message}); using local TTS.")
                        val localStarted = speakWithLocalTts(clean, language)
                        if (!localStarted) {
                            onError(result.message)
                        }
                    }
                }
            }
        } else {
            val ok = speakWithLocalTts(clean, language)
            if (!ok) {
                onError("Text-to-speech is not available on this device.")
            }
        }
    }

    fun speak(text: String, language: KeyboardLanguage = KeyboardLanguage.EN) {
        speakWithLocalTts(text.trim(), language)
    }

    private suspend fun playPcmBytes(
        pcmBytes: ByteArray,
        sampleRateHz: Int,
        onError: (String) -> Unit
    ) {
        withContext(Dispatchers.IO) {
            var track: AudioTrack? = null
            try {
                val minBuf = AudioTrack.getMinBufferSize(
                    sampleRateHz,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(8192)

                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(sampleRateHz)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuf)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                currentTrack = track
                _isSpeaking.value = true
                track.play()

                var offset = 0
                while (offset < pcmBytes.size && _isSpeaking.value) {
                    val chunkSize = minOf(minBuf, pcmBytes.size - offset)
                    val written = track.write(pcmBytes, offset, chunkSize)
                    if (written <= 0) break
                    offset += written
                }

                try {
                    track.stop()
                } catch (_: Throwable) {
                }
            } catch (t: Throwable) {
                Log.e(TAG, "AudioTrack PCM playback failed", t)
                withContext(Dispatchers.Main) {
                    onError("Audio playback failed: ${t.localizedMessage ?: "unknown error"}")
                }
            } finally {
                _isSpeaking.value = false
                try {
                    track?.release()
                } catch (_: Throwable) {
                }
                if (currentTrack === track) {
                    currentTrack = null
                }
            }
        }
    }

    private fun speakWithLocalTts(text: String, language: KeyboardLanguage): Boolean {
        val engine = tts ?: return false
        if (!isLocalReady) return false
        return try {
            val targetLocale = Locale.forLanguageTag(language.bcp47Tag)
            val availability = engine.isLanguageAvailable(targetLocale)
            if (availability >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = targetLocale
            } else if (engine.isLanguageAvailable(Locale.US) >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = Locale.US
            } else {
                engine.language = Locale.getDefault()
            }
            _isSpeaking.value = true
            val res = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "velvet_tts_${System.currentTimeMillis()}")
            if (res != TextToSpeech.SUCCESS) {
                _isSpeaking.value = false
                false
            } else {
                true
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Local TTS speak error", t)
            _isSpeaking.value = false
            false
        }
    }

    fun stop() {
        _isSynthesizing.value = false
        _isSpeaking.value = false
        playbackJob?.cancel()
        playbackJob = null
        try {
            currentTrack?.pause()
            currentTrack?.flush()
            currentTrack?.stop()
            currentTrack?.release()
        } catch (_: Throwable) {
        }
        currentTrack = null
        try {
            tts?.stop()
        } catch (_: Throwable) {
        }
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (_: Throwable) {
        }
        tts = null
        isLocalReady = false
    }
}
