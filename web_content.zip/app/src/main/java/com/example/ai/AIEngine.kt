package com.example.ai

import com.example.data.api.GeminiApiClient

sealed class AIProcessingState {
    data class Status(val statusMessage: String) : AIProcessingState()
    data class Complete(val response: SuesaResponse, val detectedIntent: AppIntent) : AIProcessingState()
    data class Error(val errorMessage: String) : AIProcessingState()
}

/**
 * Suesa AI Ana Yapay Zekâ Motoru (AIEngine).
 * Telefon eylemlerini ("Google'ı aç", "YouTube'u aç", "Kamerayı aç")
 * doğrudan ve doğal bir şekilde ("Tamam.") onaylayarak çalıştırır.
 */
class AIEngine(
    private val apiClient: GeminiApiClient = GeminiApiClient()
) {
    val conversationEngine = ConversationEngine()
    val intentEngine = IntentEngine()
    val webSearchEngine = WebSearchEngine()
    val responseEngine = ResponseEngine(conversationEngine, apiClient)
    val memory = ConversationMemory()

    suspend fun processUserRequest(
        userPrompt: String,
        apiKey: String,
        imageBase64: String? = null,
        imageMimeType: String? = null,
        isWebSearchEnabled: Boolean = true,
        onStatusUpdate: (String) -> Unit
    ): AIProcessingState {
        val trimmed = userPrompt.trim()
        if (trimmed.isBlank() && imageBase64.isNullOrBlank()) {
            return AIProcessingState.Error("Lütfen bir soru yazın veya sesli komut verin.")
        }

        val hasImage = !imageBase64.isNullOrBlank()
        val detectedIntent = intentEngine.parse(trimmed, hasImage)

        // 1. Telefon Eylemleri ve Sistem Komutları (Doğal ve kısa onay: "Tamam.")
        when (detectedIntent) {
            is AppIntent.OpenApp -> {
                return AIProcessingState.Complete(
                    response = SuesaResponse(
                        text = "Tamam.",
                        isAction = true,
                        actionType = "OPEN_APP_${detectedIntent.appType.name}"
                    ),
                    detectedIntent = detectedIntent
                )
            }
            is AppIntent.OpenSetting -> {
                return AIProcessingState.Complete(
                    response = SuesaResponse(
                        text = "Tamam.",
                        isAction = true,
                        actionType = "OPEN_SETTING_${detectedIntent.settingType.name}"
                    ),
                    detectedIntent = detectedIntent
                )
            }
            is AppIntent.CallContact -> {
                return AIProcessingState.Complete(
                    response = SuesaResponse(
                        text = "${detectedIntent.targetNameOrNumber} aranıyor...",
                        isAction = true,
                        actionType = "CALL_CONTACT"
                    ),
                    detectedIntent = detectedIntent
                )
            }
            else -> {}
        }

        // 2. Canlı Web Araması
        var webSearchResult: WebSearchResult? = null
        if (detectedIntent is AppIntent.WebSearch && isWebSearchEnabled) {
            onStatusUpdate("Bir saniye, kontrol ediyorum.")
            try {
                webSearchResult = webSearchEngine.search(trimmed)
            } catch (e: Exception) {
                webSearchResult = WebSearchResult(
                    query = trimmed,
                    summary = "İnternet bağlantısı kurulamadığı için güncel bilgiyi kontrol edemedim. Ancak diğer sorularına yardımcı olabilirim.",
                    isSuccess = false
                )
            }
        }

        // 3. Doğal Yanıt Üretimi (Asla robotik şablon YOK!)
        return try {
            val generated = responseEngine.generate(
                prompt = trimmed,
                contextMessages = memory.getContextMessages(),
                apiKey = apiKey,
                webSearchResult = webSearchResult,
                imageBase64 = imageBase64,
                imageMimeType = imageMimeType
            )

            // Hafızaya ekle
            memory.addTurn("user", trimmed, imageBase64)
            memory.addTurn("assistant", generated.text)

            AIProcessingState.Complete(
                response = generated,
                detectedIntent = detectedIntent
            )
        } catch (e: Exception) {
            AIProcessingState.Complete(
                response = SuesaResponse(text = conversationEngine.generateResponse(trimmed)),
                detectedIntent = detectedIntent
            )
        }
    }
}
