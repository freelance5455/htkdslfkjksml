package com.example.ai

import android.graphics.Bitmap
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.GenerateContentResponse
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.ThinkingLevel
import com.google.firebase.ai.type.Tool
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.ai.type.thinkingConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "LuminaryAiService"
private const val PRIMARY_MODEL = "gemini-4-hydrogen"
private const val FALLBACK_MODEL = "gemini-3.5-flash-lite"
private const val FALLBACK_MODEL_SECONDARY = "gemini-2.5-flash"
private const val SUGGESTION_MODEL = "gemini-3.5-flash-lite"
private const val FIRST_TOKEN_TIMEOUT_MS = 8_000L
private const val DEEP_DIVE_FIRST_TOKEN_TIMEOUT_MS = 12_000L
private const val FALLBACK_FIRST_TOKEN_TIMEOUT_MS = 15_000L
private const val PRIMARY_STREAM_TIMEOUT_MS = 40_000L
private const val FALLBACK_STREAM_TIMEOUT_MS = 30_000L
private const val SUGGESTION_TIMEOUT_MS = 15_000L
private const val MAX_GROUNDING_SOURCES = 6

data class ChatHistoryTurn(
    val role: String,
    val text: String,
    val image: Bitmap? = null
)

private data class StreamAttemptSpec(
    val modelName: String,
    val useThinkingConfig: Boolean,
    val enableGoogleSearch: Boolean,
    val firstTokenTimeoutMs: Long,
    val overallTimeoutMs: Long
)

class LuminaryAiService {

    private val baseSystemPrompt = """
        You are Luminary, an accurate, thoughtful, and versatile AI assistant built to answer any question across science, technology, history, culture, math, writing, coding, and everyday life.
        You have live Google Search grounding enabled for real-time information such as current news, weather, live scores, prices, schedules, and recent events. Always use the current date and time provided with the user's message and search the web whenever up-to-date or real-world facts are needed.
        Format answers cleanly using Markdown headings, bullet lists, bold key terms, and fenced code blocks where appropriate.
        If a question is ambiguous, state the most likely interpretation and answer directly. Never fabricate citations or pretend to know uncertain facts; state uncertainty clearly.
    """.trimIndent()

    private val ungroundedSystemPrompt = """
        You are Luminary, an accurate, thoughtful, and versatile AI assistant built to answer any question across science, technology, history, culture, math, writing, coding, and everyday life.
        Live web search grounding is temporarily unavailable for this request due to API quota limits. Use the current date/time provided for context, answer directly from your knowledge where confident, and if a question strictly requires live real-time data (such as today's breaking news, live scores, or current weather), clearly state that live search is currently unavailable under the active quota.
        Format answers cleanly using Markdown headings, bullet lists, bold key terms, and fenced code blocks where appropriate.
        Never fabricate citations or pretend to know uncertain real-time facts.
    """.trimIndent()

    private val modelCache = ConcurrentHashMap<String, GenerativeModel>()

    private val followUpSchema = Schema.obj(
        properties = mapOf(
            "followUps" to Schema.array(
                items = Schema.string(description = "Short natural follow-up question under 9 words"),
                description = "3 relevant follow-up questions the user might want to ask next"
            )
        )
    )

    private val suggestionModel by lazy {
        Firebase.ai.generativeModel(
            modelName = SUGGESTION_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = followUpSchema
                thinkingConfig = thinkingConfig {
                    thinkingBudget = 0
                }
            }
        )
    }

    fun warmUp(defaultMode: AnswerMode = AnswerMode.BALANCED) {
        runCatching {
            getOrCreateModel(PRIMARY_MODEL, defaultMode, useThinkingConfig = true, enableGoogleSearch = true)
            getOrCreateModel(FALLBACK_MODEL, defaultMode, useThinkingConfig = false, enableGoogleSearch = true)
        }
    }

    private fun getOrCreateModel(
        modelName: String,
        mode: AnswerMode,
        useThinkingConfig: Boolean,
        enableGoogleSearch: Boolean
    ): GenerativeModel {
        val cacheKey = "$modelName:${mode.name}:$useThinkingConfig:$enableGoogleSearch"
        return modelCache.getOrPut(cacheKey) {
            val config = if (useThinkingConfig) {
                generationConfig {
                    thinkingConfig = thinkingConfig {
                        thinkingLevel = if (mode == AnswerMode.DEEP_DIVE) {
                            ThinkingLevel.MEDIUM
                        } else {
                            ThinkingLevel.LOW
                        }
                    }
                }
            } else {
                null
            }
            val sysPrompt = if (enableGoogleSearch) baseSystemPrompt else ungroundedSystemPrompt
            Firebase.ai.generativeModel(
                modelName = modelName,
                generationConfig = config,
                tools = if (enableGoogleSearch) listOf(Tool.googleSearch()) else emptyList(),
                systemInstruction = content {
                    text("$sysPrompt\n\nResponse style requirement: ${mode.instructionSuffix}")
                }
            )
        }
    }

    private fun sanitizeHistory(history: List<ChatHistoryTurn>): List<Content> {
        val validTurns = mutableListOf<ChatHistoryTurn>()
        for (turn in history) {
            if (turn.text.isBlank() && turn.image == null) continue
            val expectedRole = if (validTurns.size % 2 == 0) "user" else "model"
            if (turn.role == expectedRole) {
                validTurns.add(turn)
            } else if (turn.role == "user" && validTurns.lastOrNull()?.role == "user") {
                validTurns[validTurns.lastIndex] = turn
            }
        }
        if (validTurns.lastOrNull()?.role == "user") {
            validTurns.removeAt(validTurns.lastIndex)
        }
        return validTurns.map { turn ->
            content(role = turn.role) {
                if (turn.image != null && turn.role == "user") {
                    image(turn.image)
                }
                if (turn.text.isNotBlank()) {
                    text(turn.text)
                }
            }
        }
    }

    private fun currentTimestampContext(): String {
        val formatter = SimpleDateFormat("EEEE, MMMM d, yyyy 'at' HH:mm z", Locale.getDefault())
        return "[Current local date and time: ${formatter.format(Date())}]"
    }

    private fun collectWebSources(
        response: GenerateContentResponse,
        sources: LinkedHashMap<String, String>
    ) {
        val chunks = response.candidates.firstOrNull()?.groundingMetadata?.groundingChunks ?: return
        for (chunk in chunks) {
            val web = chunk.web ?: continue
            val uri = web.uri?.trim().orEmpty()
            if ((uri.startsWith("https://", ignoreCase = true) || uri.startsWith("http://", ignoreCase = true)) &&
                !sources.containsKey(uri)
            ) {
                val safeTitle = web.title
                    ?.replace("[", "(")
                    ?.replace("]", ")")
                    ?.replace(Regex("\\s+"), " ")
                    ?.trim()
                    .orEmpty()
                sources[uri] = safeTitle.ifBlank { uri }
            }
        }
    }

    private fun formatSourcesMarkdown(sources: Map<String, String>): String {
        if (sources.isEmpty()) return ""
        return buildString {
            append("\n\n### Sources\n")
            sources.entries.take(MAX_GROUNDING_SOURCES).forEach { (uri, title) ->
                append("- [$title]($uri)\n")
            }
        }.trimEnd()
    }

    private fun isQuotaOrBillingError(t: Throwable): Boolean {
        var cur: Throwable? = t
        while (cur != null) {
            val msg = cur.message.orEmpty().lowercase(Locale.ROOT)
            if (msg.contains("quota") ||
                msg.contains("429") ||
                msg.contains("resource_exhausted") ||
                msg.contains("resource exhausted") ||
                msg.contains("billing") ||
                msg.contains("rate limit") ||
                msg.contains("limit: 0")
            ) {
                return true
            }
            cur = cur.cause
        }
        return false
    }

    fun askStreaming(
        question: String,
        attachedImage: Bitmap?,
        history: List<ChatHistoryTurn>,
        mode: AnswerMode
    ): Flow<String> = channelFlow {
        val sdkHistory = sanitizeHistory(history)
        val userMessageContent = content("user") {
            if (attachedImage != null) {
                image(attachedImage)
            }
            val effectivePrompt = question.ifBlank {
                "Describe and explain what is shown in this image."
            }
            text("${currentTimestampContext()}\n\n$effectivePrompt")
        }

        val primaryFirstTokenTimeout = if (mode == AnswerMode.DEEP_DIVE) {
            DEEP_DIVE_FIRST_TOKEN_TIMEOUT_MS
        } else {
            FIRST_TOKEN_TIMEOUT_MS
        }

        val attempts = listOf(
            StreamAttemptSpec(
                modelName = PRIMARY_MODEL,
                useThinkingConfig = true,
                enableGoogleSearch = true,
                firstTokenTimeoutMs = primaryFirstTokenTimeout,
                overallTimeoutMs = PRIMARY_STREAM_TIMEOUT_MS
            ),
            StreamAttemptSpec(
                modelName = FALLBACK_MODEL,
                useThinkingConfig = false,
                enableGoogleSearch = true,
                firstTokenTimeoutMs = FALLBACK_FIRST_TOKEN_TIMEOUT_MS,
                overallTimeoutMs = FALLBACK_STREAM_TIMEOUT_MS
            ),
            StreamAttemptSpec(
                modelName = FALLBACK_MODEL_SECONDARY,
                useThinkingConfig = false,
                enableGoogleSearch = true,
                firstTokenTimeoutMs = FALLBACK_FIRST_TOKEN_TIMEOUT_MS,
                overallTimeoutMs = FALLBACK_STREAM_TIMEOUT_MS
            ),
            StreamAttemptSpec(
                modelName = FALLBACK_MODEL,
                useThinkingConfig = false,
                enableGoogleSearch = false,
                firstTokenTimeoutMs = FALLBACK_FIRST_TOKEN_TIMEOUT_MS,
                overallTimeoutMs = FALLBACK_STREAM_TIMEOUT_MS
            ),
            StreamAttemptSpec(
                modelName = FALLBACK_MODEL_SECONDARY,
                useThinkingConfig = false,
                enableGoogleSearch = false,
                firstTokenTimeoutMs = FALLBACK_FIRST_TOKEN_TIMEOUT_MS,
                overallTimeoutMs = FALLBACK_STREAM_TIMEOUT_MS
            )
        )

        var lastError: Throwable? = null
        var groundingQuotaFailed = false

        for (spec in attempts) {
            currentCoroutineContext().ensureActive()

            val accumulated = StringBuilder()
            val webSources = LinkedHashMap<String, String>()
            var firstTokenReceived = false
            var streamFailure: Throwable? = null

            Log.d(
                TAG,
                "Starting Gemini stream (${spec.modelName}, mode=${mode.name}, search=${spec.enableGoogleSearch}, history=${sdkHistory.size})"
            )
            val chat = getOrCreateModel(
                modelName = spec.modelName,
                mode = mode,
                useThinkingConfig = spec.useThinkingConfig,
                enableGoogleSearch = spec.enableGoogleSearch
            ).startChat(history = sdkHistory)

            val streamJob = launch {
                try {
                    chat.sendMessageStream(userMessageContent).collect { chunk ->
                        collectWebSources(chunk, webSources)
                        val delta = chunk.text.orEmpty()
                        if (delta.isNotEmpty()) {
                            if (!firstTokenReceived) {
                                firstTokenReceived = true
                                Log.d(TAG, "First chunk received from ${spec.modelName}")
                            }
                            accumulated.append(delta)
                            send(accumulated.toString())
                        }
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (t: Throwable) {
                    streamFailure = t
                }
            }

            val firstTokenWatchdog = launch {
                delay(spec.firstTokenTimeoutMs)
                if (!firstTokenReceived) {
                    Log.w(TAG, "${spec.modelName} timed out waiting for first token (${spec.firstTokenTimeoutMs}ms).")
                    streamJob.cancel(CancellationException("FirstTokenTimeout"))
                }
            }
            val overallWatchdog = launch {
                delay(spec.overallTimeoutMs)
                if (streamJob.isActive) {
                    Log.w(TAG, "${spec.modelName} hit overall ${spec.overallTimeoutMs}ms stream limit.")
                    streamJob.cancel(CancellationException("OverallStreamTimeout"))
                }
            }

            try {
                streamJob.join()
            } finally {
                firstTokenWatchdog.cancel()
                overallWatchdog.cancel()
            }

            currentCoroutineContext().ensureActive()

            if (accumulated.isNotBlank()) {
                if (streamFailure != null) {
                    Log.w(TAG, "${spec.modelName} interrupted after partial output; preserving response.", streamFailure)
                }
                val sourcesSection = formatSourcesMarkdown(webSources)
                if (sourcesSection.isNotBlank()) {
                    accumulated.append(sourcesSection)
                    send(accumulated.toString())
                } else if (!spec.enableGoogleSearch && groundingQuotaFailed) {
                    accumulated.append("\n\n> *Answered without live web search because search grounding quota is currently exceeded.*")
                    send(accumulated.toString())
                }
                return@channelFlow
            }

            val failure = streamFailure
            if (failure != null) {
                lastError = failure
                if (spec.enableGoogleSearch && isQuotaOrBillingError(failure)) {
                    groundingQuotaFailed = true
                }
                Log.w(
                    TAG,
                    "Attempt (${spec.modelName}, search=${spec.enableGoogleSearch}) failed before emitting output: ${failure.message}",
                    failure
                )
            }
        }

        val finalErr = lastError
        if (finalErr != null && isQuotaOrBillingError(finalErr)) {
            throw IllegalStateException(
                "Gemini API quota exceeded for this project or billing tier. Please check your plan and billing details in Google Cloud / AI Studio, or try again shortly.",
                finalErr
            )
        }
        throw finalErr ?: IllegalStateException("The AI returned an empty response. Please try rephrasing your question.")
    }.flowOn(Dispatchers.IO)

    suspend fun generateFollowUps(question: String, answer: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val snippet = answer.take(1200)
            val prompt = """
                Based on this Q&A, suggest 3 concise, interesting follow-up questions the user might ask next (each under 9 words, no numbering).
                Question: $question
                Answer: $snippet
            """.trimIndent()

            val response = withTimeout(SUGGESTION_TIMEOUT_MS) {
                suggestionModel.generateContent(prompt)
            }
            val rawJson = response.text ?: return@withContext emptyList()
            val json = JSONObject(rawJson)
            val arr = json.optJSONArray("followUps") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val item = arr.optString(i).trim()
                    if (item.isNotBlank()) add(item)
                }
            }.take(3)
        } catch (e: CancellationException) {
            if (e is TimeoutCancellationException) {
                Log.w(TAG, "Follow-up suggestion generation timed out", e)
                emptyList()
            } else {
                throw e
            }
        } catch (e: Exception) {
            Log.w(TAG, "Follow-up suggestion generation failed", e)
            emptyList()
        }
    }
}
