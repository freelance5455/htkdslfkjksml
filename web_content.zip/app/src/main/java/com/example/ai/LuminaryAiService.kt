package com.example.ai

import android.graphics.Bitmap
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.GenerativeModel
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.ThinkingLevel
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.ai.type.thinkingConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "LuminaryAiService"
private const val PRIMARY_MODEL = "gemini-3.8-flash"
private const val FALLBACK_MODEL = "gemini-3.5-flash-lite"
private const val SUGGESTION_MODEL = "gemini-3.5-flash-lite"
private const val PRIMARY_STREAM_TIMEOUT_MS = 30_000L
private const val FALLBACK_STREAM_TIMEOUT_MS = 30_000L
private const val SUGGESTION_TIMEOUT_MS = 15_000L

data class ChatHistoryTurn(
    val role: String,
    val text: String,
    val image: Bitmap? = null
)

class LuminaryAiService {

    private val baseSystemPrompt = """
        You are Luminary, an accurate, thoughtful, and versatile AI assistant built to answer any question across science, technology, history, culture, math, writing, coding, and everyday life.
        Format answers cleanly using Markdown headings, bullet lists, bold key terms, and fenced code blocks where appropriate.
        If a question is ambiguous, state the most likely interpretation and answer directly. Never fabricate citations or pretend to know uncertain facts; state uncertainty clearly.
    """.trimIndent()

    private val modelCache = ConcurrentHashMap<String, GenerativeModel>()

    private val followUpSchema = Schema.obj(
        properties = mapOf(
            "followUps" to Schema.array(
                items = Schema.string(description = "Short natural follow-up question under 9 words"),
                description = "3 relevant follow-up questions the user might want to ask next"
            )
        )
    )

    private val suggestionModel by lazy {
        Firebase.ai.generativeModel(
            modelName = SUGGESTION_MODEL,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = followUpSchema
                thinkingConfig = thinkingConfig {
                    thinkingBudget = 0
                }
            }
        )
    }

    private fun getOrCreateModel(modelName: String, mode: AnswerMode, useThinkingConfig: Boolean): GenerativeModel {
        val cacheKey = "$modelName:${mode.name}:$useThinkingConfig"
        return modelCache.getOrPut(cacheKey) {
            val config = if (useThinkingConfig) {
                generationConfig {
                    thinkingConfig = thinkingConfig {
                        thinkingLevel = if (mode == AnswerMode.DEEP_DIVE) {
                            ThinkingLevel.LOW
                        } else {
                            ThinkingLevel.MINIMAL
                        }
                    }
                }
            } else {
                null
            }
            Firebase.ai.generativeModel(
                modelName = modelName,
                generationConfig = config,
                systemInstruction = content {
                    text("$baseSystemPrompt\n\nResponse style requirement: ${mode.instructionSuffix}")
                }
            )
        }
    }

    private fun sanitizeHistory(history: List<ChatHistoryTurn>): List<Content> {
        val validTurns = mutableListOf<ChatHistoryTurn>()
        for (turn in history) {
            if (turn.text.isBlank() && turn.image == null) continue
            val expectedRole = if (validTurns.size % 2 == 0) "user" else "model"
            if (turn.role == expectedRole) {
                validTurns.add(turn)
            } else if (turn.role == "user" && validTurns.lastOrNull()?.role == "user") {
                validTurns[validTurns.lastIndex] = turn
            }
        }
        if (validTurns.lastOrNull()?.role == "user") {
            validTurns.removeAt(validTurns.lastIndex)
        }
        return validTurns.map { turn ->
            content(role = turn.role) {
                if (turn.image != null && turn.role == "user") {
                    image(turn.image)
                }
                if (turn.text.isNotBlank()) {
                    text(turn.text)
                }
            }
        }
    }

    fun askStreaming(
        question: String,
        attachedImage: Bitmap?,
        history: List<ChatHistoryTurn>,
        mode: AnswerMode
    ): Flow<String> = flow {
        val sdkHistory = sanitizeHistory(history)
        val userMessageContent = content("user") {
            if (attachedImage != null) {
                image(attachedImage)
            }
            val effectivePrompt = question.ifBlank {
                "Describe and explain what is shown in this image."
            }
            text(effectivePrompt)
        }

        val accumulated = StringBuilder()
        var needsFallback = false

        try {
            Log.d(TAG, "Starting Gemini stream ($PRIMARY_MODEL, mode=${mode.name}, history=${sdkHistory.size})")
            val primaryChat = getOrCreateModel(PRIMARY_MODEL, mode, useThinkingConfig = true)
                .startChat(history = sdkHistory)
            withTimeout(PRIMARY_STREAM_TIMEOUT_MS) {
                primaryChat.sendMessageStream(userMessageContent).collect { chunk ->
                    val delta = chunk.text.orEmpty()
                    if (delta.isNotEmpty()) {
                        if (accumulated.isEmpty()) {
                            Log.d(TAG, "First chunk received from $PRIMARY_MODEL")
                        }
                        accumulated.append(delta)
                        emit(accumulated.toString())
                    }
                }
            }
        } catch (e: TimeoutCancellationException) {
            if (accumulated.isNotBlank()) {
                Log.w(TAG, "Primary stream hit timeout after receiving partial output; preserving response.", e)
                return@flow
            }
            Log.w(TAG, "Primary model stream timed out before first token; falling back to $FALLBACK_MODEL.", e)
            needsFallback = true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (accumulated.isNotBlank()) {
                Log.w(TAG, "Primary stream interrupted after partial output; preserving response.", e)
                return@flow
            }
            Log.w(TAG, "Primary model failed before emitting output; falling back to $FALLBACK_MODEL.", e)
            needsFallback = true
        }

        if (needsFallback) {
            val fallbackChat = getOrCreateModel(FALLBACK_MODEL, mode, useThinkingConfig = false)
                .startChat(history = sdkHistory)
            withTimeout(FALLBACK_STREAM_TIMEOUT_MS) {
                fallbackChat.sendMessageStream(userMessageContent).collect { chunk ->
                    val delta = chunk.text.orEmpty()
                    if (delta.isNotEmpty()) {
                        accumulated.append(delta)
                        emit(accumulated.toString())
                    }
                }
            }
        }

        if (accumulated.isBlank()) {
            throw IllegalStateException("The AI returned an empty response. Please try rephrasing your question.")
        }
    }.flowOn(Dispatchers.IO)

    suspend fun generateFollowUps(question: String, answer: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val snippet = answer.take(1200)
            val prompt = """
                Based on this Q&A, suggest 3 concise, interesting follow-up questions the user might ask next (each under 9 words, no numbering).
                Question: $question
                Answer: $snippet
            """.trimIndent()

            val response = withTimeout(SUGGESTION_TIMEOUT_MS) {
                suggestionModel.generateContent(prompt)
            }
            val rawJson = response.text ?: return@withContext emptyList()
            val json = JSONObject(rawJson)
            val arr = json.optJSONArray("followUps") ?: return@withContext emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val item = arr.optString(i).trim()
                    if (item.isNotBlank()) add(item)
                }
            }.take(3)
        } catch (e: CancellationException) {
            if (e is TimeoutCancellationException) {
                Log.w(TAG, "Follow-up suggestion generation timed out", e)
                emptyList()
            } else {
                throw e
            }
        } catch (e: Exception) {
            Log.w(TAG, "Follow-up suggestion generation failed", e)
            emptyList()
        }
    }
}
