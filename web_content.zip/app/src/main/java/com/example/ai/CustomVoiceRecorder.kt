package com.example.ai

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

class CustomVoiceRecorder(private val context: Context) {

    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    private var activeSampleRate = 16000
    private var audioRecord: AudioRecord? = null
    private var recordingJob: Job? = null
    private val pcmStream = ByteArrayOutputStream()

    private val _amplitude = MutableStateFlow(0f)
    val amplitude: StateFlow<Float> = _amplitude.asStateFlow()

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    fun hasMicPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    fun startRecording(scope: CoroutineScope): Boolean {
        if (!hasMicPermission()) return false
        if (_isRecording.value) return true

        val candidateRates = intArrayOf(16000, 44100, 48000)
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.DEFAULT
        )

        var initializedRecorder: AudioRecord? = null
        var chosenRate = 16000
        var chosenBufBytes = 4096

        outer@ for (rate in candidateRates) {
            val rawMinBuf = try {
                AudioRecord.getMinBufferSize(rate, channelConfig, audioFormat)
            } catch (_: Throwable) {
                -1
            }
            if (rawMinBuf <= 0) continue
            val bufferBytes = (rawMinBuf * 2).coerceAtLeast(4096)

            for (src in sources) {
                try {
                    val candidate = AudioRecord(
                        src,
                        rate,
                        channelConfig,
                        audioFormat,
                        bufferBytes
                    )
                    if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                        initializedRecorder = candidate
                        chosenRate = rate
                        chosenBufBytes = bufferBytes
                        break@outer
                    } else {
                        candidate.release()
                    }
                } catch (_: Throwable) {
                }
            }
        }

        val recorder = initializedRecorder ?: return false
        activeSampleRate = chosenRate

        synchronized(pcmStream) {
            pcmStream.reset()
        }
        audioRecord = recorder

        try {
            recorder.startRecording()
        } catch (_: Throwable) {
            try {
                recorder.release()
            } catch (_: Throwable) {
            }
            audioRecord = null
            return false
        }

        _isRecording.value = true

        recordingJob = scope.launch(Dispatchers.IO) {
            val buffer = ShortArray((chosenBufBytes / 2).coerceAtLeast(1024))
            val byteBuffer = ByteArray(buffer.size * 2)

            while (isActive && _isRecording.value) {
                val read = try {
                    recorder.read(buffer, 0, buffer.size)
                } catch (_: Throwable) {
                    -1
                }
                if (read > 0) {
                    var sumSq = 0.0
                    for (i in 0 until read) {
                        val s = buffer[i]
                        sumSq += (s * s).toDouble()
                        byteBuffer[i * 2] = (s.toInt() and 0xFF).toByte()
                        byteBuffer[i * 2 + 1] = ((s.toInt() shr 8) and 0xFF).toByte()
                    }
                    synchronized(pcmStream) {
                        pcmStream.write(byteBuffer, 0, read * 2)
                    }
                    val rms = sqrt(sumSq / read).toFloat()
                    _amplitude.value = (rms / 4500f).coerceIn(0.05f, 1f)
                } else if (read < 0) {
                    break
                }
            }
        }
        return true
    }

    fun stopAndBuildWav(): ByteArray {
        _isRecording.value = false
        _amplitude.value = 0f
        recordingJob?.cancel()
        recordingJob = null

        try {
            audioRecord?.stop()
        } catch (_: Throwable) {
        }
        try {
            audioRecord?.release()
        } catch (_: Throwable) {
        }
        audioRecord = null

        val pcmData = synchronized(pcmStream) {
            val bytes = pcmStream.toByteArray()
            pcmStream.reset()
            bytes
        }
        if (pcmData.isEmpty()) return ByteArray(0)
        val (uploadPcm, uploadRate) = downsampleIfHighRate(pcmData, activeSampleRate)
        return wrapPcmAsWav(uploadPcm, uploadRate)
    }

    private fun downsampleIfHighRate(pcm: ByteArray, rate: Int): Pair<ByteArray, Int> {
        val factor = when {
            rate >= 44000 -> 3
            rate >= 30000 -> 2
            else -> 1
        }
        if (factor == 1) return pcm to rate
        val sampleCount = pcm.size / 2
        val outCount = sampleCount / factor
        if (outCount <= 0) return pcm to rate
        val out = ByteArray(outCount * 2)
        for (i in 0 until outCount) {
            val srcIdx = (i * factor) * 2
            out[i * 2] = pcm[srcIdx]
            out[i * 2 + 1] = pcm[srcIdx + 1]
        }
        return out to (rate / factor)
    }

    fun cancel() {
        _isRecording.value = false
        _amplitude.value = 0f
        recordingJob?.cancel()
        recordingJob = null
        try {
            audioRecord?.stop()
        } catch (_: Throwable) {
        }
        try {
            audioRecord?.release()
        } catch (_: Throwable) {
        }
        audioRecord = null
        synchronized(pcmStream) { pcmStream.reset() }
    }

    private fun wrapPcmAsWav(pcm: ByteArray, sampleRate: Int): ByteArray {
        val totalDataLen = pcm.size + 36
        val byteRate = sampleRate * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16)
            putShort(1)
            putShort(1)
            putInt(sampleRate)
            putInt(byteRate)
            putShort(2)
            putShort(16)
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcm.size)
        }.array()

        return header + pcm
    }
}
