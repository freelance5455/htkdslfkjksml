package com.example.ai

import java.util.Locale
import java.util.regex.Pattern

/**
 * Suesa AI Doğal Konuşma Motoru (ConversationEngine).
 * Asla robotik şablonlar ("Sorunu değerlendirdim...", "Mesajını değerlendirdim...", "Komut vermen yeterli...") kullanmaz.
 * Kullanıcıyla samimi, kısa ve akıcı Türkçe konuşur.
 */
class ConversationEngine {

    private var lastGreetingIndex = 0
    private var lastAnswer: String = ""

    private val stories = listOf(
        """
        **Yıldızların Ötesindeki Sır**
        
        Küçük bir köyde yaşayan genç saat ustası Eren, geceleri gökyüzünü izlemeyi çok severdi. Eski bir saatin kasasında pirinç bir anahtar ve soluk bir harita buldu. Harita onu terk edilmiş kadim gözlemevine götürdü.
        
        Anahtarı devasa teleskoba yerleştirdiğinde gök kubbe usulca açıldı. Mercekten baktığında yıldızların arasında sessizce parıldayan ışık nehirlerini gördü. Evrenin insanların düşündüğünden çok daha büyüleyici ve keşfedilmeyi bekleyen sırlar barındırdığını o gece anladı.
        """.trimIndent(),
        """
        **Işık Bahçesi**
        
        Gökdelenlerin çevrelediği gri bir şehirde yaşayan Leyla, eski bir metro tünelinin ardında parıldayan gizli bir kapı keşfetti.
        
        İçeride çiçeklerin melodiler fısıldadığı, yaprakların insanların tebessümleriyle ışıldadığı parlayan bir bahçe vardı. Oradaki yaşlı bekçi robot gülümsedi: "Burası doğayla geleceğin barıştığı yerdir." Leyla o günden sonra şehrin betonlarına inat, insanların kalbindeki o gizli ışığı büyütmeye söz verdi.
        """.trimIndent()
    )

    private val jokes = listOf(
        "Temel bir gün uçağa binmiş. Yanındaki yolcuya sormuş: 'Hemşerim bu uçak nereye gidiyor?' Yolcu: 'Ankara'ya,' demiş. Temel başını sallamış: 'Ula teknolojiye bak! Ben arkada oturuyorum İstanbul'a gidiyorum, sen önde oturuyorsun Ankara'ya gidiyorsun!' 😄",
        "Yapay zekâya sormuşlar: 'En sevdiğin yemek ne?' Cevap vermiş: 'Byte boyu pizza, yanında da biraz RAM salatası!' 🤖🍕",
        "Nasreddin Hoca'ya sormuşlar: 'Hocam, dünya kaç metre?' Hoca hemen cevap vermiş: 'Şu minare boyunda bir ip getirin, ölçüp söyleyeyim!' 😂"
    )

    fun generateResponse(userQuery: String): String {
        val q = userQuery.lowercase(Locale.forLanguageTag("tr-TR")).trim()
        val clean = q.replace(Regex("[.,!?;:'\"’*#_`]"), " ").replace(Regex("\\s+"), " ").trim()

        // 1. Selamlaşmalar ("sa", "selam", "merhaba", "slm", "günaydın", vb.)
        if (isGreeting(clean)) {
            return getNaturalGreeting(clean)
        }

        // 2. Hal-Hatır Sorma ("nasılsın", "naber", "ne haber", "nasıl gidiyor")
        if (isSmallTalk(clean)) {
            return getNaturalSmallTalk(clean)
        }

        // 3. Can sıkıntısı / dertleşme
        if (clean.contains("canım sıkılıyor") || clean.contains("canim sikiliyor") || clean.contains("sıkıldım") || clean.contains("sikildim")) {
            return "O zaman biraz sohbet edelim 😄 Ne hakkında konuşmak istersin? İster oyunlardan, ister bilimden bahsedelim, istersen sana bir hikâye veya şaka anlatayım!"
        }

        // 4. İsim / Kimlik ("senin adın ne", "sen kimsin", "adın ne", "ismin ne")
        if (isIdentity(clean)) {
            return "Ben Suesa. 😄"
        }

        // 5. Yaş ("kaç yaşındasın", "yaşın kaç")
        if (clean.contains("kaç yaşındasın") || clean.contains("kac yasindasin") || clean.contains("yaşın kaç") || clean.contains("yasin kac")) {
            return "Benim insanlardaki gibi bir yaşım yok 😄 Dijital dünyada her zaman gencim!"
        }

        // 6. Ne yapabilirsin / Yetenekler
        if (clean.contains("ne yapabilirsin") || clean.contains("neler yapabilirsin") || clean.contains("özelliklerin") || clean.contains("yeteneklerin")) {
            return "Seninle sohbet edebilir, telefonundaki uygulamaları (YouTube, Google, Kamera vb.) açabilir, rehberinden kişileri arayabilir, internette güncel bilgi arayabilir veya sorularını yanıtlayabilirim. Ne yapmak istersin? 😄"
        }

        // 7. Matematik ("2+2 kaç?", "50*4", "100/5", vb.)
        val mathResult = evaluateMathExpression(userQuery)
        if (mathResult != null) {
            return mathResult
        }

        // 8. Şaka / Fıkra
        if (clean.contains("şaka yap") || clean.contains("saka yap") || clean.contains("bir şaka") || clean.contains("fıkra anlat") || clean.contains("fikra anlat") || clean == "şaka" || clean == "fıkra") {
            return jokes.random()
        }

        // 9. Hikâye
        if (clean.contains("hikaye anlat") || clean.contains("hikâye anlat") || clean.contains("masal anlat") || clean.contains("bir hikaye") || clean.contains("kısa bir hikaye")) {
            return stories.random()
        }

        // 10. Şiir
        if (clean.contains("şiir yaz") || clean.contains("siir yaz") || clean.contains("şiir oku")) {
            return """
                Gökyüzü mavi bir defter gibi,
                Yıldızlar gecenin gümüş kalemi.
                Bir dokunuşla başlar hayaller,
                Gülümse yeter ki her yeni güne! 🌟
            """.trimIndent()
        }

        // 11. Teşekkür / Övgü
        if (clean.contains("teşekkür") || clean.contains("tesekkur") || clean.contains("sağ ol") || clean.contains("sağol") || clean.contains("eyvallah")) {
            return "Rica ederim 😄"
        }

        if (clean.contains("harikasın") || clean.contains("harikasin") || clean.contains("adamsın") || clean.contains("süpersin") || clean.contains("aferin")) {
            return "Teşekkür ederim, seninle olmak çok keyifli! 😄"
        }

        // 12. Görüşürüz / Hoşçakal
        if (clean.contains("görüşürüz") || clean.contains("gorusuruz") || clean.contains("hoşçakal") || clean.contains("hoscakal") || clean.contains("bay bay") || clean.contains("iyi geceler")) {
            return "Görüşmek üzere! 👋 Kendine iyi bak."
        }

        // 13. Minecraft
        val mcAnswer = checkMinecraftKnowledge(clean)
        if (mcAnswer != null) {
            return mcAnswer
        }

        // 14. Genel Bilim / Coğrafya
        val scienceAnswer = checkGeneralKnowledge(clean)
        if (scienceAnswer != null) {
            return scienceAnswer
        }

        // 15. Doğal ve doğrudan yanıt (Kesinlikle robotik şablon DEĞİL!)
        return generateCleanDirectResponse(clean, userQuery)
    }

    private fun isGreeting(clean: String): Boolean {
        return clean in listOf("sa", "s a", "selam", "slm", "merhaba", "merhabalar", "hey", "günaydın", "gunaydin", "iyi günler", "iyi gunler", "iyi akşamlar", "suesa", "merhaba suesa", "selam suesa", "hey suesa") ||
                clean.startsWith("sa ") || clean.startsWith("selam ") || clean.startsWith("merhaba ")
    }

    private fun getNaturalGreeting(clean: String): String {
        if (clean == "sa" || clean == "s a") {
            return "Aleyküm selam 😄"
        }
        if (clean == "merhaba" || clean.startsWith("merhaba")) {
            return "Merhaba! 👋"
        }

        // Variation for consecutive greetings
        val variations = listOf(
            "Selam 😄",
            "Selam! Nasılsın?",
            "Selam yine 😄",
            "Buradayım, selam! 👋"
        )
        val selected = variations[lastGreetingIndex % variations.size]
        lastGreetingIndex++
        return selected
    }

    private fun isSmallTalk(clean: String): Boolean {
        return clean in listOf("nasılsın", "nasilsin", "naber", "ne haber", "nasıl gidiyor", "nasil gidiyor", "ne yapıyorsun", "ne yapiyorsun", "keyifler nasıl") ||
                clean.contains("nasılsın") || clean.contains("nasilsin") || clean.contains("naber") || clean.contains("nasıl gidiyor")
    }

    private fun getNaturalSmallTalk(clean: String): String {
        if (clean.contains("naber") || clean.contains("ne haber")) {
            return "İyi gidiyor 😄 Sende naber?"
        }
        return "İyiyim 😄 Sen nasılsın?"
    }

    private fun isIdentity(clean: String): Boolean {
        return clean in listOf("sen kimsin", "adın ne", "adin ne", "ismin ne", "senin adın ne", "senin adin ne", "sen nesin", "kimsin") ||
                clean.contains("senin adın ne") || clean.contains("adın ne") || clean.contains("sen kimsin")
    }

    fun evaluateMathExpression(raw: String): String? {
        val clean = raw.lowercase(Locale.forLanguageTag("tr-TR"))
            .replace("?", "")
            .replace("!", "")
            .replace("kaçtır", "")
            .replace("kactir", "")
            .replace("kaç eder", "")
            .replace("kac eder", "")
            .replace("kaç", "")
            .replace("kac", "")
            .replace("nedir", "")
            .replace("hesapla", "")
            .replace("çarpı", "*")
            .replace("carpi", "*")
            .replace("kere", "*")
            .replace("artı", "+")
            .replace("arti", "+")
            .replace("topla", "+")
            .replace("eksi", "-")
            .replace("çıkar", "-")
            .replace("bölü", "/")
            .replace("bolu", "/")
            .replace("böl", "/")
            .trim()

        val pattern = Pattern.compile("^\\s*([0-9]+(?:\\.[0-9]+)?)\\s*([+\\-*/xX])\\s*([0-9]+(?:\\.[0-9]+)?)\\s*$")
        val matcher = pattern.matcher(clean)
        if (matcher.find()) {
            val num1 = matcher.group(1)?.toDoubleOrNull() ?: return null
            val op = matcher.group(2) ?: return null
            val num2 = matcher.group(3)?.toDoubleOrNull() ?: return null

            val result = when (op) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "*", "x", "X" -> num1 * num2
                "/" -> if (num2 != 0.0) num1 / num2 else return "Sıfıra bölünemez."
                else -> return null
            }

            return if (result % 1.0 == 0.0) {
                result.toLong().toString()
            } else {
                String.format(Locale.US, "%.2f", result)
            }
        }

        if (raw.contains("karekök", ignoreCase = true) || raw.contains("karekok", ignoreCase = true)) {
            val numMatcher = Pattern.compile("(\\d+)").matcher(raw)
            if (numMatcher.find()) {
                val n = numMatcher.group(1)?.toDoubleOrNull()
                if (n != null && n >= 0) {
                    val root = Math.sqrt(n)
                    return if (root % 1.0 == 0.0) root.toLong().toString() else String.format(Locale.US, "%.2f", root)
                }
            }
        }

        return null
    }

    private fun checkMinecraftKnowledge(clean: String): String? {
        if (!clean.contains("minecraft")) return null

        if (clean.contains("elmas") || clean.contains("diamond")) {
            return "Minecraft'ta elmaslar en yoğun şekilde Y: -58 katmanında bulunur! Lav göllerinin hemen üstünde arama yapmak en verimli yoldur."
        }
        if (clean.contains("netherit") || clean.contains("netherite")) {
            return "Netherit için Nether'da Y: 15 seviyelerinde Antik Kalıntı (Ancient Debris) kazıp fırında eriterek altın külçeleriyle birleştirebilirsin."
        }
        if (clean.contains("ejderha") || clean.contains("ender dragon")) {
            return "Ender Ejderhası'nı yenmek için önce obsidyen kulelerdeki End Kristallerini patlatmalı, ardından yatak veya oklarla canını bitirmelisin!"
        }

        return "Minecraft, sonsuz blok dünyasında hayatta kalma ve yaratıcılık oyunudur. Madenler, craft tarifleri veya yaratıklar hakkında istediğini sorabilirsin!"
    }

    private fun checkGeneralKnowledge(clean: String): String? {
        if (clean.contains("başkenti") || clean.contains("baskenti")) {
            if (clean.contains("türkiye") || clean.contains("turkiye")) return "Türkiye'nin başkenti Ankara'dır."
            if (clean.contains("fransa")) return "Fransa'nın başkenti Paris'tir."
            if (clean.contains("almanya")) return "Almanya'nın başkenti Berlin'dir."
            if (clean.contains("ingiltere")) return "İngiltere'nin başkenti Londra'dır."
            if (clean.contains("italya")) return "İtalya'nın başkenti Roma'dır."
            if (clean.contains("japonya")) return "Japonya'nın başkenti Tokyo'dur."
            if (clean.contains("rusya")) return "Rusya'nın başkenti Moskova'dır."
        }
        if (clean.contains("en yüksek dağ")) {
            return "Dünyanın en yüksek dağı 8.848 metre ile Everest Dağı'dır."
        }
        if (clean.contains("ışık hızı") || clean.contains("isik hizi")) {
            return "Işığın boşluktaki hızı yaklaşık 300.000 km/saniyedir."
        }
        if (clean.contains("gezegen")) {
            return "Güneş Sistemimizde 8 gezegen vardır: Merkür, Venüs, Dünya, Mars, Jüpiter, Satürn, Uranüs ve Neptün."
        }
        return null
    }

    private fun generateCleanDirectResponse(clean: String, originalPrompt: String): String {
        // Doğal, direkt ve konuşkan yanıt — asla robotik template YOK!
        if (clean.contains("neden") || clean.contains("nasıl") || clean.contains("kim")) {
            return "Bu konuda merak ettiğin detayları konuşabiliriz ya da istersen güncel kaynaklardan da senin için araştırabilirim. 😄"
        }
        return "Anladım. Başka sormak istediğin bir şey veya telefonunda yapmamı istediğin bir işlem var mı? 😄"
    }
}
