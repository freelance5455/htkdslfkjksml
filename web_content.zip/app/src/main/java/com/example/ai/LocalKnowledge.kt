package com.example.ai

import java.util.Locale
import java.util.regex.Pattern

/**
 * Suesa AI Yerel Bilgi Tabanı.
 * İnternet bağlantısı olmasa veya API anahtarı bulunmasa bile Suesa'nın
 * temel sorulara, Minecraft bilgilerine, matematik işlemlerine ve asistan kimliğine
 * anında doğru ve zengin cevaplar vermesini sağlar.
 */
object LocalKnowledge {

    private val assistantInfo = """
        Ben Suesa AI; Android telefonun için tasarlanmış akıllı ve yetenekli kişisel yapay zekâ asistanıyım.
        Telefonunda arama yapabilir, uygulamaları (YouTube, Kamera, Ayarlar, Galeri, Wi-Fi vb.) açabilir,
        kişilerini bulup arayabilir, sesli olarak sohbet edebilir ve internetten güncel bilgileri araştırabilirim.
        Nasıl yardımcı olmamı istersin?
    """.trimIndent()

    private val capabilities = """
        Suesa AI olarak şunları yapabilirim:
        • Sesli konuşma ve dinleme (Mikrofon butonu ile)
        • Telefon uygulamalarını açma (YouTube, Kamera, Galeri, Mesajlar, Saat vb.)
        • Sistem ayarlarını açma (Wi-Fi, Bluetooth, Cihaz ayarları)
        • Rehberden kişi arama (Örn: "Ahmet'i ara")
        • İnternette güncel bilgi ve hava durumu arama
        • Matematiksel hesaplamalar ve birim dönüştürme
        • Minecraft ve popüler oyun rehberleri
        • Fotoğraf çekme ve görsel anlama
    """.trimIndent()

    fun findAnswer(userQuery: String): String? {
        val q = userQuery.lowercase(Locale.forLanguageTag("tr-TR")).trim()

        // Soru: Kimsin / Nesin / Adın ne
        if (q.contains("sen kimsin") || q.contains("adın ne") || q.contains("ismin ne") || q == "suesa" || q == "merhaba suesa") {
            return assistantInfo
        }

        if (q.contains("ne yapabilirsin") || q.contains("yeteneklerin") || q.contains("neler yapabilirsin") || q.contains("özelliklerin")) {
            return capabilities
        }

        if (q.contains("nasılsın") || q.contains("naber") || q.contains("nasıl gidiyor")) {
            return "Harikayım, teşekkürler! Senin için çalışmaya ve yardımcı olmaya her zaman hazırım. Sana nasıl yardımcı olabilirim?"
        }

        if (q.contains("teşekkür") || q.contains("sağol") || q.contains("eyvallah")) {
            return "Rica ederim! Her zaman yardıma hazırım. Başka bir işlem yapmak ister misin?"
        }

        // Matematiksel hesaplama kontrolü
        val mathResult = tryEvaluateMath(q)
        if (mathResult != null) {
            return mathResult
        }

        // Minecraft bilgi tabanı
        val mcAnswer = checkMinecraftKnowledge(q)
        if (mcAnswer != null) {
            return mcAnswer
        }

        // Genel bilim / coğrafya yerel bilgileri
        if (q.contains("türkiye'nin başkenti") || q.contains("turkiyenin baskenti") || q.contains("türkiyenin başkenti")) {
            return "Türkiye'nin başkenti Ankara'dır. 13 Ekim 1923 tarihinde Türkiye Büyük Millet Meclisi kararıyla başkent ilan edilmiştir."
        }

        if (q.contains("dünyanın en yüksek dağı") || q.contains("en yüksek dağ")) {
            return "Dünyanın en yüksek dağı, deniz seviyesinden 8.848,86 metre yükseklikteki Everest Dağı'dır. Nepal ile Çin (Tibet) sınırında yer alır."
        }

        if (q.contains("güneş sistemindeki gezegenler") || q.contains("gezegenler hangileri")) {
            return "Güneş sistemimizde Güneş'e yakınlıklarına göre 8 gezegen bulunur: Merkür, Venüs, Dünya, Mars, Jüpiter, Satürn, Uranüs ve Neptün."
        }

        if (q.contains("ışık hızı ne kadar") || q.contains("ışık hızı kaç")) {
            return "Işığın boşluktaki hızı yaklaşık 299.792.458 metre/saniye'dir (yaklaşık 300.000 km/s)."
        }

        if (q.contains("pi sayısı")) {
            return "Pi (π) sayısı, bir dairenin çevresinin çapına oranını temsil eden irrasyonel bir matematiksel sabittir. İlk basamakları: 3,1415926535... şeklindedir."
        }

        return null
    }

    private fun tryEvaluateMath(query: String): String? {
        val clean = query.replace("kaçtır", "")
            .replace("kaç eder", "")
            .replace("nedir", "")
            .replace("hesapla", "")
            .replace("çarpı", "*")
            .replace("kere", "*")
            .replace("artı", "+")
            .replace("eksi", "-")
            .replace("bölü", "/")
            .trim()

        // Basit aritmetik: örn "45 * 12", "120 + 350", "100 / 4"
        val pattern = Pattern.compile("^\\s*([0-9]+(?:\\.[0-9]+)?)\\s*([+\\-*/xX])\\s*([0-9]+(?:\\.[0-9]+)?)\\s*$")
        val matcher = pattern.matcher(clean)
        if (matcher.find()) {
            val num1 = matcher.group(1)?.toDoubleOrNull() ?: return null
            val op = matcher.group(2) ?: return null
            val num2 = matcher.group(3)?.toDoubleOrNull() ?: return null

            val result = when (op) {
                "+" -> num1 + num2
                "-" -> num1 - num2
                "*", "x", "X" -> num1 * num2
                "/" -> if (num2 != 0.0) num1 / num2 else return "Sıfıra bölme hatası: Matematikte bir sayı sıfıra bölünemez."
                else -> return null
            }

            val formatted = if (result % 1.0 == 0.0) {
                result.toLong().toString()
            } else {
                String.format(Locale.US, "%.2f", result)
            }
            return "İşlem sonucu: $num1 $op $num2 = $formatted"
        }

        // Karekök kontrolü: "karekök 64", "64 karekökü"
        if (query.contains("karekök")) {
            val numMatcher = Pattern.compile("(\\d+)").matcher(query)
            if (numMatcher.find()) {
                val n = numMatcher.group(1)?.toDoubleOrNull()
                if (n != null && n >= 0) {
                    val root = Math.sqrt(n)
                    val formatted = if (root % 1.0 == 0.0) root.toLong().toString() else String.format(Locale.US, "%.2f", root)
                    return "√$n sayısının karekökü = $formatted"
                }
            }
        }

        return null
    }

    private fun checkMinecraftKnowledge(q: String): String? {
        if (!q.contains("minecraft")) return null

        if (q.contains("elmas nerede") || q.contains("elmas katmanı") || q.contains("elmas bul")) {
            return "Minecraft'ta 1.18 ve sonraki sürümlerde elmaslar Y: -53 ile Y: -58 seviyeleri arasında en yoğun şekilde bulunur. Y: -58 seviyesinde maden yapmak lav göllerinin hemen üzerinde en verimli elmas arama seviyesidir."
        }

        if (q.contains("netherit") || q.contains("netherite")) {
            return "Netherite (Netherit), elmastan daha güçlü ve lavda yanmayan bir malzemedir. Nether'da Y: 8-22 (özellikle Y: 15) seviyelerinde 'Antik Kalıntı' (Ancient Debris) kazılarak, fırında eritilip altın külçeleriyle birleştirilerek elde edilir."
        }

        if (q.contains("ender ejderhası") || q.contains("ejderha nasıl öldürülür")) {
            return "Ender Ejderhası'nı (Ender Dragon) alt etmek için End Boyutu'na gitmeli, obsidyen kulelerin tepesindeki 'End Kristalleri'ni patlatarak ejderhanın can yenilemesini kesmeli ve ardından yatak veya ok/kılıç darbeleriyle ejderhayı yenmelisiniz."
        }

        if (q.contains("iksir") || q.contains("iksim standı")) {
            return "Minecraft'ta iksir yapmak için bir Simya Standı (Brewing Stand), Su Şişeleri ve Nether Yumrusu (Nether Wart) gerekir. Nether yumrusu ile önce 'Garip İksir' (Awkward Potion) hazırlanır, ardından istenen iksire göre malzemeler (Alev tozu, şeker, parıldayan karpuz vb.) eklenir."
        }

        // Genel Minecraft bilgisi
        return """
            Minecraft, Mojang Studios tarafından geliştirilen sonsuz blok dünyasında hayatta kalma ve yaratıcılık oyunudur.
            • Hayatta Kalma (Survival): Kaynak toplama, canavarlarla savaşma ve gelişme.
            • Yaratıcı (Creative): Sınırsız blok ve uçma kabiliyetiyle mimari yapılar inşa etme.
            • Boyutlar: Dünya (Overworld), Cehennem (Nether) ve Son (The End).
            Minecraft hakkında merak ettiğin zanaat tarifleri, madenler veya yaratıklar hakkında detaylı bilgi sorabilirsin!
        """.trimIndent()
    }
}
