package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions

object UnityAdsManager {
    private const val TAG = "UnityAdsManager"

    // Production Unity Ads Game ID & Placements (hazimqadir7@gmail.com)
    const val LIVE_GAME_ID = "800381280"
    const val LIVE_REWARDED_PLACEMENT = "BP_Rewarded_Android"
    const val LIVE_BANNER_PLACEMENT = "BP_Banner_Android"

    // Standard fallback placement names in Unity Dashboard
    const val DEFAULT_TEST_GAME_ID = "800381280"
    const val DEFAULT_REWARDED_PLACEMENT = "Rewarded_Android"
    const val DEFAULT_INTERSTITIAL_PLACEMENT = "Interstitial_Android"
    const val DEFAULT_BANNER_PLACEMENT = "Banner_Android"

    var liveGameId: String = LIVE_GAME_ID
    var liveRewardedPlacement: String = LIVE_REWARDED_PLACEMENT
    var isTestMode: Boolean = false
    var lastStatus: String = "Ready to initialize (Real Live Mode)"

    private var isInitialized = false
    private var isInitializing = false
    private var initializedGameId: String = ""
    private var isAdLoaded = false
    private var isLoading = false
    private var activeLoadedPlacement: String = LIVE_REWARDED_PLACEMENT
    private val pendingLoadCallbacks = mutableListOf<() -> Unit>()

    private val candidatePlacements: List<String>
        get() = listOf(
            liveRewardedPlacement.replace(" ", "").trim(),
            LIVE_REWARDED_PLACEMENT,
            DEFAULT_REWARDED_PLACEMENT,
            "BP_Interstitial_Android",
            DEFAULT_INTERSTITIAL_PLACEMENT,
            "rewardedVideo",
            "video"
        ).filter { it.isNotEmpty() }.distinct()

    fun getActiveGameId(): String = liveGameId.replace(" ", "").trim().ifEmpty { LIVE_GAME_ID }
    fun getActivePlacementId(): String = liveRewardedPlacement.replace(" ", "").trim().ifEmpty { LIVE_REWARDED_PLACEMENT }

    fun initialize(
        context: Context,
        gameId: String = getActiveGameId(),
        testMode: Boolean = false,
        onReadyCallback: (() -> Unit)? = null
    ) {
        isTestMode = false
        val cleanGameId = gameId.replace(" ", "").trim().ifEmpty { LIVE_GAME_ID }

        if ((isInitialized || UnityAds.isInitialized) && initializedGameId == cleanGameId) {
            isInitialized = true
            preloadRewardedAd(getActivePlacementId(), onLoadedCallback = onReadyCallback)
            return
        }

        if (onReadyCallback != null) {
            synchronized(pendingLoadCallbacks) {
                pendingLoadCallbacks.add(onReadyCallback)
            }
        }

        if (isInitializing) return
        isInitializing = true
        initializedGameId = cleanGameId

        try {
            lastStatus = "Initializing Real Unity SDK (Game ID: $cleanGameId)..."
            UnityAds.initialize(
                context,
                cleanGameId,
                false,
                object : IUnityAdsInitializationListener {
                    override fun onInitializationComplete() {
                        isInitialized = true
                        isInitializing = false
                        lastStatus = "Unity Live SDK Active ($cleanGameId) - Loading Real Ad..."
                        Log.d(TAG, "Unity Ads Initialized Successfully! (gameId=$cleanGameId)")
                        preloadRewardedAd(getActivePlacementId())
                    }

                    override fun onInitializationFailed(
                        error: UnityAds.UnityAdsInitializationError,
                        message: String
                    ) {
                        isInitialized = false
                        isInitializing = false
                        lastStatus = "Unity Init Error ($cleanGameId): $error - $message"
                        Log.e(TAG, "Unity Ads Initialization Failed: $error - $message")
                    }
                }
            )
        } catch (e: Exception) {
            isInitializing = false
            lastStatus = "Unity Init Exception: ${e.message}"
            Log.e(TAG, "Unity Ads init exception: ${e.message}")
        }
    }

    fun preloadRewardedAd(
        placementId: String = getActivePlacementId(),
        fallbackIndex: Int = 0,
        onLoadedCallback: (() -> Unit)? = null
    ) {
        if (onLoadedCallback != null) {
            synchronized(pendingLoadCallbacks) {
                pendingLoadCallbacks.add(onLoadedCallback)
            }
        }

        if (isAdLoaded) {
            notifyLoadedCallbacks()
            return
        }

        if (!isInitialized && !UnityAds.isInitialized) {
            return
        }
        isInitialized = true

        if (isLoading && fallbackIndex == 0) return
        isLoading = true

        val placements = candidatePlacements
        val cleanPlacement = if (fallbackIndex == 0) {
            placementId.replace(" ", "").trim().ifEmpty { LIVE_REWARDED_PLACEMENT }
        } else {
            placements.getOrElse(fallbackIndex) { DEFAULT_REWARDED_PLACEMENT }
        }

        try {
            lastStatus = "Requesting Real Unity Ad ($cleanPlacement)..."
            UnityAds.load(
                cleanPlacement,
                object : IUnityAdsLoadListener {
                    override fun onUnityAdsAdLoaded(loadedPlacementId: String) {
                        isAdLoaded = true
                        isLoading = false
                        activeLoadedPlacement = loadedPlacementId
                        lastStatus = "Real Unity Ad Ready ($loadedPlacementId)"
                        Log.d(TAG, "Unity Ads Real Ad loaded successfully for: $loadedPlacementId")
                        notifyLoadedCallbacks()
                    }

                    override fun onUnityAdsFailedToLoad(
                        failedPlacementId: String,
                        error: UnityAds.UnityAdsLoadError,
                        message: String
                    ) {
                        isAdLoaded = false
                        isLoading = false
                        lastStatus = "Unity ($failedPlacementId): $error - $message"
                        Log.w(TAG, "Unity Ads failed to load ($failedPlacementId): $error - $message")

                        val nextIndex = fallbackIndex + 1
                        if (nextIndex < placements.size) {
                            val nextPlacement = placements[nextIndex]
                            Log.d(TAG, "Trying backup Unity placement '$nextPlacement' ($nextIndex/${placements.size})...")
                            preloadRewardedAd(nextPlacement, fallbackIndex = nextIndex)
                        }
                    }
                }
            )
        } catch (e: Exception) {
            isLoading = false
            lastStatus = "Unity Load Error: ${e.message}"
            Log.e(TAG, "Unity Ads load exception: ${e.message}")
        }
    }

    private fun notifyLoadedCallbacks() {
        val callbacks = synchronized(pendingLoadCallbacks) {
            val copy = pendingLoadCallbacks.toList()
            pendingLoadCallbacks.clear()
            copy
        }
        callbacks.forEach { it.invoke() }
    }

    fun showRewardedAd(
        activity: Activity,
        onUserEarnedReward: (amount: Int, type: String) -> Unit,
        onAdDismissed: () -> Unit = {},
        onAdFailed: (String) -> Unit = {}
    ) {
        val placementId = if (isAdLoaded) activeLoadedPlacement else getActivePlacementId()
        if (!isAdLoaded) {
            preloadRewardedAd(placementId)
            onAdFailed("Unity Real Ad is still loading ($lastStatus)")
            return
        }

        try {
            val showOptions = UnityAdsShowOptions()
            UnityAds.show(
                activity,
                placementId,
                showOptions,
                object : IUnityAdsShowListener {
                    override fun onUnityAdsShowFailure(
                        placementId: String,
                        error: UnityAds.UnityAdsShowError,
                        message: String
                    ) {
                        Log.e(TAG, "Unity Ads Show Failed ($placementId): $error - $message")
                        lastStatus = "Show Error ($placementId): $error - $message"
                        isAdLoaded = false
                        preloadRewardedAd(getActivePlacementId())
                        onAdFailed(message)
                    }

                    override fun onUnityAdsShowStart(placementId: String) {
                        lastStatus = "Playing Real Unity Ad ($placementId)"
                        Log.d(TAG, "Unity Ads Show Started: $placementId")
                    }

                    override fun onUnityAdsShowClick(placementId: String) {
                        Log.d(TAG, "Unity Ads Show Clicked: $placementId")
                    }

                    override fun onUnityAdsShowComplete(
                        placementId: String,
                        state: UnityAds.UnityAdsShowCompletionState
                    ) {
                        Log.d(TAG, "Unity Ads Show Complete: $placementId with state $state")
                        isAdLoaded = false
                        lastStatus = "Real Unity Ad Completed ($placementId)"
                        preloadRewardedAd(getActivePlacementId())

                        if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED ||
                            state == UnityAds.UnityAdsShowCompletionState.SKIPPED
                        ) {
                            onUserEarnedReward(50, "Coins")
                        }
                        onAdDismissed()
                    }
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Unity Ads show exception: ${e.message}")
            isAdLoaded = false
            preloadRewardedAd(getActivePlacementId())
            onAdFailed(e.message ?: "Failed to display Unity ad")
        }
    }

    fun isAdReady(): Boolean = isAdLoaded
    fun isSdkInitialized(): Boolean = isInitialized || UnityAds.isInitialized
}
