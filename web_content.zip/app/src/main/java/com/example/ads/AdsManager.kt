package com.example.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.SharedPreferences
import android.util.Log
import com.example.BuildConfig

fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

enum class AdNetworkMode {
    AUTO,        // Dual Live Mediation: Both Google AdMob + Unity Ads active together
    ADMOB_ONLY,  // Only Google AdMob
    UNITY_ONLY   // Only Unity Ads
}

object AdsManager {
    private const val TAG = "AdsManager"
    private const val PREFS_NAME = "monetization_ads_prefs_v5_strict_real"

    // Production AdMob IDs (hazimqadir7@gmail.com)
    val DEFAULT_ADMOB_APP_ID: String = BuildConfig.ADMOB_APP_ID
        .replace(" ", "").trim()
        .takeIf { it.isNotEmpty() && !it.startsWith("ca-app-pub-3940256099942544") }
        ?: "ca-app-pub-6570099501095471~7637310181"

    val DEFAULT_ADMOB_REWARDED_ID: String = BuildConfig.ADMOB_REWARDED_AD_UNIT_ID
        .replace(" ", "").trim()
        .takeIf { it.isNotEmpty() && !it.startsWith("ca-app-pub-3940256099942544") }
        ?: "ca-app-pub-6570099501095471/2795123607"

    val DEFAULT_ADMOB_BANNER_ID: String = BuildConfig.ADMOB_BANNER_AD_UNIT_ID
        .replace(" ", "").trim()
        .takeIf { it.isNotEmpty() && !it.startsWith("ca-app-pub-3940256099942544") }
        ?: "ca-app-pub-6570099501095471/3307182931"

    // Production Unity Ads IDs (hazimqadir7@gmail.com)
    val DEFAULT_UNITY_GAME_ID: String = BuildConfig.UNITY_GAME_ID
        .replace(" ", "").trim()
        .takeIf { it.isNotEmpty() && it != "1486550" }
        ?: "800381280"

    val DEFAULT_UNITY_REWARDED_ID: String = BuildConfig.UNITY_REWARDED_PLACEMENT
        .replace(" ", "").trim()
        .takeIf { it.isNotEmpty() && it != "Rewarded_Android" }
        ?: "BP_Rewarded_Android"

    const val DEFAULT_UNITY_BANNER_ID = "Banner_Android"
    const val TEST_ADMOB_BANNER_ID = "ca-app-pub-6570099501095471/3307182931"

    const val PUBLISHER_EMAIL = "hazimqadir7@gmail.com"

    // Default to AUTO (Both AdMob + Unity Ads active) and strictly Real Live Ads (isTestMode = false)
    var networkMode: AdNetworkMode = AdNetworkMode.AUTO
    var isTestMode: Boolean = false

    var admobAppId: String = DEFAULT_ADMOB_APP_ID
    var admobRewardedUnitId: String = DEFAULT_ADMOB_REWARDED_ID
    var admobBannerUnitId: String = DEFAULT_ADMOB_BANNER_ID

    var unityGameId: String = DEFAULT_UNITY_GAME_ID
    var unityRewardedPlacement: String = DEFAULT_UNITY_REWARDED_ID
    var unityBannerPlacement: String = DEFAULT_UNITY_BANNER_ID

    private var isInitialized = false

    fun initialize(context: Context) {
        loadSettings(context)
        isTestMode = false

        // Always initialize Google AdMob SDK in Real Mode
        AdMobManager.isTestMode = false
        AdMobManager.liveRewardedAdUnitId = admobRewardedUnitId
        AdMobManager.initialize(context)

        // Always initialize Unity Ads SDK in Real Mode so both networks are preloaded & ready
        UnityAdsManager.isTestMode = false
        UnityAdsManager.liveGameId = unityGameId
        UnityAdsManager.liveRewardedPlacement = unityRewardedPlacement
        UnityAdsManager.initialize(context, unityGameId, false)

        isInitialized = true
        Log.d(TAG, "AdsManager initialized! Mode=$networkMode, RealAds=true, UnityGameId=$unityGameId, UnityPlacement=$unityRewardedPlacement")
    }

    fun forceLoadRealAds(context: Context, onAnyLoaded: (() -> Unit)? = null) {
        isTestMode = false
        AdMobManager.isTestMode = false
        AdMobManager.liveRewardedAdUnitId = admobRewardedUnitId
        AdMobManager.preloadRewardedAd(context, onLoadedCallback = onAnyLoaded)

        UnityAdsManager.isTestMode = false
        UnityAdsManager.liveGameId = unityGameId
        UnityAdsManager.liveRewardedPlacement = unityRewardedPlacement
        if (!UnityAdsManager.isSdkInitialized()) {
            UnityAdsManager.initialize(context, unityGameId, false)
        } else {
            UnityAdsManager.preloadRewardedAd(unityRewardedPlacement, onLoadedCallback = onAnyLoaded)
        }
    }

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun loadSettings(context: Context) {
        val prefs = getPrefs(context)
        val modeStr = prefs.getString("network_mode", AdNetworkMode.AUTO.name) ?: AdNetworkMode.AUTO.name
        networkMode = try {
            AdNetworkMode.valueOf(modeStr)
        } catch (_: Exception) {
            AdNetworkMode.AUTO
        }

        // Always enforce real live ads
        isTestMode = false

        val savedAdmobApp = (prefs.getString("admob_app_id", DEFAULT_ADMOB_APP_ID) ?: DEFAULT_ADMOB_APP_ID).replace(" ", "").trim()
        admobAppId = if (savedAdmobApp.isEmpty() || savedAdmobApp.startsWith("ca-app-pub-3940256099942544")) DEFAULT_ADMOB_APP_ID else savedAdmobApp

        val savedAdmobRewarded = (prefs.getString("admob_rewarded_id", DEFAULT_ADMOB_REWARDED_ID) ?: DEFAULT_ADMOB_REWARDED_ID).replace(" ", "").trim()
        admobRewardedUnitId = if (savedAdmobRewarded.isEmpty() || savedAdmobRewarded.startsWith("ca-app-pub-3940256099942544")) DEFAULT_ADMOB_REWARDED_ID else savedAdmobRewarded

        val savedAdmobBanner = (prefs.getString("admob_banner_id", DEFAULT_ADMOB_BANNER_ID) ?: DEFAULT_ADMOB_BANNER_ID).replace(" ", "").trim()
        admobBannerUnitId = if (savedAdmobBanner.isEmpty() || savedAdmobBanner.startsWith("ca-app-pub-3940256099942544")) DEFAULT_ADMOB_BANNER_ID else savedAdmobBanner

        val savedUnityGame = (prefs.getString("unity_game_id", DEFAULT_UNITY_GAME_ID) ?: DEFAULT_UNITY_GAME_ID).replace(" ", "").trim()
        unityGameId = if (savedUnityGame.isEmpty() || savedUnityGame == "1486550") DEFAULT_UNITY_GAME_ID else savedUnityGame

        val savedUnityPlacement = (prefs.getString("unity_rewarded_placement", DEFAULT_UNITY_REWARDED_ID) ?: DEFAULT_UNITY_REWARDED_ID).replace(" ", "").trim()
        unityRewardedPlacement = savedUnityPlacement.ifEmpty { DEFAULT_UNITY_REWARDED_ID }

        unityBannerPlacement = (prefs.getString("unity_banner_placement", DEFAULT_UNITY_BANNER_ID) ?: DEFAULT_UNITY_BANNER_ID).replace(" ", "").trim()
    }

    fun saveSettings(
        context: Context,
        mode: AdNetworkMode,
        testMode: Boolean,
        admobApp: String,
        admobRewarded: String,
        admobBanner: String,
        unityGame: String,
        unityPlacement: String
    ) {
        networkMode = mode
        isTestMode = false
        admobAppId = admobApp.replace(" ", "").trim().ifEmpty { DEFAULT_ADMOB_APP_ID }
        admobRewardedUnitId = admobRewarded.replace(" ", "").trim().ifEmpty { DEFAULT_ADMOB_REWARDED_ID }
        admobBannerUnitId = admobBanner.replace(" ", "").trim().ifEmpty { DEFAULT_ADMOB_BANNER_ID }
        unityGameId = unityGame.replace(" ", "").trim().ifEmpty { DEFAULT_UNITY_GAME_ID }
        unityRewardedPlacement = unityPlacement.replace(" ", "").trim().ifEmpty { DEFAULT_UNITY_REWARDED_ID }

        val prefs = getPrefs(context)
        prefs.edit()
            .putString("network_mode", networkMode.name)
            .putBoolean("is_test_mode", false)
            .putString("admob_app_id", admobAppId)
            .putString("admob_rewarded_id", admobRewardedUnitId)
            .putString("admob_banner_id", admobBannerUnitId)
            .putString("unity_game_id", unityGameId)
            .putString("unity_rewarded_placement", unityRewardedPlacement)
            .apply()

        forceLoadRealAds(context)
        Log.d(TAG, "Ad Settings updated and reloaded: Mode=$networkMode, RealAds=true")
    }

    fun showRewardedAd(
        activity: Activity,
        onUserEarnedReward: (amount: Int, type: String) -> Unit,
        onAdDismissed: () -> Unit = {},
        onFallbackToSimulatedAd: () -> Unit = {}
    ) {
        when (networkMode) {
            AdNetworkMode.ADMOB_ONLY -> {
                if (AdMobManager.isAdLoaded()) {
                    AdMobManager.showRewardedAd(
                        activity = activity,
                        onUserEarnedReward = onUserEarnedReward,
                        onAdDismissed = onAdDismissed,
                        onFallbackToSimulatedAd = onFallbackToSimulatedAd
                    )
                } else {
                    AdMobManager.preloadRewardedAd(activity)
                    onFallbackToSimulatedAd()
                }
            }

            AdNetworkMode.UNITY_ONLY -> {
                if (UnityAdsManager.isAdReady()) {
                    UnityAdsManager.showRewardedAd(
                        activity = activity,
                        onUserEarnedReward = onUserEarnedReward,
                        onAdDismissed = onAdDismissed,
                        onAdFailed = { onFallbackToSimulatedAd() }
                    )
                } else {
                    UnityAdsManager.preloadRewardedAd(unityRewardedPlacement)
                    onFallbackToSimulatedAd()
                }
            }

            AdNetworkMode.AUTO -> {
                if (UnityAdsManager.isAdReady()) {
                    UnityAdsManager.showRewardedAd(
                        activity = activity,
                        onUserEarnedReward = onUserEarnedReward,
                        onAdDismissed = onAdDismissed,
                        onAdFailed = {
                            if (AdMobManager.isAdLoaded()) {
                                AdMobManager.showRewardedAd(
                                    activity = activity,
                                    onUserEarnedReward = onUserEarnedReward,
                                    onAdDismissed = onAdDismissed,
                                    onFallbackToSimulatedAd = onFallbackToSimulatedAd
                                )
                            } else {
                                AdMobManager.preloadRewardedAd(activity)
                                onFallbackToSimulatedAd()
                            }
                        }
                    )
                } else if (AdMobManager.isAdLoaded()) {
                    AdMobManager.showRewardedAd(
                        activity = activity,
                        onUserEarnedReward = onUserEarnedReward,
                        onAdDismissed = onAdDismissed,
                        onFallbackToSimulatedAd = {
                            if (UnityAdsManager.isAdReady()) {
                                UnityAdsManager.showRewardedAd(
                                    activity = activity,
                                    onUserEarnedReward = onUserEarnedReward,
                                    onAdDismissed = onAdDismissed,
                                    onAdFailed = { onFallbackToSimulatedAd() }
                                )
                            } else {
                                UnityAdsManager.preloadRewardedAd(unityRewardedPlacement)
                                onFallbackToSimulatedAd()
                            }
                        }
                    )
                } else {
                    forceLoadRealAds(activity)
                    onFallbackToSimulatedAd()
                }
            }
        }
    }

    fun isAdMobReady(): Boolean = AdMobManager.isAdLoaded()
    fun isUnityReady(): Boolean = UnityAdsManager.isAdReady()
    fun isAnyAdReady(): Boolean = when (networkMode) {
        AdNetworkMode.ADMOB_ONLY -> isAdMobReady()
        AdNetworkMode.UNITY_ONLY -> isUnityReady()
        AdNetworkMode.AUTO -> isAdMobReady() || isUnityReady()
    }

    fun getBannerAdUnitId(): String {
        return admobBannerUnitId.ifEmpty { DEFAULT_ADMOB_BANNER_ID }
    }
}
