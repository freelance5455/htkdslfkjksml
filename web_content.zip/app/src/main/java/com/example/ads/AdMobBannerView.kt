package com.example.ads

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.TextMuted
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

@Composable
fun AdMobBannerView(
    modifier: Modifier = Modifier,
    adUnitId: String = AdsManager.getBannerAdUnitId()
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    var isLoaded by remember { mutableStateOf(false) }
    var tryUnityBanner by remember { mutableStateOf(AdsManager.networkMode == AdNetworkMode.UNITY_ONLY) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .background(GameDarkBackground, RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (!isLoaded) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            ) {
                Text(text = "📢", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "AdMob + Unity Live Ad Space",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = GameAmberBright
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (AdsManager.isTestMode) "(Test Mode)" else "(Real Ads Active)",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
        }

        if (tryUnityBanner && activity != null) {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = {
                    BannerView(activity, AdsManager.unityBannerPlacement, UnityBannerSize(320, 50)).apply {
                        listener = object : BannerView.IListener {
                            override fun onBannerLoaded(bannerAdView: BannerView?) {
                                isLoaded = true
                            }

                            override fun onBannerShown(bannerAdView: BannerView?) {
                                isLoaded = true
                            }

                            override fun onBannerClick(bannerAdView: BannerView?) {}

                            override fun onBannerFailedToLoad(bannerAdView: BannerView?, errorInfo: BannerErrorInfo?) {
                                android.util.Log.w("AdMobBannerView", "Unity Banner failed: ${errorInfo?.errorMessage}")
                            }

                            override fun onBannerLeftApplication(bannerView: BannerView?) {}
                        }
                        load()
                    }
                }
            )
        } else {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = { ctx ->
                    AdView(ctx).apply {
                        setAdSize(AdSize.BANNER)
                        setAdUnitId(adUnitId)
                        adListener = object : AdListener() {
                            override fun onAdLoaded() {
                                isLoaded = true
                            }

                            override fun onAdFailedToLoad(error: LoadAdError) {
                                android.util.Log.w("AdMobBannerView", "AdMob Banner failed (${error.code}): ${error.message}, falling back to Unity Banner")
                                isLoaded = false
                                if (AdsManager.networkMode != AdNetworkMode.ADMOB_ONLY && activity != null) {
                                    tryUnityBanner = true
                                }
                            }
                        }
                        loadAd(AdRequest.Builder().build())
                    }
                },
                update = { adView ->
                    if (adView.adUnitId != adUnitId) {
                        adView.adUnitId = adUnitId
                        adView.loadAd(AdRequest.Builder().build())
                    }
                }
            )
        }
    }
}
