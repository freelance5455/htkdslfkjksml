package com.example.ads

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.TextMuted
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize
import kotlinx.coroutines.delay

@Composable
fun AdMobBannerView(
    modifier: Modifier = Modifier,
    adUnitId: String = AdsManager.getBannerAdUnitId()
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    var isLoaded by remember { mutableStateOf(false) }
    var useUnityBanner by remember { mutableStateOf(AdsManager.networkMode == AdNetworkMode.UNITY_ONLY) }
    var unityPlacementIndex by remember { mutableIntStateOf(0) }
    var reloadTick by remember { mutableIntStateOf(0) }
    var adViewRef by remember { mutableStateOf<AdView?>(null) }
    var unityBannerRef by remember { mutableStateOf<BannerView?>(null) }

    val unityBannerPlacements = remember {
        listOf("BP_Banner_Android", "Banner_Android", AdsManager.unityBannerPlacement).distinct()
    }

    // Automatic retry loop until a real Banner Ad loads from AdMob or Unity
    LaunchedEffect(isLoaded) {
        while (!isLoaded) {
            delay(6000)
            if (!isLoaded) {
                reloadTick++
                if (!useUnityBanner) {
                    adViewRef?.loadAd(AdRequest.Builder().build())
                } else {
                    unityBannerRef?.load()
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .background(GameDarkBackground, RoundedCornerShape(8.dp))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (!isLoaded) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            ) {
                Text(text = "📢", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "AdMob + Unity Live Banner",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = GameAmberBright
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "(Loading Real Ad...)",
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
        }

        if (useUnityBanner && activity != null) {
            val activeUnityBannerPlacement = unityBannerPlacements.getOrElse(unityPlacementIndex % unityBannerPlacements.size) { "Banner_Android" }
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = {
                    BannerView(activity, activeUnityBannerPlacement, UnityBannerSize(320, 50)).apply {
                        unityBannerRef = this
                        listener = object : BannerView.IListener {
                            override fun onBannerLoaded(bannerAdView: BannerView?) {
                                isLoaded = true
                            }

                            override fun onBannerShown(bannerAdView: BannerView?) {
                                isLoaded = true
                            }

                            override fun onBannerClick(bannerAdView: BannerView?) {}

                            override fun onBannerFailedToLoad(bannerAdView: BannerView?, errorInfo: BannerErrorInfo?) {
                                android.util.Log.w("AdMobBannerView", "Unity Banner ($activeUnityBannerPlacement) failed: ${errorInfo?.errorMessage}")
                                isLoaded = false
                                unityPlacementIndex++
                                if (AdsManager.networkMode == AdNetworkMode.AUTO && unityPlacementIndex >= unityBannerPlacements.size) {
                                    useUnityBanner = false
                                }
                            }

                            override fun onBannerLeftApplication(bannerView: BannerView?) {}
                        }
                        if (UnityAdsManager.isSdkInitialized()) {
                            load()
                        }
                    }
                },
                update = { banner ->
                    if (!isLoaded && reloadTick > 0 && UnityAdsManager.isSdkInitialized()) {
                        banner.load()
                    }
                }
            )
        } else {
            AndroidView(
                modifier = Modifier.fillMaxWidth(),
                factory = { ctx ->
                    AdView(ctx).apply {
                        adViewRef = this
                        setAdSize(AdSize.BANNER)
                        setAdUnitId(adUnitId)
                        adListener = object : AdListener() {
                            override fun onAdLoaded() {
                                isLoaded = true
                            }

                            override fun onAdFailedToLoad(error: LoadAdError) {
                                android.util.Log.w("AdMobBannerView", "AdMob Banner failed (${error.code}): ${error.message}")
                                isLoaded = false
                                if (AdsManager.networkMode != AdNetworkMode.ADMOB_ONLY && activity != null && UnityAdsManager.isSdkInitialized()) {
                                    useUnityBanner = true
                                }
                            }
                        }
                        loadAd(AdRequest.Builder().build())
                    }
                },
                update = { adView ->
                    if (adView.adUnitId != adUnitId) {
                        adView.adUnitId = adUnitId
                        adView.loadAd(AdRequest.Builder().build())
                    }
                }
            )
        }
    }
}
