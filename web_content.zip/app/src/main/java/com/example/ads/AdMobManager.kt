package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

object AdMobManager {
    private const val TAG = "AdMobManager"

    // Default Google official test Rewarded Ad Unit ID
    // Production note: For real earnings into hazimqadir7@gmail.com AdMob account,
    // replace with your live Ad Unit ID before Play Store publishing
    const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-3940256099942544/5224354917"
    const val TEST_APP_ID = "ca-app-pub-3940256099942544~3347511713"

    var publisherEmail: String = "hazimqadir7@gmail.com"
    var liveRewardedAdUnitId: String = TEST_REWARDED_AD_UNIT_ID
    var isTestMode: Boolean = true

    private var rewardedAd: RewardedAd? = null
    private var isLoading = false
    private var isInitialized = false

    fun initialize(context: Context) {
        if (isInitialized) return
        try {
            MobileAds.initialize(context) { status ->
                Log.d(TAG, "AdMob SDK Initialized successfully: $status")
                isInitialized = true
                preloadRewardedAd(context)
            }
        } catch (e: Exception) {
            Log.e(TAG, "AdMob initialization error: ${e.message}")
        }
    }

    fun preloadRewardedAd(context: Context) {
        if (rewardedAd != null || isLoading) return
        isLoading = true

        val adUnitId = if (isTestMode) TEST_REWARDED_AD_UNIT_ID else liveRewardedAdUnitId
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            context,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "AdMob Rewarded Ad loaded successfully.")
                    rewardedAd = ad
                    isLoading = false
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "AdMob Rewarded Ad failed to load: ${loadAdError.message}")
                    rewardedAd = null
                    isLoading = false
                }
            }
        )
    }

    /**
     * Shows a rewarded ad. If AdMob SDK has a loaded ad, displays full Google AdMob Rewarded Ad.
     * Otherwise invokes onFallbackToSimulatedAd so the player is never blocked.
     */
    fun showRewardedAd(
        activity: Activity,
        onUserEarnedReward: (amount: Int, type: String) -> Unit,
        onAdDismissed: () -> Unit = {},
        onFallbackToSimulatedAd: () -> Unit = {}
    ) {
        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Rewarded Ad dismissed.")
                    rewardedAd = null
                    preloadRewardedAd(activity)
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    Log.e(TAG, "Rewarded Ad failed to show: ${adError.message}")
                    rewardedAd = null
                    preloadRewardedAd(activity)
                    onFallbackToSimulatedAd()
                }

                override fun onAdShowedFullScreenContent() {
                    Log.d(TAG, "Rewarded Ad displayed fullscreen.")
                }
            }

            ad.show(activity) { rewardItem ->
                Log.d(TAG, "User earned reward: ${rewardItem.amount} ${rewardItem.type}")
                onUserEarnedReward(rewardItem.amount, rewardItem.type)
            }
        } else {
            // Preload for next time, and use fallback interactive simulated ad player
            preloadRewardedAd(activity)
            onFallbackToSimulatedAd()
        }
    }

    fun isAdLoaded(): Boolean = rewardedAd != null
}
