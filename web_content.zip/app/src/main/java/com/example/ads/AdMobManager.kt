package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

object AdMobManager {
    private const val TAG = "AdMobManager"

    // Production Ad Unit IDs for hazimqadir7@gmail.com
    const val LIVE_REWARDED_AD_UNIT_ID = "ca-app-pub-6570099501095471/2795123607"
    const val LIVE_APP_ID = "ca-app-pub-6570099501095471~7637310181"
    const val TEST_REWARDED_AD_UNIT_ID = "ca-app-pub-6570099501095471/2795123607"
    const val TEST_APP_ID = "ca-app-pub-6570099501095471~7637310181"

    var publisherEmail: String = "hazimqadir7@gmail.com"
    var liveRewardedAdUnitId: String = LIVE_REWARDED_AD_UNIT_ID
    var isTestMode: Boolean = false

    var lastStatus: String = "Initialized - Ready to load Real Ad"
    var lastErrorCode: Int? = null
    var lastErrorMessage: String? = null

    private var rewardedAd: RewardedAd? = null
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var interstitialAd: InterstitialAd? = null
    private var isLoading = false
    private var isInitialized = false
    private val pendingLoadCallbacks = mutableListOf<() -> Unit>()

    fun initialize(context: Context) {
        isTestMode = false
        if (isInitialized) {
            preloadRewardedAd(context)
            return
        }
        try {
            MobileAds.initialize(context) { status ->
                Log.d(TAG, "AdMob SDK Initialized successfully: $status")
                isInitialized = true
                lastStatus = "AdMob Live SDK Active - Loading Real Ad..."
                preloadRewardedAd(context)
            }
        } catch (e: Exception) {
            Log.e(TAG, "AdMob initialization error: ${e.message}")
            lastStatus = "Init Error: ${e.message}"
            lastErrorMessage = e.message
        }
    }

    fun preloadRewardedAd(context: Context, onLoadedCallback: (() -> Unit)? = null) {
        if (onLoadedCallback != null) {
            synchronized(pendingLoadCallbacks) {
                pendingLoadCallbacks.add(onLoadedCallback)
            }
        }

        if (isAdLoaded()) {
            notifyLoadedCallbacks()
            return
        }
        if (isLoading) return
        isLoading = true
        lastStatus = "Requesting Real Ad from Google AdMob..."

        val adUnitId = liveRewardedAdUnitId.replace(" ", "").trim().ifEmpty { LIVE_REWARDED_AD_UNIT_ID }
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            context,
            adUnitId,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "AdMob Real Rewarded Ad loaded successfully.")
                    rewardedAd = ad
                    isLoading = false
                    lastStatus = "Real AdMob Ad Ready ($adUnitId)"
                    lastErrorCode = null
                    lastErrorMessage = null
                    notifyLoadedCallbacks()
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.w(TAG, "AdMob Rewarded Ad failed to load: ${loadAdError.message}")
                    rewardedAd = null
                    lastErrorCode = loadAdError.code
                    lastErrorMessage = loadAdError.message
                    lastStatus = when (loadAdError.code) {
                        3 -> "AdMob Live: No Fill (Code 3 - Store verification pending)"
                        2 -> "Network Error: Check internet connection"
                        1 -> "Invalid Ad Unit ID: Check AdMob ID"
                        else -> "AdMob (${loadAdError.code}): ${loadAdError.message}"
                    }

                    // Try RewardedInterstitialAd
                    RewardedInterstitialAd.load(
                        context,
                        adUnitId,
                        adRequest,
                        object : RewardedInterstitialAdLoadCallback() {
                            override fun onAdLoaded(rInterstitial: RewardedInterstitialAd) {
                                rewardedInterstitialAd = rInterstitial
                                isLoading = false
                                lastStatus = "Real AdMob Rewarded-Interstitial Ready"
                                lastErrorCode = null
                                lastErrorMessage = null
                                notifyLoadedCallbacks()
                            }

                            override fun onAdFailedToLoad(secondError: LoadAdError) {
                                // Try InterstitialAd
                                InterstitialAd.load(
                                    context,
                                    adUnitId,
                                    adRequest,
                                    object : InterstitialAdLoadCallback() {
                                        override fun onAdLoaded(interstitial: InterstitialAd) {
                                            interstitialAd = interstitial
                                            isLoading = false
                                            lastStatus = "Real AdMob Interstitial Ready"
                                            lastErrorCode = null
                                            lastErrorMessage = null
                                            notifyLoadedCallbacks()
                                        }

                                        override fun onAdFailedToLoad(thirdError: LoadAdError) {
                                            isLoading = false
                                        }
                                    }
                                )
                            }
                        }
                    )
                }
            }
        )
    }

    private fun notifyLoadedCallbacks() {
        val callbacks = synchronized(pendingLoadCallbacks) {
            val copy = pendingLoadCallbacks.toList()
            pendingLoadCallbacks.clear()
            copy
        }
        callbacks.forEach { it.invoke() }
    }

    fun showRewardedAd(
        activity: Activity,
        onUserEarnedReward: (amount: Int, type: String) -> Unit,
        onAdDismissed: () -> Unit = {},
        onFallbackToSimulatedAd: () -> Unit = {}
    ) {
        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    Log.d(TAG, "Rewarded Ad dismissed.")
                    rewardedAd = null
                    preloadRewardedAd(activity)
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    Log.e(TAG, "Rewarded Ad failed to show: ${adError.message}")
                    rewardedAd = null
                    preloadRewardedAd(activity)
                    onFallbackToSimulatedAd()
                }

                override fun onAdShowedFullScreenContent() {
                    lastStatus = "Playing Real AdMob Ad"
                    Log.d(TAG, "Rewarded Ad displayed fullscreen.")
                }
            }

            ad.show(activity) { rewardItem ->
                Log.d(TAG, "User earned reward: ${rewardItem.amount} ${rewardItem.type}")
                onUserEarnedReward(rewardItem.amount, rewardItem.type)
            }
            return
        }

        val rInterstitial = rewardedInterstitialAd
        if (rInterstitial != null) {
            rInterstitial.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedInterstitialAd = null
                    preloadRewardedAd(activity)
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedInterstitialAd = null
                    preloadRewardedAd(activity)
                    onFallbackToSimulatedAd()
                }
            }
            rInterstitial.show(activity) { rewardItem ->
                onUserEarnedReward(rewardItem.amount, rewardItem.type)
            }
            return
        }

        val inter = interstitialAd
        if (inter != null) {
            inter.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    preloadRewardedAd(activity)
                    onUserEarnedReward(50, "Coins")
                    onAdDismissed()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    interstitialAd = null
                    preloadRewardedAd(activity)
                    onFallbackToSimulatedAd()
                }
            }
            inter.show(activity)
            return
        }

        preloadRewardedAd(activity)
        onFallbackToSimulatedAd()
    }

    fun isAdLoaded(): Boolean = rewardedAd != null || rewardedInterstitialAd != null || interstitialAd != null
}
