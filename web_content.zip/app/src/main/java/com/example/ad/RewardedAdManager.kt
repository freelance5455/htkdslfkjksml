package com.example.ad

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AdState(
    val isShowing: Boolean = false,
    val title: String = "Sponsored Video Ad",
    val sponsorName: String = "Quest Rewards Partner",
    val rewardGranted: Boolean = false,
    val secondsRemaining: Int = 5,
    val adType: String = "REWARDED_VIDEO"
)

object RewardedAdManager {
    private val _adState = MutableStateFlow<AdState?>(null)
    val adState: StateFlow<AdState?> = _adState.asStateFlow()

    private var currentRewardCallback: (() -> Unit)? = null

    fun showRewardedAd(
        adTitle: String = "Sponsored Video Ad",
        sponsorName: String = "Top Game Studio",
        onRewardEarned: () -> Unit
    ) {
        currentRewardCallback = onRewardEarned
        _adState.value = AdState(
            isShowing = true,
            title = adTitle,
            sponsorName = sponsorName,
            rewardGranted = false,
            secondsRemaining = 5
        )
    }

    fun onAdTick(remaining: Int) {
        val current = _adState.value ?: return
        if (remaining <= 0) {
            _adState.value = current.copy(secondsRemaining = 0, rewardGranted = true)
            currentRewardCallback?.invoke()
            currentRewardCallback = null
        } else {
            _adState.value = current.copy(secondsRemaining = remaining)
        }
    }

    fun dismissAd() {
        _adState.value = null
        currentRewardCallback = null
    }
}
