package com.example.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TextToSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isLanguageAvailable = MutableStateFlow(true)
    val isLanguageAvailable: StateFlow<Boolean> = _isLanguageAvailable.asStateFlow()

    private var pendingSpeechText: String? = null
    private var speechRate: Float = 1.0f
    private var speechPitch: Float = 1.0f

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val russian = Locale("ru", "RU")
            val result = tts?.setLanguage(russian)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Try generic Russian locale
                val genericRu = Locale("ru")
                val fallback = tts?.setLanguage(genericRu)
                if (fallback == TextToSpeech.LANG_MISSING_DATA || fallback == TextToSpeech.LANG_NOT_SUPPORTED) {
                    _isLanguageAvailable.value = false
                } else {
                    _isLanguageAvailable.value = true
                }
            } else {
                _isLanguageAvailable.value = true
            }

            tts?.setSpeechRate(speechRate)
            tts?.setPitch(speechPitch)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                }
            })

            isInitialized = true
            pendingSpeechText?.let {
                speak(it, speechRate, speechPitch)
                pendingSpeechText = null
            }
        }
    }

    fun speak(text: String, rate: Float = 1.0f, pitch: Float = 1.0f) {
        speechRate = rate
        speechPitch = pitch

        if (!isInitialized) {
            pendingSpeechText = text
            return
        }

        stop()
        tts?.setSpeechRate(rate)
        tts?.setPitch(pitch)

        // Strip markdown code fences, headers, and asterisks for smooth natural speech synthesis
        val cleanForSpeech = text
            .replace(Regex("```[a-zA-Z]*\\n[\\s\\S]*?```"), "Код в сообщении.")
            .replace(Regex("`[^`]+`"), "фрагмент кода")
            .replace(Regex("[*#_>•]"), "")
            .trim()

        if (cleanForSpeech.isNotBlank()) {
            val utteranceId = "utterance_${System.currentTimeMillis()}"
            tts?.speak(cleanForSpeech, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            _isSpeaking.value = true
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (e: Exception) {
            // Ignore
        }
        _isSpeaking.value = false
    }

    fun destroy() {
        stop()
        try {
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            // Ignore
        }
    }
}
