package com.example.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class TtsVoiceOption(
    val name: String,
    val displayName: String,
    val localeTag: String,
    val isNetwork: Boolean,
    val isFemaleHint: Boolean?
)

class TextToSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isLanguageAvailable = MutableStateFlow(true)
    val isLanguageAvailable: StateFlow<Boolean> = _isLanguageAvailable.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<TtsVoiceOption>>(emptyList())
    val availableVoices: StateFlow<List<TtsVoiceOption>> = _availableVoices.asStateFlow()

    private val _activeVoiceLabel = MutableStateFlow("Системный голос")
    val activeVoiceLabel: StateFlow<String> = _activeVoiceLabel.asStateFlow()

    private var pendingSpeechText: String? = null
    private var speechRate: Float = 1.05f
    private var speechPitch: Float = 1.12f
    private var pendingVoiceName: String = ""
    private var pendingPreferFemale: Boolean? = true

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val russian = Locale("ru", "RU")
            val result = tts?.setLanguage(russian)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                val genericRu = Locale("ru")
                val fallback = tts?.setLanguage(genericRu)
                _isLanguageAvailable.value =
                    fallback != TextToSpeech.LANG_MISSING_DATA && fallback != TextToSpeech.LANG_NOT_SUPPORTED
            } else {
                _isLanguageAvailable.value = true
            }

            tts?.setSpeechRate(speechRate)
            tts?.setPitch(speechPitch)

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                }
            })

            isInitialized = true
            refreshVoices()
            applyVoiceSelection(pendingVoiceName, pendingPreferFemale)

            pendingSpeechText?.let {
                speak(it, speechRate, speechPitch, pendingVoiceName, pendingPreferFemale)
                pendingSpeechText = null
            }
        }
    }

    fun refreshVoices() {
        if (!isInitialized) return
        try {
            val rawVoices = tts?.voices ?: emptySet()
            val mapped = rawVoices
                .filter { voice ->
                    val lang = voice.locale?.language?.lowercase(Locale.ROOT).orEmpty()
                    lang == "ru" || lang == "en"
                }
                .sortedWith(
                    compareByDescending<Voice> { it.locale?.language?.equals("ru", ignoreCase = true) == true }
                        .thenBy { it.isNetworkConnectionRequired }
                        .thenBy { it.name }
                )
                .map { voice ->
                    val femaleHint = inferFemaleHint(voice.name)
                    TtsVoiceOption(
                        name = voice.name,
                        displayName = buildFriendlyVoiceName(voice, femaleHint),
                        localeTag = voice.locale?.toLanguageTag() ?: "ru-RU",
                        isNetwork = voice.isNetworkConnectionRequired,
                        isFemaleHint = femaleHint
                    )
                }
            _availableVoices.value = mapped
        } catch (_: Exception) {
            _availableVoices.value = emptyList()
        }
    }

    private fun inferFemaleHint(rawName: String): Boolean? {
        val n = rawName.lowercase(Locale.ROOT)
        return when {
            listOf("alice", "alisa", "алиса", "oksana", "elena", "irina", "anna", "milena", "katya", "svetlana", "tatyana", "female", "woman", "ruf", "dfc", "rur", "wavenet-a", "wavenet-c", "wavenet-e").any { n.contains(it) } -> true
            listOf("yuri", "aleksandr", "alexander", "pavel", "dmitry", "artemiy", "maxim", "max", "male", "man", "rue", "rud", "wavenet-b", "wavenet-d").any { n.contains(it) } -> false
            else -> null
        }
    }

    private fun buildFriendlyVoiceName(voice: Voice, femaleHint: Boolean?): String {
        val lower = voice.name.lowercase(Locale.ROOT)
        val lang = voice.locale?.language?.lowercase(Locale.ROOT) ?: "ru"
        val namedLabel = when {
            lower.contains("alisa") || lower.contains("alice") -> "Алиса (Системный TTS)"
            lower.contains("oksana") -> "Оксана"
            lower.contains("irina") -> "Ирина"
            lower.contains("elena") -> "Елена"
            lower.contains("milena") -> "Милена"
            lower.contains("svetlana") -> "Светлана"
            lower.contains("anna") -> "Анна"
            lower.contains("yuri") -> "Юрий"
            lower.contains("aleksandr") || lower.contains("alexander") -> "Александр"
            lower.contains("pavel") -> "Павел"
            lower.contains("dmitry") -> "Дмитрий"
            lower.contains("ruf") -> "Русский женский (Google RUF)"
            lower.contains("dfc") -> "Русский женский (Google DFC)"
            lower.contains("rur") -> "Русский женский (Google RUR)"
            lower.contains("rue") -> "Русский мужской (Google RUE)"
            lower.contains("rud") -> "Русский мужской (Google RUD)"
            femaleHint == true && lang == "ru" -> "Женский голос (${voice.name.take(18)})"
            femaleHint == false && lang == "ru" -> "Мужской голос (${voice.name.take(18)})"
            lang == "ru" -> "Русский голос (${voice.name.take(20)})"
            else -> "English (${voice.name.take(18)})"
        }
        val mode = if (voice.isNetworkConnectionRequired) "Сеть" else "Офлайн"
        return "$namedLabel • $mode"
    }

    fun applyVoiceSelection(selectedVoiceName: String, preferFemale: Boolean?) {
        pendingVoiceName = selectedVoiceName
        pendingPreferFemale = preferFemale
        if (!isInitialized) return

        try {
            val allVoices = tts?.voices ?: return
            val ruVoices = allVoices.filter { it.locale?.language.equals("ru", ignoreCase = true) }

            val chosen: Voice? = if (selectedVoiceName.isNotBlank()) {
                allVoices.firstOrNull { it.name == selectedVoiceName }
            } else if (preferFemale != null && ruVoices.isNotEmpty()) {
                // Prioritize Alisa/Alice or matching gender in Russian voices, preferring offline first
                val matching = ruVoices.filter { inferFemaleHint(it.name) == preferFemale }
                if (preferFemale) {
                    matching.firstOrNull {
                        val n = it.name.lowercase(Locale.ROOT)
                        n.contains("alisa") || n.contains("alice")
                    } ?: matching.firstOrNull { !it.isNetworkConnectionRequired } ?: matching.firstOrNull()
                } else {
                    matching.firstOrNull { !it.isNetworkConnectionRequired } ?: matching.firstOrNull()
                } ?: ruVoices.firstOrNull { !it.isNetworkConnectionRequired } ?: ruVoices.firstOrNull()
            } else {
                ruVoices.firstOrNull { !it.isNetworkConnectionRequired } ?: ruVoices.firstOrNull()
            }

            if (chosen != null) {
                tts?.voice = chosen
                _activeVoiceLabel.value = buildFriendlyVoiceName(chosen, inferFemaleHint(chosen.name))
            } else {
                tts?.setLanguage(Locale("ru", "RU"))
                _activeVoiceLabel.value = "Системный голос (ru-RU)"
            }
        } catch (_: Exception) {
            _activeVoiceLabel.value = "Системный голос (ru-RU)"
        }
    }

    fun speak(
        text: String,
        rate: Float = 1.0f,
        pitch: Float = 1.0f,
        selectedVoiceName: String = pendingVoiceName,
        preferFemale: Boolean? = pendingPreferFemale
    ) {
        speechRate = rate
        speechPitch = pitch
        pendingVoiceName = selectedVoiceName
        pendingPreferFemale = preferFemale

        if (!isInitialized) {
            pendingSpeechText = text
            return
        }

        stop()
        applyVoiceSelection(selectedVoiceName, preferFemale)
        tts?.setSpeechRate(rate)
        tts?.setPitch(pitch)

        val cleanForSpeech = text
            .replace(Regex("```[a-zA-Z]*\\n[\\s\\S]*?```"), "Код в сообщении.")
            .replace(Regex("`[^`]+`"), "фрагмент кода")
            .replace(Regex("[*#_>•]"), "")
            .trim()

        if (cleanForSpeech.isNotBlank()) {
            val utteranceId = "utterance_${System.currentTimeMillis()}"
            tts?.speak(cleanForSpeech, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            _isSpeaking.value = true
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
        _isSpeaking.value = false
    }

    fun destroy() {
        stop()
        try {
            tts?.shutdown()
            tts = null
        } catch (_: Exception) {
        }
    }
}
