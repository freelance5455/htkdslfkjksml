package com.example.speech

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.InlineDataPart
import com.google.firebase.ai.type.PublicPreviewAPI
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.SpeechConfig
import com.google.firebase.ai.type.Voice
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

private const val TAG = "AiSpeechSynthesizer"
private const val SAMPLE_RATE_HZ = 24_000

data class AiVoiceOption(
    val id: String,
    val title: String,
    val style: String
)

object AiVoicesCatalog {
    val voices = listOf(
        AiVoiceOption("Kore", "Алиса • Kore (Нейро-женский)", "Мягкий, выразительный и живой женский голос"),
        AiVoiceOption("Aoede", "Аврора • Aoede (Нейро-женский)", "Тёплый, мелодичный женский тембр"),
        AiVoiceOption("Leda", "Лида • Leda (Нейро-женский)", "Спокойный, ясный женский голос"),
        AiVoiceOption("Puck", "Макс • Puck (Нейро-мужской)", "Энергичный и чёткий мужской голос"),
        AiVoiceOption("Charon", "Диктор • Charon (Нейро-мужской)", "Глубокий студийный баритон"),
        AiVoiceOption("Fenrir", "Кибер • Fenrir (Нейро-мужской)", "Мощный, технологичный голос NEXUS")
    )
}

class AiSpeechSynthesizer {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var activeJob: Job? = null
    private var activeTrack: AudioTrack? = null

    @OptIn(PublicPreviewAPI::class)
    fun speak(
        text: String,
        voiceId: String = "Kore",
        onErrorFallback: (String) -> Unit
    ) {
        val clean = sanitizeForSpeech(text)
        if (clean.isBlank()) return

        stop()
        _isSpeaking.value = true

        activeJob = scope.launch {
            var track: AudioTrack? = null
            var receivedAudio = false
            try {
                val config = generationConfig {
                    responseModalities = listOf(ResponseModality.AUDIO)
                    speechConfig = SpeechConfig(
                        voice = Voice(voiceId.ifBlank { "Kore" }),
                        languageCode = "ru-RU"
                    )
                }

                val ttsModel = Firebase.ai(backend = GenerativeBackend.googleAI())
                    .generativeModel(
                        modelName = "gemini-3.1-flash-tts-preview",
                        generationConfig = config
                    )

                val minBuffer = AudioTrack.getMinBufferSize(
                    SAMPLE_RATE_HZ,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(8192)

                track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE_HZ)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minBuffer * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                activeTrack = track
                track.play()

                // Limit per neural TTS call for low latency
                val promptText = "Прочитай выразительно и естественно на русском языке:\n$clean"

                withTimeout(45_000L) {
                    ttsModel.generateContentStream(promptText).collect { chunk ->
                        val parts = chunk.candidates.firstOrNull()?.content?.parts.orEmpty()
                        for (part in parts) {
                            if (part is InlineDataPart && part.inlineData.isNotEmpty()) {
                                receivedAudio = true
                                track.write(part.inlineData, 0, part.inlineData.size)
                            }
                        }
                    }
                }

                if (!receivedAudio) {
                    throw IllegalStateException("Модель синтеза речи не вернула аудиоданные.")
                }

                // Allow hardware AudioTrack buffer to drain naturally before releasing
                try {
                    track.stop()
                } catch (_: Exception) {
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI neural speech failed, invoking fallback", e)
                withContext(Dispatchers.Main) {
                    onErrorFallback(e.localizedMessage ?: "Сбой нейро-синтеза речи")
                }
            } finally {
                try {
                    track?.pause()
                    track?.flush()
                    track?.release()
                } catch (_: Exception) {
                }
                if (activeTrack === track) {
                    activeTrack = null
                }
                _isSpeaking.value = false
            }
        }
    }

    fun stop() {
        activeJob?.cancel()
        activeJob = null
        try {
            activeTrack?.pause()
            activeTrack?.flush()
            activeTrack?.stop()
            activeTrack?.release()
        } catch (_: Exception) {
        }
        activeTrack = null
        _isSpeaking.value = false
    }

    private fun sanitizeForSpeech(raw: String): String {
        return raw
            .replace(Regex("```[a-zA-Z0-9_-]*\\n[\\s\\S]*?```"), " Программный код в ответе. ")
            .replace(Regex("`[^`]+`"), " фрагмент кода ")
            .replace(Regex("[*#_>•\\[\\]]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(1800)
    }
}
