package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class DailyReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Log.d("DailyReminderReceiver", "Alarm received at 5:00 PM for daily challenge check")
        DailyReminderManager.checkAndSendReminder(context)
    }
}
