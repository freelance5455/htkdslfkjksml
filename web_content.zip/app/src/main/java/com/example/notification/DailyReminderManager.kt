package com.example.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.data.DailyChallenges
import com.example.storage.GamePreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DailyReminderManager {
    private const val TAG = "DailyReminderManager"
    const val CHANNEL_ID = "daily_challenge_reminders"
    const val NOTIFICATION_ID = 5001
    const val ACTION_DAILY_REMINDER = "com.example.action.DAILY_REMINDER"
    const val EXTRA_OPEN_DAILY = "open_daily_challenge"
    const val TARGET_HOUR_OF_DAY = 17 // 5:00 PM
    const val TARGET_MINUTE = 0

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Daily Challenge Reminders"
            val descriptionText = "Alerts you at 5:00 PM if today's mystery puzzle has not yet been solved."
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                setShowBadge(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Schedules the next 5:00 PM alarm.
     * If current time is before 5:00 PM today, targets today at 17:00.
     * If current time is after 5:00 PM today, targets tomorrow at 17:00.
     */
    fun scheduleDailyReminder(context: Context) {
        val prefs = GamePreferences(context)
        if (!prefs.isDailyReminderEnabled()) {
            cancelDailyReminder(context)
            return
        }

        createNotificationChannel(context)

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, DailyReminderReceiver::class.java).apply {
            action = ACTION_DAILY_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            NOTIFICATION_ID,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val targetCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, TARGET_HOUR_OF_DAY)
            set(Calendar.MINUTE, TARGET_MINUTE)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            // If 5:00 PM has already passed today, schedule for tomorrow at 5:00 PM
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    targetCal.timeInMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    targetCal.timeInMillis,
                    pendingIntent
                )
            }
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
            Log.d(TAG, "Scheduled 5 PM daily reminder for: ${sdf.format(targetCal.time)}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule alarm", e)
        }
    }

    fun cancelDailyReminder(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, DailyReminderReceiver::class.java).apply {
            action = ACTION_DAILY_REMINDER
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            NOTIFICATION_ID,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
            Log.d(TAG, "Cancelled daily reminder alarm")
        }
    }

    /**
     * Called when the 5:00 PM alarm triggers.
     * Evaluates if the user has solved today's daily puzzle.
     * If not solved, dispatches the push notification.
     */
    fun checkAndSendReminder(context: Context) {
        val prefs = GamePreferences(context)
        if (!prefs.isDailyReminderEnabled()) {
            return
        }

        val stats = prefs.loadStats()
        val todayStr = DailyChallenges.getTodayDateString()

        // Check if the user has already completed today's challenge
        val alreadySolvedToday = stats.lastDailyDate == todayStr

        if (alreadySolvedToday) {
            Log.d(TAG, "Daily challenge already solved today ($todayStr). Skipping notification.")
            // Schedule the alarm for tomorrow 5 PM
            scheduleDailyReminder(context)
            return
        }

        // User has not solved today's daily challenge by 5 PM!
        sendReminderNotification(
            context = context,
            streak = stats.dailyStreak,
            isTest = false
        )

        // Reschedule for tomorrow 5 PM
        scheduleDailyReminder(context)
    }

    /**
     * Builds and posts the push notification.
     */
    fun sendReminderNotification(context: Context, streak: Int, isTest: Boolean = false) {
        createNotificationChannel(context)

        // Intent to open the game directly to the Daily Challenge modal
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_DAILY, true)
        }
        val contentPendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isTest) {
            "⏰ [Preview] Daily Challenge Reminder"
        } else if (streak > 0) {
            "🔥 Protect Your $streak-Day Streak!"
        } else {
            "📅 Today's Mystery Puzzle is Waiting!"
        }

        val multiplier = DailyChallenges.getStreakMultiplier(streak)
        val body = if (isTest) {
            "It's 5:00 PM! Solve today's mystery image puzzle before midnight to preserve your streak and earn +100 bonus coins."
        } else if (streak > 0) {
            "It's 5:00 PM! Solve today's mystery image puzzle to maintain your $streak-day streak and ${DailyChallenges.getMultiplierLabel(multiplier)} score multiplier!"
        } else {
            "It's 5:00 PM! Today's mystery image puzzle is waiting. Solve it now to start your streak and claim +100 bonus coins!"
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(contentPendingIntent)
            .addAction(0, "Play Challenge ➔", contentPendingIntent)

        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, builder.build())
            Log.d(TAG, "Push notification posted successfully.")
        } catch (e: SecurityException) {
            Log.w(TAG, "Notification permission not granted", e)
        }
    }

    /**
     * For user preview or immediate in-app testing
     */
    fun triggerTestNotification(context: Context) {
        val stats = GamePreferences(context).loadStats()
        sendReminderNotification(
            context = context,
            streak = stats.dailyStreak,
            isTest = true
        )
    }

    fun getNextScheduledReminderFormatted(context: Context): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, TARGET_HOUR_OF_DAY)
            set(Calendar.MINUTE, TARGET_MINUTE)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        val isToday = cal.get(Calendar.DAY_OF_YEAR) == Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val timeStr = SimpleDateFormat("h:mm a", Locale.US).format(cal.time)
        return if (isToday) "Today at $timeStr" else "Tomorrow at $timeStr"
    }
}
