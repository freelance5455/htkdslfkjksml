package com.example

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.ui.graphics.Color
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

// ==========================================
// PERSISTENT STORAGE: Videos, Photos, Dark User & Requests
// ==========================================

object VideoStorage {
  private const val FILE_NAME = "mtx_persistent_videos.json"

  fun loadVideos(context: Context): List<VideoItem> {
    val file = File(context.filesDir, FILE_NAME)
    if (!file.exists()) {
      return emptyList()
    }
    return try {
      val jsonStr = file.readText()
      val array = JSONArray(jsonStr)
      val list = mutableListOf<VideoItem>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val colorHex = obj.optLong("accentColor", 0xFF3B82F6L)
        list.add(
          VideoItem(
            id = obj.getInt("id"),
            title = obj.getString("title"),
            category = obj.getString("category"),
            duration = obj.optString("duration", "05:00"),
            views = obj.optString("views", "1"),
            description = obj.optString("description", ""),
            videoUri = obj.getString("videoUri"),
            isLocalFile = obj.optBoolean("isLocalFile", false),
            accentColor = Color(colorHex.toULong()),
            isPublished = obj.optBoolean("isPublished", true),
            isDark = obj.optBoolean("isDark", false) || obj.optString("isDark").equals("true", ignoreCase = true) || obj.optInt("isDark", 0) == 1
          )
        )
      }
      list
    } catch (_: Exception) {
      emptyList()
    }
  }

  fun saveVideos(context: Context, videos: List<VideoItem>) {
    try {
      val array = JSONArray()
      for (item in videos) {
        val obj = JSONObject()
        obj.put("id", item.id)
        obj.put("title", item.title)
        obj.put("category", item.category)
        obj.put("duration", item.duration)
        obj.put("views", item.views)
        obj.put("description", item.description)
        obj.put("videoUri", item.videoUri)
        obj.put("isLocalFile", item.isLocalFile)
        obj.put("accentColor", item.accentColor.value.toLong())
        obj.put("isPublished", item.isPublished)
        obj.put("isDark", item.isDark)
        array.put(obj)
      }
      val file = File(context.filesDir, FILE_NAME)
      file.writeText(array.toString(2))
    } catch (_: Exception) {}
  }
}

object PhotoStorage {
  private const val FILE_NAME = "mtx_persistent_photos.json"

  fun loadPhotos(context: Context): List<PhotoItem> {
    val file = File(context.filesDir, FILE_NAME)
    if (!file.exists()) {
      return emptyList()
    }
    return try {
      val jsonStr = file.readText()
      val array = JSONArray(jsonStr)
      val list = mutableListOf<PhotoItem>()
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        list.add(
          PhotoItem(
            id = obj.getInt("id"),
            title = obj.getString("title"),
            category = obj.getString("category"),
            imageUri = obj.getString("imageUri"),
            isLocalFile = obj.optBoolean("isLocalFile", false),
            uploadDate = obj.optString("uploadDate", "Today"),
            likes = obj.optInt("likes", 18),
            isPublished = obj.optBoolean("isPublished", true),
            isDark = obj.optBoolean("isDark", false) || obj.optString("isDark").equals("true", ignoreCase = true) || obj.optInt("isDark", 0) == 1
          )
        )
      }
      list
    } catch (_: Exception) {
      emptyList()
    }
  }

  fun savePhotos(context: Context, photos: List<PhotoItem>) {
    try {
      val array = JSONArray()
      for (item in photos) {
        val obj = JSONObject()
        obj.put("id", item.id)
        obj.put("title", item.title)
        obj.put("category", item.category)
        obj.put("imageUri", item.imageUri)
        obj.put("isLocalFile", item.isLocalFile)
        obj.put("uploadDate", item.uploadDate)
        obj.put("likes", item.likes)
        obj.put("isPublished", item.isPublished)
        obj.put("isDark", item.isDark)
        array.put(obj)
      }
      val file = File(context.filesDir, FILE_NAME)
      file.writeText(array.toString(2))
    } catch (_: Exception) {}
  }
}

// Stores the local device user's auth and approval state
object DarkUserStorage {
  private const val FILE_NAME = "mtx_dark_user_auth.json"

  fun load(context: Context): DarkUserAuth {
    val file = File(context.filesDir, FILE_NAME)
    if (!file.exists()) {
      val defaultId = "user_" + UUID.randomUUID().toString().take(8)
      val defaultAuth = DarkUserAuth(defaultId, "", "", false, "not_applied")
      save(context, defaultAuth)
      return defaultAuth
    }
    return try {
      val json = JSONObject(file.readText())
      DarkUserAuth(
        userId = json.optString("userId", "user_" + UUID.randomUUID().toString().take(8)),
        userName = json.optString("userName", ""),
        facePhotoUri = json.optString("facePhotoUri", ""),
        isApproved = json.optBoolean("isApproved", false),
        status = json.optString("status", "not_applied")
      )
    } catch (_: Exception) {
      DarkUserAuth("user_" + UUID.randomUUID().toString().take(8), "", "", false, "not_applied")
    }
  }

  fun save(context: Context, auth: DarkUserAuth) {
    try {
      val json = JSONObject().apply {
        put("userId", auth.userId)
        put("userName", auth.userName)
        put("facePhotoUri", auth.facePhotoUri)
        put("isApproved", auth.isApproved)
        put("status", auth.status)
      }
      File(context.filesDir, FILE_NAME).writeText(json.toString(2))
    } catch (_: Exception) {}
  }
}

// Stores all applications submitted by users so admin ALWAYS sees them
object DarkRequestStorage {
  private const val FILE_NAME = "mtx_dark_requests_list.json"

  fun loadRequests(context: Context): List<DarkUserApplication> {
    val list = mutableListOf<DarkUserApplication>()
    val file = File(context.filesDir, FILE_NAME)
    if (file.exists()) {
      try {
        val array = JSONArray(file.readText())
        for (i in 0 until array.length()) {
          val obj = array.getJSONObject(i)
          list.add(
            DarkUserApplication(
              userId = obj.getString("userId"),
              userName = obj.getString("userName"),
              facePhotoUri = obj.optString("facePhotoUri", ""),
              status = obj.optString("status", "pending"),
              appliedAt = obj.optString("appliedAt", "")
            )
          )
        }
      } catch (_: Exception) {}
    }

    // Always check current device user's auth: If user applied on this device, it MUST appear to admin!
    try {
      val userAuth = DarkUserStorage.load(context)
      if (userAuth.userName.isNotBlank() && (userAuth.facePhotoUri.isNotBlank() || userAuth.status == "pending" || userAuth.status == "approved")) {
        val existingIndex = list.indexOfFirst { it.userId == userAuth.userId }
        val currentApp = DarkUserApplication(
          userId = userAuth.userId,
          userName = userAuth.userName,
          facePhotoUri = userAuth.facePhotoUri,
          status = userAuth.status,
          appliedAt = "Just now"
        )
        if (existingIndex != -1) {
          list[existingIndex] = currentApp
        } else {
          list.add(0, currentApp)
        }
        saveRequests(context, list)
      }
    } catch (_: Exception) {}

    return list
  }

  fun saveRequest(context: Context, app: DarkUserApplication) {
    try {
      val existing = loadRequests(context).toMutableList()
      val idx = existing.indexOfFirst { it.userId == app.userId }
      if (idx != -1) {
        existing[idx] = app
      } else {
        existing.add(0, app)
      }
      saveRequests(context, existing)
    } catch (_: Exception) {}
  }

  fun updateStatus(context: Context, userId: String, newStatus: String) {
    try {
      val existing = loadRequests(context).toMutableList()
      val idx = existing.indexOfFirst { it.userId == userId }
      if (idx != -1) {
        existing[idx] = existing[idx].copy(status = newStatus)
        saveRequests(context, existing)
      }
    } catch (_: Exception) {}
  }

  fun saveRequests(context: Context, list: List<DarkUserApplication>) {
    try {
      val array = JSONArray()
      for (item in list) {
        val obj = JSONObject()
        obj.put("userId", item.userId)
        obj.put("userName", item.userName)
        obj.put("facePhotoUri", item.facePhotoUri)
        obj.put("status", item.status)
        obj.put("appliedAt", item.appliedAt)
        array.put(obj)
      }
      File(context.filesDir, FILE_NAME).writeText(array.toString(2))
    } catch (_: Exception) {}
  }
}

// ==========================================
// HELPERS: Media Processing
// ==========================================
fun copyMediaUriToLocalStorage(context: Context, uri: Uri, prefix: String, extension: String): Pair<String, String> {
  var title = "${prefix.replaceFirstChar { it.uppercase() }} ${System.currentTimeMillis() % 10000}"
  try {
    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
      val nameCol = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
      if (nameCol != -1 && cursor.moveToFirst()) {
        val name = cursor.getString(nameCol)
        if (!name.isNullOrBlank()) {
          title = name.substringBeforeLast(".")
        }
      }
    }
  } catch (_: Exception) {}

  val destFile = File(context.filesDir, "${prefix}_${System.currentTimeMillis()}.$extension")
  try {
    context.contentResolver.openInputStream(uri)?.use { input ->
      FileOutputStream(destFile).use { output ->
        input.copyTo(output)
      }
    }
    return Pair(destFile.absolutePath, title)
  } catch (_: Exception) {
    return Pair(uri.toString(), title)
  }
}

fun extractVideoDuration(filePath: String): String {
  return try {
    val retriever = MediaMetadataRetriever()
    retriever.setDataSource(filePath)
    val timeMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 185000L
    retriever.release()
    val totalSec = timeMs / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    String.format("%02d:%02d", min, sec)
  } catch (_: Exception) {
    "04:15"
  }
}
