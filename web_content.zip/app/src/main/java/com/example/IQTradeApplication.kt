package com.example

import android.app.Application

class IQTradeApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
