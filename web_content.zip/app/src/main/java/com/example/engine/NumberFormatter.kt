package com.example.engine

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.abs

enum class NumberGroupingStyle(val label: String, val example: String) {
  COMMA("Comma", "1,234.56"),
  SPACE("Space", "1 234.56"),
  NONE("None", "1234.56"),
}

data class FormattingOptions(
  val grouping: NumberGroupingStyle = NumberGroupingStyle.COMMA,
  val decimalPrecision: Int = -1, // -1 = Auto
)

object NumberFormatter {

  fun formatResult(value: BigDecimal, options: FormattingOptions = FormattingOptions()): String {
    if (value.compareTo(BigDecimal.ZERO) == 0) {
      return if (options.decimalPrecision > 0) {
        "0." + "0".repeat(options.decimalPrecision.coerceAtMost(10))
      } else {
        "0"
      }
    }

    val absVal = value.abs()
    if (absVal >= BigDecimal("1e12") || (absVal > BigDecimal.ZERO && absVal < BigDecimal("1e-8"))) {
      return formatScientific(value, options)
    }

    val rounded =
      if (options.decimalPrecision >= 0) {
        val scale = options.decimalPrecision.coerceIn(0, 10)
        value.setScale(scale, RoundingMode.HALF_UP)
      } else {
        val cleaned = value.round(MathContext(12, RoundingMode.HALF_UP))
        val scaleCapped = if (cleaned.scale() > 10) cleaned.setScale(10, RoundingMode.HALF_UP) else cleaned
        scaleCapped.stripTrailingZeros()
      }

    // If rounding pushed a value like 999999999999.9 to >= 1e12, switch cleanly to scientific notation
    if (options.decimalPrecision < 0 && rounded.abs() >= BigDecimal("1e12")) {
      return formatScientific(rounded, options)
    }

    val cleanRounded = if (rounded.compareTo(BigDecimal.ZERO) == 0) BigDecimal.ZERO else rounded
    val plain =
      if (options.decimalPrecision >= 0) {
        if (cleanRounded.compareTo(BigDecimal.ZERO) == 0) {
          if (options.decimalPrecision > 0) "0." + "0".repeat(options.decimalPrecision.coerceIn(0, 10)) else "0"
        } else {
          cleanRounded.toPlainString()
        }
      } else {
        cleanRounded.toPlainString()
      }

    return applyGrouping(plain, options.grouping)
  }

  fun formatDouble(value: Double, options: FormattingOptions = FormattingOptions()): String {
    if (value.isNaN() || value.isInfinite()) return "Error"
    val clean = if (value == 0.0) 0.0 else value
    val bd = BigDecimal.valueOf(clean)
    return formatResult(bd, options)
  }

  fun formatRawForExpression(value: BigDecimal): String {
    if (value.compareTo(BigDecimal.ZERO) == 0) return "0"
    val cleaned = value.round(MathContext(120, RoundingMode.HALF_UP)).stripTrailingZeros()
    val absVal = cleaned.abs()
    val str =
      if (absVal >= BigDecimal("1e120") || (absVal > BigDecimal.ZERO && absVal < BigDecimal("1e-18"))) {
        cleaned.toString()
      } else {
        cleaned.toPlainString()
      }
    return if (str.startsWith("-")) "−" + str.substring(1) else str
  }

  fun formatExpressionForDisplay(
    expression: String,
    grouping: NumberGroupingStyle = NumberGroupingStyle.COMMA,
  ): String {
    if (expression.isEmpty() || grouping == NumberGroupingStyle.NONE) return expression
    val sepChar = if (grouping == NumberGroupingStyle.COMMA) ',' else ' '
    val sb = StringBuilder(expression.length + 8)
    var i = 0
    while (i < expression.length) {
      val c = expression[i]
      if (c.isDigit()) {
        val start = i
        while (i < expression.length && (expression[i].isDigit() || expression[i] == '.')) {
          i++
        }
        val numToken = expression.substring(start, i)
        val prev = if (start > 0) expression[start - 1] else ' '
        val prev2 = if (start > 1) expression[start - 2] else ' '
        val isExponentDigits =
          prev == 'E' || prev == 'e' || ((prev == '+' || prev == '-') && (prev2 == 'E' || prev2 == 'e'))
        if (isExponentDigits || prev.isLetter()) {
          sb.append(numToken)
        } else {
          sb.append(groupDigitsOnly(numToken, sepChar))
        }
      } else {
        sb.append(c)
        i++
      }
    }
    return sb.toString()
  }

  private fun formatScientific(value: BigDecimal, options: FormattingOptions): String {
    val sigDigits = if (options.decimalPrecision >= 0) (options.decimalPrecision + 1).coerceIn(2, 10) else 10
    val rounded = value.round(MathContext(sigDigits, RoundingMode.HALF_UP)).stripTrailingZeros()
    return rounded.toString().replace("-", "−").replace("E+", "×10^").replace("E", "×10^")
  }

  private fun applyGrouping(plain: String, grouping: NumberGroupingStyle): String {
    val isNeg = plain.startsWith("-")
    val unsigned = if (isNeg) plain.substring(1) else plain
    val grouped =
      when (grouping) {
        NumberGroupingStyle.NONE -> unsigned
        NumberGroupingStyle.COMMA -> groupDigitsOnly(unsigned, ',')
        NumberGroupingStyle.SPACE -> groupDigitsOnly(unsigned, ' ')
      }
    return if (isNeg && grouped != "0") "−$grouped" else grouped
  }

  private fun groupDigitsOnly(num: String, sep: Char): String {
    val dotIdx = num.indexOf('.')
    val intPart = if (dotIdx >= 0) num.substring(0, dotIdx) else num
    val fracPart = if (dotIdx >= 0) num.substring(dotIdx) else ""
    if (intPart.length <= 3) return intPart + fracPart

    val sb = StringBuilder(intPart.length + intPart.length / 3)
    var count = 0
    for (idx in intPart.length - 1 downTo 0) {
      if (count > 0 && count % 3 == 0) {
        sb.append(sep)
      }
      sb.append(intPart[idx])
      count++
    }
    return sb.reverse().toString() + fracPart
  }
}
