package com.example.engine.future

import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Future-ready deterministic mathematical solver architecture.
 * All implemented solvers are strictly deterministic and mathematically verified
 * (no external APIs or unverified AI claims).
 */
data class SolverStep(
  val description: String,
  val equationState: String,
)

sealed interface SolverResult {
  data class Solved(
    val summary: String,
    val steps: List<SolverStep>,
  ) : SolverResult

  data class Invalid(val reason: String) : SolverResult
}

object DeterministicMathSolver {

  /** Solves ax + b = c */
  fun solveLinear(a: Double, b: Double, c: Double): SolverResult {
    if (a == 0.0) {
      return if (b == c) {
        SolverResult.Solved("Infinite solutions (identity)", emptyList())
      } else {
        SolverResult.Invalid("No solution (0x + $b = $c)")
      }
    }
    val rhs = c - b
    val x = rhs / a
    val steps =
      listOf(
        SolverStep("Start with equation", "${fmt(a)}x + ${fmt(b)} = ${fmt(c)}"),
        SolverStep("Subtract ${fmt(b)} from both sides", "${fmt(a)}x = ${fmt(rhs)}"),
        SolverStep("Divide both sides by ${fmt(a)}", "x = ${fmt(x)}"),
      )
    return SolverResult.Solved(summary = "x = ${fmt(x)}", steps = steps)
  }

  /** Solves ax² + bx + c = 0 */
  fun solveQuadratic(a: Double, b: Double, c: Double): SolverResult {
    if (a == 0.0) return solveLinear(b, c, 0.0)
    val discriminant = b * b - 4.0 * a * c
    val steps = mutableListOf(
      SolverStep("Standard form", "${fmt(a)}x² + ${fmt(b)}x + ${fmt(c)} = 0"),
      SolverStep("Compute discriminant Δ = b² − 4ac", "Δ = ${fmt(discriminant)}"),
    )
    return when {
      discriminant > 0 -> {
        val sqrtD = sqrt(discriminant)
        val x1 = (-b + sqrtD) / (2.0 * a)
        val x2 = (-b - sqrtD) / (2.0 * a)
        steps.add(SolverStep("Two real roots", "x₁ = ${fmt(x1)}, x₂ = ${fmt(x2)}"))
        SolverResult.Solved("x₁ = ${fmt(x1)}, x₂ = ${fmt(x2)}", steps)
      }
      abs(discriminant) < 1e-12 -> {
        val x = -b / (2.0 * a)
        steps.add(SolverStep("One repeated real root", "x = ${fmt(x)}"))
        SolverResult.Solved("x = ${fmt(x)}", steps)
      }
      else -> {
        val real = -b / (2.0 * a)
        val imag = sqrt(-discriminant) / abs(2.0 * a)
        val summary = "x₁ = ${fmt(real)} + ${fmt(imag)}i, x₂ = ${fmt(real)} − ${fmt(imag)}i"
        steps.add(SolverStep("Complex conjugate roots", summary))
        SolverResult.Solved(summary, steps)
      }
    }
  }

  private fun fmt(v: Double): String {
    val clean = if (abs(v) < 1e-12) 0.0 else v
    return if (clean == clean.toLong().toDouble()) clean.toLong().toString() else "%.6g".format(clean)
  }
}
