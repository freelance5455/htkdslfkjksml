package com.example.engine

data class AudioAnalysisResult(
  val trackTitle: String,
  val durationSeconds: Float,
  val bpm: Int,
  val confidence: Float,
  val beatTimestamps: List<Float>,
  val envelopeIntensity: List<Float>
)

object AudioAnalyzer {

  fun analyzeAudio(title: String, duration: Float, syncIntensity: String): AudioAnalysisResult {
    val bpm = 120
    val beatInterval = 60.0f / bpm // 0.5s per beat
    val beats = mutableListOf<Float>()
    var t = 0.0f
    while (t < duration) {
      beats.add(t)
      t += beatInterval
    }

    val envelope = mutableListOf<Float>()
    val steps = (duration * 10).toInt()
    for (i in 0 until steps) {
      val progress = i.toFloat() / steps
      val intensity = 0.5f + 0.5f * kotlin.math.sin(progress * 20.0f).let { if (it > 0) it else -it }
      envelope.add(intensity * when(syncIntensity) {
        "aggressive" -> 1.2f
        "subtle" -> 0.7f
        else -> 1.0f
      })
    }

    return AudioAnalysisResult(
      trackTitle = title,
      durationSeconds = duration,
      bpm = bpm,
      confidence = 0.94f,
      beatTimestamps = beats,
      envelopeIntensity = envelope
    )
  }
}
