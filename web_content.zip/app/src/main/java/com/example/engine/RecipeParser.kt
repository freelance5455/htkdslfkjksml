package com.example.engine

import com.example.model.*
import org.json.JSONObject

object RecipeParser {

  fun parseAndValidate(jsonString: String): ValidationResult {
    val errors = mutableListOf<String>()
    val warnings = mutableListOf<String>()

    if (jsonString.isBlank()) {
      return ValidationResult(false, listOf("Recipe code is empty."))
    }

    try {
      val root = JSONObject(jsonString)
      val version = root.optString("version", "1.0")
      val projectName = root.optString("projectName", "Imported Motion Project")

      val settingsObj = root.optJSONObject("settings")
      val width = settingsObj?.optInt("width", 1080) ?: 1080
      val height = settingsObj?.optInt("height", 1920) ?: 1920
      val fps = settingsObj?.optInt("fps", 30) ?: 30
      val duration = settingsObj?.optDouble("durationSeconds", 10.0)?.toFloat() ?: 10.0f
      val visualStyle = settingsObj?.optString("visualStyle", "cyberpunk") ?: "cyberpunk"

      val scenesArray = root.optJSONArray("scenes")
      val scenes = mutableListOf<Scene>()

      if (scenesArray != null) {
        for (i in 0 until scenesArray.length()) {
          val sObj = scenesArray.getJSONObject(i)
          val sId = sObj.optString("id", "scene_$i")
          val sName = sObj.optString("name", "Scene $i")
          val sStart = sObj.optDouble("startTime", 0.0).toFloat()
          val sDur = sObj.optDouble("duration", 10.0).toFloat()

          val layersArray = sObj.optJSONArray("layers")
          val layers = mutableListOf<Layer>()
          if (layersArray != null) {
            for (j in 0 until layersArray.length()) {
              val lObj = layersArray.getJSONObject(j)
              val lId = lObj.optString("id", "layer_$j")
              val lName = lObj.optString("name", "Layer $j")
              val lType = lObj.optString("type", "text")
              val lStart = lObj.optDouble("startTime", 0.0).toFloat()
              val lDur = lObj.optDouble("duration", 5.0).toFloat()
              val posX = lObj.optDouble("posX", 540.0).toFloat()
              val posY = lObj.optDouble("posY", 960.0).toFloat()
              val scale = lObj.optDouble("scale", 1.0).toFloat()
              val rot = lObj.optDouble("rotation", 0.0).toFloat()
              val op = lObj.optDouble("opacity", 1.0).toFloat()

              var textConfig: TextConfig? = null
              var shapeConfig: ShapeConfig? = null
              var obj3DConfig: Object3DConfig? = null

              if (lType == "text" && lObj.has("textConfig")) {
                val tc = lObj.getJSONObject("textConfig")
                textConfig = TextConfig(
                  text = tc.optString("text", "Motion Text"),
                  fontSize = tc.optInt("fontSize", 56),
                  color = tc.optString("color", "#FFFFFF"),
                  revealMode = tc.optString("revealMode", "word_by_word")
                )
              } else if (lType == "text") {
                textConfig = TextConfig(text = lName, fontSize = 56, color = "#FFFFFF")
              }

              if (lType == "shape" && lObj.has("shapeConfig")) {
                val sc = lObj.getJSONObject("shapeConfig")
                shapeConfig = ShapeConfig(
                  shape = sc.optString("shape", "rounded_rect"),
                  color = sc.optString("color", "#FF6B00"),
                  glow = sc.optBoolean("glow", true)
                )
              } else if (lType == "shape") {
                shapeConfig = ShapeConfig(shape = "rounded_rect", color = "#FF6B00")
              }

              if (lType == "3d" && lObj.has("object3DConfig")) {
                val o3 = lObj.getJSONObject("object3DConfig")
                obj3DConfig = Object3DConfig(
                  primitive = o3.optString("primitive", "cube"),
                  color = o3.optString("color", "#FF9E00"),
                  wireframe = o3.optBoolean("wireframe", false)
                )
              } else if (lType == "3d") {
                obj3DConfig = Object3DConfig(primitive = "cube", color = "#FF9E00")
              }

              layers.add(
                Layer(
                  id = lId,
                  name = lName,
                  type = lType,
                  startTime = lStart,
                  duration = lDur,
                  posX = posX,
                  posY = posY,
                  scale = scale,
                  rotation = rot,
                  opacity = op,
                  textConfig = textConfig,
                  shapeConfig = shapeConfig,
                  object3DConfig = obj3DConfig
                )
              )
            }
          }

          scenes.add(
            Scene(
              id = sId,
              name = sName,
              startTime = sStart,
              duration = sDur,
              layers = layers
            )
          )
        }
      } else {
        warnings.add("No scenes specified in recipe. Default scene created.")
        scenes.add(
          Scene(
            id = "default_scene",
            name = "Default Scene",
            layers = listOf(
              Layer(
                id = "l1",
                name = "Title",
                type = "text",
                textConfig = TextConfig("MotionForge AI", 64, "#FFFFFF")
              )
            )
          )
        )
      }

      val recipe = ProjectRecipe(
        version = version,
        projectName = projectName,
        settings = ProjectSettings(width, height, fps, duration, visualStyle),
        scenes = scenes
      )

      return ValidationResult(true, errors, warnings, recipe)

    } catch (e: Exception) {
      errors.add("JSON Parse Error: ${e.localizedMessage}")
      return ValidationResult(false, errors, warnings, null)
    }
  }

  fun getSampleRecipes(): Map<String, String> {
    return mapOf(
      "Cyberpunk Cinematic Title" to """
        {
          "version": "1.0",
          "projectName": "Cyberpunk Cinematic Title",
          "settings": {
            "width": 1080,
            "height": 1920,
            "fps": 30,
            "durationSeconds": 8.0,
            "visualStyle": "cyberpunk"
          },
          "scenes": [
            {
              "id": "scene_1",
              "name": "Title Sequence",
              "startTime": 0.0,
              "duration": 8.0,
              "layers": [
                {
                  "id": "bg_glow",
                  "name": "Neon Backdrop",
                  "type": "shape",
                  "startTime": 0.0,
                  "duration": 8.0,
                  "posX": 540,
                  "posY": 960,
                  "scale": 1.2,
                  "shapeConfig": {
                    "shape": "rect",
                    "color": "#FF6B00",
                    "glow": true
                  }
                },
                {
                  "id": "title_text",
                  "name": "Main Headline",
                  "type": "text",
                  "startTime": 0.5,
                  "duration": 7.0,
                  "posX": 540,
                  "posY": 850,
                  "scale": 1.0,
                  "textConfig": {
                    "text": "NEXT-GEN MOTION",
                    "fontSize": 64,
                    "color": "#FFFFFF",
                    "revealMode": "character_fade"
                  }
                },
                {
                  "id": "subtitle_text",
                  "name": "Subtitle Badge",
                  "type": "text",
                  "startTime": 1.2,
                  "duration": 6.5,
                  "posX": 540,
                  "posY": 980,
                  "scale": 1.0,
                  "textConfig": {
                    "text": "POWERED BY AI ENGINE",
                    "fontSize": 32,
                    "color": "#FF9E00",
                    "revealMode": "word_by_word"
                  }
                },
                {
                  "id": "cube_3d",
                  "name": "Core 3D Object",
                  "type": "3d",
                  "startTime": 0.0,
                  "duration": 8.0,
                  "posX": 540,
                  "posY": 1300,
                  "scale": 1.5,
                  "object3DConfig": {
                    "primitive": "cube",
                    "color": "#FF6B00",
                    "wireframe": false
                  }
                }
              ]
            }
          ]
        }
      """.trimIndent(),

      "Neon Social Media Burst" to """
        {
          "version": "1.0",
          "projectName": "Neon Social Media Burst",
          "settings": {
            "width": 1080,
            "height": 1080,
            "fps": 30,
            "durationSeconds": 6.0,
            "visualStyle": "luxury"
          },
          "scenes": [
            {
              "id": "scene_1",
              "name": "Square Intro",
              "startTime": 0.0,
              "duration": 6.0,
              "layers": [
                {
                  "id": "shape_pulse",
                  "name": "Pulsing Ring",
                  "type": "shape",
                  "startTime": 0.0,
                  "duration": 6.0,
                  "posX": 540,
                  "posY": 540,
                  "scale": 1.0,
                  "shapeConfig": {
                    "shape": "circle",
                    "color": "#FF6B00",
                    "glow": true
                  }
                },
                {
                  "id": "badge_text",
                  "name": "Brand Title",
                  "type": "text",
                  "startTime": 0.5,
                  "duration": 5.5,
                  "posX": 540,
                  "posY": 520,
                  "scale": 1.1,
                  "textConfig": {
                    "text": "MOTIONFORGE",
                    "fontSize": 58,
                    "color": "#FFFFFF",
                    "revealMode": "character_fade"
                  }
                }
              ]
            }
          ]
        }
      """.trimIndent(),

      "3D Geometric Showcase" to """
        {
          "version": "1.0",
          "projectName": "3D Geometric Showcase",
          "settings": {
            "width": 1920,
            "height": 1080,
            "fps": 30,
            "durationSeconds": 10.0,
            "visualStyle": "futuristic"
          },
          "scenes": [
            {
              "id": "scene_1",
              "name": "Landscape 3D",
              "startTime": 0.0,
              "duration": 10.0,
              "layers": [
                {
                  "id": "obj_sphere",
                  "name": "Sphere 3D",
                  "type": "3d",
                  "startTime": 0.0,
                  "duration": 10.0,
                  "posX": 960,
                  "posY": 540,
                  "scale": 2.0,
                  "object3DConfig": {
                    "primitive": "sphere",
                    "color": "#FF9E00",
                    "wireframe": true
                  }
                },
                {
                  "id": "hud_text",
                  "name": "HUD Overlay",
                  "type": "text",
                  "startTime": 1.0,
                  "duration": 9.0,
                  "posX": 960,
                  "posY": 200,
                  "scale": 1.0,
                  "textConfig": {
                    "text": "REAL-TIME 3D RENDERING",
                    "fontSize": 44,
                    "color": "#FF6B00",
                    "revealMode": "word_by_word"
                  }
                }
              ]
            }
          ]
        }
      """.trimIndent()
    )
  }
}
