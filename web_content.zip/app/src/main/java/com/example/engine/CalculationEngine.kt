package com.example.engine

import java.math.BigDecimal
import java.math.BigInteger
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.*

enum class AngleMode {
  DEG,
  RAD,
}

enum class CalcError(val message: String) {
  DIVISION_BY_ZERO("Can't divide by zero"),
  DOMAIN_ERROR("Domain error"),
  SYNTAX_ERROR("Invalid expression"),
  OVERFLOW("Value too large"),
}

sealed interface EvalResult {
  data class Success(
    val value: BigDecimal,
    val formatted: String,
    val rawNumericString: String,
  ) : EvalResult

  data class Error(val error: CalcError) : EvalResult
}

/**
 * Pure Kotlin, UI-independent mathematical expression parser and evaluator.
 * Uses a Recursive Descent Parser with IEEE decimal128 (34-digit) precision
 * and exact BigDecimal arithmetic for +, -, * (capped safely for huge inputs).
 * Never uses eval().
 */
object CalculationEngine {

  private val MATH_CTX = MathContext(34, RoundingMode.HALF_UP)
  private val EXACT_CAP_CTX = MathContext(120, RoundingMode.HALF_UP)
  private val PI_BD = BigDecimal("3.1415926535897932384626433832795029")
  private val E_BD = BigDecimal("2.7182818284590452353602874713526625")
  private val LN_10_BD = BigDecimal("2.3025850929940456840179914546843642")

  private const val MAX_EXPONENT = 100_000
  private const val MAX_FACTORIAL = 1_000
  private const val MAX_EXACT_SPAN = 1_000

  private sealed interface Token {
    data class Number(val raw: String) : Token
    data class Constant(val symbol: String) : Token
    data class Function(val name: String) : Token
    data class Op(val symbol: Char) : Token
    data object LParen : Token
    data object RParen : Token
    data object Comma : Token
    data object Percent : Token
    data object Factorial : Token
  }

  private sealed interface ExprNode {
    data class Num(val value: BigDecimal) : ExprNode
    data class Const(val symbol: String) : ExprNode
    data class UnaryMinus(val inner: ExprNode) : ExprNode
    data class Percent(val inner: ExprNode) : ExprNode
    data class Factorial(val inner: ExprNode) : ExprNode
    data class Binary(val op: Char, val left: ExprNode, val right: ExprNode) : ExprNode
    data class FuncCall(val name: String, val args: List<ExprNode>) : ExprNode
  }

  fun evaluate(
    rawExpression: String,
    angleMode: AngleMode = AngleMode.DEG,
    formatting: FormattingOptions = FormattingOptions(),
    autoCloseParens: Boolean = true,
  ): EvalResult {
    val trimmed = rawExpression.trim()
    if (trimmed.isEmpty()) return EvalResult.Error(CalcError.SYNTAX_ERROR)

    val tokens =
      try {
        tokenize(trimmed, autoCloseParens)
      } catch (_: CalcException) {
        return EvalResult.Error(CalcError.SYNTAX_ERROR)
      }

    if (tokens.isEmpty()) return EvalResult.Error(CalcError.SYNTAX_ERROR)

    val parser = Parser(tokens)
    val ast =
      try {
        val node = parser.parseExpression()
        if (!parser.isAtEnd()) throw CalcException(CalcError.SYNTAX_ERROR)
        node
      } catch (e: CalcException) {
        return EvalResult.Error(e.error)
      }

    return try {
      val result = evalNode(ast, angleMode)
      if (result.scale() < -1_000_000 || result.scale() > 1_000_000) {
        return EvalResult.Error(CalcError.OVERFLOW)
      }
      val formatted = NumberFormatter.formatResult(result, formatting)
      val rawString = NumberFormatter.formatRawForExpression(result)
      EvalResult.Success(value = result, formatted = formatted, rawNumericString = rawString)
    } catch (e: CalcException) {
      EvalResult.Error(e.error)
    } catch (_: ArithmeticException) {
      EvalResult.Error(CalcError.OVERFLOW)
    } catch (_: Exception) {
      EvalResult.Error(CalcError.DOMAIN_ERROR)
    }
  }

  fun evaluateLivePreview(
    rawExpression: String,
    angleMode: AngleMode = AngleMode.DEG,
    formatting: FormattingOptions = FormattingOptions(),
  ): EvalResult? {
    val trimmed = rawExpression.trim()
    if (trimmed.isEmpty()) return null
    val lastChar = trimmed.last()
    if (lastChar in charArrayOf('+', '−', '-', '×', '*', '÷', '/', '^', '(', ',')) {
      return null
    }
    return evaluate(trimmed, angleMode, formatting, autoCloseParens = true)
  }

  private fun tokenize(input: String, autoCloseParens: Boolean): List<Token> {
    val tokens = mutableListOf<Token>()
    var i = 0
    val normalized =
      input
        .replace(" ", "")
        .replace("\u00A0", "")
        .replace('−', '-')
        .replace('×', '*')
        .replace('÷', '/')

    while (i < normalized.length) {
      val ch = normalized[i]
      when {
        ch.isDigit() || ch == '.' -> {
          val start = i
          var dotCount = if (ch == '.') 1 else 0
          i++
          while (i < normalized.length && (normalized[i].isDigit() || normalized[i] == '.')) {
            if (normalized[i] == '.') {
              dotCount++
              if (dotCount > 1) throw CalcException(CalcError.SYNTAX_ERROR)
            }
            i++
          }
          if (i < normalized.length && (normalized[i] == 'E' || normalized[i] == 'e')) {
            val next = normalized.getOrNull(i + 1)
            val afterNext = normalized.getOrNull(i + 2)
            val isSciNotation =
              (next != null && next.isDigit()) ||
                ((next == '+' || next == '-') && afterNext != null && afterNext.isDigit())
            if (isSciNotation) {
              i++
              if (normalized[i] == '+' || normalized[i] == '-') i++
              while (i < normalized.length && normalized[i].isDigit()) i++
            }
          }
          val numStr = normalized.substring(start, i)
          if (numStr == ".") throw CalcException(CalcError.SYNTAX_ERROR)
          insertImplicitMultiplicationIfNeeded(tokens)
          tokens.add(Token.Number(numStr))
        }
        ch == 'π' -> {
          insertImplicitMultiplicationIfNeeded(tokens)
          tokens.add(Token.Constant("π"))
          i++
        }
        ch == '√' -> {
          insertImplicitMultiplicationIfNeeded(tokens)
          tokens.add(Token.Function("sqrt"))
          i++
          if (i < normalized.length && normalized[i] == '(') {
            tokens.add(Token.LParen)
            i++
          } else {
            tokens.add(Token.LParen)
            val atomStart = i
            while (i < normalized.length && (normalized[i].isDigit() || normalized[i] == '.')) i++
            if (i == atomStart) throw CalcException(CalcError.SYNTAX_ERROR)
            tokens.add(Token.Number(normalized.substring(atomStart, i)))
            tokens.add(Token.RParen)
          }
        }
        ch == '∛' -> {
          insertImplicitMultiplicationIfNeeded(tokens)
          tokens.add(Token.Function("cbrt"))
          i++
          if (i < normalized.length && normalized[i] == '(') {
            tokens.add(Token.LParen)
            i++
          } else {
            throw CalcException(CalcError.SYNTAX_ERROR)
          }
        }
        ch.isLetter() -> {
          val start = i
          while (
            i < normalized.length &&
              (normalized[i].isLetterOrDigit() || normalized[i] == '_' || normalized[i] == 'ₙ')
          ) {
            i++
          }
          val ident = normalized.substring(start, i)
          if (ident == "e" || ident == "pi") {
            insertImplicitMultiplicationIfNeeded(tokens)
            tokens.add(Token.Constant(if (ident == "pi") "π" else "e"))
          } else {
            val mappedFunc =
              when (ident.lowercase()) {
                "sin",
                "cos",
                "tan",
                "asin",
                "acos",
                "atan",
                "sinh",
                "cosh",
                "tanh",
                "log",
                "ln",
                "logbase",
                "logₙ",
                "sqrt",
                "cbrt",
                "nroot",
                "abs" -> ident.lowercase().replace("logₙ", "logbase")
                else -> throw CalcException(CalcError.SYNTAX_ERROR)
              }
            insertImplicitMultiplicationIfNeeded(tokens)
            tokens.add(Token.Function(mappedFunc))
            if (i >= normalized.length || normalized[i] != '(') {
              throw CalcException(CalcError.SYNTAX_ERROR)
            }
          }
        }
        ch == '(' -> {
          val prev = tokens.lastOrNull()
          if (prev !is Token.Function) {
            insertImplicitMultiplicationIfNeeded(tokens)
          }
          tokens.add(Token.LParen)
          i++
        }
        ch == ')' -> {
          tokens.add(Token.RParen)
          i++
        }
        ch == ',' -> {
          tokens.add(Token.Comma)
          i++
        }
        ch == '%' -> {
          tokens.add(Token.Percent)
          i++
        }
        ch == '!' -> {
          tokens.add(Token.Factorial)
          i++
        }
        ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^' -> {
          tokens.add(Token.Op(ch))
          i++
        }
        else -> throw CalcException(CalcError.SYNTAX_ERROR)
      }
    }

    if (autoCloseParens) {
      var openCount = 0
      for (t in tokens) {
        if (t is Token.LParen) openCount++ else if (t is Token.RParen) openCount--
      }
      repeat(openCount.coerceAtLeast(0)) { tokens.add(Token.RParen) }
    }

    return tokens
  }

  private fun insertImplicitMultiplicationIfNeeded(tokens: MutableList<Token>) {
    val prev = tokens.lastOrNull() ?: return
    if (
      prev is Token.Number ||
        prev is Token.Constant ||
        prev is Token.RParen ||
        prev is Token.Percent ||
        prev is Token.Factorial
    ) {
      tokens.add(Token.Op('*'))
    }
  }

  private class Parser(private val tokens: List<Token>) {
    private var pos = 0

    fun isAtEnd(): Boolean = pos >= tokens.size

    private fun peek(): Token? = tokens.getOrNull(pos)

    private fun consume(): Token = tokens[pos++]

    fun parseExpression(): ExprNode = parseAddSub()

    private fun parseAddSub(): ExprNode {
      var left = parseMulDiv()
      while (true) {
        val t = peek()
        if (t is Token.Op && (t.symbol == '+' || t.symbol == '-')) {
          consume()
          val right = parseMulDiv()
          left = ExprNode.Binary(t.symbol, left, right)
        } else {
          break
        }
      }
      return left
    }

    private fun parseMulDiv(): ExprNode {
      var left = parseUnary()
      while (true) {
        val t = peek()
        if (t is Token.Op && (t.symbol == '*' || t.symbol == '/')) {
          consume()
          val right = parseUnary()
          left = ExprNode.Binary(t.symbol, left, right)
        } else {
          break
        }
      }
      return left
    }

    private fun parseUnary(): ExprNode {
      val t = peek()
      if (t is Token.Op && t.symbol == '-') {
        consume()
        return ExprNode.UnaryMinus(parseUnary())
      }
      return parsePower()
    }

    private fun parsePower(): ExprNode {
      val base = parsePostfix()
      val t = peek()
      return if (t is Token.Op && t.symbol == '^') {
        consume()
        val exponent = parseUnary()
        ExprNode.Binary('^', base, exponent)
      } else {
        base
      }
    }

    private fun parsePostfix(): ExprNode {
      var node = parsePrimary()
      while (true) {
        when (peek()) {
          is Token.Percent -> {
            consume()
            node = ExprNode.Percent(node)
          }
          is Token.Factorial -> {
            consume()
            node = ExprNode.Factorial(node)
          }
          else -> break
        }
      }
      return node
    }

    private fun parsePrimary(): ExprNode {
      return when (val t = peek()) {
        is Token.Number -> {
          consume()
          val bd = t.raw.toBigDecimalOrNull() ?: throw CalcException(CalcError.SYNTAX_ERROR)
          ExprNode.Num(bd)
        }
        is Token.Constant -> {
          consume()
          ExprNode.Const(t.symbol)
        }
        is Token.LParen -> {
          consume()
          val inner = parseExpression()
          if (peek() !is Token.RParen) throw CalcException(CalcError.SYNTAX_ERROR)
          consume()
          inner
        }
        is Token.Function -> {
          consume()
          if (peek() !is Token.LParen) throw CalcException(CalcError.SYNTAX_ERROR)
          consume()
          val args = mutableListOf<ExprNode>()
          if (peek() is Token.RParen) {
            throw CalcException(CalcError.SYNTAX_ERROR)
          }
          args.add(parseExpression())
          while (peek() is Token.Comma) {
            consume()
            args.add(parseExpression())
          }
          if (peek() !is Token.RParen) throw CalcException(CalcError.SYNTAX_ERROR)
          consume()
          ExprNode.FuncCall(t.name, args)
        }
        else -> throw CalcException(CalcError.SYNTAX_ERROR)
      }
    }
  }

  private fun evalNode(node: ExprNode, angleMode: AngleMode): BigDecimal {
    return when (node) {
      is ExprNode.Num -> node.value
      is ExprNode.Const ->
        when (node.symbol) {
          "π" -> PI_BD
          "e" -> E_BD
          else -> throw CalcException(CalcError.SYNTAX_ERROR)
        }
      is ExprNode.UnaryMinus -> evalNode(node.inner, angleMode).negate()
      is ExprNode.Percent -> {
        val inner = evalNode(node.inner, angleMode)
        inner.divide(BigDecimal(100), EXACT_CAP_CTX)
      }
      is ExprNode.Factorial -> {
        val v = evalNode(node.inner, angleMode)
        val stripped = v.stripTrailingZeros()
        if (stripped.signum() < 0 || stripped.scale() > 0) {
          throw CalcException(CalcError.DOMAIN_ERROR)
        }
        if (stripped > BigDecimal(MAX_FACTORIAL)) {
          throw CalcException(CalcError.OVERFLOW)
        }
        val n = stripped.intValueExact()
        var fact = BigDecimal.ONE
        for (k in 2..n) {
          fact = fact.multiply(BigDecimal(k), EXACT_CAP_CTX)
        }
        fact
      }
      is ExprNode.Binary -> {
        if ((node.op == '+' || node.op == '-') && node.right is ExprNode.Percent) {
          val leftVal = evalNode(node.left, angleMode)
          val pctInner = evalNode(node.right.inner, angleMode)
          val delta = leftVal.multiply(pctInner, EXACT_CAP_CTX).divide(BigDecimal(100), EXACT_CAP_CTX)
          return if (node.op == '+') safeExactAdd(leftVal, delta) else safeExactSubtract(leftVal, delta)
        }
        val left = evalNode(node.left, angleMode)
        val right = evalNode(node.right, angleMode)
        when (node.op) {
          '+' -> safeExactAdd(left, right)
          '-' -> safeExactSubtract(left, right)
          '*' -> left.multiply(right, EXACT_CAP_CTX)
          '/' -> {
            if (right.compareTo(BigDecimal.ZERO) == 0) {
              throw CalcException(CalcError.DIVISION_BY_ZERO)
            }
            left.divide(right, MATH_CTX)
          }
          '^' -> evalPower(left, right)
          else -> throw CalcException(CalcError.SYNTAX_ERROR)
        }
      }
      is ExprNode.FuncCall -> evalFunction(node.name, node.args, angleMode)
    }
  }

  private fun evalPower(left: BigDecimal, right: BigDecimal): BigDecimal {
    val strippedExp = right.stripTrailingZeros()
    if (strippedExp.scale() <= 0) {
      val expLong =
        try {
          strippedExp.longValueExact()
        } catch (_: ArithmeticException) {
          throw CalcException(CalcError.OVERFLOW)
        }
      if (expLong < -MAX_EXPONENT.toLong() || expLong > MAX_EXPONENT.toLong()) {
        if (left.compareTo(BigDecimal.ONE) == 0) return BigDecimal.ONE
        if (left.compareTo(BigDecimal.ZERO) == 0) {
          return if (expLong > 0L) BigDecimal.ZERO else throw CalcException(CalcError.DIVISION_BY_ZERO)
        }
        throw CalcException(CalcError.OVERFLOW)
      }
      val n = expLong.toInt()
      if (n == 0) return BigDecimal.ONE
      if (n > 0) {
        return left.pow(n, MATH_CTX)
      }
      if (left.compareTo(BigDecimal.ZERO) == 0) {
        throw CalcException(CalcError.DIVISION_BY_ZERO)
      }
      val posPow = left.pow(-n, MATH_CTX)
      return BigDecimal.ONE.divide(posPow, MATH_CTX)
    }

    if (left.compareTo(BigDecimal.ZERO) == 0) {
      if (right.signum() < 0) throw CalcException(CalcError.DIVISION_BY_ZERO)
      return BigDecimal.ZERO
    }
    if (left.signum() < 0) {
      throw CalcException(CalcError.DOMAIN_ERROR)
    }

    val exp10 = left.precision().toLong() - left.scale().toLong() - 1L
    val mantissa = left.movePointLeft(exp10.coerceIn(-1_000_000L, 1_000_000L).toInt()).toDouble()
    val rightDouble = toCheckedDouble(right)
    if (abs(exp10) <= 250L) {
      val leftDouble = left.toDouble()
      if (leftDouble.isFinite() && leftDouble > 0.0) {
        val powRes = leftDouble.pow(rightDouble)
        if (powRes.isFinite() && (powRes != 0.0 || leftDouble == 0.0)) {
          return fromCheckedDouble(powRes)
        }
      }
    }
    val totalLog10 = (log10(mantissa) + exp10.toDouble()) * rightDouble
    if (totalLog10.isNaN()) throw CalcException(CalcError.DOMAIN_ERROR)
    if (totalLog10.isInfinite() || abs(totalLog10) > 1_000_000.0) {
      throw CalcException(CalcError.OVERFLOW)
    }
    val resExp10 = floor(totalLog10).toInt()
    val fracExp = totalLog10 - resExp10
    val resMantissa = 10.0.pow(fracExp)
    return BigDecimal.valueOf(resMantissa).round(MathContext(14, RoundingMode.HALF_UP)).movePointRight(resExp10)
  }

  private fun evalFunction(
    name: String,
    args: List<ExprNode>,
    angleMode: AngleMode,
  ): BigDecimal {
    when (name) {
      "logbase" -> {
        if (args.size != 2) throw CalcException(CalcError.SYNTAX_ERROR)
        val base = evalNode(args[0], angleMode)
        val value = evalNode(args[1], angleMode)
        if (base.signum() <= 0 || base.compareTo(BigDecimal.ONE) == 0 || value.signum() <= 0) {
          throw CalcException(CalcError.DOMAIN_ERROR)
        }
        val lnVal = evalLnHighPrecision(value)
        val lnBase = evalLnHighPrecision(base)
        return lnVal.divide(lnBase, MATH_CTX).round(MathContext(14, RoundingMode.HALF_UP))
      }
      "nroot" -> {
        if (args.size != 2) throw CalcException(CalcError.SYNTAX_ERROR)
        val nBd = evalNode(args[0], angleMode)
        val xBd = evalNode(args[1], angleMode)
        if (nBd.compareTo(BigDecimal.ZERO) == 0) throw CalcException(CalcError.DOMAIN_ERROR)
        val nStripped = nBd.stripTrailingZeros()
        if (nStripped.scale() <= 0) {
          val nInt =
            try {
              nStripped.intValueExact()
            } catch (_: ArithmeticException) {
              null
            }
          if (nInt != null && nInt >= -MAX_EXPONENT && nInt <= MAX_EXPONENT) {
            return evalIntegerRoot(nInt, xBd)
          }
        }
        val n = toCheckedDouble(nBd)
        if (xBd.signum() < 0) {
          val nInt = n.roundToInt()
          if (abs(n - nInt) < 1e-12 && abs(nInt % 2) == 1) {
            val posRoot = evalPower(xBd.negate(), BigDecimal.ONE.divide(nBd, MATH_CTX))
            return posRoot.negate()
          }
          throw CalcException(CalcError.DOMAIN_ERROR)
        }
        return evalPower(xBd, BigDecimal.ONE.divide(nBd, MATH_CTX))
      }
    }

    if (args.size != 1) throw CalcException(CalcError.SYNTAX_ERROR)
    val argBd = evalNode(args[0], angleMode)

    return when (name) {
      "sin" -> evalTrig("sin", argBd, angleMode)
      "cos" -> evalTrig("cos", argBd, angleMode)
      "tan" -> evalTrig("tan", argBd, angleMode)
      "asin" -> {
        val x = toCheckedDouble(argBd)
        if (x < -1.0 || x > 1.0) throw CalcException(CalcError.DOMAIN_ERROR)
        val rad = asin(x)
        fromCheckedDouble(if (angleMode == AngleMode.DEG) Math.toDegrees(rad) else rad)
      }
      "acos" -> {
        val x = toCheckedDouble(argBd)
        if (x < -1.0 || x > 1.0) throw CalcException(CalcError.DOMAIN_ERROR)
        val rad = acos(x)
        fromCheckedDouble(if (angleMode == AngleMode.DEG) Math.toDegrees(rad) else rad)
      }
      "atan" -> {
        val x = toCheckedDouble(argBd)
        val rad = atan(x)
        fromCheckedDouble(if (angleMode == AngleMode.DEG) Math.toDegrees(rad) else rad)
      }
      "sinh" -> fromCheckedDouble(sinh(toCheckedDouble(argBd)))
      "cosh" -> fromCheckedDouble(cosh(toCheckedDouble(argBd)))
      "tanh" -> {
        if (argBd > BigDecimal(50)) return BigDecimal.ONE
        if (argBd < BigDecimal(-50)) return BigDecimal("-1")
        fromCheckedDouble(tanh(toCheckedDouble(argBd)))
      }
      "log" -> evalLog10(argBd)
      "ln" -> evalLnHighPrecision(argBd).round(MathContext(14, RoundingMode.HALF_UP))
      "sqrt" -> evalIntegerRoot(2, argBd)
      "cbrt" -> evalIntegerRoot(3, argBd)
      "abs" -> argBd.abs()
      else -> throw CalcException(CalcError.SYNTAX_ERROR)
    }
  }

  private fun evalTrig(func: String, argBd: BigDecimal, angleMode: AngleMode): BigDecimal {
    if (angleMode == AngleMode.DEG) {
      val rem = argBd.remainder(BigDecimal(360)).stripTrailingZeros()
      val degBd = if (rem.signum() < 0) rem.add(BigDecimal(360)) else rem
      if (degBd.compareTo(BigDecimal.ZERO) == 0 || degBd.compareTo(BigDecimal(180)) == 0) {
        return when (func) {
          "sin", "tan" -> BigDecimal.ZERO
          "cos" -> if (degBd.compareTo(BigDecimal.ZERO) == 0) BigDecimal.ONE else BigDecimal("-1")
          else -> BigDecimal.ZERO
        }
      }
      if (degBd.compareTo(BigDecimal(90)) == 0 || degBd.compareTo(BigDecimal(270)) == 0) {
        return when (func) {
          "sin" -> if (degBd.compareTo(BigDecimal(90)) == 0) BigDecimal.ONE else BigDecimal("-1")
          "cos" -> BigDecimal.ZERO
          "tan" -> throw CalcException(CalcError.DOMAIN_ERROR)
          else -> BigDecimal.ZERO
        }
      }
      val deg = toCheckedDouble(degBd)
      val rad = Math.toRadians(deg)
      val res =
        when (func) {
          "sin" -> sin(rad)
          "cos" -> cos(rad)
          "tan" -> {
            val c = cos(rad)
            if (abs(c) < 1e-12) throw CalcException(CalcError.DOMAIN_ERROR)
            tan(rad)
          }
          else -> 0.0
        }
      return fromCheckedDouble(res)
    }

    val x = toCheckedDouble(argBd)
    val raw =
      when (func) {
        "sin" -> sin(x)
        "cos" -> cos(x)
        "tan" -> {
          val c = cos(x)
          if (abs(c) < 1e-12) throw CalcException(CalcError.DOMAIN_ERROR)
          tan(x)
        }
        else -> 0.0
      }
    // Only snap near-zero Trig results caused by Pi/radians rounding (|x| >= 1), never tiny inputs like sin(1e-13)
    val cleaned = if (abs(x) >= 1.0 && abs(raw) < 1e-13) 0.0 else raw
    return fromCheckedDouble(cleaned)
  }

  private fun evalLog10(argBd: BigDecimal): BigDecimal {
    if (argBd.signum() <= 0) throw CalcException(CalcError.DOMAIN_ERROR)
    val stripped = argBd.stripTrailingZeros()
    if (stripped.unscaledValue() == BigInteger.ONE) {
      return BigDecimal(-stripped.scale().toLong())
    }
    val exp10 = argBd.precision().toLong() - argBd.scale().toLong() - 1L
    if (exp10 < -1_000_000_000L || exp10 > 1_000_000_000L) throw CalcException(CalcError.OVERFLOW)
    val mantissa = argBd.movePointLeft(exp10.toInt()).toDouble()
    val res = BigDecimal.valueOf(log10(mantissa)).add(BigDecimal(exp10), MATH_CTX)
    return res.round(MathContext(14, RoundingMode.HALF_UP))
  }

  private fun evalLnHighPrecision(argBd: BigDecimal): BigDecimal {
    if (argBd.signum() <= 0) throw CalcException(CalcError.DOMAIN_ERROR)
    if (argBd.compareTo(BigDecimal.ONE) == 0) return BigDecimal.ZERO
    val exp10 = argBd.precision().toLong() - argBd.scale().toLong() - 1L
    if (exp10 < -1_000_000_000L || exp10 > 1_000_000_000L) throw CalcException(CalcError.OVERFLOW)
    val mantissa = argBd.movePointLeft(exp10.toInt()).toDouble()
    val lnMantissa = BigDecimal.valueOf(ln(mantissa))
    return if (exp10 == 0L) {
      lnMantissa
    } else {
      lnMantissa.add(LN_10_BD.multiply(BigDecimal(exp10), MATH_CTX), MATH_CTX)
    }
  }

  private fun evalIntegerRoot(n: Int, argBd: BigDecimal): BigDecimal {
    if (n == 0) throw CalcException(CalcError.DOMAIN_ERROR)
    if (n < 0) {
      val pos = evalIntegerRoot(-n, argBd)
      if (pos.compareTo(BigDecimal.ZERO) == 0) throw CalcException(CalcError.DIVISION_BY_ZERO)
      return BigDecimal.ONE.divide(pos, MATH_CTX).round(MathContext(14, RoundingMode.HALF_UP))
    }
    if (argBd.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO
    if (argBd.signum() < 0) {
      if (n % 2 == 0) throw CalcException(CalcError.DOMAIN_ERROR)
      return evalIntegerRoot(n, argBd.negate()).negate()
    }
    val exp10 = argBd.precision().toLong() - argBd.scale().toLong() - 1L
    val k = Math.floorDiv(exp10, n.toLong())
    val remExp = exp10 - k * n.toLong()
    if (k < -1_000_000L || k > 1_000_000L) throw CalcException(CalcError.OVERFLOW)
    if (remExp >= 300L) {
      return evalPower(argBd, BigDecimal.ONE.divide(BigDecimal(n), MATH_CTX))
    }
    val shift = (k * n.toLong()).toInt()
    val scaled = argBd.movePointLeft(shift).toDouble()
    if (!scaled.isFinite() || scaled <= 0.0) {
      return evalPower(argBd, BigDecimal.ONE.divide(BigDecimal(n), MATH_CTX))
    }
    val rootScaled =
      when (n) {
        2 -> sqrt(scaled)
        3 -> cbrt(scaled)
        else -> scaled.pow(1.0 / n)
      }
    return BigDecimal.valueOf(rootScaled).round(MathContext(14, RoundingMode.HALF_UP)).movePointRight(k.toInt())
  }

  private fun safeExactAdd(a: BigDecimal, b: BigDecimal): BigDecimal {
    if (a.compareTo(BigDecimal.ZERO) == 0) return b
    if (b.compareTo(BigDecimal.ZERO) == 0) return a
    val maxMsb = maxOf(a.precision().toLong() - a.scale().toLong(), b.precision().toLong() - b.scale().toLong())
    val minLsb = minOf(-a.scale().toLong(), -b.scale().toLong())
    val span = maxMsb - minLsb + 2L
    return if (span <= MAX_EXACT_SPAN) a.add(b) else a.add(b, EXACT_CAP_CTX)
  }

  private fun safeExactSubtract(a: BigDecimal, b: BigDecimal): BigDecimal {
    if (b.compareTo(BigDecimal.ZERO) == 0) return a
    if (a.compareTo(BigDecimal.ZERO) == 0) return b.negate()
    val maxMsb = maxOf(a.precision().toLong() - a.scale().toLong(), b.precision().toLong() - b.scale().toLong())
    val minLsb = minOf(-a.scale().toLong(), -b.scale().toLong())
    val span = maxMsb - minLsb + 2L
    return if (span <= MAX_EXACT_SPAN) a.subtract(b) else a.subtract(b, EXACT_CAP_CTX)
  }

  private fun toCheckedDouble(bd: BigDecimal): Double {
    val d = bd.toDouble()
    if (d.isNaN() || d.isInfinite()) throw CalcException(CalcError.OVERFLOW)
    return d
  }

  private fun fromCheckedDouble(d: Double): BigDecimal {
    if (d.isNaN()) throw CalcException(CalcError.DOMAIN_ERROR)
    if (d.isInfinite()) throw CalcException(CalcError.OVERFLOW)
    return BigDecimal.valueOf(d).round(MathContext(14, RoundingMode.HALF_UP))
  }

  private class CalcException(val error: CalcError) : RuntimeException()
}
