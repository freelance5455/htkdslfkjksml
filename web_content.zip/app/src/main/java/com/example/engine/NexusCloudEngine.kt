package com.example.engine

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.data.model.AssistantPersona
import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole
import com.example.data.model.ResolvedAttachment
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import kotlin.system.measureTimeMillis

private const val TAG = "NexusGeminiEngine"

class NexusCloudEngine(private val context: Context) : AiEngine {

    override val specs: EngineSpecs
        get() = EngineSpecs(
            name = "NEXUS Omni-AI (Gemini 3.8 Flash)",
            isOffline = false,
            memoryUsageMb = 85,
            estimatedTps = 65.0f,
            architecture = "Unified Multimodal AI via Gemini 3.8 Flash"
        )

    override fun isOfflineAvailable(): Boolean = false

    private fun isNetworkConnected(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        persona: AssistantPersona,
        assistantName: String,
        modelName: String,
        attachments: List<ResolvedAttachment>,
        onTokenStream: ((String) -> Unit)?
    ): GenerationResult {
        if (!isNetworkConnected()) {
            throw IllegalStateException(
                "Отсутствует подключение к интернету. Для работы объединённого ИИ требуется доступ к сети Wi-Fi или мобильному интернету."
            )
        }

        val systemInstructionContent = content {
            text(
                """
                Ты — $assistantName, персональный объединённый ИИ-ассистент нового поколения в приложении NEXUS AI.
                
                АКТИВНЫЙ РЕЖИМ И ХАРАКТЕР (${persona.title}):
                ${persona.systemPrompt}
                
                СИНТЕЗ ВСЕХ ИИ И СОБСТВЕННОГО ЯДРА NEXUS:
                • Объединяй в себе сильные стороны всех передовых ИИ: глубокий системный анализ, безупречное программирование и архитектуру, научную точность, живую речь, эмпатию, анализ изображений, видео, аудио и документов, а также индивидуальный характер NEXUS AI.
                • Отвечай целостно, ясно и максимально полезно, адаптируя глубину и стиль под конкретную задачу.
                
                ПРАВИЛА И ПРИНЦИПЫ РАБОТЫ:
                1. Твой основной язык — РУССКИЙ (если пользователь не попросил иной язык). Пиши грамотно, естественно и выразительно.
                2. Категорически запрещены шаблонные отписки и повторяющиеся фразы. Каждый ответ генерируется индивидуально под текущее сообщение.
                3. Используй память текущего диалога: опирайся на контекст предыдущих сообщений, помни факты, имена, код и решения из прошлых реплик.
                4. Если к сообщению прикреплены фото, видео, PDF или файлы — подробно и предметно анализируй их содержимое, текст, детали, ошибки или код.
                5. Для программного кода используй Markdown-блоки с указанием языка (```kotlin, ```html, ```python и т.д.). Для структуры используй заголовки (###), списки и **выделение**.
                6. Если пользователь просит посчитать, проанализировать или спланировать — выполняй точные вычисления и чётко структурируй шаги.
                """.trimIndent()
            )
        }

        val config = generationConfig {
            temperature = 0.75f
            topP = 0.95f
        }

        val activeModelId = modelName.trim().ifBlank { "gemini-3.8-flash" }
        val model = Firebase.ai(backend = GenerativeBackend.googleAI()).generativeModel(
            modelName = activeModelId,
            generationConfig = config,
            systemInstruction = systemInstructionContent
        )

        val chatHistoryContents = buildValidGeminiHistory(history)

        val userTurnContent = content("user") {
            val textAttachmentBuilder = StringBuilder()
            for (att in attachments) {
                if (att.extractedText != null) {
                    textAttachmentBuilder.append("\n\n--- Содержимое файла «${att.displayName}» ---\n")
                    textAttachmentBuilder.append(att.extractedText)
                    textAttachmentBuilder.append("\n--- Конец файла «${att.displayName}» ---")
                } else if (att.bytes != null) {
                    inlineData(att.bytes, att.mimeType)
                }
            }
            val finalPrompt = if (textAttachmentBuilder.isNotEmpty()) {
                "$prompt$textAttachmentBuilder"
            } else {
                prompt
            }
            text(finalPrompt)
        }

        val accumulatedText = StringBuilder()
        val latencyMs = measureTimeMillis {
            try {
                val chat = model.startChat(history = chatHistoryContents)

                withTimeout(90_000L) {
                    chat.sendMessageStream(userTurnContent).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        if (chunkText.isNotEmpty()) {
                            accumulatedText.append(chunkText)
                            onTokenStream?.invoke(accumulatedText.toString())
                        }
                    }
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Gemini generation timed out", e)
                throw IllegalStateException("Время ожидания ответа от Gemini API превысило 90 секунд. Если вы отправили большое видео, попробуйте более короткий ролик.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Gemini API call failed for $activeModelId", e)
                val rawErr = e.localizedMessage ?: "Сбой соединения с Gemini API"
                val hint = if (activeModelId == "gemini-4-argon" && (rawErr.contains("403") || rawErr.contains("billing", ignoreCase = true) || rawErr.contains("quota", ignoreCase = true) || rawErr.contains("not found", ignoreCase = true))) {
                    " (Модель Gemini 4 Argon может требовать тариф Blaze — переключитесь на Gemini 3.8 Flash в настройках.)"
                } else ""
                throw IllegalStateException("Ошибка $activeModelId: $rawErr$hint")
            }
        }

        val finalText = accumulatedText.toString().trim()
        if (finalText.isBlank()) {
            throw IllegalStateException("Модель $activeModelId вернула пустой ответ. Попробуйте переформулировать запрос.")
        }

        val tokensCount = maxOf(1, finalText.split(Regex("\\s+")).size)

        return GenerationResult(
            text = finalText,
            engineName = "NEXUS Omni-AI ($activeModelId)",
            latencyMs = latencyMs,
            tokensCount = tokensCount,
            isOffline = false
        )
    }

    private fun buildValidGeminiHistory(history: List<ChatMessage>): List<Content> {
        val cleanMessages = history
            .filter {
                (it.role == MessageRole.USER || it.role == MessageRole.ASSISTANT) &&
                    it.content.isNotBlank() &&
                    it.engineUsed != "Ошибка" &&
                    !it.content.startsWith("⚠️")
            }
            .takeLast(24)

        val firstUserIdx = cleanMessages.indexOfFirst { it.role == MessageRole.USER }
        if (firstUserIdx == -1) return emptyList()

        val sliced = cleanMessages.subList(firstUserIdx, cleanMessages.size)

        val alternating = mutableListOf<Pair<String, String>>()
        for (msg in sliced) {
            val role = if (msg.role == MessageRole.USER) "user" else "model"
            if (alternating.isNotEmpty() && alternating.last().first == role) {
                val prev = alternating.removeAt(alternating.lastIndex)
                alternating.add(role to "${prev.second}\n${msg.content}")
            } else {
                alternating.add(role to msg.content)
            }
        }

        if (alternating.isNotEmpty() && alternating.last().first == "user") {
            alternating.removeAt(alternating.lastIndex)
        }

        return alternating.map { (role, text) ->
            content(role = role) { text(text) }
        }
    }
}
