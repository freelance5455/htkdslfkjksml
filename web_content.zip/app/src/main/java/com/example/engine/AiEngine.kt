package com.example.engine

import com.example.data.model.AssistantPersona
import com.example.data.model.ChatMessage
import com.example.data.model.ResolvedAttachment

data class EngineSpecs(
    val name: String,
    val isOffline: Boolean,
    val memoryUsageMb: Int,
    val estimatedTps: Float,
    val architecture: String
)

data class GenerationResult(
    val text: String,
    val engineName: String,
    val latencyMs: Long,
    val tokensCount: Int,
    val isOffline: Boolean
)

interface AiEngine {
    val specs: EngineSpecs

    fun isOfflineAvailable(): Boolean

    suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        persona: AssistantPersona,
        assistantName: String,
        modelName: String = "gemini-3.8-flash",
        attachments: List<ResolvedAttachment> = emptyList(),
        onTokenStream: ((String) -> Unit)? = null
    ): GenerationResult
}
