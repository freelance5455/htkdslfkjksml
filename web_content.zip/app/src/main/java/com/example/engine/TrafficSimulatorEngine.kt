package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.model.ExecutionEngine
import com.example.model.HttpMethod
import com.example.model.SessionProfile
import com.example.model.SimulationConfig
import com.example.model.SimulationState
import com.example.model.SimulationStats
import com.example.model.VisitResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class TrafficSimulatorEngine(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private var simulationJob: Job? = null
    private var isPausedInternal = false

    private val _stats = MutableStateFlow(SimulationStats())
    val stats: StateFlow<SimulationStats> = _stats.asStateFlow()

    private val _visitEventFlow = MutableSharedFlow<VisitResult>(extraBufferCapacity = 64)
    val visitEventFlow: SharedFlow<VisitResult> = _visitEventFlow.asSharedFlow()

    private val baseClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun startSimulation(config: SimulationConfig, onFinish: (SimulationStats) -> Unit = {}) {
        stopSimulation()
        isPausedInternal = false

        val normalizedUrl = normalizeUrl(config.url)
        val preparedConfig = config.copy(url = normalizedUrl)

        _stats.value = SimulationStats(
            state = SimulationState.RUNNING,
            totalScheduled = preparedConfig.totalVisits,
            startTimeMs = System.currentTimeMillis()
        )

        simulationJob = scope.launch(Dispatchers.IO) {
            val total = preparedConfig.totalVisits
            // Headless WebView works sequentially or in small concurrency to avoid memory overhead
            val maxConcurrency = if (preparedConfig.executionEngine == ExecutionEngine.HEADLESS_WEBVIEW) {
                preparedConfig.concurrency.coerceAtMost(2)
            } else {
                preparedConfig.concurrency.coerceAtLeast(1)
            }
            val semaphore = Semaphore(maxConcurrency)

            val latencies = mutableListOf<Long>()
            var completed = 0

            for (i in 1..total) {
                if (!isActive) break

                // Wait if paused
                while (isPausedInternal && isActive) {
                    delay(200)
                }
                if (!isActive) break

                _stats.update { it.copy(currentRequestIndex = i) }

                if (maxConcurrency > 1) {
                    launch {
                        semaphore.withPermit {
                            if (!isActive) return@withPermit
                            val result = executeSingleVisit(i, preparedConfig)
                            synchronized(latencies) {
                                latencies.add(result.latencyMs)
                                completed++
                                recordVisitResult(result, latencies, completed, total)
                            }
                            _visitEventFlow.tryEmit(result)
                        }
                    }
                } else {
                    val result = executeSingleVisit(i, preparedConfig)
                    latencies.add(result.latencyMs)
                    completed++
                    recordVisitResult(result, latencies, completed, total)
                    _visitEventFlow.tryEmit(result)

                    if (i < total && preparedConfig.pacingMode.delayMs > 0) {
                        delay(preparedConfig.pacingMode.delayMs)
                    }
                }
            }

            // Await remaining tasks if concurrent
            if (maxConcurrency > 1) {
                while (completed < total && isActive) {
                    delay(100)
                }
            }

            if (isActive) {
                _stats.update {
                    it.copy(
                        state = SimulationState.COMPLETED,
                        elapsedMs = System.currentTimeMillis() - it.startTimeMs
                    )
                }
                withContext(Dispatchers.Main) {
                    onFinish(_stats.value)
                }
            }
        }
    }

    private fun recordVisitResult(
        result: VisitResult,
        latencies: List<Long>,
        completed: Int,
        total: Int
    ) {
        _stats.update { current ->
            val isSuccess = result.statusCode in 200..299
            val isRedirect = result.statusCode in 300..399
            val isClientError = result.statusCode in 400..499
            val isServerError = result.statusCode in 500..599
            val isNetworkError = result.statusCode == 0 || result.errorMessage != null

            val avg = if (latencies.isNotEmpty()) latencies.average().toLong() else 0L
            val min = latencies.minOrNull() ?: 0L
            val max = latencies.maxOrNull() ?: 0L

            current.copy(
                completedCount = completed,
                successCount = current.successCount + (if (isSuccess) 1 else 0),
                redirectCount = current.redirectCount + (if (isRedirect) 1 else 0),
                clientErrorCount = current.clientErrorCount + (if (isClientError) 1 else 0),
                serverErrorCount = current.serverErrorCount + (if (isServerError) 1 else 0),
                networkErrorCount = current.networkErrorCount + (if (isNetworkError) 1 else 0),
                avgLatencyMs = avg,
                minLatencyMs = min,
                maxLatencyMs = max,
                totalBytesReceived = current.totalBytesReceived + result.bytesReceived,
                elapsedMs = System.currentTimeMillis() - current.startTimeMs
            )
        }
    }

    suspend fun executeSingleVisit(index: Int, config: SimulationConfig): VisitResult {
        return if (config.executionEngine == ExecutionEngine.HEADLESS_WEBVIEW) {
            executeWebViewVisit(index, config)
        } else {
            executeHttpVisit(index, config)
        }
    }

    private suspend fun executeHttpVisit(index: Int, config: SimulationConfig): VisitResult = withContext(Dispatchers.IO) {
        val profile = ProfileCatalog.createUniqueProfile(
            index = index,
            rotateAgents = config.rotateUserAgents,
            rotateRefs = config.rotateReferrers,
            rotateLangs = config.rotateLanguages,
            rotateIps = config.rotateSimulatedIps
        )

        val isolatedClient = baseClient.newBuilder()
            .followRedirects(config.followRedirects)
            .followSslRedirects(config.followRedirects)
            .cookieJar(object : CookieJar {
                private val cookies = mutableListOf<Cookie>()
                override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
                    this.cookies.addAll(cookies)
                }
                override fun loadForRequest(url: HttpUrl): List<Cookie> {
                    return if (config.isolatedCookies) emptyList() else cookies
                }
            })
            .build()

        val headersMap = mutableMapOf<String, String>()
        headersMap["User-Agent"] = profile.userAgent
        headersMap["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
        headersMap["Accept-Language"] = profile.acceptLanguage
        headersMap["Sec-CH-UA"] = profile.secChUa
        headersMap["Sec-CH-UA-Mobile"] = profile.secChUaMobile
        headersMap["Sec-CH-UA-Platform"] = profile.secChUaPlatform
        headersMap["Sec-Fetch-Dest"] = "document"
        headersMap["Sec-Fetch-Mode"] = "navigate"
        headersMap["Sec-Fetch-Site"] = if (profile.referer != null) "cross-site" else "none"
        headersMap["Upgrade-Insecure-Requests"] = "1"
        headersMap["Cache-Control"] = "no-cache"
        headersMap["Pragma"] = "no-cache"

        if (config.rotateSimulatedIps) {
            headersMap["X-Forwarded-For"] = profile.simulatedIp
            headersMap["Client-IP"] = profile.simulatedIp
            headersMap["X-Real-IP"] = profile.simulatedIp
            headersMap["CF-Connecting-IP"] = profile.simulatedIp
        }

        if (profile.referer != null) {
            headersMap["Referer"] = profile.referer
        }

        if (config.customHeadersString.isNotBlank()) {
            config.customHeadersString.lines().forEach { line ->
                val parts = line.split(":", limit = 2)
                if (parts.size == 2) {
                    headersMap[parts[0].trim()] = parts[1].trim()
                }
            }
        }

        val requestBuilder = Request.Builder().url(config.url)
        headersMap.forEach { (k, v) -> requestBuilder.header(k, v) }

        when (config.httpMethod) {
            HttpMethod.GET -> requestBuilder.get()
            HttpMethod.HEAD -> requestBuilder.head()
            HttpMethod.POST -> {
                val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
                val bodyText = config.customPayload.ifBlank { "{\"simulatedVisit\": $index}" }
                requestBuilder.post(bodyText.toRequestBody(mediaType))
            }
        }

        val request = requestBuilder.build()
        val startTime = System.currentTimeMillis()

        try {
            val response: Response = isolatedClient.newCall(request).execute()
            val latency = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            val code = response.code
            val message = response.message

            val responseHeaders = mutableMapOf<String, String>()
            for (i in 0 until response.headers.size) {
                responseHeaders[response.headers.name(i)] = response.headers.value(i)
            }

            val serverHeader = response.header("Server") ?: "Web Server (HTTP/2 / 1.1)"
            val dateHeader = response.header("Date") ?: ""
            val setCookies = response.headers.values("Set-Cookie")
            val body = response.body
            val bytesReceived = body?.contentLength()?.takeIf { it >= 0 } ?: (body?.bytes()?.size?.toLong() ?: 0L)
            
            val bodyString = try {
                body?.string() ?: ""
            } catch (e: Exception) {
                ""
            }
            val titleSnippet = extractHtmlTitle(bodyString).ifBlank {
                bodyString.take(300).trim().replace("\n", " ")
            }

            response.close()

            VisitResult(
                index = index,
                timestamp = System.currentTimeMillis(),
                url = config.url,
                method = config.httpMethod.name,
                statusCode = code,
                statusMessage = message.ifBlank { if (code in 200..299) "OK" else "Status $code" },
                latencyMs = latency,
                bytesReceived = bytesReceived.coerceAtLeast(0L),
                isSuccess = code in 200..299,
                errorMessage = null,
                sessionProfile = profile,
                requestHeadersSent = headersMap,
                responseHeadersReceived = responseHeaders,
                cookiesReceived = setCookies,
                responseBodyPreview = titleSnippet,
                serverIdentifier = serverHeader,
                serverTimestamp = dateHeader,
                engineName = "HTTP Socket Engine"
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            val latency = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            VisitResult(
                index = index,
                timestamp = System.currentTimeMillis(),
                url = config.url,
                method = config.httpMethod.name,
                statusCode = 0,
                statusMessage = "Connection Failed",
                latencyMs = latency,
                bytesReceived = 0L,
                isSuccess = false,
                errorMessage = e.message ?: e.javaClass.simpleName,
                sessionProfile = profile,
                requestHeadersSent = headersMap,
                responseHeadersReceived = emptyMap(),
                cookiesReceived = emptyList(),
                responseBodyPreview = "",
                serverIdentifier = "No response",
                engineName = "HTTP Socket Engine"
            )
        } catch (e: Exception) {
            val latency = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            VisitResult(
                index = index,
                timestamp = System.currentTimeMillis(),
                url = config.url,
                method = config.httpMethod.name,
                statusCode = 0,
                statusMessage = "Error",
                latencyMs = latency,
                bytesReceived = 0L,
                isSuccess = false,
                errorMessage = e.message ?: "Unexpected Error",
                sessionProfile = profile,
                requestHeadersSent = headersMap,
                responseHeadersReceived = emptyMap(),
                cookiesReceived = emptyList(),
                responseBodyPreview = "",
                serverIdentifier = "Error",
                engineName = "HTTP Socket Engine"
            )
        }
    }

    /**
     * Executes real browser visit using Android's WebKit WebView engine,
     * executing JavaScript and firing client-side tracking tags.
     */
    private suspend fun executeWebViewVisit(index: Int, config: SimulationConfig): VisitResult = withContext(Dispatchers.Main) {
        val profile = ProfileCatalog.createUniqueProfile(
            index = index,
            rotateAgents = config.rotateUserAgents,
            rotateRefs = config.rotateReferrers,
            rotateLangs = config.rotateLanguages,
            rotateIps = config.rotateSimulatedIps
        )

        val completionDeferred = CompletableDeferred<Pair<Int, String>>()
        val startTime = System.currentTimeMillis()
        var webView: WebView? = null

        val headersMap = mutableMapOf<String, String>()
        if (config.rotateSimulatedIps) {
            headersMap["X-Forwarded-For"] = profile.simulatedIp
            headersMap["Client-IP"] = profile.simulatedIp
            headersMap["X-Real-IP"] = profile.simulatedIp
        }
        if (profile.referer != null) {
            headersMap["Referer"] = profile.referer
        }
        headersMap["Accept-Language"] = profile.acceptLanguage

        try {
            // Isolate cookies
            if (config.isolatedCookies) {
                val cookieManager = CookieManager.getInstance()
                cookieManager.removeAllCookies(null)
                cookieManager.flush()
            }

            webView = WebView(context).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.userAgentString = profile.userAgent
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true

                webViewClient = object : WebViewClient() {
                    private var statusCode = 200

                    override fun onReceivedHttpError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        errorResponse: WebResourceResponse?
                    ) {
                        super.onReceivedHttpError(view, request, errorResponse)
                        if (request?.isForMainFrame == true && errorResponse != null) {
                            statusCode = errorResponse.statusCode
                        }
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?
                    ) {
                        super.onReceivedError(view, request, error)
                        if (request?.isForMainFrame == true) {
                            statusCode = 0
                            val desc = error?.description?.toString() ?: "Network Error"
                            if (!completionDeferred.isCompleted) {
                                completionDeferred.complete(Pair(0, desc))
                            }
                        }
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        val pageTitle = view?.title ?: ""
                        if (!completionDeferred.isCompleted) {
                            completionDeferred.complete(Pair(statusCode, pageTitle))
                        }
                    }
                }

                loadUrl(config.url, headersMap)
            }

            // Wait for page finish with a timeout
            val result = withTimeoutOrNull(15000L) {
                completionDeferred.await()
            } ?: Pair(200, "Loaded (Timeout limit reached)")

            val latency = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            val cookiesRaw = CookieManager.getInstance().getCookie(config.url)
            val cookiesList = if (!cookiesRaw.isNullOrBlank()) {
                cookiesRaw.split(";").map { it.trim() }
            } else emptyList()

            val statusCode = result.first
            val titleOrError = result.second

            VisitResult(
                index = index,
                timestamp = System.currentTimeMillis(),
                url = config.url,
                method = "GET (Browser Render)",
                statusCode = if (statusCode > 0) statusCode else 0,
                statusMessage = if (statusCode in 200..299) "OK (DOM Loaded & JS Executed)" else if (statusCode == 0) "Render Failed" else "Status $statusCode",
                latencyMs = latency,
                bytesReceived = 15000L, // WebKit DOM estimate
                isSuccess = statusCode in 200..299,
                errorMessage = if (statusCode == 0) titleOrError else null,
                sessionProfile = profile,
                requestHeadersSent = headersMap + mapOf("User-Agent" to profile.userAgent),
                responseHeadersReceived = mapOf("Engine" to "Android WebKit WebView", "JavaScript" to "Executed"),
                cookiesReceived = cookiesList,
                responseBodyPreview = "Page Title: \"$titleOrError\"",
                serverIdentifier = "WebKit Browser Engine",
                serverTimestamp = System.currentTimeMillis().toString(),
                engineName = "WebKit Browser (DOM + JS)"
            )
        } catch (e: Exception) {
            val latency = (System.currentTimeMillis() - startTime).coerceAtLeast(1)
            VisitResult(
                index = index,
                timestamp = System.currentTimeMillis(),
                url = config.url,
                method = "GET (Browser Render)",
                statusCode = 0,
                statusMessage = "Render Exception",
                latencyMs = latency,
                bytesReceived = 0L,
                isSuccess = false,
                errorMessage = e.message ?: "Browser error",
                sessionProfile = profile,
                requestHeadersSent = headersMap,
                responseHeadersReceived = emptyMap(),
                cookiesReceived = emptyList(),
                responseBodyPreview = "",
                serverIdentifier = "Browser Error",
                engineName = "WebKit Browser (DOM + JS)"
            )
        } finally {
            webView?.stopLoading()
            webView?.clearCache(true)
            webView?.destroy()
        }
    }

    private fun extractHtmlTitle(html: String): String {
        return try {
            val matcher = Pattern.compile("<title>(.*?)</title>", Pattern.CASE_INSENSITIVE or Pattern.DOTALL).matcher(html)
            if (matcher.find()) {
                matcher.group(1)?.trim()?.replace("\n", " ") ?: ""
            } else ""
        } catch (e: Exception) {
            ""
        }
    }

    private fun normalizeUrl(url: String): String {
        var trimmed = url.trim()
        if (!trimmed.startsWith("http://", ignoreCase = true) && !trimmed.startsWith("https://", ignoreCase = true)) {
            trimmed = "https://$trimmed"
        }
        return trimmed
    }

    fun pauseSimulation() {
        isPausedInternal = true
        _stats.update { it.copy(state = SimulationState.PAUSED) }
    }

    fun resumeSimulation() {
        isPausedInternal = false
        _stats.update { it.copy(state = SimulationState.RUNNING) }
    }

    fun stopSimulation() {
        simulationJob?.cancel()
        simulationJob = null
        isPausedInternal = false
        if (_stats.value.state == SimulationState.RUNNING || _stats.value.state == SimulationState.PAUSED) {
            _stats.update {
                it.copy(
                    state = SimulationState.STOPPED,
                    elapsedMs = System.currentTimeMillis() - it.startTimeMs
                )
            }
        }
    }

    fun resetStats() {
        stopSimulation()
        _stats.value = SimulationStats()
    }
}
