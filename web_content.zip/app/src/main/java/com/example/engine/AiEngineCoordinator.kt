package com.example.engine

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.data.model.AiEngineType
import com.example.data.model.AssistantPersona
import com.example.data.model.ChatMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private const val TAG = "EngineCoordinator"

class AiEngineCoordinator(private val context: Context) {

    val localEngine = NexusLocalNeuralEngine(context)
    val cloudEngine = NexusCloudEngine(context)

    private val _isNetworkAvailable = MutableStateFlow(checkNetwork())
    val isNetworkAvailable: StateFlow<Boolean> = _isNetworkAvailable.asStateFlow()

    fun refreshNetworkStatus(): Boolean {
        val status = checkNetwork()
        _isNetworkAvailable.value = status
        return status
    }

    private fun checkNetwork(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun generate(
        prompt: String,
        history: List<ChatMessage>,
        persona: AssistantPersona,
        assistantName: String,
        enginePreference: AiEngineType,
        modelName: String = "gemini-3.8-flash",
        onTokenStream: ((String) -> Unit)? = null
    ): GenerationResult {
        val hasNet = refreshNetworkStatus()

        return when (enginePreference) {
            AiEngineType.CLOUD -> {
                if (!hasNet) {
                    throw IllegalStateException("Отсутствует подключение к интернету. Включите Wi-Fi/LTE или переключитесь на локальный режим.")
                }
                cloudEngine.generateResponse(
                    prompt = prompt,
                    history = history,
                    persona = persona,
                    assistantName = assistantName,
                    modelName = modelName,
                    onTokenStream = onTokenStream
                )
            }
            AiEngineType.LOCAL -> {
                localEngine.generateResponse(
                    prompt = prompt,
                    history = history,
                    persona = persona,
                    assistantName = assistantName,
                    modelName = modelName,
                    onTokenStream = onTokenStream
                )
            }
            AiEngineType.AUTO -> {
                if (hasNet) {
                    try {
                        cloudEngine.generateResponse(
                            prompt = prompt,
                            history = history,
                            persona = persona,
                            assistantName = assistantName,
                            modelName = modelName,
                            onTokenStream = onTokenStream
                        )
                    } catch (e: Exception) {
                        Log.w(TAG, "Cloud engine failed in AUTO mode, falling back to local engine", e)
                        localEngine.generateResponse(
                            prompt = prompt,
                            history = history,
                            persona = persona,
                            assistantName = assistantName,
                            modelName = modelName,
                            onTokenStream = onTokenStream
                        )
                    }
                } else {
                    localEngine.generateResponse(
                        prompt = prompt,
                        history = history,
                        persona = persona,
                        assistantName = assistantName,
                        modelName = modelName,
                        onTokenStream = onTokenStream
                    )
                }
            }
        }
    }
}
