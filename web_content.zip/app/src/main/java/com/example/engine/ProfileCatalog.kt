package com.example.engine

import com.example.model.DeviceType
import com.example.model.SessionProfile
import java.util.UUID

object ProfileCatalog {

    private data class AgentTemplate(
        val deviceType: DeviceType,
        val browserName: String,
        val userAgent: String,
        val secChUa: String,
        val secChUaMobile: String,
        val secChUaPlatform: String,
        val defaultViewport: String
    )

    private val templates = listOf(
        // Desktop Chrome Windows
        AgentTemplate(
            deviceType = DeviceType.DESKTOP_WINDOWS,
            browserName = "Chrome 126 (Win11)",
            userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            secChUa = "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Google Chrome\";v=\"126\"",
            secChUaMobile = "?0",
            secChUaPlatform = "\"Windows\"",
            defaultViewport = "1920x1080"
        ),
        // Desktop Safari macOS Sonoma
        AgentTemplate(
            deviceType = DeviceType.DESKTOP_MAC,
            browserName = "Safari 17.5 (macOS)",
            userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
            secChUa = "\"Safari\";v=\"17.5\", \"AppleWebKit\";v=\"605.1.15\"",
            secChUaMobile = "?0",
            secChUaPlatform = "\"macOS\"",
            defaultViewport = "1440x900"
        ),
        // Mobile Chrome on Pixel 8 / Android 14
        AgentTemplate(
            deviceType = DeviceType.MOBILE_ANDROID,
            browserName = "Chrome Mobile 126 (Pixel 8)",
            userAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.122 Mobile Safari/537.36",
            secChUa = "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Google Chrome\";v=\"126\"",
            secChUaMobile = "?1",
            secChUaPlatform = "\"Android\"",
            defaultViewport = "412x915"
        ),
        // Mobile Safari on iPhone 15 Pro / iOS 17
        AgentTemplate(
            deviceType = DeviceType.MOBILE_IOS,
            browserName = "Safari Mobile (iPhone 15 Pro)",
            userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
            secChUa = "\"Safari\";v=\"17.5\", \"AppleWebKit\";v=\"605.1.15\"",
            secChUaMobile = "?1",
            secChUaPlatform = "\"iOS\"",
            defaultViewport = "393x852"
        ),
        // Edge Windows 11
        AgentTemplate(
            deviceType = DeviceType.DESKTOP_WINDOWS,
            browserName = "Edge 126 (Win11)",
            userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
            secChUa = "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Microsoft Edge\";v=\"126\"",
            secChUaMobile = "?0",
            secChUaPlatform = "\"Windows\"",
            defaultViewport = "2560x1440"
        ),
        // Firefox Linux Ubuntu
        AgentTemplate(
            deviceType = DeviceType.DESKTOP_LINUX,
            browserName = "Firefox 127 (Linux)",
            userAgent = "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:127.0) Gecko/20100101 Firefox/127.0",
            secChUa = "\"Firefox\";v=\"127\"",
            secChUaMobile = "?0",
            secChUaPlatform = "\"Linux\"",
            defaultViewport = "1920x1080"
        ),
        // Tablet iPad Air / iPadOS 17
        AgentTemplate(
            deviceType = DeviceType.TABLET_IPAD,
            browserName = "Safari (iPad Air)",
            userAgent = "Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
            secChUa = "\"Safari\";v=\"17.5\", \"AppleWebKit\";v=\"605.1.15\"",
            secChUaMobile = "?1",
            secChUaPlatform = "\"iPadOS\"",
            defaultViewport = "820x1180"
        ),
        // Mobile Chrome on Samsung Galaxy S24
        AgentTemplate(
            deviceType = DeviceType.MOBILE_ANDROID,
            browserName = "Samsung Internet / Galaxy S24",
            userAgent = "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/121.0.6167.144 Mobile Safari/537.36",
            secChUa = "\"Samsung Internet\";v=\"25.0\", \"Chromium\";v=\"121\"",
            secChUaMobile = "?1",
            secChUaPlatform = "\"Android\"",
            defaultViewport = "384x824"
        ),
        // Desktop Chrome macOS
        AgentTemplate(
            deviceType = DeviceType.DESKTOP_MAC,
            browserName = "Chrome 126 (macOS)",
            userAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            secChUa = "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Google Chrome\";v=\"126\"",
            secChUaMobile = "?0",
            secChUaPlatform = "\"macOS\"",
            defaultViewport = "1680x1050"
        )
    )

    private val languages = listOf(
        "en-US,en;q=0.9",
        "en-GB,en;q=0.8,en-US;q=0.7",
        "de-DE,de;q=0.9,en;q=0.8",
        "fr-FR,fr;q=0.9,en-US;q=0.7",
        "ja-JP,ja;q=0.9,en;q=0.7",
        "es-ES,es;q=0.9,en;q=0.7",
        "pt-BR,pt;q=0.9,en;q=0.6",
        "it-IT,it;q=0.9,en;q=0.7",
        "nl-NL,nl;q=0.9,en;q=0.8",
        "zh-CN,zh;q=0.9,en;q=0.7",
        "ko-KR,ko;q=0.9,en;q=0.8",
        "sv-SE,sv;q=0.9,en;q=0.8"
    )

    private val referrers = listOf(
        null, // Direct / Type-in
        "https://www.google.com/",
        "https://www.google.com/search?q=developer+web+test",
        "https://t.co/traffic-test",
        "https://www.reddit.com/r/webdev/",
        "https://news.ycombinator.com/",
        "https://www.linkedin.com/feed/",
        "https://duckduckgo.com/",
        "https://www.bing.com/",
        "https://l.facebook.com/",
        "https://github.com/topics/testing"
    )

    private data class GeoIp(val ip: String, val country: String)

    private val geoIps = listOf(
        GeoIp("198.51.100.42", "United States (East)"),
        GeoIp("198.51.100.89", "United States (West)"),
        GeoIp("185.199.108.153", "United Kingdom"),
        GeoIp("193.174.32.14", "Germany (Frankfurt)"),
        GeoIp("133.242.18.91", "Japan (Tokyo)"),
        GeoIp("142.250.70.14", "Canada (Toronto)"),
        GeoIp("139.130.4.5", "Australia (Sydney)"),
        GeoIp("51.255.45.18", "France (Paris)"),
        GeoIp("145.220.12.8", "Netherlands (Amsterdam)"),
        GeoIp("200.221.2.45", "Brazil (São Paulo)"),
        GeoIp("203.116.1.18", "Singapore"),
        GeoIp("194.236.20.11", "Sweden (Stockholm)"),
        GeoIp("103.21.244.5", "India (Mumbai)")
    )

    /**
     * Generates a completely isolated and unique session profile for visit [index].
     */
    fun createUniqueProfile(
        index: Int,
        rotateAgents: Boolean = true,
        rotateRefs: Boolean = true,
        rotateLangs: Boolean = true,
        rotateIps: Boolean = true
    ): SessionProfile {
        val template = if (rotateAgents) {
            templates[(index - 1) % templates.size]
        } else {
            templates[0]
        }

        val lang = if (rotateLangs) {
            languages[(index - 1) % languages.size]
        } else {
            languages[0]
        }

        val ref = if (rotateRefs) {
            referrers[(index - 1) % referrers.size]
        } else {
            null
        }

        val geo = if (rotateIps) {
            // Generate distinct IP suffix for realism per visit
            val baseGeo = geoIps[(index - 1) % geoIps.size]
            val lastOctet = (index * 7 + 11) % 250 + 2
            val ipParts = baseGeo.ip.split(".")
            val uniqueIp = if (ipParts.size == 4) "${ipParts[0]}.${ipParts[1]}.${ipParts[2]}.$lastOctet" else baseGeo.ip
            GeoIp(uniqueIp, baseGeo.country)
        } else {
            geoIps[0]
        }

        return SessionProfile(
            id = UUID.randomUUID().toString().take(8),
            deviceType = template.deviceType,
            browserName = template.browserName,
            userAgent = template.userAgent,
            acceptLanguage = lang,
            referer = ref,
            simulatedIp = geo.ip,
            simulatedCountry = geo.country,
            secChUa = template.secChUa,
            secChUaMobile = template.secChUaMobile,
            secChUaPlatform = template.secChUaPlatform,
            viewport = template.defaultViewport
        )
    }
}
