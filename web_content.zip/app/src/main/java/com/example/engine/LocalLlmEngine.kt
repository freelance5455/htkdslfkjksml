package com.example.engine

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Log
import com.example.data.local.MessageEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.nehuatl.llamacpp.LlamaContext
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

data class GenerationResult(
    val text: String,
    val tokenCount: Int,
    val durationMs: Long
)

/**
 * Thread-safe local GGUF inference engine powered by llama.cpp (llamacpp-kotlin).
 * Automatically adapts context size, batch size & threads to device RAM/CPU, verifies
 * prompt templates & token budgets across all major model families, and streams tokens cleanly.
 */
class LocalLlmEngine(private val context: Context) {

    private val engineExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "xire-local-llm").apply { isDaemon = true }
    }
    private val engineDispatcher = engineExecutor.asCoroutineDispatcher()
    private val mutex = Mutex()
    private val contextIdSeq = AtomicInteger(1)

    @Volatile
    private var activeContext: LlamaContext? = null

    @Volatile
    private var activeContextSize: Int = 1024

    @Volatile
    private var activeThreadCount: Int = 4

    @Volatile
    private var loadedModelPath: String? = null

    @Volatile
    private var loadedModelDetails: Map<String, Any> = emptyMap()

    @Volatile
    private var activeTokenSink: ((String) -> Unit)? = null

    @Volatile
    private var stopRequested: Boolean = false

    fun isModelLoaded(modelPath: String): Boolean {
        return activeContext != null && loadedModelPath == modelPath
    }

    fun resetStopFlag() {
        stopRequested = false
    }

    suspend fun ensureModelLoaded(modelPath: String): Boolean = mutex.withLock {
        withContext(engineDispatcher) {
            loadModelInternal(modelPath)
        }
    }

    suspend fun generateReply(
        modelPath: String,
        modelName: String,
        userName: String,
        history: List<MessageEntity>,
        maxTokens: Int,
        onPartialText: (String) -> Unit
    ): GenerationResult = mutex.withLock {
        withContext(engineDispatcher) {
            if (stopRequested) {
                return@withContext GenerationResult(
                    text = "Generation stopped.",
                    tokenCount = 0,
                    durationMs = 0L
                )
            }

            val loaded = loadModelInternal(modelPath)
            val llamaCtx = activeContext
            if (!loaded || llamaCtx == null) {
                return@withContext GenerationResult(
                    text = "Unable to load this model on this device. Try a smaller quantized GGUF (such as Q4_K_M 0.3B–1.5B).",
                    tokenCount = 0,
                    durationMs = 0L
                )
            }

            val trimmedUserName = userName.trim()
            val systemPrompt = buildString {
                append("You are XIRE AI, a helpful assistant running locally on the user's device. ")
                if (trimmedUserName.isNotEmpty()) {
                    append("The user's name is $trimmedUserName. ")
                    append("Address $trimmedUserName by name naturally in your replies, and if asked what their name is or who they are, answer \"$trimmedUserName\". ")
                }
                append("Answer directly and concisely. Put any code in markdown fenced blocks with a language tag.")
            }

            val trimmedMessages = trimHistoryToFitContext(
                ctx = llamaCtx,
                modelName = modelName,
                systemPrompt = systemPrompt,
                history = history.takeLast(12),
                maxContextTokens = activeContextSize
            )

            val primaryPrompt = buildFormattedPrompt(
                ctx = llamaCtx,
                modelName = modelName,
                systemPrompt = systemPrompt,
                messages = trimmedMessages
            )

            val startTime = System.currentTimeMillis()
            var attempt = runSingleCompletion(
                ctx = llamaCtx,
                prompt = primaryPrompt,
                maxTokens = maxTokens,
                onPartialText = onPartialText
            )

            if (attempt.text.isBlank() && !stopRequested) {
                val fallbackPrompt = fallbackTemplate(
                    modelName = modelName,
                    modelDetails = loadedModelDetails,
                    systemPrompt = systemPrompt,
                    messages = trimmedMessages
                )
                if (fallbackPrompt != primaryPrompt) {
                    attempt = runSingleCompletion(
                        ctx = llamaCtx,
                        prompt = fallbackPrompt,
                        maxTokens = maxTokens,
                        onPartialText = onPartialText
                    )
                }
            }

            if (attempt.text.isBlank() && !stopRequested) {
                val simplePrompt = fallbackTemplate(
                    modelName = modelName,
                    modelDetails = loadedModelDetails,
                    systemPrompt = systemPrompt,
                    messages = history.takeLast(1)
                )
                attempt = runSingleCompletion(
                    ctx = llamaCtx,
                    prompt = simplePrompt,
                    maxTokens = maxTokens,
                    onPartialText = onPartialText
                )
            }

            val durationMs = (System.currentTimeMillis() - startTime).coerceAtLeast(1L)
            val finalText = when {
                attempt.text.isNotBlank() -> attempt.text
                stopRequested -> "Generation stopped."
                attempt.errorMessage != null ->
                    "Could not generate a response with this model (${attempt.errorMessage}). Try a shorter prompt or a Q4_K_M instruct model."
                else ->
                    "The model finished without producing text. Try rephrasing or selecting another GGUF instruct model."
            }

            GenerationResult(
                text = finalText,
                tokenCount = if (attempt.text.isNotBlank()) {
                    attempt.tokenCount.coerceAtLeast(estimateTokens(finalText))
                } else {
                    0
                },
                durationMs = durationMs
            )
        }
    }

    private fun runSingleCompletion(
        ctx: LlamaContext,
        prompt: String,
        maxTokens: Int,
        onPartialText: (String) -> Unit
    ): CompletionAttempt {
        val buffer = StringBuilder()
        var streamedTokens = 0
        val promptTokenCount = runCatching { ctx.tokenize(prompt).size }.getOrDefault(0)
        val remainingBudget = (activeContextSize - promptTokenCount - 16).coerceAtLeast(64)
        val targetPredict = maxTokens.coerceIn(32, 4096).coerceAtMost(remainingBudget)

        activeTokenSink = { chunk ->
            if (!stopRequested && chunk.isNotEmpty()) {
                buffer.append(chunk)
                streamedTokens++
                onPartialText(cleanStopTokens(buffer.toString()))
            }
        }

        return try {
            val completionParams = mapOf<String, Any>(
                "prompt" to prompt,
                "n_threads" to activeThreadCount,
                "n_predict" to targetPredict,
                "temperature" to 0.7,
                "top_p" to 0.9,
                "top_k" to 40,
                "min_p" to 0.05,
                "penalty_last_n" to 64,
                "penalty_repeat" to 1.1,
                "emit_partial_completion" to true,
                "ignore_eos" to false,
                "stop" to STOP_TOKENS
            )

            val result = ctx.completion(completionParams)
            val mapText = (result["text"] as? String)
                ?: (result["content"] as? String)
                ?: ""
            val raw = if (buffer.isNotEmpty()) buffer.toString() else mapText
            val cleaned = cleanStopTokens(raw)
            val reportedTokens = (result["tokens_predicted"] as? Number)?.toInt()
                ?: streamedTokens

            CompletionAttempt(
                text = cleaned,
                tokenCount = reportedTokens,
                errorMessage = null
            )
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            Log.e(TAG, "Completion error", t)
            val partial = cleanStopTokens(buffer.toString())
            CompletionAttempt(
                text = partial,
                tokenCount = streamedTokens,
                errorMessage = t.message?.take(120)
            )
        } finally {
            activeTokenSink = null
        }
    }

    suspend fun stopGeneration() {
        stopRequested = true
        runCatching {
            activeContext?.stopCompletion()
        }
    }

    suspend fun unloadModel() = mutex.withLock {
        withContext(engineDispatcher) {
            releaseInternal()
        }
    }

    fun releaseImmediate() {
        stopRequested = true
        runCatching { activeContext?.stopCompletion() }
        engineExecutor.execute {
            releaseInternal()
        }
        engineExecutor.shutdown()
    }

    private fun loadModelInternal(modelPath: String): Boolean {
        if (activeContext != null && loadedModelPath == modelPath) {
            return true
        }
        releaseInternal()

        val file = File(modelPath)
        if (!file.exists() || !file.canRead() || file.length() < 64L || !isValidGgufHeader(file)) {
            Log.e(TAG, "Invalid or missing GGUF file: $modelPath")
            return false
        }

        val modelUri = Uri.fromFile(file).toString()
        val (baseCtx, baseBatch, baseThreads) = computeHardwareBudget(file.length())

        val attempts = buildList {
            add(LoadConfig(nCtx = baseCtx, nBatch = baseBatch, threads = baseThreads, useMmap = false))
            if (baseCtx > 1024) {
                add(LoadConfig(nCtx = 1024, nBatch = 256, threads = baseThreads.coerceAtMost(4), useMmap = false))
            }
            add(LoadConfig(nCtx = 512, nBatch = 128, threads = baseThreads.coerceAtMost(4), useMmap = true))
        }

        for (cfg in attempts) {
            var pfd: ParcelFileDescriptor? = null
            var detachedFd = -1
            try {
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                detachedFd = pfd.detachFd()

                val engineParams = mapOf<String, Any>(
                    "model" to modelUri,
                    "model_fd" to detachedFd,
                    "n_ctx" to cfg.nCtx,
                    "n_batch" to cfg.nBatch,
                    "n_threads" to cfg.threads,
                    "n_gpu_layers" to 0,
                    "use_mmap" to cfg.useMmap,
                    "use_mlock" to false,
                    "embedding" to false,
                    "vocab_only" to false,
                    "lora" to "",
                    "lora_scaled" to 1.0,
                    "rope_freq_base" to 0.0,
                    "rope_freq_scale" to 0.0
                )

                val ctx = LlamaContext(contextIdSeq.getAndIncrement(), engineParams)
                if (ctx.context == 0L) {
                    runCatching { ctx.release() }
                    continue
                }
                ctx.setTokenCallback { tokenChunk ->
                    activeTokenSink?.invoke(tokenChunk)
                }

                activeContext = ctx
                activeContextSize = cfg.nCtx
                activeThreadCount = cfg.threads
                loadedModelPath = modelPath
                loadedModelDetails = ctx.modelDetails
                return true
            } catch (t: Throwable) {
                Log.w(TAG, "Model load attempt failed (${cfg.nCtx}, mmap=${cfg.useMmap}): ${t.message}")
                if (detachedFd >= 0) {
                    runCatching { ParcelFileDescriptor.adoptFd(detachedFd).close() }
                } else {
                    runCatching { pfd?.close() }
                }
            }
        }
        return false
    }

    private fun releaseInternal() {
        val ctx = activeContext
        activeContext = null
        loadedModelPath = null
        loadedModelDetails = emptyMap()
        activeTokenSink = null
        if (ctx != null) {
            runCatching { ctx.stopCompletion() }
            runCatching { ctx.release() }
        }
    }

    private fun trimHistoryToFitContext(
        ctx: LlamaContext,
        modelName: String,
        systemPrompt: String,
        history: List<MessageEntity>,
        maxContextTokens: Int
    ): List<MessageEntity> {
        if (history.size <= 1) return history
        val maxPromptTokens = (maxContextTokens - 96).coerceAtLeast(128)
        var startIdx = 0
        while (startIdx < history.lastIndex) {
            if (history[startIdx].role == "user") {
                val slice = history.subList(startIdx, history.size)
                val candidate = buildFormattedPrompt(ctx, modelName, systemPrompt, slice)
                val tokCount = runCatching { ctx.tokenize(candidate).size }.getOrDefault(candidate.length / 3)
                if (tokCount <= maxPromptTokens) {
                    return slice
                }
            }
            startIdx++
        }
        return history.takeLast(1)
    }

    private fun buildFormattedPrompt(
        ctx: LlamaContext,
        modelName: String,
        systemPrompt: String,
        messages: List<MessageEntity>
    ): String {
        val chatWithSystem = buildList {
            add(mapOf("role" to "system", "content" to systemPrompt))
            messages.forEach { msg ->
                val role = if (msg.role == "user") "user" else "assistant"
                add(mapOf("role" to role, "content" to msg.content))
            }
        }

        val nativeWithSystem = runCatching {
            ctx.getFormattedChat(chatWithSystem, "")
        }.getOrNull()

        if (!nativeWithSystem.isNullOrBlank()) {
            return ensureGenerationPromptSuffix(nativeWithSystem, modelName, loadedModelDetails)
        }

        // Some templates (e.g. Gemma) reject the "system" role: merge into first user message.
        val chatMergedSystem = buildList {
            var systemInserted = false
            messages.forEach { msg ->
                val role = if (msg.role == "user") "user" else "assistant"
                val content = if (!systemInserted && role == "user") {
                    systemInserted = true
                    "$systemPrompt\n\n${msg.content}"
                } else {
                    msg.content
                }
                add(mapOf("role" to role, "content" to content))
            }
        }

        val nativeMerged = runCatching {
            ctx.getFormattedChat(chatMergedSystem, "")
        }.getOrNull()

        if (!nativeMerged.isNullOrBlank()) {
            return ensureGenerationPromptSuffix(nativeMerged, modelName, loadedModelDetails)
        }

        return fallbackTemplate(modelName, loadedModelDetails, systemPrompt, messages)
    }

    private fun ensureGenerationPromptSuffix(
        formatted: String,
        modelName: String,
        modelDetails: Map<String, Any>
    ): String {
        val trimmed = formatted.trimEnd()
        val endsWithTurnCloser = listOf(
            "<|im_end|>",
            "<|eot_id|>",
            "<end_of_turn>",
            "<|end|>",
            "</s>",
            "<|endoftext|>",
            "<turn|>"
        ).any { trimmed.endsWith(it) }

        if (!endsWithTurnCloser) {
            return formatted
        }

        return when {
            "<|im_start|>" in formatted || trimmed.endsWith("<|im_end|>") ->
                "$formatted<|im_start|>assistant\n"
            "<|start_header_id|>" in formatted || trimmed.endsWith("<|eot_id|>") ->
                "$formatted<|start_header_id|>assistant<|end_header_id|>\n\n"
            "<start_of_turn>" in formatted || trimmed.endsWith("<end_of_turn>") ->
                "$formatted<start_of_turn>model\n"
            "<|user|>" in formatted || trimmed.endsWith("<|end|>") ->
                "$formatted<|assistant|>\n"
            isLlama3Model(modelName, modelDetails) ->
                "$formatted<|start_header_id|>assistant<|end_header_id|>\n\n"
            isGemmaModel(modelName, modelDetails) ->
                "$formatted<start_of_turn>model\n"
            isPhiModel(modelName, modelDetails) ->
                "$formatted<|assistant|>\n"
            else ->
                "$formatted<|im_start|>assistant\n"
        }
    }

    private fun fallbackTemplate(
        modelName: String,
        modelDetails: Map<String, Any>,
        systemPrompt: String,
        messages: List<MessageEntity>
    ): String {
        return when {
            isLlama3Model(modelName, modelDetails) -> buildString {
                append("<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n\n")
                append(systemPrompt).append("<|eot_id|>")
                messages.forEach { m ->
                    val role = if (m.role == "user") "user" else "assistant"
                    append("<|start_header_id|>").append(role).append("<|end_header_id|>\n\n")
                    append(m.content).append("<|eot_id|>")
                }
                append("<|start_header_id|>assistant<|end_header_id|>\n\n")
            }

            isGemmaModel(modelName, modelDetails) -> buildString {
                var systemInserted = false
                messages.forEach { m ->
                    val role = if (m.role == "user") "user" else "model"
                    append("<start_of_turn>").append(role).append("\n")
                    if (!systemInserted && role == "user") {
                        systemInserted = true
                        append(systemPrompt).append("\n\n")
                    }
                    append(m.content).append("<end_of_turn>\n")
                }
                append("<start_of_turn>model\n")
            }

            isPhiModel(modelName, modelDetails) -> buildString {
                append("<|system|>\n").append(systemPrompt).append("<|end|>\n")
                messages.forEach { m ->
                    val tag = if (m.role == "user") "<|user|>" else "<|assistant|>"
                    append(tag).append("\n").append(m.content).append("<|end|>\n")
                }
                append("<|assistant|>\n")
            }

            else -> buildString {
                // Standard ChatML (Qwen2.5, SmolLM2, TinyLlama-Chat, Mistral/DeepSeek Instruct variants)
                append("<|im_start|>system\n").append(systemPrompt).append("<|im_end|>\n")
                messages.forEach { m ->
                    val role = if (m.role == "user") "user" else "assistant"
                    append("<|im_start|>").append(role).append("\n")
                    append(m.content).append("<|im_end|>\n")
                }
                append("<|im_start|>assistant\n")
            }
        }
    }

    private fun isLlama3Model(modelName: String, details: Map<String, Any>): Boolean {
        val hint = "${modelName.lowercase()} ${details.values.joinToString(" ").lowercase()}"
        return "llama-3" in hint || "llama3" in hint || "<|eot_id|>" in hint
    }

    private fun isGemmaModel(modelName: String, details: Map<String, Any>): Boolean {
        val hint = "${modelName.lowercase()} ${details.values.joinToString(" ").lowercase()}"
        return "gemma" in hint || "<start_of_turn>" in hint
    }

    private fun isPhiModel(modelName: String, details: Map<String, Any>): Boolean {
        val hint = "${modelName.lowercase()} ${details.values.joinToString(" ").lowercase()}"
        return "phi-" in hint || "phi3" in hint || "phi4" in hint || "<|assistant|>" in hint
    }

    private fun computeHardwareBudget(modelSizeBytes: Long): Triple<Int, Int, Int> {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)

        val totalRam = memInfo.totalMem
        val availRam = memInfo.availMem

        val nCtx = when {
            totalRam >= 6_000_000_000L && availRam >= 1_800_000_000L && modelSizeBytes < 2_500_000_000L -> 2048
            totalRam >= 3_500_000_000L && availRam >= 1_000_000_000L -> 1536
            else -> 1024
        }
        val nBatch = if (nCtx >= 2048) 512 else 256
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
        return Triple(nCtx, nBatch, threads)
    }

    private fun isValidGgufHeader(file: File): Boolean {
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                if (raf.length() < 4L) return@use false
                val magic = ByteArray(4)
                raf.readFully(magic)
                magic[0] == 'G'.code.toByte() &&
                    magic[1] == 'G'.code.toByte() &&
                    magic[2] == 'U'.code.toByte() &&
                    magic[3] == 'F'.code.toByte()
            }
        }.getOrDefault(false)
    }

    private fun cleanStopTokens(raw: String): String {
        var result = raw
        for (token in STOP_TOKENS) {
            result = result.replace(token, "")
        }
        return result.trimStart('\n').trimEnd()
    }

    private fun estimateTokens(text: String): Int {
        return (text.length / 4).coerceAtLeast(1)
    }

    private data class LoadConfig(
        val nCtx: Int,
        val nBatch: Int,
        val threads: Int,
        val useMmap: Boolean
    )

    private data class CompletionAttempt(
        val text: String,
        val tokenCount: Int,
        val errorMessage: String?
    )

    private companion object {
        const val TAG = "XireLocalLlm"
        val STOP_TOKENS = listOf(
            "</s>",
            "<|im_end|>",
            "<|im_start|>",
            "<|eot_id|>",
            "<|end_of_text|>",
            "<end_of_turn>",
            "<|end|>",
            "<|endoftext|>",
            "<|return|>",
            "<turn|>"
        )
    }
}
