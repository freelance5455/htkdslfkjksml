package com.example.engine.future

import com.example.engine.AngleMode
import com.example.engine.CalculationEngine
import com.example.engine.EvalResult

/**
 * Future-ready graphing module architecture.
 * Decoupled from standard calculator state so a dedicated graphing screen can
 * plug in cleanly without destabilizing core calculator workflows.
 */
data class GraphViewport(
  val xMin: Double = -10.0,
  val xMax: Double = 10.0,
  val yMin: Double = -10.0,
  val yMax: Double = 10.0,
)

data class PlotPoint(
  val x: Double,
  val y: Double?,
)

data class FunctionPlotSpec(
  val id: String,
  val expressionWithX: String,
  val label: String,
)

object GraphSampler {
  fun sampleFunction(
    spec: FunctionPlotSpec,
    viewport: GraphViewport,
    sampleCount: Int = 200,
    angleMode: AngleMode = AngleMode.RAD,
  ): List<PlotPoint> {
    if (sampleCount < 2 || viewport.xMax <= viewport.xMin) return emptyList()
    val step = (viewport.xMax - viewport.xMin) / (sampleCount - 1)
    return (0 until sampleCount).map { idx ->
      val x = viewport.xMin + idx * step
      val substituted = substituteVariableX(spec.expressionWithX, x)
      val y =
        when (val res = CalculationEngine.evaluate(substituted, angleMode)) {
          is EvalResult.Success -> res.value.toDouble()
          is EvalResult.Error -> null
        }
      PlotPoint(x = x, y = y)
    }
  }

  private fun substituteVariableX(expression: String, x: Double): String {
    val replacement = if (x < 0) "(${x})" else x.toString()
    return Regex("""\bx\b""", RegexOption.IGNORE_CASE).replace(expression, replacement)
  }
}
