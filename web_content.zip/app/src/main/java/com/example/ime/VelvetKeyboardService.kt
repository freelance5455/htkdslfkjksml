package com.example.ime

import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.ai.CustomTtsSpeaker
import com.example.ai.CustomVoiceRecorder
import com.example.ai.VelvetAiEngine
import com.example.ai.VelvetVoiceEngine
import com.example.data.VelvetSettings
import com.example.data.VelvetSettingsRepository
import com.example.firebase.ensureServiceAppCheck
import com.example.keyboard.ClipboardHistoryManager
import com.example.keyboard.HapticFeedbackEngine
import com.example.keyboard.ui.KeyboardSessionController
import com.example.keyboard.ui.TextTargetAdapter
import com.example.keyboard.ui.VelvetKeyboardView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class VelvetKeyboardService : InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var settingsRepo: VelvetSettingsRepository
    private lateinit var haptics: HapticFeedbackEngine
    private lateinit var aiEngine: VelvetAiEngine
    private lateinit var wavRecorder: CustomVoiceRecorder
    private lateinit var voiceEngine: VelvetVoiceEngine
    private lateinit var ttsSpeaker: CustomTtsSpeaker
    private lateinit var clipboardManager: ClipboardHistoryManager
    private lateinit var controller: KeyboardSessionController

    private var actionLabel by mutableStateOf("Return")
    private var imeOptions by mutableStateOf(EditorInfo.IME_ACTION_NONE)
    private var showSwitcher by mutableStateOf(false)

    private val inputConnectionAdapter = object : TextTargetAdapter {
        override fun commitText(text: String) {
            try {
                currentInputConnection?.commitText(text, 1)
            } catch (_: Exception) {
            }
        }

        override fun deleteBeforeCursor(count: Int) {
            val ic = currentInputConnection ?: return
            if (count <= 0) return
            try {
                val selected = ic.getSelectedText(0)
                if (!selected.isNullOrEmpty()) {
                    ic.commitText("", 1)
                } else {
                    ic.deleteSurroundingText(count, 0)
                }
            } catch (_: Exception) {
            }
        }

        override fun getTextBeforeCursor(maxChars: Int): String {
            return try {
                currentInputConnection?.getTextBeforeCursor(maxChars, 0)?.toString().orEmpty()
            } catch (_: Exception) {
                ""
            }
        }

        override fun replaceAllText(newText: String) {
            val ic = currentInputConnection ?: return
            try {
                val extracted = ic.getExtractedText(android.view.inputmethod.ExtractedTextRequest(), 0)
                if (extracted != null) {
                    ic.beginBatchEdit()
                    ic.setSelection(0, extracted.text.length)
                    ic.commitText(newText, 1)
                    ic.endBatchEdit()
                } else {
                    val before = ic.getTextBeforeCursor(1000, 0)?.length ?: 0
                    val after = ic.getTextAfterCursor(1000, 0)?.length ?: 0
                    ic.beginBatchEdit()
                    ic.deleteSurroundingText(before, after)
                    ic.commitText(newText, 1)
                    ic.endBatchEdit()
                }
            } catch (_: Exception) {
            }
        }

        override fun performAction(): Boolean {
            val ic = currentInputConnection ?: return false
            return try {
                val action = imeOptions and EditorInfo.IME_MASK_ACTION
                val noEnterFlag = (imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
                if (!noEnterFlag && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    ic.performEditorAction(action)
                } else {
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                    ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                    true
                }
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun moveLifecycleTo(target: Lifecycle.State) {
        try {
            if (lifecycleRegistry.currentState != Lifecycle.State.DESTROYED) {
                lifecycleRegistry.currentState = target
            }
        } catch (_: Throwable) {
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        moveLifecycleTo(Lifecycle.State.CREATED)

        ensureServiceAppCheck(this)
        settingsRepo = VelvetSettingsRepository.getInstance(this)
        haptics = HapticFeedbackEngine(this)
        aiEngine = VelvetAiEngine()
        wavRecorder = CustomVoiceRecorder(this)
        voiceEngine = VelvetVoiceEngine(this, wavRecorder)
        ttsSpeaker = CustomTtsSpeaker(this, aiEngine)
        clipboardManager = ClipboardHistoryManager(this, settingsRepo, serviceScope).apply {
            startListening()
        }

        controller = KeyboardSessionController(
            scope = serviceScope,
            settingsRepo = settingsRepo,
            haptics = haptics,
            aiEngine = aiEngine,
            voiceEngine = voiceEngine,
            ttsSpeaker = ttsSpeaker,
            clipboardManager = clipboardManager,
            textTarget = inputConnectionAdapter,
            onSwitchIme = {
                try {
                    switchToNextInputMethod(false)
                } catch (_: Exception) {
                }
            },
            onOpenSettings = {
                try {
                    val intent = Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra("open_tab", "settings")
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                }
            },
            onRequestMicPermission = {
                try {
                    val intent = Intent(this, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra("request_mic", true)
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
        )
    }

    override fun onCreateInputView(): View {
        window?.window?.decorView?.let { decor ->
            decor.setViewTreeLifecycleOwner(this)
            decor.setViewTreeViewModelStoreOwner(this)
            decor.setViewTreeSavedStateRegistryOwner(this)
        }

        return ComposeView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setViewTreeLifecycleOwner(this@VelvetKeyboardService)
            setViewTreeViewModelStoreOwner(this@VelvetKeyboardService)
            setViewTreeSavedStateRegistryOwner(this@VelvetKeyboardService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
            setContent {
                val settings by settingsRepo.settingsFlow.collectAsStateWithLifecycle(
                    initialValue = VelvetSettings()
                )
                VelvetKeyboardView(
                    controller = controller,
                    settings = settings,
                    showImeSwitcher = showSwitcher,
                    showSettingsShortcut = true,
                    applyNavigationBarsPadding = true,
                    actionLabel = actionLabel,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        moveLifecycleTo(Lifecycle.State.RESUMED)
        clipboardManager.syncCurrentPrimaryClip()

        imeOptions = info?.imeOptions ?: EditorInfo.IME_ACTION_NONE
        actionLabel = when (imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "Search"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            else -> "Return"
        }
        showSwitcher = try {
            shouldOfferSwitchingToNextInputMethod()
        } catch (_: Exception) {
            false
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        controller.cancelInlineVoice()
        moveLifecycleTo(Lifecycle.State.STARTED)
    }

    override fun onDestroy() {
        super.onDestroy()
        clipboardManager.stopListening()
        voiceEngine.cancel()
        ttsSpeaker.shutdown()
        serviceScope.cancel()
        moveLifecycleTo(Lifecycle.State.DESTROYED)
        store.clear()
    }
}
