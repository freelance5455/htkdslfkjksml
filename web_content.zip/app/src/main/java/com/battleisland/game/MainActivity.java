package com.battleisland.game;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private RewardedAd rewardedAd;

    // Your real Google AdMob Rewarded Ad Unit ID.
    private static final String REWARDED_AD_UNIT_ID =
            "ca-app-pub-5650391122941934/9027110603";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        MobileAds.initialize(this, status -> loadRewardedAd());

        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebChromeClient(new WebChromeClient());

        webView.addJavascriptInterface(new AdBridge(), "AndroidAds");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private void loadRewardedAd() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, REWARDED_AD_UNIT_ID, request,
            new RewardedAdLoadCallback() {
                @Override
                public void onAdLoaded(@NonNull RewardedAd ad) {
                    rewardedAd = ad;
                }

                @Override
                public void onAdFailedToLoad(@NonNull LoadAdError error) {
                    rewardedAd = null;
                }
            });
    }

    private void showRewarded() {
        runOnUiThread(() -> {
            if (rewardedAd == null) {
                loadRewardedAd();
                Toast.makeText(this, "Ad is loading. Try again.", Toast.LENGTH_SHORT).show();
                return;
            }

            RewardedAd ad = rewardedAd;
            rewardedAd = null;

            ad.show(this, rewardItem -> {
                // The HTML game receives the reward only after the reward callback.
                webView.evaluateJavascript(
                    "window.onAdRewarded && window.onAdRewarded(" + rewardItem.getAmount() + ");",
                    null
                );
            });

            ad.setFullScreenContentCallback(new com.google.android.gms.ads.FullScreenContentCallback() {
                @Override
                public void onAdDismissedFullScreenContent() {
                    loadRewardedAd();
                }
            });
        });
    }

    public class AdBridge {
        @JavascriptInterface
        public void showRewardedAd() {
            showRewarded();
        }

        @JavascriptInterface
        public boolean isRewardedAdReady() {
            return rewardedAd != null;
        }
    }
}
