package com.app.smarty
data class ActionResult(val success:Boolean,val message:String)
