package com.app.smarty

import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.io.BufferedReader
import java.io.InputStreamReader

object SmartAiClient {
    // Set this to your deployed HTTPS Smart backend.
    // Example: https://api.yourdomain.com
    private const val BASE_URL = "https://YOUR-SMART-BACKEND-DOMAIN"

    private val sessionId: String by lazy {
        UUID.randomUUID().toString()
    }

    fun ask(message: String, callback: (String) -> Unit) {
        Thread {
            try {
                val url = URL("$BASE_URL/api/chat")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                }

                val body = JSONObject()
                    .put("message", message)
                    .put("sessionId", sessionId)
                    .toString()

                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use {
                    it.write(body)
                }

                val stream = if (connection.responseCode in 200..299) {
                    connection.inputStream
                } else {
                    connection.errorStream
                }

                val response = BufferedReader(InputStreamReader(stream)).use { reader ->
                    reader.readText()
                }

                if (connection.responseCode !in 200..299) {
                    val error = try {
                        JSONObject(response).optString("error", "Smart AI backend error")
                    } catch (_: Exception) {
                        "Smart AI backend error"
                    }
                    callback("Smart: $error")
                } else {
                    val text = JSONObject(response).optString(
                        "response",
                        "I didn't receive a response from Smart AI."
                    )
                    callback(text)
                }

                connection.disconnect()
            } catch (e: Exception) {
                callback("Smart could not reach its AI backend. Check your internet connection and backend URL.")
            }
        }.start()
    }
}
