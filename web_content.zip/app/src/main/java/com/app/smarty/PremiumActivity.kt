package com.app.smarty

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PremiumActivity : AppCompatActivity() {
    private lateinit var billing: BillingManager
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_premium)

        status = findViewById(R.id.billingStatus)
        billing = BillingManager(this) { message ->
            runOnUiThread { status.text = message }
        }
        billing.connect()

        findViewById<Button>(R.id.monthlyButton).setOnClickListener {
            billing.buy(this, BillingManager.MONTHLY_ID)
        }
        findViewById<Button>(R.id.yearlyButton).setOnClickListener {
            billing.buy(this, BillingManager.YEARLY_ID)
        }
    }

    override fun onDestroy() {
        billing.close()
        super.onDestroy()
    }
}
