package com.app.smarty

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.Manifest
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var drawer: LinearLayout
    private lateinit var dim: View
    private lateinit var scroll: ScrollView
    private lateinit var voiceStatus: TextView
    private lateinit var voiceButton: TextView
    private lateinit var voiceHint: TextView

    private val bg = Color.rgb(14, 16, 22)
    private val panel = Color.rgb(25, 28, 38)
    private val panel2 = Color.rgb(31, 35, 47)
    private val text = Color.rgb(244, 244, 248)
    private val muted = Color.rgb(165, 169, 182)
    private val accent = Color.rgb(103, 92, 255)

    private val voiceStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            val active = intent?.getBooleanExtra(SmartVoiceService.EXTRA_ACTIVE, false) ?: false
            updateVoiceCard(active)
        }
    }

    private val responseReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            val value = intent?.getStringExtra(SmartVoiceService.EXTRA_RESPONSE) ?: return
            addAssistantMessage(value)
        }
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        buildUi()
        val filter = IntentFilter(SmartVoiceService.ACTION_RESPONSE)
        val stateFilter = IntentFilter(SmartVoiceService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(responseReceiver, filter, RECEIVER_NOT_EXPORTED)
            registerReceiver(voiceStateReceiver, stateFilter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(responseReceiver, filter)
            registerReceiver(voiceStateReceiver, stateFilter)
        }
        updateVoiceCard(getSharedPreferences(SmartVoiceService.PREFS, MODE_PRIVATE)
            .getBoolean(SmartVoiceService.PREF_ACTIVE, false))
    }

    override fun onResume() {
        super.onResume()
        if (::voiceStatus.isInitialized) {
            updateVoiceCard(getSharedPreferences(SmartVoiceService.PREFS, MODE_PRIVATE)
                .getBoolean(SmartVoiceService.PREF_ACTIVE, false))
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(responseReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(voiceStateReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(bg) }

        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        root.addView(main, FrameLayout.LayoutParams(-1, -1))

        // ChatGPT-style top bar
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val menu = iconButton("☰")
        menu.contentDescription = "Open Smart menu"
        top.addView(menu, LinearLayout.LayoutParams(dp(58), dp(48)) )
        val title = TextView(this).apply {
            this.text = "Smart"
            setTextColor(text)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, 0, 0)
        }
        top.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        val newChat = iconButton("＋")
        newChat.contentDescription = "New chat"
        top.addView(newChat, LinearLayout.LayoutParams(dp(48), dp(48)))
        main.addView(top)

        scroll = ScrollView(this).apply { isFillViewport = true }
        chat = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
        }
        scroll.addView(chat, ScrollView.LayoutParams(-1, -2))
        main.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        addAssistantMessage("Hi, I'm Smart.\n\nI can chat with you and help control supported parts of your phone. Ask me a question or type a phone command below.\n\nFor hands-free control, activate Smart Voice below.")

        addChatWelcomeCard(main)
        addVoiceCard(main)

        // Bottom composer
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }
        input = EditText(this).apply {
            hint = "💬  Chat with Smart or give a command..."
            hintTextColor = muted
            setTextColor(text)
            textSize = 16f
            setSingleLine(false)
            minLines = 1
            maxLines = 4
            setPadding(dp(16), dp(11), dp(12), dp(11))
            setBackgroundColor(panel2)
        }
        composer.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val mic = iconButton("🎙")
        composer.addView(mic, LinearLayout.LayoutParams(dp(50), dp(52)))
        val send = iconButton("➤")
        composer.addView(send, LinearLayout.LayoutParams(dp(50), dp(52)))
        main.addView(composer)

        menu.setOnClickListener { openDrawer() }
        newChat.setOnClickListener { newConversation() }
        mic.setOnClickListener { startVoice() }
        send.setOnClickListener { sendCommand() }

        // Drawer overlay
        dim = View(this).apply {
            setBackgroundColor(Color.argb(150, 0, 0, 0))
            visibility = View.GONE
        }
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))
        dim.setOnClickListener { closeDrawer() }

        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(14), dp(18), dp(14), dp(14))
            elevation = dp(12).toFloat()
        }
        val drawerParams = FrameLayout.LayoutParams(dp(310), -1).apply { gravity = Gravity.START }
        root.addView(drawer, drawerParams)
        buildDrawer()
        drawer.visibility = View.GONE

        setContentView(root)
    }

    private fun buildDrawer() {
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(4), dp(16))
        }
        val logo = TextView(this).apply {
            text = "S"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(accent)
        }
        brand.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)))
        val name = TextView(this).apply {
            text = "Smart"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(text)
            setPadding(dp(12), 0, 0, 0)
        }
        brand.addView(name, LinearLayout.LayoutParams(0, dp(48), 1f))
        val close = iconButton("×")
        brand.addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))
        close.setOnClickListener { closeDrawer() }
        drawer.addView(brand)

        val newBtn = drawerButton("＋  New chat")
        drawer.addView(newBtn)
        newBtn.setOnClickListener { newConversation(); closeDrawer() }

        val searchBtn = drawerButton("⌕  Search chats")
        drawer.addView(searchBtn)
        searchBtn.setOnClickListener {
            closeDrawer()
            input.requestFocus()
        }

        drawer.addView(sectionLabel("CHATS"))
        val recent = drawerButton("Smart phone assistant")
        drawer.addView(recent)
        recent.setOnClickListener { closeDrawer() }
        val phone = drawerButton("📱  Phone control")
        drawer.addView(phone)
        phone.setOnClickListener { addUserMessage("Show my phone controls"); closeDrawer() }

        val everything = drawerButton("✨  Everything Smart can do")
        drawer.addView(everything)
        everything.setOnClickListener { showAllFeatures() }

        val spacer = Space(this)
        drawer.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        drawer.addView(sectionLabel("SMART"))
        val settings = drawerButton("⚙  Android Settings")
        drawer.addView(settings)
        settings.setOnClickListener { startActivity(Intent(Settings.ACTION_SETTINGS)); closeDrawer() }

        val gesture = drawerButton("✋  Gesture Mode")
        drawer.addView(gesture)
        gesture.setOnClickListener { startActivity(Intent(this, GestureActivity::class.java)); closeDrawer() }

        val voice = drawerButton("🎤  Smart Voice Service")
        drawer.addView(voice)
        voice.setOnClickListener {
            startSmartVoice()
            closeDrawer()
        }

        val bubble = drawerButton("🟣  Floating Smart Button")
        drawer.addView(bubble)
        bubble.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            } else startSmartVoice()
            closeDrawer()
        }

        val access = drawerButton("♿  Permissions & Access")
        drawer.addView(access)
        access.setOnClickListener { requestSmartPermissions(); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); closeDrawer() }

        val signIn = drawerButton("◉  Sign in")
        drawer.addView(signIn)
        signIn.setOnClickListener { Toast.makeText(this, "Sign-in screen will be connected to Smart accounts next.", Toast.LENGTH_SHORT).show() }

        val pro = drawerButton("★  Smart Pro")
        drawer.addView(pro)
        pro.setOnClickListener { startActivity(Intent(this, PremiumActivity::class.java)); closeDrawer() }

        val devices = drawerButton("▦  Devices & Company")
        drawer.addView(devices)
        devices.setOnClickListener {
            showAllFeatures()
        }

        val version = TextView(this).apply {
            text = "Smart • AI Phone Agent"
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(10), dp(12), dp(10), 0)
        }
        drawer.addView(version)
    }


    private fun showAllFeatures() {
        val features = """SMART — EVERYTHING

💬 CHAT & AI
• Chat with Smart
• Quick prompts and new chats
• AI backend connection foundation

🎤 VOICE
• Smart Voice activation
• “Hey Smart” voice workflow foundation
• Spoken responses
• Voice button inside the chat

📱 PHONE CONTROL
• Open supported apps
• Home / Back / Recent Apps
• Notifications and Quick Settings
• Tap, scroll and supported text entry
• Settings / Wi‑Fi / Bluetooth

📞 COMMUNICATION
• Call contacts by name
• Open dialer
• Prepare SMS messages

🌐 INTERNET
• Google/web search
• Open websites and URLs

📷 TOOLS
• Camera
• Screenshot through supported Accessibility actions
• Alarm and timer

♿ ACCESSIBILITY
• Screen interaction for supported actions
• Gesture mode
• Accessibility permission setup

🟣 FLOATING SMART
• Floating Smart button / overlay foundation

🔔 NOTIFICATIONS
• Notification listener foundation

⭐ BUSINESS
• Smart Pro / billing foundation
• Usage tracking foundation
• Sign-in foundation
• Multi-device/company-management foundation

⚠ Android permissions are required for many phone actions. Background microphone access is also restricted by Android."""
        AlertDialog.Builder(this)
            .setTitle("Everything Smart can do")
            .setMessage(features)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun openDrawer() {
        drawer.visibility = View.VISIBLE
        dim.visibility = View.VISIBLE
    }

    private fun closeDrawer() {
        drawer.visibility = View.GONE
        dim.visibility = View.GONE
    }


    private fun startSmartVoice() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 42)
            return
        }

        val serviceIntent = Intent(this, SmartVoiceService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
            updateVoiceCard(true)
            addAssistantMessage("🎤 Smart Voice activated. Say: “Hey Smart, open WhatsApp”.")
        } catch (e: Exception) {
            updateVoiceCard(false)
            Toast.makeText(this, "Smart Voice could not start. Open Smart again and try Activate Voice.", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopSmartVoice() {
        try { stopService(Intent(this, SmartVoiceService::class.java)) } catch (_: Exception) {}
        updateVoiceCard(false)
        Toast.makeText(this, "Smart Voice stopped.", Toast.LENGTH_SHORT).show()
    }

    private fun addChatWelcomeCard(parent: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(Color.rgb(24, 28, 40))
            elevation = dp(2).toFloat()
        }

        val title = TextView(this).apply {
            text = "💬  Chat with Smart"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(text)
        }
        card.addView(title)

        val subtitle = TextView(this).apply {
            text = "Ask questions, get help, or tell Smart what you want done."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(6), 0, dp(12))
        }
        card.addView(subtitle)

        val prompts = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val examples = listOf("What can you do?", "Help me", "Open WhatsApp")
        examples.forEach { example ->
            val b = TextView(this).apply {
                text = example
                textSize = 12.5f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(8), dp(10), dp(8))
                setBackgroundColor(panel2)
                isClickable = true
            }
            b.setOnClickListener {
                input.setText(example)
                input.setSelection(input.text.length)
                sendCommand()
            }
            prompts.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        card.addView(prompts)

        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(dp(12), dp(2), dp(12), dp(6))
        })
    }

    private fun addVoiceCard(parent: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            setBackgroundColor(Color.rgb(29, 32, 48))
            elevation = dp(2).toFloat()
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val icon = TextView(this).apply {
            text = "🎤"
            textSize = 28f
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(103, 92, 255))
        }
        header.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        val heading = TextView(this).apply {
            text = "Smart Voice"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(text)
        }
        titles.addView(heading)
        voiceStatus = TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(4), 0, 0)
        }
        titles.addView(voiceStatus)
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(header)

        voiceHint = TextView(this).apply {
            text = "Turn this on, then you can say “Hey Smart” while using other apps."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(12), 0, dp(12))
        }
        card.addView(voiceHint)

        voiceButton = TextView(this).apply {
            text = "🎤  ACTIVATE SMART VOICE"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(Color.rgb(103, 92, 255))
            isClickable = true
            minHeight = dp(56)
        }
        card.addView(voiceButton, LinearLayout.LayoutParams(-1, dp(56)))
        voiceButton.setOnClickListener {
            if (voiceButton.text.toString().contains("STOP")) stopSmartVoice() else startSmartVoice()
        }

        val help = TextView(this).apply {
            text = "Need the floating button? Open ☰ → Floating Smart Button."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        card.addView(help)

        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(dp(12), dp(6), dp(12), dp(8))
        })
    }

    private fun updateVoiceCard(active: Boolean) {
        if (!::voiceStatus.isInitialized) return
        if (active) {
            voiceStatus.text = "● ACTIVE — listening for “Hey Smart”"
            voiceStatus.setTextColor(Color.rgb(74, 222, 128))
            voiceHint.text = "Smart Voice is running. You can leave Smart and use supported voice commands."
            voiceButton.text = "⏹  STOP SMART VOICE"
            voiceButton.setBackgroundColor(Color.rgb(180, 55, 70))
        } else {
            voiceStatus.text = "○ OFF — voice control is not active"
            voiceStatus.setTextColor(muted)
            voiceHint.text = "Turn this on, then you can say “Hey Smart” while using other apps."
            voiceButton.text = "🎤  ACTIVATE SMART VOICE"
            voiceButton.setBackgroundColor(Color.rgb(103, 92, 255))
        }
    }

    private fun requestSmartPermissions() {
        val needed = mutableListOf<String>()
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO)
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.READ_CONTACTS)
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CAMERA)
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CALL_PHONE)
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 42)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42) {
            val micGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            if (micGranted) startSmartVoice()
            else Toast.makeText(this, "Microphone permission is required for Smart Voice.", Toast.LENGTH_LONG).show()
        }
    }

    private fun newConversation() {
        chat.removeAllViews()
        addAssistantMessage("New chat started. What would you like Smart to do?")
        input.setText("")
    }

    private fun sendCommand() {
        val command = input.text.toString().trim()
        if (command.isEmpty()) return
        addUserMessage(command)
        input.setText("")
        val lower = command.lowercase(Locale.getDefault())
        when {
            lower in setOf("hi", "hello", "hey", "hey smart") -> addAssistantMessage("Hello! I’m Smart. You can say things like “Open WhatsApp”, “Go back”, “Call John”, “Search for something”, or activate Smart Voice for hands-free control.")
            lower.contains("what can you do") || lower == "help" || lower.contains("help me") -> showAllFeatures()
            else -> SmartCommandEngine(this) { addAssistantMessage(it) }.run(command)
        }
    }

    private fun startVoice() {
        startActivityForResult(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault()), 99
        )
    }

    override fun onActivityResult(request: Int, result: Int, data: Intent?) {
        super.onActivityResult(request, result, data)
        if (request == 99 && result == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                input.setText(spoken)
                sendCommand()
            }
        }
    }

    private fun addUserMessage(value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dp(5), 0, dp(5))
        }
        val bubble = TextView(this).apply {
            text = value
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(accent)
        }
        row.addView(bubble, LinearLayout.LayoutParams(-2, -2))
        chat.addView(row)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addAssistantMessage(value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.START
            setPadding(0, dp(5), 0, dp(5))
        }
        val bubble = TextView(this).apply {
            text = value
            textSize = 16f
            setTextColor(text)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setBackgroundColor(panel)
        }
        row.addView(bubble, LinearLayout.LayoutParams(-1, -2))
        chat.addView(row)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun drawerButton(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 15.5f
        setTextColor(text)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(14), 0, dp(12), 0)
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = true
        minHeight = dp(48)
    }

    private fun sectionLabel(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 11f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(muted)
        setPadding(dp(14), dp(18), dp(14), dp(6))
    }

    private fun iconButton(label: String): TextView = TextView(this).apply {
        text = label
        textSize = 25f
        setTextColor(text)
        gravity = Gravity.CENTER
        isClickable = true
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
