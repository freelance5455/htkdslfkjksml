package com.app.smarty

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat

class SmartCommandEngine(private val context: Context, private val speak: (String) -> Unit) {
    fun run(raw: String) {
        val c = raw.trim()
        val l = c.lowercase()
        if (c.isBlank()) return

        when {
            l == "back" || l == "go back" -> global(AccessibilityService.GLOBAL_ACTION_BACK, "Going back")
            l == "home" || l == "go home" -> global(AccessibilityService.GLOBAL_ACTION_HOME, "Going home")
            l.contains("recent apps") || l == "recents" -> global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Opening recent apps")
            l.contains("notifications") || l == "open notifications" -> global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Opening notifications")
            l.contains("quick settings") -> global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, "Opening quick settings")

            l.contains("scroll down") || l.contains("swipe up") -> {
                SmartAccessibilityService.instance?.scroll(true)
                speak("Scrolling down")
            }
            l.contains("scroll up") || l.contains("swipe down") -> {
                SmartAccessibilityService.instance?.scroll(false)
                speak("Scrolling up")
            }

            l.startsWith("tap ") || l.startsWith("click ") -> {
                val target = c.substringAfter(" ").trim()
                val node = SmartAccessibilityService.instance?.findText(target)
                if (node != null) {
                    node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK)
                    speak("Tapped $target")
                } else speak("I could not find $target on the current screen.")
            }

            l == "open settings" || l == "settings" -> open(Intent(Settings.ACTION_SETTINGS), "Opening settings")
            l.contains("accessibility settings") -> open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), "Opening Accessibility settings")
            l.contains("notification access") -> open(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"), "Opening notification access")
            l.contains("wifi") -> open(Intent(Settings.ACTION_WIFI_SETTINGS), "Opening Wi-Fi settings")
            l.contains("bluetooth") -> open(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Opening Bluetooth settings")

            l.startsWith("open http://") || l.startsWith("open https://") -> openUrl(c.substringAfter("open "))
            l.startsWith("open website ") -> openUrl(c.substringAfter("open website "))
            l.startsWith("visit ") -> openUrl(c.substringAfter("visit "))

            l.startsWith("search ") || l.startsWith("search for ") -> {
                val q = c.substringAfter("search ").removePrefix("for ").trim()
                open(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))), "Searching the web")
            }

            l.startsWith("open ") -> openApp(c.substringAfter("open ").trim())

            l.startsWith("call ") || l.startsWith("phone ") -> callContact(c.substringAfter(" ").trim())

            l.startsWith("send sms ") || l.startsWith("send text ") || l.startsWith("text ") -> {
                sendSms(c.substringAfter(" ").trim())
            }

            l.startsWith("set alarm ") || l.startsWith("alarm ") -> setAlarm(c.substringAfter(" ").trim())

            l.contains("screenshot") || l.contains("screen shot") || l.contains("capture my screen") -> {
                val service = SmartAccessibilityService.instance
                if (service == null) speak("Please enable Smart Accessibility access first so I can capture the screen.")
                else service.takeScreenshotToGallery { speak(it) }
            }
            l.contains("camera") -> open(Intent("android.media.action.IMAGE_CAPTURE"), "Opening camera")
            l.contains("timer") -> open(Intent("android.intent.action.SET_TIMER"), "Opening timer")

            else -> speak("I heard: $c\n\nTry commands such as Open WhatsApp, Open Facebook, Call Mum, Send SMS 080... | Hello, Search for something, Open website example.com, Set alarm 07:00, Go back, or Scroll down.")
        }
    }

    private fun global(action: Int, message: String) {
        val ok = SmartAccessibilityService.instance?.global(action) == true
        speak(if (ok) message else "Please enable Smart Accessibility access first.")
    }

    private fun open(intent: Intent, message: String) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            speak(message)
        } catch (_: Exception) {
            speak("Android could not open that action on this phone.")
        }
    }

    private fun openUrl(raw: String) {
        val value = raw.trim()
        val url = if (value.startsWith("http://") || value.startsWith("https://")) value else "https://$value"
        open(Intent(Intent.ACTION_VIEW, Uri.parse(url)), "Opening website")
    }

    private fun openApp(name: String) {
        val pm = context.packageManager
        val normalized = name.lowercase()
        val known = mapOf(
            "whatsapp" to "com.whatsapp",
            "facebook" to "com.facebook.katana",
            "messenger" to "com.facebook.orca",
            "instagram" to "com.instagram.android",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "google chrome" to "com.android.chrome",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "settings" to "com.android.settings",
            "telegram" to "org.telegram.messenger",
            "tiktok" to "com.zhiliaoapp.musically"
        )
        var intent: Intent? = known[normalized]?.let { pm.getLaunchIntentForPackage(it) }

        if (intent == null) {
            val apps = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
                PackageManager.MATCH_ALL
            )
            val match = apps.firstOrNull {
                val label = it.loadLabel(pm).toString().lowercase()
                label == normalized || label.contains(normalized) || normalized.contains(label)
            }
            intent = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        }

        if (intent == null) {
            speak("I could not find the app $name on this phone.")
            return
        }
        open(intent, "Opening $name")
    }

    private fun callContact(name: String) {
        if (name.matches(Regex("[+0-9*# ()-]{5,}"))) {
            dial(name.replace(Regex("[^+0-9*#]"), ""), "Opening the dialer")
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            speak("Please allow Smart to access Contacts in Permissions & Access, then ask me to call $name again.")
            return
        }
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        var number: String? = null
        context.contentResolver.query(uri, projection, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { cur ->
            if (cur.moveToFirst()) number = cur.getString(0)
        }
        if (number.isNullOrBlank()) speak("I could not find $name in your contacts.")
        else dial(number!!, "Opening the dialer for $name")
    }

    private fun dial(number: String, message: String) {
        val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            open(callIntent, "Calling $number")
        } else {
            open(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")), message)
        }
    }

    private fun sendSms(raw: String) {
        val parts = raw.split("|", limit = 2)
        if (parts.size < 2) {
            speak("Use: Send SMS 08012345678 | Your message")
            return
        }
        val number = parts[0].trim()
        val message = parts[1].trim()
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).apply { putExtra("sms_body", message) }
        open(intent, "Opening the SMS composer for your review")
    }

    private fun setAlarm(raw: String) {
        val parts = raw.split(":")
        if (parts.size != 2) {
            speak("Use: Set alarm HH:MM")
            return
        }
        val hour = parts[0].toIntOrNull()
        val minute = parts[1].toIntOrNull()
        if (hour == null || minute == null || hour !in 0..23 || minute !in 0..59) {
            speak("That alarm time is not valid.")
            return
        }
        open(Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Smart alarm")
        }, "Opening the alarm confirmation")
    }
}
