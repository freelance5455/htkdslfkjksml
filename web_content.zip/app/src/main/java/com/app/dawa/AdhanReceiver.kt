package com.app.dawa

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class AdhanReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == AdhanScheduler.ACTION_FIRE) {
            val k = i.getStringExtra("k") ?: ""
            val n = i.getStringExtra("n") ?: ""
            val t = i.getLongExtra("t", 0L)
            // ignore alarms that are very late (e.g. phone was off) so it never plays at a wrong time
            val fresh = System.currentTimeMillis() - t < 10 * 60_000L
            if (fresh && k.isNotEmpty()) {
                when (AdhanStore.mode(c, k)) {
                    "on" -> try {
                        ContextCompat.startForegroundService(c, Intent(c, AdhanService::class.java).putExtra("n", n))
                    } catch (e: Exception) { silentNotification(c, n) }
                    "silent" -> silentNotification(c, n)
                }
            }
        }
        // chain to the next prayer (also runs after boot / time change / app update)
        AdhanScheduler.scheduleNext(c)
    }

    companion object {
        fun silentNotification(c: Context, n: String) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (android.os.Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("silent") == null)
                nm.createNotificationChannel(NotificationChannel("silent", "إشعار صامت للصلاة", NotificationManager.IMPORTANCE_DEFAULT).apply { setSound(null, null) })
            val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val nt = NotificationCompat.Builder(c, "silent").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("حان وقت الصلاة: $n").setContentIntent(open).setAutoCancel(true).setSilent(true).build()
            try { nm.notify(2002, nt) } catch (e: SecurityException) {}
        }
    }
}
