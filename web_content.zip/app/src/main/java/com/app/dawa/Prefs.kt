package com.app.dawa

import android.content.Context
import org.json.JSONArray

object Prayers {
    val keys = listOf("fajr", "dhuhr", "asr", "maghrib", "isha")
    val names = mapOf(
        "fajr" to "الفجر", "dhuhr" to "الظهر", "asr" to "العصر",
        "maghrib" to "المغرب", "isha" to "العشاء"
    )
}

class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("adhan", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    fun muted(k: String) = sp.getBoolean("mute_$k", false)
    fun setMuted(k: String, v: Boolean) { sp.edit().putBoolean("mute_$k", v).apply() }

    var adhanFile: String?
        get() = sp.getString("adhan_file", null)
        set(v) { sp.edit().putString("adhan_file", v).apply() }

    var lat: Double?
        get() = sp.getString("lat", null)?.toDoubleOrNull()
        set(v) { sp.edit().putString("lat", v?.toString()).apply() }

    var lng: Double?
        get() = sp.getString("lng", null)?.toDoubleOrNull()
        set(v) { sp.edit().putString("lng", v?.toString()).apply() }

    var method: Int
        get() = sp.getInt("method", 5)
        set(v) { sp.edit().putInt("method", v).apply() }

    var school: Int
        get() = sp.getInt("school", 0)
        set(v) { sp.edit().putInt("school", v).apply() }

    var times: String
        get() = sp.getString("times", "[]") ?: "[]"
        set(v) { sp.edit().putString("times", v).apply() }

    fun timesArray(): JSONArray = try { JSONArray(times) } catch (e: Exception) { JSONArray() }
}
