package com.app.dawa

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.net.Uri
import android.os.*
import androidx.core.app.NotificationCompat

class AdhanService : Service() {
    private var mp: MediaPlayer? = null
    private var wl: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val n = i?.getStringExtra("n") ?: ""
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("adhan") == null)
            nm.createNotificationChannel(NotificationChannel("adhan", "الأذان", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null); enableVibration(false) })
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, AdhanService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val nt = NotificationCompat.Builder(this, "adhan").setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(if (n.isEmpty()) "الأذان" else "حان وقت الصلاة: $n").setContentText("اضغط إيقاف لإسكات الأذان")
            .setContentIntent(open).setOngoing(true).setCategory(NotificationCompat.CATEGORY_ALARM)
            .addAction(0, "إيقاف", stop).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2001, nt, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(2001, nt)

        wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dawa:adhan").apply { acquire(8 * 60_000L) }
        play()
        handler.postDelayed({ stopSelf() }, 7 * 60_000L) // safety stop
        return START_NOT_STICKY
    }

    private fun play() {
        try {
            val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 26)
                am.requestAudioFocus(AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT).setAudioAttributes(attrs).build())
            val file = AdhanStore.audio(this)
            mp = MediaPlayer().apply {
                setAudioAttributes(attrs)
                if (file != null) setDataSource(file.absolutePath)
                else setDataSource(this@AdhanService, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, _, _ -> stopSelf(); true }
                prepare(); start()
            }
        } catch (e: Exception) { stopSelf() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { mp?.stop() } catch (_: Exception) {}
        mp?.release(); mp = null
        try { if (wl?.isHeld == true) wl?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
