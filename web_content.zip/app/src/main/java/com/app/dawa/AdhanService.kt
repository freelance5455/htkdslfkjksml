package com.app.dawa

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File
import kotlin.concurrent.thread

class AdhanService : Service() {
    companion object {
        const val ACTION_PLAY = "com.app.dawa.PLAY"
        const val ACTION_TEST = "com.app.dawa.TEST"
        const val ACTION_STOP = "com.app.dawa.STOP"
        private const val CH = "adhan_play"
        private const val NID = 77
    }

    private var mp: MediaPlayer? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_PLAY
        if (action == ACTION_STOP) { stopAll(); return START_NOT_STICKY }

        val key = intent?.getStringExtra("k") ?: "test"
        val title = if (action == ACTION_TEST) "تجربة الأذان"
        else "حان الآن موعد أذان ${Prayers.names[key] ?: ""}"

        try {
            val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            ServiceCompat.startForeground(this, NID, buildNotification(title), type)
        } catch (e: Exception) {
            // لو النظام منع الخدمة، نكمل بدون إشعار بدل ما نفشل
        }

        if (action == ACTION_PLAY) {
            AdhanScheduler.scheduleNext(this)
            thread {
                val p = Prefs(this)
                if (TimesRefresher.needsRefresh(p)) TimesRefresher.refresh(this)
            }
        }
        play()
        return START_NOT_STICKY
    }

    private fun buildNotification(title: String): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "الأذان", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, AdhanService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(title)
            .setContentText("اضغط إيقاف لو عايز تسكّت الأذان")
            .setContentIntent(open)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "إيقاف", stop)
            .build()
    }

    private fun play() {
        releasePlayer()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dawa:adhan").apply { acquire(6 * 60_000L) }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        @Suppress("DEPRECATION")
        am.requestAudioFocus(null, AudioManager.STREAM_ALARM, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
        try {
            val m = MediaPlayer()
            mp = m
            m.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            val name = Prefs(this).adhanFile
            val f = if (name != null) File(File(filesDir, "dl"), name) else null
            if (f != null && f.exists() && f.length() > 1024) {
                m.setDataSource(f.absolutePath)
            } else {
                // مفيش أذان محمّل: نشغّل نغمة المنبه الافتراضية عشان التنبيه ما يفوتش
                m.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            }
            m.setOnPreparedListener { it.start() }
            m.setOnCompletionListener { stopAll() }
            m.setOnErrorListener { _, _, _ -> stopAll(); true }
            m.prepareAsync()
        } catch (e: Exception) {
            stopAll()
        }
    }

    private fun releasePlayer() {
        try { mp?.stop() } catch (_: Exception) {}
        try { mp?.release() } catch (_: Exception) {}
        mp = null
    }

    private fun stopAll() {
        releasePlayer()
        try { if (wl?.isHeld == true) wl?.release() } catch (_: Exception) {}
        @Suppress("DEPRECATION")
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocus(null)
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        releasePlayer()
        try { if (wl?.isHeld == true) wl?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
