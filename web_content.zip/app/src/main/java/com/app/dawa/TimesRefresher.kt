package com.app.dawa

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.TimeZone

object TimesRefresher {
    private val api = mapOf(
        "fajr" to "Fajr", "dhuhr" to "Dhuhr", "asr" to "Asr",
        "maghrib" to "Maghrib", "isha" to "Isha"
    )

    fun needsRefresh(p: Prefs): Boolean {
        val now = System.currentTimeMillis()
        val arr = p.timesArray()
        var future = 0
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).getLong("t") > now) future++
        return future < 10
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "DawaAdhan/2.0")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /** يحمّل مواقيت الشهر الحالي والجاي من Aladhan ويخزنها ويجدول الأذان. */
    fun refresh(ctx: Context): Boolean {
        val p = Prefs(ctx)
        val lat = p.lat ?: return false
        val lng = p.lng ?: return false
        return try {
            val now = System.currentTimeMillis()
            val out = JSONArray()
            val cal = Calendar.getInstance()
            for (off in 0..1) {
                val y = cal.get(Calendar.YEAR)
                val m = cal.get(Calendar.MONTH) + 1
                val url = "https://api.aladhan.com/v1/calendar/$y/$m?latitude=$lat&longitude=$lng" +
                    "&method=${p.method}&school=${p.school}"
                val data = JSONObject(get(url)).getJSONArray("data")
                for (i in 0 until data.length()) {
                    val day = data.getJSONObject(i)
                    val tz = TimeZone.getTimeZone(day.getJSONObject("meta").getString("timezone"))
                    val ds = day.getJSONObject("date").getJSONObject("gregorian").getString("date")
                    val dp = ds.split("-")
                    val timings = day.getJSONObject("timings")
                    for ((k, name) in api) {
                        val hm = timings.getString(name).trim().substring(0, 5).split(":")
                        val c = Calendar.getInstance(tz)
                        c.clear()
                        c.set(dp[2].toInt(), dp[1].toInt() - 1, dp[0].toInt(), hm[0].toInt(), hm[1].toInt(), 0)
                        val t = c.timeInMillis
                        if (t > now - 3600_000L) out.put(JSONObject().put("k", k).put("t", t))
                    }
                }
                cal.add(Calendar.MONTH, 1)
            }
            if (out.length() > 0) {
                p.times = out.toString()
                AdhanScheduler.scheduleNext(ctx)
                true
            } else false
        } catch (e: Exception) {
            false
        }
    }
}
