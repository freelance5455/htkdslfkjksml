package com.app.dawa

import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class AdhanBridge(private val act: MainActivity) {

    private fun dir() = File(act.filesDir, "dl").apply { mkdirs() }

    @JavascriptInterface
    fun getState(): String {
        val p = Prefs(act)
        val o = JSONObject()
        o.put("enabled", p.enabled)
        val m = JSONObject(); Prayers.keys.forEach { m.put(it, p.muted(it)) }
        o.put("muted", m)
        o.put("hasLocation", p.lat != null)
        o.put("method", p.method)
        o.put("adhan", p.adhanFile ?: "")
        val pm = act.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        o.put("batteryOk", pm.isIgnoringBatteryOptimizations(act.packageName))
        o.put("notif", NotificationManagerCompat.from(act).areNotificationsEnabled())
        val now = System.currentTimeMillis()
        val all = p.timesArray()
        val list = ArrayList<JSONObject>()
        for (i in 0 until all.length()) { val x = all.getJSONObject(i); if (x.getLong("t") > now) list.add(x) }
        list.sortBy { it.getLong("t") }
        val up = JSONArray(); list.take(5).forEach { up.put(it) }
        o.put("times", up)
        val files = JSONArray()
        (dir().listFiles() ?: emptyArray()).filter { it.name.endsWith(".mp3") }
            .sortedBy { it.name }.forEach {
                files.put(JSONObject().put("name", it.name).put("size", it.length()))
            }
        o.put("files", files)
        return o.toString()
    }

    @JavascriptInterface
    fun configure(lat: Double, lng: Double, method: Int, school: Int) {
        val p = Prefs(act)
        p.lat = lat; p.lng = lng; p.method = method; p.school = school
        thread {
            TimesRefresher.refresh(act)
            act.js("window.__adhanState&&window.__adhanState()")
        }
    }

    @JavascriptInterface
    fun setMethod(method: Int, school: Int) {
        val p = Prefs(act)
        p.method = method; p.school = school
        if (p.lat != null) thread { TimesRefresher.refresh(act); act.js("window.__adhanState&&window.__adhanState()") }
    }

    @JavascriptInterface
    fun setEnabled(v: Boolean) { Prefs(act).enabled = v; AdhanScheduler.scheduleNext(act) }

    @JavascriptInterface
    fun setMuted(prayer: String, v: Boolean) {
        if (prayer !in Prayers.keys) return
        Prefs(act).setMuted(prayer, v)
        AdhanScheduler.scheduleNext(act)
    }

    @JavascriptInterface
    fun useAdhan(name: String) {
        if (File(dir(), name).exists()) Prefs(act).adhanFile = name
    }

    @JavascriptInterface
    fun deleteFile(name: String) {
        if (!name.matches(Regex("[A-Za-z0-9_.-]{1,80}\\.mp3"))) return
        File(dir(), name).delete()
        val p = Prefs(act)
        if (p.adhanFile == name) p.adhanFile = null
    }

    @JavascriptInterface
    fun pickAdhanFile() { act.runOnUiThread { act.pickAudio.launch(arrayOf("audio/*")) } }

    @JavascriptInterface
    fun test() {
        ContextCompat.startForegroundService(
            act, Intent(act, AdhanService::class.java).setAction(AdhanService.ACTION_TEST)
        )
    }

    @JavascriptInterface
    fun stopAdhan() {
        act.startService(Intent(act, AdhanService::class.java).setAction(AdhanService.ACTION_STOP))
    }

    @JavascriptInterface
    fun openBatterySettings() {
        act.runOnUiThread {
            try {
                act.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:${act.packageName}"))
                )
            } catch (e: Exception) {
                try { act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {}
            }
        }
    }

    @JavascriptInterface
    fun openNotifSettings() {
        act.runOnUiThread {
            try {
                act.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)
                )
            } catch (_: Exception) {}
        }
    }

    @JavascriptInterface
    fun download(url: String, name: String) {
        if (!name.matches(Regex("[A-Za-z0-9_.-]{1,80}\\.mp3")) || !url.startsWith("https://")) {
            act.js("window.__adhanDl&&window.__adhanDl('$name',0,'error')"); return
        }
        thread {
            val tmp = File(dir(), "$name.part")
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 20000; c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "Mozilla/5.0")
                val total = c.contentLengthLong
                var last = -1
                c.inputStream.use { inp ->
                    tmp.outputStream().use { out ->
                        val buf = ByteArray(32768); var read = 0L
                        while (true) {
                            val n = inp.read(buf); if (n < 0) break
                            out.write(buf, 0, n); read += n
                            if (total > 0) {
                                val pct = (read * 100 / total).toInt()
                                if (pct != last && pct % 4 == 0) {
                                    last = pct
                                    act.js("window.__adhanDl&&window.__adhanDl('$name',$pct,'prog')")
                                }
                            }
                        }
                    }
                }
                if (tmp.length() < 1024) throw IOException("small")
                val f = File(dir(), name); if (f.exists()) f.delete()
                tmp.renameTo(f)
                act.js("window.__adhanDl&&window.__adhanDl('$name',100,'done')")
            } catch (e: Exception) {
                tmp.delete()
                act.js("window.__adhanDl&&window.__adhanDl('$name',0,'error')")
            }
        }
    }
}
