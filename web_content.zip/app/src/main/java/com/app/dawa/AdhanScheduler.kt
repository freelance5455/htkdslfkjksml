package com.app.dawa

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object AdhanScheduler {
    const val ACTION_FIRE = "com.app.dawa.ADHAN_FIRE"

    /** Schedules ONLY the next enabled prayer. The receiver chains to the following one when it fires. */
    fun scheduleNext(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        val next = AdhanStore.times(c).filter { it.third > now + 1000 && AdhanStore.mode(c, it.first) != "off" }
            .minByOrNull { it.third }
        val pi = pending(c, next?.first ?: "", next?.second ?: "", next?.third ?: 0L)
        if (next == null) { am.cancel(pi); return }
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        // setAlarmClock: exact, fires in Doze, not delayed by battery savers, needs no special permission.
        am.setAlarmClock(AlarmManager.AlarmClockInfo(next.third, show), pi)
    }

    private fun pending(c: Context, k: String, n: String, t: Long): PendingIntent {
        val i = Intent(c, AdhanReceiver::class.java).setAction(ACTION_FIRE)
            .putExtra("k", k).putExtra("n", n).putExtra("t", t)
        return PendingIntent.getBroadcast(c, 1001, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }
}
