package com.app.dawa

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AdhanScheduler {
    private const val REQ = 4711

    private fun alarmIntent(ctx: Context, key: String): PendingIntent {
        val i = Intent(ctx, AdhanService::class.java)
            .setAction(AdhanService.ACTION_PLAY)
            .putExtra("k", key)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return if (Build.VERSION.SDK_INT >= 26)
            PendingIntent.getForegroundService(ctx, REQ, i, flags)
        else
            PendingIntent.getService(ctx, REQ, i, flags)
    }

    /** أقرب صلاة جاية مش مكتومة. */
    fun next(p: Prefs, after: Long): Pair<String, Long>? {
        val arr = p.timesArray()
        var best: Pair<String, Long>? = null
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val k = o.getString("k")
            val t = o.getLong("t")
            if (t > after && !p.muted(k) && (best == null || t < best.second)) best = k to t
        }
        return best
    }

    /** يجدول أقرب أذان بمنبه دقيق (setAlarmClock) بيصحّي التليفون حتى في Doze. */
    fun scheduleNext(ctx: Context) {
        val p = Prefs(ctx)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmIntent(ctx, "x"))
        if (!p.enabled) return
        val n = next(p, System.currentTimeMillis() + 1000) ?: return
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(n.second, show), alarmIntent(ctx, n.first))
    }
}
