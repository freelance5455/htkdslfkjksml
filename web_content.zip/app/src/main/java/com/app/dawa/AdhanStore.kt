package com.app.dawa

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persists the prayer schedule + per-prayer modes so alarms survive reboot/app kill. */
object AdhanStore {
    private fun p(c: Context) = c.getSharedPreferences("adhan", Context.MODE_PRIVATE)

    fun save(c: Context, json: String) { p(c).edit().putString("data", json).apply() }

    fun times(c: Context): List<Triple<String, String, Long>> {
        val o = try { JSONObject(p(c).getString("data", "{}")!!) } catch (e: Exception) { return emptyList() }
        val a = o.optJSONArray("times") ?: JSONArray()
        return (0 until a.length()).map { val x = a.getJSONObject(it); Triple(x.getString("k"), x.optString("n"), x.getLong("t")) }
    }

    /** "on" | "silent" | "off" */
    fun mode(c: Context, k: String): String = try {
        JSONObject(p(c).getString("data", "{}")!!).optJSONObject("modes")?.optString(k, "on") ?: "on"
    } catch (e: Exception) { "on" }

    fun dir(c: Context) = File(c.filesDir, "adhan").apply { mkdirs() }
    fun audio(c: Context): File? = dir(c).listFiles()?.firstOrNull { it.isFile && it.length() > 1000 && !it.name.endsWith(".part") }
}
