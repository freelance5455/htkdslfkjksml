package com.app.dawa

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {
    lateinit var web: WebView
    private var geoCb: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private var permReq: PermissionRequest? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        web = WebView(this)
        setContentView(web)
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setGeolocationEnabled(true)
        }
        web.addJavascriptInterface(Bridge(this), "DawaNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) cb.invoke(o, true, false)
                else { geoCb = cb; geoOrigin = o; ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 11) }
            }
            override fun onPermissionRequest(r: PermissionRequest) {
                if (r.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    permReq = r; ActivityCompat.requestPermissions(this@MainActivity, arrayOf(Manifest.permission.RECORD_AUDIO), 12)
                } else r.grant(r.resources)
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() } }
        })
        if (s == null) web.loadUrl("https://appassets.androidplatform.net/assets/web/index.html") else web.restoreState(s)
        askAdhanPermissions(firstRun = true)
        AdhanScheduler.scheduleNext(this)
    }

    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); web.saveState(o) }

    fun js(type: String, payload: String) = runOnUiThread {
        web.evaluateJavascript("window.onDawaNative&&window.onDawaNative('$type','$payload')", null)
    }

    /** Notifications + (once) battery-optimisation exemption so the OS never kills the schedule. */
    fun askAdhanPermissions(firstRun: Boolean = false) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 13); return
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && (!firstRun || !prefs.getBoolean("battAsked", false))) {
            prefs.edit().putBoolean("battAsked", true).apply()
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) {} }
        }
    }

    fun pickAudio() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("audio/*"), 21)
    }

    @Deprecated("simple")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 21 && res == Activity.RESULT_OK && d?.data != null) Thread {
            try {
                AdhanStore.dir(this).listFiles()?.forEach { it.delete() }
                contentResolver.openInputStream(d.data!!)!!.use { i -> File(AdhanStore.dir(this), "adhan.mp3").outputStream().use { i.copyTo(it) } }
                js("picked", "ok")
            } catch (_: Exception) { js("dl", "err") }
        }.start()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(rc, p, g)
        val ok = g.isNotEmpty() && g[0] == PackageManager.PERMISSION_GRANTED
        when (rc) {
            11 -> { geoCb?.invoke(geoOrigin, ok, false); geoCb = null }
            12 -> { permReq?.let { if (ok) it.grant(it.resources) else it.deny() }; permReq = null }
            13 -> askAdhanPermissions(firstRun = true)
        }
    }

    override fun onResume() { super.onResume(); AdhanScheduler.scheduleNext(this) }
}
