package com.app.dawa

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlin.concurrent.thread

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        AdhanScheduler.scheduleNext(app)
        val pending = goAsync()
        thread {
            try {
                if (TimesRefresher.needsRefresh(Prefs(app))) TimesRefresher.refresh(app)
            } finally {
                pending.finish()
            }
        }
    }
}
