package com.app.dawa

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Exposed to the page as window.DawaNative */
class Bridge(private val a: MainActivity) {

    @JavascriptInterface fun sync(json: String) { AdhanStore.save(a, json); AdhanScheduler.scheduleNext(a) }

    @JavascriptInterface fun status(): String {
        val pm = a.getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        return JSONObject()
            .put("audio", AdhanStore.audio(a)?.name ?: "")
            .put("notif", NotificationManagerCompat.from(a).areNotificationsEnabled())
            .put("battery", pm.isIgnoringBatteryOptimizations(a.packageName)).toString()
    }

    @JavascriptInterface fun testAdhan() {
        ContextCompat.startForegroundService(a, Intent(a, AdhanService::class.java).putExtra("n", "تجربة"))
    }

    @JavascriptInterface fun stopAdhan() { a.startService(Intent(a, AdhanService::class.java).setAction("STOP")) }

    @JavascriptInterface fun requestPermissions() { a.runOnUiThread { a.askAdhanPermissions() } }

    @JavascriptInterface fun pickAdhan() { a.runOnUiThread { a.pickAudio() } }

    @JavascriptInterface fun clearAdhan() { AdhanStore.dir(a).listFiles()?.forEach { it.delete() } }

    /** Downloads an mp3 to private storage so the adhan plays with no internet. */
    @JavascriptInterface fun downloadAdhan(url: String) {
        Thread {
            val tmp = File(AdhanStore.dir(a), "adhan.mp3.part")
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
                val total = c.contentLengthLong
                var got = 0L; var last = -1
                c.inputStream.use { ins -> tmp.outputStream().use { out ->
                    val buf = ByteArray(16384)
                    while (true) {
                        val r = ins.read(buf); if (r < 0) break
                        out.write(buf, 0, r); got += r
                        if (total > 0) { val p = (got * 100 / total).toInt(); if (p != last) { last = p; a.js("dl", p.toString()) } }
                    }
                } }
                if (got < 5000) throw Exception("too small")
                AdhanStore.dir(a).listFiles()?.filter { it.name != tmp.name }?.forEach { it.delete() }
                tmp.renameTo(File(AdhanStore.dir(a), "adhan.mp3"))
                a.js("dl", "done")
            } catch (e: Exception) { tmp.delete(); a.js("dl", "err") }
        }.start()
    }
}
