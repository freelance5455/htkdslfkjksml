package com.rizstore.warmate;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return routeUrl(request.getUrl().toString());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return routeUrl(url);
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean routeUrl(String raw) {
        if (raw == null) return true;
        try {
            Uri uri = Uri.parse(raw);
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();

            if (scheme.equals("file") || scheme.equals("about") || scheme.equals("javascript")) {
                return false;
            }

            if (scheme.equals("http") || scheme.equals("https")) {
                String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase();
                if (host.contains("shopee") || host.endsWith("shp.ee")) {
                    openExternal(uri);
                    return true;
                }
                openExternal(uri);
                return true;
            }

            // Shopee app deep link: resolve its navigate_url parameter to a normal HTTPS URL.
            if (scheme.equals("shopeeid")) {
                String target = uri.getQueryParameter("navigate_url");
                if (target != null && !target.isEmpty()) {
                    try { target = URLDecoder.decode(target, StandardCharsets.UTF_8.name()); }
                    catch (Exception ignored) {}
                    if (target.startsWith("http://") || target.startsWith("https://")) {
                        openExternal(Uri.parse(target));
                    } else {
                        Toast.makeText(this, "Tautan Shopee tidak valid.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Link Shopee tidak memiliki alamat tujuan.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            // Handle intent:// links safely; fall back to the browser URL when available.
            if (scheme.equals("intent")) {
                String fallback = uri.getQueryParameter("browser_fallback_url");
                if (fallback != null && (fallback.startsWith("https://") || fallback.startsWith("http://"))) {
                    openExternal(Uri.parse(fallback));
                } else {
                    Toast.makeText(this, "Tidak dapat membuka tautan aplikasi tersebut.", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            Toast.makeText(this, "Jenis link tidak didukung: " + scheme, Toast.LENGTH_SHORT).show();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "Gagal membuka link. Coba salin link produk lagi.", Toast.LENGTH_LONG).show();
            return true;
        }
    }

    private void openExternal(Uri uri) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka link ini.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
