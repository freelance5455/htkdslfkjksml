package com.maannapurna.healthcenter;
import android.app.*;
import android.os.*;
import android.webkit.*;
import android.net.Uri;
import android.content.*;
import android.webkit.WebChromeClient.FileChooserParams;

public class MainActivity extends Activity {
  WebView w;
  ValueCallback<Uri[]> upload;
  @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this);
    w.getSettings().setJavaScriptEnabled(true); w.getSettings().setDomStorageEnabled(true);
    w.getSettings().setAllowFileAccess(true); w.getSettings().setAllowContentAccess(true);
    w.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){
        upload=cb; Intent i=p.createIntent(); try{startActivityForResult(i,1001);}catch(Exception e){upload=null;return false;} return true;
      }
    });
    setContentView(w); w.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==1001&&upload!=null){upload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(c,d));upload=null;}}
  @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
