package com.syllabe.app;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.content.Intent;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private String pendingText = null;
    private float pendingRate = 0.78f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSafeBrowsingEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        WebView.setWebContentsDebuggingEnabled(false);
        webView.addJavascriptInterface(new AndroidTTS(), "AndroidTTS");
        setContentView(webView);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(Locale.FRENCH);
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                        && result != TextToSpeech.LANG_NOT_SUPPORTED;
                tts.setPitch(1.0f);
                if (ttsReady && pendingText != null) {
                    String text = pendingText;
                    float rate = pendingRate;
                    pendingText = null;
                    speakNow(text, rate);
                }
            }
        });

        webView.loadUrl("file:///android_asset/syllabe/index.html");
    }

    private void speakNow(String text, float rate) {
        if (tts == null || !ttsReady || text == null || text.trim().isEmpty()) return;
        tts.stop();
        tts.setLanguage(Locale.FRENCH);
        tts.setSpeechRate(Math.max(0.55f, Math.min(1.0f, rate)));
        tts.setPitch(1.0f);
        tts.speak(text.trim(), TextToSpeech.QUEUE_FLUSH, null, "syllabe");
    }

    public class AndroidTTS {
        @JavascriptInterface
        public boolean speak(String text, double rate) {
            if (text == null || text.trim().isEmpty()) return false;
            final float safeRate = (float)Math.max(0.55, Math.min(1.0, rate));

            runOnUiThread(() -> {
                if (ttsReady) {
                    speakNow(text, safeRate);
                } else {
                    pendingText = text;
                    pendingRate = safeRate;
                }
            });
            // true signifie que la demande est acceptée; si le moteur démarre
            // quelques instants plus tard, la phrase en attente sera lue.
            return true;
        }

        @JavascriptInterface
        public void stop() {
            runOnUiThread(() -> {
                pendingText = null;
                if (tts != null) tts.stop();
            });
        }

        @JavascriptInterface
        public boolean isReady() {
            return ttsReady;
        }
    }


    /**
     * Ouvre les réglages Android de synthèse vocale.
     * Il n'existe pas de permission runtime "IA" pour le TTS :
     * Android gère le moteur et ses données vocales via ses réglages.
     */
    @JavascriptInterface
    public void openTtsSettings() {
        runOnUiThread(() -> {
            try {
                startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                } catch (Exception ignored) {}
            }
        });
    }

    @JavascriptInterface
    public boolean isFrenchVoiceReady() {
        return ttsReady;
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
