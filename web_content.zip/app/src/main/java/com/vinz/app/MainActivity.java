package com.vinz.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.widget.Toast;
import android.content.pm.PackageManager;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private WebView web;
    private static final int REQUEST_CODE = 7319;

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
        (requestCode, grantResult) -> {
            if (requestCode == REQUEST_CODE) {
                String state = grantResult == PackageManager.PERMISSION_GRANTED
                    ? "GRANTED" : "DENIED";
                sendStatus(state, "Hasil permintaan izin Shizuku: " + state);
            }
        };

    private final Shizuku.OnBinderReceivedListener binderListener =
        this::refreshStatus;

    private final Shizuku.OnBinderDeadListener deadListener =
        () -> sendStatus("DISCONNECTED", "Service Shizuku terputus.");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new VinzBridge(), "VinzNative");
        setContentView(web);

        Shizuku.addRequestPermissionResultListener(permissionListener);
        Shizuku.addBinderReceivedListenerSticky(binderListener);
        Shizuku.addBinderDeadListener(deadListener);

        web.loadUrl("file:///android_asset/index.html");
    }

    private void sendStatus(String code, String message) {
        runOnUiThread(() -> {
            if (web != null) {
                String c = JSONObjectQuote.quote(code);
                String m = JSONObjectQuote.quote(message);
                web.evaluateJavascript(
                    "window.onNativeStatus && window.onNativeStatus(" + c + "," + m + ")", null);
            }
        });
    }

    private void refreshStatus() {
        try {
            if (!Shizuku.pingBinder()) {
                sendStatus("UNAVAILABLE", "Service Shizuku belum aktif.");
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                sendStatus("GRANTED", "Shizuku aktif dan izin VINZ sudah diberikan.");
            } else {
                sendStatus("NEED_PERMISSION", "Shizuku aktif, tetapi VINZ belum diberi izin.");
            }
        } catch (Exception e) {
            sendStatus("ERROR", e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    public class VinzBridge {
        @JavascriptInterface public void checkShizuku() {
            refreshStatus();
        }

        @JavascriptInterface public void requestShizuku() {
            runOnUiThread(() -> {
                try {
                    if (!Shizuku.pingBinder()) {
                        sendStatus("UNAVAILABLE", "Jalankan Shizuku terlebih dahulu.");
                        return;
                    }
                    if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                        sendStatus("GRANTED", "Izin Shizuku VINZ sudah diberikan.");
                        return;
                    }
                    Shizuku.requestPermission(REQUEST_CODE);
                    sendStatus("REQUESTING", "Permintaan izin dikirim. Pilih Allow pada dialog Shizuku.");
                } catch (Exception e) {
                    sendStatus("ERROR", e.getClass().getSimpleName() + ": " + e.getMessage());
                }
            });
        }

        @JavascriptInterface public boolean hasShizukuPermission() {
            try {
                return Shizuku.pingBinder()
                    && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public void openFreeFire() {
            runOnUiThread(() -> {
                String[] ids = {"com.dts.freefiremax", "com.dts.freefireth"};
                for (String id : ids) {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(id);
                    if (launch != null) {
                        startActivity(launch);
                        return;
                    }
                }
                Toast.makeText(MainActivity.this, "Free Fire tidak ditemukan.", Toast.LENGTH_LONG).show();
            });
        }
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        Shizuku.removeBinderReceivedListener(binderListener);
        Shizuku.removeBinderDeadListener(deadListener);
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // Safely quote strings before passing them to JavaScript.
    static class JSONObjectQuote {
        static String quote(String s) {
            if (s == null) return "null";
            return """ + s.replace("\\", "\\\\")
                .replace(""", "\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r") + """;
        }
    }
}
