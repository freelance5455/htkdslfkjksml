package com.lanafalcon.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.net.Uri;

public class MainActivity extends Activity {
  private static final String PREFS="lana_mobile";
  private static final String KEY_URL="dashboard_url";
  private WebView webView;
  private LinearLayout root;
  private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
  @Override public void onCreate(Bundle state){ super.onCreate(state); getWindow().setStatusBarColor(Color.rgb(9,17,31)); getWindow().setNavigationBarColor(Color.rgb(7,13,24));
    String saved=getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY_URL,"");
    if(saved.isEmpty()) showConnectScreen(""); else loadDashboard(saved);
  }
  private void showConnectScreen(String initial){
    root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(dp(24),dp(24),dp(24),dp(24)); root.setBackgroundColor(Color.rgb(7,13,24));
    TextView title=new TextView(this); title.setText("LANA FALCON"); title.setTextColor(Color.rgb(229,184,92)); title.setTextSize(26); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,dp(54)));
    TextView sub=new TextView(this); sub.setText("R60 · لوحة الجوال
اتصل بعنوان لوحة التحكم الآمن على جهاز المضيف"); sub.setTextColor(Color.WHITE); sub.setTextSize(16); sub.setGravity(Gravity.CENTER); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(84)));
    EditText url=new EditText(this); url.setSingleLine(true); url.setTextColor(Color.WHITE); url.setHintTextColor(Color.LTGRAY); url.setHint("https://your-secure-dashboard.example"); url.setText(initial); url.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI); url.setSelectAllOnFocus(true); root.addView(url,new LinearLayout.LayoutParams(-1,dp(54)));
    TextView note=new TextView(this); note.setText("يلزم عنوان HTTPS قابل للوصول من الهاتف. لا تدخل كلمات مرور الوسيط هنا. وضع التداول الحقيقي غير مفعّل بواسطة هذا الغلاف."); note.setTextColor(Color.rgb(170,185,205)); note.setTextSize(13); note.setGravity(Gravity.CENTER); LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(88)); np.topMargin=dp(12); root.addView(note,np);
    Button connect=new Button(this); connect.setText("اتصال بلوحة التحكم"); connect.setOnClickListener(v->{ String s=url.getText().toString().trim(); if(!validHttps(s)){ Toast.makeText(this,"أدخل رابط HTTPS صحيحًا",Toast.LENGTH_LONG).show(); return; } getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString(KEY_URL,s).apply(); ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(url.getWindowToken(),0); loadDashboard(s); }); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(52)); bp.topMargin=dp(14); root.addView(connect,bp);
    setContentView(root);
  }
  private boolean validHttps(String s){ try { Uri u=Uri.parse(s); return "https".equalsIgnoreCase(u.getScheme()) && u.getHost()!=null && u.getUserInfo()==null; } catch(Exception e){ return false; } }
  private void loadDashboard(String url){
    if(!validHttps(url)){ getSharedPreferences(PREFS,MODE_PRIVATE).edit().remove(KEY_URL).apply(); showConnectScreen(""); return; }
    webView=new WebView(this); webView.setBackgroundColor(Color.rgb(7,13,24)); WebSettings ws=webView.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(false); ws.setAllowContentAccess(false); ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); ws.setSupportMultipleWindows(false);
    webView.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){ Uri u=req.getUrl(); if("https".equalsIgnoreCase(u.getScheme()) && u.getHost()!=null) return false; Toast.makeText(MainActivity.this,"تم منع رابط غير آمن",Toast.LENGTH_SHORT).show(); return true; }});
    setContentView(webView); webView.loadUrl(url);
  }
  @Override public void onBackPressed(){ if(webView!=null && webView.canGoBack()) webView.goBack(); else showConnectScreen(getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY_URL,"")); }
}
