package com.beeblox.app

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.*
import kotlin.math.max

class MainActivity : Activity() {

    companion object {
        private const val ACCESS_KEY = "Bee-Blox26"
        private const val ACCESS_DURATION_MS = 24L * 60L * 60L * 1000L
        private const val DISCORD_INVITE = "https://discord.gg/bee-blox"
        private const val ROBLOX_WEB = "https://www.roblox.com/"
    }

    private val bg = Color.rgb(6, 8, 9)
    private val panel = Color.rgb(15, 19, 22)
    private val panel2 = Color.rgb(22, 28, 32)
    private val white = Color.WHITE
    private val muted = Color.rgb(165, 173, 180)
    private val green = Color.rgb(66, 220, 115)
    private val red = Color.rgb(255, 82, 82)

    private val prefs by lazy { getSharedPreferences("bee_blox", MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private lateinit var nav: LinearLayout
    private var current = "home"
    private var timer: CountDownTimer? = null
    private var pulseAnimator: ValueAnimator? = null

    private val tabs = listOf(
        "⌂\nHome" to "home",
        "▣\nLibrary" to "library",
        "🎮\nGames" to "games",
        "✎\nEditor" to "editor",
        "🧰\nTools" to "tools",
        "⚙\nSettings" to "settings"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        route()
    }

    override fun onResume() {
        super.onResume()
        if (!hasAccess()) {
            timer?.cancel()
        }
    }

    override fun onDestroy() {
        timer?.cancel()
        pulseAnimator?.cancel()
        super.onDestroy()
    }

    private fun accent(): Int = when (prefs.getString("accent", "gold")) {
        "amber" -> Color.rgb(255, 158, 46)
        "yellow" -> Color.rgb(255, 228, 72)
        "honey" -> Color.rgb(255, 193, 7)
        else -> Color.rgb(255, 205, 0)
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun compact(): Boolean = prefs.getBoolean("compact", false)

    private fun gapSize(): Int = if (compact()) dp(5) else dp(8)

    private fun hasAccess(): Boolean =
        prefs.getLong("access_until", 0L) > System.currentTimeMillis()

    private fun accessMillis(): Long =
        max(0L, prefs.getLong("access_until", 0L) - System.currentTimeMillis())

    private fun remaining(): String {
        val ms = accessMillis()
        val d = ms / 86_400_000L
        val h = (ms % 86_400_000L) / 3_600_000L
        val m = (ms % 3_600_000L) / 60_000L
        val s = (ms % 60_000L) / 1_000L
        return if (d > 0) "${d}d ${h}h ${m}m" else "%02dh %02dm %02ds".format(h, m, s)
    }

    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
        val p = if (compact()) dp(10) else dp(14)
        setPadding(p, if (compact()) dp(12) else dp(18), p, dp(7))
    }

    private fun scrollWrap(child: View): ScrollView =
        ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            addView(child)
        }

    private fun header(name: String, subtitle: String = ""): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), 0, dp(2), dp(8))
            addView(TextView(this@MainActivity).apply {
                text = name
                textSize = 22f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(white)
            }, LinearLayout.LayoutParams(0, dp(48), 1f))
            if (subtitle.isNotEmpty()) {
                addView(TextView(this@MainActivity).apply {
                    text = subtitle
                    textSize = 11f
                    setTextColor(accent())
                    gravity = Gravity.CENTER_VERTICAL
                })
            }
        }

    private fun button(label: String, dark: Boolean = false, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 13.5f
            typeface = Typeface.DEFAULT_BOLD
            setAllCaps(false)
            minHeight = 0
            minimumHeight = 0
            setTextColor(if (dark) white else Color.BLACK)
            background = getDrawable(if (dark) R.drawable.bg_dark_button else R.drawable.bg_button)
            setPadding(dp(9), dp(2), dp(9), dp(2))
            setOnClickListener {
                haptic()
                action()
            }
            setOnTouchListener { v, event ->
                if (!prefs.getBoolean("animations", true)) return@setOnTouchListener false
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                }
                false
            }
        }

    private fun edit(hint: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText =
        EditText(this).apply {
            this.hint = hint
            hintTextColor = Color.rgb(95, 104, 110)
            setTextColor(white)
            inputType = type
            setSingleLine(type and InputType.TYPE_TEXT_FLAG_MULTI_LINE == 0)
            setPadding(dp(14), 0, dp(14), 0)
            background = getDrawable(R.drawable.bg_card)
        }

    private fun haptic() {
        if (!prefs.getBoolean("haptics", true)) return
        try {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(
                    android.os.VibrationEffect.createOneShot(
                        16, android.os.VibrationEffect.DEFAULT_AMPLITUDE
                    )
                )
            }
        } catch (_: Exception) {}
    }

    private fun entrance(parent: ViewGroup) {
        if (!prefs.getBoolean("animations", true)) return
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            child.alpha = 0f
            child.translationY = dp(10).toFloat()
            child.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay((i * 30L).coerceAtMost(260L))
                .setDuration(260)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    private fun pulse(view: View) {
        pulseAnimator?.cancel()
        if (!prefs.getBoolean("animations", true)) return
        pulseAnimator = ValueAnimator.ofFloat(0.96f, 1.02f).apply {
            duration = 1200
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                val s = it.animatedValue as Float
                view.scaleX = s
                view.scaleY = s
            }
            start()
        }
    }

    private fun clearPage(title: String, sub: String = "") {
        timer?.cancel()
        pulseAnimator?.cancel()
        content.removeAllViews()
        content.addView(header(title, sub))
    }

    private fun route() {
        if (!hasAccess()) showKeyGate() else showApp()
    }

    private fun showKeyGate() {
        val r = root().apply { gravity = Gravity.CENTER_HORIZONTAL }
        val scroll = scrollWrap(r)

        val bee = TextView(this).apply {
            text = "🐝"
            textSize = 60f
            gravity = Gravity.CENTER
        }
        r.addView(bee)
        pulse(bee)

        r.addView(TextView(this).apply {
            text = "24-HOUR ACCESS"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent())
            gravity = Gravity.CENTER
        })

        val status = TextView(this).apply {
            text = "Sign in → get a key → activate → 24 hours"
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(17))
        }
        r.addView(status)

        val key = edit("Enter Bee-Blox key...")
        key.setSingleLine(true)
        r.addView(key, LinearLayout.LayoutParams(-1, dp(56)))

        r.addView(button("🔑  ACTIVATE KEY") {
            val input = key.text.toString().trim()
            if (input == ACCESS_KEY) {
                val until = System.currentTimeMillis() + ACCESS_DURATION_MS
                prefs.edit()
                    .putLong("access_until", until)
                    .putInt("activations", prefs.getInt("activations", 0) + 1)
                    .apply()
                toast("24-hour access activated.")
                showApp()
            } else {
                toast("Invalid Bee-Blox key.")
            }
        }, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = gapSize() })

        r.addView(button("🐝  GET KEY / CODE ON DISCORD", true) {
            openDiscord()
        }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = gapSize() })

        r.addView(TextView(this).apply {
            text = "https://discord.gg/bee-blox"
            textSize = 12f
            setTextColor(accent())
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, dp(4))
            setOnClickListener { openDiscord() }
        })

        val rule = card(
            "🔑  KEY RULE",
            "The key itself never expires. A successful activation grants 24 hours of access. When the timer reaches zero, enter the current key again.",
            null
        )
        r.addView(rule)

        r.addView(card(
            "✅  CURRENT BUILD",
            "Key format is case-sensitive. Current demo/build key: Bee-Blox26",
            "READY"
        ))

        setContentView(scroll)
        entrance(r)
    }

    private fun showApp() {
        val r = root()
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        r.addView(scrollWrap(content), LinearLayout.LayoutParams(-1, 0, 1f))

        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(panel)
            setPadding(0, dp(3), 0, 0)
        }
        r.addView(nav, LinearLayout.LayoutParams(-1, dp(66)))

        setContentView(r)
        buildNav()
        showHome()
    }

    private fun buildNav() {
        nav.removeAllViews()
        tabs.forEach { (label, id) ->
            nav.addView(TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 10.5f
                setTextColor(if (current == id) accent() else muted)
                setPadding(0, dp(3), 0, 0)
                setOnClickListener {
                    current = id
                    buildNav()
                    when (id) {
                        "home" -> showHome()
                        "library" -> showLibrary()
                        "games" -> showGames()
                        "editor" -> showEditor()
                        "tools" -> showTools()
                        "settings" -> showSettings()
                    }
                }
            }, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun startAccessTimer(label: TextView? = null) {
        timer?.cancel()
        if (!hasAccess()) {
            route()
            return
        }
        timer = object : CountDownTimer(accessMillis(), 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                if (label != null) label.text = "⏱️ ${remaining()} remaining"
            }
            override fun onFinish() {
                prefs.edit().remove("access_until").apply()
                toast("24-hour access has ended. Enter the key again.")
                showKeyGate()
            }
        }.start()
    }

    private fun showHome() {
        current = "home"
        buildNav()
        clearPage("🐝 Bee-Blox", "24H ACCESS")

        val timerLabel = TextView(this).apply {
            text = "⏱️ ${remaining()} remaining"
            textSize = 12f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(4))
        }

        val access = card(
            "🔑  ACCESS ACTIVE",
            "Full Bee-Blox access is unlocked.\nActivations: ${prefs.getInt("activations", 0)}",
            "ACTIVE"
        )
        (access as ViewGroup).addView(timerLabel)
        content.addView(access)
        startAccessTimer(timerLabel)

        val welcome = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.bg_card)
            setPadding(dp(16), dp(15), dp(16), dp(15))
            addView(TextView(this@MainActivity).apply {
                text = "Welcome to Bee-Blox! 🐝"
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(white)
            })
            addView(TextView(this@MainActivity).apply {
                text = "Your bee-themed Roblox companion is ready."
                textSize = 12.5f
                setTextColor(muted)
                setPadding(0, dp(4), 0, 0)
            })
        }
        content.addView(welcome, LinearLayout.LayoutParams(-1, -2).apply { topMargin = gapSize() })

        content.addView(button("🎮  PLAY ROBLOX", false) {
            prefs.edit().putInt("launches", prefs.getInt("launches", 0) + 1).apply()
            openRoblox()
        }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = gapSize() })

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stat("🎮", "Launches", prefs.getInt("launches", 0).toString(), stats)
        stat("🔑", "Activations", prefs.getInt("activations", 0).toString(), stats)
        stat("📝", "Notes", prefs.getString("editor", "").orEmpty().length.toString(), stats)
        content.addView(stats, LinearLayout.LayoutParams(-1, dp(84)))

        content.addView(section("QUICK ACTIONS"))
        addAction("📚  Library", "Safe references, search and favorites", ::showLibrary)
        addAction("🎮  Games", "Official Roblox experience shortcuts", ::showGames)
        addAction("✎  Editor", "Write, save and copy local notes", ::showEditor)
        addAction("🧰  Tools", "Timers, stats and utilities", ::showTools)

        content.addView(section("UPDATES"))
        content.addView(card(
            "✨  BEE-BLOX ULTIMATE",
            "Expanded mobile navigation, animated interactions, better timers, fixed navigation, improved search and more settings.",
            "NEW"
        ))
        content.addView(card(
            "🛡️  SAFE COMPANION",
            "Bee-Blox launches the official Roblox app or Roblox website. It does not inject, execute, modify or bypass Roblox security.",
            null
        ))
        content.addView(button("🔄  REFRESH DASHBOARD", true) { showHome() },
            LinearLayout.LayoutParams(-1, dp(49)).apply { topMargin = gapSize() })

        entrance(content)
    }

    private fun stat(icon: String, name: String, value: String, parent: LinearLayout) {
        parent.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = getDrawable(R.drawable.bg_card)
            addView(TextView(this@MainActivity).apply {
                text = "$icon $value"
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(accent())
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = name
                textSize = 9.5f
                setTextColor(muted)
                gravity = Gravity.CENTER
            })
        }, LinearLayout.LayoutParams(0, dp(78), 1f).apply {
            setMargins(dp(2), dp(6), dp(2), dp(4))
        })
    }

    private fun addAction(title: String, sub: String, action: () -> Unit) {
        content.addView(
            button("$title\n$sub", true, action),
            LinearLayout.LayoutParams(-1, dp(61)).apply { topMargin = gapSize() }
        )
    }

    private fun showLibrary() {
        current = "library"
        buildNav()
        clearPage("▣ Library", "Search • categories • favorites")

        val search = edit("Search library...")
        content.addView(search, LinearLayout.LayoutParams(-1, dp(52)))

        val list = arrayListOf(
            "🍍 Blox Fruits" to "Game notes • routes • tips",
            "🐱 Pet Simulator 99" to "Game notes • pets • tips",
            "🔪 Murder Mystery 2" to "Game notes • maps • tips",
            "⚔️ BedWars" to "Game notes • strategies",
            "🎯 Arsenal" to "Game notes • controls",
            "🏠 Brookhaven" to "Game notes • locations",
            "🐶 Adopt Me!" to "Game notes • pets",
            "🚪 Doors" to "Game notes • walkthrough",
            "🌎 General Roblox Tips" to "Mobile controls • account safety"
        )

        val results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(results)

        fun render(query: String = "") {
            results.removeAllViews()
            val filtered = list.filter { "$it".contains(query.trim(), true) }
            if (filtered.isEmpty()) {
                results.addView(card("🔎 No results", "Try another search term.", null))
            } else {
                filtered.forEach { (name, desc) ->
                    results.addView(card(name, desc, "INFO"))
                    results.addView(button("☆  Favorite   •   Open Reference", true) {
                        toast("$name saved to local favorites.")
                    }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(-2) })
                }
            }
            entrance(results)
        }

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("All", "Popular", "Games", "Utility", "Favorites").forEach { label ->
            chips.addView(button(label, label != "All") {
                when (label) {
                    "All" -> render()
                    "Games", "Popular" -> render()
                    "Utility" -> render("Roblox")
                    "Favorites" -> toast("Favorites are stored locally.")
                }
            }, LinearLayout.LayoutParams(0, dp(45), 1f).apply {
                setMargins(dp(2), gapSize(), dp(2), gapSize())
            })
        }
        content.addView(chips, 2)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                render(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        render()
        entrance(content)
    }

    private fun showGames() {
        current = "games"
        buildNav()
        clearPage("🎮 Games", "Official Roblox experience shortcuts")

        content.addView(card(
            "🎮  GAME LAUNCHER",
            "These shortcuts open the official Roblox app. Bee-Blox never modifies the client.",
            null
        ))

        val games = listOf(
            "🍍 Blox Fruits", "🐱 Pet Simulator 99", "🔪 Murder Mystery 2",
            "⚔️ BedWars", "🎯 Arsenal", "🏠 Brookhaven", "🐶 Adopt Me!", "🚪 Doors"
        )
        games.forEach { g ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = getDrawable(R.drawable.bg_card)
                setPadding(dp(11), dp(7), dp(7), dp(7))
                addView(TextView(this@MainActivity).apply {
                    text = "$g\nOfficial Roblox shortcut"
                    textSize = 13.5f
                    setTextColor(white)
                }, LinearLayout.LayoutParams(0, dp(58), 1f))
                addView(button("JOIN", false) {
                    prefs.edit().putInt("launches", prefs.getInt("launches", 0) + 1).apply()
                    openRoblox()
                }, LinearLayout.LayoutParams(dp(80), dp(46)))
            }
            content.addView(row, LinearLayout.LayoutParams(-1, dp(68)).apply { topMargin = gapSize() })
        }
        content.addView(button("🌐  OPEN ROBLOX WEBSITE", true) { openWeb() },
            LinearLayout.LayoutParams(-1, dp(51)).apply { topMargin = gapSize() })
        entrance(content)
    }

    private fun showEditor() {
        current = "editor"
        buildNav()
        clearPage("✎ Editor", "Local notes • drafting only")

        val tabsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("EDITOR", "CONSOLE", "SAVED").forEach { label ->
            tabsRow.addView(button(label, label != "EDITOR") {
                when (label) {
                    "EDITOR" -> toast("Editor ready.")
                    "CONSOLE" -> toast("Local preview console — no Roblox execution.")
                    "SAVED" -> toast("Saved locally on this device.")
                }
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                setMargins(dp(2), 0, dp(2), gapSize())
            })
        }
        content.addView(tabsRow)

        val editor = EditText(this).apply {
            hint = "-- Bee-Blox notes\n-- Draft safely here..."
            hintTextColor = Color.rgb(75, 90, 82)
            setTextColor(Color.rgb(85, 230, 135))
            gravity = Gravity.TOP or Gravity.START
            minLines = 13
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = getDrawable(R.drawable.bg_card)
            setText(prefs.getString("editor", ""))
        }
        content.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))

        val count = TextView(this).apply {
            text = editorStats(editor.text.toString())
            textSize = 10.5f
            setTextColor(muted)
            gravity = Gravity.END
            setPadding(0, dp(5), 0, dp(3))
        }
        content.addView(count)

        editor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, countChars: Int) {
                count.text = editorStats(s?.toString().orEmpty())
            }
            override fun afterTextChanged(e: Editable?) {}
        })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("💾 SAVE", false) {
            prefs.edit().putString("editor", editor.text.toString()).apply()
            toast("Saved locally.")
        }, LinearLayout.LayoutParams(0, dp(51), 1f))
        row.addView(button("📋 COPY", true) {
            copyText(editor.text.toString())
        }, LinearLayout.LayoutParams(0, dp(51), 1f))
        row.addView(button("🧹 CLEAR", true) {
            editor.setText("")
            prefs.edit().remove("editor").apply()
        }, LinearLayout.LayoutParams(0, dp(51), 1f))
        content.addView(row)

        content.addView(card(
            "🛡️  SAFE EDITOR",
            "This editor is for personal notes and drafting. It does not execute or inject Roblox scripts.",
            null
        ))
        entrance(content)
    }

    private fun editorStats(text: String): String {
        val words = if (text.trim().isEmpty()) 0 else text.trim().split(Regex("\\s+")).size
        val lines = if (text.isEmpty()) 0 else text.count { it == '\n' } + 1
        return "$words words • $lines lines • ${text.length} characters"
    }

    private fun showTools() {
        current = "tools"
        buildNav()
        clearPage("🧰 Tools", "Utilities • access • app controls")

        val timerCard = card("⏱️  ACCESS TIMER", "Checking access...", "ACTIVE")
        content.addView(timerCard)
        val timerText = TextView(this).apply {
            text = remaining()
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent())
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(12))
        }
        (timerCard as ViewGroup).addView(timerText)
        startAccessTimer(timerText)

        content.addView(section("LOCAL TOOLS"))
        addAction("📋  Copy Bee-Blox Key", "Copy the current build key", ::copyKey)
        addAction("📝  Note Statistics", "See editor counts", ::showNoteStats)
        addAction("📊  Usage Statistics", "See launches and activations", ::showUsage)
        addAction("🧹  Clear Saved Notes", "Remove local editor data", ::clearNotes)
        addAction("🔄  Refresh App", "Rebuild the current dashboard", ::route)

        content.addView(section("COMMUNITY"))
        addAction("🐝  Bee-Blox Discord", "Get the current key/code", ::openDiscord)

        content.addView(section("ROBLOX"))
        addAction("🎮  Launch Official Roblox", "Open the official Android client", ::openRoblox)
        addAction("🌐  Roblox Website", "Open Roblox in your browser", ::openWeb)

        content.addView(section("ACCESS & INFO"))
        addAction("🔑  Key System", "View the 24-hour access screen", ::showKeyGate)
        addAction("❓  Help & Support", "Troubleshooting and FAQ", ::showHelp)
        addAction("ℹ️  About Bee-Blox", "Version, safety and project information", ::showAbout)

        entrance(content)
    }

    private fun showNoteStats() {
        clearPage("📝 Note Statistics")
        val n = prefs.getString("editor", "").orEmpty()
        content.addView(card("Characters", n.length.toString(), null))
        content.addView(card(
            "Words",
            if (n.trim().isEmpty()) "0" else n.trim().split(Regex("\\s+")).size.toString(),
            null
        ))
        content.addView(card(
            "Lines",
            if (n.isEmpty()) "0" else (n.count { it == '\n' } + 1).toString(),
            null
        ))
        content.addView(button("←  BACK TO TOOLS", true) { showTools() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = gapSize() })
        entrance(content)
    }

    private fun showUsage() {
        clearPage("📊 Usage Statistics")
        content.addView(card("Roblox launches", prefs.getInt("launches", 0).toString(), null))
        content.addView(card("Key activations", prefs.getInt("activations", 0).toString(), null))
        content.addView(card("Current access", remaining(), "ACTIVE"))
        
        content.addView(button("←  BACK TO TOOLS", true) { showTools() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = gapSize() })
        entrance(content)
    }

    private fun showSettings() {
        current = "settings"
        buildNav()
        clearPage("⚙ Settings", "Customize Bee-Blox")

        content.addView(section("APP PREFERENCES"))
        setting("📳 Haptics", "Small vibration for taps", "haptics", true)
        setting("✨ Animations", "Animated cards, buttons and bee effects", "animations", true)
        setting("📦 Compact Mode", "Use tighter spacing", "compact", false)

        content.addView(section("THEME"))
        val accentRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("gold" to "🍯 Gold", "amber" to "🍊 Amber", "yellow" to "🌼 Yellow", "honey" to "🐝 Honey")
            .forEach { (id, label) ->
                accentRow.addView(button(
                    label,
                    prefs.getString("accent", "gold") != id
                ) {
                    prefs.edit().putString("accent", id).apply()
                    toast("Theme updated.")
                    showSettings()
                }, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                    setMargins(dp(2), gapSize(), dp(2), gapSize())
                })
            }
        content.addView(accentRow)

        content.addView(section("ACCESS"))
        content.addView(card(
            "🔑  24-HOUR KEY",
            "Current key: Bee-Blox26\nRemaining: ${remaining()}\nGet the current key/code from https://discord.gg/bee-blox",
            "ACTIVE"
        ))
        content.addView(button("🐝  GET KEY / CODE ON DISCORD", true) { openDiscord() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = gapSize() })
        content.addView(button("🔄  ENTER KEY AGAIN", true) { showKeyGate() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = gapSize() })

        content.addView(section("ACCESS ONLY"))
        content.addView(card(
            "🔑  KEY ACCESS",
            "Bee-Blox uses the 24-hour access key only. No account or login is required.",
            null
        ))

        content.addView(section("SUPPORT"))
        addAction("❓  Help & Support", "Troubleshooting and frequently asked questions", ::showHelp)
        addAction("ℹ️  About", "Version and safety information", ::showAbout)
        entrance(content)
    }

    private fun setting(name: String, desc: String, key: String, def: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = getDrawable(R.drawable.bg_card)
            setPadding(dp(13), dp(8), dp(8), dp(8))
        }
        val text = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        text.addView(TextView(this).apply {
            this.text = name
            textSize = 14.5f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        })
        text.addView(TextView(this).apply {
            this.text = desc
            textSize = 11.5f
            setTextColor(muted)
            setPadding(0, dp(2), 0, 0)
        })
        row.addView(text, LinearLayout.LayoutParams(0, dp(62), 1f))
        row.addView(Switch(this).apply {
            isChecked = prefs.getBoolean(key, def)
            buttonTint()
            setOnCheckedChangeListener { _, value ->
                prefs.edit().putBoolean(key, value).apply()
                haptic()
            }
        })
        content.addView(row, LinearLayout.LayoutParams(-1, dp(74)).apply {
            topMargin = gapSize()
        })
    }

    private fun Switch.buttonTint() {
        try {
            thumbTintList = ColorStateList.valueOf(accent())
            trackTintList = ColorStateList.valueOf(Color.rgb(75, 80, 82))
        } catch (_: Exception) {}
    }

    private fun showHelp() {
        current = "settings"
        clearPage("❓ Help & Support", "Troubleshooting")

        content.addView(card(
            "🔑  HOW DO I GET A KEY?",
            "Join the official Bee-Blox Discord and look for the current access key/code.",
            null
        ))
        content.addView(button("🐝  OPEN BEE-BLOX DISCORD", true) { openDiscord() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = gapSize() })

        content.addView(card(
            "⏱️  HOW DOES 24-HOUR ACCESS WORK?",
            "The key itself does not expire. When you activate a valid key, a 24-hour countdown starts. When it reaches zero, enter a key again.",
            null
        ))
        content.addView(card(
            "🎮  ROBLOX DOESN'T OPEN",
            "Bee-Blox first tries the official Roblox Android package. If Roblox is not installed, it opens Roblox in your browser.",
            null
        ))
        content.addView(card(
            "🔐  SECURITY",
            "Never enter your Roblox password into Bee-Blox. The app is a standalone companion.",
            null
        ))
        content.addView(card(
            "🐛  BUG FIX NOTES",
            "Improved navigation state, fixed duplicate-view errors, fixed missing button helper, added live timer updates, functional search filtering and safer refresh routing.",
            "FIXED"
        ))
        content.addView(button("←  BACK TO SETTINGS", true) { showSettings() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = gapSize() })
        entrance(content)
    }

    private fun showAbout() {
        current = "settings"
        clearPage("ℹ About", "Bee-Blox Ultimate")
        val bee = TextView(this).apply {
            text = "🐝"
            textSize = 62f
            gravity = Gravity.CENTER
        }
        content.addView(bee)
        pulse(bee)
        content.addView(TextView(this).apply {
            text = "BEE-BLOX"
            textSize = 27f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent())
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(10))
        })
        content.addView(card("Build", "Ultimate • Android Mobile • Version 3.0", "NEW"))
        content.addView(card(
            "Access",
            "Standard 24-hour key system • No VIP tier",
            "ACTIVE"
        ))
        content.addView(card(
            "Community",
            "Bee-Blox Discord: https://discord.gg/bee-blox",
            null
        ))
        content.addView(card(
            "Safety",
            "Official Roblox launcher only. No Roblox script injection, exploit execution or anti-cheat bypass.",
            null
        ))
        content.addView(button("←  BACK", true) { showSettings() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = gapSize() })
        entrance(content)
    }

    private fun section(text: String): View {
        return TextView(this).apply {
            this.text = text
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent())
            setPadding(dp(3), dp(13), 0, dp(2))
            // Important: section() returns a view but does NOT attach it.
        }
    }

    private fun card(title: String, body: String, badge: String?): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = getDrawable(R.drawable.bg_card)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val h = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        h.addView(TextView(this@MainActivity).apply {
            text = title
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (badge != null) {
            h.addView(TextView(this@MainActivity).apply {
                text = badge
                textSize = 9.5f
                setTextColor(green)
                typeface = Typeface.DEFAULT_BOLD
            })
        }
        c.addView(h)
        c.addView(TextView(this).apply {
            text = body
            textSize = 12.2f
            setTextColor(muted)
            setPadding(0, dp(5), 0, 0)
        })
        return c.apply {
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = gapSize() }
        }
    }

    private fun copyKey() {
        copyText(ACCESS_KEY)
        toast("Bee-Blox key copied.")
    }

    private fun copyText(text: String) {
        if (text.isEmpty()) {
            toast("Nothing to copy.")
            return
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Bee-Blox", text))
        toast("Copied to clipboard.")
    }

    private fun clearNotes() {
        prefs.edit().remove("editor").apply()
        toast("Saved notes cleared.")
    }

    private fun openDiscord() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DISCORD_INVITE)))
        } catch (_: Exception) {
            toast("Unable to open Discord.")
        }
    }

    private fun openRoblox() {
        try {
            val intent = packageManager.getLaunchIntentForPackage("com.roblox.client")
            if (intent != null) {
                startActivity(intent)
            } else {
                openWeb()
            }
        } catch (_: Exception) {
            openWeb()
        }
    }

    private fun openWeb() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(ROBLOX_WEB)))
        } catch (_: Exception) {
            toast("No browser is available.")
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
