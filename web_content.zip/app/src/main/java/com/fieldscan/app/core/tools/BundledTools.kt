package com.fieldscan.app.core.tools

import android.content.Context
import android.os.Build
import java.io.File

/**
 * يستخرج الأدوات المدمجة في APK إلى ملفات قابلة للتنفيذ
 * في المجلد الخاص بالتطبيق (بلا root).
 * أو استخدام الثنائي المدمج في jniLibs باسم libnmap.so
 * لتجاوز قيود W^X على Android 10+ (TargetSDK 29+).
 */
class BundledTools(private val context: Context) {

    val binDir: File = File(context.filesDir, "tools").apply { mkdirs() }
    
    // الحل المدمج الدائم: libnmap.so داخل jniLibs
    val nmapPath: String
        get() = context.applicationInfo.nativeLibraryDir + "/libnmap.so"

    val nmapFile: File
        get() = File(nmapPath)

    fun hasNativeNmap(): Boolean = try {
        val f = File(nmapPath)
        f.exists() && f.canExecute()
    } catch (_: Exception) { false }

    fun run(vararg args: String): String {
        val pb = ProcessBuilder(listOf(*args))
            .redirectErrorStream(true)
            .directory(binDir)
        val env = pb.environment()
        env["LD_LIBRARY_PATH"] = context.applicationInfo.nativeLibraryDir
        env["PATH"] = "\${binDir.absolutePath}:\${env["PATH"]}"
        val p = pb.start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        return out
    }
}
