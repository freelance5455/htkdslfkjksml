package com.fieldscan.app.data.db

data class ScanSession(
    val startedAt: Long,
    val cidr: String,
    val mode: String
)

data class HostEntity(
    val sessionId: Long,
    val ip: String,
    val mac: String?,
    val vendor: String?,
    val deviceGuess: String,
    val suspicious: Boolean,
    val riskLevel: String
)

data class PortEntity(
    val hostId: Long,
    val port: Int,
    val service: String?,
    val version: String?,
    val weakAuth: Boolean
)

data class AlertEntity(
    val sessionId: Long,
    val timestamp: Long,
    val severity: String,
    val type: String,
    val message: String
)

class ScanDao {
    fun insertSession(s: ScanSession): Long = System.currentTimeMillis()
    fun insertHosts(hosts: List<HostEntity>): List<Long> = hosts.indices.map { it.toLong() + 1 }
    fun insertPorts(ports: List<PortEntity>) {}
    fun finishSession(sessionId: Long, endedAt: Long, totalHosts: Int, suspiciousCount: Int) {}
}
