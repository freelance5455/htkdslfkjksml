package com.fieldscan.app.core.native_

import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * ICMP fallback عبر InetAddress.isReachable — يعمل بدون root.
 * الوضع البرمجي (echo ICMP) يعمل عندما يكون التطبيق في مجموعة
 * net_raw (حالة عادية على أجهزة غير مروّتة جزئيًا)، وإلا يسقط
 * تلقائيًا إلى TCP-touch probe (نفس مبدأ nmap -PT).
 */
class IcmpPinger(private val timeoutMs: Int = 300) {

    fun isAlive(ip: String): Boolean = try {
        InetAddress.getByName(ip).isReachable(timeoutMs)
    } catch (_: Exception) { false }

    /** Sweep موازي لشبكة كاملة بـ Executor بسيط */
    fun sweepParallel(ips: List<String>, concurrency: Int = 64): Set<String> {
        val pool = Executors.newFixedThreadPool(concurrency)
        val alive = java.util.Collections.synchronizedSet(mutableSetOf<String>())
        val futures = ips.map { ip -> pool.submit {
            if (isAlive(ip)) alive.add(ip)
        } }
        futures.forEach { 
            try { it.get(2, TimeUnit.SECONDS) } catch (_: Exception) {}
        }
        pool.shutdown()
        return alive
    }
}
