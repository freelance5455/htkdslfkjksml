package com.fieldscan.app.api

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONObject

/**
 * Companion APK Integration Bridge:
 * Allows authorized external tools to interact with FieldScan via Android Intents
 * or local REST API at http://127.0.0.1:8088/api/scan
 */
class ExternalScanReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_START_SCAN = "com.fieldscan.app.ACTION_START_SCAN"
        const val ACTION_SCAN_RESULTS = "com.fieldscan.app.ACTION_SCAN_RESULTS"
        const val EXTRA_CIDR = "target_cidr"
        const val EXTRA_PAYLOAD_JSON = "payload_json"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_START_SCAN -> {
                val cidr = intent.getStringExtra(EXTRA_CIDR) ?: "192.168.1.0/24"
                // Trigger background scan and reply with Broadcast
            }
        }
    }
}
