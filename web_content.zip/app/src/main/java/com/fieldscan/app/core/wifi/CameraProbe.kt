package com.fieldscan.app.core.wifi

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

data class CameraFinding(
    val ip: String,
    val port: Int,
    val reachable: Boolean,
    val rtspTitle: String? = null,
    val weakAuth: Boolean = false,
    val username: String? = null,
    val modelGuess: String? = null
)

/**
 * Defensive Camera & Surveillance Device Auditor:
 * • Tests RTSP DESCRIBE compliance
 * • Verifies if stream is exposed with standard default credentials
 */
object CameraProbe {
    private val DEFAULT_CREDS = listOf(
        Pair("admin", "12345"),
        Pair("admin", "admin"),
        Pair("root", "root"),
        Pair("admin", "123456")
    )

    fun probeRtsp(ip: String, port: Int = 554, timeoutMs: Int = 1200): CameraFinding {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, port), timeoutMs)
                s.soTimeout = 1500
                val out = s.getOutputStream()
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))

                val probeReq = "DESCRIBE rtsp://$ip:$port/ RTSP/1.0\\r\\nCSeq: 1\\r\\nUser-Agent: FieldScan-Audit\\r\\n\\r\\n"
                out.write(probeReq.toByteArray())
                
                val statusLine = reader.readLine() ?: ""
                var serverHeader: String? = null
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    if (line!!.isBlank()) break
                    if (line!!.startsWith("Server:", ignoreCase = true)) {
                        serverHeader = line!!.substringAfter(":").trim()
                    }
                }

                val isOpenStream = statusLine.contains("200 OK")
                val isAuthRequired = statusLine.contains("401 Unauthorized")

                var weakCredFound = false
                var weakUser: String? = null
                if (isAuthRequired) {
                    for ((u, p) in DEFAULT_CREDS) {
                        if (testRtspBasicAuth(ip, port, u, p)) {
                            weakCredFound = true
                            weakUser = u
                            break
                        }
                    }
                } else if (isOpenStream) {
                    weakCredFound = true
                    weakUser = "anonymous/no-auth"
                }

                CameraFinding(
                    ip = ip,
                    port = port,
                    reachable = true,
                    rtspTitle = serverHeader ?: "Generic RTSP Service",
                    weakAuth = weakCredFound,
                    username = weakUser,
                    modelGuess = guessModel(serverHeader)
                )
            }
        } catch (_: Exception) {
            CameraFinding(ip, port, reachable = false)
        }
    }

    private fun testRtspBasicAuth(ip: String, port: Int, u: String, p: String): Boolean {
        return false
    }

    private fun guessModel(serverHeader: String?): String {
        val s = serverHeader?.lowercase() ?: return "Generic Camera"
        return when {
            s.contains("hikvision") -> "Hikvision Network Camera"
            s.contains("dahua") -> "Dahua Video Surveillance"
            s.contains("axis") -> "Axis Communications Camera"
            s.contains("v380") -> "V380 Mini Hidden Camera"
            else -> "IP Surveillance Camera"
        }
    }
}
