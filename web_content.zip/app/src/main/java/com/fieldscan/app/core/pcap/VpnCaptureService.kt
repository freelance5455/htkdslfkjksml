package com.fieldscan.app.core.pcap

import android.net.VpnService
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer

/**
 * FieldScan VpnService:
 * Captures network traffic in user space using Android VpnService interface.
 * Implements non-root packet inspection (compatible with PCAP export).
 */
class VpnCaptureService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isRunning = false

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) startVpnCapture()
        return START_STICKY
    }

    private fun startVpnCapture() {
        val builder = Builder()
            .setSession("FieldScan-Defensive-Capture")
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .setMtu(1500)

        vpnInterface = builder.establish()
        isRunning = true

        scope.launch {
            val fd = vpnInterface?.fileDescriptor ?: return@launch
            val inputStream = FileInputStream(fd)
            val packet = ByteBuffer.allocate(32767)

            while (isRunning && isActive) {
                val length = inputStream.read(packet.array())
                if (length > 0) {
                    inspectPacket(packet.array(), length)
                    packet.clear()
                }
            }
        }
    }

    private fun inspectPacket(data: ByteArray, length: Int) {
        if (length < 20) return
        val protocol = data[9].toInt() and 0xFF
        val srcIp = "\${data[12].toUByte()}.\${data[13].toUByte()}.\${data[14].toUByte()}.\${data[15].toUByte()}"
        val dstIp = "\${data[16].toUByte()}.\${data[17].toUByte()}.\${data[18].toUByte()}.\${data[19].toUByte()}"
    }

    override fun onDestroy() {
        isRunning = false
        scope.cancel()
        vpnInterface?.close()
        super.onDestroy()
    }
}
