package com.fieldscan.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FieldScanAppScreen() {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("الأجهزة", "الكاميرات", "الرادار", "الحزم", "المستشار الذكي")

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "FIELDSCAN",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 18.sp,
                            color = Color(0xFF38BDF8)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Badge(containerColor = Color(0xFF10B981)) {
                            Text("100% Standalone APK", color = Color.Black, fontSize = 10.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0F172A)) {
                tabs.forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        label = { Text(title, fontSize = 11.sp) },
                        icon = {
                            when (index) {
                                0 -> Icon(Icons.Default.Devices, contentDescription = null)
                                1 -> Icon(Icons.Default.Videocam, contentDescription = null)
                                2 -> Icon(Icons.Default.Radar, contentDescription = null)
                                3 -> Icon(Icons.Default.SwapVert, contentDescription = null)
                                else -> Icon(Icons.Default.Security, contentDescription = null)
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF38BDF8),
                            indicatorColor = Color(0xFF1E293B)
                        )
                    )
                }
            }
        },
        containerColor = Color(0xFF020617)
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            when (selectedTab) {
                0 -> DevicesListView()
                1 -> CameraAuditView()
                2 -> RadarSweepView()
                3 -> LivePacketsView()
                4 -> AiSecurityAdvisorView()
            }
        }
    }
}

@Composable
fun DevicesListView() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Button(
            onClick = { /* Start Kotlin Sweep */ },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
        ) {
            Text("بدء فحص الشبكة (Native Kotlin Engine)")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("الأجهزة المكتشفة في الشبكة المحلية:", color = Color.LightGray, fontSize = 13.sp)
    }
}

@Composable fun CameraAuditView() { /* RTSP streams audit cards */ }
@Composable fun RadarSweepView() { /* Animated radar & signal distance */ }
@Composable fun LivePacketsView() { /* VpnService packet stream */ }
@Composable fun AiSecurityAdvisorView() { /* Defensive hardening advice */ }
