package com.fieldscan.app.core.native_

import java.io.File
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * آلية اكتشاف MAC بدون root بلا أدوات:
 * 1) UDP/TCP-touch على IP هدف -> يضيف نواة Android الجهاز لجدول الجوار (neighbor table)
 * 2) قراءة /proc/net/arp فورًا لالتقاط الـ MAC
 * هذه بالضبط الطريقة التي تعمل بها nmap -PE + arp-read في بيئة غير root.
 */
object ArpProbe {

    fun macOf(ip: String, probePorts: List<Int> = listOf(80, 443, 22, 554)): String? {
        // 1) املأ ARP cache بلمسة TCP سريعة
        for (port in probePorts) {
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(ip, port), 200)
                    break
                }
            } catch (_: Exception) {}
        }
        // fallback: UDP (دائمًا يعمل ويولّد ARP حتى لو الهدف غائب)
        try {
            DatagramSocket().use { ds ->
                ds.send(DatagramPacket(ByteArray(1), 1, InetAddress.getByName(ip), 5353))
            }
        } catch (_: Exception) {}

        // 2) اقرأ الجدول
        return try {
            File("/proc/net/arp").readLines().drop(1).forEach { line ->
                val f = line.trim().split(Regex("\\\\s+"))
                if (f.size >= 4 && f[0] == ip && f[3] != "00:00:00:00:00:00") {
                    return f[3].uppercase()
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }
}
