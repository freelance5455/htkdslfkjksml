package com.fieldscan.app.core.native_

import android.content.Context
import android.net.wifi.WifiManager
import java.net.NetworkInterface

object NetInfo {

    data class NetConfig(val ip: String, val prefix: Int, val cidr: String, val iface: String)

    fun currentCidr(context: Context): NetConfig? {
        // من WifiManager (يحتاج ACCESS_WIFI_STATE فقط)
        (context.getSystemService(Context.WIFI_SERVICE) as? WifiManager)?.let { wm ->
            val dhcp = wm.dhcpInfo ?: return@let
            val ip = toStr(dhcp.ipAddress)
            if (ip.isNotBlank() && ip != "0.0.0.0") {
                val mask = toStr(dhcp.netmask)
                val prefix = maskToPrefix(mask)
                return NetConfig(ip, prefix, "\${ipToCidrBase(ip, prefix)}/$prefix", "wlan0")
            }
        }
        // fallback من NetworkInterface
        for (nif in NetworkInterface.getNetworkInterfaces()) {
            if (nif.isUp && !nif.isLoopback) for (addr in nif.inetAddresses) {
                if (!addr.isLoopbackAddress && addr.address.size == 4) {
                    val prefix = nif.interfaceAddresses
                        .firstOrNull { it.address == addr }?.networkPrefixLength?.toInt() ?: 24
                    val ip = addr.hostAddress ?: continue
                    return NetConfig(ip, prefix, "\${ipToCidrBase(ip, prefix)}/$prefix", nif.name)
                }
            }
        }
        return null
    }

    private fun toStr(v: Int) = listOf(0, 8, 16, 24)
        .map { (v shr it) and 0xFF }.joinToString(".")
    private fun maskToPrefix(m: String) = m.split(".").sumOf { Integer.bitCount(it.toInt()) }
    private fun ipToCidrBase(ip: String, prefix: Int): String {
        val o = ip.split(".").map { it.toInt() }
        val bits = prefix.coerceIn(0, 32)
        val hostBits = 32 - bits
        val ipInt = (o[0].toLong() shl 24) or (o[1].toLong() shl 16) or
                    (o[2].toLong() shl 8) or o[3].toLong()
        val masked = (ipInt shr hostBits) shl hostBits
        return listOf((masked shr 24) and 0xFF, (masked shr 16) and 0xFF,
                      (masked shr 8) and 0xFF, masked and 0xFF).joinToString(".")
    }
}
