package com.fieldscan.app.core.native_

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.io.BufferedInputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

data class PortResult(
    val port: Int,
    val open: Boolean,
    val service: String? = null,
    val banner: String? = null,
    val version: String? = null
)

data class HostScanResult(
    val ip: String,
    val openPorts: List<PortResult>
)

/**
 * ماسح TCP connect كامل — بديل مباشر لـ nmap -sT:
 * • مسح موازي مع Rate limiting (64 sockets متزامنة افتراضيًا)
 * • قراءة banners لتحديد الخدمة والإصدار
 * • بلا أي ثنائي خارجي — Kotlin netty-free, JDK فقط
 */
class TcpPortScanner(
    private val concurrency: Int = 64,
    private val connectTimeoutMs: Int = 1200,
    private val bannerTimeoutMs: Int = 800
) {
    private val sem = kotlinx.coroutines.sync.Semaphore(concurrency)

    suspend fun scan(ip: String, ports: List<Int>): List<PortResult> = coroutineScope {
        val out = java.util.Collections.synchronizedList(mutableListOf<PortResult>())
        ports.map { port -> launch(Dispatchers.IO) {
            sem.withPermit {
                probe(ip, port)?.let { if (it.open) out += it }
            }
        } }.joinAll()
        out.sortedBy { it.port }
    }

    private fun probe(ip: String, port: Int): PortResult? {
        return try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, port), connectTimeoutMs)
                val banner = readBanner(s, port)
                PortResult(
                    port = port, open = true,
                    service = banner?.service ?: ServiceGuess.byPort(port),
                    banner = banner?.raw?.take(200),
                    version = banner?.version
                )
            }
        } catch (e: java.net.SocketTimeoutException) {
            null // Timeout/Filtered
        } catch (_: Exception) { null } // Closed / RST
    }

    private fun readBanner(s: Socket, port: Int): BannerInfo? {
        return try {
            s.soTimeout = bannerTimeoutMs
            val ins = BufferedInputStream(s.getInputStream())
            val buf = ByteArray(512)
            var n = ins.read(buf)
            var raw = if (n > 0) String(buf, 0, n) else ""
            if (raw.isBlank() && port in listOf(80, 8080, 8443, 443, 8000, 554, 8554)) {
                val req = "GET / HTTP/1.0\\r\\nHost: probe\\r\\nUser-Agent: FieldScan/1.0\\r\\n\\r\\n"
                s.getOutputStream().write(req.toByteArray())
                n = ins.read(buf)
                if (n > 0) raw = String(buf, 0, n)
            }
            BannerInfo.parse(raw, port)
        } catch (_: Exception) { null }
    }
}

data class BannerInfo(val raw: String, val service: String?, val version: String?) {
    companion object {
        fun parse(raw: String, port: Int): BannerInfo? {
            if (raw.isBlank()) return null
            val l = raw.uppercase()
            return when {
                l.startsWith("SSH-") -> BannerInfo(raw, "ssh",
                    raw.split("-").getOrNull(2)?.lineSequence()?.first())
                l.startsWith("HTTP/") -> BannerInfo(raw, "http",
                    Regex("Server:\\\\s*(.+)").find(raw)?.groupValues?.get(1)?.trim())
                l.startsWith("RTSP/") -> BannerInfo(raw, "rtsp",
                    Regex("Server:\\\\s*(.+)").find(raw)?.groupValues?.get(1)?.trim())
                l.startsWith("220") || l.startsWith("FTP") -> BannerInfo(raw, "ftp",
                    raw.lineSequence().firstOrNull())
                else -> BannerInfo(raw, null, null)
            }
        }
    }
}

object ServiceGuess {
    private val byPortMap = mapOf(
        21 to "ftp", 22 to "ssh", 23 to "telnet", 25 to "smtp", 53 to "dns",
        80 to "http", 110 to "pop3", 143 to "imap", 443 to "https",
        445 to "smb", 554 to "rtsp", 1883 to "mqtt", 3389 to "rdp",
        5000 to "upnp/http", 5432 to "postgres", 5900 to "vnc",
        8000 to "http-alt", 8008 to "http", 8080 to "http-proxy",
        8443 to "https-alt", 8554 to "rtsp", 9000 to "http", 49152 to "upnp"
    )
    fun byPort(p: Int) = byPortMap[p]
}

suspend inline fun <T> kotlinx.coroutines.sync.Semaphore.withPermit(block: () -> T): T {
    acquire(); try { return block() } finally { release() }
}
