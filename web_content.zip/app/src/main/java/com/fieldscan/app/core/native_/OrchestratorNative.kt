package com.fieldscan.app.core.native_

import com.fieldscan.app.core.arp.OuiDb
import com.fieldscan.app.core.wifi.CameraProbe
import com.fieldscan.app.data.db.*
import kotlinx.coroutines.*

/**
 * مسار فحص كامل يعمل 100% بلغة Kotlin:
 * 1) اكتشاف الشبكة تلقائيًا (NetInfo)
 * 2) ping sweep موازٍ (IcmpPinger)
 * 3) MAC/OUI لكل جهاز حي (ArpProbe + OuiDb)
 * 4) مسح منافذ TCP كامل مع banners (TcpPortScanner)
 * 5) فحص RTSP + كلمات مرور افتراضية (CameraProbe)
 * 6) تصنيف أجهزة + كشف مشتبه به + تنبيهات
 * بلا nmap، بلا Termux، بلا أي ثنائي.
 */
class NativeScanEngine(
    private val ouiDb: OuiDb,
    private val dao: ScanDao
) {
    private val tcpScanner = TcpPortScanner(concurrency = 64)
    private val pinger = IcmpPinger()

    val allPorts = listOf(
        21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 554, 1883, 1935,
        3389, 5000, 5432, 5900, 8000, 8008, 8009, 8080, 8081, 8443,
        8554, 9000, 9100, 49152
    )

    suspend fun fullScan(
        cidr: String,
        onProgress: (String) -> Unit,
        onAlert: (AlertEntity) -> Unit
    ): Long = coroutineScope {
        val sessionId = dao.insertSession(
            ScanSession(startedAt = System.currentTimeMillis(), cidr = cidr, mode = "native"))

        // 1) شبكة
        onProgress("توسيع نطاق $cidr ...")
        val ips = Cidr.expand(cidr)
        onProgress("فحص \${ips.size} عنوان ...")

        // 2) ping sweep
        onProgress("Ping sweep متوازي...")
        val alive = pinger.sweepParallel(ips)

        // 3) MAC/OUI
        onProgress("حل \${alive.size} جهاز حي عبر ARP/OUI...")
        data class Host(val ip: String, val mac: String?, val vendor: String?)
        val hosts = alive.map { ip ->
            async(Dispatchers.IO) {
                val mac = ArpProbe.macOf(ip)
                Host(ip, mac, mac?.let { ouiDb.lookup(it) })
            }
        }.awaitAll()

        // 4) TCP port scan + banners
        onProgress("مسح المنافذ وbanners على \${hosts.size} جهاز ...")
        val results = hosts.map { h -> async(Dispatchers.IO) {
            val ports = tcpScanner.scan(h.ip, allPorts)
            Triple(h, ports, null as String?)
        } }.awaitAll()

        // 5) RTSP/default-cred على كل جهاز
        onProgress("فحص الكاميرات والمراقبة (RTSP Probing)...")
        val camFindings = results.map { (h, _, _) -> async(Dispatchers.IO) {
            CameraProbe.probeRtsp(h.ip)
        } }.awaitAll().filter { it.reachable }

        // 6) تخزين وتصنيف
        val hostEntities = results.map { (h, ports, _) ->
            val guess = classify(ports, h.vendor)
            val suspicious = guess == "camera" || h.vendor?.uppercase() in
                setOf("HIKVISION", "DAHUA", "EZVIZ", "IMOU", "V380")
            HostEntity(sessionId = sessionId, ip = h.ip, mac = h.mac,
                vendor = h.vendor, deviceGuess = guess, suspicious = suspicious,
                riskLevel = if (ports.any { p -> p.port == 23 || p.port == 554 }) "high"
                            else if (ports.any { it.port in listOf(80, 8080, 443) }) "medium"
                            else "low")
        }
        val hostIds = dao.insertHosts(hostEntities)
        val ipToId = results.mapIndexed { i, (h, _, _) -> h.ip to hostIds[i] }.toMap()
        dao.insertPorts(results.flatMap { (h, ports, _) ->
            ports.map { p -> PortEntity(
                hostId = ipToId[h.ip]!!, port = p.port,
                service = p.service, version = p.version,
                weakAuth = camFindings.any { it.ip == h.ip && it.weakAuth }) }
        })

        // 7) تنبيهات
        camFindings.filter { it.weakAuth }.forEach { f ->
            onAlert(AlertEntity(sessionId, System.currentTimeMillis(), "critical",
                "weak_auth", "كاميرا \${f.ip}:\${f.port} بكلمة مرور افتراضية (\${f.username}). غيّرها فورًا."))
        }
        hostEntities.filter { it.suspicious }.forEach {
            onAlert(AlertEntity(sessionId, System.currentTimeMillis(), "warning",
                "suspicious_device", "جهاز مشتبه به: \${it.ip} (\${it.vendor ?: "غير معروف"})"))
        }

        dao.finishSession(sessionId, System.currentTimeMillis(),
            hostEntities.size, hostEntities.count { it.suspicious })
        onProgress("اكتمل الفحص: \${hostEntities.size} جهاز متصل")
        sessionId
    }

    private fun classify(ports: List<PortResult>, vendor: String?): String = when {
        ports.any { it.port == 554 || it.port == 8554 } -> "camera"
        ports.any { it.port in listOf(5000, 49152) } -> "router/NAS"
        ports.any { it.port == 3389 } -> "windows-pc"
        ports.any { it.port == 5900 } -> "remote-desktop"
        vendor?.lowercase()?.contains("apple") == true -> "apple-device"
        vendor?.lowercase()?.contains("samsung") == true -> "phone"
        ports.isEmpty() -> "unknown-silent"
        else -> "generic"
    }
}

object Cidr {
    fun expand(cidr: String): List<String> {
        val (base, bitsStr) = cidr.split("/")
        val prefix = bitsStr.toInt()
        val o = base.split(".").map { it.toLong() }
        val ipInt = (o[0] shl 24) or (o[1] shl 16) or (o[2] shl 8) or o[3]
        val mask = (-1L shl (32 - prefix))
        val network = ipInt and mask
        val size = 1L shl (32 - prefix)
        return (1L until size - 1).map {
            val a = network + it
            listOf((a shr 24) and 0xFF, (a shr 16) and 0xFF,
                   (a shr 8) and 0xFF, a and 0xFF).joinToString(".")
        }
    }
}
