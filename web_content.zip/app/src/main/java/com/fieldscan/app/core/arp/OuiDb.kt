package com.fieldscan.app.core.arp

class OuiDb {
    private val vendors = mapOf(
        "B8:27:EB" to "Raspberry Pi Foundation",
        "DC:A6:32" to "Raspberry Pi Foundation",
        "E4:5F:01" to "Raspberry Pi Foundation",
        "44:01:BB" to "Hikvision Digital Technology",
        "C0:56:E3" to "Dahua Technology",
        "AC:CC:8E" to "Axis Communications",
        "00:1A:79" to "Apple Inc.",
        "AC:DE:48" to "Apple Inc.",
        "F4:F5:DB" to "Apple Inc.",
        "34:7E:5C" to "Samsung Electronics",
        "D8:07:B6" to "Espressif IoT",
        "24:6F:28" to "Espressif IoT"
    )

    fun lookup(mac: String): String {
        val clean = mac.uppercase().replace("-", ":").replace(".", ":")
        val prefix = if (clean.length >= 8) clean.substring(0, 8) else clean
        return vendors[prefix] ?: "Generic Network Device"
    }
}
