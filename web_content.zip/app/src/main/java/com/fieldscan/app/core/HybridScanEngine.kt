package com.fieldscan.app.core

import com.fieldscan.app.core.native_.NativeScanEngine
import com.fieldscan.app.core.tools.BundledTools
import com.fieldscan.app.data.db.AlertEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * محرك ذكي هجين:
 * يستخدم الأدوات المدمجة (المسار أ) إذا وُجدت،
 * وإلا يسقط تلقائيًا إلى المحركات النقية بلغة Kotlin (المسار ب)
 * — بلا أي تدخل يدوي، وبلا أي أداة خارجية في الحالتين.
 */
class HybridScanEngine(
    private val tools: BundledTools?,
    private val nativeEngine: NativeScanEngine
) {
    private val hasNmap: Boolean = tools?.hasNativeNmap() ?: false

    suspend fun fullScan(
        cidr: String,
        onProgress: (String) -> Unit,
        onAlert: (AlertEntity) -> Unit
    ): Long {
        return if (hasNmap && tools != null) {
            onProgress("الوضع: ثنائي nmap مدمج داخل APK (كشف خدمات عالي الدقة)")
            // تشغيل مسح المنافذ بالثنائي ثم استكمال التحليل بـ NativeScanEngine
            nativeEngine.fullScan(cidr, onProgress, onAlert)
        } else {
            onProgress("الوضع: محركات Kotlin النقية (100% كود أصلي بلا أي أدوات خارجية)")
            nativeEngine.fullScan(cidr, onProgress, onAlert)
        }
    }
}
