package com.uvinkbook.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

/**
 * Hosts the bundled HTML app entirely from APK assets.
 *
 * Some versions of the project used WebViewAssetLoader and the URL
 * https://appassets.androidplatform.net/web/index.html.  If that loader is
 * missing or its mapping is wrong, WebView displays ERR_HTTP_RESPONSE_CODE_FAILURE.
 * This client provides the same /web/ mapping directly, without a network
 * request or an extra dependency.
 */
public class MainActivity extends Activity {
    private static final String APP_ASSET_HOST = "appassets.androidplatform.net";
    private static final String APP_ASSET_PREFIX = "/web/";

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null
                        && APP_ASSET_HOST.equalsIgnoreCase(request.getUrl().getHost())) {
                    return openBundledAsset(request.getUrl().getPath());
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                // Compatibility with older Android WebView implementations.
                if (url != null && url.startsWith("https://" + APP_ASSET_HOST + APP_ASSET_PREFIX)) {
                    return openBundledAsset(url.substring(("https://" + APP_ASSET_HOST).length()));
                }
                return super.shouldInterceptRequest(view, url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        android.webkit.WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                            "تعذر تشغيل التطبيق. تأكد من استخدام النسخة المصححة.",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        // This URL is local to the APK. Requests are intercepted above and
        // served from app/src/main/assets, so no Internet connection is needed.
        webView.loadUrl("https://" + APP_ASSET_HOST + APP_ASSET_PREFIX + "index.html");
        setContentView(webView);
    }

    private WebResourceResponse openBundledAsset(String urlPath) {
        if (urlPath == null || !urlPath.startsWith(APP_ASSET_PREFIX)) {
            return null;
        }

        String assetPath = urlPath.substring(APP_ASSET_PREFIX.length());
        if (assetPath.length() == 0 || assetPath.contains("..")) {
            return null;
        }

        try {
            InputStream stream = getAssets().open(assetPath);
            String mimeType = getMimeType(assetPath);
            return new WebResourceResponse(mimeType, "UTF-8", stream);
        } catch (IOException ignored) {
            return null;
        }
    }

    private String getMimeType(String path) {
        String extension = MimeTypeMap.getFileExtensionFromUrl(path);
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                extension.toLowerCase(Locale.US));
        if (mime != null) return mime;
        if (path.endsWith(".js")) return "application/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".html")) return "text/html";
        return "application/octet-stream";
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
