package com.mikan.vpn
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity: AppCompatActivity() {
 private val vk="https://vk.com/"
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main)
  val l=findViewById<EditText>(R.id.login); val p=findViewById<EditText>(R.id.password)
  val s=findViewById<TextView>(R.id.status); val c=findViewById<Button>(R.id.connectBtn)
  findViewById<Button>(R.id.loginBtn).setOnClickListener{
   if(l.text.isBlank()||p.text.isBlank()){s.text="Заполни логин и пароль";return@setOnClickListener}
   s.text="Тариф FREE • осталось 30 дней";c.isEnabled=true
  }
  findViewById<Button>(R.id.regBtn).setOnClickListener{
   if(l.text.isBlank()||p.text.isBlank()){s.text="Введите логин и пароль";return@setOnClickListener}
   s.text="Аккаунт создан • FREE 30 дней";c.isEnabled=true
  }
  c.setOnClickListener{Toast.makeText(this,"Подключение появится после настройки VPN-сервера",Toast.LENGTH_LONG).show()}
  findViewById<Button>(R.id.vkBtn).setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(vk)))}
 }
}