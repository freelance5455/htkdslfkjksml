package com.blazentis.bz
import android.app.*
import android.app.admin.*
import android.content.*
import android.content.pm.*
import android.graphics.*
import android.net.Uri
import android.os.*
import android.util.Base64
import android.view.WindowManager
import android.webkit.*
import org.json.*
import java.io.*

/** Runs inside the work profile (the "dimension") right after Android creates it. */
class Admin : DeviceAdminReceiver() {
    override fun onProfileProvisioningComplete(c: Context, i: Intent) {
        val d = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val cn = ComponentName(c, Admin::class.java)
        d.setProfileName(cn, "Hidden World")
        d.addCrossProfileIntentFilter(cn, IntentFilter("com.blazentis.bz.CMD").apply { addCategory(Intent.CATEGORY_DEFAULT) }, DevicePolicyManager.FLAG_PARENT_CAN_ACCESS)
        d.setProfileEnabled(cn)
    }
}

class ModeAct : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setResult(RESULT_OK, Intent().putExtra(DevicePolicyManager.EXTRA_PROVISIONING_MODE, DevicePolicyManager.PROVISIONING_MODE_MANAGED_PROFILE))
        finish()
    }
}

class DoneAct : Activity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setResult(RESULT_OK); finish() }
}

/** Commands from the outside app; only answers inside the dimension, where this app is the profile owner. */
class Cmd : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val cn = ComponentName(this, Admin::class.java)
        val p = intent.getStringExtra("p") ?: ""
        if (d.isProfileOwnerApp(packageName)) try {
            when (intent.getStringExtra("c")) {
                "move" -> { d.installExistingPackage(cn, p); d.setApplicationHidden(cn, p, true) }
                "hide" -> d.setApplicationHidden(cn, p, true)
                "unhide" -> d.setApplicationHidden(cn, p, false)
                "hideall" -> { val a = JSONArray(p); for (k in 0 until a.length()) d.setApplicationHidden(cn, a.getString(k), true) }
            }
        } catch (e: Exception) {}
        finish()
    }
}

class MainActivity : Activity() {
    private lateinit var w: WebView
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (d.isProfileOwnerApp(packageName)) { finish(); return }
        // only the copy inside the dimension should answer commands
        packageManager.setComponentEnabledSetting(ComponentName(this, Cmd::class.java), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        w = WebView(this)
        setContentView(w)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = false
        }
        w.addJavascriptInterface(Bridge(), "BlazeNative")
        w.loadUrl("file:///android_asset/index.html")
    }
    @Deprecated("back")
    override fun onBackPressed() { if (w.canGoBack()) w.goBack() else super.onBackPressed() }

    inner class Bridge {
        private val dpm get() = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        private val dim: UserHandle? get() =
            (getSystemService(USER_SERVICE) as UserManager).userProfiles.firstOrNull { it != Process.myUserHandle() }
        private fun cmd(c: String, p: String) {
            val i = Intent("com.blazentis.bz.CMD").putExtra("c", c).putExtra("p", p).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runOnUiThread { try { startActivity(i) } catch (e: Exception) {} }
        }

        @JavascriptInterface fun perms(): String = JSONObject().put("owner", dim != null).put("pkg", packageName).toString()

        @JavascriptInterface fun setup(): String {
            val a = DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE
            if (!dpm.isProvisioningAllowed(a)) return "blocked"
            val i = Intent(a).putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_Bz Snake, ComponentName(this@MainActivity, Admin::class.java))
            runOnUiThread { startActivityForResult(i, 1) }
            return "ok"
        }

        @JavascriptInterface fun list(): String {
            val pm = packageManager
            val a = JSONArray()
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(pm).toString().lowercase() }
                .forEach { a.put(JSONObject().put("p", it.activityInfo.packageName).put("n", it.loadLabel(pm).toString())) }
            return a.toString()
        }

        @JavascriptInterface fun icon(p: String): String = try {
            val bm = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
            val d = packageManager.getApplicationIcon(p)
            d.setBounds(0, 0, 96, 96); d.draw(Canvas(bm))
            val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.PNG, 100, o)
            Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) { "" }

        /** Copies the app into the dimension, hides it there, then asks to remove the outside copy. */
        @JavascriptInterface fun hide(p: String): String {
            if (dim == null) return "need_owner"
            cmd("move", p)
            try {
                if (packageManager.getApplicationInfo(p, 0).flags and ApplicationInfo.FLAG_SYSTEM == 0)
                    runOnUiThread { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$p")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            } catch (e: Exception) {}
            return "ok"
        }

        @JavascriptInterface fun unhide(p: String): String { cmd("unhide", p); return "ok" }
        @JavascriptInterface fun rehide(json: String) { cmd("hideall", json) }

        @JavascriptInterface fun open(p: String): String {
            val u = dim ?: return "fail"
            cmd("unhide", p)
            Thread.sleep(900)
            return try {
                val la = getSystemService(LauncherApps::class.java)
                val l = la.getActivityList(p, u)
                if (l.isEmpty()) "fail" else { la.startMainActivity(l[0].componentName, u, null, null); "ok" }
            } catch (e: Exception) { "fail" }
        }

        @JavascriptInterface fun save(name: String, html: String): String {
            val f = File(getExternalFilesDir(null), name); f.writeText(html); return f.absolutePath
        }
    }
}
