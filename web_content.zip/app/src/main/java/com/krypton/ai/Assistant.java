package com.krypton.ai;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

/** Conversation brain for Telegram and Gmail: normal answers, plus real picture understanding with follow-up questions. */
final class Assistant {
    static final String DEFAULT_Q = "Describe this picture in detail. If it contains text, equations, a chart, a diagram or a document, read it and explain it.";

    static File hist(Context c, String src) {
        String k = Channel.key(src);
        return new File(c.getFilesDir(), k.equals("telegram") ? "tg_history.json" : "hist_" + k + ".json");   // keeps the old Telegram history
    }

    static synchronized JSONArray load(Context c, String src) {
        File f = hist(c, src);
        if (!f.exists()) return new JSONArray();
        try (FileInputStream in = new FileInputStream(f)) { return new JSONArray(new String(Store.readAll(in), "UTF-8")); }
        catch (Exception e) { return new JSONArray(); }
    }

    static synchronized void save(Context c, String src, JSONArray a) {
        try {
            JSONArray out = new JSONArray();
            for (int i = Math.max(0, a.length() - 20); i < a.length(); i++) out.put(a.get(i));
            try (FileOutputStream o = new FileOutputStream(hist(c, src))) { o.write(out.toString().getBytes("UTF-8")); }
        } catch (Exception ignored) { }
    }

    static String chat(Context c, String src, String text) throws Exception { return chat(c, src, text, null); }

    static boolean recentImage(JSONArray h) {
        for (int i = h.length() - 1; i >= Math.max(0, h.length() - 10); i--)
            if (!h.optJSONObject(i).optString("img", "").isEmpty()) return true;
        return false;
    }

    /** imgId = a picture that came with this message (already stored by ImageStore), or null. */
    static String chat(Context c, String src, String text, String imgId) throws Exception {
        String key = Channel.key(src);
        if (imgId != null) {
            if (!Vision.available(c)) return "I can't look at pictures yet because no vision model has been set up.";
            ImageStore.setSticky(key, imgId);
        }
        JSONArray h = load(c, src);
        JSONObject um = new JSONObject().put("role", "user").put("content", text);
        if (imgId != null) um.put("img", imgId);
        h.put(um);
        boolean vision = Vision.available(c) && ImageStore.stickyActive(key) && recentImage(h);
        String ans;
        if (vision) {
            JSONArray tail = new JSONArray();
            for (int i = Math.max(0, h.length() - 10); i < h.length(); i++) tail.put(h.get(i));
            ans = Vision.askBlocking(c, tail);
            if (Vision.cancelled()) return "Cancelled.";
            ImageStore.touch(key);                                   // follow-ups keep using the same picture
        } else {
            ans = Commands.processTags(c, Llm.chat(c, Telegram.buildMessages(c, h)));
            if (Llm.cancel) return "Cancelled.";
        }
        if (ans.isEmpty()) ans = "(I could not produce an answer. Please try again.)";
        h.put(new JSONObject().put("role", "assistant").put("content", ans));
        save(c, src, h);
        Mem.addShort(c, text, Mem.cut(ans, 300));
        return ans;
    }
}
