package com.krypton.ai;

import android.content.Context;
import android.content.Intent;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * AI action planner. Loop: read the live screen -> ask the local Qwen model for ONE action (JSON, schema-forced)
 * -> execute -> re-read the screen to verify the result. Success is only reported after the final screen is verified.
 */
final class Planner {
    static class Fail extends RuntimeException { Fail(String m) { super(m); } }

    static volatile Thread worker;
    static volatile boolean cancel;
    static volatile String goal = "", status = "idle", last = "";
    static final int MAX_STEPS = 30;

    static final Pattern SEND = Pattern.compile("(?i)\\bsend\\s+(?:[\"\u201c]([^\"\u201d]+)[\"\u201d]|(.+?))\\s+to\\s+(.+?)(?:\\s+(?:on|in|via|using)\\s+\\w+)?\\s*$");
    static final Pattern OPEN = Pattern.compile("(?i)^(?:please\\s+)?(?:open|launch)\\s+(.+?)(?:\\s+and\\s+(.+))?$");

    static boolean isRunning() { Thread t = worker; return t != null && t.isAlive(); }

    static void stop() { cancel = true; Llm.cancelNow(); }

    static String statusText() { return isRunning() ? "Phone task running (" + status + "): " + goal : last.isEmpty() ? "No phone task has run yet." : last; }

    /** Returns the text to show right away. The result is delivered later through the channel. */
    static synchronized String start(final Context ctx, final String g, final String src) {
        if (isRunning()) return "A phone task is already running: " + goal + ". Send /cancel first.";
        if (KryptonAccessibilityService.instance == null)
            return "Phone control needs the Krypton Accessibility service. Turn it on in Krypton > Settings > Permissions.";
        if (ServerService.findModel(ctx) == null) return "No AI model is installed yet.";
        cancel = false; Llm.cancel = false; goal = g; status = "starting";
        final Context c = ctx.getApplicationContext();
        worker = new Thread(() -> {
            String res; boolean ok = false;
            try { res = loop(c, g, src); ok = true; }
            catch (Fail e) { res = e.getMessage(); }
            catch (Exception e) { res = cancel ? "Stopped by you." : "Unexpected problem: " + e.getMessage(); }
            status = "idle";
            last = (ok ? "Done: " : "Stopped: ") + g + " - " + res;
            if (ok) Channel.send(c, src, "Done. " + res); else Channel.error(c, src, res);
        }, "planner");
        worker.start();
        return "Working on it: " + g + "\nSend /cancel to stop. I will report each step.";
    }

    static void check() { if (cancel) throw new Fail("Stopped by you."); }

    static void sleep(long ms) {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) { check(); try { Thread.sleep(100); } catch (InterruptedException e) { throw new Fail("Interrupted."); } }
    }

    static boolean waitForeground(String pkg, int sec) {
        for (int i = 0; i < sec * 4; i++) {
            KryptonAccessibilityService s = KryptonAccessibilityService.instance;
            if (s != null && pkg.equals(s.currentPackage())) return true;
            sleep(250);
        }
        return false;
    }

    static void launch(Context c, String pkg) {
        Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) throw new Fail("I can't open that app: " + pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    static String loop(Context c, String goal, String src) throws Exception {
        String msg = null, person = null;
        Matcher sm = SEND.matcher(goal);
        if (sm.find()) { msg = sm.group(1) != null ? sm.group(1) : sm.group(2); person = sm.group(3).trim(); }
        List<String> hist = new ArrayList<>();
        Matcher om = OPEN.matcher(goal.trim());
        if (om.find()) {                                   // opening an app is deterministic, no AI needed
            String pkg = Apps.find(c, om.group(1));
            if (pkg == null) throw new Fail("I couldn't find an app named '" + om.group(1) + "' on this phone.");
            status = "opening " + Apps.label(c, pkg);
            Channel.progress(c, src, "Opening " + Apps.label(c, pkg) + "...");
            launch(c, pkg);
            if (!waitForeground(pkg, 10)) throw new Fail(Apps.label(c, pkg) + " did not come to the screen. I did not continue.");
            hist.add("Opened " + Apps.label(c, pkg) + " (verified on screen).");
            if (om.group(2) == null) return Apps.label(c, pkg) + " is open (verified).";
            goal = om.group(2).trim();
        }
        boolean sent = false;
        String lastTyped = null;
        int noChange = 0, fails = 0, doneTries = 0;
        for (int step = 1; step <= MAX_STEPS; step++) {
            check();
            status = "step " + step + "/" + MAX_STEPS;
            Screen.Snap s = Screen.snapshot(c, true);
            JSONObject a = Llm.json(c, prompt(goal, s, hist), SCHEMA);
            check();
            String act = a.optString("action", "wait"), why = a.optString("reason", "");
            Channel.progress(c, src, "Step " + step + ": " + describe(a, s));
            boolean expectChange = true;
            try {
                switch (act) {
                    case "done": {
                        String v = verify(c, goal, msg, sent);
                        if (v != null) return v;
                        if (++doneTries >= 2) throw new Fail("I could not verify that the task is complete, so I will not claim it is. Please check the phone screen.");
                        hist.add("I said done but it was not verified. Look at the screen again.");
                        continue;
                    }
                    case "fail": throw new Fail("I can't do this: " + (why.isEmpty() ? "no way found" : why));
                    case "ask": {
                        String adv = stuck(c, src, goal, why.isEmpty() ? "the model needs help" : why);
                        hist.add("Advice: " + adv);
                        continue;
                    }
                    case "wait": sleep(2000); expectChange = false; break;
                    case "back": case "home": KryptonAccessibilityService.instance.global(act); break;
                    case "scroll": KryptonAccessibilityService.instance.scroll(a.optString("direction", "down")); break;
                    case "open_app": {
                        String pkg = Apps.find(c, a.optString("app"));
                        if (pkg == null) throw new Exception("no app named " + a.optString("app"));
                        launch(c, pkg);
                        if (!waitForeground(pkg, 10)) throw new Exception(Apps.label(c, pkg) + " did not open");
                        break;
                    }
                    case "tap": {
                        Screen.Elem e = s.byId(a.optInt("id", -1));
                        if (e == null) throw new Exception("there is no element with that id");
                        if (e.label.toLowerCase(Locale.ROOT).matches("^(send|post|share|reply)$")) {
                            String text = msg != null ? msg : lastTyped;
                            if (person != null && !mentions(s, person))
                                throw new Fail("I could not verify that this chat is with " + person + ", so I did not send anything.");
                            if (text == null) throw new Exception("nothing has been typed yet");
                            if (!Guard.confirmBlocking(c, src, "Send \"" + text + "\"" + (person != null ? " to " + person : "") + " in " + Apps.label(c, s.pkg) + "?", false))
                                throw new Fail("Cancelled. I did not send anything.");
                            sent = true;
                            sleep(1500);                      // let Krypton step aside so the tap reaches the other app
                        }
                        KryptonAccessibilityService.instance.tapPoint(e.r.centerX(), e.r.centerY());
                        break;
                    }
                    case "type": {
                        Screen.Elem e = s.byId(a.optInt("id", -1));
                        String text = a.optString("text");
                        if (e == null) throw new Exception("there is no element with that id");
                        if (text.isEmpty()) throw new Exception("no text to type");
                        KryptonAccessibilityService.instance.tapPoint(e.r.centerX(), e.r.centerY());
                        sleep(700);
                        KryptonAccessibilityService.instance.type(text);
                        sleep(500);
                        if (!Screen.readable(Screen.snapshot(c, false)).toLowerCase(Locale.ROOT).contains(text.toLowerCase(Locale.ROOT)))
                            throw new Exception("the text did not appear in the field");
                        lastTyped = text;
                        break;
                    }
                    default: throw new Exception("unknown action " + act);
                }
                fails = 0;
                hist.add(describe(a, s) + " -> done");
            } catch (Fail f) { throw f; }
            catch (Exception ex) {
                fails++;
                hist.add("FAILED " + describe(a, s) + ": " + ex.getMessage());
                if (fails >= 3) hist.add("Advice: " + stuck(c, src, goal, "three actions failed in a row (" + ex.getMessage() + ")"));
                if (fails >= 3) fails = 0;
                continue;
            }
            sleep(1200);
            if (expectChange) {                              // verify the action had an effect
                if (Screen.snapshot(c, false).hash.equals(s.hash)) {
                    hist.add("The screen did not change after that action.");
                    if (++noChange >= 3) { hist.add("Advice: " + stuck(c, src, goal, "the screen stopped responding to my actions")); noChange = 0; }
                } else noChange = 0;
            }
            while (hist.size() > 10) hist.remove(0);
        }
        throw new Fail("I could not finish within " + MAX_STEPS + " steps, so I stopped. Nothing is claimed as done.");
    }

    static boolean mentions(Screen.Snap s, String person) {
        String t = Screen.readable(s).toLowerCase(Locale.ROOT);
        for (String w : person.toLowerCase(Locale.ROOT).split("\\s+")) if (w.length() >= 3 && !t.contains(w)) return false;
        return true;
    }

    /** The planner cannot continue: stop and ask the user to be more specific. */
    static String stuck(Context c, String src, String goal, String why) {
        throw new Fail("I'm stuck: " + why + ". Please tell me more exactly what to do (which app, which button, which person) and try again.");
    }

    /** Programmatic proof first (message visible in the chat), then the model checks the final screen. Null = not verified. */
    static String verify(Context c, String goal, String msg, boolean sent) throws Exception {
        sleep(1000);
        Screen.Snap s = Screen.snapshot(c, true);
        if (msg != null) {
            if (!sent) return null;
            for (Screen.Elem e : s.els)
                if (!e.edit && e.label.toLowerCase(Locale.ROOT).contains(msg.toLowerCase(Locale.ROOT)))
                    return "Message \"" + msg + "\" was sent and is visible in the chat (verified).";
            return null;
        }
        JSONArray m = new JSONArray();
        m.put(new JSONObject().put("role", "system").put("content", "You verify results on an Android screen. Answer only true if the screen clearly proves the goal is achieved."));
        m.put(new JSONObject().put("role", "user").put("content", "Goal: " + goal + "\nCurrent app: " + s.pkg + "\nScreen:\n" + Screen.describe(s)));
        JSONObject v = Llm.json(c, m, new JSONObject("{\"type\":\"object\",\"properties\":{\"complete\":{\"type\":\"boolean\"},\"evidence\":{\"type\":\"string\"}},\"required\":[\"complete\",\"evidence\"]}"));
        return v.optBoolean("complete") ? "Verified on screen: " + v.optString("evidence") : null;
    }

    static JSONObject SCHEMA;
    static {
        try {
            SCHEMA = new JSONObject("{\"type\":\"object\",\"properties\":{\"action\":{\"type\":\"string\",\"enum\":[\"tap\",\"type\",\"scroll\",\"back\",\"home\",\"open_app\",\"wait\",\"ask\",\"done\",\"fail\"]},"
                    + "\"id\":{\"type\":\"integer\"},\"text\":{\"type\":\"string\"},\"direction\":{\"type\":\"string\",\"enum\":[\"up\",\"down\"]},\"app\":{\"type\":\"string\"},\"reason\":{\"type\":\"string\"}},\"required\":[\"action\"]}");
        } catch (Exception e) { SCHEMA = new JSONObject(); }
    }

    static JSONArray prompt(String goal, Screen.Snap s, List<String> hist) throws Exception {
        String sys = "You control an Android phone to achieve the user's goal, one action per turn. Reply with JSON only.\n"
                + "Actions: tap{id}, type{id,text} (taps input field id, then types text), scroll{direction up|down}, back, home, open_app{app}, wait, ask{reason} when unsure or stuck, done{reason} when the goal is achieved, fail{reason}.\n"
                + "Rules: use only ids from the screen list. Never tap Send/Post/Share before the text is typed and the right person is visible. "
                + "If the item you need is not visible, use search or scroll. Do not repeat an action that did not change the screen.";
        StringBuilder u = new StringBuilder("Goal: ").append(goal).append("\n");
        if (!hist.isEmpty()) { u.append("Previous steps:\n"); for (String h : hist) u.append("- ").append(h).append('\n'); }
        u.append("Current app: ").append(s.pkg).append("\nScreen elements:\n").append(Screen.describe(s));
        return new JSONArray().put(new JSONObject().put("role", "system").put("content", sys))
                .put(new JSONObject().put("role", "user").put("content", u.toString()));
    }

    static String describe(JSONObject a, Screen.Snap s) {
        String act = a.optString("action");
        Screen.Elem e = s.byId(a.optInt("id", -1));
        String t = e == null ? "" : " \"" + Screen.cut(e.label, 30) + "\"";
        switch (act) {
            case "tap": return "tap" + t;
            case "type": return "type '" + Screen.cut(a.optString("text"), 40) + "' into" + t;
            case "scroll": return "scroll " + a.optString("direction", "down");
            case "open_app": return "open " + a.optString("app");
            default: return act + (a.optString("reason").isEmpty() ? "" : " (" + Screen.cut(a.optString("reason"), 60) + ")");
        }
    }
}
