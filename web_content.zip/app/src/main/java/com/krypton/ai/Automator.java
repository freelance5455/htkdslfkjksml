package com.krypton.ai;

import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import org.json.JSONArray;
import org.json.JSONObject;

/** Runs one automation at a time: open the target app, then the saved actions with waits, repeats and next-action rules. */
final class Automator {
    interface Done { void done(boolean ok, String msg); }

    static class Abort extends RuntimeException { Abort(String m) { super(m); } }

    static volatile Thread worker;
    static volatile boolean cancel;
    static volatile String name = "", last = "";
    static volatile int step, total, loop;
    static int executed;

    static boolean isRunning() { Thread t = worker; return t != null && t.isAlive(); }

    static void stop() { cancel = true; }

    static String statusText() {
        if (isRunning()) return "Running '" + name + "': action " + step + " of " + total + ", round " + loop + ".";
        return last.isEmpty() ? "No automation has run yet." : last;
    }

    /** Returns null when started, otherwise an error message. */
    static synchronized String start(final Context ctx, final JSONObject auto, final Done cb) {
        if (isRunning()) return "Automation '" + name + "' is already running. Stop it first.";
        if (KryptonAccessibilityService.instance == null)
            return "Automations need the Krypton Accessibility service. Open Krypton > Settings > Automations and turn it on.";
        cancel = false; executed = 0;
        name = auto.optString("name");
        final Context app = ctx.getApplicationContext();
        worker = new Thread(() -> {
            PowerManager.WakeLock wl = null;
            try {
                PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
                wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "krypton:auto");
                wl.acquire(30 * 60 * 1000L);       // turns the screen on while the automation runs
            } catch (Exception ignored) { }
            String err = null;
            try { runAuto(app, auto, 0); }
            catch (Abort e) { err = e.getMessage(); }
            catch (Exception e) { err = String.valueOf(e.getMessage()); }
            if (wl != null && wl.isHeld()) wl.release();
            boolean ok = err == null;
            last = ok ? "Automation '" + name + "' finished successfully."
                      : "Automation '" + name + "' stopped: " + err;
            if (cb != null) cb.done(ok, (ok ? "Done. " : "Failed. ") + last);
        }, "automation");
        worker.start();
        return null;
    }

    static void check() { if (cancel) throw new Abort("Stopped by user."); }

    static void sleep(double sec) {
        long end = System.currentTimeMillis() + (long) (Math.max(0, sec) * 1000);
        while (System.currentTimeMillis() < end) {
            check();
            try { Thread.sleep(100); } catch (InterruptedException e) { throw new Abort("Interrupted."); }
        }
    }

    static void openApp(String pkg) {
        KryptonAccessibilityService s = KryptonAccessibilityService.instance;
        if (s == null) throw new Abort("The Accessibility service is not running.");
        Intent i = s.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) throw new Abort("App is not installed: " + pkg);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        s.startActivity(i);
    }

    static void runAuto(Context c, JSONObject a, int depth) throws Exception {
        if (depth > 5) throw new Abort("Automations are nested too deeply.");
        String pkg = a.optString("app");
        if (!pkg.isEmpty()) { openApp(pkg); sleep(a.optDouble("launchWait", 3)); }
        JSONArray steps = a.optJSONArray("steps");
        if (steps == null) return;
        int repeat = a.optInt("repeat", 1);
        double gap = a.optDouble("repeatDelay", 1);
        if (depth == 0) total = steps.length();
        for (int r = 0; repeat == 0 || r < repeat; r++) {
            if (depth == 0) loop = r + 1;
            int i = 0;
            while (i < steps.length()) {
                check();
                JSONObject s = steps.getJSONObject(i);
                if (depth == 0) step = i + 1;
                int times = Math.max(1, s.optInt("repeat", 1));
                for (int k = 0; k < times; k++) {
                    check();
                    if (++executed > 20000) throw new Abort("Safety limit reached (20000 actions).");
                    try { perform(s); }
                    catch (Abort e) { throw e; }
                    catch (Exception e) { throw new Abort("action " + (i + 1) + " (" + s.optString("type") + "): " + e.getMessage()); }
                    sleep(s.optDouble("wait", 1));
                }
                String nx = s.optString("next", "next");
                if (nx.equals("stop")) return;
                if (nx.equals("goto")) {
                    int n = s.optInt("nextArg", 0);
                    if (n >= 1 && n <= steps.length()) { i = n - 1; continue; }
                }
                if (nx.equals("run")) {
                    JSONObject o = Automations.find(c, s.optString("nextArg"));
                    if (o == null) throw new Abort("Automation not found: " + s.optString("nextArg"));
                    runAuto(c, o, depth + 1);
                }
                i++;
            }
            if (repeat == 0 || r < repeat - 1) sleep(gap);
        }
    }

    static void perform(JSONObject s) throws Exception {
        KryptonAccessibilityService v = KryptonAccessibilityService.instance;
        if (v == null) throw new Abort("The Accessibility service is not running.");
        String t = s.optString("type");
        long dur = (long) s.optDouble("duration", 0);
        switch (t) {
            case "click": v.click(s.optString("x"), s.optString("y")); break;
            case "long_press": v.longPress(s.optString("x"), s.optString("y"), dur); break;
            case "swipe": v.swipe(s.optString("x"), s.optString("y"), s.optString("x2"), s.optString("y2"), dur); break;
            case "scroll": v.scroll(s.optString("dir", "down")); break;
            case "type": v.type(s.optString("text")); break;
            case "tap_text":
                if (!v.tapText(s.optString("text"), false)) throw new Exception("Nothing on screen matches '" + s.optString("text") + "'.");
                break;
            case "enter": v.enter(); break;
            case "open_app": openApp(s.optString("app")); break;
            case "back": case "home": case "recents": v.global(t); break;
            case "wait": break;
            default: throw new Exception("Unknown action type: " + t);
        }
    }
}
