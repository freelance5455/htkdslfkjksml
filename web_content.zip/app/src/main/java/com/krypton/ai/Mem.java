package com.krypton.ai;

import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Krypton memory (same structure as the Termux version): owner, permanent_knowledge, short_term (24h). */
final class Mem {
    static synchronized JSONObject load(Context c) {
        JSONObject o;
        try {
            String s = Store.read(c, "memory");
            o = new JSONObject(s.isEmpty() ? Store.DEFAULT_MEMORY : s);
        } catch (Exception e) { o = new JSONObject(); }
        try {
            if (!o.has("owner")) o.put("owner", "");
            if (o.optJSONArray("permanent_knowledge") == null) o.put("permanent_knowledge", new JSONArray());
            JSONArray st = o.optJSONArray("short_term"), keep = new JSONArray();
            double now = System.currentTimeMillis() / 1000.0;
            if (st != null) for (int i = 0; i < st.length(); i++) {
                JSONObject m = st.optJSONObject(i);
                if (m != null && now - m.optDouble("timestamp", 0) < 86400) keep.put(m);
            }
            o.put("short_term", keep);
        } catch (Exception ignored) { }
        return o;
    }

    static synchronized void save(Context c, JSONObject o) {
        try { Store.write(c, "memory.json", o.toString(2)); } catch (Exception ignored) { }
    }

    static List<String> items(Context c) {
        List<String> l = new ArrayList<>();
        JSONArray a = load(c).optJSONArray("permanent_knowledge");
        if (a != null) for (int i = 0; i < a.length(); i++) l.add(a.optString(i));
        return l;
    }

    static String owner(Context c) { return load(c).optString("owner", ""); }

    static synchronized boolean add(Context c, String t) {
        t = t.trim();
        if (t.isEmpty()) return false;
        JSONObject o = load(c);
        JSONArray a = o.optJSONArray("permanent_knowledge");
        String l = t.toLowerCase();
        for (int i = 0; i < a.length(); i++) {
            String x = a.optString(i).toLowerCase();
            if (x.contains(l) || l.contains(x)) return false;    // duplicate check, like Termux
        }
        a.put(t);
        save(c, o);
        return true;
    }

    static synchronized String forget(Context c, int n) {
        JSONObject o = load(c);
        JSONArray a = o.optJSONArray("permanent_knowledge");
        if (n < 1 || n > a.length()) return null;
        String r = a.optString(n - 1);
        a.remove(n - 1);
        save(c, o);
        return r;
    }

    static synchronized void setOwner(Context c, String name) {
        JSONObject o = load(c);
        try { o.put("owner", name); } catch (Exception ignored) { }
        save(c, o);
    }

    static synchronized void addShort(Context c, String user, String reply) {
        JSONObject o = load(c);
        try {
            JSONObject m = new JSONObject();
            m.put("timestamp", System.currentTimeMillis() / 1000.0);
            m.put("user", user);
            m.put("krypton", reply);
            o.getJSONArray("short_term").put(m);
        } catch (Exception ignored) { }
        save(c, o);
    }

    static List<String> search(Context c, String q) {
        List<String> r = new ArrayList<>();
        String l = q.toLowerCase();
        for (String s : items(c)) if (s.toLowerCase().contains(l)) r.add(s);
        return r;
    }

    static String cut(String s, int n) { return s.length() > n ? s.substring(0, n) : s; }

    static String prompt(Context c, boolean first) { return prompt(c, first, false); }

    /** remote = Telegram or Gmail: talk like a normal assistant and never bring up the app, the phone or device access. */
    static String prompt(Context c, boolean first, boolean remote) {
        JSONObject o = load(c);
        StringBuilder s = new StringBuilder(remote
                ? "You are Krypton, a friendly and capable personal AI assistant. Answer the user's questions directly, naturally and helpfully, like a knowledgeable friend. "
                  + "Reply in English unless the user asks for another language. Do not mention apps, phones, screens or device access unless the user asks about them. "
                  + "When asked for code, write the complete working code in markdown code blocks and never shorten it. "
                : "You are Krypton, a personal AI assistant that runs fully offline on the user's phone. "
                  + "Reply in English unless the user asks for another language. Be clear, correct and helpful. "
                  + "When asked for code, write the complete working code in markdown code blocks and never shorten it, "
                  + "skip parts or say \"rest of the code here\". ");
        String owner = o.optString("owner", "");
        if (!owner.isEmpty()) s.append("The user's name is ").append(owner).append(". ");
        JSONArray k = o.optJSONArray("permanent_knowledge");
        if (k != null && k.length() > 0) {
            s.append("\nThings you remember about the user:\n");
            for (int i = Math.max(0, k.length() - 30); i < k.length(); i++) s.append("- ").append(k.optString(i)).append('\n');
        }
        JSONArray st = o.optJSONArray("short_term");
        if (first && st != null && st.length() > 0) {
            s.append("\nRecent conversations (last 24 hours):\n");
            for (int i = Math.max(0, st.length() - 3); i < st.length(); i++) {
                JSONObject m = st.optJSONObject(i);
                s.append("User: ").append(cut(m.optString("user"), 160)).append("\nKrypton: ").append(cut(m.optString("krypton"), 160)).append('\n');
            }
        }
        if (remote) s.append("\nOnly when the user asks, you can add one of these on its own line: [[remember: fact]] to remember a fact, or [[remind: N | text]] to set a reminder in N minutes.");
        else s.append("\nPhone actions: only when the user asks, you can add one of these on its own line. "
                + "To save a fact: [[remember: fact]]. To send a notification now: [[notify: text]]. "
                + "To remind after N minutes: [[remind: N | text]].");
        return s.toString();
    }
}
