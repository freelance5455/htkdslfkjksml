package com.krypton.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import android.graphics.Bitmap;
import android.hardware.HardwareBuffer;

/** Performs taps, swipes, scrolls and typing for Krypton automations. */
public class KryptonAccessibilityService extends AccessibilityService {
    static volatile KryptonAccessibilityService instance;

    @Override protected void onServiceConnected() { instance = this; }
    @Override public boolean onUnbind(Intent i) { instance = null; return super.onUnbind(i); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    int w() { return getResources().getDisplayMetrics().widthPixels; }
    int h() { return getResources().getDisplayMetrics().heightPixels; }

    /** "540" = pixels, "50%" = percent of the screen. */
    static float coord(String v, int dim) throws Exception {
        try {
            v = v.trim();
            if (v.endsWith("%")) return Float.parseFloat(v.substring(0, v.length() - 1).trim()) * dim / 100f;
            return Float.parseFloat(v);
        } catch (NumberFormatException e) { throw new Exception("Invalid coordinate: '" + v + "'"); }
    }

    boolean stroke(Path p, long dur) {
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(1, dur))).build();
        final CountDownLatch l = new CountDownLatch(1);
        final boolean[] ok = {false};
        boolean sent = dispatchGesture(g, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription d) { ok[0] = true; l.countDown(); }
            @Override public void onCancelled(GestureDescription d) { l.countDown(); }
        }, null);
        if (!sent) return false;
        try { l.await(dur + 5000, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { return false; }
        return ok[0];
    }

    void tapAt(float x, float y, long dur) throws Exception {
        Path p = new Path();
        p.moveTo(x, y);
        if (!stroke(p, dur)) throw new Exception("The screen touch was not performed (is the screen on and unlocked?)");
    }

    void click(String x, String y) throws Exception { tapAt(coord(x, w()), coord(y, h()), 60); }

    void longPress(String x, String y, long ms) throws Exception { tapAt(coord(x, w()), coord(y, h()), ms > 0 ? ms : 1000); }

    void swipeF(float x1, float y1, float x2, float y2, long ms) throws Exception {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        if (!stroke(p, ms > 0 ? ms : 400)) throw new Exception("The swipe was not performed (is the screen on and unlocked?)");
    }

    void swipe(String x1, String y1, String x2, String y2, long ms) throws Exception {
        swipeF(coord(x1, w()), coord(y1, h()), coord(x2, w()), coord(y2, h()), ms);
    }

    /** "down" = show content further down (the finger moves up). */
    void scroll(String dir) throws Exception {
        float cx = w() / 2f, cy = h() / 2f, dx = w() * 0.3f, dy = h() * 0.3f;
        switch (dir) {
            case "up": swipeF(cx, cy - dy, cx, cy + dy, 400); break;
            case "left": swipeF(cx - dx, cy, cx + dx, cy, 400); break;
            case "right": swipeF(cx + dx, cy, cx - dx, cy, 400); break;
            default: swipeF(cx, cy + dy, cx, cy - dy, 400);
        }
    }

    AccessibilityNodeInfo firstEditable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 25) return null;
        if (n.isEditable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = firstEditable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    AccessibilityNodeInfo findInput() {
        AccessibilityNodeInfo root = appRoot();
        if (root == null) return null;
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        return f != null ? f : firstEditable(root, 0);
    }

    void type(String text) throws Exception {
        AccessibilityNodeInfo n = findInput();
        if (n == null) throw new Exception("No text box found. Click the text box first.");
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
        if (!n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) throw new Exception("Could not type into the text box.");
    }

    List<AccessibilityNodeInfo> roots(boolean keyboardOnly) {
        List<AccessibilityNodeInfo> r = new ArrayList<>();
        if (!keyboardOnly) {
            AccessibilityNodeInfo a = appRoot();
            if (a != null) r.add(a);
        }
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) for (AccessibilityWindowInfo w : ws) {
            if (keyboardOnly && w.getType() != AccessibilityWindowInfo.TYPE_INPUT_METHOD) continue;
            AccessibilityNodeInfo wr = w.getRoot();
            if (wr != null && !r.contains(wr)) r.add(wr);
        }
        return r;
    }

    boolean clickNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo t = n;
        while (t != null && !t.isClickable()) t = t.getParent();
        if (t != null && t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
        try {
            Rect b = new Rect();
            n.getBoundsInScreen(b);
            tapAt(b.centerX(), b.centerY(), 60);
            return true;
        } catch (Exception e) { return false; }
    }

    boolean tapText(String text, boolean keyboardOnly) {
        for (AccessibilityNodeInfo root : roots(keyboardOnly)) {
            List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(text);
            if (found != null) for (AccessibilityNodeInfo n : found) if (clickNode(n)) return true;
        }
        return false;
    }

    void enter() throws Exception {
        if (Build.VERSION.SDK_INT >= 30) {
            AccessibilityNodeInfo f = findInput();
            if (f != null && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())) return;
        }
        for (String l : new String[]{"Search", "Go", "Done", "Enter", "Send", "Next"})
            if (tapText(l, true)) return;
        throw new Exception("Could not press Enter/Search. Use a Click action on the keyboard's search key instead.");
    }

    void global(String what) throws Exception {
        int a = what.equals("home") ? GLOBAL_ACTION_HOME : what.equals("recents") ? GLOBAL_ACTION_RECENTS : GLOBAL_ACTION_BACK;
        if (!performGlobalAction(a)) throw new Exception("Could not press the " + what + " button.");
    }
    // ---------- reading the screen ----------

    /** Root of the foreground app window. Krypton's own overlay windows are skipped. */
    AccessibilityNodeInfo appRoot() {
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) for (AccessibilityWindowInfo w : ws) {
            if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
            AccessibilityNodeInfo r = w.getRoot();
            if (r != null && !getPackageName().contentEquals(r.getPackageName() == null ? "" : r.getPackageName())) return r;
        }
        return getRootInActiveWindow();
    }

    String currentPackage() {
        AccessibilityNodeInfo r = appRoot();
        return r == null || r.getPackageName() == null ? "" : r.getPackageName().toString();
    }

    /** Visible, meaningful UI elements of the foreground window (dynamic: positions come from the live screen). */
    List<Screen.Elem> elements() {
        List<Screen.Elem> out = new ArrayList<>();
        AccessibilityNodeInfo root = appRoot();
        if (root != null) collect(root, out, 0, new int[]{0});
        Collections.sort(out, new Comparator<Screen.Elem>() {
            @Override public int compare(Screen.Elem a, Screen.Elem b) {
                return a.r.top != b.r.top ? Integer.compare(a.r.top, b.r.top) : Integer.compare(a.r.left, b.r.left);
            }
        });
        return out.size() > 60 ? new ArrayList<>(out.subList(0, 60)) : out;
    }

    void collect(AccessibilityNodeInfo n, List<Screen.Elem> out, int depth, int[] visited) {
        if (n == null || depth > 40 || visited[0]++ > 700 || out.size() > 120) return;
        if (n.isVisibleToUser()) {
            CharSequence t = n.getText(), d = n.getContentDescription();
            String label = t != null && t.length() > 0 ? t.toString() : d != null ? d.toString() : "";
            if (label.isEmpty() && (n.isEditable() || n.isClickable()) && n.getViewIdResourceName() != null) {
                String id = n.getViewIdResourceName();
                label = id.substring(id.indexOf('/') + 1).replace('_', ' ');
            }
            label = label.replace('\n', ' ').trim();
            Rect b = new Rect();
            n.getBoundsInScreen(b);
            if ((!label.isEmpty() || n.isEditable()) && b.width() > 0 && b.height() > 0) {
                Screen.Elem e = new Screen.Elem();
                e.label = label.length() > 80 ? label.substring(0, 80) : label;
                e.r = b; e.click = n.isClickable(); e.edit = n.isEditable();
                e.kind = e.edit ? "input" : e.click ? "button" : "text";
                boolean dup = false;
                for (Screen.Elem o : out) if (o.label.equals(e.label) && o.r.equals(e.r)) { dup = true; break; }
                if (!dup) out.add(e);
            }
        }
        for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), out, depth + 1, visited);
    }

    /** Screenshot through the accessibility service (Android 11+). */
    Bitmap shot() throws Exception {
        if (Build.VERSION.SDK_INT < 30) throw new Exception("Accessibility screenshots need Android 11 or newer.");
        final Bitmap[] out = new Bitmap[1];
        final String[] err = {null};
        final CountDownLatch l = new CountDownLatch(1);
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult r) {
                try {
                    HardwareBuffer hb = r.getHardwareBuffer();
                    Bitmap hw = Bitmap.wrapHardwareBuffer(hb, r.getColorSpace());
                    out[0] = hw == null ? null : hw.copy(Bitmap.Config.ARGB_8888, false);
                    hb.close();
                } catch (Exception e) { err[0] = e.getMessage(); }
                l.countDown();
            }
            @Override public void onFailure(int code) { err[0] = "The screenshot was refused (code " + code + ")."; l.countDown(); }
        });
        if (!l.await(8, TimeUnit.SECONDS)) throw new Exception("The screenshot timed out.");
        if (out[0] == null) throw new Exception(err[0] != null ? err[0] : "The screenshot failed (the app may block screenshots).");
        return out[0];
    }

    void tapPoint(float x, float y) throws Exception { tapAt(x, y, 60); }
}
