package com.krypton.ai;

import android.content.Context;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Saved custom automations (the form in Settings -> Automations). */
final class Automations {
    static synchronized JSONArray load(Context c) {
        try {
            String s = Store.read(c, "automations");
            return new JSONArray(s.isEmpty() ? "[]" : s);
        } catch (Exception e) { return new JSONArray(); }
    }

    static synchronized void saveAll(Context c, JSONArray a) { Store.write(c, "automations.json", a.toString()); }

    static String norm(String s) {
        return s.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", " ").replaceAll("[.!?]+$", "");
    }

    /** Returns "" on success or an error message. */
    static synchronized String saveOne(Context c, String json) {
        try {
            JSONObject a = new JSONObject(json);
            String name = a.optString("name").trim(), cmd = a.optString("command").trim();
            if (name.isEmpty()) return "Please enter an automation name.";
            if (cmd.isEmpty()) return "Please enter an active command.";
            if (cmd.startsWith("/")) return "The active command cannot start with /. Use plain words, for example: open youtube";
            JSONArray steps = a.optJSONArray("steps");
            if ((steps == null || steps.length() == 0) && a.optString("app").isEmpty())
                return "Add at least one action or choose a target app.";
            JSONArray all = load(c);
            String id = a.optString("id");
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.getJSONObject(i);
                if (o.optString("id").equals(id)) continue;
                if (norm(o.optString("command")).equals(norm(cmd))) return "Another automation already uses this command.";
                if (o.optString("name").equalsIgnoreCase(name)) return "Another automation already has this name.";
            }
            if (id.isEmpty()) id = "a" + System.currentTimeMillis();
            a.put("id", id); a.put("name", name); a.put("command", cmd);
            JSONArray out = new JSONArray();
            boolean replaced = false;
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.getJSONObject(i);
                if (o.optString("id").equals(id)) { out.put(a); replaced = true; } else out.put(o);
            }
            if (!replaced) out.put(a);
            saveAll(c, out);
            return "";
        } catch (Exception e) { return "Could not save: " + e.getMessage(); }
    }

    static synchronized boolean delete(Context c, String key) {
        JSONObject t = find(c, key);
        if (t == null) return false;
        JSONArray all = load(c), out = new JSONArray();
        for (int i = 0; i < all.length(); i++)
            if (!all.optJSONObject(i).optString("id").equals(t.optString("id"))) out.put(all.optJSONObject(i));
        saveAll(c, out);
        return true;
    }

    static synchronized boolean setEnabled(Context c, String key, boolean on) {
        JSONObject t = find(c, key);
        if (t == null) return false;
        try { t.put("enabled", on); } catch (Exception ignored) { }
        JSONArray all = load(c), out = new JSONArray();
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            out.put(o.optString("id").equals(t.optString("id")) ? t : o);
        }
        saveAll(c, out);
        return true;
    }

    /** Find by id, then exact name, then name prefix, then name contains. */
    static JSONObject find(Context c, String key) {
        String k = key.trim().toLowerCase(Locale.ROOT);
        if (k.isEmpty()) return null;
        JSONArray all = load(c);
        for (int pass = 0; pass < 4; pass++)
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.optJSONObject(i);
                String n = o.optString("name").toLowerCase(Locale.ROOT);
                if (pass == 0 && o.optString("id").equals(key.trim())) return o;
                if (pass == 1 && n.equals(k)) return o;
                if (pass == 2 && n.startsWith(k)) return o;
                if (pass == 3 && n.contains(k)) return o;
            }
        return null;
    }

    /** The enabled automation whose Active Command equals this text. */
    static JSONObject matchCommand(Context c, String text) {
        String t = norm(text);
        JSONArray all = load(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject o = all.optJSONObject(i);
            if (o.optBoolean("enabled", true) && norm(o.optString("command")).equals(t)) return o;
        }
        return null;
    }
}
