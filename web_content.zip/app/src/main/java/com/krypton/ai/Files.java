package com.krypton.ai;

import android.os.Environment;
import java.io.File;

final class Files {
    /** Newest screenshot from the usual folders (MIUI: DCIM/Screenshots). Needs storage access. */
    static File latestScreenshot() {
        File root = Environment.getExternalStorageDirectory();
        String[] dirs = {"DCIM/Screenshots", "Pictures/Screenshots", "DCIM/Screenshot", "Pictures/Screenshot", "MIUI/screen_cap"};
        File best = null;
        for (String d : dirs) {
            File[] fs = new File(root, d).listFiles((x, n) -> {
                String l = n.toLowerCase();
                return l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".webp");
            });
            if (fs != null) for (File f : fs) if (f.isFile() && (best == null || f.lastModified() > best.lastModified())) best = f;
        }
        return best;
    }

    static File receivedDir(android.content.Context c) {
        File d = new File(Environment.getExternalStorageDirectory(), "Krypton/Received");
        if ((d.exists() || d.mkdirs()) && d.canWrite()) return d;
        File f = new File(c.getFilesDir(), "received");
        f.mkdirs();
        return f;
    }
}
