package com.krypton.ai;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Telegram Bot API remote control. Every user enters their OWN bot token and User ID.
 * The token is encrypted with an Android Keystore key, kept only inside this app's private storage,
 * never put in backups and never handed to the web UI. Only messages from the configured User ID
 * (in a private chat) are processed. Everything else is ignored.
 */
final class Telegram {
    static final String PREFS = "krypton_tg", ALIAS = "krypton_tg_key";
    static volatile String state = "disconnected", error = "", bot = "";
    static volatile int blocked = 0;
    static volatile String current = null, lastTask = "", lastResult = "", lastError = "";
    static volatile long lastTime = 0;
    static volatile boolean running = false;
    static Thread poller;
    static final ExecutorService worker = Executors.newSingleThreadExecutor();

    // ---------- secure config ----------

    static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256).build());
            kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    static String enc(String s) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        byte[] ct = c.doFinal(s.getBytes("UTF-8"));
        return Base64.encodeToString(c.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
    }

    static String dec(String s) throws Exception {
        String[] p = s.split(":");
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
        return new String(c.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), "UTF-8");
    }

    static SharedPreferences prefs(Context c) { return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static JSONObject config(Context c) {
        try {
            String s = prefs(c).getString("cfg", null);
            return s == null ? null : new JSONObject(dec(s));
        } catch (Exception e) { return null; }
    }

    static void saveConfig(Context c, String token, long uid, boolean allow, String botName) throws Exception {
        JSONObject o = obj("token", token, "uid", uid, "allow", allow, "bot", botName);
        prefs(c).edit().putString("cfg", enc(o.toString())).commit();
    }

    static boolean allowDevice(Context c) {
        JSONObject cfg = config(c);
        return cfg != null && cfg.optBoolean("allow", true);
    }

    /** Status for the settings screen. The token itself is never included, only the last 4 characters. */
    static String statusJson(Context c) {
        JSONObject cfg = config(c);
        JSONObject o = obj("state", state, "error", error, "configured", cfg != null, "blocked", blocked);
        try {
            if (cfg != null) {
                String t = cfg.optString("token");
                o.put("bot", cfg.optString("bot"));
                o.put("userId", cfg.optLong("uid"));
                o.put("allow", cfg.optBoolean("allow", true));
                o.put("tokenMask", "\u2022\u2022\u2022\u2022" + t.substring(Math.max(0, t.length() - 4)));
            }
        } catch (JSONException ignored) { }
        return o.toString();
    }

    static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        try { for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]); } catch (JSONException ignored) { }
        return o;
    }

    static String safe(String m, String token) {
        if (m == null) return "unknown error";
        return token == null || token.isEmpty() ? m : m.replace(token, "***");
    }

    // ---------- Bot API ----------

    static JSONObject api(String token, String method, JSONObject body, int readMs) throws IOException {
        HttpURLConnection h = (HttpURLConnection) new URL("https://api.telegram.org/bot" + token + "/" + method).openConnection();
        try {
            h.setConnectTimeout(15000);
            h.setReadTimeout(readMs);
            h.setRequestMethod("POST");
            h.setDoOutput(true);
            h.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            try (OutputStream o = h.getOutputStream()) { o.write((body == null ? "{}" : body.toString()).getBytes("UTF-8")); }
            int code = h.getResponseCode();
            InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
            String s = in == null ? "" : new String(Store.readAll(in), "UTF-8");
            try { return new JSONObject(s); }
            catch (JSONException e) { return obj("ok", false, "error_code", code, "description", "HTTP " + code); }
        } finally { h.disconnect(); }
    }

    // ---------- connect / disconnect ----------

    static void connect(final Context ctx, String tokenIn, final String uidIn, final boolean allow) {
        final Context c = ctx.getApplicationContext();
        state = "connecting"; error = "";
        final String tIn = tokenIn == null ? "" : tokenIn.trim();
        new Thread(() -> {
            String token = tIn;
            try {
                if (token.isEmpty()) { JSONObject old = config(c); if (old != null) token = old.optString("token"); }
                if (!token.matches("\\d{5,15}:[A-Za-z0-9_-]{30,}")) { fail("The bot token looks wrong. Copy it again from @BotFather (it looks like 123456789:ABC...)."); return; }
                String uidS = uidIn == null ? "" : uidIn.trim();
                if (!uidS.matches("\\d{4,15}")) { fail("The Telegram User ID must be a number. You can get it from @userinfobot."); return; }
                long uid = Long.parseLong(uidS);

                JSONObject me = api(token, "getMe", null, 20000);
                if (!me.optBoolean("ok")) { fail("Telegram rejected the token: " + me.optString("description", "unknown error")); return; }
                String botName = me.optJSONObject("result").optString("username");

                JSONObject t = api(token, "sendMessage", obj("chat_id", uid, "text",
                        "Krypton is connected to this chat. Send /help to see what I can do."), 20000);
                if (!t.optBoolean("ok")) {
                    fail("Could not message this User ID (" + t.optString("description") + "). Open @" + botName
                            + " in Telegram, press Start, then tap Connect Bot again.");
                    return;
                }
                saveConfig(c, token, uid, allow, botName);
                bot = botName;
                try {
                    JSONArray cmds = new JSONArray();
                    String[][] list = {{"help", "Show all commands"}, {"status", "What Krypton is doing now"}, {"cancel", "Cancel current task"},
                            {"new", "Fresh conversation"}, {"memory", "Show memory"}, {"reminders", "Pending reminders"},
                            {"auto", "Automations: list, run, stop, status"}, {"battery", "Battery level"}};
                    for (String[] r : list) cmds.put(obj("command", r[0], "description", r[1]));
                    api(token, "setMyCommands", obj("commands", cmds), 20000);
                } catch (Exception ignored) { }
                state = "connected"; error = "";
                startPolling(c);
                try { c.startForegroundService(new Intent(c, ServerService.class)); } catch (Exception ignored) { }
            } catch (IOException e) {
                fail("Network error: " + safe(e.getMessage(), token) + ". Check your internet connection.");
            } catch (Exception e) {
                fail("Could not save the settings securely: " + safe(e.getMessage(), token));
            }
        }, "tg-connect").start();
    }

    static void fail(String msg) { state = "error"; error = msg; }

    static void disconnect(Context c) {
        running = false;
        prefs(c).edit().clear().commit();
        state = "disconnected"; error = ""; bot = ""; blocked = 0;
    }

    // ---------- polling ----------

    static void autostart(Context c) { if (config(c) != null) startPolling(c.getApplicationContext()); }

    static void shutdown() { running = false; if (!"error".equals(state)) state = "stopped"; }

    static synchronized void startPolling(final Context c) {
        running = true;
        if (poller != null && poller.isAlive()) return;
        if ("disconnected".equals(state) || "stopped".equals(state)) state = "connecting";
        poller = new Thread(() -> pollLoop(c), "tg-poll");
        poller.start();
    }

    static void nap(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) { } }

    static void pollLoop(Context c) {
        while (running) {
            JSONObject cfg = config(c);
            if (cfg == null) { state = "disconnected"; break; }
            String token = cfg.optString("token");
            long owner = cfg.optLong("uid");
            try {
                long offset = prefs(c).getLong("offset", 0);
                JSONObject r = api(token, "getUpdates", obj("offset", offset, "timeout", 30,
                        "allowed_updates", new JSONArray().put("message")), 45000);
                if (!r.optBoolean("ok")) {
                    int code = r.optInt("error_code");
                    if (code == 401) { fail("The bot token is invalid or was revoked. Reconnect with a new token."); running = false; break; }
                    if (code == 409) fail("Another program is using this bot right now (conflict). Stop the other one."); 
                    else fail("Telegram error " + code + ": " + r.optString("description"));
                    nap(8000);
                    continue;
                }
                state = "connected"; error = "";
                JSONArray u = r.optJSONArray("result");
                int skipped = 0;
                for (int i = 0; u != null && i < u.length(); i++) {
                    JSONObject up = u.getJSONObject(i);
                    offset = up.optLong("update_id") + 1;
                    prefs(c).edit().putLong("offset", offset).commit();
                    JSONObject m = up.optJSONObject("message");
                    if (m != null && onMessage(c, token, owner, m)) skipped++;
                }
                if (skipped > 0) send(token, owner, "Skipped " + skipped + " old message(s) that arrived more than 15 minutes ago.");
            } catch (IOException e) {
                if (!running) break;
                fail("Network problem, retrying: " + safe(e.getMessage(), token));
                nap(6000);
            } catch (Exception e) {
                fail("Unexpected error: " + safe(e.getMessage(), token));
                nap(4000);
            }
        }
        poller = null;
    }

    /** Returns true if the message was skipped because it was too old. */
    static boolean onMessage(final Context c, final String token, long owner, JSONObject m) {
        JSONObject from = m.optJSONObject("from"), chat = m.optJSONObject("chat");
        long fromId = from == null ? 0 : from.optLong("id"), chatId = chat == null ? 0 : chat.optLong("id");
        boolean priv = chat != null && "private".equals(chat.optString("type"));
        if (from == null || from.optBoolean("is_bot") || fromId != owner || !priv || chatId != owner) {
            blocked++;                       // not the owner: ignored completely
            return false;
        }
        if (System.currentTimeMillis() - m.optLong("date") * 1000L > 15 * 60 * 1000L) return true;
        final String text = m.optString("text", "").trim();
        final long cid = chatId;
        if (text.isEmpty()) {
            if (m.has("photo") || m.has("document")) { receiveFile(c, token, cid, m); return false; }
            send(token, cid, "I can only read text, photos and documents for now.");
            return false;
        }
        try {
            if (Guard.hasPending("telegram") && !text.startsWith("/")) {   // this message answers an approval request
                boolean pw = Guard.needsPassword("telegram");
                String reply = Guard.answer(c, "telegram", text);
                if (pw) deleteMessage(token, cid, m.optLong("message_id"));   // remove the password from the chat
                record("Approval", reply.startsWith("Error") ? "error" : "OK", "");
                send(token, cid, reply);
                return false;
            }
            if (text.startsWith("/")) {
                String reply = Commands.run(c, text, "telegram");
                record("Command " + text.split("\\s+")[0], reply.startsWith("Error") ? "error" : "OK", reply.startsWith("Error") ? reply : "");
                send(token, cid, reply);
                return false;
            }
            String r = Commands.route(c, text, "telegram");
            if (r != null) { record("Action: " + cut(text, 40), "OK", ""); send(token, cid, r); return false; }
        } catch (Exception e) {
            record("Command", "error", String.valueOf(e.getMessage()));
            send(token, cid, "Error: " + e.getMessage());
            return false;
        }
        worker.submit(() -> aiJob(c, token, cid, text, null));
        return false;
    }

    static String cut(String s, int n) { return s.length() > n ? s.substring(0, n) + "..." : s; }

    static void record(String task, String result, String err) {
        lastTask = task; lastResult = result; lastTime = System.currentTimeMillis();
        if (!err.isEmpty()) lastError = err;
    }

    // ---------- files and screenshots ----------

    static void deleteMessage(String token, long chat, long messageId) {
        try { api(token, "deleteMessage", obj("chat_id", chat, "message_id", messageId), 15000); } catch (Exception ignored) { }
    }

    /** Photos and documents you send to the bot are saved on the phone (Krypton/Received). */
    static void receiveFile(Context c, String token, long chat, JSONObject m) {
        try {
            String id, name;
            if (m.has("photo")) {
                JSONArray ph = m.getJSONArray("photo");
                id = ph.getJSONObject(ph.length() - 1).optString("file_id");
                name = "photo_" + System.currentTimeMillis() + ".jpg";
            } else {
                JSONObject d = m.getJSONObject("document");
                id = d.optString("file_id");
                name = d.optString("file_name", "file_" + System.currentTimeMillis()).replaceAll("[^A-Za-z0-9._-]", "_");
            }
            JSONObject r = api(token, "getFile", obj("file_id", id), 20000);
            if (!r.optBoolean("ok")) { send(token, chat, "Telegram would not give me that file: " + r.optString("description")); return; }
            String path = r.getJSONObject("result").optString("file_path");
            File out = new File(Files.receivedDir(c), name);
            HttpURLConnection h = (HttpURLConnection) new URL("https://api.telegram.org/file/bot" + token + "/" + path).openConnection();
            h.setConnectTimeout(15000); h.setReadTimeout(120000);
            try (InputStream in = h.getInputStream(); java.io.FileOutputStream o = new java.io.FileOutputStream(out)) {
                byte[] b = new byte[65536]; int n;
                while ((n = in.read(b)) > 0) o.write(b, 0, n);
            } finally { h.disconnect(); }
            if (!out.exists() || out.length() == 0) { send(token, chat, "The file did not save correctly."); return; }
            record("Received " + name, "OK", "");
            String low = name.toLowerCase();
            boolean image = m.has("photo") || low.endsWith(".jpg") || low.endsWith(".jpeg") || low.endsWith(".png") || low.endsWith(".webp");
            if (image && Vision.available(c)) {
                try {
                    final String imgId = ImageStore.importFile(c, out);
                    final String q = m.optString("caption", "").trim().isEmpty() ? Assistant.DEFAULT_Q : m.optString("caption").trim();
                    final String tk = token;
                    final long cid = chat;
                    worker.submit(() -> aiJob(c, tk, cid, q, imgId));
                    return;
                } catch (Exception ie) { send(token, chat, "I saved the file but could not read it as a picture: " + ie.getMessage()); return; }
            }
            send(token, chat, image ? "Saved " + name + ". I can't look at pictures yet because no vision model has been set up." : "Saved " + name + " (" + out.length() / 1024 + " KB) to " + out.getPath());
        } catch (Exception e) {
            record("Receive file", "error", safe(e.getMessage(), token));
            send(token, chat, "Could not receive the file: " + safe(e.getMessage(), token));
        }
    }

    /** Uploads a file to the owner's chat. Returns null only if Telegram confirmed delivery, otherwise an error text. */
    static String sendFileToOwner(Context c, File f, String caption, boolean photo) {
        JSONObject cfg = config(c);
        if (cfg == null) return "Telegram is not connected.";
        return sendFile(cfg.optString("token"), cfg.optLong("uid"), f, caption, photo && f.length() < 9 * 1024 * 1024);
    }

    static String sendFile(String token, long chat, File f, String caption, boolean photo) {
        String boundary = "----krypton" + System.currentTimeMillis();
        try {
            if (!f.isFile()) return "the file does not exist";
            if (f.length() > 49L * 1024 * 1024) return "the file is bigger than Telegram's 50 MB bot limit";
            HttpURLConnection h = (HttpURLConnection) new URL("https://api.telegram.org/bot" + token + "/" + (photo ? "sendPhoto" : "sendDocument")).openConnection();
            h.setConnectTimeout(20000); h.setReadTimeout(180000);
            h.setRequestMethod("POST"); h.setDoOutput(true); h.setChunkedStreamingMode(65536);
            h.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            try (OutputStream o = h.getOutputStream()) {
                String head = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n" + chat + "\r\n"
                        + "--" + boundary + "\r\nContent-Disposition: form-data; name=\"caption\"\r\n\r\n" + caption + "\r\n"
                        + "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + (photo ? "photo" : "document") + "\"; filename=\""
                        + f.getName().replace('"', '_') + "\"\r\nContent-Type: application/octet-stream\r\n\r\n";
                o.write(head.getBytes("UTF-8"));
                try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                    byte[] b = new byte[65536]; int n;
                    while ((n = in.read(b)) > 0) o.write(b, 0, n);
                }
                o.write(("\r\n--" + boundary + "--\r\n").getBytes("UTF-8"));
            }
            int code = h.getResponseCode();
            String s = new String(Store.readAll(code >= 400 ? h.getErrorStream() : h.getInputStream()), "UTF-8");
            h.disconnect();
            JSONObject r = new JSONObject(s);
            return r.optBoolean("ok") ? null : r.optString("description", "Telegram refused the file");
        } catch (Exception e) { return safe(e.getMessage(), token); }
    }

    // ---------- AI chat ----------

    static File histFile(Context c) { return new File(c.getFilesDir(), "tg_history.json"); }

    static synchronized JSONArray loadHist(Context c) {
        File f = histFile(c);
        if (!f.exists()) return new JSONArray();
        try (FileInputStream in = new FileInputStream(f)) { return new JSONArray(new String(Store.readAll(in), "UTF-8")); }
        catch (Exception e) { return new JSONArray(); }
    }

    static synchronized void saveHist(Context c, JSONArray a) {
        try {
            JSONArray out = new JSONArray();
            for (int i = Math.max(0, a.length() - 20); i < a.length(); i++) out.put(a.get(i));
            try (java.io.FileOutputStream o = new java.io.FileOutputStream(histFile(c))) { o.write(out.toString().getBytes("UTF-8")); }
        } catch (Exception ignored) { }
    }

    static void resetHistory(Context c) { histFile(c).delete(); ImageStore.clearSticky("telegram"); }

    static JSONArray buildMessages(Context c, JSONArray hist) throws JSONException {
        List<JSONObject> sel = new ArrayList<>();
        int n = 0;
        for (int i = hist.length() - 1; i >= 0; i--) {
            JSONObject m = hist.getJSONObject(i);
            String t = m.optString("content");
            if (t.length() > 9000) t = t.substring(0, 3000) + "\n...[shortened]...\n" + t.substring(t.length() - 5500);
            if (!sel.isEmpty() && n + t.length() > 12000) break;
            sel.add(obj("role", m.optString("role"), "content", t));
            n += t.length();
        }
        Collections.reverse(sel);
        JSONArray msgs = new JSONArray();
        msgs.put(obj("role", "system", "content", Mem.prompt(c, hist.length() <= 1, true)));
        for (JSONObject o : sel) msgs.put(o);
        return msgs;
    }

    static void aiJob(Context c, String token, long chatId, String text, String imgId) {
        current = (imgId != null || ImageStore.stickyActive("telegram") ? "Looking at a picture: " : "Answering: ") + cut(text, 50);
        final boolean[] stop = {false};
        final String tk = token;
        final long cid = chatId;
        Thread typing = new Thread(() -> {
            while (!stop[0]) {
                try { api(tk, "sendChatAction", obj("chat_id", cid, "action", "typing"), 10000); } catch (Exception ignored) { }
                for (int i = 0; i < 8 && !stop[0]; i++) nap(500);
            }
        });
        typing.setDaemon(true);
        typing.start();
        try {
            Llm.cancel = false;
            String ans = Assistant.chat(c, "telegram", text, imgId);
            record(ans.equals("Cancelled.") ? "Answer" : "Answered: " + cut(text, 40), ans.equals("Cancelled.") ? "cancelled" : "OK", "");
            send(token, chatId, ans);
        } catch (Exception e) {
            record("Answer", "error", String.valueOf(e.getMessage()));
            send(token, chatId, "Sorry, something went wrong: " + e.getMessage());
        } finally {
            stop[0] = true;
            current = null;
        }
    }

    // ---------- sending ----------

    static void sendToOwner(Context c, String text) {
        JSONObject cfg = config(c);
        if (cfg != null) send(cfg.optString("token"), cfg.optLong("uid"), text);
    }

    static void send(String token, long chat, String text) {
        for (String part : chunks(text)) sendOne(token, chat, part);
    }

    static void sendOne(String token, long chat, String raw) {
        try {
            JSONObject r = api(token, "sendMessage", obj("chat_id", chat, "text", toHtml(raw), "parse_mode", "HTML",
                    "disable_web_page_preview", true), 30000);
            if (r.optBoolean("ok")) return;
            if (r.optInt("error_code") == 429) {
                JSONObject p = r.optJSONObject("parameters");
                nap(Math.min(10, p == null ? 3 : p.optInt("retry_after", 3)) * 1000L);
            }
            r = api(token, "sendMessage", obj("chat_id", chat, "text", raw), 30000);   // plain-text fallback
            if (!r.optBoolean("ok")) lastError = "Could not send a Telegram message: " + r.optString("description");
        } catch (Exception e) {
            lastError = "Could not send a Telegram message: " + safe(e.getMessage(), token);
        }
    }

    /** Splits long answers for Telegram's 4096 limit without breaking code blocks. */
    static List<String> chunks(String t) {
        List<String> out = new ArrayList<>();
        boolean inCode = false;
        if (t.isEmpty()) t = "(empty)";
        while (!t.isEmpty()) {
            String part;
            if (t.length() <= 3500) { part = t; t = ""; }
            else {
                int cut = t.lastIndexOf('\n', 3500);
                if (cut < 1000) cut = 3500;
                part = t.substring(0, cut);
                t = t.substring(cut);
            }
            int fences = part.split("```", -1).length - 1;
            boolean endsInCode = inCode ^ (fences % 2 == 1);
            out.add((inCode ? "```\n" : "") + part + (endsInCode ? "\n```" : ""));
            inCode = endsInCode;
        }
        return out;
    }

    static String esc(String s) { return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"); }

    static String toHtml(String text) {
        String[] parts = text.split("```", -1);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            String p = parts[i];
            if (i % 2 == 0) { b.append(esc(p)); continue; }
            int nl = p.indexOf('\n');
            if (nl >= 0 && nl <= 20 && p.substring(0, nl).matches("[A-Za-z0-9_+#.-]{0,15}")) p = p.substring(nl + 1);
            b.append("<pre>").append(esc(p)).append("</pre>");
        }
        return b.toString();
    }
}
