package com.krypton.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.nio.ByteBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Holds the screen-capture permission (needed for screenshots on Android 10 and older). */
public class CaptureService extends Service {
    static volatile MediaProjection proj;

    static boolean ready() { return proj != null; }

    static void start(Context c, int code, Intent data) {
        c.startForegroundService(new Intent(c, CaptureService.class).putExtra("code", code).putExtra("data", data));
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("krypton_capture", "Screen capture", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "krypton_capture").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Krypton can read your screen").setContentText("Screen capture permission is active").build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(3, n);
        if (i != null && i.hasExtra("data")) {
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            proj = m.getMediaProjection(i.getIntExtra("code", 0), (Intent) i.getParcelableExtra("data"));
            proj.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { proj = null; stopSelf(); }
            }, new Handler(Looper.getMainLooper()));
        }
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        MediaProjection p = proj;
        proj = null;
        if (p != null) try { p.stop(); } catch (Exception ignored) { }
        super.onDestroy();
    }

    static Bitmap capture(Context c) throws Exception {
        MediaProjection p = proj;
        if (p == null) throw new Exception("Screen capture is not allowed yet. Open Krypton > Settings > Permissions > Screen capture.");
        DisplayMetrics d = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(d);
        final int w = d.widthPixels, h = d.heightPixels;
        ImageReader r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
        final CountDownLatch l = new CountDownLatch(1);
        HandlerThread ht = new HandlerThread("krypton-cap");
        ht.start();
        Handler hd = new Handler(ht.getLooper());
        r.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override public void onImageAvailable(ImageReader rd) { l.countDown(); }
        }, hd);
        VirtualDisplay vd = p.createVirtualDisplay("krypton", w, h, d.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.getSurface(), null, hd);
        try {
            if (!l.await(5, TimeUnit.SECONDS)) throw new Exception("The screen capture timed out.");
            Image im = r.acquireLatestImage();
            if (im == null) throw new Exception("The screen capture returned nothing.");
            Image.Plane pl = im.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int ps = pl.getPixelStride(), pad = pl.getRowStride() - ps * w;
            Bitmap bm = Bitmap.createBitmap(w + pad / ps, h, Bitmap.Config.ARGB_8888);
            bm.copyPixelsFromBuffer(buf);
            im.close();
            Bitmap out = Bitmap.createBitmap(bm, 0, 0, w, h);
            bm.recycle();
            return out;
        } finally {
            vd.release(); r.close(); ht.quitSafely();
        }
    }
}
