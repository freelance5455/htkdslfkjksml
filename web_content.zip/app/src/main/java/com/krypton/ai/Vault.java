package com.krypton.ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** The Krypton Personal Password: PBKDF2-HMAC-SHA256 with a random salt. The password itself is never stored or logged. */
final class Vault {
    static SharedPreferences p(Context c) { return c.getApplicationContext().getSharedPreferences("krypton_vault", Context.MODE_PRIVATE); }

    static boolean isSet(Context c) { return p(c).contains("hash"); }

    static byte[] hash(String pw, byte[] salt) throws Exception {
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(new PBEKeySpec(pw.toCharArray(), salt, 120000, 256)).getEncoded();
    }

    static long lockedSeconds(Context c) {
        long left = p(c).getLong("lock", 0) - System.currentTimeMillis();
        return left > 0 ? (left + 999) / 1000 : 0;
    }

    /** Wrong guesses are limited: 5 failures lock password checks for 5 minutes. */
    static synchronized boolean verify(Context c, String pw) {
        if (!isSet(c) || pw == null || lockedSeconds(c) > 0) return false;
        try {
            byte[] salt = Base64.decode(p(c).getString("salt", ""), Base64.NO_WRAP);
            byte[] want = Base64.decode(p(c).getString("hash", ""), Base64.NO_WRAP);
            boolean ok = MessageDigest.isEqual(want, hash(pw, salt));
            SharedPreferences.Editor e = p(c).edit();
            if (ok) e.putInt("fails", 0);
            else {
                int f = p(c).getInt("fails", 0) + 1;
                if (f >= 5) { e.putLong("lock", System.currentTimeMillis() + 5 * 60000L); f = 0; }
                e.putInt("fails", f);
            }
            e.apply();
            return ok;
        } catch (Exception ex) { return false; }
    }

    /** Returns "" on success or an error message. oldPw is required when a password already exists. */
    static synchronized String set(Context c, String oldPw, String newPw) {
        if (newPw == null || newPw.length() < 4) return "The password needs at least 4 characters.";
        if (isSet(c) && !verify(c, oldPw)) {
            long l = lockedSeconds(c);
            return l > 0 ? "Too many wrong attempts. Try again in " + l + " seconds." : "The current password is wrong.";
        }
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            p(c).edit().putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                    .putString("hash", Base64.encodeToString(hash(newPw, salt), Base64.NO_WRAP))
                    .putInt("fails", 0).remove("lock").apply();
            return "";
        } catch (Exception e) { return "Could not save the password."; }
    }
}
