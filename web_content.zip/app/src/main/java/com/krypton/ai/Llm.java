package com.krypton.ai;

import android.content.Context;
import android.content.Intent;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

/** Talks to the local llama.cpp server from Java (used by the Telegram remote). No token or time limit. */
final class Llm {
    static volatile boolean cancel, busy;
    static volatile int chars;
    static volatile HttpURLConnection conn;

    static boolean healthy() {
        try {
            HttpURLConnection h = (HttpURLConnection) new URL("http://127.0.0.1:8080/health").openConnection();
            h.setConnectTimeout(1500);
            h.setReadTimeout(1500);
            return h.getResponseCode() == 200;
        } catch (Exception e) { return false; }
    }

    static void ensureServer(Context c) throws Exception {
        if (healthy()) return;
        Vision.releaseForText();
        if (ServerService.findModel(c) == null)
            throw new Exception("No AI model is installed yet. Open Krypton and download a model first.");
        c.startForegroundService(new Intent(c, ServerService.class));
        for (int i = 0; i < 150; i++) {
            Thread.sleep(1000);
            if (healthy()) return;
        }
        throw new Exception("The AI server did not start in time.");
    }

    static void cancelNow() {
        cancel = true;
        HttpURLConnection h = conn;
        if (h != null) try { h.disconnect(); } catch (Exception ignored) { }
    }

    /** Full answer for a list of {role, content} messages. Keeps going until the model really finishes. */
    static String chat(Context c, JSONArray base) throws Exception {
        busy = true; cancel = false; chars = 0;
        ServerService.keepAwake(c, true);
        try {
            ensureServer(c);
            StringBuilder acc = new StringBuilder();
            JSONArray msgs = base;
            for (int round = 0; round < 200; round++) {
                int before = acc.length();
                String fin;
                try { fin = call(msgs, acc); }
                catch (Exception e) { if (cancel) break; throw e; }
                if (cancel) break;
                if ("length".equals(fin) && acc.length() > before) {
                    msgs = new JSONArray(base.toString());
                    String tail = acc.substring(Math.max(0, acc.length() - 6000));
                    msgs.put(new JSONObject().put("role", "assistant").put("content", tail));
                    msgs.put(new JSONObject().put("role", "user").put("content", "Continue exactly where you stopped. Do not repeat anything."));
                    continue;
                }
                break;
            }
            return acc.toString();
        } finally {
            busy = false; conn = null;
            ServerService.keepAwake(c, false);
        }
    }

    static String call(JSONArray msgs, StringBuilder acc) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL("http://127.0.0.1:8080/v1/chat/completions").openConnection();
        conn = h;
        h.setConnectTimeout(5000);
        h.setReadTimeout(0);                                  // no time limit
        h.setRequestMethod("POST");
        h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/json");
        JSONObject body = new JSONObject().put("stream", false).put("temperature", 0.7).put("max_tokens", -1).put("messages", msgs);
        try (OutputStream o = h.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
        int code = h.getResponseCode();
        String s = new String(Store.readAll(code >= 400 ? h.getErrorStream() : h.getInputStream()), "UTF-8");
        if (code >= 400) throw new Exception("AI server error " + code);
        JSONObject ch = new JSONObject(s).getJSONArray("choices").getJSONObject(0);
        String text = ch.getJSONObject("message").optString("content", "");
        acc.append(text);
        chars = acc.length();
        return ch.optString("finish_reason", "");
    }
    /** One short JSON answer, forced into a schema (used by the action planner). */
    static JSONObject json(Context c, JSONArray msgs, JSONObject schema) throws Exception {
        ensureServer(c);
        HttpURLConnection h = (HttpURLConnection) new URL("http://127.0.0.1:8080/v1/chat/completions").openConnection();
        conn = h;
        h.setConnectTimeout(5000);
        h.setReadTimeout(240000);
        h.setRequestMethod("POST");
        h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/json");
        JSONObject body = new JSONObject().put("stream", false).put("temperature", 0.2).put("max_tokens", 220)
                .put("messages", msgs).put("response_format", new JSONObject().put("type", "json_object").put("schema", schema));
        try (OutputStream o = h.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
        int code = h.getResponseCode();
        String s = new String(Store.readAll(code >= 400 ? h.getErrorStream() : h.getInputStream()), "UTF-8");
        if (code >= 400) throw new Exception("AI server error " + code);
        String text = new JSONObject(s).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "{}").trim();
        if (text.startsWith("```")) text = text.replaceAll("^```[a-z]*\\n?|```$", "").trim();
        return new JSONObject(text);
    }
}
