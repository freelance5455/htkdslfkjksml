package com.krypton.ai;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.BatteryManager;
import java.io.File;

/** Same device actions the Termux version had (torch, battery, website, music), done natively. */
final class Device {
    static MediaPlayer mp;

    /** Returns the reply text, or "" if the text is not a device command. */
    static String run(Context c, String raw, boolean slash) {
        String t = raw.trim();
        String cmd = t.toLowerCase();
        if (!slash) {
            if (cmd.split("\\s+").length > 10) return "";
            if (cmd.matches(".*\\b(code|write|script|program|function|explain|why|essay)\\b.*")) return "";
        }
        if (cmd.contains("torch on") || cmd.contains("turn on torch")) return torch(c, true);
        if (cmd.contains("torch off") || cmd.contains("turn off torch")) return torch(c, false);
        if (cmd.contains("battery")) return battery(c);
        int i = cmd.indexOf("open website");
        if (i >= 0) return open(c, t.substring(i + 12).trim());
        i = cmd.indexOf("play music");
        int len = 10;
        if (i < 0) { i = cmd.indexOf("play song"); len = 9; }
        if (i >= 0) return play(t.substring(i + len).trim());
        if (cmd.contains("stop music") || cmd.contains("stop song")) return stop();
        return "";
    }

    static String torch(Context c, boolean on) {
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (flash != null && flash && facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cm.setTorchMode(id, on);
                    return on ? "Torch is now switched ON." : "Torch is now switched OFF.";
                }
            }
            return "No flashlight found on this device.";
        } catch (Exception e) {
            return "Could not control the torch: " + e.getMessage();
        }
    }

    static String battery(Context c) {
        try {
            Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            String status;
            switch (st) {
                case BatteryManager.BATTERY_STATUS_CHARGING: status = "Charging"; break;
                case BatteryManager.BATTERY_STATUS_DISCHARGING: status = "Discharging"; break;
                case BatteryManager.BATTERY_STATUS_FULL: status = "Full"; break;
                case BatteryManager.BATTERY_STATUS_NOT_CHARGING: status = "Not charging"; break;
                default: status = "Unknown";
            }
            return "Battery Level: " + (level * 100 / scale) + "%, Status: " + status + ".";
        } catch (Exception e) {
            return "Unable to retrieve battery status.";
        }
    }

    static String open(Context c, String url) {
        if (url.isEmpty()) return "Please give a website, for example: /open google.com";
        if (!url.startsWith("http")) url = "https://" + url;
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return "Opened website: " + url;
        } catch (Exception e) {
            return "Could not open " + url;
        }
    }

    static synchronized String play(String path) {
        if (path.isEmpty()) return "Please give an audio file path, for example: /play /sdcard/Music/song.mp3";
        if (!new File(path).exists()) return "File not found: " + path + " (check the path and storage permission).";
        try {
            stopQuiet();
            mp = new MediaPlayer();
            mp.setDataSource(path);
            mp.prepare();
            mp.start();
            return "Playing audio from: " + path;
        } catch (Exception e) {
            return "Could not play this file: " + e.getMessage();
        }
    }

    static synchronized String stop() {
        boolean was = mp != null;
        stopQuiet();
        return was ? "Music stopped." : "No music is playing.";
    }

    static void stopQuiet() {
        try { if (mp != null) { mp.stop(); mp.release(); } } catch (Exception ignored) { }
        mp = null;
    }
}
