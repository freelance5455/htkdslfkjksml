package com.krypton.ai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** After a reboot: bring back reminders and (if Telegram is set up) the background service. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context c, Intent i) {
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                Reminders.rescheduleAll(c);
                if ((Telegram.config(c) != null || Mail.config(c) != null) && ServerService.findModel(c) != null)
                    c.startForegroundService(new Intent(c, ServerService.class));
            } catch (Exception ignored) {
            } finally { pr.finish(); }
        }).start();
    }
}
