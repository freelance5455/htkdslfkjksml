package com.krypton.ai;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.Base64;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Pictures that were shared with Krypton. Each one is stored (reduced to at most 1280 px) so follow-up questions
 * can use the same picture without uploading it again. A line of OCR text is kept next to it as a reading aid.
 */
final class ImageStore {
    static final Map<String, String> stickyId = new ConcurrentHashMap<>();
    static final Map<String, Long> stickyTime = new ConcurrentHashMap<>();

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "chat_images");
        d.mkdirs();
        return d;
    }

    static String safe(String id) { return id == null ? "" : id.replaceAll("[^A-Za-z0-9_-]", ""); }

    static File file(Context c, String id) { return new File(dir(c), safe(id) + ".jpg"); }

    static File textFile(Context c, String id) { return new File(dir(c), safe(id) + ".txt"); }

    static String importUri(Context c, Uri u) throws Exception {
        try (InputStream in = c.getContentResolver().openInputStream(u)) {
            if (in == null) throw new Exception("Could not open that picture.");
            return importBytes(c, Store.readAll(in));
        }
    }

    static String importFile(Context c, File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) { return importBytes(c, Store.readAll(in)); }
    }

    static int rotation(byte[] data) {
        try {
            int o = new ExifInterface(new ByteArrayInputStream(data)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            return o == ExifInterface.ORIENTATION_ROTATE_90 ? 90 : o == ExifInterface.ORIENTATION_ROTATE_180 ? 180 : o == ExifInterface.ORIENTATION_ROTATE_270 ? 270 : 0;
        } catch (Exception e) { return 0; }
    }

    /** Decodes, fixes the rotation, limits the size, saves a JPEG and a text file with OCR text. Returns the picture id. Not for the main thread. */
    static String importBytes(Context c, byte[] data) throws Exception {
        if (data.length > 40 * 1024 * 1024) throw new Exception("That picture is too large.");
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, o);
        if (o.outWidth <= 0 || o.outHeight <= 0) throw new Exception("This file is not a readable picture.");
        int max = 1280, ss = 1;
        while (Math.max(o.outWidth, o.outHeight) / ss > max * 2) ss *= 2;
        o.inJustDecodeBounds = false;
        o.inSampleSize = ss;
        Bitmap b = BitmapFactory.decodeByteArray(data, 0, data.length, o);
        if (b == null) throw new Exception("This picture could not be decoded.");
        float f = (float) max / Math.max(b.getWidth(), b.getHeight());
        if (f < 1f) b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * f)), Math.max(1, Math.round(b.getHeight() * f)), true);
        int rot = rotation(data);
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
        }
        Bitmap flat = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);   // transparent PNGs onto white
        Canvas cv = new Canvas(flat);
        cv.drawColor(Color.WHITE);
        cv.drawBitmap(b, 0, 0, null);
        String id = Long.toString(System.currentTimeMillis(), 36) + Integer.toString((int) (Math.random() * 1296), 36);
        try (FileOutputStream out = new FileOutputStream(file(c, id))) { flat.compress(Bitmap.CompressFormat.JPEG, 88, out); }
        String ocr = Screen.ocrText(flat);
        if (!ocr.isEmpty()) try (FileOutputStream out = new FileOutputStream(textFile(c, id))) { out.write(ocr.getBytes("UTF-8")); }
        return id;
    }

    static String ocr(Context c, String id) {
        File f = textFile(c, id);
        if (!f.exists()) return "";
        try (FileInputStream in = new FileInputStream(f)) { return new String(Store.readAll(in), "UTF-8"); }
        catch (Exception e) { return ""; }
    }

    static String jpegBase64(Context c, String id, int maxSide, int quality) throws Exception {
        Bitmap b = BitmapFactory.decodeFile(file(c, id).getPath());
        if (b == null) throw new Exception("The picture is no longer available.");
        float f = (float) maxSide / Math.max(b.getWidth(), b.getHeight());
        if (f < 1f) b = Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * f)), Math.max(1, Math.round(b.getHeight() * f)), true);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.JPEG, quality, bo);
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    static String thumbData(Context c, String id) {
        try { return "data:image/jpeg;base64," + jpegBase64(c, id, 360, 72); } catch (Exception e) { return ""; }
    }

    static void delete(Context c, String id) { file(c, id).delete(); textFile(c, id).delete(); }

    static void deleteAll(Context c) {
        File[] fs = dir(c).listFiles();
        if (fs != null) for (File f : fs) f.delete();
        stickyId.clear(); stickyTime.clear();
    }

    // ---- "the picture we are talking about" for Telegram and email, so follow-ups need no new upload ----
    static void setSticky(String key, String id) { stickyId.put(key, id); stickyTime.put(key, System.currentTimeMillis()); }
    static void touch(String key) { stickyTime.put(key, System.currentTimeMillis()); }
    static boolean stickyActive(String key) {
        Long t = stickyTime.get(key);
        return t != null && System.currentTimeMillis() - t < 20 * 60 * 1000L;
    }
    static void clearSticky(String key) { stickyId.remove(key); stickyTime.remove(key); }
}
