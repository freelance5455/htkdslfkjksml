package com.krypton.ai;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Real picture understanding with a local vision-language model (VLM) served by the same llama.cpp server binary.
 * The VLM runs as a second server on port 8081 only while it is needed. If the phone is short on memory, the text model
 * is paused meanwhile and woken up again afterwards. Nothing leaves the phone.
 */
final class Vision {
    static class Model {
        final String id, name, note, gguf, proj, base;
        final int sizeMB, ramMB, maxSide;
        Model(String id, String name, String note, String gguf, String proj, String base, int sizeMB, int ramMB, int maxSide) {
            this.id = id; this.name = name; this.note = note; this.gguf = gguf; this.proj = proj; this.base = base;
            this.sizeMB = sizeMB; this.ramMB = ramMB; this.maxSide = maxSide;
        }
    }

    static final String HF = "https://huggingface.co/ggml-org/";
    static final Model[] MODELS = {
        new Model("fast", "SmolVLM 500M (fast)", "Light and quick. Good for photos and simple screenshots.",
                "SmolVLM-500M-Instruct-Q8_0.gguf", "mmproj-SmolVLM-500M-Instruct-Q8_0.gguf", HF + "SmolVLM-500M-Instruct-GGUF/resolve/main/", 560, 1100, 768),
        new Model("balanced", "SmolVLM2 2.2B (balanced)", "Understands documents, charts and small text much better.",
                "SmolVLM2-2.2B-Instruct-Q4_K_M.gguf", "mmproj-SmolVLM2-2.2B-Instruct-Q8_0.gguf", HF + "SmolVLM2-2.2B-Instruct-GGUF/resolve/main/", 1700, 2600, 1024),
        new Model("best", "Qwen2.5-VL 3B (best quality)", "Best at documents, charts, diagrams and equations. Slow on this phone and needs about 4 GB of free RAM.",
                "Qwen2.5-VL-3B-Instruct-Q4_K_M.gguf", "mmproj-Qwen2.5-VL-3B-Instruct-Q8_0.gguf", HF + "Qwen2.5-VL-3B-Instruct-GGUF/resolve/main/", 2800, 3800, 784)
    };

    static final String SYSTEM = "You are Krypton, an AI assistant that can see pictures. Look carefully and answer the user's question about the picture. "
            + "You can recognize objects, scenes, actions, screenshots, documents, charts, diagrams and math equations. "
            + "Read visible text exactly. For equations and calculations, work step by step and write the maths clearly. "
            + "For charts, describe the axes and the main trend and give the key values. "
            + "Do not identify real people by their face. If something is unclear or unreadable, say so instead of guessing. "
            + "Reply in English. Keep answers focused unless the user asks for detail.";

    static volatile Process proc;
    static volatile String procId = "";
    static volatile long lastUse;
    static volatile boolean textStopped;
    static Context appCtx;
    static volatile String dlId = "", dlError = "";
    static volatile long done;

    // ---------- installed models ----------

    static SharedPreferences prefs(Context c) { return c.getApplicationContext().getSharedPreferences("krypton_vision", Context.MODE_PRIVATE); }

    static File dir(Context c, String id) { File d = new File(new File(c.getFilesDir(), "vision"), id); d.mkdirs(); return d; }

    /** Older version stored the 500M model directly in files/vision. Move it so the existing download is kept. */
    static void migrate(Context c) {
        File root = new File(c.getFilesDir(), "vision");
        File g = new File(root, MODELS[0].gguf), p = new File(root, MODELS[0].proj);
        if (g.exists() && p.exists()) {
            File d = dir(c, "fast");
            g.renameTo(new File(d, MODELS[0].gguf));
            p.renameTo(new File(d, MODELS[0].proj));
        }
    }

    static boolean installed(Context c, Model m) { return new File(dir(c, m.id), m.gguf).exists() && new File(dir(c, m.id), m.proj).exists(); }

    static Model byId(String id) { for (Model m : MODELS) if (m.id.equals(id)) return m; return null; }

    static Model selected(Context c) {
        migrate(c);
        Model s = byId(prefs(c).getString("sel", ""));
        if (s != null && installed(c, s)) return s;
        for (int i = MODELS.length - 1; i >= 0; i--) if (installed(c, MODELS[i])) return MODELS[i];
        return null;
    }

    static boolean available(Context c) { return selected(c) != null; }

    static String activeName(Context c) { Model m = selected(c); return m == null ? "not installed" : m.name; }

    static void select(Context c, String id) { prefs(c).edit().putString("sel", id).apply(); }

    static long totalMB(Context c) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return mi.totalMem / 1048576;
    }

    static long availMB(Context c) {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return mi.availMem / 1048576;
    }

    // ---------- download ----------

    static void download(final Context ctx, final String id) {
        final Model m = byId(id);
        if (m == null || !dlId.isEmpty()) return;
        final Context c = ctx.getApplicationContext();
        dlId = id; dlError = ""; done = 0;
        new Thread(() -> {
            try {
                fetch(m.base + m.proj, new File(dir(c, id), m.proj));
                fetch(m.base + m.gguf, new File(dir(c, id), m.gguf));
                if (selected(c) == null || prefs(c).getString("sel", "").isEmpty()) select(c, id);
            } catch (Exception e) { dlError = "Download failed: " + e.getMessage(); }
            dlId = "";
        }, "vision-download").start();
    }

    static void fetch(String url, File dest) throws Exception {
        if (dest.exists()) { done += dest.length(); return; }
        File part = new File(dest.getPath() + ".part");
        long have = part.exists() ? part.length() : 0;
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(20000); h.setReadTimeout(30000);
        h.setRequestProperty("User-Agent", "KryptonAI/6.0");
        if (have > 0) h.setRequestProperty("Range", "bytes=" + have + "-");
        int code = h.getResponseCode();
        if (code == 416) { part.renameTo(dest); done += dest.length(); return; }
        if (code != 200 && code != 206) throw new Exception("HTTP " + code + " (the model file may have moved)");
        boolean append = code == 206;
        if (!append) have = 0;
        done += have;
        try (InputStream in = h.getInputStream(); OutputStream out = new FileOutputStream(part, append)) {
            byte[] b = new byte[65536]; int n;
            while ((n = in.read(b)) > 0) { out.write(b, 0, n); done += n; }
        }
        if (!part.renameTo(dest)) throw new Exception("rename failed");
    }

    static void delete(Context c, String id) {
        if (id.equals(procId)) stopProc();
        File[] fs = dir(c, id).listFiles();
        if (fs != null) for (File f : fs) f.delete();
    }

    static String status(Context c) {
        migrate(c);
        try {
            long ram = totalMB(c);
            String rec = ram >= 5500 ? "best" : ram >= 3500 ? "balanced" : "fast";
            Model sel = selected(c);
            JSONArray arr = new JSONArray();
            for (Model m : MODELS)
                arr.put(new JSONObject().put("id", m.id).put("name", m.name).put("note", m.note).put("sizeMB", m.sizeMB).put("ramMB", m.ramMB)
                        .put("installed", installed(c, m)).put("selected", sel != null && sel.id.equals(m.id))
                        .put("downloading", m.id.equals(dlId)).put("doneMB", m.id.equals(dlId) ? done / 1048576 : 0).put("recommended", m.id.equals(rec)));
            return new JSONObject().put("models", arr).put("deviceRamMB", ram).put("error", dlError).toString();
        } catch (Exception e) { return "{}"; }
    }

    // ---------- the vision server ----------

    static boolean healthy() {
        try {
            HttpURLConnection h = (HttpURLConnection) new URL("http://127.0.0.1:8081/health").openConnection();
            h.setConnectTimeout(1000); h.setReadTimeout(1000);
            return h.getResponseCode() == 200;
        } catch (Exception e) { return false; }
    }

    static final Object LOCK = new Object();

    static void ensure(Context c, Model m) throws Exception { synchronized (LOCK) { ensureLocked(c, m); } }

    static void ensureLocked(Context c, Model m) throws Exception {
        appCtx = c.getApplicationContext();
        lastUse = System.currentTimeMillis();
        if (proc != null && proc.isAlive() && m.id.equals(procId) && healthy()) return;
        stopProc();
        if (availMB(c) < m.ramMB && Llm.healthy()) {          // not enough memory for both models: pause the text model
            ServerService.stopLlm();
            textStopped = true;
            Thread.sleep(2500);
        }
        File bin = new File(c.getApplicationInfo().nativeLibraryDir, "libllama_server.so");
        final Process p = new ProcessBuilder(bin.getPath(), "--host", "127.0.0.1", "--port", "8081",
                "-m", new File(dir(c, m.id), m.gguf).getPath(), "--mmproj", new File(dir(c, m.id), m.proj).getPath(),
                "-c", "6144", "-t", "4", "-np", "1").redirectErrorStream(true).start();
        proc = p; procId = m.id;
        final StringBuilder log = new StringBuilder();
        new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String l;
                while ((l = r.readLine()) != null) { synchronized (log) { log.append(l).append('\n'); if (log.length() > 3000) log.delete(0, 1500); } }
            } catch (Exception ignored) { }
        }).start();
        for (int i = 0; i < 300; i++) {
            Thread.sleep(1000);
            if (healthy()) { idleWatch(); return; }
            if (!p.isAlive()) break;
        }
        String tail;
        synchronized (log) { tail = log.substring(Math.max(0, log.length() - 400)); }
        stopProc();
        throw new Exception("The vision model could not start (not enough memory, or this llama.cpp build has no picture support). " + tail.trim());
    }

    static void stopProc() {
        Process p = proc;
        proc = null; procId = "";
        if (p != null) try { p.destroy(); } catch (Exception ignored) { }
    }

    /** The text model needs the memory back: stop the vision server. */
    static void releaseForText() { synchronized (LOCK) { stopProc(); textStopped = false; } }

    static void idleWatch() {
        Thread t = new Thread(() -> {
            while (proc != null && proc.isAlive()) {
                try { Thread.sleep(15000); } catch (InterruptedException e) { return; }
                Job j = job;
                if ((j == null || j.done) && System.currentTimeMillis() - lastUse > 150000) {
                    stopProc();
                    if (textStopped && appCtx != null) { textStopped = false; ServerService.startLlm(appCtx); }
                    return;
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    // ---------- asking questions about pictures ----------

    static class Job {
        volatile String text = "", error = "", stage = "Starting the vision model...";
        volatile boolean done, cancel;
        volatile HttpURLConnection conn;
    }

    static volatile Job job;

    static boolean cancelled() { Job j = job; return j != null && j.cancel; }

    static void cancel() {
        Job j = job;
        if (j == null || j.done) return;
        j.cancel = true;
        HttpURLConnection h = j.conn;
        if (h != null) try { h.disconnect(); } catch (Exception ignored) { }
    }

    /** Starts a background job for the app chat. Returns "" or an error message. */
    static synchronized String startJob(final Context ctx, final JSONArray hist) {
        final Context c = ctx.getApplicationContext();
        Job old = job;
        if (old != null && !old.done) return "A picture question is already running.";
        final Model m = selected(c);
        if (m == null) return "No vision model is installed. Download one in Settings > Vision model.";
        final Job j = new Job();
        job = j;
        new Thread(() -> {
            ServerService.keepAwake(c, true);
            try { run(c, m, hist, j); }
            catch (Exception e) { if (!j.cancel) j.error = String.valueOf(e.getMessage()); }
            finally { j.done = true; lastUse = System.currentTimeMillis(); ServerService.keepAwake(c, false); }
        }, "vision-job").start();
        return "";
    }

    static String pollJson() {
        Job j = job;
        try {
            if (j == null) return new JSONObject().put("done", true).toString();
            return new JSONObject().put("text", j.text).put("error", j.error).put("stage", j.stage).put("done", j.done).put("cancelled", j.cancel).toString();
        } catch (Exception e) { return "{}"; }
    }

    /** For Telegram and email: waits for the full answer. */
    static String askBlocking(Context ctx, JSONArray hist) throws Exception {
        Context c = ctx.getApplicationContext();
        Model m = selected(c);
        if (m == null) throw new Exception("No vision model is installed.");
        Job j = new Job();
        job = j;
        ServerService.keepAwake(c, true);
        try { run(c, m, hist, j); }
        finally { j.done = true; lastUse = System.currentTimeMillis(); ServerService.keepAwake(c, false); }
        if (j.cancel) return "Cancelled.";
        return j.text.trim();
    }

    static JSONArray buildMessages(Context c, Model m, JSONArray hist) throws Exception {
        JSONArray out = new JSONArray().put(new JSONObject().put("role", "system").put("content", SYSTEM));
        int keepFrom = hist.length(), seen = 0;                 // only the 2 most recent pictures are sent to the model
        for (int i = hist.length() - 1; i >= 0 && seen < 2; i--)
            if (!hist.getJSONObject(i).optString("img", "").isEmpty()) { keepFrom = i; seen++; }
        for (int i = 0; i < hist.length(); i++) {
            JSONObject h = hist.getJSONObject(i);
            String text = h.optString("content", ""), img = ImageStore.safe(h.optString("img", ""));
            if (!img.isEmpty() && i >= keepFrom && ImageStore.file(c, img).exists()) {
                String ocr = ImageStore.ocr(c, img);
                if (!ocr.isEmpty()) text += "\n\n[Text found in the picture by OCR. It may contain mistakes: " + Screen.cut(ocr, 1500) + "]";
                JSONArray parts = new JSONArray()
                        .put(new JSONObject().put("type", "image_url").put("image_url", new JSONObject().put("url", "data:image/jpeg;base64," + ImageStore.jpegBase64(c, img, m.maxSide, 85))))
                        .put(new JSONObject().put("type", "text").put("text", text));
                out.put(new JSONObject().put("role", h.optString("role", "user")).put("content", parts));
            } else {
                if (!img.isEmpty()) text += " [an earlier picture was shared here]";
                out.put(new JSONObject().put("role", h.optString("role", "user")).put("content", text));
            }
        }
        return out;
    }

    static void run(Context c, Model m, JSONArray hist, Job j) throws Exception {
        j.stage = "Loading the vision model (the first time takes a while)...";
        ensure(c, m);
        if (j.cancel) return;
        j.stage = "Looking at the picture (this can take a minute on this phone)...";
        JSONObject body = new JSONObject().put("stream", true).put("temperature", 0.3).put("max_tokens", 1500).put("messages", buildMessages(c, m, hist));
        HttpURLConnection h = (HttpURLConnection) new URL("http://127.0.0.1:8081/v1/chat/completions").openConnection();
        j.conn = h;
        h.setConnectTimeout(5000); h.setReadTimeout(900000);
        h.setRequestMethod("POST"); h.setDoOutput(true);
        h.setRequestProperty("Content-Type", "application/json");
        try (OutputStream o = h.getOutputStream()) { o.write(body.toString().getBytes("UTF-8")); }
        int code = h.getResponseCode();
        if (code >= 400) {
            String e = new String(Store.readAll(h.getErrorStream()), "UTF-8");
            String msg = e;
            try { msg = new JSONObject(e).getJSONObject("error").optString("message", e); } catch (Exception ignored) { }
            throw new Exception("Vision server error " + code + ": " + Screen.cut(msg, 300));
        }
        try (BufferedReader r = new BufferedReader(new InputStreamReader(h.getInputStream(), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (j.cancel) break;
                if (!line.startsWith("data:")) continue;
                String d = line.substring(5).trim();
                if (d.equals("[DONE]")) break;
                try {
                    JSONArray ch = new JSONObject(d).optJSONArray("choices");
                    if (ch == null || ch.length() == 0) continue;
                    JSONObject delta = ch.getJSONObject(0).optJSONObject("delta");
                    String t = delta == null ? "" : delta.optString("content", "");
                    if (!t.isEmpty()) { j.text = j.text + t; lastUse = System.currentTimeMillis(); }
                } catch (Exception ignored) { }
            }
        } catch (java.io.IOException e) { if (!j.cancel) throw e; }
        if (j.text.trim().isEmpty() && !j.cancel) throw new Exception("The vision model gave an empty answer. Please try again.");
    }
}
