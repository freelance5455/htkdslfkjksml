package com.krypton.ai;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class MainActivity extends Activity {
    // {key, file name, download URL}
    static final String[][] MODELS = {
        {"small", "qwen2.5-0.5b-instruct-q4_k_m.gguf",
         "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf"},
        {"medium", "qwen2.5-1.5b-instruct-q4_k_m.gguf",
         "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf"}
    };

    WebView web;
    volatile String phase = "choose";   // welcome | restoring | choose | downloading | starting | error
    volatile String msg = "";
    volatile long done = 0, total = 0;
    volatile boolean downloading = false;
    volatile boolean foreground = false;
    static volatile boolean visible = false;
    static volatile String pickedJson = "";
    Uri camUri;

    static String errJson(String m) { try { return new JSONObject().put("error", m).toString(); } catch (Exception e) { return "{}"; } }
    boolean askedNotif, askedStorage, askedBattery;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setBackgroundColor(0xFF0F1A24);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/setup.html");
        getSharedPreferences("krypton_prefs", MODE_PRIVATE).edit().clear().apply();   // old switches of removed features
        Vision.migrate(this);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 77 && res == RESULT_OK && data != null) CaptureService.start(this, res, data);   // screen capture permission
        if (req == 81 || req == 82) {
            final boolean cam = req == 82;
            final Uri cu = camUri;
            final Uri u = cam ? cu : (data == null ? null : data.getData());
            if (res != RESULT_OK || u == null) {
                if (cam && cu != null) try { getContentResolver().delete(cu, null, null); } catch (Exception ignored) { }
                return;
            }
            new Thread(() -> {
                try { pickedJson = new JSONObject().put("id", ImageStore.importUri(MainActivity.this, u)).toString(); }
                catch (Exception e) { pickedJson = errJson(String.valueOf(e.getMessage())); }
                if (cam && cu != null) try { getContentResolver().delete(cu, null, null); } catch (Exception ignored) { }   // keep the gallery clean
            }, "pick-image").start();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        foreground = true;
        visible = true;
        nextPermission();
    }

    @Override
    protected void onPause() {
        foreground = false;
        visible = false;
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.krBack?window.krBack():false", v -> {
            if (!"true".equals(v)) moveTaskToBack(true);   // keep the server running in the background
        });
    }

    // ---------- permissions: asked one by one when the app opens ----------

    boolean hasStorage() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    void requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 2);
        }
    }

    void nextPermission() {
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askedNotif = true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            return;
        }
        if (!askedStorage && !hasStorage()) {
            askedStorage = true;
            requestStorage();
            return;
        }
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (!askedBattery && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
            askedBattery = true;
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) { }
        }
    }

    // ---------- bridge used by the web pages ----------

    class Bridge {
        // --- setup flow ---
        @JavascriptInterface
        public void init() {
            if (downloading) return;
            if (!Store.isInitialized(MainActivity.this)) { phase = "welcome"; return; }
            afterInit();
        }

        @JavascriptInterface
        public void startNew() {
            Store.initFresh(MainActivity.this);
            afterInit();
        }

        @JavascriptInterface
        public void restoreBackup() {
            if (!hasStorage()) {
                askedStorage = false;
                runOnUiThread(MainActivity.this::nextPermission);
                msg = "Storage permission is needed to find your backup. Allow it, then tap again.";
                phase = "welcome";
                return;
            }
            phase = "restoring"; msg = "";
            new Thread(() -> {
                String err = Store.restoreLatest(MainActivity.this);
                if (err != null) { msg = err; phase = "welcome"; }
                else { Reminders.rescheduleAll(MainActivity.this); afterInit(); }
            }).start();
        }

        @JavascriptInterface
        public void download(String key) {
            if (downloading) return;
            for (String[] m : MODELS) if (m[0].equals(key)) { startDownload(m[1], m[2]); return; }
        }

        @JavascriptInterface
        public String status() {
            try {
                JSONObject o = new JSONObject();
                o.put("phase", phase); o.put("msg", msg); o.put("done", done); o.put("total", total);
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        // --- data ---
        @JavascriptInterface
        public String loadData(String name) { return Store.read(MainActivity.this, name); }

        @JavascriptInterface
        public void saveData(String name, String data) { Store.write(MainActivity.this, name + ".json", data); }

        @JavascriptInterface
        public String backup() {
            try { return Store.backup(MainActivity.this); }
            catch (Exception e) { return "ERROR: " + e.getMessage(); }
        }

        @JavascriptInterface
        public void clearAll() { Store.clearMemory(MainActivity.this); }

        // --- shared brain (same code the Telegram remote uses) ---
        @JavascriptInterface
        public String systemPrompt(boolean first) { return Mem.prompt(MainActivity.this, first); }

        @JavascriptInterface
        public void addShort(String user, String reply) { Mem.addShort(MainActivity.this, user, reply); }

        @JavascriptInterface
        public String processTags(String text) { return Commands.processTags(MainActivity.this, text); }

        /** Reply for commands, automation phrases and device phrases; "" means: send it to the AI. */
        @JavascriptInterface
        public String route(String text) {
            String r = Commands.route(MainActivity.this, text, "app");
            return r == null ? "" : r;
        }

        @JavascriptInterface
        public String commandList() { return Commands.tableJson(); }

        // --- automations ---
        @JavascriptInterface
        public String autoList() { return Automations.load(MainActivity.this).toString(); }

        @JavascriptInterface
        public String autoSave(String json) { return Automations.saveOne(MainActivity.this, json); }

        @JavascriptInterface
        public void autoDelete(String id) { Automations.delete(MainActivity.this, id); }

        @JavascriptInterface
        public String autoRun(String id) {
            org.json.JSONObject a = Automations.find(MainActivity.this, id);
            if (a == null) return "Automation not found.";
            String err = Automator.start(MainActivity.this, a, null);
            if (err != null) return err;
            runOnUiThread(() -> web.postDelayed(() -> moveTaskToBack(true), 700));   // get Krypton out of the way
            return "Started '" + a.optString("name") + "'.";
        }

        @JavascriptInterface
        public void autoStop() { Automator.stop(); Planner.stop(); }

        @JavascriptInterface
        public String autoStatus() {
            try {
                return new JSONObject().put("running", Automator.isRunning() || Planner.isRunning()).put("text", Planner.isRunning() ? Planner.statusText() : Automator.statusText()).toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface
        public String listApps() {
            try {
                android.content.pm.PackageManager pm = getPackageManager();
                Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
                java.util.TreeMap<String, String> m = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER);
                for (android.content.pm.ResolveInfo ri : pm.queryIntentActivities(main, 0))
                    m.put(ri.loadLabel(pm).toString() + " (" + ri.activityInfo.packageName + ")", ri.activityInfo.packageName);
                org.json.JSONArray a = new org.json.JSONArray();
                for (java.util.Map.Entry<String, String> e : m.entrySet())
                    a.put(new JSONObject().put("name", e.getKey()).put("pkg", e.getValue()));
                return a.toString();
            } catch (Exception e) { return "[]"; }
        }

        @JavascriptInterface
        public String screenInfo() {
            android.util.DisplayMetrics d = getResources().getDisplayMetrics();
            return d.widthPixels + " x " + d.heightPixels;
        }

        @JavascriptInterface
        public boolean a11yEnabled() { return KryptonAccessibilityService.instance != null; }

        @JavascriptInterface
        public void openA11ySettings() {
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }

        @JavascriptInterface
        public boolean overlayGranted() { return Settings.canDrawOverlays(MainActivity.this); }

        @JavascriptInterface
        public void openOverlaySettings() {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }

        // --- Telegram remote (the token never comes back to the page) ---
        @JavascriptInterface
        public String tgStatus() { return Telegram.statusJson(MainActivity.this); }

        @JavascriptInterface
        public void tgConnect(String token, String userId, boolean allowDevice) {
            Telegram.connect(MainActivity.this, token, userId, allowDevice);
        }

        @JavascriptInterface
        public void tgDisconnect() { Telegram.disconnect(MainActivity.this); }

        // --- approvals, background results, switches ---
        /** Polled by the chat page: pending approval request + messages from background tasks. */
        @JavascriptInterface
        public String poll() {
            try {
                String p = Guard.uiPromptJson();
                String pk = pickedJson;
                pickedJson = "";
                return new JSONObject().put("prompt", p.isEmpty() ? JSONObject.NULL : new JSONObject(p)).put("msgs", UiBus.drain())
                        .put("notes", UiBus.drainNotes()).put("picked", pk.isEmpty() ? JSONObject.NULL : new JSONObject(pk)).toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface
        public String guardAnswer(final String text) {
            // runs in the background (an approved action may upload a file); the result arrives through the chat poll
            new Thread(() -> {
                String r = Guard.answer(MainActivity.this, "ui", text);
                if (r != null && !r.isEmpty()) UiBus.add(r);
            }).start();
            return "";
        }

        @JavascriptInterface
        public String stopAll() { return Commands.run(MainActivity.this, "/cancel", "app"); }

        // --- Personal Password (never returned to the page) ---
        @JavascriptInterface
        public boolean pwIsSet() { return Vault.isSet(MainActivity.this); }

        @JavascriptInterface
        public String pwSet(String oldPw, String newPw) { return Vault.set(MainActivity.this, oldPw, newPw); }

        // --- Gmail ---
        @JavascriptInterface
        public String mailStatus() { return Mail.statusJson(MainActivity.this); }

        @JavascriptInterface
        public void mailConnect(String bot, String pw, String auth) { Mail.connect(MainActivity.this, bot, pw, auth); }

        @JavascriptInterface
        public void mailDisconnect() { Mail.disconnect(MainActivity.this); }

        // --- optional vision model ---
        @JavascriptInterface
        public String visionStatus() { return Vision.status(MainActivity.this); }

        @JavascriptInterface
        public void visionDownload(String id) { Vision.download(MainActivity.this, id); }

        @JavascriptInterface
        public void visionSelect(String id) { Vision.select(MainActivity.this, id); }

        @JavascriptInterface
        public void visionDelete(String id) { Vision.delete(MainActivity.this, id); }

        // --- permissions screen ---
        @JavascriptInterface
        public String permStatus() {
            try {
                boolean notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
                boolean batt = ((PowerManager) getSystemService(POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());
                boolean a11y = KryptonAccessibilityService.instance != null;
                boolean cap = (Build.VERSION.SDK_INT >= 30 && a11y) || CaptureService.ready();
                org.json.JSONArray a = new org.json.JSONArray();
                a.put(perm("accessibility", "Accessibility service", "Lets Krypton read the screen and tap, swipe and type for automations and phone tasks. Krypton does not send screen content anywhere unless you approve it.", a11y));
                a.put(perm("overlay", "Display over other apps", "Lets Krypton open apps while it is in the background, for example when you start a phone task from Telegram.", Settings.canDrawOverlays(MainActivity.this)));
                a.put(perm("capture", "Screen capture", "Needed for screenshots when a phone task must read the screen. Android 11+ uses the Accessibility service instead. On older Android you must allow this each time Krypton restarts.", cap));
                a.put(perm("notif", "Notifications", "Shows reminders, task results and approval requests.", notif));
                a.put(perm("storage", "All files access", "Needed for backups, saving received files and finding your latest screenshot.", hasStorage()));
                a.put(perm("battery", "Run in background", "Keeps Telegram, Gmail and reminders working with the screen off.", batt));
                return a.toString();
            } catch (Exception e) { return "[]"; }
        }

        JSONObject perm(String id, String name, String why, boolean ok) throws Exception {
            return new JSONObject().put("id", id).put("name", name).put("why", why).put("granted", ok);
        }

        @JavascriptInterface
        public void permRequest(final String id) {
            runOnUiThread(() -> {
                switch (id) {
                    case "accessibility": startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); break;
                    case "overlay": startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); break;
                    case "capture":
                        android.media.projection.MediaProjectionManager m = (android.media.projection.MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                        startActivityForResult(m.createScreenCaptureIntent(), 77);
                        break;
                    case "notif": askedNotif = false; nextPermission(); break;
                    case "storage": askedStorage = false; nextPermission(); break;
                    case "battery": askedBattery = false; nextPermission(); break;
                }
            });
        }

        // --- pictures: pick, remember, ask (real vision model, see Vision.java) ---
        @JavascriptInterface
        public void pickImage(final String source) {
            runOnUiThread(() -> {
                try {
                    if (source.equals("camera")) {
                        android.content.ContentValues v = new android.content.ContentValues();
                        v.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "krypton_" + System.currentTimeMillis() + ".jpg");
                        v.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                        if (Build.VERSION.SDK_INT >= 29) v.put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Krypton");
                        camUri = getContentResolver().insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
                        if (camUri == null) { pickedJson = errJson("Could not prepare the camera (allow storage access in Permissions)."); return; }
                        Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).putExtra(android.provider.MediaStore.EXTRA_OUTPUT, camUri)
                                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivityForResult(i, 82);
                    } else {
                        startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 81);
                    }
                } catch (Exception e) { pickedJson = errJson("Could not open the " + source + ": " + e.getMessage()); }
            });
        }

        @JavascriptInterface
        public String imageThumb(String id) { return ImageStore.thumbData(MainActivity.this, id); }

        @JavascriptInterface
        public void imageDelete(String id) { ImageStore.delete(MainActivity.this, id); }

        @JavascriptInterface
        public boolean visionAvailable() { return Vision.available(MainActivity.this); }

        @JavascriptInterface
        public String visionStart(String histJson) {
            try { return Vision.startJob(MainActivity.this, new org.json.JSONArray(histJson)); }
            catch (Exception e) { return "Could not start: " + e.getMessage(); }
        }

        @JavascriptInterface
        public String visionPoll() { return Vision.pollJson(); }

        @JavascriptInterface
        public void visionCancel() { Vision.cancel(); }

        /** The text model was paused to make room for the vision model: bring it back. */
        @JavascriptInterface
        public void wakeText() {
            new Thread(() -> { Vision.releaseForText(); ServerService.startLlm(MainActivity.this); }).start();
        }

        @JavascriptInterface
        public boolean textHealthy() { return Llm.healthy(); }

        /** After approving something a running phone task was waiting for, give the screen back to the other app. */
        @JavascriptInterface
        public void sendToBackIfBusy() {
            if (Planner.isRunning() || Automator.isRunning()) runOnUiThread(() -> moveTaskToBack(true));
        }

        // --- phone features ---
        @JavascriptInterface
        public void copy(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("Krypton", text));
            });
        }

        @JavascriptInterface
        public void notifyUser(String title, String text) { Notifier.show(MainActivity.this, title, text); }

        @JavascriptInterface
        public int remind(int minutes, String text) { return Reminders.add(MainActivity.this, Math.max(1, minutes), text); }

        @JavascriptInterface
        public String device(String text, boolean slash) { return Device.run(MainActivity.this, text, slash); }

        @JavascriptInterface
        public void keepAwake(boolean on) { ServerService.keepAwake(MainActivity.this, on); }

        @JavascriptInterface
        public boolean isForeground() { return foreground; }
    }

    void afterInit() {
        if (ServerService.findModel(this) != null) launch();
        else phase = "choose";
    }

    void startDownload(final String name, final String url) {
        downloading = true; phase = "downloading"; done = 0; total = 0; msg = "";
        new Thread(() -> {
            File dir = new File(getFilesDir(), "models");
            dir.mkdirs();
            File dest = new File(dir, name);
            File part = new File(dir, name + ".part");
            try {
                long have = part.exists() ? part.length() : 0;
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(20000);
                c.setReadTimeout(30000);
                c.setRequestProperty("User-Agent", "KryptonAI/4.0");
                if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                int code = c.getResponseCode();
                if (code == 416 && have > 0) {
                    if (!part.renameTo(dest)) throw new IOException("rename failed");
                } else {
                    if (code != 200 && code != 206) throw new IOException("HTTP " + code);
                    boolean append = code == 206;
                    if (!append) have = 0;
                    total = have + c.getContentLengthLong();
                    done = have;
                    try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(part, append)) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); done += n; }
                    }
                    if (total > 0 && done < total) throw new IOException("Download was interrupted");
                    if (!part.renameTo(dest)) throw new IOException("rename failed");
                }
                downloading = false;
                launch();
            } catch (Exception e) {
                downloading = false;
                phase = "error";
                msg = "Download failed: " + e.getMessage() + "\nCheck your internet and try again. The download will continue where it stopped.";
            }
        }).start();
    }

    void launch() {
        phase = "starting"; msg = "";
        startForegroundService(new Intent(this, ServerService.class));
        new Thread(() -> {
            long t0 = System.currentTimeMillis();
            while (System.currentTimeMillis() - t0 < 240000) {
                long el = System.currentTimeMillis() - t0;
                if (el > 5000 && !ServerService.isAlive()) {
                    phase = "error";
                    msg = "The AI server stopped.\n" + ServerService.tail();
                    return;
                }
                if (healthy()) { runOnUiThread(this::showChat); return; }
                try { Thread.sleep(1000); } catch (InterruptedException e) { return; }
            }
            phase = "error";
            msg = "The AI server did not start in time.\n" + ServerService.tail();
        }).start();
    }

    boolean healthy() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:8080/health").openConnection();
            c.setConnectTimeout(1500);
            c.setReadTimeout(1500);
            return c.getResponseCode() == 200;
        } catch (Exception e) { return false; }
    }

    void showChat() {
        try (InputStream in = getAssets().open("chat.html")) {
            // Base URL = the server's origin, so fetch() calls stay same-origin (no CORS problems).
            web.loadDataWithBaseURL("http://127.0.0.1:8080/", new String(Store.readAll(in), "UTF-8"),
                    "text/html", "utf-8", null);
        } catch (IOException e) {
            phase = "error"; msg = "Could not load the chat screen: " + e.getMessage();
        }
    }
}
