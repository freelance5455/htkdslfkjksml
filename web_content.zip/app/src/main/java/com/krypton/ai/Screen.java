package com.krypton.ai;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** Reading the screen: accessibility tree first, local OCR when that is not enough, screenshots when needed. */
final class Screen {
    static class Elem {
        int id; String label = "", kind = "text"; Rect r = new Rect(); boolean click, edit;
    }

    static class Snap {
        String pkg = "", note = "", hash = ""; List<Elem> els = new ArrayList<>(); boolean ocr;
        Elem byId(int id) { for (Elem e : els) if (e.id == id) return e; return null; }
    }

    static Snap snapshot(Context c, boolean ocrIfSparse) throws Exception {
        KryptonAccessibilityService s = KryptonAccessibilityService.instance;
        if (s == null) throw new Exception("The Krypton Accessibility service is off.");
        Snap sn = new Snap();
        sn.pkg = s.currentPackage();
        sn.els = s.elements();
        if (ocrIfSparse && sn.els.size() < 4) {            // app hides its UI from accessibility: read pixels instead
            try {
                for (Elem e : ocr(screenshot(c))) sn.els.add(e);
                sn.ocr = true;
            } catch (Exception e) { sn.note = "The screen could not be read (no accessibility info; OCR failed: " + e.getMessage() + ")."; }
        }
        StringBuilder h = new StringBuilder(sn.pkg);
        for (int i = 0; i < sn.els.size(); i++) {
            Elem e = sn.els.get(i);
            e.id = i + 1;
            if (i < 50) h.append(e.label).append(e.r.top / 20).append(e.r.left / 20);
        }
        sn.hash = Integer.toHexString(h.toString().hashCode());
        return sn;
    }

    static String describe(Snap s) {
        StringBuilder b = new StringBuilder();
        for (Elem e : s.els) b.append('[').append(e.id).append("] ").append(e.kind).append(" \"").append(cut(e.label, 50)).append("\"\n");
        if (!s.note.isEmpty()) b.append(s.note).append('\n');
        return b.length() == 0 ? "(nothing readable on screen)" : b.toString();
    }

    /** Plain text of the visible screen, for questions like "what is on my screen". */
    static String readable(Snap s) {
        StringBuilder b = new StringBuilder();
        for (Elem e : s.els) if (!e.label.isEmpty()) b.append(e.label).append('\n');
        return b.toString().trim();
    }

    static String cut(String s, int n) { return s.length() > n ? s.substring(0, n) : s; }

    /** Full screenshot (accessibility on Android 11+, screen-capture permission on older versions). */
    static Bitmap screenshot(Context c) throws Exception {
        KryptonAccessibilityService s = KryptonAccessibilityService.instance;
        if (Build.VERSION.SDK_INT >= 30 && s != null) {
            try { return s.shot(); }
            catch (Exception e) { if (!CaptureService.ready()) throw e; }
        }
        return CaptureService.capture(c);
    }

    static List<Elem> ocr(Bitmap b) throws Exception {
        TextRecognizer rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        Text t = Tasks.await(rec.process(InputImage.fromBitmap(b, 0)), 25, TimeUnit.SECONDS);
        List<Elem> out = new ArrayList<>();
        for (Text.TextBlock bl : t.getTextBlocks())
            for (Text.Line ln : bl.getLines()) {
                Rect r = ln.getBoundingBox();
                if (r == null || ln.getText().trim().isEmpty()) continue;
                Elem e = new Elem();
                e.label = ln.getText().trim(); e.kind = "ocr-text"; e.r = r; e.click = true;
                out.add(e);
                if (out.size() >= 60) return out;
            }
        return out;
    }

    static String ocrText(Bitmap b) {
        try {
            StringBuilder s = new StringBuilder();
            for (Elem e : ocr(b)) s.append(e.label).append('\n');
            return s.toString().trim();
        } catch (Exception e) { return ""; }
    }
}
