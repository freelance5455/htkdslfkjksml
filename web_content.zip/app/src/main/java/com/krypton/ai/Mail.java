package com.krypton.ai;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;
import org.json.JSONObject;

/**
 * Gmail remote control over IMAP/SMTP with a Gmail App Password. The password is encrypted with the Android Keystore,
 * never shown again, and only mail from the authorized address that passes Google's SPF/DKIM check is obeyed.
 */
final class Mail {
    static final String PREFS = "krypton_mail";
    static volatile String state = "disconnected", error = "";
    static volatile int blocked = 0;
    static volatile boolean running;
    static Thread poller;
    static volatile long connectedAt;

    static SharedPreferences prefs(Context c) { return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

    static JSONObject config(Context c) {
        try {
            String s = prefs(c).getString("cfg", null);
            return s == null ? null : new JSONObject(Secure.dec(s));
        } catch (Exception e) { return null; }
    }

    static String statusJson(Context c) {
        JSONObject cfg = config(c);
        JSONObject o = new JSONObject();
        try {
            o.put("state", state).put("error", error).put("configured", cfg != null).put("blocked", blocked);
            if (cfg != null) o.put("bot", cfg.optString("bot")).put("auth", cfg.optString("auth"));   // never the password
        } catch (Exception ignored) { }
        return o.toString();
    }

    static String clean(String m, String pw) {
        if (m == null) return "unknown error";
        return pw == null || pw.isEmpty() ? m : m.replace(pw, "***");
    }

    static Properties props() {
        Properties p = new Properties();
        p.put("mail.store.protocol", "imaps");
        p.put("mail.imaps.host", "imap.gmail.com"); p.put("mail.imaps.port", "993"); p.put("mail.imaps.ssl.enable", "true");
        p.put("mail.imaps.connectiontimeout", "20000"); p.put("mail.imaps.timeout", "30000");
        p.put("mail.smtp.host", "smtp.gmail.com"); p.put("mail.smtp.port", "465"); p.put("mail.smtp.ssl.enable", "true");
        p.put("mail.smtp.auth", "true"); p.put("mail.smtp.connectiontimeout", "20000"); p.put("mail.smtp.timeout", "30000");
        return p;
    }

    static void fail(String m) { state = "error"; error = m; }

    static void connect(final Context ctx, String botIn, String pwIn, String authIn) {
        final Context c = ctx.getApplicationContext();
        state = "connecting"; error = "";
        final String bot = botIn == null ? "" : botIn.trim().toLowerCase(Locale.ROOT);
        final String auth = authIn == null ? "" : authIn.trim().toLowerCase(Locale.ROOT);
        final String typed = pwIn == null ? "" : pwIn.replaceAll("\\s+", "");
        new Thread(() -> {
            String pw = typed;
            try {
                if (pw.isEmpty()) { JSONObject old = config(c); if (old != null) pw = old.optString("pw"); }
                if (!bot.matches("[a-z0-9._%+-]+@gmail\\.com")) { fail("The bot Gmail address must be a gmail.com address."); return; }
                if (!auth.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}")) { fail("The authorized user email address looks wrong."); return; }
                if (auth.equals(bot)) { fail("The authorized address must be different from the bot address."); return; }
                if (pw.length() < 12) { fail("Enter the 16-character Gmail App Password (Google Account > Security > App passwords)."); return; }
                javax.mail.Store st = Session.getInstance(props()).getStore("imaps");
                st.connect("imap.gmail.com", bot, pw);                    // proves the login works (IMAP must be enabled in Gmail)
                st.close();
                Transport t = Session.getInstance(props()).getTransport("smtp");
                t.connect("smtp.gmail.com", 465, bot, pw);
                t.close();
                JSONObject o = new JSONObject().put("bot", bot).put("pw", pw).put("auth", auth);
                prefs(c).edit().putString("cfg", Secure.enc(o.toString())).commit();
                connectedAt = System.currentTimeMillis();
                state = "connected"; error = "";
                startPolling(c);
                sendToOwner(c, "Krypton connected", "Krypton is now connected to this email address. Send a command such as /help or /status and I will reply here.");
            } catch (javax.mail.AuthenticationFailedException e) {
                fail("Gmail refused the login. Use a 16-character App Password (not your normal password), and make sure IMAP is enabled in Gmail settings.");
            } catch (Exception e) {
                fail("Could not connect: " + clean(e.getMessage(), pw));
            }
        }, "mail-connect").start();
    }

    static void disconnect(Context c) {
        running = false;
        prefs(c).edit().clear().commit();
        state = "disconnected"; error = ""; blocked = 0;
    }

    static void autostart(Context c) { if (config(c) != null) startPolling(c.getApplicationContext()); }

    static void shutdown() { running = false; if (!"error".equals(state)) state = "stopped"; }

    static synchronized void startPolling(final Context c) {
        running = true;
        if (connectedAt == 0) connectedAt = System.currentTimeMillis() - 60000;
        if (poller != null && poller.isAlive()) return;
        if (!"error".equals(state)) state = "connecting";
        poller = new Thread(() -> loop(c), "mail-poll");
        poller.start();
    }

    static void loop(Context c) {
        while (running) {
            JSONObject cfg = config(c);
            if (cfg == null) { state = "disconnected"; break; }
            String pw = cfg.optString("pw");
            try {
                checkInbox(c, cfg);
                state = "connected"; error = "";
            } catch (javax.mail.AuthenticationFailedException e) {
                fail("Gmail rejected the saved App Password. Reconnect with a new one."); running = false; break;
            } catch (Exception e) {
                fail("Mail check failed, retrying: " + clean(e.getMessage(), pw));
            }
            for (int i = 0; i < 20 && running; i++) { try { Thread.sleep(1000); } catch (InterruptedException ignored) { } }
        }
        poller = null;
    }

    static void checkInbox(Context c, JSONObject cfg) throws Exception {
        String bot = cfg.optString("bot"), auth = cfg.optString("auth");
        javax.mail.Store st = Session.getInstance(props()).getStore("imaps");
        st.connect("imap.gmail.com", bot, cfg.optString("pw"));
        Folder f = st.getFolder("INBOX");
        f.open(Folder.READ_WRITE);
        try {
            for (Message m : f.search(new FlagTerm(new Flags(Flags.Flag.SEEN), false))) {
                m.setFlag(Flags.Flag.SEEN, true);
                handle(c, auth, m);
            }
        } finally { try { f.close(false); } catch (Exception ignored) { } st.close(); }
    }

    static void handle(Context c, String auth, Message m) throws Exception {
        String from = "";
        if (m.getFrom() != null && m.getFrom().length > 0) from = ((InternetAddress) m.getFrom()[0]).getAddress().toLowerCase(Locale.ROOT);
        String[] ar = m.getHeader("Authentication-Results");
        String res = ar == null ? "" : String.join(" ", ar).toLowerCase(Locale.ROOT);
        boolean authentic = (res.contains("dkim=pass") || res.contains("spf=pass")) && !res.contains("dkim=fail");
        if (!from.equals(auth) || !authentic) { blocked++; return; }                // anyone else is ignored
        Date d = m.getReceivedDate();
        if (d != null && d.getTime() < connectedAt - 60000) return;                 // old mail from before connecting
        String subject = m.getSubject() == null ? "" : m.getSubject();
        String cmd = firstLines(body(m));
        if (cmd.isEmpty()) cmd = subject.trim();
        String imgId = null;
        try {
            byte[] img = firstImage(m);
            if (img != null) imgId = ImageStore.importBytes(c, img);
        } catch (Exception ignored) { }
        if (cmd.isEmpty() && imgId != null) cmd = Assistant.DEFAULT_Q;
        if (cmd.isEmpty()) return;
        String reply;
        if (Guard.hasPending("email")) reply = Guard.answer(c, "email", cmd);
        else if (cmd.startsWith("/")) reply = Commands.run(c, cmd, "email");
        else {
            reply = imgId != null ? null : Commands.route(c, cmd, "email");
            if (reply == null) reply = Assistant.chat(c, "email", cmd, imgId);
        }
        send(c, auth, "Re: " + (subject.isEmpty() ? "Krypton" : subject.replaceFirst("(?i)^re:\\s*", "")), reply, null);
    }

    static String body(Part p) throws Exception {
        if (p.isMimeType("text/plain")) return String.valueOf(p.getContent());
        if (p.isMimeType("multipart/*")) {
            Multipart mp = (Multipart) p.getContent();
            for (int i = 0; i < mp.getCount(); i++) {
                Part b = mp.getBodyPart(i);
                if (b.isMimeType("text/plain") && Part.ATTACHMENT.equalsIgnoreCase(b.getDisposition()) == false) return String.valueOf(b.getContent());
            }
            for (int i = 0; i < mp.getCount(); i++) { String s = body(mp.getBodyPart(i)); if (!s.isEmpty()) return s; }
        }
        return "";
    }

    /** First picture attached to (or shown in) the email, as bytes. */
    static byte[] firstImage(Part p) throws Exception {
        if (p.isMimeType("image/*")) {
            try (java.io.InputStream in = p.getInputStream()) { byte[] b = Store.readAll(in); return b.length > 15 * 1024 * 1024 ? null : b; }
        }
        if (p.isMimeType("multipart/*")) {
            Multipart mp = (Multipart) p.getContent();
            for (int i = 0; i < mp.getCount(); i++) { byte[] b = firstImage(mp.getBodyPart(i)); if (b != null) return b; }
        }
        return null;
    }

    /** The new text of a reply: stops at quoted lines ("> ..." or "On ... wrote:"). */
    static String firstLines(String s) {
        StringBuilder b = new StringBuilder();
        for (String l : s.split("\\r?\\n")) {
            String t = l.trim();
            if (t.startsWith(">") || (t.startsWith("On ") && t.endsWith("wrote:")) || t.equals("--")) break;
            if (!t.isEmpty() || b.length() > 0) b.append(t).append('\n');
        }
        return b.toString().trim();
    }

    static void sendToOwner(Context c, String subject, String text) {
        JSONObject cfg = config(c);
        if (cfg != null) try { send(c, cfg.optString("auth"), subject, text, null); } catch (Exception ignored) { }
    }

    static void send(Context c, String to, String subject, String text, File attach) throws Exception {
        JSONObject cfg = config(c);
        if (cfg == null) throw new Exception("Gmail is not connected.");
        Session s = Session.getInstance(props());
        MimeMessage msg = new MimeMessage(s);
        msg.setFrom(new InternetAddress(cfg.optString("bot")));
        msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
        msg.setSubject(subject, "UTF-8");
        MimeMultipart mp = new MimeMultipart();
        MimeBodyPart tp = new MimeBodyPart();
        tp.setText(text, "UTF-8");
        mp.addBodyPart(tp);
        if (attach != null) {
            MimeBodyPart ap = new MimeBodyPart();
            ap.setDataHandler(new DataHandler(new FileDataSource(attach)));
            ap.setFileName(attach.getName());
            mp.addBodyPart(ap);
        }
        msg.setContent(mp);
        Transport t = s.getTransport("smtp");
        t.connect("smtp.gmail.com", 465, cfg.optString("bot"), cfg.optString("pw"));
        try { t.sendMessage(msg, msg.getAllRecipients()); } finally { t.close(); }
    }
}
