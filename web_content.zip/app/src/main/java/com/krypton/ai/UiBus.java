package com.krypton.ai;

import java.util.concurrent.ConcurrentLinkedQueue;
import org.json.JSONArray;

/** Messages for the in-app chat that come from background tasks (results, progress, errors). */
final class UiBus {
    static final ConcurrentLinkedQueue<String> q = new ConcurrentLinkedQueue<>();
    static final ConcurrentLinkedQueue<String> notes = new ConcurrentLinkedQueue<>();
    static void add(String s) { q.add(s); }
    static void note(String s) { notes.add(s); while (notes.size() > 40) notes.poll(); }
    static JSONArray drainNotes() {
        JSONArray a = new JSONArray();
        String s;
        while ((s = notes.poll()) != null) a.put(s);
        return a;
    }
    static JSONArray drain() {
        JSONArray a = new JSONArray();
        String s;
        while ((s = q.poll()) != null) a.put(s);
        return a;
    }
}
