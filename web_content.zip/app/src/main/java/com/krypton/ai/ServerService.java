package com.krypton.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.PowerManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Runs the llama.cpp server (libllama_server.so) in the background. */
public class ServerService extends Service {
    static volatile Process proc;
    static final StringBuilder log = new StringBuilder();
    static PowerManager.WakeLock wl;

    /** Pause the text model (the vision model needs the memory). */
    static void stopLlm() { Process p = proc; if (p != null) try { p.destroy(); } catch (Exception ignored) { } }

    /** Start the text model again. */
    static void startLlm(Context c) { c.startForegroundService(new Intent(c, ServerService.class)); }

    static boolean isAlive() { Process p = proc; return p != null && p.isAlive(); }

    static String tail() {
        synchronized (log) { return log.substring(Math.max(0, log.length() - 1200)); }
    }

    static void add(String s) {
        synchronized (log) {
            log.append(s).append('\n');
            if (log.length() > 8000) log.delete(0, log.length() - 4000);
        }
    }

    static File findModel(Context c) {
        File[] fs = new File(c.getFilesDir(), "models").listFiles((d, n) -> n.endsWith(".gguf"));
        if (fs == null || fs.length == 0) return null;
        File best = fs[0];
        for (File f : fs) if (f.lastModified() > best.lastModified()) best = f;
        return best;
    }

    static int awake = 0;

    /** Keeps the CPU awake while Krypton is generating (long answers finish even with the screen off). Calls must be paired. */
    static synchronized void keepAwake(Context c, boolean on) {
        try {
            if (on) {
                awake++;
                if (wl == null) {
                    PowerManager pm = (PowerManager) c.getApplicationContext().getSystemService(Context.POWER_SERVICE);
                    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "krypton:generate");
                    wl.setReferenceCounted(false);
                }
                if (!wl.isHeld()) wl.acquire(6 * 60 * 60 * 1000L);
            } else {
                awake = Math.max(0, awake - 1);
                if (awake == 0 && wl != null && wl.isHeld()) wl.release();
            }
        } catch (Exception ignored) { }
    }

    @Override
    public int onStartCommand(Intent i, int flags, int id) {
        if (i != null && "STOP".equals(i.getAction())) {
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(1, notif());
        launchProc(true);
        Telegram.autostart(getApplicationContext());
        Mail.autostart(getApplicationContext());
        return START_STICKY;
    }

    synchronized void launchProc(final boolean full) {
        if (isAlive()) return;
        File model = findModel(this);
        if (model == null) { add("Model file not found."); return; }
        File bin = new File(getApplicationInfo().nativeLibraryDir, "libllama_server.so");
        if (!bin.exists()) { add("libllama_server.so is missing from the APK."); return; }
        try {
            List<String> a = new ArrayList<>(Arrays.asList(bin.getPath(),
                    "--host", "127.0.0.1", "--port", "8080",
                    "-m", model.getPath(), "-c", "8192", "-t", "4", "-np", "1"));
            if (full) { a.add("--context-shift"); a.add("--timeout"); a.add("86400"); }  // endless generation
            ProcessBuilder pb = new ProcessBuilder(a);
            pb.redirectErrorStream(true);
            final Process p = pb.start();
            proc = p;
            final long t0 = System.currentTimeMillis();
            new Thread(() -> {
                try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                    String l;
                    while ((l = r.readLine()) != null) add(l);
                } catch (IOException ignored) { }
            }).start();
            new Thread(() -> {
                try { p.waitFor(); } catch (InterruptedException e) { return; }
                if (full && System.currentTimeMillis() - t0 < 8000) {
                    String t;
                    synchronized (log) { t = log.toString().toLowerCase(); }
                    if (t.contains("invalid argument") || t.contains("unknown argument") || t.contains("unrecognized")) {
                        add("Retrying without optional flags...");
                        launchProc(false);
                    }
                }
            }).start();
        } catch (Exception e) {
            add("Start error: " + e);
        }
    }

    Notification notif() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("krypton", "Krypton AI server", NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1, new Intent(this, ServerService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, "krypton")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Krypton AI is running")
                .setContentText("Local AI server is active")
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
                .build();
    }

    @Override
    public void onDestroy() {
        Process p = proc;
        if (p != null) p.destroy();
        Telegram.shutdown();
        Mail.shutdown();
        awake = 0;
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
