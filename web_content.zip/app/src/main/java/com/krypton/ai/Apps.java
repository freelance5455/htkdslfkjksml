package com.krypton.ai;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.Locale;

final class Apps {
    /** Package name for an app label such as "Instagram" (exact, then starts-with, then contains). */
    static String find(Context c, String name) {
        PackageManager pm = c.getPackageManager();
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (n.isEmpty()) return null;
        String best = null;
        int bestScore = 0;
        for (ResolveInfo ri : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
            String l = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            int score = l.equals(n) ? 3 : l.startsWith(n) ? 2 : l.contains(n) ? 1 : 0;
            if (score > bestScore) { bestScore = score; best = ri.activityInfo.packageName; }
        }
        return best;
    }

    static String label(Context c, String pkg) {
        try { return c.getPackageManager().getApplicationLabel(c.getPackageManager().getApplicationInfo(pkg, 0)).toString(); }
        catch (Exception e) { return pkg; }
    }

    /** True if the text names an installed app (used to tell phone tasks apart from normal chat). */
    static boolean mentionsApp(Context c, String text) {
        String t = " " + text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ") + " ";
        PackageManager pm = c.getPackageManager();
        for (ResolveInfo ri : pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)) {
            String l = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", "").trim();
            if (l.length() >= 3 && t.contains(" " + l + " ")) return true;
        }
        return false;
    }
}
