package com.krypton.ai;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context c, Intent i) {
        final int id = i.getIntExtra("id", -1);
        final PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                String text = Reminders.fire(c, id);
                if (text != null) {
                    Notifier.show(c, "Krypton reminder", text);
                    Telegram.sendToOwner(c, "Reminder: " + text);
                }
            } finally { pr.finish(); }
        }).start();
    }
}
