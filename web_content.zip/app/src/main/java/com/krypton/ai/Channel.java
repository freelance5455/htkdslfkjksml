package com.krypton.ai;

import android.content.Context;

/** Sends results back to whoever gave the command: the app ("ui"), Telegram or email. */
final class Channel {
    static String key(String src) { return "app".equals(src) ? "ui" : src; }

    static void send(Context c, String src, String text) {
        switch (key(src)) {
            case "telegram": Telegram.sendToOwner(c, text); break;
            case "email": Mail.sendToOwner(c, "Krypton", text); break;
            default:
                UiBus.add(text);
                if (!MainActivity.visible) Notifier.show(c, "Krypton", text);
        }
    }

    /** Step-by-step progress. Email only gets the final result. */
    static void progress(Context c, String src, String text) {
        switch (key(src)) {
            case "telegram": Telegram.sendToOwner(c, text); break;
            case "email": break;
            default: UiBus.note(text);
        }
    }

    static void error(Context c, String src, String text) {
        switch (key(src)) {
            case "telegram": Telegram.sendToOwner(c, "Error: " + text); break;
            case "email": Mail.sendToOwner(c, "Krypton error", text); break;
            default:
                UiBus.add("Error: " + text);
                Notifier.show(c, "Krypton error", text);
        }
    }

    /** Run slow work in the background and report the result through the right channel. */
    static String async(final Context c, final String src, final String started, final java.util.concurrent.Callable<String> job) {
        final Context app = c.getApplicationContext();
        new Thread(() -> {
            try { send(app, src, job.call()); }
            catch (Exception e) { error(app, src, String.valueOf(e.getMessage())); }
        }, "krypton-task").start();
        return started;
    }
}
