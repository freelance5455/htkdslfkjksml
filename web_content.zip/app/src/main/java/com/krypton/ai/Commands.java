package com.krypton.ai;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.concurrent.Callable;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONObject;

/** One command processor shared by the app chat and the Telegram remote. */
final class Commands {
    static final String DENIED = "Device control from Telegram is turned off. Turn it on in Krypton > Settings > Telegram Remote.";

    static final String[][] TABLE = {
        {"/help", "Show all commands."},
        {"/new", "Start a new chat (in Telegram: start a fresh conversation)."},
        {"/remember <text>", "Save a fact to Krypton's permanent memory."},
        {"/memory", "Show everything saved in memory."},
        {"/search <words>", "Search your saved memories."},
        {"/forget <number>", "Delete one saved memory by its number."},
        {"/name <your name>", "Tell Krypton what to call you."},
        {"/notify <text>", "Send a notification to the phone right now."},
        {"/remind <minutes> <text>", "Create a reminder."},
        {"/reminders", "List pending reminders and tasks."},
        {"/editreminder <id> <minutes> <text>", "Change the time and text of a reminder."},
        {"/cancelreminder <id>", "Cancel a reminder."},
        {"/auto list", "List your saved automations."},
        {"/auto run <name>", "Start an automation."},
        {"/auto stop", "Stop the running automation."},
        {"/auto status", "Show automation progress."},
        {"/auto enable <name>", "Turn an automation on."},
        {"/auto disable <name>", "Turn an automation off."},
        {"/auto delete <name>", "Delete an automation."},
        {"/do <task>", "Let Krypton do a task on the phone by looking at the screen, for example /do open Instagram and send hii to Sam."},
        {"/screen", "Read what is on the screen and explain it."},
        {"/screenshot", "Take a screenshot (sent to Telegram only after your Personal Password)."},
        {"/latestscreenshot", "Send your newest gallery screenshot to Telegram (needs your Personal Password)."},
        {"/getfile <path>", "Send a file from the phone to Telegram (needs your Personal Password)."},
        {"/status", "Show what Krypton is doing now, the last result and any error."},
        {"/cancel", "Cancel the current answer and stop any running automation."},
        {"/torch on", "Turn the flashlight on. Plain text also works: \"turn on torch\"."},
        {"/torch off", "Turn the flashlight off. Plain text also works: \"turn off torch\"."},
        {"/battery", "Show battery level and charging status. Plain text also works: \"battery\"."},
        {"/open <website>", "Open a website. Plain text also works: \"open website google.com\"."},
        {"/play <file path>", "Play an audio file, for example /play /sdcard/Music/song.mp3."},
        {"/stop", "Stop the music."},
        {"/backup", "Save a backup of all Krypton data to internal storage."},
        {"/clear", "Delete the current chat (in the app only)."}
    };

    static String tableJson() {
        JSONArray a = new JSONArray();
        try {
            for (String[] r : TABLE) a.put(new JSONObject().put("u", r[0]).put("d", r[1]));
        } catch (Exception ignored) { }
        return a.toString();
    }

    static boolean deviceOk(Context c, String src) { return !"telegram".equals(src) || Telegram.allowDevice(c); }

    static final java.util.regex.Pattern LATEST = Pattern.compile("(send|share|upload).*(latest|last|recent|newest).*(screenshot|screen shot)");
    static final java.util.regex.Pattern SHOT = Pattern.compile("^(please )?(take|capture) (a |my |the )?(screenshot|screen shot)");
    static final java.util.regex.Pattern SCREENQ = Pattern.compile("(what('s| is)|read|describe|explain|summari[sz]e|tell me about).*(my |the |this |current )?screen");
    static final java.util.regex.Pattern TASK1 = Pattern.compile("^(please )?(open|launch|go back|go home|scroll|swipe|tap|click|press)\\b.*");
    static final java.util.regex.Pattern TASK2 = Pattern.compile("^(please )?(send|message|text|call|share|search)\\b.*");

    /** Reply text for commands, automation phrases, phone tasks and device phrases. Returns null if the text should go to the AI. */
    static String route(Context c, String text, String src) {
        String t = text.trim();
        if (t.startsWith("/")) return run(c, t, src);
        JSONObject a = Automations.matchCommand(c, t);
        if (a != null) return deviceOk(c, src) ? startAuto(c, a, src) : DENIED;
        if (deviceOk(c, src)) {
            String d = Device.run(c, t, false);
            if (!d.isEmpty()) return d;
        }
        String low = t.toLowerCase(Locale.ROOT);
        if (LATEST.matcher(low).find()) return deviceOk(c, src) ? sendLatestScreenshot(c, src) : DENIED;
        if (SHOT.matcher(low).find()) return deviceOk(c, src) ? screenshotCmd(c, src) : DENIED;
        if (SCREENQ.matcher(low).find()) return screenQuestion(c, src, t);
        if (TASK1.matcher(low).matches() || (TASK2.matcher(low).matches() && Apps.mentionsApp(c, t)))
            return deviceOk(c, src) ? Planner.start(c, t, src) : DENIED;
        return null;
    }

    static String sendLatestScreenshot(final Context c, String src) {
        final File f = Files.latestScreenshot();
        if (f == null) return "I couldn't find a screenshot in DCIM/Screenshots or Pictures/Screenshots. Check that storage access is allowed.";
        if (Telegram.config(c) == null) return "Telegram is not connected. Connect your bot in Settings > Telegram Remote first.";
        return Guard.ask(c, src, "Send your latest screenshot (" + f.getName() + ") to your Telegram bot chat", true, () -> {
            String e = Telegram.sendFileToOwner(c, f, "Latest screenshot", true);
            return e == null ? "Sent " + f.getName() + " to Telegram (Telegram confirmed it)." : "Could not send it: " + e;
        });
    }

    static File saveShot(Context c, Bitmap b) throws Exception {
        File d = new File(Environment.getExternalStorageDirectory(), "Krypton/Screenshots");
        if (!(d.exists() || d.mkdirs()) || !d.canWrite()) d = c.getCacheDir();
        File f = new File(d, "krypton_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".png");
        try (FileOutputStream o = new FileOutputStream(f)) { b.compress(Bitmap.CompressFormat.PNG, 100, o); }
        return f;
    }

    static String screenshotCmd(final Context c, final String src) {
        final String k = Channel.key(src);
        final boolean remote = k.equals("telegram") || k.equals("email");
        final Callable<String> job = () -> {
            File f = saveShot(c, Screen.screenshot(c));
            if (!remote) return "Screenshot saved: " + f.getPath();
            String e = Telegram.sendFileToOwner(c, f, "Screenshot", true);
            return e == null ? "Screenshot sent (Telegram confirmed it)." : "Could not send the screenshot: " + e;
        };
        if (!remote) return Channel.async(c, src, "Taking the screenshot...", job);
        return Guard.ask(c, src, "Take a screenshot of your phone and send it here", true, () -> Channel.async(c, src, "Taking the screenshot...", job));
    }

    static String screenQuestion(final Context c, final String src, final String question) {
        final String k = Channel.key(src);
        final Callable<String> job = () -> {
            Screen.Snap s = Screen.snapshot(c, true);
            String txt = Screen.readable(s);
            if (txt.isEmpty()) return "I couldn't read anything on the screen. " + s.note;
            JSONArray m = new JSONArray()
                    .put(new JSONObject().put("role", "system").put("content", "You answer questions about what is on the user's phone screen, using only the screen text you are given. Reply in English."))
                    .put(new JSONObject().put("role", "user").put("content", "App: " + s.pkg + "\nScreen text:\n" + Screen.cut(txt, 5000) + "\n\nQuestion: " + question));
            return Commands.processTags(c, Llm.chat(c, m));
        };
        if (k.equals("telegram") || k.equals("email"))      // screen content leaves the phone: needs the password
            return Guard.ask(c, src, "Read your phone screen and send you the answer here", true, () -> Channel.async(c, src, "Reading the screen...", job));
        return Channel.async(c, src, "Reading the screen...", job);
    }

    static String startAuto(final Context c, JSONObject a, String src) {
        final boolean tg = "telegram".equals(src);
        if (a.optBoolean("sensitive", false))
            return Guard.ask(c, src, "Run the automation '" + a.optString("name") + "'", true, () -> startAutoNow(c, a, src));
        return startAutoNow(c, a, src);
    }

    static String startAutoNow(final Context c, JSONObject a, String src) {
        final boolean tg = "telegram".equals(src);
        String err = Automator.start(c, a, tg ? (ok, msg) -> Telegram.sendToOwner(c, msg) : null);
        if (err != null) return err;
        return "Starting automation '" + a.optString("name") + "'." + (tg ? " I will message you when it is done." : "");
    }

    static String run(Context c, String text, String src) {
        int sp = text.indexOf(' ');
        String cmd = (sp < 0 ? text : text.substring(0, sp)).toLowerCase(Locale.ROOT);
        int at = cmd.indexOf('@');
        if (at > 0) cmd = cmd.substring(0, at);
        String arg = sp < 0 ? "" : text.substring(sp + 1).trim();
        boolean tg = "telegram".equals(src);
        try {
            switch (cmd) {
                case "/start": case "/help": return help(c);
                case "/new":
                    if (tg) { Telegram.resetHistory(c); return "Started a fresh conversation."; }
                    return "Started a new chat.";
                case "/remember":
                    if (arg.isEmpty()) return "Usage: /remember <text>";
                    return Mem.add(c, arg) ? "Saved to memory." : "That is already in memory.";
                case "/memory": {
                    List<String> l = Mem.items(c);
                    StringBuilder b = new StringBuilder("Owner: ").append(Mem.owner(c).isEmpty() ? "(not set, use /name)" : Mem.owner(c)).append('\n');
                    if (l.isEmpty()) b.append("No saved memories yet.");
                    for (int i = 0; i < l.size(); i++) b.append(i + 1).append(". ").append(l.get(i)).append('\n');
                    return b.toString().trim();
                }
                case "/search": {
                    if (arg.isEmpty()) return "Usage: /search <words>";
                    List<String> r = Mem.search(c, arg);
                    if (r.isEmpty()) return "No memories match '" + arg + "'.";
                    StringBuilder b = new StringBuilder("Matching memories:\n");
                    for (String s : r) b.append("- ").append(s).append('\n');
                    return b.toString().trim();
                }
                case "/forget": {
                    String r = Mem.forget(c, Integer.parseInt(arg.trim()));
                    return r == null ? "No memory with that number. Use /memory to see the numbers." : "Forgot: " + r;
                }
                case "/name":
                    if (arg.isEmpty()) return "Usage: /name <your name>";
                    Mem.setOwner(c, arg);
                    return "Okay, I will call you " + arg + ".";
                case "/notify":
                    if (arg.isEmpty()) return "Usage: /notify <text>";
                    Notifier.show(c, "Krypton", arg);
                    return "Notification sent to the phone.";
                case "/remind": {
                    Matcher m = Pattern.compile("^(\\d+)\\s+([\\s\\S]+)$").matcher(arg);
                    if (!m.matches()) return "Usage: /remind <minutes> <text>";
                    int id = Reminders.add(c, Integer.parseInt(m.group(1)), m.group(2).trim());
                    return "Reminder set: " + Reminders.describeId(c, id);
                }
                case "/reminders": case "/pending": {
                    String s = Reminders.listText(c);
                    if (Automator.isRunning()) s += "\nRunning automation: " + Automator.statusText();
                    return s;
                }
                case "/editreminder": {
                    Matcher m = Pattern.compile("^(\\d+)\\s+(\\d+)\\s+([\\s\\S]+)$").matcher(arg);
                    if (!m.matches()) return "Usage: /editreminder <id> <minutes> <text>";
                    int id = Integer.parseInt(m.group(1));
                    if (!Reminders.edit(c, id, Integer.parseInt(m.group(2)), m.group(3).trim())) return "No reminder with id " + id + ".";
                    return "Reminder updated: " + Reminders.describeId(c, id);
                }
                case "/cancelreminder": {
                    int id = Integer.parseInt(arg.trim());
                    return Reminders.cancel(c, id) ? "Reminder #" + id + " cancelled." : "No reminder with id " + id + ".";
                }
                case "/auto": return auto(c, arg, src);
                case "/do":
                    if (arg.isEmpty()) return "Usage: /do <task>, for example /do open Instagram and send hii to Sam";
                    return deviceOk(c, src) ? Planner.start(c, arg, src) : DENIED;
                case "/screen": return screenQuestion(c, src, arg.isEmpty() ? "Describe what is on the screen briefly." : arg);
                case "/screenshot": return deviceOk(c, src) ? screenshotCmd(c, src) : DENIED;
                case "/latestscreenshot": return deviceOk(c, src) ? sendLatestScreenshot(c, src) : DENIED;
                case "/getfile": {
                    final File f = new File(arg);
                    if (arg.isEmpty()) return "Usage: /getfile <full path>";
                    if (!deviceOk(c, src)) return DENIED;
                    if (!f.isFile()) return "File not found: " + arg;
                    if (Telegram.config(c) == null) return "Telegram is not connected.";
                    return Guard.ask(c, src, "Send the file " + f.getName() + " to your Telegram bot chat", true, () -> {
                        String e = Telegram.sendFileToOwner(c, f, f.getName(), false);
                        return e == null ? "Sent " + f.getName() + " (Telegram confirmed it)." : "Could not send it: " + e;
                    });
                }
                case "/status": return statusText(c);
                case "/cancel":
                    Llm.cancelNow();
                    Automator.stop();
                    Planner.stop();
                    Vision.cancel();
                    Guard.clear(src);
                    return "Cancelling the current answer, phone task and automation.";
                case "/torch":
                    if (!deviceOk(c, src)) return DENIED;
                    return arg.equals("on") || arg.equals("off") ? Device.run(c, "torch " + arg, true) : "Usage: /torch on  or  /torch off";
                case "/battery": return Device.run(c, "battery", true);
                case "/open": return deviceOk(c, src) ? Device.run(c, "open website " + arg, true) : DENIED;
                case "/play": return deviceOk(c, src) ? Device.run(c, "play music " + arg, true) : DENIED;
                case "/stop": return deviceOk(c, src) ? Device.run(c, "stop music", true) : DENIED;
                case "/backup": return "Backup saved: " + Store.backup(c);
                default: return "Unknown command. Send /help to see all commands.";
            }
        } catch (NumberFormatException e) {
            return "That number is not valid. Send /help for the command format.";
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    static String auto(Context c, String arg, String src) {
        String[] p = arg.split("\\s+", 2);
        String sub = p[0].toLowerCase(Locale.ROOT), rest = p.length > 1 ? p[1].trim() : "";
        switch (sub) {
            case "list": {
                JSONArray a = Automations.load(c);
                if (a.length() == 0) return "No automations yet. Create one in Krypton > Settings > Automations.";
                StringBuilder b = new StringBuilder("Automations:\n");
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.optJSONObject(i);
                    b.append(i + 1).append(". ").append(o.optString("name")).append("  (say: '").append(o.optString("command")).append("')")
                            .append(o.optBoolean("enabled", true) ? "" : "  [disabled]").append('\n');
                }
                return b.toString().trim();
            }
            case "run": {
                if (!deviceOk(c, src)) return DENIED;
                JSONObject a = Automations.find(c, rest);
                if (a == null) return "No automation named '" + rest + "'. Use /auto list.";
                if (!a.optBoolean("enabled", true)) return "That automation is disabled. Use /auto enable " + a.optString("name");
                return startAuto(c, a, src);
            }
            case "stop":
                if (!Automator.isRunning()) return "No automation is running.";
                Automator.stop();
                return "Stopping '" + Automator.name + "'.";
            case "status": return Automator.statusText();
            case "enable": case "disable": {
                boolean on = sub.equals("enable");
                return Automations.setEnabled(c, rest, on) ? "Automation " + (on ? "enabled." : "disabled.") : "No automation named '" + rest + "'.";
            }
            case "delete": return Automations.delete(c, rest) ? "Automation deleted." : "No automation named '" + rest + "'.";
            default: return "Usage: /auto list | run <name> | stop | status | enable <name> | disable <name> | delete <name>";
        }
    }

    static String help(Context c) {
        StringBuilder b = new StringBuilder("Commands:\n");
        for (String[] r : TABLE) b.append(r[0]).append("\n   ").append(r[1]).append('\n');
        JSONArray a = Automations.load(c);
        if (a.length() > 0) {
            b.append("\nYour automation commands (just type them):\n");
            for (int i = 0; i < a.length(); i++)
                b.append("'").append(a.optJSONObject(i).optString("command")).append("' starts ").append(a.optJSONObject(i).optString("name")).append('\n');
        }
        return b.toString().trim();
    }

    static String hm(long t) { return new SimpleDateFormat("HH:mm", Locale.US).format(new Date(t)); }

    static String statusText(Context c) {
        StringBuilder s = new StringBuilder("Krypton status\n");
        s.append("AI server: ").append(Llm.healthy() ? "running" : "not running").append('\n');
        s.append("Telegram: ").append(Telegram.state).append('\n');
        String cur = Telegram.current;
        if (Llm.busy) cur = (cur != null ? cur : "Answering") + " (" + Llm.chars + " characters so far)";
        s.append("Current task: ").append(cur != null ? cur : "idle").append('\n');
        if (!Telegram.lastTask.isEmpty())
            s.append("Last task: ").append(Telegram.lastTask).append(" - ").append(Telegram.lastResult).append(" at ").append(hm(Telegram.lastTime)).append('\n');
        s.append("Last error: ").append(Telegram.lastError.isEmpty() ? "none" : Telegram.lastError).append('\n');
        s.append("Automation: ").append(Automator.statusText()).append('\n');
        s.append("Phone task: ").append(Planner.statusText()).append('\n');
        s.append("Gmail: ").append(Mail.state).append('
');
        s.append("Image model: ").append(Vision.activeName(c)).append('
');
        s.append("Pending reminders: ").append(Reminders.load(c).length()).append('\n');
        s.append("Memories saved: ").append(Mem.items(c).size()).append('\n');
        s.append(Device.battery(c));
        return s.toString();
    }

    /** Runs [[remember: ..]], [[notify: ..]] and [[remind: N | ..]] tags the model wrote, and removes them from the text. */
    static String processTags(Context c, String text) {
        Matcher m = Pattern.compile("\\[\\[(remember|notify|remind):([^\\]]*)\\]\\]", Pattern.CASE_INSENSITIVE).matcher(text);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String k = m.group(1).toLowerCase(Locale.ROOT), v = m.group(2).trim();
            try {
                if (k.equals("remember")) Mem.add(c, v);
                else if (k.equals("notify")) Notifier.show(c, "Krypton", v);
                else {
                    String[] p = v.split("\\|", 2);
                    int min = Integer.parseInt(p[0].trim());
                    if (min > 0) Reminders.add(c, min, p.length > 1 ? p[1].trim() : "Reminder");
                }
            } catch (Exception ignored) { }
            m.appendReplacement(sb, "");
        }
        m.appendTail(sb);
        return sb.toString().trim();
    }
}
