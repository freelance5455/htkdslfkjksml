package com.krypton.ai;

import android.content.Context;
import android.os.Environment;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

/** All Krypton user data (chats, memory, settings) lives in files/data. Backup = zip of those files. */
final class Store {
    static final String[] FILES = {"chats.json", "memory.json", "settings.json", "automations.json", "reminders.json"};
    static final String DEFAULT_MEMORY = "{\"owner\":\"\",\"permanent_knowledge\":[],\"short_term\":[]}";

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "data");
        d.mkdirs();
        return d;
    }

    static File backupDir() {
        return new File(Environment.getExternalStorageDirectory(), "Krypton/Backups");
    }

    static boolean isInitialized(Context c) { return new File(dir(c), ".init").exists(); }

    static String defaultFor(String file) {
        if (file.equals("chats.json") || file.equals("automations.json") || file.equals("reminders.json")) return "[]";
        if (file.equals("memory.json")) return DEFAULT_MEMORY;
        return "{}";
    }

    static synchronized String read(Context c, String name) {
        File f = new File(dir(c), name + ".json");
        if (!f.exists() || !isAllowed(name + ".json")) return "";
        try (FileInputStream in = new FileInputStream(f)) {
            return new String(readAll(in), "UTF-8");
        } catch (IOException e) { return ""; }
    }

    static synchronized void write(Context c, String file, String data) {
        if (!isAllowed(file)) return;
        try {
            File tmp = new File(dir(c), file + ".tmp");
            try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(data.getBytes("UTF-8")); }
            File dest = new File(dir(c), file);
            if (!tmp.renameTo(dest)) { dest.delete(); tmp.renameTo(dest); }
        } catch (IOException ignored) { }
    }

    static boolean isAllowed(String file) { return Arrays.asList(FILES).contains(file); }

    /** Fresh start: empty memory, empty chats. */
    static synchronized void initFresh(Context c) {
        for (String f : FILES) write(c, f, defaultFor(f));
        ImageStore.deleteAll(c);
        try { new File(dir(c), ".init").createNewFile(); } catch (IOException ignored) { }
    }

    /** "Clear my memory": chats + memory + Telegram conversation. Automations and reminders are kept. */
    static synchronized void clearMemory(Context c) {
        write(c, "chats.json", "[]");
        write(c, "memory.json", DEFAULT_MEMORY);
        new File(c.getFilesDir(), "tg_history.json").delete();
        new File(c.getFilesDir(), "hist_email.json").delete();
        ImageStore.deleteAll(c);
    }

    static String backup(Context c) throws IOException {
        File dir = backupDir();
        if (!dir.exists() && !dir.mkdirs())
            throw new IOException("Cannot create " + dir.getPath() + ". Allow storage access and try again.");
        String name = "krypton_backup_" + new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date()) + ".zip";
        File out = new File(dir, name);
        synchronized (Store.class) {
            try (ZipOutputStream z = new ZipOutputStream(new FileOutputStream(out))) {
                for (String n : FILES) {
                    File f = new File(dir(c), n);
                    if (!f.exists()) continue;
                    z.putNextEntry(new ZipEntry(n));
                    try (FileInputStream in = new FileInputStream(f)) { z.write(readAll(in)); }
                    z.closeEntry();
                }
                File[] imgs = ImageStore.dir(c).listFiles();
                if (imgs != null) for (File f : imgs) {
                    z.putNextEntry(new ZipEntry("images/" + f.getName()));
                    try (FileInputStream in = new FileInputStream(f)) { z.write(readAll(in)); }
                    z.closeEntry();
                }
                z.putNextEntry(new ZipEntry("backup_info.txt"));
                z.write(("Krypton backup\nCreated: " + new Date() + "\n").getBytes("UTF-8"));
                z.closeEntry();
            }
        }
        return out.getPath();
    }

    /** Returns null on success, otherwise an error message. */
    static String restoreLatest(Context c) {
        File[] zs = backupDir().listFiles((d, n) -> n.startsWith("krypton_backup") && n.endsWith(".zip"));
        if (zs == null || zs.length == 0)
            return "No Krypton backup found in " + backupDir().getPath() + ". If you have one, make sure storage access is allowed.";
        File best = zs[0];
        for (File f : zs) if (f.lastModified() > best.lastModified()) best = f;
        try (ZipInputStream z = new ZipInputStream(new FileInputStream(best))) {
            Map<String, byte[]> got = new HashMap<>();
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (isAllowed(e.getName())) got.put(e.getName(), readAll(z));
                else if (e.getName().matches("images/[A-Za-z0-9_-]+\\.(jpg|txt)")) {
                    try (FileOutputStream o = new FileOutputStream(new File(ImageStore.dir(c), e.getName().substring(7)))) { o.write(readAll(z)); }
                }
            }
            if (!got.containsKey("chats.json") && !got.containsKey("memory.json"))
                return "The latest backup file is not a valid Krypton backup.";
            for (String n : FILES)
                write(c, n, got.containsKey(n) ? new String(got.get(n), "UTF-8") : defaultFor(n));
            new File(dir(c), ".init").createNewFile();
        } catch (IOException ex) {
            return "Could not read the backup: " + ex.getMessage();
        }
        return null;
    }

    static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return bo.toByteArray();
    }
}
