package com.krypton.ai;

import android.content.Context;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.json.JSONObject;

/**
 * Approval gate for sensitive actions. One pending request per channel ("ui" = the app).
 * needPw = the Personal Password must be given. Otherwise a YES/NO confirmation is enough.
 * Email can never carry the password, so password-protected actions are refused there.
 */
final class Guard {
    static class Pending {
        String desc; boolean needPw; long expires; Callable<String> action; int tries;
    }

    static final Map<String, Pending> pend = new HashMap<>();

    static synchronized boolean hasPending(String src) {
        Pending p = pend.get(Channel.key(src));
        if (p != null && p.expires < System.currentTimeMillis()) { pend.remove(Channel.key(src)); return false; }
        return p != null;
    }

    static synchronized void clear(String src) { pend.remove(Channel.key(src)); }

    static boolean needsPassword(String src) { Pending p = pend.get(Channel.key(src)); return p != null && p.needPw; }

    /** Starts an approval request. Returns the text to show to the user. */
    static synchronized String ask(Context c, String src, String desc, boolean needPw, Callable<String> action) {
        String k = Channel.key(src);
        if (needPw) {
            if ("email".equals(k)) return "This action needs your Personal Password, and a password must not be sent by email. Do it from the Krypton app or Telegram instead.";
            if (!Vault.isSet(c)) return "This action is protected. Create your Personal Password first: Krypton > Settings > Personal Password.";
            if (Vault.lockedSeconds(c) > 0) return "Password checks are locked for " + Vault.lockedSeconds(c) + " more seconds.";
        }
        Pending p = new Pending();
        p.desc = desc; p.needPw = needPw; p.action = action; p.expires = System.currentTimeMillis() + 3 * 60000L;
        pend.put(k, p);
        if (k.equals("ui")) {
            Notifier.show(c, "Krypton needs your approval", desc);
            return "Waiting for your approval: " + desc;
        }
        return "Approval needed: " + desc + "\n" + (needPw ? "Reply with your Personal Password to approve, or send 'cancel'."
                : "Reply YES to approve or NO to cancel.");
    }

    /** Handles the user's answer. Returns the text to send back. */
    static String answer(Context c, String src, String text) {
        String k = Channel.key(src);
        Pending p;
        synchronized (Guard.class) {
            p = pend.get(k);
            if (p == null || p.expires < System.currentTimeMillis()) { pend.remove(k); return "Nothing is waiting for approval."; }
            String t = text.trim().toLowerCase();
            if (t.equals("cancel") || t.equals("no") || t.equals("n") || t.equals("deny")) { pend.remove(k); return runDeny(p); }
            if (p.needPw) {
                if (!Vault.verify(c, text)) {
                    long l = Vault.lockedSeconds(c);
                    if (l > 0) { pend.remove(k); return "Too many wrong attempts. Locked for " + l + " seconds. The request was cancelled."; }
                    return "Wrong password. Try again or send 'cancel'.";
                }
            } else if (!(t.equals("yes") || t.equals("y") || t.equals("approve") || t.equals("ok"))) {
                return "Please reply YES to approve or NO to cancel.";
            }
            pend.remove(k);
        }
        try { return p.action.call(); } catch (Exception e) { return "Error: " + e.getMessage(); }
    }

    /** A denied request never runs its action. */
    static String runDeny(Pending p) { return "Cancelled."; }

    /** For a long-running task that must pause for approval (for example before pressing Send). */
    static boolean confirmBlocking(Context c, String src, String desc, boolean needPw) {
        final CountDownLatch l = new CountDownLatch(1);
        final boolean[] approved = {false};
        String prompt = ask(c, src, desc, needPw, () -> { approved[0] = true; l.countDown(); return "Approved. Continuing."; });
        if (!hasPending(src)) { Channel.send(c, src, prompt); return false; }   // refused (no password, email...)
        if (!"ui".equals(Channel.key(src))) Channel.send(c, src, prompt);
        // watcher: if the pending request disappears without approval it was denied/expired
        try {
            for (int i = 0; i < 180 && !approved[0]; i++) {
                if (l.await(1, TimeUnit.SECONDS)) break;
                if (!hasPending(src)) break;
            }
        } catch (InterruptedException ignored) { }
        return approved[0];
    }

    static synchronized String uiPromptJson() {
        Pending p = pend.get("ui");
        if (p == null || p.expires < System.currentTimeMillis()) return "";
        try { return new JSONObject().put("desc", p.desc).put("needPw", p.needPw).toString(); } catch (Exception e) { return ""; }
    }
}
