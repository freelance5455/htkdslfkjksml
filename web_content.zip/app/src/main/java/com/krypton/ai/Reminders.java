package com.krypton.ai;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

/** Reminders: saved in reminders.json, fired by AlarmManager, re-created after reboot. */
final class Reminders {
    static synchronized JSONArray load(Context c) {
        try {
            String s = Store.read(c, "reminders");
            return new JSONArray(s.isEmpty() ? "[]" : s);
        } catch (Exception e) { return new JSONArray(); }
    }

    static synchronized void save(Context c, JSONArray a) { Store.write(c, "reminders.json", a.toString()); }

    static synchronized int add(Context c, int minutes, String text) {
        JSONArray a = load(c);
        int id = 1;
        for (int i = 0; i < a.length(); i++) id = Math.max(id, a.optJSONObject(i).optInt("id") + 1);
        long when = System.currentTimeMillis() + Math.max(1, minutes) * 60000L;
        try {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("text", text); o.put("when", when);
            a.put(o);
        } catch (Exception ignored) { }
        save(c, a);
        schedule(c, id, when);
        return id;
    }

    static synchronized boolean cancel(Context c, int id) {
        JSONArray a = load(c), keep = new JSONArray();
        boolean found = false;
        for (int i = 0; i < a.length(); i++) {
            if (a.optJSONObject(i).optInt("id") == id) found = true; else keep.put(a.optJSONObject(i));
        }
        if (found) { save(c, keep); cancelAlarm(c, id); }
        return found;
    }

    /** minutes <= 0 keeps the old time; text == null keeps the old text. */
    static synchronized boolean edit(Context c, int id, int minutes, String text) {
        JSONArray a = load(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o.optInt("id") != id) continue;
            try {
                if (minutes > 0) o.put("when", System.currentTimeMillis() + minutes * 60000L);
                if (text != null) o.put("text", text);
            } catch (Exception ignored) { }
            save(c, a);
            schedule(c, id, o.optLong("when"));
            return true;
        }
        return false;
    }

    /** Called when the alarm rings. Returns the reminder text, or null if it was cancelled meanwhile. */
    static synchronized String fire(Context c, int id) {
        JSONArray a = load(c), keep = new JSONArray();
        String text = null;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o.optInt("id") == id) text = o.optString("text"); else keep.put(o);
        }
        if (text != null) save(c, keep);
        return text;
    }

    static void rescheduleAll(Context c) {
        JSONArray a = load(c);
        long now = System.currentTimeMillis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            schedule(c, o.optInt("id"), Math.max(o.optLong("when"), now + 3000));
        }
    }

    static String describe(JSONObject o) {
        long when = o.optLong("when");
        long min = Math.max(0, (when - System.currentTimeMillis()) / 60000);
        return "#" + o.optInt("id") + " at " + new SimpleDateFormat("HH:mm", Locale.US).format(new Date(when))
                + " (in " + min + " min): " + o.optString("text");
    }

    static String listText(Context c) {
        JSONArray a = load(c);
        if (a.length() == 0) return "No pending reminders.";
        StringBuilder b = new StringBuilder("Pending reminders:\n");
        for (int i = 0; i < a.length(); i++) b.append(describe(a.optJSONObject(i))).append('\n');
        return b.toString().trim();
    }

    static String describeId(Context c, int id) {
        JSONArray a = load(c);
        for (int i = 0; i < a.length(); i++) if (a.optJSONObject(i).optInt("id") == id) return describe(a.optJSONObject(i));
        return "#" + id;
    }

    static void schedule(Context c, int id, long when) {
        Intent i = new Intent(c, ReminderReceiver.class);
        i.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
    }

    static void cancelAlarm(Context c, int id) {
        PendingIntent pi = PendingIntent.getBroadcast(c, id, new Intent(c, ReminderReceiver.class),
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
            pi.cancel();
        }
    }
}
