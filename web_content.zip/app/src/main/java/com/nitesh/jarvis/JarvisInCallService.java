package com.nitesh.jarvis;

import android.telecom.Call;
import android.telecom.InCallService;

public class JarvisInCallService extends InCallService {
    private static volatile Call currentCall;

    @Override public void onCallAdded(Call call) {
        super.onCallAdded(call);
        currentCall = call;
        call.registerCallback(new Call.Callback() {
            @Override public void onStateChanged(Call c, int state) {
                if (state == Call.STATE_DISCONNECTED && currentCall == c) currentCall = null;
            }
        });
    }

    @Override public void onCallRemoved(Call call) {
        if (currentCall == call) currentCall = null;
        super.onCallRemoved(call);
    }

    public static boolean answerCurrentCall() {
        Call c = currentCall;
        if (c != null && c.getState() == Call.STATE_RINGING) {
            c.answer(android.telecom.VideoProfile.STATE_AUDIO_ONLY);
            return true;
        }
        return false;
    }

    public static boolean rejectCurrentCall() {
        Call c = currentCall;
        if (c != null && c.getState() == Call.STATE_RINGING) {
            c.reject(false, null);
            return true;
        }
        return false;
    }
}
