package com.nitesh.jarvis;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private static final int REQ_SPEECH = 41;
    private DevicePolicyManager dpm;
    private ComponentName admin;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        dpm = (DevicePolicyManager)getSystemService(Context.DEVICE_POLICY_SERVICE);
        admin = new ComponentName(this, JarvisAdminReceiver.class);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(Locale.US);
        });
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void speak(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }

    private void startSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Speech recognition is not available on this device."); return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onError(int e) { sendResult(""); }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                sendResult(r != null && !r.isEmpty() ? r.get(0) : "");
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle p) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN");
        recognizer.startListening(i);
    }

    private void sendResult(String result) {
        String safe = result.replace("\\", "\\\\").replace("'", "\\'");
        runOnUiThread(() -> web.evaluateJavascript("window.onJarvisSpeech && window.onJarvisSpeech('" + safe + "')", null));
    }

    private class Bridge {
        @JavascriptInterface public void speakText(String text) { runOnUiThread(() -> speak(text)); }
        @JavascriptInterface public void listen() { runOnUiThread(() -> startSpeech()); }
        @JavascriptInterface public void requestLockPermission() {
            runOnUiThread(() -> {
                if (!dpm.isAdminActive(admin)) {
                    Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                    i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
                    i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allow JARVIS to lock the screen when you request it.");
                    startActivity(i);
                } else Toast.makeText(MainActivity.this, "Screen-lock permission is already enabled.", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void lockScreen() {
            runOnUiThread(() -> {
                if (dpm.isAdminActive(admin)) dpm.lockNow();
                else Toast.makeText(MainActivity.this, "First enable screen-lock permission.", Toast.LENGTH_LONG).show();
            });
        }
        @JavascriptInterface public void answerCall() {
            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                JarvisInCallService.answerCurrentCall() ? "Answering call" : "No ringing call available", Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void rejectCall() {
            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                JarvisInCallService.rejectCurrentCall() ? "Rejecting call" : "No ringing call available", Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void requestCallRole() {
            runOnUiThread(() -> {
                android.telecom.TelecomManager tm = (android.telecom.TelecomManager)getSystemService(TELECOM_SERVICE);
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    if (!getPackageName().equals(tm.getDefaultDialerPackage())) {
                        Intent intent = new Intent(android.telecom.TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
                        intent.putExtra(android.telecom.TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, getPackageName());
                        startActivity(intent);
                    }
                } else Toast.makeText(MainActivity.this, "Default dialer role requires Android 10 or newer in this starter.", Toast.LENGTH_LONG).show();
            });
        }
        @JavascriptInterface public void launchApp(String packageName) {
            runOnUiThread(() -> {
                Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
                if (i != null) startActivity(i);
                else Toast.makeText(MainActivity.this, "App not found.", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public String getBattery() {
            android.content.IntentFilter f = new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent b = registerReceiver(null, f);
            return b == null ? "Battery status unavailable" :
                b.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) + "%";
        }
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
