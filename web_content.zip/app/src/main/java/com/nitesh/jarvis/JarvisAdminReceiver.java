package com.nitesh.jarvis;

import android.app.admin.DeviceAdminReceiver;

public class JarvisAdminReceiver extends DeviceAdminReceiver { }
