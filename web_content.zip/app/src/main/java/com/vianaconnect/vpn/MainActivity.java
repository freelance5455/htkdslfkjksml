package com.vianaconnect.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.vianaconnect.vpn.service.VianaVpnService;

public class MainActivity extends AppCompatActivity {
    private static final int VPN_REQUEST_CODE = 0x0F;
    private WebView webView;
    private String pendingServer = "192.168.142.164";
    private int pendingPort = 53;
    private String pendingOperator = "AFRICELL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        // Native Android Bridge for Real System VPN Tunnel
        webView.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void startVpn(String operator, String serverIp, int port) {
                pendingOperator = operator;
                pendingServer = serverIp;
                pendingPort = port;
                runOnUiThread(() -> requestVpnPermission());
            }

            @JavascriptInterface
            public void stopVpn() {
                runOnUiThread(() -> {
                    Intent intent = new Intent(MainActivity.this, VianaVpnService.class);
                    intent.setAction(VianaVpnService.ACTION_DISCONNECT);
                    startService(intent);
                    Toast.makeText(MainActivity.this, "VPN Desconectada com sucesso", Toast.LENGTH_SHORT).show();
                });
            }
        }, "AndroidVPN");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void requestVpnPermission() {
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            // Prompts official Android system dialog with 🔑 icon
            startActivityForResult(intent, VPN_REQUEST_CODE);
        } else {
            // Already authorized by user
            onActivityResult(VPN_REQUEST_CODE, Activity.RESULT_OK, null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            Intent serviceIntent = new Intent(this, VianaVpnService.class);
            serviceIntent.setAction(VianaVpnService.ACTION_CONNECT);
            serviceIntent.putExtra("SERVER_IP", pendingServer);
            serviceIntent.putExtra("PORT", pendingPort);
            serviceIntent.putExtra("OPERATOR", pendingOperator);
            startService(serviceIntent);
            Toast.makeText(this, "Conectando ao túnel VPN oficial...", Toast.LENGTH_LONG).show();
        } else if (requestCode == VPN_REQUEST_CODE) {
            Toast.makeText(this, "Permissão de VPN recusada pelo usuário.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
