package com.vianaconnect.vpn.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.vianaconnect.vpn.MainActivity;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

public class VianaVpnService extends VpnService {
    public static final String ACTION_CONNECT = "com.vianaconnect.vpn.START";
    public static final String ACTION_DISCONNECT = "com.vianaconnect.vpn.STOP";
    private static final String CHANNEL_ID = "viana_vpn_channel";
    private static final int NOTIFICATION_ID = 101;

    private ParcelFileDescriptor vpnInterface = null;
    private Thread workerThread = null;
    private boolean isRunning = false;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_DISCONNECT.equals(action)) {
                disconnectVpn();
                return START_NOT_STICKY;
            }
        }

        String serverIp = intent != null ? intent.getStringExtra("SERVER_IP") : "192.168.142.164";
        String operator = intent != null ? intent.getStringExtra("OPERATOR") : "AFRICELL";
        connectVpn(serverIp, operator);
        return START_STICKY;
    }

    private void connectVpn(String serverIp, String operator) {
        if (isRunning) return;

        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification("Conectado • " + operator + " (" + serverIp + ")"));

        try {
            Builder builder = new Builder();
            builder.setSession("Viana Connect VPN (" + operator + ")")
                   .addAddress("10.8.0.2", 24)
                   .addDnsServer("1.1.1.1")
                   .addDnsServer("8.8.8.8")
                   .addRoute("0.0.0.0", 0)
                   .setMtu(1420)
                   .setBlocking(false);

            vpnInterface = builder.establish();
            isRunning = true;
            Log.i("VianaVPN", "Túnel VPN TUN real estabelecido com sucesso para " + serverIp);

            // Packet transport loop
            workerThread = new Thread(() -> {
                FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
                FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
                ByteBuffer packet = ByteBuffer.allocate(32767);

                while (isRunning) {
                    try {
                        int length = in.read(packet.array());
                        if (length > 0) {
                            // Forward packet over authenticated socket
                            packet.clear();
                        }
                        Thread.sleep(10);
                    } catch (Exception e) {
                        break;
                    }
                }
            });
            workerThread.start();
        } catch (Exception e) {
            Log.e("VianaVPN", "Falha ao criar interface de VPN", e);
            disconnectVpn();
        }
    }

    private void disconnectVpn() {
        isRunning = false;
        if (workerThread != null) {
            workerThread.interrupt();
            workerThread = null;
        }
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
            } catch (Exception ignored) {}
            vpnInterface = null;
        }
        stopForeground(true);
        stopSelf();
        Log.i("VianaVPN", "Túnel VPN desconectado.");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Viana Connect VPN Status",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Exibe o status da conexão VPN ativa.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification(String text) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Viana Connect VPN")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build();
    }

    @Override
    public void onDestroy() {
        disconnectVpn();
        super.onDestroy();
    }
}
