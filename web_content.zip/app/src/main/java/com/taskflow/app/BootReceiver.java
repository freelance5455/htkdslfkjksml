package com.taskflow.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i) {
   // Task alarms can be restored after reboot by the app's persisted task store.
   // Open TaskFlow once after installation to initialize notification permission.
 }
}
