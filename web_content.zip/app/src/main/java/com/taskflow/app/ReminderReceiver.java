package com.taskflow.app;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String id=i.getStringExtra("id"), title=i.getStringExtra("title");
        int interval=i.getIntExtra("interval",15);
        if(id==null)return;
        String channel="taskflow_reminders";
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(channel,"Task reminders",NotificationManager.IMPORTANCE_HIGH));
        Intent open=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        PendingIntent content=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
        nm.notify(id.hashCode(),b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("TaskFlow reminder").setContentText(title==null?"You have an unfinished task":title).setAutoCancel(true).setContentIntent(content).build());
        // Repeating reminders are scheduled by the app while it is active; completing a task cancels its alarm.
        // Android may defer alarms under battery restrictions.
    }
}
