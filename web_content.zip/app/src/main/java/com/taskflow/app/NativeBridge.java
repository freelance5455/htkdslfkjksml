package com.taskflow.app;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.provider.Settings;
import android.net.Uri;
import android.webkit.JavascriptInterface;

public class NativeBridge {
    private final MainActivity activity;
    NativeBridge(MainActivity a) { activity=a; }
    @JavascriptInterface public void schedule(String id, String title, long when, int intervalMinutes) {
        Intent i=new Intent(activity, ReminderReceiver.class);
        i.putExtra("id",id); i.putExtra("title",title); i.putExtra("interval",intervalMinutes);
        PendingIntent pi=PendingIntent.getBroadcast(activity,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)activity.getSystemService(Context.ALARM_SERVICE);
        long trigger=Math.max(when,System.currentTimeMillis()+1000);
        if (Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
            Intent settings=new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+activity.getPackageName()));
            settings.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); activity.startActivity(settings);
        }
        if (Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,trigger,pi);
        else am.set(AlarmManager.RTC_WAKEUP,trigger,pi);
    }
    @JavascriptInterface public void cancel(String id) {
        Intent i=new Intent(activity,ReminderReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(activity,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager)activity.getSystemService(Context.ALARM_SERVICE)).cancel(pi); pi.cancel();
    }
}
