package com.screenshare.phone;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class PhoneWebSocketServer {
    private final int port;
    private volatile boolean running;
    private ServerSocket serverSocket;
    private Thread acceptThread;
    private final List<Client> clients = new CopyOnWriteArrayList<>();

    public PhoneWebSocketServer(int port) { this.port = port; }

    public void start() throws IOException {
        if (running) return;
        serverSocket = new ServerSocket();
        serverSocket.setReuseAddress(true);
        serverSocket.bind(new InetSocketAddress(port));
        running = true;
        acceptThread = new Thread(() -> {
            while (running) {
                try {
                    Socket socket = serverSocket.accept();
                    Thread t = new Thread(() -> handle(socket), "ws-client");
                    t.start();
                } catch (IOException ignored) {
                    if (running) {}
                }
            }
        }, "ws-accept");
        acceptThread.start();
    }

    public void stopServer() {
        running = false;
        try { if (serverSocket != null) serverSocket.close(); } catch (Exception ignored) {}
        for (Client c : clients) c.close();
        clients.clear();
    }

    private void handle(Socket socket) {
        Client client = new Client(socket);
        try {
            client.handshake();
            clients.add(client);
            while (running && !socket.isClosed()) {
                String msg = client.readText();
                if (msg == null) break;
                // Minimal signaling relay: messages containing a room are broadcast
                // to other connected clients. The Android screen/WebRTC layer can
                // build on this channel.
                for (Client other : clients) {
                    if (other != client) other.sendText(msg);
                }
            }
        } catch (Exception ignored) {
        } finally {
            clients.remove(client);
            client.close();
        }
    }

    private static class Client {
        final Socket socket;
        final InputStream in;
        final OutputStream out;

        Client(Socket s) throws IOException {
            socket = s;
            in = s.getInputStream();
            out = s.getOutputStream();
        }

        void handshake() throws Exception {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.ISO_8859_1));
            String line, key = null;
            while ((line = r.readLine()) != null && !line.isEmpty()) {
                if (line.toLowerCase(Locale.US).startsWith("sec-websocket-key:"))
                    key = line.substring(line.indexOf(':') + 1).trim();
            }
            if (key == null) throw new IOException("Missing WebSocket key");
            String accept = Base64.getEncoder().encodeToString(
                MessageDigest.getInstance("SHA-1").digest(
                    (key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.ISO_8859_1)
                )
            );
            String response =
                "HTTP/1.1 101 Switching Protocols\r\n" +
                "Upgrade: websocket\r\n" +
                "Connection: Upgrade\r\n" +
                "Sec-WebSocket-Accept: " + accept + "\r\n\r\n";
            out.write(response.getBytes(StandardCharsets.ISO_8859_1));
            out.flush();
        }

        String readText() throws IOException {
            int b1 = in.read(), b2 = in.read();
            if (b1 < 0 || b2 < 0) return null;
            int opcode = b1 & 0x0F;
            boolean masked = (b2 & 0x80) != 0;
            long len = b2 & 0x7F;
            if (len == 126) len = ((in.read() & 255) << 8) | (in.read() & 255);
            else if (len == 127) {
                len = 0;
                for (int i=0;i<8;i++) len = (len << 8) | (in.read() & 255);
            }
            if (len > 2_000_000) throw new IOException("Frame too large");
            byte[] mask = masked ? readFully(4) : null;
            byte[] data = readFully((int)len);
            if (masked) for (int i=0;i<data.length;i++) data[i] ^= mask[i%4];
            if (opcode == 8) return null;
            if (opcode == 9) { sendFrame(10, data); return ""; }
            if (opcode != 1) return "";
            return new String(data, StandardCharsets.UTF_8);
        }

        void sendText(String s) throws IOException {
            sendFrame(1, s.getBytes(StandardCharsets.UTF_8));
        }

        void sendFrame(int opcode, byte[] data) throws IOException {
            synchronized (out) {
                out.write(0x80 | opcode);
                if (data.length < 126) out.write(data.length);
                else if (data.length <= 65535) {
                    out.write(126); out.write((data.length >> 8) & 255); out.write(data.length & 255);
                } else {
                    out.write(127);
                    long n = data.length;
                    for (int i=7;i>=0;i--) out.write((int)(n >> (8*i)) & 255);
                }
                out.write(data); out.flush();
            }
        }

        byte[] readFully(int n) throws IOException {
            byte[] b = new byte[n]; int p=0;
            while (p<n) { int r=in.read(b,p,n-p); if (r<0) throw new EOFException(); p+=r; }
            return b;
        }

        void close() {
            try { socket.close(); } catch (Exception ignored) {}
        }
    }
}
