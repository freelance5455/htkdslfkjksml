package com.screenshare.phone;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private PhoneWebSocketServer server;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        server = new PhoneWebSocketServer(8080);
        try {
            server.start();
        } catch (Exception e) {
            Toast.makeText(this, "تعذر تشغيل السيرفر: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

        WebView web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
    }

    @Override protected void onDestroy() {
        if (server != null) server.stopServer();
        super.onDestroy();
    }
}
