package com.workshop.equipment;

import android.app.Activity;
import android.content.*;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.view.*;
import android.webkit.*;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private static final int REQ_TREE = 7001;
    private static final int REQ_FILES = 7002;
    private ValueCallback<Uri[]> fileCallback;
    private SharedPreferences prefs;
    private float downX, downY;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(11,15,20));
        getWindow().setNavigationBarColor(Color.rgb(11,15,20));
        prefs = getSharedPreferences("equipment_android", MODE_PRIVATE);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBlockNetworkLoads(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setDefaultTextEncodingName("UTF-8");
        web.setBackgroundColor(Color.rgb(11,15,20));
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(params.getAcceptTypes()!=null && params.getAcceptTypes().length>0 && params.getAcceptTypes()[0].length()>0 ? params.getAcceptTypes()[0] : "*/*");
                if(params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                try{ startActivityForResult(i,REQ_FILES); }catch(Exception e){ fileCallback=null; cb.onReceiveValue(null); }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){ downX=e.getX(); downY=e.getY(); }
            else if(e.getAction()==MotionEvent.ACTION_UP){
                float dx=e.getX()-downX, dy=e.getY()-downY;
                if(downX>55 && dx < -140 && Math.abs(dx)>Math.abs(dy)*1.3f){
                    web.evaluateJavascript("if(typeof Android!=='undefined'&&window.androidGoBack){androidGoBack()}else{history.back();}",null);
                    return true;
                }
            }
            return false;
        });
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_TREE){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){
                Uri u=data.getData();
                try{ getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION); }catch(Exception ignored){}
                prefs.edit().putString("tree_uri",u.toString()).putString("tree_name",queryDisplayName(u)).apply();
                String n=prefs.getString("tree_name","مجلد النسخه برنامج الورشه");
                js("window.__androidFolderPicked(true,"+jsq(n)+",null);");
            }else js("window.__androidFolderPicked(false,null,'تم إلغاء اختيار المجلد');");
        } else if(requestCode==REQ_FILES){
            if(fileCallback==null) return;
            Uri[] out=null;
            if(resultCode==RESULT_OK && data!=null){
                if(data.getClipData()!=null){
                    int c=data.getClipData().getItemCount(); out=new Uri[c];
                    for(int i=0;i<c;i++) out[i]=data.getClipData().getItemAt(i).getUri();
                } else if(data.getData()!=null) out=new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(out); fileCallback=null;
        }
    }

    private void js(String code){ runOnUiThread(()->web.evaluateJavascript(code,null)); }
    private static String jsq(String s){ return JSONObject.quote(s==null?"":s); }

    private Uri tree(){ String x=prefs.getString("tree_uri",null); return x==null?null:Uri.parse(x); }
    private String rootDocId(){ Uri u=tree(); return u==null?null:DocumentsContract.getTreeDocumentId(u); }

    private Uri childUri(Uri parent,String childName,boolean dir,boolean create,String mime){
        try{
            String parentId=DocumentsContract.getDocumentId(parent);
            Uri q=DocumentsContract.buildChildDocumentsUriUsingTree(parent,parentId);
            String found=null;
            try(android.database.Cursor c=getContentResolver().query(q,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
                if(c!=null) while(c.moveToNext()) if(childName.equals(c.getString(1))){found=c.getString(0);break;}
            }
            if(found!=null) return DocumentsContract.buildDocumentUriUsingTree(parent,found);
            if(!create) return null;
            Uri r=DocumentsContract.createDocument(getContentResolver(),parent,dir?DocumentsContract.Document.MIME_TYPE_DIR:(mime==null?mimeFor(childName):mime),childName);
            return r;
        }catch(Exception e){ return null; }
    }
    private Uri resolveDir(String path,boolean create){
        Uri r=tree(); if(r==null) return null; if(path==null||path.isEmpty()) return r;
        for(String part:path.split("/")){ if(part.isEmpty()) continue; r=childUri(r,part,true,create,null); if(r==null) return null; }
        return r;
    }
    private Uri resolveFile(String path,boolean create,String mime){
        int slash=path.lastIndexOf('/'); String d=slash>=0?path.substring(0,slash):""; String n=slash>=0?path.substring(slash+1):path;
        Uri parent=resolveDir(d,create); if(parent==null)return null; return childUri(parent,n,false,create,mime);
    }
    private String mimeFor(String n){
        String x=n.toLowerCase(Locale.ROOT);
        if(x.endsWith(".json"))return "application/json"; if(x.endsWith(".jsonl"))return "application/json"; if(x.endsWith(".txt"))return "text/plain"; if(x.endsWith(".html"))return "text/html"; if(x.endsWith(".jpg")||x.endsWith(".jpeg"))return "image/jpeg"; if(x.endsWith(".png"))return "image/png"; if(x.endsWith(".pdf"))return "application/pdf"; return "application/octet-stream";
    }

    private class AndroidBridge {
        @android.webkit.JavascriptInterface public void pickFolder(){
            runOnUiThread(()->{ try{ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION); startActivityForResult(i,REQ_TREE); }catch(Exception e){ js("window.__androidFolderPicked(false,null,"+jsq(e.toString())+");"); } });
        }
        @android.webkit.JavascriptInterface public String getLinkedFolderName(){ return prefs.getString("tree_name",""); }
        @android.webkit.JavascriptInterface public String list(String path){
            try{
                Uri dir=resolveDir(path,false); if(dir==null)return "[]";
                String id=DocumentsContract.getDocumentId(dir); Uri q=DocumentsContract.buildChildDocumentsUriUsingTree(dir,id);
                JSONArray a=new JSONArray();
                try(android.database.Cursor c=getContentResolver().query(q,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE},null,null,null)){
                    if(c!=null) while(c.moveToNext()){ JSONObject o=new JSONObject(); o.put("name",c.getString(1)); o.put("kind",DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2))?"directory":"file"); a.put(o); }
                }
                return a.toString();
            }catch(Exception e){ return "[]"; }
        }
        @android.webkit.JavascriptInterface public void makeDir(String path){ resolveDir(path,true); }
        private final Map<String,OutputStream> writeStreams = new HashMap<>();
        @android.webkit.JavascriptInterface public String readFileMeta(String path){
            try{
                Uri f=resolveFile(path,false,null);
                if(f==null)return new JSONObject().put("size",0).put("name",path.substring(path.lastIndexOf('/')+1)).put("mime","").toString();
                long size=0;
                try(android.database.Cursor c=getContentResolver().query(f,new String[]{DocumentsContract.Document.COLUMN_SIZE},null,null,null)){
                    if(c!=null&&c.moveToFirst()&&!c.isNull(0)) size=c.getLong(0);
                }
                JSONObject o=new JSONObject(); o.put("size",size); o.put("name",path.substring(path.lastIndexOf('/')+1)); o.put("mime",getContentResolver().getType(f)); return o.toString();
            }catch(Exception e){ throw new RuntimeException(e); }
        }
        @android.webkit.JavascriptInterface public String readFileChunk(String path,long offset,int length){
            try{
                Uri f=resolveFile(path,false,null); if(f==null)return "";
                try(InputStream in=getContentResolver().openInputStream(f)){
                    if(in==null)throw new IOException("Cannot open input");
                    long skip=offset; while(skip>0){ long n=in.skip(skip); if(n<=0)break; skip-=n; }
                    byte[] buf=new byte[Math.max(1,Math.min(length,1024*1024))]; int n=in.read(buf);
                    if(n<=0)return ""; return Base64.encodeToString(Arrays.copyOf(buf,n),Base64.NO_WRAP);
                }
            }catch(Exception e){ throw new RuntimeException(e); }
        }
        @android.webkit.JavascriptInterface public String beginWrite(String path,String name){
            try{
                Uri f=resolveFile(path,true,mimeFor(name==null?path:name)); if(f==null)throw new IOException("Cannot create file");
                OutputStream out=getContentResolver().openOutputStream(f,"wt"); if(out==null)throw new IOException("Cannot open output");
                String token=UUID.randomUUID().toString(); writeStreams.put(token,out); return token;
            }catch(Exception e){ throw new RuntimeException(e); }
        }
        @android.webkit.JavascriptInterface public void writeChunk(String token,String base64){
            OutputStream out=writeStreams.get(token); if(out==null)throw new IllegalStateException("write-session-not-found");
            try{ out.write(Base64.decode(base64,Base64.DEFAULT)); }catch(Exception e){ throw new RuntimeException(e); }
        }
        @android.webkit.JavascriptInterface public void endWrite(String token,boolean abort){
            OutputStream out=writeStreams.remove(token); if(out==null)return;
            try{ if(abort){ try{out.close();}catch(Exception ignored){} } else {out.flush();out.close();} }catch(Exception e){throw new RuntimeException(e);}
        }
        @android.webkit.JavascriptInterface public void deletePath(String path,boolean recursive){
            try{ Uri f=resolveFile(path,false,null); if(f==null)f=resolveDir(path,false); if(f==null)return; if(recursive)deleteRecursive(f); else DocumentsContract.deleteDocument(getContentResolver(),f); }catch(Exception ignored){}
        }
        @android.webkit.JavascriptInterface public void clearLinkedFolder(){ prefs.edit().remove("tree_uri").remove("tree_name").apply(); }
        @android.webkit.JavascriptInterface public String stat(String path){ try{ return resolveDir(path,false)!=null?"directory":(resolveFile(path,false,null)!=null?"file":"missing"); }catch(Exception e){return "missing";} }
    }

    private void deleteRecursive(Uri u)throws Exception{
        String mime=getContentResolver().getType(u);
        if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)){
            String id=DocumentsContract.getDocumentId(u); Uri q=DocumentsContract.buildChildDocumentsUriUsingTree(u,id);
            ArrayList<Uri> kids=new ArrayList<>();
            try(android.database.Cursor c=getContentResolver().query(q,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID},null,null,null)){
                if(c!=null)while(c.moveToNext())kids.add(DocumentsContract.buildDocumentUriUsingTree(u,c.getString(0)));
            }
            for(Uri k:kids)deleteRecursive(k);
        }
        DocumentsContract.deleteDocument(getContentResolver(),u);
    }
    private byte[] readAll(InputStream in)throws IOException{ if(in==null)throw new IOException("null stream"); ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)b.write(buf,0,n); in.close(); return b.toByteArray(); }
    private String queryDisplayName(Uri u){
        try(android.database.Cursor c=getContentResolver().query(u,new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)){ if(c!=null&&c.moveToFirst())return c.getString(0); }
        catch(Exception ignored){} return "مجلد النسخه برنامج الورشه";
    }
    @Override public void onBackPressed(){
        web.evaluateJavascript("if(typeof window.androidGoBack==='function'){window.androidGoBack()}else{history.back();}",null);
    }
}
