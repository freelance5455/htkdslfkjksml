package com.haneesh.os

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 21, 44)
        window.navigationBarColor = Color.rgb(7, 21, 44)
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(7, 21, 44))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        val prefs = getSharedPreferences("haneesh_os", MODE_PRIVATE)
        if (!prefs.getBoolean("intro_seen", false)) {
            web.postDelayed({
                AlertDialog.Builder(this)
                    .setTitle("Welcome to Haneesh OS")
                    .setMessage("Explore the HTML design preview first, or choose Set as your OS to open Android's default Home app settings.")
                    .setPositiveButton("Set as your OS") { _, _ ->
                        prefs.edit().putBoolean("intro_seen", true).apply()
                        openHomeSettings()
                    }
                    .setNegativeButton("Preview first") { _, _ ->
                        prefs.edit().putBoolean("intro_seen", true).apply()
                    }
                    .setNeutralButton("Later", null)
                    .show()
            }, 450)
        }
    }

    private fun openHomeSettings() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Open Settings → Apps → Default apps → Home app, then select Haneesh OS.", Toast.LENGTH_LONG).show()
            }
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun setAsHome() {
            runOnUiThread { openHomeSettings() }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        web.evaluateJavascript(
            "(function(){var ids=['preview','gallery','launcher','controls','settings','notifications'];for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);if(e&&e.classList.contains('active')){document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));document.getElementById('welcome').classList.add('active');return 'handled';}}return 'home';})()"
        ) { result ->
            if (result == "\\"home\\"") super.onBackPressed()
        }
    }
}
