package com.haneesh.os

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

/** Native Android shell for the Haneesh OS launcher concept. */
class MainActivity : Activity() {
    private lateinit var web: WebView
    private var showingIntro = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 21, 44)
        window.navigationBarColor = Color.rgb(7, 21, 44)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.navigationBarDividerColor = Color.rgb(22, 48, 82)
        }
        window.decorView.systemUiVisibility = 0
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(3, 11, 25))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    // Keep local interface navigation inside the app.
                    return url?.startsWith("file:") != true
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(), "AndroidBridge")
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")

        val prefs = getSharedPreferences("haneesh_os", MODE_PRIVATE)
        if (!prefs.getBoolean("intro_seen_v3", false)) {
            web.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                showingIntro = true
                AlertDialog.Builder(this)
                    .setTitle("Welcome to Haneesh OS")
                    .setMessage("A motion-rich Android launcher concept with a custom home experience, app drawer, searchable apps, settings previews and quick-control designs. Tap Preview first to explore. Choose Set as your OS to open Android's official Home app settings. Android will ask you to confirm the default launcher.")
                    .setPositiveButton("Set as your OS") { _, _ ->
                        prefs.edit().putBoolean("intro_seen_v3", true).apply()
                        showingIntro = false
                        openHomeSettings()
                    }
                    .setNegativeButton("Preview first") { _, _ ->
                        prefs.edit().putBoolean("intro_seen_v3", true).apply()
                        showingIntro = false
                    }
                    .setNeutralButton("Later") { _, _ -> showingIntro = false }
                    .setOnCancelListener { showingIntro = false }
                    .show()
            }, 500)
        }
    }

    private fun openHomeSettings() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(
                    this,
                    "Open Settings → Apps → Default apps → Home app, then select Haneesh OS.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun vibrateLightly() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = getSystemService(VibratorManager::class.java)
                manager?.defaultVibrator?.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(12)
                }
            }
        } catch (_: Exception) {
            // Haptics are optional; the interface still works if unavailable.
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun setAsHome() {
            runOnUiThread { openHomeSettings() }
        }

        @JavascriptInterface
        fun haptic() {
            runOnUiThread { vibrateLightly() }
        }

        @JavascriptInterface
        fun openAndroidSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Open Android Settings from your phone.", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (::web.isInitialized && !showingIntro) {
            web.evaluateJavascript(
                "(function(){var ids=['preview','gallery','launcher','controls','settings','notifications'];for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);if(e&&e.classList.contains('active')){document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));document.getElementById('welcome').classList.add('active');return 'handled';}}return 'home';})()"
            ) { result ->
                if (result == "\"home\"") super.onBackPressed()
            }
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.removeJavascriptInterface("AndroidBridge")
            web.stopLoading()
            web.loadUrl("about:blank")
            web.destroy()
        }
        super.onDestroy()
    }
}
