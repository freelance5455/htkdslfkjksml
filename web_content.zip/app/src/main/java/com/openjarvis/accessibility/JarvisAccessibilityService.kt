package com.openjarvis.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction
import kotlinx.coroutines.delay
import java.util.ArrayDeque
import java.util.Locale

class JarvisAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or AccessibilityServiceInfo.FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY
            notificationTimeout = 80
        }
    }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun openAppByPackage(packageName: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }
    fun openAppByLabel(label: String): Boolean {
        val intent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val wanted = normalize(label)
        packageManager.queryIntentActivities(intent, 0).forEach {
            val appLabel = normalize(it.loadLabel(packageManager).toString())
            if (appLabel == wanted || appLabel.contains(wanted) || wanted.contains(appLabel)) return openAppByPackage(it.activityInfo.packageName)
        }
        return false
    }
    fun tapByText(text: String): Boolean {
        val node = findBestNode(text) ?: return false
        return clickNode(node)
    }
    fun longPressByText(text: String): Boolean {
        val node = findBestNode(text) ?: return false
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        node.recycle(); return ok
    }
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        val target = focused ?: findEditable(root)
        val ok = target?.let { setText(it, text) } ?: false
        target?.recycle(); root.recycle(); return ok
    }
    fun clearAndType(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root)
        if (focused == null) { root.recycle(); return false }
        val ok = setText(focused, text)
        focused.recycle(); root.recycle(); return ok
    }
    fun swipe(direction: String, distance: String = "medium"): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findScrollable(root)
        val ok = if (node != null) {
            val action = when(direction.lowercase(Locale.ROOT)) {
                "up" -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                "down" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                else -> 0
            }
            if (action != 0) node.performAction(action) else false
        } else false
        node?.recycle(); root.recycle(); return ok
    }
    fun scroll(direction: String): Boolean = swipe(direction, "medium")
    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun pressRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val out = StringBuilder()
        collectText(root, out)
        root.recycle()
        return out.toString().replace(Regex("\\s+"), " ").trim()
    }
    suspend fun waitForText(text: String, timeoutMs: Long = 4000): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs.coerceIn(250, 15000)
        while (System.currentTimeMillis() < deadline) {
            if (readScreen().contains(text, ignoreCase = true)) return true
            delay(200)
        }
        return false
    }

    private fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = node
        while (cur != null) {
            if (cur.isClickable && cur.isVisibleToUser) {
                val ok = cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                cur.recycle(); if (cur !== node) node.recycle(); return ok
            }
            cur = cur.parent
        }
        node.recycle(); return false
    }
    private fun findBestNode(text: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val wanted = normalize(text)
        val queue = ArrayDeque<AccessibilityNodeInfo>(); queue.add(root)
        var fallback: AccessibilityNodeInfo? = null
        while(queue.isNotEmpty()) {
            val n=queue.removeFirst()
            val a=normalize(n.text?.toString().orEmpty()); val d=normalize(n.contentDescription?.toString().orEmpty())
            if ((a == wanted || d == wanted) && n.isVisibleToUser) { root.recycle(); fallback?.recycle(); return n }
            if ((a.contains(wanted) || d.contains(wanted)) && n.isVisibleToUser && fallback==null) fallback=n else if (fallback !== n) n.recycle()
            for(i in 0 until n.childCount) n.getChild(i)?.let(queue::add)
        }
        root.recycle(); return fallback
    }
    private fun findEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val q=ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while(q.isNotEmpty()) { val n=q.removeFirst(); if(n.isEditable && n.isVisibleToUser) return n; for(i in 0 until n.childCount)n.getChild(i)?.let(q::add); n.recycle() }; return null
    }
    private fun findScrollable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val q=ArrayDeque<AccessibilityNodeInfo>(); q.add(root)
        while(q.isNotEmpty()){val n=q.removeFirst(); if(n.isScrollable && n.isVisibleToUser)return n; for(i in 0 until n.childCount)n.getChild(i)?.let(q::add); n.recycle()};return null
    }
    private fun collectText(n: AccessibilityNodeInfo,out:StringBuilder){n.text?.toString()?.takeIf{it.isNotBlank()}?.let{out.append(it).append(' ')};n.contentDescription?.toString()?.takeIf{it.isNotBlank()}?.let{out.append(it).append(' ')};for(i in 0 until n.childCount)n.getChild(i)?.let{collectText(it,out);it.recycle()}}
    private fun normalize(s:String)=s.lowercase(Locale("tr","TR")).replace("ı","i").trim()
    companion object { var instance: JarvisAccessibilityService? = null; private set }
}
