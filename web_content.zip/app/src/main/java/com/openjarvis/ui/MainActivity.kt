package com.openjarvis.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.openjarvis.accessibility.JarvisAccessibilityService

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(AndroidBridge(this@MainActivity), "AndroidJarvis")
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onDestroy() {
        webView.removeJavascriptInterface("AndroidJarvis")
        webView.destroy()
        super.onDestroy()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val component = ComponentName(this, JarvisAccessibilityService::class.java)
        return enabled.contains(component.flattenToString())
    }

    inner class AndroidBridge(private val activity: Activity) {
        @JavascriptInterface
        fun isNativeAndroid(): Boolean = true

        @JavascriptInterface
        fun isAccessibilityEnabled(): Boolean = isAccessibilityServiceEnabled()

        @JavascriptInterface
        fun enableAccessibility() {
            activity.runOnUiThread {
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        @JavascriptInterface
        fun openApp(packageName: String): Boolean {
            val service = JarvisAccessibilityService.instance
            if (service != null) {
                service.openAppByPackage(packageName)
                return true
            }
            val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            return true
        }

        @JavascriptInterface
        fun openWhatsApp(): Boolean = openApp("com.whatsapp")

        @JavascriptInterface
        fun tapText(text: String): Boolean =
            JarvisAccessibilityService.instance?.tapByText(text) ?: false

        @JavascriptInterface
        fun tapHint(hint: String): Boolean =
            JarvisAccessibilityService.instance?.tapByText(hint) ?: false

        @JavascriptInterface
        fun typeText(text: String): Boolean =
            JarvisAccessibilityService.instance?.typeText(text) ?: false

        @JavascriptInterface
        fun back(): Boolean = JarvisAccessibilityService.instance?.pressBack() ?: false

        @JavascriptInterface
        fun home(): Boolean = JarvisAccessibilityService.instance?.pressHome() ?: false

        @JavascriptInterface
        fun recents(): Boolean = JarvisAccessibilityService.instance?.pressRecents() ?: false

        @JavascriptInterface
        fun readScreen(): String =
            JarvisAccessibilityService.instance?.readVisibleScreen() ?: "Accessibility Service etkin değil."

        @JavascriptInterface
        fun sendWhatsApp(contact: String, message: String) {
            val service = JarvisAccessibilityService.instance
            if (service == null) {
                activity.runOnUiThread {
                    Toast.makeText(activity, "Önce Accessibility Service'i etkinleştir.", Toast.LENGTH_LONG).show()
                }
                return
            }
            service.sendWhatsAppMessage(contact, message)
        }

        @JavascriptInterface
        fun openAccessibilitySettings() = enableAccessibility()

        @JavascriptInterface
        fun openWhatsAppChat(contact: String): Boolean {
            // This uses WhatsApp's documented deep-link style. The fallback is the normal app UI.
            return try {
                val url = "https://wa.me/" + contact.filter { it.isDigit() }
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                true
            } catch (_: Exception) {
                openWhatsApp()
            }
        }
    }
}
