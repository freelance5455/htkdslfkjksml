package com.openjarvis.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.openjarvis.webbridge.JarvisWebBridge

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val voiceRequest = 501
    private val contactRequest = 502

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = false
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(JarvisWebBridge(this, web), "AndroidJarvis")
        setContentView(web)
        web.loadUrl("file:///android_asset/web/index.html")
        val missing = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.RECORD_AUDIO).filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), contactRequest)
    }

    fun startNativeVoice() {
        val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Jarvis'e söyle")
        }
        try { startActivityForResult(intent, voiceRequest) } catch (_: Exception) {
            web.evaluateJavascript("window.jarvisVoiceError('Cihazda sesli giriş bulunamadı.');", null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == Activity.RESULT_OK) {
            val text = data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            web.evaluateJavascript("window.jarvisVoice(${org.json.JSONObject.quote(text)});", null)
        }
    }

    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
