package com.openjarvis.webbridge

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import com.openjarvis.accessibility.JarvisAccessibilityService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class JarvisCommandEngine(private val context: Context) {
    data class Result(val ok: Boolean, val message: String)

    suspend fun execute(command: String): Result = withContext(Dispatchers.Main) {
        val c = command.trim()
        val l = c.lowercase(Locale("tr", "TR"))
        when {
            l.matches(Regex(".*\\b(saat kaç|şu an saat kaç|saat ne)\\b.*")) ->
                Result(true, "Saat ${SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(Date())}.")
            l.contains("erişilebilirlik") || l.contains("accessibility") -> {
                context.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Result(true, "Erişilebilirlik ayarlarını açtım. Open Jarvis'i etkinleştir.")
            }
            l.contains("overlay") || l.contains("üstte göster") -> {
                context.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Result(true, "Üstte gösterme izni ekranını açtım.")
            }
            l.matches(Regex(".*\\b(ana ekran|home)\\b.*")) -> {
                JarvisAccessibilityService.instance?.pressHome() == true
                Result(true, "Ana ekrana geçtim.")
            }
            l.matches(Regex(".*\\b(geri|geriye dön)\\b.*")) -> {
                JarvisAccessibilityService.instance?.pressBack() == true
                Result(true, "Geri gittim.")
            }
            l.contains("son uygulamalar") || l.contains("recent") -> {
                JarvisAccessibilityService.instance?.pressRecents() == true
                Result(true, "Son uygulamaları açtım.")
            }
            l.contains("ekranı oku") || l.contains("ekran ne yazıyor") || l.contains("ekranı oku") -> {
                val text = JarvisAccessibilityService.instance?.readScreen().orEmpty()
                Result(text.isNotBlank(), if (text.isBlank()) "Ekran okunamadı. Accessibility Service açık mı?" else text.take(5000))
            }
            l.contains("whatsapp") && (l.contains("mesaj") || l.contains("yaz") || l.contains("gönder")) -> sendWhatsApp(c)
            l.contains("whatsapp") -> openApp("com.whatsapp", "WhatsApp")
            l.contains("chatgpt") -> openApp("com.openai.chatgpt", "ChatGPT")
            l.contains("spotify") -> openApp("com.spotify.music", "Spotify")
            l.contains("google maps") || l.contains("harita") -> openApp("com.google.android.apps.maps", "Google Maps")
            l.contains("youtube") -> openApp("com.google.android.youtube", "YouTube")
            l.contains("chrome") -> openApp("com.android.chrome", "Chrome")
            l.contains("ayarlar") -> {
                context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                Result(true, "Ayarlar'ı açtım.")
            }
            l.startsWith("aç ") || l.startsWith("ac ") -> {
                val label = c.substringAfter(' ').trim()
                openApp(null, label)
            }
            l.contains("yukarı kaydır") || l.contains("yukari kaydir") -> {
                val ok = JarvisAccessibilityService.instance?.swipe("up") == true
                Result(ok, if (ok) "Yukarı kaydırdım." else "Ekran kaydırılamadı.")
            }
            l.contains("aşağı kaydır") || l.contains("asagi kaydir") -> {
                val ok = JarvisAccessibilityService.instance?.swipe("down") == true
                Result(ok, if (ok) "Aşağı kaydırdım." else "Ekran kaydırılamadı.")
            }
            l.contains("dokun") || l.startsWith("tıkla") || l.startsWith("tikla") -> {
                val target = c.substringAfter(' ').trim().removePrefix("şuna ").removePrefix("şuna")
                val ok = JarvisAccessibilityService.instance?.tapByText(target) == true
                Result(ok, if (ok) "$target öğesine dokundum." else "Ekranda '$target' bulunamadı.")
            }
            l.startsWith("yaz ") || l.startsWith("şunu yaz ") || l.startsWith("sunu yaz ") -> {
                val text = c.substringAfter(' ').removePrefix("yaz ").trim()
                val ok = JarvisAccessibilityService.instance?.typeText(text) == true
                Result(ok, if (ok) "Yazdım." else "Yazılacak bir metin alanı bulamadım.")
            }
            else -> Result(false, "Komutu anladım ama bu işlem için uygun Android eylemi tanımlı değil: $c")
        }
    }

    private fun openApp(packageName: String?, label: String): Result {
        val service = JarvisAccessibilityService.instance
        val ok = if (packageName != null) service?.openAppByPackage(packageName) == true else service?.openAppByLabel(label) == true
        return Result(ok, if (ok) "$label açıldı." else "$label bulunamadı. Uygulama yüklü mü ve Accessibility açık mı?")
    }

    private fun sendWhatsApp(command: String): Result {
        // Accepts natural variants such as:
        // "WhatsApp'ta Ahmet'e merhaba yaz", "WhatsApp Ahmet'e merhaba gönder"
        val cleaned = command.trim()
            .replace(Regex("(?i)^whatsapp(?:'|’)?(?:ta|te|da|de)?\\s*"), "")
            .replace(Regex("(?i)^whatsapp\\s*"), "")
            .trim()
        val match = Regex("(?i)^(.+?)(?:'|’)?(?:a|e)\\s+(.+)$").find(cleaned)
        if (match == null) return Result(false, "WhatsApp için kişi adı ve mesajı birlikte söyle: 'WhatsApp'ta Ahmet'e merhaba yaz'.")
        val name = match.groupValues[1].trim()
        var message = match.groupValues[2].trim()
        message = message.replace(Regex("(?i)\\s+(?:yaz|gönder|gonder)$"), "").trim()
        if (name.isBlank() || message.isBlank()) return Result(false, "Kişi adı veya mesaj eksik.")
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return Result(false, "Kişi bulmak için Kişiler izni gerekiyor. Uygulama ayarlarından Kişiler iznini aç.")
        }
        val phone = findContactPhone(name) ?: return Result(false, "Kişiler'de '$name' bulunamadı.")
        val digits = phone.filter { it.isDigit() || it == '+' }
        val packageName = when {
            isInstalled("com.whatsapp") -> "com.whatsapp"
            isInstalled("com.whatsapp.w4b") -> "com.whatsapp.w4b"
            else -> null
        } ?: return Result(false, "WhatsApp yüklü değil.")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send?phone=${Uri.encode(digits)}&text=${Uri.encode(message)}"))
            .setPackage(packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            val explicitlySend = Regex("(?i)\\b(gönder|gonder|yolla)\\b").containsMatchIn(command)
            if (explicitlySend) {
                kotlinx.coroutines.delay(1800)
                val service = JarvisAccessibilityService.instance
                val sent = listOf("Gönder", "Gonder", "Send").any { service?.tapByText(it) == true }
                Result(sent, if (sent) "$name kişisine WhatsApp mesajı gönderildi." else "Mesaj hazırlandı fakat Gönder düğmesi bulunamadı.")
            } else {
                Result(true, "WhatsApp'ta $name için mesajı hazırladım: $message")
            }
        } catch (_: Exception) {
            Result(false, "WhatsApp açılamadı.")
        }
    }

    private fun isInstalled(packageName: String): Boolean = try { context.packageManager.getApplicationInfo(packageName, 0); true } catch (_: Exception) { false }

    private fun findContactPhone(name: String): String? {
        val cr = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        cr.query(uri, projection, "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { cur ->
            if (cur.moveToFirst()) return cur.getString(0)
        }
        return null
    }
}
