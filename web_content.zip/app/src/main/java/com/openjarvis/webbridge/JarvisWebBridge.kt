package com.openjarvis.webbridge

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import com.openjarvis.accessibility.JarvisAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JarvisWebBridge(private val activity: Activity, private val webView: WebView) {
    private val engine = JarvisCommandEngine(activity)
    private val scope = CoroutineScope(Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())

    @JavascriptInterface fun command(text: String) {
        scope.launch {
            val result = engine.execute(text)
            val json = "window.jarvisResult(${org.json.JSONObject.quote(text)},${org.json.JSONObject.quote(result.message)},${result.ok});"
            handler.post { webView.evaluateJavascript(json, null) }
        }
    }

    @JavascriptInterface fun readScreen() {
        val text = JarvisAccessibilityService.instance?.readScreen().orEmpty()
        val json = "window.jarvisScreen(${org.json.JSONObject.quote(text)});"
        handler.post { webView.evaluateJavascript(json, null) }
    }

    @JavascriptInterface fun openAccessibility() = activity.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
    @JavascriptInterface fun openOverlay() = activity.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${activity.packageName}")))
    @JavascriptInterface fun isAccessibilityEnabled(): Boolean = JarvisAccessibilityService.instance != null
    @JavascriptInterface fun startVoice() { (activity as? com.openjarvis.ui.MainActivity)?.startNativeVoice() }
}
