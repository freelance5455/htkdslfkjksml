package com.hesom.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var fileChooser: ValueCallback<Array<Uri>>? = null
    private var pendingWebPermission: PermissionRequest? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var controller: MediaController? = null
    private var controllerListener: Player.Listener? = null
    @Volatile private var nativeAutoplay = true

    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        pendingWebPermission?.let { request ->
            if (granted) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) else request.deny()
        }
        pendingWebPermission = null
    }

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val uris = if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val clip = data?.clipData
            when {
                clip != null -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                data?.data != null -> arrayOf(data.data!!)
                else -> emptyArray()
            }
        } else emptyArray()
        fileChooser?.onReceiveValue(uris)
        fileChooser = null
        if (uris.isNotEmpty()) importUris(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        WebView.setWebContentsDebuggingEnabled(false)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileChooser?.onReceiveValue(null)
                fileChooser = callback
                chooser.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    type = "audio/*"
                })
                return true
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    if (!wantsAudio || request.resources.any { it != PermissionRequest.RESOURCE_AUDIO_CAPTURE }) {
                        request.deny()
                    } else if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    } else {
                        pendingWebPermission?.deny()
                        pendingWebPermission = request
                        requestMic.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            }
        }
        web.addJavascriptInterface(AndroidBridge(), "HesomAndroid")
        web.addJavascriptInterface(ToastBridge(), "AndroidToast")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun getController(onReady: (MediaController) -> Unit) {
        controller?.let { onReady(it); return }
        ContextCompat.startForegroundService(this, Intent(this, HesomPlaybackService::class.java))
        val token = SessionToken(this, android.content.ComponentName(this, HesomPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                attachControllerListener(c)
                onReady(c)
            } catch (_: Exception) {
                runOnUiThread { Toast.makeText(this, "O player do Hésom não pôde ser iniciado.", Toast.LENGTH_SHORT).show() }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun attachControllerListener(c: MediaController) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && !nativeAutoplay) {
                    controller?.pause()
                }
            }

            override fun onEvents(player: Player, events: Player.Events) {
                val index = player.currentMediaItemIndex
                val playing = player.isPlaying
                val duration = player.duration.coerceAtLeast(0L)
                val position = player.currentPosition.coerceAtLeast(0L)
                val js = "window.onNativePlaybackState && window.onNativePlaybackState($index,$playing,$duration,$position);"
                if (::web.isInitialized) web.evaluateJavascript(js, null)
            }
        }
        controllerListener = listener
        c.addListener(listener)
    }

    private fun importUris(uris: Array<Uri>) {
        executor.execute {
            val dir = File(filesDir, "music").apply { mkdirs() }
            val out = JSONArray()
            for (uri in uris) {
                try {
                    val name = queryName(uri) ?: "musica_${System.currentTimeMillis()}"
                    val safeName = name.replace(Regex("[^A-Za-z0-9._ -]"), "_")
                    val file = uniqueFile(dir, safeName)
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(file).use { output -> input.copyTo(output, 64 * 1024) }
                    } ?: continue
                    val mime = contentResolver.getType(uri) ?: "audio/*"
                    out.put(JSONObject().put("name", name.substringBeforeLast('.', name)).put("artist", "Arquivo do celular").put("file", file.name).put("mime", mime))
                } catch (_: Exception) { }
            }
            runOnUiThread {
                val json = JSONObject.quote(out.toString())
                web.evaluateJavascript("window.onNativeAudioPicked && window.onNativeAudioPicked($json);", null)
            }
        }
    }

    private fun queryName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun uniqueFile(dir: File, name: String): File {
        val base = name.substringBeforeLast('.', name)
        val ext = name.substringAfterLast('.', "").let { if (it.isBlank()) "" else ".${it}" }
        var i = 0
        var f = File(dir, name)
        while (f.exists()) f = File(dir, "${base}_${++i}$ext")
        return f
    }

    inner class ToastBridge {
        @JavascriptInterface fun show(message: String) = runOnUiThread {
            Toast.makeText(this@MainActivity, message.take(200), Toast.LENGTH_SHORT).show()
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface fun pickAudio() = runOnUiThread {
            chooser.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                type = "audio/*"
            })
        }

        @JavascriptInterface fun playNativeQueue(raw: String, startIndex: Int, autoplay: Boolean) {
            nativeAutoplay = autoplay
            getController { c ->
                try {
                    val arr = JSONArray(raw)
                    val items = ArrayList<androidx.media3.common.MediaItem>(arr.length())
                    val root = File(filesDir, "music").canonicalFile
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val name = o.optString("file")
                        val target = File(root, name).canonicalFile
                        if (!target.path.startsWith(root.path + File.separator) || !target.isFile) continue
                        val item = androidx.media3.common.MediaItem.Builder()
                            .setMediaId(target.name)
                            .setUri(Uri.fromFile(target))
                            .setMimeType(o.optString("mime", "audio/*"))
                            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                                .setTitle(o.optString("title", "Música"))
                                .setArtist(o.optString("artist", "Arquivo do celular"))
                                .setAlbumTitle("Hésom")
                                .build())
                            .build()
                        items.add(item)
                    }
                    if (items.isEmpty()) return@getController
                    val safeIndex = startIndex.coerceIn(0, items.lastIndex)
                    c.setMediaItems(items, safeIndex, 0L)
                    c.prepare()
                    c.play()
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "Não foi possível tocar a música.", Toast.LENGTH_SHORT).show() }
                }
            }
        }

        @JavascriptInterface fun playNativeFile(file: String, title: String, artist: String, mime: String) {
            val raw = JSONArray().put(JSONObject().put("file", file).put("title", title).put("artist", artist).put("mime", mime)).toString()
            playNativeQueue(raw, 0, true)
        }
        @JavascriptInterface fun togglePlayback() { getController { c -> if (c.isPlaying) c.pause() else c.play() } }
        @JavascriptInterface fun getPosition(): Long = controller?.currentPosition ?: 0L
        @JavascriptInterface fun getDuration(): Long = controller?.duration ?: 0L
        @JavascriptInterface fun isPlaying(): Boolean = controller?.isPlaying == true
        @JavascriptInterface fun clearData() {
            // JavaScript interfaces are invoked off the UI thread; delete synchronously here
            // so a following reload cannot race the file cleanup.
            try { File(filesDir, "music").deleteRecursively() } catch (_: Exception) { }
        }
        @JavascriptInterface fun deleteNativeFile(file: String) {
            executor.execute {
                try {
                    val root = File(filesDir, "music").canonicalFile
                    val f = File(root, file).canonicalFile
                    if (f.path.startsWith(root.path + File.separator)) f.delete()
                } catch (_: Exception) { }
            }
        }
        @JavascriptInterface fun seekTo(positionMs: Long) { getController { it.seekTo(positionMs.coerceAtLeast(0L)) } }
    }

    override fun onDestroy() {
        fileChooser?.onReceiveValue(null)
        fileChooser = null
        pendingWebPermission?.deny()
        pendingWebPermission = null
        controller?.let { c -> controllerListener?.let(c::removeListener); c.release() }
        controller = null
        controllerListener = null
        executor.shutdownNow()
        web.destroy()
        super.onDestroy()
    }
}
