package com.corm.mikrotik

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale

/**
 * CORM v8.5 — MainActivity.kt
 * نقطة الدخول الرئيسية لتطبيق الأندرويد الأصلي (Native Kotlin WebView + @JavascriptInterface Bridge).
 * تقوم بتحميل الواجهة من file:///android_asset/index.html وربطها بكلاس MikrotikScanner مباشرًة.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val scanner = MikrotikScanner()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ضبط لون شريط الحالة والتنقل باللون السيبراني الداكن (#040711)
        window.statusBarColor = 0xFF040711.toInt()
        window.navigationBarColor = 0xFF040711.toInt()
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadsImagesAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        webView.setBackgroundColor(0xFF040711.toInt())
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("file:///android_asset/")) {
                    return false
                }
                // فتح روابط واتساب أو الرسائل القصيرة في التطبيقات الخارجية للهاتف
                try {
                    val intent = android.content.Intent(
                        android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse(url)
                    )
                    startActivity(intent)
                } catch (_: Exception) {
                }
                return true
            }
        }

        // ربط الجسر الأصلي @JavascriptInterface باسم AndroidBridge و MikrotikBridge
        val bridge = CormJsBridge(this, scanner)
        webView.addJavascriptInterface(bridge, "AndroidBridge")
        webView.addJavascriptInterface(bridge, "MikrotikBridge")

        // تحميل واجهة المستخدم من مجلد assets
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    /**
     * جسر التواصل المباشر بين JavaScript داخل index.html وكلاس Kotlin الأصلي MikrotikScanner
     */
    class CormJsBridge(
        private val context: Context,
        private val mikrotikScanner: MikrotikScanner
    ) {

        /**
         * توليد معرّف بصمة الجهاز الفريد بصيغة CORM-XXXX-XXXX من معرّف أندرويد والعتاد
         */
        @JavascriptInterface
        fun getHardwareDeviceId(): String {
            return try {
                val androidId = Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ANDROID_ID
                ) ?: "UNKNOWN_ANDROID"
                val raw = "$androidId|${Build.MANUFACTURER}|${Build.MODEL}|${Build.BOARD}"
                val digest = MessageDigest.getInstance("SHA-256")
                    .digest(raw.toByteArray(StandardCharsets.UTF_8))
                val hex = digest.joinToString("") { String.format("%02X", it) }
                "CORM-${hex.substring(0, 4)}-${hex.substring(4, 8)}"
            } catch (_: Exception) {
                "CORM-A8F2-91C4"
            }
        }

        /**
         * فحص المنافذ القياسية وسحب البانر عبر java.net.Socket
         */
        @JavascriptInterface
        fun probePorts(host: String): String {
            return mikrotikScanner.probeStandardPortsJson(host)
        }

        /**
         * الاتصال الفعلي بسيرفر ميكروتيك الهوتسبوت وفحص الثغرات والمشتركين
         */
        @JavascriptInterface
        fun auditHotspotRouter(host: String, port: Int, user: String, pass: String): String {
            return mikrotikScanner.auditHotspotRouterJson(host, port, user, pass)
        }

        /**
         * تنفيذ أوامر RouterOS API (تأمين السيرفر، طرد مشترك، حظر ماك، تحديد سرعة 512Kbps)
         */
        @JavascriptInterface
        fun executeRouterCommands(
            host: String,
            port: Int,
            user: String,
            pass: String,
            commandsJson: String
        ): String {
            return mikrotikScanner.executeRouterOsCommandsJson(host, port, user, pass, commandsJson)
        }

        /**
         * تشغيل أداة فحص الكابلات وقياس مسافة القطع بالأمتار (/interface ethernet cable-test)
         */
        @JavascriptInterface
        fun runCableTest(
            host: String,
            port: Int,
            user: String,
            pass: String,
            interfaceName: String,
            simulationPreset: String
        ): String {
            return mikrotikScanner.runCableTestJson(
                host,
                port,
                user,
                pass,
                interfaceName,
                simulationPreset
            )
        }

        /**
         * تحليل بت العشوائية U/L Bit في البايت الأول لعنوان الماك
         */
        @JavascriptInterface
        fun inspectMacUlBit(macAddress: String): String {
            return mikrotikScanner.inspectMacUlBitJson(macAddress)
        }

        /**
         * قراءة سحب البيانات الحي (RX/TX Mbps & PPS)
         */
        @JavascriptInterface
        fun readTrafficThroughput(host: String, port: Int, user: String, pass: String): String {
            return mikrotikScanner.readTrafficThroughputJson(host, port, user, pass)
        }

        /**
         * نسخ النصوص والأوامر والتقارير إلى حافظة أندرويد الرسمية
         */
        @JavascriptInterface
        fun copyToClipboard(text: String) {
            try {
                val clipboard =
                    context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("CORM v8.5", text)
                clipboard.setPrimaryClip(clip)
            } catch (_: Exception) {
            }
        }

        /**
         * إظهار رسالة Toast أصلية على شاشة الهاتف
         */
        @JavascriptInterface
        fun showNativeToast(message: String) {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
