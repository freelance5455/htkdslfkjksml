package ro.jurnal.debord;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new NativeBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeBridge {
        @JavascriptInterface public void printPdf() {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager)getSystemService(Context.PRINT_SERVICE);
                    if (pm == null) throw new Exception("Serviciul de tipărire nu este disponibil.");
                    String name = "Jurnal de Bord";
                    PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                        .setColorMode(PrintAttributes.COLOR_MODE_COLOR).build();
                    pm.print(name, webView.createPrintDocumentAdapter(name), attrs);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Eroare PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void saveExcel(String fileName, String base64) {
            final String raw = (fileName == null || fileName.trim().isEmpty()) ? "Jurnal.xlsx" :
                fileName.replaceAll("[^A-Za-z0-9._-]", "_");
            final String name = raw.toLowerCase().endsWith(".xlsx") ? raw : raw + ".xlsx";
            new Thread(() -> {
                try {
                    if (Build.VERSION.SDK_INT < 29)
                        throw new Exception("Salvarea automată necesită Android 10 sau mai nou.");
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    cv.put(MediaStore.Downloads.MIME_TYPE,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new Exception("Nu s-a putut crea fișierul.");
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) throw new Exception("Nu s-a putut deschide fișierul.");
                        os.write(data);
                        os.flush();
                    }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Excel salvat în Descărcări: " + name, Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    String msg = e.getMessage() == null ? "eroare necunoscută" : e.getMessage();
                    runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Eroare Excel: " + msg, Toast.LENGTH_LONG).show());
                }
            }).start();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
