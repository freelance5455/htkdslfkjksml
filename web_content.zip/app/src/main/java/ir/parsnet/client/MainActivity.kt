package ir.parsnet.client

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Gold = Color(0xFFE7C477)
private val Purple = Color(0xFF241044)
private val Plum = Color(0xFF38205D)
private val Lilac = Color(0xFFB9A6D6)
private val Muted = Color(0xFFB7A9D0)
private val Danger = Color(0xFFFF9AA8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { App() }
        }
    }
}

private fun fmt(sec: Long): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    val raw = "%02d:%02d:%02d".format(h, m, s)
    return raw.map { if (it in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")
}

@Composable
private fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("parsnet_ui", Context.MODE_PRIVATE) }

    var catalog by remember { mutableStateOf<CatalogResult?>(null) }
    var loading by remember { mutableStateOf(true) }
    var selectedId by remember { mutableStateOf(prefs.getString("selected", null)) }
    var hint by remember { mutableStateOf("") }
    var elapsed by remember { mutableStateOf(0L) }

    val phase by VpnState.phase.collectAsState()
    val message by VpnState.message.collectAsState()

    fun reload() {
        scope.launch {
            loading = true
            catalog = Catalog.load(ctx)
            loading = false
        }
    }

    val servers = catalog?.servers.orEmpty()
    val selected = servers.firstOrNull { it.id == selectedId }

    fun startVpn() {
        val s = selected ?: return
        val cfg = runCatching { SingBoxConfig.build(s.link) }.getOrElse {
            VpnState.message.value = it.message ?: "کانفیگ نامعتبر است"
            VpnState.phase.value = Phase.ERROR
            return
        }
        VpnState.message.value = ""
        VpnState.phase.value = Phase.CONNECTING
        val i = Intent(ctx, ParsnetVpnService::class.java)
            .setAction(ParsnetVpnService.ACTION_START)
            .putExtra(ParsnetVpnService.EXTRA_CONFIG, cfg)
            .putExtra(ParsnetVpnService.EXTRA_NAME, s.name)
        ContextCompat.startForegroundService(ctx, i)
    }

    val vpnPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK) startVpn()
        else hint = "برای اتصال باید اجازه‌ی VPN را بدهید."
    }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        reload()
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(phase) {
        while (phase == Phase.ON) {
            elapsed = (System.currentTimeMillis() - VpnState.startedAt) / 1000
            delay(1000)
        }
    }

    fun onPower() {
        hint = ""
        when (phase) {
            Phase.ON, Phase.CONNECTING ->
                ctx.startService(Intent(ctx, ParsnetVpnService::class.java).setAction(ParsnetVpnService.ACTION_STOP))
            else -> {
                if (selected == null) { hint = "ابتدا یک سرور از فهرست انتخاب کنید."; return }
                val prep = VpnService.prepare(ctx)
                if (prep != null) vpnPermission.launch(prep) else startVpn()
            }
        }
    }

    val busy = phase == Phase.ON || phase == Phase.CONNECTING

    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF120820), Purple, Color(0xFF10071D))))
            .statusBarsPadding()
            .padding(horizontal = 18.dp, vertical = 12.dp)
    ) {
        // Header
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("PARSNET", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                Text("سامانه سرورهای اختصاصی پارس", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = { reload() }, enabled = !loading) {
                Icon(Icons.Filled.Refresh, contentDescription = "به‌روزرسانی فهرست", tint = Gold)
            }
        }

        // Announcement
        val ann = catalog?.announcement.orEmpty().ifBlank { "به پارس‌نت خوش آمدید" }
        val ad = catalog?.ad.orEmpty()
        Spacer(Modifier.height(14.dp))
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Plum.copy(alpha = .55f))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(ann, color = Gold, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            if (ad.isNotBlank()) Text(ad, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }

        // Power
        Spacer(Modifier.height(22.dp))
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            PowerButton(phase, ::onPower)
            Spacer(Modifier.height(14.dp))
            Text(
                when (phase) {
                    Phase.OFF -> "قطع"
                    Phase.CONNECTING -> "در حال اتصال…"
                    Phase.ON -> "متصل"
                    Phase.ERROR -> "اتصال برقرار نشد"
                },
                color = if (phase == Phase.ON) Gold else Color.White,
                fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
            )
            if (phase == Phase.ON) Text(fmt(elapsed), color = Lilac, fontSize = 15.sp)
            Text(
                selected?.let { "سرور: ${it.name}" } ?: "سروری انتخاب نشده",
                color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
            val line = when {
                phase == Phase.ERROR && message.isNotBlank() -> message
                hint.isNotBlank() -> hint
                catalog?.offline == true -> "اینترنت یا فایل فهرست در دسترس نبود؛ نسخه‌ی ذخیره‌شده نمایش داده می‌شود."
                else -> ""
            }
            if (line.isNotBlank()) {
                Text(
                    line,
                    color = if (phase == Phase.ERROR || hint.isNotBlank()) Danger else Muted,
                    fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 6.dp, start = 12.dp, end = 12.dp)
                )
            }
        }

        // Servers
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            Text("انتخاب سرور", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("${servers.size} سرور", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        if (servers.isEmpty()) {
            Text(
                if (loading) "در حال بارگذاری…" else "فعلاً سرور فعالی وجود ندارد.",
                color = Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(24.dp)
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                items(servers, key = { it.id }) { s ->
                    ServerRow(s, s.id == selectedId) {
                        if (busy) { hint = "برای تغییر سرور، ابتدا اتصال را قطع کنید." }
                        else {
                            selectedId = s.id
                            prefs.edit().putString("selected", s.id).apply()
                            hint = ""
                            if (phase == Phase.ERROR) VpnState.phase.value = Phase.OFF
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ServerRow(s: ServerConfig, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth()
            .clip(shape)
            .background(if (selected) Plum else Plum.copy(alpha = .5f))
            .border(1.dp, if (selected) Gold else Gold.copy(alpha = .16f), shape)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            s.protocol.name.take(8), color = Gold, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Gold.copy(alpha = .12f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
        Column(Modifier.weight(1f)) {
            Text(s.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${s.host}:${s.port}", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier.size(20.dp).clip(CircleShape)
                .border(2.dp, if (selected) Gold else Muted.copy(alpha = .5f), CircleShape)
                .background(if (selected) Gold else Color.Transparent)
        )
    }
}

@Composable
private fun PowerButton(phase: Phase, onClick: () -> Unit) {
    val on = phase == Phase.ON
    val connecting = phase == Phase.CONNECTING
    val glow by animateFloatAsState(if (on) 1f else 0f, tween(500), label = "glow")
    val spin = rememberInfiniteTransition(label = "spin")
    val angle by spin.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Restart),
        label = "angle"
    )
    Box(
        Modifier.size(220.dp).clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null, role = Role.Button, onClick = onClick
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            drawCircle(
                Brush.radialGradient(listOf(Gold.copy(alpha = .30f * glow), Color.Transparent), center, r),
                radius = r
            )
            drawCircle(Gold.copy(alpha = .10f + .35f * glow), radius = r * .94f, style = Stroke(2f))
            drawCircle(Gold.copy(alpha = .20f + .35f * glow), radius = r * .80f, style = Stroke(2f))
            if (connecting) {
                drawArc(
                    Gold, startAngle = angle, sweepAngle = 110f, useCenter = false,
                    topLeft = Offset(center.x - r * .70f, center.y - r * .70f),
                    size = Size(r * 1.4f, r * 1.4f),
                    style = Stroke(8f, cap = StrokeCap.Round)
                )
            }
        }
        Box(
            Modifier.size(150.dp).clip(CircleShape).background(
                if (on) Brush.radialGradient(listOf(Color(0xFFF8E3A9), Gold, Color(0xFFC79D45)))
                else Brush.radialGradient(listOf(Color(0xFF4A2B78), Color(0xFF2A1450)))
            ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.PowerSettingsNew,
                contentDescription = if (on || connecting) "قطع اتصال" else "اتصال",
                tint = if (on) Purple else if (phase == Phase.ERROR) Danger else Lilac,
                modifier = Modifier.size(64.dp)
            )
        }
    }
}
