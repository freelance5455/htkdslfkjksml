package id.akhtara.stokproduksi;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Cangkang WebView: 100% offline, fullscreen edge-to-edge, data disimpan ke file internal. */
public class MainActivity extends Activity {
    static final int RC_EXPORT = 1, RC_IMPORT = 2;
    private WebView web;
    private FrameLayout root;
    private File dataFile;
    private String pendingExport = "";
    private int insTop = 0, insBottom = 0;
    private boolean darkNavIcons = false;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        dataFile = new File(getFilesDir(), "stokprod.json");
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            w.setStatusBarContrastEnforced(false);
            w.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 30) w.setDecorFitsSystemWindows(false);
        applyIcons();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#17161B"));
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) { pushInsets(); }
            @Override public boolean shouldOverrideUrlLoading(WebView v, android.webkit.WebResourceRequest r) {
                return !"file".equals(r.getUrl().getScheme());
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int stable = ins.getStableInsetBottom();
            int sys = ins.getSystemWindowInsetBottom();
            int ime = Math.max(0, sys - stable);
            insTop = ins.getSystemWindowInsetTop();
            insBottom = ime > 0 ? 0 : stable;
            root.setPadding(0, 0, 0, ime);
            pushInsets();
            return ins;
        });
        root.requestApplyInsets();
        web.loadUrl("file:///android_asset/index.html");
    }

    @SuppressWarnings("deprecation")
    private void applyIcons() {
        int f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
              | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (darkNavIcons && Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(f);
    }

    private void pushInsets() {
        if (web == null) return;
        float d = getResources().getDisplayMetrics().density;
        final String js = "var r=document.documentElement.style;r.setProperty('--sat','" + (insTop / d)
            + "px');r.setProperty('--sab','" + (insBottom / d) + "px');";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    private synchronized void writeData(String j) {
        try {
            File tmp = new File(getFilesDir(), "stokprod.tmp");
            FileOutputStream o = new FileOutputStream(tmp);
            o.write(j.getBytes(StandardCharsets.UTF_8));
            o.getFD().sync();
            o.close();
            if (!tmp.renameTo(dataFile)) { dataFile.delete(); tmp.renameTo(dataFile); }
        } catch (Exception ignored) { }
    }

    private synchronized String readData() {
        try {
            if (!dataFile.exists()) return "";
            FileInputStream in = new FileInputStream(dataFile);
            String t = readAll(in);
            in.close();
            return t;
        } catch (Exception e) { return ""; }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }

    class Bridge {
        @JavascriptInterface public void saveData(String j) { writeData(j); }
        @JavascriptInterface public String loadData() { return readData(); }
        @JavascriptInterface public void setBars(String bgHex, boolean darkNav) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(bgHex);
                    root.setBackgroundColor(c);
                } catch (Exception ignored) { }
                darkNavIcons = darkNav;
                applyIcons();
            });
        }
        @JavascriptInterface public void share(String j) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, j);
                startActivity(Intent.createChooser(i, "Kirim backup"));
            });
        }
        @JavascriptInterface public void exportFile(String name, String json) {
            pendingExport = json;
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, name);
                startActivityForResult(i, RC_EXPORT);
            });
        }
        @JavascriptInterface public void importFile() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, RC_IMPORT);
            });
        }
    }

    @Override protected void onActivityResult(int rc, int res, Intent data) {
        super.onActivityResult(rc, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (rc == RC_EXPORT) {
                OutputStream o = getContentResolver().openOutputStream(u);
                o.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                o.close();
                Toast.makeText(this, "Backup tersimpan", Toast.LENGTH_SHORT).show();
            } else if (rc == RC_IMPORT) {
                InputStream in = getContentResolver().openInputStream(u);
                String t = readAll(in);
                in.close();
                web.evaluateJavascript("window.onImport(" + JSONObject.quote(t) + ")", null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Gagal membaca/menulis file", Toast.LENGTH_SHORT).show();
        }
    }

    private void flushWeb() {
        if (web != null) web.evaluateJavascript("window.flushSave&&window.flushSave()", null);
    }

    @Override protected void onPause() { flushWeb(); super.onPause(); }
    @Override protected void onStop() { flushWeb(); super.onStop(); }
    @Override public void onBackPressed() { moveTaskToBack(true); }
}
