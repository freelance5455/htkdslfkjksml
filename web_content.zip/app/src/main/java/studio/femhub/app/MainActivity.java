package studio.femhub.app;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import java.io.OutputStream;

public class MainActivity extends Activity {
  WebView wv;
  ValueCallback<Uri[]> cb;
  static final int REQ = 11;

  public class Bridge {
    @JavascriptInterface
    public String save(String b64, String name, String mime) {
      try {
        byte[] d = Base64.decode(b64, Base64.DEFAULT);
        ContentValues v = new ContentValues();
        v.put(MediaStore.Images.Media.DISPLAY_NAME, name);
        v.put(MediaStore.Images.Media.MIME_TYPE, mime);
        v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Femhub Studio");
        Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
        OutputStream o = getContentResolver().openOutputStream(u);
        o.write(d);
        o.close();
        return "ok";
      } catch (Exception e) {
        return String.valueOf(e.getMessage());
      }
    }
  }

  @Override
  protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(Color.BLACK);
    getWindow().setNavigationBarColor(Color.BLACK);
    wv = new WebView(this);
    wv.setBackgroundColor(Color.BLACK);
    setContentView(wv);
    WebSettings s = wv.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
    wv.setWebViewClient(new WebViewClient() {
      @Override
      public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest r) {
        return loader.shouldInterceptRequest(r.getUrl());
      }
    });
    wv.setWebChromeClient(new WebChromeClient() {
      @Override
      public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> f, FileChooserParams p) {
        if (cb != null) cb.onReceiveValue(null);
        cb = f;
        try {
          startActivityForResult(p.createIntent(), REQ);
        } catch (Exception e) {
          cb = null;
          return false;
        }
        return true;
      }
    });
    wv.addJavascriptInterface(new Bridge(), "FemhubAndroid");
    wv.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  @Override
  protected void onActivityResult(int rc, int res, Intent d) {
    if (rc == REQ && cb != null) {
      cb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d));
      cb = null;
    } else {
      super.onActivityResult(rc, res, d);
    }
  }
}
