package app.ideen.xideenwerkstatt;

import android.app.Activity;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.OutputStream;

public class MainActivity extends Activity {
  WebView w;

  class Bridge {
    @JavascriptInterface
    public String save(String name, String b64) {
      try {
        byte[] d = Base64.decode(b64, 0);
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, name);
        v.put(MediaStore.Downloads.RELATIVE_PATH, "Download/Ideen-Werkstatt");
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        OutputStream o = getContentResolver().openOutputStream(u);
        o.write(d);
        o.close();
        return "ok";
      } catch (Exception e) {
        return "err:" + e;
      }
    }
  }

  @Override
  protected void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    w = new WebView(this);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setMediaPlaybackRequiresUserGesture(false);
    w.addJavascriptInterface(new Bridge(), "Android");
    w.setWebViewClient(new WebViewClient());
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }

  @Override
  public void onBackPressed() {
    if (w.canGoBack()) w.goBack(); else super.onBackPressed();
  }
}
