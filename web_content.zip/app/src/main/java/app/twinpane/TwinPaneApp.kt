package app.twinpane

import android.app.Application
import android.content.Context
import androidx.room.Room
import app.twinpane.core.fs.*
import app.twinpane.data.AppDatabase
import app.twinpane.data.SettingsRepository

/** Elle DI: Hilt'e geçmek istersen sadece bu sınıf değişir. */
class AppContainer(ctx: Context) {
    val settings = SettingsRepository(ctx)
    val db: AppDatabase = Room.databaseBuilder(ctx, AppDatabase::class.java, "twinpane.db").build()
    val registry = ProviderRegistry(listOf(LocalFileProvider()))   // Faz 2+: Archive, Root, SAF, SFTP...
    val engine = TransferEngine(registry)
}

class TwinPaneApp : Application() {
    lateinit var container: AppContainer
    override fun onCreate() { super.onCreate(); container = AppContainer(this) }
}
