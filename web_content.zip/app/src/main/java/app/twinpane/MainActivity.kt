package app.twinpane

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import app.twinpane.ui.dualpane.DualPaneScreen
import app.twinpane.ui.dualpane.DualPaneViewModel
import app.twinpane.ui.theme.ThemeMode
import app.twinpane.ui.theme.TwinPaneTheme

class MainActivity : ComponentActivity() {
    private var hasAccess by mutableStateOf(false)
    private val legacyPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasAccess = checkAccess()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as TwinPaneApp).container
        hasAccess = checkAccess()
        setContent {
            val mode by container.settings.themeMode.collectAsStateWithLifecycle(ThemeMode.SYSTEM)
            val dynamic by container.settings.dynamicColor.collectAsStateWithLifecycle(true)
            TwinPaneTheme(mode, dynamic) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (hasAccess) {
                        val vm: DualPaneViewModel = viewModel(factory = viewModelFactory {
                            initializer {
                                DualPaneViewModel(container.registry, container.engine,
                                    Environment.getExternalStorageDirectory().absolutePath)
                            }
                        })
                        DualPaneScreen(vm)
                    } else PermissionScreen(::requestAccess)
                }
            }
        }
    }

    override fun onResume() { super.onResume(); hasAccess = checkAccess() }

    private fun checkAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            val i = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            runCatching { startActivity(i) }.onFailure {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else legacyPerm.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(stringResource(R.string.perm_title), style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.perm_body), textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onGrant) { Text(stringResource(R.string.grant)) }
    }
}
