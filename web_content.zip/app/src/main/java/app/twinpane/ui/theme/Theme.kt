package app.twinpane.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

enum class ThemeMode { SYSTEM, LIGHT, DARK }

private val Light = lightColorScheme(
    primary = Color(0xFF2F5BEA), onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE1FF), onPrimaryContainer = Color(0xFF001551),
    secondary = Color(0xFF5A5D72), secondaryContainer = Color(0xFFDFE1F9), onSecondaryContainer = Color(0xFF171A2C),
    background = Color(0xFFFBF8FF), onBackground = Color(0xFF1B1B1F),
    surface = Color(0xFFFBF8FF), onSurface = Color(0xFF1B1B1F),
    surfaceVariant = Color(0xFFE3E1EC), onSurfaceVariant = Color(0xFF46464F),
    surfaceContainerLow = Color(0xFFF5F2FA),
    outline = Color(0xFF777680), outlineVariant = Color(0xFFC7C5D0),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFB7C4FF), onPrimary = Color(0xFF002683),
    primaryContainer = Color(0xFF1B3FA0), onPrimaryContainer = Color(0xFFDCE1FF),
    secondary = Color(0xFFC3C5DD), secondaryContainer = Color(0xFF424659), onSecondaryContainer = Color(0xFFDFE1F9),
    background = Color(0xFF121318), onBackground = Color(0xFFE4E1E9),
    surface = Color(0xFF121318), onSurface = Color(0xFFE4E1E9),
    surfaceVariant = Color(0xFF46464F), onSurfaceVariant = Color(0xFFC7C5D0),
    surfaceContainerLow = Color(0xFF1B1B21),
    outline = Color(0xFF91909A), outlineVariant = Color(0xFF46464F),
)

@Composable
fun TwinPaneTheme(mode: ThemeMode, dynamic: Boolean, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val scheme = when {
        dynamic && Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> Dark
        else -> Light
    }
    // Uygulama teması sistemden farklıysa durum/gezinme çubuğu ikonları da uyumlu olsun.
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
