package app.twinpane.ui.dualpane

import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.twinpane.R
import app.twinpane.core.fs.*
import java.io.File
import java.text.DateFormat
import java.util.Date

private val dateFormat by lazy { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DualPaneScreen(vm: DualPaneViewModel) {
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val ctx = LocalContext.current
    var askDelete by remember { mutableStateOf(false) }
    val send: (UiIntent) -> Unit = vm::onIntent

    LaunchedEffect(Unit) {
        vm.effects.collect { fx ->
            when (fx) {
                is UiEffect.Message -> snackbar.showSnackbar(fx.text)
                is UiEffect.OpenFile -> openWithSystem(ctx, fx.path)
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { TopAppBar(title = { Text(stringResource(R.string.app_name)) }) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            state.transfer?.let { t ->
                LinearProgressIndicator(
                    progress = { if (t.totalBytes == 0L) 0f else t.doneBytes.toFloat() / t.totalBytes },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                // Tablet / katlanabilir / yatay: yan yana. Telefon dikey: üst-alt.
                val wide = maxWidth >= 600.dp
                if (wide) Row(Modifier.fillMaxSize()) {
                    PaneView(PaneSide.LEFT, state.left, state.active == PaneSide.LEFT, send, Modifier.weight(1f).fillMaxHeight())
                    ActionRail(true, state, send) { askDelete = true }
                    PaneView(PaneSide.RIGHT, state.right, state.active == PaneSide.RIGHT, send, Modifier.weight(1f).fillMaxHeight())
                } else Column(Modifier.fillMaxSize()) {
                    PaneView(PaneSide.LEFT, state.left, state.active == PaneSide.LEFT, send, Modifier.weight(1f).fillMaxWidth())
                    ActionRail(false, state, send) { askDelete = true }
                    PaneView(PaneSide.RIGHT, state.right, state.active == PaneSide.RIGHT, send, Modifier.weight(1f).fillMaxWidth())
                }
            }
        }
    }

    if (askDelete) {
        val n = state.pane(state.active).selection.size
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text(stringResource(R.string.delete)) },
            text = { Text(stringResource(R.string.delete_confirm, n)) },
            confirmButton = { TextButton({ askDelete = false; send(UiIntent.DeleteSelected) }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton({ askDelete = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

@Composable
private fun ActionRail(vertical: Boolean, state: DualPaneState, send: (UiIntent) -> Unit, onDelete: () -> Unit) {
    val side = state.active
    val pane = state.pane(side)
    val hasSel = pane.selection.isNotEmpty()
    val buttons: @Composable () -> Unit = {
        RailButton(R.drawable.ic_copy, R.string.copy_to_other, hasSel) { send(UiIntent.Transfer(move = false)) }
        RailButton(R.drawable.ic_move, R.string.move_to_other, hasSel) { send(UiIntent.Transfer(move = true)) }
        RailButton(R.drawable.ic_sync, R.string.sync_panes, true) { send(UiIntent.SyncPanes) }
        RailButton(R.drawable.ic_select_all, R.string.select_all, true) { send(UiIntent.SelectAll(side)) }
        RailButton(R.drawable.ic_invert, R.string.invert_selection, true) { send(UiIntent.InvertSelection(side)) }
        RailButton(
            if (pane.showHidden) R.drawable.ic_eye else R.drawable.ic_eye_off,
            R.string.show_hidden, true,
        ) { send(UiIntent.ToggleHidden(side)) }
        RailButton(R.drawable.ic_delete, R.string.delete, hasSel, onDelete)
    }
    if (vertical) Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.Center) { buttons() }
    else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { buttons() }
}

@Composable
private fun RailButton(@DrawableRes icon: Int, @StringRes label: Int, enabled: Boolean, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled) { Icon(painterResource(icon), contentDescription = stringResource(label)) }
}

@Composable
private fun PaneView(
    side: PaneSide, pane: PaneState, active: Boolean,
    send: (UiIntent) -> Unit, modifier: Modifier,
) {
    val shape = RoundedCornerShape(16.dp)
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.padding(4.dp).clip(shape)
            .border(if (active) 2.dp else 1.dp, if (active) cs.primary else cs.outlineVariant, shape)
            .background(cs.surfaceContainerLow),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton({ send(UiIntent.Back(side)) }, enabled = pane.back.isNotEmpty()) {
                Icon(painterResource(R.drawable.ic_back), stringResource(R.string.nav_back))
            }
            IconButton({ send(UiIntent.Forward(side)) }, enabled = pane.forward.isNotEmpty()) {
                Icon(painterResource(R.drawable.ic_forward), stringResource(R.string.nav_forward))
            }
            IconButton({ send(UiIntent.Up(side)) }, enabled = pane.path != "/") {
                Icon(painterResource(R.drawable.ic_up), stringResource(R.string.nav_up))
            }
            Text(
                pane.path, Modifier.weight(1f).padding(end = 12.dp),
                style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                pane.error != null -> Text(
                    pane.error, Modifier.align(Alignment.Center).padding(16.dp), color = cs.error,
                )
                pane.visible.isEmpty() && !pane.loading -> Text(
                    stringResource(R.string.empty_folder), Modifier.align(Alignment.Center), color = cs.onSurfaceVariant,
                )
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(pane.visible, key = { it.path }) { item ->
                        FileRow(item, item.path in pane.selection, pane.selection.isNotEmpty(), side, send)
                    }
                }
            }
            if (pane.loading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }
        Text(
            stringResource(R.string.status_fmt, pane.visible.size, pane.selection.size),
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(item: FileItem, selected: Boolean, selectionMode: Boolean, side: PaneSide, send: (UiIntent) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val cs = MaterialTheme.colorScheme
    val meta = remember(item) {
        val date = dateFormat.format(Date(item.modified))
        if (item.isDirectory) date else "${formatSize(item.size)} · $date"
    }
    Row(
        Modifier.fillMaxWidth()
            .background(if (selected) cs.secondaryContainer else Color.Transparent)
            .combinedClickable(
                onClick = {
                    if (selectionMode) send(UiIntent.ToggleSelect(side, item.path)) else send(UiIntent.Open(side, item))
                },
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    send(UiIntent.ToggleSelect(side, item.path))
                },
            )
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            painterResource(fileIcon(item)), null,
            tint = if (item.isDirectory) cs.primary else cs.onSurfaceVariant,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(item.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(meta, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (selectionMode) Checkbox(checked = selected, onCheckedChange = null)
    }
}

private fun openWithSystem(ctx: Context, path: String) {
    val file = File(path)
    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase()) ?: "*/*"
    val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(Intent.createChooser(view, file.name)) }
}

@DrawableRes
private fun fileIcon(item: FileItem): Int = if (item.isDirectory) R.drawable.ic_folder else when (item.extension) {
    "jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic" -> R.drawable.ic_file_image
    "mp3", "wav", "flac", "ogg", "m4a", "aac", "opus" -> R.drawable.ic_file_audio
    "mp4", "mkv", "avi", "mov", "webm", "3gp" -> R.drawable.ic_file_video
    "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz" -> R.drawable.ic_file_archive
    "apk", "apks", "xapk", "aab" -> R.drawable.ic_file_apk
    "kt", "java", "xml", "json", "smali", "py", "js", "ts", "html", "css", "sh", "c", "cpp", "h", "md" -> R.drawable.ic_file_code
    else -> R.drawable.ic_file
}
