package app.twinpane.ui.dualpane

import app.twinpane.core.fs.*

data class PaneState(
    val path: String,
    val all: List<FileItem> = emptyList(),
    val visible: List<FileItem> = emptyList(),   // filtre + gizli + sıralama uygulanmış
    val selection: Set<String> = emptySet(),
    val back: List<String> = emptyList(),
    val forward: List<String> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val showHidden: Boolean = false,
    val filter: String = "",
    val sort: SortOrder = SortOrder.NAME,
)

data class DualPaneState(
    val left: PaneState,
    val right: PaneState,
    val active: PaneSide = PaneSide.LEFT,
    val transfer: TransferProgress? = null,
) {
    fun pane(side: PaneSide) = if (side == PaneSide.LEFT) left else right
}

/** Büyük klasörlerde ana iş parçacığını bloklamamak için Default dispatcher'dan çağrılmalı. */
fun buildView(all: List<FileItem>, showHidden: Boolean, filter: String, sort: SortOrder): List<FileItem> {
    val q = filter.trim()
    val cmp: Comparator<FileItem> = when (sort) {
        SortOrder.NAME -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
        SortOrder.SIZE -> compareBy { it.size }
        SortOrder.DATE -> compareByDescending { it.modified }
        SortOrder.TYPE -> compareBy<FileItem> { it.extension }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name }
    }
    return all.asSequence()
        .filter { showHidden || !it.isHidden }
        .filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) }
        .toList()
        .sortedWith(compareByDescending<FileItem> { it.isDirectory }.then(cmp))
}

fun PaneState.recompute() = copy(visible = buildView(all, showHidden, filter, sort))

sealed interface UiIntent {
    data class Open(override val side: PaneSide, val item: FileItem) : PaneIntent
    data class Back(override val side: PaneSide) : PaneIntent
    data class Forward(override val side: PaneSide) : PaneIntent
    data class Up(override val side: PaneSide) : PaneIntent
    data class Refresh(override val side: PaneSide) : PaneIntent
    data class ToggleSelect(override val side: PaneSide, val path: String) : PaneIntent
    data class SelectAll(override val side: PaneSide) : PaneIntent
    data class InvertSelection(override val side: PaneSide) : PaneIntent
    data class SelectSameType(override val side: PaneSide, val ext: String) : PaneIntent
    data class ClearSelection(override val side: PaneSide) : PaneIntent
    data class ToggleHidden(override val side: PaneSide) : PaneIntent
    data class SetFilter(override val side: PaneSide, val query: String) : PaneIntent
    data class SetSort(override val side: PaneSide, val sort: SortOrder) : PaneIntent
    data class Transfer(val move: Boolean) : UiIntent
    data object SyncPanes : UiIntent
    data object DeleteSelected : UiIntent
    data object CancelTransfer : UiIntent
}

/** Bir panele ait intent'ler; gönderildiği anda o pane aktif olur. */
sealed interface PaneIntent : UiIntent { val side: PaneSide }

sealed interface UiEffect {
    data class OpenFile(val path: String) : UiEffect
    data class Message(val text: String) : UiEffect
}
