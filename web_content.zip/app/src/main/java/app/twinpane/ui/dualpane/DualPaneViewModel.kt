package app.twinpane.ui.dualpane

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.twinpane.core.fs.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DualPaneViewModel(
    private val registry: ProviderRegistry,
    private val engine: TransferEngine,
    startPath: String,
) : ViewModel() {

    private val _state = MutableStateFlow(DualPaneState(PaneState(startPath), PaneState(startPath)))
    val state: StateFlow<DualPaneState> = _state.asStateFlow()

    private val _effects = MutableSharedFlow<UiEffect>(extraBufferCapacity = 8)
    val effects: SharedFlow<UiEffect> = _effects.asSharedFlow()

    private val loadJobs = mutableMapOf<PaneSide, Job>()
    private var opJob: Job? = null

    init { PaneSide.entries.forEach(::load) }

    fun onIntent(i: UiIntent) {
        if (i is PaneIntent) _state.update { it.copy(active = i.side) }
        when (i) {
            is UiIntent.Open ->
                if (i.item.isDirectory) navigate(i.side, i.item.path) else _effects.tryEmit(UiEffect.OpenFile(i.item.path))
            is UiIntent.Back -> back(i.side)
            is UiIntent.Forward -> forward(i.side)
            is UiIntent.Up -> up(i.side)
            is UiIntent.Refresh -> load(i.side)
            is UiIntent.ToggleSelect -> edit(i.side) {
                it.copy(selection = if (i.path in it.selection) it.selection - i.path else it.selection + i.path)
            }
            is UiIntent.SelectAll -> edit(i.side) { p -> p.copy(selection = p.visible.mapTo(HashSet()) { it.path }) }
            is UiIntent.InvertSelection -> edit(i.side) { p ->
                p.copy(selection = p.visible.map { it.path }.filter { it !in p.selection }.toSet())
            }
            is UiIntent.SelectSameType -> edit(i.side) { p ->
                p.copy(selection = p.visible.filter { !it.isDirectory && it.extension == i.ext }.map { it.path }.toSet())
            }
            is UiIntent.ClearSelection -> edit(i.side) { it.copy(selection = emptySet()) }
            is UiIntent.ToggleHidden -> edit(i.side) { it.copy(showHidden = !it.showHidden).recompute() }
            is UiIntent.SetFilter -> edit(i.side) { it.copy(filter = i.query).recompute() }
            is UiIntent.SetSort -> edit(i.side) { it.copy(sort = i.sort).recompute() }
            is UiIntent.Transfer -> transfer(i.move)
            is UiIntent.SyncPanes -> {
                val a = _state.value.active
                navigate(a.other(), _state.value.pane(a).path)
            }
            is UiIntent.DeleteSelected -> deleteSelected()
            is UiIntent.CancelTransfer -> opJob?.cancel()
        }
    }

    // ---- gezinme ----
    private fun navigate(side: PaneSide, path: String) {
        edit(side) { it.copy(path = path, back = it.back + it.path, forward = emptyList(), filter = "") }
        load(side)
    }

    private fun back(side: PaneSide) {
        val prev = pane(side).back.lastOrNull() ?: return
        edit(side) { it.copy(path = prev, back = it.back.dropLast(1), forward = it.forward + it.path) }
        load(side)
    }

    private fun forward(side: PaneSide) {
        val next = pane(side).forward.lastOrNull() ?: return
        edit(side) { it.copy(path = next, forward = it.forward.dropLast(1), back = it.back + it.path) }
        load(side)
    }

    private fun up(side: PaneSide) {
        val p = pane(side).path
        if (p == "/") return
        navigate(side, p.trimEnd('/').substringBeforeLast('/', "").ifEmpty { "/" })
    }

    private fun load(side: PaneSide) {
        loadJobs[side]?.cancel()
        val path = pane(side).path
        edit(side) { it.copy(loading = true, error = null) }
        loadJobs[side] = viewModelScope.launch {
            try {
                val raw = registry.resolve(path).list(path)
                val v = pane(side)
                val visible = withContext(Dispatchers.Default) { buildView(raw, v.showHidden, v.filter, v.sort) }
                edit(side) { it.copy(all = raw, visible = visible, loading = false, selection = emptySet()) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                edit(side) { it.copy(all = emptyList(), visible = emptyList(), loading = false, error = e.message ?: "Error") }
            }
        }
    }

    // ---- işlemler ----
    private fun transfer(move: Boolean) {
        val from = _state.value.active
        val paths = pane(from).selection.toList()
        if (paths.isEmpty() || opJob?.isActive == true) return
        val dest = pane(from.other()).path
        opJob = viewModelScope.launch {
            try {
                engine.transfer(paths, dest, move).collect { p -> _state.update { it.copy(transfer = p) } }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _effects.tryEmit(UiEffect.Message(e.message ?: "Transfer failed"))
            } finally {
                _state.update { it.copy(transfer = null) }
                PaneSide.entries.forEach(::load)
            }
        }
    }

    private fun deleteSelected() {
        val paths = pane(_state.value.active).selection.toList()
        if (paths.isEmpty() || opJob?.isActive == true) return
        opJob = viewModelScope.launch {
            try { engine.delete(paths) } catch (e: CancellationException) { throw e } catch (e: Exception) {
                _effects.tryEmit(UiEffect.Message(e.message ?: "Delete failed"))
            } finally { PaneSide.entries.forEach(::load) }
        }
    }

    private fun pane(side: PaneSide) = _state.value.pane(side)

    private fun edit(side: PaneSide, f: (PaneState) -> PaneState) = _state.update {
        if (side == PaneSide.LEFT) it.copy(left = f(it.left)) else it.copy(right = f(it.right))
    }
}
