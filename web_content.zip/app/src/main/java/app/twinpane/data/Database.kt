package app.twinpane.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.*
import app.twinpane.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val label: String,
    val path: String,
    val position: Int = 0,
)

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY position, id") fun observeAll(): Flow<List<Bookmark>>
    @Insert suspend fun insert(b: Bookmark): Long
    @Delete suspend fun delete(b: Bookmark)
}

@Database(entities = [Bookmark::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() { abstract fun bookmarks(): BookmarkDao }

private val Context.dataStore by preferencesDataStore("settings")

class SettingsRepository(private val ctx: Context) {
    private val kTheme = stringPreferencesKey("theme_mode")
    private val kDynamic = booleanPreferencesKey("dynamic_color")

    val themeMode: Flow<ThemeMode> = ctx.dataStore.data.map { p ->
        runCatching { ThemeMode.valueOf(p[kTheme] ?: "") }.getOrDefault(ThemeMode.SYSTEM)
    }
    val dynamicColor: Flow<Boolean> = ctx.dataStore.data.map { it[kDynamic] ?: true }

    suspend fun setThemeMode(m: ThemeMode) { ctx.dataStore.edit { it[kTheme] = m.name } }
    suspend fun setDynamicColor(v: Boolean) { ctx.dataStore.edit { it[kDynamic] = v } }
}
