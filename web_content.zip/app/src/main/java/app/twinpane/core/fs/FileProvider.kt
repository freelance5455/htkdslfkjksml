package app.twinpane.core.fs

import java.io.InputStream
import java.io.OutputStream

/**
 * Sanal dosya sistemi (VFS) katmanı. Yerel, root, SAF, arşiv, SFTP... hepsi bu arayüzü uygular;
 * UI ve TransferEngine hangi depolamayla konuştuğunu bilmez. Bu sayede "arşivi klasör gibi aç"
 * ve "paneller arası direkt kopyala" aynı koddan çalışır.
 */
interface FileProvider {
    fun accepts(path: String): Boolean
    suspend fun list(path: String): List<FileItem>
    suspend fun stat(path: String): FileItem?
    suspend fun mkdir(path: String): Boolean
    /** Dizinse özyinelemeli siler; symlink'leri takip etmez. */
    suspend fun delete(path: String): Boolean
    suspend fun rename(path: String, newName: String): Boolean
    /** Aynı sağlayıcı içinde anında taşıma. Desteklenmiyorsa false -> kopyala+sil. */
    suspend fun moveWithin(src: String, dstPath: String): Boolean = false
    fun openInput(path: String): InputStream
    fun openOutput(path: String): OutputStream
    fun child(dir: String, name: String): String = dir.trimEnd('/') + "/" + name
}

class ProviderRegistry(private val providers: List<FileProvider>) {
    fun resolve(path: String): FileProvider =
        providers.firstOrNull { it.accepts(path) } ?: error("No provider for $path")
}
