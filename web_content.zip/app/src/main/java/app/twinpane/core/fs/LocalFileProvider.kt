package app.twinpane.core.fs

import android.system.Os
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

class LocalFileProvider : FileProvider {
    override fun accepts(path: String) = path.startsWith("/")

    override suspend fun list(path: String): List<FileItem> = withContext(Dispatchers.IO) {
        val files = File(path).listFiles() ?: throw IOException("Cannot read: $path")
        files.map { it.toItem() }
    }

    override suspend fun stat(path: String): FileItem? = withContext(Dispatchers.IO) {
        File(path).takeIf { it.exists() || it.isSymlink() }?.toItem()
    }

    override suspend fun mkdir(path: String) = withContext(Dispatchers.IO) { File(path).mkdirs() }
    override suspend fun delete(path: String) = withContext(Dispatchers.IO) { File(path).deleteSafely() }

    override suspend fun rename(path: String, newName: String) = withContext(Dispatchers.IO) {
        val f = File(path); f.renameTo(File(f.parentFile, newName))
    }

    override suspend fun moveWithin(src: String, dstPath: String) =
        withContext(Dispatchers.IO) { File(src).renameTo(File(dstPath)) }

    override fun openInput(path: String): InputStream = FileInputStream(path)
    override fun openOutput(path: String): OutputStream = FileOutputStream(path)

    suspend fun symlink(target: String, link: String): Boolean =
        withContext(Dispatchers.IO) { runCatching { Os.symlink(target, link) }.isSuccess }

    private fun File.isSymlink() = runCatching { canonicalPath != absolutePath }.getOrDefault(false)

    private fun File.deleteSafely(): Boolean {
        if (!isSymlink() && isDirectory) listFiles()?.forEach { it.deleteSafely() }
        return delete()
    }

    private fun File.toItem() = FileItem(
        path = absolutePath, name = name, isDirectory = isDirectory,
        size = if (isDirectory) 0L else length(), modified = lastModified(),
        isHidden = isHidden, isSymlink = isSymlink(),
    )
}
