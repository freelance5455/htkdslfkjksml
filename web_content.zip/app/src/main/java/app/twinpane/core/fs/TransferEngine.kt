package app.twinpane.core.fs

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flowOn

data class TransferProgress(
    val currentName: String,
    val doneBytes: Long,
    val totalBytes: Long,
    val finished: Boolean = false,
)

/** Sağlayıcıdan bağımsız kopyala/taşı/sil. Paneller arası "paste'siz" aktarımın kalbi. */
class TransferEngine(private val registry: ProviderRegistry) {

    fun transfer(sources: List<String>, destDir: String, move: Boolean): Flow<TransferProgress> = channelFlow {
        val dp = registry.resolve(destDir)
        val total = sources.sumOf { sizeOf(it) }
        var done = 0L

        suspend fun copyNode(src: String, dst: String) {
            val sp = registry.resolve(src)
            val item = sp.stat(src) ?: return
            if (item.isSymlink && item.isDirectory) return
            if (item.isDirectory) {
                dp.mkdir(dst)
                for (c in sp.list(src)) copyNode(c.path, dp.child(dst, c.name))
            } else {
                sp.openInput(src).use { input ->
                    dp.openOutput(dst).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n); done += n
                            send(TransferProgress(item.name, done, total))
                        }
                    }
                }
            }
        }

        for (src in sources) {
            val base = src.trimEnd('/')
            require(destDir != base && !destDir.startsWith("$base/")) { "Cannot put a folder into itself" }
            val sp = registry.resolve(src)
            val item = sp.stat(src) ?: continue
            if (move && base.substringBeforeLast('/') == destDir.trimEnd('/')) continue
            val dst = uniqueChild(dp, destDir, item.name)
            if (move && sp === dp && sp.moveWithin(src, dst)) continue
            copyNode(src, dst)
            if (move) sp.delete(src)
        }
        send(TransferProgress("", total, total, finished = true))
    }.flowOn(Dispatchers.IO)

    suspend fun delete(paths: List<String>) {
        for (p in paths) registry.resolve(p).delete(p)
    }

    private suspend fun sizeOf(path: String): Long {
        val p = registry.resolve(path)
        val item = p.stat(path) ?: return 0L
        return if (item.isDirectory && !item.isSymlink) p.list(path).sumOf { sizeOf(it.path) } else item.size
    }

    /** Çakışmada üzerine yazmaz: "ad (1).uzantı" üretir. */
    private suspend fun uniqueChild(p: FileProvider, dir: String, name: String): String {
        var candidate = p.child(dir, name)
        if (p.stat(candidate) == null) return candidate
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            candidate = p.child(dir, "$base ($i)$ext")
            if (p.stat(candidate) == null) return candidate
            i++
        }
    }
}
