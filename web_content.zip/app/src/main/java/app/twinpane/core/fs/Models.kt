package app.twinpane.core.fs

import java.util.Locale

data class FileItem(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val size: Long,
    val modified: Long,
    val isHidden: Boolean,
    val isSymlink: Boolean = false,
) {
    val extension: String get() = if (isDirectory) "" else name.substringAfterLast('.', "").lowercase()
}

enum class SortOrder { NAME, SIZE, DATE, TYPE }
enum class PaneSide { LEFT, RIGHT; fun other() = if (this == LEFT) RIGHT else LEFT }

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes.toDouble(); var i = -1
    do { v /= 1024; i++ } while (v >= 1024 && i < units.lastIndex)
    return String.format(Locale.getDefault(), "%.1f %s", v, units[i])
}
