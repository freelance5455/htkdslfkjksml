package bf.tontinesolidaire.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var cameraOutputUri: Uri? = null
    private var pendingBackupJson: String? = null

    private val createBackupLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri == null) {
            pendingBackupJson = null
            return@registerForActivityResult
        }
        try {
            contentResolver.openOutputStream(uri)?.use { stream ->
                stream.write((pendingBackupJson ?: "{}").toByteArray(Charsets.UTF_8))
            }
            runOnUiThread { webView.evaluateJavascript("alert('Sauvegarde exportée avec succès.');", null) }
        } catch (e: Exception) {
            runOnUiThread { webView.evaluateJavascript("alert('Impossible d\u0027écrire la sauvegarde.');", null) }
        } finally {
            pendingBackupJson = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(15, 23, 42)
        window.navigationBarColor = android.graphics.Color.rgb(15, 23, 42)

        webView = WebView(this)
        setContentView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            databaseEnabled = true
            setSupportZoom(true)
            builtInZoomControls = false
            displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
        }
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.host == "appassets.androidplatform.net") return false
                return openExternal(uri)
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                launchFileChooser(fileChooserParams)
                return true
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private fun openExternal(uri: Uri): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            true
        } catch (_: Exception) {
            true
        }
    }

    private fun launchFileChooser(params: WebChromeClient.FileChooserParams) {
        val mimeTypes = params.acceptTypes.filter { it.isNotBlank() }.toTypedArray()
        val pickIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = if (mimeTypes.size == 1 && !mimeTypes[0].contains(',')) mimeTypes[0] else "*/*"
            if (mimeTypes.isNotEmpty()) putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val wantsImage = mimeTypes.any { it.contains("image") } || params.isCaptureEnabled
        var cameraIntent: Intent? = null
        if (wantsImage) {
            try {
                val cameraDir = File(cacheDir, "camera").apply { mkdirs() }
                val photoFile = File.createTempFile("tontine_photo_", ".jpg", cameraDir)
                cameraOutputUri = FileProvider.getUriForFile(
                    this,
                    "bf.tontinesolidaire.app.fileprovider",
                    photoFile
                )
                cameraIntent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                    putExtra(android.provider.MediaStore.EXTRA_OUTPUT, cameraOutputUri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                }
            } catch (_: Exception) {
                cameraIntent = null
            }
        }

        try {
            val chooser = if (cameraIntent != null && android.os.Build.VERSION.SDK_INT >= 24) {
                Intent.createChooser(pickIntent, "Choisir un document ou prendre une photo", arrayOf(cameraIntent!!))
            } else {
                Intent.createChooser(pickIntent, "Choisir un document")
            }
            @Suppress("DEPRECATION")
            startActivityForResult(chooser, FILE_CHOOSER_REQUEST)
        } catch (_: Exception) {
            fileChooserCallback?.onReceiveValue(null)
            fileChooserCallback = null
        }
    }

    @Deprecated("Deprecated in Android, retained for WebView file chooser compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != FILE_CHOOSER_REQUEST) return
        val callback = fileChooserCallback ?: return
        var results: Array<Uri>? = null
        if (resultCode == Activity.RESULT_OK) {
            val selected = data?.data ?: cameraOutputUri
            if (selected != null) results = arrayOf(selected)
        }
        callback.onReceiveValue(results)
        fileChooserCallback = null
        cameraOutputUri = null
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun saveBackup(json: String) {
            pendingBackupJson = json
            runOnUiThread {
                createBackupLauncher.launch("tontine-solidaire-bf-sauvegarde.json")
            }
        }

        @JavascriptInterface
        fun exitApp() {
            runOnUiThread { finishAndRemoveTask() }
        }
    }

    companion object {
        private const val FILE_CHOOSER_REQUEST = 4207
    }
}
