package jp.pocovirus.prank

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import android.view.WindowManager
import android.provider.Settings

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooserCallback: android.webkit.ValueCallback<Array<Uri>>? = null
    private val audioRequest = 41

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePathCallback: android.webkit.ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = filePathCallback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(intent, audioRequest)
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun canOverlay(): Boolean = Settings.canDrawOverlays(this@MainActivity)
        @JavascriptInterface fun requestOverlay() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        }
        @JavascriptInterface fun start() {
            runOnUiThread {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "先に「他のアプリの上に表示」を許可してください", Toast.LENGTH_LONG).show()
                    requestOverlay()
                } else {
                    val i = Intent(this@MainActivity, PopupService::class.java)
                    startForegroundService(i)
                    Toast.makeText(this@MainActivity, "演出を開始しました。通知からも停止できます。", Toast.LENGTH_SHORT).show()
                }
            }
        }
        @JavascriptInterface fun stop() {
            stopService(Intent(this@MainActivity, PopupService::class.java))
            runOnUiThread { Toast.makeText(this@MainActivity, "演出を停止しました", Toast.LENGTH_SHORT).show() }
        }
        @JavascriptInterface fun setInterval(seconds: Int) {
            getSharedPreferences("poco", MODE_PRIVATE).edit().putInt("interval", seconds.coerceIn(15, 300)).apply()
        }
        @JavascriptInterface fun setSound(uri: String) {
            getSharedPreferences("poco", MODE_PRIVATE).edit().putString("sound", uri).apply()
        }
        @JavascriptInterface fun chooseSound() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(intent, audioRequest)
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == audioRequest) {
            val uri = if (resultCode == RESULT_OK) data?.data else null
            if (uri != null) {
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                getSharedPreferences("poco", MODE_PRIVATE).edit().putString("sound", uri.toString()).apply()
                val name = queryName(uri)
                web.evaluateJavascript("onSoundChosen(${org.json.JSONObject.quote(name)})", null)
            }
        }
    }

    private fun queryName(uri: Uri): String {
        var name = "選択した音声"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ix >= 0) name = c.getString(ix) ?: name
            }
        }
        return name
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
