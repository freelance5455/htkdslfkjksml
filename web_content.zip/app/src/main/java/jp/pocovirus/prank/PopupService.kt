package jp.pocovirus.prank

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class PopupService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var popup: android.view.View? = null
    private var player: MediaPlayer? = null
    private var running = false
    private val prefs by lazy { getSharedPreferences("poco", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val stopIntent = PendingIntent.getService(
            this, 1, Intent(this, PopupService::class.java).setAction("STOP"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, "poco_run")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("POCO VIRUS：演出中")
            .setContentText("通知の「停止」からいつでも終了できます")
            .addAction(android.R.drawable.ic_media_pause, "停止", stopIntent)
            .setOngoing(true)
            .build()
        startForeground(7, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            handler.postDelayed(showTask, 5000)
        }
        return START_NOT_STICKY
    }

    private val showTask = object : Runnable {
        override fun run() {
            if (!running) return
            showPopup()
            val seconds = prefs.getInt("interval", 45).coerceIn(15, 300)
            handler.postDelayed(this, seconds * 1000L)
        }
    }

    private fun showPopup() {
        if (popup != null) return
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = GradientDrawable().apply {
                setColor(Color.rgb(242, 242, 242))
                setStroke(2, Color.rgb(120, 20, 20))
                cornerRadius = 8f
            }
        }
        val title = TextView(this).apply {
            text = "⚠  Windows Security Alert"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(125, 15, 15))
            typeface = Typeface.DEFAULT_BOLD
        }
        val message = TextView(this).apply {
            text = "重大な警告！\\n\\nあなたのAndroidがウイルスにさらされています！\\n\\n不審なアクティビティが検出されました。"
            textSize = 17f
            setTextColor(Color.BLACK)
            setPadding(8, 22, 8, 22)
        }
        val small = TextView(this).apply {
            text = "ジョークアプリによる演出です"
            textSize = 9f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.END
        }
        val buttons = LinearLayout(this).apply { gravity = Gravity.END; orientation = LinearLayout.HORIZONTAL }
        val close = Button(this).apply { text = "×"; setOnClickListener { removePopup() } }
        val ok = Button(this).apply {
            text = "OK"
            setOnClickListener {
                removePopup()
                showDownloadDialog()
            }
        }
        buttons.addView(close)
        buttons.addView(ok)
        panel.addView(title)
        panel.addView(message)
        panel.addView(small)
        panel.addView(buttons)

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            dimAmount = 0.22f
        }
        try {
            wm.addView(panel, params)
            popup = panel
            playSound()
        } catch (_: Exception) {}
    }

    private fun showDownloadDialog() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 18, 24, 18)
            background = GradientDrawable().apply { setColor(Color.WHITE); setStroke(2, Color.GRAY); cornerRadius = 8f }
        }
        val heading = TextView(this).apply {
            text = "Android Security"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(65, 75, 85))
        }
        val body = TextView(this).apply {
            text = "アンドロイド防御ファイルをダウンロードしますか？"
            textSize = 17f
            setTextColor(Color.BLACK)
            setPadding(8, 24, 8, 24)
        }
        val buttons = LinearLayout(this).apply { gravity = Gravity.END }
        val cancel = Button(this).apply { text = "キャンセル"; setOnClickListener { removePopup() } }
        val download = Button(this).apply {
            text = "ダウンロード"
            setOnClickListener {
                removePopup()
                showPunchline()
            }
        }
        buttons.addView(cancel); buttons.addView(download)
        panel.addView(heading); panel.addView(body); panel.addView(buttons)
        addPanel(panel)
    }

    private fun showPunchline() {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 30, 24, 30)
            background = GradientDrawable().apply { setColor(Color.rgb(25,25,25)); cornerRadius = 8f }
        }
        val done = TextView(this).apply {
            text = "ダウンロード完了！"
            textSize = 14f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        val joke = TextView(this).apply {
            text = "防御なんかねえよ🥴"
            textSize = 27f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val close = Button(this).apply { text = "閉じる"; setOnClickListener { removePopup() } }
        panel.addView(done); panel.addView(joke); panel.addView(close)
        addPanel(panel)
    }

    private fun addPanel(panel: LinearLayout) {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.88f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            0,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try { wm.addView(panel, params); popup = panel } catch (_: Exception) {}
    }

    private fun playSound() {
        val raw = prefs.getString("sound", null) ?: return
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@PopupService, Uri.parse(raw))
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                setOnPreparedListener { it.start() }
                setOnCompletionListener { it.release(); if (player === it) player = null }
                prepareAsync()
            }
        } catch (_: Exception) { player?.release(); player = null }
    }

    private fun removePopup() {
        popup?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        popup = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("poco_run", "POCO VIRUS 演出", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        removePopup()
        player?.release()
        player = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
