package dz.physique.app;
import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebSettings; import android.webkit.WebChromeClient;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setSupportMultipleWindows(true); s.setJavaScriptCanOpenWindowsAutomatically(true); w.setWebChromeClient(new WebChromeClient()); w.loadUrl("file:///android_asset/index.html"); setContentView(w);}
}
