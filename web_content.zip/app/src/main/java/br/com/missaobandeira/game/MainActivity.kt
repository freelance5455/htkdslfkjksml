package br.com.missaobandeira.game

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var game: WebView
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Trava a orientação em paisagem automaticamente ao abrir o app, sem pedir permissões.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        game = WebView(this)
        game.settings.javaScriptEnabled = true
        game.settings.domStorageEnabled = true
        game.settings.allowFileAccess = true
        game.settings.allowContentAccess = false
        game.settings.javaScriptCanOpenWindowsAutomatically = false
        game.settings.setSupportMultipleWindows(false)
        game.webViewClient = WebViewClient()
        game.webChromeClient = WebChromeClient()
        game.keepScreenOn = true
        game.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        setContentView(game)
        game.loadUrl("file:///android_asset/index.html")
    }
    override fun onResume() {
        super.onResume()
        // Reforça a orientação horizontal ao retornar ao aplicativo, sem permissões ou avisos.
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::game.isInitialized) {
            game.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }
    override fun onBackPressed() {
        // Mantém o jogo simples: voltar sai do aplicativo.
        super.onBackPressed()
    }
}
