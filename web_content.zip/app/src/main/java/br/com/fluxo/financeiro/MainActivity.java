package br.com.fluxo.financeiro;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
  private WebView webView;
  private android.webkit.ValueCallback<android.net.Uri[]> filePathCallback;
  private static final int FILE_CHOOSER_REQUEST = 1001;
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    webView = new WebView(this);
    setContentView(webView);
    webView.getSettings().setJavaScriptEnabled(true);
    webView.getSettings().setDomStorageEnabled(true);
    webView.getSettings().setAllowFileAccess(true);
    webView.getSettings().setAllowContentAccess(true);
    webView.getSettings().setSupportMultipleWindows(false);
    webView.setWebViewClient(new WebViewClient());
    webView.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<android.net.Uri[]> callback, FileChooserParams params) {
        if (MainActivity.this.filePathCallback != null) MainActivity.this.filePathCallback.onReceiveValue(null);
        MainActivity.this.filePathCallback = callback;
        try { startActivityForResult(params.createIntent(), FILE_CHOOSER_REQUEST); return true; }
        catch (Exception e) { MainActivity.this.filePathCallback = null; callback.onReceiveValue(null); return false; }
      }
    });
    webView.addJavascriptInterface(new FluxoBridge(), "NativeBridge");
    webView.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() {
    if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
  }
  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
      android.net.Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
      filePathCallback.onReceiveValue(results); filePathCallback = null; return;
    }
    super.onActivityResult(requestCode, resultCode, data);
  }
  private class FluxoBridge {
    @JavascriptInterface public void shareFile(String name, String mime, String base64) {
      new Thread(() -> {
        try {
          byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
          File dir = new File(getCacheDir(), "exports");
          if (!dir.exists() && !dir.mkdirs()) throw new Exception("Não foi possível preparar os arquivos temporários.");
          String sanitized = name == null ? "fluxo-export" : name.replaceAll("[^a-zA-Z0-9._-]", "-");
          final String safe = sanitized.isEmpty() ? "fluxo-export" : sanitized;
          File file = new File(dir, safe);
          try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); out.flush(); }
          Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
          runOnUiThread(() -> {
            try {
              Intent send = new Intent(Intent.ACTION_SEND);
              send.setType((mime == null || mime.trim().isEmpty()) ? "application/octet-stream" : mime);
              send.putExtra(Intent.EXTRA_STREAM, uri);
              send.setClipData(ClipData.newUri(getContentResolver(), safe, uri));
              send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
              startActivity(Intent.createChooser(send, "Compartilhar ou salvar arquivo"));
            } catch (Exception e) { Toast.makeText(MainActivity.this, "Não foi possível abrir o compartilhamento.", Toast.LENGTH_LONG).show(); }
          });
        } catch (Exception e) { runOnUiThread(() -> Toast.makeText(MainActivity.this, "Falha ao preparar o arquivo para compartilhar.", Toast.LENGTH_LONG).show()); }
      }).start();
    }
    @JavascriptInterface public void saveFile(String name, String mime, String base64) { shareFile(name, mime, base64); }
  }
  @Override protected void onDestroy() { if (webView != null) { webView.removeJavascriptInterface("NativeBridge"); webView.destroy(); } super.onDestroy(); }
}
