package br.com.runnershort.game

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat

private const val TAG = "RunnerShotGun"
private const val LOCAL_GAME_URL = "https://appassets.androidplatform.net/assets/index.html"

/** Intercepts the reserved appassets host and serves files bundled in app/src/main/assets. */
private class LocalContentWebViewClient(
    private val assetLoader: WebViewAssetLoader
) : WebViewClientCompat() {
    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest
    ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

    @Suppress("DEPRECATION")
    override fun shouldInterceptRequest(view: WebView, url: String): WebResourceResponse? =
        assetLoader.shouldInterceptRequest(Uri.parse(url))

    override fun onReceivedHttpError(
        view: WebView,
        request: WebResourceRequest,
        errorResponse: WebResourceResponse
    ) {
        super.onReceivedHttpError(view, request, errorResponse)
        if (request.isForMainFrame) {
            Log.e(TAG, "Falha HTTP ao abrir ${request.url}: ${errorResponse.statusCode} ${errorResponse.reasonPhrase}")
        }
    }

    override fun onReceivedError(
        view: WebView,
        request: WebResourceRequest,
        error: android.webkit.WebResourceError
    ) {
        super.onReceivedError(view, request, error)
        if (request.isForMainFrame) {
            Log.e(TAG, "Falha ao carregar a página principal ${request.url}: ${error.errorCode} ${error.description}")
        }
    }
}

class MainActivity : Activity() {
    private lateinit var game: WebView

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

        game = WebView(this)
        game.settings.javaScriptEnabled = true
        game.settings.domStorageEnabled = true
        // WebViewAssetLoader supplies the HTTPS-like local origin; file:// access is unnecessary.
        game.settings.allowFileAccess = false
        game.settings.allowContentAccess = false
        game.settings.javaScriptCanOpenWindowsAutomatically = false
        game.settings.setSupportMultipleWindows(false)
        game.settings.allowFileAccessFromFileURLs = false
        game.settings.allowUniversalAccessFromFileURLs = false

        val assetLoader = WebViewAssetLoader.Builder()
            // Caminho oficial do WebViewAssetLoader: /assets/ mapeia para app/src/main/assets/.
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        game.webViewClient = LocalContentWebViewClient(assetLoader)
        game.webChromeClient = WebChromeClient()
        game.keepScreenOn = true
        game.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        setContentView(game)

        // URL virtual servida localmente pelo WebViewAssetLoader; não exige internet para abrir o HTML.
        // /assets/index.html corresponde exatamente a app/src/main/assets/index.html.
        if (runCatching { assets.open("index.html").use { it.read() }; true }.getOrDefault(false)) {
            Log.i(TAG, "Abrindo HTML local: $LOCAL_GAME_URL")
            game.loadUrl(LOCAL_GAME_URL)
        } else {
            Log.e(TAG, "O arquivo app/src/main/assets/index.html não foi incluído no APK.")
            game.loadDataWithBaseURL(
                "https://appassets.androidplatform.net/",
                "<!doctype html><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><body style='font:16px system-ui;background:#142b3c;color:white;padding:24px'><h2>Runner Shot Gun</h2><p>O HTML local do jogo não foi incluído neste APK.</p><p>Confira app/src/main/assets/index.html e gere o APK novamente.</p></body>",
                "text/html", "UTF-8", null
            )
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    override fun onResume() {
        super.onResume()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && ::game.isInitialized) {
            game.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }
}
