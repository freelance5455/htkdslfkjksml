package pk.edu.khairpur.sindhrover;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Trusted offline dashboard bundled inside a native Android application.
 * Uses the Wi-Fi HTTP API of Sindh Rescue Rover firmware v3.2/v3.3.
 * No BLE in v1.0; no Internet, paid APIs, or external Java libraries needed.
 */
public final class MainActivity extends Activity {
    private static final String ROVER_ORIGIN = "http://192.168.4.1/";
    private static final int BG = Color.rgb(9, 20, 34);
    private static final int TEAL = Color.rgb(96, 226, 195);
    private static final int MUTED = Color.rgb(171, 194, 205);
    private static final int RED = Color.rgb(232, 110, 117);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService stopExecutor = Executors.newSingleThreadExecutor();
    // All routine requests are serialized; an independent STOP path remains available.
    private final ExecutorService apiExecutor = Executors.newSingleThreadExecutor();
    private ConnectivityManager.NetworkCallback wifiCallback;
    private volatile Network selectedWifi;
    private volatile String activeClientId = "";

    private ConnectivityManager cm;
    private Network boundWifi;
    private WebView web;
    private TextView connectionLabel;
    private boolean visible = false;
    private boolean destroyed = false;

    // Some Android phones prefer cellular data if ESP32's Wi-Fi has no Internet.
    // Bind this process's traffic to the user's *already selected* Wi-Fi network.
    private final Runnable wifiBinder = new Runnable() {
        @Override public void run() {
            if (!visible || destroyed) return;
            bindToAvailableWifi();
            handler.postDelayed(this, 3000);
        }
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        bindToAvailableWifi();
        registerWifiWatcher();

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(BG);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setPadding(dp(12), dp(7), dp(9), dp(7));
        toolbar.setBackgroundColor(Color.rgb(12, 30, 43));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView heading = new TextView(this);
        heading.setText("SINDH ROVER");
        heading.setTextColor(Color.WHITE);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextSize(14);
        titles.addView(heading);
        connectionLabel = new TextView(this);
        connectionLabel.setText("CONNECT TO ROVER WI-FI");
        connectionLabel.setTextSize(10);
        connectionLabel.setTextColor(MUTED);
        titles.addView(connectionLabel);
        toolbar.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        Button wifi = createButton("Wi-Fi", Color.rgb(33, 69, 80));
        wifi.setContentDescription("Open Wi-Fi settings and select RescueRover-S3");
        wifi.setOnClickListener(v -> openWifiSettings());
        toolbar.addView(wifi, new LinearLayout.LayoutParams(-2, dp(44)));

        Button refresh = createButton("↻", Color.rgb(30, 54, 70));
        refresh.setContentDescription("Stop motors and reload dashboard");
        refresh.setTextSize(23);
        refresh.setOnClickListener(v -> {
            stopOnBoard();
            bindToAvailableWifi();
            loadBundledDashboard();
        });
        toolbar.addView(refresh, new LinearLayout.LayoutParams(dp(47), dp(44)));

        Button stop = createButton("STOP", Color.rgb(124, 43, 50));
        stop.setTextSize(13);
        stop.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        stop.setContentDescription("Emergency software STOP; also use the physical motor power switch");
        stop.setOnClickListener(v -> {
            // UI command is sequenced with any in-flight movement requests.
            if (web != null) web.evaluateJavascript("window.roverNativeStop&&window.roverNativeStop()", null);
            // Independent HTTP backup if the UI JavaScript hangs.
            stopOnBoard();
        });
        toolbar.addView(stop, new LinearLayout.LayoutParams(dp(66), dp(44)));

        layout.addView(toolbar, new LinearLayout.LayoutParams(-1, -2));
        web = new WebView(this);
        web.setBackgroundColor(BG);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings config = web.getSettings();
        config.setJavaScriptEnabled(true); // required by bundled dashboard only
        config.setDomStorageEnabled(false);
        config.setAllowFileAccess(false);
        config.setAllowContentAccess(false);
        config.setJavaScriptCanOpenWindowsAutomatically(false);
        config.setSupportMultipleWindows(false);
        config.setCacheMode(WebSettings.LOAD_NO_CACHE);
        config.setDefaultTextEncodingName("UTF-8");
        web.addJavascriptInterface(new RoverJsBridge(), "RoverNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // This is an application, not a general-purpose browser.
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith(ROVER_ORIGIN)) return null;
                // Prevent embedded content from navigating to outside sites.
                return new WebResourceResponse("text/plain", "UTF-8",
                        new ByteArrayInputStream(new byte[0]));
            }
        });
        layout.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(layout);
        loadBundledDashboard();
    }

    private Button createButton(String text, int background) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(background));
        b.setPadding(dp(7), 0, dp(7), 0);
        return b;
    }

    private int dp(float d) { return Math.round(getResources().getDisplayMetrics().density * d); }

    private void loadBundledDashboard() {
        try (InputStream in = getAssets().open("dashboard.html")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int count;
            while ((count = in.read(chunk)) != -1) out.write(chunk, 0, count);
            String html = out.toString(StandardCharsets.UTF_8.name());
            // This HTTP base origin lets fetch('/api/...') use ESP32's actual address
            // without CORS problems, even though HTML is stored locally in the APK.
            web.loadDataWithBaseURL(ROVER_ORIGIN, html, "text/html", "UTF-8", null);
        } catch (IOException e) {
            Toast.makeText(this, "Dashboard asset could not be opened", Toast.LENGTH_LONG).show();
        }
    }

    private final class RoverJsBridge {
        /** Requests always use Network.openConnection on a Wi-Fi transport,
         *  NEVER a cellular/default interface. Background operations never block WebView. */
        @JavascriptInterface public void httpRequest(int requestId, String path) {
            if (destroyed || requestId < 1 || requestId > 1000000000) return;
            if (!isAllowedApiPath(path)) {
                completeJsRequest(requestId, false, "Invalid rover API path");
                return;
            }
            ExecutorService executor = path.startsWith("/api/stop") ? stopExecutor : apiExecutor;
            executor.execute(() -> {
                try {
                    String result = requestRover(path, 1500, 1700);
                    completeJsRequest(requestId, true, result);
                } catch (Exception e) {
                    String problem = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
                    completeJsRequest(requestId, false, problem);
                }
            });
        }
        @JavascriptInterface public void setSessionId(String id) {
            // Non-sensitive per-WebView command sequence key, digits only.
            if (id != null && id.matches("[0-9]{1,12}")) activeClientId = id;
        }
        @JavascriptInterface public void linkState(boolean connected, String label) {
            if (destroyed) return;
            runOnUiThread(() -> {
                if (destroyed) return;
                connectionLabel.setText(connected ? "● ROVER CONNECTED" : "● " + label);
                connectionLabel.setTextColor(connected ? TEAL : RED);
            });
        }
    }

    private static boolean isAllowedApiPath(String path) {
        if (path == null || path.length() > 230 || path.indexOf('#') >= 0
                || path.indexOf('\\') >= 0 || path.contains("//") || path.contains("..")) return false;
        return path.equals("/api/state?poll=1") || path.startsWith("/api/state?poll=1&")
                || path.matches("/api/cmd\\?c=[A-Za-z0-9:%._-]{1,18}(&[a-zA-Z0-9_=%.-]+)*")
                || path.matches("/api/stop(\\?[a-zA-Z0-9_=%.-]+)?");
    }

    private void completeJsRequest(int requestId, boolean ok, String payload) {
        handler.post(() -> {
            if (destroyed || web == null) return;
            web.evaluateJavascript("window.roverHttpReply&&window.roverHttpReply("
                    + requestId + "," + ok + "," + JSONObject.quote(payload) + ");", null);
        });
    }

    private void registerWifiWatcher() {
        if (cm == null) return;
        try {
            NetworkRequest req = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build();
            wifiCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    selectedWifi = network;
                    handler.post(() -> bindToAvailableWifi());
                }
                @Override public void onLost(Network network) {
                    if (network.equals(selectedWifi)) selectedWifi = null;
                    handler.post(() -> bindToAvailableWifi());
                }
            };
            cm.registerNetworkCallback(req, wifiCallback);
        } catch (Exception ignored) { wifiCallback = null; }
    }

    private void bindToAvailableWifi() {
        if (cm == null) return;
        Network selected = null;
        try {
            // A Wi-Fi link to the rover often has no Internet. Do not require VALIDATED.
            Network previous = selectedWifi;
            if (previous != null && cm.getNetworkCapabilities(previous) != null
                    && cm.getNetworkCapabilities(previous).hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                selected = previous;
            }
            if (selected == null) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                    if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                        selected = n; break;
                    }
                }
            }
            selectedWifi = selected;
            if (selected != null && !selected.equals(boundWifi)) {
                if (cm.bindProcessToNetwork(selected)) boundWifi = selected;
            } else if (selected == null && boundWifi != null) {
                cm.bindProcessToNetwork(null);
                boundWifi = null;
            }
        } catch (Exception ignored) { }
    }

    private String requestRover(String path, int connectMs, int readMs) throws IOException {
        if (!isAllowedApiPath(path)) throw new IOException("Unsupported API route");
        Network route = selectedWifi;
        if (route == null) throw new IOException("Connect to RescueRover-S3 Wi-Fi first");
        HttpURLConnection conn = null;
        try {
            URL url = new URL(ROVER_ORIGIN + path.substring(1));
            // Explicit Wi-Fi transport: Android cannot silently route via mobile data.
            conn = (HttpURLConnection) route.openConnection(url);
            conn.setInstanceFollowRedirects(false);
            conn.setUseCaches(false);
            conn.setConnectTimeout(connectMs);
            conn.setReadTimeout(readMs);
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            int status = conn.getResponseCode();
            if (status != HttpURLConnection.HTTP_OK) throw new IOException("ESP32 HTTP " + status);
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] bytes = new byte[2048]; int n;
                while ((n = in.read(bytes)) >= 0) {
                    if (n == 0) continue;
                    if (out.size() + n > 10000) throw new IOException("Unexpectedly large ESP32 response");
                    out.write(bytes, 0, n);
                }
                return out.toString("UTF-8");
            }
        } finally { if (conn != null) conn.disconnect(); }
    }

    private void openWifiSettings() {
        try {
            Intent intent;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                intent = new Intent(Settings.Panel.ACTION_WIFI);
            else intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        }
        Toast.makeText(this, "Select RescueRover-S3; stay connected without Internet", Toast.LENGTH_LONG).show();
    }

    private void stopOnBoard() {
        if (destroyed) return;
        stopExecutor.execute(() -> {
            // Independent emergency path intentionally bypasses routine request queue.
            long sequence = System.currentTimeMillis() * 1000L + 999;
            String session = activeClientId;
            String route = "/api/stop?q=" + sequence
                    + (session.isEmpty() ? "" : "&cid=" + session);
            try {
                requestRover(route, 750, 850);
            } catch (IOException e) {
                // Secondary attempt, still using the explicit Wi-Fi route.
                try { requestRover("/api/stop", 750, 850); } catch (IOException ignored) { }
            }
        });
    }

    @Override protected void onResume() {
        super.onResume();
        visible = true;
        bindToAvailableWifi();
        handler.removeCallbacks(wifiBinder);
        handler.postDelayed(wifiBinder, 1500);
        if (web != null) web.onResume();
    }
    @Override protected void onPause() {
        visible = false;
        handler.removeCallbacks(wifiBinder);
        stopOnBoard(); // stops Manual, Cruise and Autonomous if app leaves foreground
        if (web != null) web.onPause();
        super.onPause();
    }
    @Override protected void onDestroy() {
        destroyed = true;
        handler.removeCallbacks(wifiBinder);
        stopExecutor.shutdown();
        apiExecutor.shutdownNow();
        if (cm != null && wifiCallback != null) {
            try { cm.unregisterNetworkCallback(wifiCallback); } catch (Exception ignored) { }
        }
        if (web != null) {
            web.removeJavascriptInterface("RoverNative");
            web.destroy();
            web = null;
        }
        if (cm != null && boundWifi != null) cm.bindProcessToNetwork(null);
        super.onDestroy();
    }
}
