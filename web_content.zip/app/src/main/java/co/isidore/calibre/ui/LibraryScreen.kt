package co.isidore.calibre.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import co.isidore.calibre.model.AuthorGroup
import co.isidore.calibre.model.Book
import co.isidore.calibre.model.SortMode
import co.isidore.calibre.ui.components.BookDetailDialog
import co.isidore.calibre.ui.components.PosterView
import co.isidore.calibre.ui.theme.CardSlate
import co.isidore.calibre.ui.theme.TextPrimary
import co.isidore.calibre.ui.theme.TextSecondary
import co.isidore.calibre.ui.theme.WarmGold

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: LibraryViewModel,
    onPersistUriPermission: (Uri) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val sortMode by viewModel.sortMode.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    var selectedBook by remember { mutableStateOf<Book?>(null) }
    var selectedAuthor by remember { mutableStateOf<AuthorGroup?>(null) }

    // SAF Document Tree Directory Picker
    val directoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        uri?.let {
            onPersistUriPermission(it)
            viewModel.triggerBulkDownload(it)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ISIDORE",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 2.sp,
                                    color = WarmGold
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF10B981))
                            )
                        }
                        Text(
                            text = "Calibre Repository Client",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary
                            )
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.syncLiveFeed() }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Sync Feed",
                            tint = TextPrimary
                        )
                    }
                    Button(
                        onClick = { directoryLauncher.launch(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = WarmGold),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudDownload,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Download Library",
                            color = Color.Black,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Search Input: adapts strictly to Author Search vs Publication Search
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = {
                    Text(
                        if (sortMode == SortMode.BY_AUTHOR) "Search author names..." else "Search publications by title, author, or tags...",
                        color = TextSecondary
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WarmGold,
                    unfocusedBorderColor = CardSlate,
                    focusedContainerColor = CardSlate,
                    unfocusedContainerColor = CardSlate
                )
            )

            // Sleek Tab / Segmented Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardSlate)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                TabButton(
                    title = "By Publication Name",
                    selected = sortMode == SortMode.BY_TITLE,
                    onClick = {
                        selectedAuthor = null
                        viewModel.setSortMode(SortMode.BY_TITLE)
                    },
                    modifier = Modifier.weight(1f)
                )
                TabButton(
                    title = "By Author",
                    selected = sortMode == SortMode.BY_AUTHOR,
                    onClick = {
                        viewModel.setSortMode(SortMode.BY_AUTHOR)
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            // State Content
            Box(modifier = Modifier.fillMaxSize()) {
                when (val state = uiState) {
                    is UiState.Loading -> {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = WarmGold)
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(text = state.message, color = TextSecondary, fontSize = 14.sp)
                        }
                    }
                    is UiState.Error -> {
                        Column(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = state.error, color = Color.Red, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = { viewModel.syncLiveFeed() }) {
                                Text("Retry")
                            }
                        }
                    }
                    is UiState.Success -> {
                        if (sortMode == SortMode.BY_AUTHOR) {
                            val activeAuthor = selectedAuthor
                            if (activeAuthor != null) {
                                // Drill-down into author's books
                                Column(modifier = Modifier.fillMaxSize()) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(onClick = { selectedAuthor = null }) {
                                            Icon(
                                                imageVector = Icons.Default.ArrowBack,
                                                contentDescription = "Back",
                                                tint = WarmGold,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("All Authors", color = WarmGold, fontSize = 12.sp)
                                        }
                                        Spacer(modifier = Modifier.weight(1f))
                                        Text(
                                            text = "${activeAuthor.books.size} publications",
                                            color = TextSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                    Text(
                                        text = activeAuthor.name,
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                    LazyVerticalGrid(
                                        columns = GridCells.Adaptive(minSize = 150.dp),
                                        contentPadding = PaddingValues(16.dp),
                                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(14.dp),
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        items(activeAuthor.books, key = { it.id }) { book ->
                                            PosterView(
                                                book = book,
                                                onClick = { selectedBook = book }
                                            )
                                        }
                                    }
                                }
                            } else {
                                // Author List View (individual listings)
                                if (state.authorGroups.isEmpty()) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text("No authors found matching criteria.", color = TextSecondary)
                                    }
                                } else {
                                    LazyColumn(
                                        contentPadding = PaddingValues(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        items(state.authorGroups, key = { it.name }) { group ->
                                            Card(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .clickable { selectedAuthor = group },
                                                colors = CardDefaults.cardColors(containerColor = CardSlate)
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(14.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(40.dp)
                                                            .clip(CircleShape)
                                                            .background(WarmGold.copy(alpha = 0.15f)),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Person,
                                                            contentDescription = null,
                                                            tint = WarmGold,
                                                            modifier = Modifier.size(20.dp)
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.width(12.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = group.name,
                                                            color = TextPrimary,
                                                            fontWeight = FontWeight.SemiBold,
                                                            fontSize = 15.sp
                                                        )
                                                        Text(
                                                            text = "${group.books.size} ${if (group.books.size == 1) "book" else "books"}",
                                                            color = TextSecondary,
                                                            fontSize = 12.sp
                                                        )
                                                    }
                                                    Text(
                                                        text = "›",
                                                        color = TextSecondary,
                                                        fontSize = 20.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            if (state.books.isEmpty()) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("No publications found matching criteria.", color = TextSecondary)
                                }
                            } else {
                                LazyVerticalGrid(
                                    columns = GridCells.Adaptive(minSize = 150.dp),
                                    contentPadding = PaddingValues(16.dp),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(state.books, key = { it.id }) { book ->
                                        PosterView(
                                            book = book,
                                            onClick = { selectedBook = book }
                                        )
                                    }
                                }
                            }
                        }
                    }
                    is UiState.Idle -> {}
                }
            }
        }

        // Publication Detail Dialog
        selectedBook?.let { book ->
            BookDetailDialog(
                book = book,
                onDismiss = { selectedBook = null },
                onDownloadFile = { _, _ ->
                    directoryLauncher.launch(null)
                }
            )
        }
    }
}

@Composable
fun TabButton(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) WarmGold else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) Color.Black else TextSecondary
        )
    }
}