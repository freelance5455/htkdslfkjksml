package co.isidore.calibre.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import co.isidore.calibre.database.DatabaseParser
import co.isidore.calibre.download.DownloadWorker
import co.isidore.calibre.model.Book
import co.isidore.calibre.model.SortMode
import co.isidore.calibre.network.NetworkModule
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed class UiState {
    object Idle : UiState()
    data class Loading(val message: String) : UiState()
    data class Success(val books: List<Book>, val authorGroups: List<co.isidore.calibre.model.AuthorGroup>) : UiState()
    data class Error(val error: String) : UiState()
}

class LibraryViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _sortMode = MutableStateFlow(SortMode.BY_TITLE)
    val sortMode: StateFlow<SortMode> = _sortMode.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private var rawBooks: List<Book> = emptyList()

    init {
        syncLiveFeed()
    }

    fun syncLiveFeed() {
        viewModelScope.launch {
            _uiState.value = UiState.Loading("Synchronizing with Isidore Calibre Feed...")
            val localDb = File(getApplication<Application>().cacheDir, "metadata.db")

            val downloadSuccess = NetworkModule.downloadMetadataDatabase(localDb)
            if (downloadSuccess) {
                val books = DatabaseParser.parseCalibreDatabase(localDb)
                rawBooks = books
                applyFilterAndSort()
            } else {
                if (localDb.exists()) {
                    rawBooks = DatabaseParser.parseCalibreDatabase(localDb)
                    applyFilterAndSort()
                } else {
                    _uiState.value = UiState.Error("Failed to fetch repository index from Isidore.")
                }
            }
        }
    }

    fun setSortMode(mode: SortMode) {
        _sortMode.value = mode
        applyFilterAndSort()
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        applyFilterAndSort()
    }

    private fun applyFilterAndSort() {
        val query = _searchQuery.value.trim()

        // 1. Publication books list (filtered by title, author, or tags)
        val filteredBooks = if (query.isNotEmpty()) {
            rawBooks.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.author.contains(query, ignoreCase = true) ||
                it.tags.any { tag -> tag.contains(query, ignoreCase = true) }
            }
        } else {
            rawBooks
        }
        val sortedBooks = filteredBooks.sortedBy { it.title.lowercase() }

        // 2. Individual authors list (Search bar on author screen strictly matches author names, not publication titles)
        val authorMap = mutableMapOf<String, MutableList<Book>>()
        for (book in rawBooks) {
            for (authorName in book.getIndividualAuthors()) {
                val authorBooks = authorMap.getOrPut(authorName) { mutableListOf() }
                if (!authorBooks.any { it.id == book.id }) {
                    authorBooks.add(book)
                }
            }
        }

        val filteredAuthorMap = if (query.isNotEmpty()) {
            authorMap.filterKeys { it.contains(query, ignoreCase = true) }
        } else {
            authorMap
        }

        val groups = filteredAuthorMap.map { (name, bList) ->
            co.isidore.calibre.model.AuthorGroup(
                name = name,
                books = bList.sortedBy { it.title.lowercase() }
            )
        }.sortedBy { it.name.lowercase() }

        _uiState.value = UiState.Success(books = sortedBooks, authorGroups = groups)
    }

    fun triggerBulkDownload(treeUri: Uri) {
        val inputData = Data.Builder()
            .putString(DownloadWorker.KEY_TREE_URI, treeUri.toString())
            .build()

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .setRequiresCharging(false)
            .build()

        val downloadWorkRequest = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setConstraints(constraints)
            .setInputData(inputData)
            .build()

        WorkManager.getInstance(getApplication()).enqueue(downloadWorkRequest)
    }
}
