package co.isidore.calibre.database

import android.database.sqlite.SQLiteDatabase
import co.isidore.calibre.model.Book
import co.isidore.calibre.model.BookFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object DatabaseParser {

    suspend fun parseCalibreDatabase(dbFile: File): List<Book> = withContext(Dispatchers.IO) {
        val books = mutableListOf<Book>()
        if (!dbFile.exists()) return@withContext books

        var db: SQLiteDatabase? = null
        try {
            db = SQLiteDatabase.openDatabase(
                dbFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY
            )

            // Step 1: Query Base Books & Authors Link
            val query = """
                SELECT 
                    b.id AS book_id, 
                    b.title AS book_title, 
                    b.sort AS book_sort, 
                    b.author_sort AS author_sort, 
                    b.path AS book_path, 
                    b.has_cover AS book_has_cover,
                    a.name AS author_name,
                    c.text AS book_comment
                FROM books b
                LEFT JOIN books_authors_link bal ON b.id = bal.book
                LEFT JOIN authors a ON bal.author = a.id
                LEFT JOIN comments c ON b.id = c.book
                ORDER BY b.title ASC
            """.trimIndent()

            val tempMap = mutableMapOf<Long, MutableBookRecord>()

            db.rawQuery(query, null).use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow("book_id")
                val titleCol = cursor.getColumnIndexOrThrow("book_title")
                val authorSortCol = cursor.getColumnIndexOrThrow("author_sort")
                val pathCol = cursor.getColumnIndexOrThrow("book_path")
                val hasCoverCol = cursor.getColumnIndexOrThrow("book_has_cover")
                val authorNameCol = cursor.getColumnIndexOrThrow("author_name")
                val commentCol = cursor.getColumnIndexOrThrow("book_comment")

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Untitled"
                    val authorSort = cursor.getString(authorSortCol) ?: "Unknown Author"
                    val path = cursor.getString(pathCol) ?: ""
                    val hasCover = cursor.getInt(hasCoverCol) == 1
                    val authorName = cursor.getString(authorNameCol) ?: "Unknown Author"
                    val comment = cursor.getString(commentCol)

                    if (!tempMap.containsKey(id)) {
                        tempMap[id] = MutableBookRecord(
                            id = id,
                            title = title,
                            authorSort = authorSort,
                            authors = mutableSetOf(authorName),
                            path = path,
                            hasCover = hasCover,
                            comment = comment
                        )
                    } else {
                        tempMap[id]?.authors?.add(authorName)
                    }
                }
            }

            // Step 2: Fetch Formats from `data` table
            val formatQuery = "SELECT book, format, uncompressed_size, name FROM data"
            val formatsMap = mutableMapOf<Long, MutableList<BookFormat>>()

            db.rawQuery(formatQuery, null).use { cursor ->
                val bookCol = cursor.getColumnIndexOrThrow("book")
                val formatCol = cursor.getColumnIndexOrThrow("format")
                val sizeCol = cursor.getColumnIndexOrThrow("uncompressed_size")
                val nameCol = cursor.getColumnIndexOrThrow("name")

                while (cursor.moveToNext()) {
                    val bId = cursor.getLong(bookCol)
                    val fmt = cursor.getString(formatCol) ?: ""
                    val size = cursor.getLong(sizeCol)
                    val name = cursor.getString(nameCol) ?: ""

                    val list = formatsMap.getOrPut(bId) { mutableListOf() }
                    list.add(BookFormat(fmt, size, name))
                }
            }

            // Step 3: Fetch Tags
            val tagsQuery = """
                SELECT btl.book, t.name 
                FROM books_tags_link btl 
                JOIN tags t ON btl.tag = t.id
            """.trimIndent()
            val tagsMap = mutableMapOf<Long, MutableList<String>>()

            db.rawQuery(tagsQuery, null).use { cursor ->
                val bookCol = cursor.getColumnIndexOrThrow("book")
                val tagCol = cursor.getColumnIndexOrThrow("name")

                while (cursor.moveToNext()) {
                    val bId = cursor.getLong(bookCol)
                    val tag = cursor.getString(tagCol) ?: ""
                    tagsMap.getOrPut(bId) { mutableListOf() }.add(tag)
                }
            }

            // Build domain instances
            for ((id, record) in tempMap) {
                books.add(
                    Book(
                        id = id,
                        title = record.title,
                        authorSort = record.authorSort,
                        author = record.authors.joinToString(", "),
                        authors = record.authors.toList(),
                        path = record.path,
                        hasCover = record.hasCover,
                        comment = record.comment,
                        tags = tagsMap[id] ?: emptyList(),
                        formats = formatsMap[id] ?: emptyList()
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            db?.close()
        }

        return@withContext books
    }

    private data class MutableBookRecord(
        val id: Long,
        val title: String,
        val authorSort: String,
        val authors: MutableSet<String>,
        val path: String,
        val hasCover: Boolean,
        val comment: String?
    )
}