package co.isidore.calibre.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DeepCharcoal = Color(0xFF121417)
val CardSlate = Color(0xFF1A1D24)
val CardHighlight = Color(0xFF262A34)
val WarmGold = Color(0xFFD4AF37)
val DeepIndigo = Color(0xFF6366F1)
val TextPrimary = Color(0xFFF3F4F6)
val TextSecondary = Color(0xFF9CA3AF)

private val DarkColorScheme = darkColorScheme(
    primary = WarmGold,
    secondary = DeepIndigo,
    background = DeepCharcoal,
    surface = CardSlate,
    surfaceVariant = CardHighlight,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary
)

@Composable
fun IsidoreTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}