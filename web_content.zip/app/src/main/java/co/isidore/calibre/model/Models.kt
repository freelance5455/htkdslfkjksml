package co.isidore.calibre.model

import java.io.Serializable

data class Book(
    val id: Long,
    val title: String,
    val authorSort: String,
    val author: String,
    val authors: List<String> = emptyList(),
    val path: String,
    val hasCover: Boolean,
    val comment: String? = null,
    val tags: List<String> = emptyList(),
    val formats: List<BookFormat> = emptyList()
) : Serializable {
    fun getCoverUrl(baseUrl: String): String {
        val sanitizedBase = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return "$sanitizedBase$path/cover.jpg"
    }

    /**
     * Returns individual authors, properly splitting co-authored books.
     */
    fun getIndividualAuthors(): List<String> {
        if (authors.isNotEmpty()) return authors
        return author.split(Regex(";;;|\s+&\s+|\s+and\s+", RegexOption.IGNORE_CASE))
            .map { it.trim().trim('|').trim() }
            .filter { it.isNotBlank() }
    }
}

data class AuthorGroup(
    val name: String,
    val books: List<Book>,
    val bookCount: Int = books.size
) : Serializable

data class BookFormat(
    val format: String,
    val uncompressedSize: Long,
    val name: String
) : Serializable {
    fun getFileUrl(baseUrl: String, bookPath: String): String {
        val sanitizedBase = if (baseUrl.endsWith("/")) baseUrl else "$baseUrl/"
        return "$sanitizedBase$bookPath/$name.$format".lowercase()
    }
}

enum class SortMode {
    BY_TITLE,
    BY_AUTHOR
}