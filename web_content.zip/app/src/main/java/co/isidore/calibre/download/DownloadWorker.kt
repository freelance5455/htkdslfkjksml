package co.isidore.calibre.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import co.isidore.calibre.database.DatabaseParser
import co.isidore.calibre.network.NetworkModule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File

class DownloadWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        const val KEY_TREE_URI = "tree_uri"
        const val CHANNEL_ID = "isidore_download_channel"
        const val NOTIFICATION_ID = 1001
    }

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val treeUriString = inputData.getString(KEY_TREE_URI) ?: return@withContext Result.failure()
        val treeUri = Uri.parse(treeUriString)

        createNotificationChannel()
        val initialNotification = createNotification("Starting Isidore Library Download...", 0, 100)
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            setForeground(ForegroundInfo(NOTIFICATION_ID, initialNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC))
        } else {
            setForeground(ForegroundInfo(NOTIFICATION_ID, initialNotification))
        }

        val targetDir = DocumentFile.fromTreeUri(context, treeUri)
            ?: return@withContext Result.failure()

        // 1. Fetch metadata.db to local cache to discover everything
        val tempDb = File(context.cacheDir, "temp_sync_metadata.db")
        val dbDownloaded = NetworkModule.downloadMetadataDatabase(tempDb)
        if (!dbDownloaded) return@withContext Result.retry()

        // Copy metadata.db into the target SAF directory
        saveFileToSaf(targetDir, "metadata.db", "application/x-sqlite3", tempDb.readBytes())

        // 2. Parse library models
        val books = DatabaseParser.parseCalibreDatabase(tempDb)
        val totalBooks = books.size

        // 3. Recursive Download of all resources
        books.forEachIndexed { index, book ->
            if (isStopped) return@withContext Result.failure()

            val progressPercent = ((index + 1) * 100) / totalBooks
            notificationManager.notify(
                NOTIFICATION_ID,
                createNotification("Downloading: ${book.title}", progressPercent, 100)
            )
            setProgress(workDataOf("PROGRESS" to progressPercent, "CURRENT_TITLE" to book.title))

            // Create author and book subdirectories
            val bookDir = resolvePathHierarchy(targetDir, book.path)

            // Download cover.jpg if available
            if (book.hasCover) {
                val coverUrl = book.getCoverUrl(NetworkModule.BASE_URL)
                downloadUrlToSaf(coverUrl, bookDir, "cover.jpg", "image/jpeg")
            }

            // Download each available publication format (EPUB, PDF, MOBI, etc.)
            book.formats.forEach { format ->
                val fileUrl = format.getFileUrl(NetworkModule.BASE_URL, book.path)
                val fileName = "${format.name}.${format.format}".lowercase()
                downloadUrlToSaf(fileUrl, bookDir, fileName, "application/octet-stream")
            }
        }

        notificationManager.notify(
            NOTIFICATION_ID,
            NotificationCompat.Builder(context, CHANNEL_ID)
                .setContentTitle("Download Complete")
                .setContentText("The Calibre Library has been synchronized successfully.")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setOngoing(false)
                .build()
        )

        Result.success()
    }

    private fun resolvePathHierarchy(root: DocumentFile, relativePath: String): DocumentFile {
        val parts = relativePath.split("/").filter { it.isNotBlank() }
        var currentDir = root
        for (part in parts) {
            val existing = currentDir.findFile(part)
            currentDir = if (existing != null && existing.isDirectory) {
                existing
            } else {
                currentDir.createDirectory(part) ?: currentDir
            }
        }
        return currentDir
    }

    private fun downloadUrlToSaf(url: String, parentDir: DocumentFile, fileName: String, mimeType: String) {
        if (parentDir.findFile(fileName) != null) return // Skip existing

        try {
            val request = Request.Builder().url(url).build()
            NetworkModule.okHttpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return
                val body = response.body ?: return

                val docFile = parentDir.createFile(mimeType, fileName) ?: return
                context.contentResolver.openOutputStream(docFile.uri)?.use { output ->
                    body.byteStream().use { input ->
                        input.copyTo(output)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun saveFileToSaf(targetDir: DocumentFile, name: String, mimeType: String, bytes: ByteArray) {
        val existing = targetDir.findFile(name)
        val file = existing ?: targetDir.createFile(mimeType, name)
        file?.let {
            context.contentResolver.openOutputStream(it.uri)?.use { stream ->
                stream.write(bytes)
            }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Isidore Library Sync",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Reports progress for Calibre library background downloads"
        }
        notificationManager.createNotificationChannel(channel)
    }

    private fun createNotification(contentText: String, progress: Int, max: Int): Notification {
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setContentTitle("Isidore Downloader")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(max, progress, false)
            .setOngoing(true)
            .build()
    }
}