package co.isidore.calibre.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import org.jsoup.Jsoup
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

object NetworkModule {
    const val BASE_URL = "https://isidore.co/CalibreLibrary/"

    val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            })
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /**
     * Downloads the remote Calibre SQLite metadata repository database.
     */
    suspend fun downloadMetadataDatabase(
        destinationFile: File,
        onProgress: (bytesRead: Long, totalBytes: Long) -> Unit = { _, _ -> }
    ): Boolean = withContext(Dispatchers.IO) {
        val dbUrl = "${BASE_URL}metadata.db"
        val request = Request.Builder().url(dbUrl).build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext false
            val body = response.body ?: return@withContext false
            val contentLength = body.contentLength()

            body.byteStream().use { input ->
                FileOutputStream(destinationFile).use { output ->
                    val buffer = ByteArray(8192)
                    var bytesCopied: Long = 0
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        output.write(buffer, 0, read)
                        bytesCopied += read
                        onProgress(bytesCopied, contentLength)
                    }
                }
            }
            return@withContext true
        }
    }

    /**
     * Directory fallback parser via Jsoup in case directory listings are read directly.
     */
    suspend fun scrapeDirectoryListing(url: String): List<String> = withContext(Dispatchers.IO) {
        val links = mutableListOf<String>()
        val request = Request.Builder().url(url).build()

        okHttpClient.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                response.body?.string()?.let { html ->
                    val doc = Jsoup.parse(html, url)
                    for (element in doc.select("a[href]")) {
                        val href = element.attr("href")
                        if (href != "../" && !href.startsWith("?")) {
                            links.add(element.absUrl("href"))
                        }
                    }
                }
            }
        }
        links
    }

    /**
     * Open an input stream directly from an endpoint.
     */
    fun openStream(url: String): InputStream? {
        val request = Request.Builder().url(url).build()
        val response = okHttpClient.newCall(request).execute()
        return if (response.isSuccessful) response.body?.byteStream() else null
    }
}