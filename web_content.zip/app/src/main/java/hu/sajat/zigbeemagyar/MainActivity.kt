package hu.sajat.zigbeemagyar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

data class HaEntity(
    val entityId: String,
    val name: String,
    val state: String,
    val domain: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZigbeeApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZigbeeApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("zigbee_magyar", android.content.Context.MODE_PRIVATE)
    }
    var baseUrl by remember { mutableStateOf(prefs.getString("base_url", "http://homeassistant.local:8123") ?: "") }
    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    var entities by remember { mutableStateOf<List<HaEntity>>(emptyList()) }
    var message by remember { mutableStateOf("Add meg a Home Assistant címét és a hozzáférési tokent.") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()
    val api = remember { HomeAssistantApi() }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Zigbee Magyar") },
                    actions = {
                        TextButton(onClick = { showSettings = !showSettings }) {
                            Text(if (showSettings) "Bezárás" else "Beállítások")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (showSettings) {
                    OutlinedTextField(
                        value = baseUrl,
                        onValueChange = { baseUrl = it },
                        label = { Text("Home Assistant címe") },
                        placeholder = { Text("http://192.168.1.50:8123") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it },
                        label = { Text("Hosszú élettartamú hozzáférési token") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            prefs.edit().putString("base_url", baseUrl.trim().trimEnd('/'))
                                .putString("token", token.trim()).apply()
                            message = "Beállítások mentve a telefonon."
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Beállítások mentése") }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        enabled = !busy && baseUrl.isNotBlank() && token.isNotBlank(),
                        onClick = {
                            busy = true
                            scope.launch {
                                try {
                                    entities = api.getEntities(baseUrl.trim().trimEnd('/'), token.trim())
                                    message = "Kapcsolódva. ${entities.size} entitás betöltve."
                                    showSettings = false
                                } catch (e: Exception) {
                                    message = "Kapcsolódási hiba: ${e.message ?: "ismeretlen hiba"}"
                                } finally { busy = false }
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(if (busy) "Kapcsolódás…" else "Kapcsolódás / frissítés") }
                    OutlinedButton(onClick = {
                        entities = entities.sortedBy { it.name.lowercase() }
                    }) { Text("ABC") }
                }

                Text(message, style = MaterialTheme.typography.bodyMedium)

                if (entities.isNotEmpty()) {
                    Text("Eszközök és entitások", style = MaterialTheme.typography.titleLarge)
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(entities, key = { it.entityId }) { entity ->
                            EntityCard(
                                entity = entity,
                                onToggle = { id, turnOn ->
                                    scope.launch {
                                        try {
                                            api.callService(baseUrl.trim().trimEnd('/'), token.trim(), id, turnOn)
                                            message = "${entity.name}: parancs elküldve."
                                            entities = api.getEntities(baseUrl.trim().trimEnd('/'), token.trim())
                                        } catch (e: Exception) {
                                            message = "Nem sikerült a kapcsolás: ${e.message}"
                                        }
                                    }
                                }
                            )
                        }
                    }
                } else {
                    Text(
                        "Első használat: telepítsd a Home Assistantot és a Zigbee2MQTT-t, párosíts eszközöket, majd itt add meg a központ címét és a tokent.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
fun EntityCard(entity: HaEntity, onToggle: (String, Boolean) -> Unit) {
    val switchable = entity.domain in listOf("light", "switch", "fan", "input_boolean")
    val isOn = entity.state in listOf("on", "playing", "open")
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(entity.name, style = MaterialTheme.typography.titleMedium)
                Text("${entity.entityId} • ${entity.state}", style = MaterialTheme.typography.bodySmall)
            }
            if (switchable) {
                Switch(checked = isOn, onCheckedChange = { onToggle(entity.entityId, it) })
            } else {
                Text(entity.domain, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

class HomeAssistantApi {
    private val client = OkHttpClient()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun getEntities(baseUrl: String, token: String): List<HaEntity> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("$baseUrl/api/states")
            .header("Authorization", "Bearer $token")
            .header("Content-Type", "application/json")
            .get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}. Ellenőrizd a címet és a tokent.")
            val array = JSONArray(response.body?.string() ?: "[]")
            val result = mutableListOf<HaEntity>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val id = obj.optString("entity_id")
                val domain = id.substringBefore(".", "")
                val attrs = obj.optJSONObject("attributes") ?: JSONObject()
                val name = attrs.optString("friendly_name", id)
                val state = obj.optString("state", "unknown")
                // Keep common user-facing entities; include sensors and binary sensors.
                if (domain in listOf("light", "switch", "fan", "input_boolean", "sensor", "binary_sensor", "climate", "cover", "lock", "button", "automation")) {
                    result.add(HaEntity(id, name, state, domain))
                }
            }
            result.sortedWith(compareBy<HaEntity> { it.domain }.thenBy { it.name.lowercase() })
        }
    }

    suspend fun callService(baseUrl: String, token: String, entityId: String, turnOn: Boolean) = withContext(Dispatchers.IO) {
        val domain = entityId.substringBefore(".")
        val service = if (turnOn) "turn_on" else "turn_off"
        val body = JSONObject().put("entity_id", entityId).toString().toRequestBody(jsonType)
        val request = Request.Builder()
            .url("$baseUrl/api/services/$domain/$service")
            .header("Authorization", "Bearer $token")
            .post(body).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}")
        }
    }
}
