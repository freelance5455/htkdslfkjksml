package org.worldaudio.studio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Keeps the app alive while system-wide effects are switched on. */
public class GlobalFxService extends Service {
    private static final String CHANNEL = "fx";

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        GlobalFx.init(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Audio effects", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_fg)
                .setContentTitle("World Audio Studio")
                .setContentText("System audio effects are on")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
        GlobalFx.running = true;
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        GlobalFx.running = false;
        GlobalFx.releaseAll();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
