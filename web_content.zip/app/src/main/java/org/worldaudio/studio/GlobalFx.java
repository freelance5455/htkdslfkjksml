package org.worldaudio.studio;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.media.audiofx.Virtualizer;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Attaches EQ, loudness and virtualizer effects to audio sessions announced by other apps. */
final class GlobalFx {
    private static final class Session {
        int id; String pkg;
        Equalizer eq; Virtualizer virt; LoudnessEnhancer loud;
    }

    private static final Map<Integer, Session> sessions = new LinkedHashMap<>();
    private static SharedPreferences prefs;
    private static Context appCtx;
    static volatile boolean running = false;
    static boolean enabled = true;
    static float bass = 0f, presence = 0f, treble = 0f, trim = 0f, width = 100f;

    static synchronized void init(Context c) {
        if (prefs != null) return;
        appCtx = c.getApplicationContext();
        prefs = appCtx.getSharedPreferences("fx", Context.MODE_PRIVATE);
        bass = prefs.getFloat("bass", 0f);
        presence = prefs.getFloat("presence", 0f);
        treble = prefs.getFloat("treble", 0f);
        trim = prefs.getFloat("trim", 0f);
        width = prefs.getFloat("width", 100f);
        enabled = prefs.getBoolean("enabled", true);
    }

    static synchronized void set(String key, float v) {
        if (prefs == null) return;
        switch (key) {
            case "bass": bass = v; break;
            case "presence": presence = v; break;
            case "treble": treble = v; break;
            case "trim": trim = v; break;
            case "width": width = v; break;
            case "enabled": enabled = v > 0.5f; break;
            default: return; // room ambience is in-app only
        }
        SharedPreferences.Editor e = prefs.edit();
        e.putFloat("bass", bass).putFloat("presence", presence).putFloat("treble", treble)
         .putFloat("trim", trim).putFloat("width", width).putBoolean("enabled", enabled).apply();
        for (Session s : sessions.values()) apply(s);
    }

    static synchronized void open(int id, String pkg) {
        if (id <= 0 || prefs == null) return; // 0 is the global mix, which Android blocks
        close(id);
        Session s = new Session();
        s.id = id; s.pkg = pkg == null ? "unknown app" : pkg;
        try { s.eq = new Equalizer(0, id); } catch (Throwable t) { s.eq = null; }
        try { s.virt = new Virtualizer(0, id); } catch (Throwable t) { s.virt = null; }
        try { s.loud = new LoudnessEnhancer(id); } catch (Throwable t) { s.loud = null; }
        if (s.eq == null && s.virt == null && s.loud == null) return;
        sessions.put(id, s);
        apply(s);
    }

    static synchronized void close(int id) {
        Session s = sessions.remove(id);
        if (s != null) release(s);
    }

    static synchronized void releaseAll() {
        for (Session s : new ArrayList<>(sessions.values())) release(s);
        sessions.clear();
    }

    private static void release(Session s) {
        try { if (s.eq != null) s.eq.release(); } catch (Throwable t) { }
        try { if (s.virt != null) s.virt.release(); } catch (Throwable t) { }
        try { if (s.loud != null) s.loud.release(); } catch (Throwable t) { }
    }

    private static void apply(Session s) {
        boolean on = enabled;
        try {
            if (s.eq != null) {
                short bands = s.eq.getNumberOfBands();
                short[] range = s.eq.getBandLevelRange();
                for (short i = 0; i < bands; i++) {
                    int hz = s.eq.getCenterFreq(i) / 1000;
                    float db = hz < 250 ? bass : (hz < 4000 ? presence : treble);
                    int mb = Math.round(db * 100f);
                    mb = Math.max(range[0], Math.min(range[1], mb));
                    s.eq.setBandLevel(i, (short) mb);
                }
                s.eq.setEnabled(on);
            }
        } catch (Throwable t) { }
        try {
            if (s.virt != null && s.virt.getStrengthSupported()) {
                int strength = Math.round(Math.max(0f, width - 100f) / 50f * 1000f);
                s.virt.setStrength((short) Math.max(0, Math.min(1000, strength)));
                s.virt.setEnabled(on && strength > 0);
            }
        } catch (Throwable t) { }
        try {
            if (s.loud != null) {
                s.loud.setTargetGain(Math.round(trim * 100f));
                s.loud.setEnabled(on && trim != 0f);
            }
        } catch (Throwable t) { }
    }

    private static String label(String pkg) {
        try {
            PackageManager pm = appCtx.getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Throwable t) { return pkg; }
    }

    static synchronized String stateJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("running", running);
            o.put("enabled", enabled);
            JSONArray a = new JSONArray();
            List<Session> list = new ArrayList<>(sessions.values());
            for (Session s : list) {
                JSONObject j = new JSONObject();
                j.put("session", s.id);
                j.put("pkg", s.pkg);
                j.put("label", label(s.pkg));
                a.put(j);
            }
            o.put("sessions", a);
            return o.toString();
        } catch (Throwable t) {
            return "{\"running\":false,\"enabled\":true,\"sessions\":[]}";
        }
    }
}
