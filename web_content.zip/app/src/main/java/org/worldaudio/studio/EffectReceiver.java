package org.worldaudio.studio;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.audiofx.AudioEffect;

/** Receives "audio session opened/closed" announcements from music and video apps. */
public class EffectReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        GlobalFx.init(context);
        if (!GlobalFx.running || intent == null) return;
        int session = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1);
        String pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME);
        String action = intent.getAction();
        if (AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION.equals(action)) {
            GlobalFx.open(session, pkg);
        } else if (AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION.equals(action)) {
            GlobalFx.close(session);
        }
    }
}
