package de.familienzeit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Filter
import com.google.firebase.firestore.Query
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.security.SecureRandom

private val Night = Color(0xFF10151D)
private val Panel = Color(0xFF1A222D)
private val Mint = Color(0xFF71D6B3)
private val Soft = Color(0xFFAAB5C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { FamilienzeitRoot() }
    }
}

private enum class Page(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Home("Übersicht", Icons.Default.Home), Chats("Chats", Icons.Default.Chat), Calendar("Kalender", Icons.Default.CalendarMonth), Tasks("Aufgaben", Icons.Default.CheckCircle), Gallery("Galerie", Icons.Default.PhotoLibrary), Profile("Profil", Icons.Default.Person)
}

@Composable
private fun FamilienzeitRoot() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var signedIn by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var userName by remember { mutableStateOf("") }
    var familyId by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val current = auth.currentUser
        if (current != null) try {
            val profile = db.collection("users").document(current.uid).get().await()
            familyId = profile.getString("familyId").orEmpty()
            userName = profile.getString("displayName") ?: current.displayName.orEmpty()
            signedIn = familyId.isNotBlank()
            if (!signedIn) auth.signOut()
        } catch (_: Exception) { auth.signOut() }
        loading = false
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Night, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            when {
                loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Mint) }
                signedIn -> MainShell(userName, familyId) { auth.signOut(); signedIn = false }
                else -> AuthScreen { name, fid -> userName = name; familyId = fid; signedIn = true }
            }
        }
    }
}

@Composable
private fun AuthScreen(onSuccess: (String, String) -> Unit) {
    var mode by remember { mutableStateOf("login") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var memberName by remember { mutableStateOf("") }
    var familyName by remember { mutableStateOf("") }
    var familyCode by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val db = remember { FirebaseFirestore.getInstance() }
    val auth = remember { FirebaseAuth.getInstance() }
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(76.dp).background(Mint.copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.FamilyRestroom, null, tint = Mint, modifier = Modifier.size(42.dp)) }
        Spacer(Modifier.height(16.dp)); Text("Familienzeit", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Gemeinsam organisiert. Ganz einfach.", color = Soft)
        Spacer(Modifier.height(22.dp))
        when (mode) {
            "login" -> {
                Field(email, { email = it }, "E-Mail", KeyboardType.Email)
                Spacer(Modifier.height(8.dp)); PasswordField(password, { password = it })
                Button(onClick = { scope.launch { busy = true; error = ""; try { auth.signInWithEmailAndPassword(email.trim(), password).await(); val u = auth.currentUser ?: throw IllegalStateException("Anmeldung fehlgeschlagen"); val p = db.collection("users").document(u.uid).get().await(); val fid = p.getString("familyId") ?: throw IllegalStateException("Für dieses Konto ist noch keine Familie eingerichtet."); onSuccess(p.getString("displayName") ?: "Familienmitglied", fid) } catch (e: Exception) { error = e.message ?: "Anmeldung fehlgeschlagen." }; busy = false } }, enabled = !busy && email.isNotBlank() && password.isNotBlank(), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) { Text(if (busy) "Anmeldung …" else "Anmelden") }
                TextButton(onClick = { mode = "create"; error = "" }) { Text("Neue Familie einrichten", color = Mint) }
                TextButton(onClick = { mode = "join"; error = "" }) { Text("Mit Familiencode beitreten", color = Mint) }
            }
            "create" -> {
                Field(familyName, { familyName = it }, "Name eurer Familie")
                Field(memberName, { memberName = it }, "Dein Name")
                Field(email, { email = it }, "Deine E-Mail", KeyboardType.Email)
                PasswordField(password, { password = it })
                Text("Jedes Mitglied braucht ein eigenes E-Mail-Konto.", color = Soft, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Button(onClick = { scope.launch { busy = true; error = ""; try {
                    val credential = auth.createUserWithEmailAndPassword(email.trim(), password).await(); val uid = credential.user?.uid ?: throw IllegalStateException("Konto konnte nicht angelegt werden.")
                    val code = newFamilyCode(); val fam = db.collection("families").document(code)
                    fam.set(mapOf("name" to familyName.trim(), "ownerUid" to uid, "createdAt" to FieldValue.serverTimestamp())).await()
                    fam.collection("members").document(uid).set(mapOf("displayName" to memberName.trim(), "role" to "admin", "createdAt" to FieldValue.serverTimestamp())).await()
                    db.collection("users").document(uid).set(mapOf("familyId" to code, "displayName" to memberName.trim())).await()
                    onSuccess(memberName.trim(), code)
                } catch (e: Exception) { error = e.message ?: "Familie konnte nicht eingerichtet werden." }; busy = false } }, enabled = !busy && familyName.isNotBlank() && memberName.isNotBlank() && email.contains("@") && password.length >= 6, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) { Text(if (busy) "Wird eingerichtet …" else "Familie erstellen") }
                Text("Das Passwort muss mindestens 6 Zeichen haben.", color = Soft, fontSize = 12.sp)
                TextButton(onClick = { mode = "login" }) { Text("Zur Anmeldung", color = Mint) }
            }
            else -> {
                Field(familyCode, { familyCode = it.uppercase() }, "Familiencode")
                Field(memberName, { memberName = it }, "Dein Name")
                Field(email, { email = it }, "Deine E-Mail", KeyboardType.Email)
                PasswordField(password, { password = it })
                Button(onClick = { scope.launch { busy = true; error = ""; try {
                    val credential = auth.createUserWithEmailAndPassword(email.trim(), password).await(); val uid = credential.user?.uid ?: throw IllegalStateException("Konto konnte nicht angelegt werden.")
                    val fam = db.collection("families").document(familyCode.trim().uppercase()); val family = fam.get().await(); if (!family.exists()) throw IllegalStateException("Familiencode nicht gefunden.")
                    fam.collection("members").document(uid).set(mapOf("displayName" to memberName.trim(), "role" to "member", "createdAt" to FieldValue.serverTimestamp())).await()
                    db.collection("users").document(uid).set(mapOf("familyId" to familyCode.trim().uppercase(), "displayName" to memberName.trim())).await()
                    onSuccess(memberName.trim(), familyCode.trim().uppercase())
                } catch (e: Exception) { error = e.message ?: "Beitritt fehlgeschlagen." }; busy = false } }, enabled = !busy && familyCode.length >= 12 && memberName.isNotBlank() && email.contains("@") && password.length >= 6, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) { Text(if (busy) "Wird verbunden …" else "Familie beitreten") }
                TextButton(onClick = { mode = "login" }) { Text("Zur Anmeldung", color = Mint) }
            }
        }
        if (error.isNotBlank()) Text(error, color = if (error.startsWith("Euer Familiencode")) Mint else Color(0xFFFF8B8B), modifier = Modifier.padding(top = 8.dp))
    }
}

private fun newFamilyCode(): String {
    val bytes = ByteArray(8); SecureRandom().nextBytes(bytes)
    return bytes.joinToString("") { "%02X".format(it) }
}

@Composable private fun Field(value: String, update: (String) -> Unit, label: String, type: KeyboardType = KeyboardType.Text) {
    OutlinedTextField(value, update, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = type), colors = inputColors())
}
@Composable private fun PasswordField(value: String, update: (String) -> Unit) {
    OutlinedTextField(value, update, label = { Text("Passwort") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), colors = inputColors())
}

@Composable
private fun MainShell(name: String, familyId: String, onLogout: () -> Unit) {
    var page by remember { mutableStateOf(Page.Home) }
    Scaffold(containerColor = Night, bottomBar = { NavigationBar(containerColor = Panel) { listOf(Page.Home, Page.Chats, Page.Calendar, Page.Tasks, Page.Gallery).forEach { p -> NavigationBarItem(selected = page == p, onClick = { page = p }, icon = { Icon(p.icon, p.title) }, label = { Text(p.title) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Mint, selectedTextColor = Mint, indicatorColor = Mint.copy(alpha = .12f), unselectedIconColor = Soft, unselectedTextColor = Soft)) } } }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("FAMILIENZEIT", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp); Text(if (page == Page.Home) "Hallo, $name" else page.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
                IconButton(onClick = { page = Page.Profile }) { Icon(Icons.Default.AccountCircle, "Profil", tint = Mint, modifier = Modifier.size(32.dp)) }
            }
            when (page) {
                Page.Home -> HomePage(name, { page = it })
                Page.Chats -> ChatsPage(familyId, name)
                Page.Calendar -> DataListPage(familyId, "events", "Termine", "Termin", name)
                Page.Tasks -> DataListPage(familyId, "tasks", "Aufgaben", "Aufgabe", name)
                Page.Gallery -> GalleryPage(familyId, name)
                Page.Profile -> ProfilePage(name, familyId, onLogout)
            }
        }
    }
}

@Composable
private fun HomePage(name: String, go: (Page) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(20.dp)) { Text("Schön, dass du da bist", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("Alles Wichtige für eure Familie an einem Ort.", color = Soft); Spacer(Modifier.height(14.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = { go(Page.Calendar) }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) { Text("Termin planen") }; OutlinedButton(onClick = { go(Page.Tasks) }) { Text("Aufgabe ansehen") } } } } }
        items(listOf(Page.Chats, Page.Calendar, Page.Tasks, Page.Gallery)) { p -> Card(Modifier.fillMaxWidth().clickable { go(p) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(p.icon, null, tint = Mint); Spacer(Modifier.width(14.dp)); Column { Text(p.title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(when (p) { Page.Chats -> "Familienchat und Einzelchats"; Page.Calendar -> "Gemeinsame und private Termine"; Page.Tasks -> "Familienaufgaben organisieren"; else -> "Foto-Links miteinander teilen" }, color = Soft, fontSize = 13.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Soft) } } }
    }
}

@Composable
private fun ChatsPage(familyId: String, name: String) {
    var selected by remember { mutableStateOf("family") }; var members by remember { mutableStateOf(listOf<Pair<String, String>>()) }; var messageText by remember { mutableStateOf("") }; var messages by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    val db = remember { FirebaseFirestore.getInstance() }; val uid = FirebaseAuth.getInstance().currentUser?.uid.orEmpty(); val scope = rememberCoroutineScope()
    LaunchedEffect(familyId) { db.collection("families").document(familyId).collection("members").addSnapshotListener { s, _ -> members = s?.documents?.map { it.id to (it.getString("displayName") ?: "Mitglied") } ?: emptyList() } }
    LaunchedEffect(familyId, selected) { val chatId = if (selected == "family") "family" else listOf(uid, selected).sorted().joinToString("_"); db.collection("families").document(familyId).collection("chats").document(chatId).collection("messages").orderBy("createdAt", Query.Direction.ASCENDING).limitToLast(100).addSnapshotListener { s, _ -> messages = s?.documents?.map { it.data ?: emptyMap() } ?: emptyList() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected == "family", { selected = "family" }, label = { Text("Familie") }); members.filter { it.first != uid }.forEach { (id, member) -> FilterChip(selected == id, { selected = id }, label = { Text(member) }) } }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 12.dp)) { items(messages) { m -> Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) { Text(m["senderName"]?.toString() ?: "Mitglied", color = Mint, fontSize = 12.sp); Text(m["text"]?.toString() ?: "", color = Color.White) } } }
        Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(messageText, { messageText = it }, modifier = Modifier.weight(1f), placeholder = { Text("Nachricht schreiben …") }, colors = inputColors()); IconButton(onClick = { if (messageText.isNotBlank()) scope.launch { val chatId = if (selected == "family") "family" else listOf(uid, selected).sorted().joinToString("_"); db.collection("families").document(familyId).collection("chats").document(chatId).collection("messages").add(mapOf("text" to messageText.trim(), "senderId" to uid, "senderName" to name, "createdAt" to FieldValue.serverTimestamp())).await(); messageText = "" } }) { Icon(Icons.Default.Send, "Senden", tint = Mint) } }
    }
}

@Composable
private fun DataListPage(familyId: String, collection: String, title: String, label: String, name: String) {
    var rows by remember { mutableStateOf(listOf<Map<String, Any>>()) }; var showAdd by remember { mutableStateOf(false) }; var text by remember { mutableStateOf("") }; var shared by remember { mutableStateOf(true) }; var date by remember { mutableStateOf("") }
    val db = remember { FirebaseFirestore.getInstance() }; val uid = FirebaseAuth.getInstance().currentUser?.uid; val scope = rememberCoroutineScope()
    LaunchedEffect(familyId) { db.collection("families").document(familyId).collection(collection).where(Filter.or(Filter.equalTo("shared", true), Filter.equalTo("createdBy", uid))).orderBy("createdAt", Query.Direction.DESCENDING).addSnapshotListener { s, _ -> rows = s?.documents?.map { it.data ?: emptyMap() } ?: emptyList() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); FilledTonalButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("Hinzufügen") } }
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 14.dp)) { if (rows.isEmpty()) item { EmptyCard("Noch keine Einträge", "Tippe auf Hinzufügen, um den ersten Eintrag anzulegen.") }; items(rows) { row -> Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if (collection == "tasks") Icons.Default.CheckCircle else Icons.Default.Event, null, tint = Mint); Spacer(Modifier.width(12.dp)); Column { Text(row["title"]?.toString() ?: "", color = Color.White, fontWeight = FontWeight.SemiBold); if (row["date"]?.toString()?.isNotBlank() == true) Text(row["date"].toString(), color = Mint, fontSize = 12.sp); Text((if (row["shared"] == true) "Für die Familie" else "Privat") + " · " + (row["createdByName"] ?: name), color = Soft, fontSize = 12.sp) } } } } }
    }
    if (showAdd) AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("$label eintragen") }, text = { Column { Field(text, { text = it }, "Titel"); if (collection == "events") { Spacer(Modifier.height(8.dp)); Field(date, { date = it }, "Datum (JJJJ-MM-TT)") }; Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(shared, { shared = it }); Text("Für alle sichtbar", color = Color.White) } } }, confirmButton = { TextButton(onClick = { if (text.isNotBlank()) scope.launch { db.collection("families").document(familyId).collection(collection).add(mapOf("title" to text.trim(), "date" to date.trim(), "shared" to shared, "createdBy" to uid, "createdByName" to name, "createdAt" to FieldValue.serverTimestamp())).await(); text = ""; date = ""; showAdd = false } }) { Text("Speichern") } }, dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Abbrechen") } })
}

@Composable
private fun GalleryPage(familyId: String, name: String) {
    var photos by remember { mutableStateOf(listOf<Map<String, Any>>()) }; var showAdd by remember { mutableStateOf(false) }; var title by remember { mutableStateOf("") }; var link by remember { mutableStateOf("") }
    val db = remember { FirebaseFirestore.getInstance() }; val scope = rememberCoroutineScope(); val uid = FirebaseAuth.getInstance().currentUser?.uid
    LaunchedEffect(familyId) { db.collection("families").document(familyId).collection("photos").whereEqualTo("shared", true).orderBy("createdAt", Query.Direction.DESCENDING).addSnapshotListener { s, _ -> photos = s?.documents?.map { it.data ?: emptyMap() } ?: emptyList() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Familiengalerie", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text("Teilt Links zu euren Bildern", color = Soft) }; FilledTonalButton(onClick = { showAdd = true }) { Icon(Icons.Default.AddLink, null); Text("Link") } }; LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) { if (photos.isEmpty()) item { EmptyCard("Noch keine Bilder-Links", "Fügt einen Link zu einem Bild hinzu.") }; items(photos) { p -> Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text(p["title"]?.toString() ?: "Familienfoto", color = Color.White, fontWeight = FontWeight.SemiBold); Text(p["url"]?.toString() ?: "", color = Mint); Text("Von ${p["createdByName"] ?: name}", color = Soft, fontSize = 12.sp) } } } } }
    if (showAdd) AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Bild-Link teilen") }, text = { Column { Field(title, { title = it }, "Titel"); Field(link, { link = it }, "Bild-Link") } }, confirmButton = { TextButton(onClick = { if (title.isNotBlank() && link.startsWith("https://")) scope.launch { db.collection("families").document(familyId).collection("photos").add(mapOf("title" to title.trim(), "url" to link.trim(), "shared" to true, "createdBy" to uid, "createdByName" to name, "createdAt" to FieldValue.serverTimestamp())).await(); title = ""; link = ""; showAdd = false } }) { Text("Teilen") } }, dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Abbrechen") } })
}

@Composable
private fun ProfilePage(name: String, familyId: String, onLogout: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(96.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Mint, modifier = Modifier.size(54.dp)) }; Spacer(Modifier.height(14.dp)); Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Familienmitglied", color = Soft); Spacer(Modifier.height(20.dp)); Text("Familiencode", color = Soft); Text(familyId, color = Mint, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("Teile diesen Code mit deiner Familie. Jedes Mitglied legt ein eigenes Konto an.", color = Soft, modifier = Modifier.padding(vertical = 14.dp)); OutlinedButton(onClick = onLogout) { Icon(Icons.Default.Logout, null); Spacer(Modifier.width(8.dp)); Text("Abmelden") } }
}

@Composable private fun EmptyCard(title: String, body: String) { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(body, color = Soft) } } }
@Composable private fun inputColors() = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Mint, unfocusedBorderColor = Soft.copy(alpha = .35f), focusedLabelColor = Mint, unfocusedLabelColor = Soft, cursorColor = Mint, focusedContainerColor = Panel, unfocusedContainerColor = Panel)
