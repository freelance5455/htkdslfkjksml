package de.familienzeit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import coil.compose.AsyncImage
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Filter
import com.google.firebase.firestore.Query
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Night = Color(0xFF10151D)
private val Panel = Color(0xFF1A222D)
private val Mint = Color(0xFF71D6B3)
private val Soft = Color(0xFFAAB5C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(PlayIntegrityAppCheckProviderFactory.getInstance())
        setContent { FamilienzeitRoot() }
    }
}

private enum class Page(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Home("Übersicht", Icons.Default.Home), Chats("Chats", Icons.Default.Chat), Calendar("Kalender", Icons.Default.CalendarMonth), Tasks("Aufgaben", Icons.Default.CheckCircle), Gallery("Galerie", Icons.Default.PhotoLibrary), Profile("Profil", Icons.Default.Person)
}

@Composable
private fun FamilienzeitRoot() {
    val auth = remember { FirebaseAuth.getInstance() }
    var signedIn by remember { mutableStateOf(false) }
    var userName by remember { mutableStateOf("") }
    var familyId by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val current = auth.currentUser
        if (current != null) {
            try { val claims = current.getIdToken(true).await().claims; familyId = claims["familyId"] as? String ?: ""; userName = claims["displayName"] as? String ?: current.displayName.orEmpty(); signedIn = familyId.isNotBlank() }
            catch (_: Exception) { auth.signOut() }
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Mint, background = Night, surface = Panel)) {
        Surface(Modifier.fillMaxSize(), color = Night) {
            if (signedIn) MainShell(userName, familyId) { auth.signOut(); signedIn = false }
            else AuthScreen(
                onSuccess = { name, fid -> userName = name; familyId = fid; signedIn = true }
            )
        }
    }
}

@Composable
private fun AuthScreen(onSuccess: (String, String) -> Unit) {
    var createMode by remember { mutableStateOf(false) }
    var familyCode by remember { mutableStateOf("") }
    var familyName by remember { mutableStateOf("") }
    var memberName by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var newCode by remember { mutableStateOf("") }
    var pendingToken by remember { mutableStateOf("") }
    var pendingFamilyId by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(76.dp).background(Mint.copy(alpha = .14f), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.FamilyRestroom, null, tint = Mint, modifier = Modifier.size(42.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text("Familienzeit", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(if (createMode) "Richtet euren Familienbereich ein" else "Gemeinsam organisiert. Ganz einfach.", color = Soft)
        Spacer(Modifier.height(26.dp))
        if (createMode) {
            Field(familyName, { familyName = it }, "Name eurer Familie")
            Spacer(Modifier.height(10.dp))
            Field(memberName, { memberName = it }, "Dein Name")
            Text("Du erhältst einen einmalig angezeigten PIN und Familiencode.", color = Soft, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
            Button(onClick = {
                scope.launch {
                    busy = true; error = ""
                    try {
                        val result = FirebaseFunctions.getInstance().getHttpsCallable("createFamily").call(mapOf("familyName" to familyName, "adminName" to memberName)).await().data as Map<*, *>
                        val token = result["token"] as String
                        FirebaseAuth.getInstance().signInWithCustomToken(token).await()
                        newPin = result["pin"] as String; newCode = result["familyCode"] as String
                        pendingToken = token; pendingFamilyId = result["familyId"] as String
                    } catch (e: Exception) { error = e.message ?: "Familie konnte nicht angelegt werden." }
                    busy = false
                }
            }, enabled = !busy && familyName.isNotBlank() && memberName.isNotBlank(), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) { Text(if (busy) "Wird eingerichtet …" else "Familie erstellen") }
        } else {
            Field(familyCode, { familyCode = it }, "Familiencode")
            Spacer(Modifier.height(10.dp))
            Field(memberName, { memberName = it }, "Dein Name")
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(pin, { pin = it.take(8) }, label = { Text("PIN") }, modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), visualTransformation = PasswordVisualTransformation(), colors = inputColors())
            Spacer(Modifier.height(14.dp))
            Button(onClick = {
                scope.launch {
                    busy = true; error = ""
                    try {
                        val result = FirebaseFunctions.getInstance().getHttpsCallable("loginWithPin").call(mapOf("familyCode" to familyCode.trim().uppercase(), "name" to memberName.trim(), "pin" to pin)).await().data as Map<*, *>
                        FirebaseAuth.getInstance().signInWithCustomToken(result["token"] as String).await()
                        onSuccess(memberName.trim(), result["familyId"] as String)
                    } catch (e: Exception) { error = "Anmeldung fehlgeschlagen. Bitte Angaben prüfen." }
                    busy = false
                }
            }, enabled = !busy && familyCode.isNotBlank() && memberName.isNotBlank() && pin.length == 8, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) { Text(if (busy) "Anmeldung …" else "Sicher anmelden") }
        }
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF8B8B), modifier = Modifier.padding(top = 10.dp))
        TextButton(onClick = { createMode = !createMode; error = "" }) { Text(if (createMode) "Ich habe schon einen Familiencode" else "Neue Familie einrichten", color = Mint) }
    }
    if (newPin.isNotBlank()) AlertDialog(onDismissRequest = {}, title = { Text("Zugangsdaten sichern") }, text = { Text("Familiencode: $newCode\nDein PIN: $newPin\n\nSchreibe beides auf. Der PIN wird nur jetzt angezeigt.") }, confirmButton = { TextButton(onClick = { scope.launch { FirebaseAuth.getInstance().signInWithCustomToken(pendingToken).await(); onSuccess(memberName, pendingFamilyId); newPin = "" } }) { Text("Gesichert") } })
}

@Composable
private fun MainShell(name: String, familyId: String, onLogout: () -> Unit) {
    var page by remember { mutableStateOf(Page.Home) }
    Scaffold(containerColor = Night, bottomBar = {
        NavigationBar(containerColor = Panel) {
            listOf(Page.Home, Page.Chats, Page.Calendar, Page.Tasks, Page.Gallery).forEach { p ->
                NavigationBarItem(selected = page == p, onClick = { page = p }, icon = { Icon(p.icon, p.title) }, label = { Text(p.title) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Mint, selectedTextColor = Mint, indicatorColor = Mint.copy(alpha = .12f), unselectedIconColor = Soft, unselectedTextColor = Soft))
            }
        }
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("FAMILIENZEIT", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp); Text(when(page) { Page.Home -> "Hallo, $name"; else -> page.title }, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
                IconButton(onClick = { page = Page.Profile }) { Icon(Icons.Default.AccountCircle, "Profil", tint = Mint, modifier = Modifier.size(32.dp)) }
            }
            when(page) {
                Page.Home -> HomePage(name, familyId, { page = it })
                Page.Chats -> ChatsPage(familyId, name)
                Page.Calendar -> DataListPage(familyId, "events", "Termine", "Termin", name)
                Page.Tasks -> DataListPage(familyId, "tasks", "Aufgaben", "Aufgabe", name)
                Page.Gallery -> GalleryPage(familyId, name)
                Page.Profile -> ProfilePage(name, familyId, onLogout)
            }
        }
    }
}

@Composable
private fun HomePage(name: String, familyId: String, go: (Page) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(20.dp)) { Text("Schön, dass du da bist", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold); Text("Alles Wichtige für eure Familie an einem Ort.", color = Soft); Spacer(Modifier.height(14.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = { go(Page.Calendar) }, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) { Text("Termin planen") }; OutlinedButton(onClick = { go(Page.Tasks) }) { Text("Aufgabe ansehen") } } } } }
        item { Text("Eure Bereiche", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
        items(listOf(Page.Chats, Page.Calendar, Page.Tasks, Page.Gallery)) { p -> Card(Modifier.fillMaxWidth().clickable { go(p) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(p.icon, null, tint = Mint); Spacer(Modifier.width(14.dp)); Column { Text(p.title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(when(p) { Page.Chats -> "Familienchat und persönliche Chats"; Page.Calendar -> "Gemeinsame und private Termine"; Page.Tasks -> "Aufgaben gemeinsam organisieren"; else -> "Urlaubsbilder für alle" }, color = Soft, fontSize = 13.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Soft) } } }
        item { Text("Deine Daten werden in eurem privaten Familienbereich gespeichert.", color = Soft, fontSize = 12.sp, modifier = Modifier.padding(8.dp)) }
    }
}

@Composable
private fun ChatsPage(familyId: String, name: String) {
    var selected by remember { mutableStateOf("family") }
    var members by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var messageText by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    val db = remember { FirebaseFirestore.getInstance() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(familyId) {
        db.collection("families").document(familyId).collection("members").addSnapshotListener { s, _ -> members = s?.documents?.map { it.id to (it.getString("displayName") ?: "Mitglied") } ?: emptyList() }
    }
    LaunchedEffect(familyId, selected) {
        val ownUid = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
        val chatId = if(selected == "family") "family" else listOf(ownUid, selected).sorted().joinToString("_")
        db.collection("families").document(familyId).collection("chats").document(chatId).collection("messages").orderBy("createdAt", Query.Direction.ASCENDING).limitToLast(100).addSnapshotListener { s, _ -> messages = s?.documents?.map { it.data ?: emptyMap() } ?: emptyList() }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(selected == "family", { selected = "family" }, label = { Text("Familie") }); members.filter { it.first != FirebaseAuth.getInstance().currentUser?.uid }.forEach { (id, n) -> FilterChip(selected == id, { selected = id }, label = { Text(n) }) } }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 12.dp)) { items(messages) { m -> Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(12.dp)) { Text(m["senderName"]?.toString() ?: "Mitglied", color = Mint, fontSize = 12.sp); Text(m["text"]?.toString() ?: "", color = Color.White) } } }
        Row(verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(messageText, { messageText = it }, modifier = Modifier.weight(1f), placeholder = { Text("Nachricht schreiben …") }, colors = inputColors()); IconButton(onClick = { if(messageText.isNotBlank()) scope.launch { val ownUid = FirebaseAuth.getInstance().currentUser?.uid.orEmpty(); val id = if(selected == "family") "family" else listOf(ownUid, selected).sorted().joinToString("_"); db.collection("families").document(familyId).collection("chats").document(id).collection("messages").add(mapOf("text" to messageText.trim(), "senderId" to FirebaseAuth.getInstance().currentUser?.uid, "senderName" to name, "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())).await(); messageText = "" } }) { Icon(Icons.Default.Send, "Senden", tint = Mint) } }
    }
}

@Composable
private fun DataListPage(familyId: String, collection: String, title: String, itemLabel: String, name: String) {
    var rows by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    var showAdd by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var shared by remember { mutableStateOf(true) }
    var eventDate by remember { mutableStateOf("") }
    val db = remember { FirebaseFirestore.getInstance() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(familyId) { db.collection("families").document(familyId).collection(collection).where(Filter.or(Filter.equalTo("shared", true), Filter.equalTo("createdBy", FirebaseAuth.getInstance().currentUser?.uid))).orderBy("createdAt", Query.Direction.DESCENDING).addSnapshotListener { s, _ -> rows = s?.documents?.map { it.data ?: emptyMap() } ?: emptyList() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); FilledTonalButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, null); Text("Hinzufügen") } }
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
            if(rows.isEmpty()) item { EmptyCard("Noch keine Einträge", "Tippe auf Hinzufügen, um den ersten Eintrag anzulegen.") }
            items(rows) { row -> Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(if(collection == "tasks") Icons.Default.CheckCircle else Icons.Default.Event, null, tint = Mint); Spacer(Modifier.width(12.dp)); Column { Text(row["title"]?.toString() ?: "", color = Color.White, fontWeight = FontWeight.SemiBold); if(row["date"] != null) Text(row["date"].toString(), color = Mint, fontSize = 12.sp); Text((if(row["shared"] == true) "Für die Familie" else "Privat") + " · " + (row["createdByName"] ?: name), color = Soft, fontSize = 12.sp) } } } }
        }
    }
    if(showAdd) AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("$itemLabel eintragen") }, text = { Column { Field(text, { text = it }, "Titel"); if(collection == "events") { Spacer(Modifier.height(8.dp)); Field(eventDate, { eventDate = it }, "Datum (JJJJ-MM-TT)") }; Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(shared, { shared = it }); Text("Für alle sichtbar", color = Color.White) } } }, confirmButton = { TextButton(onClick = { if(text.isNotBlank()) scope.launch { db.collection("families").document(familyId).collection(collection).add(mapOf("title" to text.trim(), "date" to eventDate.trim(), "shared" to shared, "createdBy" to FirebaseAuth.getInstance().currentUser?.uid, "createdByName" to name, "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())).await(); text = ""; eventDate = ""; showAdd = false } }) { Text("Speichern") } }, dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Abbrechen") } })
}

@Composable
private fun GalleryPage(familyId: String, name: String) {
    var photos by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    var caption by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val db = remember { FirebaseFirestore.getInstance() }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            try {
                val uid = FirebaseAuth.getInstance().currentUser?.uid ?: error("Nicht angemeldet")
                val path = "families/$familyId/gallery/$uid/${UUID.randomUUID()}.jpg"
                val ref = FirebaseStorage.getInstance().reference.child(path)
                ref.putFile(uri).await()
                val url = ref.downloadUrl.await().toString()
                db.collection("families").document(familyId).collection("photos").add(mapOf("imageUrl" to url, "storagePath" to path, "shared" to true, "caption" to caption.trim(), "createdBy" to uid, "createdByName" to name, "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp())).await()
                caption = ""; message = "Bild wurde zur Familiengalerie hinzugefügt."
            } catch (e: Exception) { message = e.message ?: "Bild konnte nicht hochgeladen werden." }
            busy = false
        }
    }
    LaunchedEffect(familyId) { db.collection("families").document(familyId).collection("photos").whereEqualTo("shared", true).orderBy("createdAt", Query.Direction.DESCENDING).addSnapshotListener { s, _ -> photos = s?.documents?.map { it.data ?: emptyMap() } ?: emptyList() } }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Familiengalerie", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold); Text("Bilder, die ihr miteinander teilt", color = Soft, fontSize = 13.sp) }; FilledTonalButton(enabled = !busy, onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Icon(Icons.Default.AddPhotoAlternate, null); Text(if(busy) "Lädt …" else "Foto") } }
        if(message.isNotBlank()) Text(message, color = Mint, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        OutlinedTextField(caption, { caption = it }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), label = { Text("Bildunterschrift (optional)") }, colors = inputColors())
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 14.dp)) {
            if(photos.isEmpty()) item { EmptyCard("Eure Galerie ist bereit", "Tippe auf Foto und wähle ein Bild aus.") }
            items(photos) { photo -> Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column { AsyncImage(model = photo["imageUrl"], contentDescription = photo["caption"]?.toString() ?: "Familienfoto", modifier = Modifier.fillMaxWidth().height(220.dp)); Column(Modifier.padding(14.dp)) { Text(photo["caption"]?.toString()?.ifBlank { "Familienfoto" } ?: "Familienfoto", color = Color.White, fontWeight = FontWeight.SemiBold); Text("Von ${photo["createdByName"] ?: "Familie"}", color = Soft, fontSize = 12.sp) } } } }
        }
    }
}

@Composable
private fun ProfilePage(name: String, familyId: String, onLogout: () -> Unit) {
    var inviteName by remember { mutableStateOf("") }
    var invitePin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var familyCode by remember { mutableStateOf("") }
    var profilePhotoUrl by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val profilePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if(uri != null) scope.launch {
            try { val uid = FirebaseAuth.getInstance().currentUser?.uid ?: error("Nicht angemeldet"); val path = "families/$familyId/profiles/$uid/${UUID.randomUUID()}.jpg"; val ref = FirebaseStorage.getInstance().reference.child(path); ref.putFile(uri).await(); FirebaseFunctions.getInstance().getHttpsCallable("setProfilePhoto").call(mapOf("storagePath" to path)).await(); profilePhotoUrl = ref.downloadUrl.await().toString(); message = "Profilbild gespeichert." }
            catch(e: Exception) { message = e.message ?: "Profilbild konnte nicht gespeichert werden." }
        }
    }
    LaunchedEffect(familyId) { FirebaseFirestore.getInstance().collection("families").document(familyId).addSnapshotListener { snap, _ -> familyCode = snap?.getString("inviteCode") ?: "" }; val uid = FirebaseAuth.getInstance().currentUser?.uid; if(uid != null) FirebaseFirestore.getInstance().collection("families").document(familyId).collection("members").document(uid).addSnapshotListener { snap, _ -> val path = snap?.getString("profilePhotoPath"); if(path != null) FirebaseStorage.getInstance().reference.child(path).downloadUrl.addOnSuccessListener { profilePhotoUrl = it.toString() } } } }
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(100.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { if(profilePhotoUrl != null) AsyncImage(profilePhotoUrl, contentDescription = "Profilbild", modifier = Modifier.size(100.dp)); else Icon(Icons.Default.Person, null, tint = Mint, modifier = Modifier.size(56.dp)) }
        Spacer(Modifier.height(14.dp)); Text(name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("Familienmitglied", color = Soft); if(familyCode.isNotBlank()) Text("Familiencode: $familyCode", color = Mint, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(14.dp)); OutlinedButton(onClick = { profilePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Icon(Icons.Default.AddAPhoto, null); Spacer(Modifier.width(8.dp)); Text("Profilbild auswählen") }; Spacer(Modifier.height(12.dp))
        Spacer(Modifier.height(18.dp)); OutlinedTextField(inviteName, { inviteName = it }, label = { Text("Mitglied einladen (Admin)") }, modifier = Modifier.fillMaxWidth(), colors = inputColors())
        Spacer(Modifier.height(8.dp)); Button(onClick = { scope.launch { try { val result = FirebaseFunctions.getInstance().getHttpsCallable("inviteMember").call(mapOf("name" to inviteName)).await().data as Map<*, *>; invitePin = result["pin"] as String; message = "Einmal-PIN für ${result["name"]}: $invitePin" } catch (e: Exception) { message = e.message ?: "Einladung fehlgeschlagen." } } }, enabled = inviteName.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) { Text("Einladung erstellen") }
        if(message.isNotBlank()) Text(message, color = Mint, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(26.dp)); OutlinedButton(onClick = onLogout) { Icon(Icons.Default.Logout, null); Spacer(Modifier.width(8.dp)); Text("Abmelden") }
    }
}

@Composable private fun EmptyCard(title: String, body: String) { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(body, color = Soft) } } }
@Composable private fun Field(value: String, update: (String) -> Unit, label: String) { OutlinedTextField(value, update, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true, colors = inputColors()) }
@Composable private fun inputColors() = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Mint, unfocusedBorderColor = Soft.copy(alpha = .35f), focusedLabelColor = Mint, unfocusedLabelColor = Soft, cursorColor = Mint, focusedContainerColor = Panel, unfocusedContainerColor = Panel)
