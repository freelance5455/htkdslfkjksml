package in.lifeloop.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF236B4A)
private val Pale = Color(0xFFEAF4ED)
private val Ink = Color(0xFF18352A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LifeLoopApp() }
    }
}

private data class Task(val title: String, val done: Boolean = false)
private data class Note(val title: String, val body: String)
private data class Expense(val title: String, val amount: Double)

private class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("lifeloop_local", Context.MODE_PRIVATE)

    fun loadTasks(): List<Task> = try {
        val arr = JSONArray(prefs.getString("tasks", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Task(o.optString("title"), o.optBoolean("done"))
        }
    } catch (_: Exception) { emptyList() }

    fun saveTasks(items: List<Task>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("title", it.title).put("done", it.done)) }
        prefs.edit().putString("tasks", arr.toString()).apply()
    }

    fun loadNotes(): List<Note> = try {
        val arr = JSONArray(prefs.getString("notes", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Note(o.optString("title"), o.optString("body"))
        }
    } catch (_: Exception) { emptyList() }

    fun saveNotes(items: List<Note>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("title", it.title).put("body", it.body)) }
        prefs.edit().putString("notes", arr.toString()).apply()
    }

    fun loadExpenses(): List<Expense> = try {
        val arr = JSONArray(prefs.getString("expenses", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Expense(o.optString("title"), o.optDouble("amount"))
        }
    } catch (_: Exception) { emptyList() }

    fun saveExpenses(items: List<Expense>) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("title", it.title).put("amount", it.amount)) }
        prefs.edit().putString("expenses", arr.toString()).apply()
    }
}

@Composable
private fun LifeLoopApp() {
    val context = LocalContext.current
    val store = remember { LocalStore(context) }
    val tasks = remember { mutableStateListOf<Task>().apply { addAll(store.loadTasks()) } }
    val notes = remember { mutableStateListOf<Note>().apply { addAll(store.loadNotes()) } }
    val expenses = remember { mutableStateListOf<Expense>().apply { addAll(store.loadExpenses()) } }
    var selected by remember { mutableStateOf("Home") }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFF79A98A), background = Color(0xFFF7FAF7))) {
        Scaffold(
            containerColor = Color(0xFFF7FAF7),
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Tasks", "Notes", "Money").forEach { tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Text(when(tab) { "Home" -> "⌂"; "Tasks" -> "✓"; "Notes" -> "▤"; else -> "₹" }, fontSize = 20.sp) },
                            label = { Text(tab) }
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Home" -> HomeScreen(padding, tasks.count { it.done }, tasks.size, notes.size, expenses.sumOf { it.amount })
                "Tasks" -> TasksScreen(padding, tasks) { store.saveTasks(tasks.toList()) }
                "Notes" -> NotesScreen(padding, notes) { store.saveNotes(notes.toList()) }
                else -> MoneyScreen(padding, expenses) { store.saveExpenses(expenses.toList()) }
            }
        }
    }
}

@Composable
private fun HomeScreen(padding: PaddingValues, done: Int, total: Int, noteCount: Int, totalExpense: Double) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(padding),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("LifeLoop", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Green)
            Text("A little help for every day", color = Color.Gray)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Pale), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(greeting(), fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("Make today count. One small step at a time.", color = Ink)
                    Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), color = Green, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item { Text("Your overview", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Tasks done", "$done / $total", Modifier.weight(1f))
            StatCard("Notes", noteCount.toString(), Modifier.weight(1f))
        } }
        item { StatCard("Expenses recorded", "₹${"%.2f".format(totalExpense)}", Modifier.fillMaxWidth()) }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("A simple daily companion", fontWeight = FontWeight.Bold, color = Green)
                    Text("Use Tasks to plan your day, Notes to remember useful things, and Money to keep a record of spending.")
                    Text("Your entries are saved on this phone. No account or internet is needed for these tools.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
    }
}

private fun greeting(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "Good morning ☀️"
        hour < 17 -> "Good afternoon 🌿"
        else -> "Good evening 🌙"
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = Color.Gray, fontSize = 12.sp)
            Text(value, color = Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TasksScreen(padding: PaddingValues, tasks: MutableList<Task>, save: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("My Day", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green)
        Text("Write down what you want to get done.")
        OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth(), label = { Text("New task") }, singleLine = true)
        Button(onClick = {
            if (text.isNotBlank()) { tasks.add(Task(text.trim())); text = ""; save() }
        }, modifier = Modifier.fillMaxWidth()) { Text("Add task") }
        if (tasks.isEmpty()) EmptyHint("No tasks yet. Add your first task above.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(tasks) { index, task ->
                Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.done, onCheckedChange = {
                            tasks[index] = task.copy(done = it); save()
                        })
                        Text(task.title, modifier = Modifier.weight(1f), color = if (task.done) Color.Gray else Ink)
                        TextButton(onClick = { tasks.removeAt(index); save() }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotesScreen(padding: PaddingValues, notes: MutableList<Note>, save: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("My Pocket Notes", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Green)
        OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Note title") }, singleLine = true)
        OutlinedTextField(body, { body = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Write a note") }, minLines = 3)
        Button(onClick = {
            if (title.isNotBlank() || body.isNotBlank()) {
                notes.add(0, Note(title.ifBlank { "Quick note" }, body))
                title = ""; body = ""; save()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Save note") }
        if (notes.isEmpty()) EmptyHint("Your saved notes will appear here.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(notes) { index, note ->
                Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(note.title, fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.weight(1f))
                            TextButton(onClick = { notes.removeAt(index); save() }) { Text("Delete") }
                        }
                        Text(note.body)
                    }
                }
            }
        }
    }
}

@Composable
private fun MoneyScreen(padding: PaddingValues, expenses: MutableList<Expense>, save: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val total = expenses.sumOf { it.amount }
    Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Money Diary", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green)
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Pale)) {
            Column(Modifier.padding(16.dp)) {
                Text("Total recorded expenses", color = Ink)
                Text("₹${"%.2f".format(total)}", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Green)
            }
        }
        OutlinedTextField(title, { title = it }, modifier = Modifier.fillMaxWidth(), label = { Text("What did you spend on?") }, singleLine = true)
        OutlinedTextField(amount, { amount = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Amount in ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        Button(onClick = {
            val value = amount.toDoubleOrNull()
            if (title.isNotBlank() && value != null && value > 0) {
                expenses.add(0, Expense(title.trim(), value)); title = ""; amount = ""; save()
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Add expense") }
        if (expenses.isEmpty()) EmptyHint("No expenses recorded yet.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(expenses) { index, item ->
                Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.title, fontWeight = FontWeight.Bold, color = Green)
                            Text("₹${"%.2f".format(item.amount)}")
                        }
                        TextButton(onClick = { expenses.removeAt(index); save() }) { Text("Delete") }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyHint(message: String) {
    Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
        Text(message, color = Color.Gray)
    }
}
