import {Share} from '@capacitor/share';
import {isNative} from './native';

export const canShare =
  isNative ||
  (typeof navigator !== 'undefined' && typeof navigator.share === 'function');

export async function shareContent(opts: {
  title?: string;
  text?: string;
  url?: string;
}): Promise<void> {
  if (isNative) {
    try {
      await Share.share({...opts, dialogTitle: opts.title});
    } catch (err) {
      if (err instanceof Error && /cancel/i.test(err.message)) {
        const abort = new Error('Partilha cancelada');
        abort.name = 'AbortError';
        throw abort;
      }
      throw err;
    }
    return;
  }
  await navigator.share(opts);
}
