import type { inferRouterOutputs } from "@trpc/server";
import type { AppRouter } from "../../api/router";

export type RouterOutput = inferRouterOutputs<AppRouter>;

export type TransactionRow = RouterOutput["finance"]["transactions"]["list"][number];
export type CategoryRow = RouterOutput["finance"]["categories"]["list"][number];
export type BudgetRow = RouterOutput["finance"]["budgets"]["list"][number];
export type SettingsRow = RouterOutput["finance"]["settings"]["get"];
