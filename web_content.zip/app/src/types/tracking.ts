import type {Timestamp} from 'firebase/firestore';

export type TrackerCategory = 'vehicle' | 'person' | 'asset' | 'pet';
export type NavTab = 'map' | 'devices' | 'history' | 'geofences' | 'alerts';
export type TrackerFilter = 'all' | 'live' | 'shared';
export type AppTheme = 'light' | 'dark';
export type MapVisualStyle = 'light' | 'night' | 'satellite';

// Synchronized with firebase-blueprint.json
export const BLUEPRINT_LIMITS = {
  NAME_MIN: 1,
  NAME_MAX: 60,
  OWNER_NAME_MAX: 80,
  MAX_VIEWERS: 20,
  RADIUS_MIN_M: 50,
  RADIUS_MAX_M: 50000,
  ADDRESS_MAX: 220,
  WEATHER_COND_MAX: 80,
  SOS_MESSAGE_MAX: 280,
  SIGNAL_PAYLOAD_MAX: 16000,
  SHARE_CODE_PATTERN: /^PV-[A-Z0-9]{4,8}$/,
  HEX_COLOR_PATTERN: /^#[0-9A-Fa-f]{6}$/,
} as const;

export const TRACKER_COLORS = [
  {label: 'Azul Cobalto', value: '#2563EB'},
  {label: 'Esmeralda', value: '#16A34A'},
  {label: 'Âmbar', value: '#D97706'},
  {label: 'Carmesim', value: '#DC2626'},
  {label: 'Ciano', value: '#0891B2'},
  {label: 'Índigo', value: '#4F46E5'},
] as const;

export const CATEGORY_LABELS: Record<TrackerCategory, string> = {
  vehicle: 'Veículo',
  person: 'Pessoa',
  asset: 'Objeto',
  pet: 'Pet',
};

export const LOW_BATTERY_THRESHOLD = 20;

export interface DeviceBatteryState {
  level: number;
  charging: boolean;
}

export interface UserPositionState {
  lat: number;
  lng: number;
  accuracy: number;
  speed?: number;
  heading?: number;
  altitude?: number | null;
  altitudeAccuracy?: number | null;
  updatedAt?: number;
}

export interface WeatherData {
  temperatureC: number;
  feelsLikeC: number;
  humidity: number;
  windKmh: number;
  precipProb: number;
  condition: string;
  conditionCode:
    | 'clear'
    | 'partly_cloudy'
    | 'cloudy'
    | 'fog'
    | 'rain'
    | 'storm'
    | 'snow';
  isDaytime: boolean;
  uvIndex?: number;
  iconUri?: string;
  source: 'google' | 'open-meteo';
}

export interface Tracker {
  id: string;
  name: string;
  category: TrackerCategory;
  color: string;
  shareCode: string;
  ownerId: string;
  ownerName: string;
  viewerIds: string[];
  isBroadcasting: boolean;
  lat: number;
  lng: number;
  accuracy: number;
  speed: number;
  heading: number;
  batteryLevel?: number;
  batteryCharging?: boolean;
  lastSeenAt: Timestamp | null;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface TrackPoint {
  id: string;
  trackerId: string;
  ownerId: string;
  viewerIds: string[];
  lat: number;
  lng: number;
  accuracy: number;
  speed: number;
  heading: number;
  altitude?: number;
  altitudeAccuracy?: number;
  batteryLevel?: number;
  batteryCharging?: boolean;
  address?: string;
  weatherTempC?: number;
  weatherCondition?: string;
  weatherWindKmh?: number;
  weatherHumidity?: number;
  distanceFromPrevMeters?: number;
  isSos?: boolean;
  source: 'gps' | 'manual' | 'sos';
  recordedAt: Timestamp | null;
}

export interface Geofence {
  id: string;
  ownerId: string;
  name: string;
  lat: number;
  lng: number;
  radiusMeters: number;
  color: string;
  active: boolean;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface GeofenceAlert {
  id: string;
  ownerId: string;
  trackerId: string;
  trackerName: string;
  geofenceId: string;
  geofenceName: string;
  eventType: 'enter' | 'exit';
  distanceMeters: number;
  acknowledged: boolean;
  createdAt: Timestamp | null;
}

export interface SosEvent {
  id: string;
  ownerId: string;
  ownerName: string;
  viewerIds: string[];
  trackerId?: string;
  trackerName?: string;
  status: 'active' | 'resolved';
  message: string;
  lat: number;
  lng: number;
  accuracy: number;
  altitude?: number;
  speed?: number;
  address?: string;
  weatherSummary?: string;
  batteryLevel?: number;
  cameraEnabled: boolean;
  micEnabled: boolean;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
  resolvedAt?: Timestamp | null;
}

export interface SosSignal {
  id: string;
  sosId: string;
  ownerId: string;
  viewerIds: string[];
  senderId: string;
  targetId: string;
  type: 'join' | 'offer' | 'answer' | 'ice' | 'leave';
  payload: string;
  createdAt: Timestamp | null;
}

export interface ShareInvite {
  trackerId: string;
  ownerId: string;
  trackerName: string;
  active: boolean;
}

export interface RouteSummary {
  targetTrackerId: string;
  targetTrackerName: string;
  distanceMeters: number;
  durationMillis: number;
  travelMode: 'DRIVING' | 'WALKING';
}

export function generateDocId(prefix = 'id'): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let suffix = '';
  for (let i = 0; i < 14; i++) {
    suffix += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `${prefix}_${Date.now()}_${suffix}`;
}

export function generateShareCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `PV-${code}`;
}

export function sanitizeName(raw: string, fallback = 'Rastreador'): string {
  const trimmed = raw.trim().slice(0, BLUEPRINT_LIMITS.NAME_MAX);
  return trimmed.length >= BLUEPRINT_LIMITS.NAME_MIN ? trimmed : fallback;
}

export function clampLat(lat: number): number {
  if (!Number.isFinite(lat)) return -23.5505;
  return Math.max(-90, Math.min(90, lat));
}

export function clampLng(lng: number): number {
  if (!Number.isFinite(lng)) return -46.6333;
  return Math.max(-180, Math.min(180, lng));
}

export function haversineDistanceMeters(
  a: {lat: number; lng: number},
  b: {lat: number; lng: number}
): number {
  const R = 6371000;
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const sinDLat = Math.sin(dLat / 2);
  const sinDLng = Math.sin(dLng / 2);
  const h =
    sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
  return 2 * R * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
}

export function formatDistance(meters: number): string {
  if (!Number.isFinite(meters) || meters < 0) return '0 m';
  if (meters < 1000) return `${Math.round(meters)} m`;
  return `${(meters / 1000).toFixed(2)} km`;
}

export function formatSpeedKmh(metersPerSecond: number): string {
  if (!Number.isFinite(metersPerSecond) || metersPerSecond <= 0) return '0 km/h';
  return `${Math.round(metersPerSecond * 3.6)} km/h`;
}

export function formatDurationPt(durationMillis: number): string {
  const totalMinutes = Math.max(1, Math.round(durationMillis / 60000));
  if (totalMinutes < 60) return `${totalMinutes} min`;
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  return mins > 0 ? `${hours} h ${mins} min` : `${hours} h`;
}

export function formatCoordinates(lat: number, lng: number): string {
  return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
}

export function formatRelativeTimePt(ts: Timestamp | null): string {
  if (!ts) return 'Agora';
  const date = ts.toDate();
  const diffSec = Math.max(0, Math.floor((Date.now() - date.getTime()) / 1000));
  if (diffSec < 10) return 'Agora mesmo';
  if (diffSec < 60) return `Há ${diffSec} s`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `Há ${diffMin} min`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `Há ${diffHours} h`;
  return date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDateTimePt(ts: Timestamp | null): string {
  if (!ts) return 'Agora mesmo';
  return ts.toDate().toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
}
