import * as THREE from 'three';
import './style.css';
import { createWorld, LAYOUT } from './game/world.js';
import { Player, FollowCamera } from './game/player.js';
import { Input } from './game/input.js';
import { Traffic } from './game/cars.js';
import { Worker } from './game/workers.js';
import { Effects } from './game/effects.js';
import { GameState, fmtMoney } from './game/state.js';
import { UI } from './game/ui.js';
import { animateCharacter } from './game/models.js';

// ——— Детерминированный рандом для декораций ———
function mulberry32(a) {
  return function () {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ——— Рендерер ———
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
} catch (e) {
  document.body.innerHTML = '<div style="color:#fff;padding:40px;font-family:sans-serif">Ваш браузер не поддерживает WebGL. Попробуйте обновить Chrome.</div>';
  throw e;
}
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.75)); // оптимизация для слабых телефонов
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
document.getElementById('app').appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(52, innerWidth / innerHeight, 0.1, 300);
camera.position.set(0, 8, 20);

// ——— Мир и сущности ———
const world = createWorld(scene, mulberry32(20261018));
const state = new GameState();
const hasSave = state.load();
const player = new Player(scene);
const followCam = new FollowCamera(camera);
const input = new Input();
const effects = new Effects(scene, camera, document.getElementById('float-layer'));
const traffic = new Traffic(scene, effects);
const workers = [];

// Синхронизация мира с сохранённым прогрессом
function syncUpgrades() {
  world.arches.forEach((arch, i) => { arch.visible = i < state.slotsUnlocked; });
  while (workers.length < state.workers) workers.push(new Worker(scene, workers.length));
  while (workers.length > state.workers) workers.pop().dispose(scene);
}
syncUpgrades();

// ——— UI ———
let running = false;
const ui = new UI(state,
  id => { // покупка улучшения
    if (state.buy(id)) {
      syncUpgrades();
      ui.toast('Улучшение куплено!', true);
      afterEconomyChange();
    }
  },
  () => { // сброс прогресса
    state.reset();
    location.reload();
  });

function afterEconomyChange() {
  const done = state.checkTask();
  if (done) {
    ui.toast(`Задание выполнено! +${fmtMoney(done.reward)} сом`, true);
    // награда могла закрыть и следующее задание
    afterEconomyChangeOnce();
  }
  ui.updateMoney();
  ui.updateTask();
  state.save();
}
function afterEconomyChangeOnce() {
  const done = state.checkTask();
  if (done) { ui.toast(`Задание выполнено! +${fmtMoney(done.reward)} сом`, true); afterEconomyChangeOnce(); }
}

ui.showStart(hasSave, () => { state.started = true; state.save(); running = true; });
ui.updateMoney();
ui.updateTask();

// ——— Ввод ———
input.attach(
  document.getElementById('joystick'),
  document.getElementById('joy-knob'),
  renderer.domElement);

// ——— Игровые хуки для трафика ———
const hooks = {
  arches: world.arches,
  camera,
  playerPos: () => player.mesh.position,
  onMoney(amount, pos) {
    effects.floatText(pos.clone().add(new THREE.Vector3(0, 2, 0)), `+${fmtMoney(amount)} сом`);
    afterEconomyChange();
  },
  onCarWashed() {},
};

// ——— Автосохранение ———
setInterval(() => { if (running) state.save(); }, 5000);
addEventListener('visibilitychange', () => { if (document.hidden) state.save(); });
addEventListener('pagehide', () => state.save());

// ——— Главный цикл ———
const clock = new THREE.Clock();
let simTime = 0;
const WASH_RADIUS = 3.1;

function step(dt) {
  simTime += dt;
  world.update(dt);

  const move = running && !ui.shopOpen ? input.getMove() : { x: 0, y: 0 };
  player.update(dt, move, followCam.yaw);

  if (running && !ui.shopOpen) {
    // Игрок моет ближайшую ждущую машину, стоя рядом
    if (!player.washing && player.moving < 0.1) {
      const car = traffic.nearestWaiting(player.mesh.position, WASH_RADIUS, null, true);
      if (car) player.washCar(car, simTime);
    } else if (player.washing) {
      if (player.washing.state !== 'washing' && player.washing.state !== 'wait') {
        player.releaseCar();
      } else if (player.mesh.position.distanceTo(player.washing.mesh.position) > WASH_RADIUS + 0.6) {
        player.releaseCar();
      } else {
        player.washCar(player.washing, simTime);
      }
    }
    if (!player.washing) animateCharacter(player.mesh, simTime, player.moving * player.speed);
  } else {
    animateCharacter(player.mesh, simTime, 0);
  }

  traffic.update(dt, simTime, state, hooks);
  for (const w of workers) w.update(dt, simTime, traffic);
  effects.update(dt, simTime);
  followCam.update(dt, player.mesh.position, input.takeCamDX());
}

renderer.setAnimationLoop(() => {
  const dt = Math.min(clock.getDelta(), 0.05);
  step(dt);
  renderer.render(scene, camera);
});

addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});

// ——— Хуки для проверки/скриншотов ———
window.__seek = t => {
  const steps = Math.min(Math.floor(Math.max(0, t) * 60), 3600);
  for (let i = 0; i < steps; i++) step(1 / 60);
  renderer.render(scene, camera);
};
window.__play = () => {};
window.__SCENE_READY__ = true;
window.__game = { state, player, traffic, workers, syncUpgrades };
