# CPLS V2 — Stage 1139

## Candle Gap Integrity Monitor
- Adds explicit integrity validation for candle chronology, duplicate timestamps, and abnormal gaps.
- Hardens live sample timestamps to the valid seven-day history/current-time boundary.
- Updates near-duplicate live samples instead of accumulating redundant points.
- Keeps the existing no-synthetic-candle policy and all chart interactions.

Source ZIP stage only; APK build not performed.
