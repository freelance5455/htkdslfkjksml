import { useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useExportMiniApp, useGenerateMiniApp, useHealthCheck } from '@workspace/api-client-react';
import {
  AlertCircle,
  ArrowUpRight,
  BrainCircuit,
  Check,
  ChevronDown,
  CircleCheck,
  Clock3,
  Code2,
  Copy,
  Download,
  ExternalLink,
  FileCode2,
  FolderOpen,
  History,
  ImagePlus,
  Loader2,
  Menu,
  MessageCircle,
  MoreHorizontal,
  Paperclip,
  PanelLeft,
  PanelRight,
  Plus,
  RotateCw,
  Save,
  Search,
  Send,
  Settings2,
  Sparkles,
  Trash2,
  UserRound,
  WandSparkles,
  X,
  Zap,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type Model = 'flash' | 'pro' | 'flash-lite' | 'extended';
type Reasoning = 'off' | 'balanced' | 'deep';

type Attachment = {
  name: string;
  mimeType: string;
  data: string;
};

type MiniFile = {
  path: string;
  content: string;
  language: string;
};

type Generation = {
  id: string;
  title: string;
  summary: string;
  model: string;
  files: MiniFile[];
  previewHtml: string;
  createdAt: string;
};

type PromptHistoryItem = {
  id: string;
  prompt: string;
  model: Model;
  reasoning: Reasoning;
  attachments: string[];
  createdAt: string;
};

type ThemeMode = 'system' | 'light' | 'dark';

const colorSeeds = [
  { id: 'coral', label: 'Coral', hue: 14 },
  { id: 'ocean', label: 'Ocean', hue: 204 },
  { id: 'violet', label: 'Violet', hue: 278 },
  { id: 'mint', label: 'Mint', hue: 158 },
] as const;

const modelOptions: Array<{ id: Model; name: string; detail: string; icon: typeof Zap }> = [
  { id: 'flash', name: 'Flash', detail: 'Fast sketches', icon: Zap },
  { id: 'pro', name: 'Pro', detail: 'More polish', icon: Sparkles },
  { id: 'flash-lite', name: 'Flash Lite', detail: 'Quickest pass', icon: WandSparkles },
  { id: 'extended', name: 'Extended', detail: 'Deep build', icon: BrainCircuit },
];

const starterIdeas = [
  'A tiny focus timer that feels like a sunrise',
  'A recipe mixer for whatever is left in my fridge',
  'A one-page reading tracker with a satisfying finish line',
];

const formatDate = (date: string) =>
  new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric' }).format(new Date(date));

const formatTime = (date: string) =>
  new Intl.DateTimeFormat('en', { hour: 'numeric', minute: '2-digit' }).format(new Date(date));

function applyMaterialYouPalette(seedId: string, mode: ThemeMode) {
  const seed = colorSeeds.find((item) => item.id === seedId) ?? colorSeeds[0];
  const root = document.documentElement;
  const systemDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
  const dark = mode === 'dark' || (mode === 'system' && systemDark);
  const hue = seed.hue;
  const tone = (value: number, saturation: number, lightness: number) =>
    `${Math.round((value + 360) % 360)} ${saturation}% ${lightness}%`;
  const colors = dark
    ? {
        background: tone(hue, 24, 10),
        foreground: tone(hue + 18, 24, 94),
        border: tone(hue, 18, 26),
        card: tone(hue, 25, 14),
        cardBorder: tone(hue, 18, 27),
        sidebar: tone(hue, 28, 8),
        sidebarBorder: tone(hue, 20, 18),
        primary: tone(hue, 82, 72),
        primaryForeground: tone(hue, 28, 12),
        secondary: tone(hue + 155, 30, 30),
        secondaryForeground: tone(hue + 155, 48, 84),
        muted: tone(hue, 20, 20),
        mutedForeground: tone(hue + 10, 16, 70),
        accent: tone(hue + 38, 82, 66),
        accentForeground: tone(hue, 28, 12),
      }
    : {
        background: tone(hue, 32, 96),
        foreground: tone(hue + 18, 30, 16),
        border: tone(hue, 20, 84),
        card: tone(hue, 38, 99),
        cardBorder: tone(hue, 20, 88),
        sidebar: tone(hue + 18, 28, 16),
        sidebarBorder: tone(hue + 18, 24, 26),
        primary: tone(hue, 78, 56),
        primaryForeground: tone(hue + 18, 28, 12),
        secondary: tone(hue + 155, 30, 84),
        secondaryForeground: tone(hue + 155, 40, 24),
        muted: tone(hue, 25, 91),
        mutedForeground: tone(hue + 10, 16, 42),
        accent: tone(hue + 38, 88, 76),
        accentForeground: tone(hue + 18, 28, 12),
      };

  const mapped = {
    '--background': colors.background,
    '--foreground': colors.foreground,
    '--border': colors.border,
    '--card': colors.card,
    '--card-foreground': colors.foreground,
    '--card-border': colors.cardBorder,
    '--sidebar': colors.sidebar,
    '--sidebar-foreground': colors.foreground,
    '--sidebar-border': colors.sidebarBorder,
    '--sidebar-primary': colors.primary,
    '--sidebar-primary-foreground': colors.primaryForeground,
    '--sidebar-accent': colors.muted,
    '--sidebar-accent-foreground': colors.foreground,
    '--popover': colors.card,
    '--popover-foreground': colors.foreground,
    '--popover-border': colors.cardBorder,
    '--primary': colors.primary,
    '--primary-foreground': colors.primaryForeground,
    '--secondary': colors.secondary,
    '--secondary-foreground': colors.secondaryForeground,
    '--muted': colors.muted,
    '--muted-foreground': colors.mutedForeground,
    '--accent': colors.accent,
    '--accent-foreground': colors.accentForeground,
    '--input': colors.border,
    '--ring': colors.primary,
    '--md-sys-color-primary': colors.primary,
    '--md-sys-color-on-primary': colors.primaryForeground,
    '--md-sys-color-primary-container': dark ? tone(hue, 50, 30) : tone(hue, 60, 90),
    '--md-sys-color-on-primary-container': dark ? tone(hue, 48, 92) : tone(hue, 52, 20),
    '--md-sys-color-surface': colors.background,
    '--md-sys-color-surface-container-low': dark ? tone(hue, 24, 13) : tone(hue, 30, 94),
    '--md-sys-color-surface-container': colors.card,
    '--md-sys-color-surface-variant': dark ? tone(hue, 18, 23) : tone(hue, 18, 89),
    '--md-sys-color-on-surface-variant': colors.mutedForeground,
    '--md-sys-color-outline': colors.border,
  };

  Object.entries(mapped).forEach(([property, value]) => root.style.setProperty(property, value));
  root.classList.toggle('dark', dark);
  root.style.colorScheme = dark ? 'dark' : 'light';
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', `hsl(${colors.primary})`);
}

function HaloMark({ small = false }: { small?: boolean }) {
  return (
    <div className={`relative flex shrink-0 items-center justify-center ${small ? 'h-8 w-8' : 'h-10 w-10'}`} aria-label="Halo mark">
      <span className="absolute inset-[3px] rounded-full border-[1.5px] border-primary rotate-[-18deg]" />
      <span className="absolute inset-[7px] rounded-full border border-accent rotate-[32deg]" />
      <span className="h-2.5 w-2.5 rounded-full bg-primary shadow-[0_0_0_4px_hsl(var(--primary)/.12)]" />
    </div>
  );
}

function Sidebar({
  history,
  promptHistory,
  currentId,
  onNew,
  onLoad,
  onReplayPrompt,
  onSettings,
  appIcon,
  mobileOpen,
  onClose,
}: {
  history: Generation[];
  promptHistory: PromptHistoryItem[];
  currentId?: string;
  onNew: () => void;
  onLoad: (generation: Generation) => void;
  onReplayPrompt: (item: PromptHistoryItem) => void;
  onSettings: () => void;
  appIcon: string | null;
  mobileOpen: boolean;
  onClose: () => void;
}) {
  return (
    <>
      {mobileOpen && <button className="fixed inset-0 z-30 bg-foreground/20 md:hidden" onClick={onClose} aria-label="Close navigation" data-testid="button-close-navigation" />}
      <aside className={`fixed inset-y-0 left-0 z-40 flex w-[264px] flex-col border-r border-sidebar-border bg-sidebar px-4 py-5 text-sidebar-foreground transition-transform duration-300 md:relative md:z-0 md:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`} data-testid="sidebar-workspace">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-2.5">
            <HaloMark small />
            <span className="font-serif text-[25px] tracking-[-.03em] text-sidebar-foreground">halo</span>
          </div>
          <button onClick={onClose} className="rounded-lg p-2 text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground md:hidden" aria-label="Close menu" data-testid="button-close-sidebar">
            <X className="h-4 w-4" />
          </button>
        </div>

        <button onClick={onNew} className="mt-8 flex items-center justify-between rounded-xl bg-sidebar-primary px-3.5 py-3 text-sm font-bold text-sidebar-primary-foreground shadow-[0_10px_24px_hsl(var(--sidebar-primary)/.16)] transition-transform hover:-translate-y-0.5" data-testid="button-new-project">
          <span className="flex items-center gap-2"><Plus className="h-4 w-4" /> New project</span>
          <span className="font-mono text-[10px] opacity-60">⌘ N</span>
        </button>

        <nav className="mt-7 space-y-1" aria-label="Workspace navigation">
          <p className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[.18em] text-sidebar-foreground/45">Workspace</p>
          <button className="flex w-full items-center gap-3 rounded-lg bg-sidebar-accent px-3 py-2.5 text-left text-sm font-semibold text-sidebar-accent-foreground" data-testid="nav-studio">
            <Sparkles className="h-4 w-4 text-sidebar-primary" /> Studio
          </button>
          <button onClick={() => document.getElementById('history-list')?.scrollIntoView({ behavior: 'smooth' })} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-sidebar-foreground/70 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground" data-testid="nav-history">
            <History className="h-4 w-4" /> History
            {history.length > 0 && <span className="ml-auto rounded-full bg-sidebar-foreground/10 px-2 py-0.5 font-mono text-[10px]">{history.length}</span>}
          </button>
        </nav>

        <div id="history-list" className="mt-8 min-h-0 flex-1 overflow-y-auto">
          <div className="mb-2 flex items-center justify-between px-3">
            <p className="text-[10px] font-bold uppercase tracking-[.18em] text-sidebar-foreground/45">Recent builds</p>
            {history.length > 0 && <MoreHorizontal className="h-4 w-4 text-sidebar-foreground/40" />}
          </div>
          {history.length === 0 ? (
            <div className="mx-2 mt-5 rounded-xl border border-dashed border-sidebar-border px-3 py-4 text-center">
              <Clock3 className="mx-auto mb-2 h-4 w-4 text-sidebar-foreground/45" />
              <p className="text-xs leading-5 text-sidebar-foreground/45">Your next good idea will live here.</p>
            </div>
          ) : (
            <div className="space-y-1">
              {history.map((item) => (
                <button key={item.id} onClick={() => onLoad(item)} className={`group flex w-full items-start gap-2.5 rounded-lg px-3 py-2.5 text-left transition-colors ${currentId === item.id ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground/65 hover:bg-sidebar-accent hover:text-sidebar-foreground'}`} data-testid={`history-item-${item.id}`}>
                  <FolderOpen className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${currentId === item.id ? 'text-sidebar-primary' : 'text-sidebar-foreground/40'}`} />
                  <span className="min-w-0">
                    <span className="block truncate text-xs font-semibold">{item.title}</span>
                    <span className="mt-0.5 block font-mono text-[9px] text-sidebar-foreground/40">{formatDate(item.createdAt)}</span>
                  </span>
                  <ArrowUpRight className="ml-auto mt-0.5 h-3 w-3 shrink-0 opacity-0 transition-opacity group-hover:opacity-60" />
                </button>
              ))}
            </div>
          )}
        </div>

         <div className="mt-5 border-t border-sidebar-border pt-4">
           <div className="mb-2 flex items-center justify-between px-3">
             <p className="text-[10px] font-bold uppercase tracking-[.18em] text-sidebar-foreground/45">Prompt history</p>
             {promptHistory.length > 0 && <span className="font-mono text-[9px] text-sidebar-foreground/40">{promptHistory.length}</span>}
           </div>
           {promptHistory.length === 0 ? (
             <p className="px-3 text-[10px] leading-5 text-sidebar-foreground/40">Your ideas will appear here after the first build.</p>
           ) : (
             <div className="space-y-1">
               {promptHistory.slice(0, 6).map((item) => (
                 <button key={item.id} onClick={() => onReplayPrompt(item)} className="group flex w-full items-start gap-2.5 rounded-lg px-3 py-2 text-left text-sidebar-foreground/65 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground" data-testid={`prompt-history-item-${item.id}`}>
                   <RotateCw className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sidebar-foreground/40 transition-transform group-hover:rotate-[-35deg]" />
                   <span className="min-w-0">
                     <span className="block truncate text-[11px] leading-4">{item.prompt}</span>
                     <span className="mt-0.5 block font-mono text-[9px] text-sidebar-foreground/40">{formatDate(item.createdAt)} · {item.model}</span>
                   </span>
                 </button>
               ))}
             </div>
           )}
         </div>

        <div className="mt-5 border-t border-sidebar-border pt-4">
          <button onClick={onSettings} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-sidebar-foreground/65 transition-colors hover:bg-sidebar-accent hover:text-sidebar-foreground" data-testid="button-settings">
            <Settings2 className="h-4 w-4" /> Settings
          </button>
          <div className="mt-3 flex items-center gap-3 rounded-xl bg-sidebar-accent/65 px-3 py-2.5">
             <div className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full bg-accent text-xs font-bold text-accent-foreground">{appIcon ? <img src={appIcon} alt="" className="h-full w-full object-cover" /> : 'AR'}</div>
            <div className="min-w-0">
              <p className="truncate text-xs font-bold">Alex Rivera</p>
              <p className="truncate text-[10px] text-sidebar-foreground/45">Personal studio</p>
            </div>
            <UserRound className="ml-auto h-3.5 w-3.5 text-sidebar-foreground/40" />
          </div>
        </div>
      </aside>
    </>
  );
}

function Topbar({ onMenu, onSettings, onProfile, appIcon }: { onMenu: () => void; onSettings: () => void; onProfile: () => void; appIcon: string | null }) {
  return (
    <header className="flex h-[72px] shrink-0 items-center justify-between border-b border-border bg-background/85 px-5 backdrop-blur md:px-8">
      <div className="flex items-center gap-3">
        <button onClick={onMenu} className="rounded-lg p-2 text-muted-foreground hover:bg-muted md:hidden" aria-label="Open navigation" data-testid="button-open-navigation"><Menu className="h-5 w-5" /></button>
        <div className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex">
          <span className="font-mono text-[10px] uppercase tracking-[.16em]">Studio</span>
          <span className="text-border">/</span>
          <span className="font-semibold text-foreground">New project</span>
        </div>
        <div className="flex items-center gap-2 sm:hidden">
          <HaloMark small />
          <span className="font-serif text-2xl tracking-[-.03em]">halo</span>
        </div>
      </div>
      <div className="flex items-center gap-1.5">
        <div className="mr-2 hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-[10px] font-mono text-muted-foreground lg:flex">
          <span className="h-1.5 w-1.5 rounded-full bg-secondary-foreground" /> local workspace
        </div>
        <button onClick={onSettings} className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" aria-label="Open settings" data-testid="button-open-settings"><Settings2 className="h-[17px] w-[17px]" /></button>
         <button onClick={onProfile} className="ml-1 flex h-8 w-8 items-center justify-center overflow-hidden rounded-full bg-accent text-[10px] font-bold text-accent-foreground transition-transform hover:scale-105" aria-label="Open profile" data-testid="button-open-profile">{appIcon ? <img src={appIcon} alt="" className="h-full w-full object-cover" /> : 'AR'}</button>
      </div>
    </header>
  );
}

function Conversation({
  prompt,
  setPrompt,
  model,
  setModel,
  reasoning,
  setReasoning,
  attachments,
  onAttach,
  onRemoveAttachment,
  onGenerate,
  isPending,
  generation,
  error,
  onStarter,
  fileInputRef,
}: {
  prompt: string;
  setPrompt: (value: string) => void;
  model: Model;
  setModel: (value: Model) => void;
  reasoning: Reasoning;
  setReasoning: (value: Reasoning) => void;
  attachments: Attachment[];
  onAttach: (event: ChangeEvent<HTMLInputElement>) => void;
  onRemoveAttachment: (name: string) => void;
  onGenerate: (event: FormEvent<HTMLFormElement>) => void;
  isPending: boolean;
  generation: Generation | null;
  error: string | null;
  onStarter: (idea: string) => void;
  fileInputRef: { current: HTMLInputElement | null };
}) {
  return (
     <section className="md3-expressive-card flex min-h-[640px] flex-col rounded-2xl border border-border bg-card shadow-[0_14px_50px_hsl(223_30%_18%/.055)]" data-testid="conversation-panel">
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary text-secondary-foreground"><MessageCircle className="h-4 w-4" /></div>
          <div>
            <p className="text-sm font-bold">Build conversation</p>
            <p className="font-mono text-[9px] uppercase tracking-[.14em] text-muted-foreground">idea → interface</p>
          </div>
        </div>
        <span className="flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 font-mono text-[9px] text-muted-foreground"><span className="h-1.5 w-1.5 rounded-full bg-secondary-foreground" /> ready</span>
      </div>

      <div className="halo-grid flex-1 overflow-y-auto px-5 py-6 sm:px-7">
        <div className="halo-rise flex gap-3">
          <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-foreground text-background"><Sparkles className="h-3.5 w-3.5" /></div>
          <div className="max-w-[490px]">
            <p className="mb-1 font-mono text-[9px] uppercase tracking-[.14em] text-muted-foreground">Halo / now</p>
            <div className="rounded-2xl rounded-tl-sm border border-border bg-background px-4 py-3.5 text-sm leading-6 text-foreground/80">
              Tell me what you want to make. I&apos;ll turn the rough thought into a small, working thing you can open, tweak, and take with you.
            </div>
          </div>
        </div>

        {!prompt && !generation && (
          <div className="mt-8 pl-10">
            <p className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Try a starting point</p>
            <div className="space-y-2">
              {starterIdeas.map((idea) => (
                <button key={idea} onClick={() => onStarter(idea)} className="group flex w-full items-center justify-between rounded-xl border border-border bg-card/75 px-3.5 py-3 text-left text-xs text-muted-foreground transition-all hover:-translate-y-0.5 hover:border-primary/45 hover:text-foreground" data-testid={`button-starter-${starterIdeas.indexOf(idea)}`}>
                  <span>{idea}</span><ArrowUpRight className="h-3.5 w-3.5 shrink-0 opacity-40 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </button>
              ))}
            </div>
          </div>
        )}

        {prompt && (
          <div className="halo-rise mt-7 flex justify-end gap-3">
            <div className="max-w-[88%]">
              <p className="mb-1 text-right font-mono text-[9px] uppercase tracking-[.14em] text-muted-foreground">You / draft</p>
              <div className="rounded-2xl rounded-tr-sm bg-foreground px-4 py-3.5 text-sm leading-6 text-background">{prompt}</div>
              {attachments.length > 0 && <div className="mt-2 flex flex-wrap justify-end gap-1.5">{attachments.map((file) => <span key={file.name} className="flex items-center gap-1.5 rounded-full border border-border bg-card px-2.5 py-1 font-mono text-[9px] text-muted-foreground"><FileCode2 className="h-3 w-3" /> {file.name}</span>)}</div>}
            </div>
            <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-accent text-[9px] font-bold text-accent-foreground">AR</div>
          </div>
        )}

        {isPending && (
          <div className="halo-rise mt-7 flex gap-3">
            <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-foreground text-background"><Sparkles className="h-3.5 w-3.5 halo-pulse" /></div>
            <div className="rounded-2xl rounded-tl-sm border border-border bg-background px-4 py-3.5">
              <div className="flex items-center gap-2 text-xs text-muted-foreground"><span className="flex gap-1"><i className="h-1.5 w-1.5 rounded-full bg-primary" /><i className="h-1.5 w-1.5 rounded-full bg-primary/60" /><i className="h-1.5 w-1.5 rounded-full bg-primary/30" /></span> shaping your idea</div>
            </div>
          </div>
        )}

        {generation && !isPending && (
          <div className="halo-rise mt-7 flex gap-3">
            <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-foreground text-background"><Check className="h-3.5 w-3.5" /></div>
            <div className="max-w-[490px]">
              <p className="mb-1 font-mono text-[9px] uppercase tracking-[.14em] text-muted-foreground">Halo / built {formatTime(generation.createdAt)}</p>
              <div className="rounded-2xl rounded-tl-sm border border-secondary/70 bg-secondary/35 px-4 py-3.5 text-sm leading-6 text-foreground/80">
                <p>{generation.summary}</p>
                <div className="mt-3 flex items-center gap-3 border-t border-secondary/70 pt-3 font-mono text-[9px] uppercase tracking-[.12em] text-muted-foreground">
                  <span className="flex items-center gap-1"><Code2 className="h-3 w-3" /> {generation.files.length} files</span><span>•</span><span>{generation.model}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {error && <div className="halo-rise mt-5 flex items-start gap-2.5 rounded-xl border border-destructive/25 bg-destructive/8 px-3.5 py-3 text-xs text-destructive" role="alert" data-testid="status-generation-error"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><span>{error}</span></div>}
      </div>

      <form onSubmit={onGenerate} className="border-t border-border p-4 sm:p-5" data-testid="form-generation">
        {attachments.length > 0 && (
          <div className="mb-3 flex flex-wrap gap-2">
            {attachments.map((attachment) => <span key={attachment.name} className="flex items-center gap-2 rounded-lg bg-muted px-2.5 py-1.5 text-[10px] font-semibold text-muted-foreground"><FileCode2 className="h-3 w-3 text-primary" />{attachment.name}<button type="button" onClick={() => onRemoveAttachment(attachment.name)} aria-label={`Remove ${attachment.name}`} data-testid={`button-remove-attachment-${attachment.name}`}><X className="h-3 w-3 hover:text-destructive" /></button></span>)}
          </div>
        )}
         <div className="md3-pill relative rounded-xl border border-input bg-background transition-colors focus-within:border-primary/60 focus-within:ring-2 focus-within:ring-primary/10">
          <textarea value={prompt} onChange={(event) => setPrompt(event.target.value)} placeholder="Describe a small thing you want to make..." rows={3} className="w-full resize-none bg-transparent px-4 py-3.5 pr-4 text-sm leading-6 outline-none placeholder:text-muted-foreground/65" data-testid="input-generation-prompt" aria-label="Describe your app idea" />
          <div className="flex items-center justify-between px-3 pb-3">
            <div className="flex items-center gap-1.5">
              <label className="flex cursor-pointer items-center gap-1.5 rounded-lg px-2 py-1.5 text-[10px] font-semibold text-muted-foreground transition-colors hover:bg-muted hover:text-foreground" data-testid="button-attach-file">
                <Paperclip className="h-3.5 w-3.5" /> Attach
                <input ref={fileInputRef} type="file" multiple className="hidden" onChange={onAttach} aria-label="Attach reference files" />
              </label>
              <select value={reasoning} onChange={(event) => setReasoning(event.target.value as Reasoning)} className="rounded-lg border-0 bg-muted px-2 py-1.5 text-[10px] font-semibold text-muted-foreground outline-none" aria-label="Reasoning depth" data-testid="select-reasoning">
                <option value="off">Reasoning off</option><option value="balanced">Balanced</option><option value="deep">Deep reasoning</option>
              </select>
            </div>
             <button type="submit" disabled={isPending || !prompt.trim()} className="md3-fab flex items-center gap-2 bg-primary px-3.5 py-2 text-xs font-bold text-primary-foreground transition-all hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-40" data-testid="button-generate">
              {isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />} {isPending ? 'Building' : 'Build app'}
            </button>
          </div>
        </div>
        <p className="mt-2.5 text-center font-mono text-[9px] text-muted-foreground/70">Describe the feeling, the job, or the tiny friction. Specifics can come later.</p>
      </form>
    </section>
  );
}

function Preview({
  generation,
  onExport,
  onSave,
  isExporting,
  saved,
  projectName,
  setProjectName,
}: {
  generation: Generation | null;
  onExport: () => void;
  onSave: () => void;
  isExporting: boolean;
  saved: boolean;
  projectName: string;
  setProjectName: (value: string) => void;
}) {
  const [copied, setCopied] = useState(false);

  const openPreview = () => {
    if (!generation) return;
    const previewUrl = URL.createObjectURL(new Blob([generation.previewHtml], { type: 'text/html' }));
    window.open(previewUrl, '_blank', 'noopener,noreferrer');
    window.setTimeout(() => URL.revokeObjectURL(previewUrl), 30_000);
  };

  const copyPreview = async () => {
    if (!generation) return;
    await navigator.clipboard?.writeText(generation.previewHtml);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1600);
  };

  return (
     <section className="md3-expressive-card flex min-h-[640px] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-[0_14px_50px_hsl(223_30%_18%/.055)]" data-testid="preview-panel">
      <div className="flex items-center justify-between border-b border-border px-5 py-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent text-accent-foreground"><PanelRight className="h-4 w-4" /></div>
          <div><p className="text-sm font-bold">Live preview</p><p className="font-mono text-[9px] uppercase tracking-[.14em] text-muted-foreground">sandbox / 01</p></div>
        </div>
        <div className="flex items-center gap-1.5">
          <button onClick={openPreview} className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-30" disabled={!generation} aria-label="Open preview in new window" data-testid="button-open-preview"><ExternalLink className="h-4 w-4" /></button>
          <button onClick={copyPreview} className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground disabled:opacity-30" disabled={!generation} aria-label="Copy generated preview HTML" data-testid="button-copy-preview">{copied ? <Check className="h-4 w-4 text-secondary-foreground" /> : <Copy className="h-4 w-4" />}</button>
        </div>
      </div>
      <div className="halo-grid flex flex-1 items-center justify-center p-4 sm:p-7">
        {!generation ? (
          <div className="relative w-full max-w-[390px] rounded-[24px] border border-border bg-background px-7 py-16 text-center shadow-[0_20px_50px_hsl(223_30%_18%/.08)]">
            <div className="absolute left-1/2 top-0 h-16 w-16 -translate-x-1/2 -translate-y-1/2 rounded-full border border-primary/30 bg-background p-2"><div className="flex h-full w-full items-center justify-center rounded-full bg-primary/10"><HaloMark small /></div></div>
            <MonitorPlaceholder />
            <p className="mt-5 font-serif text-2xl text-foreground">A blank canvas, for now.</p>
            <p className="mx-auto mt-2 max-w-[240px] text-xs leading-5 text-muted-foreground">Your app will appear here as soon as the idea has somewhere to land.</p>
            <div className="mx-auto mt-7 flex w-fit items-center gap-2 rounded-full border border-border px-3 py-1.5 font-mono text-[9px] uppercase tracking-[.12em] text-muted-foreground"><span className="h-1.5 w-1.5 rounded-full bg-muted-foreground/40" /> waiting for a spark</div>
          </div>
        ) : (
          <div className="h-full min-h-[450px] w-full overflow-hidden rounded-xl border border-border bg-background shadow-[0_18px_45px_hsl(223_30%_18%/.1)]">
            <div className="flex h-8 items-center gap-1.5 border-b border-border bg-muted/70 px-3"><span className="h-2 w-2 rounded-full bg-destructive/55" /><span className="h-2 w-2 rounded-full bg-accent/80" /><span className="h-2 w-2 rounded-full bg-secondary-foreground/55" /><span className="ml-2 truncate font-mono text-[9px] text-muted-foreground">{generation.title.toLowerCase().replaceAll(' ', '-')}.local</span></div>
            <iframe title="Generated mini-app preview" srcDoc={generation.previewHtml} sandbox="allow-scripts" className="h-[calc(100%-32px)] min-h-[418px] w-full bg-background" data-testid="iframe-generated-preview" />
          </div>
        )}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border px-5 py-4">
        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">{generation ? <><CircleCheck className="h-3.5 w-3.5 text-secondary-foreground" /> Preview is interactive</> : <><Code2 className="h-3.5 w-3.5" /> HTML preview will render here</>}</div>
        <div className="flex items-center gap-2">
          {generation && <input value={projectName} onChange={(event) => setProjectName(event.target.value)} className="hidden w-[120px] rounded-lg border border-input bg-background px-2.5 py-2 text-[10px] outline-none focus:border-primary sm:block" aria-label="Export project name" data-testid="input-project-name" />}
          <button onClick={onSave} disabled={!generation || saved} className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-xs font-bold text-foreground transition-colors hover:bg-muted disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-save-project">{saved ? <Check className="h-3.5 w-3.5 text-secondary-foreground" /> : <Save className="h-3.5 w-3.5" />} {saved ? 'Saved' : 'Save'}</button>
          <button onClick={onExport} disabled={!generation || isExporting} className="flex items-center gap-2 rounded-lg bg-foreground px-3 py-2 text-xs font-bold text-background transition-all hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-45" data-testid="button-export-project">{isExporting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />} {isExporting ? 'Packaging' : 'Export zip'}</button>
        </div>
      </div>
    </section>
  );
}

function MonitorPlaceholder() {
  return (
    <div className="mx-auto flex h-24 w-36 items-center justify-center rounded-xl border border-border bg-muted/45">
      <div className="flex h-11 w-16 items-end justify-center gap-1 border-b-2 border-muted-foreground/30">
        <span className="h-5 w-1 rounded-full bg-primary/50" /><span className="h-9 w-1 rounded-full bg-accent/80" /><span className="h-7 w-1 rounded-full bg-secondary-foreground/40" /><span className="h-11 w-1 rounded-full bg-primary/30" />
      </div>
    </div>
  );
}

function SettingsPanel({
  onClose,
  themeMode,
  setThemeMode,
  colorSeed,
  setColorSeed,
  appIcon,
  onIconUpload,
}: {
  onClose: () => void;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  colorSeed: string;
  setColorSeed: (seed: string) => void;
  appIcon: string | null;
  onIconUpload: (event: ChangeEvent<HTMLInputElement>) => void;
}) {
  const [compact, setCompact] = useState(false);
  const [autoSave, setAutoSave] = useState(true);
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-foreground/15 backdrop-blur-[2px]" role="dialog" aria-modal="true" aria-label="Settings panel" data-testid="settings-panel">
      <button className="absolute inset-0 cursor-default" onClick={onClose} aria-label="Close settings" data-testid="button-close-settings-overlay" />
      <aside className="relative h-full w-full max-w-[390px] border-l border-border bg-card px-6 py-6 shadow-[-18px_0_50px_hsl(223_30%_18%/.12)] halo-rise">
        <div className="flex items-center justify-between"><div><p className="font-serif text-3xl">Studio settings</p><p className="mt-1 text-xs text-muted-foreground">Shape the way Halo meets you.</p></div><button onClick={onClose} className="rounded-lg p-2 text-muted-foreground hover:bg-muted" aria-label="Close settings panel" data-testid="button-close-settings"><X className="h-4 w-4" /></button></div>
         <div className="mt-9 space-y-6">
           <div>
             <p className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Material You theme</p>
             <label className="mb-2 block text-xs font-semibold">Color source</label>
             <div className="grid grid-cols-3 gap-1.5 rounded-xl bg-muted p-1" role="group" aria-label="Theme mode">
               {(['system', 'light', 'dark'] as ThemeMode[]).map((mode) => (
                 <button key={mode} type="button" onClick={() => setThemeMode(mode)} className={`rounded-lg px-2 py-2 text-[10px] font-bold capitalize transition-colors ${themeMode === mode ? 'bg-card text-foreground shadow-sm' : 'text-muted-foreground hover:text-foreground'}`} data-testid={`button-theme-${mode}`}>{mode}</button>
               ))}
             </div>
             <p className="mb-2 mt-4 text-xs font-semibold">Dynamic color seed</p>
             <div className="grid grid-cols-4 gap-2">
               {colorSeeds.map((seed) => (
                 <button key={seed.id} type="button" onClick={() => setColorSeed(seed.id)} className={`flex flex-col items-center gap-1.5 rounded-xl border p-2 text-[10px] font-semibold transition-all ${colorSeed === seed.id ? 'border-primary bg-primary/10 text-foreground' : 'border-border text-muted-foreground hover:bg-muted'}`} data-testid={`button-color-seed-${seed.id}`}>
                   <span className="h-6 w-6 rounded-full shadow-inner" style={{ backgroundColor: `hsl(${seed.hue} 78% 58%)` }} />
                   {seed.label}
                 </button>
               ))}
             </div>
           </div>
           <div>
             <p className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">App identity</p>
             <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-border bg-background p-3 transition-colors hover:bg-muted">
               <span className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-xl bg-accent text-accent-foreground">{appIcon ? <img src={appIcon} alt="Current app icon" className="h-full w-full object-cover" /> : <ImagePlus className="h-4 w-4" />}</span>
               <span><span className="block text-xs font-bold">Upload app icon</span><span className="mt-1 block text-[10px] text-muted-foreground">Used in your exported app package.</span></span>
               <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden" onChange={onIconUpload} data-testid="input-app-icon" />
             </label>
           </div>
           <div><p className="mb-3 text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Generation defaults</p><label className="mb-2 block text-xs font-semibold">Default reasoning</label><select className="w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" defaultValue="balanced" data-testid="select-default-reasoning"><option value="off">Off — keep it quick</option><option value="balanced">Balanced — a little thought</option><option value="deep">Deep — take the long way</option></select></div>
           <div className="space-y-3"><p className="text-[10px] font-bold uppercase tracking-[.16em] text-muted-foreground">Workspace feel</p><ToggleRow label="Save projects locally" detail="Keep your recent builds in this browser." checked={autoSave} onChange={() => setAutoSave(!autoSave)} testId="toggle-autosave" /><ToggleRow label="Compact conversation" detail="Fit more of the idea stream on screen." checked={compact} onChange={() => setCompact(!compact)} testId="toggle-compact" /></div>
           <div className="rounded-xl border border-border bg-muted/45 p-4"><div className="flex items-start gap-3"><div className="rounded-lg bg-accent p-2 text-accent-foreground"><Sparkles className="h-4 w-4" /></div><div><p className="text-xs font-bold">Halo workspace</p><p className="mt-1 text-[11px] leading-5 text-muted-foreground">A private creative bench for turning a thought into something you can click.</p></div></div></div>
        </div>
      </aside>
    </div>
  );
}

function ToggleRow({ label, detail, checked, onChange, testId }: { label: string; detail: string; checked: boolean; onChange: () => void; testId: string }) {
  return <button onClick={onChange} className="flex w-full items-center justify-between rounded-xl border border-border px-3.5 py-3 text-left hover:bg-muted/60" data-testid={testId}><span><span className="block text-xs font-semibold">{label}</span><span className="mt-1 block text-[10px] text-muted-foreground">{detail}</span></span><span className={`relative h-5 w-9 rounded-full transition-colors ${checked ? 'bg-primary' : 'bg-muted-foreground/25'}`}><span className={`absolute top-0.5 h-4 w-4 rounded-full bg-card shadow-sm transition-transform ${checked ? 'translate-x-[17px]' : 'translate-x-0.5'}`} /></span></button>;
}

function ProfilePopover({ onClose, onSettings, appIcon }: { onClose: () => void; onSettings: () => void; appIcon: string | null }) {
  return <div className="fixed inset-0 z-40" onClick={onClose}><div className="absolute right-5 top-[62px] w-[220px] rounded-xl border border-border bg-card p-2 shadow-[0_16px_40px_hsl(223_30%_18%/.14)] halo-rise" onClick={(event) => event.stopPropagation()}><div className="flex items-center gap-3 rounded-lg bg-muted/60 px-3 py-2.5"><div className="flex h-8 w-8 items-center justify-center overflow-hidden rounded-full bg-accent text-[10px] font-bold text-accent-foreground">{appIcon ? <img src={appIcon} alt="" className="h-full w-full object-cover" /> : 'AR'}</div><div><p className="text-xs font-bold">Alex Rivera</p><p className="text-[10px] text-muted-foreground">Building in public</p></div></div><button onClick={onSettings} className="mt-1 flex w-full items-center gap-2 rounded-lg px-3 py-2.5 text-left text-xs text-muted-foreground hover:bg-muted hover:text-foreground" data-testid="profile-settings"><Settings2 className="h-3.5 w-3.5" /> Workspace settings</button></div></div>;
}

function Home() {
  const [history, setHistory] = useState<Generation[]>([]);
  const [promptHistory, setPromptHistory] = useState<PromptHistoryItem[]>([]);
  const [generation, setGeneration] = useState<Generation | null>(null);
  const [prompt, setPrompt] = useState('');
  const [model, setModel] = useState<Model>('flash');
  const [reasoning, setReasoning] = useState<Reasoning>('balanced');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [exportName, setExportName] = useState('halo-project');
  const [themeMode, setThemeMode] = useState<ThemeMode>('system');
  const [colorSeed, setColorSeed] = useState('coral');
  const [appIcon, setAppIcon] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const generateMutation = useGenerateMiniApp();
  const exportMutation = useExportMiniApp();
  const health = useHealthCheck();

  useEffect(() => {
    try {
      const stored = localStorage.getItem('halo-generations');
      if (stored) setHistory(JSON.parse(stored) as Generation[]);
      const storedPrompts = localStorage.getItem('halo-prompt-history');
      if (storedPrompts) setPromptHistory(JSON.parse(storedPrompts) as PromptHistoryItem[]);
      const storedTheme = localStorage.getItem('halo-theme-mode');
      if (storedTheme === 'system' || storedTheme === 'light' || storedTheme === 'dark') setThemeMode(storedTheme);
      const storedSeed = localStorage.getItem('halo-color-seed');
      if (storedSeed) setColorSeed(storedSeed);
      const storedIcon = localStorage.getItem('halo-app-icon');
      if (storedIcon) setAppIcon(storedIcon);
    } catch {
      setHistory([]);
    }
  }, []);

  useEffect(() => {
    applyMaterialYouPalette(colorSeed, themeMode);
    localStorage.setItem('halo-theme-mode', themeMode);
    localStorage.setItem('halo-color-seed', colorSeed);
    const media = window.matchMedia?.('(prefers-color-scheme: dark)');
    const onSystemThemeChange = () => {
      if (themeMode === 'system') applyMaterialYouPalette(colorSeed, themeMode);
    };
    media?.addEventListener('change', onSystemThemeChange);
    return () => media?.removeEventListener('change', onSystemThemeChange);
  }, [colorSeed, themeMode]);

  const persistHistory = (items: Generation[]) => {
    setHistory(items);
    localStorage.setItem('halo-generations', JSON.stringify(items.slice(0, 12)));
  };

  const persistPromptHistory = (items: PromptHistoryItem[]) => {
    const next = items.slice(0, 24);
    setPromptHistory(next);
    localStorage.setItem('halo-prompt-history', JSON.stringify(next));
  };

  const readFile = (file: File) =>
    new Promise<Attachment>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve({ name: file.name, mimeType: file.type || 'application/octet-stream', data: String(reader.result).split(',')[1] ?? '' });
      reader.onerror = () => reject(new Error(`Could not read ${file.name}`));
      reader.readAsDataURL(file);
    });

  const handleAttach = async (event: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files ?? []);
    try {
      const next = await Promise.all(files.map(readFile));
      setAttachments((current) => [...current, ...next].slice(0, 5));
    } catch {
      setError('One of those files could not be read. Try attaching it again.');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleGenerate = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!prompt.trim() || generateMutation.isPending) return;
    setError(null);
    setSaved(false);
    const submittedPrompt = prompt.trim();
    persistPromptHistory([
      {
        id: crypto.randomUUID(),
        prompt: submittedPrompt,
        model,
        reasoning,
        attachments: attachments.map((attachment) => attachment.name),
        createdAt: new Date().toISOString(),
      },
      ...promptHistory.filter((item) => item.prompt !== submittedPrompt),
    ]);
    generateMutation.mutate({ data: { prompt: submittedPrompt, model, reasoning, attachments } }, {
      onSuccess: (result) => {
        const next = result as Generation;
        setGeneration(next);
        setExportName(next.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'halo-project');
        persistHistory([next, ...history.filter((item) => item.id !== next.id)]);
      },
      onError: () => setError('Halo could not finish that build. Check your connection and try again.'),
    });
  };

  const handleNew = () => {
    setGeneration(null);
    setPrompt('');
    setAttachments([]);
    setError(null);
    setSaved(false);
    setMobileOpen(false);
  };

  const handleLoad = (item: Generation) => {
    setGeneration(item);
    setPrompt(item.summary);
    setExportName(item.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'));
    setSaved(true);
    setMobileOpen(false);
  };

  const handleReplayPrompt = (item: PromptHistoryItem) => {
    setPrompt(item.prompt);
    setModel(item.model);
    setReasoning(item.reasoning);
    setAttachments([]);
    setError(null);
    setMobileOpen(false);
  };

  const handleIconUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const value = String(reader.result);
      setAppIcon(value);
      localStorage.setItem('halo-app-icon', value);
    };
    reader.readAsDataURL(file);
    event.target.value = '';
  };

  const handleExport = () => {
    if (!generation || exportMutation.isPending) return;
    exportMutation.mutate({ data: { projectName: exportName.trim() || 'halo-project', files: generation.files } }, {
      onSuccess: (blob) => {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${exportName.trim() || 'halo-project'}.zip`;
        link.click();
        URL.revokeObjectURL(url);
      },
      onError: () => setError('The export could not be packaged. Please try again.'),
    });
  };

  const handleSave = () => {
    if (!generation) return;
    persistHistory([generation, ...history.filter((item) => item.id !== generation.id)]);
    setSaved(true);
  };

  const statusLabel = useMemo(() => health.isError ? 'offline mode' : health.isLoading ? 'checking connection' : 'api connected', [health.isError, health.isLoading]);

  return (
     <div className="halo-noise md3-expressive-shell flex min-h-[100dvh] text-foreground">
       <Sidebar history={history} promptHistory={promptHistory} currentId={generation?.id} onNew={handleNew} onLoad={handleLoad} onReplayPrompt={handleReplayPrompt} onSettings={() => setSettingsOpen(true)} appIcon={appIcon} mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      <main className="flex min-w-0 flex-1 flex-col">
         <Topbar onMenu={() => setMobileOpen(true)} onSettings={() => setSettingsOpen(true)} onProfile={() => setProfileOpen(!profileOpen)} appIcon={appIcon} />
        <div className="flex-1 overflow-y-auto">
          <div className="mx-auto max-w-[1510px] px-5 py-7 sm:px-8 sm:py-9 xl:px-10">
            <div className="mb-7 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
              <div className="halo-rise">
                <div className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.18em] text-primary"><span className="h-px w-6 bg-primary" /> Creative workspace</div>
                <h1 className="max-w-[620px] font-serif text-[clamp(2.7rem,5vw,4.5rem)] leading-[.94] tracking-[-.045em]">Make the thing<br /><em className="text-primary">you can&apos;t stop thinking about.</em></h1>
                <p className="mt-4 max-w-[500px] text-sm leading-6 text-muted-foreground">A conversational workbench for turning a half-formed idea into a mini-app that actually works.</p>
              </div>
              <div className="flex shrink-0 items-center gap-2 text-[10px] text-muted-foreground"><span className={`h-2 w-2 rounded-full ${health.isError ? 'bg-destructive' : health.isLoading ? 'bg-accent' : 'bg-secondary-foreground'}`} /> {statusLabel}<span className="mx-1 text-border">•</span><span className="font-mono">v0.1 / studio</span></div>
            </div>

            <div className="mb-5 flex flex-col gap-3 rounded-xl border border-border bg-card/55 px-4 py-3 sm:flex-row sm:items-center sm:justify-between sm:px-5">
              <div className="flex items-center gap-3"><div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary/10 text-primary"><Zap className="h-3.5 w-3.5" /></div><p className="text-xs text-muted-foreground">Choose a model, then write like you&apos;re explaining it to a clever friend.</p></div>
              <div className="flex flex-wrap gap-1.5">
                {modelOptions.map(({ id, name, detail, icon: Icon }) => <button key={id} onClick={() => setModel(id)} className={`group flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition-colors ${model === id ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`} title={detail} data-testid={`button-model-${id}`}><Icon className="h-3 w-3" /> {name}</button>)}
              </div>
            </div>

            <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_minmax(390px,.86fr)]">
              <Conversation prompt={prompt} setPrompt={setPrompt} model={model} setModel={setModel} reasoning={reasoning} setReasoning={setReasoning} attachments={attachments} onAttach={handleAttach} onRemoveAttachment={(name) => setAttachments((items) => items.filter((item) => item.name !== name))} onGenerate={handleGenerate} isPending={generateMutation.isPending} generation={generation} error={error} onStarter={(idea) => { setPrompt(idea); }} fileInputRef={fileInputRef} />
              <Preview generation={generation} onExport={handleExport} onSave={handleSave} isExporting={exportMutation.isPending} saved={saved} projectName={exportName} setProjectName={setExportName} />
            </div>

            <div className="mt-6 flex flex-col gap-4 border-t border-border pt-5 text-[10px] text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4"><span className="flex items-center gap-1.5"><Search className="h-3.5 w-3.5" /> Natural language in</span><span className="flex items-center gap-1.5"><Code2 className="h-3.5 w-3.5" /> Working code out</span></div>
              <p className="font-mono uppercase tracking-[.12em]">Built for the curious</p>
            </div>
          </div>
        </div>
      </main>
       {settingsOpen && <SettingsPanel onClose={() => setSettingsOpen(false)} themeMode={themeMode} setThemeMode={setThemeMode} colorSeed={colorSeed} setColorSeed={setColorSeed} appIcon={appIcon} onIconUpload={handleIconUpload} />}
       {profileOpen && <ProfilePopover onClose={() => setProfileOpen(false)} onSettings={() => { setProfileOpen(false); setSettingsOpen(true); }} appIcon={appIcon} />}
    </div>
  );
}

function Router() {
  return (
    <ErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;