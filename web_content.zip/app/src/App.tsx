import { Routes, Route, Navigate } from 'react-router'
import { Loader2 } from 'lucide-react'
import { trpc } from '@/providers/trpc'
import AppLayout from '@/components/AppLayout'
import Login from '@/pages/Login'
import Dashboard from '@/pages/Dashboard'
import Statistik from '@/pages/Statistik'
import Habits from '@/pages/Habits'
import Leaderboard from '@/pages/Leaderboard'
import Admin from '@/pages/Admin'
import Profile from '@/pages/Profile'

export default function App() {
  const { data: me, isLoading } = trpc.auth.me.useQuery()

  if (isLoading) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    )
  }

  if (!me) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    )
  }

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/statistik" element={<Statistik />} />
        <Route path="/habit" element={<Habits />} />
        <Route path="/peringkat" element={<Leaderboard />} />
        <Route
          path="/admin"
          element={me.role === 'admin' ? <Admin /> : <Navigate to="/" replace />}
        />
        <Route path="/profil" element={<Profile />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AppLayout>
  )
}
