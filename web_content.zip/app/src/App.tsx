import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {APIProvider} from '@vis.gl/react-google-maps';
import {clearWatchBg, watchPositionBg} from './geo';
import {
  onAuthStateChanged,
  type User,
} from 'firebase/auth';
import {
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {AlertCircle, BatteryLow, Bell, Plus, Siren, X} from 'lucide-react';
import {ConsentModal} from './components/ConsentModal';
import {ErrorBoundary} from './components/ErrorBoundary';
import {NewTrackerModal} from './components/NewTrackerModal';
import {ShareCodeModal} from './components/ShareCodeModal';
import {SidebarPanel} from './components/SidebarPanel';
import {SosModal} from './components/SosModal';
import {TrackingMap, type MapPickMode} from './components/TrackingMap';
import {formatWeatherSummary} from './components/WeatherStrip';
import {
  OperationType,
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  signInWithGoogle,
  signOutEverywhere,
} from './firebase';
import {getCachedAddressLabel} from './hooks/useReverseGeocode';
import {
  fetchWeatherForCoords,
  getCachedWeatherForCoords,
} from './hooks/useWeather';
import {
  type AppTheme,
  BLUEPRINT_LIMITS,
  type DeviceBatteryState,
  type Geofence,
  type GeofenceAlert,
  LOW_BATTERY_THRESHOLD,
  type MapVisualStyle,
  type NavTab,
  type SosEvent,
  type TrackPoint,
  type Tracker,
  type TrackerCategory,
  type UserPositionState,
  clampLat,
  clampLng,
  generateDocId,
  generateShareCode,
  haversineDistanceMeters,
  sanitizeName,
} from './types/tracking';
import {
  PrecisionLocationFilter,
  acquireBestPosition,
} from './utils/locationPrecision';

interface BatteryManagerLike extends EventTarget {
  level: number;
  charging: boolean;
  addEventListener(
    type: 'levelchange' | 'chargingchange',
    listener: () => void
  ): void;
  removeEventListener(
    type: 'levelchange' | 'chargingchange',
    listener: () => void
  ): void;
}

type NavigatorWithBattery = Navigator & {
  getBattery?: () => Promise<BatteryManagerLike>;
};

const MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
const MAPS_LIBRARIES = ['marker', 'places', 'routes'];
const THEME_STORAGE_KEY = 'pontovivo-theme';

function getInitialTheme(): AppTheme {
  if (typeof window === 'undefined') return 'light';
  try {
    const stored = window.localStorage.getItem(THEME_STORAGE_KEY);
    if (stored === 'dark' || stored === 'light') return stored;
    if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
  } catch {
    // Ignore storage access failures
  }
  return 'light';
}

export default function App() {
  const [theme, setTheme] = useState<AppTheme>(getInitialTheme);
  const [mapStyle, setMapStyle] = useState<MapVisualStyle>(() =>
    getInitialTheme() === 'dark' ? 'night' : 'light'
  );
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<NavTab>('devices');

  // Trackers state (merged owned + shared)
  const [ownedTrackers, setOwnedTrackers] = useState<Tracker[]>([]);
  const [sharedTrackers, setSharedTrackers] = useState<Tracker[]>([]);
  const [selectedTrackerId, setSelectedTrackerId] = useState<string | null>(
    null
  );
  const [selectedPoints, setSelectedPoints] = useState<TrackPoint[]>([]);
  const [selectedHistoryPointId, setSelectedHistoryPointId] = useState<
    string | null
  >(null);
  const [geofences, setGeofences] = useState<Geofence[]>([]);
  const [alerts, setAlerts] = useState<GeofenceAlert[]>([]);

  // Live GPS, battery & UI workflow state
  const [userPosition, setUserPosition] = useState<UserPositionState | null>(
    null
  );
  const [locatingUser, setLocatingUser] = useState(false);
  const [deviceBattery, setDeviceBattery] = useState<DeviceBatteryState | null>(
    null
  );
  const [dismissedBatteryAlertKey, setDismissedBatteryAlertKey] = useState<
    string | null
  >(null);
  const [activeBroadcastTrackerId, setActiveBroadcastTrackerId] = useState<
    string | null
  >(null);
  const [consentTargetTracker, setConsentTargetTracker] =
    useState<Tracker | null>(null);
  const [shareTargetTracker, setShareTargetTracker] = useState<Tracker | null>(
    null
  );
  const [pendingShareCode, setPendingShareCode] = useState<string | null>(
    () => {
      if (typeof window === 'undefined') return null;
      const raw = new URLSearchParams(window.location.search).get('codigo');
      if (!raw) return null;
      const cleaned = raw.trim().toUpperCase();
      return BLUEPRINT_LIMITS.SHARE_CODE_PATTERN.test(cleaned) ? cleaned : null;
    }
  );
  const [showNewTrackerModal, setShowNewTrackerModal] = useState(false);
  const [isCreatingTracker, setIsCreatingTracker] = useState(false);

  const [pickMode, setPickMode] = useState<MapPickMode>({type: 'none'});
  const [pickedGeofenceCenter, setPickedGeofenceCenter] = useState<{
    lat: number;
    lng: number;
  } | null>(null);
  const [routeTargetTracker, setRouteTargetTracker] = useState<Tracker | null>(
    null
  );
  const [routeTravelMode, setRouteTravelMode] = useState<'DRIVING' | 'WALKING'>(
    'DRIVING'
  );
  const [followSelected, setFollowSelected] = useState(false);
  const [focusRequest, setFocusRequest] = useState<{
    lat: number;
    lng: number;
    zoom?: number;
    nonce: number;
  } | null>(null);

  const [joinMessage, setJoinMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [bannerFeedback, setBannerFeedback] = useState<string | null>(null);

  // SOS Emergency state
  const [ownedSosEvents, setOwnedSosEvents] = useState<SosEvent[]>([]);
  const [sharedSosEvents, setSharedSosEvents] = useState<SosEvent[]>([]);
  const [showSosModal, setShowSosModal] = useState(false);
  const [inspectedSosId, setInspectedSosId] = useState<string | null>(null);

  const watchIdRef = useRef<number | null>(null);
  const userPassiveWatchIdRef = useRef<number | null>(null);
  const userFilterRef = useRef<PrecisionLocationFilter>(
    new PrecisionLocationFilter()
  );
  const broadcastFilterRef = useRef<PrecisionLocationFilter>(
    new PrecisionLocationFilter()
  );
  const lastWriteTimeRef = useRef<number>(0);
  const lastSosSyncTimeRef = useRef<number>(0);
  const lastTrailPointRef = useRef<{
    lat: number;
    lng: number;
    time: number;
  } | null>(null);
  const geofenceInsideMapRef = useRef<Record<string, boolean>>({});
  const deviceBatteryRef = useRef<DeviceBatteryState | null>(null);

  // Close drawer on Escape key
  useEffect(() => {
    if (!isMenuOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsMenuOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isMenuOpen]);

  // Reset highlighted history point when switching tracker
  useEffect(() => {
    setSelectedHistoryPointId(null);
  }, [selectedTrackerId]);

  // Prompt sign-in if opened via shared deep link ?codigo=PV-...
  useEffect(() => {
    if (!authReady || !pendingShareCode) return;
    if (!user) {
      setIsMenuOpen(true);
      setBannerFeedback(
        `Código ${pendingShareCode} recebido! Entre com Google para acompanhar este rastreador em tempo real.`
      );
    }
  }, [authReady, user, pendingShareCode]);

  // Persist and apply light/dark theme class on <html>
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    try {
      window.localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // Ignore storage access failures
    }
  }, [theme]);

  const handleChangeTheme = useCallback((nextTheme: AppTheme) => {
    setTheme(nextTheme);
    setMapStyle((prev) => {
      if (prev === 'satellite') {
        return nextTheme === 'dark' ? 'night' : 'light';
      }
      return nextTheme === 'dark' ? 'night' : 'light';
    });
  }, []);

  // Tier 1/2 quota exceeded listener
  useEffect(() => {
    const onQuotaExceeded = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuotaExceeded);
    return () =>
      window.removeEventListener('gmp-quota-exceeded', onQuotaExceeded);
  }, []);

  // Device Battery Status API monitor
  useEffect(() => {
    const nav = navigator as NavigatorWithBattery;
    if (typeof nav.getBattery !== 'function') return;

    let mounted = true;
    let batteryRef: BatteryManagerLike | null = null;

    const syncBattery = () => {
      if (!mounted || !batteryRef) return;
      const next: DeviceBatteryState = {
        level: Math.max(0, Math.min(100, Math.round(batteryRef.level * 100))),
        charging: Boolean(batteryRef.charging),
      };
      deviceBatteryRef.current = next;
      setDeviceBattery(next);
    };

    nav
      .getBattery()
      .then((battery) => {
        if (!mounted) return;
        batteryRef = battery;
        syncBattery();
        battery.addEventListener('levelchange', syncBattery);
        battery.addEventListener('chargingchange', syncBattery);
      })
      .catch(() => {
        // Battery Status API unavailable in this browser context
      });

    return () => {
      mounted = false;
      if (batteryRef) {
        batteryRef.removeEventListener('levelchange', syncBattery);
        batteryRef.removeEventListener('chargingchange', syncBattery);
      }
    };
  }, []);

  const applyUserPosition = useCallback((pos: GeolocationPosition) => {
    const filtered = userFilterRef.current.process(pos);
    if (!filtered || filtered.wasOutlierRejected) return null;
    const next: UserPositionState = {
      lat: filtered.lat,
      lng: filtered.lng,
      accuracy: filtered.accuracy,
      speed: filtered.speed,
      heading: filtered.heading,
      altitude: filtered.altitude,
      altitudeAccuracy:
        typeof pos.coords.altitudeAccuracy === 'number' &&
        Number.isFinite(pos.coords.altitudeAccuracy)
          ? pos.coords.altitudeAccuracy
          : null,
      updatedAt: filtered.timestamp,
    };
    setUserPosition(next);
    return next;
  }, []);

  const ensurePassiveUserWatch = useCallback(() => {
    if (!navigator.geolocation || userPassiveWatchIdRef.current !== null) return;
    userPassiveWatchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        applyUserPosition(pos);
      },
      () => {
        if (userPassiveWatchIdRef.current !== null && navigator.geolocation) {
          navigator.geolocation.clearWatch(userPassiveWatchIdRef.current);
          userPassiveWatchIdRef.current = null;
        }
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: 15000,
      }
    );
  }, [applyUserPosition]);

  // Initial non-blocking high-precision geolocation lock so "Você" converges accurately
  useEffect(() => {
    if (!navigator.geolocation) return;
    let cancelled = false;

    acquireBestPosition({windowMs: 3600, targetAccuracyMeters: 10})
      .then((pos) => {
        if (cancelled) return;
        applyUserPosition(pos);
        ensurePassiveUserWatch();
      })
      .catch(() => {
        // Silent on initial load; user can trigger locate explicitly via "Minha posição"
      });

    return () => {
      cancelled = true;
    };
  }, [applyUserPosition, ensurePassiveUserWatch]);

  // Firebase Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
      setAuthReady(true);
      if (!nextUser) {
        setOwnedTrackers([]);
        setSharedTrackers([]);
        setSelectedPoints([]);
        setGeofences([]);
        setAlerts([]);
        setOwnedSosEvents([]);
        setSharedSosEvents([]);
        setSelectedTrackerId(null);
      }
    });
    return () => unsub();
  }, []);

  // Cleanup geolocation watches on unmount
  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null && navigator.geolocation) {
        clearWatchBg(watchIdRef.current);
        watchIdRef.current = null;
      }
      if (userPassiveWatchIdRef.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(userPassiveWatchIdRef.current);
        userPassiveWatchIdRef.current = null;
      }
    };
  }, []);

  // Combined deduplicated trackers
  const trackers = useMemo(() => {
    const byId: Record<string, Tracker> = {};
    sharedTrackers.forEach((t) => {
      byId[t.id] = t;
    });
    ownedTrackers.forEach((t) => {
      byId[t.id] = t;
    });
    return Object.values(byId).sort((a, b) => {
      if (a.isBroadcasting !== b.isBroadcasting) {
        return a.isBroadcasting ? -1 : 1;
      }
      const aTime = a.lastSeenAt?.toMillis() ?? 0;
      const bTime = b.lastSeenAt?.toMillis() ?? 0;
      return bTime - aTime;
    });
  }, [ownedTrackers, sharedTrackers]);

  // Keep selectedTrackerId valid
  useEffect(() => {
    if (trackers.length === 0) {
      setSelectedTrackerId(null);
      return;
    }
    if (
      !selectedTrackerId ||
      !trackers.some((t) => t.id === selectedTrackerId)
    ) {
      setSelectedTrackerId(trackers[0].id);
    }
  }, [trackers, selectedTrackerId]);

  // Firestore listeners (attached strictly when authenticated)
  useEffect(() => {
    if (!authReady || !user) return;

    const ownedQuery = query(
      collection(db, 'trackers'),
      where('ownerId', '==', user.uid)
    );
    const sharedQuery = query(
      collection(db, 'trackers'),
      where('viewerIds', 'array-contains', user.uid)
    );
    const geofencesQuery = query(
      collection(db, 'geofences'),
      where('ownerId', '==', user.uid)
    );
    const alertsQuery = query(
      collection(db, 'alerts'),
      where('ownerId', '==', user.uid)
    );

    const unsubOwned = onSnapshot(
      ownedQuery,
      (snap) => {
        const list: Tracker[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<Tracker, 'id'>),
        }));
        setOwnedTrackers(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'trackers');
      }
    );

    const unsubShared = onSnapshot(
      sharedQuery,
      (snap) => {
        const list: Tracker[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<Tracker, 'id'>),
        }));
        setSharedTrackers(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'trackers');
      }
    );

    const unsubGeofences = onSnapshot(
      geofencesQuery,
      (snap) => {
        const list: Geofence[] = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<Geofence, 'id'>),
          }))
          .sort(
            (a, b) =>
              (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0)
          );
        setGeofences(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'geofences');
      }
    );

    const unsubAlerts = onSnapshot(
      alertsQuery,
      (snap) => {
        const list: GeofenceAlert[] = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<GeofenceAlert, 'id'>),
          }))
          .sort(
            (a, b) =>
              (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0)
          )
          .slice(0, 40);
        setAlerts(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'alerts');
      }
    );

    const unsubOwnedSos = onSnapshot(
      query(collection(db, 'sosEvents'), where('ownerId', '==', user.uid)),
      (snap) => {
        const list: SosEvent[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<SosEvent, 'id'>),
        }));
        setOwnedSosEvents(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'sosEvents');
      }
    );

    const unsubSharedSos = onSnapshot(
      query(
        collection(db, 'sosEvents'),
        where('viewerIds', 'array-contains', user.uid)
      ),
      (snap) => {
        const list: SosEvent[] = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<SosEvent, 'id'>),
        }));
        setSharedSosEvents(list);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, 'sosEvents');
      }
    );

    return () => {
      unsubOwned();
      unsubShared();
      unsubGeofences();
      unsubAlerts();
      unsubOwnedSos();
      unsubSharedSos();
    };
  }, [authReady, user]);

  // Combined deduplicated active SOS events
  const sosEvents = useMemo(() => {
    const byId: Record<string, SosEvent> = {};
    sharedSosEvents.forEach((s) => {
      byId[s.id] = s;
    });
    ownedSosEvents.forEach((s) => {
      byId[s.id] = s;
    });
    return Object.values(byId).sort(
      (a, b) => (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0)
    );
  }, [ownedSosEvents, sharedSosEvents]);

  const activeSosEvents = useMemo(
    () => sosEvents.filter((s) => s.status === 'active'),
    [sosEvents]
  );

  const ownActiveSos = useMemo(
    () =>
      user
        ? activeSosEvents.find((s) => s.ownerId === user.uid) ?? null
        : null,
    [activeSosEvents, user]
  );

  const activeSosForModal = useMemo(() => {
    if (inspectedSosId) {
      return activeSosEvents.find((s) => s.id === inspectedSosId) ?? null;
    }
    return ownActiveSos;
  }, [inspectedSosId, activeSosEvents, ownActiveSos]);

  const buildTrackPointExtras = useCallback(
    async (opts: {
      lat: number;
      lng: number;
      altitude?: number | null;
      altitudeAccuracy?: number | null;
      distanceFromPrevMeters?: number;
      isSos?: boolean;
    }): Promise<Record<string, unknown>> => {
      const extras: Record<string, unknown> = {};

      if (
        typeof opts.altitude === 'number' &&
        Number.isFinite(opts.altitude) &&
        opts.altitude >= -500 &&
        opts.altitude <= 20000
      ) {
        extras.altitude = Math.round(opts.altitude * 10) / 10;
      }

      if (
        typeof opts.altitudeAccuracy === 'number' &&
        Number.isFinite(opts.altitudeAccuracy) &&
        opts.altitudeAccuracy >= 0 &&
        opts.altitudeAccuracy <= 10000
      ) {
        extras.altitudeAccuracy = Math.round(opts.altitudeAccuracy * 10) / 10;
      }

      if (deviceBatteryRef.current) {
        extras.batteryLevel = Math.max(
          0,
          Math.min(100, Math.round(deviceBatteryRef.current.level))
        );
        extras.batteryCharging = Boolean(deviceBatteryRef.current.charging);
      }

      const cachedAddr = getCachedAddressLabel(opts.lat, opts.lng);
      if (cachedAddr) {
        extras.address = cachedAddr.slice(0, BLUEPRINT_LIMITS.ADDRESS_MAX);
      }

      const weather =
        getCachedWeatherForCoords(opts.lat, opts.lng) ??
        (await fetchWeatherForCoords(opts.lat, opts.lng));
      if (weather) {
        if (weather.temperatureC >= -90 && weather.temperatureC <= 70) {
          extras.weatherTempC = Math.round(weather.temperatureC * 10) / 10;
        }
        if (weather.condition) {
          extras.weatherCondition = weather.condition.slice(
            0,
            BLUEPRINT_LIMITS.WEATHER_COND_MAX
          );
        }
        if (weather.windKmh >= 0 && weather.windKmh <= 500) {
          extras.weatherWindKmh = Math.round(weather.windKmh * 10) / 10;
        }
        if (weather.humidity >= 0 && weather.humidity <= 100) {
          extras.weatherHumidity = Math.round(weather.humidity);
        }
      }

      if (
        typeof opts.distanceFromPrevMeters === 'number' &&
        Number.isFinite(opts.distanceFromPrevMeters) &&
        opts.distanceFromPrevMeters >= 0 &&
        opts.distanceFromPrevMeters <= 20000000
      ) {
        extras.distanceFromPrevMeters = Math.round(opts.distanceFromPrevMeters);
      }

      if (opts.isSos) {
        extras.isSos = true;
      }

      return extras;
    },
    []
  );

  // Selected tracker breadcrumb points listener
  const selectedTrackerObj = useMemo(
    () => trackers.find((t) => t.id === selectedTrackerId) ?? null,
    [trackers, selectedTrackerId]
  );

  useEffect(() => {
    if (!authReady || !user || !selectedTrackerObj) {
      setSelectedPoints([]);
      return;
    }

    const isOwner = selectedTrackerObj.ownerId === user.uid;
    const pointsPath = `trackers/${selectedTrackerObj.id}/points`;
    const pointsQuery = isOwner
      ? query(collection(db, pointsPath), where('ownerId', '==', user.uid))
      : query(
          collection(db, pointsPath),
          where('viewerIds', 'array-contains', user.uid)
        );

    const unsub = onSnapshot(
      pointsQuery,
      (snap) => {
        const pts: TrackPoint[] = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<TrackPoint, 'id'>),
          }))
          .sort(
            (a, b) =>
              (a.recordedAt?.toMillis() ?? 0) - (b.recordedAt?.toMillis() ?? 0)
          )
          .slice(-200);
        setSelectedPoints(pts);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, pointsPath);
      }
    );

    return () => unsub();
  }, [authReady, user, selectedTrackerObj?.id, selectedTrackerObj?.ownerId]);

  // Monitor geofence enter/exit transitions for owned trackers
  useEffect(() => {
    if (!user || ownedTrackers.length === 0 || geofences.length === 0) return;

    const activeFences = geofences.filter((g) => g.active);
    ownedTrackers.forEach((tracker) => {
      activeFences.forEach((fence) => {
        const key = `${tracker.id}::${fence.id}`;
        const distance = haversineDistanceMeters(
          {lat: tracker.lat, lng: tracker.lng},
          {lat: fence.lat, lng: fence.lng}
        );
        const isInside = distance <= fence.radiusMeters;
        const previous = geofenceInsideMapRef.current[key];

        if (previous === undefined) {
          geofenceInsideMapRef.current[key] = isInside;
          return;
        }

        if (previous !== isInside) {
          geofenceInsideMapRef.current[key] = isInside;
          const alertId = generateDocId('alert');
          setDoc(doc(db, 'alerts', alertId), {
            ownerId: user.uid,
            trackerId: tracker.id,
            trackerName: sanitizeName(tracker.name),
            geofenceId: fence.id,
            geofenceName: sanitizeName(fence.name),
            eventType: isInside ? 'enter' : 'exit',
            distanceMeters: Math.round(distance),
            acknowledged: false,
            createdAt: serverTimestamp(),
          }).catch((error) => {
            handleFirestoreError(
              error,
              OperationType.CREATE,
              `alerts/${alertId}`
            );
          });
        }
      });
    });
  }, [user, ownedTrackers, geofences]);

  const handleSignIn = useCallback(async () => {
    try {
      await signInWithGoogle();
      setBannerFeedback(null);
    } catch (err) {
      console.error('Erro no login Google:', err);
      setBannerFeedback(
        'Não foi possível concluir o login com Google. Tente novamente.'
      );
    }
  }, []);

  const stopGpsWatch = useCallback(
    async (trackerToStop?: Tracker) => {
      if (watchIdRef.current !== null && navigator.geolocation) {
        clearWatchBg(watchIdRef.current);
        watchIdRef.current = null;
      }
      const targetId = trackerToStop?.id ?? activeBroadcastTrackerId;
      setActiveBroadcastTrackerId(null);

      if (targetId && user) {
        const path = `trackers/${targetId}`;
        try {
          await updateDoc(doc(db, 'trackers', targetId), {
            isBroadcasting: false,
            lastSeenAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.UPDATE, path);
        }
      }

      ensurePassiveUserWatch();
    },
    [activeBroadcastTrackerId, user, ensurePassiveUserWatch]
  );

  const handleSignOut = useCallback(async () => {
    await stopGpsWatch();
    await signOutEverywhere();
  }, [stopGpsWatch]);

  // Sync device battery changes to actively broadcasting tracker even while stationary
  useEffect(() => {
    if (!user || !activeBroadcastTrackerId || !deviceBattery) return;

    updateDoc(doc(db, 'trackers', activeBroadcastTrackerId), {
      batteryLevel: deviceBattery.level,
      batteryCharging: deviceBattery.charging,
      updatedAt: serverTimestamp(),
    }).catch((error) => {
      handleFirestoreError(
        error,
        OperationType.UPDATE,
        `trackers/${activeBroadcastTrackerId}`
      );
    });
  }, [user, activeBroadcastTrackerId, deviceBattery?.level, deviceBattery?.charging]);

  const startGpsWatch = useCallback(
    async (tracker: Tracker) => {
      if (!user) return;
      if (!navigator.geolocation) {
        setBannerFeedback(
          'Geolocalização não suportada neste navegador. Use "Marcar no mapa" para atualizar a posição.'
        );
        return;
      }

      if (watchIdRef.current !== null) {
        clearWatchBg(watchIdRef.current);
        watchIdRef.current = null;
      }
      if (userPassiveWatchIdRef.current !== null) {
        navigator.geolocation.clearWatch(userPassiveWatchIdRef.current);
        userPassiveWatchIdRef.current = null;
      }

      setActiveBroadcastTrackerId(tracker.id);
      setSelectedTrackerId(tracker.id);
      setFollowSelected(true);
      lastWriteTimeRef.current = 0;
      lastTrailPointRef.current = null;
      broadcastFilterRef.current.reset();

      const batteryPayload = deviceBatteryRef.current
        ? {
            batteryLevel: deviceBatteryRef.current.level,
            batteryCharging: deviceBatteryRef.current.charging,
          }
        : {};

      try {
        await updateDoc(doc(db, 'trackers', tracker.id), {
          isBroadcasting: true,
          ...batteryPayload,
          lastSeenAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `trackers/${tracker.id}`
        );
      }

      const handlePositionUpdate = async (pos: GeolocationPosition) => {
        const filtered = broadcastFilterRef.current.process(pos);
        if (!filtered || filtered.wasOutlierRejected) {
          return;
        }

        const {lat, lng, accuracy, speed, heading, altitude, timestamp} =
          filtered;
        const altAcc =
          typeof pos.coords.altitudeAccuracy === 'number' &&
          Number.isFinite(pos.coords.altitudeAccuracy)
            ? pos.coords.altitudeAccuracy
            : null;

        setUserPosition({
          lat,
          lng,
          accuracy,
          speed,
          heading,
          altitude,
          altitudeAccuracy: altAcc,
          updatedAt: timestamp,
        });

        const now = Date.now();
        const minIntervalMs = speed >= 0.4 ? 1200 : 2500;
        if (now - lastWriteTimeRef.current < minIntervalMs) return;
        lastWriteTimeRef.current = now;

        const currentBattery = deviceBatteryRef.current
          ? {
              batteryLevel: deviceBatteryRef.current.level,
              batteryCharging: deviceBatteryRef.current.charging,
            }
          : {};

        try {
          await updateDoc(doc(db, 'trackers', tracker.id), {
            lat,
            lng,
            accuracy,
            speed,
            heading,
            isBroadcasting: true,
            ...currentBattery,
            lastSeenAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });

          const prevPt = lastTrailPointRef.current;
          const distFromLast = prevPt
            ? haversineDistanceMeters(prevPt, {lat, lng})
            : Infinity;
          const adaptiveStepMeters = Math.max(5, Math.min(20, accuracy * 0.5));
          const isCoarseWhenHistoryExists =
            prevPt !== null && accuracy > 120 && distFromLast < accuracy;
          const isTimeMovingCheckpoint =
            prevPt !== null &&
            speed >= 1.5 &&
            now - prevPt.time >= 6000 &&
            distFromLast >= 4;
          const movedEnough =
            !isCoarseWhenHistoryExists &&
            (distFromLast >= adaptiveStepMeters || isTimeMovingCheckpoint);

          if (movedEnough) {
            lastTrailPointRef.current = {lat, lng, time: now};
            const pointId = generateDocId('pt');
            const extras = await buildTrackPointExtras({
              lat,
              lng,
              altitude,
              altitudeAccuracy: altAcc,
              distanceFromPrevMeters: Number.isFinite(distFromLast)
                ? distFromLast
                : 0,
            });
            await setDoc(doc(db, `trackers/${tracker.id}/points`, pointId), {
              trackerId: tracker.id,
              ownerId: user.uid,
              viewerIds: tracker.viewerIds.slice(
                0,
                BLUEPRINT_LIMITS.MAX_VIEWERS
              ),
              lat,
              lng,
              accuracy,
              speed,
              heading,
              ...extras,
              source: 'gps',
              recordedAt: serverTimestamp(),
            });
          }
        } catch (error) {
          handleFirestoreError(
            error,
            OperationType.UPDATE,
            `trackers/${tracker.id}`
          );
        }
      };

      // Trigger an immediate multi-sample high-precision burst lock and pan map
      acquireBestPosition({windowMs: 3200, targetAccuracyMeters: 10})
        .then((pos) => {
          setFocusRequest({
            lat: clampLat(pos.coords.latitude),
            lng: clampLng(pos.coords.longitude),
            zoom: 17,
            nonce: Date.now(),
          });
          return handlePositionUpdate(pos);
        })
        .catch(() => {
          // watchPosition below handles fallback & error reporting
        });

      const attachWatch = (highAccuracy: boolean) => {
        watchIdRef.current = watchPositionBg(
          (pos) => {
            void handlePositionUpdate(pos);
          },
          (geoErr) => {
            if (
              highAccuracy &&
              geoErr.code !== geoErr.PERMISSION_DENIED &&
              watchIdRef.current !== null
            ) {
              clearWatchBg(watchIdRef.current);
              watchIdRef.current = null;
              attachWatch(false);
              return;
            }
            console.error('Erro de GPS:', geoErr);
            setBannerFeedback(
              geoErr.code === geoErr.PERMISSION_DENIED
                ? 'Permissão de GPS negada pelo navegador. Autorize a localização na barra do navegador ou use "Marcar no mapa".'
                : 'Sinal de GPS indisponível no momento.'
            );
            void stopGpsWatch(tracker);
          },
          {
            enableHighAccuracy: highAccuracy,
            maximumAge: 0,
            timeout: 15000,
          }
        );
      };

      attachWatch(true);
    },
    [user, stopGpsWatch]
  );

  const handleCreateTracker = useCallback(
    async (data: {
      name: string;
      category: TrackerCategory;
      color: string;
    }) => {
      if (!user) return;
      setIsCreatingTracker(true);
      try {
        const trackerId = generateDocId('trk');
        const shareCode = generateShareCode();
        const safeName = sanitizeName(data.name);
        const ownerName = (user.displayName || user.email || 'Usuário')
          .trim()
          .slice(0, BLUEPRINT_LIMITS.OWNER_NAME_MAX);

        const initialLat = userPosition?.lat ?? -23.55052;
        const initialLng = userPosition?.lng ?? -46.633308;

        const batteryPayload = deviceBatteryRef.current
          ? {
              batteryLevel: deviceBatteryRef.current.level,
              batteryCharging: deviceBatteryRef.current.charging,
            }
          : {};

        const batch = writeBatch(db);
        batch.set(doc(db, 'trackers', trackerId), {
          name: safeName,
          category: data.category,
          color: data.color,
          shareCode,
          ownerId: user.uid,
          ownerName,
          viewerIds: [],
          isBroadcasting: false,
          lat: initialLat,
          lng: initialLng,
          accuracy: userPosition?.accuracy ?? 25,
          speed: 0,
          heading: 0,
          ...batteryPayload,
          lastSeenAt: serverTimestamp(),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        batch.set(doc(db, 'shareInvites', shareCode), {
          trackerId,
          ownerId: user.uid,
          trackerName: safeName,
          active: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        await batch.commit();

        const initialPointId = generateDocId('pt');
        const initialExtras = await buildTrackPointExtras({
          lat: initialLat,
          lng: initialLng,
          altitude: userPosition?.altitude,
          altitudeAccuracy: userPosition?.altitudeAccuracy,
          distanceFromPrevMeters: 0,
        });
        await setDoc(doc(db, `trackers/${trackerId}/points`, initialPointId), {
          trackerId,
          ownerId: user.uid,
          viewerIds: [],
          lat: initialLat,
          lng: initialLng,
          accuracy: userPosition?.accuracy ?? 25,
          speed: 0,
          heading: 0,
          ...initialExtras,
          source: userPosition ? 'gps' : 'manual',
          recordedAt: serverTimestamp(),
        });

        setSelectedTrackerId(trackerId);
        setShowNewTrackerModal(false);
        setFocusRequest({
          lat: initialLat,
          lng: initialLng,
          zoom: 15,
          nonce: Date.now(),
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, 'trackers');
      } finally {
        setIsCreatingTracker(false);
      }
    },
    [user, userPosition, buildTrackPointExtras]
  );

  const handleMapPickLocation = useCallback(
    async (coords: {lat: number; lng: number}) => {
      if (!user) return;
      const lat = clampLat(coords.lat);
      const lng = clampLng(coords.lng);

      if (pickMode.type === 'create-geofence') {
        setPickedGeofenceCenter({lat, lng});
        setPickMode({type: 'none'});
        return;
      }

      if (pickMode.type === 'move-tracker') {
        const target = trackers.find((t) => t.id === pickMode.trackerId);
        setPickMode({type: 'none'});
        if (!target || target.ownerId !== user.uid) return;

        try {
          await updateDoc(doc(db, 'trackers', target.id), {
            lat,
            lng,
            accuracy: 10,
            speed: 0,
            lastSeenAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });

          const pointId = generateDocId('pt');
          const distFromPrev = haversineDistanceMeters(
            {lat: target.lat, lng: target.lng},
            {lat, lng}
          );
          const extras = await buildTrackPointExtras({
            lat,
            lng,
            distanceFromPrevMeters: distFromPrev,
          });
          await setDoc(doc(db, `trackers/${target.id}/points`, pointId), {
            trackerId: target.id,
            ownerId: user.uid,
            viewerIds: target.viewerIds.slice(0, BLUEPRINT_LIMITS.MAX_VIEWERS),
            lat,
            lng,
            accuracy: 10,
            speed: 0,
            heading: 0,
            ...extras,
            source: 'manual',
            recordedAt: serverTimestamp(),
          });
        } catch (error) {
          handleFirestoreError(
            error,
            OperationType.UPDATE,
            `trackers/${target.id}`
          );
        }
      }
    },
    [user, pickMode, trackers, buildTrackPointExtras]
  );

  const handleJoinByShareCode = useCallback(
    async (rawCode: string) => {
      if (!user) return;
      const code = rawCode.trim().toUpperCase();
      if (!BLUEPRINT_LIMITS.SHARE_CODE_PATTERN.test(code)) {
        setJoinMessage({
          type: 'error',
          text: 'Formato inválido. Use o padrão PV-XXXXXX.',
        });
        return;
      }

      try {
        const inviteSnap = await getDoc(doc(db, 'shareInvites', code));
        if (!inviteSnap.exists()) {
          setJoinMessage({
            type: 'error',
            text: 'Código não encontrado ou expirado.',
          });
          return;
        }
        const invite = inviteSnap.data() as {
          trackerId: string;
          ownerId: string;
          trackerName: string;
          active: boolean;
        };

        if (!invite.active) {
          setJoinMessage({
            type: 'error',
            text: 'Este código de compartilhamento está desativado.',
          });
          return;
        }

        if (invite.ownerId === user.uid) {
          setSelectedTrackerId(invite.trackerId);
          setJoinMessage({
            type: 'success',
            text: `Você já é o proprietário de ${invite.trackerName}.`,
          });
          return;
        }

        await updateDoc(doc(db, 'trackers', invite.trackerId), {
          viewerIds: arrayUnion(user.uid),
          updatedAt: serverTimestamp(),
        });

        setSelectedTrackerId(invite.trackerId);
        setJoinMessage({
          type: 'success',
          text: `Agora acompanhando ${invite.trackerName} em tempo real.`,
        });
      } catch (error) {
        console.error('Erro ao entrar por código:', error);
        setJoinMessage({
          type: 'error',
          text: 'Não foi possível vincular este rastreador.',
        });
      }
    },
    [user]
  );

  // Auto-join tracker when user is authenticated and came via ?codigo=PV-...
  useEffect(() => {
    if (!authReady || !user || !pendingShareCode) return;
    const codeToJoin = pendingShareCode;
    setPendingShareCode(null);

    if (typeof window !== 'undefined') {
      const url = new URL(window.location.href);
      if (url.searchParams.has('codigo')) {
        url.searchParams.delete('codigo');
        window.history.replaceState({}, '', url.toString());
      }
    }

    void handleJoinByShareCode(codeToJoin).then(() => {
      setActiveTab('devices');
      setIsMenuOpen(true);
    });
  }, [authReady, user, pendingShareCode, handleJoinByShareCode]);

  const handleDeleteTracker = useCallback(
    async (tracker: Tracker) => {
      if (!user || tracker.ownerId !== user.uid) return;
      if (activeBroadcastTrackerId === tracker.id) {
        await stopGpsWatch(tracker);
      }
      try {
        const batch = writeBatch(db);
        batch.delete(doc(db, 'trackers', tracker.id));
        batch.delete(doc(db, 'shareInvites', tracker.shareCode));
        await batch.commit();
        if (routeTargetTracker?.id === tracker.id) {
          setRouteTargetTracker(null);
        }
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.DELETE,
          `trackers/${tracker.id}`
        );
      }
    },
    [user, activeBroadcastTrackerId, stopGpsWatch, routeTargetTracker]
  );

  const handleLeaveSharedTracker = useCallback(
    async (tracker: Tracker) => {
      if (!user) return;
      try {
        await updateDoc(doc(db, 'trackers', tracker.id), {
          viewerIds: arrayRemove(user.uid),
          updatedAt: serverTimestamp(),
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `trackers/${tracker.id}`
        );
      }
    },
    [user]
  );

  const handleClearHistory = useCallback(
    async (tracker: Tracker) => {
      if (!user || tracker.ownerId !== user.uid) return;
      const pointsPath = `trackers/${tracker.id}/points`;
      try {
        const snap = await getDocs(
          query(collection(db, pointsPath), where('ownerId', '==', user.uid))
        );
        const docs = snap.docs;
        for (let i = 0; i < docs.length; i += 450) {
          const chunk = docs.slice(i, i + 450);
          const batch = writeBatch(db);
          chunk.forEach((d) => batch.delete(d.ref));
          await batch.commit();
        }
        setSelectedHistoryPointId(null);
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, pointsPath);
      }
    },
    [user]
  );

  const handleCreateGeofence = useCallback(
    async (data: {name: string; radiusMeters: number; color: string}) => {
      if (!user) return;
      const center =
        pickedGeofenceCenter ??
        (selectedTrackerObj
          ? {lat: selectedTrackerObj.lat, lng: selectedTrackerObj.lng}
          : userPosition
            ? {lat: userPosition.lat, lng: userPosition.lng}
            : {lat: -23.55052, lng: -46.633308});

      const fenceId = generateDocId('geo');
      try {
        await setDoc(doc(db, 'geofences', fenceId), {
          ownerId: user.uid,
          name: sanitizeName(data.name, 'Zona Segura'),
          lat: clampLat(center.lat),
          lng: clampLng(center.lng),
          radiusMeters: Math.max(
            BLUEPRINT_LIMITS.RADIUS_MIN_M,
            Math.min(BLUEPRINT_LIMITS.RADIUS_MAX_M, data.radiusMeters)
          ),
          color: data.color,
          active: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        setPickedGeofenceCenter(null);
        setFocusRequest({
          lat: center.lat,
          lng: center.lng,
          zoom: 15,
          nonce: Date.now(),
        });
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.CREATE,
          `geofences/${fenceId}`
        );
      }
    },
    [user, pickedGeofenceCenter, selectedTrackerObj, userPosition]
  );

  const handleToggleGeofence = useCallback(async (fence: Geofence) => {
    try {
      await updateDoc(doc(db, 'geofences', fence.id), {
        active: !fence.active,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(
        error,
        OperationType.UPDATE,
        `geofences/${fence.id}`
      );
    }
  }, []);

  const handleDeleteGeofence = useCallback(async (fence: Geofence) => {
    try {
      await deleteDoc(doc(db, 'geofences', fence.id));
    } catch (error) {
      handleFirestoreError(
        error,
        OperationType.DELETE,
        `geofences/${fence.id}`
      );
    }
  }, []);

  const handleAcknowledgeAlert = useCallback(async (alertItem: GeofenceAlert) => {
    try {
      await updateDoc(doc(db, 'alerts', alertItem.id), {
        acknowledged: true,
      });
    } catch (error) {
      handleFirestoreError(
        error,
        OperationType.UPDATE,
        `alerts/${alertItem.id}`
      );
    }
  }, []);

  const handleDeleteAlert = useCallback(async (alertItem: GeofenceAlert) => {
    try {
      await deleteDoc(doc(db, 'alerts', alertItem.id));
    } catch (error) {
      handleFirestoreError(
        error,
        OperationType.DELETE,
        `alerts/${alertItem.id}`
      );
    }
  }, []);

  const handleLocateMe = useCallback(async () => {
    if (!navigator.geolocation) {
      setBannerFeedback('Geolocalização não disponível neste navegador.');
      return;
    }
    setLocatingUser(true);
    userFilterRef.current.reset();
    try {
      const pos = await acquireBestPosition({
        windowMs: 3800,
        targetAccuracyMeters: 10,
      });
      const nextPos = applyUserPosition(pos);
      const lat = nextPos?.lat ?? clampLat(pos.coords.latitude);
      const lng = nextPos?.lng ?? clampLng(pos.coords.longitude);
      setFocusRequest({lat, lng, zoom: 17, nonce: Date.now()});
      setBannerFeedback(null);
      if (!activeBroadcastTrackerId) {
        ensurePassiveUserWatch();
      }
    } catch (err) {
      const geoErr = err as GeolocationPositionError;
      if (geoErr && geoErr.code === geoErr.PERMISSION_DENIED) {
        setBannerFeedback(
          'Permissão de localização bloqueada no navegador. Libere o acesso à localização no ícone ao lado da barra de endereço e tente novamente.'
        );
      } else {
        setBannerFeedback(
          'Não foi possível obter sua localização atual. Verifique se o GPS ou serviços de localização do dispositivo estão ativados.'
        );
      }
    } finally {
      setLocatingUser(false);
    }
  }, [applyUserPosition, ensurePassiveUserWatch, activeBroadcastTrackerId]);

  const handleOpenSos = useCallback(
    (targetSos?: SosEvent) => {
      if (!user) {
        setIsMenuOpen(true);
        setBannerFeedback(
          'Entre com sua conta Google para enviar alerta SOS em tempo real com câmera e áudio.'
        );
        return;
      }
      setInspectedSosId(targetSos ? targetSos.id : ownActiveSos?.id ?? null);
      setShowSosModal(true);
    },
    [user, ownActiveSos]
  );

  const handleActivateSos = useCallback(
    async (options: {
      message: string;
      cameraEnabled: boolean;
      micEnabled: boolean;
    }) => {
      if (!user) return;
      const ownedPrimary =
        ownedTrackers.find((t) => t.id === selectedTrackerId) ??
        ownedTrackers[0] ??
        null;

      let lat = userPosition?.lat ?? ownedPrimary?.lat ?? -23.55052;
      let lng = userPosition?.lng ?? ownedPrimary?.lng ?? -46.633308;
      let accuracy = userPosition?.accuracy ?? ownedPrimary?.accuracy ?? 25;
      let speed = userPosition?.speed ?? ownedPrimary?.speed ?? 0;
      let altitude = userPosition?.altitude ?? null;

      if (!userPosition && navigator.geolocation) {
        try {
          const pos = await acquireBestPosition({
            windowMs: 1800,
            targetAccuracyMeters: 15,
          });
          const next = applyUserPosition(pos);
          if (next) {
            lat = next.lat;
            lng = next.lng;
            accuracy = next.accuracy;
            speed = next.speed ?? 0;
            altitude = next.altitude ?? null;
          }
        } catch {
          // Continue with fallback coords so SOS never stalls
        }
      }

      const viewerSet = new Set<string>();
      ownedTrackers.forEach((t) => {
        t.viewerIds.forEach((vid) => {
          if (vid && vid !== user.uid) viewerSet.add(vid);
        });
      });
      const viewerIds = Array.from(viewerSet).slice(
        0,
        BLUEPRINT_LIMITS.MAX_VIEWERS
      );

      const weather =
        getCachedWeatherForCoords(lat, lng) ??
        (await fetchWeatherForCoords(lat, lng));
      const weatherSummary = formatWeatherSummary(weather).slice(0, 120);
      const cachedAddr = getCachedAddressLabel(lat, lng);

      const sosId = generateDocId('sos');
      const sosPayload: Record<string, unknown> = {
        ownerId: user.uid,
        ownerName: (user.displayName || user.email || 'Usuário')
          .trim()
          .slice(0, BLUEPRINT_LIMITS.OWNER_NAME_MAX),
        viewerIds,
        status: 'active',
        message: options.message
          .trim()
          .slice(0, BLUEPRINT_LIMITS.SOS_MESSAGE_MAX),
        lat: clampLat(lat),
        lng: clampLng(lng),
        accuracy: Math.max(0, Math.min(100000, accuracy)),
        cameraEnabled: options.cameraEnabled,
        micEnabled: options.micEnabled,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      if (ownedPrimary) {
        sosPayload.trackerId = ownedPrimary.id;
        sosPayload.trackerName = sanitizeName(ownedPrimary.name);
      }
      if (
        typeof altitude === 'number' &&
        Number.isFinite(altitude) &&
        altitude >= -500 &&
        altitude <= 20000
      ) {
        sosPayload.altitude = Math.round(altitude * 10) / 10;
      }
      if (typeof speed === 'number' && Number.isFinite(speed) && speed >= 0) {
        sosPayload.speed = Math.min(1000, Math.round(speed * 10) / 10);
      }
      if (cachedAddr) {
        sosPayload.address = cachedAddr.slice(0, BLUEPRINT_LIMITS.ADDRESS_MAX);
      }
      if (weatherSummary) {
        sosPayload.weatherSummary = weatherSummary;
      }
      if (deviceBatteryRef.current) {
        sosPayload.batteryLevel = Math.max(
          0,
          Math.min(100, Math.round(deviceBatteryRef.current.level))
        );
      }

      try {
        await setDoc(doc(db, 'sosEvents', sosId), sosPayload);
        setInspectedSosId(sosId);

        if (ownedPrimary) {
          const ptId = generateDocId('pt');
          const extras = await buildTrackPointExtras({
            lat,
            lng,
            altitude,
            isSos: true,
          });
          await setDoc(doc(db, `trackers/${ownedPrimary.id}/points`, ptId), {
            trackerId: ownedPrimary.id,
            ownerId: user.uid,
            viewerIds: ownedPrimary.viewerIds.slice(
              0,
              BLUEPRINT_LIMITS.MAX_VIEWERS
            ),
            lat: clampLat(lat),
            lng: clampLng(lng),
            accuracy: Math.max(0, Math.min(100000, accuracy)),
            speed: Math.max(0, Math.min(1000, speed)),
            heading: userPosition?.heading ?? 0,
            ...extras,
            source: 'sos',
            recordedAt: serverTimestamp(),
          });

          if (activeBroadcastTrackerId !== ownedPrimary.id) {
            void startGpsWatch(ownedPrimary);
          }
        }
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.CREATE,
          `sosEvents/${sosId}`
        );
      }
    },
    [
      user,
      ownedTrackers,
      selectedTrackerId,
      userPosition,
      applyUserPosition,
      buildTrackPointExtras,
      activeBroadcastTrackerId,
      startGpsWatch,
    ]
  );

  const handleUpdateSosMedia = useCallback(
    async (
      sos: SosEvent,
      patch: {cameraEnabled?: boolean; micEnabled?: boolean; message?: string}
    ) => {
      if (!user || sos.ownerId !== user.uid || sos.status !== 'active') return;
      const updatePayload: Record<string, unknown> = {
        updatedAt: serverTimestamp(),
      };
      if (typeof patch.cameraEnabled === 'boolean') {
        updatePayload.cameraEnabled = patch.cameraEnabled;
      }
      if (typeof patch.micEnabled === 'boolean') {
        updatePayload.micEnabled = patch.micEnabled;
      }
      if (typeof patch.message === 'string' && patch.message.trim()) {
        updatePayload.message = patch.message
          .trim()
          .slice(0, BLUEPRINT_LIMITS.SOS_MESSAGE_MAX);
      }
      try {
        await updateDoc(doc(db, 'sosEvents', sos.id), updatePayload);
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `sosEvents/${sos.id}`
        );
      }
    },
    [user]
  );

  const handleResolveSos = useCallback(
    async (sos: SosEvent) => {
      if (!user || sos.ownerId !== user.uid || sos.status !== 'active') return;
      try {
        await updateDoc(doc(db, 'sosEvents', sos.id), {
          status: 'resolved',
          cameraEnabled: false,
          micEnabled: false,
          resolvedAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        setShowSosModal(false);
        setInspectedSosId(null);
      } catch (error) {
        handleFirestoreError(
          error,
          OperationType.UPDATE,
          `sosEvents/${sos.id}`
        );
      }
    },
    [user]
  );

  // Continuously sync live GPS, weather, address, and battery into own active SOS event
  useEffect(() => {
    if (!user || !ownActiveSos || ownActiveSos.status !== 'active' || !userPosition) {
      return;
    }
    const now = Date.now();
    if (now - lastSosSyncTimeRef.current < 3000) return;
    lastSosSyncTimeRef.current = now;

    const patch: Record<string, unknown> = {
      lat: clampLat(userPosition.lat),
      lng: clampLng(userPosition.lng),
      accuracy: Math.max(0, Math.min(100000, userPosition.accuracy)),
      updatedAt: serverTimestamp(),
    };
    if (
      typeof userPosition.altitude === 'number' &&
      Number.isFinite(userPosition.altitude) &&
      userPosition.altitude >= -500 &&
      userPosition.altitude <= 20000
    ) {
      patch.altitude = Math.round(userPosition.altitude * 10) / 10;
    }
    if (typeof userPosition.speed === 'number' && userPosition.speed >= 0) {
      patch.speed = Math.min(1000, Math.round(userPosition.speed * 10) / 10);
    }
    const addr = getCachedAddressLabel(userPosition.lat, userPosition.lng);
    if (addr) {
      patch.address = addr.slice(0, BLUEPRINT_LIMITS.ADDRESS_MAX);
    }
    const w = getCachedWeatherForCoords(userPosition.lat, userPosition.lng);
    if (w) {
      patch.weatherSummary = formatWeatherSummary(w).slice(0, 120);
    }
    if (deviceBattery) {
      patch.batteryLevel = Math.max(0, Math.min(100, deviceBattery.level));
    }

    updateDoc(doc(db, 'sosEvents', ownActiveSos.id), patch).catch((error) => {
      handleFirestoreError(
        error,
        OperationType.UPDATE,
        `sosEvents/${ownActiveSos.id}`
      );
    });
  }, [user, ownActiveSos, userPosition, deviceBattery]);

  const unacknowledgedAlerts = useMemo(
    () => alerts.filter((a) => !a.acknowledged).length,
    [alerts]
  );

  const lowBatteryTrackers = useMemo(
    () =>
      trackers.filter(
        (t) =>
          typeof t.batteryLevel === 'number' &&
          t.batteryLevel < LOW_BATTERY_THRESHOLD
      ),
    [trackers]
  );

  const isLocalBatteryLow =
    deviceBattery !== null && deviceBattery.level < LOW_BATTERY_THRESHOLD;

  const batteryAlertKey = useMemo(() => {
    if (!isLocalBatteryLow && lowBatteryTrackers.length === 0) return null;
    const localPart = isLocalBatteryLow
      ? `local:${deviceBattery.level}:${deviceBattery.charging}`
      : '';
    const trackersPart = lowBatteryTrackers
      .map((t) => `${t.id}:${Math.round(t.batteryLevel ?? 0)}`)
      .join(',');
    return `${localPart}|${trackersPart}`;
  }, [isLocalBatteryLow, deviceBattery, lowBatteryTrackers]);

  return (
    <ErrorBoundary>
      <div className="h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden transition-colors">
        {/* Mandatory Case A Demo Key Quota Exceeded Banner */}
        {quotaExceeded && (
          <div className="bg-amber-50 dark:bg-amber-950/85 border-b border-amber-200 dark:border-amber-900 text-amber-900 dark:text-amber-200 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
            <span>
              Google Maps Platform quota reached. If you are the app owner,
              visit{' '}
              <a
                href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-semibold text-amber-950 dark:text-amber-100 hover:text-amber-800 dark:hover:text-white"
              >
                maps developer site
              </a>{' '}
              for instructions to update your account.
            </span>
          </div>
        )}

        {/* Strict 3-Zone Top Bar Contract */}
        <header className="h-14 shrink-0 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 flex items-center justify-between gap-8">
          {/* Zone 1: Single-element Brand Wordmark */}
          <a
            href="#mapa"
            onClick={(e) => {
              e.preventDefault();
              setIsMenuOpen(false);
            }}
            className="text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap shrink-0"
          >
            PontoVivo
          </a>

          {/* Zone 2: Clean single-line text nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            <button
              type="button"
              onClick={() => setIsMenuOpen(false)}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                !isMenuOpen
                  ? 'text-blue-600 dark:text-blue-400 underline underline-offset-8 decoration-2'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Mapa
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('devices');
                setIsMenuOpen(true);
              }}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                isMenuOpen && activeTab === 'devices'
                  ? 'text-blue-600 dark:text-blue-400 underline underline-offset-8 decoration-2'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Dispositivos
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('history');
                setIsMenuOpen(true);
              }}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                isMenuOpen && activeTab === 'history'
                  ? 'text-blue-600 dark:text-blue-400 underline underline-offset-8 decoration-2'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Histórico
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('geofences');
                setIsMenuOpen(true);
              }}
              className={`py-1 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                isMenuOpen && activeTab === 'geofences'
                  ? 'text-blue-600 dark:text-blue-400 underline underline-offset-8 decoration-2'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Cercas
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('alerts');
                setIsMenuOpen(true);
              }}
              className={`py-1 inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                isMenuOpen && activeTab === 'alerts'
                  ? 'text-blue-600 dark:text-blue-400 underline underline-offset-8 decoration-2'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Alertas
              {unacknowledgedAlerts > 0 && (
                <span className="text-xs font-mono tabular-nums text-amber-700 dark:text-amber-400">
                  ({unacknowledgedAlerts})
                </span>
              )}
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center shrink-0">
            {user ? (
              <button
                type="button"
                onClick={() => setShowNewTrackerModal(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Plus className="w-4 h-4" />
                Novo rastreador
              </button>
            ) : (
              <button
                type="button"
                onClick={() => void handleSignIn()}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-slate-900 dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                Entrar com Google
              </button>
            )}
          </div>
        </header>

        {/* Low battery (< 20%) alert banner */}
        {batteryAlertKey && dismissedBatteryAlertKey !== batteryAlertKey && (
          <div
            role="alert"
            className="bg-red-50 dark:bg-red-950/75 border-b border-red-200 dark:border-red-900 px-4 py-2 text-xs text-red-900 dark:text-red-100 flex items-center justify-between gap-3 shrink-0"
          >
            <div className="flex items-center gap-2 min-w-0">
              <BatteryLow className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0" />
              <span className="truncate">
                <strong className="font-semibold">
                  Alerta de bateria baixa (&lt; 20%):
                </strong>{' '}
                {[
                  ...(isLocalBatteryLow && deviceBattery
                    ? [
                        `Este dispositivo (${deviceBattery.level}%${
                          deviceBattery.charging ? ', carregando' : ''
                        })`,
                      ]
                    : []),
                  ...lowBatteryTrackers.map(
                    (t) =>
                      `${t.name} (${Math.round(t.batteryLevel ?? 0)}%${
                        t.batteryCharging ? ', carregando' : ''
                      })`
                  ),
                ].join(' · ')}
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {lowBatteryTrackers[0] && (
                <button
                  type="button"
                  onClick={() => {
                    const target = lowBatteryTrackers[0];
                    setSelectedTrackerId(target.id);
                    setFocusRequest({
                      lat: target.lat,
                      lng: target.lng,
                      zoom: 16,
                      nonce: Date.now(),
                    });
                  }}
                  className="font-medium underline text-red-800 dark:text-red-200 hover:text-red-950 dark:hover:text-white cursor-pointer whitespace-nowrap"
                >
                  Focar no mapa
                </button>
              )}
              <button
                type="button"
                onClick={() => setDismissedBatteryAlertKey(batteryAlertKey)}
                aria-label="Dispensar alerta de bateria baixa"
                className="p-1 text-red-700 dark:text-red-300 hover:text-red-950 dark:hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Inline non-blocking feedback banner */}
        {bannerFeedback && (
          <div className="bg-amber-50 dark:bg-amber-950/75 border-b border-amber-200 dark:border-amber-900 px-4 py-2 text-xs text-amber-900 dark:text-amber-100 flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-700 dark:text-amber-400 shrink-0" />
              <span>{bannerFeedback}</span>
            </div>
            <button
              type="button"
              onClick={() => setBannerFeedback(null)}
              aria-label="Fechar aviso"
              className="p-1 text-amber-700 dark:text-amber-300 hover:text-amber-950 dark:hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Active unacknowledged alert notification strip */}
        {unacknowledgedAlerts > 0 && !(isMenuOpen && activeTab === 'alerts') && (
          <div className="bg-blue-50 dark:bg-blue-950/60 border-b border-blue-200 dark:border-blue-900 px-4 py-2 text-xs text-blue-900 dark:text-blue-100 flex items-center justify-between gap-3 shrink-0">
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
              <span>
                {unacknowledgedAlerts} alerta(s) de cerca virtual não lido(s).
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setActiveTab('alerts');
                setIsMenuOpen(true);
              }}
              className="font-medium underline hover:text-blue-700 dark:hover:text-blue-300 cursor-pointer whitespace-nowrap"
            >
              Ver alertas
            </button>
          </div>
        )}

        {/* Urgent Active SOS Alert Banner */}
        {activeSosEvents.length > 0 && (
          <div
            role="alert"
            className="bg-red-600 dark:bg-red-700 text-white px-4 py-2.5 text-xs flex flex-wrap items-center justify-between gap-2 shrink-0 shadow-md"
          >
            <div className="flex items-center gap-2 min-w-0">
              <Siren className="w-4 h-4 animate-pulse shrink-0" />
              <span className="truncate font-medium">
                <strong className="font-bold">
                  {activeSosEvents[0].ownerId === user?.uid
                    ? 'SEU SOS ESTÁ ATIVO:'
                    : `EMERGÊNCIA SOS DE ${activeSosEvents[0].ownerName.toUpperCase()}:`}
                </strong>{' '}
                {activeSosEvents[0].address ||
                  `${activeSosEvents[0].lat.toFixed(5)}, ${activeSosEvents[0].lng.toFixed(5)}`}
                {activeSosEvents[0].weatherSummary
                  ? ` · ${activeSosEvents[0].weatherSummary}`
                  : ''}
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  const target = activeSosEvents[0];
                  setFocusRequest({
                    lat: target.lat,
                    lng: target.lng,
                    zoom: 17,
                    nonce: Date.now(),
                  });
                }}
                className="px-2.5 py-1 rounded-md bg-white/15 hover:bg-white/25 font-medium transition-colors cursor-pointer whitespace-nowrap"
              >
                Focar no mapa
              </button>
              <button
                type="button"
                onClick={() => handleOpenSos(activeSosEvents[0])}
                className="px-2.5 py-1 rounded-md bg-white text-red-700 hover:bg-red-50 font-bold transition-colors cursor-pointer whitespace-nowrap"
              >
                Abrir SOS / Câmera & Áudio
              </button>
            </div>
          </div>
        )}

        {/* Full-bleed Map Workspace + Click-to-Open Overlay Menu Drawer */}
        <main className="flex-1 relative min-h-0 overflow-hidden">
          <section className="w-full h-full relative">
            <APIProvider
              apiKey={MAPS_API_KEY}
              libraries={MAPS_LIBRARIES}
              language="pt-BR"
              region="BR"
            >
              <TrackingMap
                theme={theme}
                mapStyle={mapStyle}
                onChangeMapStyle={setMapStyle}
                isMenuOpen={isMenuOpen}
                onOpenMenu={() => {
                  if (activeTab === 'map') {
                    setActiveTab('devices');
                  }
                  setIsMenuOpen(true);
                }}
                trackers={trackers}
                selectedTrackerId={selectedTrackerId}
                selectedPoints={selectedPoints}
                selectedHistoryPointId={selectedHistoryPointId}
                onSelectHistoryPoint={setSelectedHistoryPointId}
                geofences={geofences}
                sosEvents={sosEvents}
                hasActiveOwnSos={Boolean(ownActiveSos)}
                userPosition={userPosition}
                deviceBattery={deviceBattery}
                locatingUser={locatingUser}
                pickMode={pickMode}
                routeTargetTracker={routeTargetTracker}
                routeTravelMode={routeTravelMode}
                followSelected={followSelected}
                focusRequest={focusRequest}
                onSelectTracker={(id) => {
                  setSelectedTrackerId(id);
                  setFollowSelected(false);
                }}
                onMapPickLocation={(coords) => void handleMapPickLocation(coords)}
                onCancelPickMode={() => setPickMode({type: 'none'})}
                onStartRouteToTracker={(tracker) =>
                  setRouteTargetTracker(tracker)
                }
                onShareTracker={(tracker) => setShareTargetTracker(tracker)}
                onOpenSos={(sos) => handleOpenSos(sos)}
                onClearRoute={() => setRouteTargetTracker(null)}
                onChangeTravelMode={setRouteTravelMode}
                onToggleFollow={() => setFollowSelected((prev) => !prev)}
                onLocateMe={() => void handleLocateMe()}
              />
            </APIProvider>
          </section>

          <SidebarPanel
            isOpen={isMenuOpen}
            onClose={() => setIsMenuOpen(false)}
            theme={theme}
            onChangeTheme={handleChangeTheme}
            user={user}
            authReady={authReady}
            activeTab={activeTab}
            onSelectTab={(tab) => setActiveTab(tab)}
            trackers={trackers}
            selectedPoints={selectedPoints}
            selectedHistoryPointId={selectedHistoryPointId}
            onSelectHistoryPoint={setSelectedHistoryPointId}
            onClearHistory={handleClearHistory}
            geofences={geofences}
            alerts={alerts}
            selectedTrackerId={selectedTrackerId}
            activeBroadcastTrackerId={activeBroadcastTrackerId}
            userPosition={userPosition}
            locatingUser={locatingUser}
            deviceBattery={deviceBattery}
            pickMode={pickMode}
            pickedGeofenceCenter={pickedGeofenceCenter}
            joinMessage={joinMessage}
            onSignIn={() => void handleSignIn()}
            onSignOut={() => void handleSignOut()}
            onLocateMe={() => void handleLocateMe()}
            onSelectTracker={(id) => {
              setSelectedTrackerId(id);
              setFollowSelected(false);
            }}
            onRequestBroadcast={(tracker) => setConsentTargetTracker(tracker)}
            onStopBroadcast={(tracker) => void stopGpsWatch(tracker)}
            onStartPickTrackerLocation={(tracker) =>
              setPickMode({
                type: 'move-tracker',
                trackerId: tracker.id,
                trackerName: tracker.name,
              })
            }
            onRouteToTracker={(tracker) => setRouteTargetTracker(tracker)}
            onShareTracker={(tracker) => setShareTargetTracker(tracker)}
            onDeleteTracker={(tracker) => void handleDeleteTracker(tracker)}
            onLeaveSharedTracker={(tracker) =>
              void handleLeaveSharedTracker(tracker)
            }
            onJoinByShareCode={handleJoinByShareCode}
            onOpenNewTrackerModal={() => setShowNewTrackerModal(true)}
            onStartPickGeofenceCenter={() =>
              setPickMode({type: 'create-geofence'})
            }
            onCreateGeofence={handleCreateGeofence}
            onToggleGeofence={(fence) => void handleToggleGeofence(fence)}
            onFocusCoords={(lat, lng, zoom) =>
              setFocusRequest({lat, lng, zoom, nonce: Date.now()})
            }
            onDeleteGeofence={(fence) => void handleDeleteGeofence(fence)}
            onAcknowledgeAlert={(alertItem) =>
              void handleAcknowledgeAlert(alertItem)
            }
            onDeleteAlert={(alertItem) => void handleDeleteAlert(alertItem)}
            onOpenSos={() => handleOpenSos()}
            hasActiveOwnSos={Boolean(ownActiveSos)}
          />
        </main>

        {/* Modals */}
        {consentTargetTracker && (
          <ConsentModal
            trackerName={consentTargetTracker.name}
            viewerCount={consentTargetTracker.viewerIds.length}
            onConfirm={() => {
              const target = consentTargetTracker;
              setConsentTargetTracker(null);
              void startGpsWatch(target);
            }}
            onCancel={() => setConsentTargetTracker(null)}
          />
        )}

        {shareTargetTracker && (
          <ShareCodeModal
            tracker={shareTargetTracker}
            onClose={() => setShareTargetTracker(null)}
          />
        )}

        {showNewTrackerModal && (
          <NewTrackerModal
            isSubmitting={isCreatingTracker}
            onCreate={handleCreateTracker}
            onClose={() => setShowNewTrackerModal(false)}
          />
        )}

        {showSosModal && (
          <SosModal
            user={user}
            activeSos={activeSosForModal}
            userPosition={userPosition}
            deviceBattery={deviceBattery}
            currentAddress={
              userPosition
                ? getCachedAddressLabel(userPosition.lat, userPosition.lng)
                : null
            }
            currentWeather={
              userPosition
                ? getCachedWeatherForCoords(userPosition.lat, userPosition.lng)
                : null
            }
            onActivateSos={handleActivateSos}
            onUpdateSosMedia={handleUpdateSosMedia}
            onResolveSos={handleResolveSos}
            onFocusLocation={(lat, lng, zoom) =>
              setFocusRequest({lat, lng, zoom, nonce: Date.now()})
            }
            onClose={() => setShowSosModal(false)}
          />
        )}
      </div>
    </ErrorBoundary>
  );
}
