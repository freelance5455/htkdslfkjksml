import { useEffect, useMemo, useRef, useState } from 'react'
import {
  Bell, BellOff, BookOpen, Check, CheckCheck, ChevronRight, Coffee, Compass,
  Droplets, GraduationCap, LocateFixed, MapPin, Moon, MoreHorizontal,
  Palette, Phone, Plus, Search, Settings, ShowerHead, Sparkles, Star, Sun,
  Sunrise, Tablet, Trash2, Utensils, Volume2, VolumeX, X, MoonStar,
  Clock3, ShieldCheck, WifiOff, LogOut, Play, Pause, Navigation,
} from 'lucide-react'
import { CalculationMethod, Coordinates, Madhab, PrayerTimes, Qibla } from 'adhan'
import { defaultTasks, family, islands, taskIcons, type Profile, type Task } from './data'

const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
const dayShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const prayerNames = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'] as const
const iconOptions: Record<string, typeof Sun> = {
  mosque: MoonStar, sun: Sunrise, coffee: Coffee, tablet: Tablet, book: BookOpen,
  palette: Palette, quran: BookOpen, shower: ShowerHead, utensils: Utensils,
  school: GraduationCap, droplets: Droplets, moon: Moon, star: Star,
}

function localDateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}
function timeInMaldives(date: Date | null) {
  if (!date) return '—'
  return new Intl.DateTimeFormat('en-GB', { timeZone: 'Indian/Maldives', hour: '2-digit', minute: '2-digit', hour12: false }).format(date)
}
function toMinutes(value: string) {
  const [h, m] = value.split(':').map(Number)
  return h * 60 + m
}
function useLocal<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try { const saved = localStorage.getItem(key); return saved ? JSON.parse(saved) : initial } catch { return initial }
  })
  useEffect(() => { localStorage.setItem(key, JSON.stringify(value)) }, [key, value])
  return [value, setValue] as const
}
function Logo({ compact = false }: { compact?: boolean }) {
  return <div className="brand"><span className="brand-mark"><MoonStar size={compact ? 20 : 23} strokeWidth={1.6} /></span><span>barakah<span className="brand-dot">.</span></span></div>
}
function Avatar({ profile, small = false }: { profile: Profile; small?: boolean }) {
  return <span className={`avatar ${small ? 'avatar-small' : ''}`} style={{ '--avatar': profile.color } as React.CSSProperties}>{profile.initials}</span>
}
function ProgressRing({ value, size = 46, stroke = 4 }: { value: number; size?: number; stroke?: number }) {
  const r = (size - stroke) / 2
  return <svg className="progress-ring" width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-label={`${Math.round(value)}% complete`}>
    <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeOpacity=".14" strokeWidth={stroke} />
    <circle className="ring-value" cx={size / 2} cy={size / 2} r={r} fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeDasharray={2 * Math.PI * r} strokeDashoffset={2 * Math.PI * r * (1 - value / 100)} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
  </svg>
}
function Toggle({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`toggle ${checked ? 'on' : ''}`} onClick={onChange}><span /></button>
}
function Modal({ children, onClose, title }: { children: React.ReactNode; onClose: () => void; title: string }) {
  useEffect(() => {
    const listener = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose() }
    document.addEventListener('keydown', listener)
    return () => document.removeEventListener('keydown', listener)
  }, [onClose])
  return <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose() }}>
    <section className="modal glass" role="dialog" aria-modal="true" aria-label={title}>
      <button className="icon-button modal-close" onClick={onClose} aria-label="Close dialog"><X size={19} /></button>
      {children}
    </section>
  </div>
}

function Login({ onLogin }: { onLogin: (profile: Profile) => void }) {
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const authenticate = async (number: string) => {
    if (!/^\d{7}$/.test(number)) { setError('Enter a valid 7-digit Maldivian phone number.'); return }
    setLoading(true); setError('')
    try {
      const response = await fetch('/api/family/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone: number }) })
      const data = await response.json()
      if (!response.ok) throw new Error(data.error || 'Unable to sign in.')
      onLogin(data.profile)
    } catch (err) { setError(err instanceof Error ? err.message : 'Unable to connect. Please try again.') }
    finally { setLoading(false) }
  }
  return <main className="login-page">
    <div className="ambient ambient-one" /><div className="ambient ambient-two" />
    <header className="login-header"><Logo /><span className="quiet-label"><ShieldCheck size={15} /> Private family space</span></header>
    <div className="login-layout">
      <section className="login-story">
        <p className="dhivehi">އަސްސަލާމު އަލައިކުމް</p>
        <h1>Little moments.<br /><em>Lasting barakah.</em></h1>
        <p className="login-copy">A gentle rhythm for your family’s day — prayers, learning, and the moments in between, beautifully together.</p>
        <div className="login-prayer glass"><span className="prayer-line" /><div><span>Made for the Maldives</span><strong>Local times · Family routines · Qibla</strong></div><Compass size={25} strokeWidth={1.3} /></div>
      </section>
      <section className="login-card glass">
        <div className="login-card-heading"><span className="mini-label">WELCOME HOME</span><h2>Who’s checking in?</h2><p>Choose your profile or use your phone number.</p></div>
        <div className="family-grid">
          {family.map((member) => <button className="family-member" key={member.phone} onClick={() => authenticate(member.phone)} disabled={loading}><Avatar profile={member} /><span><strong>{member.firstName}</strong><small>{member.relation}</small></span><ChevronRight size={16} /></button>)}
        </div>
        <div className="divider"><span>or continue with phone</span></div>
        <form onSubmit={(e) => { e.preventDefault(); authenticate(phone) }}>
          <label htmlFor="phone">Maldivian phone number</label>
          <div className={`phone-field ${error ? 'field-error' : ''}`}><span>+960</span><input id="phone" inputMode="numeric" maxLength={7} placeholder="7-digit number" value={phone} onChange={(e) => { setPhone(e.target.value.replace(/\D/g, '')); setError('') }} /><Phone size={17} /></div>
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="primary-button login-submit" type="submit" disabled={loading}>{loading ? <span className="spinner" /> : <MoonStar size={18} />}{loading ? 'Opening your space…' : 'Enter family space'}<ChevronRight size={18} /></button>
        </form>
        <p className="login-foot"><ShieldCheck size={14} /> Only registered family numbers can enter.</p>
      </section>
    </div>
    <footer className="login-footer">A quieter way to keep everyone in rhythm.<span>Malé · Maldives</span></footer>
  </main>
}

function Onboarding({ onDone, notifications, setNotifications, onLocation }: { onDone: () => void; notifications: boolean; setNotifications: (v: boolean) => void; onLocation: () => void }) {
  const [locationEnabled, setLocationEnabled] = useState(false)
  const [notice, setNotice] = useState('')
  const enableNotifications = async () => {
    if (!('Notification' in window)) { setNotice('Notifications are not supported here. In-app reminders will still work.'); return }
    const permission = await Notification.requestPermission()
    setNotifications(permission === 'granted')
    setNotice(permission === 'granted' ? 'Notifications are ready.' : 'No problem — reminders will appear inside the app.')
  }
  const enableLocation = () => {
    if (!navigator.geolocation) { setNotice('Location is not supported. Choose your island instead.'); return }
    navigator.geolocation.getCurrentPosition(() => { setLocationEnabled(true); onLocation(); setNotice('Location enabled for prayer times and Qibla.') }, () => setNotice('Location was skipped. Your selected island will be used.'))
  }
  return <Modal onClose={onDone} title="Set up your family space">
    <div className="onboarding-symbol"><Sparkles size={26} /></div>
    <span className="mini-label">A LITTLE SETUP</span><h2>Make each moment<br /><em>feel effortless.</em></h2>
    <p className="modal-intro">Two optional permissions help Barakah keep time with you.</p>
    <div className="permission-list">
      <div className="permission-row"><Bell size={21} /><div><strong>Gentle reminders</strong><p>Task alerts 5 minutes before and Azan at prayer time.</p></div><button className={`permission-button ${notifications ? 'enabled' : ''}`} onClick={enableNotifications}>{notifications ? <Check size={17} /> : 'Enable'}</button></div>
      <div className="permission-row"><LocateFixed size={21} /><div><strong>Local precision</strong><p>Accurate prayer times and a live Qibla direction.</p></div><button className={`permission-button ${locationEnabled ? 'enabled' : ''}`} onClick={enableLocation}>{locationEnabled ? <Check size={17} /> : 'Enable'}</button></div>
    </div>
    {notice && <p className="permission-notice">{notice}</p>}
    <button className="primary-button" onClick={onDone}>Continue to my day <ChevronRight size={18} /></button>
    <button className="text-button" onClick={onDone}>Skip for now — I’ll use my island settings</button>
  </Modal>
}

function TaskEditor({ task, onSave, onDelete, onClose }: { task: Task | null; onSave: (task: Task) => void; onDelete?: (id: string) => void; onClose: () => void }) {
  const [draft, setDraft] = useState<Task>(task || { id: crypto.randomUUID(), title: '', start: '16:00', end: '', icon: 'star', reminder: true })
  const [error, setError] = useState('')
  const save = () => {
    if (!draft.title.trim()) { setError('Give this routine a name.'); return }
    if (!draft.start) { setError('Choose a start time.'); return }
    if (draft.end && toMinutes(draft.end) <= toMinutes(draft.start)) { setError('End time must be after the start time.'); return }
    onSave({ ...draft, title: draft.title.trim(), end: draft.end || undefined })
  }
  return <Modal onClose={onClose} title={task ? 'Edit routine' : 'Add a routine'}>
    <span className="mini-label">DAILY RHYTHM</span><h2>{task ? 'Refine this moment' : 'Add to your day'}</h2>
    <div className="editor-fields">
      <label>Routine name<input autoFocus value={draft.title} onChange={(e) => { setDraft({ ...draft, title: e.target.value }); setError('') }} placeholder="e.g. Afternoon reading" /></label>
      <div className="time-fields"><label>Starts<input type="time" value={draft.start} onChange={(e) => setDraft({ ...draft, start: e.target.value })} /></label><label>Ends <span>(optional)</span><input type="time" value={draft.end || ''} onChange={(e) => setDraft({ ...draft, end: e.target.value })} /></label></div>
      <fieldset><legend>Icon</legend><div className="icon-picker">{taskIcons.map((name) => { const Icon = iconOptions[name]; return <button type="button" aria-label={`Use ${name} icon`} className={draft.icon === name ? 'selected' : ''} key={name} onClick={() => setDraft({ ...draft, icon: name })}><Icon size={19} /></button> })}</div></fieldset>
      <div className="editor-reminder"><div><strong>5-minute reminder</strong><p>A gentle heads-up before it begins.</p></div><Toggle label="5-minute reminder" checked={draft.reminder} onChange={() => setDraft({ ...draft, reminder: !draft.reminder })} /></div>
      {error && <p className="form-error" role="alert">{error}</p>}
      <button className="primary-button" onClick={save}><Check size={18} /> Save routine</button>
      {task && onDelete && <button className="danger-button" onClick={() => onDelete(task.id)}><Trash2 size={16} /> Remove routine</button>}
    </div>
  </Modal>
}

type DoneState = Record<string, string[]>
type View = 'today' | 'prayer' | 'settings'

function Dashboard({ profile, onLogout }: { profile: Profile; onLogout: () => void }) {
  const storageKey = `barakah-${profile.phone}`
  const [tasks, setTasks] = useLocal<Task[]>(`${storageKey}-tasks`, defaultTasks)
  const [done, setDone] = useLocal<DoneState>(`${storageKey}-done`, {})
  const [islandName, setIslandName] = useLocal(`${storageKey}-island`, 'Malé')
  const [theme, setTheme] = useLocal<'dark' | 'light'>('barakah-theme', 'dark')
  const [notifications, setNotifications] = useLocal(`${storageKey}-notifications`, false)
  const [azanEnabled, setAzanEnabled] = useLocal(`${storageKey}-azan`, true)
  const [volume, setVolume] = useLocal(`${storageKey}-volume`, 0.7)
  const [onboarded, setOnboarded] = useLocal(`${storageKey}-onboarded`, false)
  const [view, setView] = useState<View>('today')
  const [selectedDay, setSelectedDay] = useState(new Date().getDay())
  const [editing, setEditing] = useState<Task | null | undefined>(undefined)
  const [toast, setToast] = useState('')
  const [menu, setMenu] = useState(false)
  const [islandSearch, setIslandSearch] = useState('')
  const [islandOpen, setIslandOpen] = useState(false)
  const [geo, setGeo] = useState<{ lat: number; lng: number } | null>(null)
  const [heading, setHeading] = useState<number | null>(null)
  const [playing, setPlaying] = useState(false)
  const [audioLoading, setAudioLoading] = useState(false)
  const [now, setNow] = useState(new Date())
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => { document.documentElement.dataset.theme = theme }, [theme])
  useEffect(() => { const timer = window.setInterval(() => setNow(new Date()), 30000); return () => clearInterval(timer) }, [])
  useEffect(() => { if (toast) { const timer = window.setTimeout(() => setToast(''), 2600); return () => clearTimeout(timer) } }, [toast])
  useEffect(() => {
    const listener = (event: DeviceOrientationEvent) => {
      const webkitHeading = (event as DeviceOrientationEvent & { webkitCompassHeading?: number }).webkitCompassHeading
      if (typeof webkitHeading === 'number') setHeading(webkitHeading)
      else if (event.absolute && event.alpha !== null) setHeading(360 - event.alpha)
    }
    window.addEventListener('deviceorientationabsolute', listener, true)
    window.addEventListener('deviceorientation', listener, true)
    return () => { window.removeEventListener('deviceorientationabsolute', listener, true); window.removeEventListener('deviceorientation', listener, true) }
  }, [])

  const island = islands.find((item) => item.name === islandName) || islands[0]
  const coords = geo || island
  const prayerTimes = useMemo(() => {
    const params = CalculationMethod.MuslimWorldLeague()
    params.madhab = Madhab.Shafi
    return new PrayerTimes(new Coordinates(coords.lat, coords.lng), now, params)
  }, [coords.lat, coords.lng, localDateKey(now)])
  const prayerDates: Record<(typeof prayerNames)[number], Date | null> = { Fajr: prayerTimes.fajr, Dhuhr: prayerTimes.dhuhr, Asr: prayerTimes.asr, Maghrib: prayerTimes.maghrib, Isha: prayerTimes.isha }
  const nextPrayer = prayerNames.find((name) => prayerDates[name] && prayerDates[name]!.getTime() > now.getTime()) || 'Fajr'
  const nextPrayerDate = prayerDates[nextPrayer] && prayerDates[nextPrayer]! > now ? prayerDates[nextPrayer]! : new PrayerTimes(new Coordinates(coords.lat, coords.lng), new Date(now.getTime() + 86400000), CalculationMethod.MuslimWorldLeague()).fajr
  const countdown = nextPrayerDate ? Math.max(0, nextPrayerDate.getTime() - now.getTime()) : 0
  const countdownText = `${Math.floor(countdown / 3600000)}h ${Math.floor((countdown % 3600000) / 60000)}m`
  const qibla = Math.round(Qibla(new Coordinates(coords.lat, coords.lng)))

  const today = new Date()
  const weekDates = days.map((_, index) => { const date = new Date(today); date.setDate(today.getDate() - today.getDay() + index); return date })
  const selectedDate = weekDates[selectedDay]
  const selectedKey = localDateKey(selectedDate)
  const selectedDone = done[selectedKey] || []
  const sortedTasks = [...tasks].sort((a, b) => toMinutes(a.start) - toMinutes(b.start))
  const progress = tasks.length ? Math.round((selectedDone.length / tasks.length) * 100) : 0
  const isToday = selectedDay === today.getDay()
  const currentMinutes = now.getHours() * 60 + now.getMinutes()
  const filteredIslands = islands.filter((item) => `${item.name} ${item.atoll}`.toLowerCase().includes(islandSearch.toLowerCase()))

  const reward = () => {
    if ('vibrate' in navigator) navigator.vibrate?.(35)
    try {
      const context = new AudioContext(); const oscillator = context.createOscillator(); const gain = context.createGain()
      oscillator.frequency.setValueAtTime(520, context.currentTime); oscillator.frequency.exponentialRampToValueAtTime(760, context.currentTime + .12)
      gain.gain.setValueAtTime(.06, context.currentTime); gain.gain.exponentialRampToValueAtTime(.001, context.currentTime + .25)
      oscillator.connect(gain); gain.connect(context.destination); oscillator.start(); oscillator.stop(context.currentTime + .25)
    } catch { /* audio feedback is optional */ }
  }
  const toggleDone = (id: string) => {
    const exists = selectedDone.includes(id)
    setDone({ ...done, [selectedKey]: exists ? selectedDone.filter((item) => item !== id) : [...selectedDone, id] })
    if (!exists) { reward(); setToast('Beautifully done. One moment at a time.') }
  }
  const markAll = () => { setDone({ ...done, [selectedKey]: tasks.map((task) => task.id) }); reward(); setToast('Your whole day is complete. Masha’Allah.') }
  const saveTask = (task: Task) => {
    setTasks(tasks.some((item) => item.id === task.id) ? tasks.map((item) => item.id === task.id ? task : item) : [...tasks, task])
    setEditing(undefined); setToast(editing ? 'Routine updated.' : 'Routine added to your day.')
  }
  const requestNotifications = async () => {
    if (!('Notification' in window)) { setToast('In-app reminders will be used on this device.'); return }
    const result = await Notification.requestPermission(); setNotifications(result === 'granted'); setToast(result === 'granted' ? 'Notifications enabled.' : 'In-app reminders remain available.')
  }
  const locate = () => {
    if (!navigator.geolocation) { setToast('Location unavailable. Your selected island is used.'); return }
    navigator.geolocation.getCurrentPosition((position) => { setGeo({ lat: position.coords.latitude, lng: position.coords.longitude }); setToast('Using your current location.') }, () => { setGeo(null); setToast('Using your selected island instead.') })
  }
  const enableCompass = async () => {
    try {
      const Orientation = DeviceOrientationEvent as typeof DeviceOrientationEvent & { requestPermission?: () => Promise<'granted' | 'denied'> }
      if (Orientation.requestPermission) { const result = await Orientation.requestPermission(); if (result !== 'granted') throw new Error() }
      setToast('Compass is listening. Calibrate with a figure-eight motion.')
    } catch { setToast('Compass permission was not enabled. The Qibla bearing still works.') }
  }
  const toggleAudio = async () => {
    if (!audioRef.current) return
    if (playing || audioLoading) { audioRef.current.pause(); audioRef.current.currentTime = 0; setPlaying(false); setAudioLoading(false); return }
    audioRef.current.volume = volume
    setAudioLoading(true)
    try { await audioRef.current.play() } catch { setAudioLoading(false); setPlaying(false); setToast('Audio could not load. Check your connection and try again.') }
  }

  useEffect(() => {
    if (!onboarded) return
    const key = localDateKey(now)
    sortedTasks.forEach((task) => {
      if (!task.reminder) return
      const alertKey = `alert-${profile.phone}-${key}-${task.id}`
      if (currentMinutes === toMinutes(task.start) - 5 && !localStorage.getItem(alertKey)) {
        localStorage.setItem(alertKey, '1')
        if (notifications && Notification.permission === 'granted') new Notification(`${task.title} in 5 minutes`, { body: `${task.start} · Your family routine` })
        setToast(`Up in 5 minutes: ${task.title}`)
      }
    })
    prayerNames.forEach((name) => {
      const date = prayerDates[name]; if (!date) return
      const alertKey = `azan-${key}-${name}-${islandName}`
      if (date.getHours() === now.getHours() && date.getMinutes() === now.getMinutes() && !localStorage.getItem(alertKey)) {
        localStorage.setItem(alertKey, '1')
        if (azanEnabled) { setAudioLoading(true); audioRef.current?.play().catch(() => { setAudioLoading(false); setToast(`It's time for ${name} prayer.`) }) }
        if (notifications && Notification.permission === 'granted') new Notification(`${name} prayer time`, { body: `${islandName} · ${timeInMaldives(date)}` })
      }
    })
  }, [now])

  const nav = (next: View) => { setView(next); setMenu(false); window.scrollTo({ top: 0, behavior: 'smooth' }) }

  return <div className="app-shell">
    <div className="ambient app-ambient-one" /><div className="ambient app-ambient-two" />
    <audio ref={audioRef} src="https://upload.wikimedia.org/wikipedia/commons/b/b0/Beautiful_adhan.ogg" onPlaying={() => { setPlaying(true); setAudioLoading(false) }} onEnded={() => setPlaying(false)} onError={() => { setPlaying(false); setAudioLoading(false) }} preload="none" />
    <header className="app-header glass">
      <button className="brand-button" onClick={() => nav('today')} aria-label="Go to today"><Logo compact /></button>
      <nav className="desktop-nav" aria-label="Main navigation"><button className={view === 'today' ? 'active' : ''} onClick={() => nav('today')}>My day</button><button className={view === 'prayer' ? 'active' : ''} onClick={() => nav('prayer')}>Prayer & Qibla</button><button className={view === 'settings' ? 'active' : ''} onClick={() => nav('settings')}>Settings</button></nav>
      <div className="header-actions"><button className="icon-button" aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`} onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button><button className="profile-trigger" onClick={() => setMenu(!menu)} aria-expanded={menu}><Avatar profile={profile} small /><span>{profile.firstName}</span><MoreHorizontal size={17} /></button>{menu && <div className="profile-menu glass"><strong>{profile.name}</strong><span>+960 {profile.phone}</span><button onClick={onLogout}><LogOut size={16} /> Switch family member</button></div>}</div>
    </header>

    <main className="app-main">
      {view === 'today' && <>
        <section className="greeting-row"><div><p className="greeting-arabic">Assalaamu alaikum, {profile.firstName}</p><h1>Let’s make today<br /><em>meaningful.</em></h1></div><div className="date-block"><span>{days[today.getDay()]}</span><strong>{today.toLocaleDateString('en-GB', { day: 'numeric', month: 'long' })}</strong><small>{today.toLocaleDateString('en-GB', { year: 'numeric' })} · Maldives</small></div></section>
        <section className="overview-grid">
          <div className="next-prayer glass"><div className="next-prayer-copy"><span className="mini-label"><span className="live-dot" /> NEXT PRAYER</span><h2>{nextPrayer}</h2><div className="prayer-bigtime">{timeInMaldives(nextPrayerDate)}<span> MVT</span></div><p><Clock3 size={15} /> in {countdownText}<span className="inline-separator" /><MapPin size={15} /> {geo ? 'Current location' : island.name}</p></div><div className="prayer-orbit"><div className="orbit-ring" /><MoonStar size={39} strokeWidth={1.1} /><span>{qibla}°</span><small>QIBLA</small></div></div>
          <button className="day-progress glass" onClick={markAll}><div className="progress-visual"><ProgressRing value={progress} size={98} stroke={6} /><div><strong>{progress}%</strong><span>complete</span></div></div><div><span className="mini-label">TODAY’S RHYTHM</span><h3>{selectedDone.length} of {tasks.length} moments</h3><p>{progress === 100 ? 'A beautiful, complete day.' : 'Small steps, beautifully kept.'}</p></div><CheckCheck size={23} /></button>
        </section>
        <section className="week-section glass"><div className="week-inner">{weekDates.map((date, index) => { const dayDone = done[localDateKey(date)]?.length || 0; const pct = tasks.length ? (dayDone / tasks.length) * 100 : 0; return <button key={days[index]} className={`day-button ${selectedDay === index ? 'selected' : ''} ${index === today.getDay() ? 'today' : ''}`} onClick={() => setSelectedDay(index)}><span>{dayShort[index]}</span><strong>{date.getDate()}</strong><ProgressRing value={pct} size={23} stroke={2.5} /></button> })}</div></section>
        <div className="content-grid">
          <section className="schedule-section">
            <div className="section-heading"><div><span className="mini-label">{isToday ? 'YOUR DAY, AT A GLANCE' : `${days[selectedDay].toUpperCase()} ROUTINE`}</span><h2>{isToday ? 'A gentle flow for today' : 'Family routine'}</h2></div><button className="secondary-button" onClick={markAll}><CheckCheck size={17} /> Mark all done</button></div>
            <div className="timeline">
              {sortedTasks.map((task) => {
                const Icon = iconOptions[task.icon] || Star; const complete = selectedDone.includes(task.id); const current = isToday && currentMinutes >= toMinutes(task.start) && (!task.end || currentMinutes <= toMinutes(task.end))
                return <article key={task.id} className={`task-card glass ${complete ? 'complete' : ''} ${current ? 'current' : ''}`}>
                  <button className="task-main" onClick={() => setEditing(task)} aria-label={`Edit ${task.title}`}><div className="task-time"><strong>{task.start}</strong><span>{task.end || '—'}</span></div><div className="task-icon"><Icon size={20} strokeWidth={1.6} /></div><div className="task-copy"><h3>{task.title}</h3><p>{task.reminder ? <><Bell size={12} /> 5m before</> : 'No reminder'}{task.prayer && <><span>·</span> Azan alert</>}</p></div></button>
                  <button className={`done-button ${complete ? 'is-done' : ''}`} onClick={() => toggleDone(task.id)} aria-label={complete ? `Mark ${task.title} not done` : `Mark ${task.title} done`}>{complete ? <Check size={18} /> : <span className="empty-check" />}<span>{complete ? 'Done' : 'Done'}</span></button>
                </article>
              })}
            </div>
            <button className="add-routine" onClick={() => setEditing(null)}><Plus size={19} /> Add a new moment to {isToday ? 'today' : days[selectedDay]}<span>Custom time, icon & reminder</span></button>
          </section>
          <aside className="today-aside">
            <section className="prayer-list-card glass"><div className="aside-heading"><div><span className="mini-label">PRAYER TIMES</span><h3>{geo ? 'Near you' : island.name}</h3></div><button className="icon-button" onClick={() => nav('prayer')} aria-label="Open prayer settings"><Settings size={17} /></button></div>{prayerNames.map((name) => <div className={`prayer-row ${nextPrayer === name ? 'next' : ''}`} key={name}><span>{name}{nextPrayer === name && <small>UP NEXT</small>}</span><strong>{timeInMaldives(prayerDates[name])}</strong><button aria-label={`${azanEnabled ? 'Mute' : 'Enable'} ${name} Azan`} onClick={() => setAzanEnabled(!azanEnabled)}>{azanEnabled ? <Bell size={15} /> : <BellOff size={15} />}</button></div>)}<button className="text-link" onClick={() => nav('prayer')}>Qibla compass & audio <ChevronRight size={15} /></button></section>
            <section className="reflection glass"><span className="quote-mark">“</span><p>Verily, in the remembrance of Allah do hearts find rest.</p><span>Surah Ar-Ra’d · 13:28</span><div className="reflection-line" /></section>
            <div className="local-note"><WifiOff size={15} /><span>Your routines are saved on this device and available offline.</span></div>
          </aside>
        </div>
      </>}

      {view === 'prayer' && <>
        <section className="page-title"><div><p className="greeting-arabic">Time, direction, devotion</p><h1>Prayer <em>& Qibla.</em></h1></div><p>Calculated for your chosen corner of the Maldives, with gentle alerts for every prayer.</p></section>
        <div className="prayer-page-grid">
          <section className="prayer-main glass"><div className="island-selector"><label htmlFor="island-search">Island & atoll</label><div className="search-field"><MapPin size={18} /><input id="island-search" placeholder="Search island or atoll…" value={islandOpen ? islandSearch : island.name} onFocus={() => { setIslandOpen(true); setIslandSearch('') }} onChange={(e) => setIslandSearch(e.target.value)} /><Search size={17} /></div>{islandOpen && <div className="island-results">{filteredIslands.slice(0, 8).map((item, index) => <button key={`${item.name}-${item.atoll}-${index}`} onClick={() => { setIslandName(item.name); setGeo(null); setIslandOpen(false) }}><span><strong>{item.name}</strong><small>{item.atoll}</small></span><ChevronRight size={16} /></button>)}{filteredIslands.length === 0 && <p>No matching island. Try an atoll name.</p>}<button className="close-results" onClick={() => setIslandOpen(false)}>Close</button></div>}</div>
            <div className="prayer-date-line"><span>{now.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' })}</span><button onClick={locate}><LocateFixed size={15} /> Use my location</button></div>
            <div className="large-prayer-list">{prayerNames.map((name, index) => <div key={name} className={nextPrayer === name ? 'active' : ''}><span className="prayer-number">0{index + 1}</span><div><strong>{name}</strong><small>{name === nextPrayer ? `in ${countdownText}` : name === 'Fajr' ? 'Dawn prayer' : name === 'Dhuhr' ? 'Midday prayer' : name === 'Asr' ? 'Afternoon prayer' : name === 'Maghrib' ? 'Sunset prayer' : 'Night prayer'}</small></div><time>{timeInMaldives(prayerDates[name])}</time><Bell size={17} /></div>)}</div>
            <p className="calculation-note">Muslim World League calculation · Shafi’i Asr · Indian/Maldivian local convention may vary slightly.</p>
          </section>
          <section className="qibla-card glass"><div className="aside-heading"><div><span className="mini-label">TOWARD THE KAABA</span><h3>Qibla compass</h3></div><Compass size={22} /></div><div className="compass-wrap"><div className="compass-face"><span className="north">N</span><span className="east">E</span><span className="south">S</span><span className="west">W</span>{[0,30,60,90,120,150,180,210,240,270,300,330].map((deg) => <i key={deg} style={{ transform: `rotate(${deg}deg)` }} />)}<div className="qibla-needle" style={{ transform: `translateX(-50%) rotate(${qibla - (heading || 0)}deg)` }}><Navigation size={32} fill="currentColor" /></div><div className="kaaba-mark">ﷲ</div></div></div><div className="qibla-reading"><strong>{qibla}°</strong><span>from true north</span><small>{heading === null ? 'Device bearing not active' : `Device bearing ${Math.round(heading)}°`}</small></div><button className="secondary-button" onClick={enableCompass}><Compass size={17} /> Enable live compass</button><p className="calculation-note">Keep your device flat and away from magnetic objects.</p></section>
          <section className="azan-card glass"><div className="azan-copy"><span className="mini-label">AZAN AUDIO</span><h3>A familiar call,<br /><em>right on time.</em></h3><p>Play the Azan at each prayer, or listen to a test now.</p></div><div className="audio-controls"><button className="play-button" onClick={toggleAudio} aria-label={playing || audioLoading ? 'Stop Azan' : 'Test Azan audio'}>{playing || audioLoading ? <Pause size={23} /> : <Play size={23} fill="currentColor" />}</button><div><strong>{playing ? 'Azan is playing' : audioLoading ? 'Loading Azan…' : 'Test the Azan'}</strong><span>{playing || audioLoading ? 'Tap to stop playback' : 'Audio preview · Adhan'}</span></div><button className="icon-button" onClick={() => setAzanEnabled(!azanEnabled)} aria-label={azanEnabled ? 'Mute Azan alerts' : 'Enable Azan alerts'}>{azanEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}</button></div><label className="volume-slider">Volume <input type="range" min="0" max="1" step="0.05" value={volume} onChange={(e) => { const value = Number(e.target.value); setVolume(value); if (audioRef.current) audioRef.current.volume = value }} /><span>{Math.round(volume * 100)}%</span></label><div className="setting-line"><span>Azan at prayer time</span><Toggle checked={azanEnabled} onChange={() => setAzanEnabled(!azanEnabled)} label="Azan at prayer time" /></div></section>
        </div>
      </>}

      {view === 'settings' && <>
        <section className="page-title"><div><p className="greeting-arabic">Your space, your rhythm</p><h1>Family <em>settings.</em></h1></div><p>Permissions, alerts, location, and the little details that make this space yours.</p></section>
        <div className="settings-grid">
          <section className="settings-card glass"><div className="settings-heading"><ShieldCheck size={22} /><div><h3>Permissions & alerts</h3><p>You can change these at any time.</p></div></div><div className="setting-line"><div><strong>Notifications</strong><p>5-minute task reminders and prayer alerts</p></div><Toggle checked={notifications} onChange={requestNotifications} label="Notifications" /></div><div className="setting-line"><div><strong>Current location</strong><p>{geo ? 'Enabled for prayer times and Qibla' : `Using selected island: ${island.name}`}</p></div><button className="small-button" onClick={locate}>{geo ? 'Refresh' : 'Enable'}</button></div><div className="setting-line"><div><strong>Azan audio</strong><p>Play at Fajr, Dhuhr, Asr, Maghrib and Isha</p></div><Toggle checked={azanEnabled} onChange={() => setAzanEnabled(!azanEnabled)} label="Azan audio" /></div><p className="settings-footnote">Browser reminders and Azan play while the app is open. Audio starts after your first interaction on devices that require it.</p></section>
          <section className="settings-card glass"><div className="settings-heading"><Palette size={22} /><div><h3>Appearance & place</h3><p>A calm view, day or night.</p></div></div><div className="setting-line"><div><strong>Dark glass</strong><p>Emerald night with warm gold details</p></div><Toggle checked={theme === 'dark'} onChange={() => setTheme(theme === 'dark' ? 'light' : 'dark')} label="Dark glass" /></div><div className="setting-line"><div><strong>Home island</strong><p>Used for prayer times and Qibla</p></div><select value={island.name} onChange={(e) => { setIslandName(e.target.value); setGeo(null) }}>{[...new Set(islands.map((item) => item.name))].map((name) => <option key={name}>{name}</option>)}</select></div><div className="setting-line"><div><strong>Setup guide</strong><p>Review notification and location options</p></div><button className="small-button" onClick={() => setOnboarded(false)}>Open</button></div></section>
          <section className="settings-card glass"><div className="settings-heading"><WifiOff size={22} /><div><h3>Offline family data</h3><p>Private to this browser.</p></div></div><p className="settings-description">Your edited routines, completion history, island, and preferences are stored on this device. They will not sync to another phone, and clearing browser data removes them.</p><div className="data-summary"><span><strong>{tasks.length}</strong> daily routines</span><span><strong>{Object.keys(done).length}</strong> days recorded</span></div><button className="danger-button" onClick={() => { if (confirm('Reset all routines and completion history on this device?')) { setTasks(defaultTasks); setDone({}); setToast('Your routines have been reset.') } }}><Trash2 size={16} /> Reset local family data</button></section>
          <section className="settings-card glass profile-settings"><Avatar profile={profile} /><div><span className="mini-label">SIGNED IN AS</span><h3>{profile.name}</h3><p>+960 {profile.phone}</p></div><button className="secondary-button" onClick={onLogout}><LogOut size={16} /> Switch profile</button></section>
        </div>
      </>}
    </main>

    <nav className="mobile-nav glass" aria-label="Mobile navigation"><button className={view === 'today' ? 'active' : ''} onClick={() => nav('today')}><Sun size={20} /><span>My day</span></button><button className={view === 'prayer' ? 'active' : ''} onClick={() => nav('prayer')}><Compass size={20} /><span>Prayer</span></button><button className={view === 'settings' ? 'active' : ''} onClick={() => nav('settings')}><Settings size={20} /><span>Settings</span></button></nav>
    {!onboarded && <Onboarding onDone={() => setOnboarded(true)} notifications={notifications} setNotifications={setNotifications} onLocation={locate} />}
    {editing !== undefined && <TaskEditor task={editing} onSave={saveTask} onDelete={(id) => { setTasks(tasks.filter((task) => task.id !== id)); setEditing(undefined); setToast('Routine removed.') }} onClose={() => setEditing(undefined)} />}
    {toast && <div className="toast glass" role="status"><span><Check size={16} /></span>{toast}</div>}
  </div>
}

export default function App() {
  const [profile, setProfile] = useState<Profile | null>(() => {
    try { const saved = localStorage.getItem('barakah-profile'); return saved ? JSON.parse(saved) : null } catch { return null }
  })
  const login = (member: Profile) => { localStorage.setItem('barakah-profile', JSON.stringify(member)); setProfile(member) }
  const logout = () => { localStorage.removeItem('barakah-profile'); setProfile(null) }
  return profile ? <Dashboard key={profile.phone} profile={profile} onLogout={logout} /> : <Login onLogin={login} />
}
