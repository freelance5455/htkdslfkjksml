import {useCallback, useEffect, useRef, useState} from 'react';
import type {User} from 'firebase/auth';
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import {OperationType, db, handleFirestoreError} from '../firebase';
import {
  BLUEPRINT_LIMITS,
  type SosEvent,
  type SosSignal,
  generateDocId,
} from '../types/tracking';

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    {urls: 'stun:stun.l.google.com:19302'},
    {urls: 'stun:stun1.l.google.com:19302'},
  ],
};

interface UseSosWebRtcOptions {
  role: 'broadcaster' | 'viewer';
  sosEvent: SosEvent | null;
  user: User | null;
  localStream: MediaStream | null;
}

export function useSosWebRtc({
  role,
  sosEvent,
  user,
  localStream,
}: UseSosWebRtcOptions) {
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [connectedPeersCount, setConnectedPeersCount] = useState(0);
  const [connectionState, setConnectionState] = useState<
    'idle' | 'connecting' | 'connected' | 'disconnected'
  >('idle');
  const [returnMicActive, setReturnMicActive] = useState(false);

  const peersRef = useRef<Map<string, RTCPeerConnection>>(new Map());
  const pendingIceRef = useRef<Map<string, RTCIceCandidateInit[]>>(new Map());
  const processedSignalIdsRef = useRef<Set<string>>(new Set());
  const localStreamRef = useRef<MediaStream | null>(localStream);
  const returnAudioStreamRef = useRef<MediaStream | null>(null);

  localStreamRef.current = localStream;

  const updateConnectedCount = useCallback(() => {
    let active = 0;
    peersRef.current.forEach((pc) => {
      if (
        pc.connectionState === 'connected' ||
        pc.iceConnectionState === 'connected' ||
        pc.iceConnectionState === 'completed'
      ) {
        active += 1;
      }
    });
    setConnectedPeersCount(active);
    if (active > 0) {
      setConnectionState('connected');
    } else if (peersRef.current.size > 0) {
      setConnectionState('connecting');
    }
  }, []);

  const sendSignal = useCallback(
    async (
      targetId: string,
      type: SosSignal['type'],
      payloadData: Record<string, unknown>
    ) => {
      if (!sosEvent || !user || sosEvent.status !== 'active') return;
      const payload = JSON.stringify(payloadData);
      if (payload.length > BLUEPRINT_LIMITS.SIGNAL_PAYLOAD_MAX) return;

      const signalId = generateDocId('sig');
      const path = `sosEvents/${sosEvent.id}/signals/${signalId}`;
      try {
        await setDoc(doc(db, `sosEvents/${sosEvent.id}/signals`, signalId), {
          sosId: sosEvent.id,
          ownerId: sosEvent.ownerId,
          viewerIds: sosEvent.viewerIds.slice(0, BLUEPRINT_LIMITS.MAX_VIEWERS),
          senderId: user.uid,
          targetId,
          type,
          payload,
          createdAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, path);
      }
    },
    [sosEvent, user]
  );

  const cleanupAllPeers = useCallback(() => {
    peersRef.current.forEach((pc) => {
      try {
        pc.close();
      } catch {
        // Ignore close errors
      }
    });
    peersRef.current.clear();
    pendingIceRef.current.clear();
    setRemoteStream(null);
    setConnectedPeersCount(0);
    setConnectionState('idle');
    if (returnAudioStreamRef.current) {
      returnAudioStreamRef.current.getTracks().forEach((t) => t.stop());
      returnAudioStreamRef.current = null;
      setReturnMicActive(false);
    }
  }, []);

  const createPeerForRemote = useCallback(
    (remoteUserId: string): RTCPeerConnection => {
      const existing = peersRef.current.get(remoteUserId);
      if (existing) {
        existing.close();
        peersRef.current.delete(remoteUserId);
      }

      const pc = new RTCPeerConnection(RTC_CONFIG);

      if (role === 'broadcaster') {
        const stream = localStreamRef.current;
        if (stream) {
          stream.getTracks().forEach((track) => {
            pc.addTrack(track, stream);
          });
        }
        // Always allow receiving two-way voice audio from viewers
        if (!stream || stream.getAudioTracks().length === 0) {
          pc.addTransceiver('audio', {direction: 'recvonly'});
        }
      } else {
        // Viewer wants to receive video & audio, and optionally send voice back
        pc.addTransceiver('video', {direction: 'recvonly'});
        if (returnAudioStreamRef.current) {
          returnAudioStreamRef.current.getAudioTracks().forEach((track) => {
            pc.addTrack(track, returnAudioStreamRef.current!);
          });
        } else {
          pc.addTransceiver('audio', {direction: 'sendrecv'});
        }
      }

      pc.onicecandidate = (event) => {
        if (event.candidate) {
          void sendSignal(remoteUserId, 'ice', {
            candidate: event.candidate.toJSON(),
          });
        }
      };

      pc.ontrack = (event) => {
        const incomingStream = event.streams[0];
        if (incomingStream) {
          setRemoteStream(incomingStream);
        } else {
          setRemoteStream((prev) => {
            const next = prev ? new MediaStream(prev.getTracks()) : new MediaStream();
            next.addTrack(event.track);
            return next;
          });
        }
      };

      pc.onconnectionstatechange = () => {
        updateConnectedCount();
        if (
          pc.connectionState === 'failed' ||
          pc.connectionState === 'closed'
        ) {
          peersRef.current.delete(remoteUserId);
          updateConnectedCount();
        }
      };

      pc.oniceconnectionstatechange = () => {
        updateConnectedCount();
      };

      peersRef.current.set(remoteUserId, pc);
      return pc;
    },
    [role, sendSignal, updateConnectedCount]
  );

  const flushPendingIce = useCallback(
    async (remoteUserId: string, pc: RTCPeerConnection) => {
      const queued = pendingIceRef.current.get(remoteUserId);
      if (!queued || queued.length === 0) return;
      pendingIceRef.current.delete(remoteUserId);
      for (const cand of queued) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(cand));
        } catch {
          // Ignore stale candidate
        }
      }
    },
    []
  );

  // Broadcaster: attach/replace local tracks on existing peer connections when stream updates
  useEffect(() => {
    if (role !== 'broadcaster' || !localStream || !sosEvent) return;

    const audioTrack = localStream.getAudioTracks()[0] ?? null;
    const videoTrack = localStream.getVideoTracks()[0] ?? null;

    peersRef.current.forEach((pc, remoteUserId) => {
      const senders = pc.getSenders();
      let renegotiate = false;

      if (videoTrack) {
        const videoSender = senders.find((s) => s.track?.kind === 'video');
        if (videoSender) {
          void videoSender.replaceTrack(videoTrack);
        } else {
          pc.addTrack(videoTrack, localStream);
          renegotiate = true;
        }
      }

      if (audioTrack) {
        const audioSender = senders.find((s) => s.track?.kind === 'audio');
        if (audioSender) {
          void audioSender.replaceTrack(audioTrack);
        } else {
          pc.addTrack(audioTrack, localStream);
          renegotiate = true;
        }
      }

      if (renegotiate && sosEvent.status === 'active') {
        void pc
          .createOffer()
          .then((offer) => pc.setLocalDescription(offer).then(() => offer))
          .then((offer) =>
            sendSignal(remoteUserId, 'offer', {
              sdp: offer.sdp,
              type: offer.type,
            })
          )
          .catch(() => {});
      }
    });
  }, [role, localStream, sosEvent, sendSignal]);

  // Listen to signaling subcollection and handle WebRTC handshake
  useEffect(() => {
    if (!sosEvent || !user || sosEvent.status !== 'active') {
      cleanupAllPeers();
      processedSignalIdsRef.current.clear();
      return;
    }

    const sosId = sosEvent.id;
    const signalsPath = `sosEvents/${sosId}/signals`;
    const isOwner = sosEvent.ownerId === user.uid;

    const q = isOwner
      ? query(collection(db, signalsPath), where('ownerId', '==', user.uid))
      : query(
          collection(db, signalsPath),
          where('viewerIds', 'array-contains', user.uid)
        );

    const mountTimeMs = Date.now() - 12000;

    if (role === 'viewer') {
      setConnectionState('connecting');
      void sendSignal(sosEvent.ownerId, 'join', {
        viewerName: user.displayName || user.email || 'Contato',
        ts: Date.now(),
      });
    }

    const unsub = onSnapshot(
      q,
      (snap) => {
        const ordered = snap.docs
          .map((d) => ({
            id: d.id,
            ...(d.data() as Omit<SosSignal, 'id'>),
          }))
          .sort(
            (a, b) =>
              (a.createdAt?.toMillis() ?? Date.now()) -
              (b.createdAt?.toMillis() ?? Date.now())
          );

        ordered.forEach((sig) => {
          if (processedSignalIdsRef.current.has(sig.id)) return;
          processedSignalIdsRef.current.add(sig.id);

          if (sig.senderId === user.uid) return;
          if (sig.targetId !== user.uid && sig.targetId !== '*') return;

          const sigMs = sig.createdAt?.toMillis() ?? Date.now();
          if (sigMs < mountTimeMs) return;

          let parsed: Record<string, unknown> = {};
          try {
            parsed = JSON.parse(sig.payload) as Record<string, unknown>;
          } catch {
            return;
          }

          if (role === 'broadcaster') {
            if (sig.type === 'join') {
              const pc = createPeerForRemote(sig.senderId);
              void pc
                .createOffer()
                .then((offer) => pc.setLocalDescription(offer).then(() => offer))
                .then((offer) =>
                  sendSignal(sig.senderId, 'offer', {
                    sdp: offer.sdp,
                    type: offer.type,
                  })
                )
                .catch(() => {});
            } else if (sig.type === 'answer') {
              const pc = peersRef.current.get(sig.senderId);
              if (pc && typeof parsed.sdp === 'string') {
                void pc
                  .setRemoteDescription(
                    new RTCSessionDescription({
                      type: 'answer',
                      sdp: parsed.sdp,
                    })
                  )
                  .then(() => flushPendingIce(sig.senderId, pc))
                  .catch(() => {});
              }
            } else if (sig.type === 'ice' && parsed.candidate) {
              const pc = peersRef.current.get(sig.senderId);
              const candidate = parsed.candidate as RTCIceCandidateInit;
              if (pc && pc.remoteDescription) {
                void pc
                  .addIceCandidate(new RTCIceCandidate(candidate))
                  .catch(() => {});
              } else {
                const list = pendingIceRef.current.get(sig.senderId) ?? [];
                list.push(candidate);
                pendingIceRef.current.set(sig.senderId, list);
              }
            } else if (sig.type === 'leave') {
              const pc = peersRef.current.get(sig.senderId);
              if (pc) {
                pc.close();
                peersRef.current.delete(sig.senderId);
                updateConnectedCount();
              }
            }
          } else {
            // Viewer role
            if (sig.type === 'offer' && typeof parsed.sdp === 'string') {
              const pc = createPeerForRemote(sig.senderId);
              void pc
                .setRemoteDescription(
                  new RTCSessionDescription({
                    type: 'offer',
                    sdp: parsed.sdp,
                  })
                )
                .then(() => flushPendingIce(sig.senderId, pc))
                .then(() => pc.createAnswer())
                .then((answer) =>
                  pc.setLocalDescription(answer).then(() => answer)
                )
                .then((answer) =>
                  sendSignal(sig.senderId, 'answer', {
                    sdp: answer.sdp,
                    type: answer.type,
                  })
                )
                .catch(() => {});
            } else if (sig.type === 'ice' && parsed.candidate) {
              const pc = peersRef.current.get(sig.senderId);
              const candidate = parsed.candidate as RTCIceCandidateInit;
              if (pc && pc.remoteDescription) {
                void pc
                  .addIceCandidate(new RTCIceCandidate(candidate))
                  .catch(() => {});
              } else {
                const list = pendingIceRef.current.get(sig.senderId) ?? [];
                list.push(candidate);
                pendingIceRef.current.set(sig.senderId, list);
              }
            }
          }
        });
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, signalsPath);
      }
    );

    return () => {
      unsub();
      if (role === 'viewer' && sosEvent.status === 'active') {
        void sendSignal(sosEvent.ownerId, 'leave', {ts: Date.now()});
      }
      cleanupAllPeers();
    };
  }, [
    role,
    sosEvent?.id,
    sosEvent?.status,
    sosEvent?.ownerId,
    user?.uid,
    createPeerForRemote,
    flushPendingIce,
    sendSignal,
    cleanupAllPeers,
    updateConnectedCount,
  ]);

  // Viewer two-way talkback microphone toggle
  const toggleReturnMic = useCallback(async () => {
    if (role !== 'viewer' || !sosEvent) return;

    if (returnAudioStreamRef.current) {
      returnAudioStreamRef.current.getTracks().forEach((t) => t.stop());
      returnAudioStreamRef.current = null;
      peersRef.current.forEach((pc) => {
        const audioSender = pc.getSenders().find((s) => s.track?.kind === 'audio');
        if (audioSender) {
          void audioSender.replaceTrack(null);
        }
      });
      setReturnMicActive(false);
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia) return;
    try {
      const micStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      });
      returnAudioStreamRef.current = micStream;
      const track = micStream.getAudioTracks()[0];
      if (track) {
        peersRef.current.forEach((pc) => {
          const audioSender = pc
            .getSenders()
            .find((s) => s.track?.kind === 'audio' || s.track === null);
          if (audioSender) {
            void audioSender.replaceTrack(track);
          } else {
            pc.addTrack(track, micStream);
          }
        });
      }
      setReturnMicActive(true);
    } catch {
      setReturnMicActive(false);
    }
  }, [role, sosEvent]);

  const reconnectViewer = useCallback(() => {
    if (role !== 'viewer' || !sosEvent || !user) return;
    setConnectionState('connecting');
    void sendSignal(sosEvent.ownerId, 'join', {
      viewerName: user.displayName || user.email || 'Contato',
      ts: Date.now(),
    });
  }, [role, sosEvent, user, sendSignal]);

  return {
    remoteStream,
    connectedPeersCount,
    connectionState,
    returnMicActive,
    toggleReturnMic,
    reconnectViewer,
  };
}
