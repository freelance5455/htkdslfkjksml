import {useEffect, useState} from 'react';
import {useMapsLibrary} from '@vis.gl/react-google-maps';

interface ReverseGeocodeResult {
  address: string | null;
  placeName: string | null;
  isLoading: boolean;
}

interface CachedPlaceSummary {
  address: string | null;
  placeName: string | null;
}

// Ephemeral in-memory session cache (no persistent storage of non-geospatial Places data)
const SESSION_ADDRESS_CACHE = new Map<string, CachedPlaceSummary>();
const IN_FLIGHT_REQUESTS = new Map<string, Promise<CachedPlaceSummary>>();

function makeCoordKey(lat: number, lng: number): string {
  // ~11 meter spatial bucket to prevent duplicate queries during minor GPS drift
  return `${lat.toFixed(4)},${lng.toFixed(4)}`;
}

export function getCachedAddressLabel(
  lat: number,
  lng: number
): string | null {
  const hit = SESSION_ADDRESS_CACHE.get(makeCoordKey(lat, lng));
  if (!hit) return null;
  if (hit.placeName && hit.address) return `${hit.placeName} — ${hit.address}`;
  return hit.address || hit.placeName || null;
}

export function useReverseGeocode(
  coords: {lat: number; lng: number} | null,
  enabled = true
): ReverseGeocodeResult {
  const placesLib = useMapsLibrary('places');
  const coordKey = coords ? makeCoordKey(coords.lat, coords.lng) : null;

  const [result, setResult] = useState<ReverseGeocodeResult>(() => {
    if (coordKey && SESSION_ADDRESS_CACHE.has(coordKey)) {
      const cached = SESSION_ADDRESS_CACHE.get(coordKey)!;
      return {...cached, isLoading: false};
    }
    return {address: null, placeName: null, isLoading: false};
  });

  useEffect(() => {
    if (!enabled || !coords || !coordKey || !placesLib) {
      return;
    }

    const cached = SESSION_ADDRESS_CACHE.get(coordKey);
    if (cached) {
      setResult({...cached, isLoading: false});
      return;
    }

    let cancelled = false;
    setResult((prev) => ({...prev, isLoading: true}));

    let reqPromise = IN_FLIGHT_REQUESTS.get(coordKey);
    if (!reqPromise) {
      reqPromise = placesLib.Place.searchNearby({
        fields: ['displayName', 'formattedAddress'],
        locationRestriction: {
          center: {lat: coords.lat, lng: coords.lng},
          radius: 75,
        },
        rankPreference: placesLib.SearchNearbyRankPreference.DISTANCE,
        maxResultCount: 1,
        language: 'pt-BR',
      })
        .then(({places}) => {
          const top = places?.[0];
          const summary: CachedPlaceSummary = {
            address: top?.formattedAddress ?? null,
            placeName: top?.displayName ?? null,
          };
          if (SESSION_ADDRESS_CACHE.size >= 150) {
            const oldestKey = SESSION_ADDRESS_CACHE.keys().next().value;
            if (oldestKey) SESSION_ADDRESS_CACHE.delete(oldestKey);
          }
          SESSION_ADDRESS_CACHE.set(coordKey, summary);
          return summary;
        })
        .catch((err: unknown) => {
          const msg = err instanceof Error ? err.message : String(err);
          if (
            msg.includes('RESOURCE_EXHAUSTED') ||
            msg.includes('OVER_QUERY_LIMIT') ||
            msg.includes('429')
          ) {
            window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
          }
          return {address: null, placeName: null};
        })
        .finally(() => {
          IN_FLIGHT_REQUESTS.delete(coordKey);
        });

      IN_FLIGHT_REQUESTS.set(coordKey, reqPromise);
    }

    reqPromise.then((summary) => {
      if (!cancelled) {
        setResult({...summary, isLoading: false});
      }
    });

    return () => {
      cancelled = true;
    };
  }, [enabled, coordKey, coords?.lat, coords?.lng, placesLib]);

  return result;
}
