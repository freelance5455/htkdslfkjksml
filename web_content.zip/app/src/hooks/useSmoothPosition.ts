import {useEffect, useRef, useState} from 'react';
import {haversineDistanceMeters} from '../types/tracking';

export function useSmoothPosition(
  targetLat: number,
  targetLng: number,
  durationMs = 950
): {lat: number; lng: number} {
  const [pos, setPos] = useState({lat: targetLat, lng: targetLng});
  const currentRef = useRef({lat: targetLat, lng: targetLng});
  const rafRef = useRef<number | null>(null);

  useEffect(() => {
    const start = currentRef.current;
    const end = {lat: targetLat, lng: targetLng};
    const dist = haversineDistanceMeters(start, end);

    if (dist < 0.15 || dist > 50000 || !Number.isFinite(dist)) {
      currentRef.current = end;
      setPos(end);
      return;
    }

    if (rafRef.current !== null) {
      window.cancelAnimationFrame(rafRef.current);
    }

    const startTime = performance.now();

    const step = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / durationMs);
      // Smooth ease-out while keeping continuous motion
      const eased = 1 - Math.pow(1 - t, 2.2);
      const next = {
        lat: start.lat + (end.lat - start.lat) * eased,
        lng: start.lng + (end.lng - start.lng) * eased,
      };
      currentRef.current = next;
      setPos(next);

      if (t < 1) {
        rafRef.current = window.requestAnimationFrame(step);
      } else {
        currentRef.current = end;
        setPos(end);
        rafRef.current = null;
      }
    };

    rafRef.current = window.requestAnimationFrame(step);

    return () => {
      if (rafRef.current !== null) {
        window.cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [targetLat, targetLng, durationMs]);

  return pos;
}
