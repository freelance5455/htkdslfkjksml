import {useEffect, useState} from 'react';
import type {WeatherData} from '../types/tracking';
import {isNative} from '../native';

// No APK não há servidor local: usa VITE_API_BASE (se definido) ou o Open-Meteo diretamente.
const API_BASE = (import.meta.env.VITE_API_BASE as string | undefined) || '';

function wmoToPt(code: number): {
  label: string;
  conditionCode: WeatherData['conditionCode'];
} {
  if (code === 0) return {label: 'Céu limpo', conditionCode: 'clear'};
  if (code === 1 || code === 2)
    return {label: 'Parcialmente nublado', conditionCode: 'partly_cloudy'};
  if (code === 3) return {label: 'Nublado', conditionCode: 'cloudy'};
  if (code === 45 || code === 48)
    return {label: 'Nevoeiro', conditionCode: 'fog'};
  if (code >= 51 && code <= 57)
    return {label: 'Chuvisco', conditionCode: 'rain'};
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82))
    return {label: 'Chuva', conditionCode: 'rain'};
  if ((code >= 71 && code <= 77) || code === 85 || code === 86)
    return {label: 'Neve', conditionCode: 'snow'};
  if (code >= 95 && code <= 99)
    return {label: 'Tempestade', conditionCode: 'storm'};
  return {label: 'Tempo variável', conditionCode: 'partly_cloudy'};
}

async function fetchOpenMeteoDirect(
  lat: number,
  lng: number
): Promise<WeatherData | null> {
  try {
    const url =
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}` +
      `&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,is_day` +
      `&hourly=precipitation_probability&forecast_days=1&timezone=auto`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const json = await res.json();
    const cur = json.current;
    if (!cur || typeof cur.temperature_2m !== 'number') return null;
    const wmo = wmoToPt(cur.weather_code ?? 0);
    const precip =
      json.hourly?.precipitation_probability?.[0] ??
      ((cur.precipitation ?? 0) > 0 ? 80 : 0);
    return {
      temperatureC: Math.round(cur.temperature_2m * 10) / 10,
      feelsLikeC:
        Math.round((cur.apparent_temperature ?? cur.temperature_2m) * 10) / 10,
      humidity: Math.round(cur.relative_humidity_2m ?? 0),
      windKmh: Math.round(cur.wind_speed_10m ?? 0),
      precipProb: Math.round(precip),
      condition: wmo.label,
      conditionCode: wmo.conditionCode,
      isDaytime: (cur.is_day ?? 1) === 1,
      source: 'open-meteo',
    };
  } catch {
    return null;
  }
}

async function loadWeather(lat: number, lng: number): Promise<WeatherData | null> {
  if (!isNative || API_BASE) {
    try {
      const res = await fetch(
        `${API_BASE}/api/weather?lat=${encodeURIComponent(lat)}&lng=${encodeURIComponent(lng)}`
      );
      if (res.ok) return (await res.json()) as WeatherData;
    } catch {
      // cai para o Open-Meteo direto
    }
  }
  return fetchOpenMeteoDirect(lat, lng);
}

interface CachedWeather {
  data: WeatherData;
  expiresAt: number;
}

const CLIENT_WEATHER_CACHE = new Map<string, CachedWeather>();
const IN_FLIGHT_WEATHER = new Map<string, Promise<WeatherData | null>>();
const CLIENT_TTL_MS = 5 * 60 * 1000;

function makeWeatherKey(lat: number, lng: number): string {
  return `${lat.toFixed(2)},${lng.toFixed(2)}`;
}

export function getCachedWeatherForCoords(
  lat: number,
  lng: number
): WeatherData | null {
  const entry = CLIENT_WEATHER_CACHE.get(makeWeatherKey(lat, lng));
  if (entry && entry.expiresAt > Date.now()) {
    return entry.data;
  }
  return null;
}

export async function fetchWeatherForCoords(
  lat: number,
  lng: number
): Promise<WeatherData | null> {
  const key = makeWeatherKey(lat, lng);
  const existing = CLIENT_WEATHER_CACHE.get(key);
  if (existing && existing.expiresAt > Date.now()) {
    return existing.data;
  }

  let promise = IN_FLIGHT_WEATHER.get(key);
  if (!promise) {
    promise = loadWeather(lat, lng)
      .then((data) => {
        if (data && typeof data.temperatureC === 'number') {
          if (CLIENT_WEATHER_CACHE.size >= 120) {
            const oldest = CLIENT_WEATHER_CACHE.keys().next().value;
            if (oldest) CLIENT_WEATHER_CACHE.delete(oldest);
          }
          CLIENT_WEATHER_CACHE.set(key, {
            data,
            expiresAt: Date.now() + CLIENT_TTL_MS,
          });
          return data;
        }
        return null;
      })
      .catch(() => null)
      .finally(() => {
        IN_FLIGHT_WEATHER.delete(key);
      });

    IN_FLIGHT_WEATHER.set(key, promise);
  }

  return promise;
}

export function useWeather(
  coords: {lat: number; lng: number} | null,
  enabled = true
): {weather: WeatherData | null; isLoading: boolean} {
  const key = coords ? makeWeatherKey(coords.lat, coords.lng) : null;
  const [weather, setWeather] = useState<WeatherData | null>(() =>
    coords ? getCachedWeatherForCoords(coords.lat, coords.lng) : null
  );
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!enabled || !coords || !key) return;

    const cached = getCachedWeatherForCoords(coords.lat, coords.lng);
    if (cached) {
      setWeather(cached);
      setIsLoading(false);
      return;
    }

    let cancelled = false;
    setIsLoading(true);
    void fetchWeatherForCoords(coords.lat, coords.lng).then((data) => {
      if (!cancelled) {
        setWeather(data);
        setIsLoading(false);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [enabled, key, coords?.lat, coords?.lng]);

  return {weather, isLoading};
}
