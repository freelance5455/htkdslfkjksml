# CPLS V2 — Stage 1134

## Candle Gap / Future-Time Hardening
- Rejects candle buckets that are still in the future.
- Clamps candle end timestamps to the current time.
- Merges duplicate normalized buckets while preserving latest close and accumulated high/low.
- Preserves sample-count metadata for diagnostics.
- Keeps existing live feed, zoom, pan, and chart continuity behavior.

Source ZIP stage only; APK build not performed.
