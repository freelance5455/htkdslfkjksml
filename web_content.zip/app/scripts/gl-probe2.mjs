import { chromium } from "playwright";
console.log("whoami:", process.env.HOME, process.env.USER);
// 1) bundled launch with diagnostics
try {
  const b = await chromium.launch();
  console.log("bundled launch OK", b.version());
  const p = await b.newPage();
  const ok = await p.evaluate(() => {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    return gl ? (gl.getParameter(gl.RENDERER) || "yes") : null;
  });
  console.log("bundled webgl:", ok);
  await b.close();
} catch (e) {
  console.log("bundled ERR:", String(e).slice(0, 400));
}
// 2) find executable path from registry
try {
  const { registry } = await import("playwright-core/lib/server");
  console.log("registry import ok");
} catch { /* ignore */ }
