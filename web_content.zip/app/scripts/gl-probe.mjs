import { chromium } from "playwright";
const flagSets = [
  ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
  ["--no-sandbox", "--use-gl=angle", "--use-angle=swiftshader"],
  ["--no-sandbox", "--enable-unsafe-swiftshader"],
  ["--no-sandbox", "--use-gl=swiftshader", "--disable-gpu-sandbox"],
  ["--no-sandbox", "--disable-gpu", "--enable-unsafe-swiftshader"],
];
for (const args of flagSets) {
  try {
    const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", args });
    const page = await browser.newPage();
    const ok = await page.evaluate(() => {
      const c = document.createElement("canvas");
      const gl = c.getContext("webgl2") || c.getContext("webgl");
      return gl ? gl.getParameter(gl.RENDERER) || "yes" : null;
    });
    console.log(JSON.stringify(args), "=>", ok);
    await browser.close();
    if (ok) break;
  } catch (e) { console.log(JSON.stringify(args), "ERR", String(e).slice(0, 120)); }
}
