import { chromium } from "playwright";
const exes = [
  process.env.HOME + "/.cache/ms-playwright/chromium-1247/chrome-linux64/chrome",
  process.env.HOME + "/.cache/ms-playwright/chromium_headless_shell-1247/chrome-headless-shell-linux64/chrome-headless-shell",
  "/usr/bin/chromium",
];
const argsets = [
  ["--no-sandbox", "--disable-dev-shm-usage", "--in-process-gpu", "--enable-unsafe-swiftshader"],
  ["--no-sandbox", "--disable-dev-shm-usage", "--use-gl=angle", "--use-angle=swiftshader", "--enable-features=AllowSwiftShaderFallback"],
  ["--no-sandbox", "--disable-dev-shm-usage", "--enable-unsafe-swiftshader", "--use-angle=vulkan", "--use-vulkan=swiftshader", "--enable-features=Vulkan"],
];
for (const executablePath of exes) {
  for (const args of argsets) {
    try {
      const browser = await chromium.launch({ executablePath, args, timeout: 20000 });
      const page = await browser.newPage();
      const info = await page.evaluate(() => {
        const c = document.createElement("canvas");
        const gl = c.getContext("webgl2") || c.getContext("webgl");
        if (!gl) return null;
        const ext = gl.getExtension("WEBGL_debug_renderer_info");
        return ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : "unknown";
      });
      console.log(info ? "OK  " : "FAIL", executablePath.split("/").slice(-1)[0], JSON.stringify(args.slice(2)), "→", info);
      await browser.close();
    } catch (e) { console.log("ERR ", executablePath.split("/").slice(-1)[0], String(e).slice(0, 80)); }
  }
}
