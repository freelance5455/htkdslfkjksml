<?php
declare(strict_types=1);
require_once __DIR__ . '/voice.php';

/**
 * Shared, SQLite-first wallet reservations for billable platform jobs.
 * Defaults are intentionally conservative and may be changed in Admin -> Models.
 * Image/video jobs use reservations; Realtime is settled from Decart's measured billed_seconds.
 */
function billing_schema(): void {
    static $ready = false;
    if ($ready) return;
    db()->exec("CREATE TABLE IF NOT EXISTS credit_operations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        workspace TEXT NOT NULL,
        job_id TEXT NOT NULL UNIQUE,
        credits INTEGER NOT NULL CHECK(credits > 0),
        state TEXT NOT NULL CHECK(state IN ('reserved','settled','refunded')),
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )");
    db()->exec("CREATE INDEX IF NOT EXISTS idx_credit_operations_user ON credit_operations(user_id,created_at)");
    // Upgrade the old default image price once while preserving non-default Admin choices.
    $marker='pricing_migration_image_20_v1';
    $check=db()->prepare('SELECT setting_value FROM platform_settings WHERE setting_key=? LIMIT 1');
    $check->execute([$marker]);
    if($check->fetchColumn()===false){
        $pdo=db(); $driver=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
        $pdo->prepare("UPDATE platform_settings SET setting_value='20',updated_at=? WHERE setting_key='credit_price_image' AND setting_value='10'")->execute([now_sql()]);
        $sql=$driver==='sqlite'?'INSERT OR IGNORE INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?)':'INSERT IGNORE INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?)';
        $pdo->prepare($sql)->execute([$marker,'1',now_sql()]);
    }
    $ready = true;
}

function billing_price(string $workspace): ?int {
    $defaults = ['image'=>20, 'video'=>50, 'realtime'=>10, 'lip_sync'=>30];
    if (!array_key_exists($workspace, $defaults)) throw new InvalidArgumentException('Unknown workspace pricing key.');
    billing_schema();
    $key = 'credit_price_' . $workspace;
    $q = db()->prepare('SELECT setting_value FROM platform_settings WHERE setting_key=? LIMIT 1');
    $q->execute([$key]);
    $v = $q->fetchColumn();
    if ($v === false) {
        $v = (string)$defaults[$workspace];
        $driver = db()->getAttribute(PDO::ATTR_DRIVER_NAME);
        if ($driver === 'sqlite') db()->prepare('INSERT OR IGNORE INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?)')->execute([$key,$v,now_sql()]);
        else db()->prepare('INSERT IGNORE INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?)')->execute([$key,$v,now_sql()]);
    }
    if (!ctype_digit((string)$v) || (int)$v < 1 || (int)$v > 1000000) return null;
    return (int)$v;
}

function billing_reserve(int $userId, string $workspace, string $jobId, int $credits): void {
    if ($userId < 1 || !in_array($workspace,['image','video'],true) ||
        !preg_match('/^[a-f0-9]{32}$/',$jobId) || $credits < 1 || $credits > 1000000) {
        throw new InvalidArgumentException('Invalid credit reservation.');
    }
    billing_schema();
    voice_wallet_ensure($userId);
    $pdo = db();
    try {
        $pdo->exec('BEGIN IMMEDIATE');
        $pdo->prepare("INSERT INTO credit_operations(user_id,workspace,job_id,credits,state,created_at,updated_at) VALUES(?,?,?,?,'reserved',?,?)")
            ->execute([$userId,$workspace,$jobId,$credits,now_sql(),now_sql()]);
        $debit = $pdo->prepare('UPDATE user_wallets SET balance=balance-?,updated_at=? WHERE user_id=? AND balance>=?');
        $debit->execute([$credits,now_sql(),$userId,$credits]);
        if ($debit->rowCount() !== 1) throw new RuntimeException('Insufficient credits. Add credits or choose a lower-cost operation.');
        $q=$pdo->prepare('SELECT balance FROM user_wallets WHERE user_id=?');
        $q->execute([$userId]); $balance=(int)$q->fetchColumn();
        $pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')
            ->execute([$userId,-$credits,$balance,ucfirst($workspace).' generation reservation',$jobId,now_sql()]);
        $pdo->exec('COMMIT');
    } catch(Throwable $e) {
        try { $pdo->exec('ROLLBACK'); } catch(Throwable $ignored) {}
        if ($e instanceof PDOException && str_contains(strtolower($e->getMessage()),'unique')) {
            throw new RuntimeException('This generation request has already been reserved. Check your generation history before retrying.');
        }
        throw $e;
    }
}

function billing_settle(string $jobId): void {
    billing_schema();
    $q=db()->prepare("UPDATE credit_operations SET state='settled',updated_at=? WHERE job_id=? AND state='reserved'");
    $q->execute([now_sql(),$jobId]);
    if ($q->rowCount() === 0) {
        $s=db()->prepare('SELECT state FROM credit_operations WHERE job_id=?'); $s->execute([$jobId]);
        $state=$s->fetchColumn();
        if ($state === 'settled') return;
        if ($state === false) throw new RuntimeException('Credit reservation not found.');
        throw new RuntimeException('A refunded generation cannot be settled.');
    }
}

function billing_refund(string $jobId, string $reason='Confirmed provider failure'): bool {
    billing_schema();
    $pdo=db();
    try {
        $pdo->exec('BEGIN IMMEDIATE');
        $q=$pdo->prepare('SELECT user_id,credits,state,workspace FROM credit_operations WHERE job_id=?');
        $q->execute([$jobId]); $op=$q->fetch();
        if (!$op) throw new RuntimeException('Credit reservation not found for refund.');
        if ($op['state']==='refunded') { $pdo->exec('COMMIT'); return false; }
        if ($op['state']!=='reserved') { $pdo->exec('COMMIT'); return false; }
        $uid=(int)$op['user_id']; $amount=(int)$op['credits'];
        $pdo->prepare('UPDATE user_wallets SET balance=balance+?,updated_at=? WHERE user_id=?')->execute([$amount,now_sql(),$uid]);
        $b=$pdo->prepare('SELECT balance FROM user_wallets WHERE user_id=?'); $b->execute([$uid]); $balance=(int)$b->fetchColumn();
        $pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')
            ->execute([$uid,$amount,$balance,substr($reason,0,120),$jobId,now_sql()]);
        $pdo->prepare("UPDATE credit_operations SET state='refunded',updated_at=? WHERE job_id=? AND state='reserved'")->execute([now_sql(),$jobId]);
        $pdo->exec('COMMIT');
        return true;
    } catch(Throwable $e) {
        try { $pdo->exec('ROLLBACK'); } catch(Throwable $ignored) {}
        throw $e;
    }
}

function billing_operation(string $jobId): ?array {
    billing_schema();
    $q=db()->prepare('SELECT * FROM credit_operations WHERE job_id=?'); $q->execute([$jobId]);
    $r=$q->fetch(); return $r ?: null;
}

/**
 * Settle Decart's provider-measured realtime duration. Never infer seconds from
 * the browser clock. A unique ledger reference makes retries idempotent.
 */
function realtime_settle_measured_seconds(string $remoteId, int $userId, int $seconds): array {
    if ($userId < 1 || !preg_match('/^rs_[A-Za-z0-9_-]{4,120}$/', $remoteId) || $seconds < 0 || $seconds > 86400) {
        throw new InvalidArgumentException('Invalid measured realtime usage.');
    }
    $pdo = db();
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver === 'sqlite') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS realtime_credit_usage (id INTEGER PRIMARY KEY AUTOINCREMENT,remote_id TEXT NOT NULL UNIQUE,user_id INTEGER NOT NULL,billed_seconds INTEGER NOT NULL,credits_due INTEGER NOT NULL,credits_charged INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS realtime_credit_usage (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,remote_id VARCHAR(140) NOT NULL UNIQUE,user_id BIGINT UNSIGNED NOT NULL,billed_seconds INT NOT NULL,credits_due BIGINT NOT NULL,credits_charged BIGINT NOT NULL DEFAULT 0,status VARCHAR(20) NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY idx_realtime_credit_user(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    $q = $pdo->prepare('SELECT * FROM realtime_credit_usage WHERE remote_id=? AND user_id=? LIMIT 1');
    $q->execute([$remoteId, $userId]);
    $row = $q->fetch();
    $rate = billing_price('realtime') ?? 10;
    $due = $seconds * $rate;
    if ($due > 100000000) throw new RuntimeException('Realtime usage exceeded the supported billing limit.');
    if (!$row) {
        try {
            $pdo->prepare('INSERT INTO realtime_credit_usage(remote_id,user_id,billed_seconds,credits_due,credits_charged,status,created_at,updated_at) VALUES(?,?,?,?,0,?,?,?)')
                ->execute([$remoteId,$userId,$seconds,$due,$due===0?'settled':'pending',now_sql(),now_sql()]);
        } catch (PDOException $e) {
            $q->execute([$remoteId,$userId]); $row=$q->fetch();
            if (!$row) throw $e;
        }
    } elseif ((int)$row['billed_seconds'] !== $seconds) {
        throw new RuntimeException('The provider returned conflicting realtime usage for this session.');
    }
    $q->execute([$remoteId,$userId]); $row=$q->fetch();
    if (!$row) throw new RuntimeException('Realtime billing record could not be loaded.');
    $due=(int)$row['credits_due']; // Preserve the first measured quote across retries and Admin rate changes.
    if ($row['status'] === 'settled') return ['status'=>'settled','billed_seconds'=>$seconds,'credits_due'=>(int)$row['credits_due'],'credits_charged'=>(int)$row['credits_charged'],'balance'=>voice_wallet_balance($userId)];
    if ($due === 0) return ['status'=>'settled','billed_seconds'=>0,'credits_due'=>0,'credits_charged'=>0,'balance'=>voice_wallet_balance($userId)];
    $reference = 'realtime-' . substr(hash('sha256',$remoteId),0,40);
    try {
        voice_charge_credits($userId,$due,$reference,'Realtime session usage');
        $status='settled'; $charged=$due;
    } catch (Throwable $e) {
        $ledger=$pdo->prepare('SELECT id FROM credit_transactions WHERE user_id=? AND reference_id=? AND amount<0 LIMIT 1');
        $ledger->execute([$userId,$reference]);
        if ($ledger->fetchColumn()) { $status='settled'; $charged=$due; }
        else { $status='unpaid'; $charged=0; }
    }
    $pdo->prepare('UPDATE realtime_credit_usage SET credits_charged=?,status=?,updated_at=? WHERE remote_id=? AND user_id=?')
        ->execute([$charged,$status,now_sql(),$remoteId,$userId]);
    return ['status'=>$status,'billed_seconds'=>$seconds,'credits_due'=>$due,'credits_charged'=>$charged,'balance'=>voice_wallet_balance($userId)];
}
