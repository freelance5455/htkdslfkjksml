<?php
declare(strict_types=1);
require_once __DIR__.'/voice.php';

/** Fish Audio Agent API adapter. Credentials and raw provider responses never leave PHP. */
function anx_fish_error_message(int $status, string $providerCode = ''): string {
    $code=strtolower($providerCode);
    if($status===401) return 'The AI Agent provider authentication needs attention.';
    if($status===402) return 'The Fish Audio account needs an active plan or sufficient provider credits.';
    if($status===403) return 'The Fish Audio account does not have access to this Agent API feature.';
    if($status===404) return 'The selected agent or provider resource could not be found.';
    if($status===409) return 'Publish the latest agent configuration before starting a conversation.';
    if($status===400) return 'Fish Audio could not accept this agent request. Check the agent fields and selected voice.';
    if($status===422) return 'The selected agent configuration is not supported. Review its voice, model and required fields.';
    if($status===429) return 'The AI Agent service is temporarily busy. Please try again.';
    if($status>=500 || $status===0 || in_array($status,[408,425],true)) return 'The AI Agent service is temporarily unavailable.';
    if(str_contains($code,'insufficient')) return 'You do not have enough credits for this session.';
    return 'The AI Agent provider rejected the request (HTTP '.($status?:'connection').').';
}
function anx_fish_request(string $method,string $path,?array $payload=null,?array $multipart=null): array {
    if(!function_exists('curl_init')) throw new RuntimeException('PHP cURL is required for Fish Audio Agent Studio.');
    $allowedPath = preg_match('~^/v1/agent/(?:agents|sessions|knowledge-sources)(?:/[A-Za-z0-9_-]{1,160})?(?:/(?:config|publish|end))?$~D', $path);
    if (!$allowedPath) throw new InvalidArgumentException('Unsupported Fish Agent API path.');
    // Enforce the documented method/path combinations to prevent accidental arbitrary API access.
    $method = strtoupper($method);
    $methodAllowed = ($path === '/v1/agent/agents' && $method === 'POST')
        || ($path === '/v1/agent/sessions' && $method === 'POST')
        || ($path === '/v1/agent/knowledge-sources' && $method === 'POST')
        || (preg_match('~^/v1/agent/agents/[A-Za-z0-9_-]{1,160}$~D', $path) && $method === 'DELETE')
        || (preg_match('~^/v1/agent/agents/[A-Za-z0-9_-]{1,160}/config$~D', $path) && $method === 'PATCH')
        || (preg_match('~^/v1/agent/agents/[A-Za-z0-9_-]{1,160}/publish$~D', $path) && $method === 'POST')
        || (preg_match('~^/v1/agent/sessions/[A-Za-z0-9_-]{1,160}$~D', $path) && $method === 'GET')
        || (preg_match('~^/v1/agent/sessions/[A-Za-z0-9_-]{1,160}/end$~D', $path) && $method === 'POST')
        || (preg_match('~^/v1/agent/knowledge-sources/[A-Za-z0-9_-]{1,160}$~D', $path) && $method === 'DELETE');
    if (!$methodAllowed) throw new InvalidArgumentException('Unsupported Fish Agent API method for this endpoint.');
    $keys=fish_audio_key_records(); if(!$keys) throw new RuntimeException('The AI Agent provider authentication needs attention.');
    $lastMessage='The AI Agent service is temporarily unavailable.';
    foreach($keys as $key) {
        $ch=curl_init('https://api.fish.audio'.$path);
        $headers=['Authorization: Bearer '.$key['key'],'Accept: application/json'];
        if($payload===null && $multipart===null && in_array($method,['POST','PATCH'],true)) $headers[]='Content-Type: application/json';
        $opts=[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>strtoupper($method),CURLOPT_CONNECTTIMEOUT=>12,CURLOPT_TIMEOUT=>60,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2];
        if($multipart!==null) $opts[CURLOPT_POSTFIELDS]=$multipart;
        elseif($payload!==null) {$headers[]='Content-Type: application/json';$opts[CURLOPT_POSTFIELDS]=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);}
        $opts[CURLOPT_HTTPHEADER]=$headers; curl_setopt_array($ch,$opts);
        $body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
        $json=is_string($body)?json_decode($body,true):null;
        if(is_string($body)&&$status>=200&&$status<300) {fish_audio_note_result($key,$status);return ['status'=>$status,'data'=>is_array($json)?$json:[],'raw'=>$body];}
        $providerCode=is_array($json)?(string)($json['code']??$json['error_code']??''):'';
        $providerMessage=is_array($json)?(string)($json['detail']??$json['message']??$json['error']??''):'';
        $lastMessage=anx_fish_error_message($status,$providerCode);
        // Diagnostic is deliberately bounded and excludes authorization headers and request bodies.
        $diagnostic=['http_status'=>$status,'provider_code'=>substr($providerCode,0,80),'provider_message'=>substr(preg_replace('/[\r\n\t]+/',' ',$providerMessage),0,500),'transport_error'=>substr($err,0,180),'path'=>$path,'method'=>strtoupper($method)];
        error_log('Fish Audio Agent API: '.json_encode($diagnostic,JSON_UNESCAPED_SLASHES));
        fish_audio_note_result($key,$status,$err?:($providerCode?:$providerMessage?:$lastMessage));
        // Rotate keys only for authentication failures; retry transient network/rate/server failures once per key.
        if($status===401) continue;
        if(!in_array($status,[0,408,425,429,500,502,503,504],true)) break;
        if(in_array(strtoupper($method),['POST','PATCH','DELETE'],true)) break; // avoid replaying mutations
    }
    throw new RuntimeException($lastMessage);
}
function agent_schema(): void {
    static $done=false;if($done)return;$p=db();$d=$p->getAttribute(PDO::ATTR_DRIVER_NAME);
    if($d==='sqlite'){
      $p->exec("CREATE TABLE IF NOT EXISTS agents(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,fish_agent_id TEXT NOT NULL UNIQUE,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',avatar TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'draft',publication_state TEXT NOT NULL DEFAULT 'draft',config_json TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
      $p->exec("CREATE INDEX IF NOT EXISTS idx_agents_user ON agents(user_id,updated_at)");
      $p->exec("CREATE TABLE IF NOT EXISTS knowledge_sources(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,provider_source_id TEXT NOT NULL UNIQUE,source_name TEXT NOT NULL,source_type TEXT NOT NULL,original_filename TEXT NOT NULL DEFAULT '',storage_path TEXT NOT NULL DEFAULT '',mime_type TEXT NOT NULL DEFAULT '',file_size INTEGER NOT NULL DEFAULT 0,processing_status TEXT NOT NULL DEFAULT 'ready',processing_error TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_knowledge(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,agent_id INTEGER NOT NULL,knowledge_source_id INTEGER NOT NULL,created_at TEXT NOT NULL,UNIQUE(agent_id,knowledge_source_id))");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,agent_id INTEGER NOT NULL,provider_session_id TEXT NOT NULL DEFAULT '',channel TEXT NOT NULL,session_status TEXT NOT NULL,started_at TEXT NOT NULL,ended_at TEXT NULL)");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_messages(id INTEGER PRIMARY KEY AUTOINCREMENT,session_id INTEGER NOT NULL,sender TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL)");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_usage(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,agent_id INTEGER NOT NULL,session_id INTEGER NULL,provider_usage_id TEXT NOT NULL UNIQUE,usage_type TEXT NOT NULL,quantity REAL NOT NULL DEFAULT 0,credits_reserved INTEGER NOT NULL DEFAULT 0,credits_charged INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL,created_at TEXT NOT NULL)");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_publications(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,agent_id INTEGER NOT NULL,public_token TEXT NOT NULL UNIQUE,enabled INTEGER NOT NULL DEFAULT 0,allowed_origins TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL)");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,agent_id INTEGER NOT NULL,action TEXT NOT NULL,details TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL)");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_billing_rates(id INTEGER PRIMARY KEY AUTOINCREMENT,usage_type TEXT NOT NULL,provider_model TEXT NOT NULL DEFAULT '',rate REAL NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,version INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL,UNIQUE(usage_type,provider_model))");
    } else {
      $p->exec("CREATE TABLE IF NOT EXISTS agents(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,fish_agent_id VARCHAR(120) NOT NULL UNIQUE,name VARCHAR(180) NOT NULL,description TEXT NOT NULL,avatar VARCHAR(255) NOT NULL DEFAULT '',status VARCHAR(24) NOT NULL DEFAULT 'draft',publication_state VARCHAR(24) NOT NULL DEFAULT 'draft',config_json LONGTEXT NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY idx_agents_user(user_id,updated_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $p->exec("CREATE TABLE IF NOT EXISTS knowledge_sources(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,provider_source_id VARCHAR(120) NOT NULL UNIQUE,source_name VARCHAR(180) NOT NULL,source_type VARCHAR(40) NOT NULL,original_filename VARCHAR(255) NOT NULL DEFAULT '',storage_path VARCHAR(255) NOT NULL DEFAULT '',mime_type VARCHAR(120) NOT NULL DEFAULT '',file_size BIGINT NOT NULL DEFAULT 0,processing_status VARCHAR(24) NOT NULL DEFAULT 'ready',processing_error VARCHAR(1000) NOT NULL DEFAULT '',created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY idx_knowledge_user(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_knowledge(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,agent_id BIGINT UNSIGNED NOT NULL,knowledge_source_id BIGINT UNSIGNED NOT NULL,created_at DATETIME NOT NULL,UNIQUE KEY uq_agent_knowledge(agent_id,knowledge_source_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_sessions(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,agent_id BIGINT UNSIGNED NOT NULL,provider_session_id VARCHAR(120) NOT NULL DEFAULT '',channel VARCHAR(20) NOT NULL,session_status VARCHAR(24) NOT NULL,started_at DATETIME NOT NULL,ended_at DATETIME NULL,KEY idx_agent_sessions_user(user_id,started_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_messages(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,session_id BIGINT UNSIGNED NOT NULL,sender VARCHAR(20) NOT NULL,message LONGTEXT NOT NULL,created_at DATETIME NOT NULL,KEY idx_agent_messages_session(session_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_usage(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,agent_id BIGINT UNSIGNED NOT NULL,session_id BIGINT UNSIGNED NULL,provider_usage_id VARCHAR(120) NOT NULL UNIQUE,usage_type VARCHAR(40) NOT NULL,quantity DOUBLE NOT NULL DEFAULT 0,credits_reserved BIGINT NOT NULL DEFAULT 0,credits_charged BIGINT NOT NULL DEFAULT 0,status VARCHAR(24) NOT NULL,created_at DATETIME NOT NULL,KEY idx_agent_usage_user(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_publications(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,agent_id BIGINT UNSIGNED NOT NULL,public_token VARCHAR(80) NOT NULL UNIQUE,enabled TINYINT(1) NOT NULL DEFAULT 0,allowed_origins TEXT NOT NULL,created_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_audit_logs(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,agent_id BIGINT UNSIGNED NOT NULL,action VARCHAR(80) NOT NULL,details LONGTEXT NOT NULL,created_at DATETIME NOT NULL,KEY idx_agent_audit_user(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
      $p->exec("CREATE TABLE IF NOT EXISTS agent_billing_rates(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,usage_type VARCHAR(40) NOT NULL,provider_model VARCHAR(120) NOT NULL DEFAULT '',rate DOUBLE NOT NULL DEFAULT 0,active TINYINT(1) NOT NULL DEFAULT 1,version INT NOT NULL DEFAULT 1,updated_at DATETIME NOT NULL,UNIQUE KEY uq_agent_rate(usage_type,provider_model)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    $done=true;
}
function agent_owned(int $id,int $uid): array { agent_schema();$s=db()->prepare('SELECT * FROM agents WHERE id=? AND user_id=?');$s->execute([$id,$uid]);$r=$s->fetch();if(!$r)throw new RuntimeException('Agent not found or access denied.');return $r; }
function agent_audit(int $uid,int $aid,string $action,array $details=[]): void { db()->prepare('INSERT INTO agent_audit_logs(user_id,agent_id,action,details,created_at) VALUES(?,?,?,?,?)')->execute([$uid,$aid,$action,json_encode($details,JSON_UNESCAPED_SLASHES),now_sql()]); }
function agent_local_store(int $uid,array $provider,string $name,string $description,array $config): int {
 $fid=(string)($provider['agent_id']??$provider['id']??'');if($fid==='')throw new RuntimeException('Fish Audio did not return an agent identifier.');
 db()->prepare('INSERT INTO agents(user_id,fish_agent_id,name,description,status,publication_state,config_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$uid,$fid,$name,$description,'draft','draft',json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),now_sql(),now_sql()]);
 return (int)db()->lastInsertId();
}
function agent_config_array(array $a): array { $v=json_decode((string)$a['config_json'],true);return is_array($v)?$v:[]; }


/**
 * Reconcile provider-measured web conversation duration and any separately billed LLM token usage.
 * Fish Audio publishes a per-second web conversation rate and returns duration_seconds;
 * token-billed model costs are read only from provider billable_cost_usd fields. No browser timer estimates are used.
 */
function agent_reconcile_provider_usage(int $localSessionId, int $userId): array {
    agent_schema();
    $q=db()->prepare('SELECT s.*,a.fish_agent_id FROM agent_sessions s JOIN agents a ON a.id=s.agent_id WHERE s.id=? AND s.user_id=? AND a.user_id=? LIMIT 1');
    $q->execute([$localSessionId,$userId,$userId]);
    $local=$q->fetch();
    if(!$local) throw new RuntimeException('Agent session not found or access denied.');
    $providerId=(string)$local['provider_session_id'];
    if($providerId==='') return ['status'=>'pending','measured_usd'=>0.0,'credits_charged'=>0,'message'=>'The provider session ID is missing; usage cannot yet be reconciled.'];

    $detail=anx_fish_request('GET','/v1/agent/sessions/'.rawurlencode($providerId))['data'];
    $providerStatus=strtolower((string)($detail['status']??''));
    if(!in_array($providerStatus,['completed','failed'],true)) {
        return ['status'=>'pending','measured_usd'=>0.0,'credits_charged'=>0,'message'=>'Fish Audio has not finalized this session usage yet.','provider_status'=>$providerStatus];
    }

    $rate=max(0.0,(float)voice_setting('agent_credits_per_usd',(string)(app_config()['agent_credits_per_usd']??0)));
    $perMinute=max(0.0,(float)voice_setting('agent_conversation_usd_per_minute','0'));
    $measured=0.0; $chargedTotal=0; $pending=0; $unpaid=0; $processed=0;

    // Fish Audio's published web-agent conversation fee is billed by second.
    // duration_seconds is the provider-measured quantity, never inferred from browser timers.
    $durationRaw=$detail['duration_seconds']??null;
    if($durationRaw!==null && is_numeric($durationRaw) && (float)$durationRaw>=0 && $perMinute>0) {
        $duration=(float)$durationRaw;
        $baseUsd=($duration/60.0)*$perMinute;
        $measured += $baseUsd;
        $baseUsageId='fish-session-'.substr(hash('sha256',$providerId),0,40);
        $baseResult=agent_settle_measured_usage($userId,(int)$local['agent_id'],$localSessionId,$baseUsageId,'conversation_cost_usd',$duration,$baseUsd,$rate);
        $chargedTotal+=(int)$baseResult['credits']; $processed+=(int)$baseResult['processed'];
        if($baseResult['status']==='unpaid')$unpaid++;
        if($baseResult['status']==='pending')$pending++;
    } elseif($durationRaw===null) {
        $pending++;
    }

    $usageRows=[]; $seenUsage=[];
    foreach((is_array($detail['items']??null)?$detail['items']:[]) as $item) {
        if(is_array($item) && isset($item['llm_usage']) && is_array($item['llm_usage'])) { $uid=(string)($item['llm_usage']['message_generation_id']??''); if($uid===''||!isset($seenUsage[$uid])) { $usageRows[]=$item['llm_usage']; if($uid!=='')$seenUsage[$uid]=true; } }
    }
    foreach((is_array($detail['unattributed_llm_usage']??null)?$detail['unattributed_llm_usage']:[]) as $usage) if(is_array($usage)) { $uid=(string)($usage['message_generation_id']??''); if($uid===''||!isset($seenUsage[$uid])) { $usageRows[]=$usage; if($uid!=='')$seenUsage[$uid]=true; } }

    foreach($usageRows as $usage) {
        $complete=($usage['status']??'')==='complete' && (!array_key_exists('usage_complete',$usage) || $usage['usage_complete']===true);
        if(!$complete) { $pending++; continue; }
        $usageId=trim((string)($usage['message_generation_id']??''));
        if($usageId==='') { $pending++; continue; }
        $usdRaw=$usage['billable_cost_usd']??$usage['cost_usd']??null;
        if(!is_numeric($usdRaw)) { $pending++; continue; }
        $usd=max(0.0,(float)$usdRaw);
        $measured+=$usd;
        $stableId='fish-llm-'.substr(hash('sha256',$providerId.'|'.$usageId),0,40);
        $result=agent_settle_measured_usage($userId,(int)$local['agent_id'],$localSessionId,$stableId,'llm_cost_usd',$usd,$usd,$rate);
        $chargedTotal+=(int)$result['credits']; $processed+=(int)$result['processed'];
        if($result['status']==='unpaid')$unpaid++;
        if($result['status']==='pending')$pending++;
    }
    return ['status'=>$pending>0?'pending':($unpaid>0?'unpaid':($rate>0?'complete':'measured')),'measured_usd'=>round($measured,8),'credits_charged'=>$chargedTotal,'pending_items'=>$pending,'unpaid_items'=>$unpaid,'processed_items'=>$processed,'credits_per_usd'=>$rate,'provider_duration_seconds'=>isset($durationRaw)?(int)$durationRaw:null];
}

/** Idempotently settle one provider-measured USD usage item. */
function agent_settle_measured_usage(int $userId,int $agentId,int $sessionId,string $usageId,string $usageType,float $quantity,float $usd,float $creditsPerUsd): array {
    $existing=db()->prepare('SELECT credits_charged,status FROM agent_usage WHERE provider_usage_id=? LIMIT 1');
    $existing->execute([$usageId]); $prior=$existing->fetch();
    if($prior && $prior['status']==='charged') return ['status'=>'charged','credits'=>(int)$prior['credits_charged'],'processed'=>0];
    if($prior && $prior['status']==='measured' && $creditsPerUsd<=0) return ['status'=>'measured','credits'=>0,'processed'=>0];
    if($creditsPerUsd<=0) {
        if(!$prior) db()->prepare('INSERT INTO agent_usage(user_id,agent_id,session_id,provider_usage_id,usage_type,quantity,credits_reserved,credits_charged,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute([$userId,$agentId,$sessionId,$usageId,$usageType,$quantity,0,0,'measured',now_sql()]);
        return ['status'=>'measured','credits'=>0,'processed'=>$prior?0:1];
    }
    $credits=(int)ceil(max(0.0,$usd)*$creditsPerUsd);
    if($credits<1) {
        if(!$prior) db()->prepare('INSERT INTO agent_usage(user_id,agent_id,session_id,provider_usage_id,usage_type,quantity,credits_reserved,credits_charged,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute([$userId,$agentId,$sessionId,$usageId,$usageType,$quantity,0,0,'measured',now_sql()]);
        return ['status'=>'measured','credits'=>0,'processed'=>$prior?0:1];
    }
    $ledgerRef='agent-'.substr(hash('sha256',$usageId),0,40);
    try { voice_charge_credits($userId,$credits,$ledgerRef); $status='charged'; }
    catch(Throwable $chargeError) {
        $ledger=db()->prepare('SELECT id FROM credit_transactions WHERE user_id=? AND reference_id=? AND amount<0 LIMIT 1');
        $ledger->execute([$userId,$ledgerRef]);
        if($ledger->fetchColumn()) $status='charged'; else { $status='unpaid'; $credits=0; }
    }
    if($prior) {
        db()->prepare('UPDATE agent_usage SET credits_charged=?,status=?,quantity=? WHERE provider_usage_id=? AND status IN (\'unpaid\',\'measured\')')->execute([$credits,$status,$quantity,$usageId]);
    } else {
        db()->prepare('INSERT INTO agent_usage(user_id,agent_id,session_id,provider_usage_id,usage_type,quantity,credits_reserved,credits_charged,status,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute([$userId,$agentId,$sessionId,$usageId,$usageType,$quantity,0,$credits,$status,now_sql()]);
    }
    return ['status'=>$status,'credits'=>$credits,'processed'=>1];
}

