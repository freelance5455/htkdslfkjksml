import { Hono } from 'hono'
import { bodyLimit } from 'hono/body-limit'
import { z } from 'zod'

const profiles = [
  { phone: '9909020', name: 'Ismail Mohamed', firstName: 'Ismail', initials: 'IM', relation: 'Father', color: '#d8a854' },
  { phone: '9192914', name: 'Aishath Fairooza', firstName: 'Fairooza', initials: 'AF', relation: 'Mother', color: '#68b9a5' },
  { phone: '9506054', name: 'Naailaa Mohamed', firstName: 'Naailaa', initials: 'NM', relation: 'Family member', color: '#d7997e' },
  { phone: '7922464', name: 'Hawwa Nihaaya', firstName: 'Nihaaya', initials: 'HN', relation: 'Family member', color: '#8fa8cf' },
]

export const familyRoutes = new Hono()
familyRoutes.get('/members', (c) => c.json({ members: profiles }))
familyRoutes.post('/login', bodyLimit({ maxSize: 2048, onError: (c) => c.body(null, 413) }), async (c) => {
  const parsed = z.object({ phone: z.string().regex(/^\d{7}$/) }).safeParse(await c.req.json().catch(() => ({})))
  if (!parsed.success) return c.json({ error: 'Enter a valid 7-digit Maldivian number.' }, 400)
  const profile = profiles.find((member) => member.phone === parsed.data.phone)
  if (!profile) return c.json({ error: 'This number is not connected to the family.' }, 401)
  return c.json({ profile })
})
