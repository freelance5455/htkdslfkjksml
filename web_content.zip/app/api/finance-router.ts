import { z } from "zod";
import { authedQuery, createRouter } from "./middleware";
import {
  createCategory,
  createTransaction,
  deleteBudget,
  deleteCategory,
  deleteTransaction,
  ensureDefaultCategories,
  ensureSettings,
  listBudgets,
  listCategories,
  listMonthTransactions,
  updateCategory,
  updateSettings,
  updateTransaction,
  upsertBudget,
} from "./queries/finance";

const monthKeySchema = z
  .string()
  .regex(/^\d{4}-\d{2}$/, "monthKey must be YYYY-MM");

const ensureOnboarded = authedQuery.use(async (opts) => {
  await ensureDefaultCategories(opts.ctx.user.id);
  await ensureSettings(opts.ctx.user.id);
  return opts.next();
});

export const financeRouter = createRouter({
  categories: createRouter({
    list: ensureOnboarded.query(({ ctx }) => listCategories(ctx.user.id)),
    create: ensureOnboarded
      .input(
        z.object({
          name: z.string().trim().min(1).max(100),
          kind: z.enum(["expense", "income"]),
          icon: z.string().trim().min(1).max(50),
          color: z.string().trim().min(1).max(20),
        }),
      )
      .mutation(({ ctx, input }) => createCategory(ctx.user.id, input)),
    update: ensureOnboarded
      .input(
        z.object({
          id: z.number().int().positive(),
          name: z.string().trim().min(1).max(100).optional(),
          icon: z.string().trim().min(1).max(50).optional(),
          color: z.string().trim().min(1).max(20).optional(),
        }),
      )
      .mutation(({ ctx, input }) =>
        updateCategory(ctx.user.id, input.id, {
          ...(input.name !== undefined ? { name: input.name } : {}),
          ...(input.icon !== undefined ? { icon: input.icon } : {}),
          ...(input.color !== undefined ? { color: input.color } : {}),
        }),
      ),
    delete: ensureOnboarded
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ ctx, input }) => deleteCategory(ctx.user.id, input.id)),
  }),

  transactions: createRouter({
    list: ensureOnboarded
      .input(z.object({ monthKey: monthKeySchema }))
      .query(({ ctx, input }) =>
        listMonthTransactions(ctx.user.id, input.monthKey),
      ),
    create: ensureOnboarded
      .input(
        z.object({
          categoryId: z.number().int().positive(),
          amount: z.number().int().positive().max(1_000_000_000),
          note: z.string().trim().max(255).optional(),
          txDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
        }),
      )
      .mutation(({ ctx, input }) => createTransaction(ctx.user.id, input)),
    update: ensureOnboarded
      .input(
        z.object({
          id: z.number().int().positive(),
          categoryId: z.number().int().positive().optional(),
          amount: z.number().int().positive().max(1_000_000_000).optional(),
          note: z.string().trim().max(255).nullish(),
          txDate: z
            .string()
            .regex(/^\d{4}-\d{2}-\d{2}$/)
            .optional(),
        }),
      )
      .mutation(({ ctx, input }) =>
        updateTransaction(ctx.user.id, input.id, {
          ...(input.categoryId !== undefined
            ? { categoryId: input.categoryId }
            : {}),
          ...(input.amount !== undefined ? { amount: input.amount } : {}),
          ...(input.note !== undefined ? { note: input.note } : {}),
          ...(input.txDate !== undefined ? { txDate: input.txDate } : {}),
        }),
      ),
    delete: ensureOnboarded
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ ctx, input }) => deleteTransaction(ctx.user.id, input.id)),
  }),

  budgets: createRouter({
    list: ensureOnboarded
      .input(z.object({ monthKey: monthKeySchema }))
      .query(({ ctx, input }) => listBudgets(ctx.user.id, input.monthKey)),
    upsert: ensureOnboarded
      .input(
        z.object({
          categoryId: z.number().int().positive(),
          monthKey: monthKeySchema,
          amount: z.number().int().positive().max(1_000_000_000),
        }),
      )
      .mutation(({ ctx, input }) => upsertBudget(ctx.user.id, input)),
    delete: ensureOnboarded
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ ctx, input }) => deleteBudget(ctx.user.id, input.id)),
  }),

  settings: createRouter({
    get: ensureOnboarded.query(({ ctx }) => ensureSettings(ctx.user.id)),
    update: ensureOnboarded
      .input(
        z.object({
          currency: z
            .string()
            .trim()
            .min(3)
            .max(10)
            .regex(/^[A-Z]{3}$/)
            .optional(),
          familyName: z.string().trim().max(100).optional(),
        }),
      )
      .mutation(({ ctx, input }) => updateSettings(ctx.user.id, input)),
  }),
});
