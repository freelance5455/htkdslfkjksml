import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, asc, desc, eq, ne, sql } from "drizzle-orm";
import { createRouter, publicQuery, protectedProcedure, adminProcedure } from "./middleware";
import { getDb } from "./queries/connection";
import { users, relapses, checkins, habits, habitLogs } from "../db/schema";
import {
  createSession,
  destroySession,
  verifyPassword,
  hashPassword,
  sessionCookieHeader,
  clearSessionCookieHeader,
  readSessionCookie,
} from "./lib/auth";
import { computeStats, todayStr } from "./lib/stats";

const dateStr = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Format tanggal harus YYYY-MM-DD");

const publicUser = (u: typeof users.$inferSelect) => ({
  id: u.id,
  username: u.username,
  displayName: u.displayName,
  role: u.role,
  status: u.status,
  startDate: u.startDate,
  createdAt: u.createdAt,
});

async function getStatsFor(userId: number, startDate: string) {
  const db = getDb();
  const rows = await db
    .select({ date: relapses.date })
    .from(relapses)
    .where(eq(relapses.userId, userId))
    .orderBy(asc(relapses.date));
  return computeStats(startDate, rows.map((r) => r.date));
}

async function ensureUniqueUsername(username: string, excludeId?: number) {
  const db = getDb();
  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.username, username))
    .limit(1);
  if (existing.length > 0 && existing[0].id !== excludeId) {
    throw new TRPCError({ code: "CONFLICT", message: "Username sudah digunakan" });
  }
}

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),

  auth: createRouter({
    me: publicQuery.query(({ ctx }) => (ctx.user ? publicUser(ctx.user) : null)),

    login: publicQuery
      .input(z.object({ username: z.string().min(1), password: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        const db = getDb();
        const found = await db
          .select()
          .from(users)
          .where(eq(users.username, input.username.trim().toLowerCase()))
          .limit(1);
        const user = found[0];
        if (!user || !verifyPassword(input.password, user.passwordHash)) {
          throw new TRPCError({ code: "UNAUTHORIZED", message: "Username atau password salah" });
        }
        if (user.status !== "active") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Akun ini dinonaktifkan" });
        }
        const token = await createSession(user.id);
        ctx.resHeaders.append("Set-Cookie", sessionCookieHeader(token));
        return publicUser(user);
      }),

    logout: protectedProcedure.mutation(async ({ ctx }) => {
      const token = readSessionCookie(ctx.req);
      if (token) await destroySession(token);
      ctx.resHeaders.append("Set-Cookie", clearSessionCookieHeader());
      return { ok: true };
    }),

    changePassword: protectedProcedure
      .input(
        z.object({
          currentPassword: z.string().min(1),
          newPassword: z.string().min(6, "Password baru minimal 6 karakter"),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        if (!verifyPassword(input.currentPassword, ctx.user.passwordHash)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Password saat ini salah" });
        }
        const db = getDb();
        await db
          .update(users)
          .set({ passwordHash: hashPassword(input.newPassword) })
          .where(eq(users.id, ctx.user.id));
        return { ok: true };
      }),

    updateProfile: protectedProcedure
      .input(
        z.object({
          displayName: z.string().min(1).max(100),
          startDate: dateStr,
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const db = getDb();
        await db
          .update(users)
          .set({ displayName: input.displayName.trim(), startDate: input.startDate })
          .where(eq(users.id, ctx.user.id));
        return { ok: true };
      }),
  }),

  tracker: createRouter({
    my: protectedProcedure.query(async ({ ctx }) => {
      const db = getDb();
      const [relapseRows, checkinRows] = await Promise.all([
        db
          .select()
          .from(relapses)
          .where(eq(relapses.userId, ctx.user.id))
          .orderBy(desc(relapses.date)),
        db
          .select({ date: checkins.date })
          .from(checkins)
          .where(eq(checkins.userId, ctx.user.id))
          .orderBy(desc(checkins.date)),
      ]);
      const stats = computeStats(
        ctx.user.startDate,
        relapseRows.map((r) => r.date).reverse(),
      );
      const today = todayStr();
      return {
        stats,
        relapses: relapseRows,
        checkins: checkinRows.map((c) => c.date),
        checkedToday: checkinRows.some((c) => c.date === today),
        today,
      };
    }),

    checkin: protectedProcedure.mutation(async ({ ctx }) => {
      const db = getDb();
      const today = todayStr();
      await db
        .insert(checkins)
        .values({ userId: ctx.user.id, date: today })
        .onDuplicateKeyUpdate({ set: { date: today } });
      return { ok: true, date: today };
    }),

    relapse: protectedProcedure
      .input(
        z.object({
          date: dateStr,
          note: z.string().max(500).optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        if (input.date > todayStr()) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Tanggal tidak boleh di masa depan" });
        }
        if (input.date < ctx.user.startDate) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Tanggal sebelum tanggal mulai perjalanan",
          });
        }
        const db = getDb();
        await db
          .insert(relapses)
          .values({ userId: ctx.user.id, date: input.date, note: input.note?.trim() || null })
          .onDuplicateKeyUpdate({
            set: { note: input.note?.trim() || null },
          });
        return { ok: true };
      }),

    deleteRelapse: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const db = getDb();
        await db
          .delete(relapses)
          .where(and(eq(relapses.id, input.id), eq(relapses.userId, ctx.user.id)));
        return { ok: true };
      }),
  }),

  habits: createRouter({
    mine: protectedProcedure.query(async ({ ctx }) => {
      const db = getDb();
      const today = todayStr();
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 13);
      const since = todayStr(weekAgo);
      const habitRows = await db
        .select()
        .from(habits)
        .where(eq(habits.userId, ctx.user.id))
        .orderBy(asc(habits.createdAt));
      const logs = await db
        .select()
        .from(habitLogs)
        .where(and(eq(habitLogs.userId, ctx.user.id), sql`${habitLogs.date} >= ${since}`));
      const byHabit = new Map<number, Set<string>>();
      for (const l of logs) {
        if (!byHabit.has(l.habitId)) byHabit.set(l.habitId, new Set());
        byHabit.get(l.habitId)!.add(l.date);
      }
      return habitRows.map((h) => ({
        ...h,
        doneToday: byHabit.get(h.id)?.has(today) ?? false,
        recentDates: [...(byHabit.get(h.id) ?? [])].sort(),
      }));
    }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(120),
          description: z.string().max(255).optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const db = getDb();
        const dup = await db
          .select({ id: habits.id })
          .from(habits)
          .where(and(eq(habits.userId, ctx.user.id), eq(habits.name, input.name.trim())))
          .limit(1);
        if (dup.length > 0) {
          throw new TRPCError({ code: "CONFLICT", message: "Habit dengan nama ini sudah ada" });
        }
        await db.insert(habits).values({
          userId: ctx.user.id,
          name: input.name.trim(),
          description: input.description?.trim() || null,
        });
        return { ok: true };
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          name: z.string().min(1).max(120),
          description: z.string().max(255).optional(),
        }),
      )
      .mutation(async ({ ctx, input }) => {
        const db = getDb();
        await db
          .update(habits)
          .set({ name: input.name.trim(), description: input.description?.trim() || null })
          .where(and(eq(habits.id, input.id), eq(habits.userId, ctx.user.id)));
        return { ok: true };
      }),

    remove: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const db = getDb();
        await db.delete(habitLogs).where(eq(habitLogs.habitId, input.id));
        await db
          .delete(habits)
          .where(and(eq(habits.id, input.id), eq(habits.userId, ctx.user.id)));
        return { ok: true };
      }),

    toggle: protectedProcedure
      .input(z.object({ habitId: z.number().int().positive(), date: dateStr }))
      .mutation(async ({ ctx, input }) => {
        const db = getDb();
        const owns = await db
          .select({ id: habits.id })
          .from(habits)
          .where(and(eq(habits.id, input.habitId), eq(habits.userId, ctx.user.id)))
          .limit(1);
        if (owns.length === 0) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Habit tidak ditemukan" });
        }
        const existing = await db
          .select({ id: habitLogs.id })
          .from(habitLogs)
          .where(and(eq(habitLogs.habitId, input.habitId), eq(habitLogs.date, input.date)))
          .limit(1);
        if (existing.length > 0) {
          await db.delete(habitLogs).where(eq(habitLogs.id, existing[0].id));
          return { done: false };
        }
        await db.insert(habitLogs).values({
          habitId: input.habitId,
          userId: ctx.user.id,
          date: input.date,
        });
        return { done: true };
      }),
  }),

  leaderboard: createRouter({
    list: protectedProcedure.query(async ({ ctx }) => {
      const db = getDb();
      const members = await db
        .select()
        .from(users)
        .where(and(eq(users.role, "member"), eq(users.status, "active")));
      const result = await Promise.all(
        members.map(async (m) => {
          const stats = await getStatsFor(m.id, m.startDate);
          return {
            id: m.id,
            displayName: m.displayName,
            username: m.username,
            currentStreak: stats.currentStreak,
            bestStreak: stats.bestStreak,
            totalCleanDays: stats.totalCleanDays,
            totalRelapses: stats.totalRelapses,
            isMe: m.id === ctx.user.id,
          };
        }),
      );
      result.sort((a, b) => b.currentStreak - a.currentStreak || b.bestStreak - a.bestStreak);
      return result.map((r, i) => ({ ...r, rank: i + 1 }));
    }),
  }),

  admin: createRouter({
    members: adminProcedure.query(async () => {
      const db = getDb();
      const all = await db.select().from(users).orderBy(asc(users.createdAt));
      return Promise.all(
        all.map(async (u) => ({
          ...publicUser(u),
          stats: u.role === "member" ? await getStatsFor(u.id, u.startDate) : null,
        })),
      );
    }),

    memberDetail: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(async ({ input }) => {
        const db = getDb();
        const found = await db.select().from(users).where(eq(users.id, input.id)).limit(1);
        const user = found[0];
        if (!user) throw new TRPCError({ code: "NOT_FOUND", message: "Member tidak ditemukan" });
        const [relapseRows, checkinRows, habitRows] = await Promise.all([
          db.select().from(relapses).where(eq(relapses.userId, user.id)).orderBy(desc(relapses.date)),
          db
            .select({ date: checkins.date })
            .from(checkins)
            .where(eq(checkins.userId, user.id))
            .orderBy(desc(checkins.date)),
          db.select().from(habits).where(eq(habits.userId, user.id)).orderBy(asc(habits.createdAt)),
        ]);
        const logs = await db
          .select()
          .from(habitLogs)
          .where(eq(habitLogs.userId, user.id));
        const stats = computeStats(
          user.startDate,
          relapseRows.map((r) => r.date).reverse(),
        );
        return {
          user: publicUser(user),
          stats,
          relapses: relapseRows,
          checkins: checkinRows.map((c) => c.date),
          habits: habitRows.map((h) => ({
            ...h,
            completions: logs.filter((l) => l.habitId === h.id).length,
          })),
        };
      }),

    createMember: adminProcedure
      .input(
        z.object({
          username: z
            .string()
            .min(3)
            .max(64)
            .regex(/^[a-z0-9_.-]+$/, "Username hanya huruf kecil, angka, titik, strip"),
          password: z.string().min(6, "Password minimal 6 karakter"),
          displayName: z.string().min(1).max(100),
          startDate: dateStr,
        }),
      )
      .mutation(async ({ input }) => {
        await ensureUniqueUsername(input.username);
        const db = getDb();
        await db.insert(users).values({
          username: input.username.trim().toLowerCase(),
          passwordHash: hashPassword(input.password),
          displayName: input.displayName.trim(),
          role: "member",
          status: "active",
          startDate: input.startDate,
        });
        return { ok: true };
      }),

    setStatus: adminProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          status: z.enum(["active", "inactive"]),
        }),
      )
      .mutation(async ({ input }) => {
        const db = getDb();
        await db.update(users).set({ status: input.status }).where(eq(users.id, input.id));
        if (input.status === "inactive") {
          await db.delete(checkins).where(eq(checkins.userId, input.id));
        }
        return { ok: true };
      }),

    resetPassword: adminProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          newPassword: z.string().min(6, "Password minimal 6 karakter"),
        }),
      )
      .mutation(async ({ input }) => {
        const db = getDb();
        await db
          .update(users)
          .set({ passwordHash: hashPassword(input.newPassword) })
          .where(eq(users.id, input.id));
        return { ok: true };
      }),

    deleteMember: adminProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        if (input.id === ctx.user.id) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Tidak bisa menghapus akun sendiri" });
        }
        const db = getDb();
        await db.delete(habitLogs).where(eq(habitLogs.userId, input.id));
        await db.delete(habits).where(eq(habits.userId, input.id));
        await db.delete(checkins).where(eq(checkins.userId, input.id));
        await db.delete(relapses).where(eq(relapses.userId, input.id));
        await db.delete(users).where(and(eq(users.id, input.id), ne(users.role, "admin")));
        return { ok: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
