import { authRouter } from "./auth-router";
import { captchaRouter } from "./captchaRouter";
import { walletRouter } from "./walletRouter";
import { adminRouter } from "./adminRouter";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  captcha: captchaRouter,
  wallet: walletRouter,
  admin: adminRouter,

  // TODO: add feature routers here, e.g.
  // todo: createRouter({
  //   list: publicQuery.query(() => findTodos()),
  // }),
});

export type AppRouter = typeof appRouter;
