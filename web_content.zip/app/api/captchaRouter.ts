import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, eq, gt, sql } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { captchas, solves, settings } from "../db/schema";
import { Economy } from "@contracts/constants";

const CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomCode(len = 5) {
  let s = "";
  for (let i = 0; i < len; i++) s += CHARS[Math.floor(Math.random() * CHARS.length)];
  return s;
}

function renderSvg(code: string) {
  const w = 240, h = 80;
  const palette = ["#74f7b2", "#8ecbff", "#ffb3c7", "#ffe08a", "#c9b8ff"];
  let inner = "";
  // noise lines
  for (let i = 0; i < 5; i++) {
    const x1 = Math.random() * w, y1 = Math.random() * h;
    const x2 = Math.random() * w, y2 = Math.random() * h;
    inner += `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="rgba(255,255,255,0.18)" stroke-width="1.5"/>`;
  }
  // noise dots
  for (let i = 0; i < 30; i++) {
    inner += `<circle cx="${Math.random() * w}" cy="${Math.random() * h}" r="${Math.random() * 1.8 + 0.5}" fill="rgba(255,255,255,0.15)"/>`;
  }
  const step = w / (code.length + 1);
  for (let i = 0; i < code.length; i++) {
    const x = step * (i + 1) + (Math.random() * 8 - 4);
    const y = h / 2 + (Math.random() * 12 - 6);
    const rot = Math.random() * 40 - 20;
    const size = 30 + Math.random() * 8;
    const color = palette[i % palette.length];
    inner += `<text x="${x}" y="${y}" transform="rotate(${rot} ${x} ${y})" font-family="Menlo, Consolas, monospace" font-weight="700" font-size="${size}" fill="${color}">${code[i]}</text>`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><rect width="100%" height="100%" fill="#12142a"/>${inner}</svg>`;
}

async function getAdUnitId() {
  const db = getDb();
  const rows = await db.select().from(settings).where(eq(settings.key, "applovin_interstitial_unit_id"));
  return rows[0]?.value || Economy.defaultAdUnitId;
}

export const captchaRouter = createRouter({
  getChallenge: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    const code = randomCode();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);
    const [res] = await db.insert(captchas).values({
      userId: ctx.user.id,
      answer: code,
      expiresAt,
    });
    return { id: Number(res.insertId), svg: renderSvg(code) };
  }),

  submit: authedQuery
    .input(z.object({ id: z.number(), answer: z.string().min(1).max(8) }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(captchas)
        .where(
          and(
            eq(captchas.id, input.id),
            eq(captchas.userId, ctx.user.id),
            eq(captchas.used, false),
            gt(captchas.expiresAt, new Date()),
          ),
        );
      const cap = rows[0];
      if (!cap) throw new TRPCError({ code: "BAD_REQUEST", message: "Captcha expired. Request a new one." });

      await db.update(captchas).set({ used: true }).where(eq(captchas.id, cap.id));

      if (cap.answer.toUpperCase() !== input.answer.trim().toUpperCase()) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Incorrect captcha answer." });
      }

      // One full-screen interstitial impression → simulated AppLovin MAX revenue
      const ecpm = Economy.ecpmMin + Math.random() * (Economy.ecpmMax - Economy.ecpmMin);
      const adRevenue = ecpm / 1000;
      const userEarned = (adRevenue * Economy.userSharePct) / 100;
      const platformEarned = adRevenue - userEarned;
      const adUnitId = await getAdUnitId();

      await db.insert(solves).values({
        userId: ctx.user.id,
        adRevenue: adRevenue.toFixed(6),
        userEarned: userEarned.toFixed(6),
        platformEarned: platformEarned.toFixed(6),
        adUnitId,
      });

      const [{ cnt }] = await db
        .select({ cnt: sql<number>`count(*)` })
        .from(solves)
        .where(eq(solves.userId, ctx.user.id));

      return { reward: userEarned, adUnitId, totalSolves: Number(cnt) };
    }),
});
