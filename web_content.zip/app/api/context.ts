import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";
import { getUserBySessionToken, readSessionCookie } from "./lib/auth";
import type { User } from "../db/schema";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  user: User | null;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
): Promise<TrpcContext> {
  const token = readSessionCookie(opts.req);
  const user = token ? await getUserBySessionToken(token) : null;
  return { req: opts.req, resHeaders: opts.resHeaders, user };
}
