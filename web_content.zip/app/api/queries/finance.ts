import { and, asc, desc, eq, gte, lt } from "drizzle-orm";
import { getDb } from "./connection";
import { budgets, categories, settings, transactions } from "../../db/schema";

// ---------------------------------------------------------------------------
// Default Arabic categories, seeded on first use
// ---------------------------------------------------------------------------

const DEFAULT_EXPENSE_CATEGORIES = [
  { name: "بقالة وتموين", icon: "shopping-basket", color: "#224e37" },
  { name: "إيجار", icon: "home", color: "#9b702c" },
  { name: "فواتير وخدمات", icon: "zap", color: "#de5126" },
  { name: "مواصلات ووقود", icon: "car-front", color: "#8a5a2b" },
  { name: "أطفال ومدارس", icon: "baby", color: "#75b858" },
  { name: "صحة", icon: "heart-pulse", color: "#b3372f" },
  { name: "مطاعم وقهوة", icon: "utensils", color: "#c96f2e" },
  { name: "تسوق", icon: "shopping-bag", color: "#3f6b8a" },
  { name: "ترفيه", icon: "gamepad-2", color: "#5b4a8a" },
  { name: "صيانة المنزل", icon: "wrench", color: "#6d6d6d" },
] as const;

const DEFAULT_INCOME_CATEGORIES = [
  { name: "راتب", icon: "briefcase", color: "#224e37" },
  { name: "دخل إضافي", icon: "trending-up", color: "#4a7c59" },
  { name: "هدايا وتحويلات", icon: "gift", color: "#9b702c" },
] as const;

export async function ensureDefaultCategories(userId: number) {
  const db = getDb();
  const existing = await db.query.categories.findFirst({
    where: eq(categories.userId, userId),
  });
  if (existing) return;

  let order = 0;
  const rows = [
    ...DEFAULT_EXPENSE_CATEGORIES.map((c) => ({ ...c, kind: "expense" as const })),
    ...DEFAULT_INCOME_CATEGORIES.map((c) => ({ ...c, kind: "income" as const })),
  ];
  for (const row of rows) {
    await db.insert(categories).values({
      userId,
      name: row.name,
      kind: row.kind,
      icon: row.icon,
      color: row.color,
      isDefault: true,
      sortOrder: order++,
    });
  }
}

export async function ensureSettings(userId: number) {
  const db = getDb();
  const existing = await db.query.settings.findFirst({
    where: eq(settings.userId, userId),
  });
  if (existing) return existing;
  try {
    await db.insert(settings).values({ userId });
  } catch {
    // Another request may have created the row concurrently — that's fine.
  }
  return db.query.settings.findFirst({ where: eq(settings.userId, userId) });
}

export async function listCategories(userId: number) {
  const db = getDb();
  return db
    .select()
    .from(categories)
    .where(eq(categories.userId, userId))
    .orderBy(asc(categories.sortOrder), asc(categories.id));
}

export async function createCategory(
  userId: number,
  data: { name: string; kind: "expense" | "income"; icon: string; color: string },
) {
  const db = getDb();
  const max = await db.query.categories.findFirst({
    where: eq(categories.userId, userId),
    orderBy: [desc(categories.sortOrder)],
  });
  await db.insert(categories).values({
    userId,
    name: data.name,
    kind: data.kind,
    icon: data.icon,
    color: data.color,
    isDefault: false,
    sortOrder: (max?.sortOrder ?? -1) + 1,
  });
}

export async function updateCategory(
  userId: number,
  id: number,
  data: { name?: string; icon?: string; color?: string },
) {
  const db = getDb();
  await db
    .update(categories)
    .set(data)
    .where(and(eq(categories.id, id), eq(categories.userId, userId)));
}

export async function deleteCategory(userId: number, id: number) {
  const db = getDb();
  // Delete dependent records first so the category can be removed.
  await db
    .delete(budgets)
    .where(and(eq(budgets.categoryId, id), eq(budgets.userId, userId)));
  await db
    .delete(transactions)
    .where(and(eq(transactions.categoryId, id), eq(transactions.userId, userId)));
  await db
    .delete(categories)
    .where(and(eq(categories.id, id), eq(categories.userId, userId)));
}

// ---------------------------------------------------------------------------
// Transactions
// ---------------------------------------------------------------------------

export type TransactionWithCategory = Awaited<
  ReturnType<typeof listMonthTransactions>
>[number];

export async function listMonthTransactions(userId: number, monthKey: string) {
  const db = getDb();
  const start = `${monthKey}-01`;
  const [year, month] = monthKey.split("-").map(Number);
  const endDate = new Date(Date.UTC(year, month, 1));
  const end = endDate.toISOString().slice(0, 10); // first day of next month

  return db
    .select({
      id: transactions.id,
      categoryId: transactions.categoryId,
      amount: transactions.amount,
      note: transactions.note,
      txDate: transactions.txDate,
      createdAt: transactions.createdAt,
      categoryName: categories.name,
      categoryKind: categories.kind,
      categoryIcon: categories.icon,
      categoryColor: categories.color,
    })
    .from(transactions)
    .innerJoin(categories, eq(transactions.categoryId, categories.id))
    .where(
      and(
        eq(transactions.userId, userId),
        gte(transactions.txDate, start),
        lt(transactions.txDate, end),
      ),
    )
    .orderBy(desc(transactions.txDate), desc(transactions.id));
}

export async function createTransaction(
  userId: number,
  data: {
    categoryId: number;
    amount: number;
    note?: string;
    txDate: string;
  },
) {
  const db = getDb();
  await db.insert(transactions).values({
    userId,
    categoryId: data.categoryId,
    amount: data.amount,
    note: data.note?.trim() ? data.note.trim() : null,
    txDate: data.txDate,
  });
}

export async function updateTransaction(
  userId: number,
  id: number,
  data: {
    categoryId?: number;
    amount?: number;
    note?: string | null;
    txDate?: string;
  },
) {
  const db = getDb();
  await db
    .update(transactions)
    .set({
      ...data,
      ...(data.note !== undefined
        ? { note: data.note?.trim() ? data.note.trim() : null }
        : {}),
    })
    .where(and(eq(transactions.id, id), eq(transactions.userId, userId)));
}

export async function deleteTransaction(userId: number, id: number) {
  const db = getDb();
  await db
    .delete(transactions)
    .where(and(eq(transactions.id, id), eq(transactions.userId, userId)));
}

// ---------------------------------------------------------------------------
// Budgets (per category, per month)
// ---------------------------------------------------------------------------

export async function listBudgets(userId: number, monthKey: string) {
  const db = getDb();
  return db
    .select({
      id: budgets.id,
      categoryId: budgets.categoryId,
      monthKey: budgets.monthKey,
      amount: budgets.amount,
      categoryName: categories.name,
      categoryIcon: categories.icon,
      categoryColor: categories.color,
    })
    .from(budgets)
    .innerJoin(categories, eq(budgets.categoryId, categories.id))
    .where(and(eq(budgets.userId, userId), eq(budgets.monthKey, monthKey)));
}

export async function upsertBudget(
  userId: number,
  data: { categoryId: number; monthKey: string; amount: number },
) {
  const db = getDb();
  const existing = await db.query.budgets.findFirst({
    where: and(
      eq(budgets.userId, userId),
      eq(budgets.categoryId, data.categoryId),
      eq(budgets.monthKey, data.monthKey),
    ),
  });
  if (existing) {
    await db
      .update(budgets)
      .set({ amount: data.amount })
      .where(eq(budgets.id, existing.id));
  } else {
    await db.insert(budgets).values({ userId, ...data });
  }
}

export async function deleteBudget(userId: number, id: number) {
  const db = getDb();
  await db
    .delete(budgets)
    .where(and(eq(budgets.id, id), eq(budgets.userId, userId)));
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export async function updateSettings(
  userId: number,
  data: { currency?: string; familyName?: string },
) {
  const db = getDb();
  await ensureSettings(userId);
  await db
    .update(settings)
    .set(data)
    .where(eq(settings.userId, userId));
}
