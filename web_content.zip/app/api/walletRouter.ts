import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { solves, withdrawals } from "../db/schema";
import { Economy } from "@contracts/constants";

async function userBalance(userId: number) {
  const db = getDb();
  const [{ earned }] = await db
    .select({ earned: sql<string>`coalesce(sum(${solves.userEarned}),0)` })
    .from(solves)
    .where(eq(solves.userId, userId));
  const [{ locked }] = await db
    .select({ locked: sql<string>`coalesce(sum(${withdrawals.amount}),0)` })
    .from(withdrawals)
    .where(
      and(
        eq(withdrawals.userId, userId),
        eq(withdrawals.kind, "user"),
        sql`${withdrawals.status} in ('pending','approved','paid')`,
      ),
    );
  return Math.max(0, Number(earned) - Number(locked));
}

export const walletRouter = createRouter({
  summary: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const [balance, [{ todayEarned }], [{ totalSolves }], [{ todaySolves }]] =
      await Promise.all([
        userBalance(ctx.user.id),
        db
          .select({ todayEarned: sql<string>`coalesce(sum(${solves.userEarned}),0)` })
          .from(solves)
          .where(and(eq(solves.userId, ctx.user.id), gte(solves.createdAt, todayStart))),
        db
          .select({ totalSolves: sql<string>`count(*)` })
          .from(solves)
          .where(eq(solves.userId, ctx.user.id)),
        db
          .select({ todaySolves: sql<string>`count(*)` })
          .from(solves)
          .where(and(eq(solves.userId, ctx.user.id), gte(solves.createdAt, todayStart))),
      ]);

    return {
      balance,
      todayEarned: Number(todayEarned),
      totalSolves: Number(totalSolves),
      todaySolves: Number(todaySolves),
      minWithdrawal: Economy.minUserWithdrawal,
    };
  }),

  myWithdrawals: authedQuery.query(({ ctx }) =>
    getDb()
      .select()
      .from(withdrawals)
      .where(and(eq(withdrawals.userId, ctx.user.id), eq(withdrawals.kind, "user")))
      .orderBy(desc(withdrawals.createdAt))
      .limit(50),
  ),

  requestWithdrawal: authedQuery
    .input(
      z.object({
        amount: z.number().positive(),
        method: z.string().min(1).max(50),
        account: z.string().min(2).max(255),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      if (input.amount < Economy.minUserWithdrawal) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Minimum withdrawal is $${Economy.minUserWithdrawal.toFixed(2)}`,
        });
      }
      const balance = await userBalance(ctx.user.id);
      if (input.amount > balance) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient balance." });
      }
      await getDb().insert(withdrawals).values({
        userId: ctx.user.id,
        kind: "user",
        amount: input.amount.toFixed(2),
        method: input.method,
        account: input.account,
      });
      return { success: true };
    }),
});
