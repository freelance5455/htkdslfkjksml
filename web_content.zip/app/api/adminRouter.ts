import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, desc, eq, sql } from "drizzle-orm";
import { createRouter, authedQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { solves, settings, users, withdrawals } from "../db/schema";
import { Economy, OwnerPayout } from "@contracts/constants";

async function platformTotals() {
  const db = getDb();
  const [{ revenue }] = await db
    .select({ revenue: sql<string>`coalesce(sum(${solves.platformEarned}),0)` })
    .from(solves);
  const [{ ownerWithdrawn }] = await db
    .select({ ownerWithdrawn: sql<string>`coalesce(sum(${withdrawals.amount}),0)` })
    .from(withdrawals)
    .where(and(eq(withdrawals.kind, "owner"), sql`${withdrawals.status} in ('pending','approved','paid')`));
  return { total: Number(revenue), available: Math.max(0, Number(revenue) - Number(ownerWithdrawn)) };
}

export const adminRouter = createRouter({
  // First registered user can claim owner/admin role (only works while no admin exists)
  claimOwnership: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    const admins = await db.select().from(users).where(eq(users.role, "admin")).limit(1);
    if (admins.length > 0) {
      throw new TRPCError({ code: "FORBIDDEN", message: "An owner already exists." });
    }
    await db.update(users).set({ role: "admin" }).where(eq(users.id, ctx.user.id));
    return { success: true };
  }),

  stats: adminQuery.query(async () => {
    const db = getDb();
    const [{ impressions }] = await db.select({ impressions: sql<string>`count(*)` }).from(solves);
    const [{ userPayouts }] = await db
      .select({ userPayouts: sql<string>`coalesce(sum(${solves.userEarned}),0)` })
      .from(solves);
    const [{ userCount }] = await db.select({ userCount: sql<string>`count(*)` }).from(users);
    const t = await platformTotals();
    return {
      platformRevenueTotal: t.total,
      platformRevenueAvailable: t.available,
      userPayoutsTotal: Number(userPayouts),
      adImpressions: Number(impressions),
      userCount: Number(userCount),
      minOwnerWithdrawal: Economy.minOwnerWithdrawal,
    };
  }),

  userWithdrawals: adminQuery.query(() =>
    getDb()
      .select({
        id: withdrawals.id,
        amount: withdrawals.amount,
        method: withdrawals.method,
        account: withdrawals.account,
        status: withdrawals.status,
        createdAt: withdrawals.createdAt,
        userName: users.name,
        userEmail: users.email,
      })
      .from(withdrawals)
      .innerJoin(users, eq(users.id, withdrawals.userId))
      .where(eq(withdrawals.kind, "user"))
      .orderBy(desc(withdrawals.createdAt))
      .limit(100),
  ),

  setWithdrawalStatus: adminQuery
    .input(z.object({ id: z.number(), status: z.enum(["approved", "rejected", "paid"]) }))
    .mutation(async ({ input }) => {
      await getDb().update(withdrawals).set({ status: input.status }).where(eq(withdrawals.id, input.id));
      return { success: true };
    }),

  ownerWithdrawals: adminQuery.query(({ ctx }) =>
    getDb()
      .select()
      .from(withdrawals)
      .where(and(eq(withdrawals.kind, "owner"), eq(withdrawals.userId, ctx.user.id)))
      .orderBy(desc(withdrawals.createdAt))
      .limit(50),
  ),

  requestOwnerWithdrawal: adminQuery
    .input(
      z.object({
        amount: z.number().positive(),
        method: z.string().min(1).max(50),
        account: z.string().min(2).max(255),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      if (input.amount < Economy.minOwnerWithdrawal) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Minimum owner withdrawal is $${Economy.minOwnerWithdrawal.toFixed(2)}`,
        });
      }
      const t = await platformTotals();
      if (input.amount > t.available) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Amount exceeds available ad revenue." });
      }
      await getDb().insert(withdrawals).values({
        userId: ctx.user.id,
        kind: "owner",
        amount: input.amount.toFixed(2),
        method: input.method,
        account: input.account,
        status: "approved",
      });
      return { success: true };
    }),

  getOwnerPayout: adminQuery.query(async () => {
    const rows = await getDb().select().from(settings).where(eq(settings.key, "owner_payout_upi"));
    return { upiId: rows[0]?.value || OwnerPayout.upiId, method: OwnerPayout.method };
  }),

  setOwnerPayout: adminQuery
    .input(z.object({ upiId: z.string().min(3).max(255) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .insert(settings)
        .values({ key: "owner_payout_upi", value: input.upiId })
        .onDuplicateKeyUpdate({ set: { value: input.upiId } });
      return { success: true };
    }),

  getAdConfig: adminQuery.query(async () => {
    const rows = await getDb().select().from(settings).where(eq(settings.key, "applovin_interstitial_unit_id"));
    return { unitId: rows[0]?.value || Economy.defaultAdUnitId };
  }),

  setAdConfig: adminQuery
    .input(z.object({ unitId: z.string().min(1).max(128) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .insert(settings)
        .values({ key: "applovin_interstitial_unit_id", value: input.unitId })
        .onDuplicateKeyUpdate({ set: { value: input.unitId } });
      return { success: true };
    }),
});
