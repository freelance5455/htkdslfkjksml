import { scryptSync, randomBytes, timingSafeEqual, createHash } from "node:crypto";
import { eq, gt } from "drizzle-orm";
import { getDb } from "../queries/connection";
import { sessions, users, type User } from "../../db/schema";

const SESSION_COOKIE = "nn_session";
const SESSION_DAYS = 30;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  return candidate.length === expected.length && timingSafeEqual(candidate, expected);
}

export async function createSession(userId: number): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  const db = getDb();
  // housekeeping: drop expired sessions of this user
  await db.delete(sessions).where(eq(sessions.userId, userId));
  await db.insert(sessions).values({ token: hashToken(token), userId, expiresAt });
  return token;
}

function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export async function destroySession(token: string): Promise<void> {
  const db = getDb();
  await db.delete(sessions).where(eq(sessions.token, hashToken(token)));
}

export async function getUserBySessionToken(token: string | undefined): Promise<User | null> {
  if (!token) return null;
  const db = getDb();
  const rows = await db
    .select({ user: users, expiresAt: sessions.expiresAt })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(eq(sessions.token, hashToken(token)))
    .limit(1);
  if (rows.length === 0) return null;
  const { user, expiresAt } = rows[0];
  if (expiresAt.getTime() < Date.now() || user.status !== "active") return null;
  return user;
}

export function readSessionCookie(req: Request): string | undefined {
  const cookieHeader = req.headers.get("cookie");
  if (!cookieHeader) return undefined;
  for (const part of cookieHeader.split(";")) {
    const [name, ...rest] = part.trim().split("=");
    if (name === SESSION_COOKIE) return decodeURIComponent(rest.join("="));
  }
  return undefined;
}

export function sessionCookieHeader(token: string): string {
  const maxAge = SESSION_DAYS * 24 * 60 * 60;
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
}

export function clearSessionCookieHeader(): string {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}

export { gt };

/** Create the default admin account on first run so the owner can log in. */
export async function ensureAdmin(): Promise<void> {
  const db = getDb();
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin")).limit(1);
  if (existing.length > 0) return;
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  await db.insert(users).values({
    username: "admin",
    passwordHash: hashPassword("admin123"),
    displayName: "Admin",
    role: "admin",
    status: "active",
    startDate: `${y}-${m}-${d}`,
  });
}
