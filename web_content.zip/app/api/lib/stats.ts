export type TrackerStats = {
  currentStreak: number;
  bestStreak: number;
  totalCleanDays: number;
  totalRelapses: number;
  relapsedToday: boolean;
};

export function todayStr(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function diffDays(a: string, b: string): number {
  return Math.round((Date.parse(b + "T00:00:00Z") - Date.parse(a + "T00:00:00Z")) / 86400000);
}

/** Compute streak statistics from the user's start date and relapse dates (sorted ascending). */
export function computeStats(startDate: string, relapseDates: string[], today = todayStr()): TrackerStats {
  const relapsedToday = relapseDates[relapseDates.length - 1] === today;
  const segments: number[] = [];
  let prev = startDate;
  for (const r of relapseDates) {
    segments.push(diffDays(prev, r));
    prev = r;
  }
  const currentStreak = diffDays(prev, today);
  segments.push(currentStreak);
  return {
    currentStreak,
    bestStreak: Math.max(0, ...segments),
    totalCleanDays: segments.reduce((s, n) => s + Math.max(0, n), 0),
    totalRelapses: relapseDates.length,
    relapsedToday,
  };
}
