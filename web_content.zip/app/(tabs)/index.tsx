import * as Clipboard from "expo-clipboard";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Animated,
  Dimensions,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@expo/vector-icons/Ionicons";

import { ScreenContainer } from "@/components/screen-container";

type ScreenId = "home" | "gen" | "quick" | "guide" | "cfg";
type ThemeId = "neon" | "pulse" | "void";
type ChoiceKey = "device" | "style" | null;
type IconName = keyof typeof Ionicons.glyphMap;

type Sensitivity = {
  general: number;
  redDot: number;
  x2: number;
  x4: number;
  sniper: number;
  look: number;
  dpi: number;
  control: number;
};

const DEVICE_OPTIONS = [
  { value: "android_low", label: "Android · gama baja", hint: "Respuesta estable" },
  { value: "android_mid", label: "Android · gama media", hint: "Perfil equilibrado" },
  { value: "android_high", label: "Android · 90/120 Hz", hint: "Deslizamiento rápido" },
  { value: "iphone", label: "iPhone · iOS", hint: "Toque preciso" },
  { value: "ipad", label: "iPad · Tablet", hint: "Área amplia" },
] as const;

const STYLE_OPTIONS = [
  { value: "headshot", label: "Solo rojo / levantado", hint: "Prioriza headshots" },
  { value: "balanced", label: "Equilibrado", hint: "Corta y larga distancia" },
  { value: "speed", label: "Velocidad / movement", hint: "Respuesta PvP" },
] as const;

const BASE_VALUES: Record<string, Sensitivity> = {
  android_low: { general: 76, redDot: 72, x2: 65, x4: 55, sniper: 40, look: 82, dpi: 420, control: 78 },
  android_mid: { general: 86, redDot: 82, x2: 75, x4: 65, sniper: 48, look: 90, dpi: 480, control: 84 },
  android_high: { general: 93, redDot: 89, x2: 82, x4: 72, sniper: 54, look: 96, dpi: 560, control: 80 },
  iphone: { general: 88, redDot: 85, x2: 78, x4: 68, sniper: 50, look: 92, dpi: 0, control: 88 },
  ipad: { general: 82, redDot: 79, x2: 72, x4: 62, sniper: 46, look: 87, dpi: 0, control: 86 },
};

const THEME_COLORS: Record<ThemeId, { bg: string; panel: string; panelAlt: string; cyan: string; hot: string; yellow: string; green: string; text: string; muted: string; line: string }> = {
  neon: {
    bg: "#05070d",
    panel: "#0b1220",
    panelAlt: "#101a2b",
    cyan: "#00f0ff",
    hot: "#ff2d72",
    yellow: "#ffe600",
    green: "#22ff88",
    text: "#e6f7ff",
    muted: "#8ba0b9",
    line: "rgba(0,240,255,0.25)",
  },
  pulse: {
    bg: "#0a0610",
    panel: "#171022",
    panelAlt: "#241333",
    cyan: "#d78bff",
    hot: "#ff3d9a",
    yellow: "#ffd75e",
    green: "#54ffc3",
    text: "#fff2fb",
    muted: "#baa4c5",
    line: "rgba(215,139,255,0.3)",
  },
  void: {
    bg: "#020505",
    panel: "#0b1111",
    panelAlt: "#12201e",
    cyan: "#6dffcf",
    hot: "#ff785c",
    yellow: "#f0e67a",
    green: "#9dff72",
    text: "#edfff8",
    muted: "#93aaa3",
    line: "rgba(109,255,207,0.26)",
  },
};

const NAV_ITEMS: { id: ScreenId; label: string; icon: IconName }[] = [
  { id: "home", label: "Inicio", icon: "home-outline" },
  { id: "gen", label: "Calibrar", icon: "options-outline" },
  { id: "guide", label: "Guía", icon: "book-outline" },
  { id: "cfg", label: "Ajustes", icon: "settings-outline" },
];

function clamp(value: number, min = 0, max = 100) {
  return Math.max(min, Math.min(max, Math.round(value)));
}

function getChoiceLabel(options: readonly { value: string; label: string }[], value: string) {
  return options.find((option) => option.value === value)?.label ?? value;
}

function generateSensitivity(device: string, style: string, previous?: Sensitivity): Sensitivity {
  const base = BASE_VALUES[device] ?? BASE_VALUES.android_mid;
  const styleDelta = style === "headshot"
    ? { general: 6, redDot: 7, x2: 4, x4: 2, sniper: -2, look: 4, control: -2 }
    : style === "speed"
      ? { general: 4, redDot: 3, x2: 6, x4: 6, sniper: 1, look: 6, control: -4 }
      : { general: 0, redDot: 0, x2: 0, x4: 0, sniper: 0, look: 0, control: 2 };
  const drift = previous ? 1 : 0;
  const jitter = () => (previous ? Math.round(Math.random() * 6 - 3) : 0);
  return {
    general: clamp(base.general + styleDelta.general + jitter()),
    redDot: clamp(base.redDot + styleDelta.redDot + jitter()),
    x2: clamp(base.x2 + styleDelta.x2 + jitter()),
    x4: clamp(base.x4 + styleDelta.x4 + jitter()),
    sniper: clamp(base.sniper + styleDelta.sniper + jitter()),
    look: clamp(base.look + styleDelta.look + jitter()),
    dpi: base.dpi ? base.dpi + (previous ? (Math.random() > 0.5 ? 10 : -10) : 0) : 0,
    control: clamp(base.control + styleDelta.control + drift + jitter(), 54, 96),
  };
}

function displayRange(value: number, spread = 6) {
  return `${Math.max(1, value - spread)}–${Math.min(100, value + spread)}`;
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const [screen, setScreen] = useState<ScreenId>("home");
  const [device, setDevice] = useState("android_mid");
  const [playStyle, setPlayStyle] = useState("balanced");
  const [choice, setChoice] = useState<ChoiceKey>(null);
  const [result, setResult] = useState<Sensitivity | null>(null);
  const [lastRun, setLastRun] = useState("");
  const [theme, setTheme] = useState<ThemeId>("neon");
  const [animations, setAnimations] = useState(true);
  const [toast, setToast] = useState("");
  const [progress] = useState(() => new Animated.Value(0));
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const colors = THEME_COLORS[theme];
  const compact = Dimensions.get("window").height < 720;

  const notify = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 2100);
  }, []);

  useEffect(() => () => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
  }, []);

  useEffect(() => {
    if (!result) return;
    if (!animations) {
      progress.setValue(result.control);
      return;
    }
    progress.setValue(0);
    Animated.timing(progress, {
      toValue: result.control,
      duration: 650,
      useNativeDriver: false,
    }).start();
  }, [animations, progress, result]);

  const runCalculation = useCallback((nextDevice = device, nextStyle = playStyle, recalculating = false) => {
    const next = generateSensitivity(nextDevice, nextStyle, recalculating ? result ?? undefined : undefined);
    setDevice(nextDevice);
    setPlayStyle(nextStyle);
    setResult(next);
    setLastRun(`${getChoiceLabel(DEVICE_OPTIONS, nextDevice)} · ${getChoiceLabel(STYLE_OPTIONS, nextStyle)}`);
    setScreen("gen");
    if (recalculating) notify("NUEVA CONFIGURACIÓN LISTA");
  }, [device, notify, playStyle, result]);

  const openScreen = useCallback((next: ScreenId) => {
    setChoice(null);
    setScreen(next);
  }, []);

  const openQuick = useCallback(() => {
    runCalculation("android_mid", "balanced");
    notify("CALIBRACIÓN RÁPIDA COMPLETADA");
  }, [notify, runCalculation]);

  const copyResults = useCallback(async () => {
    if (!result) {
      notify("CALCULA UNA CONFIGURACIÓN PRIMERO");
      return;
    }
    const text = [
      "VIP GENERADOR · CONFIGURACIÓN",
      `Dispositivo: ${getChoiceLabel(DEVICE_OPTIONS, device)}`,
      `Estilo: ${getChoiceLabel(STYLE_OPTIONS, playStyle)}`,
      `General: ${result.general}`,
      `Punto rojo: ${result.redDot}`,
      `Mira 2x: ${result.x2}`,
      `Mira 4x: ${result.x4}`,
      `Francotirador: ${result.sniper}`,
      `Cámara 360: ${result.look}`,
      result.dpi ? `DPI recomendado: ${result.dpi}` : "DPI recomendado: No aplica",
      `Índice de control: ${result.control}%`,
    ].join("\n");
    await Clipboard.setStringAsync(text);
    notify(Platform.OS === "web" ? "COPIADO AL PORTAPAPELES" : "COPIADO EN ANDROID");
  }, [device, notify, playStyle, result]);

  const themeLabel = theme === "neon" ? "NEON CYAN" : theme === "pulse" ? "PULSE MAGENTA" : "VOID MINT";
  const selectedOptions = choice === "device" ? DEVICE_OPTIONS : STYLE_OPTIONS;
  const selectedValue = choice === "device" ? device : playStyle;

  const backgroundStyle = useMemo(() => [styles.root, { backgroundColor: colors.bg }], [colors.bg]);

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-transparent" safeAreaClassName="bg-transparent">
      <View style={backgroundStyle}>
        <StatusBar style="light" />
        <View pointerEvents="none" style={[styles.gridLayer, { borderColor: colors.line }]} />
        <View pointerEvents="none" style={[styles.scanLayer, { borderColor: colors.cyan }]} />

        <View style={[styles.appFrame, { borderColor: colors.line, backgroundColor: colors.panel }]}>
          <View style={[styles.header, { borderBottomColor: colors.line }]}>
            <View>
              <Text style={[styles.brand, { color: colors.cyan }]}>VIP GENERADOR</Text>
              <Text style={[styles.headerSub, { color: colors.muted }]}>SENSITIVITY LAB · v4.1</Text>
            </View>
            <View style={styles.online}>
              <View style={[styles.onlineDot, { backgroundColor: colors.green, shadowColor: colors.green }]} />
              <Text style={[styles.onlineText, { color: colors.green }]}>ONLINE</Text>
            </View>
          </View>

          <ScrollView
            style={styles.viewport}
            contentContainerStyle={[styles.content, { paddingBottom: 24 + Math.max(insets.bottom, 8) }]}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {screen === "home" && (
              <HomePanel colors={colors} compact={compact} lastRun={lastRun} onOpen={openScreen} onQuick={openQuick} />
            )}
            {screen === "gen" && (
              <GeneratorPanel
                colors={colors}
                compact={compact}
                device={device}
                playStyle={playStyle}
                result={result}
                progress={progress}
                onOpenChoice={setChoice}
                onCalculate={() => runCalculation()}
                onRecalculate={() => runCalculation(device, playStyle, true)}
                onCopy={copyResults}
              />
            )}
            {screen === "quick" && (
              <QuickPanel colors={colors} onStart={openQuick} onOpenGenerator={() => openScreen("gen")} />
            )}
            {screen === "guide" && <GuidePanel colors={colors} compact={compact} />}
            {screen === "cfg" && (
              <SettingsPanel
                colors={colors}
                theme={theme}
                themeLabel={themeLabel}
                animations={animations}
                onTheme={() => setTheme(theme === "neon" ? "pulse" : theme === "pulse" ? "void" : "neon")}
                onAnimations={() => setAnimations((value) => !value)}
                onHome={() => openScreen("home")}
              />
            )}
          </ScrollView>

          <View style={[styles.dock, { borderTopColor: colors.line, paddingBottom: Math.max(insets.bottom, 8) }]}>
            {NAV_ITEMS.map((item) => {
              const active = screen === item.id;
              return (
                <Pressable
                  key={item.id}
                  accessibilityRole="tab"
                  accessibilityState={{ selected: active }}
                  onPress={() => openScreen(item.id)}
                  style={({ pressed }) => [styles.navButton, pressed && styles.pressed]}
                >
                  <Ionicons name={item.icon} size={21} color={active ? colors.cyan : colors.muted} />
                  <Text style={[styles.navLabel, { color: active ? colors.cyan : colors.muted }]}>{item.label}</Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        {toast ? (
          <View pointerEvents="none" style={[styles.toast, { backgroundColor: colors.cyan }]}>
            <Text style={styles.toastText}>{toast}</Text>
          </View>
        ) : null}

        <Modal visible={choice !== null} transparent animationType="fade" onRequestClose={() => setChoice(null)}>
          <Pressable style={styles.modalBackdrop} onPress={() => setChoice(null)}>
            <Pressable style={[styles.modalCard, { backgroundColor: colors.panelAlt, borderColor: colors.line }]} onPress={(event) => event.stopPropagation()}>
              <Text style={[styles.modalEyebrow, { color: colors.hot }]}>SELECCIONAR</Text>
              <Text style={[styles.modalTitle, { color: colors.text }]}>{choice === "device" ? "TIPO DE DISPOSITIVO" : "ESTILO DE JUEGO"}</Text>
              {selectedOptions.map((option) => {
                const active = selectedValue === option.value;
                return (
                  <Pressable
                    key={option.value}
                    accessibilityRole="button"
                    onPress={() => {
                      if (choice === "device") setDevice(option.value);
                      else setPlayStyle(option.value);
                      setChoice(null);
                    }}
                    style={({ pressed }) => [styles.option, { borderColor: active ? colors.cyan : "rgba(255,255,255,0.08)", backgroundColor: active ? `${colors.cyan}18` : "rgba(0,0,0,0.12)" }, pressed && styles.pressed]}
                  >
                    <View style={{ flex: 1 }}>
                      <Text style={[styles.optionLabel, { color: colors.text }]}>{option.label}</Text>
                      <Text style={[styles.optionHint, { color: colors.muted }]}>{option.hint}</Text>
                    </View>
                    {active ? <Ionicons name="checkmark-circle" size={20} color={colors.cyan} /> : null}
                  </Pressable>
                );
              })}
            </Pressable>
          </Pressable>
        </Modal>
      </View>
    </ScreenContainer>
  );
}

function HomePanel({ colors, compact, lastRun, onOpen, onQuick }: { colors: typeof THEME_COLORS.neon; compact: boolean; lastRun: string; onOpen: (screen: ScreenId) => void; onQuick: () => void }) {
  return (
    <View style={styles.panelStack}>
      <View style={styles.hero}>
        <Text style={[styles.badge, { color: colors.bg, backgroundColor: colors.cyan }]}>SYSTEM READY · v4.1</Text>
        <Text style={[styles.title, { color: colors.text, textShadowColor: colors.cyan }, compact && styles.titleCompact]}>VIP{`\n`}GENERADOR</Text>
        <Text style={[styles.subtitle, { color: colors.hot }]}>FREE FIRE SENSITIVITY</Text>
        <Text style={[styles.body, { color: colors.muted }]}>Calibración por rango cerrado: la mira ni se queda en el pecho ni se pasa de la cabeza.</Text>
      </View>

      <View style={styles.tiles}>
        <Tile colors={colors} hot icon="locate-outline" title="Calibración rápida" subtitle="Perfil equilibrado y resultado inmediato" onPress={onQuick} />
        <Tile colors={colors} icon="options-outline" title="Calibrador completo" subtitle="Elige dispositivo y estilo de juego" onPress={() => onOpen("gen")} />
        <Tile colors={colors} icon="book-outline" title="Guía de ajuste fino" subtitle="Cómo corregir sin arruinar la config" onPress={() => onOpen("guide")} />
        <Tile colors={colors} icon="settings-outline" title="Ajustes" subtitle="Variación fina y animaciones" onPress={() => onOpen("cfg")} />
      </View>

      {lastRun ? (
        <View style={[styles.lastChip, { borderColor: `${colors.yellow}55`, backgroundColor: `${colors.yellow}0f` }]}>
          <Text style={[styles.lastLabel, { color: colors.yellow }]}>ÚLTIMO</Text>
          <Text style={[styles.lastText, { color: colors.muted }]} numberOfLines={2}>{lastRun}</Text>
        </View>
      ) : null}

      <PrimaryButton colors={colors} label="ABRIR CALIBRADOR" icon="arrow-forward-outline" onPress={() => onOpen("gen")} />
    </View>
  );
}

function GeneratorPanel({ colors, compact, device, playStyle, result, progress, onOpenChoice, onCalculate, onRecalculate, onCopy }: { colors: typeof THEME_COLORS.neon; compact: boolean; device: string; playStyle: string; result: Sensitivity | null; progress: Animated.Value; onOpenChoice: (choice: Exclude<ChoiceKey, null>) => void; onCalculate: () => void; onRecalculate: () => void; onCopy: () => void }) {
  return (
    <View style={styles.panelStack}>
      <SectionHeader colors={colors} eyebrow="CALIBRADOR" title="CALIBRADOR" />
      <SelectorField colors={colors} label="Tipo de dispositivo" value={getChoiceLabel(DEVICE_OPTIONS, device)} hint={DEVICE_OPTIONS.find((option) => option.value === device)?.hint ?? ""} onPress={() => onOpenChoice("device")} />
      <SelectorField colors={colors} label="Estilo de juego" value={getChoiceLabel(STYLE_OPTIONS, playStyle)} hint={STYLE_OPTIONS.find((option) => option.value === playStyle)?.hint ?? ""} onPress={() => onOpenChoice("style")} />
      <PrimaryButton colors={colors} label="CALCULAR SENSIBILIDAD" icon="pulse-outline" onPress={onCalculate} />

      {result ? (
        <View style={[styles.results, compact && styles.resultsCompact]}>
          <SectionHeader colors={colors} eyebrow="RESULTADO" title="CONFIGURACIÓN" />
          <View style={styles.valueGrid}>
            <ValueCard colors={colors} label="General" value={result.general} hot range={displayRange(result.general)} />
            <ValueCard colors={colors} label="Punto rojo" value={result.redDot} range={displayRange(result.redDot)} />
            <ValueCard colors={colors} label="Mira 2x" value={result.x2} range={displayRange(result.x2)} />
            <ValueCard colors={colors} label="Mira 4x" value={result.x4} range={displayRange(result.x4)} />
            <ValueCard colors={colors} label="Francotirador" value={result.sniper} range={displayRange(result.sniper)} />
            <ValueCard colors={colors} label="Cámara 360" value={result.look} range={displayRange(result.look)} />
          </View>
          <View style={[styles.dpiCard, { borderColor: `${colors.yellow}55`, backgroundColor: `${colors.yellow}0d` }]}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.dpiTitle, { color: colors.yellow }]}>DPI RECOMENDADO</Text>
              <Text style={[styles.dpiHint, { color: colors.muted }]}>{result.dpi ? "Ajuste de ancho mínimo" : "No aplica en este dispositivo"}</Text>
            </View>
            <Text style={[styles.dpiValue, { color: colors.yellow }]}>{result.dpi || "—"}</Text>
          </View>
          <View style={[styles.meterBox, { borderColor: colors.line, backgroundColor: `${colors.cyan}0b` }]}>
            <View style={styles.meterTop}><Text style={[styles.meterLabel, { color: colors.muted }]}>ÍNDICE DE CONTROL</Text><Text style={[styles.meterValue, { color: colors.cyan }]}>{result.control}%</Text></View>
            <View style={styles.meter}><Animated.View style={[styles.meterFill, { backgroundColor: colors.cyan, width: progress.interpolate({ inputRange: [0, 100], outputRange: ["0%", "100%"] }) }]} /></View>
          </View>
          <View style={styles.actionRow}>
            <SecondaryButton colors={colors} label="COPIAR" icon="copy-outline" onPress={onCopy} />
            <SecondaryButton colors={colors} label="RE-CALCULAR" icon="refresh-outline" onPress={onRecalculate} />
          </View>
        </View>
      ) : (
        <View style={[styles.emptyState, { borderColor: colors.line, backgroundColor: `${colors.cyan}08` }]}>
          <Ionicons name="scan-outline" size={30} color={colors.cyan} />
          <Text style={[styles.emptyTitle, { color: colors.text }]}>LISTO PARA CALIBRAR</Text>
          <Text style={[styles.emptyText, { color: colors.muted }]}>Selecciona tu dispositivo y estilo. Los valores aparecerán aquí.</Text>
        </View>
      )}
    </View>
  );
}

function QuickPanel({ colors, onStart, onOpenGenerator }: { colors: typeof THEME_COLORS.neon; onStart: () => void; onOpenGenerator: () => void }) {
  return (
    <View style={styles.panelStack}>
      <SectionHeader colors={colors} eyebrow="MODO EXPRESS" title="CALIBRACIÓN RÁPIDA" />
      <View style={[styles.quickHero, { borderColor: colors.line, backgroundColor: `${colors.hot}10` }]}>
        <View style={[styles.quickIcon, { backgroundColor: `${colors.hot}22`, borderColor: `${colors.hot}55` }]}><Ionicons name="flash-outline" size={30} color={colors.hot} /></View>
        <Text style={[styles.quickTitle, { color: colors.text }]}>PERFIL EQUILIBRADO</Text>
        <Text style={[styles.body, { color: colors.muted }]}>Una base rápida para Android de gama media, afinada para combinar control, levantada de mira y velocidad.</Text>
      </View>
      <View style={[styles.infoRow, { borderColor: `${colors.yellow}44`, backgroundColor: `${colors.yellow}0b` }]}><Ionicons name="information-circle-outline" size={20} color={colors.yellow} /><Text style={[styles.infoText, { color: colors.muted }]}>Puedes ajustar el dispositivo y el estilo después desde el calibrador completo.</Text></View>
      <PrimaryButton colors={colors} label="GENERAR PERFIL RÁPIDO" icon="flash-outline" onPress={onStart} />
      <SecondaryButton colors={colors} label="ABRIR CALIBRADOR COMPLETO" icon="options-outline" onPress={onOpenGenerator} />
    </View>
  );
}

function GuidePanel({ colors, compact }: { colors: typeof THEME_COLORS.neon; compact: boolean }) {
  const tips = [
    ["01", "Prueba en entrenamiento, nunca en ranked. Dispara a un bot quieto y a uno en movimiento antes de subir o bajar nada."],
    ["02", "Si la mira se queda corta y no llega a la cabeza: sube General +3 y Punto rojo +2, nada más."],
    ["03", "Si la mira se pasa: baja General -3. No toques francotirador hasta que el movimiento corto esté estable."],
    ["04", "Cambia una sola variable cada vez. Si corriges dos a la vez, no sabrás qué ajuste funcionó."],
  ];
  return (
    <View style={styles.panelStack}>
      <SectionHeader colors={colors} eyebrow="MANUAL VIP" title="AJUSTE FINO" />
      <Text style={[styles.body, { color: colors.muted }]}>El generador te da una base. Estos microajustes convierten esa base en una configuración realmente tuya.</Text>
      {tips.map(([number, text]) => <Tip key={number} colors={colors} number={number} text={text} />)}
      <View style={[styles.tipFooter, { borderColor: colors.line, backgroundColor: `${colors.cyan}08` }]}><Ionicons name="shield-checkmark-outline" size={22} color={colors.green} /><Text style={[styles.tipFooterText, { color: colors.muted }]}>Regla VIP: si el control baja de 60%, vuelve al valor anterior y practica 3 minutos antes de recalibrar.</Text></View>
      {compact ? null : <Text style={[styles.microcopy, { color: colors.hot }]}>NO HAY MAGIA. HAY RANGO, CONTROL Y REPETICIÓN.</Text>}
    </View>
  );
}

function SettingsPanel({ colors, theme, themeLabel, animations, onTheme, onAnimations, onHome }: { colors: typeof THEME_COLORS.neon; theme: ThemeId; themeLabel: string; animations: boolean; onTheme: () => void; onAnimations: () => void; onHome: () => void }) {
  return (
    <View style={styles.panelStack}>
      <SectionHeader colors={colors} eyebrow="SISTEMA" title="AJUSTES" />
      <Text style={[styles.body, { color: colors.muted }]}>Personaliza la respuesta visual sin tocar los cálculos de sensibilidad.</Text>
      <SettingRow colors={colors} icon="color-palette-outline" label="Tema visual" value={themeLabel} onPress={onTheme} />
      <SettingRow colors={colors} icon="sparkles-outline" label="Animaciones" value={animations ? "ACTIVADAS" : "REDUCIDAS"} onPress={onAnimations} />
      <View style={[styles.settingsNote, { borderColor: colors.line, backgroundColor: `${colors.cyan}08` }]}><Text style={[styles.settingsCode, { color: colors.cyan }]}>THEME::{theme.toUpperCase()}</Text><Text style={[styles.settingsText, { color: colors.muted }]}>Los cambios se mantienen mientras la sesión siga abierta.</Text></View>
      <SecondaryButton colors={colors} label="VOLVER AL INICIO" icon="home-outline" onPress={onHome} />
    </View>
  );
}

function Tile({ colors, icon, title, subtitle, hot, onPress }: { colors: typeof THEME_COLORS.neon; icon: IconName; title: string; subtitle: string; hot?: boolean; onPress: () => void }) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.tile, { borderColor: hot ? `${colors.hot}66` : "rgba(255,255,255,0.1)", backgroundColor: hot ? `${colors.hot}12` : colors.panelAlt }, pressed && styles.pressed]}><View style={[styles.tileIcon, { backgroundColor: hot ? `${colors.hot}1e` : `${colors.cyan}16`, borderColor: hot ? `${colors.hot}55` : `${colors.cyan}44` }]}><Ionicons name={icon} size={20} color={hot ? colors.hot : colors.cyan} /></View><View style={styles.tileText}><Text style={[styles.tileTitle, { color: colors.text }]}>{title}</Text><Text style={[styles.tileSubtitle, { color: colors.muted }]}>{subtitle}</Text></View><Ionicons name="chevron-forward" size={17} color={colors.muted} /></Pressable>;
}

function SectionHeader({ colors, eyebrow, title }: { colors: typeof THEME_COLORS.neon; eyebrow: string; title: string }) {
  return <View style={styles.sectionHeader}><View style={[styles.sectionMark, { backgroundColor: colors.hot }]} /><View><Text style={[styles.sectionEyebrow, { color: colors.hot }]}>{eyebrow}</Text><Text style={[styles.sectionTitle, { color: colors.cyan }]}>{title}</Text></View><View style={[styles.sectionLine, { backgroundColor: colors.line }]} /></View>;
}

function SelectorField({ colors, label, value, hint, onPress }: { colors: typeof THEME_COLORS.neon; label: string; value: string; hint: string; onPress: () => void }) {
  return <View style={styles.field}><Text style={[styles.fieldLabel, { color: colors.muted }]}>{label}</Text><Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.selector, { borderColor: colors.line, backgroundColor: `${colors.bg}cc` }, pressed && styles.pressed]}><View style={{ flex: 1 }}><Text style={[styles.selectorValue, { color: colors.text }]} numberOfLines={1}>{value}</Text><Text style={[styles.selectorHint, { color: colors.muted }]}>{hint}</Text></View><Ionicons name="chevron-down" size={19} color={colors.cyan} /></Pressable></View>;
}

function PrimaryButton({ colors, label, icon, onPress }: { colors: typeof THEME_COLORS.neon; label: string; icon: IconName; onPress: () => void }) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.primaryButton, { backgroundColor: `${colors.cyan}1c`, borderColor: colors.cyan }, pressed && styles.buttonPressed]}><Ionicons name={icon} size={19} color={colors.text} /><Text style={[styles.buttonText, { color: colors.text }]}>{label}</Text></Pressable>;
}

function SecondaryButton({ colors, label, icon, onPress }: { colors: typeof THEME_COLORS.neon; label: string; icon: IconName; onPress: () => void }) {
  return <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.secondaryButton, { borderColor: colors.line, backgroundColor: `${colors.text}05` }, pressed && styles.buttonPressed]}><Ionicons name={icon} size={17} color={colors.cyan} /><Text style={[styles.secondaryText, { color: colors.muted }]}>{label}</Text></Pressable>;
}

function ValueCard({ colors, label, value, range, hot }: { colors: typeof THEME_COLORS.neon; label: string; value: number; range: string; hot?: boolean }) {
  return <View style={[styles.valueCard, { borderColor: "rgba(255,255,255,0.08)", backgroundColor: colors.panelAlt }]}><View style={[styles.valueAccent, { backgroundColor: hot ? colors.hot : colors.cyan }]} /><Text style={[styles.valueName, { color: colors.muted }]}>{label}</Text><Text style={[styles.valueNumber, { color: colors.text }]}>{value}</Text><Text style={[styles.valueRange, { color: colors.muted }]}>{range}</Text></View>;
}

function Tip({ colors, number, text }: { colors: typeof THEME_COLORS.neon; number: string; text: string }) {
  return <View style={[styles.tip, { borderColor: "rgba(255,255,255,0.08)", backgroundColor: `${colors.text}04` }]}><Text style={[styles.tipNumber, { color: colors.cyan }]}>{number}</Text><Text style={[styles.tipText, { color: colors.text }]}>{text}</Text></View>;
}

function SettingRow({ colors, icon, label, value, onPress }: { colors: typeof THEME_COLORS.neon; icon: IconName; label: string; value: string; onPress: () => void }) {
  return <Pressable accessibilityRole="switch" onPress={onPress} style={({ pressed }) => [styles.settingRow, { borderColor: "rgba(255,255,255,0.08)", backgroundColor: `${colors.text}04` }, pressed && styles.pressed]}><Ionicons name={icon} size={22} color={colors.cyan} /><View style={{ flex: 1 }}><Text style={[styles.settingLabel, { color: colors.text }]}>{label}</Text><Text style={[styles.settingValue, { color: colors.cyan }]}>{value}</Text></View><Ionicons name="swap-horizontal-outline" size={19} color={colors.muted} /></Pressable>;
}

const styles = StyleSheet.create({
  root: { flex: 1, minHeight: "100%", position: "relative" },
  gridLayer: { ...StyleSheet.absoluteFill, opacity: 0.15, borderWidth: 1, borderStyle: "dashed" },
  scanLayer: { position: "absolute", left: 0, right: 0, top: 38, height: 1, opacity: 0.2, borderTopWidth: 1 },
  appFrame: { flex: 1, marginHorizontal: 10, marginBottom: 10, borderWidth: 1, borderRadius: 18, overflow: "hidden", shadowColor: "#00f0ff", shadowOpacity: 0.18, shadowRadius: 22, elevation: 6 },
  header: { minHeight: 66, paddingHorizontal: 18, paddingVertical: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1 },
  brand: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 14, fontWeight: "900", letterSpacing: 2.2 },
  headerSub: { marginTop: 3, fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 8, letterSpacing: 1.2 },
  online: { flexDirection: "row", alignItems: "center", gap: 6 },
  onlineDot: { width: 7, height: 7, borderRadius: 7, shadowOpacity: 0.9, shadowRadius: 8 },
  onlineText: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 9, letterSpacing: 1.4 },
  viewport: { flex: 1 },
  content: { paddingHorizontal: 16, paddingTop: 18 },
  panelStack: { gap: 14 },
  hero: { gap: 9, paddingTop: 3, paddingBottom: 2 },
  badge: { alignSelf: "flex-start", overflow: "hidden", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 99, fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 9, fontWeight: "900", letterSpacing: 1.1 },
  title: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 38, lineHeight: 40, fontWeight: "900", letterSpacing: 2, textShadowOffset: { width: 0, height: 0 }, textShadowRadius: 16 },
  titleCompact: { fontSize: 32, lineHeight: 34 },
  subtitle: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 11, fontWeight: "800", letterSpacing: 2.1 },
  body: { fontSize: 15, lineHeight: 21 },
  tiles: { gap: 10 },
  tile: { minHeight: 68, borderWidth: 1, borderRadius: 13, padding: 12, flexDirection: "row", alignItems: "center", gap: 11 },
  tileIcon: { width: 39, height: 39, borderRadius: 11, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  tileText: { flex: 1, gap: 3 },
  tileTitle: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 12, fontWeight: "800", letterSpacing: 0.45 },
  tileSubtitle: { fontSize: 12, lineHeight: 16 },
  lastChip: { minHeight: 44, paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 8 },
  lastLabel: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 10, fontWeight: "900", letterSpacing: 1.1 },
  lastText: { flex: 1, fontSize: 12 },
  primaryButton: { minHeight: 52, borderWidth: 1, borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, shadowColor: "#00f0ff", shadowOpacity: 0.16, shadowRadius: 12, elevation: 2 },
  buttonText: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 11, fontWeight: "900", letterSpacing: 1.1 },
  secondaryButton: { minHeight: 50, borderWidth: 1, borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7, paddingHorizontal: 12 },
  secondaryText: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 10, fontWeight: "800", letterSpacing: 0.85 },
  pressed: { opacity: 0.78, transform: [{ scale: 0.985 }] },
  buttonPressed: { opacity: 0.82, transform: [{ scale: 0.985 }] },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 9, minHeight: 34 },
  sectionMark: { width: 3, height: 29, borderRadius: 3 },
  sectionEyebrow: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 8, fontWeight: "900", letterSpacing: 1.1 },
  sectionTitle: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 15, fontWeight: "900", letterSpacing: 1.8 },
  sectionLine: { flex: 1, height: 1, marginLeft: 3 },
  field: { gap: 6 },
  fieldLabel: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 10, fontWeight: "800", letterSpacing: 1.2, textTransform: "uppercase" },
  selector: { minHeight: 62, borderWidth: 1, borderRadius: 11, paddingHorizontal: 13, paddingVertical: 9, flexDirection: "row", alignItems: "center", gap: 10 },
  selectorValue: { fontSize: 15, fontWeight: "700" },
  selectorHint: { marginTop: 2, fontSize: 12 },
  results: { gap: 13, paddingTop: 5 },
  resultsCompact: { gap: 10 },
  valueGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9 },
  valueCard: { width: "31.8%", minHeight: 87, padding: 10, borderWidth: 1, borderRadius: 10, overflow: "hidden" },
  valueAccent: { position: "absolute", left: 0, top: 0, bottom: 0, width: 3 },
  valueName: { fontSize: 10, lineHeight: 13 },
  valueNumber: { marginTop: 3, fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 21, fontWeight: "900" },
  valueRange: { marginTop: 2, fontSize: 10 },
  dpiCard: { minHeight: 68, paddingHorizontal: 13, paddingVertical: 11, borderRadius: 11, borderWidth: 1, flexDirection: "row", alignItems: "center" },
  dpiTitle: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  dpiHint: { marginTop: 3, fontSize: 11 },
  dpiValue: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 22, fontWeight: "900" },
  meterBox: { padding: 12, borderRadius: 11, borderWidth: 1 },
  meterTop: { flexDirection: "row", justifyContent: "space-between", marginBottom: 8 },
  meterLabel: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 9, letterSpacing: 1.1 },
  meterValue: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 11, fontWeight: "900" },
  meter: { height: 7, borderRadius: 99, overflow: "hidden", backgroundColor: "rgba(255,255,255,0.09)" },
  meterFill: { height: "100%", borderRadius: 99 },
  actionRow: { flexDirection: "row", gap: 9 },
  emptyState: { minHeight: 140, borderRadius: 12, borderWidth: 1, alignItems: "center", justifyContent: "center", padding: 22, gap: 8 },
  emptyTitle: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 11, fontWeight: "900", letterSpacing: 1 },
  emptyText: { fontSize: 13, lineHeight: 18, textAlign: "center" },
  quickHero: { padding: 17, borderWidth: 1, borderRadius: 13, gap: 11 },
  quickIcon: { width: 50, height: 50, borderRadius: 15, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  quickTitle: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 16, fontWeight: "900", letterSpacing: 1 },
  infoRow: { padding: 12, borderRadius: 11, borderWidth: 1, flexDirection: "row", gap: 9, alignItems: "center" },
  infoText: { flex: 1, fontSize: 13, lineHeight: 18 },
  tip: { padding: 13, borderRadius: 11, borderWidth: 1, flexDirection: "row", gap: 11, alignItems: "flex-start" },
  tipNumber: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 12, fontWeight: "900" },
  tipText: { flex: 1, fontSize: 14, lineHeight: 20 },
  tipFooter: { padding: 12, borderRadius: 11, borderWidth: 1, flexDirection: "row", gap: 9, alignItems: "center" },
  tipFooterText: { flex: 1, fontSize: 12, lineHeight: 17 },
  microcopy: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), textAlign: "center", fontSize: 9, fontWeight: "900", letterSpacing: 1.1, paddingVertical: 5 },
  settingRow: { minHeight: 68, paddingHorizontal: 13, paddingVertical: 10, borderWidth: 1, borderRadius: 11, flexDirection: "row", alignItems: "center", gap: 11 },
  settingLabel: { fontSize: 15, fontWeight: "700" },
  settingValue: { marginTop: 3, fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 10, fontWeight: "900", letterSpacing: 1 },
  settingsNote: { padding: 14, borderWidth: 1, borderRadius: 11, gap: 7 },
  settingsCode: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 11, fontWeight: "900", letterSpacing: 1.2 },
  settingsText: { fontSize: 13, lineHeight: 18 },
  dock: { minHeight: 68, paddingTop: 8, paddingHorizontal: 8, flexDirection: "row", justifyContent: "space-around", borderTopWidth: 1, backgroundColor: "rgba(4,8,14,0.96)" },
  navButton: { minWidth: 62, alignItems: "center", justifyContent: "center", gap: 3, borderRadius: 10, paddingVertical: 5 },
  navLabel: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 9, fontWeight: "800", letterSpacing: 0.7 },
  toast: { position: "absolute", left: 28, right: 28, bottom: 92, minHeight: 42, borderRadius: 99, alignItems: "center", justifyContent: "center", paddingHorizontal: 18, shadowColor: "#00f0ff", shadowOpacity: 0.5, shadowRadius: 18, elevation: 7 },
  toastText: { color: "#001014", fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 10, fontWeight: "900", letterSpacing: 1.1, textAlign: "center" },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(0,0,0,0.72)", justifyContent: "flex-end", padding: 16 },
  modalCard: { borderWidth: 1, borderRadius: 17, padding: 16, gap: 9, marginBottom: 8 },
  modalEyebrow: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 9, fontWeight: "900", letterSpacing: 1.4 },
  modalTitle: { fontFamily: Platform.select({ android: "monospace", ios: "Menlo", default: "monospace" }), fontSize: 15, fontWeight: "900", letterSpacing: 1.2, marginBottom: 4 },
  option: { minHeight: 58, paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderRadius: 10, flexDirection: "row", alignItems: "center", gap: 8 },
  optionLabel: { fontSize: 14, fontWeight: "800" },
  optionHint: { marginTop: 2, fontSize: 11 },
});
