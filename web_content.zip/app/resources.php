<?php
declare(strict_types=1);
require_once __DIR__ . '/platform.php';
require_once __DIR__ . '/auth.php';

/** Safe, additive schema setup for the Tools & Tutorials centre and user dashboard. */
function resources_schema(): void {
    static $ready = false;
    if ($ready) return;
    $pdo = db();
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver === 'sqlite') {
        $statements = [
            "CREATE TABLE IF NOT EXISTS tool_categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 100, is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS tutorial_categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, description TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 100, is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)",
            "CREATE TABLE IF NOT EXISTS tools (id INTEGER PRIMARY KEY AUTOINCREMENT, category_id INTEGER NULL, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, logo_path TEXT NULL, short_description TEXT NOT NULL DEFAULT '', full_description TEXT NOT NULL DEFAULT '', official_url TEXT NOT NULL, download_page_url TEXT NOT NULL DEFAULT '', windows_download_url TEXT NOT NULL DEFAULT '', macos_download_url TEXT NOT NULL DEFAULT '', linux_download_url TEXT NOT NULL DEFAULT '', installation_instructions TEXT NOT NULL DEFAULT '', compatibility_info TEXT NOT NULL DEFAULT '', system_requirements TEXT NOT NULL DEFAULT '', pricing TEXT NOT NULL DEFAULT 'unknown', version TEXT NOT NULL DEFAULT '', is_featured INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'draft', source_verified_at TEXT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(category_id) REFERENCES tool_categories(id) ON DELETE SET NULL)",
            "CREATE INDEX IF NOT EXISTS idx_tools_category_status ON tools(category_id,status)",
            "CREATE INDEX IF NOT EXISTS idx_tools_featured ON tools(status,is_featured,updated_at)",
            "CREATE TABLE IF NOT EXISTS tutorials (id INTEGER PRIMARY KEY AUTOINCREMENT, category_id INTEGER NULL, title TEXT NOT NULL, slug TEXT NOT NULL UNIQUE, thumbnail_path TEXT NULL, short_description TEXT NOT NULL DEFAULT '', content_markdown TEXT NOT NULL DEFAULT '', reading_minutes INTEGER NOT NULL DEFAULT 5, difficulty TEXT NOT NULL DEFAULT 'beginner', is_featured INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'draft', last_updated_at TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(category_id) REFERENCES tutorial_categories(id) ON DELETE SET NULL)",
            "CREATE INDEX IF NOT EXISTS idx_tutorials_category_status ON tutorials(category_id,status,updated_at)",
            "CREATE INDEX IF NOT EXISTS idx_tutorials_featured ON tutorials(status,is_featured,updated_at)",
            "CREATE TABLE IF NOT EXISTS tutorial_steps (id INTEGER PRIMARY KEY AUTOINCREMENT, tutorial_id INTEGER NOT NULL, step_order INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE)",
            "CREATE INDEX IF NOT EXISTS idx_tutorial_steps_order ON tutorial_steps(tutorial_id,step_order)",
            "CREATE TABLE IF NOT EXISTS tutorial_relations (id INTEGER PRIMARY KEY AUTOINCREMENT, tutorial_id INTEGER NOT NULL, related_type TEXT NOT NULL CHECK(related_type IN ('tool','tutorial')), related_id INTEGER NOT NULL, sort_order INTEGER NOT NULL DEFAULT 100, created_at TEXT NOT NULL, UNIQUE(tutorial_id,related_type,related_id), FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE)",
            "CREATE INDEX IF NOT EXISTS idx_tutorial_relations_lookup ON tutorial_relations(tutorial_id,related_type,sort_order)",
            "CREATE TABLE IF NOT EXISTS tutorial_media (id INTEGER PRIMARY KEY AUTOINCREMENT, tutorial_id INTEGER NOT NULL, media_kind TEXT NOT NULL, disk_path TEXT NULL, external_url TEXT NULL, mime_type TEXT NOT NULL DEFAULT '', alt_text TEXT NOT NULL DEFAULT '', caption TEXT NOT NULL DEFAULT '', sort_order INTEGER NOT NULL DEFAULT 100, created_at TEXT NOT NULL, FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE)",
            "CREATE INDEX IF NOT EXISTS idx_tutorial_media_order ON tutorial_media(tutorial_id,sort_order)",
            "CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, event_key TEXT NOT NULL, title TEXT NOT NULL, message TEXT NOT NULL DEFAULT '', notification_type TEXT NOT NULL DEFAULT 'activity', link_url TEXT NOT NULL DEFAULT '', read_at TEXT NULL, created_at TEXT NOT NULL, UNIQUE(user_id,event_key))",
            "CREATE INDEX IF NOT EXISTS idx_notifications_user_created ON notifications(user_id,created_at)",
            "CREATE TABLE IF NOT EXISTS dashboard_recent_access (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, workspace TEXT NOT NULL, title TEXT NOT NULL, target_url TEXT NOT NULL, accessed_at TEXT NOT NULL)",
            "CREATE INDEX IF NOT EXISTS idx_dashboard_access_user ON dashboard_recent_access(user_id,accessed_at)",
        ];
    } elseif ($driver === 'mysql') {
        $statements = [
            "CREATE TABLE IF NOT EXISTS tool_categories (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, slug VARCHAR(160) NOT NULL UNIQUE, description TEXT NOT NULL, sort_order INT NOT NULL DEFAULT 100, is_active TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS tutorial_categories (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, slug VARCHAR(160) NOT NULL UNIQUE, description TEXT NOT NULL, sort_order INT NOT NULL DEFAULT 100, is_active TINYINT(1) NOT NULL DEFAULT 1, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS tools (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, category_id BIGINT UNSIGNED NULL, name VARCHAR(160) NOT NULL, slug VARCHAR(180) NOT NULL UNIQUE, logo_path VARCHAR(255) NULL, short_description VARCHAR(500) NOT NULL DEFAULT '', full_description TEXT NOT NULL, official_url VARCHAR(2048) NOT NULL, download_page_url VARCHAR(2048) NOT NULL DEFAULT '', windows_download_url VARCHAR(2048) NOT NULL DEFAULT '', macos_download_url VARCHAR(2048) NOT NULL DEFAULT '', linux_download_url VARCHAR(2048) NOT NULL DEFAULT '', installation_instructions TEXT NOT NULL, compatibility_info TEXT NOT NULL, system_requirements TEXT NOT NULL, pricing VARCHAR(20) NOT NULL DEFAULT 'unknown', version VARCHAR(80) NOT NULL DEFAULT '', is_featured TINYINT(1) NOT NULL DEFAULT 0, status VARCHAR(20) NOT NULL DEFAULT 'draft', source_verified_at DATE NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, KEY idx_tools_category_status(category_id,status), KEY idx_tools_featured(status,is_featured,updated_at), CONSTRAINT fk_tools_category FOREIGN KEY(category_id) REFERENCES tool_categories(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS tutorials (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, category_id BIGINT UNSIGNED NULL, title VARCHAR(180) NOT NULL, slug VARCHAR(180) NOT NULL UNIQUE, thumbnail_path VARCHAR(255) NULL, short_description VARCHAR(500) NOT NULL DEFAULT '', content_markdown LONGTEXT NOT NULL, reading_minutes INT NOT NULL DEFAULT 5, difficulty VARCHAR(20) NOT NULL DEFAULT 'beginner', is_featured TINYINT(1) NOT NULL DEFAULT 0, status VARCHAR(20) NOT NULL DEFAULT 'draft', last_updated_at DATETIME NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, KEY idx_tutorials_category_status(category_id,status), KEY idx_tutorials_featured(status,is_featured,updated_at), CONSTRAINT fk_tutorials_category FOREIGN KEY(category_id) REFERENCES tutorial_categories(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS tutorial_steps (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, tutorial_id BIGINT UNSIGNED NOT NULL, step_order INT NOT NULL, title VARCHAR(180) NOT NULL, body TEXT NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, KEY idx_tutorial_steps_order(tutorial_id,step_order), CONSTRAINT fk_tutorial_steps_tutorial FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS tutorial_relations (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, tutorial_id BIGINT UNSIGNED NOT NULL, related_type VARCHAR(20) NOT NULL, related_id BIGINT UNSIGNED NOT NULL, sort_order INT NOT NULL DEFAULT 100, created_at DATETIME NOT NULL, UNIQUE KEY uq_tutorial_relation(tutorial_id,related_type,related_id), KEY idx_tutorial_relations_lookup(tutorial_id,related_type,sort_order), CONSTRAINT fk_tutorial_relations_tutorial FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS tutorial_media (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, tutorial_id BIGINT UNSIGNED NOT NULL, media_kind VARCHAR(20) NOT NULL, disk_path VARCHAR(255) NULL, external_url VARCHAR(2048) NULL, mime_type VARCHAR(100) NOT NULL DEFAULT '', alt_text VARCHAR(255) NOT NULL DEFAULT '', caption VARCHAR(500) NOT NULL DEFAULT '', sort_order INT NOT NULL DEFAULT 100, created_at DATETIME NOT NULL, KEY idx_tutorial_media_order(tutorial_id,sort_order), CONSTRAINT fk_tutorial_media_tutorial FOREIGN KEY(tutorial_id) REFERENCES tutorials(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS notifications (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, event_key VARCHAR(190) NOT NULL, title VARCHAR(180) NOT NULL, message TEXT NOT NULL, notification_type VARCHAR(30) NOT NULL DEFAULT 'activity', link_url VARCHAR(500) NOT NULL DEFAULT '', read_at DATETIME NULL, created_at DATETIME NOT NULL, UNIQUE KEY uq_notifications_user_event(user_id,event_key), KEY idx_notifications_user_created(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            "CREATE TABLE IF NOT EXISTS dashboard_recent_access (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT UNSIGNED NOT NULL, workspace VARCHAR(40) NOT NULL, title VARCHAR(160) NOT NULL, target_url VARCHAR(500) NOT NULL, accessed_at DATETIME NOT NULL, KEY idx_dashboard_access_user(user_id,accessed_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        ];
    } else {
        throw new RuntimeException('Resource centre requires SQLite PDO.');
    }
    foreach ($statements as $sql) $pdo->exec($sql);
    $resourceDir = APP_ROOT . '/storage/resources';
    if (is_link($resourceDir)) throw new RuntimeException('Resource media directory must not be a symbolic link.');
    if (!is_dir($resourceDir) && !mkdir($resourceDir, 0750, true) && !is_dir($resourceDir)) throw new RuntimeException('Could not create private resource media storage.');
    $deny = $resourceDir . '/.htaccess';
    if (!is_file($deny)) @file_put_contents($deny, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    $ready = true;
}

function resources_slug(string $value): string {
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    return trim($value, '-') ?: 'resource-' . bin2hex(random_bytes(4));
}
function resources_safe_url(string $url, bool $allowBlank = true): string {
    $url = trim($url);
    if ($url === '' && $allowBlank) return '';
    if (strlen($url) > 2048 || !filter_var($url, FILTER_VALIDATE_URL)) throw new InvalidArgumentException('Enter a valid complete HTTPS URL.');
    $parts = parse_url($url);
    if (!is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https' || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])) throw new InvalidArgumentException('Only public HTTPS links are accepted.');
    return $url;
}
function resources_category_id(string $table, string $slug): ?int {
    if (!in_array($table, ['tool_categories','tutorial_categories'], true)) throw new InvalidArgumentException('Invalid category table.');
    $s = db()->prepare("SELECT id FROM {$table} WHERE slug=? LIMIT 1"); $s->execute([$slug]);
    $v = $s->fetchColumn(); return $v === false ? null : (int)$v;
}
function resources_seed(): void {
    resources_schema();
    $pdo = db(); $now = now_sql();
    $toolCats = [
        ['AI Media & Responsible Editing','ai-media','AI-assisted creation and editing. Use only media you own or have permission to use.',10],
        ['Realtime Voice Changers','voice-changers','Desktop and mobile voice processing tools.',20],
        ['Streaming & Production','streaming-production','Streaming, recording, virtual cameras and audio routing.',30],
        ['Creative Production','creative-production','Video, image, audio and media utility software.',40],
    ];
    $tutorialCats = [
        ['Realtime & Mobile','realtime-mobile','Camera permissions, realtime setup and mobile troubleshooting.',10],
        ['OBS & Streaming','obs-streaming','Recording, streaming, scenes and audio routing.',20],
        ['Voice Tools','voice-tools','Voice changer installation and workflow setup.',30],
        ['Image & Video Studio','image-video','Image references and video generation workflows.',40],
        ['Voice Studio','voice-studio','Fish Audio voice generation and history.',50],
        ['Responsible AI','responsible-ai','Consent, disclosure and safe synthetic media practice.',60],
    ];
    foreach ($toolCats as [$name,$slug,$desc,$order]) {
        $s=$pdo->prepare('INSERT IGNORE INTO tool_categories(name,slug,description,sort_order,is_active,created_at,updated_at) VALUES(?,?,?,?,1,?,?)');
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite') $s=$pdo->prepare('INSERT OR IGNORE INTO tool_categories(name,slug,description,sort_order,is_active,created_at,updated_at) VALUES(?,?,?,?,1,?,?)');
        $s->execute([$name,$slug,$desc,$order,$now,$now]);
    }
    foreach ($tutorialCats as [$name,$slug,$desc,$order]) {
        $s=$pdo->prepare('INSERT IGNORE INTO tutorial_categories(name,slug,description,sort_order,is_active,created_at,updated_at) VALUES(?,?,?,?,1,?,?)');
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite') $s=$pdo->prepare('INSERT OR IGNORE INTO tutorial_categories(name,slug,description,sort_order,is_active,created_at,updated_at) VALUES(?,?,?,?,1,?,?)');
        $s->execute([$name,$slug,$desc,$order,$now,$now]);
    }
    $tools = [
        ['OBS Studio','obs-studio','streaming-production','Open-source software for video recording, live streaming, scenes and audio/video sources.','A production and streaming application maintained by the OBS Project. Use scenes to combine camera, screen capture, windows, graphics and audio sources.','https://obsproject.com/','https://obsproject.com/download/','https://obsproject.com/download/','https://obsproject.com/download/','https://obsproject.com/download/','Download from the official download selector. Install the package for your operating system, open OBS, run the Auto-Configuration Wizard, then add only the camera, display and audio sources you need.','Windows 10/11; macOS 13+; Linux official distribution paths include Flathub and Ubuntu PPA. Compatibility and packaging vary by distribution.','CPU/GPU needs depend on encoder, resolution, frame rate and scene complexity. The vendor recommends using the Auto-Configuration Wizard.','free','33.0.1',1],
        ['Voicemod','voicemod','voice-changers','Realtime voice effects for supported desktop and mobile workflows.','A third-party voice processing application. Device availability differs by operating system and product mode; check the current vendor requirements before installing.','https://www.voicemod.net/','https://support.voicemod.net/hc/en-us/articles/360018501820-Download-Voicemod','https://www.voicemod.net/','https://www.voicemod.net/','','Open the vendor download guide, sign in if the vendor requires it, download the installer, run it and follow the setup prompts. Set the virtual microphone as the input only in apps where you want the effect.','Desktop app availability includes Windows 10/11 and macOS Ventura 13 or later per current vendor support guidance. Mobile app features differ from desktop.','Check the vendor system-requirements article for current CPU, memory and device-specific requirements.','freemium','Current release — see vendor page',1],
        ['Clownfish Voice Changer','clownfish-voice-changer','voice-changers','Windows microphone effects with optional standalone plugins and a terminal edition.','A third-party system-level voice changer. The vendor download page lists Windows installers and separately lists CFConsole terminal editions for Windows, macOS and Linux. Verify the intended package before installing.','https://www.clownfishvoicechanger.net/','https://www.clownfishvoicechanger.net/download/','https://www.clownfishvoicechanger.net/download/','','','Use the official vendor download page. Select the installer matching Windows architecture and VST variant, download it, run setup and restart audio applications. Avoid mirrors and repackaged installers.','Main desktop voice-changer builds are listed for Windows 7/8/8.1/10/11. The vendor page separately lists CFConsole packages for macOS and Linux; those are not the same desktop GUI workflow.','Choose a package matching the operating system and 32/64-bit requirements listed beside the official download.','free','2.10',0],
        ['Voice.ai','voice-ai','voice-changers','AI-assisted realtime voice effects for supported devices.','A third-party voice application. Use voices you are authorized to use and do not impersonate another person or mislead listeners about a real person speaking.','https://voice.ai/','https://voice.ai/platforms/pc','https://voice.ai/platforms/pc','','','Open the official PC page, review current requirements, download the installer, follow the setup prompts, sign in if required and test the input/output devices before joining a call or stream.','The vendor currently lists a Windows desktop experience; mobile availability and feature parity vary. Confirm the latest supported platform page before relying on a mobile workflow.','Vendor support lists 4 GB RAM minimum for the desktop app; graphics requirements vary by live mode.','freemium','Current release — see vendor page',0],
        ['VB-CABLE Virtual Audio Device','vb-cable','streaming-production','Virtual audio routing that connects one application output to another application input.','A virtual audio device from VB-Audio. It is useful for routing audio between compatible production applications; configure it carefully to avoid feedback loops.','https://vb-audio.com/Cable/','https://vb-audio.com/Cable/','https://vb-audio.com/Cable/','https://vb-audio.com/Cable/','','Download the current package from VB-Audio, extract it, run the setup utility with the required administrator permissions, reboot if prompted, then select CABLE Input/Output in the applications being connected.','Windows driver package supports recent Windows versions and 32/64-bit/ARM64 builds; the page also lists a separate macOS driver package.','Audio device/driver compatibility is OS-specific. Check the package notes and vendor installation guide.','free','Windows package 4.5; Mac package 1.08',0],
        ['Audacity','audacity','creative-production','Free desktop audio editor and recorder for multitrack editing, cleanup and export.','Open-source audio editing software maintained by the Audacity team. It is intended for desktop systems and is not an official Android or iOS app.','https://www.audacityteam.org/','https://www.audacityteam.org/download/','https://www.audacityteam.org/download/','https://www.audacityteam.org/download/','https://www.audacityteam.org/download/','Choose the package for Windows, macOS or Linux from the official download page. Install it, select the preferred microphone and playback device, record a short test, then export to a supported audio format.','Desktop software. Official downloads are provided for Windows, macOS and Linux; current OS requirements are published in the vendor manual/FAQ.','The vendor recommends roughly 500 MB free disk space for installation and fast, uninterrupted local storage for audio work.','free','4.0.2',0],
        ['Shotcut','shotcut','creative-production','Free, open-source cross-platform video editor with timeline editing and export.','Desktop video editing software. Obtain installers and portable packages only from the official Shotcut download page.','https://www.shotcut.org/','https://www.shotcut.org/download/','https://www.shotcut.org/download/','https://www.shotcut.org/download/','https://www.shotcut.org/download/','Open the official download page, choose the package for your OS and CPU architecture, install or extract it, import source media, edit on the timeline and export using a preset suited to your delivery resolution.','Current page lists Windows 10/11, macOS 12–27 and several 64-bit Linux distributions. Legacy OS builds are separate older releases.','Requires a compatible OS, graphics stack and adequate disk space for project media; check the release notes for supported Linux distributions.','free','26.9.27',0],
        ['GIMP','gimp','creative-production','Free, open-source image editor for photo retouching, compositing and artwork.','Cross-platform image editing software. Download packages and verify release checksums through the official project download page.','https://www.gimp.org/','https://www.gimp.org/downloads/','https://www.gimp.org/downloads/','https://www.gimp.org/downloads/','https://www.gimp.org/downloads/','Choose the correct operating-system package from the official GIMP download page. Verify the checksum where provided, install, then open and export a test image.','Current download page lists Windows 10 1903+, macOS 11+ and Linux packages such as AppImage, Flatpak and Snap depending on distribution.','CPU/RAM and disk needs vary with image dimensions, layers and plugins. The vendor provides package-specific OS notes.','free','3.2.8',0],
        ['HandBrake','handbrake','creative-production','Free, open-source video transcoder for compressing and converting media.','A video conversion utility maintained by the HandBrake project. It supports common desktop formats and provides platform-specific packages.','https://handbrake.fr/','https://handbrake.fr/downloads.php','https://handbrake.fr/downloads.php','https://handbrake.fr/downloads.php','https://handbrake.fr/downloads.php','Download the installer or package from the official HandBrake page, install it, open a source file, select an output preset, choose a destination and start encoding. Review the output before deleting the source.','Vendor page lists Windows 10+, macOS 10.13+ and Linux Flatpak/package options.','Transcoding performance depends heavily on CPU/GPU encoder, source resolution and target quality. Allow sufficient free disk space.','free','1.11.2',0],
        ['Adobe Firefly','adobe-firefly','ai-media','Web-based generative image and media tools from Adobe.','A web-based creative AI service. Review the current Firefly terms and content credentials guidance; use only assets you own or have permission to submit.','https://firefly.adobe.com/','https://firefly.adobe.com/','','','','Open the official Firefly web app, sign in through Adobe, review the available features and terms, then create using permitted source material. No third-party executable is hosted by ANONYMOUX.','Web application accessed through a supported browser; feature availability depends on region, plan and Adobe account.','A current browser and internet connection are required. System requirements vary by browser and feature.','freemium','Web app — current features on vendor site',0],
        ['NVIDIA Broadcast','nvidia-broadcast','streaming-production','AI-assisted microphone noise removal, room echo reduction and virtual camera/microphone devices for compatible NVIDIA RTX systems.','A Windows production utility from NVIDIA. It can create virtual microphone, speaker and camera devices for compatible applications. GPU and driver eligibility are essential; it is not a general-purpose mobile tool.','https://www.nvidia.com/en-us/geforce/broadcasting/broadcast-app/','https://www.nvidia.com/en-us/geforce/broadcasting/broadcast-app/','https://www.nvidia.com/en-us/geforce/broadcasting/broadcast-app/','','','Review NVIDIA\'s current GPU and driver requirements first. Download only from NVIDIA, install the application, choose the intended physical microphone/camera, enable the processing features you need, then select NVIDIA Broadcast virtual devices in compatible applications.','Windows 10/11 64-bit and Windows on Arm. Requires a supported NVIDIA RTX GPU; current page lists GeForce RTX 2060, Quadro RTX 3000, TITAN RTX or higher. Features may have higher GPU requirements.','8 GB RAM or higher; NVIDIA driver 572.61 or later for listed Windows configurations; Intel Core i5-8600 or AMD Ryzen 5 2600 or higher recommended. Internet required during installation.','free','2.3.0',0],
    ];
    foreach ($tools as $t) {
        [$name,$slug,$cat,$short,$full,$official,$download,$win,$mac,$linux,$install,$compat,$requirements,$pricing,$version,$featured] = $t;
        $exists=$pdo->prepare('SELECT id FROM tools WHERE slug=? LIMIT 1'); $exists->execute([$slug]); if ($exists->fetchColumn()) continue;
        $pdo->prepare('INSERT INTO tools(category_id,name,slug,short_description,full_description,official_url,download_page_url,windows_download_url,macos_download_url,linux_download_url,installation_instructions,compatibility_info,system_requirements,pricing,version,is_featured,status,source_verified_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? ,\'published\',?,?,?)')
            ->execute([resources_category_id('tool_categories',$cat),$name,$slug,$short,$full,$official,$download,$win,$mac,$linux,$install,$compat,$requirements,$pricing,$version,$featured,date('Y-m-d'),$now,$now]);
    }

    $tutorials = [
        ['How to use ANONYMOUX Realtime Studio on Android and mobile devices','realtime-mobile','realtime-mobile','Start a mobile realtime session, understand browser permission prompts and read the connection states honestly.',6,'beginner',1,
            "This guide covers the mobile browser workflow for ANONYMOUX Realtime Studio. The experience depends on the browser, device camera, network quality, Decart account access and currently enabled models. A local camera preview is not proof that the remote transformed stream is connected.\n\nUse a current browser over HTTPS. Keep the page open while a session is active and stop the session before leaving the page. Do not assume a result is saved unless the workspace displays an actual capture or export action.",
            [['Check browser and network','Open the application in a current Android browser such as Chrome. Use HTTPS and a stable connection. Keep the browser in the foreground while the session starts.'],['Review permissions','Tap the browser permission prompt and allow camera access only when you intend to use it. Allow microphone access only when the application requests it for a supported feature.'],['Prepare the workspace','Choose a model that is enabled in the administrator model settings. Select a prompt and optional reference image if the workspace offers it.'],['Start the session','Tap Start and wait for the interface to report each connection stage. A local camera preview means the device camera is available; wait separately for the provider connection and transformed output state.'],['Understand the status','Treat Connected/Streaming as confirmed only when the remote output is visibly updating. A connecting state, frozen frame or local preview alone is not a completed realtime transformation.'],['Stop and troubleshoot','Use Stop to close the session and release the camera. If it fails, check browser permissions, network stability, supported model access and the on-screen error. Retry only after checking whether a session is still active.'],['Save only supported output','Use the capture or download control only when it is present and reports success. If no export control is offered, the session should not be described as saved.']]],
        ['Complete OBS Studio setup for ANONYMOUX STUDIO','obs-studio-setup','obs-streaming','Install OBS, create a scene, configure camera and microphone sources, and test recording before going live.',8,'beginner',1,
            "OBS Studio is a third-party recording and streaming application. Its official downloads and setup documentation are maintained by the OBS Project. The exact source and encoder options vary by operating system and hardware.\n\nThis walkthrough describes a basic, non-destructive setup. Make a short local recording before attempting a live stream.",
            [['Download OBS','Open the official OBS download page from the Creative Tools directory. Select the operating system and architecture that match your device. Avoid unofficial installer mirrors.'],['Install and launch','Run the downloaded installer or package. Open OBS and use the Auto-Configuration Wizard to choose settings appropriate for your hardware and intended output.'],['Create a scene','In Scenes, add a new scene such as Creator Setup. Keep the scene simple while testing.'],['Add video','Under Sources, add the appropriate camera or capture source. Select the intended camera and confirm that its preview is visible.'],['Configure microphone','Add or select the microphone in Audio Mixer settings. Speak at a normal level and check that the meter responds without clipping.'],['Configure output and routing','Select the correct playback device. If a virtual cable is needed, install it from its official vendor and route one application at a time. Avoid monitoring the same signal through multiple paths, which can create echo or feedback.'],['Connect a supported ANONYMOUX workflow','Use OBS as a recording/streaming layer only. Select the camera or virtual-camera source the ANONYMOUX browser session actually exposes; do not assume the browser automatically publishes a transformed feed to OBS.'],['Test and record','Make a 20–30 second local test. Play it back, verify picture and sound, then configure streaming credentials directly inside OBS if you choose to stream. Never paste stream keys into public chat or resource pages.']]],
        ['How to install and configure Voicemod','install-voicemod','voice-tools','Follow the vendor download flow, select the correct microphone and test voice effects locally.',6,'beginner',0,
            "Voicemod is third-party software and its available desktop features depend on the supported OS and vendor account. Download from the official Voicemod website or linked support article only.\n\nDo not use a voice effect to impersonate a real person or mislead listeners about who is speaking.",
            [['Open the official guide','Use the official Voicemod download link from this resource centre. Read the vendor’s current OS and hardware requirements first.'],['Download the app','The vendor may ask you to sign in before the download begins. Save the installer from the official page.'],['Install','Run the installer and follow its on-screen prompts. Restart the app or computer if the installer requests it.'],['Choose input and output','Open Voicemod settings and select the intended physical microphone and playback device. Confirm the virtual microphone is available.'],['Test safely','Use a local recording or private test call. Adjust input gain and effects until the signal is clear.'],['Use in another app','In the target application, select the Voicemod virtual microphone as input. Switch back to the physical microphone when you no longer need processing.']]],
        ['How to install and configure Clownfish Voice Changer','install-clownfish','voice-tools','Choose the correct Windows package, install it carefully and confirm the correct microphone device.',6,'beginner',0,
            "Clownfish Voice Changer is third-party software. The vendor’s download page distinguishes Windows installers, VST variants and separately listed terminal editions. Choose the package that matches your intended use and system.\n\nThe instructions below focus on the Windows desktop build. The terminal edition is a separate workflow and should not be assumed to provide the same desktop interface.",
            [['Open the vendor page','Go to the official Clownfish download page and review the package labels and supported Windows version.'],['Select the installer','Choose the 32-bit or 64-bit package and VST variant that match your system and intended application. Do not download from third-party mirrors.'],['Install','Run the installer and follow the prompts. Grant administrator permission only to the official installer when required.'],['Restart audio apps','Close and reopen applications that use the microphone so they can refresh their available input devices.'],['Configure the microphone','Use the vendor’s setup instructions to install the effect for the intended microphone. Confirm which input device is active.'],['Test and remove if needed','Test with a local recording. If audio becomes distorted or another device stops working, disable the effect and restore the previous input selection.']]],
        ['How to connect realtime voice changers to OBS','voice-changer-obs','obs-streaming','Route a voice changer microphone into OBS and prevent doubled monitoring or feedback.',7,'intermediate',0,
            "This guide connects a third-party voice processing app to OBS where both applications expose compatible audio devices. Device names differ across Windows, macOS and Linux. Virtual audio drivers should be downloaded from their official vendor.\n\nAlways test privately before recording or streaming. Do not use voice effects to impersonate a real person.",
            [['Confirm the voice changer works','Run a local microphone test in the voice changer first. Do not add OBS to the chain until the processed microphone is available.'],['Choose the processed input','In OBS, open Settings → Audio or add an Audio Input Capture source. Select the voice changer virtual microphone when available.'],['Set monitoring deliberately','Avoid monitoring the same microphone through both OBS and the operating system at the same time. This can cause echo or feedback.'],['Route through a virtual cable only when needed','If the application does not expose a virtual microphone, review its official routing options. Install a virtual cable only from the vendor and follow its setup instructions.'],['Set levels','Speak normally and watch the OBS audio meter. Reduce gain if the meter clips. Keep desktop audio separate from microphone audio when possible.'],['Record a short test','Record locally, listen back, and verify that only the intended processed microphone is present. Keep the original physical microphone available as a fallback.']]],
        ['Configure camera and microphone permissions on Android','android-camera-mic-permissions','realtime-mobile','Review Android app permissions and browser site permissions before opening a realtime session.',5,'beginner',0,
            "Android permissions are controlled both at the operating-system level and by the browser for each website. Menu names can vary by Android version and device manufacturer. Only grant access when you understand why the page needs it.",
            [['Check system permissions','Open Android Settings → Apps → your browser → Permissions. Review Camera and Microphone permissions.'],['Check site permissions','In the browser, open the ANONYMOUX site settings. Set Camera to Allow only when you intend to use realtime video. Set Microphone only if the feature requests it.'],['Reload after changes','Return to the site and reload the page if permission settings changed. Browser permission prompts may appear again.'],['Select the intended device','When the browser offers a camera selector, choose the front or rear camera that you intend to use. Availability depends on browser and device.'],['Stop when finished','Stop the realtime session and close the camera view before leaving the page. Revoke permission later through site settings if you no longer need it.']]],
        ['How to use AI image references in Image Studio','image-reference-guide','image-video','Upload an appropriate source image and optional reference, then review the returned result and job status.',6,'beginner',0,
            "Image Studio accepts a source image and, when the selected model supports it, an optional reference image. The reference guides the generation; it does not guarantee an exact match. Only upload images you own or have permission to use.",
            [['Select a source image','Open Image Studio and choose a supported JPEG, PNG or WebP file within the configured upload limit.'],['Review the preview','Confirm the correct source is visible before submitting. Replace it if the wrong file was selected.'],['Add an optional reference','Upload a reference image only when the model supports it. Check the displayed capability notice if reference input is unavailable.'],['Write a clear prompt','Describe the requested visual change. Include details that should remain consistent, and avoid conflicting instructions.'],['Submit once','Review the estimated settings and submit. If the browser times out, check History before resubmitting because the server may still have received the request.'],['Review the actual result','Wait for the provider status to complete. Open or download only the result linked to the completed job.']]],
        ['How to submit and monitor video generation jobs','video-job-monitoring','image-video','Submit a supported video, retain its job reference and follow the provider status through completion.',6,'beginner',0,
            "Video editing uses asynchronous provider jobs. Submission is not the same as completion. Keep the job ID and use History to check the current state before retrying a timed-out submission.",
            [['Prepare the source','Choose a supported MP4, WebM or MOV file within both the application and host upload limits.'],['Select model and prompt','Choose a model currently enabled by the administrator. Write a concise prompt and attach a reference image only if supported.'],['Submit once','Start the transformation and retain the displayed job reference. Do not repeatedly press Submit while the request is pending.'],['Monitor the status','Review the provider-reported state in the workspace or History. Submitted and processing are not completed states.'],['Handle failures carefully','Read the failure message. A connection timeout can happen after a remote provider accepted the job; check History before creating another job.'],['Download the output','Use the result link only after the job status is completed and the application provides a valid output.']]],
        ['How to use AI voice generation in Voice Studio','voice-studio-guide','voice-studio','Search the provider voice library, write a script, generate speech and review the saved audio history.',6,'beginner',0,
            "Voice Studio uses the configured Fish Audio provider integration. The available voice list depends on the API key, provider permissions, pagination and current service response. Use your own voice or voices you have permission to use.\n\nDo not use generated speech to impersonate a real person or create deceptive messages.",
            [['Open Voice Studio','Confirm the administrator has configured Fish Audio access. If the provider is unavailable, the workspace should show a connection error rather than a fabricated voice list.'],['Search the voice library','Use the voice search control to find a voice by title, language or tag where available. Provider results may be paginated.'],['Review the voice','Check the provider’s description and permitted use. Do not assume that every voice is licensed for every purpose.'],['Write the script','Enter the text you want spoken. Review spelling, names and punctuation before generation.'],['Generate audio','Review any credit estimate, submit once and wait for the provider response. Failed provider requests should not be treated as successful outputs.'],['Review history','Open the saved generation and play or download it only when the audio file is present and belongs to your account.']]],
        ['How to use AI face transformation responsibly','responsible-face-transformation','responsible-ai','Use only consented media, avoid impersonation and disclose synthetic edits when viewers could be misled.',5,'beginner',1,
            "AI face transformation and synthetic media can affect real people. Use this technology only with your own images or with clear, informed permission from the person shown. A person’s consent to one edit does not automatically grant permission for every other use.\n\nNever create or distribute deceptive, humiliating, intimate or otherwise harmful media of a person. Do not imply that a real person said or did something they did not. Follow applicable law, platform policies and the rights of everyone represented.",
            [['Confirm permission','Before uploading a person’s image or video, make sure you own the media or have clear permission from the people shown for this specific kind of edit.'],['Explain the intended use','Tell the person what transformation will be made, where the output may appear and who may see it. Respect a refusal or withdrawal of permission.'],['Avoid deceptive contexts','Do not present a synthetic edit as authentic footage, evidence, an endorsement or a real statement by the person.'],['Use safe source material','Avoid private, sensitive or vulnerable contexts. Do not use images of children or other people in a way that could expose or embarrass them.'],['Label synthetic results','When a viewer could mistake an output for a real recording, clearly disclose that it has been AI-edited or generated.'],['Respect takedown requests','Remove shared content promptly when a person withdraws permission or raises a legitimate concern.']]],
    ];
    foreach ($tutorials as $t) {
        [$title,$slug,$cat,$short,$minutes,$difficulty,$featured,$content,$steps] = $t;
        $exists=$pdo->prepare('SELECT id FROM tutorials WHERE slug=? LIMIT 1'); $exists->execute([$slug]); if ($exists->fetchColumn()) continue;
        $pdo->prepare('INSERT INTO tutorials(category_id,title,slug,short_description,content_markdown,reading_minutes,difficulty,is_featured,status,last_updated_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,\'published\',?,?,?)')
            ->execute([resources_category_id('tutorial_categories',$cat),$title,$slug,$short,$content,$minutes,$difficulty,$featured,$now,$now,$now]);
        $id=(int)$pdo->lastInsertId(); $st=$pdo->prepare('INSERT INTO tutorial_steps(tutorial_id,step_order,title,body,created_at,updated_at) VALUES(?,?,?,?,?,?)');
        foreach ($steps as $i=>$step) $st->execute([$id,$i+1,$step[0],$step[1],$now,$now]);
    }
}

function resources_upload_image(array $file, string $prefix = 'resource'): string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new InvalidArgumentException('The image upload did not complete.');
    $tmp=(string)($file['tmp_name']??''); if (!is_uploaded_file($tmp)) throw new InvalidArgumentException('Image upload validation failed.');
    $size=(int)($file['size']??0); if ($size<1 || $size>5*1024*1024) throw new InvalidArgumentException('Resource images must be no larger than 5 MB.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp) ?: '';
    $map=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    if (!isset($map[$mime])) throw new InvalidArgumentException('Use a JPEG, PNG, WebP or GIF resource image. SVG files are not accepted.');
    $info=@getimagesize($tmp); if (!$info || (int)$info[0]<1 || (int)$info[1]<1 || $info[0]>5000 || $info[1]>5000 || $info[0]*$info[1]>25000000) throw new InvalidArgumentException('Resource image dimensions are invalid or too large.');
    $dir=APP_ROOT.'/storage/resources'; if (is_link($dir)) throw new RuntimeException('Resource storage is not safe.');
    if (!is_dir($dir) && !mkdir($dir,0750,true) && !is_dir($dir)) throw new RuntimeException('Resource storage is unavailable.');
    $disk=$prefix.'-'.bin2hex(random_bytes(16)).'.'.$map[$mime];
    if (!move_uploaded_file($tmp,$dir.'/'.$disk)) throw new RuntimeException('Could not store the resource image.');
    @chmod($dir.'/'.$disk,0640);
    return $disk;
}
function resources_delete_disk(?string $disk): void {
    if (!$disk || basename($disk)!==$disk) return;
    $path=APP_ROOT.'/storage/resources/'.$disk;
    if (is_file($path) && !is_link($path)) @unlink($path);
}
function resources_tool_by_slug(string $slug, bool $includeDrafts = false): ?array {
    resources_seed();
    $sql='SELECT t.*,c.name category_name,c.slug category_slug FROM tools t LEFT JOIN tool_categories c ON c.id=t.category_id WHERE t.slug=?';
    if (!$includeDrafts) $sql.=" AND t.status='published'";
    $s=db()->prepare($sql.' LIMIT 1'); $s->execute([$slug]); $r=$s->fetch(); return $r?:null;
}
function resources_tutorial_by_slug(string $slug, bool $includeDrafts = false): ?array {
    resources_seed();
    $sql='SELECT t.*,c.name category_name,c.slug category_slug FROM tutorials t LEFT JOIN tutorial_categories c ON c.id=t.category_id WHERE t.slug=?';
    if (!$includeDrafts) $sql.=" AND t.status='published'";
    $s=db()->prepare($sql.' LIMIT 1'); $s->execute([$slug]); $r=$s->fetch(); return $r?:null;
}
function resources_render_markdown(string $markdown, int $tutorialId = 0): string {
    $lines=preg_split('/\r\n|\r|\n/', $markdown) ?: []; $out=''; $paragraph=[]; $listType='';
    $flushParagraph=static function() use (&$paragraph,&$out): void { if ($paragraph) { $out.='<p>'.resources_inline_markdown(implode(' ',$paragraph),$GLOBALS['__resource_render_tutorial_id']??0).'</p>'; $paragraph=[]; } };
    $flushList=static function() use (&$listType,&$out): void { if ($listType!=='') {$out.='</'.$listType.'>';$listType='';} };
    $GLOBALS['__resource_render_tutorial_id']=$tutorialId;
    foreach ($lines as $line) {
        $trim=trim($line);
        if ($trim==='') { $flushParagraph(); $flushList(); continue; }
        if (preg_match('/^(#{1,3})\s+(.+)$/',$trim,$m)) { $flushParagraph();$flushList();$level=min(4,2+strlen($m[1]));$out.='<h'.$level.'>'.resources_inline_markdown($m[2],$tutorialId).'</h'.$level.'>';continue; }
        if (preg_match('/^[-*]\s+(.+)$/',$trim,$m)) { $flushParagraph(); if($listType!=='ul'){ $flushList();$listType='ul';$out.='<ul>'; } $out.='<li>'.resources_inline_markdown($m[1],$tutorialId).'</li>';continue; }
        if (preg_match('/^\d+[.)]\s+(.+)$/',$trim,$m)) { $flushParagraph(); if($listType!=='ol'){ $flushList();$listType='ol';$out.='<ol>'; } $out.='<li>'.resources_inline_markdown($m[1],$tutorialId).'</li>';continue; }
        $flushList(); $paragraph[]=$trim;
    }
    $flushParagraph();$flushList();unset($GLOBALS['__resource_render_tutorial_id']);return $out;
}
function resources_video_embed_url(string $url): ?string {
    try { $url=resources_safe_url($url,false); } catch(Throwable $e) { return null; }
    $parts=parse_url($url); if(!is_array($parts))return null;
    $host=strtolower((string)($parts['host']??''));$path=(string)($parts['path']??'');$query=[];parse_str((string)($parts['query']??''),$query);
    if(in_array($host,['youtube.com','www.youtube.com','m.youtube.com','youtube-nocookie.com','www.youtube-nocookie.com'],true)){
        $id='';if(str_starts_with($path,'/embed/'))$id=substr($path,7);elseif(($query['v']??'')!=='')$id=(string)$query['v'];
        if(preg_match('/^[A-Za-z0-9_-]{6,20}$/',$id))return 'https://www.youtube-nocookie.com/embed/'.$id;
    }
    if($host==='youtu.be'){$id=trim($path,'/');if(preg_match('/^[A-Za-z0-9_-]{6,20}$/',$id))return 'https://www.youtube-nocookie.com/embed/'.$id;}
    if(in_array($host,['vimeo.com','www.vimeo.com','player.vimeo.com'],true)){$id=basename($path);if(preg_match('/^[0-9]{5,15}$/',$id))return 'https://player.vimeo.com/video/'.$id;}
    return null;
}
function resources_inline_markdown(string $text, int $tutorialId): string {
    $safe=htmlspecialchars($text,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    $safe=preg_replace_callback('/!\[([^\]]*)\]\(media:(\d+)\)/',function($m) use($tutorialId){
        $s=db()->prepare("SELECT id,alt_text,caption FROM tutorial_media WHERE id=? AND tutorial_id=? AND media_kind IN ('image','gif') AND disk_path IS NOT NULL LIMIT 1");$s->execute([(int)$m[2],$tutorialId]);$r=$s->fetch();if(!$r)return '';
        $alt=htmlspecialchars((string)($m[1]?:$r['alt_text']),ENT_QUOTES,'UTF-8');$id=(int)$r['id'];return '<img class="tutorial-inline-image" src="resource-media.php?id='.$id.'" alt="'.$alt.'" loading="lazy">';
    },$safe) ?? $safe;
    $safe=preg_replace_callback('/\[([^\]]+)\]\((https:\/\/[^\s)]+)\)/',static function($m){$url=html_entity_decode($m[2],ENT_QUOTES,'UTF-8');try{$url=resources_safe_url($url,false);}catch(Throwable $e){return $m[1];}return '<a href="'.htmlspecialchars($url,ENT_QUOTES,'UTF-8').'" target="_blank" rel="noopener noreferrer">'.$m[1].'</a>';},$safe) ?? $safe;
    $safe=preg_replace('/\*\*(.+?)\*\*/','<strong>$1</strong>',$safe) ?? $safe;
    $safe=preg_replace('/(?<!\*)\*([^*]+)\*(?!\*)/','<em>$1</em>',$safe) ?? $safe;
    $safe=preg_replace('/`([^`]+)`/','<code>$1</code>',$safe) ?? $safe;
    return $safe;
}
function resources_track_access(string $workspace, string $title, string $url, int $userId): void {
    if ($userId<1) return;
    try {
        $pdo=db();
        if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite') $pdo->prepare('INSERT INTO dashboard_recent_access(user_id,workspace,title,target_url,accessed_at) VALUES(?,?,?,?,?)')->execute([$userId,$workspace,$title,$url,now_sql()]);
        else $pdo->prepare('INSERT INTO dashboard_recent_access(user_id,workspace,title,target_url,accessed_at) VALUES(?,?,?,?,?)')->execute([$userId,$workspace,$title,$url,now_sql()]);
        $keep=$pdo->prepare('SELECT id FROM dashboard_recent_access WHERE user_id=? ORDER BY accessed_at DESC,id DESC LIMIT 50');
        $keep->execute([$userId]); $ids=array_map('intval',$keep->fetchAll(PDO::FETCH_COLUMN));
        if ($ids) { $marks=implode(',',array_fill(0,count($ids),'?')); $pdo->prepare('DELETE FROM dashboard_recent_access WHERE user_id=? AND id NOT IN ('.$marks.')')->execute(array_merge([$userId],$ids)); }
    } catch(Throwable $ignored) {}
}
function resources_insert_notification(int $userId, string $eventKey, string $title, string $message, string $type, string $url, string $createdAt): void {
    $pdo=db();
    $sql=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite'
        ? 'INSERT OR IGNORE INTO notifications(user_id,event_key,title,message,notification_type,link_url,created_at) VALUES(?,?,?,?,?,?,?)'
        : 'INSERT IGNORE INTO notifications(user_id,event_key,title,message,notification_type,link_url,created_at) VALUES(?,?,?,?,?,?,?)';
    $pdo->prepare($sql)->execute([$userId,$eventKey,$title,$message,$type,$url,$createdAt]);
}
function resources_sync_notifications(int $userId, string $ownerKey, int $storageBytes, int $quotaBytes, int $walletBalance): void {
    if ($userId<1) return;
    $pdo=db(); $now=now_sql();
    $s=$pdo->prepare("SELECT id,workspace,status,updated_at FROM platform_jobs WHERE owner_key=? AND status IN ('completed','failed') ORDER BY updated_at DESC LIMIT 40");$s->execute([$ownerKey]);
    foreach($s->fetchAll() as $job){$status=(string)$job['status'];$title=$status==='completed'?'Generation completed':'Generation failed';$message=ucfirst((string)$job['workspace']).' job '.$status.'. Open History to review the recorded provider status.';$url='history.php';$event='platform:'.$job['id'].':'.$status;
        resources_insert_notification($userId,$event,$title,$message,$status==='failed'?'error':'success',$url,$job['updated_at']?:$now);
    }
    $s=$pdo->prepare("SELECT id,status,created_at FROM voice_usage WHERE user_id=? AND status IN ('success','failed') ORDER BY id DESC LIMIT 30");
    $s->execute([$userId]); foreach($s->fetchAll() as $voice){$ok=$voice['status']==='success';resources_insert_notification($userId,'voice:'.$voice['id'], $ok?'Voice generation completed':'Voice generation failed', $ok?'A successful Fish Audio request was recorded. Open Voice Studio history to review it.':'A Fish Audio request failed. Review the workspace message before retrying.', $ok?'success':'error','voice/',$voice['created_at']?:$now);}
    $s=$pdo->prepare("SELECT remote_id,ended_at FROM realtime_sessions WHERE owner_key=? AND status='ended' ORDER BY ended_at DESC LIMIT 30");
    $s->execute([$ownerKey]); foreach($s->fetchAll() as $session){resources_insert_notification($userId,'realtime:'.$session['remote_id'],'Realtime session ended','A Realtime Studio session was stopped and its recorded session state is available in the workspace.','activity','realtime/',$session['ended_at']?:$now);}
    if ($walletBalance<=20) resources_insert_notification($userId,'wallet-low:'.$userId.':'.$walletBalance,'Wallet balance is low','Your available balance is '.$walletBalance.' credits. Review your recent ledger activity.','warning','dashboard.php#credit-wallet',$now);
    if ($quotaBytes>0 && $storageBytes>=$quotaBytes*0.8) resources_insert_notification($userId,'storage-warning:'.$userId.':'.(int)floor($storageBytes/($quotaBytes*0.1)),'Storage usage is high','Your stored media has reached at least 80% of the configured account quota. Review Assets before uploading more.','warning','assets.php',$now);
}

function resources_tool_categories(bool $activeOnly = true): array {
    resources_seed();$sql='SELECT * FROM tool_categories'.($activeOnly?' WHERE is_active=1':'').' ORDER BY sort_order,name';return db()->query($sql)->fetchAll();
}
function resources_tutorial_categories(bool $activeOnly = true): array {
    resources_seed();$sql='SELECT * FROM tutorial_categories'.($activeOnly?' WHERE is_active=1':'').' ORDER BY sort_order,name';return db()->query($sql)->fetchAll();
}

/** Database-backed, paginated catalogue query shared by the public Resources page. */
function resources_catalog_page(string $kind, string $search = '', string $category = '', int $page = 1, int $perPage = 12): array {
    resources_schema();
    $kind = $kind === 'tutorials' ? 'tutorials' : 'tools';
    $page = max(1, $page);
    $perPage = max(1, min(48, $perPage));
    if ($kind === 'tools') {
        $from = ' FROM tools t LEFT JOIN tool_categories c ON c.id=t.category_id WHERE t.status=?';
        $searchSql = ' AND (t.name LIKE ? OR t.short_description LIKE ? OR t.full_description LIKE ? OR c.name LIKE ?)';
        $select = 'SELECT t.*,c.name AS category_name,c.slug AS category_slug';
        $order = ' ORDER BY t.is_featured DESC,t.name ASC,t.id DESC';
        $status = 'published';
    } else {
        $from = ' FROM tutorials t LEFT JOIN tutorial_categories c ON c.id=t.category_id WHERE t.status=?';
        $searchSql = ' AND (t.title LIKE ? OR t.short_description LIKE ? OR t.content_markdown LIKE ? OR c.name LIKE ?)';
        $select = 'SELECT t.*,c.name AS category_name,c.slug AS category_slug';
        $order = ' ORDER BY t.is_featured DESC,t.updated_at DESC,t.id DESC';
        $status = 'published';
    }
    $args = [$status];
    $where = '';
    if ($search !== '') {
        $where .= $searchSql;
        $like = '%' . $search . '%';
        array_push($args, $like, $like, $like, $like);
    }
    if ($category !== '') {
        $where .= ' AND c.slug=?';
        $args[] = $category;
    }
    $count = db()->prepare('SELECT COUNT(*)' . $from . $where);
    $count->execute($args);
    $total = (int)$count->fetchColumn();
    $pages = max(1, (int)ceil($total / $perPage));
    $page = min($page, $pages);
    $sql = $select . $from . $where . $order . ' LIMIT ' . $perPage . ' OFFSET ' . (($page - 1) * $perPage);
    $stmt = db()->prepare($sql);
    $stmt->execute($args);
    return ['items'=>$stmt->fetchAll(), 'total'=>$total, 'page'=>$page, 'pages'=>$pages, 'per_page'=>$perPage];
}
