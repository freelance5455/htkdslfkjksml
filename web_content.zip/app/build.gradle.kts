plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.qubex.party"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.qubex.party"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "9.0"
    }

    buildFeatures {
        buildConfig = true
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.webkit:webkit:1.14.0")
    implementation("com.google.android.gms:play-services-nearby:19.4.0")
}
