plugins {
    id("com.android.application")
}

android {
    namespace = "com.pettown.fantasy"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pettown.fantasy"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
