plugins { id("com.android.application") }
android {
    namespace = "app.zmessage.web"; compileSdk = 34
    defaultConfig { applicationId = "app.zmessage"; minSdk = 29; targetSdk = 34; versionCode = 2; versionName = "0.2.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
