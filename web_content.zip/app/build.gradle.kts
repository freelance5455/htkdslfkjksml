plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.riderstanding.moto3"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.riderstanding.moto3"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
