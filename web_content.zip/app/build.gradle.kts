plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "com.sreeganesh.billing"; compileSdk = 35
    defaultConfig { applicationId = "com.sreeganesh.billing"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
