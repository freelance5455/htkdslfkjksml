plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.portugalrp.game"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.portugalrp.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
