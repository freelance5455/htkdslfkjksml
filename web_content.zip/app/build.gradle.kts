plugins {
    id("com.android.application")
}

android {
    namespace = "com.procam.studio"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.procam.studio"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
}
