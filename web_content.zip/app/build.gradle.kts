plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.baocaocongviec.v2"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.baocaocongviec.v2"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
