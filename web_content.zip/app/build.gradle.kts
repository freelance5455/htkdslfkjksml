plugins {
    id("com.android.application")
}

android {
    namespace = "org.worldaudio.studio"
    compileSdk = 35

    defaultConfig {
        applicationId = "org.worldaudio.studio"
        minSdk = 26
        targetSdk = 34
        versionCode = 40100
        versionName = "4.1.0-alpha02"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
