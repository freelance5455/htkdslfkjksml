plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rollmaze.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rollmaze.game"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.webkit:webkit:1.11.0")
}

// Bundles Three.js inside the app so the game works fully offline.
// If the download fails, the game falls back to the CDN copy at runtime (needs internet).
val downloadThree by tasks.registering {
    val out = layout.projectDirectory.file("src/main/assets/three.min.js").asFile
    outputs.upToDateWhen { out.exists() && out.length() > 100_000 }
    doLast {
        if (!out.exists() || out.length() < 100_000) {
            try {
                out.parentFile.mkdirs()
                java.net.URL("https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js").openStream().use { input ->
                    out.outputStream().use { output -> input.copyTo(output) }
                }
            } catch (e: Exception) {
                logger.warn("Could not download three.min.js (" + e.message + "). The app will load it from the CDN instead.")
                out.delete()
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadThree) }
