plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.rtppragmatic"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.rtppragmatic"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
}
