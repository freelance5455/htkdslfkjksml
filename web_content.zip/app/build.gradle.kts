plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "jp.pocovirus.prank"
    compileSdk = 35

    defaultConfig {
        applicationId = "jp.pocovirus.prank"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
