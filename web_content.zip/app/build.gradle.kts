plugins { id("com.android.application") }

android {
    namespace = "com.neonmatrix.hub"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.neonmatrix.hub"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
