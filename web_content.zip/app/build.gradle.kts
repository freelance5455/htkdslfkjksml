plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose"); id("org.jetbrains.kotlin.plugin.serialization") }

android { namespace="com.getmoneymachine"; compileSdk=35
 defaultConfig { applicationId="com.getmoneymachine"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0.0"; buildConfigField("String","API_URL", "\"${project.findProperty(\"API_URL\") ?: \"\"}\"") }
 buildFeatures { compose=true; buildConfig=true }
 buildTypes {
    release {
        isMinifyEnabled=false
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"),"proguard-rules.pro")
        val ksPath=project.findProperty("RELEASE_STORE_FILE") as String?
        val ksPassword=project.findProperty("RELEASE_STORE_PASSWORD") as String?
        val keyAlias=project.findProperty("RELEASE_KEY_ALIAS") as String?
        val keyPassword=project.findProperty("RELEASE_KEY_PASSWORD") as String?
        if (ksPath!=null && ksPassword!=null && keyAlias!=null && keyPassword!=null) {
            signingConfig=signingConfigs.create("releaseSecure") {
                storeFile=file(ksPath); storePassword=ksPassword; this.keyAlias=keyAlias; this.keyPassword=keyPassword
            }
        }
    }
}
}

dependencies {
 implementation(platform("androidx.compose:compose-bom:2024.12.01"))
 implementation("androidx.compose.ui:ui"); implementation("androidx.compose.ui:ui-tooling-preview"); debugImplementation("androidx.compose.ui:ui-tooling")
 implementation("androidx.compose.material3:material3"); implementation("androidx.activity:activity-compose:1.10.0"); implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
 implementation("androidx.datastore:datastore-preferences:1.1.1")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0"); implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
}
