plugins {
    id("com.android.application")
}
android {
    namespace = "com.stargullak.v4"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.stargullak.v4"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "4.0"
    }
}
