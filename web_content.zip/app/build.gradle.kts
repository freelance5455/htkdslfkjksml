plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.prahaar.neet"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.prahaar.neet"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"
    }
}
dependencies {
    // Bundled Latin text-recognition model: recognition works offline after installation.
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
