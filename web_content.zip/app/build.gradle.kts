plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "lk.impactplus.clubmanagement"
    compileSdk = 35
    defaultConfig {
        applicationId = "lk.impactplus.clubmanagement"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
