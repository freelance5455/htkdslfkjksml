plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.app.smarty"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.app.smarty"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "11.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.android.billingclient:billing-ktx:9.1.0")
}

kotlin { jvmToolchain(17) }
