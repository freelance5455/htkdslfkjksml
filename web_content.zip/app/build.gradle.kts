plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rktechhub.snakegamepromax"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.rktechhub.snakegamepromax"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"
    }

    buildFeatures { buildConfig = true }

    buildTypes {
        debug {
            // Debug builds always use Google's sample App ID and test ad units.
            manifestPlaceholders["ADMOB_APP_ID"] = "ca-app-pub-3940256099942544~3347511713"
            buildConfigField("String", "BANNER_AD_UNIT_ID", "\"ca-app-pub-3940256099942544/9214589741\"")
            buildConfigField("String", "REWARDED_INTERSTITIAL_AD_UNIT_ID", "\"ca-app-pub-3940256099942544/5224354917\"")
            buildConfigField("boolean", "USE_TEST_ADS", "true")
        }
        release {
            // Production IDs are only compiled into release builds.
            manifestPlaceholders["ADMOB_APP_ID"] = "ca-app-pub-1496380656721365~3229477100"
            buildConfigField("String", "BANNER_AD_UNIT_ID", "\"ca-app-pub-1496380656721365/7222808419\"")
            buildConfigField("String", "REWARDED_INTERSTITIAL_AD_UNIT_ID", "\"ca-app-pub-1496380656721365/9058634267\"")
            buildConfigField("boolean", "USE_TEST_ADS", "false")
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

dependencies {
    // Google Mobile Ads SDK (Legacy API) used by AdView and RewardedInterstitialAd.
    implementation("com.google.android.gms:play-services-ads:25.4.0")
}
