plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.forgelife.app"; compileSdk = 36
    defaultConfig { applicationId = "com.forgelife.app"; minSdk = 26; targetSdk = 35; versionCode = 29; versionName = "2.9-forge-ai-auto-download" }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.1")
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
}

