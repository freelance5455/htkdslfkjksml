plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.moneytrackerpro.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.moneytrackerpro.app"; minSdk = 23; targetSdk = 35; versionCode = 2; versionName = "2.0.0" }
}
