plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ro.passatb6bird.game"
    compileSdk = 35
    defaultConfig {
        applicationId = "ro.passatb6bird.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
