plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexyvera.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexyvera.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-health-connect"
    }
}

dependencies {
    implementation("androidx.health.connect:connect-client:1.1.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
}
