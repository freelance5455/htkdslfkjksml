plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.parale.dairyfarm"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.parale.dairyfarm"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
