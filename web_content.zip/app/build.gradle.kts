plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.suraj.airtouch"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.suraj.airtouch"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            // Debug-signed so "assembleRelease" also gives an installable APK (personal use).
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += "task" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Optional: bundle the hand model into the APK when the build machine has internet.
// If the download fails (isolated build server) the build still succeeds and the app
// downloads the model itself on first run (see ModelStore.kt).
val modelFile = file("src/main/assets/hand_landmarker.task")
val downloadModel by tasks.registering {
    outputs.file(modelFile)
    outputs.upToDateWhen { modelFile.exists() && modelFile.length() > 1_000_000 }
    doLast {
        if (!modelFile.exists() || modelFile.length() < 1_000_000) {
            val part = File(modelFile.parentFile, "hand_landmarker.task.part")
            try {
                modelFile.parentFile.mkdirs()
                println("Downloading hand_landmarker.task ...")
                java.net.URL("https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task")
                    .openStream().use { i -> part.outputStream().use { o -> i.copyTo(o) } }
                if (part.length() > 1_000_000) part.renameTo(modelFile)
            } catch (e: Exception) {
                logger.warn("Hand model NOT bundled (${e.message}). The app will download it on first run.")
            } finally {
                if (part.exists()) part.delete()
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadModel) }
