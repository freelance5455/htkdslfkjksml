plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace="com.ziyaul.editing"; compileSdk=35
 defaultConfig { applicationId="com.ziyaul.editing"; minSdk=23; targetSdk=35; versionCode=8; versionName="8.0" }
}
