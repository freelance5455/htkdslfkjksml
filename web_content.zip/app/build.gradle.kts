plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.jobtracker"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.jobtracker"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
}
