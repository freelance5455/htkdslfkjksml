plugins {
    id("com.android.application")
}

android {
    namespace = "com.mindtrace.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mindtrace.app"
        minSdk = 23
        targetSdk = 28
        versionCode = 1
        versionName = "1.0"
    }
}
