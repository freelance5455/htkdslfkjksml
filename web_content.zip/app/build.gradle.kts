plugins {
    id("com.android.application")
}

android {
    namespace = "com.aljanoubia.news"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.aljanoubia.news"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
}
