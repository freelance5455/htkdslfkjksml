plugins {
    id("com.android.application")
}

android {
    namespace = "com.omshiv.communication"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.omshiv.communication"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
