const CACHE_NAME = "gavran-dhaba-v1";

const ASSETS = [
  "./index.html",
  "./waiter.html",
  "./kitchen.html",
  "./history.html",
  "./table.html",
  "./table.css",
  "./table.js",
  "./firebase.js",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png"
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// App shell (HTML/CSS/JS/icons) is served cache-first so the app opens
// instantly and works even with a weak signal. Firebase data calls go
// straight to the network since orders/menu/history need to be live.
self.addEventListener("fetch", (e) => {
  const url = e.request.url;

  if (url.includes("firebaseio.com") || url.includes("googleapis.com")) {
    return; // let Firebase's own requests pass through untouched
  }

  e.respondWith(
    caches.match(e.request).then((cached) => {
      if (cached) return cached;

      return fetch(e.request).then((response) => {
        if (e.request.method === "GET" && response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(e.request, clone));
        }
        return response;
      });
    })
  );
});
