import {
database,
ref,
set,
push,
update,
remove,
onValue

} from "./firebase.js";


// =================
// VARIABLES
// =================

let selectedTable = null;
let editIndex = null;
let notifiedTables = {};

let tables = {};

for(let i=1;i<=15;i++){
    tables[i]=[];
}


// =================
// LIVE TABLE DATA
// =================


onValue(ref(database,"tables"), snapshot=>{

    for(let i=1;i<=15;i++){
        tables[i]=[];
    }


    let data=snapshot.val();


    if(data){


        for(let t in data){


            tables[t]=[];

let orders=data[t].orders || {};

for(let id in orders){

tables[t].push({

id:id,

...orders[id]

});

}

if(
data[t].status==="completed"
&&
!notifiedTables[t]
){

showNotification(t);

notifiedTables[t]=true;

}

        }

    }


    loadTables();

    showBill();

});



// =================
// MENU DATA
// =================


// =================
// FIREBASE MENU
// =================


let menu=[];



onValue(

ref(database,"menu"),

(snapshot)=>{


menu=[];


if(snapshot.exists()){


let data=snapshot.val();


for(let id in data){


menu.push({

id:id,

...data[id]

});


}


}



loadMenu();



}

);




// =================
// TABLES
// =================


function loadTables(){


let box=document.getElementById("tablesGrid");

box.innerHTML="";


for(let i=1;i<=15;i++){


let div=document.createElement("div");


div.className="table-card";


if(tables[i].length>0)
div.classList.add("busy");


if(selectedTable==i)
div.classList.add("active");


div.innerHTML="Table "+i;


div.onclick=()=>selectTable(i);


box.appendChild(div);


}

}



function selectTable(num){

selectedTable=num;

document.getElementById("selectedTable")
.innerHTML=num;


loadTables();

showBill();

}



// =================
// ADD / EDIT DISH
// =================


function saveDish(){


let dish={

name:dishName.value,

category:dishCategory.value,

type:dishType.value,

half:Number(halfPrice.value),

full:Number(fullPrice.value)

};



if(dish.name==""){

alert("Enter Dish Name");

return;

}



if(editIndex===null){



push(

ref(database,"menu"),

dish

);



}

else{


let id=menu[editIndex].id;


update(

ref(database,"menu/"+id),

dish

);


editIndex=null;


}



clearDish();


}



function clearDish(){

dishName.value="";
halfPrice.value="";
fullPrice.value="";

}



function editDish(i){


let d=menu[i];


dishName.value=d.name;

dishCategory.value=d.category;

dishType.value=d.type;

halfPrice.value=d.half;

fullPrice.value=d.full;


editIndex=i;


}




function deleteDish(i){


if(confirm("Delete Dish?")){


let id=menu[i].id;


remove(

ref(database,"menu/"+id)

);


}


}





// =================
// MENU DISPLAY
// =================


function loadMenu(data=menu){


let box=document.getElementById("menuList");

box.innerHTML="";



data.forEach((item,i)=>{


box.innerHTML+=`

<div class="dish-card">


<div>

<h3>${item.name}</h3>

<p>${item.category} | ${item.type}</p>

<p>
Half ₹${item.half}
<br>
Full ₹${item.full}
</p>

</div>



<div>


<button onclick=
"addDish('${item.name}','Half',${item.half})">

Half

</button>


<button onclick=
"addDish('${item.name}','Full',${item.full})">

Full

</button>


<button onclick="editDish(${i})">

Edit

</button>


<button onclick="deleteDish(${i})">

Delete

</button>


</div>

</div>

`;


});


}




// =================
// ADD ORDER
// =================


function addDish(name,size,price){


if(!selectedTable){

alert("Select Table");

return;

}



push(

ref(database,
"tables/"+selectedTable+"/orders"),

{

name,
size,
price,
qty:1,

time:
new Date()
.toLocaleTimeString()

}

);



update(

ref(database,
"tables/"+selectedTable),

{
status:"cooking"
}

);


}



// =================
// BILL
// =================


function showBill(){


let box=document.getElementById("orderItems");

box.innerHTML="";


let total=0;



if(!selectedTable)
return;




tables[selectedTable]
.forEach((item,i)=>{


total += item.price*item.qty;



box.innerHTML+=`

<div class="order">


<b>${item.name}</b>

(${item.size})


<br>


<button onclick=
"changeQty(${i},-1)">

-

</button>


${item.qty}


<button onclick=
"changeQty(${i},1)">

+

</button>


<br>

₹${item.price*item.qty}


<button onclick=
"removeItem(${i})">

❌

</button>


</div>

`;



});



document
.getElementById("totalAmount")
.innerHTML=total;


}





function changeQty(i,num){


let item=tables[selectedTable][i];


let qty=item.qty+num;



if(qty<=0){


remove(

ref(
database,
"tables/"+selectedTable+
"/orders/"+item.id
)

);

delete notifiedTables[selectedTable];


}else{


update(

ref(
database,
"tables/"+selectedTable+
"/orders/"+item.id
),

{
qty:qty
}

);


}


}





function removeItem(i){


let item=
tables[selectedTable][i];


remove(

ref(
database,
"tables/"+selectedTable+
"/orders/"+item.id
)

);


}







// =================
// CHECKOUT
// =================


function checkout(){


if(!selectedTable){

alert("Select Table");

return;

}


let total =
document.getElementById("totalAmount")
.innerHTML;


let payment =
document.getElementById("payment")
.value;



push(

ref(database,"paidHistory"),

{

table:selectedTable,

items:tables[selectedTable],

total:total,

payment:payment,

date:new Date().toLocaleString()

}

);





alert("Bill Paid ₹"+total);





remove(

ref(
database,
"tables/"+selectedTable
)

);



selectedTable=null;



document
.getElementById("selectedTable")
.innerHTML="None";


}





// =================
// SEARCH + FILTER
// =================


searchDish.addEventListener("keyup",function(){


let text=this.value.toLowerCase();


loadMenu(

menu.filter(x=>

x.name.toLowerCase()
.includes(text)

)

);


});




function filterFood(type){


if(type==="All"){

loadMenu(menu);

}else{


loadMenu(

menu.filter(x=>x.type===type)

);


}


}





// =================
// NOTIFICATION
// =================


function showNotification(table){


let msg=document.createElement("div");


msg.className="notification";


msg.innerHTML=
`🔔 Table ${table} Ready`;


document.body.appendChild(msg);



setTimeout(()=>{

msg.remove();

},4000);


}



// =================
// HTML ACCESS
// =================


window.addDish=addDish;
window.editDish=editDish;
window.deleteDish=deleteDish;
window.changeQty=changeQty;
window.removeItem=removeItem;
window.checkout=checkout;
window.filterFood=filterFood;
window.saveDish=saveDish;


// START

loadTables();
loadMenu();