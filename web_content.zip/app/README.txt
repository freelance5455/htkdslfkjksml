TIKET BIOSKOP - VERSI DOWNLOAD
==============================

CARA TERCEPAT (tanpa install apa pun)
  Windows      : klik dua kali "Buka Tiket Bioskop.bat"
                 (atau klik dua kali index.html)
  Mac / Linux  : jalankan buka_mac_linux.sh, atau buka index.html
  Aplikasi terbuka di browser dan jalan offline.
  Catatan: tanpa internet, font judul diganti font bawaan (tampilan sedikit beda).

JADIKAN APLIKASI DESKTOP (.exe / .dmg / AppImage), opsional
  Butuh Node.js (nodejs.org). Lalu di folder "electron":
      npm install
      npm start        -> mencoba aplikasi dalam jendela sendiri
      npm run dist     -> membuat installer/portable di folder "dist"
  Build .exe sebaiknya dijalankan di Windows, .dmg di Mac, AppImage di Linux.
  Setelah jadi, file di folder "dist" bisa dibagikan sendiri.

ISI PAKET
  index.html                  aplikasinya (satu file)
  Buka Tiket Bioskop.bat      pembuka cepat Windows
  buka_mac_linux.sh           pembuka cepat Mac/Linux
  electron/                   proyek pembungkus aplikasi desktop
