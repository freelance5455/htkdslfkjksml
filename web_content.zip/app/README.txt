Contractor Pro V18.0.0 — Global. APK-ready single file; root index.html is required by HTML-to-APK converters.
New in V18: real cloud client (email OTP login, multi-device sync with merge + deletions) for server 1.2.0.
Includes all V16.1 fixes (alerts, overdue logic, stock, translations, layout). Offline operation is preserved.
Android note: use an https endpoint for public servers; http only for LAN/localhost.
