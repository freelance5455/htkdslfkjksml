تطبيق سبحتي (PWA يعمل بدون إنترنت)
التشغيل: ارفع المجلد على أي استضافة HTTPS (GitHub Pages / Netlify) وافتح الرابط من الموبايل ثم "إضافة إلى الشاشة الرئيسية".
لتحويله إلى APK: استخدم pwabuilder.com أو Capacitor (npx cap add android) على نفس الملفات.
للتجربة محليًا: python3 -m http.server داخل المجلد.
