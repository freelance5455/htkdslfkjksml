PAHADA PILLARS - phone par app ki tarah install karne ke tarike
================================================================

Ye ek PWA (web app) hai. Install karne ke liye ise https link par rakhna padta hai.
Isi se mic (voice) bhi chalta hai.

TARIKA 1: Netlify Drop (sabse aasaan, 2 minute)
1. Is zip ko unzip karo. "app" folder milega (andar index.html hai).
2. Phone ya computer ke browser me https://app.netlify.com/drop kholo.
3. Poore folder ko wahan drag karke chhodo. Ek https link mil jayega.
4. Phone ke Chrome me wo link kholo.
5. Chrome menu (3 dots) -> "Install app" ya "Add to Home Screen".
6. Home screen par "Pahada Pillars" ka icon aa jayega. Ab ye app ki tarah khulega.
7. Pehli baar mic ki ijazat maango to "Allow" dabao.

TARIKA 2: GitHub Pages
1. GitHub par naya repository banao, in sab files ko upload karo.
2. Settings -> Pages -> Branch: main, folder: / (root) -> Save.
3. Kuch der baad https://<naam>.github.io/<repo>/ link chalega. Aage ke steps 4-7 wahi hain.

TARIKA 3: APK file chahiye (Play Store ke bina install)
1. Upar ke tarike se https link bana lo.
2. https://www.pwabuilder.com kholo, apna link daalo, "Package for stores" -> Android.
3. Wahan se APK/AAB download hoga. APK ko phone me install karo
   (Settings me "Install unknown apps" allow karna padega).

Files:
  index.html               - poora game
  manifest.webmanifest     - app ka naam, icon, rang
  sw.js                    - offline chalane ke liye (ek baar khulne ke baad internet ke bina bhi chalta hai)
  icon-192.png, icon-512.png, icon-maskable-512.png - app icons
