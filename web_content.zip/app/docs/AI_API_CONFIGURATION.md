# AI API Configuration (photo → 3D character, image → 3D garment)

The app never contains an API key. It talks to a small backend (`server/server.js`) which holds the key and calls the AI provider.
Without a configured backend, "Generate 3D character" and "Reconstruct with AI" show a clear setup message and do nothing else. Nothing is faked.

## 1. Get a provider key
The included backend supports **Meshy** (Image-to-3D API: `POST https://api.meshy.ai/openapi/v1/image-to-3d`, polled via `GET .../image-to-3d/:id`, GLB output). Create an account at meshy.ai, enable API access and copy the key. API use is paid / credit based; check their current pricing.

## 2. Run the backend
```bash
cd app
MESHY_API_KEY=msy_xxx ALLOWED_ORIGINS=https://your-app-domain npm run backend
```
Deploy `server/server.js` on any Node 18+ host (Render, Railway, Fly.io, a VPS). Set the variables in `server/.env.example` as environment variables on the host. Use HTTPS in production.

* `ALLOWED_ORIGINS` — comma-separated list of web-app origins allowed by CORS (`*` for testing only). For the Android APK add `https://localhost` and `capacitor://localhost`.
* `RATE_LIMIT_PER_HOUR` — jobs per IP per hour (default 10), to protect your credits.

## 3. Connect the app
Open the app → Settings → "AI backend address" → paste the backend URL → **Test connection**. It reports whether the backend is reachable and has a key.

## Data handling (tell your users)
* The user sees a preview and must tick "I agree" before every AI request.
* The photo goes: phone → your backend (in memory only, never written to disk) → Meshy. The backend logs no image data.
* Meshy processes and may retain data under its own terms and privacy policy: https://www.meshy.ai — read it before launch and update the in-app Privacy Policy (Settings → Privacy policy; last section is the owner contact placeholder).
* Photos of real people: only with their consent.

## Using another provider
Add an object to `providers` in `server/server.js` with `configured()`, `create(imageDataUri)` returning a task id, and `status(taskId)` returning `{status:'pending'|'running'|'done'|'failed', progress, modelUrl, error}`; then set `PROVIDER=yourname`. The app code does not change.
