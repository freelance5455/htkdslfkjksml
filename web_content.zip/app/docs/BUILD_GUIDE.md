# Build Guide (Android APK)

An APK was **not** built in the delivery environment (no Android SDK / network there). Build it on your computer:

Requirements: Node 18+, JDK 17, Android Studio (Android SDK).

```bash
cd app
npm install
npm run vendor:three        # IMPORTANT: bundles Three.js so the APK works offline
npm run android:add         # first time only (creates ./android)
npm run android:sync        # builds ./www and syncs it into the Android project
npm run android:open        # opens Android Studio
```
In Android Studio: **Build ▸ Build Bundle(s)/APK(s) ▸ Build APK(s)**. The file is at `android/app/build/outputs/apk/debug/app-debug.apk`. For Play Store use a signed release build.

Notes
* Replace the default Capacitor launcher icon with `logo/app-icon-512.png` (Android Studio ▸ New ▸ Image Asset).
* Camera/gallery pickers work through the standard Android file chooser; no extra permissions are needed.
* Set the backend address inside the app after install (Settings), and add `https://localhost` to the backend's `ALLOWED_ORIGINS`.
* Change `appId` in `capacitor.config.json` before publishing.
