# Limitations (honest list)

* **Photo → 3D realism depends entirely on the external AI service.** The result is an AI estimate; unseen body parts are guessed, and likeness is not guaranteed. Needs a paid provider key and internet.
* **The built-in base body is a simple procedural mannequin**, not photo-realistic. It exists for customization and clothing; for realistic humans use AI generation or import a GLB.
* **Face/hair/skin/body customization applies to the base body only**, not to AI-generated or imported meshes (they have no rig/morph targets).
* **Image-based clothing** is a texture on a generic garment shape; it does not recover the real cut. "Reconstruct with AI" makes a 3D object that you fit manually.
* **No cloth simulation and no skeletal rigging/posing.** Garments are fitted by scale/position only; AI/imported garments may clip through the body.
* **OBJ** materials (.mtl) and **GLTF** external files (.bin/textures) are not loaded; GLB is recommended. FBX support depends on file contents.
* **The 3D rendering code could not be run on a real GPU in the delivery environment** (no WebGL Three.js available there). Non-3D screens, language switching, storage, and the backend were tested; test the 3D screens on your device and report problems.
* **APK not built here** — see BUILD_GUIDE.md.
* PNG export of 2048 px may fail on very old phones; use 1024.
* Data lives in the browser/app storage of one device; there is no cloud sync. Clearing app data deletes characters.
* The in-app privacy policy is a template: add your contact details and have it reviewed before publishing.
