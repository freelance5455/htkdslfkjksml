# Feature Guide

**Home** — New Character, Change of Clothes, My Characters, My Wardrobe, Export Center, Settings.

**New Character** — (a) choose a photo (Gallery / Camera / Files; JPG, PNG, WEBP), preview it, agree, and the AI backend builds a textured 3D human (GLB); (b) start from the built-in editable base body; (c) import your own GLB human.

**Character editor** — live 3D preview with tabs: Hair (style, color), Face (width, length, jaw, nose, mouth), Skin (tone swatches, roughness), Body (height, build, shoulders, legs, head), Eyes (shape, color, size, spacing), Accessories (glasses, hat, earrings, necklace, watch), Outfit, Presets, Scene (light intensity/direction, backgrounds). Save, rename, reset and presets are included. Face/body editing applies to the built-in base body only; AI/imported models can be dressed, viewed and exported.

**Change of Clothes** — pick a character, then either upload a clothing image (applied as texture on a garment fitted to the body; optional AI reconstruction into a 3D garment) or import a 3D garment (GLB/GLTF/OBJ/FBX) and fit it with size/position/rotation sliders. Save to wardrobe, or save and wear.

**My Characters** — gallery with preview, name, date; Edit, Clothes, Duplicate, Export, Delete (with confirmation).

**My Wardrobe** — categories (Casual, Formal, Traditional, Sportswear, Partywear, Custom), apply to a character, preview, rename, delete.

**3D viewer** — drag to rotate, pinch/scroll to zoom, front/side/back/full/face buttons, auto-rotate, lighting and background controls. Render quality (Auto/Low/High) in Settings for older Android phones.

**Export Center** — GLB (mesh + materials + textures) and PNG at 1024 or 2048, transparent or studio background, front/side/back (one file per view).

**Settings** — language (Bengali/English, updates all UI text), AI backend, render quality, privacy policy, clear cache, delete all data.
