# Hyper Character Design — Documentation

1. [INSTALLATION_GUIDE.md](INSTALLATION_GUIDE.md) — run the web app
2. [AI_API_CONFIGURATION.md](AI_API_CONFIGURATION.md) — enable photo-to-3D
3. [BUILD_GUIDE.md](BUILD_GUIDE.md) — build the Android APK
4. [FEATURE_GUIDE.md](FEATURE_GUIDE.md) — what each screen does
5. [LIMITATIONS.md](LIMITATIONS.md) — honest list of what is and isn't included
6. [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
7. [BANGLA_README.md](BANGLA_README.md) — বাংলায় সারসংক্ষেপ
