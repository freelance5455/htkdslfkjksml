# Installation Guide (Web App)

Requirements: Node.js 18+ (only for the helper scripts; the app itself is plain HTML/CSS/JS).

```bash
cd app
npm install                 # downloads Three.js (needs internet)
npm run vendor:three        # copies Three.js into js/vendor/three (offline use, APK)
npm run serve               # open http://localhost:8080
```

* The app uses ES modules, so it must be opened through `http://` (not by double-clicking `index.html`).
* If you skip `vendor:three`, the app loads Three.js 0.160.0 from the jsDelivr CDN and needs internet. Settings → About shows which source is used.
* To host it online, upload the folder contents (`index.html`, `css`, `js`, `logo`, `assets`) to any static host (Netlify, Vercel, GitHub Pages, your own server). HTTPS is recommended, and required for the camera on phones.
* Characters, outfits and settings are stored in the browser (IndexedDB) of each device. No account is needed.
