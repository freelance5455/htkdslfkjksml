# Troubleshooting

| Problem | Fix |
|---|---|
| Blank page when opening index.html | Serve via http (`npm run serve`); ES modules do not run from `file://`. |
| 3D screens show "Something went wrong" | Check internet (CDN) or run `npm run vendor:three`. Check the browser console. Update the browser/WebView. |
| "Could not reach the AI backend" | Check the URL in Settings (use https), that the server runs, and `ALLOWED_ORIGINS` includes your app origin. |
| "AI backend has no provider API key" | Set `MESHY_API_KEY` on the server and restart. |
| "Rate limit reached" | Wait, or raise `RATE_LIMIT_PER_HOUR`. |
| Generation fails / low quality | Use a clear, well-lit, front-facing full-body photo, one person, plain background. |
| PNG export fails | Pick 1024×1024; set Render quality to Low. |
| Slow on Android | Settings → Render quality → Low. |
| Garment looks wrong / floats | Use the Adjust sliders (size, position, rotate). Prefer GLB files. |
| Characters disappeared | Browser/app data was cleared. Export GLBs as backups. |
| `npm run prepare:www` complains about Three.js | Run `npm install` then `npm run vendor:three`. |
