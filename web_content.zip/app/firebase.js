// =====================================================
// SHARED FIREBASE MODULE
// Every page imports the same initialized app + helpers
// from here instead of repeating the config everywhere.
// =====================================================

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.4/firebase-app.js";
import {
  getDatabase,
  ref,
  push,
  update,
  remove,
  onValue,
  set
} from "https://www.gstatic.com/firebasejs/10.12.4/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyDK7wPC6F_gn_Wecl-_QQ6x3p1QlN3QjFk",
  authDomain: "hotel-gavran-dhaba.firebaseapp.com",
  databaseURL: "https://hotel-gavran-dhaba-default-rtdb.firebaseio.com/",
  projectId: "hotel-gavran-dhaba",
  storageBucket: "hotel-gavran-dhaba.firebasestorage.app",
  messagingSenderId: "1021021497263",
  appId: "1:1021021497263:web:a70336046747a03e41315a"
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

export { database, ref, push, update, remove, onValue, set };
