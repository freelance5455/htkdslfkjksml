<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

function platform_schema(): void {
    $pdo = db();
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver === 'sqlite') {
        $pdo->exec("PRAGMA busy_timeout = 5000");
        try { $pdo->query('PRAGMA journal_mode = WAL')->fetchColumn(); } catch (Throwable $ignored) { /* Shared hosts may disable WAL; default journal mode remains valid. */ }
        $pdo->exec("CREATE TABLE IF NOT EXISTS platform_jobs (
            id TEXT PRIMARY KEY, owner_key TEXT NOT NULL, workspace TEXT NOT NULL CHECK(workspace IN ('image','video')),
            provider_job_id TEXT NULL, model TEXT NOT NULL, prompt TEXT NOT NULL DEFAULT '',
            status TEXT NOT NULL CHECK(status IN ('submitted','processing','completed','failed','expired')),
            input_disk TEXT NOT NULL, reference_disk TEXT NULL, output_disk TEXT NULL,
            output_mime TEXT NULL, output_bytes INTEGER NULL, error_message TEXT NULL,
            resolution TEXT NOT NULL DEFAULT '720p', metadata TEXT NOT NULL DEFAULT '{}',
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_platform_jobs_owner_created ON platform_jobs(owner_key, created_at DESC)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_platform_jobs_provider ON platform_jobs(provider_job_id)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS platform_assets (
            id TEXT PRIMARY KEY, owner_key TEXT NOT NULL, job_id TEXT NOT NULL,
            kind TEXT NOT NULL, disk_name TEXT NOT NULL, mime_type TEXT NOT NULL,
            file_size INTEGER NOT NULL, original_name TEXT NOT NULL, created_at TEXT NOT NULL,
            FOREIGN KEY(job_id) REFERENCES platform_jobs(id) ON DELETE CASCADE
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_platform_assets_owner ON platform_assets(owner_key, created_at DESC)");
    } elseif ($driver === 'mysql') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS platform_jobs (
            id VARCHAR(40) PRIMARY KEY, owner_key CHAR(64) NOT NULL, workspace VARCHAR(16) NOT NULL,
            provider_job_id VARCHAR(120) NULL, model VARCHAR(40) NOT NULL, prompt TEXT NOT NULL,
            status VARCHAR(20) NOT NULL, input_disk VARCHAR(180) NOT NULL, reference_disk VARCHAR(180) NULL,
            output_disk VARCHAR(180) NULL, output_mime VARCHAR(100) NULL, output_bytes BIGINT NULL,
            error_message TEXT NULL, resolution VARCHAR(12) NOT NULL DEFAULT '720p', metadata LONGTEXT NOT NULL,
            created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
            KEY idx_platform_jobs_owner_created(owner_key,created_at), KEY idx_platform_jobs_provider(provider_job_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS platform_assets (
            id VARCHAR(40) PRIMARY KEY, owner_key CHAR(64) NOT NULL, job_id VARCHAR(40) NOT NULL,
            kind VARCHAR(20) NOT NULL, disk_name VARCHAR(180) NOT NULL, mime_type VARCHAR(100) NOT NULL,
            file_size BIGINT NOT NULL, original_name VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL,
            KEY idx_platform_assets_owner(owner_key,created_at), CONSTRAINT fk_platform_asset_job FOREIGN KEY(job_id) REFERENCES platform_jobs(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
}
function platform_dirs(): array {
    $base = APP_ROOT . '/storage/platform';
    foreach (['inputs','references','outputs'] as $d) {
        $p = $base . '/' . $d;
        if (!is_dir($p) && !mkdir($p,0750,true) && !is_dir($p)) throw new RuntimeException('Private storage is unavailable.');
    }
    return ['inputs'=>$base.'/inputs','references'=>$base.'/references','outputs'=>$base.'/outputs'];
}
function platform_storage_used_bytes(string $ownerKey, ?int $userId = null): int {
    $pdo = db(); $used = 0; $dirs = platform_dirs();
    $asset = $pdo->prepare('SELECT disk_name FROM platform_assets WHERE owner_key=?'); $asset->execute([$ownerKey]);
    foreach ($asset->fetchAll(PDO::FETCH_COLUMN) as $disk) {
        $path = $dirs['outputs'] . '/' . basename((string)$disk);
        if (is_file($path) && !is_link($path)) $used += (int)filesize($path);
    }
    $jobs = $pdo->prepare('SELECT input_disk,reference_disk FROM platform_jobs WHERE owner_key=?'); $jobs->execute([$ownerKey]);
    foreach ($jobs->fetchAll() as $row) {
        foreach (['input_disk'=>'inputs','reference_disk'=>'references'] as $field=>$dirKey) {
            $disk=(string)($row[$field]??''); if ($disk==='') continue;
            $path=$dirs[$dirKey].'/'.basename($disk);
            if (is_file($path) && !is_link($path)) $used += (int)filesize($path);
        }
    }
    $refs=$pdo->prepare('SELECT disk_name FROM reference_uploads WHERE owner_key=?'); $refs->execute([$ownerKey]);
    foreach ($refs->fetchAll(PDO::FETCH_COLUMN) as $disk) {
        $path=APP_ROOT.'/storage/references/'.basename((string)$disk);
        if (is_file($path) && !is_link($path)) $used += (int)filesize($path);
    }
    $userId = $userId ?? (int)($_SESSION['user_id']??0);
    if ($userId>0) {
        try {
            $voice=$pdo->prepare('SELECT audio_file FROM voice_generations WHERE user_id=?'); $voice->execute([$userId]);
            foreach ($voice->fetchAll(PDO::FETCH_COLUMN) as $disk) {
                $path=APP_ROOT.'/storage/voice-audio/'.basename((string)$disk);
                if (is_file($path) && !is_link($path)) $used += (int)filesize($path);
            }
        } catch (Throwable $ignored) { /* Voice history may not exist on an older installation. */ }
    }
    return $used;
}

function platform_upload(array $file, string $kind): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new InvalidArgumentException('Upload failed. Check the file and hosting upload limits.');
    $tmp=(string)$file['tmp_name'];
    if (!is_uploaded_file($tmp)) throw new InvalidArgumentException('Upload validation failed.');
    $size=(int)$file['size'];
    $quota=max(1,(int)(app_config()['max_storage_per_user_bytes']??1073741824));
    $used=platform_storage_used_bytes(owner_key());
    if($used+$size>$quota) throw new InvalidArgumentException('Your account storage quota has been reached. Delete older assets before uploading more files.');
    $cfg=app_config();
    $max=(int)($cfg['max_'.$kind.'_bytes'] ?? ($kind==='video'?100*1024*1024:15*1024*1024));
    if ($size<1 || $size>$max) throw new InvalidArgumentException('File exceeds the configured upload limit of '.round($max/1048576).' MB.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp) ?: '';
    $allowed = $kind==='image'
        ? ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp']
        : ['video/mp4'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov'];
    if (!isset($allowed[$mime])) throw new InvalidArgumentException($kind==='image'?'Use a JPEG, PNG or WebP image.':'Use an MP4, WebM or QuickTime video.');
    $name=bin2hex(random_bytes(18)).'.'.$allowed[$mime];
    $dirs=platform_dirs();
    $dir=$kind==='image' ? $dirs['inputs'] : $dirs['inputs'];
    if (!move_uploaded_file($tmp,$dir.'/'.$name)) throw new RuntimeException('Could not store uploaded file.');
    $meta=['disk'=>$name,'mime'=>$mime,'size'=>$size,'original'=>secure_filename((string)($file['name']??'upload'))];
    if ($kind==='image') {
        $info=@getimagesize($dir.'/'.$name);
        if (!$info || $info[0]>12000 || $info[1]>12000 || $info[0]*$info[1]>60000000) { @unlink($dir.'/'.$name); throw new InvalidArgumentException('Image dimensions exceed the supported limit.'); }
        $meta['width']=(int)$info[0]; $meta['height']=(int)$info[1];
    }
    return $meta;
}
function platform_store_job(array $row): void {
    $sql='INSERT INTO platform_jobs (id,owner_key,workspace,provider_job_id,model,prompt,status,input_disk,reference_disk,output_disk,output_mime,output_bytes,error_message,resolution,metadata,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
    db()->prepare($sql)->execute([$row['id'],owner_key(),$row['workspace'],$row['provider_job_id']??null,$row['model'],$row['prompt'],$row['status'],$row['input_disk'],$row['reference_disk']??null,$row['output_disk']??null,$row['output_mime']??null,$row['output_bytes']??null,$row['error_message']??null,$row['resolution']??'720p',json_encode($row['metadata']??[]),now_sql(),now_sql()]);
}
function platform_owned_job(string $id): array {
    $s=db()->prepare('SELECT * FROM platform_jobs WHERE id=? AND owner_key=? LIMIT 1'); $s->execute([$id,owner_key()]); $r=$s->fetch();
    if (!$r) json_response(['ok'=>false,'error'=>'Generation not found for this browser session.'],404);
    return $r;
}
function platform_curl(string $method,string $url,array $headers, mixed $postFields=null,int $timeout=180): array {
    if (!extension_loaded('curl')) throw new RuntimeException('PHP cURL is required for provider requests.');
    $ch=curl_init($url); $responseHeaders=[];
    curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>20,CURLOPT_TIMEOUT=>$timeout,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HEADERFUNCTION=>static function($c,$line) use (&$responseHeaders){$n=strlen($line);$p=explode(':',$line,2);if(count($p)===2)$responseHeaders[strtolower(trim($p[0]))]=trim($p[1]);return $n;}]);
    if($postFields!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,$postFields);
    $raw=curl_exec($ch); if($raw===false){$e=curl_error($ch);curl_close($ch);throw new RuntimeException('Provider connection failed: '.$e);}
    $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$type=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE);curl_close($ch);
    return ['status'=>$status,'body'=>(string)$raw,'content_type'=>$type,'headers'=>$responseHeaders];
}
function decart_platform_curl(string $method,string $url,array $headers,mixed $postFields=null,int $timeout=180): array {
    $keys=decart_api_key_records();
    if(!$keys) throw new RuntimeException('Decart API key is not configured. Add one in Admin → API Management or configure DECART_API_KEY.');
    $baseHeaders=array_values(array_filter($headers,static fn($h)=>!str_starts_with(strtolower((string)$h),'x-api-key:')));
    $last=null;
    foreach($keys as $key){
        try {
            $r=platform_curl($method,$url,array_merge(['X-API-KEY: '.$key['key']],$baseHeaders),$postFields,$timeout);
        } catch (Throwable $transportError) {
            decart_note_key_result($key,0,'Transport failure: '.$transportError->getMessage());
            $last=['status'=>0,'body'=>'Provider connection failed.','content_type'=>'text/plain','headers'=>[]];
            continue;
        }
        decart_note_key_result($key,(int)$r['status'],(int)$r['status']>=400?'HTTP '.$r['status'].' '.substr((string)$r['body'],0,400):'');
        if(in_array((int)$r['status'],[0,408,425,429,500,502,503,504],true)&&count($keys)>1){$last=$r;continue;}
        return $r;
    }
    return $last??['status'=>503,'body'=>'No active API key.','content_type'=>'text/plain','headers'=>[]];
}

function platform_provider_error(array $r): string {
    $j=json_decode($r['body'],true);$m=is_array($j)?($j['detail']??$j['message']??$j['error']??''):'';
    if(is_array($m))$m=json_encode($m);
    return is_string($m)&&$m!==''?$m:'Provider returned HTTP '.(int)$r['status'].'.';
}
function platform_save_asset(string $jobId,string $disk,string $mime,string $kind,string $name): void {
    $path=platform_dirs()['outputs'].'/'.$disk;
    $id=bin2hex(random_bytes(16));
    db()->prepare('INSERT INTO platform_assets (id,owner_key,job_id,kind,disk_name,mime_type,file_size,original_name,created_at) VALUES (?,?,?,?,?,?,?,?,?)')
      ->execute([$id,owner_key(),$jobId,$kind,$disk,$mime,filesize($path),$name,now_sql()]);
}
platform_schema();
