/* ============================================================
   TGPSC Ready — App logic
   ============================================================ */
(function(){
  "use strict";

  const STORE_KEY = "tgpsc_ready_state_v1";
  const defaultState = {
    theme: "light",
    read: {},        // "subjectId::topicIndex": true
    bookmarks: {},    // "subjectId::topicIndex": true
    coins: 0,
    studySeconds: 0,
    downloads: 0,
    adsWatched: 0,
  };

  let state = loadState();
  let currentView = { type: "home" };        // home | subject | topic | search | bookmarks | rewards
  let studyTimer = null;
  let lastMinuteTick = 0;

  function loadState(){
    try{
      const raw = localStorage.getItem(STORE_KEY);
      if(!raw) return structuredCloneSafe(defaultState);
      return Object.assign(structuredCloneSafe(defaultState), JSON.parse(raw));
    }catch(e){ return structuredCloneSafe(defaultState); }
  }
  function structuredCloneSafe(o){ return JSON.parse(JSON.stringify(o)); }
  function saveState(){
    try{ localStorage.setItem(STORE_KEY, JSON.stringify(state)); }catch(e){ /* storage unavailable */ }
  }

  function key(subjectId, topicIdx){ return subjectId + "::" + topicIdx; }

  function totalTopics(){
    return SUBJECTS.reduce((n,s)=> n + s.topics.length, 0);
  }
  function readCount(){ return Object.keys(state.read).filter(k=>state.read[k]).length; }
  function subjectReadCount(s){
    return s.topics.filter((t,i)=> state.read[key(s.id,i)]).length;
  }

  /* ---------------- DOM refs ---------------- */
  const el = {
    sidebar: document.getElementById("sidebar"),
    sidebarList: document.getElementById("sidebarList"),
    backdrop: document.getElementById("sidebarBackdrop"),
    main: document.getElementById("main"),
    search: document.getElementById("searchInput"),
    coinpill: document.getElementById("coinPill"),
    themeBtn: document.getElementById("themeBtn"),
    hamburger: document.getElementById("hamburgerBtn"),
    progressLabel: document.getElementById("sidebarProgressLabel"),
    progressBar: document.getElementById("sidebarProgressBar"),
    overlay: document.getElementById("adOverlay"),
    adFill: document.getElementById("adFill"),
    adTimeLeft: document.getElementById("adTimeLeft"),
    toast: document.getElementById("toast"),
  };

  /* ---------------- Sidebar ---------------- */
  function renderSidebar(){
    el.sidebarList.innerHTML = "";
    SUBJECTS.forEach(s=>{
      const wrap = document.createElement("div");
      wrap.className = "subject";
      wrap.dataset.subject = s.id;

      const head = document.createElement("div");
      head.className = "subject-head";
      head.innerHTML = `<span class="ic">${s.icon}</span><span class="nm">${s.name}</span><span class="count">${subjectReadCount(s)}/${s.topics.length}</span><span class="chev">›</span>`;
      head.addEventListener("click", ()=>{
        wrap.classList.toggle("open");
      });
      wrap.appendChild(head);

      const list = document.createElement("div");
      list.className = "topiclist";
      s.topics.forEach((t,i)=>{
        const row = document.createElement("div");
        const k = key(s.id,i);
        row.className = "topicrow" + (state.read[k] ? " read":"");
        row.innerHTML = `<span class="dot"></span><span>${t.title}</span>`;
        row.addEventListener("click", (ev)=>{ ev.stopPropagation(); openTopic(s.id, i); closeSidebarMobile(); });
        list.appendChild(row);
      });
      wrap.appendChild(list);
      el.sidebarList.appendChild(wrap);
    });
    updateSidebarProgress();
  }

  function updateSidebarProgress(){
    const total = totalTopics();
    const done = readCount();
    const pct = total ? Math.round((done/total)*100) : 0;
    el.progressLabel.textContent = `Studied ${done}/${total}`;
    el.progressBar.style.width = pct + "%";
    document.querySelectorAll(".subject").forEach(w=>{
      const s = SUBJECTS.find(x=>x.id===w.dataset.subject);
      const countEl = w.querySelector(".count");
      if(s && countEl) countEl.textContent = `${subjectReadCount(s)}/${s.topics.length}`;
    });
    document.querySelectorAll(".topicrow").forEach((row, idx)=>{});
    refreshTopicRowStates();
  }

  function refreshTopicRowStates(){
    document.querySelectorAll(".subject").forEach(wrap=>{
      const sid = wrap.dataset.subject;
      const rows = wrap.querySelectorAll(".topicrow");
      rows.forEach((row,i)=>{
        row.classList.toggle("read", !!state.read[key(sid,i)]);
        row.classList.toggle("active", currentView.type==="topic" && currentView.subjectId===sid && currentView.topicIdx===i);
      });
    });
  }

  function closeSidebarMobile(){
    el.sidebar.classList.remove("open");
    el.backdrop.classList.remove("show");
  }

  /* ---------------- Views ---------------- */
  function renderHome(){
    currentView = { type:"home" };
    const done = readCount(), total = totalTopics();
    const pct = total ? Math.round((done/total)*100) : 0;
    el.main.innerHTML = `
      <div class="home-hero">
        <div class="eyebrow">TGPSC · SI &amp; Constable</div>
        <h1>Everything you need to clear the exam, in one register.</h1>
        <p>${SUBJECTS.length} subjects, ${totalTopics()} topic notes covering Polity, History, Geography, Economy, Telangana GK, Science, Arithmetic, Reasoning, English, Computer Awareness, Environment and Current Affairs — free to read and download.</p>
        <div class="stat-row">
          <div class="stat"><div class="n">${pct}%</div><div class="l">Overall progress</div></div>
          <div class="stat"><div class="n">${state.coins}</div><div class="l">Study coins earned</div></div>
          <div class="stat"><div class="n">${Object.keys(state.bookmarks).filter(k=>state.bookmarks[k]).length}</div><div class="l">Bookmarked topics</div></div>
          <div class="stat"><div class="n">${state.downloads}</div><div class="l">Notes downloaded</div></div>
        </div>
      </div>
      <div class="subject-grid" id="subjectGrid"></div>
    `;
    const grid = document.getElementById("subjectGrid");
    SUBJECTS.forEach(s=>{
      const done = subjectReadCount(s);
      const pct = Math.round((done/s.topics.length)*100);
      const card = document.createElement("div");
      card.className = "subject-card";
      card.innerHTML = `
        <div class="top"><span class="ic">${s.icon}</span><span class="meta">${done}/${s.topics.length}</span></div>
        <h3>${s.name}</h3>
        <div class="meta">${s.topics.length} topic notes</div>
        <div class="mini-bar bar"><span style="width:${pct}%"></span></div>
      `;
      card.addEventListener("click", ()=> openSubject(s.id));
      grid.appendChild(card);
    });
    refreshTopicRowStates();
  }

  function openSubject(id){
    const s = SUBJECTS.find(x=>x.id===id);
    if(!s) return;
    currentView = { type:"subject", subjectId:id };
    const done = subjectReadCount(s);
    el.main.innerHTML = `
      <div class="crumbs"><button id="crumbHome">All subjects</button> / ${s.name}</div>
      <div class="subject-header-bar">
        <div><h1 style="font-size:24px;margin-bottom:4px;">${s.icon} ${s.name}</h1>
        <div style="color:var(--ink-soft);font-size:13px;">${done}/${s.topics.length} topics studied</div></div>
        <div class="actionrow" style="margin:0;">
          <button class="btn" id="dlSubjectTxt">Download all notes (.txt)</button>
          <button class="btn primary" id="dlSubjectPdf">Download all notes (PDF)</button>
        </div>
      </div>
      <div class="searchresults" id="topicMiniList"></div>
    `;
    document.getElementById("crumbHome").addEventListener("click", renderHome);
    document.getElementById("dlSubjectTxt").addEventListener("click", ()=> downloadSubjectText(s));
    document.getElementById("dlSubjectPdf").addEventListener("click", ()=> downloadSubjectPdf(s));
    const list = document.getElementById("topicMiniList");
    s.topics.forEach((t,i)=>{
      const row = document.createElement("div");
      row.className = "topic-mini";
      const k = key(s.id,i);
      row.innerHTML = `<div class="sub">${state.read[k] ? "✓ studied" : "not studied yet"}${state.bookmarks[k] ? " · ★ bookmarked" : ""}</div><h4>${t.title}</h4><p>${t.explain}</p>`;
      row.addEventListener("click", ()=> openTopic(s.id, i));
      list.appendChild(row);
    });
    openSidebarSubject(id);
    refreshTopicRowStates();
  }

  function openSidebarSubject(id){
    document.querySelectorAll(".subject").forEach(w=>{
      w.classList.toggle("open", w.dataset.subject === id);
    });
  }

  function openTopic(subjectId, topicIdx){
    const s = SUBJECTS.find(x=>x.id===subjectId);
    if(!s) return;
    const t = s.topics[topicIdx];
    currentView = { type:"topic", subjectId, topicIdx };
    const k = key(subjectId, topicIdx);
    const isRead = !!state.read[k];
    const isBookmarked = !!state.bookmarks[k];

    el.main.innerHTML = `
      <div class="crumbs"><button id="crumbHome">All subjects</button> / <button id="crumbSubject">${s.name}</button> / ${t.title}</div>
      <div class="topic-card">
        <span class="subject-tag">${s.icon} ${s.name}</span>
        <h2>${t.title}</h2>

        <div class="block">
          <div class="h">Easy explanation</div>
          <p>${t.explain}</p>
        </div>

        <div class="block">
          <div class="h">Shortcut / trick</div>
          <div class="trickbox">${t.trick}</div>
        </div>

        <div class="block">
          <div class="h">Quick question — test yourself first</div>
          <div class="quizbox">
            <div class="q">${t.quiz}</div>
            <button class="revealbtn" id="revealBtn">Reveal answer</button>
            <div class="answerline" id="answerLine"><strong>Answer:</strong> ${t.answer}</div>
          </div>
        </div>

        <div class="actionrow">
          <button class="btn ${isRead ? "on":""}" id="markReadBtn">${isRead ? "✓ Studied" : "Mark as studied"}</button>
          <button class="btn ${isBookmarked ? "on":""}" id="bookmarkBtn">${isBookmarked ? "★ Bookmarked" : "☆ Bookmark"}</button>
          <button class="btn" id="dlTxtBtn">Download note (.txt)</button>
          <button class="btn primary" id="dlPdfBtn">Download note (PDF)</button>
        </div>
      </div>
    `;
    document.getElementById("crumbHome").addEventListener("click", renderHome);
    document.getElementById("crumbSubject").addEventListener("click", ()=> openSubject(subjectId));
    document.getElementById("revealBtn").addEventListener("click", (e)=>{
      document.getElementById("answerLine").classList.add("show");
      e.target.style.display = "none";
    });
    document.getElementById("markReadBtn").addEventListener("click", ()=> toggleRead(subjectId, topicIdx));
    document.getElementById("bookmarkBtn").addEventListener("click", ()=> toggleBookmark(subjectId, topicIdx));
    document.getElementById("dlTxtBtn").addEventListener("click", ()=> downloadTopicText(s, t));
    document.getElementById("dlPdfBtn").addEventListener("click", ()=> downloadTopicPdf(s, t));

    openSidebarSubject(subjectId);
    refreshTopicRowStates();
  }

  function toggleRead(subjectId, topicIdx){
    const k = key(subjectId, topicIdx);
    const wasRead = !!state.read[k];
    state.read[k] = !wasRead;
    if(!wasRead){ state.coins += 2; showToast("Marked as studied · +2 coins"); }
    saveState();
    updateCoinPill();
    updateSidebarProgress();
    if(currentView.type === "topic") openTopic(subjectId, topicIdx);
    else if(currentView.type === "subject") openSubject(subjectId);
    else if(currentView.type === "home") renderHome();
  }

  function toggleBookmark(subjectId, topicIdx){
    const k = key(subjectId, topicIdx);
    state.bookmarks[k] = !state.bookmarks[k];
    saveState();
    showToast(state.bookmarks[k] ? "Bookmarked" : "Removed bookmark");
    if(currentView.type === "topic") openTopic(subjectId, topicIdx);
  }

  /* ---------------- Search ---------------- */
  function runSearch(qRaw){
    const q = qRaw.trim().toLowerCase();
    if(!q){ renderHome(); return; }
    currentView = { type:"search" };
    const results = [];
    SUBJECTS.forEach(s=>{
      s.topics.forEach((t,i)=>{
        const hay = (t.title+" "+t.explain+" "+t.trick+" "+t.quiz).toLowerCase();
        if(hay.includes(q)) results.push({s,t,i});
      });
    });
    el.main.innerHTML = `
      <div class="crumbs"><button id="crumbHome">All subjects</button> / Search results for "${qRaw}"</div>
      <h1 style="font-size:22px;">${results.length} result${results.length===1?"":"s"} found</h1>
      <div class="searchresults" id="searchResultsList"></div>
    `;
    document.getElementById("crumbHome").addEventListener("click", ()=>{ el.search.value=""; renderHome(); });
    const list = document.getElementById("searchResultsList");
    if(results.length===0){
      list.innerHTML = `<div class="empty">No notes matched. Try a shorter or different keyword.</div>`;
      return;
    }
    results.forEach(r=>{
      const row = document.createElement("div");
      row.className = "topic-mini";
      row.innerHTML = `<div class="sub">${r.s.icon} ${r.s.name}</div><h4>${r.t.title}</h4><p>${r.t.explain}</p>`;
      row.addEventListener("click", ()=>{ el.search.value=""; openTopic(r.s.id, r.i); });
      list.appendChild(row);
    });
  }

  /* ---------------- Bookmarks page ---------------- */
  function renderBookmarks(){
    currentView = { type:"bookmarks" };
    const rows = [];
    SUBJECTS.forEach(s=> s.topics.forEach((t,i)=>{
      if(state.bookmarks[key(s.id,i)]) rows.push({s,t,i});
    }));
    el.main.innerHTML = `
      <div class="crumbs"><button id="crumbHome">All subjects</button> / Bookmarks</div>
      <h1 style="font-size:24px;">★ Your bookmarked topics</h1>
      <div class="list-page" id="bookmarkList"></div>
    `;
    document.getElementById("crumbHome").addEventListener("click", renderHome);
    const wrap = document.getElementById("bookmarkList");
    if(rows.length===0){ wrap.innerHTML = `<div class="empty">Nothing bookmarked yet. Open any topic and tap ☆ Bookmark to save it here.</div>`; return; }
    rows.forEach(r=>{
      const row = document.createElement("div");
      row.className = "list-row";
      row.innerHTML = `<div><div class="sub">${r.s.icon} ${r.s.name}</div><strong>${r.t.title}</strong></div><span>›</span>`;
      row.addEventListener("click", ()=> openTopic(r.s.id, r.i));
      wrap.appendChild(row);
    });
  }

  /* ---------------- Rewards page ---------------- */
  function renderRewards(){
    currentView = { type:"rewards" };
    const mins = Math.floor(state.studySeconds/60);
    el.main.innerHTML = `
      <div class="crumbs"><button id="crumbHome">All subjects</button> / Study Rewards</div>
      <h1 style="font-size:24px;">Study Rewards</h1>
      <p style="max-width:60ch;color:var(--ink-soft);">Earn <strong>StudyCoins</strong> for time spent reading, for marking topics studied, and for watching a short rewarded video. This is a demo rewards engine — wiring it to a real ad network (AdSense/AdMob) and a payout system needs a backend, which isn't included here.</p>
      <div class="stat-row">
        <div class="stat"><div class="n">${state.coins}</div><div class="l">Total StudyCoins</div></div>
        <div class="stat"><div class="n">${mins}</div><div class="l">Minutes studied</div></div>
        <div class="stat"><div class="n">${state.downloads}</div><div class="l">Notes downloaded</div></div>
        <div class="stat"><div class="n">${state.adsWatched}</div><div class="l">Rewarded videos watched</div></div>
      </div>
      <div class="actionrow">
        <button class="btn primary" id="watchAdBtn">▶ Watch a video, earn 10 coins</button>
      </div>
    `;
    document.getElementById("crumbHome").addEventListener("click", renderHome);
    document.getElementById("watchAdBtn").addEventListener("click", startRewardedAd);
  }

  /* ---------------- Rewarded "ad" simulation ---------------- */
  function startRewardedAd(){
    el.overlay.classList.add("show");
    el.adFill.style.width = "0%";
    let seconds = 15;
    el.adTimeLeft.textContent = seconds + "s remaining";
    let elapsed = 0;
    const timer = setInterval(()=>{
      elapsed += 1;
      const pct = Math.min(100, Math.round((elapsed/seconds)*100));
      el.adFill.style.width = pct + "%";
      el.adTimeLeft.textContent = Math.max(0, seconds-elapsed) + "s remaining";
      if(elapsed >= seconds){
        clearInterval(timer);
        el.adTimeLeft.textContent = "Complete — coins credited!";
        state.coins += 10;
        state.adsWatched += 1;
        saveState();
        updateCoinPill();
        setTimeout(()=>{ el.overlay.classList.remove("show"); if(currentView.type==="rewards") renderRewards(); showToast("+10 coins credited"); }, 900);
      }
    }, 1000);
  }

  /* ---------------- Downloads ---------------- */
  function buildTopicText(s, t){
    return [
      "TGPSC READY — STUDY NOTE",
      "=".repeat(40),
      "Subject: " + s.name,
      "Topic: " + t.title,
      "",
      "EASY EXPLANATION",
      "-".repeat(20),
      t.explain,
      "",
      "SHORTCUT / TRICK",
      "-".repeat(20),
      t.trick,
      "",
      "QUICK QUESTION",
      "-".repeat(20),
      "Q: " + t.quiz,
      "A: " + t.answer,
      "",
      "Downloaded from TGPSC Ready — tgpsc-ready.app",
    ].join("\n");
  }

  function buildSubjectText(s){
    let out = ["TGPSC READY — " + s.name.toUpperCase() + " — FULL NOTES", "=".repeat(50), ""];
    s.topics.forEach((t,i)=>{
      out.push(`${i+1}. ${t.title}`);
      out.push("-".repeat(30));
      out.push("Explanation: " + t.explain);
      out.push("Trick: " + t.trick);
      out.push("Q: " + t.quiz);
      out.push("A: " + t.answer);
      out.push("");
    });
    out.push("Downloaded from TGPSC Ready — tgpsc-ready.app");
    return out.join("\n");
  }

  function triggerBlobDownload(filename, text){
    const blob = new Blob([text], {type:"text/plain;charset=utf-8"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  function creditDownload(){
    state.downloads += 1; state.coins += 3;
    saveState(); updateCoinPill();
    showToast("Downloaded · +3 coins");
  }

  function downloadTopicText(s, t){
    triggerBlobDownload(slug(s.name+"-"+t.title)+".txt", buildTopicText(s,t));
    creditDownload();
  }
  function downloadSubjectText(s){
    triggerBlobDownload(slug(s.name)+"-full-notes.txt", buildSubjectText(s));
    creditDownload();
  }

  function slug(str){ return str.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/(^-|-$)/g,""); }

  /* PDF export — uses jsPDF from CDN if available, else falls back to text download */
  function withJsPDF(cb){
    if(window.jspdf && window.jspdf.jsPDF){ cb(window.jspdf.jsPDF); return; }
    showToast("PDF engine unavailable offline — downloading .txt instead");
    return null;
  }

  function downloadTopicPdf(s, t){
    const ok = withJsPDF((JsPDF)=>{
      const doc = new JsPDF();
      writePdfHeader(doc, s.name);
      let y = 34;
      y = writeWrapped(doc, t.title, 14, y, 16, true);
      y += 4;
      y = writePdfSection(doc, "Easy explanation", t.explain, y);
      y = writePdfSection(doc, "Shortcut / trick", t.trick, y);
      y = writePdfSection(doc, "Quick question", "Q: " + t.quiz + "\nA: " + t.answer, y);
      doc.save(slug(s.name+"-"+t.title)+".pdf");
      creditDownload();
    });
    if(ok === null){ downloadTopicText(s,t); }
  }

  function downloadSubjectPdf(s){
    const ok = withJsPDF((JsPDF)=>{
      const doc = new JsPDF();
      writePdfHeader(doc, s.name + " — full notes");
      let y = 34;
      s.topics.forEach((t,i)=>{
        if(y > 260){ doc.addPage(); y = 20; }
        y = writeWrapped(doc, (i+1)+". "+t.title, 14, y, 14, true);
        y = writePdfSection(doc, "Explanation", t.explain, y);
        y = writePdfSection(doc, "Trick", t.trick, y);
        y = writePdfSection(doc, "Q&A", "Q: "+t.quiz+"\nA: "+t.answer, y);
        y += 4;
      });
      doc.save(slug(s.name)+"-full-notes.pdf");
      creditDownload();
    });
    if(ok === null){ downloadSubjectText(s); }
  }

  function writePdfHeader(doc, title){
    doc.setFillColor(20,32,46);
    doc.rect(0,0,210,20,"F");
    doc.setTextColor(255,255,255);
    doc.setFontSize(13);
    doc.text("TGPSC Ready", 14, 13);
    doc.setTextColor(20,32,46);
    doc.setFontSize(11);
    doc.text(title, 14, 27);
    doc.setDrawColor(185,138,46);
    doc.line(14,29,196,29);
  }
  function writeWrapped(doc, str, x, y, size, bold){
    doc.setFont(undefined, bold ? "bold":"normal");
    doc.setFontSize(size);
    const lines = doc.splitTextToSize(str, 182);
    doc.text(lines, x, y);
    return y + lines.length * (size*0.42) + 2;
  }
  function writePdfSection(doc, label, body, y){
    if(y > 265){ doc.addPage(); y = 20; }
    doc.setFont(undefined, "bold"); doc.setFontSize(10.5);
    doc.setTextColor(138,36,50);
    doc.text(label, 14, y);
    y += 5;
    doc.setTextColor(20,32,46);
    doc.setFont(undefined, "normal"); doc.setFontSize(10.5);
    const lines = doc.splitTextToSize(body, 182);
    if(y + lines.length*4.6 > 285){ doc.addPage(); y = 20; }
    doc.text(lines, 14, y);
    return y + lines.length*4.6 + 4;
  }

  function downloadAllNotes(){
    const ok = withJsPDF((JsPDF)=>{
      const doc = new JsPDF();
      writePdfHeader(doc, "Complete Master Notes — All Subjects");
      let y = 34;
      SUBJECTS.forEach(s=>{
        if(y > 255){ doc.addPage(); y = 20; }
        y = writeWrapped(doc, s.icon + " " + s.name, 14, y, 15, true);
        s.topics.forEach((t,i)=>{
          y = writePdfSection(doc, (i+1)+". "+t.title, t.explain + "\nTrick: "+t.trick, y);
        });
        y += 4;
      });
      doc.save("tgpsc-ready-complete-notes.pdf");
      creditDownload();
    });
    if(ok === null){
      let out = ["TGPSC READY — COMPLETE MASTER NOTES", "=".repeat(50), ""];
      SUBJECTS.forEach(s=>{ out.push(buildSubjectText(s)); out.push(""); });
      triggerBlobDownload("tgpsc-ready-complete-notes.txt", out.join("\n"));
      creditDownload();
    }
  }

  /* ---------------- Misc UI ---------------- */
  function updateCoinPill(){ el.coinpill.textContent = "🪙 " + state.coins; }
  function showToast(msg){
    el.toast.textContent = msg;
    el.toast.classList.add("show");
    clearTimeout(showToast._t);
    showToast._t = setTimeout(()=> el.toast.classList.remove("show"), 2200);
  }

  function applyTheme(){
    document.documentElement.setAttribute("data-theme", state.theme);
    el.themeBtn.textContent = state.theme === "dark" ? "☀ Light" : "☾ Dark";
  }

  /* ---------------- Study timer (drives coin-per-minute) ---------------- */
  function startStudyTimer(){
    studyTimer = setInterval(()=>{
      if(document.hidden) return;
      state.studySeconds += 1;
      if(state.studySeconds - lastMinuteTick >= 60){
        lastMinuteTick = state.studySeconds;
        state.coins += 1;
        updateCoinPill();
        showToast("+1 coin for a minute of study time");
      }
      saveState();
    }, 1000);
  }

  /* ---------------- Wire up static controls ---------------- */
  function init(){
    renderSidebar();
    applyTheme();
    updateCoinPill();
    renderHome();
    startStudyTimer();

    el.search.addEventListener("input", (e)=> runSearch(e.target.value));
    el.themeBtn.addEventListener("click", ()=>{
      state.theme = state.theme === "dark" ? "light" : "dark";
      saveState(); applyTheme();
    });
    el.hamburger.addEventListener("click", ()=>{
      el.sidebar.classList.add("open");
      el.backdrop.classList.add("show");
    });
    el.backdrop.addEventListener("click", closeSidebarMobile);

    document.getElementById("navBookmarks").addEventListener("click", ()=>{ closeSidebarMobile(); renderBookmarks(); });
    document.getElementById("navRewards").addEventListener("click", ()=>{ closeSidebarMobile(); renderRewards(); });
    document.getElementById("navHome").addEventListener("click", ()=>{ closeSidebarMobile(); renderHome(); });
    document.getElementById("downloadAllBtn").addEventListener("click", downloadAllNotes);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
