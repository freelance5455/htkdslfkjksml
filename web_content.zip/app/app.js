// Paste your deployed Google Apps Script Web App URL here.
const API_URL = 'PASTE_YOUR_DEPLOYED_WEB_APP_URL_HERE';

const $ = id => document.getElementById(id);
$('search').addEventListener('click', loadPrices);

async function loadPrices() {
  if (!API_URL.startsWith('https://')) {
    $('status').textContent = 'Backend is not connected yet. Set API_URL in app.js first.';
    return;
  }
  $('status').textContent = 'Loading official mandi records...';
  $('results').innerHTML = '';
  const q = new URLSearchParams({
    state: $('state').value.trim(),
    district: $('district').value.trim(),
    market: $('market').value.trim(),
    commodity: $('commodity').value.trim()
  });
  try {
    const res = await fetch(API_URL + '?' + q.toString());
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'Price service error');
    $('status').textContent = data.count + ' official record(s) received.';
    if (!data.records.length) {
      $('results').textContent = 'No matching report found. Try fewer filters.';
      return;
    }
    $('results').innerHTML = data.records.map(r => `
      <article class="card">
        <h3>${esc(r.commodity)} — ${esc(r.market)}</h3>
        <small>${esc(r.district)}, ${esc(r.state)} · Variety: ${esc(r.variety)} · Report date: ${esc(r.arrival_date)}</small>
        <div class="prices">
          ${priceBox('Minimum',r.min_quintal,r.min_kg)}
          ${priceBox('Maximum',r.max_quintal,r.max_kg)}
          ${priceBox('Modal',r.modal_quintal,r.modal_kg)}
        </div>
      </article>`).join('');
  } catch (err) {
    $('status').textContent = 'Could not load prices: ' + err.message;
  }
}
function priceBox(label,q,kg) {
  return `<div class="price"><b>${label}</b><br>₹${fmt(q)}/quintal<br>₹${fmt(kg)}/kg</div>`;
}
function fmt(v){return v == null ? '—' : Number(v).toLocaleString('en-IN',{maximumFractionDigits:2});}
function esc(v){return String(v == null ? '' : v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
