/* Zagros Manager – offline-first owner app. Vanilla JS, no dependencies, no inline code (CSP-safe). */
(function () {
'use strict';
var VERSION = '1.0';
var LANGS = ['de', 'en', 'fa'];
var STATUSES = ['new', 'contacted', 'quoted', 'won', 'lost'];

/* ------------------------------ i18n ------------------------------ */
var I = {
de: { app: 'Zagros Manager', login: 'Anmelden', sub: 'Anfragen, Angebote und Website-Einstellungen. Funktioniert auch offline.', user: 'Benutzer', pass: 'Passwort', server: 'Server-Adresse (nur wenn die App nicht von Ihrer Website geladen wurde)', signin: 'Anmelden', e_login: 'Benutzer oder Passwort falsch.', e_net: 'Keine Verbindung zum Server.', e_many: 'Zu viele Versuche. Bitte später erneut.',
  inbox: 'Anfragen', stats: 'Zahlen', settings: 'Einstellungen', all: 'Alle', search: 'Suchen …', empty: 'Keine Anfragen.', newq: 'Neue Anfrage notieren', offline: 'Offline', online: 'Online', pending: 'zu senden', synced: 'Zuletzt synchronisiert', never: 'noch nie', syncnow: 'Jetzt synchronisieren', syncing: 'Synchronisiere …',
  st: { new: 'Neu', contacted: 'Kontaktiert', quoted: 'Angebot gesendet', won: 'Auftrag', lost: 'Abgesagt' },
  f: { name: 'Name', phone: 'Telefon', email: 'E-Mail', service: 'Leistung', size: 'Umfang', from: 'Von', to: 'Nach', date: 'Wunschtermin', message: 'Nachricht', replyLang: 'Antwortsprache', price: 'Angebotspreis (€, netto)', note: 'Interne Notiz', keep: 'Aufbewahren (Auftrag / gesetzliche Frist)', status: 'Status', video: 'Video-Besichtigung', source: 'Quelle', web: 'Website', manual: 'Manuell', vat: 'USt.-Satz', paid: 'Bezahlt', buyerAddr: 'Rechnungsanschrift des Kunden' },
  save: 'Speichern', del: 'Löschen', cdel: 'Anfrage endgültig löschen?', back: 'Zurück', call: 'Anrufen', mail: 'E-Mail', wa: 'WhatsApp', copy: 'Kopieren', copied: 'Kopiert', saved: 'Gespeichert', queued: 'Offline gespeichert – wird gesendet, sobald Sie online sind.', done: 'Synchronisiert', newin: 'Neue Anfrage(n)', photos: 'Fotos', phoff: 'Foto offline nicht verfügbar',
  total: 'Gesamt', open: 'Offen', won: 'Aufträge', lost: 'Abgesagt', conv: 'Abschlussquote', rev: 'Summe Angebotspreise (Aufträge)', l30: 'Letzte 30 Tage', months: 'Anfragen pro Monat',
  banner: 'Hinweis-Banner auf der Website', bon: 'Banner anzeigen', btxt: 'Text', bhint: 'z. B. Betriebsferien. Erscheint oben auf jeder Seite der Website.', rates: 'Preisrichtwerte im Planer', showp: 'Richtwert-Preis im Planer anzeigen', pph: '€ pro Person und Stunde', pkm: '€ pro Kilometer', pmin: 'Mindestpreis (€)', rhint: 'Nur ein unverbindlicher Richtwert für Besucher.',
  app_h: 'App', lang: 'Sprache', theme: 'Darstellung', th_auto: 'Automatisch', th_l: 'Hell', th_d: 'Dunkel', notif: 'Benachrichtigung bei neuer Anfrage (wenn die App geöffnet ist)', install: 'App installieren', ios: 'Tippen Sie auf „Teilen“ und dann „Zum Home-Bildschirm“.', csv: 'CSV exportieren (Excel)', json: 'Sicherung (JSON)', logout: 'Abmelden', logall: 'Auf allen Geräten abmelden', cl: 'Beim Abmelden werden die auf diesem Gerät gespeicherten Daten gelöscht. Nicht gesendete Änderungen gehen verloren.', srv: 'Server', upd: 'Neue Version verfügbar', reload: 'Neu laden', exp: 'Sitzung abgelaufen. Bitte neu anmelden; Ihre Daten bleiben erhalten.', inv_h: 'Rechnung', inv_make: 'Rechnung erstellen', inv_print: 'Rechnung drucken', inv_no: 'Rechnungs-Nr.', inv_off: 'Nur online möglich.', inv_need: 'Bitte zuerst Preis und Status „Auftrag“ speichern.' },
en: { app: 'Zagros Manager', login: 'Sign in', sub: 'Enquiries, quotes and website settings. Works offline too.', user: 'User', pass: 'Password', server: 'Server address (only if the app was not loaded from your website)', signin: 'Sign in', e_login: 'Wrong user or password.', e_net: 'Cannot reach the server.', e_many: 'Too many attempts. Try again later.',
  inbox: 'Enquiries', stats: 'Numbers', settings: 'Settings', all: 'All', search: 'Search …', empty: 'No enquiries.', newq: 'Log a new enquiry', offline: 'Offline', online: 'Online', pending: 'to send', synced: 'Last synced', never: 'never', syncnow: 'Sync now', syncing: 'Syncing …',
  st: { new: 'New', contacted: 'Contacted', quoted: 'Quote sent', won: 'Job won', lost: 'Lost' },
  f: { name: 'Name', phone: 'Phone', email: 'Email', service: 'Service', size: 'Size', from: 'From', to: 'To', date: 'Preferred date', message: 'Message', replyLang: 'Reply language', price: 'Quoted price (€, net)', note: 'Internal note', keep: 'Keep (job won / legal retention)', status: 'Status', video: 'Video survey', source: 'Source', web: 'Website', manual: 'Manual', vat: 'VAT rate', paid: 'Paid', buyerAddr: "Customer's billing address" },
  save: 'Save', del: 'Delete', cdel: 'Delete this enquiry permanently?', back: 'Back', call: 'Call', mail: 'Email', wa: 'WhatsApp', copy: 'Copy', copied: 'Copied', saved: 'Saved', queued: 'Saved offline – will be sent when you are online.', done: 'Synced', newin: 'new enquiry(ies)', photos: 'Photos', phoff: 'Photo not available offline',
  total: 'Total', open: 'Open', won: 'Jobs won', lost: 'Lost', conv: 'Win rate', rev: 'Sum of quoted prices (jobs won)', l30: 'Last 30 days', months: 'Enquiries per month',
  banner: 'Notice banner on the website', bon: 'Show banner', btxt: 'Text', bhint: 'e.g. holiday closure. Appears at the top of every website page.', rates: 'Guide prices in the planner', showp: 'Show guide price in the planner', pph: '€ per person per hour', pkm: '€ per kilometre', pmin: 'Minimum price (€)', rhint: 'Only a non-binding guide value for visitors.',
  app_h: 'App', lang: 'Language', theme: 'Appearance', th_auto: 'Automatic', th_l: 'Light', th_d: 'Dark', notif: 'Notify on new enquiry (while the app is open)', install: 'Install app', ios: 'Tap Share, then “Add to Home Screen”.', csv: 'Export CSV (Excel)', json: 'Backup (JSON)', logout: 'Sign out', logall: 'Sign out on all devices', cl: 'Signing out deletes the data stored on this device. Unsent changes are lost.', srv: 'Server', upd: 'New version available', reload: 'Reload', exp: 'Session expired. Please sign in again; your data is kept.', inv_h: 'Invoice', inv_make: 'Create invoice', inv_print: 'Print invoice', inv_no: 'Invoice no.', inv_off: 'Only possible while online.', inv_need: 'Please save a price and set status to “Job won” first.' },
fa: { app: 'مدیریت زاگرس', login: 'ورود', sub: 'درخواست‌ها، قیمت‌ها و تنظیمات سایت. آفلاین هم کار می‌کند.', user: 'نام کاربری', pass: 'گذرواژه', server: 'نشانی سرور (فقط اگر برنامه از سایت شما باز نشده)', signin: 'ورود', e_login: 'نام کاربری یا گذرواژه درست نیست.', e_net: 'اتصال به سرور برقرار نشد.', e_many: 'تلاش بیش از حد. بعداً دوباره امتحان کنید.',
  inbox: 'درخواست‌ها', stats: 'آمار', settings: 'تنظیمات', all: 'همه', search: 'جست‌وجو …', empty: 'درخواستی نیست.', newq: 'ثبت درخواست جدید', offline: 'آفلاین', online: 'آنلاین', pending: 'در انتظار ارسال', synced: 'آخرین همگام‌سازی', never: 'هنوز نه', syncnow: 'همگام‌سازی اکنون', syncing: 'در حال همگام‌سازی …',
  st: { new: 'جدید', contacted: 'تماس گرفته شد', quoted: 'قیمت فرستاده شد', won: 'کار گرفته شد', lost: 'منصرف شد' },
  f: { name: 'نام', phone: 'تلفن', email: 'ایمیل', service: 'خدمت', size: 'حجم', from: 'مبدأ', to: 'مقصد', date: 'تاریخ دلخواه', message: 'پیام', replyLang: 'زبان پاسخ', price: 'قیمت پیشنهادی (یورو، خالص)', note: 'یادداشت داخلی', keep: 'نگه داشتن (کار گرفته شد / مدت قانونی)', status: 'وضعیت', video: 'بازدید ویدیویی', source: 'منبع', web: 'وب‌سایت', manual: 'دستی', vat: 'نرخ مالیات بر ارزش‌افزوده', paid: 'پرداخت‌شده', buyerAddr: 'نشانی فاکتور مشتری' },
  save: 'ذخیره', del: 'حذف', cdel: 'این درخواست برای همیشه حذف شود؟', back: 'بازگشت', call: 'تماس', mail: 'ایمیل', wa: 'واتساپ', copy: 'کپی', copied: 'کپی شد', saved: 'ذخیره شد', queued: 'آفلاین ذخیره شد و با وصل شدن اینترنت ارسال می‌شود.', done: 'همگام شد', newin: 'درخواست جدید', photos: 'عکس‌ها', phoff: 'عکس آفلاین در دسترس نیست',
  total: 'کل', open: 'باز', won: 'کار گرفته‌شده', lost: 'منصرف‌شده', conv: 'نرخ موفقیت', rev: 'جمع قیمت‌ها (کارهای گرفته‌شده)', l30: '۳۰ روز گذشته', months: 'درخواست در هر ماه',
  banner: 'بنر اطلاع‌رسانی روی سایت', bon: 'نمایش بنر', btxt: 'متن', bhint: 'مثلاً تعطیلات. بالای همهٔ صفحات سایت نمایش داده می‌شود.', rates: 'قیمت راهنما در برآوردگر', showp: 'نمایش قیمت راهنما در برآوردگر', pph: 'یورو برای هر نفر در ساعت', pkm: 'یورو برای هر کیلومتر', pmin: 'حداقل قیمت (یورو)', rhint: 'فقط یک مقدار راهنمای غیرالزام‌آور برای بازدیدکننده.',
  app_h: 'برنامه', lang: 'زبان', theme: 'ظاهر', th_auto: 'خودکار', th_l: 'روشن', th_d: 'تاریک', notif: 'اعلان درخواست جدید (وقتی برنامه باز است)', install: 'نصب برنامه', ios: 'روی «اشتراک‌گذاری» بزنید و «افزودن به صفحهٔ اصلی» را انتخاب کنید.', csv: 'خروجی CSV (برای Excel)', json: 'پشتیبان (JSON)', logout: 'خروج', logall: 'خروج از همهٔ دستگاه‌ها', cl: 'با خروج، داده‌های ذخیره‌شده روی این دستگاه پاک می‌شود. تغییرات ارسال‌نشده از بین می‌رود.', srv: 'سرور', upd: 'نسخهٔ جدید آماده است', reload: 'بارگذاری مجدد', exp: 'نشست تمام شد. دوباره وارد شوید؛ داده‌های شما نگه داشته شده است.', inv_h: 'فاکتور', inv_make: 'ساخت فاکتور', inv_print: 'چاپ فاکتور', inv_no: 'شماره فاکتور', inv_off: 'فقط وقتی آنلاین هستید ممکن است.', inv_need: 'لطفاً اول قیمت را ثبت و وضعیت را «کار گرفته شد» کن.' },
};

/* ------------------------------ storage (IndexedDB, in-memory fallback) ------------------------------ */
var mem = {}, dbp = null;
function db() {
  if (!dbp) dbp = new Promise(function (res, rej) {
    try { var r = indexedDB.open('zagros-mgr', 1); r.onupgradeneeded = function () { r.result.createObjectStore('kv'); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; } catch (e) { rej(e); }
  });
  return dbp;
}
function kvGet(k) { return db().then(function (d) { return new Promise(function (res) { var q = d.transaction('kv').objectStore('kv').get(k); q.onsuccess = function () { res(q.result); }; q.onerror = function () { res(mem[k]); }; }); }, function () { return mem[k]; }); }
function kvSet(k, v) { mem[k] = v; return db().then(function (d) { return new Promise(function (res) { var t = d.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); t.oncomplete = res; t.onerror = res; }); }, function () {}); }
function kvClear() { mem = {}; return db().then(function (d) { return new Promise(function (res) { var t = d.transaction('kv', 'readwrite'); t.objectStore('kv').clear(); t.oncomplete = res; t.onerror = res; }); }, function () {}); }

/* ------------------------------ state ------------------------------ */
var S = { lang: 'de', theme: 'auto', notify: false, base: '', token: '', serverRows: [], settings: null, queue: [], last: null, online: navigator.onLine, syncing: false, tab: 'inbox', filter: 'all', q: '', expired: false, ready: false, known: null };
var T = function () { return I[S.lang]; };
var $app = document.getElementById('app');
var sheet = null, toastEl = null, deferredInstall = null, newWorker = null;

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
function persist() { return Promise.all([kvSet('serverRows', S.serverRows), kvSet('settings', S.settings), kvSet('queue', S.queue), kvSet('last', S.last), kvSet('known', S.known)]); }
function savePrefs() { return kvSet('prefs', { lang: S.lang, theme: S.theme, notify: S.notify, base: S.base }); }

/* ------------------------------ DOM helper ------------------------------ */
function h(tag, a) {
  var e = document.createElement(tag);
  if (a) for (var k in a) { var v = a[k]; if (v == null || v === false) continue; if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v); else if (k === 'value') e.value = v; else e.setAttribute(k, v === true ? '' : v); }
  for (var i = 2; i < arguments.length; i++) add(e, arguments[i]);
  return e;
}
function add(e, c) { if (c == null || c === false) return; if (Array.isArray(c)) c.forEach(function (x) { add(e, x); }); else e.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c))); }
function svg(d) { var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'ic'); s.setAttribute('aria-hidden', 'true'); var p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', d); s.appendChild(p); return s; }
var P = { inbox: 'M4 6h16v12H4zM4 7l8 6 8-6', stats: 'M5 20V10M12 20V4M19 20v-7', settings: 'M4 7h10M18 7h2M4 17h2M10 17h10M14 5v4M8 15v4', plus: 'M12 5v14M5 12h14' };
function fmtDate(iso) { try { return new Date(iso).toLocaleString(S.lang === 'fa' ? 'fa-IR' : S.lang, { dateStyle: 'medium', timeStyle: 'short' }); } catch (e) { return iso; } }
function money(n) { try { return new Intl.NumberFormat(S.lang === 'fa' ? 'fa-IR' : S.lang, { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(n); } catch (e) { return n + ' €'; } }
function nfmt(n) { try { return new Intl.NumberFormat(S.lang === 'fa' ? 'fa-IR' : S.lang).format(n); } catch (e) { return String(n); } }

/* ------------------------------ data: overlay of queued ops on the last server state ------------------------------ */
function applyOps() {
  var rows = S.serverRows.map(function (r) { return Object.assign({}, r); });
  var settings = S.settings ? JSON.parse(JSON.stringify(S.settings)) : null;
  S.queue.forEach(function (op) {
    if (op.type === 'update') { rows.forEach(function (r) { if (r.ref === op.ref) { Object.assign(r, op.patch); if (op.patch.status === 'won') r.keep = true; r._pending = true; } }); }
    else if (op.type === 'delete') rows = rows.filter(function (r) { return r.ref !== op.ref; });
    else if (op.type === 'create') { if (!rows.some(function (r) { return r.cid === op.id; })) rows.push(Object.assign({ ref: 'L-' + op.id, status: 'new', note: '', keep: false, photos: 0, price: null, source: 'manual', _local: true, _pending: true, cid: op.id }, op.data)); }
    else if (op.type === 'settings' && settings) { Object.assign(settings.banner, op.settings.banner || {}); Object.assign(settings.rates, op.settings.rates || {}); }
  });
  rows.sort(function (a, b) { return a.at < b.at ? 1 : -1; });
  return { rows: rows, settings: settings };
}
var VIEW = { rows: [], settings: null };
function recompute() { VIEW = applyOps(); updateBadge(); }
function updateBadge() {
  var n = VIEW.rows.filter(function (r) { return r.status === 'new'; }).length;
  document.title = (n ? '(' + n + ') ' : '') + T().app;
  try { if (navigator.setAppBadge) { if (n) navigator.setAppBadge(n); else navigator.clearAppBadge(); } } catch (e) {}
}

/* ------------------------------ API + sync ------------------------------ */
function apiUrl(p) { return (S.base || '') + p; }
function api(path, body) {
  var ctl = window.AbortController ? new AbortController() : null, to = setTimeout(function () { if (ctl) ctl.abort(); }, 25000);
  var headers = { 'Content-Type': 'application/json', 'X-Admin': '1' };
  if (S.token) headers.Authorization = 'Bearer ' + S.token;
  return fetch(apiUrl(path), { method: body ? 'POST' : 'GET', headers: headers, body: body ? JSON.stringify(body) : undefined, signal: ctl ? ctl.signal : undefined, cache: 'no-store' })
    .then(function (r) { clearTimeout(to); return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) { var e = new Error('http'); e.status = r.status; throw e; } return j; }); },
          function (e) { clearTimeout(to); e.net = true; throw e; });
}
function enqueue(op) { op.id = op.id || uid(); S.queue.push(op); recompute(); persist(); render(); sync(); return op; }
function sync(manual) {
  if (S.syncing) { S.again = true; return Promise.resolve(); }
  if (!S.token || S.expired) return Promise.resolve();
  if (!navigator.onLine && !manual) return Promise.resolve();
  S.syncing = true; renderStatus();
  var batch = S.queue.slice();
  return api('/admin/api/sync', { ops: batch }).then(function (r) {
    var res = {}; (r.results || []).forEach(function (x) { res[x.id] = x; });
    var done = {}; batch.forEach(function (op) { var x = res[op.id]; if (x && (x.ok || x.gone || x.error === 'invalid' || x.error === 'op')) done[op.id] = true; else { op.tries = (op.tries || 0) + 1; if (op.tries >= 6) done[op.id] = true; } });
    S.queue = S.queue.filter(function (op) { return !done[op.id]; });
    var prev = S.known; S.serverRows = r.rows || []; S.settings = r.settings || S.settings; S.last = r.now || new Date().toISOString(); S.online = true;
    var refs = {}; S.serverRows.forEach(function (x) { refs[x.ref] = 1; });
    if (prev) { var fresh = S.serverRows.filter(function (x) { return !prev[x.ref] && x.status === 'new' && x.source !== 'manual'; }); if (fresh.length) notifyNew(fresh); }
    S.known = refs; recompute(); persist(); render();
    if (manual) toast(T().done);
  }).catch(function (e) {
    if (e.status === 401) { S.expired = true; kvSet('token', ''); S.token = ''; render(); }
    else S.online = false;
    renderStatus();
  }).then(function () { S.syncing = false; renderStatus(); if (S.again) { S.again = false; setTimeout(function () { sync(); }, 400); } });
}
function notifyNew(rows) {
  toast(rows.length + ' ' + T().newin + ': ' + rows[0].name);
  try { if (S.notify && document.hidden && window.Notification && Notification.permission === 'granted') new Notification(T().app, { body: rows.length + ' ' + T().newin + ': ' + rows[0].name, icon: '../img/mgr-192.png' }); } catch (e) {}
}

/* ------------------------------ photos (cached for offline) ------------------------------ */
function photoUrl(ref, i) { return apiUrl('/admin/api/photo/' + ref + '/' + i); }
function loadPhoto(ref, i) {
  var url = photoUrl(ref, i), cache = window.caches ? caches.open('zagros-photos') : Promise.reject();
  return cache.then(function (c) {
    return c.match(url).then(function (hit) {
      if (hit) return hit.blob();
      return fetch(url, { headers: { Authorization: 'Bearer ' + S.token, 'X-Admin': '1' }, cache: 'no-store' }).then(function (r) { if (!r.ok) throw new Error('p'); c.put(url, r.clone()); return r.blob(); });
    });
  }, function () { return fetch(url, { headers: { Authorization: 'Bearer ' + S.token } }).then(function (r) { if (!r.ok) throw new Error('p'); return r.blob(); }); })
  .then(function (b) { return URL.createObjectURL(b); });
}

/* ------------------------------ UI bits ------------------------------ */
function toast(msg, action) {
  if (toastEl) toastEl.remove();
  toastEl = h('div', { class: 'toast', role: 'status' }, h('span', { text: msg }), action ? h('button', { type: 'button', text: action.label, onclick: action.fn }) : null);
  $app.appendChild(toastEl); var t = toastEl; setTimeout(function () { if (t.parentNode) t.remove(); }, action ? 12000 : 3500);
}
function statusPill() {
  var n = S.queue.length, off = !navigator.onLine || !S.online;
  var txt = S.syncing ? T().syncing : (off ? T().offline : T().online);
  if (n) txt += ' · ' + nfmt(n) + ' ' + T().pending;
  return h('span', { class: 'pill ' + (off || n ? 'off' : 'ok'), id: 'pill', text: txt });
}
function renderStatus() { var p = document.getElementById('pill'); if (p) p.replaceWith(statusPill()); }

function header(title, extra) { return h('header', { class: 'hdr' }, h('h1', { text: title }), statusPill(), extra); }

/* ------------------------------ screens ------------------------------ */
function renderLogin() {
  var t = T(), err = h('div', { class: 'err', role: 'alert' }), u = h('input', { name: 'user', autocomplete: 'username', autocapitalize: 'none', required: true }), pw = h('input', { name: 'pw', type: 'password', autocomplete: 'current-password', required: true });
  var srv = null;
  var needSrv = location.protocol === 'file:' || !/^https?:$/.test(location.protocol);
  if (needSrv || S.base) srv = h('input', { name: 'srv', type: 'url', placeholder: 'https://www.example.de', value: S.base, autocapitalize: 'none' });
  var lang = h('select', { 'aria-label': 'Language', onchange: function (e) { S.lang = e.target.value; savePrefs(); applyLang(); render(); } }, LANGS.map(function (l) { return h('option', { value: l, text: { de: 'Deutsch', en: 'English', fa: 'فارسی' }[l] }); }));
  lang.value = S.lang;
  var btn = h('button', { class: 'btn pri', type: 'submit', text: t.signin });
  var f = h('form', { class: 'login', onsubmit: function (ev) {
    ev.preventDefault(); err.textContent = ''; btn.disabled = true;
    if (srv) { S.base = srv.value.trim().replace(/\/+$/, ''); if (S.base && !/^https?:\/\//.test(S.base)) S.base = 'https://' + S.base; savePrefs(); }
    api('/admin/api/login', { user: u.value.trim(), password: pw.value, label: (navigator.platform || 'device').slice(0, 40) }).then(function (r) {
      S.token = r.token; S.expired = false; return kvSet('token', r.token).then(function () { return sync(true); });
    }).then(function () { render(); }, function (e) { err.textContent = e.net ? t.e_net : (e.status === 429 ? t.e_many : t.e_login); }).then(function () { btn.disabled = false; });
  } },
    h('img', { class: 'banner', src: '../img/banner.jpg', alt: 'Zagros', width: 640, height: 336 }), h('h1', { text: t.app }), h('p', { class: 'muted', text: S.expired ? t.exp : t.sub }),
    h('label', null, t.user, u), h('label', null, t.pass, pw), srv ? h('label', null, t.server, srv) : null, err, btn,
    h('p', null, lang));
  $app.textContent = ''; $app.appendChild(f);
}

function tabBar() {
  var t = T(), nNew = VIEW.rows.filter(function (r) { return r.status === 'new'; }).length;
  function tb(id, label, path) { return h('button', { type: 'button', 'aria-current': S.tab === id ? 'true' : 'false', onclick: function () { S.tab = id; render(); } }, svg(path), h('span', null, label, id === 'inbox' && nNew ? h('span', { class: 'badge', text: nfmt(nNew) }) : null)); }
  return h('nav', { class: 'tabs', 'aria-label': 'Navigation' }, tb('inbox', t.inbox, P.inbox), tb('stats', t.stats, P.stats), tb('settings', t.settings, P.settings));
}

function matches(r, q) { if (!q) return true; q = q.toLowerCase(); return [r.name, r.email, r.phone, r.from, r.to, r.message, r.ref, r.note].join(' ').toLowerCase().indexOf(q) >= 0; }
function renderInbox() {
  var t = T(), rows = VIEW.rows;
  var list = h('div'), cnt = {};
  rows.forEach(function (r) { cnt[r.status] = (cnt[r.status] || 0) + 1; });
  function fill() {
    list.textContent = '';
    var vis = rows.filter(function (r) { return (S.filter === 'all' || r.status === S.filter) && matches(r, S.q); });
    if (!vis.length) list.appendChild(h('p', { class: 'muted', text: t.empty }));
    vis.forEach(function (r) {
      list.appendChild(h('button', { type: 'button', class: 'card item' + (r.status === 'new' ? ' new' : ''), onclick: function () { openDetail(r.ref); } },
        h('div', { class: 'row sp' }, h('span', { class: 'title', text: r.name }), h('span', { class: 'st ' + r.status, text: t.st[r.status] })),
        h('div', { class: 'muted small', text: [r.from && r.to ? r.from + ' → ' + r.to : (r.from || ''), r.date].filter(Boolean).join(' · ') }),
        h('div', { class: 'muted small' }, fmtDate(r.at), r._pending ? ' · ⏳' : '', r.photos ? ' · 📷' + r.photos : '')));
    });
  }
  var chips = h('div', { class: 'chips', role: 'group' }, ['all'].concat(STATUSES).map(function (s) {
    return h('button', { type: 'button', class: 'chip', 'aria-pressed': S.filter === s ? 'true' : 'false', onclick: function (e) { S.filter = s; $$('.chip', chips).forEach(function (c) { c.setAttribute('aria-pressed', 'false'); }); e.currentTarget.setAttribute('aria-pressed', 'true'); fill(); } }, s === 'all' ? t.all : t.st[s], ' ', nfmt(s === 'all' ? rows.length : (cnt[s] || 0)));
  }));
  var q = h('input', { type: 'search', placeholder: t.search, value: S.q, 'aria-label': t.search, oninput: function (e) { S.q = e.target.value; fill(); } });
  fill();
  var sc = h('div', { class: 'scroll' }, h('div', { class: 'row' }, q), chips, list);
  return [header(t.inbox), sc, h('button', { class: 'fab', type: 'button', 'aria-label': t.newq, onclick: openNew }, svg(P.plus))];
}
function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

function renderStats() {
  var t = T(), rows = VIEW.rows.filter(function (r) { return !r._local; });
  var c = { new: 0, contacted: 0, quoted: 0, won: 0, lost: 0 }; rows.forEach(function (r) { if (c[r.status] != null) c[r.status]++; });
  var now = Date.now(), l30 = rows.filter(function (r) { return now - Date.parse(r.at) < 30 * 86400000; }).length;
  var closed = c.won + c.lost, conv = closed ? Math.round(c.won / closed * 100) : null;
  var rev = rows.filter(function (r) { return r.status === 'won' && r.price; }).reduce(function (n, r) { return n + r.price; }, 0);
  var months = [], d = new Date(); d.setDate(1);
  for (var i = 5; i >= 0; i--) { var m = new Date(d.getFullYear(), d.getMonth() - i, 1); months.push({ y: m.getFullYear(), m: m.getMonth(), n: 0, label: m.toLocaleDateString(S.lang === 'fa' ? 'fa-IR' : S.lang, { month: 'short' }) }); }
  rows.forEach(function (r) { var x = new Date(r.at); months.forEach(function (mm) { if (mm.y === x.getFullYear() && mm.m === x.getMonth()) mm.n++; }); });
  var max = Math.max(1, Math.max.apply(null, months.map(function (m) { return m.n; })));
  function stat(label, val) { return h('div', { class: 'stat' }, h('b', { text: val }), h('span', { class: 'muted small', text: label })); }
  var bars = h('div', { class: 'bars', role: 'img', 'aria-label': t.months }, months.map(function (m) { var bar = h('i'); bar.style.height = Math.round(m.n / max * 80) + 'px'; return h('div', null, h('span', { text: nfmt(m.n) }), bar, h('span', { text: m.label })); }));
  return [header(t.stats), h('div', { class: 'scroll' },
    h('div', { class: 'grid2' }, stat(t.total, nfmt(rows.length)), stat(t.l30, nfmt(l30)), stat(t.open, nfmt(c.new + c.contacted + c.quoted)), stat(t.won, nfmt(c.won)), stat(t.lost, nfmt(c.lost)), stat(t.conv, conv == null ? '–' : nfmt(conv) + ' %')),
    h('div', { class: 'card' }, h('div', { class: 'muted small', text: t.rev }), h('b', { text: money(rev) })),
    h('h2', { text: t.months }), h('div', { class: 'card' }, bars))];
}

function renderSettings() {
  var t = T(), st = VIEW.settings || { banner: { enabled: false }, rates: {} }, b = st.banner || {}, r = st.rates || {};
  var bon = h('input', { type: 'checkbox' }); bon.checked = !!b.enabled;
  var tx = {}; LANGS.concat(['fr']).forEach(function (l) { tx[l] = h('textarea', { maxlength: 280, lang: l, dir: l === 'fa' ? 'rtl' : 'ltr', rows: 2 }); tx[l].value = b[l] || ''; });
  var sp = h('input', { type: 'checkbox' }); sp.checked = !!r.showPrice;
  function numIn(v) { return h('input', { type: 'number', min: 0, step: '0.01', inputmode: 'decimal', value: v == null ? '' : v }); }
  var pph = numIn(r.perPersonHour), pkm = numIn(r.perKm), pmin = numIn(r.minimum);
  var save = h('button', { class: 'btn pri', type: 'button', text: t.save, onclick: function () {
    var ban = { enabled: bon.checked }; ['de', 'en', 'fr', 'fa'].forEach(function (l) { ban[l] = tx[l].value.trim(); });
    function nv(i) { return i.value === '' ? null : parseFloat(i.value); }
    enqueue({ type: 'settings', settings: { banner: ban, rates: { showPrice: sp.checked, perPersonHour: nv(pph), perKm: nv(pkm), minimum: nv(pmin) } } });
    toast(navigator.onLine ? t.saved : t.queued);
  } });
  var lang = h('select', { onchange: function (e) { S.lang = e.target.value; savePrefs(); applyLang(); render(); } }, LANGS.map(function (l) { return h('option', { value: l, text: { de: 'Deutsch', en: 'English', fa: 'فارسی' }[l] }); })); lang.value = S.lang;
  var th = h('select', { onchange: function (e) { S.theme = e.target.value; savePrefs(); applyTheme(); } }, [['auto', t.th_auto], ['light', t.th_l], ['dark', t.th_d]].map(function (o) { return h('option', { value: o[0], text: o[1] }); })); th.value = S.theme;
  var nt = h('input', { type: 'checkbox', onchange: function (e) { S.notify = e.target.checked; savePrefs(); if (S.notify && window.Notification && Notification.permission === 'default') Notification.requestPermission(); } }); nt.checked = S.notify;
  var inst = null;
  if (deferredInstall) inst = h('button', { class: 'btn', type: 'button', text: t.install, onclick: function () { deferredInstall.prompt(); deferredInstall.userChoice.then(function () { deferredInstall = null; render(); }); } });
  else if (/iphone|ipad|ipod/i.test(navigator.userAgent) && !isStandalone()) inst = h('p', { class: 'muted small', text: t.install + ': ' + t.ios });
  return [header(t.settings), h('div', { class: 'scroll' },
    h('h2', { text: t.banner }), h('div', { class: 'card' }, h('p', { class: 'muted small', text: t.bhint }), h('label', { class: 'chk' }, bon, t.bon),
      ['de', 'en', 'fr', 'fa'].map(function (l) { return h('label', null, { de: 'Deutsch', en: 'English', fr: 'Français', fa: 'فارسی' }[l], tx[l]); })),
    h('h2', { text: t.rates }), h('div', { class: 'card' }, h('p', { class: 'muted small', text: t.rhint }), h('label', { class: 'chk' }, sp, t.showp), h('label', null, t.pph, pph), h('label', null, t.pkm, pkm), h('label', null, t.pmin, pmin)),
    h('div', { class: 'row' }, save),
    h('h2', { text: t.app_h }), h('div', { class: 'card' }, h('label', null, t.lang, lang), h('label', null, t.theme, th), h('label', { class: 'chk' }, nt, t.notif), inst,
      h('div', { class: 'row' }, h('button', { class: 'btn sm', type: 'button', text: t.syncnow, onclick: function () { sync(true); } }), h('button', { class: 'btn sm', type: 'button', text: t.csv, onclick: exportCsv }), h('button', { class: 'btn sm', type: 'button', text: t.json, onclick: exportJson })),
      h('p', { class: 'muted small', text: t.synced + ': ' + (S.last ? fmtDate(S.last) : t.never) }),
      h('p', { class: 'muted small', text: t.srv + ': ' + (S.base || location.origin) + ' · v' + VERSION })),
    h('div', { class: 'card' }, h('p', { class: 'muted small', text: t.cl }), h('div', { class: 'row' }, h('button', { class: 'btn dng', type: 'button', text: t.logout, onclick: function () { logout(false); } }), h('button', { class: 'btn dng', type: 'button', text: t.logall, onclick: function () { logout(true); } }))))];
}

function isStandalone() { return (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone; }
function logout(all) {
  var done = function () { S.token = ''; S.serverRows = []; S.queue = []; S.settings = null; S.last = null; S.known = null; S.expired = false; recompute(); (window.caches ? caches.delete('zagros-photos') : Promise.resolve()).catch(function () {}); kvClear().then(function () { savePrefs(); render(); }); };
  api(all ? '/admin/api/logout-all' : '/admin/api/logout', {}).then(done, done);
}

/* ------------------------------ detail / new ------------------------------ */
function closeSheet(fromPop) { if (sheet) { sheet.remove(); sheet = null; } if (!fromPop && history.state && history.state.sheet) history.back(); }
function openSheet(node) { closeSheet(true); sheet = node; $app.appendChild(node); history.pushState({ sheet: 1 }, ''); }
window.addEventListener('popstate', function () { if (sheet) closeSheet(true); });

function openInvoiceWindow(ref) {
  var t = T();
  var w = null;
  try { w = window.open('', '_blank'); } catch (e) {}
  fetch(apiUrl('/admin/api/invoice/' + ref), { headers: { Authorization: 'Bearer ' + S.token } })
    .then(function (r) { if (!r.ok) throw new Error('http'); return r.text(); })
    .then(function (html) { if (w) { w.document.open(); w.document.write(html); w.document.close(); } })
    .catch(function () { if (w) w.close(); toast(t.e_net); });
}
function invoiceBlock(r) {
  var t = T();
  if (r.invoiceNo) {
    return h('div', { class: 'row' },
      h('span', { class: 'muted small', text: t.inv_no + ': ' + r.invoiceNo }),
      h('button', { class: 'btn sm', type: 'button', text: t.inv_print, onclick: function () { openInvoiceWindow(r.ref); } }));
  }
  if (!navigator.onLine) return h('p', { class: 'muted small', text: t.inv_off });
  if (r.price == null || r.status !== 'won') return h('p', { class: 'muted small', text: t.inv_need });
  var btn = h('button', { class: 'btn sm', type: 'button', text: t.inv_make });
  btn.onclick = function () {
    btn.disabled = true;
    api('/admin/api/invoice', { ref: r.ref }).then(function (res) {
      if (res && res.row) { var i = S.serverRows.findIndex(function (x) { return x.ref === r.ref; }); if (i >= 0) S.serverRows[i] = res.row; recompute(); persist(); openDetail(r.ref); }
    }, function () { btn.disabled = false; toast(t.e_net); });
  };
  return btn;
}
function openDetail(ref) {
  var t = T(), r = VIEW.rows.filter(function (x) { return x.ref === ref; })[0]; if (!r) return;
  var status = h('select', { 'aria-label': t.f.status }, STATUSES.map(function (s) { return h('option', { value: s, text: t.st[s] }); })); status.value = r.status;
  var price = h('input', { type: 'number', min: 0, step: '0.01', inputmode: 'decimal', value: r.price == null ? '' : r.price });
  var note = h('textarea', { maxlength: 1000 }); note.value = r.note || '';
  var keep = h('input', { type: 'checkbox' }); keep.checked = !!r.keep;
  var vat = h('select', { 'aria-label': t.f.vat }, [0, 7, 19].map(function (v) { return h('option', { value: String(v), text: v + ' %', selected: (r.vatRate == null ? 19 : r.vatRate) === v }); })); vat.value = String(r.vatRate == null ? 19 : r.vatRate);
  var paid = h('input', { type: 'checkbox' }); paid.checked = !!r.paid;
  var buyerAddr = h('textarea', { maxlength: 500, rows: 2 }); buyerAddr.value = r.buyerAddress || '';
  var kv = h('dl', { class: 'kv' });
  [['phone', r.phone], ['email', r.email], ['service', r.service], ['size', r.size], ['from', r.from], ['to', r.to], ['date', r.date], ['replyLang', r.replyLang], ['source', r.source === 'manual' ? t.f.manual : t.f.web]].forEach(function (p) { if (p[1]) { kv.appendChild(h('dt', { text: t.f[p[0]] })); kv.appendChild(h('dd', { text: p[1] })); } });
  var phones = (r.phone || '').replace(/[^\d+]/g, ''), wa = phones.replace(/\D/g, '');
  var photos = h('div', { class: 'photos' });
  if (r.photos && !r._local) for (var i = 0; i < r.photos; i++) (function (i) {
    var b = h('button', { type: 'button', 'aria-label': t.photos + ' ' + (i + 1), text: '…' }); photos.appendChild(b);
    loadPhoto(r.ref, i).then(function (u) { b.textContent = ''; b.appendChild(h('img', { src: u, alt: '' })); b.onclick = function () { var big = h('div', { class: 'big', onclick: function () { big.remove(); } }, h('img', { src: u, alt: '' })); $app.appendChild(big); }; }, function () { b.textContent = '📷'; b.title = t.phoff; });
  })(i);
  var summary = [r.ref, r.name, r.phone, r.email, (r.from || '') + (r.to ? ' → ' + r.to : ''), r.date, r.message].filter(Boolean).join('\n');
  var node = h('section', { class: 'sheet', 'aria-label': r.name },
    h('header', { class: 'hdr' }, h('button', { class: 'btn sm', type: 'button', text: '←', 'aria-label': t.back, onclick: function () { closeSheet(); } }), h('h1', { text: r.name }), h('span', { class: 'st ' + r.status, text: t.st[r.status] })),
    h('div', { class: 'scroll' },
      h('div', { class: 'muted small' }, h('span', { class: 'ref', text: r.ref }), ' · ', fmtDate(r.at)),
      h('div', { class: 'row', role: 'group' }, phones ? h('a', { class: 'btn sm', href: 'tel:' + phones, text: t.call }) : null, r.email ? h('a', { class: 'btn sm', href: 'mailto:' + r.email, text: t.mail }) : null, wa ? h('a', { class: 'btn sm', href: 'https://wa.me/' + wa, rel: 'noopener', text: t.wa }) : null,
        h('button', { class: 'btn sm', type: 'button', text: t.copy, onclick: function () { try { navigator.clipboard.writeText(summary).then(function () { toast(t.copied); }); } catch (e) {} } })),
      kv, r.message ? h('div', { class: 'msg', text: r.message }) : null,
      r.photos && !r._local ? [h('h2', { text: t.photos }), photos] : null,
      h('h2', { text: t.f.status }), h('label', null, t.f.status, status), h('label', null, t.f.price, price), h('label', null, t.f.note, note), h('label', { class: 'chk' }, keep, t.f.keep), h('label', null, t.f.vat, vat), h('label', { class: 'chk' }, paid, t.f.paid), h('label', null, t.f.buyerAddr, buyerAddr),
      r._local ? null : [h('h2', { text: t.inv_h }), invoiceBlock(r)],
      h('div', { class: 'row' },
        h('button', { class: 'btn pri', type: 'button', text: t.save, onclick: function () {
          var patch = {};
          if (status.value !== r.status) patch.status = status.value;
          var pv = price.value === '' ? null : parseFloat(price.value); if (pv !== r.price && !(pv == null && r.price == null)) patch.price = pv;
          if (note.value !== (r.note || '')) patch.note = note.value;
          if (keep.checked !== !!r.keep) patch.keep = keep.checked;
          if (parseInt(vat.value, 10) !== (r.vatRate == null ? 19 : r.vatRate)) patch.vatRate = parseInt(vat.value, 10);
          if (paid.checked !== !!r.paid) patch.paid = paid.checked;
          if (buyerAddr.value !== (r.buyerAddress || '')) patch.buyerAddress = buyerAddr.value;
          if (Object.keys(patch).length) { if (r._local) { var op = S.queue.filter(function (o) { return o.type === 'create' && o.id === r.cid; })[0]; if (op) { op.data.note = patch.note != null ? patch.note : op.data.note; } persist(); toast(t.queued); } else { enqueue({ type: 'update', ref: r.ref, patch: patch }); toast(navigator.onLine ? t.saved : t.queued); } }
          closeSheet();
        } }),
        h('button', { class: 'btn dng', type: 'button', text: t.del, onclick: function () { if (!confirm(t.cdel)) return; if (r._local) { S.queue = S.queue.filter(function (o) { return o.id !== r.cid; }); recompute(); persist(); } else enqueue({ type: 'delete', ref: r.ref }); closeSheet(); render(); } }))));
  openSheet(node);
}

function openNew() {
  var t = T(), f = {};
  function inp(k, type) { f[k] = h(k === 'message' ? 'textarea' : 'input', { name: k, type: k === 'message' ? null : type || 'text', maxlength: k === 'message' ? 2000 : 160, autocomplete: 'off' }); return h('label', null, t.f[k], f[k]); }
  var node = h('form', { class: 'sheet', 'aria-label': t.newq, onsubmit: function (ev) {
    ev.preventDefault();
    var d = {}; ['name', 'phone', 'email', 'from', 'to', 'date', 'message'].forEach(function (k) { d[k] = f[k].value.trim(); });
    if (d.name.length < 2) { f.name.focus(); return; }
    d.at = new Date().toISOString(); d.replyLang = S.lang === 'fa' ? 'fa' : S.lang; d.service = '';
    var op = { type: 'create', id: uid(), data: d }; op.data.cid = op.id; enqueue(op);
    toast(navigator.onLine ? t.saved : t.queued); closeSheet(); } },
    h('header', { class: 'hdr' }, h('button', { class: 'btn sm', type: 'button', text: '←', 'aria-label': t.back, onclick: function () { closeSheet(); } }), h('h1', { text: t.newq })),
    h('div', { class: 'scroll' }, inp('name'), inp('phone', 'tel'), inp('email', 'email'), inp('from'), inp('to'), inp('date', 'date'), inp('message'), h('button', { class: 'btn pri', type: 'submit', text: t.save })));
  f.name.required = true;
  openSheet(node); setTimeout(function () { f.name.focus(); }, 60);
}

/* ------------------------------ export ------------------------------ */
function download(name, type, text) {
  var u = URL.createObjectURL(new Blob([text], { type: type })), a = h('a', { href: u, download: name }); document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(u); }, 2000);
}
function exportCsv() {
  function q(v) { v = String(v == null ? '' : v); if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; }
  var cols = ['ref', 'at', 'status', 'name', 'email', 'phone', 'service', 'size', 'from', 'to', 'date', 'replyLang', 'price', 'keep', 'source', 'note', 'message'];
  var out = [cols.join(',')]; VIEW.rows.forEach(function (r) { out.push(cols.map(function (c) { return q(r[c]); }).join(',')); });
  download('zagros-anfragen.csv', 'text/csv;charset=utf-8', '﻿' + out.join('\r\n') + '\r\n');
}
function exportJson() { download('zagros-backup-' + new Date().toISOString().slice(0, 10) + '.json', 'application/json', JSON.stringify({ app: 'zagros-manager', version: VERSION, exportedAt: new Date().toISOString(), rows: VIEW.rows, settings: VIEW.settings }, null, 1)); }

/* ------------------------------ render ------------------------------ */
function applyLang() { document.documentElement.lang = S.lang; document.documentElement.dir = S.lang === 'fa' ? 'rtl' : 'ltr'; updateBadge(); }
function applyTheme() { if (S.theme === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', S.theme); try { localStorage.setItem('z-theme', S.theme === 'auto' ? '' : S.theme); } catch (e) {} }
function render() {
  if (!S.ready) return;
  var keepSheet = sheet; if (keepSheet) keepSheet.remove();
  if (!S.token) { sheet = null; renderLogin(); return; }
  $app.textContent = '';
  var parts = S.tab === 'stats' ? renderStats() : S.tab === 'settings' ? renderSettings() : renderInbox();
  parts.forEach(function (p) { $app.appendChild(p); });
  $app.appendChild(tabBar());
  if (keepSheet && sheet === keepSheet) $app.appendChild(keepSheet);
}

/* ------------------------------ boot ------------------------------ */
function registerSW() {
  if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
  navigator.serviceWorker.register(new URL('../sw.js', location.href).pathname).then(function (reg) {
    reg.addEventListener('updatefound', function () { var w = reg.installing; if (w) w.addEventListener('statechange', function () { if (w.state === 'installed' && navigator.serviceWorker.controller) toast(T().upd, { label: T().reload, fn: function () { location.reload(); } }); }); });
    setInterval(function () { reg.update().catch(function () {}); }, 3600000);
  }).catch(function () {});
}
window.addEventListener('online', function () { S.online = true; renderStatus(); sync(); });
window.addEventListener('offline', function () { S.online = false; renderStatus(); });
document.addEventListener('visibilitychange', function () { if (!document.hidden) sync(); });
setInterval(function () { if (!document.hidden) sync(); }, 60000);
window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferredInstall = e; if (S.ready && S.token && S.tab === 'settings') render(); });
window.addEventListener('appinstalled', function () { deferredInstall = null; });

Promise.all(['prefs', 'token', 'serverRows', 'settings', 'queue', 'last', 'known'].map(kvGet)).then(function (v) {
  var p = v[0] || {};
  var nl = (navigator.language || 'de').slice(0, 2);
  S.lang = LANGS.indexOf(p.lang) >= 0 ? p.lang : (LANGS.indexOf(nl) >= 0 ? nl : 'de'); S.theme = p.theme || 'auto'; S.notify = !!p.notify; S.base = p.base || '';
  S.token = v[1] || ''; S.serverRows = v[2] || []; S.settings = v[3] || null; S.queue = v[4] || []; S.last = v[5] || null; S.known = v[6] || null;
  applyLang(); applyTheme(); recompute(); S.ready = true; render(); registerSW(); sync();
});
})();
