/* ============================================================
   Калькулятор себестоимости напитков + потребление отеля (Сочи)
   ============================================================ */

const INGREDIENTS = [
  { id: 1, name: 'NESCAFE Intenso Cafe Grao 6х1 кг Xl',        short: 'Кофе зерно',   weight: 1000 },
  { id: 2, name: 'NESTLE ALEGRIA Смесь МолСухОб 12х500г N1',   short: 'Молоко',       weight: 500  },
  { id: 3, name: 'Какао Микс NP 6x1кг',                        short: 'Какао',        weight: 1000 },
  { id: 4, name: 'NESCAFE Speciale 6x500г',                    short: 'Сублимат',     weight: 500  },
  { id: 5, name: 'Сливочный Латте',                            short: 'Слив. латте',  weight: 500  },
];

/* grams = [кофе, молоко, какао, сублимат, слив.латте] на порцию */
const DRINKS = [
  { name: 'Эспрессо 40мл',      grams: [7,  0,  0, 0,  0] },
  { name: 'Американо 200мл',    grams: [7,  0,  0, 0,  0] },
  { name: 'Американо 300мл',    grams: [9,  0,  0, 0,  0] },
  { name: 'Американо 400мл',    grams: [12, 0,  0, 0,  0] },
  { name: 'Капучино 200мл',     grams: [7,  8,  0, 0,  0] },
  { name: 'Капучино 300мл',     grams: [9,  12, 0, 0,  0] },
  { name: 'Капучино 400мл',     grams: [12, 16, 0, 0,  0] },
  { name: 'Латте 200мл',        grams: [7,  12, 0, 0,  0] },
  { name: 'Латте 300мл',        grams: [9,  18, 0, 0,  0] },
  { name: 'Латте 400мл',        grams: [12, 24, 0, 0,  0] },
  { name: 'Слив. Латте 200мл',  grams: [7,  0,  0, 0, 15] },
  { name: 'Слив. Латте 300мл',  grams: [9,  0,  0, 0, 20] },
  { name: 'Слив. Латте 400мл',  grams: [12, 0,  0, 0, 25] },
  { name: 'РАФ 200мл',          grams: [7,  6,  0, 0, 10] },
  { name: 'РАФ 300мл',          grams: [9,  9,  0, 0, 15] },
  { name: 'РАФ 400мл',          grams: [12, 12, 0, 0, 20] },
  { name: 'Какао 200мл',        grams: [0,  5, 15, 0,  0] },
  { name: 'Какао 300мл',        grams: [0,  8, 20, 0,  0] },
  { name: 'Какао 400мл',        grams: [0,  10, 25, 0, 0] },
];

/* ---------------- helpers ---------------- */
const $ = id => document.getElementById(id);
const num = v => { const n = parseFloat(v); return isNaN(n) ? 0 : n; };

const fmtInt = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 });
const fmt1   = new Intl.NumberFormat('ru-RU', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const fmt2   = new Intl.NumberFormat('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/* слот-машинная анимация числа: новое значение «вкатывается» снизу */
function setNum(el, text) {
  if (el.textContent === text) return;
  el.textContent = text;
  el.classList.remove('roll');
  void el.offsetWidth;
  el.classList.add('roll');
}

/* ---------------- построение UI ---------------- */
function buildIngredients() {
  const grid = $('ingGrid');
  grid.innerHTML = '';
  INGREDIENTS.forEach((ing, i) => {
    const card = document.createElement('div');
    card.className = 'ing-card reveal';
    card.innerHTML = `
      <div class="tag">Продукт ${String(i + 1).padStart(2, '0')}</div>
      <h3>${ing.name}</h3>
      <div class="fields">
        <div class="field">
          <label>Цена пачки, ₽</label>
          <input type="number" id="ingPrice${ing.id}" min="0" placeholder="0" oninput="recalculateAll()">
        </div>
        <div class="field">
          <label>Вес пачки, г</label>
          <input type="number" id="ingWeight${ing.id}" min="1" value="${ing.weight}" oninput="recalculateAll()">
        </div>
      </div>
      <div class="pergram" id="perGram${ing.id}">Цена за грамм: <b>—</b></div>`;
    grid.appendChild(card);
  });
}

function buildDrinks() {
  const grid = $('drinksGrid');
  grid.innerHTML = '';
  DRINKS.forEach((d, di) => {
    const card = document.createElement('div');
    card.className = 'drink-card reveal';
    card.id = `drink${di}`;

    const gramFields = INGREDIENTS.map((ing, ii) => `
      <div class="field">
        <label>${ing.short}, г</label>
        <input type="number" min="0" step="0.5" data-ing="${ii}" value="${d.grams[ii] || ''}" placeholder="0" oninput="recalculateAll()">
      </div>`).join('');

    card.innerHTML = `
      <div class="drink-top">
        <h4>${d.name}</h4>
        <label class="switch" title="Включить в меню отеля">
          <input type="checkbox" class="hotel-toggle" onchange="toggleHotel(${di}, this.checked)">
          <span class="pill"></span><span class="lbl">В отеле</span>
        </label>
      </div>
      <div class="gram-grid">${gramFields}</div>
      <div class="drink-bottom">
        <div class="field">
          <label>Рек. цена, ₽</label>
          <input type="number" min="0" class="sell-price" placeholder="0" oninput="recalculateAll()">
        </div>
        <div class="field">
          <label>Доля в меню, %</label>
          <input type="number" min="0" max="100" class="share" placeholder="0" oninput="recalculateAll()">
        </div>
        <div class="results">
          <div><div class="r-label">Себестоимость</div><div class="r-val" data-r="cost">0,00 ₽</div></div>
          <div><div class="r-label">Маржа</div><div class="r-val" data-r="margin">0,00 ₽</div></div>
          <div><div class="r-label">Наценка</div><div class="r-val" data-r="markup">0,0%</div></div>
          <div class="hotel-line" data-r="hotelLine">порций/мес: —</div>
        </div>
      </div>`;
    grid.appendChild(card);
  });
}

function toggleHotel(di, on) {
  $(`drink${di}`).classList.toggle('in-hotel', on);
  recalculateAll();
}

/* ---------------- чтение состояния ---------------- */
function readState() {
  const prices = INGREDIENTS.map(i => num($(`ingPrice${i.id}`).value));
  const weights = INGREDIENTS.map(i => Math.max(num($(`ingWeight${i.id}`).value), 0.0001));

  const drinks = DRINKS.map((d, di) => {
    const card = $(`drink${di}`);
    const gInputs = card.querySelectorAll('input[data-ing]');
    const grams = INGREDIENTS.map((_, ii) => num(gInputs[ii].value));
    return {
      name: d.name,
      grams,
      sell: num(card.querySelector('.sell-price').value),
      inHotel: card.querySelector('.hotel-toggle').checked,
      share: num(card.querySelector('.share').value),
    };
  });

  const hotel = {
    name: $('hotelName').value.trim(),
    capacity: num($('capacity').value),
    occupancy: Math.min(num($('occupancy').value), 100),
    rations: num($('rations').value),
    days: Math.max(num($('daysInMonth').value), 1),
  };
  return { prices, weights, drinks, hotel };
}

/* ---------------- расчёт ---------------- */
function calc(state) {
  const { prices, weights, drinks, hotel } = state;

  /* себестоимость порции = Σ (цена пачки / вес пачки) × граммы */
  const perGram = prices.map((p, i) => (weights[i] > 0 ? p / weights[i] : 0));
  drinks.forEach(d => {
    d.cost = d.grams.reduce((s, g, i) => s + perGram[i] * g, 0);
    d.margin = d.sell - d.cost;
    d.markup = d.cost !== 0 ? (d.margin / d.cost) * 100 : 0;
  });

  /* отель */
  const guestsDay = hotel.capacity * hotel.occupancy / 100;
  const portionsDay = guestsDay * hotel.rations;
  const guestsMonth = guestsDay * hotel.days;
  const portionsMonth = portionsDay * hotel.days;

  /* доли напитков нормируем до 100% */
  const selected = drinks.filter(d => d.inHotel);
  const shareSum = selected.reduce((s, d) => s + d.share, 0);
  selected.forEach(d => {
    d.normShare = shareSum > 0 ? d.share / shareSum : 1 / selected.length;
    d.portionsMonth = portionsMonth * d.normShare;
  });
  drinks.forEach(d => { if (!d.inHotel) { d.normShare = 0; d.portionsMonth = 0; } });

  /* потребление по продуктам */
  const consumption = INGREDIENTS.map((ing, i) => {
    const gramsMonth = selected.reduce((s, d) => s + d.portionsMonth * d.grams[i], 0);
    const packsMonth = weights[i] > 0 ? gramsMonth / weights[i] : 0;
    const moneyMonth = gramsMonth * perGram[i];
    return { gramsMonth, packsMonth, moneyMonth, packsYear: packsMonth * 12, moneyYear: moneyMonth * 12 };
  });

  return { perGram, guestsDay, portionsDay, guestsMonth, portionsMonth, consumption, shareSum };
}

/* ---------------- отрисовка ---------------- */
function render(state, r) {
  /* цена за грамм на карточках продуктов */
  INGREDIENTS.forEach((ing, i) => {
    const el = $(`perGram${ing.id}`);
    const v = r.perGram[i];
    el.innerHTML = `Цена за грамм: <b>${v > 0 ? fmt2.format(v) + ' ₽' : '—'}</b>`;
  });

  /* карточки напитков */
  state.drinks.forEach((d, di) => {
    const card = $(`drink${di}`);
    const costEl = card.querySelector('[data-r="cost"]');
    const margEl = card.querySelector('[data-r="margin"]');
    const markEl = card.querySelector('[data-r="markup"]');
    setNum(costEl, fmt2.format(d.cost) + ' ₽');
    setNum(margEl, (d.margin >= 0 ? '+' : '') + fmt2.format(d.margin) + ' ₽');
    setNum(markEl, fmt1.format(d.markup) + '%');
    margEl.className = 'r-val ' + (d.margin >= 0 ? 'pos' : 'neg');
    markEl.className = 'r-val ' + (d.markup >= 0 ? 'pos' : 'neg');
    if (d.inHotel) {
      card.querySelector('[data-r="hotelLine"]').textContent =
        `порций/мес: ${fmtInt.format(Math.round(d.portionsMonth))} · доля ${fmt1.format(d.normShare * 100)}%`;
    }
  });

  /* статистика отеля */
  setNum($('stGuestsDay'), fmtInt.format(Math.round(r.guestsDay)));
  setNum($('stPortionsDay'), fmtInt.format(Math.round(r.portionsDay)));
  setNum($('stGuestsMonth'), fmtInt.format(Math.round(r.guestsMonth)));
  setNum($('stPortionsMonth'), fmtInt.format(Math.round(r.portionsMonth)));

  /* таблица потребления */
  const body = $('consBody');
  body.innerHTML = '';
  let totG = 0, totM = 0, totY = 0;
  INGREDIENTS.forEach((ing, i) => {
    const c = r.consumption[i];
    totG += c.gramsMonth; totM += c.moneyMonth; totY += c.moneyYear;
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${ing.name}</td>
      <td>${fmtInt.format(state.weights[i])}</td>
      <td>${state.prices[i] > 0 ? fmt2.format(state.prices[i]) : '—'}</td>
      <td>${fmtInt.format(Math.round(c.gramsMonth))}</td>
      <td><b>${fmt2.format(c.packsMonth)}</b></td>
      <td><b>${fmt2.format(c.moneyMonth)}</b></td>
      <td>${fmt2.format(c.packsYear)}</td>
      <td>${fmt2.format(c.moneyYear)}</td>`;
    body.appendChild(tr);
  });
  $('ftGrams').textContent = fmtInt.format(Math.round(totG));
  $('ftMonth').textContent = fmt2.format(totM) + ' ₽';
  $('ftYear').textContent = fmt2.format(totY) + ' ₽';

  /* нижняя плавающая панель */
  setNum($('bbPortions'), fmtInt.format(Math.round(r.portionsMonth)));
  setNum($('bbMonth'), fmt2.format(totM) + ' ₽');
  setNum($('bbYear'), fmt2.format(totY) + ' ₽');
}

function recalculateAll() {
  const state = readState();
  render(state, calc(state));
}

/* ---------------- экспорт ---------------- */
function s2ab(s) {
  const buf = new ArrayBuffer(s.length);
  const view = new Uint8Array(buf);
  for (let i = 0; i < s.length; i++) view[i] = s.charCodeAt(i) & 0xFF;
  return buf;
}

function exportData() {
  try {
    const state = readState();
    const r = calc(state);
    const wb = XLSX.utils.book_new();

    /* Лист 1 · Отель */
    const hotelRows = [
      ['Параметры отеля'],
      ['Название отеля', state.hotel.name || '—'],
      ['Вместимость, мест', state.hotel.capacity],
      ['Загрузка отеля, %', state.hotel.occupancy],
      ['Рационов питания на гостя в день', state.hotel.rations],
      ['Дней в месяце', state.hotel.days],
      [],
      ['Среднее количество людей в день', Math.round(r.guestsDay)],
      ['Среднее количество людей в месяц', Math.round(r.guestsMonth)],
      ['Порций напитков в день', Math.round(r.portionsDay)],
      ['Порций напитков в месяц', Math.round(r.portionsMonth)],
      ['Порций напитков в год', Math.round(r.portionsMonth * 12)],
    ];
    const wsHotel = XLSX.utils.aoa_to_sheet(hotelRows);
    wsHotel['!cols'] = [{ wch: 42 }, { wch: 22 }];
    XLSX.utils.book_append_sheet(wb, wsHotel, 'Отель');

    /* Лист 2 · Напитки */
    const drinkRows = [[
      'Напиток', 'В меню отеля', 'Доля, %',
      ...INGREDIENTS.map(i => i.short + ', г/порцию'),
      'Себестоимость порции, ₽', 'Рек. цена продажи, ₽',
      'Маржа, ₽', 'Наценка, %', 'Порций в месяц',
    ]];
    state.drinks.forEach(d => {
      drinkRows.push([
        d.name, d.inHotel ? 'да' : 'нет', d.inHotel ? +(d.normShare * 100).toFixed(1) : '',
        ...d.grams.map(g => g || ''),
        +d.cost.toFixed(2), d.sell || '', +d.margin.toFixed(2), +d.markup.toFixed(1),
        d.inHotel ? Math.round(d.portionsMonth) : '',
      ]);
    });
    const wsDrinks = XLSX.utils.aoa_to_sheet(drinkRows);
    wsDrinks['!cols'] = [{ wch: 22 }, { wch: 12 }, { wch: 9 },
      ...INGREDIENTS.map(() => ({ wch: 15 })),
      { wch: 22 }, { wch: 19 }, { wch: 11 }, { wch: 11 }, { wch: 15 }];
    XLSX.utils.book_append_sheet(wb, wsDrinks, 'Напитки');

    /* Лист 3 · Потребление */
    const consRows = [[
      'Продукт', 'Вес пачки, г', 'Цена пачки, ₽', 'Цена за грамм, ₽',
      'Расход, г/мес', 'Пачек в месяц', 'Сумма в месяц, ₽',
      'Пачек в год', 'Сумма в год, ₽',
    ]];
    let totM = 0, totY = 0;
    INGREDIENTS.forEach((ing, i) => {
      const c = r.consumption[i];
      totM += c.moneyMonth; totY += c.moneyYear;
      consRows.push([
        ing.name, state.weights[i], state.prices[i], +r.perGram[i].toFixed(4),
        Math.round(c.gramsMonth), +c.packsMonth.toFixed(2), +c.moneyMonth.toFixed(2),
        +c.packsYear.toFixed(2), +c.moneyYear.toFixed(2),
      ]);
    });
    consRows.push([]);
    consRows.push(['ИТОГО закупка', '', '', '', '', '', +totM.toFixed(2), '', +totY.toFixed(2)]);
    const wsCons = XLSX.utils.aoa_to_sheet(consRows);
    wsCons['!cols'] = [{ wch: 38 }, { wch: 12 }, { wch: 13 }, { wch: 16 },
      { wch: 14 }, { wch: 14 }, { wch: 16 }, { wch: 12 }, { wch: 15 }];
    XLSX.utils.book_append_sheet(wb, wsCons, 'Потребление');

    const safeName = (state.hotel.name || 'отель').replace(/[\\/:*?"<>|]/g, '_');
    const fileData = XLSX.write(wb, { bookType: 'biff8', type: 'binary' });
    const blob = new Blob([s2ab(fileData)], { type: 'application/octet-stream' });
    saveAs(blob, `Калькуляция_${safeName}.xls`);
  } catch (e) {
    console.error('Ошибка экспорта:', e);
    alert('Произошла ошибка при экспорте данных.');
  }
}

/* ---------------- декоративное ---------------- */
function buildMarquee() {
  const items = ['NESCAFE INTENSO', 'NESTLE ALEGRIA', 'КАКАО МИКС NP', 'NESCAFE SPECIALE',
    'СЛИВОЧНЫЙ ЛАТТЕ', 'ЭСПРЕССО', 'КАПУЧИНО', 'ЛАТТЕ', 'РАФ', 'КАКАО', 'СОЧИ · ОТЕЛИ'];
  const chunk = items.map(t => `<span>${t}</span><span class="dot">•</span>`).join('');
  $('marqueeTrack').innerHTML = chunk + chunk;
}

function initReveal() {
  const io = new IntersectionObserver(entries => {
    entries.forEach((en, k) => {
      if (en.isIntersecting) {
        en.target.style.transitionDelay = (k * 60) + 'ms';
        en.target.classList.add('visible');
        io.unobserve(en.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));
}

function initBottombar() {
  const bar = $('bottombar');
  const io = new IntersectionObserver(entries => {
    entries.forEach(en => bar.classList.toggle('show', !en.isIntersecting));
  }, { threshold: 0 });
  io.observe(document.querySelector('.hero'));
}

window.addEventListener('DOMContentLoaded', () => {
  buildMarquee();
  buildIngredients();
  buildDrinks();
  initReveal();
  initBottombar();
  recalculateAll();
});
