/* NATINF Route – aide à la qualification. Fonctionne hors ligne. Source : nomenclature NATINF (Ministère de la Justice, Licence Ouverte 2.0). */
(function () {
'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

/* ---------- stockage (protégé) ---------- */
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
};

/* ---------- données ---------- */
let D, ROWS, NAT, E, SCEN, IDX = new Map(), SCEN_BY = new Map(), PRIM = new Map();
const F_NUM = 0, F_NAT = 1, F_LIB = 2, F_DEF = 3, F_REP = 4, F_ROAD = 5, F_PRIM = 6;

const AMAX = ['38 €', '150 €', '450 €', '750 €', '1 500 € (3 000 € en récidive)'];
const FORF = ['11 €', '35 €', '68 €', '135 €'];

/* ---------- libellés lisibles (accents restaurés à l'affichage ; le libellé officiel reste consultable) ---------- */
const ACC = {};
('vehicule:véhicule vehicules:véhicules etat:état delit:délit delits:délits securite:sécurité controle:contrôle controles:contrôles declaration:déclaration activite:activité incapacite:incapacité ' +
 'etablissement:établissement marche:marché autorite:autorité sante:santé peche:pêche prealable:préalable superieure:supérieure superieur:supérieur publicite:publicité categorie:catégorie ' +
 'equipement:équipement equipements:équipements irreguliere:irrégulière irregulier:irrégulier interieures:intérieures interieur:intérieur interieure:intérieure degradation:dégradation dechets:déchets ' +
 'execution:exécution inexecution:inexécution entraine:entraîné presentation:présentation depositaire:dépositaire medicament:médicament medicaments:médicaments destine:destiné destines:destinés ' +
 'aeronef:aéronef matiere:matière matieres:matières depassement:dépassement donnees:données identite:identité conformite:conformité reserve:réservé reservee:réservée reserves:réservés ' +
 'duree:durée presence:présence proprietaire:propriétaire stupefiants:stupéfiants arrete:arrêté etranger:étranger etrangere:étrangère veterinaire:vétérinaire materiel:matériel ' +
 'deterioration:détérioration depot:dépôt denrees:denrées acces:accès espece:espèce caractere:caractère operation:opération operations:opérations qualite:qualité illegale:illégale illegal:illégal ' +
 'delais:délais delai:délai societe:société electronique:électronique elements:éléments element:élément systeme:système infirmite:infirmité realisation:réalisation delivrance:délivrance ' +
 'economique:économique oeuvre:œuvre exercant:exerçant foret:forêt entree:entrée prevention:prévention enlevement:enlèvement agrement:agrément agree:agréé periode:période ' +
 'aggravee:aggravée aggrave:aggravé etiquetage:étiquetage nucleaire:nucléaire coeur:cœur europeenne:européenne classee:classée contrefacon:contrefaçon fondee:fondée equipage:équipage ' +
 'affecte:affecté reception:réception prohibe:prohibé chargee:chargée denomination:dénomination emission:émission reglementation:réglementation reglementaire:réglementaire visibilite:visibilité ' +
 'equipe:équipé reseau:réseau privee:privée defense:défense francais:français automatise:automatisé electrique:électrique regulier:régulier regulierement:régulièrement amenagement:aménagement ' +
 'prelevement:prélèvement materiaux:matériaux falsifies:falsifiés repute:réputé egard:égard remuneration:rémunération caracteristiques:caractéristiques revelation:révélation legal:légal ' +
 'vegetaux:végétaux regle:règle regles:règles motorise:motorisé harcelement:harcèlement procedure:procédure sejour:séjour verification:vérification verifications:vérifications ' +
 'sequestration:séquestration procede:procédé etant:étant interet:intérêt evaluation:évaluation regime:régime benefice:bénéfice solidarite:solidarité numerique:numérique inferieur:inférieur ' +
 'deplacement:déplacement melange:mélange periodique:périodique etre:être ete:été eclairage:éclairage echappement:échappement retroviseur:rétroviseur homologue:homologué attache:attaché ' +
 'genant:gênant genants:gênants tres:très chaussee:chaussée priorite:priorité pieton:piéton pietons:piétons engage:engagé traversee:traversée precede:précède necessite:nécessité ' +
 'arriere:arrière expire:expiré depistage:dépistage etablir:établir prevu:prévu obtemperer:obtempérer arreter:arrêter arret:arrêt expose:exposé telephone:téléphone ecran:écran emettre:émettre ' +
 'retention:rétention malgre:malgré reduit:réduit numero:numéro fourriere:fourrière cedez:cédez ceder:céder autorise:autorisé autorisee:autorisée tenue:tenue ' +
 'recidive:récidive reprimee:réprimée definie:définie evenement:événement vehicle:véhicule liberte:liberté securise:sécurisé metre:mètre metres:mètres degre:degré ' +
 'detecteur:détecteur controlee:contrôlée delivre:délivré delivree:délivrée accompagne:accompagné accompagnement:accompagnement apprentissage:apprentissage eleve:élève ' +
 'brevet:brevet cyclomoteur:cyclomoteur homologuee:homologuée presente:présenté realise:réalisé realisee:réalisée mise:mise gene:gêné genee:gênée ' +
 'concerne:concerné obligatoire:obligatoire obligatoires:obligatoires immatricule:immatriculé deja:déjà cede:cédé accidente:accidenté accidentee:accidentée ' +
 'periodique:périodique ordonne:ordonné ordonnee:ordonnée prescrite:prescrite pense:pensé specialise:spécialisé specialement:spécialement designee:désignée ' +
 'transforme:transformé modifie:modifié modifiee:modifiée neuf:neuf visibles:visibles lisible:lisible illisible:illisible amovible:amovible ' +
 'consigne:consigné considere:considéré geree:gérée gestion:gestion collectivite:collectivité ' + 'exces:excès routiere:routière routieres:routières excedant:excédant excedent:excédent genante:gênante annule:annulé proroge:prorogé pietonne:piétonne pietonnes:piétonnes ferree:ferrée receptionne:réceptionné receptionnee:réceptionnée equide:équidé equides:équidés endossee:endossée acquereur:acquéreur impose:imposé imposee:imposée immobilise:immobilisé immobilisee:immobilisée prevue:prévue prevues:prévues prevus:prévus defaut:défaut detention:détention penal:pénal penale:pénale penales:pénales presomption:présomption reglement:règlement reglements:règlements recepisse:récépissé prefectoral:préfectoral prefecture:préfecture generale:générale general:général emis:émis depart:départ ecole:école ecoles:écoles elevee:élevée etrangers:étrangers epreuve:épreuve epreuves:épreuves medical:médical medicale:médicale medecin:médecin leger:léger legere:légère legers:légers cle:clé agglomeration:agglomération immediate:immédiate immediatement:immédiatement defectueux:défectueux defectueuse:défectueuse degagement:dégagement detenu:détenu detenue:détenue cree:créé creee:créée difficulte:difficulté adaptee:adaptée adapte:adapté reduite:réduite declare:déclaré declares:déclarés etabli:établi evasion:évasion prejudice:préjudice beneficiaire:bénéficiaire resultat:résultat resultats:résultats meconnaissance:méconnaissance surete:sûreté degats:dégâts verifie:vérifié reception:réception regulation:régulation tolere:toléré toleree:tolérée transmis:transmis designe:désigné exerce:exercé exercee:exercée realisee:réalisée mesuree:mesurée commise:commise commis:commis detourne:détourné detournee:détournée precedent:précédent precedente:précédente suivante:suivante tele:télé lies:liés liee:liée sureté:sûreté ').split(/\s+/).forEach(p => { const i = p.indexOf(':'); if (i > 0) ACC[p.slice(0, i)] = p.slice(i + 1); });
const NOUN_BEFORE_A = /^(qui|il|elle|on|n|l|d|lui|ce|cela|ne|y)$/;
const UPPER = /^(ptac|ptra|edpm|ue|ce|cee|ct|fpr|siv|m1|n1|m2|n2|n3|ptrt|cpp|kg)$/;
function fmt(s) {
  const w = s.toLowerCase().split(/(\W+)/);
  for (let i = 0; i < w.length; i++) {
    const t = w[i];
    if (!t || /^\W+$/.test(t)) continue;
    if (t === 'a') {
      const prev = (w[i - 2] || '');
      const next = (w[i + 2] || '');
      if (prev && !NOUN_BEFORE_A.test(prev) && /^[a-z0-9]/.test(next)) w[i] = 'à';
      continue;
    }
    if (ACC[t]) w[i] = ACC[t];
    else if (UPPER.test(t)) w[i] = t.toUpperCase();
  }
  let r = w.join('');
  return r.charAt(0).toUpperCase() + r.slice(1);
}

/* ---------- normalisation / recherche ---------- */
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/['’]/g, ' ').replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
const STOP = new Set('le la les l d de du des un une en au aux et ou a pour par sur dans qui que ce il elle est ils elles on y se sa son ses mon ma ne pas plus tres avec volant lui cela ca je tu nous vous'.split(' '));
const SYN_GROUPS = [
  'alcool alcoolique alcoolemie ivresse ivre saoul soul bourre biere vin ethylotest ethylometre ethylique',
  'stupefiant stup stups drogue came cannabis shit joint herbe cocaine amphetamine opiace fume salivaire',
  'telephone portable tel smartphone gsm sms texto',
  'vehicule voiture auto caisse bagnole',
  'motocyclette moto cyclomoteur scooter mobylette',
  'engin trottinette edpm hoverboard gyropode',
  'cycle velo cycliste',
  'vitesse radar flash cinemometre survitesse',
  'immatriculation plaque grise',
  'fuite fuit',
  'obtemperer obtempere sommation',
  'conducteur chauffeur automobiliste',
  'stationnement gare garer parking',
  'ceinture attache',
  'feu feux brule',
  'refus refuse refuser souffler',
  'violence frappe coup bagarre baston',
  'vol voleur cambriolage',
  'arme couteau pistolet',
  'injure insulte outrage',
  'enfant mineur gosse',
  'chien animal'
];
const SYN = new Map();
SYN_GROUPS.forEach(g => { const a = g.split(' '); a.forEach(w => SYN.set(w, a)); });
const stem = t => (t.length > 3 && /[sx]$/.test(t) && !/ss$/.test(t)) ? t.slice(0, -1) : t;
const PHRASES = [[/carte grise/g, 'certificat immatriculation'], [/permis de conduire/g, 'permis'], [/ligne continue/g, 'ligne continue'],
  [/pris de boisson/g, 'alcool'], [/en etat d ivresse/g, 'alcool'], [/delit de fuite/g, 'delit fuite'], [/feu rouge/g, 'feu rouge'], [/passage pieton/g, 'passage pietons']];
function tokens(q) {
  let n = norm(q); PHRASES.forEach(([re, to]) => { n = n.replace(re, to); });
  return n.split(' ').filter(t => t && !STOP.has(t)).map(stem);
}
const alts = t => SYN.get(t) || [t];
let TXT = [];     // texte normalisé de chaque ligne, encadré d'espaces
let ARTS = null;  // articles normalisés de chaque ligne (lazy)

function buildIndex() {
  TXT = ROWS.map(r => ' ' + norm(r[F_LIB]) + ' ');
  ROWS.forEach((r, i) => { IDX.set(r[F_NUM], i); if (r[F_PRIM]) { const k = r[F_PRIM]; (PRIM.get(k) || PRIM.set(k, []).get(k)).push(i); } });
  SCEN.forEach(s => { s._t = ' ' + norm(s.title) + ' '; s._k = ' ' + norm(s.kw + ' ' + s.desc) + ' '; SCEN_BY.set(s.id, s); });
}
function buildArts() {
  const re = /ART\.([LRD]\.\d+(?:-\d+)*|\d+(?:-\d+)*)/g;
  ARTS = ROWS.map(r => {
    const out = {def: ' ', all: ' '};
    for (const m of r[F_DEF].matchAll(re)) { const a = m[1].toLowerCase(); out.def += a + ' '; out.all += a + ' '; }
    for (const m of r[F_REP].matchAll(re)) out.all += m[1].toLowerCase() + ' ';
    return out;
  });
}
function scoreText(t, toks) {
  // renvoie null si un mot n'est pas trouvé ; sinon un score
  let s = 0;
  for (const tk of toks) {
    let best = 0;
    for (const a of alts(tk)) {
      if (t.includes(' ' + a + ' ')) { best = Math.max(best, 3); }
      else if (a.length >= 4 && t.includes(' ' + a)) { best = Math.max(best, 2); }
      else if (a.length >= 5 && t.includes(a)) { best = Math.max(best, 1); }
    }
    if (!best) return null;
    s += best;
  }
  return s;
}
function search(q, filter) {
  q = q.trim();
  if (!q) return {list: [], mode: 'vide'};
  const fOK = i => {
    const r = ROWS[i], k = r[F_NAT];
    switch (filter) {
      case 'route': return r[F_ROAD] === 1;
      case 'contra': return k <= 4 || k === 8;
      case 'delit': return k === 5 || k === 7 || k === 9;
      case 'crime': return k === 6;
      default: return true;
    }
  };
  // 1) numéro NATINF
  if (/^\d{1,6}$/.test(q)) {
    const out = [];
    const n = parseInt(q, 10);
    if (IDX.has(n)) out.push(IDX.get(n));
    ROWS.forEach((r, i) => { if (r[F_NUM] !== n && String(r[F_NUM]).startsWith(q) && out.length < 40) out.push(i); });
    return {list: out.filter(fOK), mode: 'numéro'};
  }
  // 2) article (ex : L234-1, R.412-6, art 221-18)
  const am = q.toLowerCase().match(/^(?:art(?:icle)?\.?\s*)?([lrd])?\.?\s*(\d+-\d+(?:-\d+)*|\d{3,})\s*$/);
  if (am && (am[1] || /-/.test(am[2]))) {
    if (!ARTS) buildArts();
    const key = (am[1] ? am[1] + '.' : '') + am[2];
    const re = new RegExp((am[1] ? ' ' : ' (?:[lrd]\\.)?') + key.replace(/[.\-]/g, '\\$&') + '(?![0-9-])');
    const out = [];
    ROWS.forEach((r, i) => {
      if (!fOK(i)) return;
      if (re.test(ARTS[i].def)) out.push([3 + (r[F_ROAD] ? 1 : 0), i]);
      else if (re.test(ARTS[i].all)) out.push([1 + (r[F_ROAD] ? 1 : 0), i]);
    });
    out.sort((a, b) => b[0] - a[0] || ROWS[a[1]][F_NUM] - ROWS[b[1]][F_NUM]);
    return {list: out.map(x => x[1]), mode: 'article'};
  }
  // 3) texte
  const toks = tokens(q);
  if (!toks.length) return {list: [], mode: 'vide'};
  const scored = [];
  const boost = new Map(), top = rankScen(q)[0], wantRed = /redevable/.test(norm(q));
  if (top) top.groups.forEach(g => g.ids.forEach(n => boost.set(n, Math.max(boost.get(n) || 0, g.role === 'principal' ? 8 : 4))));
  for (let i = 0; i < ROWS.length; i++) {
    if (!fOK(i)) continue;
    const sc = scoreText(TXT[i], toks);
    if (sc === null) continue;
    const r = ROWS[i];
    let b = sc + (r[F_ROAD] ? 1.5 : 0) + (E[r[F_NUM]] && E[r[F_NUM]].pts !== undefined ? 1 : 0) - TXT[i].length / 400 + (boost.get(r[F_NUM]) || 0)
          - (!wantRed && TXT[i].startsWith(' redevable') ? 3 : 0);
    scored.push([b, i]);
  }
  let mode = 'texte';
  if (scored.length < 4 && toks.length > 1) {   // repli : au moins la moitié des mots
    const need = Math.ceil(toks.length / 2), seen = new Set(scored.map(x => x[1]));
    for (let i = 0; i < ROWS.length; i++) {
      if (seen.has(i) || !fOK(i)) continue;
      let hit = 0, sc = 0;
      for (const tk of toks) { const s1 = scoreText(TXT[i], [tk]); if (s1 !== null) { hit++; sc += s1; } }
      if (hit >= need) scored.push([sc * 0.5 + (ROWS[i][F_ROAD] ? 1 : 0) - TXT[i].length / 400 + (boost.get(ROWS[i][F_NUM]) || 0), i]);
    }
    mode = 'approchant';
  }
  scored.sort((a, b) => b[0] - a[0] || ROWS[a[1]][F_NUM] - ROWS[b[1]][F_NUM]);
  return {list: scored.map(x => x[1]), mode, toks};
}
function rankScen(q) {
  const toks = tokens(q);
  if (!toks.length) return [];
  const out = [];
  SCEN.forEach(s => {
    let sc = 0, hit = 0;
    for (const tk of toks) {
      let b = 0;
      for (const a of alts(tk)) {
        if (s._t.includes(' ' + a + ' ')) b = Math.max(b, 3);
        else if (s._k.includes(' ' + a + ' ')) b = Math.max(b, 2);
        else if (a.length >= 4 && s._t.includes(' ' + a)) b = Math.max(b, 3);
        else if (a.length >= 4 && s._k.includes(' ' + a)) b = Math.max(b, 2);
        else if (a.length >= 5 && (s._k.includes(a) || s._t.includes(a))) b = Math.max(b, 1);
      }
      if (b) { hit++; sc += b; }
    }
    if (hit && hit >= Math.ceil(toks.length / 2)) out.push([sc * (hit / toks.length), s]);
  });
  out.sort((a, b) => b[0] - a[0]);
  return out.map(x => x[1]);
}

/* ---------- rendu ---------- */
const natClass = k => k <= 4 ? 'nat-c' : (k === 5 || k === 7 || k === 9) ? 'nat-d' : k === 6 ? 'nat-k' : 'nat-o';
const natShort = k => k <= 4 ? 'Contravention ' + (k + 1) + 'e cl.' : NAT[k];
function hl(html, toks) {
  if (!toks || !toks.length) return html;
  let out = html;
  const words = new Set();
  toks.forEach(t => alts(t).forEach(a => a.length >= 2 && words.add(a)));
  const re = new RegExp('(^|[^a-zà-ÿ])(' + [...words].map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'gi');
  return out.replace(re, (m, p, w) => p + '<mark>' + w + '</mark>');
}
function routeArts(r, n = 3) {
  const out = [];
  for (const part of r[F_DEF].trim().split(/(?<=\.)\s+(?=ART\.)/)) {
    if (/C\.ROUTE\.$/.test(part.trim())) {
      for (const m of part.matchAll(/ART\.([LRD]\.\d+(?:-\d+)*)/g)) if (!out.includes(m[1])) out.push(m[1]);
    }
  }
  return out.slice(0, n);
}
function badges(num, r) {
  const e = E[num] || {}, b = [];
  if (e.pts !== undefined && e.pts !== null) b.push(`<span class="chip pts">${e.pts} pt${e.pts > 1 ? 's' : ''}</span>`);
  const add = (key, label, strong) => {
    const v = e[key]; if (!v || !v.lvl) return;
    b.push(`<span class="chip ${v.lvl === 'obl' || (strong && v.lvl === 'rec') ? 'red' : 'amb'}">${label}</span>`);
  };
  if (e.confiscation && e.confiscation.lvl) b.push(`<span class="chip ${e.confiscation.lvl === 'obl' ? 'red' : 'amb'}">${e.confiscation.lvl === 'obl' ? 'Confiscation oblig.' : 'Confiscation'}</span>`);
  add('retention', 'Rétention');
  add('depistage', 'Dépistage');
  add('immobilisation', 'Immobilisation');
  return b.join('');
}
function card(i, toks, extraClass) {
  const r = ROWS[i], num = r[F_NUM], k = r[F_NAT];
  const arts = routeArts(r);
  return `<button class="card ${natClass(k)} ${extraClass || ''}" data-n="${num}">
    <div class="top"><span class="num">${num}</span><span class="chip ${natClass(k)}">${esc(natShort(k))}</span>${badges(num, r)}</div>
    <div class="lib">${hl(esc(fmt(r[F_LIB])), toks)}</div>
    ${arts.length ? `<div class="arts">${arts.map(esc).join(' · ')}</div>` : ''}
  </button>`;
}
function scenCard(s, big) {
  const n = s.groups.reduce((a, g) => a + g.ids.length, 0);
  return `<button class="scard ${big ? 'big' : ''}" data-s="${s.id}"><b>${esc(s.title)}</b><small>${esc(s.cat)} · ${n} NATINF</small></button>`;
}

/* ---------- état et vues ---------- */
const state = {tab: store.get('tab', 'situations'), filter: 'tous', q: '', shown: 40};
let lastScroll = 0;
const main = $('#main');

function viewSituations() {
  const q = state.q.trim();
  let html = '';
  if (!q) {
    html += `<p class="hint">Choisissez une situation de contrôle, ou décrivez-la ci-dessus (ex. « conduit en état d'ivresse », « refus de s'arrêter », « téléphone au volant »).</p>`;
    const cats = [];
    SCEN.forEach(s => { if (!cats.includes(s.cat)) cats.push(s.cat); });
    cats.forEach(c => {
      html += `<h2>${esc(c)}</h2><div class="grid">${SCEN.filter(s => s.cat === c).map(s => scenCard(s)).join('')}</div>`;
    });
  } else {
    const res = search(q, 'tous');
    const sc = (res.mode === 'numéro' || res.mode === 'article') ? [] : rankScen(q);
    if (sc.length) {
      html += `<h2>Situations correspondantes</h2><div class="list">${sc.slice(0, 5).map(s => scenCard(s, true)).join('')}</div>`;
    }
    if (res.list.length) {
      html += `<h2>Infractions possibles${res.mode === 'approchant' ? ' (approchant)' : ''}</h2><div class="list">${res.list.slice(0, 10).map(i => card(i, res.toks)).join('')}</div>`;
      if (res.list.length > 10) html += `<button class="more" data-go="infractions">Voir les ${res.list.length} résultats dans « Infractions »</button>`;
    }
    if (!sc.length && !res.list.length) html += `<div class="empty">Aucun résultat pour « ${esc(q)} ».<br>Essayez un mot plus simple (ex. « permis », « vitesse », « alcool »).</div>`;
  }
  return html;
}
function viewInfractions() {
  const q = state.q.trim();
  const chips = [['tous', 'Tous'], ['route', 'Routier'], ['contra', 'Contraventions'], ['delit', 'Délits'], ['crime', 'Crimes']];
  let html = `<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(110px,1fr));margin-bottom:12px">${chips.map(([k, l]) =>
    `<button class="btn ${state.filter === k ? 'primary' : ''}" data-filter="${k}">${l}</button>`).join('')}</div>`;
  if (!q) {
    html += `<p class="hint">Cherchez par <b>mot</b> (« sans permis », « ceinture »), par <b>numéro NATINF</b> (« 1247 ») ou par <b>article</b> (« L234-1 », « R412-6-1 »). ${ROWS.length.toLocaleString('fr-FR')} infractions en vigueur, hors ligne.</p>`;
    html += `<h2>Recherches fréquentes</h2><div class="grid">${['sans permis', 'alcool', 'stupéfiants', 'refus d\'obtempérer', 'téléphone', 'ceinture', 'plaque', 'stationnement gênant'].map(x =>
      `<button class="scard" data-ex="${esc(x)}"><b>${esc(x)}</b></button>`).join('')}</div>`;
    return html;
  }
  const res = search(q, state.filter);
  const sc = rankScen(q);
  if (sc.length && res.mode !== 'numéro' && res.mode !== 'article') html += `<div class="list" style="margin-bottom:12px">${scenCard(sc[0], true)}</div>`;
  if (!res.list.length) return html + `<div class="empty">Aucun NATINF trouvé pour « ${esc(q)} »${state.filter !== 'tous' ? ' avec ce filtre' : ''}.</div>`;
  html += `<p class="hint">${res.list.length.toLocaleString('fr-FR')} résultat${res.list.length > 1 ? 's' : ''}${res.mode === 'approchant' ? ' approchants (tous les mots ne correspondent pas)' : ''}${res.mode === 'article' ? ' pour cet article' : ''}</p>`;
  html += `<div class="list">${res.list.slice(0, state.shown).map(i => card(i, res.toks)).join('')}</div>`;
  if (res.list.length > state.shown) html += `<button class="more" data-more="1">Afficher plus (${res.list.length - state.shown} restants)</button>`;
  return html;
}
function viewFavoris() {
  const fav = store.get('fav', []);
  if (!fav.length) return `<div class="empty">Aucun favori.<br>Ouvrez une fiche et touchez ☆ pour la garder à portée de main.</div>`;
  return `<div class="list">${fav.filter(n => IDX.has(n)).map(n => card(IDX.get(n))).join('')}</div>`;
}
function renderList() {
  const fn = state.tab === 'situations' ? viewSituations : state.tab === 'infractions' ? viewInfractions : viewFavoris;
  main.innerHTML = fn();
  document.querySelectorAll('#tabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.tab === state.tab ? 'true' : 'false'));
  $('#tabs').hidden = false;
}

/* ----- détail d'une infraction ----- */
function tile(k, v, lvl, wide) {
  const cls = lvl === 'obl' ? 'red' : (lvl === 'fac' || lvl === 'rec') ? 'amb' : '';
  return `<div class="tile ${cls} ${wide ? 'wide' : ''}"><div class="k">${k}</div><div class="v">${v}</div></div>`;
}
const LVL = {obl: 'OBLIGATOIRE – ', rec: 'EN RÉCIDIVE – ', fac: 'POSSIBLE – '};
let GL = [];
function artBlock(s) {
  if (!s.trim()) return '<div>—</div>';
  return s.trim().split(/(?<=\.)\s+(?=ART\.)/).map(g => {
    let body = g.replace(/ART\./g, ''), tail = '';
    for (const [mn, lib, kind, re] of GL) {
      if (re.test(body)) {
        if (kind === 'code') { body = body.replace(re, '$1').replace(/[\s.]+$/, '').trim(); tail = ' — ' + lib; }
        else body = body.replace(re, '$1' + lib);
        break;
      }
    }
    return `<div>${esc(body + tail)}</div>`;
  }).join('');
}
function viewDetail(num) {
  if (!IDX.has(num)) return `<button class="back" data-back="1">‹ Retour</button><div class="empty">NATINF ${esc(num)} introuvable.</div>`;
  const i = IDX.get(num), r = ROWS[i], k = r[F_NAT], e = E[num] || {};
  const fav = store.get('fav', []).includes(num);
  let h = `<button class="back" data-back="1">‹ Retour</button>
  <div class="dhead"><span class="dnum">${num}</span><span class="chip ${natClass(k)}">${esc(NAT[k])}</span>${r[F_ROAD] ? '<span class="chip nat-o">Code de la route</span>' : ''}</div>
  <div class="dlib">${esc(fmt(r[F_LIB]))}</div>
  <div class="actions"><button class="btn primary" data-copy="${num}">Copier NATINF + libellé</button><button class="btn" data-fav="${num}" aria-label="Favori"><span class="star">${fav ? '★' : '☆'}</span></button></div>`;

  // Mesures
  const t = [];
  const road = r[F_ROAD] === 1;
  if (e.pts !== undefined) t.push(tile('Retrait de points', e.pts === null ? 'Non renseigné – voir barème' : `<b>${e.pts}</b> point${e.pts > 1 ? 's' : ''}`, e.pts >= 6 ? 'obl' : e.pts >= 3 ? 'fac' : null));
  else if (road && (k <= 5)) t.push(tile('Retrait de points', 'Non renseigné dans cette version – voir barème officiel', null));
  if (k <= 4) t.push(tile('Amende', `Max ${AMAX[k]}${road && k <= 3 ? `<br>Forfaitaire courante : ${esc(e.forfait || FORF[k])}` : ''}`, null, false));
  if (e.peine) t.push(tile('Peine encourue', esc(e.peine), null, true));
  [['retention', 'Rétention du permis'], ['suspension', 'Suspension'], ['depistage', 'Dépistage / vérification'], ['confiscation', 'Confiscation du véhicule'], ['immobilisation', 'Immobilisation']]
    .forEach(([key, label]) => { const v = e[key]; if (v) t.push(tile(label, (v.lvl ? `<b style="font-size:13px">${LVL[v.lvl]}</b>` : '') + esc(v.txt), v.lvl, true)); });
  if (t.length) h += `<h2>Mesures et barème <span class="tag">Indicatif – à valider</span></h2><div class="tiles">${t.join('')}</div>`;
  else if (road) h += `<h2>Mesures et barème</h2><div class="box">Points, rétention, confiscation et dépistage ne sont pas encore renseignés pour cette infraction : se référer aux articles ci-dessous.</div>`;
  if (e.notes && e.notes.length) h += `<div class="box"><h3>À savoir</h3><ul>${e.notes.map(n => `<li>${esc(n)}</li>`).join('')}</ul></div>`;

  // Articles
  h += `<h2>Textes <span class="src">source : NATINF officiel</span></h2><div class="box art"><b>Définie par</b>${artBlock(r[F_DEF])}<b>Réprimée par (peines)</b>${artBlock(r[F_REP])}</div>`;
  h += `<div class="box"><h3>Libellé officiel NATINF</h3><div class="art">${esc(r[F_LIB])}</div></div>`;

  // Voisines
  if (r[F_PRIM] && PRIM.has(r[F_PRIM])) {
    const sib = PRIM.get(r[F_PRIM]).filter(j => j !== i).slice(0, 8);
    if (sib.length) h += `<h2>Voir aussi (même article ${esc(r[F_PRIM])})</h2><div class="list">${sib.map(j => card(j)).join('')}</div>`;
  }
  // Scénarios liés
  const sl = SCEN.filter(s => s.groups.some(g => g.ids.includes(num)));
  if (sl.length) h += `<h2>Situations liées</h2><div class="list">${sl.map(s => scenCard(s, true)).join('')}</div>`;
  h += `<p class="legal">Aide à la qualification, <b>non opposable</b>. Vérifier systématiquement les textes en vigueur (Légifrance) avant de rédiger une procédure. Base NATINF : édition ${esc(D.meta.edition)}.</p>`;
  return h;
}
function viewScenario(id) {
  const s = SCEN_BY.get(id);
  if (!s) return `<button class="back" data-back="1">‹ Retour</button><div class="empty">Situation introuvable.</div>`;
  let h = `<button class="back" data-back="1">‹ Retour</button><div class="chip nat-o">${esc(s.cat)}</div>
  <div class="dlib" style="margin-top:8px">${esc(s.title)}</div><p class="hint" style="margin-top:-6px">${esc(s.desc)}</p>`;
  if (s.check && s.check.length) h += `<div class="box"><h3>À vérifier / à faire <span class="tag">Indicatif – à valider</span></h3><ul>${s.check.map(c => `<li>${esc(c)}</li>`).join('')}</ul></div>`;
  const label = {principal: 'Infractions à retenir', associee: 'Infractions souvent associées', aggravante: 'Cas aggravés'};
  s.groups.forEach(g => {
    if (!g.ids.length) return;
    h += `<h2>${esc(g.title)}</h2><div class="list">${g.ids.filter(n => IDX.has(n)).map(n => card(IDX.get(n))).join('')}</div>`;
  });
  h += `<p class="legal">Sélection d'aide à la qualification : elle ne remplace ni l'analyse des faits ni la vérification des textes. Pour une qualification précise, utilisez aussi l'onglet « Infractions ».</p>`;
  return h;
}
function viewAbout() {
  return `<button class="back" data-back="1">‹ Retour</button>
  <div class="dlib">À propos et limites</div>
  <div class="box"><h3>Source des données</h3>Nomenclature NATINF « Liste des infractions en vigueur » – Ministère de la Justice (data.gouv.fr), <b>Licence Ouverte 2.0</b>. Édition ${esc(D.meta.edition)} : <b>${D.meta.count.toLocaleString('fr-FR')}</b> infractions. Numéro, nature, libellé et articles viennent tels quels de ce fichier.</div>
  <div class="box"><h3>Ce qui n'est pas dans le fichier officiel</h3>Les <b>points</b>, la <b>rétention</b>, la <b>suspension</b>, la <b>confiscation</b>, le <b>dépistage</b>, l'<b>immobilisation</b>, les <b>peines</b> des principaux délits et les listes de « à vérifier » ont été ajoutés pour faciliter le travail. Ils sont signalés <span class="tag">Indicatif – à valider</span> : ils doivent être relus et validés par une personne compétente avant tout usage opérationnel.</div>
  <div class="box"><h3>Utilisation</h3><ul>
  <li><b>Situations</b> : décrivez les faits ou choisissez une situation ; l'application propose les NATINF liés.</li>
  <li><b>Infractions</b> : recherche par mot, numéro NATINF (ex. 1247) ou article (ex. L234-1).</li>
  <li>Fonctionne <b>hors ligne</b> une fois la page chargée et installée sur l'écran d'accueil.</li></ul></div>
  <div class="box"><h3>Avertissement</h3>Outil d'aide à la qualification, <b>non officiel</b>, qui n'a aucune valeur juridique. Les textes évoluent : vérifiez toujours sur Légifrance. Aucune donnée saisie n'est envoyée : la recherche se fait sur votre appareil.</div>
  <div class="box"><h3>Thème</h3><button class="btn" data-theme="auto">Auto</button> <button class="btn" data-theme="light">Clair</button> <button class="btn" data-theme="dark">Sombre</button></div>`;
}

/* ---------- routeur ---------- */
function route() {
  const h = location.hash || '#/';
  let m;
  const top = $('#tabs');
  if ((m = h.match(/^#\/n\/(\d+)/))) { top.hidden = true; main.innerHTML = viewDetail(parseInt(m[1], 10)); window.scrollTo(0, 0); document.title = 'NATINF ' + m[1]; }
  else if ((m = h.match(/^#\/s\/([\w-]+)/))) { top.hidden = true; main.innerHTML = viewScenario(m[1]); window.scrollTo(0, 0); }
  else if (h.startsWith('#/about')) { top.hidden = true; main.innerHTML = viewAbout(); window.scrollTo(0, 0); }
  else { document.title = 'NATINF Route'; renderList(); window.scrollTo(0, lastScroll); }
}
function go(hash) { if (/^#\/(n|s|about)/.test(hash)) lastScroll = window.scrollY; location.hash = hash; }
window.addEventListener('hashchange', route);

/* ---------- événements ---------- */
let timer;
const qEl = $('#q'), clr = $('#clear');
qEl.addEventListener('input', () => {
  clr.hidden = !qEl.value;
  clearTimeout(timer);
  timer = setTimeout(() => {
    state.q = qEl.value; state.shown = 40; lastScroll = 0;
    if (location.hash && location.hash !== '#/') { location.hash = '#/'; } else renderList();
  }, 140);
});
qEl.addEventListener('keydown', e => { if (e.key === 'Enter') qEl.blur(); });
clr.addEventListener('click', () => { qEl.value = ''; state.q = ''; clr.hidden = true; qEl.focus(); if (location.hash !== '#/' && location.hash) location.hash = '#/'; else renderList(); });
$('#tabs').addEventListener('click', e => {
  const b = e.target.closest('button[data-tab]'); if (!b) return;
  state.tab = b.dataset.tab; store.set('tab', state.tab); state.shown = 40; lastScroll = 0; renderList(); window.scrollTo(0, 0);
});
$('#btnAbout').addEventListener('click', () => go('#/about'));
$('#title').addEventListener('click', () => { if (location.hash !== '#/') location.hash = '#/'; });
function toast(t) { const el = $('#toast'); el.textContent = t; el.classList.add('on'); clearTimeout(toast._t); toast._t = setTimeout(() => el.classList.remove('on'), 1800); }
function applyTheme(t) { if (t === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', t); store.set('theme', t); }
main.addEventListener('click', e => {
  const t = e.target.closest('[data-n],[data-s],[data-back],[data-go],[data-filter],[data-ex],[data-more],[data-copy],[data-fav],[data-theme]');
  if (!t) return;
  const d = t.dataset;
  if (d.n) go('#/n/' + d.n);
  else if (d.s) go('#/s/' + d.s);
  else if (d.back) { if (history.length > 1 && document.referrer !== undefined && window.__navDepth > 0) history.back(); else location.hash = '#/'; }
  else if (d.go) { state.tab = d.go; store.set('tab', state.tab); renderList(); window.scrollTo(0, 0); }
  else if (d.filter) { state.filter = d.filter; state.shown = 40; renderList(); }
  else if (d.ex) { qEl.value = d.ex; state.q = d.ex; clr.hidden = false; renderList(); window.scrollTo(0, 0); }
  else if (d.more) { state.shown += 60; renderList(); }
  else if (d.copy) {
    const n = parseInt(d.copy, 10), r = ROWS[IDX.get(n)];
    const txt = 'NATINF ' + n + ' – ' + fmt(r[F_LIB]);
    const ok = () => toast('Copié : NATINF ' + n);
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(ok, () => toast('Copie impossible'));
    else { const ta = document.createElement('textarea'); ta.value = txt; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); ok(); } catch (x) { toast('Copie impossible'); } ta.remove(); }
  }
  else if (d.fav) {
    const n = parseInt(d.fav, 10); let fav = store.get('fav', []);
    fav = fav.includes(n) ? fav.filter(x => x !== n) : [n, ...fav];
    store.set('fav', fav); t.querySelector('.star').textContent = fav.includes(n) ? '★' : '☆';
    toast(fav.includes(n) ? 'Ajouté aux favoris' : 'Retiré des favoris');
  }
  else if (d.theme) applyTheme(d.theme);
});
window.__navDepth = 0;
window.addEventListener('hashchange', () => { window.__navDepth = Math.min(window.__navDepth + 1, 50); });

/* ---------- démarrage ---------- */
function start(data) {
  D = data; GL = Object.entries(D.glossaire || {}).sort((a, b) => b[0].length - a[0].length).map(([mn, v]) => [mn, v[0], v[1], new RegExp('(^|\\s)' + mn.replace(/[.&]/g, '\\$&') + '(?=[\\s.]|$)')]); ROWS = D.rows; NAT = D.nature; E = D.enrich; SCEN = D.scen;
  buildIndex();
  const th = store.get('theme', 'auto'); if (th !== 'auto') applyTheme(th);
  $('#loading').hidden = true;
  route();
  if (location.search.includes('q=')) { const p = new URLSearchParams(location.search).get('q'); if (p) { qEl.value = p; state.q = p; clr.hidden = false; renderList(); } }
}
if (window.__DATA__) start(window.__DATA__);
else fetch('data.json').then(r => r.json()).then(start).catch(() => { $('#loading').textContent = 'Impossible de charger la base. Vérifiez la connexion pour le premier chargement.'; });
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});
window.__natinf = {search, rankScen, fmt, tokens, row: i => ROWS[i]};   // aide au test
})();
