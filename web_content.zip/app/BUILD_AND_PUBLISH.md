# Genus Business Manager – Android app

This folder is a ready-to-open Android Studio project (built with Capacitor). Your app lives in `www/index.html`.
Nothing here has been compiled yet, because it needs the Android SDK. Follow the steps below on your own computer.

## 1. One-time setup on your PC
1. Install **Node.js (LTS)**: https://nodejs.org
2. Install **Android Studio**: https://developer.android.com/studio (it includes the Java and Android SDK you need).

## 2. Build and test
```
npm install
npx cap sync android
npx cap open android
```
Android Studio opens. Wait for Gradle to finish syncing (first time takes several minutes), then plug in a phone with
USB debugging on (or start an emulator) and press the green **Run** button.

**Test these on a real phone before publishing:** sign-in, a sale, void a sale, camera barcode scan, Print (should open the
Android print dialog – choose "Save as PDF" to test), Backup (should open a Save/Share sheet), Restore, close and reopen the
app (data must still be there).

## 3. Before you publish
- **App ID**: `com.genuspc.businessmanager` is a placeholder. It is permanent once published. To change it, edit `appId` in
  `capacitor.config.json`, `applicationId`/`namespace` in `android/app/build.gradle`, and the Java package in
  `android/app/src/main/java/...` (Android Studio: right-click package > Refactor > Rename).
- **Icon**: replace the default icon: in Android Studio, right-click `app/res` > New > Image Asset.
- **Version**: each upload to Google Play needs a higher `versionCode` in `android/app/build.gradle`.
- If you edit `www/index.html`, run `npx cap sync android` again.

## 4. Make the signed release file (.aab)
Android Studio > **Build > Generate Signed App Bundle / APK > Android App Bundle**. Create a new keystore, and **back up the
.jks file and its passwords somewhere safe** (outside this folder). Choose "release". Use Google Play App Signing when asked.
Result: `android/app/release/app-release.aab`.

## 5. Google Play Console
1. Create a developer account at https://play.google.com/console (one-time US$25 fee, identity verification).
2. **To sell the app (paid app) you need a Google payments merchant profile, and your country must support merchant
   registration.** Check your country here: https://support.google.com/googleplay/android-developer/answer/9306917
   An app set to *Free* can never be switched to Paid later, so decide the price model when you create the app.
   Alternative to a paid download: publish it free and sell licences/activation outside Google Play.
3. Create app > upload the `.aab` > fill in the store listing: 512×512 icon, 1024×500 feature graphic, at least 2 phone
   screenshots, short and full description.
4. Required forms: **Privacy policy URL**, **Data safety**, **Content rating**, **Target audience**, **App access** (give
   Google a test administrator login).
5. New personal developer accounts may have to run a **closed test with a minimum number of testers for 14 days** before
   production access. Check the current rule in Play Console help.

## 6. Things to know about this app
- All data (sales, stock, payroll, employees) is stored **only on the phone**, inside the app. Uninstalling or clearing app
  data deletes it. Tell customers to use **Backup** regularly and keep the file safe.
- There is no cloud sync: each phone has its own separate data.
- Sign-in security is local to the device. It is fine for a shop, but do not describe it as bank-grade security in the
  store listing.
- Some text and features are specific to your shop (default name "Genus PC Connections", PlayStation/Xbox repair page,
  NIS/BIR payroll fields, "TTD"). Customers in other businesses or countries may want those changed before you sell it.
