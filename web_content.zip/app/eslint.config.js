import firebaseRulesPlugin from '@firebase/eslint-plugin-security-rules';

export default [
  {
    ignores: ['dist/**/*', '.gmp_cache/**/*', 'node_modules/**/*', 'src/**/*'],
  },
  {
    files: ['DRAFT_firestore.rules', 'firestore.rules'],
    ...firebaseRulesPlugin.configs['flat/recommended'],
  },
];
