<?php
declare(strict_types=1);
require_once __DIR__ . '/resources.php';
require_once __DIR__ . '/admin.php';

function resource_admin_notice(?string $message, string $type='success'): array {
    return ['message'=>$message ?? '', 'type'=>$type];
}
function resource_admin_parse_steps(string $raw): array {
    $steps=[];$lines=preg_split('/\r\n|\r|\n/',$raw)?:[];
    foreach($lines as $line){$line=trim($line);if($line==='')continue;$parts=explode('|',$line,2);$title=trim($parts[0]);$body=trim($parts[1]??'');if($title==='')$title='Step '.(count($steps)+1);if($body==='')$body=$title;$steps[]=['title'=>substr($title,0,180),'body'=>substr($body,0,5000)];if(count($steps)>=40)break;}
    return $steps;
}
function resource_admin_validate_category(string $kind, int $id): ?int {
    $table=$kind==='tool'?'tool_categories':'tutorial_categories';
    if($id<1)return null;
    $s=db()->prepare("SELECT id FROM {$table} WHERE id=? LIMIT 1");$s->execute([$id]);$v=$s->fetchColumn();
    if($v===false)throw new InvalidArgumentException('Choose a category that exists.');
    return (int)$v;
}
function resource_admin_handle_post(): ?array {
    if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')return null;
    $action=(string)($_POST['admin_action']??'');
    if(!str_starts_with($action,'resource_'))return null;
    $admin=auth_require_admin();
    if(!auth_csrf_valid())return resource_admin_notice('Security token expired. Refresh and try again.','error');
    resources_schema();
    try {
        $pdo=db();$now=now_sql();
        if($action==='resource_save_tool'){
            $id=(int)($_POST['id']??0);$name=trim((string)($_POST['name']??''));$slugInput=trim((string)($_POST['slug']??''));$slug=resources_slug($slugInput!==''?$slugInput:$name);if(strlen($slug)>180)throw new InvalidArgumentException('Tool URL slug must be 180 characters or fewer.');
            if($name===''||strlen($name)>160)throw new InvalidArgumentException('Tool name is required and must be 160 characters or fewer.');
            $short=trim((string)($_POST['short_description']??''));$full=trim((string)($_POST['full_description']??''));
            if(strlen($short)>500||strlen($full)>10000)throw new InvalidArgumentException('Tool description is too long.');
            $official=resources_safe_url((string)($_POST['official_url']??''),false);
            $download=resources_safe_url((string)($_POST['download_page_url']??''));
            $win=resources_safe_url((string)($_POST['windows_download_url']??''));$mac=resources_safe_url((string)($_POST['macos_download_url']??''));$linux=resources_safe_url((string)($_POST['linux_download_url']??''));
            $category=resource_admin_validate_category('tool',(int)($_POST['category_id']??0));
            $pricing=(string)($_POST['pricing']??'unknown');if(!in_array($pricing,['free','paid','freemium','unknown'],true))$pricing='unknown';
            $status=(string)($_POST['status']??'draft');if(!in_array($status,['draft','published'],true))$status='draft';
            $featured=isset($_POST['is_featured'])?1:0;$version=substr(trim((string)($_POST['version']??'')),0,80);
            $install=trim((string)($_POST['installation_instructions']??''));$compat=trim((string)($_POST['compatibility_info']??''));$req=trim((string)($_POST['system_requirements']??''));
            if(strlen($install)>10000||strlen($compat)>5000||strlen($req)>5000)throw new InvalidArgumentException('Tool setup or compatibility details exceed the allowed length.');
            $existing=null;if($id>0){$q=$pdo->prepare('SELECT logo_path FROM tools WHERE id=?');$q->execute([$id]);$existing=$q->fetch();if(!$existing)throw new InvalidArgumentException('Tool record not found.');}
            $logo=resources_upload_image($_FILES['logo']??[],'tool-logo');if($logo==='')$logo=$existing['logo_path']??null;
            $dupe=$pdo->prepare('SELECT id FROM tools WHERE slug=? AND id<>? LIMIT 1');$dupe->execute([$slug,$id]);if($dupe->fetchColumn())throw new InvalidArgumentException('That tool URL slug is already in use.');
            if($id>0){$pdo->prepare('UPDATE tools SET category_id=?,name=?,slug=?,logo_path=?,short_description=?,full_description=?,official_url=?,download_page_url=?,windows_download_url=?,macos_download_url=?,linux_download_url=?,installation_instructions=?,compatibility_info=?,system_requirements=?,pricing=?,version=?,is_featured=?,status=?,source_verified_at=?,updated_at=? WHERE id=?')->execute([$category,$name,$slug,$logo,$short,$full,$official,$download,$win,$mac,$linux,$install,$compat,$req,$pricing,$version,$featured,$status,($_POST['source_verified']??'')==='1'?date('Y-m-d'):null,$now,$id]);if($logo!==($existing['logo_path']??null))resources_delete_disk($existing['logo_path']??null);}
            else{$pdo->prepare('INSERT INTO tools(category_id,name,slug,logo_path,short_description,full_description,official_url,download_page_url,windows_download_url,macos_download_url,linux_download_url,installation_instructions,compatibility_info,system_requirements,pricing,version,is_featured,status,source_verified_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$category,$name,$slug,$logo,$short,$full,$official,$download,$win,$mac,$linux,$install,$compat,$req,$pricing,$version,$featured,$status,($_POST['source_verified']??'')==='1'?date('Y-m-d'):null,$now,$now]);$id=(int)$pdo->lastInsertId();}
            admin_audit($id>0?'resource_tool_saved':'resource_tool_created','tool',(string)$id,['slug'=>$slug,'status'=>$status]);return resource_admin_notice('Tool saved.');
        }
        if($action==='resource_delete_tool'){
            $id=(int)($_POST['id']??0);$s=$pdo->prepare('SELECT logo_path,name FROM tools WHERE id=?');$s->execute([$id]);$r=$s->fetch();if(!$r)throw new InvalidArgumentException('Tool record not found.');
            $pdo->prepare("DELETE FROM tutorial_relations WHERE related_type='tool' AND related_id=?")->execute([$id]);$pdo->prepare('DELETE FROM tools WHERE id=?')->execute([$id]);resources_delete_disk($r['logo_path']);admin_audit('resource_tool_deleted','tool',(string)$id,['name'=>$r['name']]);return resource_admin_notice('Tool deleted.');
        }
        if($action==='resource_save_tutorial'){
            $id=(int)($_POST['id']??0);$title=trim((string)($_POST['title']??''));$slugInput=trim((string)($_POST['slug']??''));$slug=resources_slug($slugInput!==''?$slugInput:$title);if(strlen($slug)>180)throw new InvalidArgumentException('Tutorial URL slug must be 180 characters or fewer.');
            if($title===''||strlen($title)>180)throw new InvalidArgumentException('Tutorial title is required and must be 180 characters or fewer.');
            $short=trim((string)($_POST['short_description']??''));$content=trim((string)($_POST['content_markdown']??''));
            if(strlen($short)>500||strlen($content)>40000)throw new InvalidArgumentException('Tutorial description or content is too long.');
            $category=resource_admin_validate_category('tutorial',(int)($_POST['category_id']??0));
            $videoUrls=[];foreach(preg_split('/\r\n|\r|\n/',(string)($_POST['video_urls']??''))?:[] as $candidate){$candidate=trim($candidate);if($candidate==='')continue;$videoUrls[]=resources_safe_url($candidate,false);if(count($videoUrls)>20)throw new InvalidArgumentException('A tutorial can include at most 20 external video links.');}
            $minutes=max(1,min(180,(int)($_POST['reading_minutes']??5)));$difficulty=(string)($_POST['difficulty']??'beginner');if(!in_array($difficulty,['beginner','intermediate','advanced'],true))$difficulty='beginner';
            $status=(string)($_POST['status']??'draft');if(!in_array($status,['draft','published'],true))$status='draft';$featured=isset($_POST['is_featured'])?1:0;
            $existing=null;if($id>0){$q=$pdo->prepare('SELECT thumbnail_path FROM tutorials WHERE id=?');$q->execute([$id]);$existing=$q->fetch();if(!$existing)throw new InvalidArgumentException('Tutorial record not found.');}
            $thumb=resources_upload_image($_FILES['thumbnail']??[],'tutorial-thumb');if($thumb==='')$thumb=$existing['thumbnail_path']??null;
            $dupe=$pdo->prepare('SELECT id FROM tutorials WHERE slug=? AND id<>? LIMIT 1');$dupe->execute([$slug,$id]);if($dupe->fetchColumn())throw new InvalidArgumentException('That tutorial URL slug is already in use.');
            if($id>0){$pdo->prepare('UPDATE tutorials SET category_id=?,title=?,slug=?,thumbnail_path=?,short_description=?,content_markdown=?,reading_minutes=?,difficulty=?,is_featured=?,status=?,last_updated_at=?,updated_at=? WHERE id=?')->execute([$category,$title,$slug,$thumb,$short,$content,$minutes,$difficulty,$featured,$status,$now,$now,$id]);if($thumb!==($existing['thumbnail_path']??null))resources_delete_disk($existing['thumbnail_path']??null);}
            else{$pdo->prepare('INSERT INTO tutorials(category_id,title,slug,thumbnail_path,short_description,content_markdown,reading_minutes,difficulty,is_featured,status,last_updated_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([$category,$title,$slug,$thumb,$short,$content,$minutes,$difficulty,$featured,$status,$now,$now,$now]);$id=(int)$pdo->lastInsertId();}
            $pdo->prepare('DELETE FROM tutorial_steps WHERE tutorial_id=?')->execute([$id]);$stepStmt=$pdo->prepare('INSERT INTO tutorial_steps(tutorial_id,step_order,title,body,created_at,updated_at) VALUES(?,?,?,?,?,?)');
            foreach(resource_admin_parse_steps((string)($_POST['steps']??'')) as $idx=>$step)$stepStmt->execute([$id,$idx+1,$step['title'],$step['body'],$now,$now]);
            // Replace the related-resource set with IDs verified against the proper tables.
            // External video references are edited as a complete set in the form.
            // Keep uploaded image/GIF media, but replace old video rows to avoid duplicates.
            $pdo->prepare("DELETE FROM tutorial_media WHERE tutorial_id=? AND media_kind='video'")->execute([$id]);
            $pdo->prepare('DELETE FROM tutorial_relations WHERE tutorial_id=?')->execute([$id]);
            $relatedTools=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['related_tools']??[])),static fn($v)=>$v>0)));
            $relatedTutorials=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['related_tutorials']??[])),static fn($v)=>$v>0&&$v!==$id)));
            $relationInsert=$pdo->prepare('INSERT INTO tutorial_relations(tutorial_id,related_type,related_id,sort_order,created_at) VALUES(?,?,?,?,?)');
            $lookup=$pdo->prepare('SELECT id FROM tools WHERE id=?');$order=1;foreach($relatedTools as $rid){$lookup->execute([$rid]);if($lookup->fetchColumn())$relationInsert->execute([$id,'tool',$rid,$order++,$now]);}
            $lookup=$pdo->prepare('SELECT id FROM tutorials WHERE id=?');foreach($relatedTutorials as $rid){$lookup->execute([$rid]);if($lookup->fetchColumn())$relationInsert->execute([$id,'tutorial',$rid,$order++,$now]);}
            $mediaFiles=$_FILES['media_files']??null;
            if(is_array($mediaFiles)&&isset($mediaFiles['name'])&&is_array($mediaFiles['name'])){
                $count=min(count($mediaFiles['name']),8);
                for($i=0;$i<$count;$i++){
                    $file=['name'=>$mediaFiles['name'][$i]??'','type'=>$mediaFiles['type'][$i]??'','tmp_name'=>$mediaFiles['tmp_name'][$i]??'','error'=>$mediaFiles['error'][$i]??UPLOAD_ERR_NO_FILE,'size'=>$mediaFiles['size'][$i]??0];
                    if(($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)continue;
                    $disk=resources_upload_image($file,'tutorial-media');$mime=(new finfo(FILEINFO_MIME_TYPE))->file(APP_ROOT.'/storage/resources/'.$disk)?:'image/jpeg';
                    $pdo->prepare('INSERT INTO tutorial_media(tutorial_id,media_kind,disk_path,external_url,mime_type,alt_text,caption,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$id,$mime==='image/gif'?'gif':'image',$disk,null,$mime,substr(trim((string)($_POST['media_alt']??'')),0,255),substr(trim((string)($_POST['media_caption']??'')),0,500),100+$i,$now]);
                }
            }
            $order=200;
            foreach($videoUrls as $url){$pdo->prepare('INSERT INTO tutorial_media(tutorial_id,media_kind,disk_path,external_url,mime_type,alt_text,caption,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$id,'video',null,$url,'text/uri-list','', 'External video reference',$order++,$now]);}
            admin_audit('resource_tutorial_saved','tutorial',(string)$id,['slug'=>$slug,'status'=>$status]);return resource_admin_notice('Tutorial saved. Uploaded media was added to its media gallery.');
        }
        if($action==='resource_delete_tutorial'){
            $id=(int)($_POST['id']??0);$s=$pdo->prepare('SELECT title,thumbnail_path FROM tutorials WHERE id=?');$s->execute([$id]);$r=$s->fetch();if(!$r)throw new InvalidArgumentException('Tutorial record not found.');
            $m=$pdo->prepare('SELECT disk_path FROM tutorial_media WHERE tutorial_id=?');$m->execute([$id]);foreach($m->fetchAll(PDO::FETCH_COLUMN) as $disk)resources_delete_disk($disk);
            $pdo->prepare("DELETE FROM tutorial_relations WHERE related_type='tutorial' AND related_id=?")->execute([$id]);$pdo->prepare('DELETE FROM tutorials WHERE id=?')->execute([$id]);resources_delete_disk($r['thumbnail_path']);admin_audit('resource_tutorial_deleted','tutorial',(string)$id,['title'=>$r['title']]);return resource_admin_notice('Tutorial and its attached records were deleted.');
        }
        if($action==='resource_remove_media'){
            $id=(int)($_POST['media_id']??0);$q=$pdo->prepare('SELECT m.disk_path,m.tutorial_id FROM tutorial_media m WHERE m.id=?');$q->execute([$id]);$r=$q->fetch();if(!$r)throw new InvalidArgumentException('Tutorial media not found.');
            $pdo->prepare('DELETE FROM tutorial_media WHERE id=?')->execute([$id]);resources_delete_disk($r['disk_path']);admin_audit('resource_media_deleted','tutorial',(string)$r['tutorial_id'],['media_id'=>$id]);return resource_admin_notice('Tutorial media removed.');
        }
        if($action==='resource_bulk_action'){
            $kind=(string)($_POST['resource_kind']??'tool');
            $operation=(string)($_POST['bulk_operation']??'');
            if(!in_array($kind,['tool','tutorial'],true))throw new InvalidArgumentException('Invalid resource type.');
            if(!in_array($operation,['publish','draft','delete'],true))throw new InvalidArgumentException('Choose a valid bulk operation.');
            $ids=array_values(array_unique(array_filter(array_map('intval',(array)($_POST['resource_ids']??[])),static fn($v)=>$v>0)));
            if(!$ids)throw new InvalidArgumentException('Select at least one resource.');
            if(count($ids)>100)throw new InvalidArgumentException('Select no more than 100 records per bulk operation.');
            $table=$kind==='tool'?'tools':'tutorials';$idColumn='id';$done=0;
            foreach($ids as $rid){
                $q=$pdo->prepare("SELECT * FROM {$table} WHERE {$idColumn}=?");$q->execute([$rid]);$record=$q->fetch();if(!$record)continue;
                if($operation==='publish'||$operation==='draft'){
                    $pdo->prepare("UPDATE {$table} SET status=?,updated_at=? WHERE id=?")->execute([$operation==='publish'?'published':'draft',$now,$rid]);
                }else{
                    if($kind==='tool'){
                        $pdo->prepare("DELETE FROM tutorial_relations WHERE related_type='tool' AND related_id=?")->execute([$rid]);$pdo->prepare('DELETE FROM tools WHERE id=?')->execute([$rid]);resources_delete_disk($record['logo_path']??null);
                    }else{
                        $m=$pdo->prepare('SELECT disk_path FROM tutorial_media WHERE tutorial_id=?');$m->execute([$rid]);foreach($m->fetchAll(PDO::FETCH_COLUMN) as $disk)resources_delete_disk($disk);
                        $pdo->prepare("DELETE FROM tutorial_relations WHERE related_type='tutorial' AND related_id=?")->execute([$rid]);$pdo->prepare('DELETE FROM tutorials WHERE id=?')->execute([$rid]);resources_delete_disk($record['thumbnail_path']??null);
                    }
                }
                admin_audit('resource_bulk_'.$operation,$kind,(string)$rid,['name'=>$record[$kind==='tool'?'name':'title']??'']);$done++;
            }
            return resource_admin_notice($done.' '.($kind==='tool'?'tool':'tutorial').' record(s) '.($operation==='delete'?'deleted':($operation==='publish'?'published':'moved to drafts')).'.');
        }
        if($action==='resource_save_category'){
            $kind=(string)($_POST['category_kind']??'tool');if(!in_array($kind,['tool','tutorial'],true))throw new InvalidArgumentException('Invalid category type.');$table=$kind==='tool'?'tool_categories':'tutorial_categories';
            $id=(int)($_POST['id']??0);$name=trim((string)($_POST['name']??''));$slugInput=trim((string)($_POST['slug']??''));$slug=resources_slug($slugInput!==''?$slugInput:$name);if(strlen($slug)>160)throw new InvalidArgumentException('Category URL slug must be 160 characters or fewer.');$desc=trim((string)($_POST['description']??''));$order=max(0,min(9999,(int)($_POST['sort_order']??100)));
            if($name===''||strlen($name)>120||strlen($desc)>500)throw new InvalidArgumentException('Category name or description is invalid.');$active=isset($_POST['is_active'])?1:0;
            $q=$pdo->prepare("SELECT id FROM {$table} WHERE slug=? AND id<>? LIMIT 1");$q->execute([$slug,$id]);if($q->fetchColumn())throw new InvalidArgumentException('That category slug is already in use.');
            if($id>0){$q=$pdo->prepare("UPDATE {$table} SET name=?,slug=?,description=?,sort_order=?,is_active=?,updated_at=? WHERE id=?");$q->execute([$name,$slug,$desc,$order,$active,$now,$id]);if(!$q->rowCount()){$check=$pdo->prepare("SELECT id FROM {$table} WHERE id=?");$check->execute([$id]);if(!$check->fetchColumn())throw new InvalidArgumentException('Category not found.');}}
            else{$pdo->prepare("INSERT INTO {$table}(name,slug,description,sort_order,is_active,created_at,updated_at) VALUES(?,?,?,?,?,?,?)")->execute([$name,$slug,$desc,$order,$active,$now,$now]);$id=(int)$pdo->lastInsertId();}
            admin_audit('resource_category_saved',$kind.'_category',(string)$id,['slug'=>$slug,'active'=>$active]);return resource_admin_notice('Category saved.');
        }
        if($action==='resource_delete_category'){
            $kind=(string)($_POST['category_kind']??'tool');if(!in_array($kind,['tool','tutorial'],true))throw new InvalidArgumentException('Invalid category type.');
            $table=$kind==='tool'?'tool_categories':'tutorial_categories';$content=$kind==='tool'?'tools':'tutorials';$id=(int)($_POST['id']??0);
            $q=$pdo->prepare("SELECT id,name FROM {$table} WHERE id=?");$q->execute([$id]);$cat=$q->fetch();if(!$cat)throw new InvalidArgumentException('Category not found.');
            $q=$pdo->prepare("SELECT COUNT(*) FROM {$content} WHERE category_id=?");$q->execute([$id]);if((int)$q->fetchColumn()>0)throw new InvalidArgumentException('This category is still assigned to resources. Reassign those records before deleting it.');
            $pdo->prepare("DELETE FROM {$table} WHERE id=?")->execute([$id]);admin_audit('resource_category_deleted',$kind.'_category',(string)$id,['name'=>$cat['name']]);return resource_admin_notice('Unused category deleted.');
        }
        if($action==='resource_disable_category'){
            $kind=(string)($_POST['category_kind']??'tool');if(!in_array($kind,['tool','tutorial'],true))throw new InvalidArgumentException('Invalid category type.');$table=$kind==='tool'?'tool_categories':'tutorial_categories';$id=(int)($_POST['id']??0);
            $pdo->prepare("UPDATE {$table} SET is_active=0,updated_at=? WHERE id=?")->execute([$now,$id]);admin_audit('resource_category_disabled',$kind.'_category',(string)$id);return resource_admin_notice('Category disabled. Existing records were preserved.');
        }
        return resource_admin_notice('Unknown resource-management action.','error');
    } catch(Throwable $e) {
        error_log('Resource administration failure: '.get_class($e).' '.$e->getMessage());
        return resource_admin_notice($e instanceof InvalidArgumentException?$e->getMessage():'The resource operation failed. Review the fields and try again.','error');
    }
}
