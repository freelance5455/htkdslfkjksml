import {
  mysqlTable,
  mysqlEnum,
  serial,
  bigint,
  varchar,
  text,
  date,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable(
  "users",
  {
    id: serial("id").primaryKey(),
    username: varchar("username", { length: 64 }).notNull(),
    passwordHash: varchar("password_hash", { length: 255 }).notNull(),
    displayName: varchar("display_name", { length: 100 }).notNull(),
    role: mysqlEnum("role", ["admin", "member"]).notNull().default("member"),
    status: mysqlEnum("status", ["active", "inactive"]).notNull().default("active"),
    startDate: date("start_date", { mode: "string" }).notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("username_idx").on(t.username)],
);

export const sessions = mysqlTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    token: varchar("token", { length: 128 }).notNull(),
    userId: bigint("user_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    expiresAt: timestamp("expires_at").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("token_idx").on(t.token)],
);

export const relapses = mysqlTable(
  "relapses",
  {
    id: serial("id").primaryKey(),
    userId: bigint("user_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    date: date("date", { mode: "string" }).notNull(),
    note: text("note"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("relapse_user_date_idx").on(t.userId, t.date)],
);

export const checkins = mysqlTable(
  "checkins",
  {
    id: serial("id").primaryKey(),
    userId: bigint("user_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    date: date("date", { mode: "string" }).notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("checkin_user_date_idx").on(t.userId, t.date)],
);

export const habits = mysqlTable(
  "habits",
  {
    id: serial("id").primaryKey(),
    userId: bigint("user_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    name: varchar("name", { length: 120 }).notNull(),
    description: varchar("description", { length: 255 }),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("habit_user_name_idx").on(t.userId, t.name)],
);

export const habitLogs = mysqlTable(
  "habit_logs",
  {
    id: serial("id").primaryKey(),
    habitId: bigint("habit_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => habits.id),
    userId: bigint("user_id", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    date: date("date", { mode: "string" }).notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("habit_log_idx").on(t.habitId, t.date)],
);

export type User = typeof users.$inferSelect;
export type Relapse = typeof relapses.$inferSelect;
export type Habit = typeof habits.$inferSelect;
