import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  int,
  bigint,
  boolean,
  date,
  timestamp,
  unique,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ---------------------------------------------------------------------------
// Household finance tables
// ---------------------------------------------------------------------------

export const categories = mysqlTable("categories", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  name: varchar("name", { length: 100 }).notNull(),
  kind: mysqlEnum("kind", ["expense", "income"]).notNull(),
  icon: varchar("icon", { length: 50 }).notNull().default("tag"),
  color: varchar("color", { length: 20 }).notNull().default("#de5126"),
  isDefault: boolean("isDefault").notNull().default(false),
  sortOrder: int("sortOrder").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Category = typeof categories.$inferSelect;

export const transactions = mysqlTable("transactions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  categoryId: bigint("categoryId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => categories.id),
  // Amount stored in minor currency units (halalas / piasters / fils) to avoid floats.
  amount: int("amount").notNull(),
  note: varchar("note", { length: 255 }),
  txDate: date("txDate", { mode: "string" }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Transaction = typeof transactions.$inferSelect;

export const budgets = mysqlTable(
  "budgets",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => users.id),
    categoryId: bigint("categoryId", { mode: "number", unsigned: true })
      .notNull()
      .references(() => categories.id),
    // "YYYY-MM"
    monthKey: varchar("monthKey", { length: 7 }).notNull(),
    amount: int("amount").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => [unique("uq_budget_cat_month").on(t.userId, t.categoryId, t.monthKey)],
);

export type Budget = typeof budgets.$inferSelect;

export const settings = mysqlTable("settings", {
  userId: bigint("userId", { mode: "number", unsigned: true })
    .primaryKey()
    .references(() => users.id),
  currency: varchar("currency", { length: 10 }).notNull().default("SAR"),
  familyName: varchar("familyName", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Settings = typeof settings.$inferSelect;
