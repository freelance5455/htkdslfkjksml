// آدرس فعلی Runflare برای تست؛ پیش از انتشار عمومی حتماً با دامنه HTTPS واقعی جایگزین شود.
window.AZARAKHSH_API_BASE = 'http://remote-fanhab.runflare.com:31177';
