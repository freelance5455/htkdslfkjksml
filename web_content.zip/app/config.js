// تنظیم آدرس پیش‌فرض API؛ می‌توان آن را در رابط ورود نیز تغییر داد.
window.AZARAKHSH_API_BASE = 'https://remote-fanhab.runflare.com:30791';
