// تنظیم آدرس پیش‌فرض API؛ می‌توان آن را در رابط ورود نیز تغییر داد.
window.AZARAKHSH_API_BASE = 'http://remote-fanhab.runflare.com:31177';
