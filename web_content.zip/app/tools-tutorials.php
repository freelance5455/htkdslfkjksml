<?php
declare(strict_types=1);

/**
 * Shared Tools & Tutorials route bootstrap.
 *
 * The public entry point (tools-tutorials.php) includes this file before it
 * authenticates the visitor and renders the database-backed catalogue. Keep
 * the route bootstrap separate from presentation so existing resource
 * services, authentication and the admin resource handler remain authoritative.
 */
require_once __DIR__ . '/resources.php';
require_once __DIR__ . '/auth.php';
