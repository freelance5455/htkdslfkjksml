# Créditos e licenças

- **Phaser 3** (motor do jogo) — licença MIT. Copyright © Richard Davey, Photon Storm Ltd.
- **Ícone do app** (`public/icon-512.png` e derivados) — imagem gerada por IA (Kimi image
  generation) para este projeto; uso livre dentro do projeto.
- **Som e música** — sintetizados em runtime via Web Audio API (sem arquivos de terceiros).
- **Arte** — desenhada proceduralmente em canvas; portada do protótipo original
  "Crônicas do Cristal" (Godot 4), projeto do próprio autor.
