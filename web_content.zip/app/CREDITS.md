# Credits

- Prayer and Qibla calculations: Adhan JS by Batoul Apps, MIT license.
- Azan audio: “Beautiful adhan” by Adam-synagda, Wikimedia Commons, CC0 1.0 public-domain dedication. Loaded from upload.wikimedia.org/wikipedia/commons/b/b0/Beautiful_adhan.ogg.
- Interface icons: Lucide, ISC license.
- Typefaces: DM Sans and Lora, served by Google Fonts under the SIL Open Font License.
