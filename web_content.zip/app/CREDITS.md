# Credits

- **Car base model:** “Cyan five-door compact hatchback,” Kimi design asset `05-V1-0002`. Reused through the design-asset library and adapted into merged vertex-colored mobile geometry with shared resources.
- **Renderer:** Three.js, MIT license. The supplied license text is retained at `public/car/THREE-LICENSE.txt`.
- **World, routes, physics, interface, weather, and synthesized audio:** created procedurally for this project.
- No external vehicle brands, music recordings, or Forza assets are included.
