#!/bin/sh
cd "$(dirname "$0")"
if command -v xdg-open >/dev/null 2>&1; then xdg-open index.html; else open index.html; fi
