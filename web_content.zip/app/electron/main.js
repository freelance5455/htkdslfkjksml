const { app, BrowserWindow } = require('electron');
const path = require('path');

function buatJendela() {
  const win = new BrowserWindow({
    width: 480,
    height: 860,
    minWidth: 360,
    title: 'Tiket Bioskop',
    autoHideMenuBar: true
  });
  win.loadFile(path.join(__dirname, 'index.html'));
}

app.whenReady().then(buatJendela);
app.on('window-all-closed', () => app.quit());
