# CPLS V2 — Stage 1146

## Cadence Confidence Stabilization
- Cadence confidence now carries sample-count and timing details alongside the score.
- Confidence labels expose a compact percentage for healthy recent sampling.
- Unknown/insufficient cadence remains explicitly unknown instead of being treated as healthy.
- No synthetic prices or candles are generated.
- Previous gap, freshness, sample-count, candle-integrity and live-continuity protections are preserved.

Source ZIP stage only; APK build not performed.
