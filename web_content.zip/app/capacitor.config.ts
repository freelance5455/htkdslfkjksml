import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.chaosarena.game',
  appName: 'ساحة الفوضى',
  webDir: 'dist',
  bundledWebRuntime: false,
};

export default config;
