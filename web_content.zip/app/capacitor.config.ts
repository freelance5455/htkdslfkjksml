import type {CapacitorConfig} from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'pt.pontovivo.app', // se mudares, muda também no Firebase (google-services.json)
  appName: 'PontoVivo',
  webDir: 'dist',
  server: {androidScheme: 'https'},
  plugins: {
    FirebaseAuthentication: {
      skipNativeAuth: true,
      providers: ['google.com'],
    },
  },
};

export default config;
