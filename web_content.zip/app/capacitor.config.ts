import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.apexfestival.game',
  appName: 'Apex Festival',
  webDir: 'dist',
  backgroundColor: '#0b0e12',
  android: {
    allowMixedContent: false,
    captureInput: true,
  },
};

export default config;
