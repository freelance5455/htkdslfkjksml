import express from 'express';
import fs from 'fs';
import path from 'path';
import {fileURLToPath} from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface WeatherPayload {
  temperatureC: number;
  feelsLikeC: number;
  humidity: number;
  windKmh: number;
  precipProb: number;
  condition: string;
  conditionCode:
    | 'clear'
    | 'partly_cloudy'
    | 'cloudy'
    | 'fog'
    | 'rain'
    | 'storm'
    | 'snow';
  isDaytime: boolean;
  uvIndex?: number;
  iconUri?: string;
  source: 'google' | 'open-meteo';
}

interface CacheEntry {
  data: WeatherPayload;
  expiresAt: number;
}

const WEATHER_CACHE = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 5 * 60 * 1000;

function mapGoogleWeatherType(
  rawType?: string
): WeatherPayload['conditionCode'] {
  const t = (rawType || '').toUpperCase();
  if (t.includes('THUNDER') || t.includes('STORM')) return 'storm';
  if (t.includes('SNOW') || t.includes('SLEET') || t.includes('HAIL')) {
    return 'snow';
  }
  if (t.includes('RAIN') || t.includes('SHOWER') || t.includes('DRIZZLE')) {
    return 'rain';
  }
  if (t.includes('FOG') || t.includes('MIST') || t.includes('HAZE')) {
    return 'fog';
  }
  if (t.includes('PARTLY') || t.includes('MOSTLY_CLEAR') || t.includes('FEW')) {
    return 'partly_cloudy';
  }
  if (t.includes('CLOUD') || t.includes('OVERCAST')) return 'cloudy';
  return 'clear';
}

function mapWmoCodeToPt(code: number): {
  label: string;
  conditionCode: WeatherPayload['conditionCode'];
} {
  if (code === 0) return {label: 'Céu limpo', conditionCode: 'clear'};
  if (code === 1 || code === 2) {
    return {label: 'Parcialmente nublado', conditionCode: 'partly_cloudy'};
  }
  if (code === 3) return {label: 'Nublado', conditionCode: 'cloudy'};
  if (code === 45 || code === 48) {
    return {label: 'Nevoeiro', conditionCode: 'fog'};
  }
  if (code >= 51 && code <= 57) {
    return {label: 'Chuvisco', conditionCode: 'rain'};
  }
  if ((code >= 61 && code <= 67) || (code >= 80 && code <= 82)) {
    return {label: 'Chuva', conditionCode: 'rain'};
  }
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) {
    return {label: 'Neve', conditionCode: 'snow'};
  }
  if (code >= 95 && code <= 99) {
    return {label: 'Tempestade', conditionCode: 'storm'};
  }
  return {label: 'Tempo variável', conditionCode: 'partly_cloudy'};
}

async function fetchGoogleWeather(
  lat: number,
  lng: number,
  apiKey: string
): Promise<WeatherPayload | null> {
  const url = new URL(
    'https://weather.googleapis.com/v1/currentConditions:lookup'
  );
  url.searchParams.set('key', apiKey);
  url.searchParams.set('location.latitude', String(lat));
  url.searchParams.set('location.longitude', String(lng));
  url.searchParams.set('unitsSystem', 'METRIC');
  url.searchParams.set('languageCode', 'pt-BR');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3500);
  try {
    const res = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        'X-Goog-Maps-Solution-ID': 'gmp_mcp_codeassist_v1_aistudio',
      },
      signal: controller.signal,
    });
    if (!res.ok) return null;
    const json = (await res.json()) as {
      isDaytime?: boolean;
      weatherCondition?: {
        type?: string;
        iconBaseUri?: string;
        description?: {text?: string};
      };
      temperature?: {degrees?: number};
      feelsLikeTemperature?: {degrees?: number};
      relativeHumidity?: number;
      uvIndex?: number;
      precipitation?: {probability?: {percent?: number}};
      wind?: {speed?: {value?: number}};
    };

    if (typeof json.temperature?.degrees !== 'number') return null;

    return {
      temperatureC: Math.round(json.temperature.degrees * 10) / 10,
      feelsLikeC:
        Math.round(
          (json.feelsLikeTemperature?.degrees ?? json.temperature.degrees) * 10
        ) / 10,
      humidity: Math.round(json.relativeHumidity ?? 0),
      windKmh: Math.round(json.wind?.speed?.value ?? 0),
      precipProb: Math.round(json.precipitation?.probability?.percent ?? 0),
      condition: json.weatherCondition?.description?.text || 'Tempo atual',
      conditionCode: mapGoogleWeatherType(json.weatherCondition?.type),
      isDaytime: json.isDaytime ?? true,
      uvIndex:
        typeof json.uvIndex === 'number' ? Math.round(json.uvIndex) : undefined,
      iconUri: json.weatherCondition?.iconBaseUri
        ? `${json.weatherCondition.iconBaseUri}.svg`
        : undefined,
      source: 'google',
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function fetchOpenMeteoWeather(
  lat: number,
  lng: number
): Promise<WeatherPayload | null> {
  const url = new URL('https://api.open-meteo.com/v1/forecast');
  url.searchParams.set('latitude', String(lat));
  url.searchParams.set('longitude', String(lng));
  url.searchParams.set(
    'current',
    'temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,is_day'
  );
  url.searchParams.set('hourly', 'precipitation_probability');
  url.searchParams.set('forecast_days', '1');
  url.searchParams.set('timezone', 'auto');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const res = await fetch(url.toString(), {signal: controller.signal});
    if (!res.ok) return null;
    const json = (await res.json()) as {
      current?: {
        temperature_2m?: number;
        apparent_temperature?: number;
        relative_humidity_2m?: number;
        wind_speed_10m?: number;
        weather_code?: number;
        is_day?: number;
        precipitation?: number;
      };
      hourly?: {
        precipitation_probability?: number[];
      };
    };

    const cur = json.current;
    if (!cur || typeof cur.temperature_2m !== 'number') return null;
    const wmo = mapWmoCodeToPt(cur.weather_code ?? 0);
    const precipProb =
      json.hourly?.precipitation_probability?.[0] ??
      ((cur.precipitation ?? 0) > 0 ? 80 : 0);

    return {
      temperatureC: Math.round(cur.temperature_2m * 10) / 10,
      feelsLikeC:
        Math.round((cur.apparent_temperature ?? cur.temperature_2m) * 10) / 10,
      humidity: Math.round(cur.relative_humidity_2m ?? 0),
      windKmh: Math.round(cur.wind_speed_10m ?? 0),
      precipProb: Math.round(precipProb),
      condition: wmo.label,
      conditionCode: wmo.conditionCode,
      isDaytime: (cur.is_day ?? 1) === 1,
      source: 'open-meteo',
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

async function startServer() {
  const app = express();
  const port = Number(process.env.PORT) || 3000;

  app.get('/api/weather', async (req, res) => {
    const lat = Number(req.query.lat);
    const lng = Number(req.query.lng);
    if (
      !Number.isFinite(lat) ||
      !Number.isFinite(lng) ||
      lat < -90 ||
      lat > 90 ||
      lng < -180 ||
      lng > 180
    ) {
      res.status(400).json({error: 'Coordenadas inválidas'});
      return;
    }

    const key = `${lat.toFixed(2)},${lng.toFixed(2)}`;
    const cached = WEATHER_CACHE.get(key);
    if (cached && cached.expiresAt > Date.now()) {
      res.json(cached.data);
      return;
    }

    const mapsKey =
      process.env.GOOGLE_MAPS_API_KEY ||
      process.env.VITE_GOOGLE_MAPS_API_KEY ||
      '';

    let weather: WeatherPayload | null = null;
    if (mapsKey) {
      weather = await fetchGoogleWeather(lat, lng, mapsKey);
    }
    if (!weather) {
      weather = await fetchOpenMeteoWeather(lat, lng);
    }

    if (!weather) {
      res.status(502).json({error: 'Clima indisponível no momento'});
      return;
    }

    if (WEATHER_CACHE.size >= 200) {
      const oldest = WEATHER_CACHE.keys().next().value;
      if (oldest) WEATHER_CACHE.delete(oldest);
    }
    WEATHER_CACHE.set(key, {
      data: weather,
      expiresAt: Date.now() + CACHE_TTL_MS,
    });
    res.json(weather);
  });

  const isProd = process.env.NODE_ENV === 'production';
  const distDir = path.resolve(__dirname, 'dist');

  if (!isProd || !fs.existsSync(distDir)) {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`PontoVivo server running on http://0.0.0.0:${port}`);
  });
}

void startServer();
