<?php
declare(strict_types=1);

const APP_ROOT = __DIR__ . '/..';
const DEFAULT_MODELS = ['lucy-2.5', 'lucy-2.6'];

/** Return the application base path even when a workspace runs from its own folder. */
function app_base_path(): string
{
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '/'));
    $dir = str_replace('\\', '/', dirname($script));
    $workspaceFolders = ['image', 'video', 'realtime', 'lip-sync', 'voice', 'agents'];
    if (in_array(basename($dir), $workspaceFolders, true)) {
        $dir = dirname($dir);
    }
    if ($dir === '.' || $dir === DIRECTORY_SEPARATOR) $dir = '/';
    $dir = '/' . trim(str_replace('\\', '/', $dir), '/');
    return $dir === '/' ? '/' : $dir . '/';
}

/** Redirect the old flat workspace URL to its folder route unless included by that route. */
function workspace_legacy_redirect(string $route): void
{
    if (defined('ANONYMOUX_WORKSPACE_INCLUDE') && ANONYMOUX_WORKSPACE_INCLUDE === true) return;
    $route = trim($route, '/');
    if ($route === '') return;
    $location = app_base_path() . $route;
    if (!str_contains(basename($route), '.')) $location .= '/';
    $query = (string)($_SERVER['QUERY_STRING'] ?? '');
    if ($query !== '') $location .= '?' . $query;
    header('Location: ' . $location, true, 301);
    exit;
}

function app_config(): array
{
    static $config = null;
    if ($config !== null) return $config;

    $local = APP_ROOT . '/config.local.php';
    $fileConfig = is_file($local) ? require $local : [];
    if (!is_array($fileConfig)) $fileConfig = [];

    $config = array_merge([
        'decart_api_key' => getenv('DECART_API_KEY') ?: '',
        'magichour_api_key' => getenv('MAGIC_HOUR_API_KEY') ?: '',
        'fish_audio_api_key' => getenv('FISH_AUDIO_API_KEY') ?: '',
        // Agent LLM usage is charged only when the operator explicitly sets a credit/USD rate.
        'agent_credits_per_usd' => (float)(getenv('ANONYMOUX_AGENT_CREDITS_PER_USD') ?: 0),
        'max_audio_bytes' => 30 * 1024 * 1024,
        'admin_api_encryption_key' => getenv('ANONYMOUX_KEY_ENCRYPTION_SECRET') ?: '',
        'decart_api_base' => 'https://api.decart.ai/v1',
        'realtime_transport' => 'http-signaling',
        'max_reference_bytes' => 5 * 1024 * 1024,
        'max_prompt_length' => 2000,
        'max_image_bytes' => 15 * 1024 * 1024,
        'max_video_bytes' => 100 * 1024 * 1024,
        'max_storage_per_user_bytes' => 1073741824,
        'video_job_timeout_seconds' => 7200,
        'force_https' => true,
    ], $fileConfig);

    if (getenv('DECART_API_KEY')) $config['decart_api_key'] = getenv('DECART_API_KEY');
    if (getenv('FISH_AUDIO_API_KEY')) $config['fish_audio_api_key'] = getenv('FISH_AUDIO_API_KEY');
    if (getenv('ANONYMOUX_AGENT_CREDITS_PER_USD') !== false) $config['agent_credits_per_usd'] = max(0, (float)getenv('ANONYMOUX_AGENT_CREDITS_PER_USD'));
    if (getenv('ANONYMOUX_KEY_ENCRYPTION_SECRET')) $config['admin_api_encryption_key'] = getenv('ANONYMOUX_KEY_ENCRYPTION_SECRET');
    return $config;
}

function app_start_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    $isLocal = $host === 'localhost' || str_starts_with($host, 'localhost:') || $host === '127.0.0.1' || str_starts_with($host, '127.0.0.1:') || $host === '::1';
    $remote = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $trustedProxies = app_config()['trusted_proxy_ips'] ?? [];
    $trustForwarded = is_array($trustedProxies) && in_array($remote, $trustedProxies, true);
    $forwardedProto = $trustForwarded ? strtolower((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) : '';
    $isHttpsRequest = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443') || $forwardedProto === 'https';
    if (!$isLocal && !$isHttpsRequest && PHP_SAPI !== 'cli' && (app_config()['force_https'] ?? true)) {
        $canonical = trim((string)(app_config()['canonical_base_url'] ?? ''));
        $parts = $canonical !== '' ? parse_url($canonical) : false;
        if (is_array($parts) && strtolower((string)($parts['scheme'] ?? '')) === 'https' && !empty($parts['host'])) {
            $base = 'https://' . $parts['host'] . (isset($parts['port']) ? ':' . (int)$parts['port'] : '') . rtrim((string)($parts['path'] ?? ''), '/');
            $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
            if ($uri === '' || $uri[0] !== '/' || str_starts_with($uri, '//')) $uri = '/';
            header('Location: ' . $base . $uri, true, 308);
            exit;
        }
        http_response_code(400);
        exit('HTTPS is required. Configure canonical_base_url in private application configuration to enable a safe HTTPS redirect.');
    }
    $secure = $isHttpsRequest;
    // Session lifetime is bounded; ownership tokens are rotated at every auth boundary.
    @ini_set('session.gc_maxlifetime', '28800');
    @ini_set('session.use_trans_sid', '0');
    @ini_set('session.use_strict_mode', '1');
    @ini_set('session.use_only_cookies', '1');
    session_name('ANONYMOUX_REALTIME');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
    if (!headers_sent()) {
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('X-Frame-Options: SAMEORIGIN');
        header('Permissions-Policy: camera=(self), microphone=(self), geolocation=()');
        if ($secure) header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    if (empty($_SESSION['owner_token'])) $_SESSION['owner_token'] = bin2hex(random_bytes(32));
    if (!isset($_SESSION['remote_sessions']) || !is_array($_SESSION['remote_sessions'])) $_SESSION['remote_sessions'] = [];
}
app_start_session();

set_exception_handler(static function (Throwable $e): void {
    $missingSqlite = str_contains(strtolower($e->getMessage()), 'pdo sqlite extension');
    error_log('ANONYMOUX uncaught application error: ' . get_class($e) . ($missingSqlite ? ' (pdo_sqlite missing)' : ''));
    if (!headers_sent()) {
        http_response_code($missingSqlite ? 503 : 500);
        header('Cache-Control: no-store');
        $script = (string)($_SERVER['SCRIPT_NAME'] ?? '');
        if (str_contains($script, '/api/')) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok'=>false,'error'=>$missingSqlite
                ? 'This host must enable PHP PDO SQLite (pdo_sqlite) before ANONYMOUX STUDIOS can start.'
                : 'The application encountered an internal error. Check the protected server log.']);
        } else {
            header('Content-Type: text/html; charset=utf-8');
            $message = $missingSqlite
                ? 'ANONYMOUX STUDIOS requires the PHP PDO SQLite extension (pdo_sqlite). Enable it in your hosting PHP settings, then reload this page.'
                : 'ANONYMOUX STUDIOS could not complete this request. Check the protected server log or hosting configuration.';
            echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Application requirement</title><body style="margin:0;background:#111318;color:#FFFFFF;font:16px system-ui;padding:8vh 8vw"><h1 style="color:#A3FF12">ANONYMOUX STUDIOS</h1><p>'.htmlspecialchars($message,ENT_QUOTES,'UTF-8').'</p></body></html>';
        }
    }
    exit;
});

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    // This deployment uses SQLite exclusively. Do not allow an environment
    // variable or local config file to silently switch the app to another PDO driver.
    if (!extension_loaded('pdo_sqlite')) {
        $message='ANONYMOUX STUDIOS requires the PHP PDO SQLite extension (pdo_sqlite). Enable it in your hosting PHP settings, then reload the application.';
        if (PHP_SAPI === 'cli') throw new RuntimeException($message);
        if (!headers_sent()) {
            http_response_code(503);
            header('Cache-Control: no-store');
            $script=(string)($_SERVER['SCRIPT_NAME']??'');
            if (str_contains($script,'/api/')) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['ok'=>false,'error'=>$message]);
            } else {
                header('Content-Type: text/html; charset=utf-8');
                echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Database extension required</title><body style="margin:0;background:#111318;color:#FFFFFF;font:16px system-ui;padding:8vh 8vw"><h1 style="color:#A3FF12">ANONYMOUX STUDIOS</h1><p>'.htmlspecialchars($message,ENT_QUOTES,'UTF-8').'</p></body></html>';
            }
        }
        exit;
    }
    $storage = APP_ROOT . '/storage';
    if (is_link($storage)) throw new RuntimeException('Private storage directory must not be a symbolic link.');
    if (!is_dir($storage) && !mkdir($storage, 0750, true) && !is_dir($storage)) {
        throw new RuntimeException('Could not create the private storage directory. Check folder permissions.');
    }
    if (!is_writable($storage)) throw new RuntimeException('Private storage is not writable by PHP. Grant the storage directory write permission.');
    $dsn = 'sqlite:' . $storage . '/workspace.sqlite';

    $pdo = new PDO($dsn, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA busy_timeout = 5000');
    schema_init($pdo);
    seed_prompts($pdo);
    return $pdo;
}

function schema_init(PDO $pdo): void
{
    $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver === 'sqlite') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS prompt_library (
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            prompt TEXT NOT NULL, category TEXT NOT NULL, is_custom INTEGER NOT NULL DEFAULT 0,
            owner_key TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_prompts_owner ON prompt_library(owner_key, is_custom)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS workspace_preferences (
            owner_key TEXT NOT NULL, preference_key TEXT NOT NULL, preference_value TEXT NOT NULL,
            updated_at TEXT NOT NULL, PRIMARY KEY(owner_key, preference_key)
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS reference_uploads (
            id TEXT PRIMARY KEY, owner_key TEXT NOT NULL, disk_name TEXT NOT NULL, original_name TEXT NOT NULL,
            mime_type TEXT NOT NULL, file_size INTEGER NOT NULL, width INTEGER NOT NULL, height INTEGER NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
        )");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_references_owner ON reference_uploads(owner_key, is_active)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS realtime_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, remote_id TEXT NOT NULL UNIQUE, owner_key TEXT NOT NULL,
            model TEXT NOT NULL, prompt TEXT NOT NULL DEFAULT '', status TEXT NOT NULL,
            started_at TEXT NOT NULL, ended_at TEXT NULL, billed_seconds INTEGER NULL
        )");
    } elseif ($driver === 'mysql') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS prompt_library (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, title VARCHAR(180) NOT NULL,
            description VARCHAR(500) NOT NULL DEFAULT '', prompt TEXT NOT NULL, category VARCHAR(80) NOT NULL,
            is_custom TINYINT(1) NOT NULL DEFAULT 0, owner_key VARCHAR(64) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, KEY idx_prompts_owner(owner_key, is_custom)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS workspace_preferences (
            owner_key VARCHAR(64) NOT NULL, preference_key VARCHAR(100) NOT NULL,
            preference_value LONGTEXT NOT NULL, updated_at DATETIME NOT NULL,
            PRIMARY KEY(owner_key, preference_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS reference_uploads (
            id VARCHAR(40) NOT NULL PRIMARY KEY, owner_key VARCHAR(64) NOT NULL, disk_name VARCHAR(100) NOT NULL,
            original_name VARCHAR(255) NOT NULL, mime_type VARCHAR(100) NOT NULL, file_size BIGINT NOT NULL,
            width INT NOT NULL, height INT NOT NULL, is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL, KEY idx_references_owner(owner_key, is_active)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS realtime_sessions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, remote_id VARCHAR(100) NOT NULL UNIQUE,
            owner_key VARCHAR(64) NOT NULL, model VARCHAR(40) NOT NULL, prompt TEXT NOT NULL,
            status VARCHAR(30) NOT NULL, started_at DATETIME NOT NULL, ended_at DATETIME NULL,
            billed_seconds INT NULL, KEY idx_sessions_owner(owner_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } else {
        throw new RuntimeException('Unsupported database driver. This application requires SQLite PDO.');
    }
    if ($driver === 'sqlite') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_api_keys (id INTEGER PRIMARY KEY AUTOINCREMENT,label TEXT NOT NULL,encrypted_key TEXT NOT NULL,nonce TEXT NOT NULL,auth_tag TEXT NOT NULL,is_active INTEGER NOT NULL DEFAULT 1,priority INTEGER NOT NULL DEFAULT 100,last_used_at TEXT NULL,failure_count INTEGER NOT NULL DEFAULT 0,last_error TEXT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_audit_logs (id INTEGER PRIMARY KEY AUTOINCREMENT,actor_user_id INTEGER NULL,action TEXT NOT NULL,target_type TEXT NOT NULL DEFAULT '',target_id TEXT NOT NULL DEFAULT '',details TEXT NOT NULL DEFAULT '{}',ip_address TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS platform_settings (setting_key TEXT PRIMARY KEY,setting_value TEXT NOT NULL,updated_at TEXT NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS fish_audio_keys (id INTEGER PRIMARY KEY AUTOINCREMENT,label TEXT NOT NULL,encrypted_key TEXT NOT NULL,nonce TEXT NOT NULL,auth_tag TEXT NOT NULL,is_active INTEGER NOT NULL DEFAULT 1,priority INTEGER NOT NULL DEFAULT 100,last_used_at TEXT NULL,failure_count INTEGER NOT NULL DEFAULT 0,last_error TEXT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_usage (id INTEGER PRIMARY KEY AUTOINCREMENT,owner_key TEXT NOT NULL,user_id INTEGER NULL,characters INTEGER NOT NULL,model TEXT NOT NULL,status TEXT NOT NULL,error_code INTEGER NULL,created_at TEXT NOT NULL)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_voice_usage_owner ON voice_usage(owner_key,created_at)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_voice_usage_user ON voice_usage(user_id,created_at)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_wallets (user_id INTEGER PRIMARY KEY,balance INTEGER NOT NULL DEFAULT 200,updated_at TEXT NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS credit_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,amount INTEGER NOT NULL,balance_after INTEGER NOT NULL,reason TEXT NOT NULL,reference_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_credit_user ON credit_transactions(user_id,created_at)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_request_keys (user_id INTEGER NOT NULL,request_key VARCHAR(100) NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(user_id,request_key))");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_refunds (user_id INTEGER NOT NULL,request_key VARCHAR(100) NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(user_id,request_key))");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_generations (id TEXT PRIMARY KEY,user_id INTEGER NOT NULL,script TEXT NOT NULL,voice_id TEXT NOT NULL DEFAULT '',model TEXT NOT NULL,audio_file TEXT NOT NULL,audio_bytes INTEGER NOT NULL,credits_charged INTEGER NOT NULL,created_at TEXT NOT NULL)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_voice_generations_user ON voice_generations(user_id,created_at)");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_api_keys (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,label VARCHAR(120) NOT NULL,encrypted_key LONGTEXT NOT NULL,nonce VARCHAR(64) NOT NULL,auth_tag VARCHAR(64) NOT NULL,is_active TINYINT(1) NOT NULL DEFAULT 1,priority INT NOT NULL DEFAULT 100,last_used_at DATETIME NULL,failure_count INT NOT NULL DEFAULT 0,last_error TEXT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY idx_admin_keys_active(is_active,priority)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_audit_logs (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,actor_user_id BIGINT NULL,action VARCHAR(100) NOT NULL,target_type VARCHAR(80) NOT NULL DEFAULT '',target_id VARCHAR(120) NOT NULL DEFAULT '',details LONGTEXT NOT NULL,ip_address VARCHAR(64) NOT NULL DEFAULT '',created_at DATETIME NOT NULL,KEY idx_admin_audit_created(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS platform_settings (setting_key VARCHAR(120) NOT NULL PRIMARY KEY,setting_value LONGTEXT NOT NULL,updated_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS fish_audio_keys (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,label VARCHAR(120) NOT NULL,encrypted_key LONGTEXT NOT NULL,nonce VARCHAR(64) NOT NULL,auth_tag VARCHAR(64) NOT NULL,is_active TINYINT(1) NOT NULL DEFAULT 1,priority INT NOT NULL DEFAULT 100,last_used_at DATETIME NULL,failure_count INT NOT NULL DEFAULT 0,last_error TEXT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY idx_fish_keys_active(is_active,priority)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_usage (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,owner_key VARCHAR(64) NOT NULL,user_id BIGINT NULL,characters INT NOT NULL,model VARCHAR(60) NOT NULL,status VARCHAR(20) NOT NULL,error_code INT NULL,created_at DATETIME NOT NULL,KEY idx_voice_usage_owner(owner_key,created_at),KEY idx_voice_usage_created(created_at),KEY idx_voice_usage_user(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_wallets (user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,balance BIGINT NOT NULL DEFAULT 200,updated_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS credit_transactions (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,amount BIGINT NOT NULL,balance_after BIGINT NOT NULL,reason VARCHAR(120) NOT NULL,reference_id VARCHAR(80) NOT NULL DEFAULT '',created_at DATETIME NOT NULL,KEY idx_credit_user(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_request_keys (user_id BIGINT UNSIGNED NOT NULL,request_key VARCHAR(100) NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(user_id,request_key)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_refunds (user_id BIGINT UNSIGNED NOT NULL,request_key VARCHAR(100) NOT NULL,created_at DATETIME NOT NULL,PRIMARY KEY(user_id,request_key)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_generations (id CHAR(32) NOT NULL PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,script TEXT NOT NULL,voice_id VARCHAR(120) NOT NULL DEFAULT '',model VARCHAR(60) NOT NULL,audio_file VARCHAR(100) NOT NULL,audio_bytes BIGINT NOT NULL,credits_charged INT NOT NULL,created_at DATETIME NOT NULL,KEY idx_voice_generations_user(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    if ($driver === 'mysql') {
        $indexCheck=$pdo->query("SHOW INDEX FROM voice_usage WHERE Key_name='idx_voice_usage_user'");
        if (!$indexCheck || !$indexCheck->fetch()) $pdo->exec('CREATE INDEX idx_voice_usage_user ON voice_usage(user_id,created_at)');
    }
}

function seed_prompts(PDO $pdo): void
{
    $count = (int)$pdo->query('SELECT COUNT(*) FROM prompt_library WHERE is_custom = 0')->fetchColumn();
    if ($count > 0) return;
    $rows = [
        ['Cinematic Portrait', 'Film-grade portrait lighting and depth.', 'Transform the scene into a cinematic portrait with natural skin detail, rich filmic contrast, soft key light, subtle rim light, and a shallow depth of field.', 'Cinematic'],
        ['Golden Hour Film', 'Warm late-afternoon light.', 'Create a polished golden-hour film look with warm sunlight, soft highlights, gentle shadows, realistic skin tones, and subtle 35mm film texture.', 'Cinematic'],
        ['Anime Hero', 'Expressive anime character styling.', 'Transform the subject into a beautifully detailed anime hero while preserving the person’s pose, facial expression, and motion. Use clean linework, expressive eyes, and vivid but balanced colors.', 'Anime'],
        ['Soft Anime', 'A gentle animated look.', 'Restyle the scene as a soft, high-quality anime sequence with delicate shading, clean contours, warm color harmony, and consistent character details.', 'Anime'],
        ['Photoreal Studio', 'Natural, camera-real output.', 'Make the scene photorealistic with natural skin texture, believable materials, accurate lighting, crisp detail, and realistic shadows. Preserve the subject’s movement and proportions.', 'Realistic'],
        ['Documentary Realism', 'Unpolished natural camera feel.', 'Give the video a grounded documentary look with natural available light, authentic texture, realistic color, and restrained contrast. Avoid plastic skin or exaggerated effects.', 'Realistic'],
        ['Enchanted Forest', 'Magical woodland atmosphere.', 'Transform the environment into an enchanted forest with glowing fireflies, lush foliage, delicate mist, and magical shafts of light while keeping the subject clearly visible.', 'Fantasy'],
        ['Fantasy Royalty', 'Regal fantasy character styling.', 'Restyle the subject as a regal fantasy character with ornate yet believable details, rich fabrics, subtle magical atmosphere, and cinematic light. Preserve facial expression and movement.', 'Fantasy'],
        ['Neon Cyberpunk', 'Futuristic neon city aesthetic.', 'Create a cinematic cyberpunk look with tasteful neon magenta and cyan lighting, reflective city ambience, subtle holographic details, and realistic subject motion.', 'Cyberpunk'],
        ['Tech Noir', 'Dark futuristic atmosphere.', 'Apply a restrained tech-noir aesthetic with deep shadows, cool practical lights, atmospheric reflections, and sophisticated futuristic set details.', 'Cyberpunk'],
        ['Executive Studio', 'Premium professional appearance.', 'Give the scene a premium professional studio look with clean soft lighting, a refined neutral background, natural skin tones, and polished but realistic detail.', 'Professional'],
        ['Creator Workspace', 'Modern creator studio background.', 'Place the subject in a clean modern creator studio with tasteful practical lights, elegant equipment, balanced depth, and a bright professional visual identity.', 'Professional'],
        ['Editorial Fashion', 'High-end magazine styling.', 'Create a high-fashion editorial look with elegant studio lighting, refined color grading, detailed fabric texture, and a polished magazine-campaign aesthetic.', 'Fashion'],
        ['Runway Spotlight', 'Fashion-show atmosphere.', 'Transform the scene into a fashion runway moment with dramatic spotlighting, a refined show environment, rich blacks, and realistic garment movement.', 'Fashion'],
        ['Character Swap', 'Use a reference image for identity.', 'Transform the person in the live video into the character shown in the uploaded reference image. Preserve the live person’s expressions, gestures, and timing.', 'Character Transformation'],
        ['Animated Character', 'Become a stylized character.', 'Transform the subject into a coherent animated character while preserving the subject’s pose, timing, and expressions. Keep the character design consistent across frames.', 'Character Transformation'],
        ['Stylized Cartoon', 'Bright illustrated cartoon look.', 'Restyle the video as a polished 3D cartoon with appealing shapes, smooth shading, expressive features, and consistent design. Preserve the subject’s movement.', 'Cartoon'],
        ['Graphic Novel', 'Bold illustrated ink style.', 'Apply a graphic-novel visual treatment with confident ink contours, controlled halftone texture, expressive shadows, and a cohesive illustrated palette.', 'Cartoon'],
        ['Dream Bloom', 'Soft creative glow and color.', 'Add a dreamy creative treatment with gentle bloom, luminous highlights, subtle color separation, and elegant atmospheric detail without obscuring the subject.', 'Creative Effects'],
        ['Prism Light', 'Tasteful refracted light accents.', 'Add subtle prismatic light accents and elegant reflections around the scene. Keep the face, clothing, and motion clear and naturally integrated.', 'Creative Effects'],
    ];
    $stmt = $pdo->prepare('INSERT INTO prompt_library (title, description, prompt, category, is_custom, owner_key, created_at, updated_at) VALUES (?, ?, ?, ?, 0, ?, ?, ?)');
    $now = date('Y-m-d H:i:s');
    foreach ($rows as $row) $stmt->execute([...$row, '', $now, $now]);
}

function owner_key(): string {
    $userId=(int)($_SESSION['user_id']??0);
    return $userId>0 ? hash('sha256','anonymoux-account-owner-v1:'.$userId) : hash('sha256',(string)$_SESSION['owner_token']);
}
function csrf_token(): string { return (string)$_SESSION['csrf_token']; }
function now_sql(): string { return date('Y-m-d H:i:s'); }
function app_text_length(string $value): int { return function_exists('mb_strlen') ? mb_strlen($value,'UTF-8') : strlen($value); }

function json_response(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function api_guard(array $methods = ['GET']): void
{
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if (!in_array($method, $methods, true)) {
        header('Allow: ' . implode(', ', $methods));
        json_response(['ok' => false, 'error' => 'Method not allowed.'], 405);
    }
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    if ($origin !== '') {
        $host = strtolower($_SERVER['HTTP_HOST'] ?? '');
        $originHost = strtolower((string)parse_url($origin, PHP_URL_HOST));
        if ($originHost !== '' && $host !== '' && $originHost !== strtolower(explode(':', $host)[0])) {
            json_response(['ok' => false, 'error' => 'Cross-origin request rejected.'], 403);
        }
    }
    if ($method !== 'GET' && $method !== 'HEAD') {
        $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['_csrf'] ?? '');
        if (!is_string($provided) || !hash_equals(csrf_token(), $provided)) {
            json_response(['ok' => false, 'error' => 'Security token expired. Refresh the page and try again.'], 419);
        }
    }
}

function json_input(): array
{
    $raw = file_get_contents('php://input');
    if (!$raw) return [];
    $data = json_decode($raw, true);
    if (!is_array($data)) json_response(['ok' => false, 'error' => 'Invalid JSON request body.'], 400);
    return $data;
}

function platform_model_enabled(string $model): bool {
    try { $s=db()->prepare('SELECT setting_value FROM platform_settings WHERE setting_key=? LIMIT 1');$s->execute(['model_enabled_'.$model]);$v=$s->fetchColumn();return $v===false?true:$v==='1'; } catch(Throwable $ignored) { return true; }
}

function decart_encryption_secret(): string
{
    $secret = trim((string)(app_config()['admin_api_encryption_key'] ?? ''));
    if (strlen($secret) < 32) throw new RuntimeException('Set ANONYMOUX_KEY_ENCRYPTION_SECRET (at least 32 characters) before storing API keys in the admin panel.');
    return hash('sha256', $secret, true);
}

function decart_api_key_records(): array
{
    $keys = [];
    try {
        $rows = db()->query('SELECT id,label,encrypted_key,nonce,auth_tag,is_active,priority FROM admin_api_keys WHERE is_active=1 ORDER BY priority ASC,id ASC')->fetchAll();
        if ($rows && function_exists('openssl_decrypt')) {
            $secret = decart_encryption_secret();
            foreach ($rows as $row) {
                $plain = openssl_decrypt((string)$row['encrypted_key'], 'aes-256-gcm', $secret, 0, base64_decode((string)$row['nonce']), base64_decode((string)$row['auth_tag']));
                if (is_string($plain) && $plain !== '') $keys[] = ['id'=>(int)$row['id'],'label'=>(string)$row['label'],'key'=>$plain];
            }
        }
    } catch (Throwable $ignored) { /* Legacy config key remains a safe fallback when admin key storage is not configured. */ }
    if (!$keys) {
        $legacy = trim((string)(app_config()['decart_api_key'] ?? ''));
        if ($legacy !== '' && !str_contains($legacy, 'PASTE_YOUR_')) $keys[] = ['id'=>0,'label'=>'Server configuration','key'=>$legacy];
    }
    return $keys;
}

function decart_ready(): bool { return count(decart_api_key_records()) > 0; }

function decart_note_key_result(array $key, int $status, string $error = ''): void
{
    $id = (int)($key['id'] ?? 0); if ($id < 1) return;
    try {
        if ($status >= 200 && $status < 300) db()->prepare('UPDATE admin_api_keys SET last_used_at=?,last_error=NULL,updated_at=? WHERE id=?')->execute([now_sql(),now_sql(),$id]);
        else db()->prepare('UPDATE admin_api_keys SET failure_count=failure_count+1,last_error=?,updated_at=? WHERE id=?')->execute([substr($error,0,1000),now_sql(),$id]);
    } catch (Throwable $ignored) {}
}

/** Provider requests rotate to the next enabled key after auth, quota, or transient provider failures. */
function decart_request(string $method, string $path, ?array $payload = null, array $extraHeaders = []): array
{
    $keys = decart_api_key_records();
    if (!$keys) throw new RuntimeException('Decart API key is not configured. Add one in Admin → API Management or configure DECART_API_KEY.');
    if (!extension_loaded('curl')) throw new RuntimeException('PHP cURL extension is required for Decart API requests.');
    $cfg = app_config(); $url = rtrim((string)$cfg['decart_api_base'], '/') . '/' . ltrim($path, '/');
    $last = null;
    foreach ($keys as $key) {
        $responseHeaders = [];
        $headers = array_merge(['X-API-KEY: ' . $key['key'], 'Accept: application/json'], $extraHeaders);
        $body = $payload !== null ? json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : null;
        if ($body !== null) $headers[] = 'Content-Type: application/json';
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_CUSTOMREQUEST=>strtoupper($method),CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>75,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_HEADERFUNCTION=>static function($curl,string $line) use (&$responseHeaders): int {$length=strlen($line);$parts=explode(':',$line,2);if(count($parts)===2)$responseHeaders[strtolower(trim($parts[0]))]=trim($parts[1]);return $length;}]);
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        $raw = curl_exec($ch);
        if ($raw === false) { $error=curl_error($ch);curl_close($ch);decart_note_key_result($key,0,$error);$last=new RuntimeException('Could not reach Decart: '.$error);continue; }
        $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
        $decoded=$raw!==''?json_decode((string)$raw,true):[];
        $result=['status'=>$status,'body'=>is_array($decoded)?$decoded:[],'raw'=>(string)$raw,'headers'=>$responseHeaders];
        decart_note_key_result($key,$status,$status>=400?('HTTP '.$status.' '.substr((string)$raw,0,400)):'' );
        if (in_array($status,[401,403,408,429,500,502,503,504],true) && count($keys)>1) { $last=$result; continue; }
        return $result;
    }
    if (is_array($last)) return $last;
    if ($last instanceof Throwable) throw $last;
    throw new RuntimeException('No usable Decart API key is available.');
}

function decart_error_message(array $result): string
{
    $body = $result['body'] ?? [];
    $detail = $body['detail'] ?? $body['message'] ?? $body['title'] ?? '';
    if (is_array($detail)) $detail = json_encode($detail);
    if (!is_string($detail) || $detail === '') $detail = 'Decart returned HTTP ' . (int)($result['status'] ?? 0) . '.';
    return $detail;
}

function owned_remote_session(string $remoteId): array
{
    if (!preg_match('/^rs_[A-Za-z0-9_-]{4,120}$/', $remoteId)) json_response(['ok' => false, 'error' => 'Invalid session identifier.'], 400);
    $entry = $_SESSION['remote_sessions'][$remoteId] ?? null;
    if (!is_array($entry)) json_response(['ok' => false, 'error' => 'This browser does not own that session. Start a new transformation.'], 404);
    return $entry;
}

function update_remote_session_state(string $remoteId, array $changes): void
{
    if (!isset($_SESSION['remote_sessions'][$remoteId])) return;
    $_SESSION['remote_sessions'][$remoteId] = array_merge($_SESSION['remote_sessions'][$remoteId], $changes);
}

function active_reference(): ?array
{
    $stmt = db()->prepare('SELECT id, original_name, mime_type, file_size, width, height, created_at FROM reference_uploads WHERE owner_key = ? AND is_active = 1 ORDER BY created_at DESC LIMIT 1');
    $stmt->execute([owner_key()]);
    $row = $stmt->fetch();
    return $row ?: null;
}

function owned_reference_file(string $referenceId): array
{
    $stmt = db()->prepare('SELECT * FROM reference_uploads WHERE id = ? AND owner_key = ? AND is_active = 1 LIMIT 1');
    $stmt->execute([$referenceId, owner_key()]);
    $row = $stmt->fetch();
    if (!$row) json_response(['ok' => false, 'error' => 'Reference image was not found. Upload it again.'], 404);
    $path = APP_ROOT . '/storage/references/' . basename((string)$row['disk_name']);
    if (!is_file($path)) json_response(['ok' => false, 'error' => 'Stored reference image is missing. Upload it again.'], 404);
    return [$row, $path];
}

function reference_base64(?string $referenceId): ?string
{
    if ($referenceId === null || $referenceId === '') return null;
    [, $path] = owned_reference_file($referenceId);
    $contents = file_get_contents($path);
    if ($contents === false) throw new RuntimeException('Could not read the stored reference image.');
    return base64_encode($contents);
}

function preference_get(string $key, mixed $default = null): mixed
{
    $stmt = db()->prepare('SELECT preference_value FROM workspace_preferences WHERE owner_key = ? AND preference_key = ?');
    $stmt->execute([owner_key(), $key]);
    $value = $stmt->fetchColumn();
    if ($value === false) return $default;
    $decoded = json_decode((string)$value, true);
    return json_last_error() === JSON_ERROR_NONE ? $decoded : $default;
}

function preference_set(string $key, mixed $value): void
{
    $sql = 'INSERT INTO workspace_preferences (owner_key, preference_key, preference_value, updated_at) VALUES (?, ?, ?, ?)';
    if (db()->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
        $sql .= ' ON CONFLICT(owner_key, preference_key) DO UPDATE SET preference_value = excluded.preference_value, updated_at = excluded.updated_at';
    } else {
        $sql .= ' ON DUPLICATE KEY UPDATE preference_value = VALUES(preference_value), updated_at = VALUES(updated_at)';
    }
    db()->prepare($sql)->execute([owner_key(), $key, json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), now_sql()]);
}

/** Session-scoped limiter for expensive generation submissions. */
function app_rate_limit(string $bucket, int $limit, int $windowSeconds): void
{
    $now = time();
    $state = $_SESSION['rate_limits'][$bucket] ?? ['start' => $now, 'count' => 0];
    if (!is_array($state) || $now - (int)($state['start'] ?? 0) >= $windowSeconds) {
        $state = ['start' => $now, 'count' => 0];
    }
    if ((int)($state['count'] ?? 0) >= $limit) {
        json_response(['ok' => false, 'error' => 'Too many requests. Please wait before starting another generation.'], 429);
    }

    // Also enforce an IP-scoped limit so creating fresh browser sessions cannot bypass it.
    $storage = APP_ROOT . '/storage';
    if (!is_dir($storage) && !@mkdir($storage, 0750, true) && !is_dir($storage)) {
        json_response(['ok' => false, 'error' => 'Request protection is temporarily unavailable.'], 503);
    }
    $identity = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $userId = (int)($_SESSION['user_id'] ?? 0);
    $fileKey = hash('sha256', $bucket . "\0" . $identity . "\0" . $userId);
    $rateDir = $storage . '/rate-limits';
    if (!is_dir($rateDir) && !@mkdir($rateDir, 0750, true) && !is_dir($rateDir)) {
        json_response(['ok' => false, 'error' => 'Request protection is temporarily unavailable.'], 503);
    }
    $handle = @fopen($rateDir . '/' . $fileKey . '.json', 'c+');
    if (!$handle || !flock($handle, LOCK_EX)) {
        if (is_resource($handle)) fclose($handle);
        json_response(['ok' => false, 'error' => 'Request protection is temporarily unavailable.'], 503);
    }
    rewind($handle);
    $ipState = json_decode((string)stream_get_contents($handle), true);
    if (!is_array($ipState) || $now - (int)($ipState['start'] ?? 0) >= $windowSeconds) {
        $ipState = ['start' => $now, 'count' => 0];
    }
    if ((int)($ipState['count'] ?? 0) >= $limit) {
        flock($handle, LOCK_UN); fclose($handle);
        json_response(['ok' => false, 'error' => 'Too many requests from this network. Please wait before trying again.'], 429);
    }
    $ipState['count'] = (int)$ipState['count'] + 1;
    rewind($handle); ftruncate($handle, 0);
    fwrite($handle, json_encode($ipState)); fflush($handle);
    flock($handle, LOCK_UN); fclose($handle);

    $state['count'] = (int)$state['count'] + 1;
    $_SESSION['rate_limits'][$bucket] = $state;
}

function secure_filename(string $name): string
{
    $name = basename(str_replace('\\', '/', $name));
    $name = preg_replace('/[^A-Za-z0-9._-]+/', '_', $name) ?: 'reference-image';
    return substr($name, 0, 160);
}
