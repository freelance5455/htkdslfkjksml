# Keep the JavaScript bridge visible to Android WebView.
-keepclassmembers class com.mrkhorasani.accounting.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
