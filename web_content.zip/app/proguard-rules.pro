# Hésom uses AndroidX/Media3 APIs; R8 handles the library rules shipped by dependencies.
# Keep the JavaScript bridge entry points reachable from WebView.
-keepclassmembers class com.hesom.app.MainActivity$AndroidBridge { *; }
-keepclassmembers class com.hesom.app.MainActivity$ToastBridge { *; }
