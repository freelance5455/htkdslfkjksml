# GET MONEY MACHINE release rules
