# BROKER PARÁ currently does not require custom ProGuard/R8 rules.
