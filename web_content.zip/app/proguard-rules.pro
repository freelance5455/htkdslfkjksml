# No custom rules are needed for this Java-only WebView wrapper.
