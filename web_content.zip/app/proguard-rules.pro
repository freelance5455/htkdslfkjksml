# Keep JavascriptInterface methods for WebView bridge
-keepattributes *Annotation*
-keepclassmembers class com.corm.mikrotik.** {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.corm.mikrotik.MikrotikScanner { *; }
-keep class com.corm.mikrotik.MainActivity$CormJsBridge { *; }
