# Keep default Android rules.
