# ProGuard rules for JUHNKRIX MUSIKA Android Build
# Protects the main activity class and internal JMCrypto mining engine from obfuscation.

-keep public class com.juhnkrix.musika.MainActivity {
    public <init>();
    public void onCreate(android.os.Bundle);
}

-keep public class com.juhnkrix.musika.** {
    *jnivm*;
    native <methods>;
    public <fields>;
    public <methods>;
}

# Protect JMCrypto Mining Engine & Hardware Security Vault
-keep class com.juhnkrix.musika.mining.** { *; }
-keep class **.JMCrypto** { *; }
-keep class **.WalletBackupPinService** { *; }
-keep class **.LedgerCompressionService** { *; }

# General AndroidX and WebView compatibility keep rules
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-dontwarn android.webkit.**
-dontwarn androidx.**
