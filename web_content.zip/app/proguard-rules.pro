# TDH PickleQue does not require custom ProGuard/R8 rules for the WebView shell.
