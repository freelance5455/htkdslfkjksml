# Add project specific ProGuard rules here.

# Keep Room components
-keep class androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keep class com.example.data.local.** { *; }
-keep class com.example.data.model.** { *; }

# Keep Compose and ViewModels
-keep class com.example.ui.viewmodel.** { *; }
-keep class * extends androidx.lifecycle.ViewModel { *; }
-keep class * extends androidx.lifecycle.ViewModelProvider$Factory { *; }

# Coroutines and annotations
-keepattributes *Annotation*
-dontwarn kotlinx.coroutines.**
