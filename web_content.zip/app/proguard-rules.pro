# CryptoPulse keeps WebView assets and uses no custom shrink rules.
