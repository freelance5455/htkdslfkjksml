# Keep WebView JavascriptInterface methods
-keepclassmembers class com.illuminxs.sf2bundleeditor.MainActivity$AndroidExportBridge {
    @android.webkit.JavascriptInterface <methods>;
}
