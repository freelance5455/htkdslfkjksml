# The prototype does not require custom ProGuard rules.
