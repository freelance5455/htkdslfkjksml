# LaguAI - regras adicionais de ProGuard/R8 (vazio por padrão)
