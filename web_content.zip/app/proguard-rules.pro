# ForgeFPS Ultra keeps Shizuku provider classes discoverable.
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
