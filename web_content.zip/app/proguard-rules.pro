# NotifyStyle keeps its WebView bridge public methods.
-keepclassmembers class com.notifystyle.app.WebBridge { public *; }
