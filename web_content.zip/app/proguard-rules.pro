# Les methodes appelees depuis la page web (Android.saveText, Android.getDeviceKey, ...) sont
# appelees par leur NOM depuis le JavaScript. R8 ne doit ni les supprimer ni les renommer, sinon
# l'application ne repond plus. Tout le reste du code est libre d'etre renomme/reduit.
-keepclassmembers class com.greg.ed.cmc.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.greg.ed.cmc.MainActivity$Bridge { *; }

# Evite des avertissements sans consequence a la compilation.
-dontwarn android.webkit.**
