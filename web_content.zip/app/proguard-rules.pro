# Preserve Mizo_q AccessibilityService, Foreground Overlay Service, and Room Entities
-keep class com.mizoq.tiktoktoolkit.service.accessibility.MizoAccessibilityService { *; }
-keep class com.mizoq.tiktoktoolkit.service.overlay.MizoOverlayService { *; }
-keep class com.mizoq.tiktoktoolkit.data.local.** { *; }
-keepnames class * extends androidx.room.RoomDatabase
-dontwarn kotlinx.coroutines.**
