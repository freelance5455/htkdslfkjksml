<?php
declare(strict_types=1);
require_once __DIR__.'/voice.php';

function payments_schema(): void {
    static $ready=false; if($ready)return; $pdo=db(); $driver=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if($driver==='sqlite'){
        $pdo->exec("CREATE TABLE IF NOT EXISTS credit_packages (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',price_minor INTEGER NOT NULL,credits INTEGER NOT NULL,currency TEXT NOT NULL DEFAULT 'NGN',is_active INTEGER NOT NULL DEFAULT 1,sort_order INTEGER NOT NULL DEFAULT 100,promo_badge TEXT NOT NULL DEFAULT '',bonus_credits INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS payment_orders (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,package_id INTEGER NOT NULL,reference TEXT NOT NULL UNIQUE,amount_minor INTEGER NOT NULL,currency TEXT NOT NULL,credits INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',provider_transaction_id TEXT NULL UNIQUE,provider_status TEXT NULL,verified_at TEXT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_payment_orders_user ON payment_orders(user_id,created_at)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_payment_orders_status ON payment_orders(status,created_at)");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS credit_packages (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,description VARCHAR(500) NOT NULL DEFAULT '',price_minor BIGINT NOT NULL,credits BIGINT NOT NULL,currency CHAR(3) NOT NULL DEFAULT 'NGN',is_active TINYINT(1) NOT NULL DEFAULT 1,sort_order INT NOT NULL DEFAULT 100,promo_badge VARCHAR(80) NOT NULL DEFAULT '',bonus_credits BIGINT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY idx_packages_active(is_active,sort_order)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS payment_orders (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,package_id BIGINT UNSIGNED NOT NULL,reference VARCHAR(100) NOT NULL UNIQUE,amount_minor BIGINT NOT NULL,currency CHAR(3) NOT NULL,credits BIGINT NOT NULL,status VARCHAR(20) NOT NULL DEFAULT 'pending',provider_transaction_id VARCHAR(100) NULL UNIQUE,provider_status VARCHAR(40) NULL,verified_at DATETIME NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY idx_payment_orders_user(user_id,created_at),KEY idx_payment_orders_status(status,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    // Additive compatibility upgrades for existing 2.5.4 installations.
    $cols=[];
    if($driver==='sqlite') { foreach($pdo->query('PRAGMA table_info(credit_packages)')->fetchAll(PDO::FETCH_ASSOC) as $c) $cols[$c['name']]=true; }
    else { $q=$pdo->query('SHOW COLUMNS FROM credit_packages'); foreach($q->fetchAll(PDO::FETCH_ASSOC) as $c) $cols[$c['Field']]=true; }
    foreach(['sort_order'=>'INTEGER NOT NULL DEFAULT 100','promo_badge'=>"VARCHAR(80) NOT NULL DEFAULT ''",'bonus_credits'=>'BIGINT NOT NULL DEFAULT 0'] as $col=>$def) if(!isset($cols[$col])) $pdo->exec('ALTER TABLE credit_packages ADD COLUMN '.$col.' '.$def);
    $defaults=[['Starter','For trying the creative workspaces',250000,250,10],['Creator','For regular creative projects',600000,600,20],['Studio','For larger production sessions',1500000,1500,30],['Professional','For high-volume professional work',3500000,3500,40]];
    $exists=$pdo->prepare('SELECT id FROM credit_packages WHERE name=? LIMIT 1');
    $ins=$pdo->prepare("INSERT INTO credit_packages(name,description,price_minor,credits,currency,is_active,sort_order,promo_badge,bonus_credits,created_at,updated_at) VALUES(?,?,?,?,'NGN',1,?,'',0,?,?)");
    foreach($defaults as $v) { $exists->execute([$v[0]]); if(!$exists->fetchColumn()) $ins->execute([$v[0],$v[1],$v[2],$v[3],$v[4],now_sql(),now_sql()]); }
    $ready=true;
}
function payment_setting(string $key,string $default=''): string {
    $s=db()->prepare('SELECT setting_value FROM platform_settings WHERE setting_key=?');$s->execute(['flutterwave_'.$key]);$v=$s->fetchColumn();return $v===false?$default:(string)$v;
}
function payment_secret_decrypt(string $cipher,string $nonce,string $tag): string {
    $secret=trim((string)(app_config()['admin_api_encryption_key']??'')); if(strlen($secret)<32||stripos($secret,'REPLACE_WITH')!==false||!function_exists('openssl_decrypt'))return '';
    $plain=openssl_decrypt($cipher,'aes-256-gcm',hash('sha256',$secret,true),0,base64_decode($nonce,true)?:'',base64_decode($tag,true)?:'');
    return is_string($plain)?$plain:'';
}
function payment_secret_get(string $name): string {
    $c=payment_setting($name.'_cipher');if($c==='')return '';
    return payment_secret_decrypt($c,payment_setting($name.'_nonce'),payment_setting($name.'_tag'));
}

function payment_setting_set(string $key,string $value): void {
    $pdo=db();$driver=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if($driver==='sqlite')$pdo->prepare('INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=excluded.updated_at')->execute(['flutterwave_'.$key,$value,now_sql()]);
    else $pdo->prepare('INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=VALUES(updated_at)')->execute(['flutterwave_'.$key,$value,now_sql()]);
}
function payment_store_secret(string $name,string $plain): void {
    if($plain==='')return;
    $cfg=app_config();$secret=trim((string)($cfg['admin_api_encryption_key']??''));
    if(strlen($secret)<32||stripos($secret,'REPLACE_WITH')!==false||!function_exists('openssl_encrypt'))throw new RuntimeException('Configure a 32-character encryption secret and OpenSSL before saving payment credentials.');
    $nonce=random_bytes(12);$tag='';$cipher=openssl_encrypt($plain,'aes-256-gcm',hash('sha256',$secret,true),0,$nonce,$tag);
    if(!is_string($cipher))throw new RuntimeException('Could not encrypt the payment credential.');
    payment_setting_set($name.'_cipher',$cipher);payment_setting_set($name.'_nonce',base64_encode($nonce));payment_setting_set($name.'_tag',base64_encode($tag));
}

function payment_gateway_config(): array {
    return ['public_key'=>payment_setting('public_key'),'secret_key'=>payment_secret_get('secret_key'),'webhook_hash'=>payment_secret_get('webhook_hash'),'mode'=>payment_setting('mode','test'),'enabled'=>payment_setting('enabled','0')==='1','currency'=>payment_setting('currency','NGN')];
}
function payment_http(string $method,string $url,array $payload=[],string $secret=''): array {
    if(!function_exists('curl_init'))throw new RuntimeException('PHP cURL is required for Flutterwave requests on this host.');
    $ch=curl_init($url);$headers=['Authorization: Bearer '.$secret,'Content-Type: application/json','Accept: application/json'];
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>35,CURLOPT_CONNECTTIMEOUT=>12,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    if($payload)curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($payload,JSON_UNESCAPED_SLASHES));
    $raw=curl_exec($ch);$err=curl_error($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    if(!is_string($raw))throw new RuntimeException('Flutterwave connection failed: '.substr($err,0,180));
    $json=json_decode($raw,true);if(!is_array($json))throw new RuntimeException('Flutterwave returned an invalid response.');
    return ['status'=>$status,'json'=>$json];
}
function payment_create_order(int $userId,int $packageId): array {
    payments_schema();$cfg=payment_gateway_config();
    if($userId<1)throw new InvalidArgumentException('A signed-in account is required.');
    if(!$cfg['enabled']||$cfg['secret_key']===''||$cfg['public_key']==='')throw new RuntimeException('Credit purchases are temporarily unavailable. Contact the administrator.');
    $s=db()->prepare('SELECT * FROM credit_packages WHERE id=? AND is_active=1');$s->execute([$packageId]);$pkg=$s->fetch();
    if(!$pkg)throw new InvalidArgumentException('This credit package is unavailable.');
    if((int)$pkg['price_minor']<1||(int)$pkg['credits']<1)throw new RuntimeException('This package has invalid pricing or credit settings.');
    if(strtoupper((string)$pkg['currency'])!==$cfg['currency'])throw new RuntimeException('Package currency does not match the configured payment currency.');
    $ref='ANX'.strtoupper(bin2hex(random_bytes(14)));$now=now_sql();
    db()->prepare("INSERT INTO payment_orders(user_id,package_id,reference,amount_minor,currency,credits,status,created_at,updated_at) VALUES(?,?,?,?,?,?, 'pending',?,?)")->execute([$userId,$packageId,$ref,(int)$pkg['price_minor'],strtoupper((string)$pkg['currency']),((int)$pkg['credits']+max(0,(int)$pkg['bonus_credits'])),$now,$now]);
    $canonical=trim((string)(app_config()['canonical_base_url']??''));
    if($canonical!==''){
        $parts=parse_url($canonical);
        if(!is_array($parts)||strtolower((string)($parts['scheme']??''))!=='https'||empty($parts['host'])) throw new RuntimeException('Configure a valid HTTPS canonical_base_url before enabling checkout.');
        $base='https://'.$parts['host'].(isset($parts['port'])?':'.(int)$parts['port']:'').rtrim((string)($parts['path']??''),'/');
    } else {
        $serverName=strtolower((string)($_SERVER['SERVER_NAME']??''));
        if($serverName===''||!preg_match('/^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/',$serverName)) throw new RuntimeException('Configure canonical_base_url before enabling Flutterwave checkout.');
        $base='https://'.$serverName;
    }
    $dir=rtrim(str_replace('\\','/',dirname((string)($_SERVER['SCRIPT_NAME']??'/'))),'/'); if(str_ends_with($dir,'/api'))$dir=substr($dir,0,-4);
    $redirect=$base.($canonical!==''?'':($dir===''?'':$dir)).'/credits.php';
    $amount=number_format(((int)$pkg['price_minor'])/100,2,'.','');
    try {
        $resp=payment_http('POST','https://api.flutterwave.com/v3/payments',['tx_ref'=>$ref,'amount'=>$amount,'currency'=>$pkg['currency'],'redirect_url'=>$redirect,'customer'=>['email'=>(string)auth_user()['email'],'name'=>(string)auth_user()['name']],'customizations'=>['title'=>'ANONYMOUX STUDIOS','description'=>'Credit package purchase'],'meta'=>['user_id'=>$userId,'package_id'=>$packageId,'credits'=>((int)$pkg['credits']+max(0,(int)$pkg['bonus_credits']))]],$cfg['secret_key']);
        if($resp['status']<200||$resp['status']>=300||($resp['json']['status']??'')!=='success'||empty($resp['json']['data']['link'])) {
            db()->prepare("UPDATE payment_orders SET status='failed',provider_status=?,updated_at=? WHERE reference=?")->execute([substr((string)($resp['json']['message']??'checkout_init_failed'),0,40),now_sql(),$ref]);
            throw new RuntimeException('Flutterwave could not initialize checkout. Please try again.');
        }
    } catch(Throwable $e) {
        db()->prepare("UPDATE payment_orders SET status='failed',provider_status='checkout_init_error',updated_at=? WHERE reference=? AND status='pending'")->execute([now_sql(),$ref]);
        throw $e;
    }
    return ['reference'=>$ref,'checkout_url'=>(string)$resp['json']['data']['link']];
}
function payment_verify_and_credit(string $reference,string $transactionId,?int $expectedUser=null): array {
    payments_schema();$cfg=payment_gateway_config();
    if(!$cfg['enabled']||$cfg['secret_key']==='')throw new RuntimeException('Payment verification is not configured.');
    if(!preg_match('/^ANX[A-F0-9]{28}$/',$reference)||!ctype_digit($transactionId))throw new InvalidArgumentException('Invalid payment reference.');
    $q=db()->prepare('SELECT * FROM payment_orders WHERE reference=? LIMIT 1');$q->execute([$reference]);$order=$q->fetch();
    if(!$order)throw new InvalidArgumentException('Payment reference was not found.');
    if((int)$order['amount_minor']<1||(int)$order['credits']<1)throw new RuntimeException('Payment order contains invalid pricing or credit settings.');
    if($expectedUser!==null&&(int)$order['user_id']!==$expectedUser)throw new RuntimeException('This payment does not belong to the signed-in account.');
    if($order['status']==='successful')return ['ok'=>true,'credited'=>false,'credits'=>(int)$order['credits'],'status'=>'successful'];
    $v=payment_http('GET','https://api.flutterwave.com/v3/transactions/'.rawurlencode($transactionId).'/verify',[],$cfg['secret_key']);
    $d=$v['json']['data']??[];
    $valid=$v['status']===200&&($v['json']['status']??'')==='success'&&($d['status']??'')==='successful'&&hash_equals($reference,(string)($d['tx_ref']??''))&&strtoupper((string)($d['currency']??''))===strtoupper((string)$order['currency'])&&abs((float)($d['amount']??0)-((int)$order['amount_minor']/100))<0.00001;
    if(!$valid){
        $providerState=strtolower((string)($d['status']??''));
        if(in_array($providerState,['failed','cancelled','canceled'],true)) {
            db()->prepare("UPDATE payment_orders SET status=CASE WHEN status='successful' THEN status ELSE 'failed' END,provider_status=?,updated_at=? WHERE reference=?")->execute([substr($providerState,0,40),now_sql(),$reference]);
        }
        throw new RuntimeException('Flutterwave transaction could not be verified against this order.');
    }
    $pdo=db();$sqlite=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite';
    try{
        if($sqlite)$pdo->exec('BEGIN IMMEDIATE');else $pdo->beginTransaction();
        $lock=$pdo->prepare('SELECT * FROM payment_orders WHERE reference=?'.($sqlite?'':' FOR UPDATE'));$lock->execute([$reference]);$fresh=$lock->fetch();
        if(!$fresh)throw new RuntimeException('Payment order disappeared.');
        if($fresh['status']==='successful'){if($sqlite)$pdo->exec('COMMIT');else $pdo->commit();return ['ok'=>true,'credited'=>false,'credits'=>(int)$fresh['credits'],'status'=>'successful'];}
        if((int)$fresh['user_id']!== (int)$order['user_id'])throw new RuntimeException('Payment ownership changed.');
        voice_wallet_ensure((int)$fresh['user_id']);
        $pdo->prepare('UPDATE user_wallets SET balance=balance+?,updated_at=? WHERE user_id=?')->execute([(int)$fresh['credits'],now_sql(),(int)$fresh['user_id']]);
        $b=$pdo->prepare('SELECT balance FROM user_wallets WHERE user_id=?');$b->execute([(int)$fresh['user_id']]);$balance=(int)$b->fetchColumn();
        $pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')->execute([(int)$fresh['user_id'],(int)$fresh['credits'],$balance,'Flutterwave credit purchase',$reference,now_sql()]);
        $pdo->prepare("UPDATE payment_orders SET status='successful',provider_status='successful',provider_transaction_id=?,verified_at=?,updated_at=? WHERE id=?")->execute([$transactionId,now_sql(),now_sql(),(int)$fresh['id']]);
        if($sqlite)$pdo->exec('COMMIT');else $pdo->commit();
        return ['ok'=>true,'credited'=>true,'credits'=>(int)$fresh['credits'],'status'=>'successful'];
    }catch(Throwable $e){if($sqlite){try{$pdo->exec('ROLLBACK');}catch(Throwable $x){}}elseif($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
