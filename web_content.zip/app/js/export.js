import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';

/** Export the character (mesh + materials + textures) as a binary GLB. Resolves with a Blob. */
export function exportGLB(root) {
  return new Promise((res, rej) => {
    new GLTFExporter().parse(root, (buf) => res(new Blob([buf], { type: 'model/gltf-binary' })), (e) => rej(e instanceof Error ? e : new Error(String(e))),
      { binary: true, onlyVisible: true, maxTextureSize: 2048 });
  });
}

/** Render PNG(s). views: ['front','side','back']; returns [{view, blob}] */
export async function exportPNGs(viewer, { size, bg, views }) {
  const out = [];
  for (const v of views) out.push({ view: v, blob: await viewer.snapshot({ size, view: v, bg }) });
  return out;
}
