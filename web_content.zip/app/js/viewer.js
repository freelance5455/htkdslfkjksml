// Three.js viewer: orbit controls, views, lighting, backgrounds, snapshots.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { disposeTree } from './avatar.js';
import { settings } from './db.js';

export const BACKGROUNDS = {
  dark: { type: 'gradient', a: '#1b1a16', b: '#07070a' },
  charcoal: { type: 'color', c: '#1e1e26' },
  studio: { type: 'color', c: '#e7e3da' },
  gold: { type: 'gradient', a: '#e1c06b', b: '#8f6f26' },
  white: { type: 'color', c: '#ffffff' },
  transparent: { type: 'none' },
};

function gradientTexture(a, b) {
  const c = document.createElement('canvas'); c.width = 4; c.height = 256;
  const x = c.getContext('2d'); const g = x.createLinearGradient(0, 0, 0, 256); g.addColorStop(0, a); g.addColorStop(1, b);
  x.fillStyle = g; x.fillRect(0, 0, 4, 256);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export class Viewer {
  constructor(container) {
    this.el = container;
    const q = settings.get().quality;
    const dpr = window.devicePixelRatio || 1;
    this.maxPR = q === 'low' ? 1 : q === 'high' ? Math.min(dpr, 2.5) : Math.min(dpr, 1.75);
    this.renderer = new THREE.WebGLRenderer({ antialias: q !== 'low', alpha: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(this.maxPR);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.0;
    container.appendChild(this.renderer.domElement);
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(32, 1, 0.05, 50);
    const pm = new THREE.PMREMGenerator(this.renderer);
    this.envTex = pm.fromScene(new RoomEnvironment(), 0.04).texture; this.scene.environment = this.envTex; pm.dispose();

    this.hemi = new THREE.HemisphereLight(0xfff4e0, 0x20202a, 0.55); this.scene.add(this.hemi);
    this.key = new THREE.DirectionalLight(0xfff1d6, 2.2); this.scene.add(this.key);
    this.fill = new THREE.DirectionalLight(0xb8c8ff, 0.7); this.fill.position.set(-3, 2, 2); this.scene.add(this.fill);
    this.rim = new THREE.DirectionalLight(0xffd98a, 1.4); this.rim.position.set(0, 3, -4); this.scene.add(this.rim);
    this.light = { intensity: 1, angle: 35 }; this._applyLight();

    // platform
    this.platform = new THREE.Group();
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.66, 0.025, 48), new THREE.MeshStandardMaterial({ color: '#15151b', roughness: 0.5, metalness: 0.4 }));
    disc.position.y = -0.0125;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.64, 0.006, 8, 64), new THREE.MeshStandardMaterial({ color: '#c9a24b', roughness: 0.3, metalness: 0.9 }));
    ring.rotation.x = Math.PI / 2; ring.position.y = 0.002;
    this.platform.add(disc, ring); this.scene.add(this.platform);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true; this.controls.dampingFactor = 0.08; this.controls.enablePan = true;
    this.controls.minDistance = 0.4; this.controls.maxDistance = 8; this.controls.maxPolarAngle = Math.PI * 0.55;
    this.controls.screenSpacePanning = true;

    this.model = null; this.modelH = 1.75; this.goal = null; this.bgName = 'dark'; this._alive = true;
    this.setBackground('dark');
    this.setView('full', false);
    this._ro = new ResizeObserver(() => this.resize()); this._ro.observe(container);
    this.resize();
    const loop = () => {
      if (!this._alive) return;
      this._raf = requestAnimationFrame(loop);
      if (document.hidden) return;
      if (this.goal) {
        this.camera.position.lerp(this.goal.pos, 0.14); this.controls.target.lerp(this.goal.target, 0.14);
        if (this.camera.position.distanceTo(this.goal.pos) < 0.004) this.goal = null;
      }
      this.controls.update();
      this.renderer.render(this.scene, this.camera);
    };
    loop();
  }

  resize() {
    const w = this.el.clientWidth || 300, h = this.el.clientHeight || 300;
    this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
  }

  setModel(root) {
    if (this.model) { this.scene.remove(this.model); disposeTree(this.model); }
    this.model = root; if (!root) return;
    this.scene.add(root);
    const box = new THREE.Box3().setFromObject(root); this.modelH = Math.max(0.3, box.max.y - Math.min(0, box.min.y));
    this.platform.scale.setScalar(Math.max(0.6, this.modelH / 1.75));
  }

  _viewPose(name, h = this.modelH, aspect = this.camera.aspect) {
    const fov = THREE.MathUtils.degToRad(this.camera.fov);
    const fitH = (hh) => (hh / 2) / Math.tan(fov / 2) / Math.min(1, aspect * 1.0) * 1.12;
    const az = { front: 0, back: Math.PI, side: Math.PI / 2, left: -Math.PI / 2, full: 0.35, face: 0.0 }[name] ?? 0;
    let target, dist;
    if (name === 'face') { target = new THREE.Vector3(0, h * 0.925, 0); dist = fitH(h * 0.2); }
    else { target = new THREE.Vector3(0, h * 0.5, 0); dist = fitH(h * 1.08); }
    const pos = new THREE.Vector3(Math.sin(az) * dist, target.y + h * (name === 'face' ? 0 : 0.04), Math.cos(az) * dist);
    return { pos, target };
  }

  setView(name, animate = true) {
    const pose = this._viewPose(name);
    if (!animate) { this.camera.position.copy(pose.pos); this.controls.target.copy(pose.target); this.goal = null; this.controls.update(); }
    else this.goal = pose;
  }

  zoom(factor) {
    const dir = this.camera.position.clone().sub(this.controls.target);
    const len = THREE.MathUtils.clamp(dir.length() * factor, this.controls.minDistance, this.controls.maxDistance);
    this.goal = { pos: this.controls.target.clone().add(dir.setLength(len)), target: this.controls.target.clone() };
  }

  setAutoRotate(on) { this.controls.autoRotate = on; this.controls.autoRotateSpeed = 2.2; }

  _applyLight() {
    const { intensity, angle } = this.light, a = THREE.MathUtils.degToRad(angle);
    this.key.position.set(Math.sin(a) * 4, 3.5, Math.cos(a) * 4);
    this.key.intensity = 2.2 * intensity; this.hemi.intensity = 0.55 * intensity; this.fill.intensity = 0.7 * intensity; this.rim.intensity = 1.4 * intensity;
    this.renderer.toneMappingExposure = 0.6 + 0.4 * intensity;
  }
  setLighting(patch) { this.light = { ...this.light, ...patch }; this._applyLight(); }

  _bgFor(name) {
    const d = BACKGROUNDS[name] || BACKGROUNDS.dark;
    if (d.type === 'gradient') return gradientTexture(d.a, d.b);
    if (d.type === 'color') return new THREE.Color(d.c);
    return null;
  }
  setBackground(name) {
    this.bgName = name;
    const old = this.scene.background; if (old && old.isTexture) old.dispose();
    this.scene.background = this._bgFor(name);
    this.el.classList.toggle('checker', name === 'transparent');
    this.el.style.background = name === 'transparent' ? 'repeating-conic-gradient(#222 0 25%,#2b2b33 0 50%) 0 0/20px 20px' : '';
  }

  /** Render a PNG of the current model. opts: {size, view, bg:'transparent'|'studio'|...} -> Blob */
  async snapshot({ size = 1024, view = 'front', bg = 'studio', aspect = 1 } = {}) {
    const r = this.renderer, c = r.domElement;
    const prev = { pr: r.getPixelRatio(), w: c.width, h: c.height, bg: this.scene.background, plat: this.platform.visible, ca: r.getClearAlpha() };
    const cam = this.camera.clone(); cam.aspect = aspect; cam.updateProjectionMatrix();
    const pose = this._viewPose(view, this.modelH, aspect);
    cam.position.copy(pose.pos); cam.lookAt(pose.target);
    try {
      r.setPixelRatio(1); r.setSize(size, Math.round(size / aspect), false);
      this.scene.background = this._bgFor(bg); this.platform.visible = bg !== 'transparent';
      if (bg === 'transparent') r.setClearAlpha(0);
      r.render(this.scene, cam);
      const url = c.toDataURL('image/png');
      return await (await fetch(url)).blob();
    } finally {
      const snapBg = this.scene.background; if (snapBg && snapBg.isTexture && snapBg !== prev.bg) snapBg.dispose();
      this.scene.background = prev.bg;
      this.platform.visible = prev.plat; r.setClearAlpha(prev.ca);
      r.setPixelRatio(prev.pr); this.resize();
    }
  }

  destroy() {
    this._alive = false; cancelAnimationFrame(this._raf); this._ro.disconnect();
    if (this.model) disposeTree(this.model);
    this.controls.dispose(); this.envTex.dispose(); this.renderer.dispose(); this.renderer.forceContextLoss();
    this.renderer.domElement.remove();
  }
}
