import { t, setLang, getLang, LANGS } from './i18n.js';
import { db, uid, settings, deleteAllData } from './db.js';
import { $, $$, esc, toast, modal, pickFile, resizeImage, fmtDate, isImageFile } from './util.js';
import { icons, topbar, aiConsent, confirmBox, aiErrorMessage } from './ui.js';
import { DEFAULT_PARAMS } from './avatar.js';
import { CATEGORIES, clearClothingCaches, forgetOutfit, forgetBase } from './clothing.js';
import { renderEditor, renderOutfitMaker, renderExport, blobUrl, thumbUrlCache } from './editor.js';
import { generateModel, health } from './ai.js';

const app = document.getElementById('app');
const hist = []; let cleanup = null;
const nav = {
  beforeLeave: null,
  async go(name, params = {}) { if (!(await leaveOk())) return; hist.push({ name, params }); history.pushState({}, ''); await draw(); },
  async back() { if (!(await leaveOk())) return; if (hist.length > 1) hist.pop(); await draw(); },
  async replace(name, params = {}) { if (!(await leaveOk())) return; hist.pop(); hist.push({ name, params }); await draw(); },
};
async function leaveOk() { if (nav.beforeLeave) { const f = nav.beforeLeave; const ok = await f(); if (!ok) return false; nav.beforeLeave = null; } return true; }
window.addEventListener('popstate', () => nav.back());
app.addEventListener('click', (e) => { const b = e.target.closest('[data-act="back"]'); if (b) nav.back(); });

async function draw() {
  if (cleanup) { try { cleanup(); } catch {} cleanup = null; }
  nav.beforeLeave = null;
  const { name, params } = hist.at(-1);
  app.innerHTML = '';
  const host = document.createElement('div'); host.className = 'screen'; host.style.cssText = 'flex:1;min-height:0;display:flex;flex-direction:column'; app.appendChild(host);
  try {
    const r = await screens[name](host, params);
    if (typeof r === 'function') cleanup = r;
  } catch (e) { console.error(e); host.innerHTML = `<div class="empty">${esc(t('error_generic'))}<br><small>${esc(e.message || e)}</small></div>`; }
}

const newChar = (over = {}) => ({ id: uid(), name: '', created: Date.now(), updated: Date.now(), base: { type: 'procedural' }, params: { ...DEFAULT_PARAMS }, worn: [], ...over });
async function nextName() { const n = (await db.list('characters')).length + 1; return `${t('character')} ${n}`; }
const charCard = (c, acts) => `<div class="card"><div class="thumb">${c.preview ? `<img src="${blobUrl(c.preview)}" alt="">` : icons.person.replace('<svg', '<svg width="48" height="48" stroke="#c9a24b" fill="none"')}</div>
  <div class="meta"><b>${esc(c.name)}</b><span>${fmtDate(c.created, getLang())}</span></div><div class="acts">${acts}</div></div>`;

// ---------------- screens ----------------
const screens = {
  async splash(host) {
    host.className = 'screen splash'; host.innerHTML = `<img src="logo/logo-lockup.png" alt="Hyper Character Design"><div class="bar"><i></i></div>`;
    const tm = setTimeout(() => nav.replace('home'), 1500); return () => clearTimeout(tm);
  },

  async home(host) {
    host.innerHTML = `<div class="home-head"><img src="logo/logo-lockup.png" alt="Hyper Character Design"><button class="iconbtn" data-go="settings" aria-label="${esc(t('settings'))}">${icons.settings}</button></div>
    <div class="content pad-b">
      <button class="feature" data-go="newchar">${icons.person}<h3>${t('new_character')}</h3><p>${t('new_character_desc')}</p></button>
      <button class="feature" data-go="clothes">${icons.shirt}<h3>${t('change_clothes')}</h3><p>${t('change_clothes_desc')}</p></button>
      <div class="grid2"><button class="mini" data-go="characters">${icons.users}${t('my_characters')}</button><button class="mini" data-go="wardrobe">${icons.hanger}${t('my_wardrobe')}</button>
      <button class="mini" data-go="exportpick">${icons.export}${t('export_center')}</button><button class="mini" data-go="settings">${icons.settings}${t('settings')}</button></div></div>`;
    host.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-go]'); if (!b) return;
      if (b.dataset.go === 'exportpick') { const c = await pickCharacter(); if (c) nav.go('export', { id: c }); } else nav.go(b.dataset.go);
    });
  },

  async newchar(host) {
    let file = null, url = null;
    host.innerHTML = `${topbar(t('new_character'))}<div class="content pad-b"></div>`;
    const c = $('.content', host);
    const draw = () => {
      c.innerHTML = `<div class="h2" style="margin-top:0">${t('from_photo')}</div>
      ${url ? `<img class="preview" src="${url}" alt="">` : `<div class="drop muted">${t('photo_hint')}</div>`}
      <div class="row" style="margin-top:12px"><button class="btn small" data-src="gallery">${icons.image} ${t('gallery')}</button><button class="btn small" data-src="camera">${icons.camera} ${t('camera')}</button><button class="btn small" data-src="file">${icons.folder} ${t('files')}</button></div>
      <div class="note">${t('photo_privacy_note')}</div>
      <div class="progress" id="prog" style="display:none"><i></i></div><div id="pstat" class="muted" style="font-size:13px"></div>
      <div class="row"><button class="btn primary grow" data-gen ${file ? '' : 'disabled'}>${icons.spark} ${t('generate_ai')}</button><button class="btn" data-cancel style="display:none">${t('cancel')}</button></div>
      <div class="h2">${t('other_ways')}</div>
      <div class="row"><button class="btn grow" data-base>${icons.person} ${t('start_base')}</button><button class="btn grow" data-import>${icons.cube} ${t('import_glb')}</button></div>
      <div class="note">${t('base_note')}</div>`;
    };
    draw();
    let ctrl = null;
    const setFile = async (f) => {
      if (!f) return; if (!isImageFile(f)) return toast(t('bad_image'), true);
      if (url) URL.revokeObjectURL(url);
      file = f; url = URL.createObjectURL(f); draw();
    };
    c.addEventListener('click', async (e) => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.src) setFile(await pickFile(b.dataset.src === 'file' ? 'image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp' : 'image/*', b.dataset.src === 'camera' ? 'environment' : undefined));
      else if ('cancel' in b.dataset) ctrl?.abort();
      else if ('gen' in b.dataset) {
        if (!settings.get().backendUrl) { await needBackend(); return; }
        if (!(await aiConsent('photo'))) return;
        ctrl = new AbortController(); b.disabled = true; $('[data-cancel]', c).style.display = ''; $('#prog', c).style.display = '';
        try {
          const img = await resizeImage(file, 1280, 'image/jpeg', 0.9);
          $('#pstat', c).textContent = t('uploading');
          const glb = await generateModel('character', img, (p, s) => { $('#prog i', c).style.width = p + '%'; $('#pstat', c).textContent = t('ai_working') + ' ' + p + '%'; }, ctrl.signal);
          const ch = newChar({ name: await nextName(), base: { type: 'glb', blob: glb }, source: 'ai' });
          await db.put('characters', ch);
          if (url) { URL.revokeObjectURL(url); url = null; } file = null;   // temporary photo cleanup
          toast(t('character_created')); nav.replace('editor', { id: ch.id });
        } catch (err) { toast(aiErrorMessage(err), true); draw(); }
      } else if ('base' in b.dataset) {
        const ch = newChar({ name: await nextName() }); await db.put('characters', ch); nav.replace('editor', { id: ch.id });
      } else if ('import' in b.dataset) {
        const f = await pickFile(''); if (!f) return;
        if (!/\.glb$/i.test(f.name)) return toast(t('need_glb'), true);
        const ch = newChar({ name: f.name.replace(/\.glb$/i, '').slice(0, 40) || await nextName(), base: { type: 'glb', blob: f }, source: 'import' });
        await db.put('characters', ch); nav.replace('editor', { id: ch.id });
      }
    });
    return () => { ctrl?.abort(); if (url) URL.revokeObjectURL(url); };
  },

  async clothes(host) {
    const list = (await db.list('characters')).sort((a, b) => b.updated - a.updated);
    host.innerHTML = `${topbar(t('change_clothes'))}<div class="content pad-b"><div class="note">${t('pick_character_for_clothes')}</div>${list.length ? `<div class="cards">${list.map((c) => charCard(c, `<button class="btn small primary" data-pick="${c.id}">${t('select')}</button>`)).join('')}</div>` : `<div class="empty">${t('no_characters')}<br><br><button class="btn primary" data-go="newchar">${t('new_character')}</button></div>`}</div>`;
    host.addEventListener('click', (e) => {
      const p = e.target.closest('[data-pick]'); if (p) return nav.go('outfit', { characterId: p.dataset.pick, returnToEditor: false });
      if (e.target.closest('[data-go]')) nav.replace('newchar');
    });
  },

  async characters(host) {
    const draw = async () => {
      const list = (await db.list('characters')).sort((a, b) => b.updated - a.updated);
      $('.content', host).innerHTML = list.length ? `<div class="cards">${list.map((c) => charCard(c, `
        <button class="btn small primary" data-a="edit" data-id="${c.id}">${t('edit')}</button><button class="btn small" data-a="clothes" data-id="${c.id}">${t('clothes')}</button>
        <button class="btn small" data-a="dup" data-id="${c.id}">${t('duplicate')}</button><button class="btn small" data-a="export" data-id="${c.id}">${t('export')}</button>
        <button class="btn small danger" data-a="del" data-id="${c.id}">${t('delete')}</button>`)).join('')}</div>` : `<div class="empty">${t('no_characters')}<br><br><button class="btn primary" data-a="new">${t('new_character')}</button></div>`;
    };
    host.innerHTML = `${topbar(t('my_characters'), { right: `<button class="iconbtn" data-a="new" aria-label="${esc(t('new_character'))}">${icons.plus}</button>` })}<div class="content pad-b"></div>`;
    await draw();
    host.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-a]'); if (!b) return; const id = b.dataset.id, a = b.dataset.a;
      if (a === 'new') nav.go('newchar');
      else if (a === 'edit') nav.go('editor', { id });
      else if (a === 'clothes') nav.go('outfit', { characterId: id, returnToEditor: false });
      else if (a === 'export') nav.go('export', { id });
      else if (a === 'dup') { const c = await db.get('characters', id); await db.put('characters', { ...c, id: uid(), name: c.name + ' ' + t('copy_suffix'), created: Date.now(), updated: Date.now() }); toast(t('duplicated')); draw(); }
      else if (a === 'del') {
        const c = await db.get('characters', id);
        if (await confirmBox(t('delete_char_title'), t('delete_char_body', c.name), t('delete'))) { await db.del('characters', id); forgetBase(id); toast(t('deleted')); draw(); }
      }
    });
  },

  async wardrobe(host) {
    let cat = 'all';
    host.innerHTML = `${topbar(t('my_wardrobe'), { right: `<button class="iconbtn" data-a="new" aria-label="${esc(t('create_outfit'))}">${icons.plus}</button>` })}<div class="content pad-b"><div class="chips"></div><div id="list"></div></div>`;
    const draw = async () => {
      const all = (await db.list('outfits')).sort((a, b) => b.created - a.created);
      $('.chips', host).innerHTML = ['all', ...CATEGORIES].map((k) => `<button class="chip ${cat === k ? 'on' : ''}" data-cat="${k}">${t('cat_' + k)}</button>`).join('');
      const list = cat === 'all' ? all : all.filter((o) => o.category === cat);
      $('#list', host).innerHTML = list.length ? `<div class="cards">${list.map((o) => `<div class="card"><div class="thumb">${o.thumb ? `<img src="${blobUrl(o.thumb)}" alt="">` : ''}</div>
        <div class="meta"><b>${esc(o.name)}</b><span>${t('cat_' + o.category)} · ${o.kind === 'model' ? '3D' : t('image')}</span></div>
        <div class="acts"><button class="btn small primary" data-a="apply" data-id="${o.id}">${t('apply')}</button><button class="btn small" data-a="preview" data-id="${o.id}">${t('preview')}</button>
        <button class="btn small" data-a="rename" data-id="${o.id}">${t('rename')}</button><button class="btn small danger" data-a="del" data-id="${o.id}">${t('delete')}</button></div></div>`).join('')}</div>` : `<div class="empty">${t('wardrobe_empty')}<br><br><button class="btn primary" data-a="new">${t('create_outfit')}</button></div>`;
    };
    await draw();
    host.addEventListener('click', async (e) => {
      const ch = e.target.closest('[data-cat]'); if (ch) { cat = ch.dataset.cat; return draw(); }
      const b = e.target.closest('[data-a]'); if (!b) return; const a = b.dataset.a, id = b.dataset.id;
      if (a === 'new') return nav.go('outfit', { characterId: null });
      const o = await db.get('outfits', id); if (!o) return;
      if (a === 'apply') {
        const cid = await pickCharacter(); if (!cid) return;
        const c = await db.get('characters', cid); c.worn = (c.worn || []).filter((x) => x !== id); c.worn.push(id); c.updated = Date.now(); await db.put('characters', c);
        toast(t('outfit_applied')); nav.go('editor', { id: cid });
      } else if (a === 'preview') {
        await modal({ title: o.name, html: o.thumb ? `<img src="${blobUrl(o.thumb)}" style="width:100%;border-radius:12px" alt="">` : '', buttons: [{ label: t('close'), cls: 'primary', value: true }] });
      } else if (a === 'rename') {
        const r = await modal({ title: t('rename'), html: `<input type="text" id="rn" value="${esc(o.name)}" maxlength="40">`, buttons: [{ label: t('cancel'), value: null }, { label: t('save'), cls: 'primary', value: (m) => m.querySelector('#rn').value.trim() }] });
        if (r) { o.name = r; await db.put('outfits', o); draw(); }
      } else if (a === 'del') {
        if (await confirmBox(t('delete_outfit_title'), t('delete_outfit_body', o.name), t('delete'))) {
          await db.del('outfits', id); forgetOutfit(id);
          for (const c of await db.list('characters')) if ((c.worn || []).includes(id)) { c.worn = c.worn.filter((x) => x !== id); await db.put('characters', c); }
          toast(t('deleted')); draw();
        }
      }
    });
  },

  editor: (host, p) => renderEditor(host, p, nav),
  outfit: (host, p) => renderOutfitMaker(host, p, nav),
  export: (host, p) => renderExport(host, p, nav),

  async settings(host) {
    const s = settings.get();
    host.innerHTML = `${topbar(t('settings'))}<div class="content pad-b">
      <div class="h2" style="margin-top:0">${t('language')}</div>
      <div class="opts">${Object.entries(LANGS).map(([k, n]) => `<button class="opt ${s.lang === k ? 'on' : ''}" data-lang="${k}">${n}</button>`).join('')}</div>
      <div class="h2">${t('ai_backend')}</div>
      <input type="text" id="burl" inputmode="url" placeholder="https://your-backend.example.com" value="${esc(s.backendUrl)}">
      <div class="note">${t('backend_note')}</div>
      <div class="row"><button class="btn small" data-save-url>${t('save')}</button><button class="btn small" data-test>${t('test_connection')}</button></div><div id="testres" class="muted" style="margin-top:8px;font-size:13px"></div>
      <div class="h2">${t('render_quality')}</div>
      <div class="opts">${['auto', 'low', 'high'].map((q) => `<button class="opt ${s.quality === q ? 'on' : ''}" data-q="${q}">${t('q_' + q)}</button>`).join('')}</div>
      <div class="note">${t('quality_note')}</div>
      <div class="h2">${t('privacy_data')}</div>
      <div class="row"><button class="btn small" data-priv>${t('privacy_policy')}</button><button class="btn small" data-cache>${t('clear_cache')}</button><button class="btn small danger" data-wipe>${t('delete_all')}</button></div>
      <div class="h2">${t('about')}</div><div class="muted" style="font-size:13px">Hyper Character Design · v1.0.0<br>Three.js: ${window.__THREE_SOURCE === 'local' ? t('three_local') : t('three_cdn')}</div></div>`;
    host.addEventListener('click', async (e) => {
      const b = e.target.closest('button'); if (!b) return;
      if (b.dataset.lang) { await settings.set({ lang: b.dataset.lang }); setLang(b.dataset.lang); }
      else if (b.dataset.q) { await settings.set({ quality: b.dataset.q }); $$('[data-q]', host).forEach((x) => x.classList.toggle('on', x === b)); toast(t('quality_next')); }
      else if ('saveUrl' in b.dataset) { await settings.set({ backendUrl: $('#burl', host).value.trim() }); toast(t('saved')); }
      else if ('test' in b.dataset) {
        await settings.set({ backendUrl: $('#burl', host).value.trim() }); const r = $('#testres', host); r.textContent = '…';
        try { const h = await health(); r.textContent = h.configured ? t('test_ok', h.provider) : t('test_nokey'); }
        catch (err) { r.textContent = aiErrorMessage(err); }
      } else if ('priv' in b.dataset) nav.go('privacy');
      else if ('cache' in b.dataset) {
        clearClothingCaches(); thumbUrlCache.forEach((u) => URL.revokeObjectURL(u)); thumbUrlCache.clear();
        try { for (const k of await caches.keys()) await caches.delete(k); } catch {}
        toast(t('cache_cleared'));
      } else if ('wipe' in b.dataset) {
        if (await confirmBox(t('delete_all'), t('delete_all_body'), t('delete_all'))) { await deleteAllData(); clearClothingCaches(); hist.length = 0; hist.push({ name: 'home', params: {} }); setLang('en'); toast(t('deleted')); }
      }
    });
  },

  async privacy(host) {
    host.innerHTML = `${topbar(t('privacy_policy'))}<div class="content pad-b legal">${[1, 2, 3, 4, 5, 6].map((i) => `<h4>${t('priv_h' + i)}</h4><p>${t('priv_p' + i)}</p>`).join('')}</div>`;
  },
};

async function pickCharacter() {
  const list = (await db.list('characters')).sort((a, b) => b.updated - a.updated);
  if (!list.length) { toast(t('no_characters'), true); return null; }
  return modal({ title: t('select_character'), html: '', buttons: [...list.slice(0, 8).map((c) => ({ label: c.name, cls: 'primary', value: c.id })), { label: t('cancel'), value: null }] });
}

async function needBackend() {
  const r = await modal({ title: t('ai_setup_title'), html: `<p>${t('ai_setup_body')}</p>`, buttons: [{ label: t('close'), value: false }, { label: t('settings'), cls: 'primary', value: true }] });
  if (r) nav.go('settings');
}

// ---------------- boot ----------------
(async () => {
  try { await settings.load(); } catch (e) { console.warn('settings load failed', e); }
  setLang(settings.get().lang);
  window.addEventListener('hcd-lang', () => { if (hist.length && hist.at(-1).name !== 'splash') draw(); });
  hist.push({ name: 'splash', params: {} }); await draw();
})();
