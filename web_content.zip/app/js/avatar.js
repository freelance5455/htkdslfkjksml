// Built-in parametric human base body (procedural Three.js geometry).
// This is NOT an AI-generated model: it is the editable base mannequin used for customization and clothing.
import * as THREE from 'three';

export const DEFAULT_PARAMS = {
  height: 1.75, build: 0.5, shoulder: 0.5, legs: 0.5, headSize: 0.5,
  faceWidth: 0.5, faceLength: 0.5, jaw: 0.5, noseSize: 0.5, mouthWidth: 0.5,
  eyeSize: 0.5, eyeSpacing: 0.5, eyeShape: 'almond', eyeColor: '#4a3220',
  skinTone: '#c68a62', skinRough: 0.55,
  hairStyle: 'short', hairColor: '#1a120d',
  glasses: 'none', earrings: false, necklace: false, watch: false, hat: 'none',
  baseTop: '#2b2b33', baseBottom: '#1c1c22',
};

export const SKIN_TONES = ['#f6d9c3', '#ecc3a0', '#d9a37a', '#c68a62', '#a56c47', '#7d4d31', '#5a3623', '#3d2418'];
export const HAIR_COLORS = ['#0e0a08', '#1a120d', '#3b2416', '#6b4423', '#a87b3f', '#d8b36a', '#8c8c8c', '#e8e4da', '#7a2b1f', '#2c3e6b'];
export const EYE_COLORS = ['#2a1a10', '#4a3220', '#6b8e4e', '#3f7cac', '#7a8a99', '#8b6b2a'];
export const HAIR_STYLES = ['bald', 'buzz', 'short', 'long', 'bun', 'ponytail', 'curly'];
export const EYE_SHAPES = ['round', 'almond', 'narrow', 'big'];
export const GLASSES = ['none', 'round', 'square'];
export const HATS = ['none', 'cap'];

export const PRESETS = {
  neutral: {},
  male: { build: 0.6, shoulder: 0.72, legs: 0.5, jaw: 0.7, height: 1.78, headSize: 0.5, mouthWidth: 0.55, noseSize: 0.55 },
  female: { build: 0.4, shoulder: 0.3, legs: 0.62, jaw: 0.3, height: 1.66, headSize: 0.45, mouthWidth: 0.5, noseSize: 0.4, hairStyle: 'long' },
  athletic: { build: 0.62, shoulder: 0.8, legs: 0.55, height: 1.82 },
  slim: { build: 0.2, shoulder: 0.4, legs: 0.6, height: 1.72 },
  tall: { height: 1.92, legs: 0.7, build: 0.45 },
};

const lerp = (a, b, t) => a + (b - a) * t;
const mat = (color, rough = 0.6, metal = 0) => new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });

/** Body measurements derived from params (meters). Also used to fit clothing. */
export function measure(p) {
  const H = p.height;
  const bf = lerp(0.82, 1.28, p.build);
  const sf = lerp(0.88, 1.2, p.shoulder);
  const hh = 0.13 * H * lerp(0.9, 1.1, p.headSize);
  const legY = lerp(0.455, 0.49, p.legs);       // crotch height ratio
  return {
    H, bf, sf, hh, legY: legY * H,
    ankle: 0.045 * H, knee: 0.27 * H, hipTop: legY * H + 0.055 * H,
    waist: 0.62 * H, chest: 0.73 * H, shoulderY: 0.81 * H, neckBase: 0.83 * H,
    shoulderW: 0.112 * H * sf + 0.012 * H, hipX: 0.052 * H * bf,
    upperArm: 0.19 * H, foreArm: 0.17 * H, zScale: 0.62,
  };
}

/** radius (x half-width) of the torso at height y; torso is an ellipse (z scaled by zScale) */
export function torsoRadius(m, y) {
  const H = m.H;
  const pts = [
    [m.legY, 0.098 * H * m.bf], [m.hipTop, 0.108 * H * m.bf], [m.waist, 0.092 * H * lerp(0.9, 1.1, (m.bf - 0.82) / 0.46)],
    [m.chest, 0.104 * H * lerp(0.95, 1.05, (m.sf - 0.88) / 0.32) * lerp(0.92, 1.08, (m.bf - 0.82) / 0.46)],
    [m.shoulderY, 0.112 * H * m.sf], [m.neckBase - 0.008 * H, 0.07 * H], [m.neckBase + 0.012 * H, 0.03 * H],
  ];
  if (y <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    if (y <= pts[i][0]) {
      const t = (y - pts[i - 1][0]) / (pts[i][0] - pts[i - 1][0]);
      const s = t * t * (3 - 2 * t);
      return lerp(pts[i - 1][1], pts[i][1], s * 0.6 + t * 0.4);
    }
  }
  return pts[pts.length - 1][1];
}

export function lathe(m, y0, y1, grow, mater, steps = 26) {
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    const y = lerp(y0, y1, i / steps);
    pts.push(new THREE.Vector2(torsoRadius(m, y) + grow, y));
  }
  const g = new THREE.LatheGeometry(pts, 36);
  const mesh = new THREE.Mesh(g, mater);
  mesh.scale.z = m.zScale;
  return mesh;
}

function limb(rTop, rBot, len, mater) {
  const g = new THREE.CylinderGeometry(rTop, rBot, len, 18);
  g.translate(0, -len / 2, 0);
  return new THREE.Mesh(g, mater);
}

function hairColorMat(c) { return mat(c, 0.5, 0.05); }

/** Build the base body. Returns { group, parts, measure } */
export function buildAvatar(p) {
  p = { ...DEFAULT_PARAMS, ...p };
  const m = measure(p);
  const H = m.H, hh = m.hh;
  const g = new THREE.Group(); g.name = 'avatar';
  const skin = mat(p.skinTone, p.skinRough, 0);
  const parts = {};

  // torso
  const torso = lathe(m, m.legY, m.neckBase + 0.012 * H, 0, skin); torso.name = 'torso'; g.add(torso); parts.torso = torso;
  // neck
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.026 * H, 0.03 * H, 0.07 * H, 16), skin);
  neck.position.y = H - hh - 0.005 * H + 0.0; g.add(neck);

  // head
  const headC = H - hh / 2;
  const rx = hh * 0.40 * lerp(0.88, 1.14, p.faceWidth), ry = hh / 2 * lerp(0.94, 1.1, p.faceLength), rz = hh * 0.44;
  const head = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 24), skin);
  head.scale.set(rx, ry, rz); head.position.y = headC; g.add(head); parts.head = head;
  const jawW = hh * 0.30 * lerp(0.78, 1.2, p.jaw);
  const jaw = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 18), skin);
  jaw.scale.set(jawW, hh * 0.26, rz * 0.82); jaw.position.set(0, headC - ry * 0.52, hh * 0.04); g.add(jaw);
  const surfZ = (x, y) => rz * Math.sqrt(Math.max(0.05, 1 - (x / rx) ** 2 - ((y - headC) / ry) ** 2));
  // ears
  for (const s of [-1, 1]) {
    const e = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 10), skin);
    e.scale.set(hh * 0.035, hh * 0.09, hh * 0.05); e.position.set(s * rx * 0.99, headC - ry * 0.05, -rz * 0.05); g.add(e);
    if (p.earrings) {
      const r = new THREE.Mesh(new THREE.SphereGeometry(hh * 0.028, 12, 10), mat('#d4af37', 0.25, 0.9));
      r.position.set(s * rx * 1.0, headC - ry * 0.26, -rz * 0.05); g.add(r);
    }
  }
  // eyes
  const shapeY = { round: 1, almond: 0.72, narrow: 0.52, big: 1.15 }[p.eyeShape] || 1;
  const eyeR = hh * 0.05 * lerp(0.8, 1.35, p.eyeSize);
  const ex = hh * lerp(0.13, 0.22, p.eyeSpacing), ey = headC + ry * 0.08;
  for (const s of [-1, 1]) {
    const x = s * ex, z = surfZ(x, ey) - eyeR * 0.3;
    const eg = new THREE.Group(); eg.position.set(x, ey, z); eg.scale.set(1.15, shapeY, 1);
    const white = new THREE.Mesh(new THREE.SphereGeometry(eyeR, 16, 12), mat('#f4f1ea', 0.3));
    const iris = new THREE.Mesh(new THREE.SphereGeometry(eyeR * 0.62, 16, 12), mat(p.eyeColor, 0.25)); iris.position.z = eyeR * 0.5; iris.scale.z = 0.5;
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(eyeR * 0.3, 12, 10), mat('#050505', 0.2)); pupil.position.z = eyeR * 0.78; pupil.scale.z = 0.4;
    eg.add(white, iris, pupil); g.add(eg);
    const brow = new THREE.Mesh(new THREE.BoxGeometry(eyeR * 3, eyeR * 0.35, eyeR * 0.6), hairColorMat(p.hairColor));
    brow.position.set(x, ey + eyeR * 2.1, surfZ(x, ey + eyeR * 2.1) - eyeR * 0.1); brow.rotation.z = -s * 0.12; g.add(brow);
  }
  // nose
  const nose = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 12), skin);
  const ns = hh * 0.05 * lerp(0.75, 1.5, p.noseSize);
  nose.scale.set(ns * 0.9, ns * 1.5, ns * 1.2); nose.position.set(0, headC - ry * 0.13, surfZ(0, headC - ry * 0.13) + ns * 0.4); g.add(nose);
  // mouth
  const mw = hh * lerp(0.12, 0.22, p.mouthWidth);
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(mw, hh * 0.022, hh * 0.03), mat('#8a4b4b', 0.45));
  const my = headC - ry * 0.46; mouth.position.set(0, my, surfZ(0, my) - hh * 0.005); g.add(mouth);

  // hair
  addHair(g, p, { rx, ry, rz, headC, hh });
  addHat(g, p, { rx, ry, rz, headC, hh });
  addGlasses(g, p, { rx, ey, ex, eyeR, surfZ, hh });

  // arms
  const ar = 0.03 * H * lerp(0.85, 1.2, p.build);
  const arms = {};
  for (const s of [-1, 1]) {
    const arm = new THREE.Group(); arm.position.set(s * m.shoulderW, m.shoulderY - 0.01 * H, 0); arm.rotation.z = s * 0.16;
    const up = limb(ar, ar * 0.82, m.upperArm, skin);
    const elbow = new THREE.Mesh(new THREE.SphereGeometry(ar * 0.82, 14, 12), skin); elbow.position.y = -m.upperArm;
    const fore = new THREE.Group(); fore.position.y = -m.upperArm; fore.rotation.z = s * 0.03;
    const fa = limb(ar * 0.8, ar * 0.6, m.foreArm, skin);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 12), skin); hand.scale.set(ar * 0.7, ar * 1.15, ar * 0.45); hand.position.y = -m.foreArm - ar * 0.9;
    fore.add(fa, hand);
    if (p.watch && s === -1) {
      const w = new THREE.Mesh(new THREE.CylinderGeometry(ar * 0.72, ar * 0.72, ar * 0.7, 18), mat('#d4af37', 0.3, 0.85)); w.position.y = -m.foreArm * 0.88; fore.add(w);
    }
    arm.add(up, elbow, fore); arm.userData.fore = fore; g.add(arm);
    arms[s < 0 ? 'L' : 'R'] = arm;
  }
  parts.arms = arms;

  // legs
  const lr = 0.055 * H * lerp(0.85, 1.25, p.build);
  const thighLen = m.legY - m.knee, shinLen = m.knee - m.ankle;
  const legs = {};
  for (const s of [-1, 1]) {
    const leg = new THREE.Group(); leg.position.set(s * m.hipX, m.legY + 0.01 * H, 0); leg.rotation.z = -s * 0.025;
    const th = limb(lr, lr * 0.72, thighLen + 0.01 * H, skin);
    const kn = new THREE.Mesh(new THREE.SphereGeometry(lr * 0.72, 14, 12), skin); kn.position.y = -(thighLen + 0.01 * H);
    const shin = new THREE.Group(); shin.position.y = -(thighLen + 0.01 * H);
    const sh = limb(lr * 0.7, lr * 0.46, shinLen, skin);
    const foot = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 12), skin); foot.scale.set(lr * 0.5, lr * 0.32, lr * 1.2);
    foot.position.set(0, -shinLen - lr * 0.1, lr * 0.55);
    shin.add(sh, foot); leg.add(th, kn, shin); leg.userData.thighLen = thighLen; leg.userData.shin = shin; g.add(leg);
    legs[s < 0 ? 'L' : 'R'] = leg;
  }
  parts.legs = legs;

  // necklace
  if (p.necklace) {
    const n = new THREE.Mesh(new THREE.TorusGeometry(0.05 * H, 0.004 * H, 10, 36), mat('#d4af37', 0.25, 0.9));
    n.rotation.x = Math.PI / 2 - 0.35; n.position.y = m.neckBase - 0.015 * H; n.scale.y = 1.05; g.add(n);
  }
  g.userData.m = m;
  return { group: g, parts, measure: m };
}

function addHair(g, p, d) {
  const style = p.hairStyle; if (style === 'bald') return;
  const hm = hairColorMat(p.hairColor);
  const { rx, ry, rz, headC, hh } = d;
  const capLen = { buzz: 0.52, short: 0.58, long: 0.6, bun: 0.56, ponytail: 0.56, curly: 0.56 }[style] * Math.PI;
  const grow = style === 'buzz' ? 1.015 : 1.06;
  const cap = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 20, 0, Math.PI * 2, 0, capLen), hm);
  cap.scale.set(rx * grow, ry * grow, rz * grow); cap.position.set(0, headC + ry * 0.02, -rz * 0.04); cap.rotation.x = -0.28; g.add(cap);
  if (style === 'long') {
    const back = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 18), hm);
    back.scale.set(rx * 1.02, hh * 0.95, rz * 0.55); back.position.set(0, headC - hh * 0.5, -rz * 0.5); g.add(back);
    for (const s of [-1, 1]) { const side = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), hm); side.scale.set(hh * 0.07, hh * 0.7, rz * 0.45); side.position.set(s * rx * 0.98, headC - hh * 0.3, -rz * 0.15); g.add(side); }
  } else if (style === 'bun') {
    const bun = new THREE.Mesh(new THREE.SphereGeometry(hh * 0.17, 16, 14), hm); bun.position.set(0, headC + ry * 1.12, -rz * 0.2); g.add(bun);
  } else if (style === 'ponytail') {
    const tail = new THREE.Mesh(new THREE.CapsuleGeometry(hh * 0.07, hh * 0.7, 6, 12), hm); tail.position.set(0, headC - hh * 0.15, -rz * 1.1); tail.rotation.x = 0.25; g.add(tail);
  } else if (style === 'curly') {
    const n = 46; // deterministic ring of curls
    for (let i = 0; i < n; i++) {
      const a = (i * 2.399963) % (Math.PI * 2), b = Math.acos(1 - (i + 0.5) / n * 0.85);
      const c = new THREE.Mesh(new THREE.SphereGeometry(hh * 0.075, 8, 6), hm);
      c.position.set(Math.sin(b) * Math.cos(a) * rx * 1.08, headC + Math.cos(b) * ry * 1.05, Math.sin(b) * Math.sin(a) * rz * 1.0 - rz * 0.08); g.add(c);
    }
  }
}

function addHat(g, p, d) {
  if (p.hat !== 'cap') return;
  const { rx, ry, rz, headC } = d;
  const hm = mat('#222831', 0.7);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(1, 28, 16, 0, Math.PI * 2, 0, Math.PI * 0.52), hm);
  dome.scale.set(rx * 1.12, ry * 1.1, rz * 1.12); dome.position.set(0, headC + ry * 0.06, 0); g.add(dome);
  const brim = new THREE.Mesh(new THREE.CylinderGeometry(rx * 0.9, rx * 0.9, ry * 0.05, 24, 1, false, -Math.PI / 2, Math.PI), hm);
  brim.scale.z = 0.9; brim.position.set(0, headC + ry * 0.3, rz * 0.95); brim.rotation.x = 0.12; g.add(brim);
}

function addGlasses(g, p, d) {
  if (p.glasses === 'none') return;
  const { ey, ex, eyeR, surfZ, hh } = d;
  const fm = mat('#c9a24b', 0.25, 0.9);
  const lens = new THREE.MeshStandardMaterial({ color: '#9fb4c7', transparent: true, opacity: 0.22, roughness: 0.1 });
  const r = eyeR * 2.3;
  for (const s of [-1, 1]) {
    const x = s * ex, z = surfZ(x, ey) + eyeR * 0.6;
    let frame;
    if (p.glasses === 'round') frame = new THREE.Mesh(new THREE.TorusGeometry(r, hh * 0.007, 8, 28), fm);
    else { frame = new THREE.Mesh(new THREE.BoxGeometry(r * 2.1, r * 1.5, hh * 0.012), fm); frame.material = fm; }
    frame.position.set(x, ey, z); g.add(frame);
    const l = new THREE.Mesh(p.glasses === 'round' ? new THREE.CircleGeometry(r, 24) : new THREE.PlaneGeometry(r * 1.9, r * 1.35), lens);
    l.position.set(x, ey, z + 0.0005); g.add(l);
    const temple = new THREE.Mesh(new THREE.BoxGeometry(hh * 0.01, hh * 0.01, hh * 0.45), fm);
    temple.position.set(s * (ex + r), ey, z - hh * 0.22); g.add(temple);
  }
  const bridge = new THREE.Mesh(new THREE.BoxGeometry(ex * 2 - r * 2 + 0.01, hh * 0.01, hh * 0.01), fm);
  bridge.position.set(0, ey + r * 0.2, surfZ(0, ey) + eyeR * 0.6); g.add(bridge);
}

/** dispose geometry/materials of a tree unless flagged userData.keep (shared with a cache) */
export function disposeTree(root) {
  root.traverse((o) => {
    if (o.userData && o.userData.keep) return;
    if (o.geometry) o.geometry.dispose();
    if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((mm) => mm.dispose());
  });
}
