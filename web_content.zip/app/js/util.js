export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function toast(msg, err = false) {
  const root = document.getElementById('toast-root');
  const d = document.createElement('div'); d.className = 'toast' + (err ? ' err' : ''); d.textContent = msg; root.appendChild(d);
  setTimeout(() => d.remove(), err ? 5500 : 2800);
}

/** Modal. buttons: [{label, cls, value}] -> resolves with the clicked value (null if dismissed). */
export function modal({ title, html, buttons }) {
  return new Promise((res) => {
    const root = document.getElementById('modal-root');
    const bg = document.createElement('div'); bg.className = 'modal-bg';
    bg.innerHTML = `<div class="modal" role="dialog" aria-modal="true"><h3>${esc(title)}</h3><div class="mbody">${html || ''}</div><div class="row"></div></div>`;
    const row = bg.querySelector('.row');
    const close = (v) => { bg.remove(); res(v); };
    for (const b of buttons) {
      const el = document.createElement('button'); el.className = 'btn ' + (b.cls || ''); el.textContent = b.label;
      el.onclick = () => close(typeof b.value === 'function' ? b.value(bg) : b.value); row.appendChild(el);
    }
    bg.addEventListener('click', (e) => { if (e.target === bg) close(null); });
    root.appendChild(bg);
  });
}

export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export const safeName = (s) => (s || 'character').replace(/[^\p{L}\p{N}_-]+/gu, '_').slice(0, 40) || 'character';

export function fmtDate(ts, lang) {
  try { return new Intl.DateTimeFormat(lang === 'bn' ? 'bn-BD' : 'en-GB', { dateStyle: 'medium' }).format(new Date(ts)); } catch { return new Date(ts).toLocaleDateString(); }
}

/** Decode + downscale an image file to a JPEG/PNG Blob (keeps alpha for PNG/WEBP). */
export async function resizeImage(file, maxDim = 1280, type = 'image/jpeg', quality = 0.9) {
  const bmp = await createImageBitmap(file);
  const s = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas'); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
  const x = c.getContext('2d'); if (type === 'image/jpeg') { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); }
  x.drawImage(bmp, 0, 0, c.width, c.height); bmp.close?.();
  const blob = await new Promise((r) => c.toBlob(r, type, quality));
  c.width = c.height = 0;
  return blob;
}

export const blobToDataURL = (b) => new Promise((res, rej) => { const f = new FileReader(); f.onload = () => res(f.result); f.onerror = rej; f.readAsDataURL(b); });

export const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
export const isImageFile = (f) => IMAGE_TYPES.includes(f.type) || /\.(jpe?g|png|webp)$/i.test(f.name);

/** Create a small thumbnail Blob from a PNG blob */
export async function thumbOf(blob, size = 320) { return resizeImage(blob, size, 'image/jpeg', 0.82); }

/** Open the system file chooser. The input is attached to the page (required on many mobile browsers/WebViews).
 *  accept: MIME/extension list for images; pass '' to allow any file (use this for 3D models: Android greys out unknown types). */
export function pickFile(accept, capture) {
  return new Promise((res) => {
    const i = document.createElement('input'); i.type = 'file';
    if (accept) i.accept = accept; if (capture) i.setAttribute('capture', capture);
    i.style.cssText = 'position:fixed;left:-9999px;top:0;width:1px;height:1px;opacity:0';
    let done = false;
    const finish = (f) => { if (done) return; done = true; window.removeEventListener('focus', onFocus); setTimeout(() => i.remove(), 500); res(f); };
    const onFocus = () => setTimeout(() => { if (!done && !i.files.length) finish(null); }, 1500);   // chooser closed without a pick
    i.addEventListener('change', () => finish(i.files[0] || null));
    i.addEventListener('cancel', () => finish(null));
    document.body.appendChild(i);
    window.addEventListener('focus', onFocus);
    i.click();
  });
}
