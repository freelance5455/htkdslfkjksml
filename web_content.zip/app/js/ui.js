import { t } from './i18n.js';
import { Viewer } from './viewer.js';
import { modal, esc } from './util.js';

const I = (d) => `<svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
export const icons = {
  back: I('<path d="M15 5l-7 7 7 7"/>'),
  settings: I('<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7 7 0 0 0-2-1.2L14 3h-4l-.4 2.6a7 7 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 2 1.2L10 21h4l.4-2.6a7 7 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.2-.8.2-1.2z"/>'),
  person: I('<circle cx="12" cy="7" r="3.2"/><path d="M5.5 21v-3a6.5 6.5 0 0 1 13 0v3"/><path d="M9 21v-5M15 21v-5"/>'),
  shirt: I('<path d="M8 3l-5 3 2.5 4L8 9v12h8V9l2.5 1L21 6l-5-3a4 4 0 0 1-8 0z"/>'),
  users: I('<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a5 5 0 0 1 10 0v2"/><circle cx="17" cy="9" r="2.4"/><path d="M16 14.3A4.5 4.5 0 0 1 21 18.5V20"/>'),
  hanger: I('<path d="M12 7a2 2 0 1 0-2-2"/><path d="M12 7v2l9 6a1.5 1.5 0 0 1-.9 2.7H3.9A1.5 1.5 0 0 1 3 15l9-6"/>'),
  export: I('<path d="M12 15V3M7 8l5-5 5 5"/><path d="M4 14v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5"/>'),
  save: I('<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h7V3M8 21v-7h8v7"/>'),
  plus: I('<path d="M12 5v14M5 12h14"/>'),
  image: I('<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-5-8 8"/>'),
  camera: I('<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>'),
  folder: I('<path d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>'),
  cube: I('<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12L4 7.5M12 12v9"/>'),
  spark: I('<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 17l.8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8z"/>'),
};

/** Top bar markup */
export function topbar(title, { back = true, right = '' } = {}) {
  return `<div class="topbar">${back ? `<button class="iconbtn" data-act="back" aria-label="${esc(t('back'))}">${icons.back}</button>` : ''}<h1>${esc(title)}</h1>${right}</div>`;
}

/** Create the 3D stage (canvas + view pills) inside host. Returns the Viewer. */
export function mountStage(host) {
  host.innerHTML = `<div class="stage"><div class="overlay">
    <button class="pill" data-v="front">${t('view_front')}</button><button class="pill" data-v="side">${t('view_side')}</button>
    <button class="pill" data-v="back">${t('view_back')}</button><button class="pill on" data-v="full">${t('view_full')}</button>
    <button class="pill" data-v="face">${t('view_face')}</button>
    <button class="pill" data-z="0.75" aria-label="${esc(t('zoom_in'))}">＋</button><button class="pill" data-z="1.33" aria-label="${esc(t('zoom_out'))}">－</button>
    <button class="pill" data-rot>${t('auto_rotate')}</button></div></div>`;
  const stage = host.querySelector('.stage');
  const viewer = new Viewer(stage);
  stage.addEventListener('click', (e) => {
    const b = e.target.closest('.pill'); if (!b) return;
    if (b.dataset.v) { viewer.setView(b.dataset.v); stage.querySelectorAll('[data-v]').forEach((x) => x.classList.toggle('on', x === b)); }
    else if (b.dataset.z) viewer.zoom(Number(b.dataset.z));
    else if ('rot' in b.dataset) { const on = !viewer.controls.autoRotate; viewer.setAutoRotate(on); b.classList.toggle('on', on); }
  });
  return viewer;
}

/** Privacy consent shown before every AI request. Resolves true only if the user agrees. */
export async function aiConsent(kind) {
  const r = await modal({
    title: t('consent_title'),
    html: `<p>${t(kind === 'garment' ? 'consent_body_garment' : 'consent_body_photo')}</p><ul><li>${t('consent_1')}</li><li>${t('consent_2')}</li><li>${t('consent_3')}</li></ul>`,
    buttons: [{ label: t('cancel'), value: false }, { label: t('consent_agree'), cls: 'primary', value: true }],
  });
  return r === true;
}

export async function confirmBox(title, body, okLabel, danger = true) {
  return (await modal({ title, html: `<p>${esc(body)}</p>`, buttons: [{ label: t('cancel'), value: false }, { label: okLabel, cls: danger ? 'danger' : 'primary', value: true }] })) === true;
}

export const aiErrorMessage = (e) => {
  if (e?.name === 'AiNotConfigured') return t({ 'no-backend': 'ai_err_nobackend', unreachable: 'ai_err_unreachable', 'no-key': 'ai_err_nokey' }[e.message] || 'ai_err_nobackend');
  if (e?.name === 'AbortError') return t('cancelled');
  return t('ai_err_generic') + ' ' + (e?.message || '');
};
