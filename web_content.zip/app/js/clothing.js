// Clothing: parametric garments (image-textured) + imported 3D garment fitting + character composition.
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { buildAvatar, measure, torsoRadius, lathe, DEFAULT_PARAMS } from './avatar.js';

export const CATEGORIES = ['casual', 'formal', 'traditional', 'sportswear', 'partywear', 'custom'];
export const GARMENT_TYPES = ['top', 'bottom', 'dress', 'full'];
export const slotsFor = (g) => (g === 'top' ? ['top'] : g === 'bottom' ? ['bottom'] : ['top', 'bottom']);
const lerp = (a, b, t) => a + (b - a) * t;

const texCache = new Map();    // outfit id -> THREE.Texture
const modelCache = new Map();  // outfit id -> parsed Object3D
const baseCache = new Map();   // character id -> {key, root}

export function clearClothingCaches() { texCache.forEach((t) => t.dispose()); texCache.clear(); modelCache.clear(); baseCache.clear(); }
export function forgetOutfit(id) { texCache.get(id)?.dispose(); texCache.delete(id); modelCache.delete(id); }

function loadTexture(outfit) {
  if (texCache.has(outfit.id)) return Promise.resolve(texCache.get(outfit.id));
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(outfit.image);
    new THREE.TextureLoader().load(url, (t) => {
      t.colorSpace = THREE.SRGBColorSpace; t.wrapS = THREE.RepeatWrapping; t.offset.x = 0.5; t.anisotropy = 4;
      t.userData = { keep: true }; texCache.set(outfit.id, t); URL.revokeObjectURL(url); res(t);
    }, undefined, () => { URL.revokeObjectURL(url); rej(new Error('Could not decode clothing image')); });
  });
}

function garmentMat(outfit, tex) {
  const m = new THREE.MeshStandardMaterial({ map: tex || null, color: tex ? 0xffffff : (outfit.color || '#888888'), roughness: 0.85, metalness: 0, side: THREE.DoubleSide });
  return m;
}

const armR = (m) => 0.03 * m.H * lerp(0.85, 1.2, (m.bf - 0.82) / 0.46);
const legR = (m) => 0.055 * m.H * lerp(0.85, 1.25, (m.bf - 0.82) / 0.46);

function tube(rTop, rBot, len, mater, parent, y = 0) {
  const g = new THREE.CylinderGeometry(rTop, rBot, len, 20, 1, true); g.translate(0, -len / 2 + y, 0);
  const mesh = new THREE.Mesh(g, mater); parent.add(mesh); return mesh;
}

function addTop(root, parts, m, outfit, mater) {
  const grp = new THREE.Group(); grp.name = 'garment-top';
  grp.add(lathe(m, m.hipTop - 0.03 * m.H, m.neckBase + 0.006 * m.H, 0.012 * m.H, mater));
  root.add(grp);
  if (parts && outfit.sleeve !== 'none') {
    for (const side of ['L', 'R']) {
      const arm = parts.arms[side], r = armR(m) * 1.16;
      const s = tube(r, r * 0.86, outfit.sleeve === 'long' ? m.upperArm : m.upperArm * 0.55, mater, arm); s.name = 'garment-sleeve';
      if (outfit.sleeve === 'long') { const f = tube(r * 0.86, r * 0.7, m.foreArm * 0.95, mater, arm.userData.fore); f.name = 'garment-sleeve'; }
    }
  }
  return grp;
}

function addLegs(root, parts, m, outfit, mater, hem) {
  const lr = legR(m) * 1.12, thigh = m.legY - m.knee + 0.01 * m.H, shin = m.knee - m.ankle;
  for (const side of ['L', 'R']) {
    let leg = parts?.legs[side];
    if (!leg) { leg = new THREE.Group(); leg.position.set((side === 'L' ? -1 : 1) * m.hipX, m.legY + 0.01 * m.H, 0); root.add(leg); leg.userData.shin = new THREE.Group(); leg.userData.shin.position.y = -thigh; leg.add(leg.userData.shin); }
    tube(lr, lr * 0.74, hem === 'long' ? thigh : thigh * 0.62, mater, leg);
    if (hem === 'long') tube(lr * 0.72, lr * 0.5, shin * 0.97, mater, leg.userData.shin);
  }
}

function addBottom(root, parts, m, outfit, mater) {
  const grp = new THREE.Group(); grp.name = 'garment-bottom';
  grp.add(lathe(m, m.legY - 0.004 * m.H, m.waist + 0.005 * m.H, 0.014 * m.H, mater, 12));
  root.add(grp);
  addLegs(root, parts, m, outfit, mater, outfit.hem === 'short' ? 'short' : 'long');
  return grp;
}

function addDress(root, parts, m, outfit, mater) {
  const grp = new THREE.Group(); grp.name = 'garment-top';
  const yEnd = outfit.hem === 'long' ? m.ankle + 0.04 * m.H : m.knee + 0.06 * m.H;
  const pts = [], steps = 34, yTop = m.neckBase + 0.006 * m.H, grow = 0.014 * m.H;
  for (let i = 0; i <= steps; i++) {
    const y = lerp(yEnd, yTop, i / steps);
    let r;
    if (y >= m.legY) r = torsoRadius(m, y) + grow;
    else r = torsoRadius(m, m.legY) + grow + (m.legY - y) * 0.42;
    pts.push(new THREE.Vector2(r, y));
  }
  const mesh = new THREE.Mesh(new THREE.LatheGeometry(pts, 40), mater); mesh.scale.z = m.zScale + 0.18; grp.add(mesh); root.add(grp);
  if (parts && outfit.sleeve !== 'none') {
    for (const side of ['L', 'R']) {
      const arm = parts.arms[side], r = armR(m) * 1.16;
      tube(r, r * 0.86, outfit.sleeve === 'long' ? m.upperArm : m.upperArm * 0.55, mater, arm);
      if (outfit.sleeve === 'long') tube(r * 0.86, r * 0.7, m.foreArm * 0.95, mater, arm.userData.fore);
    }
  }
}

function addBaseLayer(root, parts, m, p, wearTop, wearBottom) {
  if (!wearTop) {
    const mt = new THREE.MeshStandardMaterial({ color: p.baseTop, roughness: 0.85, side: THREE.DoubleSide });
    addTop(root, parts, m, { sleeve: 'short' }, mt).userData.base = true;
  }
  if (!wearBottom) {
    const mb = new THREE.MeshStandardMaterial({ color: p.baseBottom, roughness: 0.85, side: THREE.DoubleSide });
    addBottom(root, parts, m, { hem: 'short' }, mb);
  }
}

// ---------- 3D garment files ----------
export const MODEL_FORMATS = ['glb', 'gltf', 'obj', 'fbx'];
export const extOf = (n) => (n.split('.').pop() || '').toLowerCase();

export async function parseModel(buf, format) {
  format = format.toLowerCase();
  if (format === 'glb' || format === 'gltf') {
    const gltf = await new GLTFLoader().parseAsync(buf, '');
    return gltf.scene;
  }
  if (format === 'obj') {
    const { OBJLoader } = await import('three/addons/loaders/OBJLoader.js');
    const obj = new OBJLoader().parse(new TextDecoder().decode(buf));
    obj.traverse((o) => { if (o.isMesh && !o.material.map) { o.material = new THREE.MeshStandardMaterial({ color: '#9a9a9a', roughness: 0.8, side: THREE.DoubleSide }); } });
    return obj;
  }
  if (format === 'fbx') {
    const { FBXLoader } = await import('three/addons/loaders/FBXLoader.js');
    return new FBXLoader().parse(buf, '');
  }
  throw new Error('Unsupported format: ' + format);
}

async function loadGarmentModel(outfit) {
  if (!modelCache.has(outfit.id)) {
    const buf = await outfit.model.blob.arrayBuffer();
    const o = await parseModel(buf, outfit.model.format);
    o.traverse((x) => { x.userData.keep = true; });
    modelCache.set(outfit.id, o);
  }
  return modelCache.get(outfit.id).clone(true);
}

function fitTargets(garment, m) {
  const H = m.H;
  const w = (2 * m.shoulderW + 0.1 * H);
  switch (garment) {
    case 'top': return { y0: m.hipTop - 0.03 * H, y1: m.neckBase + 0.01 * H, w };
    case 'bottom': return { y0: m.ankle * 0.5, y1: m.waist + 0.01 * H, w: 4.4 * m.hipX };
    case 'dress': return { y0: m.knee * 0.5, y1: m.neckBase + 0.01 * H, w };
    default: return { y0: 0.01 * H, y1: m.neckBase + 0.02 * H, w };
  }
}

async function addModelGarment(root, m, outfit) {
  const obj = await loadGarmentModel(outfit);
  const wrap = new THREE.Group(); wrap.name = 'garment-model'; wrap.userData.slotModel = true;
  wrap.add(obj);
  const a = { scale: 1, x: 0, y: 0, z: 0, rotY: 0, ...(outfit.adjust || {}) };
  obj.rotation.y = THREE.MathUtils.degToRad(a.rotY);
  obj.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(obj), size = box.getSize(new THREE.Vector3()), c = box.getCenter(new THREE.Vector3());
  const t = fitTargets(outfit.garment, m);
  let s = (t.y1 - t.y0) / Math.max(size.y, 1e-6);
  if (size.x * s > t.w * 1.4) s *= (t.w * 1.4) / (size.x * s);
  s *= a.scale;
  obj.scale.setScalar(s);
  obj.position.set(-c.x * s, -box.min.y * s, -c.z * s); // feet-line at 0, centered
  wrap.position.set(a.x * m.H, t.y0 + a.y * m.H, a.z * m.H);
  root.add(wrap);
}

// ---------- base model (GLB / AI-generated character) ----------
async function loadBaseModel(character) {
  const key = character.id + ':' + character.base.blob.size;
  const c = baseCache.get(character.id);
  if (c && c.key === key) return c.root;
  const buf = await character.base.blob.arrayBuffer();
  const root = await parseModel(buf, 'glb');
  root.traverse((x) => { x.userData.keep = true; });
  const box = new THREE.Box3().setFromObject(root), size = box.getSize(new THREE.Vector3()), cc = box.getCenter(new THREE.Vector3());
  const holder = new THREE.Group(); holder.add(root);
  root.position.set(-cc.x, -box.min.y, -cc.z);
  holder.userData = { keep: false, size: size.y };
  holder.userData.keepHolder = true;
  baseCache.set(character.id, { key, root: holder });
  return holder;
}

export const forgetBase = (id) => baseCache.delete(id);

/**
 * Build the full renderable character: base body + worn outfits.
 * character: {id, base:{type:'procedural'}|{type:'glb', blob}, params, worn:[outfitId]}
 * outfits: array of outfit records (already looked up)
 */
export async function composeCharacter(character, outfits = []) {
  const root = new THREE.Group(); root.name = 'character';
  const p = { ...DEFAULT_PARAMS, ...(character.params || {}) };
  let parts = null, m;
  if (character.base?.type === 'glb') {
    const base = await loadBaseModel(character);
    root.add(base);
    const H = base.userData.size || 1.75;
    m = measure({ ...DEFAULT_PARAMS, height: H });
  } else {
    const av = buildAvatar(p); root.add(av.group); parts = av.parts; m = av.measure;
  }
  // resolve worn outfits -> slot map
  const slotTop = [], slotBottom = [], models = [];
  for (const o of outfits) {
    if (!o) continue;
    if (o.kind === 'model') { models.push(o); continue; }
    if (o.garment === 'top') slotTop.push(o);
    else if (o.garment === 'bottom') slotBottom.push(o);
    else { slotTop.push(o); slotBottom.length = 0; }
  }
  const wornTop = slotTop.at(-1), wornBottom = slotBottom.at(-1);
  const modelCovers = (g) => models.some((o) => slotsFor(o.garment).includes(g));
  if (character.base?.type !== 'glb') {
    addBaseLayer(root, parts, m, p, !!wornTop || modelCovers('top'), !!wornBottom || modelCovers('bottom') || wornTop?.garment === 'dress');
  }
  const errors = [];
  if (wornTop) {
    try {
      const tex = wornTop.image ? await loadTexture(wornTop) : null; const mater = garmentMat(wornTop, tex);
      (wornTop.garment === 'dress' ? addDress : addTop)(root, parts, m, wornTop, mater);
    } catch (e) { errors.push(e.message); }
  }
  if (wornBottom && wornTop?.garment !== 'dress') {
    try { const tex = wornBottom.image ? await loadTexture(wornBottom) : null; addBottom(root, parts, m, wornBottom, garmentMat(wornBottom, tex)); } catch (e) { errors.push(e.message); }
  }
  for (const o of models) { try { await addModelGarment(root, m, o); } catch (e) { errors.push(`${o.name}: ${e.message}`); } }
  root.userData.errors = errors;
  root.userData.measure = m;
  return root;
}
