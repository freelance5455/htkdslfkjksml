// IndexedDB wrapper: characters, outfits, settings. Blobs are stored directly (no base64).
const DB_NAME = 'hyper-character-design';
const DB_VER = 1;
let _db;

function open() {
  if (_db) return Promise.resolve(_db);
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB_NAME, DB_VER);
    r.onupgradeneeded = () => {
      const d = r.result;
      if (!d.objectStoreNames.contains('characters')) d.createObjectStore('characters', { keyPath: 'id' });
      if (!d.objectStoreNames.contains('outfits')) d.createObjectStore('outfits', { keyPath: 'id' });
      if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv');
    };
    r.onsuccess = () => { _db = r.result; res(_db); };
    r.onerror = () => rej(r.error);
  });
}

async function tx(store, mode, fn) {
  const d = await open();
  return new Promise((res, rej) => {
    const t = d.transaction(store, mode);
    const s = t.objectStore(store);
    let out;
    const rq = fn(s);
    if (rq) rq.onsuccess = () => { out = rq.result; };
    t.oncomplete = () => res(out);
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error);
  });
}

export const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2));

export const db = {
  list: (store) => tx(store, 'readonly', (s) => s.getAll()),
  get: (store, id) => tx(store, 'readonly', (s) => s.get(id)),
  put: (store, obj) => tx(store, 'readwrite', (s) => s.put(obj)),
  del: (store, id) => tx(store, 'readwrite', (s) => s.delete(id)),
  clear: (store) => tx(store, 'readwrite', (s) => s.clear()),
  kvGet: (k) => tx('kv', 'readonly', (s) => s.get(k)),
  kvSet: (k, v) => tx('kv', 'readwrite', (s) => s.put(v, k)),
};

export const DEFAULT_SETTINGS = { lang: 'en', backendUrl: '', quality: 'auto', consentRemembered: false, keepPhoto: false };

let _settings = { ...DEFAULT_SETTINGS };
export const settings = {
  get: () => _settings,
  async load() { _settings = { ...DEFAULT_SETTINGS, ...((await db.kvGet('settings')) || {}) }; return _settings; },
  async set(patch) { _settings = { ..._settings, ...patch }; await db.kvSet('settings', _settings); return _settings; },
};

export async function deleteAllData() {
  await db.clear('characters'); await db.clear('outfits'); await db.clear('kv');
  _settings = { ...DEFAULT_SETTINGS };
}
