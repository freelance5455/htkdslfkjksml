// UI strings: key -> [English, Bengali]. Add a language by adding a third column and an entry in LANGS.
export const LANGS = { en: 'English', bn: 'বাংলা' };
const ORDER = ['en', 'bn'];
let lang = 'en';

const S = {
  // general
  back: ['Back', 'পিছনে'], cancel: ['Cancel', 'বাতিল'], close: ['Close', 'বন্ধ করুন'], save: ['Save', 'সংরক্ষণ'], saved: ['Saved', 'সংরক্ষিত হয়েছে'],
  save_failed: ['Could not save:', 'সংরক্ষণ করা যায়নি:'], delete: ['Delete', 'মুছুন'], deleted: ['Deleted', 'মুছে ফেলা হয়েছে'], edit: ['Edit', 'এডিট'],
  duplicate: ['Duplicate', 'ডুপ্লিকেট'], duplicated: ['Duplicated', 'ডুপ্লিকেট করা হয়েছে'], copy_suffix: ['(copy)', '(কপি)'], rename: ['Rename', 'নাম বদলান'],
  export: ['Export', 'এক্সপোর্ট'], select: ['Select', 'নির্বাচন'], select_character: ['Select a character', 'একটি ক্যারেক্টার বেছে নিন'], apply: ['Apply', 'পরান'],
  preview: ['Preview', 'প্রিভিউ'], remove: ['Remove', 'সরান'], reset: ['Reset', 'রিসেট'], discard: ['Discard', 'বাদ দিন'], on: ['On', 'চালু'], off: ['Off', 'বন্ধ'],
  image: ['Image', 'ছবি'], character: ['Character', 'ক্যারেক্টার'], clothes: ['Clothes', 'পোশাক'], cancelled: ['Cancelled', 'বাতিল করা হয়েছে'],
  not_found: ['Item not found', 'পাওয়া যায়নি'], error_generic: ['Something went wrong.', 'কিছু একটা ভুল হয়েছে।'],
  // home
  new_character: ['New Character', 'নতুন ক্যারেক্টার'], new_character_desc: ['Create a realistic 3D human from a photo or start from the base body.', 'ছবি থেকে বাস্তবসম্মত ৩ডি মানুষ তৈরি করুন, অথবা বেস বডি দিয়ে শুরু করুন।'],
  change_clothes: ['Change of Clothes', 'পোশাক বদল'], change_clothes_desc: ['Dress a character from a clothing photo or a 3D garment file.', 'পোশাকের ছবি বা ৩ডি পোশাকের ফাইল দিয়ে ক্যারেক্টারকে সাজান।'],
  my_characters: ['My Characters', 'আমার ক্যারেক্টার'], my_wardrobe: ['My Wardrobe', 'আমার ওয়ার্ডরোব'], export_center: ['Export Center', 'এক্সপোর্ট সেন্টার'], settings: ['Settings', 'সেটিংস'],
  // new character
  from_photo: ['Generate from a photo (AI)', 'ছবি থেকে তৈরি (এআই)'], photo_hint: ['Choose a JPG, PNG or WEBP photo of a person.', 'একজন মানুষের JPG, PNG বা WEBP ছবি বেছে নিন।'],
  gallery: ['Gallery', 'গ্যালারি'], camera: ['Camera', 'ক্যামেরা'], files: ['Files', 'ফাইল'],
  photo_privacy_note: ['Your photo is only sent after you agree. It is previewed here first and deleted from the app after processing.', 'আপনি সম্মতি দিলেই ছবি পাঠানো হবে। আগে এখানে প্রিভিউ দেখা যায় এবং প্রক্রিয়া শেষে অ্যাপ থেকে মুছে ফেলা হয়।'],
  generate_ai: ['Generate 3D character', '৩ডি ক্যারেক্টার তৈরি করুন'], other_ways: ['Other ways to start', 'শুরু করার অন্য উপায়'],
  start_base: ['Use base body', 'বেস বডি ব্যবহার করুন'], import_glb: ['Import GLB model', 'GLB মডেল ইমপোর্ট'],
  base_note: ['The base body is a built-in editable mannequin, not generated from a photo. Hair, face, skin, body and accessories can be customized on it.', 'বেস বডি হলো অ্যাপের নিজস্ব এডিটযোগ্য মডেল, ছবি থেকে তৈরি নয়। এতে চুল, মুখ, ত্বক, শরীর ও অ্যাক্সেসরি কাস্টমাইজ করা যায়।'],
  bad_image: ['Please choose a JPG, PNG or WEBP image.', 'দয়া করে JPG, PNG বা WEBP ছবি বেছে নিন।'], need_glb: ['Please choose a .glb file.', 'দয়া করে একটি .glb ফাইল বেছে নিন।'],
  uploading: ['Uploading…', 'আপলোড হচ্ছে…'], ai_working: ['AI is working…', 'এআই কাজ করছে…'], character_created: ['Character created', 'ক্যারেক্টার তৈরি হয়েছে'],
  // consent / ai
  consent_title: ['Send to AI service?', 'এআই সার্ভিসে পাঠাবেন?'],
  consent_body_photo: ['Your photo will be sent to the AI backend you configured, which forwards it to an external AI provider to build the 3D model.', 'আপনার ছবি আপনার কনফিগার করা এআই ব্যাকএন্ডে পাঠানো হবে, যা ৩ডি মডেল তৈরির জন্য একটি বাইরের এআই প্রদানকারীর কাছে পাঠায়।'],
  consent_body_garment: ['Your clothing image will be sent to the AI backend you configured, which forwards it to an external AI provider to build a 3D garment.', 'আপনার পোশাকের ছবি আপনার কনফিগার করা এআই ব্যাকএন্ডে পাঠানো হবে, যা ৩ডি পোশাক তৈরির জন্য একটি বাইরের এআই প্রদানকারীর কাছে পাঠায়।'],
  consent_1: ['The app does not store the original image after processing.', 'প্রক্রিয়া শেষে অ্যাপ মূল ছবি সংরক্ষণ করে না।'],
  consent_2: ['The provider processes it under its own terms and retention rules.', 'প্রদানকারী নিজস্ব শর্ত ও সংরক্ষণ নীতি অনুযায়ী এটি প্রক্রিয়া করে।'],
  consent_3: ['Only use photos of people who agreed, or yourself.', 'শুধু নিজের বা সম্মতি দিয়েছেন এমন ব্যক্তির ছবি ব্যবহার করুন।'],
  consent_agree: ['I agree, continue', 'সম্মত, এগিয়ে যান'],
  ai_setup_title: ['AI backend not set up', 'এআই ব্যাকএন্ড সেট করা নেই'],
  ai_setup_body: ['Generating a character from a photo needs the AI backend (server/server.js) running with a provider API key. Enter its address in Settings. No result is faked: without it, this feature stays off. You can still use the base body or import a GLB.', 'ছবি থেকে ক্যারেক্টার তৈরির জন্য এআই ব্যাকএন্ড (server/server.js) প্রোভাইডারের API কী সহ চালু থাকতে হবে। এর ঠিকানা সেটিংসে দিন। কোনো ফলাফল নকল করা হয় না: ব্যাকএন্ড ছাড়া এই সুবিধা বন্ধ থাকে। তবে বেস বডি বা GLB ইমপোর্ট ব্যবহার করতে পারবেন।'],
  ai_err_nobackend: ['AI backend address is not set (Settings).', 'এআই ব্যাকএন্ডের ঠিকানা দেওয়া নেই (সেটিংস)।'],
  ai_err_unreachable: ['Could not reach the AI backend. Check the address and your internet.', 'এআই ব্যাকএন্ডে পৌঁছানো যায়নি। ঠিকানা ও ইন্টারনেট পরীক্ষা করুন।'],
  ai_err_nokey: ['The AI backend is running but has no provider API key.', 'এআই ব্যাকএন্ড চালু আছে কিন্তু প্রোভাইডারের API কী নেই।'],
  ai_err_generic: ['AI request failed.', 'এআই অনুরোধ ব্যর্থ হয়েছে।'],
  // characters / wardrobe
  no_characters: ['No characters yet.', 'এখনো কোনো ক্যারেক্টার নেই।'], delete_char_title: ['Delete character?', 'ক্যারেক্টার মুছবেন?'],
  delete_char_body: ['"{0}" will be permanently deleted from this device.', '"{0}" এই ডিভাইস থেকে স্থায়ীভাবে মুছে যাবে।'],
  delete_outfit_title: ['Delete outfit?', 'পোশাক মুছবেন?'], delete_outfit_body: ['"{0}" will be permanently deleted.', '"{0}" স্থায়ীভাবে মুছে যাবে।'],
  pick_character_for_clothes: ['Choose the character to dress.', 'কোন ক্যারেক্টারকে সাজাবেন তা বেছে নিন।'],
  wardrobe_empty: ['Your wardrobe is empty.', 'আপনার ওয়ার্ডরোব খালি।'], create_outfit: ['Create outfit', 'নতুন পোশাক বানান'],
  outfit_applied: ['Outfit applied', 'পোশাক পরানো হয়েছে'], untitled_outfit: ['Untitled outfit', 'নামহীন পোশাক'],
  cat_all: ['All', 'সব'], cat_casual: ['Casual', 'ক্যাজুয়াল'], cat_formal: ['Formal', 'ফর্মাল'], cat_traditional: ['Traditional', 'ঐতিহ্যবাহী'],
  cat_sportswear: ['Sportswear', 'স্পোর্টসওয়্যার'], cat_partywear: ['Partywear', 'পার্টিওয়্যার'], cat_custom: ['Custom', 'কাস্টম'],
  // outfit maker
  method_image: ['Clothing image', 'পোশাকের ছবি'], method_model: ['3D clothing file', '৩ডি পোশাকের ফাইল'],
  upload_clothing_img: ['Upload clothing image', 'পোশাকের ছবি আপলোড'], image_loaded: ['Image loaded', 'ছবি লোড হয়েছে'], upload_3d: ['Import 3D garment', '৩ডি পোশাক ইমপোর্ট'],
  basic_wrap_note: ['Basic fit (no AI): the image is wrapped as a texture on a garment shape fitted to the body, so colors and patterns are kept but the cut is generic. For a real 3D garment use “Reconstruct with AI”.', 'বেসিক ফিট (এআই ছাড়া): ছবিটি শরীরের মাপে তৈরি পোশাকের আকৃতির ওপর টেক্সচার হিসেবে মোড়ানো হয়, তাই রং ও প্যাটার্ন থাকে কিন্তু কাটিং সাধারণ। আসল ৩ডি পোশাকের জন্য “এআই দিয়ে তৈরি” ব্যবহার করুন।'],
  ai_reconstruct: ['Reconstruct with AI', 'এআই দিয়ে ৩ডি তৈরি'], ai_garment_hint: ['Creates a 3D object from the image; you then fit it with the sliders.', 'ছবি থেকে ৩ডি অবজেক্ট তৈরি করে; তারপর স্লাইডার দিয়ে ফিট করুন।'],
  ai_not_set_hint: ['Needs the AI backend (Settings).', 'এআই ব্যাকএন্ড লাগবে (সেটিংস)।'], ai_garment_done: ['3D garment created. Adjust the fit below.', '৩ডি পোশাক তৈরি হয়েছে। নিচে ফিট ঠিক করুন।'],
  model_note: ['Formats: GLB, GLTF, OBJ, FBX. GLB keeps its own colors and textures. OBJ materials (.mtl) and external GLTF files are not loaded; use GLB when possible.', 'ফরম্যাট: GLB, GLTF, OBJ, FBX। GLB নিজের রং ও টেক্সচার ধরে রাখে। OBJ-এর মেটেরিয়াল (.mtl) ও আলাদা GLTF ফাইল লোড হয় না; সম্ভব হলে GLB ব্যবহার করুন।'],
  gltf_note: ['GLTF with external files may not load fully; GLB is recommended.', 'বাইরের ফাইলসহ GLTF পুরোপুরি লোড নাও হতে পারে; GLB ভালো।'],
  bad_model: ['Unsupported file. Use GLB, GLTF, OBJ or FBX.', 'এই ফাইল সমর্থিত নয়। GLB, GLTF, OBJ বা FBX ব্যবহার করুন।'],
  garment_type: ['Garment type', 'পোশাকের ধরন'], gt_top: ['Top', 'উপরের অংশ'], gt_bottom: ['Bottom', 'নিচের অংশ'], gt_dress: ['Dress', 'ড্রেস'], gt_full: ['Full outfit', 'পূর্ণ পোশাক'],
  sleeve: ['Sleeves', 'হাতা'], sl_none: ['None', 'নেই'], sl_short: ['Short', 'ছোট'], sl_long: ['Long', 'লম্বা'], hem: ['Length', 'দৈর্ঘ্য'], hem_short: ['Short', 'ছোট'], hem_long: ['Long', 'লম্বা'],
  adjust_outfit: ['Adjust outfit', 'পোশাক অ্যাডজাস্ট'], adj_scale: ['Size', 'আকার'], adj_x: ['Left / right', 'বামে / ডানে'], adj_y: ['Up / down', 'উপরে / নিচে'], adj_z: ['Forward / back', 'সামনে / পিছনে'], adj_rotY: ['Rotate', 'ঘোরান'],
  no_cloth_sim: ['Cloth simulation is not included; garments are fitted by size and position only.', 'ক্লথ সিমুলেশন নেই; পোশাক শুধু মাপ ও অবস্থান দিয়ে ফিট করা হয়।'],
  outfit_name: ['Outfit name', 'পোশাকের নাম'], outfit_name_ph: ['e.g. Blue kurta', 'যেমন: নীল পাঞ্জাবি'], category: ['Category', 'ক্যাটেগরি'],
  save_and_wear: ['Save & wear', 'সংরক্ষণ করে পরান'], save_wardrobe: ['Save to wardrobe', 'ওয়ার্ডরোবে সংরক্ষণ'], need_clothing: ['Add a clothing image or 3D file first.', 'আগে পোশাকের ছবি বা ৩ডি ফাইল দিন।'],
  outfit_saved: ['Outfit saved to wardrobe', 'পোশাক ওয়ার্ডরোবে সংরক্ষিত হয়েছে'], outfit_saved_worn: ['Outfit saved and worn', 'পোশাক সংরক্ষণ করে পরানো হয়েছে'],
  // editor
  tab_hair: ['Hair', 'চুল'], tab_face: ['Face', 'মুখ'], tab_skin: ['Skin', 'ত্বক'], tab_body: ['Body', 'শরীর'], tab_eyes: ['Eyes', 'চোখ'], tab_acc: ['Accessories', 'অ্যাক্সেসরি'],
  tab_outfit: ['Outfit', 'পোশাক'], tab_presets: ['Presets', 'প্রিসেট'], tab_scene: ['Scene', 'দৃশ্য'],
  p_hairStyle: ['Hairstyle', 'হেয়ারস্টাইল'], p_hairColor: ['Hair color', 'চুলের রং'], p_faceWidth: ['Face width', 'মুখের প্রস্থ'], p_faceLength: ['Face length', 'মুখের দৈর্ঘ্য'], p_jaw: ['Jaw', 'চোয়াল'],
  p_noseSize: ['Nose size', 'নাকের আকার'], p_mouthWidth: ['Mouth width', 'মুখের চওড়া ভাব'], p_skinTone: ['Skin tone', 'ত্বকের রং'], p_skinRough: ['Skin roughness (matte ↔ glossy)', 'ত্বকের খসখসে ভাব (ম্যাট ↔ চকচকে)'],
  p_height: ['Height', 'উচ্চতা'], p_build: ['Build', 'গড়ন'], p_shoulder: ['Shoulders', 'কাঁধ'], p_legs: ['Leg length', 'পায়ের দৈর্ঘ্য'], p_headSize: ['Head size', 'মাথার আকার'],
  p_eyeShape: ['Eye shape', 'চোখের আকৃতি'], p_eyeColor: ['Eye color', 'চোখের রং'], p_eyeSize: ['Eye size', 'চোখের আকার'], p_eyeSpacing: ['Eye spacing', 'চোখের দূরত্ব'],
  p_glasses: ['Glasses', 'চশমা'], p_hat: ['Hat', 'টুপি'], p_earrings: ['Earrings', 'কানের দুল'], p_necklace: ['Necklace', 'গলার হার'], p_watch: ['Watch', 'ঘড়ি'],
  p_baseTop: ['Base top', 'বেস টপ'], p_baseBottom: ['Base bottom', 'বেস বটম'], p_color: ['Color', 'রং'],
  hs_bald: ['Bald', 'টাক'], hs_buzz: ['Buzz', 'ছোট করে ছাঁটা'], hs_short: ['Short', 'ছোট'], hs_long: ['Long', 'লম্বা'], hs_bun: ['Bun', 'খোঁপা'], hs_ponytail: ['Ponytail', 'পনিটেইল'], hs_curly: ['Curly', 'কোঁকড়া'],
  es_round: ['Round', 'গোল'], es_almond: ['Almond', 'কাজলটানা'], es_narrow: ['Narrow', 'সরু'], es_big: ['Big', 'বড়'],
  gl_none: ['None', 'নেই'], gl_round: ['Round', 'গোল'], gl_square: ['Square', 'চৌকো'], hat_none: ['None', 'নেই'], hat_cap: ['Cap', 'ক্যাপ'],
  presets: ['Body & face presets', 'শরীর ও মুখের প্রিসেট'], pre_neutral: ['Neutral', 'নিরপেক্ষ'], pre_male: ['Male', 'পুরুষ'], pre_female: ['Female', 'নারী'], pre_athletic: ['Athletic', 'অ্যাথলেটিক'], pre_slim: ['Slim', 'চিকন'], pre_tall: ['Tall', 'লম্বা'],
  preset_applied: ['Preset applied', 'প্রিসেট প্রয়োগ হয়েছে'], reset_custom: ['Reset customization', 'কাস্টমাইজেশন রিসেট'], reset_confirm: ['All customization will return to the defaults.', 'সব কাস্টমাইজেশন ডিফল্টে ফিরে যাবে।'],
  glb_note: ['This is an imported/AI model. Hair, face, skin and body editing only applies to the built-in base body; you can still dress, view and export it.', 'এটি ইমপোর্ট করা/এআই মডেল। চুল, মুখ, ত্বক ও শরীর এডিট শুধু বেস বডিতে কাজ করে; তবে পোশাক পরানো, দেখা ও এক্সপোর্ট করা যাবে।'],
  worn_outfits: ['Worn outfits', 'পরা পোশাক'], no_worn: ['Nothing worn yet.', 'এখনো কিছু পরানো হয়নি।'], add_from_wardrobe: ['Add from wardrobe', 'ওয়ার্ডরোব থেকে নিন'], base_clothes: ['Base clothes colors', 'বেস পোশাকের রং'],
  light_intensity: ['Light intensity', 'আলোর তীব্রতা'], light_angle: ['Light direction', 'আলোর দিক'], background: ['Background', 'ব্যাকগ্রাউন্ড'],
  bg_dark: ['Black', 'কালো'], bg_charcoal: ['Charcoal', 'চারকোল'], bg_studio: ['Studio', 'স্টুডিও'], bg_gold: ['Gold', 'সোনালি'], bg_white: ['White', 'সাদা'], bg_transparent: ['Transparent', 'স্বচ্ছ'],
  view_front: ['Front', 'সামনে'], view_side: ['Side', 'পাশে'], view_back: ['Back', 'পিছনে'], view_full: ['Full body', 'পূর্ণ শরীর'], view_face: ['Face', 'মুখ'],
  zoom_in: ['Zoom in', 'জুম ইন'], zoom_out: ['Zoom out', 'জুম আউট'], auto_rotate: ['Rotate', 'ঘোরান'],
  unsaved_title: ['Unsaved changes', 'অসংরক্ষিত পরিবর্তন'], unsaved_body: ['Save your changes before leaving?', 'বের হওয়ার আগে পরিবর্তন সংরক্ষণ করবেন?'],
  // export
  glb_desc: ['Exports the full 3D model with mesh, materials and textures as a .glb file.', 'মেশ, মেটেরিয়াল ও টেক্সচারসহ পূর্ণ ৩ডি মডেল .glb ফাইল হিসেবে এক্সপোর্ট করে।'],
  export_glb: ['Export GLB', 'GLB এক্সপোর্ট'], png_size: ['PNG size', 'PNG মাপ'], png_views: ['Views', 'ভিউ'], export_png: ['Export PNG', 'PNG এক্সপোর্ট'],
  exporting: ['Exporting…', 'এক্সপোর্ট হচ্ছে…'], export_done: ['Exported:', 'এক্সপোর্ট হয়েছে:'], export_failed: ['Export failed:', 'এক্সপোর্ট ব্যর্থ:'], pick_view: ['Select at least one view.', 'অন্তত একটি ভিউ বেছে নিন।'],
  try_1024: ['Try 1024 × 1024.', '১০২৪ × ১০২৪ চেষ্টা করুন।'],
  // settings
  language: ['Language', 'ভাষা'], ai_backend: ['AI backend address', 'এআই ব্যাকএন্ডের ঠিকানা'],
  backend_note: ['No API key is stored in the app. Run server/server.js with your provider key and enter its URL here.', 'অ্যাপে কোনো API কী রাখা হয় না। আপনার প্রোভাইডার কী দিয়ে server/server.js চালান এবং এখানে তার URL দিন।'],
  test_connection: ['Test connection', 'সংযোগ পরীক্ষা'], test_ok: ['Backend is reachable and configured (provider: {0}).', 'ব্যাকএন্ড পাওয়া গেছে ও কনফিগার করা (প্রোভাইডার: {0})।'],
  test_nokey: ['Backend is reachable but has no provider API key.', 'ব্যাকএন্ড পাওয়া গেছে কিন্তু প্রোভাইডার API কী নেই।'],
  render_quality: ['Render quality', 'রেন্ডার কোয়ালিটি'], q_auto: ['Auto', 'অটো'], q_low: ['Low (fast)', 'কম (দ্রুত)'], q_high: ['High', 'বেশি'],
  quality_note: ['Use Low on older Android phones. Applies the next time a 3D screen opens.', 'পুরনো অ্যান্ড্রয়েড ফোনে "কম" ব্যবহার করুন। পরের বার ৩ডি স্ক্রিন খুললে কার্যকর হবে।'], quality_next: ['Applies next time a 3D screen opens', 'পরের বার ৩ডি স্ক্রিন খুললে কার্যকর হবে'],
  privacy_data: ['Privacy & data', 'প্রাইভেসি ও ডেটা'], privacy_policy: ['Privacy policy', 'প্রাইভেসি পলিসি'], clear_cache: ['Clear cache', 'ক্যাশ পরিষ্কার'], cache_cleared: ['Cache cleared (your characters are kept)', 'ক্যাশ পরিষ্কার হয়েছে (ক্যারেক্টার অক্ষত)'],
  delete_all: ['Delete all data', 'সব ডেটা মুছুন'], delete_all_body: ['All characters, outfits and settings on this device will be permanently deleted.', 'এই ডিভাইসের সব ক্যারেক্টার, পোশাক ও সেটিংস স্থায়ীভাবে মুছে যাবে।'],
  about: ['About', 'সম্পর্কে'], three_local: ['bundled locally', 'লোকালি বান্ডেল করা'], three_cdn: ['loaded from CDN (internet required)', 'CDN থেকে লোড (ইন্টারনেট লাগবে)'],
  priv_h1: ['What the app stores', 'অ্যাপ কী সংরক্ষণ করে'], priv_p1: ['Characters, outfits and settings are saved only on this device (IndexedDB). There is no account and nothing is uploaded unless you use an AI feature.', 'ক্যারেক্টার, পোশাক ও সেটিংস শুধু এই ডিভাইসে (IndexedDB) সংরক্ষিত হয়। কোনো অ্যাকাউন্ট নেই এবং এআই সুবিধা ব্যবহার না করলে কিছুই আপলোড হয় না।'],
  priv_h2: ['Photos and AI processing', 'ছবি ও এআই প্রক্রিয়া'], priv_p2: ['If you choose AI generation, you see a preview and must agree first. The image is sent to your configured backend, which forwards it to an external AI provider. The backend in this project keeps the image only in memory while forwarding it and does not write it to disk.', 'এআই তৈরি বেছে নিলে আগে প্রিভিউ দেখানো হয় এবং আপনাকে সম্মতি দিতে হয়। ছবি আপনার কনফিগার করা ব্যাকএন্ডে যায়, যা এটি বাইরের এআই প্রদানকারীর কাছে পাঠায়। এই প্রজেক্টের ব্যাকএন্ড পাঠানোর সময় ছবি শুধু মেমরিতে রাখে, ডিস্কে লেখে না।'],
  priv_h3: ['The AI provider', 'এআই প্রদানকারী'], priv_p3: ['The provider (for example Meshy) processes the image under its own terms and privacy policy and may keep data according to them. Read their policy before using photos of other people.', 'প্রদানকারী (যেমন Meshy) নিজস্ব শর্ত ও প্রাইভেসি পলিসি অনুযায়ী ছবি প্রক্রিয়া করে এবং সেই অনুযায়ী ডেটা রাখতে পারে। অন্যের ছবি ব্যবহারের আগে তাদের পলিসি পড়ুন।'],
  priv_h4: ['Photos of other people', 'অন্য মানুষের ছবি'], priv_p4: ['Only use photos of yourself or of people who agreed. Do not create characters of people to deceive, harass or impersonate them.', 'শুধু নিজের বা সম্মতি দিয়েছেন এমন মানুষের ছবি ব্যবহার করুন। কাউকে প্রতারণা, হয়রানি বা নকল করার উদ্দেশ্যে ক্যারেক্টার বানাবেন না।'],
  priv_h5: ['Your control', 'আপনার নিয়ন্ত্রণ'], priv_p5: ['You can delete any character or outfit, clear the cache, or delete all data at any time in Settings. Deleting requires confirmation.', 'সেটিংসে যেকোনো সময় ক্যারেক্টার বা পোশাক মুছতে, ক্যাশ পরিষ্কার করতে বা সব ডেটা মুছতে পারবেন। মোছার আগে নিশ্চিত করতে হয়।'],
  priv_h6: ['Contact', 'যোগাযোগ'], priv_p6: ['Replace this section with the owner’s contact details before publishing the app.', 'অ্যাপ প্রকাশের আগে এই অংশে মালিকের যোগাযোগের তথ্য বসান।'],
};

export function t(key, ...args) {
  const row = S[key];
  if (!row) { console.warn('[i18n] missing key', key); return key; }
  let s = row[ORDER.indexOf(lang)] ?? row[0];
  args.forEach((a, i) => { s = s.replaceAll('{' + i + '}', a); });
  return s;
}
export const getLang = () => lang;
export function setLang(l) {
  if (!LANGS[l]) l = 'en';
  lang = l; document.documentElement.lang = l;
  window.dispatchEvent(new Event('hcd-lang'));
}
export const _strings = S;
