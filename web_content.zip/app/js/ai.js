// Client for the AI backend proxy (see server/server.js). No API keys ever live in the app.
import { settings } from './db.js';
import { blobToDataURL } from './util.js';

export class AiNotConfigured extends Error { constructor(msg) { super(msg); this.name = 'AiNotConfigured'; } }

const base = () => (settings.get().backendUrl || '').trim().replace(/\/+$/, '');

async function api(path, opts) {
  const b = base();
  if (!b) throw new AiNotConfigured('no-backend');
  let r;
  try { r = await fetch(b + path, opts); } catch { throw new AiNotConfigured('unreachable'); }
  return r;
}

export async function health() {
  const r = await api('/api/health');
  if (!r.ok) throw new AiNotConfigured('unreachable');
  return r.json();
}

/** Upload an image, wait for the provider, return the generated GLB as a Blob. */
export async function generateModel(kind, imageBlob, onProgress, signal) {
  const h = await health();
  if (!h.configured) throw new AiNotConfigured('no-key');
  const image = await blobToDataURL(imageBlob);
  let r = await api('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ kind, image }), signal });
  let j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
  const id = j.jobId;
  for (let i = 0; i < 240; i++) {               // up to ~12 minutes
    await new Promise((res) => setTimeout(res, 3000));
    if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
    r = await api(`/api/jobs/${id}`, { signal }); j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || `HTTP ${r.status}`);
    onProgress?.(j.progress || 0, j.status);
    if (j.status === 'failed') throw new Error(j.error || 'Generation failed');
    if (j.status === 'done') {
      r = await api(`/api/jobs/${id}/model`, { signal });
      if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || `HTTP ${r.status}`);
      return new Blob([await r.arrayBuffer()], { type: 'model/gltf-binary' });
    }
  }
  throw new Error('Timed out');
}
