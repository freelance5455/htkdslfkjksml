// Screens that use the 3D stage: Character editor, Outfit maker, Export center.
import { t, getLang } from './i18n.js';
import { db, uid, settings } from './db.js';
import { mountStage, topbar, icons, aiConsent, confirmBox, aiErrorMessage } from './ui.js';
import { $, $$, esc, toast, modal, pickFile, resizeImage, downloadBlob, safeName, isImageFile } from './util.js';
import { DEFAULT_PARAMS, PRESETS, SKIN_TONES, HAIR_COLORS, EYE_COLORS, HAIR_STYLES, EYE_SHAPES, GLASSES, HATS } from './avatar.js';
import { composeCharacter, CATEGORIES, forgetOutfit, MODEL_FORMATS, extOf } from './clothing.js';
import { BACKGROUNDS } from './viewer.js';
import { exportGLB, exportPNGs } from './export.js';
import { generateModel } from './ai.js';

const outfitsFor = async (char) => (await Promise.all((char.worn || []).map((id) => db.get('outfits', id)))).filter(Boolean);
export const thumbUrlCache = new Map();
export function blobUrl(blob) { if (!blob) return ''; if (!thumbUrlCache.has(blob)) thumbUrlCache.set(blob, URL.createObjectURL(blob)); return thumbUrlCache.get(blob); }

/** coalesced async model refresh */
function makeRefresher(viewer, build) {
  let busy = false, again = false;
  const run = async () => {
    if (busy) { again = true; return; }
    busy = true;
    try { const root = await build(); if (viewer._alive) { viewer.setModel(root); if (root.userData.errors?.length) toast(root.userData.errors[0], true); } }
    catch (e) { toast(e.message || String(e), true); }
    busy = false; if (again) { again = false; run(); }
  };
  return run;
}

// ======================= CHARACTER EDITOR =======================
export async function renderEditor(host, { id }, nav) {
  const char = await db.get('characters', id);
  if (!char) { toast(t('not_found'), true); nav.back(); return () => {}; }
  char.params = { ...DEFAULT_PARAMS, ...(char.params || {}) }; char.worn = char.worn || [];
  const isGlb = char.base?.type === 'glb';
  let dirty = false, tab = isGlb ? 'outfit' : 'hair';
  const scene = { intensity: 1, angle: 35, bg: 'dark' };

  host.innerHTML = `<div class="screen">${topbar(char.name, { right: `<button class="iconbtn" data-act="rename" aria-label="${esc(t('rename'))}">✎</button><button class="iconbtn" data-act="save" aria-label="${esc(t('save'))}">${icons.save}</button><button class="iconbtn" data-act="export" aria-label="${esc(t('export'))}">${icons.export}</button>` })}
    <div id="stagehost" style="flex:1;display:flex;flex-direction:column;min-height:0"></div>
    <div class="sheet"><div class="tabs"></div><div class="panel"></div></div></div>`;
  const viewer = mountStage($('#stagehost', host));
  const refresh = makeRefresher(viewer, async () => composeCharacter(char, await outfitsFor(char)));
  refresh().then(() => { if (!char.preview) setTimeout(() => save(true), 700); });

  const tabs = isGlb ? ['outfit', 'scene'] : ['hair', 'face', 'skin', 'body', 'eyes', 'acc', 'outfit', 'presets', 'scene'];
  const tabsEl = $('.tabs', host), panel = $('.panel', host);
  const drawTabs = () => { tabsEl.innerHTML = tabs.map((k) => `<button class="tab ${k === tab ? 'on' : ''}" data-tab="${k}">${t('tab_' + k)}</button>`).join(''); };

  const P = char.params;
  const pct = (v) => Math.round(v * 100) + '%';
  const slider = (k, min = 0, max = 1, step = 0.01, fmt = pct) => `<div class="field"><label>${t('p_' + k)}<b id="v-${k}">${fmt(P[k])}</b></label><input type="range" data-p="${k}" min="${min}" max="${max}" step="${step}" value="${P[k]}"></div>`;
  const opts = (k, list, pre) => `<div class="field"><label>${t('p_' + k)}</label><div class="opts">${list.map((v) => `<button class="opt ${P[k] === v ? 'on' : ''}" data-set="${k}" data-v="${v}">${t(pre + v)}</button>`).join('')}</div></div>`;
  const swatches = (k, list) => `<div class="field"><label>${t('p_' + k)}</label><div class="swatches">${list.map((c) => `<button class="sw ${P[k].toLowerCase() === c ? 'on' : ''}" style="background:${c}" data-set="${k}" data-v="${c}" aria-label="${c}"></button>`).join('')}<input type="color" data-p="${k}" value="${P[k]}"></div></div>`;
  const toggle = (k) => `<div class="switch"><span>${t('p_' + k)}</span><button class="opt ${P[k] ? 'on' : ''}" data-toggle="${k}">${P[k] ? t('on') : t('off')}</button></div>`;

  async function drawPanel() {
    let h = '';
    if (isGlb && tab !== 'scene') h += `<div class="note">${t('glb_note')}</div>`;
    switch (tab) {
      case 'hair': h += opts('hairStyle', HAIR_STYLES, 'hs_') + swatches('hairColor', HAIR_COLORS); break;
      case 'face': h += slider('faceWidth') + slider('faceLength') + slider('jaw') + slider('noseSize') + slider('mouthWidth'); break;
      case 'skin': h += swatches('skinTone', SKIN_TONES) + slider('skinRough', 0.1, 0.95); break;
      case 'body': h += slider('height', 1.45, 2.05, 0.01, (v) => Math.round(v * 100) + ' cm') + slider('build') + slider('shoulder') + slider('legs') + slider('headSize'); break;
      case 'eyes': h += opts('eyeShape', EYE_SHAPES, 'es_') + swatches('eyeColor', EYE_COLORS) + slider('eyeSize') + slider('eyeSpacing'); break;
      case 'acc': h += opts('glasses', GLASSES, 'gl_') + opts('hat', HATS, 'hat_') + toggle('earrings') + toggle('necklace') + toggle('watch'); break;
      case 'presets':
        h += `<div class="field"><label>${t('presets')}</label><div class="opts">${Object.keys(PRESETS).map((k) => `<button class="opt" data-preset="${k}">${t('pre_' + k)}</button>`).join('')}</div></div><button class="btn danger" data-reset>${t('reset_custom')}</button>`; break;
      case 'outfit': {
        const worn = await outfitsFor(char);
        h += `<div class="h2">${t('worn_outfits')}</div>` + (worn.length ? worn.map((o) => `<div class="switch"><span>${esc(o.name)}</span><button class="btn small danger" data-unwear="${o.id}">${t('remove')}</button></div>`).join('') : `<div class="muted">${t('no_worn')}</div>`);
        h += `<div class="row" style="margin-top:12px"><button class="btn small" data-wardrobe>${t('add_from_wardrobe')}</button><button class="btn small primary" data-newoutfit>${t('create_outfit')}</button></div>`;
        if (!isGlb) h += `<div class="h2">${t('base_clothes')}</div><div class="row"><span class="muted">${t('p_baseTop')}</span><input type="color" data-p="baseTop" value="${P.baseTop}"><span class="muted">${t('p_baseBottom')}</span><input type="color" data-p="baseBottom" value="${P.baseBottom}"></div>`;
        break;
      }
      case 'scene':
        h += `<div class="field"><label>${t('light_intensity')}<b id="v-li">${pct(scene.intensity)}</b></label><input type="range" data-s="intensity" min="0.3" max="1.6" step="0.01" value="${scene.intensity}"></div>
          <div class="field"><label>${t('light_angle')}<b id="v-la">${Math.round(scene.angle)}°</b></label><input type="range" data-s="angle" min="-180" max="180" step="1" value="${scene.angle}"></div>
          <div class="field"><label>${t('background')}</label><div class="opts">${Object.keys(BACKGROUNDS).map((k) => `<button class="opt ${scene.bg === k ? 'on' : ''}" data-bg="${k}">${t('bg_' + k)}</button>`).join('')}</div></div>`;
        break;
    }
    panel.innerHTML = h;
  }
  const setDirty = () => { dirty = true; };

  panel.addEventListener('input', (e) => {
    const el = e.target;
    if (el.dataset.p) {
      const k = el.dataset.p; P[k] = el.type === 'range' ? Number(el.value) : el.value; setDirty();
      const lab = $('#v-' + k, panel); if (lab) lab.textContent = k === 'height' ? Math.round(P[k] * 100) + ' cm' : pct(P[k]);
      refresh();
    } else if (el.dataset.s) {
      scene[el.dataset.s] = Number(el.value); viewer.setLighting({ [el.dataset.s]: scene[el.dataset.s] });
      $('#v-li', panel) && ($('#v-li', panel).textContent = pct(scene.intensity)); $('#v-la', panel) && ($('#v-la', panel).textContent = Math.round(scene.angle) + '°');
    }
  });
  panel.addEventListener('click', async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.set) { P[b.dataset.set] = b.dataset.v; setDirty(); refresh(); drawPanel(); }
    else if (b.dataset.toggle) { P[b.dataset.toggle] = !P[b.dataset.toggle]; setDirty(); refresh(); drawPanel(); }
    else if (b.dataset.preset) { Object.assign(P, PRESETS[b.dataset.preset]); setDirty(); refresh(); toast(t('preset_applied')); }
    else if ('reset' in b.dataset) { if (await confirmBox(t('reset_custom'), t('reset_confirm'), t('reset'))) { Object.assign(P, DEFAULT_PARAMS); setDirty(); refresh(); drawPanel(); } }
    else if (b.dataset.bg) { scene.bg = b.dataset.bg; viewer.setBackground(scene.bg); drawPanel(); }
    else if (b.dataset.unwear) { char.worn = char.worn.filter((x) => x !== b.dataset.unwear); setDirty(); refresh(); drawPanel(); }
    else if ('newoutfit' in b.dataset) { await save(true); nav.go('outfit', { characterId: char.id, returnToEditor: true }); }
    else if ('wardrobe' in b.dataset) {
      const list = await db.list('outfits');
      if (!list.length) return toast(t('wardrobe_empty'), true);
      const pick = await modal({
        title: t('add_from_wardrobe'),
        html: `<div class="cards" style="grid-template-columns:repeat(2,1fr)">${list.map((o) => `<button class="card" data-pick="${o.id}" style="cursor:pointer;color:inherit;text-align:left"><div class="thumb">${o.thumb ? `<img src="${blobUrl(o.thumb)}" alt="">` : ''}</div><div class="meta"><b>${esc(o.name)}</b></div></button>`).join('')}</div>`,
        buttons: [{ label: t('cancel'), value: null }],
      }).catch(() => null);
      void pick;
    }
  });
  // outfit picker: modal buttons are inside #modal-root, handle there
  const pickHandler = (e) => {
    const c = e.target.closest('[data-pick]'); if (!c) return;
    const id = c.dataset.pick; document.querySelector('.modal-bg')?.remove();
    db.get('outfits', id).then((o) => { if (!o) return; char.worn = char.worn.filter((x) => x !== id); char.worn.push(id); setDirty(); refresh(); drawPanel(); toast(t('outfit_applied')); });
  };
  document.getElementById('modal-root').addEventListener('click', pickHandler);

  tabsEl.addEventListener('click', (e) => { const b = e.target.closest('[data-tab]'); if (!b) return; tab = b.dataset.tab; drawTabs(); drawPanel(); });

  async function save(silent) {
    try {
      char.updated = Date.now();
      char.preview = await viewer.snapshot({ size: 360, view: 'full', bg: 'charcoal' });
      await db.put('characters', char); dirty = false;
      if (!silent) toast(t('saved'));
    } catch (err) { toast(t('save_failed') + ' ' + err.message, true); }
  }
  host.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-act]'); if (!b) return;
    if (b.dataset.act === 'save') save();
    else if (b.dataset.act === 'export') { await save(true); nav.go('export', { id: char.id }); }
    else if (b.dataset.act === 'rename') {
      const r = await modal({ title: t('rename'), html: `<input type="text" id="rn" value="${esc(char.name)}" maxlength="40">`, buttons: [{ label: t('cancel'), value: null }, { label: t('save'), cls: 'primary', value: (m) => m.querySelector('#rn').value.trim() }] });
      if (r) { char.name = r; $('.topbar h1', host).textContent = r; setDirty(); }
    }
  });
  nav.beforeLeave = async () => {
    if (!dirty) return true;
    const r = await modal({ title: t('unsaved_title'), html: `<p>${t('unsaved_body')}</p>`, buttons: [{ label: t('cancel'), value: 'cancel' }, { label: t('discard'), cls: 'danger', value: 'discard' }, { label: t('save'), cls: 'primary', value: 'save' }] });
    if (r === 'save') { await save(true); return true; }
    return r === 'discard';
  };
  drawTabs(); drawPanel();
  return () => { document.getElementById('modal-root').removeEventListener('click', pickHandler); viewer.destroy(); };
}

// ======================= OUTFIT MAKER =======================
export async function renderOutfitMaker(host, { characterId, returnToEditor }, nav) {
  let char = characterId ? await db.get('characters', characterId) : null;
  const base = char ? { ...char, worn: [] } : { id: 'tmp', base: { type: 'procedural' }, params: { ...DEFAULT_PARAMS }, worn: [] };
  const d = { id: uid(), name: '', category: 'casual', kind: 'image', garment: 'top', sleeve: 'short', hem: 'long', color: '#7a1f2b', image: null, model: null, adjust: { scale: 1, x: 0, y: 0, z: 0, rotY: 0 } };
  let method = 'image';

  host.innerHTML = `<div class="screen">${topbar(t('create_outfit'))}<div id="stagehost" style="height:42vh;display:flex;flex-direction:column"></div><div class="content pad-b" id="form"></div></div>`;
  const viewer = mountStage($('#stagehost', host));
  const refresh = makeRefresher(viewer, async () => {
    const has = (d.kind === 'image' && (d.image || true)) || (d.kind === 'model' && d.model);
    return composeCharacter(base, has ? [{ ...d, kind: d.kind }] : []);
  });
  refresh();
  const form = $('#form', host);

  function draw() {
    const aiOn = !!settings.get().backendUrl;
    const gts = method === 'model' ? ['top', 'bottom', 'dress', 'full'] : ['top', 'bottom', 'dress'];
    form.innerHTML = `
      <div class="chips"><button class="chip ${method === 'image' ? 'on' : ''}" data-m="image">${t('method_image')}</button><button class="chip ${method === 'model' ? 'on' : ''}" data-m="model">${t('method_model')}</button></div>
      ${method === 'image' ? `
        <div class="row"><button class="btn" data-up="img">${icons.image} ${t('upload_clothing_img')}</button>${d.image ? `<span class="gold">✓ ${t('image_loaded')}</span>` : ''}</div>
        <div class="note">${t('basic_wrap_note')}</div>
        ${d.kind === 'image' && !d.image ? `<div class="field"><label>${t('p_color')}</label><input type="color" data-f="color" value="${d.color}"></div>` : ''}
        ${d.image ? `<button class="btn small" data-ai>${icons.spark} ${t('ai_reconstruct')}</button>
          <div class="progress" id="aiprog" style="display:none"><i></i></div>
          <div class="muted" style="font-size:12px;margin-top:6px">${aiOn ? t('ai_garment_hint') : t('ai_not_set_hint')}</div>` : ''}`
      : `<div class="row"><button class="btn" data-up="model">${icons.cube} ${t('upload_3d')}</button>${d.model ? `<span class="gold">✓ ${esc(d.model.filename)}</span>` : ''}</div>
        <div class="note">${t('model_note')}</div>`}
      <div class="field"><label>${t('garment_type')}</label><div class="opts">${gts.map((g) => `<button class="opt ${d.garment === g ? 'on' : ''}" data-f="garment" data-v="${g}">${t('gt_' + g)}</button>`).join('')}</div></div>
      ${d.kind === 'image' && (d.garment === 'top' || d.garment === 'dress') ? `<div class="field"><label>${t('sleeve')}</label><div class="opts">${['none', 'short', 'long'].map((g) => `<button class="opt ${d.sleeve === g ? 'on' : ''}" data-f="sleeve" data-v="${g}">${t('sl_' + g)}</button>`).join('')}</div></div>` : ''}
      ${d.kind === 'image' && (d.garment === 'bottom' || d.garment === 'dress') ? `<div class="field"><label>${t('hem')}</label><div class="opts">${['short', 'long'].map((g) => `<button class="opt ${d.hem === g ? 'on' : ''}" data-f="hem" data-v="${g}">${t('hem_' + g)}</button>`).join('')}</div></div>` : ''}
      ${d.kind === 'model' && d.model ? `<div class="h2">${t('adjust_outfit')}</div>
        ${[['scale', 0.5, 1.8, 0.01], ['x', -0.2, 0.2, 0.005], ['y', -0.2, 0.2, 0.005], ['z', -0.2, 0.2, 0.005], ['rotY', 0, 360, 1]].map(([k, a, b, s]) => `<div class="field"><label>${t('adj_' + k)}</label><input type="range" data-adj="${k}" min="${a}" max="${b}" step="${s}" value="${d.adjust[k]}"></div>`).join('')}
        <div class="muted" style="font-size:12px">${t('no_cloth_sim')}</div>` : ''}
      <div class="h2">${t('outfit_name')}</div><input type="text" data-f="name" maxlength="40" value="${esc(d.name)}" placeholder="${esc(t('outfit_name_ph'))}">
      <div class="field"><label>${t('category')}</label><select data-f="category">${CATEGORIES.map((c) => `<option value="${c}" ${d.category === c ? 'selected' : ''}>${t('cat_' + c)}</option>`).join('')}</select></div>
      <div class="row" style="margin-top:14px">${char ? `<button class="btn primary grow" data-save="wear">${t('save_and_wear')}</button>` : ''}<button class="btn grow" data-save="only">${t('save_wardrobe')}</button></div>`;
  }
  draw();

  form.addEventListener('input', (e) => {
    const el = e.target;
    if (el.dataset.adj) { d.adjust[el.dataset.adj] = Number(el.value); refresh(); }
    else if (el.dataset.f === 'color') { d.color = el.value; refresh(); }
    else if (el.dataset.f === 'name') d.name = el.value;
  });
  form.addEventListener('change', (e) => { if (e.target.dataset.f === 'category') d.category = e.target.value; });

  form.addEventListener('click', async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.m) { method = b.dataset.m; d.kind = method === 'image' ? 'image' : 'model'; if (method === 'image' && d.garment === 'full') d.garment = 'top'; draw(); refresh(); }
    else if (b.dataset.f) { d[b.dataset.f] = b.dataset.v; draw(); refresh(); }
    else if (b.dataset.up === 'img') {
      const f = await pickFile('image/jpeg,image/png,image/webp'); if (!f) return;
      if (!isImageFile(f)) return toast(t('bad_image'), true);
      try { forgetOutfit(d.id); d.id = uid(); d.image = await resizeImage(f, 1024, f.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.92); d.kind = 'image'; if (!d.name) d.name = f.name.replace(/\.[^.]+$/, '').slice(0, 40); draw(); refresh(); }
      catch (err) { toast(t('bad_image') + ' ' + err.message, true); }
    } else if (b.dataset.up === 'model') {
      const f = await pickFile('.glb,.gltf,.obj,.fbx'); if (!f) return;
      const ext = extOf(f.name);
      if (!MODEL_FORMATS.includes(ext)) return toast(t('bad_model'), true);
      if (ext === 'gltf') toast(t('gltf_note'));
      forgetOutfit(d.id); d.id = uid(); d.model = { blob: f, format: ext, filename: f.name }; d.kind = 'model'; d.adjust = { scale: 1, x: 0, y: 0, z: 0, rotY: 0 };
      if (!d.name) d.name = f.name.replace(/\.[^.]+$/, '').slice(0, 40);
      draw(); refresh();
    } else if ('ai' in b.dataset) {
      if (!settings.get().backendUrl) { toast(t('ai_err_nobackend'), true); return; }
      if (!(await aiConsent('garment'))) return;
      const bar = $('#aiprog', form); bar.style.display = ''; b.disabled = true;
      try {
        const glb = await generateModel('garment', d.image, (p) => { bar.firstElementChild.style.width = p + '%'; });
        forgetOutfit(d.id); d.id = uid(); d.model = { blob: glb, format: 'glb', filename: 'ai-garment.glb' }; d.kind = 'model'; method = 'model'; d.adjust = { scale: 1, x: 0, y: 0, z: 0, rotY: 0 };
        draw(); refresh(); toast(t('ai_garment_done'));
      } catch (err) { toast(aiErrorMessage(err), true); bar.style.display = 'none'; b.disabled = false; }
    } else if (b.dataset.save) {
      if (d.kind === 'image' && !d.image) return toast(t('need_clothing'), true);
      if (d.kind === 'model' && !d.model) return toast(t('need_clothing'), true);
      try {
        const rec = { id: uid(), name: d.name.trim() || t('untitled_outfit'), category: d.category, kind: d.kind, garment: d.garment, sleeve: d.sleeve, hem: d.hem, color: d.color, image: d.kind === 'image' ? d.image : null, model: d.kind === 'model' ? d.model : null, adjust: { ...d.adjust }, created: Date.now() };
        rec.thumb = await viewer.snapshot({ size: 360, view: 'full', bg: 'charcoal' });
        await db.put('outfits', rec);
        if (b.dataset.save === 'wear' && char) { char.worn = (char.worn || []).filter((x) => x !== rec.id); char.worn.push(rec.id); char.updated = Date.now(); await db.put('characters', char); toast(t('outfit_saved_worn')); (returnToEditor ? nav.back() : nav.replace('editor', { id: char.id })); }
        else { toast(t('outfit_saved')); nav.back(); }
      } catch (err) { toast(t('save_failed') + ' ' + err.message, true); }
    }
  });
  return () => { forgetOutfit(d.id); viewer.destroy(); };
}

// ======================= EXPORT CENTER =======================
export async function renderExport(host, { id }, nav) {
  const char = await db.get('characters', id);
  if (!char) { toast(t('not_found'), true); nav.back(); return () => {}; }
  const o = { size: 1024, bg: 'transparent', views: new Set(['front']) };
  host.innerHTML = `<div class="screen">${topbar(t('export_center') + ' · ' + char.name)}<div id="stagehost" style="height:36vh;display:flex;flex-direction:column"></div>
    <div class="content pad-b">
      <div class="h2">GLB</div><div class="note">${t('glb_desc')}</div>
      <button class="btn primary" data-glb>${icons.cube} ${t('export_glb')}</button>
      <div class="h2">PNG</div>
      <div class="field"><label>${t('png_size')}</label><div class="opts">${[1024, 2048].map((s) => `<button class="opt ${o.size === s ? 'on' : ''}" data-size="${s}">${s} × ${s}</button>`).join('')}</div></div>
      <div class="field"><label>${t('background')}</label><div class="opts">${['transparent', 'studio'].map((s) => `<button class="opt ${o.bg === s ? 'on' : ''}" data-bg="${s}">${t('bg_' + s)}</button>`).join('')}</div></div>
      <div class="field"><label>${t('png_views')}</label><div class="opts">${['front', 'side', 'back'].map((s) => `<button class="opt ${o.views.has(s) ? 'on' : ''}" data-view="${s}">${t('view_' + s)}</button>`).join('')}</div></div>
      <button class="btn primary" data-png>${icons.image} ${t('export_png')}</button>
      <div id="status" class="muted" style="margin-top:12px"></div></div></div>`;
  const viewer = mountStage($('#stagehost', host));
  const root = await composeCharacter(char, await outfitsFor(char)); viewer.setModel(root);
  const status = $('#status', host);
  const content = $('.content', host);
  content.addEventListener('click', async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.size) { o.size = Number(b.dataset.size); $$('[data-size]', host).forEach((x) => x.classList.toggle('on', x === b)); }
    else if (b.dataset.bg) { o.bg = b.dataset.bg; $$('[data-bg]', host).forEach((x) => x.classList.toggle('on', x === b)); }
    else if (b.dataset.view) { o.views.has(b.dataset.view) ? o.views.delete(b.dataset.view) : o.views.add(b.dataset.view); b.classList.toggle('on', o.views.has(b.dataset.view)); }
    else if ('glb' in b.dataset) {
      b.disabled = true; status.textContent = t('exporting');
      try { const blob = await exportGLB(viewer.model); downloadBlob(blob, safeName(char.name) + '.glb'); status.textContent = t('export_done') + ' ' + safeName(char.name) + '.glb (' + (blob.size / 1048576).toFixed(1) + ' MB)'; }
      catch (err) { status.textContent = ''; toast(t('export_failed') + ' ' + (err.message || err), true); }
      b.disabled = false;
    } else if ('png' in b.dataset) {
      if (!o.views.size) return toast(t('pick_view'), true);
      b.disabled = true; status.textContent = t('exporting');
      try {
        const res = await exportPNGs(viewer, { size: o.size, bg: o.bg, views: [...o.views] });
        res.forEach((r, i) => setTimeout(() => downloadBlob(r.blob, `${safeName(char.name)}_${r.view}_${o.size}.png`), i * 400));
        status.textContent = t('export_done') + ' ' + res.length + ' PNG';
      } catch (err) { status.textContent = ''; toast(t('export_failed') + ' ' + (err.message || err) + ' ' + t('try_1024'), true); }
      b.disabled = false;
    }
  });
  return () => viewer.destroy();
}
