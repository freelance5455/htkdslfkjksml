<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/resources.php';
require_once __DIR__ . '/voice.php';
$user = auth_require_user();
resources_schema();
$topbarBalance = voice_wallet_balance((int)$user['id']);
$currentScript = (string)($workspaceRoute ?? basename($_SERVER['SCRIPT_NAME'] ?? ''));
$accessMap = [
 'index.php'=>['realtime','Realtime Studio','realtime/'],
 'image-studio.php'=>['image','Image Studio','image/'],
 'video-studio.php'=>['video','Video Edit Studio','video/'],
 'lip-sync.php'=>['lip-sync','Lip Sync','lip-sync/'],
 'voice-studio.php'=>['voice','Voice Cloning Studio','voice/'],
 'agent-studio.php'=>['agents','AI Agent Studio','agents/'],
 'agent-chat.php'=>['agents','AI Agent Studio','agents/'],
 'projects.php'=>['projects','Projects','projects.php'],
 'assets.php'=>['assets','Assets','assets.php'],
 'history.php'=>['history','History','history.php'],
 'tools-tutorials.php'=>['tools-tutorials','Tools & Tutorials','tools-tutorials.php'],
 'tutorial.php'=>['tutorial','Tutorial','tools-tutorials.php'],
 'settings.php'=>['settings','Settings','settings.php'],
];
if (isset($accessMap[$currentScript]) && $currentScript !== 'resources.php') resources_track_access($accessMap[$currentScript][0],$accessMap[$currentScript][1],$accessMap[$currentScript][2],(int)$user['id']);
$csrf = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
$current = (string)($workspaceNavKey ?? basename($_SERVER['SCRIPT_NAME'] ?? ''));
$navGroups = [
 'DASHBOARD' => [['Dashboard','dashboard.php','grid']],
 'CREATIVE WORKSPACES' => [
  ['Image Studio','image/','image'],['Video Edit Studio','video/','film'],['Realtime Studio','realtime/','cpu'],['Lip Sync Studio','lip-sync/','audio-lines']
 ],
 'AI CREATION' => [['Voice Cloning Studio','voice/','audio'],['AI Agent Studio','agents/','bot'],['WhatsApp Deployments','agents/?section=whatsapp#whatsapp-deployments','phone-call']],
 'YOUR LIBRARY' => [['Projects','projects.php','folder'],['Assets','assets.php','layers'],['History','history.php','history']],
 'ACCOUNT' => [['Buy Credits','credits.php','wallet'],['Tools & Tutorials','tools-tutorials.php','book-open'],['Settings','settings.php','settings']]
];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#111318"><?php if (!empty($platformBaseHref)): ?><base href="<?= htmlspecialchars((string)$platformBaseHref,ENT_QUOTES,'UTF-8') ?>"><?php endif; ?><title><?= htmlspecialchars(($pageTitle??'Dashboard').' · ANONYMOUX STUDIOS',ENT_QUOTES,'UTF-8') ?></title><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet"><link rel="icon" type="image/png" sizes="32x32" href="assets/branding/favicon-32.png"><link rel="apple-touch-icon" href="assets/branding/anonymoux-icon-192.png">
<link rel="stylesheet" href="assets/style.css?v=2.6.2"><link rel="stylesheet" href="assets/navigation.css?v=2.6.2"><link rel="stylesheet" href="assets/workspaces.css?v=2.6.2"><link rel="stylesheet" href="assets/platform-pages.css?v=2.6.2"><link rel="stylesheet" href="assets/dashboard.css?v=2.6.2"><link rel="stylesheet" href="assets/resources.css?v=2.6.2"><link rel="stylesheet" href="assets/history.css?v=2.6.2"><link rel="stylesheet" href="assets/visual-refresh.css?v=2.6.2"><link rel="stylesheet" href="assets/glass-notifications.css?v=2.6.2"><link rel="stylesheet" href="assets/anonymoux-red-overrides.css?v=2.6.2"><link rel="stylesheet" href="assets/theme-system.css?v=2.6.2">
</head><body class="<?= htmlspecialchars((string)($pageShellClass??''),ENT_QUOTES,'UTF-8') ?>"><div class="studio-layout" id="studioLayout"><aside class="studio-sidebar" id="studioSidebar" aria-label="Primary navigation">
<a class="sidebar-brand" href="dashboard.php"><img class="sidebar-brand-logo" src="assets/branding/anonymoux-icon-192.png" alt="ANONYMOUX emblem"><span><strong>ANONYMOUX</strong><small>STUDIOS</small></span></a><nav class="sidebar-nav" aria-label="Workspace navigation">
<?php foreach($navGroups as $group=>$items): ?><div class="sidebar-caption<?= $group==='DASHBOARD'?' sidebar-caption-primary':'' ?>"><?= htmlspecialchars($group,ENT_QUOTES,'UTF-8') ?></div>
<?php foreach($items as [$label,$href,$icon]): $active=($current===$href && !($href==='agents/'&&($_GET['section']??'')==='whatsapp'))||($href==='agents/'&&$current==='agents/chat.php')||($href==='tools-tutorials.php'&&$current==='tutorial.php')||($href==='agents/?section=whatsapp#whatsapp-deployments'&&$current==='agents/'&&($_GET['section']??'')==='whatsapp'); ?>
<a class="sidebar-link" href="<?= htmlspecialchars($href,ENT_QUOTES,'UTF-8') ?>" data-icon="<?= htmlspecialchars($icon,ENT_QUOTES,'UTF-8') ?>" <?= $active?'aria-current="page"':'' ?>><span class="nav-icon" data-icon="<?= htmlspecialchars($icon,ENT_QUOTES,'UTF-8') ?>"></span><span><?= htmlspecialchars($label,ENT_QUOTES,'UTF-8') ?></span></a>
<?php endforeach; endforeach; ?>
<?php if(($user['role']??'')==='admin'): ?><div class="sidebar-caption nav-section-caption">ADMINISTRATION</div><a class="sidebar-link" href="admin.php" <?php if($current==='admin.php')echo 'aria-current="page"'; ?>><span class="nav-icon" data-icon="settings"></span><span>Admin console</span></a><?php endif; ?>
</nav><div class="sidebar-bottom"><span class="sidebar-status-dot"></span><span class="sidebar-account-copy"><strong><?= htmlspecialchars($user['name'],ENT_QUOTES,'UTF-8') ?></strong><small><?= htmlspecialchars(ucfirst($user['role']),ENT_QUOTES,'UTF-8') ?> account</small></span><form class="sidebar-logout-form" method="post" action="logout.php"><input type="hidden" name="_csrf" value="<?=htmlspecialchars(csrf_token(),ENT_QUOTES,'UTF-8')?>"><button type="submit" aria-label="Sign out" title="Sign out">↗</button></form></div></aside>
<button class="sidebar-backdrop" id="sidebarBackdrop" type="button" aria-label="Close navigation"></button><div class="studio-main"><header class="topbar"><button class="nav-toggle" id="navToggle" type="button" aria-label="Open navigation" aria-expanded="false"><span></span><span></span><span></span></button><div class="topbar-spacer" aria-hidden="true"></div><div class="topbar-right"><div class="topbar-notifications" data-notification-center><button class="notification-bell" type="button" aria-label="Notifications" aria-expanded="false" aria-controls="notificationPanel"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg><span class="notification-count" hidden>0</span></button><section class="notification-panel" id="notificationPanel" aria-label="Notifications"><div class="notification-panel-head"><strong>Notifications</strong><span class="notification-panel-actions"><button type="button" data-read-all>Mark all read</button><button class="notification-sound-toggle" type="button" aria-label="Mute notification sound">♫</button></span></div><div class="notification-list"><div class="notification-empty">Loading notifications…</div></div></section></div><a class="topbar-balance-chip" href="credits.php" aria-label="Wallet balance: <?=number_format($topbarBalance)?> credits"><span class="balance-chip-label">BALANCE</span><strong><?=number_format($topbarBalance)?></strong><small>credits</small></a><button class="theme-toggle" id="themeToggle" type="button" aria-label="Switch color theme">☼</button></div></header><main class="main-content">
