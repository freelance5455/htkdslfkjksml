<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/platform.php';

function voice_encryption_secret(): string {
    $secret = trim((string)(app_config()['admin_api_encryption_key'] ?? ''));
    if (strlen($secret) < 32) throw new RuntimeException('Configure ANONYMOUX_KEY_ENCRYPTION_SECRET with at least 32 characters before adding Fish Audio keys.');
    return hash('sha256', $secret, true);
}
function voice_encrypt_key(string $plain): array {
    if (!function_exists('openssl_encrypt')) throw new RuntimeException('OpenSSL is required to encrypt Fish Audio keys.');
    $nonce = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', voice_encryption_secret(), 0, $nonce, $tag);
    if (!is_string($cipher)) throw new RuntimeException('Could not encrypt the Fish Audio key.');
    return [$cipher, base64_encode($nonce), base64_encode($tag)];
}
function fish_audio_key_records(): array {
    $out = [];
    try {
        $rows = db()->query('SELECT id,label,encrypted_key,nonce,auth_tag,is_active,priority FROM fish_audio_keys WHERE is_active=1 ORDER BY priority ASC,id ASC')->fetchAll();
        foreach ($rows as $row) {
            $plain = openssl_decrypt((string)$row['encrypted_key'], 'aes-256-gcm', voice_encryption_secret(), 0, base64_decode((string)$row['nonce']), base64_decode((string)$row['auth_tag']));
            if (is_string($plain) && $plain !== '') $out[] = ['id'=>(int)$row['id'],'label'=>(string)$row['label'],'key'=>$plain];
        }
    } catch (Throwable $ignored) {}
    $legacy = trim((string)(app_config()['fish_audio_api_key'] ?? ''));
    if (!$out && $legacy !== '' && !str_contains($legacy, 'PASTE_')) $out[] = ['id'=>0,'label'=>'Server configuration','key'=>$legacy];
    return $out;
}
function fish_audio_ready(): bool { return count(fish_audio_key_records()) > 0; }
function voice_setting(string $key, string $default=''): string {
    try { $s=db()->prepare('SELECT setting_value FROM platform_settings WHERE setting_key=?'); $s->execute(['voice_'.$key]); $v=$s->fetchColumn(); return $v===false?$default:(string)$v; } catch(Throwable $e) { return $default; }
}
function voice_setting_set(string $key, string $value): void {
    $driver=db()->getAttribute(PDO::ATTR_DRIVER_NAME);
    if ($driver==='sqlite') db()->prepare('INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=excluded.updated_at')->execute(['voice_'.$key,$value,now_sql()]);
    else db()->prepare('INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=VALUES(updated_at)')->execute(['voice_'.$key,$value,now_sql()]);
}
function fish_audio_note_result(array $key, int $status, string $error=''): void {
    $id=(int)($key['id']??0); if($id<1)return;
    try { if($status>=200&&$status<300) db()->prepare('UPDATE fish_audio_keys SET last_used_at=?,last_error=NULL,updated_at=? WHERE id=?')->execute([now_sql(),now_sql(),$id]); else db()->prepare('UPDATE fish_audio_keys SET failure_count=failure_count+1,last_error=?,updated_at=? WHERE id=?')->execute([substr($error,0,500),now_sql(),$id]); } catch(Throwable $ignored) {}
}
function fish_audio_tts(string $text, string $referenceId='', string $format='mp3'): array {
    if (!extension_loaded('curl')) throw new RuntimeException('PHP cURL is not enabled on this hosting account.');
    $keys=fish_audio_key_records(); if(!$keys) throw new RuntimeException('Fish Audio API key is not configured. Ask an administrator to add it in Admin → Voice AI.');
    $model='s2.1-pro-free'; $payload=['text'=>$text,'format'=>$format]; if($referenceId!=='')$payload['reference_id']=$referenceId;
    $lastError='Fish Audio request failed.';
    foreach($keys as $key){
        $ch=curl_init('https://api.fish.audio/v1/tts');
        curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key['key'],'Content-Type: application/json','Accept: audio/mpeg','model: '.$model],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>90,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
        $body=curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $ctype=(string)curl_getinfo($ch,CURLINFO_CONTENT_TYPE); $curlErr=curl_error($ch); curl_close($ch);
        if(is_string($body)&&$status>=200&&$status<300&&strlen($body)>100&&(str_contains(strtolower($ctype),'audio')||str_contains(strtolower($ctype),'octet-stream'))){fish_audio_note_result($key,$status);return ['audio'=>$body,'content_type'=>$ctype,'model'=>$model,'key_label'=>$key['label']];}
        $decoded=is_string($body)?json_decode($body,true):null;
        $providerMessage='';
        if(is_array($decoded)){
            $candidate=$decoded['message']??$decoded['detail']??$decoded['error']??'';
            if(is_string($candidate)) $providerMessage=trim($candidate);
            elseif(is_array($candidate)) $providerMessage=trim((string)($candidate['message']??$candidate['detail']??$candidate['code']??''));
        }
        if($curlErr!=='') $lastError='Could not connect to Fish Audio. Check that PHP cURL and outbound HTTPS are enabled on the hosting account, then retry.';
        elseif($status===401) $lastError='Fish Audio rejected the API key (HTTP 401). Replace or verify the active key in Admin → Voice AI.';
        elseif($status===403) $lastError='Fish Audio denied this request (HTTP 403). Check the key permissions, account access and selected voice.';
        elseif($status===402) $lastError='Fish Audio reports that the provider account has insufficient balance or quota (HTTP 402). Check the Fish Audio account.';
        elseif($status===404) $lastError='Fish Audio could not find the selected voice or model (HTTP 404). Choose another voice or verify its ID.';
        elseif($status===422) $lastError='Fish Audio could not process this text or voice selection (HTTP 422). Verify the selected voice and shorten or simplify the script.';
        elseif($status===429) $lastError='Fish Audio rate limit reached (HTTP 429). Wait briefly before generating again.';
        elseif($status>=500) $lastError='Fish Audio is temporarily unavailable (HTTP '.$status.'). Please retry shortly.';
        elseif($status>0) $lastError='Fish Audio rejected the request (HTTP '.$status.').'.($providerMessage!==''?' '.$providerMessage:'');
        else $lastError='Fish Audio did not return a valid audio response. Please retry shortly.';
        fish_audio_note_result($key,$status,$curlErr!==''?('Transport failure: '.$curlErr):$lastError);
        // A transport failure has status 0; it is retryable and must not pin the rotation to one key.
        if($status!==0 && !in_array($status,[408,425,429,500,502,503,504],true)) break;
    }
    throw new RuntimeException($lastError);
}


/**
 * Fetch one page of voice models from Fish Audio. The API key is only used
 * server-side; the browser receives a small allow-listed metadata response.
 */
function fish_audio_list_voices(int $page = 1, int $pageSize = 60): array {
    if (!extension_loaded('curl')) throw new RuntimeException('PHP cURL is not enabled on this hosting account.');
    $keys = fish_audio_key_records();
    if (!$keys) throw new RuntimeException('Fish Audio API key is not configured. Ask an administrator to add it in Admin → Voice AI.');
    $page = max(1, min(1000, $page));
    $pageSize = max(1, min(100, $pageSize));
    $query = http_build_query(['page_size' => $pageSize, 'page_number' => $page, 'sort_by' => 'score']);
    $lastError = 'Fish Audio voice library is temporarily unavailable.';
    foreach ($keys as $key) {
        $ch = curl_init('https://api.fish.audio/model?' . $query);
        curl_setopt_array($ch, [
            CURLOPT_HTTPGET => true,
            CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $key['key'], 'Accept: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 12,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $body = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);
        if (is_string($body) && $status >= 200 && $status < 300) {
            $decoded = json_decode($body, true);
            if (!is_array($decoded)) {
                $lastError = 'Fish Audio returned an unreadable voice-library response.';
                fish_audio_note_result($key, $status, $lastError);
                continue;
            }
            $rows = $decoded['items'] ?? $decoded['data'] ?? $decoded['models'] ?? $decoded;
            if (is_array($rows) && isset($rows['items']) && is_array($rows['items'])) $rows = $rows['items'];
            elseif (is_array($rows) && isset($rows['models']) && is_array($rows['models'])) $rows = $rows['models'];
            if (!is_array($rows)) $rows = [];
            $voices = [];
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                $id = (string)($row['_id'] ?? $row['id'] ?? $row['model_id'] ?? '');
                $title = trim((string)($row['title'] ?? $row['name'] ?? ''));
                if ($id === '' || $title === '' || !preg_match('/^[A-Za-z0-9_-]{6,120}$/', $id)) continue;
                // Fish Audio's current public model-list schema identifies voice models as type=svc.
                // Accept the documented svc type (and legacy tts records) instead of
                // filtering out the actual public voice catalogue.
                if (isset($row['type']) && !in_array((string)$row['type'], ['svc', 'tts'], true)) continue;
                if (isset($row['state']) && (string)$row['state'] === 'failed') continue;
                $languages = $row['languages'] ?? $row['language'] ?? [];
                if (is_string($languages)) $languages = [$languages];
                if (!is_array($languages)) $languages = [];
                $tags = $row['tags'] ?? [];
                if (is_string($tags)) $tags = [$tags];
                if (!is_array($tags)) $tags = [];
                // Fish Audio model records can expose one or more provider-hosted sample clips.
                // Only return HTTPS preview URLs from Fish Audio-owned hosts; never proxy arbitrary URLs.
                $samples = $row['samples'] ?? [];
                if (is_array($samples) && isset($samples['audio'])) $samples = [$samples];
                $previewUrl = '';
                if (is_array($samples)) {
                    foreach ($samples as $sample) {
                        if (!is_array($sample)) continue;
                        $audioField = $sample['audio'] ?? '';
                        if (is_array($audioField)) $audioField = $audioField['url'] ?? $audioField['uri'] ?? '';
                        $candidate = (string)($audioField ?: ($sample['audio_url'] ?? $sample['url'] ?? $sample['sample_url'] ?? ''));
                        $parts = $candidate !== '' ? parse_url($candidate) : false;
                        $host = is_array($parts) ? strtolower((string)($parts['host'] ?? '')) : '';
                        if (($parts['scheme'] ?? '') === 'https' && ($host === 'fish.audio' || str_ends_with($host, '.fish.audio'))) { $previewUrl = $candidate; break; }
                    }
                }
                $voices[] = [
                    'id' => $id,
                    'provider' => 'Fish Audio',
                    'title' => (function_exists('mb_substr') ? mb_substr($title, 0, 120) : substr($title, 0, 120)),
                    'description' => (function_exists('mb_substr') ? mb_substr(trim((string)($row['description'] ?? '')), 0, 260) : substr(trim((string)($row['description'] ?? '')), 0, 260)),
                    'languages' => array_values(array_slice(array_filter(array_map(static fn($v) => is_scalar($v) ? (function_exists('mb_substr') ? mb_substr((string)$v, 0, 40) : substr((string)$v, 0, 40)) : '', $languages)), 0, 8)),
                    'tags' => array_values(array_slice(array_filter(array_map(static fn($v) => is_scalar($v) ? (function_exists('mb_substr') ? mb_substr((string)$v, 0, 40) : substr((string)$v, 0, 40)) : '', $tags)), 0, 10)),
                    'cover' => filter_var((string)($row['cover_image'] ?? $row['cover'] ?? ''), FILTER_VALIDATE_URL) ? (string)($row['cover_image'] ?? $row['cover']) : '',
                    'preview_url' => $previewUrl,
                    'visibility' => in_array((string)($row['visibility'] ?? ''), ['public', 'private', 'unlist'], true) ? (string)$row['visibility'] : '',
                ];
            }
            fish_audio_note_result($key, $status);
            $total = (int)($decoded['total'] ?? $decoded['total_count'] ?? $decoded['count'] ?? 0);
            $rawCount = count($rows);
            $hasMore = array_key_exists('has_more', $decoded) && is_bool($decoded['has_more'])
                ? $decoded['has_more']
                : ($total > 0 ? ($page * $pageSize < $total) : ($rawCount >= $pageSize));
            return ['voices' => $voices, 'page' => $page, 'page_size' => $pageSize, 'total' => $total, 'has_more' => $hasMore];
        }
        $decoded = is_string($body) ? json_decode($body, true) : null;
        $lastError = is_array($decoded) ? (string)($decoded['message'] ?? $decoded['detail'] ?? 'Fish Audio rejected the voice-library request.') : ($curlError !== '' ? 'Could not connect to Fish Audio voice library.' : 'Fish Audio voice library returned HTTP ' . $status . '.');
        fish_audio_note_result($key, $status, $curlError !== '' ? ('Transport failure: ' . $curlError) : $lastError);
        if ($status !== 0 && !in_array($status, [408, 425, 429, 500, 502, 503, 504], true)) break;
    }
    throw new RuntimeException($lastError);
}




/** Additive storage for user-owned private Fish Audio voice models. */
function voice_clone_schema(): void {
    static $done=false; if($done)return; $pdo=db(); $driver=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    if($driver==='sqlite') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_profiles (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,provider_voice_id TEXT NOT NULL UNIQUE,voice_name TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',provider_state TEXT NOT NULL DEFAULT 'created',visibility TEXT NOT NULL DEFAULT 'private',consent_status INTEGER NOT NULL DEFAULT 0,consent_version TEXT NOT NULL DEFAULT 'voice-consent-v1',consent_at TEXT NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)");
        $pdo->exec('CREATE INDEX IF NOT EXISTS idx_voice_profiles_user ON voice_profiles(user_id,created_at)');
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_clone_requests(user_id INTEGER NOT NULL,request_key TEXT NOT NULL,status TEXT NOT NULL,provider_voice_id TEXT NOT NULL DEFAULT '',credits_charged INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(user_id,request_key))");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_profiles (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id BIGINT UNSIGNED NOT NULL,provider_voice_id VARCHAR(120) NOT NULL UNIQUE,voice_name VARCHAR(160) NOT NULL,description TEXT NOT NULL,provider_state VARCHAR(32) NOT NULL DEFAULT 'created',visibility VARCHAR(20) NOT NULL DEFAULT 'private',consent_status TINYINT(1) NOT NULL DEFAULT 0,consent_version VARCHAR(40) NOT NULL DEFAULT 'voice-consent-v1',consent_at DATETIME NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY idx_voice_profiles_user(user_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS voice_clone_requests(user_id BIGINT UNSIGNED NOT NULL,request_key VARCHAR(100) NOT NULL,status VARCHAR(24) NOT NULL,provider_voice_id VARCHAR(120) NOT NULL DEFAULT '',credits_charged BIGINT NOT NULL DEFAULT 0,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,PRIMARY KEY(user_id,request_key)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    $done=true;
}

/** Ensure a voice ID is either public/unlisted or belongs to the signed-in user. */
function fish_audio_user_can_use_voice(int $userId,string $voiceId): bool {
    if($voiceId==='') return true;
    if(!preg_match('/^[A-Za-z0-9_-]{6,120}$/',$voiceId)) throw new InvalidArgumentException('The Fish Audio voice ID is invalid.');
    voice_clone_schema();
    $q=db()->prepare('SELECT user_id FROM voice_profiles WHERE provider_voice_id=? LIMIT 1');$q->execute([$voiceId]);$owner=$q->fetchColumn();
    if($owner!==false){if((int)$owner!==$userId)throw new RuntimeException('This private voice belongs to another account.');return true;}
    if(!function_exists('curl_init'))throw new RuntimeException('PHP cURL is required to verify this Fish Audio voice.');
    $keys=fish_audio_key_records();if(!$keys)throw new RuntimeException('Fish Audio API key is not configured.');$last='The selected voice is not available to this account.';
    foreach($keys as $key){$ch=curl_init('https://api.fish.audio/model/'.rawurlencode($voiceId));curl_setopt_array($ch,[CURLOPT_HTTPGET=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key['key'],'Accept: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>20,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);$body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);$data=is_string($body)?json_decode($body,true):null;
        if($status>=200&&$status<300&&is_array($data)){$visibility=strtolower((string)($data['visibility']??''));if(in_array($visibility,['public','unlist'],true)){fish_audio_note_result($key,$status);return true;}throw new RuntimeException('The selected Fish Audio voice is private or unavailable to this account.');}
        $last=$status===404?'The selected Fish Audio voice could not be found.':($err!==''?'Could not verify the selected Fish Audio voice.':'Fish Audio could not verify this voice (HTTP '.$status.').');fish_audio_note_result($key,$status,$err?:$last);if($status!==0&&!in_array($status,[408,425,429,500,502,503,504],true))break;
    }
    throw new RuntimeException($last);
}

/** Create a persistent private clone using Fish Audio's documented POST /model multipart API. */
function fish_audio_create_private_voice(int $userId,string $title,string $description,array $upload,bool $consent): array {
    if($userId<1) throw new RuntimeException('Sign in before creating a voice.');
    if(!$consent) throw new InvalidArgumentException('Confirm that you own this voice sample or have explicit permission to use it.');
    if(!function_exists('curl_init') || !class_exists('CURLFile')) throw new RuntimeException('PHP cURL with file-upload support is required for voice cloning.');
    if(($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) throw new InvalidArgumentException('Choose a valid audio sample to upload.');
    $tmp=(string)($upload['tmp_name']??''); $name=(string)($upload['name']??'sample'); $size=(int)($upload['size']??0);
    if($tmp==='' || !is_uploaded_file($tmp)) throw new InvalidArgumentException('The uploaded audio sample could not be verified.');
    if($size<1024 || $size>15*1024*1024) throw new InvalidArgumentException('Audio samples must be between 1 KB and 15 MB.');
    $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
    if(!in_array($ext,['wav','mp3','m4a','opus'],true)) throw new InvalidArgumentException('Supported audio formats are WAV, MP3, M4A and OPUS.');
    $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=(string)$finfo->file($tmp);
    $allowed=['wav'=>['audio/wav','audio/x-wav','audio/vnd.wave','application/octet-stream'],'mp3'=>['audio/mpeg','audio/mp3','application/octet-stream'],'m4a'=>['audio/mp4','audio/x-m4a','video/mp4','application/octet-stream'],'opus'=>['audio/ogg','audio/opus','application/ogg','application/octet-stream']];
    if(!in_array($mime,$allowed[$ext],true)) throw new InvalidArgumentException('The uploaded file does not match its declared audio format.');
    $head=(string)file_get_contents($tmp,false,null,0,16);
    $signatureOk=match($ext){'wav'=>str_starts_with($head,'RIFF') && substr($head,8,4)==='WAVE','mp3'=>str_starts_with($head,'ID3') || (strlen($head)>1 && ord($head[0])===0xFF && (ord($head[1])&0xE0)===0xE0),'m4a'=>strlen($head)>=8 && substr($head,4,4)==='ftyp','opus'=>str_starts_with($head,'OggS'),default=>false};
    if(!$signatureOk) throw new InvalidArgumentException('The audio file signature is invalid or unsupported.');
    $title=trim($title); $description=trim($description);
    if($title==='' || app_text_length($title)>120) throw new InvalidArgumentException('Enter a voice name of 1–120 characters.');
    if(app_text_length($description)>500) throw new InvalidArgumentException('Voice description must be 500 characters or fewer.');
    $keys=fish_audio_key_records(); if(!$keys) throw new RuntimeException('Fish Audio API key is not configured. Ask an administrator to add it in Admin → Voice AI.');
    $last='Fish Audio could not create this voice model.';
    foreach($keys as $key) {
        $file=new CURLFile($tmp,$mime,'sample.'.$ext);
        $post=['type'=>'tts','title'=>$title,'description'=>$description,'visibility'=>'private','train_mode'=>'fast','voices'=>$file];
        $ch=curl_init('https://api.fish.audio/model');
        curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$post,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key['key'],'Accept: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>15,CURLOPT_TIMEOUT=>120,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
        $body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
        $json=is_string($body)?json_decode($body,true):null;
        if(is_string($body)&&$status>=200&&$status<300&&is_array($json)) {
            $providerId=(string)($json['_id']??$json['id']??'');
            if($providerId==='' || !preg_match('/^[A-Za-z0-9_-]{6,120}$/',$providerId)) throw new RuntimeException('Fish Audio returned an incomplete voice model response.');
            voice_clone_schema();
            try { db()->prepare('INSERT INTO voice_profiles(user_id,provider_voice_id,voice_name,description,provider_state,visibility,consent_status,consent_version,consent_at,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)')->execute([$userId,$providerId,$title,$description,substr((string)($json['state']??'created'),0,32),'private',1,'voice-consent-v1',now_sql(),now_sql(),now_sql()]); } catch(Throwable $storageError) { $cleanup=curl_init('https://api.fish.audio/model/'.rawurlencode($providerId));curl_setopt_array($cleanup,[CURLOPT_CUSTOMREQUEST=>'DELETE',CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key['key']],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>15,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);curl_exec($cleanup);curl_close($cleanup);throw $storageError; }
            fish_audio_note_result($key,$status);
            return ['id'=>$providerId,'name'=>$title,'state'=>(string)($json['state']??'created'),'visibility'=>'private'];
        }
        $providerMsg=is_array($json)?(string)($json['detail']??$json['message']??$json['error']??''):'';
        $last=$status===401?'Fish Audio rejected the configured API key.':($status===402?'Fish Audio reports insufficient provider balance or quota.':($status===403?'This Fish Audio account cannot create voice models.':($status===413?'The audio sample is too large for Fish Audio.':($status===422?'Fish Audio could not process this audio sample. Check its format and quality.':($status===429?'Fish Audio rate limit reached. Wait before retrying.':($err!==''?'Could not connect to Fish Audio. Check outbound HTTPS and PHP cURL.':'Fish Audio rejected the voice sample (HTTP '.$status.').'.($providerMsg!==''?' '.$providerMsg:'')))))));
        fish_audio_note_result($key,$status,$err?:$last);
        if($status!==0 && !in_array($status,[408,425,429,500,502,503,504],true)) break;
    }
    throw new RuntimeException($last);
}

function voice_owned_profiles(int $userId): array {
    voice_clone_schema(); $q=db()->prepare('SELECT provider_voice_id AS id,voice_name AS title,description,provider_state AS state,visibility,created_at FROM voice_profiles WHERE user_id=? ORDER BY created_at DESC');$q->execute([$userId]);return $q->fetchAll();
}
function fish_audio_delete_private_voice(int $userId,string $providerId): void {
    if(!preg_match('/^[A-Za-z0-9_-]{6,120}$/',$providerId)) throw new InvalidArgumentException('Invalid voice model ID.');
    voice_clone_schema();$q=db()->prepare('SELECT id FROM voice_profiles WHERE user_id=? AND provider_voice_id=? LIMIT 1');$q->execute([$userId,$providerId]);if(!$q->fetchColumn())throw new RuntimeException('This voice does not belong to your account.');
    try{$agents=db()->prepare('SELECT config_json FROM agents WHERE user_id=?');$agents->execute([$userId]);foreach($agents->fetchAll(PDO::FETCH_COLUMN) as $configJson){$config=json_decode((string)$configJson,true);if(is_array($config)&&($config['voice']['voice_id']??'')===$providerId)throw new RuntimeException('This voice is assigned to one or more AI agents. Change those agent voices before deleting it.');}}catch(PDOException $ignored){}
    $keys=fish_audio_key_records();if(!$keys)throw new RuntimeException('Fish Audio is not configured.');$done=false;$last='Fish Audio could not delete this voice model.';
    foreach($keys as $key){$ch=curl_init('https://api.fish.audio/model/'.rawurlencode($providerId));curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>'DELETE',CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key['key'],'Accept: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>12,CURLOPT_TIMEOUT=>30,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);$body=curl_exec($ch);$status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);if($status>=200&&$status<300){$done=true;fish_audio_note_result($key,$status);break;}$last=$status===401?'Fish Audio rejected the configured API key.':($status===404?'Fish Audio no longer has this voice model.':($err!==''?'Could not connect to Fish Audio.': 'Fish Audio rejected the delete request (HTTP '.$status.').'));fish_audio_note_result($key,$status,$err?:$last);if($status!==0&&!in_array($status,[408,425,429,500,502,503,504],true))break;}
    if(!$done)throw new RuntimeException($last);
    db()->prepare('DELETE FROM voice_profiles WHERE user_id=? AND provider_voice_id=?')->execute([$userId,$providerId]);
}

/** Voice wallet and durable generation history. One credit is charged per configured
 * 100-character block by default. Failed provider calls are refunded automatically. */
function voice_wallet_ensure(int $userId): void {
    $pdo = db(); $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
    $initial = max(0, (int)voice_setting('initial_credits', '250'));
    if ($driver === 'sqlite') {
        $insert=$pdo->prepare('INSERT OR IGNORE INTO user_wallets(user_id,balance,updated_at) VALUES(?,?,?)');
    } else {
        $insert=$pdo->prepare('INSERT IGNORE INTO user_wallets(user_id,balance,updated_at) VALUES(?,?,?)');
    }
    $insert->execute([$userId,$initial,now_sql()]);
    if ($insert->rowCount() === 1 && $initial > 0) {
        $pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')->execute([$userId,$initial,$initial,'Welcome credits','initial-grant',now_sql()]);
    }
}
function voice_wallet_balance(int $userId): int {
    voice_wallet_ensure($userId); $s=db()->prepare('SELECT balance FROM user_wallets WHERE user_id=?'); $s->execute([$userId]); return max(0,(int)$s->fetchColumn());
}
function voice_credit_cost(int $characters): int {
    $rate=max(0,(int)voice_setting('credits_per_100_chars','1'));
    return (int)ceil(max(1,$characters)/100)*$rate;
}
function voice_charge_credits(int $userId, int $amount, string $reference, string $reason = 'Voice generation'): int {
    if ($userId < 1 || $amount < 1 || !preg_match('/^[A-Za-z0-9_-]{12,100}$/', $reference)) throw new InvalidArgumentException('Invalid wallet transaction.');
    $pdo=db(); voice_wallet_ensure($userId); $sqlite=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite';
    try {
        if ($sqlite) $pdo->exec('BEGIN IMMEDIATE'); else $pdo->beginTransaction();
        // A dedicated unique key table closes the concurrent-request race on
        // both SQLite and MySQL without imposing uniqueness on legacy ledger rows.
        try {
            $pdo->prepare('INSERT INTO voice_request_keys(user_id,request_key,created_at) VALUES(?,?,?)')->execute([$userId,$reference,now_sql()]);
        } catch (PDOException $duplicate) {
            $state=(string)($duplicate->errorInfo[0]??$duplicate->getCode());
            if (in_array($state,['23000','19','SQLITE_CONSTRAINT'],true)) {
                throw new RuntimeException('This voice request has already been charged. Check Voice History before retrying.');
            }
            throw $duplicate;
        }
        $dupe=$pdo->prepare("SELECT id FROM credit_transactions WHERE user_id=? AND reference_id=? AND amount<0 LIMIT 1");
        $dupe->execute([$userId,$reference]);
        if ($dupe->fetchColumn()) throw new RuntimeException('This voice request has already been charged. Use a new idempotency key for a new request.');
        $s=$pdo->prepare('UPDATE user_wallets SET balance=balance-?,updated_at=? WHERE user_id=? AND balance>=?');
        $s->execute([$amount,now_sql(),$userId,$amount]);
        if ($s->rowCount() !== 1) throw new RuntimeException('Insufficient voice credits. Please top up your account or reduce the script length.');
        $q=$pdo->prepare('SELECT balance FROM user_wallets WHERE user_id=?'); $q->execute([$userId]); $balance=(int)$q->fetchColumn();
        $pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')->execute([$userId,-$amount,$balance,$reason,$reference,now_sql()]);
        if ($sqlite) $pdo->exec('COMMIT'); else $pdo->commit();
        return $balance;
    } catch (Throwable $e) {
        if ($sqlite) { try { $pdo->exec('ROLLBACK'); } catch(Throwable $ignored) {} }
        elseif ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}
function voice_refund_credits(int $userId, int $amount, string $reference, string $reason = 'Voice generation refund'): void {
    if ($userId < 1 || $amount < 1) return;
    $pdo=db(); $sqlite=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite';
    try {
        if ($sqlite) $pdo->exec('BEGIN IMMEDIATE'); else $pdo->beginTransaction();
        $refundClaimed=true;
        try {
            $pdo->prepare('INSERT INTO voice_refunds(user_id,request_key,created_at) VALUES(?,?,?)')->execute([$userId,$reference,now_sql()]);
        } catch (PDOException $duplicate) {
            $state=(string)($duplicate->errorInfo[0]??$duplicate->getCode());
            if (!in_array($state,['23000','19','SQLITE_CONSTRAINT'],true)) throw $duplicate;
            $refundClaimed=false;
        }
        if ($refundClaimed) {
            $q=$pdo->prepare('SELECT id FROM credit_transactions WHERE user_id=? AND reference_id=? AND amount>0 AND reason=? LIMIT 1');
            $q->execute([$userId,$reference,$reason]);
            if (!$q->fetchColumn()) {
                $debit=$pdo->prepare("SELECT id FROM credit_transactions WHERE user_id=? AND reference_id=? AND amount<0 LIMIT 1");
                $debit->execute([$userId,$reference]);
                if ($debit->fetchColumn()) {
                    $pdo->prepare('UPDATE user_wallets SET balance=balance+?,updated_at=? WHERE user_id=?')->execute([$amount,now_sql(),$userId]);
                    $b=$pdo->prepare('SELECT balance FROM user_wallets WHERE user_id=?'); $b->execute([$userId]); $balance=(int)$b->fetchColumn();
                    $pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')->execute([$userId,$amount,$balance,$reason,$reference,now_sql()]);
                }
            }
        }
        if ($sqlite) $pdo->exec('COMMIT'); else $pdo->commit();
    } catch(Throwable $e) {
        if ($sqlite) { try { $pdo->exec('ROLLBACK'); } catch(Throwable $ignored) {} }
        elseif ($pdo->inTransaction()) $pdo->rollBack();
        throw $e;
    }
}
function voice_history_store(int $userId, string $script, string $voiceId, array $result, int $credits): string {
    $dir=APP_ROOT.'/storage/voice-audio';
    if (is_link($dir)) throw new RuntimeException('Voice audio storage path is not safe.');
    if (!is_dir($dir) && !mkdir($dir,0750,true) && !is_dir($dir)) throw new RuntimeException('Could not create private voice audio storage.');
    if (!is_writable($dir)) throw new RuntimeException('Private voice audio storage is not writable.');
    $deny=$dir.'/.htaccess';if(!is_file($deny))@file_put_contents($deny,"Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    $audioBytes=strlen((string)($result['audio']??''));
    $quota=max(1,(int)(app_config()['max_storage_per_user_bytes']??1073741824));
    if(platform_storage_used_bytes(owner_key(),$userId)+$audioBytes>$quota) throw new InvalidArgumentException('Your account storage quota has been reached. Delete older assets before saving another voice generation.');
    $id=bin2hex(random_bytes(16)); $filename=$id.'.mp3'; $path=$dir.'/'.$filename;
    if (file_put_contents($path,$result['audio'],LOCK_EX)===false) throw new RuntimeException('Could not save generated audio to history.');
    @chmod($path,0640);
    try { db()->prepare('INSERT INTO voice_generations(id,user_id,script,voice_id,model,audio_file,audio_bytes,credits_charged,created_at) VALUES(?,?,?,?,?,?,?,?,?)')->execute([$id,$userId,$script,$voiceId,(string)$result['model'],$filename,strlen($result['audio']),$credits,now_sql()]); }
    catch(Throwable $e){@unlink($path);throw $e;}
    return $id;
}
