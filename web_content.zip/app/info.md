# Crônicas do Cristal

Jogo de ação e plataforma 2D para navegador, portado do protótipo Godot 4 original
(`Cronicas_do_Cristal_Projeto.zip`) para a web com Phaser 3. Três reinos, espada,
magia em área e cristais ancestrais.

## Jogar

- `npm run dev` (desenvolvimento) ou `npm run build && npm run preview` (produção).
- Desktop: A/D ou setas para mover, Espaço/W para pular, J espada, K magia, ESC pausa, M som.
- Celular: botões de toque na tela (aparecem em telas de toque), com pausa e controle de som.

## Objetivo

Atravesse as três fases (Bosque dos Ecos, Ruínas Submersas, Cidadela Sombria),
colete cristais — 5 deles desbloqueiam a Explosão Arcana — derrote o Guardião
e alcance o portal final. Vida e mana são finitas (o protótipo tinha valores
ilimitados); quedas no vazio custam vida.

## Estrutura

```
src/game/boot.ts            entrada: cria o Phaser.Game + controles touch DOM
src/game/config.ts          ajustes (física/combate herdados do GDScript original)
src/game/levels.ts          as três fases e seus temas visuais
src/game/hero.ts            herói: física, espada, magia, animação por partes
src/game/enemy.ts           inimigos + chefe (IA de patrulha/perseguição)
src/game/art.ts             texturas procedurais (céu, montanhas, piso, brilhos)
src/game/audio.ts           SFX + música sintetizados (Web Audio), sem arquivos
src/game/scenes/            Title / Game / Pause / End (vitória e derrota)
src/game/input.ts           estado compartilhado dos botões touch
src/game/run.ts             estado da campanha + recordes (localStorage do navegador)
public/                     ícones e PWA (manifest + service worker)
```

## Sistemas

- Loop completo de estados: título → jogo ⇄ pausa → vitória/derrota → reinício.
- Combate: espada (dano 2, alcance curto), Explosão Arcana (dano 5 em área, 35 de mana,
  desbloqueada com 5 cristais), dano por contato, invulnerabilidade pós-dano.
- Inimigos perseguem num raio de 260px; o chefe da Cidadela tem 40 de HP e barra própria.
- Progressão de fases por portal; cristais, recordes e configuração de som persistem
  no navegador (não sincronizam entre dispositivos).
- Arte 100% procedural (canvas) e áudio 100% sintetizado; sem assets externos,
  exceto o ícone do app gerado por IA em `public/`.
