# Apex Festival v1.5 — Android APK (telefonla derleme)

Bu proje Capacitor ile Android uygulaması olarak paketlenecek şekilde hazırlandı.
APK henüz bu ZIP'in içinde değildir; GitHub Actions derleme işlemini bulutta yapar.

## Telefonda yapılacaklar

1. GitHub hesabına giriş yap.
2. Bu ZIP'i açıp içindeki tüm dosyaları bir GitHub deposuna yükle. Depo **Public** veya hesabında Actions kullanmaya izin veren **Private** olabilir.
3. Depoda `app/` klasörünün ve kökte `.github/workflows/android-apk.yml` dosyasının bulunduğunu kontrol et.
4. GitHub deposunda **Actions** sekmesini aç.
5. Soldan **Build Apex Festival Android APK** iş akışını seç.
6. **Run workflow** → **Run workflow** düğmesine dokun.
7. İşlem tamamlanınca ilgili çalışmanın sayfasına gir. **Artifacts** bölümünden `Apex-Festival-debug-APK` dosyasını indir.
8. ZIP içinden `app-debug.apk` dosyasını çıkarıp Android'e kur.

## Notlar

- Bu bir **debug APK**'dır; telefona test amaçlı kurulabilir. Google Play yayını için imzalı release/AAB süreci ayrıca gerekir.
- Derleme GitHub sunucularında yapılır; telefona Android Studio kurman gerekmez.
- İlk derleme birkaç dakika sürebilir.
- Uygulama kimliği: `com.apexfestival.game`.
- Oyunun kaynak kodu ve mevcut oyun içeriği değiştirilmemiştir; Capacitor paketleme yapılandırması eklenmiştir.
- GitHub Actions çalışması hata verirse logdaki ilk `FAILURE` bölümünü paylaş; ona göre düzeltelim.
