<?php
declare(strict_types=1);
require_once __DIR__.'/auth.php';
require_once __DIR__.'/voice.php';
require_once __DIR__.'/magichour.php';
require_once __DIR__.'/payments.php';
require_once __DIR__.'/credits.php';

function admin_audit(string $action,string $type='',string $id='',array $details=[]): void {
    try { $u=auth_user(); db()->prepare('INSERT INTO admin_audit_logs(actor_user_id,action,target_type,target_id,details,ip_address,created_at) VALUES(?,?,?,?,?,?,?)')->execute([$u['id']??null,$action,$type,$id,json_encode($details,JSON_UNESCAPED_SLASHES),substr((string)($_SERVER['REMOTE_ADDR']??''),0,64),now_sql()]); } catch(Throwable $ignored) {}
}
function admin_encrypt_key(string $plain): array {
    if(!function_exists('openssl_encrypt')) throw new RuntimeException('OpenSSL is required to securely store API keys.');
    $cfg=app_config();$secret=trim((string)($cfg['admin_api_encryption_key']??''));
    if(strlen($secret)<32 || stripos($secret,'REPLACE_WITH')!==false) throw new RuntimeException('Configure ANONYMOUX_KEY_ENCRYPTION_SECRET with at least 32 characters in your hosting environment or private config before adding API keys.');
    $nonce=random_bytes(12);$tag='';$cipher=openssl_encrypt($plain,'aes-256-gcm',hash('sha256',$secret,true),0,$nonce,$tag);
    if(!is_string($cipher)) throw new RuntimeException('Could not encrypt the API key.');
    return [$cipher,base64_encode($nonce),base64_encode($tag)];
}
function admin_handle_post(array $admin): ?string {
    if($_SERVER['REQUEST_METHOD']!=='POST') return null;
    if(!auth_csrf_valid()) return 'Security token expired. Refresh and try again.';
    $action=(string)($_POST['admin_action']??'');
    try {
        if(in_array($action,['save_flutterwave_config','package_save','package_toggle'],true)) payments_schema();
        if($action==='test_flutterwave_connection'){
            $fw=payment_gateway_config();if($fw['secret_key']==='')throw new InvalidArgumentException('Save a Flutterwave secret key first.');
            $test=payment_http('GET','https://api.flutterwave.com/v3/balances?currency='.rawurlencode($fw['currency']),[],$fw['secret_key']);
            if($test['status']<200||$test['status']>=300||($test['json']['status']??'')!=='success')throw new RuntimeException('Flutterwave authentication test failed (HTTP '.$test['status'].').');
            payment_setting_set('last_test_at',now_sql());admin_audit('flutterwave_connection_tested','payment_gateway','flutterwave',['http_status'=>$test['status'],'currency'=>$fw['currency']]);return 'Flutterwave API authentication succeeded.';
        }
        if($action==='save_flutterwave_config'){
            $pub=trim((string)($_POST['public_key']??''));$secret=trim((string)($_POST['secret_key']??''));$hook=trim((string)($_POST['webhook_hash']??''));
            $mode=(string)($_POST['mode']??'test');$currency=strtoupper(trim((string)($_POST['currency']??'NGN')));$enabled=isset($_POST['gateway_enabled'])?'1':'0';
            if($pub!==''&&strlen($pub)>200)throw new InvalidArgumentException('Public key is too long.');
            if($mode!=='test'&&$mode!=='live')throw new InvalidArgumentException('Select test or live mode.');
            if(!preg_match('/^[A-Z]{3}$/',$currency))throw new InvalidArgumentException('Enter a valid ISO currency code.');
            if($enabled==='1'&&($pub===''||($secret===''&&payment_secret_get('secret_key')==='')||($hook===''&&payment_secret_get('webhook_hash')==='')))throw new InvalidArgumentException('To activate Flutterwave, configure a public key, secret key and webhook secret hash first.');
            payment_setting_set('public_key',$pub);payment_setting_set('mode',$mode);payment_setting_set('currency',$currency);payment_setting_set('enabled',$enabled);
            payment_store_secret('secret_key',$secret);payment_store_secret('webhook_hash',$hook);
            admin_audit('flutterwave_config_updated','payment_gateway','flutterwave',['mode'=>$mode,'currency'=>$currency,'enabled'=>$enabled==='1','secret_updated'=>$secret!=='','webhook_updated'=>$hook!=='']);
            return 'Flutterwave configuration saved. Secret fields are encrypted and never displayed.';
        }
        if($action==='package_save'){
            $id=(int)($_POST['package_id']??0);$name=trim((string)($_POST['package_name']??''));$desc=trim((string)($_POST['package_description']??''));$price=(float)($_POST['package_price']??0);$credits=(int)($_POST['package_credits']??0);$currency=strtoupper(trim((string)($_POST['package_currency']??'NGN')));$sort=max(0,min(100000,(int)($_POST['package_sort_order']??100)));$badge=trim((string)($_POST['package_badge']??''));$bonus=max(0,min(100000000,(int)($_POST['package_bonus']??0)));if(strlen($badge)>80)throw new InvalidArgumentException('Promotional badge must be 80 characters or fewer.');
            if($name===''||strlen($name)>120||strlen($desc)>500||$price<=0||$price>100000000||$credits<1||$credits>100000000||!preg_match('/^[A-Z]{3}$/',$currency))throw new InvalidArgumentException('Enter valid package details.');
            $minor=(int)round($price*100);$now=now_sql();
            if($id>0){db()->prepare('UPDATE credit_packages SET name=?,description=?,price_minor=?,credits=?,currency=?,sort_order=?,promo_badge=?,bonus_credits=?,updated_at=? WHERE id=?')->execute([$name,$desc,$minor,$credits,$currency,$sort,$badge,$bonus,$now,$id]);}
            else{db()->prepare('INSERT INTO credit_packages(name,description,price_minor,credits,currency,is_active,sort_order,promo_badge,bonus_credits,created_at,updated_at) VALUES(?,?,?,?,?,1,?,?,?, ?,?)')->execute([$name,$desc,$minor,$credits,$currency,$sort,$badge,$bonus,$now,$now]);$id=(int)db()->lastInsertId();}
            admin_audit('credit_package_saved','credit_package',(string)$id,['price_minor'=>$minor,'credits'=>$credits,'currency'=>$currency]);return 'Credit package saved.';
        }
        if($action==='package_toggle'){
            $id=(int)($_POST['package_id']??0);db()->prepare('UPDATE credit_packages SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END,updated_at=? WHERE id=?')->execute([now_sql(),$id]);admin_audit('credit_package_toggled','credit_package',(string)$id);return 'Credit package status updated.';
        }
        if($action==='add_api_key'){
            $label=trim((string)($_POST['label']??''));$key=trim((string)($_POST['api_key']??''));
            if($label===''||strlen($label)>120) throw new InvalidArgumentException('Enter a key label (maximum 120 characters).');
            if(strlen($key)<12||strlen($key)>500) throw new InvalidArgumentException('Enter a valid API key.');
            [$cipher,$nonce,$tag]=admin_encrypt_key($key);
            db()->prepare('INSERT INTO admin_api_keys(label,encrypted_key,nonce,auth_tag,is_active,priority,created_at,updated_at) VALUES(?,?,?,?,1,?,?,?)')->execute([$label,$cipher,$nonce,$tag,max(1,(int)($_POST['priority']??100)),now_sql(),now_sql()]);
            admin_audit('api_key_added','api_key',(string)db()->lastInsertId(),['label'=>$label]);return 'API key encrypted and added.';
        }
        if($action==='toggle_api_key'){
            $id=(int)($_POST['id']??0);$s=db()->prepare('UPDATE admin_api_keys SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END,updated_at=? WHERE id=?');$s->execute([now_sql(),$id]);admin_audit('api_key_status_changed','api_key',(string)$id);return 'API key status updated.';
        }
        if($action==='delete_api_key'){
            $id=(int)($_POST['id']??0);db()->prepare('DELETE FROM admin_api_keys WHERE id=?')->execute([$id]);admin_audit('api_key_deleted','api_key',(string)$id);return 'API key removed.';
        }
        if($action==='test_fish_audio_connection'){
            $result=fish_audio_list_voices(1,1);
            $count=count($result['voices']??[]);
            admin_audit('fish_audio_connection_tested','ai_provider','fish_audio',['http_test'=>'success','sample_voices_returned'=>$count]);
            return 'Fish Audio authentication succeeded. Provider voice-list request completed; '.$count.' voice record(s) returned on the first page.';
        }
        if($action==='add_fish_audio_key'){
            $label=trim((string)($_POST['label']??''));$key=trim((string)($_POST['fish_api_key']??''));
            if($label===''||strlen($label)>120) throw new InvalidArgumentException('Enter a Fish Audio key label (maximum 120 characters).');
            if(strlen($key)<12||strlen($key)>500) throw new InvalidArgumentException('Enter a valid Fish Audio API key.');
            [$cipher,$nonce,$tag]=voice_encrypt_key($key);
            db()->prepare('INSERT INTO fish_audio_keys(label,encrypted_key,nonce,auth_tag,is_active,priority,created_at,updated_at) VALUES(?,?,?,?,1,?,?,?)')->execute([$label,$cipher,$nonce,$tag,max(1,(int)($_POST['priority']??100)),now_sql(),now_sql()]);
            admin_audit('fish_audio_key_added','fish_audio_key',(string)db()->lastInsertId(),['label'=>$label]);return 'Fish Audio API key encrypted and added.';
        }
        if($action==='toggle_fish_audio_key'){$id=(int)($_POST['id']??0);db()->prepare('UPDATE fish_audio_keys SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END,updated_at=? WHERE id=?')->execute([now_sql(),$id]);admin_audit('fish_audio_key_status_changed','fish_audio_key',(string)$id);return 'Fish Audio key status updated.';}
        if($action==='delete_fish_audio_key'){$id=(int)($_POST['id']??0);db()->prepare('DELETE FROM fish_audio_keys WHERE id=?')->execute([$id]);admin_audit('fish_audio_key_deleted','fish_audio_key',(string)$id);return 'Fish Audio key removed.';}
        if($action==='save_voice_settings'){
            $voice=trim((string)($_POST['default_voice']??''));$speed=(float)($_POST['default_speed']??1);$initialCredits=(int)($_POST['initial_credits']??250);$creditsRate=(int)($_POST['credits_per_100_chars']??1);$cloneRate=(int)($_POST['credits_per_voice_clone']??100);$agentRate=(float)($_POST['agent_credits_per_usd']??0);$agentMinute=(float)($_POST['agent_conversation_usd_per_minute']??0);
            if(strlen($voice)>120||($voice!==''&&!preg_match('/^[A-Za-z0-9_-]+$/',$voice)))throw new InvalidArgumentException('Enter a valid Fish Audio voice reference ID.');
            if($speed<0.7||$speed>1.3)throw new InvalidArgumentException('Playback speed must be between 0.70 and 1.30.');
            if($initialCredits<0||$initialCredits>1000000||$creditsRate<0||$creditsRate>1000||$cloneRate<0||$cloneRate>100000||$agentRate<0||$agentRate>1000000||$agentMinute<0||$agentMinute>10)throw new InvalidArgumentException('Credit settings are outside the allowed range.');
            voice_setting_set('default_voice',$voice);voice_setting_set('default_speed',(string)$speed);voice_setting_set('initial_credits',(string)$initialCredits);voice_setting_set('credits_per_100_chars',(string)$creditsRate);voice_setting_set('credits_per_voice_clone',(string)$cloneRate);voice_setting_set('agent_credits_per_usd',(string)$agentRate);voice_setting_set('agent_conversation_usd_per_minute',(string)$agentMinute);admin_audit('voice_settings_updated','voice_settings','fish_audio',['default_voice_set'=>$voice!=='','default_speed'=>$speed,'initial_credits'=>$initialCredits,'credits_per_100_chars'=>$creditsRate,'credits_per_voice_clone'=>$cloneRate,'agent_credits_per_usd'=>$agentRate,'agent_conversation_usd_per_minute'=>$agentMinute]);return 'Voice settings saved.';
        }
        if($action==='save_magichour_settings'){
            $key=trim((string)($_POST['magichour_api_key']??''));
            if($key!==''){
                if(strlen($key)<12||strlen($key)>500)throw new InvalidArgumentException('Enter a valid Magic Hour API key.');
                [$cipher,$nonce,$tag]=admin_encrypt_key($key);
                mh_setting_set('key_cipher',$cipher);mh_setting_set('key_nonce',$nonce);mh_setting_set('key_tag',$tag);
            }
            $enabled=isset($_POST['magichour_enabled'])?'1':'0';
            $price=(int)($_POST['magichour_credit_price']??30);
            if($price<1||$price>100000)throw new InvalidArgumentException('Lip Sync credit price must be between 1 and 100,000.');
            $modes=trim((string)($_POST['magichour_modes']??'lite'));
            $modeList=array_values(array_unique(array_filter(array_map(static fn($v)=>strtolower(trim($v)),explode(',',$modes)),static fn($v)=>preg_match('/^[a-z0-9_-]{1,40}$/',$v))));
            if(!$modeList)throw new InvalidArgumentException('Add at least one generation mode.');
            mh_setting_set('enabled',$enabled);mh_setting_set('credit_price',(string)$price);mh_setting_set('modes',implode(',',$modeList));
            admin_audit('magichour_settings_updated','provider','magichour',['enabled'=>$enabled==='1','credit_price'=>$price,'modes'=>$modeList,'key_updated'=>$key!=='']);
            return 'Magic Hour settings saved. Only configure modes confirmed for your Magic Hour account.';
        }
        if($action==='test_magichour_connection'){
            if(!mh_api_key())throw new InvalidArgumentException('Add a Magic Hour API key before testing the connection.');
            $test=mh_api_request('GET','/account',null,30);
            if($test['status']<200||$test['status']>=300)throw new RuntimeException(mh_error($test));
            mh_setting_set('account_credits',(string)max(0,(int)($test['json']['credits']??0)));mh_setting_set('account_tier',(string)($test['json']['tier']??'unknown'));mh_setting_set('last_test_at',now_sql());
            admin_audit('magichour_connection_tested','provider','magichour',['http_status'=>$test['status']]);
            return 'Magic Hour API authentication succeeded.';
        }
        if($action==='save_workspace_credit_prices'){
            $fields=['image_credit_price'=>'credit_price_image','video_credit_price'=>'credit_price_video','realtime_credit_price'=>'credit_price_realtime','lip_sync_credit_price'=>'credit_price_lip_sync'];
            $values=[]; foreach($fields as $field=>$key){$value=(int)($_POST[$field]??0);if($value<1||$value>1000000)throw new InvalidArgumentException('Every workspace price must be between 1 and 1,000,000 credits.');$values[$key]=$value;}
            $pdo=db(); $driver=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME); foreach($values as $key=>$value){$sql=$driver==='sqlite'?'INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=excluded.updated_at':'INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=VALUES(updated_at)';$pdo->prepare($sql)->execute([$key,(string)$value,now_sql()]);}
            $voiceRate=(int)($_POST['voice_credit_rate']??1);$cloneRate=(int)($_POST['voice_clone_credit_price']??100);$agentRate=(float)($_POST['agent_credits_per_usd']??0);
            if($voiceRate<0||$voiceRate>1000||$cloneRate<0||$cloneRate>100000||$agentRate<0||$agentRate>1000000)throw new InvalidArgumentException('Voice and Agent pricing values are outside their allowed range.');
            voice_setting_set('credits_per_100_chars',(string)$voiceRate);voice_setting_set('credits_per_voice_clone',(string)$cloneRate);voice_setting_set('agent_credits_per_usd',(string)$agentRate);mh_setting_set('credit_price',(string)$values['credit_price_lip_sync']);
            admin_audit('workspace_credit_prices_updated','billing','all_workspaces',['prices'=>$values,'voice_per_100_chars'=>$voiceRate,'voice_clone'=>$cloneRate,'agent_credits_per_usd'=>$agentRate]);
            return 'Workspace pricing saved. Image, Video, Voice and Lip Sync use their server-side billing paths. Realtime is priced per provider-measured active second and settled after the session ends; any unpaid measured usage is recorded for retry. AI Agent usage uses provider-measured reconciliation.';
        }
        if($action==='model_toggle'){
            $model=(string)($_POST['model']??'');$enabled=(string)($_POST['enabled']??'0');
            if(!in_array($model,['lucy-image-2','lucy-2.5','lucy-2.6'],true)||!in_array($enabled,['0','1'],true)) throw new InvalidArgumentException('Invalid model setting.');
            if(db()->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite') db()->prepare('INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value,updated_at=excluded.updated_at')->execute(['model_enabled_'.$model,$enabled,now_sql()]);
            else db()->prepare('INSERT INTO platform_settings(setting_key,setting_value,updated_at) VALUES(?,?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=VALUES(updated_at)')->execute(['model_enabled_'.$model,$enabled,now_sql()]);
            admin_audit('model_availability_changed','model',$model,['enabled'=>$enabled==='1']);return 'Model availability updated.';
        }
        if($action==='wallet_adjust'){
            $id=(int)($_POST['id']??0);$delta=(int)($_POST['credit_delta']??0);
            if($id<1||$delta===0||abs($delta)>1000000)throw new InvalidArgumentException('Enter a non-zero credit adjustment up to 1,000,000.');
            voice_wallet_ensure($id);$pdo=db();$pdo->beginTransaction();
            try{$q=$pdo->prepare('SELECT balance FROM user_wallets WHERE user_id=?'.($pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='mysql'?' FOR UPDATE':''));$q->execute([$id]);$before=(int)$q->fetchColumn();$after=$before+$delta;if($after<0)throw new InvalidArgumentException('A wallet cannot have a negative balance.');$pdo->prepare('UPDATE user_wallets SET balance=?,updated_at=? WHERE user_id=?')->execute([$after,now_sql(),$id]);$pdo->prepare('INSERT INTO credit_transactions(user_id,amount,balance_after,reason,reference_id,created_at) VALUES(?,?,?,?,?,?)')->execute([$id,$delta,$after,'Administrator adjustment','admin-'.$admin['id'].'-'.bin2hex(random_bytes(5)),now_sql()]);$pdo->commit();}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
            admin_audit('wallet_credits_adjusted','user',(string)$id,['delta'=>$delta,'balance_after'=>$after]);return 'User credits adjusted successfully.';
        }
        if($action==='user_update'){
            $id=(int)($_POST['id']??0);$status=(string)($_POST['status']??'active');$role=(string)($_POST['role']??'member');
            if($id<1||!in_array($status,['active','suspended'],true)||!in_array($role,['member','admin'],true)) throw new InvalidArgumentException('Invalid user update.');
            if($id===(int)$admin['id']&&($status!=='active'||$role!=='admin')) throw new InvalidArgumentException('You cannot suspend or remove your own administrator access.');
            if($status!=='active'||$role!=='admin'){$s=db()->prepare("SELECT COUNT(*) FROM users WHERE role='admin' AND status='active' AND id<>?");$s->execute([$id]);if((int)$s->fetchColumn()<1)throw new InvalidArgumentException('Keep at least one active administrator account.');}
            db()->prepare('UPDATE users SET status=?,role=?,updated_at=? WHERE id=?')->execute([$status,$role,now_sql(),$id]);admin_audit('user_updated','user',(string)$id,['status'=>$status,'role'=>$role]);return 'User account updated.';
        }
    } catch(Throwable $e){return $e->getMessage();}
    return 'Unknown administration action.';
}
