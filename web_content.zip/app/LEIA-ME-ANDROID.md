# PontoVivo: gerar o APK no Android Studio

O projeto já inclui a pasta `android/` pronta (Capacitor 8). Só falta o teu
`google-services.json` e a chave do Google Maps.

## 1. Requisitos
- **Android Studio** (versão recente; traz o Android SDK e o JDK)
- **Node.js 24 ou superior** (o Firebase 13 exige-o)

## 2. Chave do Google Maps
Copia `.env.example` para `.env.local` e preenche `VITE_GOOGLE_MAPS_API_KEY`.
Na Google Cloud Console, em Credenciais > a tua chave > Restrições de sites,
junta **`https://localhost/*`** (é a origem da app dentro do APK).

## 3. Firebase (login com Google no Android)
1. Consola Firebase > projeto `brave-autonomy-hmln4` > Definições > **Adicionar app > Android**.
2. Nome do pacote: `pt.pontovivo.app` (igual ao `appId` em `capacitor.config.ts`).
3. Junta o **SHA-1** da chave de debug. No Android Studio: separador Gradle >
   `app` > Tasks > android > **signingReport** (ou, no terminal:
   `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android`).
4. Authentication > Sign-in method: confirma que **Google** está ativo.
5. **Só depois** de adicionar o SHA-1, descarrega o `google-services.json` e
   coloca-o em `android/app/google-services.json`.

## 4. Abrir no Android Studio
```bash
npm install
npm run android
```
Este comando compila a parte web, sincroniza com o Android e abre o Android Studio.
Espera que o Gradle termine o "Sync" (a primeira vez demora e descarrega muita coisa).

## 5. Gerar o APK
Android Studio > **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
O ficheiro fica em `android/app/build/outputs/apk/debug/app-debug.apk`.
Passa-o para o telemóvel, abre-o e permite instalar de "fontes desconhecidas".
Ou liga o telemóvel por USB (depuração USB ativa) e carrega em **Run ▶**.

Depois de alterares código web: `npm run cap:sync` e volta a gerar.

## 6. APK final (assinado)
**Build > Generate Signed App Bundle / APK**. Guarda o `.keystore` e a palavra-passe
(sem eles não podes atualizar a app). Junta o SHA-1 dessa chave ao Firebase
e descarrega o `google-services.json` outra vez.

## O que está adaptado para Android
- **Login Google nativo** (a janela popup não funciona no APK)
- **Localização com o ecrã bloqueado**: ao partilhar, arranca um serviço com
  notificação permanente "partilha de localização ativa"
- **Partilha** pelo menu nativo do Android
- **Meteorologia** direta (Open-Meteo), sem precisar do servidor `server.ts`
- Permissões: localização, notificações, câmara e microfone (SOS)
- Ícone da app e SOS sem números de emergência

## Limitações conhecidas
- Não consegui compilar o Gradle nem testar num telemóvel aqui. A parte web
  compila (`tsc` e `vite build` sem erros), mas é normal precisares de acertar
  detalhes no primeiro build.
- O mapa usa o Google Maps JavaScript (precisa de internet e de chave válida).
- Na primeira partilha, o Android pede localização e notificações: aceita ambas.
  Em alguns telemóveis (Xiaomi, Huawei, Samsung) convém desativar a otimização
  de bateria para a app, senão o sistema pode parar a localização.
