# Security Specification & Payload-First TDD

## 1. Data Invariants
1. Every `Tracker` must belong to a verified authenticated `ownerId == request.auth.uid` on creation, with server-enforced `createdAt`, `updatedAt`, and `lastSeenAt`.
2. `TrackPoint` documents under `/trackers/{trackerId}/points/{pointId}` can only be created by the owner of the parent `Tracker` (`get(.../trackers/$(trackerId)).data.ownerId == request.auth.uid`), with optional bounded telemetry extras (`altitude`, `altitudeAccuracy`, `batteryLevel`, `batteryCharging`, `address`, `weatherTempC`, `weatherCondition`, `weatherWindKmh`, `weatherHumidity`, `distanceFromPrevMeters`, `isSos`).
3. `ShareInvite` documents cannot be listed (`allow list: if false`); only exact `get` by a verified user who knows the `shareCode` is permitted.
4. `Geofence` and `GeofenceAlert` records are strictly private to their `ownerId`.
5. `SosEvent` documents under `/sosEvents/{sosId}` can only be created/updated by `ownerId == request.auth.uid`, read/listed only by `ownerId` or bounded `viewerIds` (`<= 20`), and are terminally locked once `status == 'resolved'`.
6. `SosSignal` documents under `/sosEvents/{sosId}/signals/{signalId}` require Master Gate validation against an active parent `SosEvent`, enforce `senderId == request.auth.uid`, restrict list/get to `ownerId` or `viewerIds`, and bound `payload` (`<= 16000` chars).
7. No unverified email (`email_verified != true`) or unauthenticated requests may read or write any collection.
8. All coordinates (`lat` in `[-90, 90]`, `lng` in `[-180, 180]`), string lengths, numeric ranges, and array sizes (`viewerIds.size() <= 20`) are strictly bounded.

## 2. Adversarial "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. **Identity Spoofing on Tracker Create**: `{ "ownerId": "victim_uid", "name": "Spoof", ... }` -> Denied (`ownerId != request.auth.uid`).
2. **Shadow Ghost Field on TrackPoint Create**: Valid track point + `{ "isAdmin": true }` -> Denied (`hasOnly` rejects extra field).
3. **Invalid Coordinates / Telemetry Poisoning**: `{ "lat": 145.0, "altitude": 999999, "weatherTempC": 500, ... }` -> Denied (out-of-range numeric bounds).
4. **Client Timestamp Tampering**: `{ "createdAt": "2020-01-01T00:00:00Z", ... }` -> Denied (`createdAt != request.time`).
5. **Path ID Poisoning**: Document ID `"a".repeat(200)` or `"bad/id$"` -> Denied (`isValidId` fails).
6. **Privilege Escalation via Viewer Join**: Viewer attempts to overwrite `ownerId` or `name` or `lat` during join -> Denied (`affectedKeys().hasOnly(['viewerIds', 'updatedAt'])`).
7. **Terminal State Bypass on Resolved SOS**: Owner attempts to reopen or mutate a `status == 'resolved'` `SosEvent` -> Denied (`existing().status == 'active'`).
8. **Unbounded Array Exhaustion**: `viewerIds` with 25 entries -> Denied (`viewerIds.size() <= 20`).
9. **Blanket Collection Scraping**: `list` on `/shareInvites` or `/sosEvents` without owner/viewer predicate -> Denied.
10. **Cross-Tenant Geofence Read**: User B tries `get` or `list` on User A's `/geofences` -> Denied (`ownerId == request.auth.uid`).
11. **Orphaned / Unauthorized SOS Signal Injection**: Outsider not in `viewerIds` creates `/sosEvents/{sosId}/signals/s1` -> Denied (Master Gate parent check fails).
12. **Unverified Email Spoof**: Authenticated token with `email_verified: false` -> Denied (`isVerifiedUser()` fails).
