<?php
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

function auth_schema(): void {
    static $ready = false; if ($ready) return; $pdo = db();
    if ($pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite') {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL COLLATE NOCASE UNIQUE, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'member', status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL, updated_at TEXT NOT NULL, last_login_at TEXT NULL)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_users_status ON users(status)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_bootstrap_lock (id INTEGER PRIMARY KEY CHECK(id=1),created_at TEXT NOT NULL)");
        $pdo->prepare('INSERT OR IGNORE INTO admin_bootstrap_lock(id,created_at) VALUES(1,?)')->execute([date('Y-m-d H:i:s')]);
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE, password_hash VARCHAR(255) NOT NULL, role VARCHAR(20) NOT NULL DEFAULT 'member', status VARCHAR(20) NOT NULL DEFAULT 'active', created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, last_login_at DATETIME NULL, KEY idx_users_status(status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_bootstrap_lock (id TINYINT UNSIGNED NOT NULL PRIMARY KEY,created_at DATETIME NOT NULL) ENGINE=InnoDB");
        $pdo->prepare('INSERT IGNORE INTO admin_bootstrap_lock(id,created_at) VALUES(1,?)')->execute([date('Y-m-d H:i:s')]);
    }
    $ready = true;
}
function auth_user(): ?array { auth_schema(); $id=(int)($_SESSION['user_id']??0); if($id<1)return null; $s=db()->prepare('SELECT id,name,email,role,status,created_at,last_login_at FROM users WHERE id=? LIMIT 1');$s->execute([$id]);$u=$s->fetch();if(!$u||$u['status']!=='active'){unset($_SESSION['user_id']);return null;}return $u; }
function auth_require_user(): array { $u=auth_user(); if(!$u){$next=(string)($_SERVER['REQUEST_URI']??'dashboard.php');header('Location: '.app_base_path().'login.php?next='.rawurlencode($next));exit;}return $u; }
function api_require_user(): array { $u=auth_user(); if(!$u) json_response(['ok'=>false,'error'=>'Authentication required. Please sign in and retry.'],401); return $u; }
function auth_require_admin(): array { $u=auth_require_user(); if(($u['role']??'member')!=='admin'){http_response_code(403);exit('Access denied. Administrator privileges are required.');}return $u; }
function auth_csrf_valid(): bool { $v=$_POST['_csrf']??'';return is_string($v)&&hash_equals(csrf_token(),$v); }

function auth_login_throttle(string $email, ?bool $success = null): void {
    $dir = APP_ROOT . '/storage/auth-rate-limits';
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Sign-in protection is temporarily unavailable.');
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $key = hash('sha256', strtolower(trim($email)) . "\0" . $ip);
    $path = $dir . '/' . $key . '.json';
    $fp = @fopen($path, 'c+');
    if (!$fp || !flock($fp, LOCK_EX)) { if (is_resource($fp)) fclose($fp); throw new RuntimeException('Sign-in protection is temporarily unavailable.'); }
    rewind($fp); $raw = stream_get_contents($fp); $state = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($state) || time() - (int)($state['start'] ?? 0) >= 900) $state = ['start'=>time(),'count'=>0];
    if ($success) $state = ['start'=>time(),'count'=>0];
    elseif ((int)$state['count'] >= 8) { flock($fp, LOCK_UN); fclose($fp); throw new InvalidArgumentException('Too many sign-in attempts. Wait 15 minutes and try again.'); }
    elseif ($success === false) $state['count'] = (int)$state['count'] + 1;
    rewind($fp); ftruncate($fp, 0); fwrite($fp, json_encode($state)); fflush($fp); flock($fp, LOCK_UN); fclose($fp);
}


function auth_bind_legacy_workspace(int $userId, string $oldOwnerKey): void {
    if ($userId < 1 || $oldOwnerKey === '') return;
    $newOwnerKey = hash('sha256', 'anonymoux-account-owner-v1:' . $userId);
    if (hash_equals($newOwnerKey, $oldOwnerKey)) return;
    $pdo=db();
    $tables=['prompt_library','workspace_preferences','reference_uploads','realtime_sessions','voice_usage','platform_jobs','platform_assets'];
    foreach($tables as $table) {
        try {
            if ($table==='workspace_preferences') $pdo->prepare('UPDATE workspace_preferences SET owner_key=? WHERE owner_key=?')->execute([$newOwnerKey,$oldOwnerKey]);
            else $pdo->prepare('UPDATE '.$table.' SET owner_key=? WHERE owner_key=?')->execute([$newOwnerKey,$oldOwnerKey]);
        } catch(Throwable $ignored) { /* Optional feature tables are created by their owning module. */ }
    }
}

function auth_login(string $email,string $password): bool {
    auth_schema();
    auth_login_throttle($email);$s=db()->prepare('SELECT id,password_hash,status FROM users WHERE email=? LIMIT 1');$s->execute([strtolower(trim($email))]);$u=$s->fetch();
    if(!$u||$u['status']!=='active'||!password_verify($password,(string)$u['password_hash'])){ auth_login_throttle($email);return false; }
    if(password_needs_rehash((string)$u['password_hash'],PASSWORD_DEFAULT)){db()->prepare('UPDATE users SET password_hash=?,updated_at=? WHERE id=?')->execute([password_hash($password,PASSWORD_DEFAULT),now_sql(),$u['id']]);}
    auth_login_throttle($email, true);$legacyOwner=owner_key();auth_bind_legacy_workspace((int)$u['id'],$legacyOwner);session_regenerate_id(true);$_SESSION['owner_token']=bin2hex(random_bytes(32));unset($_SESSION['auth_attempts'],$_SESSION['rate_limits']);$_SESSION['user_id']=(int)$u['id'];$_SESSION['auth_login_at']=time();db()->prepare('UPDATE users SET last_login_at=?,updated_at=? WHERE id=?')->execute([now_sql(),now_sql(),$u['id']]);
    try { require_once __DIR__.'/resources.php'; resources_schema(); resources_insert_notification((int)$u['id'],'security-login:'.date('YmdHis').':'.bin2hex(random_bytes(4)),'New account sign-in','Your ANONYMOUX account was signed in successfully. If this was not you, sign out and review your account access.','security','settings.php',now_sql()); } catch(Throwable $ignored) { /* Sign-in remains available if optional notifications are unavailable. */ }
    return true;
}
function auth_register(string $name,string $email,string $password): int {
    auth_schema();$name=trim($name);$email=strtolower(trim($email));
    if((function_exists('mb_strlen')?mb_strlen($name):strlen($name))<2||(function_exists('mb_strlen')?mb_strlen($name):strlen($name))>100)throw new InvalidArgumentException('Name must be between 2 and 100 characters.');
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>190)throw new InvalidArgumentException('Enter a valid email address.');
    if(strlen($password)<10||strlen($password)>200)throw new InvalidArgumentException('Password must be at least 10 characters.');
    $pdo=db();$sqlite=$pdo->getAttribute(PDO::ATTR_DRIVER_NAME)==='sqlite';
    try {
        if($sqlite)$pdo->exec('BEGIN IMMEDIATE');else $pdo->beginTransaction();
        // Public registration must never grant administrator privileges. Initial
        // administrator provisioning is performed only by the hosting CLI tool.
        $lock=$pdo->prepare('SELECT id FROM admin_bootstrap_lock WHERE id=1'.($sqlite?'':' FOR UPDATE'));$lock->execute();
        $stmt=$pdo->prepare('INSERT INTO users (name,email,password_hash,role,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)');
        $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),'member','active',now_sql(),now_sql()]);
        $id=(int)$pdo->lastInsertId();
        if($sqlite)$pdo->exec('COMMIT');else $pdo->commit();
        return $id;
    } catch(PDOException $e) {
        if($sqlite){try{$pdo->exec('ROLLBACK');}catch(Throwable $ignored){}}elseif($pdo->inTransaction())$pdo->rollBack();
        if(str_contains(strtolower($e->getMessage()),'unique'))throw new InvalidArgumentException('An account with this email already exists.');
        throw $e;
    } catch(Throwable $e) {
        if($sqlite){try{$pdo->exec('ROLLBACK');}catch(Throwable $ignored){}}elseif($pdo->inTransaction())$pdo->rollBack();
        throw $e;
    }
}
function auth_logout(): void {
    unset($_SESSION['user_id'], $_SESSION['auth_login_at'], $_SESSION['auth_attempts'], $_SESSION['rate_limits'], $_SESSION['remote_sessions']);
    $_SESSION['owner_token'] = bin2hex(random_bytes(32));
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    session_regenerate_id(true);
}
function auth_redirect_target(string $target): string { if($target===''||str_contains($target,"\r")||str_contains($target,"\n")||!str_starts_with($target,'/')||str_starts_with($target,'//'))return 'dashboard.php'; if(preg_match('/^(\/login|\/register|\/logout)(\.php)?(?:\?|$)/i',$target))return 'dashboard.php';return $target; }
