# TGPSC Ready — SI & Constable Exam Notes App

A free, offline-friendly study app for TGPSC Police (SI/Constable) aspirants.

## How to run
1. Unzip this folder.
2. Open `index.html` directly in any browser (double-click it) — no server or install needed.
   - Or, for the best experience (so relative asset loading always works), serve the folder:
     `python3 -m http.server 8000` then visit `http://localhost:8000`.

## Files
- `index.html` — entry point / app shell
- `style.css` — design system (ledger/notebook-inspired theme, light + dark mode)
- `data.js` — all subject & topic notes content (edit this to add more notes)
- `app.js` — app logic: navigation, search, progress, bookmarks, rewards, downloads

## Features
- 14 subjects, 60+ topic notes (Polity, History, Geography, Economy, Telangana History & GK,
  Science, Arithmetic, Reasoning — including Odd Man Out, Puzzle Test, Direction & Distance,
  Letter Series, and Clocks — English, Computer Awareness, Environment, Current Affairs).
- Full-text search across every topic.
- Mark topics as studied, bookmark topics, track progress per subject and overall.
- Download any single topic, any whole subject, or the entire note bank, as `.txt` or `.pdf`.
- Dark/light theme toggle, fully responsive (mobile drawer navigation).
- A working "StudyCoins" rewards engine: coins for study time, marking topics studied,
  downloading notes, and a simulated "watch a video, earn coins" flow.

## Adding more notes
Open `data.js` and add a new object to the `SUBJECTS` array, or a new topic object inside an
existing subject's `topics` array, following the existing `{ title, explain, trick, quiz, answer }`
shape. No other file needs to change.

## About the "earn money" feature
The rewards system (StudyCoins, watch-to-earn flow, download credits) is fully built and
functional as a front-end demo — coins are real, tracked, and persisted in the browser
(`localStorage`). Turning StudyCoins into an actual payout requires two things this app
intentionally does not include, since they need real accounts/credentials:
1. A real ad network integration (e.g. Google AdSense or AdMob rewarded video ads) in place
   of the simulated 15-second "watch to earn" modal.
2. A backend service + payment gateway to convert coin balances into real money and pay users out.

The coin logic, UI, and event hooks are all in place in `app.js` (`startRewardedAd`,
`creditDownload`, and the study-timer coin ticks) — swapping in a real ad SDK call and a
server-side ledger is the only extra work needed.
