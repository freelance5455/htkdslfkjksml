# Hyper Character Design
AI-powered 3D character design studio (Web + Android via Capacitor). Start with `docs/README.md` (বাংলা: `docs/BANGLA_README.md`).
