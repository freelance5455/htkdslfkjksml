# Apex Festival (v1.5 · open world)

A mobile-friendly, offline-first 3D open-world racing game built with Three.js.

## Objective

Explore the festival region in free roam or compete against three AI rivals in Village Sprint, Blackpine Trail, and Highland Circuit. Pass every amber checkpoint before time expires. Drifting charges nitro; boost provides extra acceleration. Seasons change the world, weather, and available grip.

## Controls

- **W / Up:** throttle
- **S / Down:** brake and reverse
- **A / D or Left / Right:** steer
- **Shift:** handbrake / drift
- **Space:** nitro; also starts or retries from menus
- **E:** enter a nearby festival event
- **R:** recover the car
- **Esc:** pause / resume
- **M:** mute
- **Gamepad:** left stick steering, triggers for throttle/brake, A handbrake, B boost
- **Touch:** landscape steering, gas, brake, drift, and boost buttons

## Game flow

Title → free roam or race → pause/resume → finish or DNF results → retry, next event, free roam, or title. Credits, influence, best times, and mute preference are stored locally in this browser only. Clearing browser data removes progress; it does not sync between devices.

## Run

```bash
npm install
npm run dev
```

Production:

```bash
npm run build
npm run preview
```

## Rendering and performance

The game uses a fixed 60 Hz simulation, chase camera, instanced vegetation/buildings, optimized reusable car geometry, pooled weather buffers, spatially indexed road queries, fog-based view limits, and automatic resolution scaling. The busiest verification scenes used roughly 20–40 draw calls and 40,000–55,000 rendered triangles. Browser verification used Chromium with software WebGL, which validates rendering and behavior but is not a physical Android GPU benchmark.

## Scope

This is an original playable browser-game prototype, not a native Android APK and not a licensed Forza product. Online multiplayer, cloud saves, licensed vehicles, and a full 40–50 km² production map are outside this prototype.

## v1.5 — what changed

**Bug fixes**
- Tapping a country on the world map did nothing and `tsc -b` failed: `enterRegion()` was called but never written. Regions now rebuild their own terrain, roads, props and events behind a loading screen.
- The car was drawn rotated 90° off its direction of travel (the asset's front is at -X; v1.4 used a 180° flip and `rotation.y = +heading`). Visuals now use `facingYaw = -90°` and `rotation.y = -heading`. Wheels now spin about the axle (not the car's length axis) at the real rolling rate, and steer about the vertical axis. Nose lifts on acceleration, dives on braking.
- Minimap arrow was mirrored; tire smoke particles never disappeared.

**Performance (target: stable ≥ 30 FPS on mid-range phones)**
- Removed `transmission` + `clearcoat` car materials (transmission forces an extra full-scene render pass). Car/world now use Phong/Lambert.
- Removed every `backdrop-filter` (blurring a live WebGL canvas is very expensive on mobile GPUs).
- `preserveDrawingBuffer` only with `?verify` (needed by `scripts/verify-game.mjs`).
- Adaptive quality governor (`src/game/quality.ts`): lowers render resolution first, then whole tiers (view distance, prop density, particles, traffic, skid marks); promotes again on fast devices. Tier 3 ("low") caps to a stable 30 FPS. Pause menu → GRAPHICS cycles AUTO / HIGH / BALANCED / ECO; FPS toggle shows live fps, tier and resolution scale.
- Trees are instanced in 106 m chunks (frustum + distance culled); density is changed at runtime without rebuilding. Traffic and far-away rivals are 2 instanced draw calls total. Skid marks are one draw call (ring buffer).
- Interpolated rendering of the 60 Hz simulation, tighter catch-up limits, weather updated per rendered frame, cached HUD DOM lookups, minimap static layer.

**World / gameplay**
- Four distinct regions: Alpine peaks and chalets, Dutch windmills + tulip fields + tree-lined roads, Finnish lakes, British villages/windmill/ferris wheel. Mountain ring + haze, sky dome, sun/moon/stars, clouds.
- Dynamic time of day (pause → TIME OF DAY), headlights with ground light cone, brake lights, nitro flames, speed-lines overlay.
- Solid trees/rocks (spatial-grid collisions), ambient traffic, 28 collectible festival tokens per region, drift chains that bank credits, water hazard + smarter recover (R).

## Tests
`npm test` runs `src/game/logic.test.ts` (quality governor, terrain/lakes, road index, obstacle grid).
