# STEEL COURTYARD — Mobile Tactical Arena FPS

A complete 3D first-person tactical shooter for browser: 5-round team combat inside a
walled stone fortress. Built with **Three.js + TypeScript** on the `game-3d` template
(React shell + fixed-timestep loop). All characters, weapons and the arena are
parametric 3D models — no external art assets. All audio is synthesized at runtime.

## Run it

```bash
npm install        # once
npm run build      # type-check + bundle to dist/
npm run preview    # serve dist/ locally
```

`npm run dev` runs the Vite dev server with HMR for development.
`node scripts/verify-game.mjs` (after a build) runs the automated Playwright smoke
check: zero console errors, canvas render check, direction assertions, screenshots.

## Controls

| Action | Touch | Desktop |
|---|---|---|
| Move | left virtual joystick | WASD / arrows |
| Look | drag on open screen | mouse (click canvas to lock) |
| Fire | hold FIRE | hold LMB |
| Aim (ADS) | hold ⊕ | hold RMB |
| Reload | ⟳ button | R |
| Swap weapon | ⇄ button | Q / 1 / 2 |
| Grenade | grenade button (badge = count) | G |
| Crouch | crouch button (toggles stance) | C / Shift |
| Armor plate | ✚ button | E |
| Pause | ≡ button | Esc |
| Start / restart | DEPLOY / PLAY AGAIN | Space / Enter |

## Architecture (src/game/)

Everything is imperative TypeScript under `src/game/`; React only mounts the canvas
(`src/pages/Home.tsx` → `startGame(canvas)` / `stopGame()` in `boot.ts`).

| Module | Responsibility |
|---|---|
| `boot.ts` | Renderer/scene/camera, fixed-timestep loop, state machine glue, all cross-system wiring |
| `config.ts` | All tuning: player, weapons, grenades, bots, match, colors |
| `arena.ts` | Fortress geometry, static AABB colliders, slab raycasts, LOS, collision resolve, waypoints, spawns |
| `player.ts` | PlayerController — movement, crouch (camera height), look, collision, plates, HP regen |
| `weapon.ts` | WeaponSystem — hitscan, spread/bloom, recoil, ADS, reload, viewmodel + arms, ray helpers |
| `grenade.ts` | GrenadeSystem — parabolic throw, wall/ground bounces, fuse, radial AoE |
| `enemy.ts` | Parametric soldier models + EnemyAI (patrol ⇄ engage, vision cone, LOS, burst fire, strafing) |
| `match.ts` | MatchManager — countdown → fight → round end → match end, scores, round resets |
| `hud.ts` | MobileHUDController — builds the whole DOM overlay, joystick, buttons, minimap, kill feed |
| `effects.ts` | Pooled tracers, muzzle flashes, particles, explosions (zero hot-loop allocation) |
| `input.ts` | Unified input — keyboard/mouse + touch writes the same fields |
| `audio.ts` | Synthesized SFX + adaptive music, mute persisted in localStorage |
| `engine.ts` / `state.ts` | Fixed-timestep loop and the title/playing/paused/gameover state machine (template base) |

## How the pieces connect (no missing references)

- **UI wiring**: `MobileHUDController` receives the `GameInput` instance and writes
  touch state directly into it (`joyX/joyY`, `fireHeld`, `aimHeld`,
  `queueAction("reload"|"grenade"|"switch"|"crouch"|"plate")`). Desktop keyboard/mouse
  write the same fields, so game systems read one source of truth. Buttons dispatch
  `pointerdown`/`pointerup` with `stopPropagation`, so they never trigger touch-look;
  look-drag lives on the canvas in `boot.ts` and feeds `input.feedLook()`.
- **Flow callbacks**: the HUD exposes `onDeploy / onPause / onResume / onRestart /
  onMuteToggle`; `boot.ts` assigns them to state-machine transitions. The HUD never
  calls game systems directly and vice versa — `MatchManager` talks to the HUD only
  through its constructor hooks (`onKillFeed`, `onBanner`, `onMatchEnd`, …).
- **Damage & kills**: every elimination routes through `MatchManager.onKill`
  (player weapon → `WeaponSystem.onShoot` → `Bot.takeDamage`; bot fire →
  `BotHooks.onPlayerHit`; grenades → `GrenadeSystem` AoE callbacks), so the kill feed
  and team scores always agree.
- **Rounds**: `MatchManager` calls the injected `resetRound()` (respawns player +
  bots at team spawns, refills ammo and grenades) between rounds; first to 5 takes
  the match and lands on the game-over screen.
- **Verification hooks**: `window.__gameProbe()` (player position),
  `window.__GAME_READY__` (first rendered frame) and `window.__matchInfo()` back the
  automated self-checks.

## Notes

- Collision, bullet raycasts and AI line-of-sight are analytic (slab tests against
  the arena's AABB list) — no physics-engine dependency for the static world.
- Ally bots (blue) and enemy bots (red) share the same `Bot` class; team targeting
  is data-driven, so blue allies hunt red bots and vice versa.
- The minimap, crosshair gap, hit markers, damage numbers, banners and loadout bar
  update every frame from the same `HudFrameData` snapshot.
