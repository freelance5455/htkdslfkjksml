/* ============================================================
   TGPSC Police (SI/Constable) Master Notes — Data
   Built from: Odd Man Out, Puzzle Test, Direction & Distance,
   Letter Series, Clocks, and the TGPRB Master Notes.
   Structure: subjects[] -> topics[] -> {id, title, explain, trick, quiz, answer}
   ============================================================ */

const SUBJECTS = [
  {
    id: "polity",
    name: "Indian Polity",
    icon: "⚖",
    topics: [
      { title: "Constitution", explain: "Think of it as India's rule book: it defines government powers and citizen rights.", trick: "26 Nov 1949 — adopted. 26 Jan 1950 — came into effect.", quiz: "On what date was the Constitution adopted, and on what date did it come into force?", answer: "Adopted 26 Nov 1949; effective 26 Jan 1950." },
      { title: "Fundamental Rights", explain: "Articles 12–35 protect the core individual freedoms of every citizen.", trick: "Remember the six baskets: Equality, Freedom, against Exploitation, Religion, Culture & Education, Constitutional Remedies.", quiz: "Which article range covers Fundamental Rights?", answer: "Articles 12–35." },
      { title: "DPSP", explain: "Directive Principles of State Policy are guidelines for building a welfare-oriented State.", trick: "Rights = a citizen's claim; Duties = a citizen's responsibility; DPSP = the government's goal.", quiz: "What is the core idea behind DPSP?", answer: "Non-justiciable guidelines directing the State toward welfare goals." },
      { title: "President & PM", explain: "The President is the constitutional (nominal) head of State; the PM and Council of Ministers hold real executive power.", trick: "Common MCQ trap: constitutional head is NOT the same as real executive head.", quiz: "Who exercises real executive power in India?", answer: "The Prime Minister and Council of Ministers." },
      { title: "Parliament", explain: "Parliament = President + Lok Sabha + Rajya Sabha, not just the two Houses.", trick: "Don't forget the President is part of Parliament when answering definition questions.", quiz: "What three components make up Parliament?", answer: "President, Lok Sabha, Rajya Sabha." },
    ],
  },
  {
    id: "history",
    name: "Indian History",
    icon: "🏛",
    topics: [
      { title: "Ancient India", explain: "Indus Valley Civilisation, Vedic Age, rise of Buddhism and Jainism, Mauryan and Gupta empires are the core areas.", trick: "Build a timeline and attach one signature contribution to each period.", quiz: "Name the two major religious movements of ancient India that arose as a reaction to Vedic ritualism.", answer: "Buddhism and Jainism." },
      { title: "Medieval India", explain: "Delhi Sultanate, Vijayanagara Empire, the Mughals, and the Bhakti–Sufi movements.", trick: "For every dynasty, learn: Founder → key ruler → administration → lasting contribution.", quiz: "Which two devotional movements defined medieval Indian religious life?", answer: "The Bhakti movement (Hindu) and the Sufi movement (Islamic)." },
      { title: "Modern India", explain: "Company rule, the Revolt of 1857, the growth of the national movement, and independence in 1947.", trick: "Anchor timeline: 1857 → 1885 → 1920 → 1930 → 1942 → 1947.", quiz: "What event happened in 1885?", answer: "Formation of the Indian National Congress." },
      { title: "Freedom Movement", explain: "Non-Cooperation, Civil Disobedience, and Quit India were the three major mass movements led by Gandhi.", trick: "1920 → Non-Cooperation Movement; 1930 → Civil Disobedience Movement; 1942 → Quit India Movement.", quiz: "Which movement began in 1930?", answer: "The Civil Disobedience Movement (Dandi March)." },
    ],
  },
  {
    id: "geography",
    name: "Geography (India)",
    icon: "🗺",
    topics: [
      { title: "Physical Divisions", explain: "India is divided into the Himalayas, Northern Plains, Peninsular Plateau, the Great Indian Desert, and Coasts & Islands.", trick: "Mnemonic: H – N – P – D – C – I.", quiz: "Name the five major physical divisions of India.", answer: "Himalayas, Northern Plains, Peninsular Plateau, Desert, Coasts & Islands." },
      { title: "Rivers", explain: "For every major river study its origin, tributaries, states it flows through, key projects, and drainage direction.", trick: "Make one master river table for fast revision before the exam.", quiz: "What five facts should you note for every river?", answer: "Origin, tributaries, states covered, projects, drainage direction." },
      { title: "Soils", explain: "Alluvial soil is the most widespread in India; black soil is strongly linked with cotton cultivation; red and laterite soils are also important.", trick: "Association to remember: Black soil = Cotton (\"black cotton soil\").", quiz: "Which soil type is best known for cotton cultivation?", answer: "Black (regur) soil." },
      { title: "Monsoon", explain: "The monsoon is a seasonal reversal of winds that controls most of India's rainfall.", trick: "Study it in four stages: onset → advance → peak → retreat.", quiz: "What four stages make up the monsoon cycle?", answer: "Onset, advance, peak, retreat." },
    ],
  },
  {
    id: "economy",
    name: "Indian Economy",
    icon: "📈",
    topics: [
      { title: "GDP", explain: "Gross Domestic Product is the value of all final goods and services produced within an economy over a period.", trick: "GDP = production, not income or spending.", quiz: "What does GDP measure?", answer: "The value of final goods and services produced within a period." },
      { title: "Inflation", explain: "Inflation is a sustained rise in the general price level over time.", trick: "Inflation = prices rising economy-wide, not just one product.", quiz: "Define inflation in one line.", answer: "A sustained rise in the general price level." },
      { title: "RBI", explain: "The Reserve Bank of India is the central bank; it manages monetary policy and regulates banking.", trick: "Repo Rate = the rate at which RBI lends money to commercial banks.", quiz: "What is the Repo Rate?", answer: "The rate at which RBI lends to commercial banks." },
      { title: "Fiscal Policy", explain: "Fiscal policy covers government taxation, spending, and borrowing decisions.", trick: "Fiscal = Government's money; Monetary = Central bank's money.", quiz: "What is the key difference between fiscal and monetary policy?", answer: "Fiscal policy is run by the government (tax/spend); monetary policy is run by the central bank (money supply/interest rates)." },
    ],
  },
  {
    id: "telangana-history",
    name: "Telangana History & Movement",
    icon: "🚩",
    topics: [
      { title: "State Formation", explain: "Telangana became India's 29th state on 2 June 2014, separated from Andhra Pradesh.", trick: "2 June = Telangana Formation Day — a guaranteed static-GK question.", quiz: "On what date was Telangana formed?", answer: "2 June 2014." },
      { title: "Historical Periods", explain: "Key ruling periods: Kakatiyas, Qutb Shahis, Asaf Jahis (Nizams), the princely Hyderabad State, and its integration into the Indian Union.", trick: "For every dynasty learn: Ruler → Capital → Contribution.", quiz: "Name the dynasty famous for the Kakatiya rule and their capital.", answer: "The Kakatiyas, capital at Warangal (Orugallu)." },
      { title: "Telangana Movement", explain: "Study the causes, phases, key leaders, major events, and final outcome of the statehood movement.", trick: "Answer four questions for every phase: Why? What? Who? Result?", quiz: "What are the four questions to ask about any phase of the movement?", answer: "Why, What, Who, Result." },
    ],
  },
  {
    id: "telangana-geo",
    name: "Telangana Geography & GK",
    icon: "📍",
    topics: [
      { title: "Rivers of Telangana", explain: "The Godavari and Krishna river systems, their tributaries, and major irrigation projects are the most important areas.", trick: "Practice matching each irrigation project to its river using a map.", quiz: "Which two rivers dominate Telangana's drainage system?", answer: "Godavari and Krishna." },
      { title: "Districts", explain: "Learn the current districts of Telangana along with major towns, rivers, forests, and mineral resources in each.", trick: "Revise 5–6 districts at a time rather than all at once.", quiz: "What five details should you know for each district?", answer: "District name, major towns, rivers, forests, resources." },
      { title: "State Facts", explain: "Learn Telangana's official symbols (state bird, animal, tree, flower) and key cultural facts from an updated source.", trick: "Static facts can be revised by the government — always verify close to the exam date.", quiz: "Why should static state facts be double-checked before the exam?", answer: "Because official symbols/facts can be updated over time." },
    ],
  },
  {
    id: "science",
    name: "General Science",
    icon: "🔬",
    topics: [
      { title: "Physics", explain: "Force changes an object's motion; work is force applied over a displacement; power is the rate of doing work.", trick: "Power = Work ÷ Time.", quiz: "What is the formula for power?", answer: "Power = Work / Time." },
      { title: "Chemistry", explain: "Core areas: atoms and elements, acids, bases, salts, metals/non-metals, and common chemical reactions.", trick: "For each topic learn: Definition → Example → Everyday use.", quiz: "What three things should you note for every chemistry concept?", answer: "Definition, example, use." },
      { title: "Biology", explain: "The cell is the basic unit of life. Also study organs, body systems, common diseases, vitamins, and ecology.", trick: "Vitamin C deficiency → Scurvy; Vitamin D deficiency → Rickets.", quiz: "Which disease results from Vitamin C deficiency?", answer: "Scurvy." },
      { title: "Human Body", explain: "The heart pumps blood, the lungs exchange gases, the kidneys filter blood, and the brain coordinates the whole body.", trick: "Pair every organ with its one main function for quick recall.", quiz: "What is the kidney's main function?", answer: "Filtering the blood." },
    ],
  },
  {
    id: "arithmetic",
    name: "Arithmetic",
    icon: "🧮",
    topics: [
      { title: "Percentage", explain: "Percentage = (Part ÷ Whole) × 100.", trick: "10% = divide by 10; 5% = half of the 10% value; 1% = divide by 100.", quiz: "What is 15% of 200 using the shortcut?", answer: "10% of 200 = 20; 5% = 10; 15% = 20+10 = 30." },
      { title: "Profit & Loss", explain: "Profit = Selling Price − Cost Price. Loss = Cost Price − Selling Price.", trick: "Profit % and Loss % are normally calculated on the Cost Price (CP).", quiz: "On which value is profit % normally calculated?", answer: "Cost Price (CP)." },
      { title: "Simple Interest", explain: "SI = (Principal × Rate × Time) ÷ 100.", trick: "Always convert months into years before applying the formula.", quiz: "Write the Simple Interest formula.", answer: "SI = P×R×T/100." },
      { title: "Ratio & Proportion", explain: "A ratio compares two quantities; a proportion states that two ratios are equal.", trick: "a:b = c:d  ⇒  a×d = b×c (cross-multiplication).", quiz: "How do you test if two ratios form a proportion?", answer: "Cross-multiply: a×d should equal b×c." },
      { title: "Average", explain: "Average = Sum of all values ÷ Number of values.", trick: "If every value in a set increases by x, the average also increases by exactly x.", quiz: "If each of 5 numbers increases by 4, what happens to their average?", answer: "The average also increases by 4." },
      { title: "Time, Speed & Distance", explain: "Speed = Distance ÷ Time; Distance = Speed × Time; Time = Distance ÷ Speed.", trick: "Memory triangle: Distance on top, Speed × Time on the bottom.", quiz: "A train covers 180 km in 3 hours — what is its speed?", answer: "180 ÷ 3 = 60 km/h." },
      { title: "Time & Work", explain: "If a person finishes a job in x days, their one-day work is 1/x of the job.", trick: "For people working together, simply add their individual one-day work rates.", quiz: "A finishes a job in 10 days. What fraction does A complete in one day?", answer: "1/10 of the job." },
    ],
  },
  {
    id: "reasoning",
    name: "Reasoning",
    icon: "🧩",
    topics: [
      {
        title: "Odd Man Out",
        explain: "Four classic patterns show up in Odd-One-Out questions — Number-based (primes, squares/cubes, powers & factorials, arithmetic on the digits, multiples & factors), Alphabet-based (a constant difference between two letters' positions, A=1…Z=26), Word-based (all items belong to one category except one, e.g. Mercury/Jupiter/Saturn/Venus are planets but the Moon is a satellite), and Figure-based (count sides, count inner/outer lines, or compare markings).",
        trick: "For letter pairs, find the position-number difference for each option — the odd one breaks the constant difference. For number pairs, apply the same arithmetic rule (e.g. ×2 − 10) to every option; the one that fails is the answer. For cube-number sets, check n³ (1,8,27,64,125,216,343,512,729,1000,1331…). Word-groups: ask 'what single category do three of these share?' — the odd one won't fit.",
        quiz: "Which does not belong: 216, 512, 343, 728?",
        answer: "728 — since 216=6³, 512=8³, 343=7³ are perfect cubes, but 728 is not (9³=729).",
      },
      {
        title: "Puzzle Test — Types",
        explain: "Puzzle tests appear in several formats: Day-based, Floor-based, Condition/tabular-based, Age-based, Vacant-floor-based, and Seating-with-direction puzzles.",
        trick: "Always read the entire question once before solving. Use ready-made shortcuts (e.g. a floor/day table) instead of solving from scratch each time. Arrange positive and negative clues on the same diagram/timeline together so contradictions are easy to spot.",
        quiz: "What should you do before attempting any puzzle?",
        answer: "Read the full question carefully first, then build a table/diagram from the clues.",
      },
      {
        title: "Puzzle Test — Floor Example",
        explain: "5 friends P, Q, R, S, T live on 5 different floors. P lives on an odd floor with no one above him. R is on the 2nd floor. One person is between S and T. T lives at the bottom.",
        trick: "Start with the most fixed clues: 'no one above him' + 'odd floor' fixes P at the top (floor 5). 'T at bottom' fixes floor 1. Place R at floor 2 directly. Fill remaining floors (3, 4) using the 'one person between S and T' clue.",
        quiz: "What is the floor-order (top to bottom) for P, Q, R, S, T?",
        answer: "Floor 5: P, Floor 4: Q, Floor 3: S, Floor 2: R, Floor 1: T.",
      },
      {
        title: "Direction & Distance",
        explain: "Use a fixed compass: North up, South down, East right, West left, with NE/NW/SE/SW as diagonals. When someone turns left or right, their facing direction changes accordingly. For the straight-line (shortest) distance between start and end points, use the Pythagoras theorem: (hypotenuse)² = (side1)² + (side2)².",
        trick: "Add up all movements along the same axis (e.g. all 'North' minus all 'South' gives net N-S distance); do the same for East-West. Then apply Pythagoras to the two net values to get the shortest distance.",
        quiz: "Lucifer walks 13 km south, then 10 km north, then 4 km east. What is the distance between his start and end point?",
        answer: "Net south = 13−10 = 3 km; east = 4 km. Distance = √(3²+4²) = √25 = 5 km.",
      },
      {
        title: "Letter Series",
        explain: "A letter series can follow a constant addition/subtraction to letter positions (A=1…Z=26), an alternating-difference pattern, odd/even-position number patterns, or an opposite-letter pairing where each pair of letters sums to 27 (A↔Z, B↔Y, C↔X…).",
        trick: "Convert each letter to its position number, identify the difference pattern (constant, increasing, or alternating), then convert the answer back to a letter. For 'opposite letter' style series, remember: position + opposite position = 27.",
        quiz: "PON, RQP, TSR, VUT, ? — find the missing group.",
        answer: "XWV — each group's first letter shifts +2 from the previous group's first letter (P→R→T→V→X).",
      },
      {
        title: "Clocks — Basics",
        explain: "A clock face is 360°, split into 12 equal parts of 30° each (so 1 hour = 30°). The minute hand moves 6° every minute; the hour hand moves 0.5° every minute.",
        trick: "Relative speed of the minute hand over the hour hand = 6° − 0.5° = 5.5° per minute. Use this to find the angle between the hands at any given time.",
        quiz: "How many degrees does the hour hand move in 20 minutes?",
        answer: "20 × 0.5° = 10°.",
      },
      {
        title: "Clocks — Mirror & Water Images",
        explain: "Mirror image time formula: Mirror image + Clock time = 11:60 (i.e., 12:00 written as 11 hours 60 minutes). Water image time formula: Water image + Clock time = 17:90 (i.e., 18:30 written as 17 hours 90 minutes).",
        trick: "Simply subtract the given clock time from 11:60 (mirror) or 17:90 (water) to get the reflected time.",
        quiz: "What is the mirror-image time when the clock shows 6:15?",
        answer: "11:60 − 6:15 = 5:45.",
      },
      {
        title: "Clocks — Hands Meeting/Opposite/Right-Angle",
        explain: "In every 12 hours, the hour and minute hands coincide (overlap) 11 times, and are exactly opposite (180°) 11 times — so in a full 24-hour day that's 22 times each. They form a right angle (90°) 22 times in 12 hours (44 times a day).",
        trick: "Remember the '11 times per 12 hours' rule for both overlap and opposite positions — it is one of the most frequently asked clock facts.", 
        quiz: "How many times do the hour and minute hands overlap in a full day?",
        answer: "22 times (11 times every 12 hours).",
      },
      { title: "Number & Letter Series (Rules)", explain: "Check for a constant difference, a constant ratio, alternating differences, or a squares/cubes pattern, in that order.", trick: "Test order: difference → ratio → alternate terms → powers (squares/cubes).", quiz: "In what order should you test a series for its pattern?", answer: "Difference, then ratio, then alternating terms, then powers." },
      { title: "Coding–Decoding", explain: "Find the hidden rule that transforms letters or numbers from the question into the code.", trick: "Assign A=1…Z=26 to quickly test position-based shifts.", quiz: "What numbering system helps decode most letter-coding questions?", answer: "A=1, B=2 … Z=26." },
      { title: "Blood Relations", explain: "Convert the sentence clue-by-clue into a family tree diagram.", trick: "Always draw the tree — don't try to track complex relations mentally.", quiz: "What is the recommended method for solving blood relation puzzles?", answer: "Draw a family tree from the clues step by step." },
      { title: "Directions (General)", explain: "Use a fixed North–East–South–West diagram as your reference for every direction question.", trick: "North is always up, East right, South down, West left — keep this orientation fixed while solving.", quiz: "In the standard direction diagram, which way does East point?", answer: "To the right." },
      { title: "Syllogism", explain: "Test whether a conclusion necessarily follows from the given statements using Venn-diagram logic.", trick: "'Some' does not mean 'All' — a very common trap in syllogism options.", quiz: "Does 'Some A are B' allow you to conclude 'All A are B'?", answer: "No — 'some' never implies 'all'." },
      { title: "Analogy", explain: "Identify the exact relationship in the first pair, then apply the same relationship to find the second pair.", trick: "Always prefer the most specific relationship over a vague, general one.", quiz: "What should you prioritize when choosing the relationship in an analogy?", answer: "The most specific relationship that fits the first pair exactly." },
    ],
  },
  {
    id: "english",
    name: "General English",
    icon: "🔤",
    topics: [
      { title: "Parts of Speech", explain: "English words fall into 8 categories: Noun, Pronoun, Verb, Adjective, Adverb, Preposition, Conjunction, Interjection.", trick: "Identify a word's part of speech by its job in the sentence, not just its spelling.", quiz: "Name the 8 parts of speech.", answer: "Noun, Pronoun, Verb, Adjective, Adverb, Preposition, Conjunction, Interjection." },
      { title: "Tenses", explain: "Tense shows the time of an action: Present, Past, or Future, each with Simple, Continuous, Perfect, and Perfect Continuous forms.", trick: "Focus on the helping verb (is/was/has/had/will) to quickly identify the tense.", quiz: "How many basic tense forms exist per time period?", answer: "Four: Simple, Continuous, Perfect, Perfect Continuous." },
      { title: "Subject–Verb Agreement", explain: "A singular subject takes a singular verb; a plural subject takes a plural verb.", trick: "Ignore words between the subject and verb ('along with', 'as well as') when checking agreement.", quiz: "Does the phrase 'along with' change the verb's number?", answer: "No — the verb still agrees with the main subject." },
      { title: "Vocabulary — Synonyms/Antonyms", explain: "Build word lists in pairs: a word with its closest synonym and its opposite (antonym).", trick: "Learn 10 new word-pairs a day and revise the previous day's list before adding new ones.", quiz: "What is an effective daily vocabulary routine?", answer: "Learn ~10 new word pairs a day and revise the prior day's list first." },
      { title: "One-Word Substitution", explain: "A single word can replace a whole phrase, e.g. 'a person who studies birds' = Ornithologist.", trick: "Group substitutions by theme (people, places, actions) for easier memorisation.", quiz: "What one word means 'a person who studies birds'?", answer: "Ornithologist." },
    ],
  },
  {
    id: "computer",
    name: "Computer Awareness",
    icon: "💻",
    topics: [
      { title: "Computer Basics", explain: "A computer has Hardware (physical parts: CPU, monitor, keyboard) and Software (programs that run on it: system software and application software).", trick: "CPU = Central Processing Unit = the computer's 'brain'.", quiz: "What are the two broad categories of a computer's components?", answer: "Hardware and Software." },
      { title: "MS Office Basics", explain: "MS Word is for documents, MS Excel is for spreadsheets/calculations, and MS PowerPoint is for presentations.", trick: "Match the file extension to the tool: .docx → Word, .xlsx → Excel, .pptx → PowerPoint.", quiz: "Which MS Office tool is used for spreadsheets?", answer: "MS Excel." },
      { title: "Internet & Email", explain: "The Internet is a global network of connected computers; email lets users send digital messages using an address like name@domain.com.", trick: "'www' stands for World Wide Web, a service that runs on the Internet — the two are not the same thing.", quiz: "Are the Internet and the World Wide Web the same thing?", answer: "No — the Internet is the network; the Web (www) is one service that runs on it." },
      { title: "Cyber Security Basics", explain: "Basic safety practices include using strong passwords, avoiding suspicious links, and keeping software updated.", trick: "Never share OTPs or passwords with anyone, even if the caller claims to be from a bank.", quiz: "Should you ever share an OTP over a phone call?", answer: "No, legitimate banks/services never ask for your OTP." },
    ],
  },
  {
    id: "environment",
    name: "Environment & Ecology",
    icon: "🌱",
    topics: [
      { title: "Ecosystem Basics", explain: "An ecosystem is a community of living organisms interacting with their non-living environment (soil, water, air).", trick: "Food chain flow: Producers → Primary Consumers → Secondary Consumers → Decomposers.", quiz: "What is the basic flow of energy in a food chain?", answer: "Producers → Primary consumers → Secondary consumers → Decomposers." },
      { title: "Biodiversity", explain: "Biodiversity is the variety of life (species, genes, and ecosystems) found in a region.", trick: "India is one of the world's recognised mega-biodiversity countries.", quiz: "What three levels does biodiversity cover?", answer: "Species diversity, genetic diversity, ecosystem diversity." },
      { title: "Environmental Laws (India)", explain: "Key laws include the Wildlife Protection Act (1972), Water Act (1974), Air Act (1981), and the Environment Protection Act (1986).", trick: "Match each law to the year using the sequence: Wildlife(72) → Water(74) → Air(81) → Environment(86).", quiz: "Which year was the Wildlife Protection Act passed?", answer: "1972." },
      { title: "Telangana Forests & Parks", explain: "Telangana is home to protected areas such as Kawal Tiger Reserve, Amrabad Tiger Reserve, and Mrugavani National Park.", trick: "Learn each protected area with its district and the species it is known for.", quiz: "Name two tiger reserves located in Telangana.", answer: "Kawal Tiger Reserve and Amrabad Tiger Reserve." },
    ],
  },
  {
    id: "current-affairs",
    name: "Current Affairs & Strategy",
    icon: "📰",
    topics: [
      { title: "Current Affairs Coverage", explain: "Cover Telangana, national, international, economy, government schemes, awards, sports, science, and appointments.", trick: "Maintain daily notes, do a weekly revision, and prepare a monthly compilation.", quiz: "What is the recommended current-affairs revision cycle?", answer: "Daily notes → weekly revision → monthly compilation." },
      { title: "Previous Year Questions (PYQs)", explain: "PYQs reveal which concepts repeat and how questions are typically framed.", trick: "Solve a PYQ set once to learn, then solve it again later under strict time limits.", quiz: "Why solve PYQs twice?", answer: "First for learning, then again under exam-like time pressure." },
      { title: "Revision Strategy", explain: "Active recall (testing yourself) is far stronger for retention than repeated reading.", trick: "Follow the 1 day → 7 days → 30 days revision spacing.", quiz: "What is the ideal spaced-revision schedule?", answer: "Revise after 1 day, then after 7 days, then after 30 days." },
      { title: "Mock Tests", explain: "Every mock test mistake should be analysed as either a concept gap, a calculation error, or a careless mistake.", trick: "A mock test without a proper mistake-analysis gives very limited benefit.", quiz: "Into what three categories should mock-test mistakes be sorted?", answer: "Concept error, calculation error, careless error." },
    ],
  },
  {
    id: "formula-sheet",
    name: "Rapid Revision Formula Sheet",
    icon: "📋",
    topics: [
      {
        title: "All Formulas at a Glance",
        explain: "Percentage = Part/Whole × 100 · Profit = SP − CP · Loss = CP − SP · Simple Interest = P×R×T/100 · Average = Sum/Number · Speed = Distance/Time · Distance = Speed×Time · Time = Distance/Speed.",
        trick: "Constitution: adopted 26 Nov 1949, effective 26 Jan 1950 · Telangana Formation Day: 2 June 2014 · Vitamin C deficiency: Scurvy · Vitamin D deficiency: Rickets · Repo Rate: RBI lends to banks.",
        quiz: "Recite the Simple Interest and Average formulas from memory.",
        answer: "SI = P×R×T/100. Average = Sum of values / Number of values.",
      },
    ],
  },
];
