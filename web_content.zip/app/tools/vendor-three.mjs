// Copies Three.js (build + the example modules this app uses) from node_modules into js/vendor/three,
// so the app works offline and inside the APK. Run:  npm install && npm run vendor:three
import fs from 'node:fs'; import path from 'node:path';
const src = path.resolve('node_modules/three'), dst = path.resolve('js/vendor/three');
if (!fs.existsSync(src)) { console.error('Run "npm install" first.'); process.exit(1); }
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(path.join(src, 'build'), path.join(dst, 'build'), { recursive: true });
fs.cpSync(path.join(src, 'examples/jsm'), path.join(dst, 'examples/jsm'), { recursive: true });
console.log('Three.js copied to js/vendor/three');
