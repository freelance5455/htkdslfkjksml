// Builds ./www (what Capacitor packs into the APK): only the web app, not server/docs/tools.
import fs from 'node:fs'; import path from 'node:path';
if (!fs.existsSync('js/vendor/three/build/three.module.js')) { console.error('Vendor Three.js first: npm install && npm run vendor:three (the APK should work offline).'); process.exit(1); }
fs.rmSync('www', { recursive: true, force: true }); fs.mkdirSync('www');
for (const f of ['index.html', 'css', 'js', 'logo', 'assets']) fs.cpSync(f, path.join('www', f), { recursive: true });
console.log('www/ ready');
