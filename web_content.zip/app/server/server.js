// Hyper Character Design - AI backend proxy (zero dependencies, Node 18+).
// Keeps the AI provider API key on the server. Photos are forwarded in memory only; nothing is written to disk.
//
//   MESHY_API_KEY=msy_xxx ALLOWED_ORIGINS=https://yourapp.example node server.js
//
// Endpoints:
//   GET  /api/health              -> { ok, configured, provider }
//   POST /api/jobs                -> body { kind:'character'|'garment', image:'data:image/...;base64,...' } -> { jobId }
//   GET  /api/jobs/:id            -> { status:'pending'|'running'|'done'|'failed', progress, error? }
//   GET  /api/jobs/:id/model      -> GLB bytes (proxied, so the browser never sees provider URLs/keys)
import http from 'node:http';
import crypto from 'node:crypto';

const PORT = Number(process.env.PORT || 8787);
const PROVIDER = (process.env.PROVIDER || 'meshy').toLowerCase();
const ORIGINS = (process.env.ALLOWED_ORIGINS || '*').split(',').map((s) => s.trim()).filter(Boolean);
const MAX_BODY = 12 * 1024 * 1024;          // 12 MB request body
const RATE_MAX = Number(process.env.RATE_LIMIT_PER_HOUR || 10);
const JOB_TTL = 60 * 60 * 1000;

// ---------- providers (add your own by implementing create/status/modelUrl) ----------
const providers = {
  meshy: {
    configured: () => !!process.env.MESHY_API_KEY,
    base: 'https://api.meshy.ai/openapi/v1/image-to-3d',
    headers() { return { Authorization: `Bearer ${process.env.MESHY_API_KEY}`, 'Content-Type': 'application/json' }; },
    // Documented options: image_url (URL or data URI), should_texture, enable_pbr, pose_mode, target_formats
    async create(image) {
      const r = await fetch(this.base, { method: 'POST', headers: this.headers(), body: JSON.stringify({ image_url: image, should_texture: true, enable_pbr: true, pose_mode: 'a-pose', target_formats: ['glb'] }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.result) throw new Error(j.message || `Provider error (HTTP ${r.status})`);
      return j.result;
    },
    async status(id) {
      const r = await fetch(`${this.base}/${encodeURIComponent(id)}`, { headers: this.headers() });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(j.message || `Provider error (HTTP ${r.status})`);
      const map = { PENDING: 'pending', IN_PROGRESS: 'running', SUCCEEDED: 'done', FAILED: 'failed', CANCELED: 'failed' };
      return { status: map[j.status] || 'running', progress: j.progress ?? 0, modelUrl: j.model_urls?.glb, error: j.task_error?.message };
    },
  },
};

const jobs = new Map();   // our id -> { task, kind, created, ip }
const hits = new Map();   // ip -> [timestamps]

function cors(req, res) {
  const o = req.headers.origin;
  if (ORIGINS.includes('*')) res.setHeader('Access-Control-Allow-Origin', '*');
  else if (o && ORIGINS.includes(o)) { res.setHeader('Access-Control-Allow-Origin', o); res.setHeader('Vary', 'Origin'); }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };

function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > MAX_BODY) { reject(Object.assign(new Error('Image too large'), { code: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function limited(ip) {
  const now = Date.now(), list = (hits.get(ip) || []).filter((t) => now - t < 3600e3);
  if (list.length >= RATE_MAX) { hits.set(ip, list); return true; }
  list.push(now); hits.set(ip, list); return false;
}

setInterval(() => { const now = Date.now(); for (const [k, v] of jobs) if (now - v.created > JOB_TTL) jobs.delete(k); }, 60e3).unref();

const server = http.createServer(async (req, res) => {
  cors(req, res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  const url = new URL(req.url, 'http://x');
  const P = providers[PROVIDER];
  const ip = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress;
  try {
    if (url.pathname === '/api/health' && req.method === 'GET') {
      return send(res, 200, { ok: true, configured: !!P?.configured(), provider: PROVIDER });
    }
    if (!P || !P.configured()) return send(res, 503, { error: 'AI provider is not configured on the server (missing API key).' });

    if (url.pathname === '/api/jobs' && req.method === 'POST') {
      if (limited(ip)) return send(res, 429, { error: 'Rate limit reached. Try again later.' });
      let body; try { body = JSON.parse(await readBody(req)); } catch (e) { return send(res, e.code || 400, { error: e.code === 413 ? 'Image too large' : 'Invalid request body' }); }
      const kind = body.kind === 'garment' ? 'garment' : 'character';
      if (typeof body.image !== 'string' || !/^data:image\/(jpeg|png|webp);base64,/.test(body.image)) return send(res, 400, { error: 'image must be a JPG, PNG or WEBP data URI' });
      const task = await P.create(body.image);
      body.image = null; // drop reference immediately; the photo is never stored
      const id = crypto.randomUUID(); jobs.set(id, { task, kind, created: Date.now() });
      return send(res, 202, { jobId: id });
    }

    const m = url.pathname.match(/^\/api\/jobs\/([\w-]+)(\/model)?$/);
    if (m && req.method === 'GET') {
      const job = jobs.get(m[1]); if (!job) return send(res, 404, { error: 'Unknown or expired job' });
      const st = await P.status(job.task);
      if (!m[2]) return send(res, 200, { status: st.status, progress: st.progress, error: st.error });
      if (st.status !== 'done' || !st.modelUrl) return send(res, 409, { error: 'Model not ready' });
      const f = await fetch(st.modelUrl);
      if (!f.ok) return send(res, 502, { error: 'Could not download model from provider' });
      res.writeHead(200, { 'Content-Type': 'model/gltf-binary', 'Cache-Control': 'no-store' });
      res.end(Buffer.from(await f.arrayBuffer()));
      jobs.delete(m[1]);
      return;
    }
    send(res, 404, { error: 'Not found' });
  } catch (e) {
    console.error('[error]', e.message);   // never log image data
    send(res, 502, { error: e.message || 'Upstream error' });
  }
});

server.listen(PORT, () => console.log(`Hyper AI backend on :${PORT} provider=${PROVIDER} configured=${!!providers[PROVIDER]?.configured()}`));
