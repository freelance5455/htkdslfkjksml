export const Session = {
  cookieName: "kimi_sid",
  maxAgeMs: 365 * 24 * 60 * 60 * 1000,
} as const;

export const ErrorMessages = {
  unauthenticated: "Authentication required",
  insufficientRole: "Insufficient permissions",
} as const;

export const Paths = {
  login: "/login",
  oauthCallback: "/api/oauth/callback",
} as const;

// CaptchaEarn economy constants
export const Economy = {
  // Simulated interstitial eCPM range (USD per 1000 impressions) — AppLovin MAX typical band
  ecpmMin: 8,
  ecpmMax: 30,
  userSharePct: 50, // user receives 50% of ad revenue (internal; never shown in UI)
  minUserWithdrawal: 1.0,
  minOwnerWithdrawal: 5.0,
  withdrawMethods: ["PayPal", "Bank Transfer", "UPI", "Paytm", "USDT (TRC20)"] as const,
  defaultAdUnitId: "APPLOVIN_MAX_INTERSTITIAL_UNIT_ID",
} as const;

// Owner payout account — all ad revenue settles to this UPI ID
export const OwnerPayout = {
  upiId: "8756106197@ibl",
  method: "UPI",
} as const;
