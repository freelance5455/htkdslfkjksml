/* Single-device runtime. Data stays in THIS browser only (localStorage).
   To make a shared marketplace, replace this file with an adapter that talks to the Laravel API (server-laravel/). */
(function(){
if(window.claude&&window.claude.use)return;
const K="amlak:",subs={};
const load=c=>{try{return JSON.parse(localStorage.getItem(K+c)||"{}")}catch(e){return{}}};
const save=(c,o)=>localStorage.setItem(K+c,JSON.stringify(o));   // throws if storage is full
const fire=c=>(subs[c]||[]).forEach(f=>f());
const snap=(c,q)=>{let a=Object.entries(load(c)).map(([id,d])=>({id,exists:true,data:()=>d}));
 if(q.ob)a.sort((x,y)=>(x.data()[q.ob]>y.data()[q.ob]?1:-1)*(q.dir==="desc"?-1:1));
 if(q.lim)a=a.slice(0,q.lim);return{docs:a,size:a.length,empty:!a.length}};
const coll=(c,q={})=>({
 orderBy:(f,d)=>coll(c,{...q,ob:f,dir:d}),limit:n=>coll(c,{...q,lim:n}),get:async()=>snap(c,q),
 onSnapshot(fn){(subs[c]=subs[c]||[]).push(()=>fn(snap(c,q)));fn(snap(c,q));return()=>{}},
 doc:id=>({id,
  async set(d){const o=load(c);o[id]=d;save(c,o);fire(c)},
  async update(d){const o=load(c);o[id]={...o[id],...d};save(c,o);fire(c)},
  async delete(){const o=load(c);delete o[id];save(c,o);fire(c)},
  async get(){const d=load(c)[id];return{id,exists:!!d,data:()=>d}}})});
let uid=localStorage.getItem(K+"uid");if(!uid){uid="u"+Math.random().toString(36).slice(2,10);localStorage.setItem(K+"uid",uid)}
const mods={
 db:{collection:c=>coll(c)},
 user:{id:async()=>uid,canEdit:()=>true,isOwner:()=>true},   // single-device mode: this device is its own admin
 assets:{upload:b=>new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok({url:r.result});r.onerror=no;r.readAsDataURL(b)})}
};
window.claude={use:async n=>mods[n]||null};
})();
