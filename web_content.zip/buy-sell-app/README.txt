HOW TO RUN
1. Install Node.js 18 or newer (nodejs.org).
2. Open this folder in a terminal and run:  npm install
3. Run:  npm start
4. Open http://localhost:3000   Login: admin / admin123  (create your own user in Settings)

WHERE TO PUT YOUR WHATSAPP KEY/TOKEN
- Open the file ".env" and write your token after WA_TOKEN=
- In the app go to Settings > add each WhatsApp number and paste its "Phone Number ID" (from Meta for Developers > WhatsApp > API Setup).
- Tick "Default sender" for the number that sends receipts, and "Gets a copy" for numbers that should receive every sale/order alert.
- For incoming orders: in Meta set the webhook URL to https://YOUR-DOMAIN/webhook and the verify token to the same word as WA_VERIFY in .env.
- Without a token, the app still works: it gives a "Send by WhatsApp" wa.me link instead.
