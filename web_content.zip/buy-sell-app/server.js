require('dotenv').config();
const express=require('express'),Database=require('better-sqlite3'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken');
const db=new Database('shop.db'),app=express(),SECRET=process.env.JWT_SECRET||'change-me';
app.use(express.json());app.use(express.static('public'));
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password TEXT,role TEXT);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,name TEXT,stock REAL DEFAULT 0,buy_price REAL DEFAULT 0,sell_price REAL DEFAULT 0,min_stock REAL DEFAULT 5);
CREATE TABLE IF NOT EXISTS parties(id INTEGER PRIMARY KEY,name TEXT,phone TEXT,type TEXT,balance REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY,product_id INT,supplier_id INT,qty REAL,price REAL,date TEXT);
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY,customer_id INT,items TEXT,discount REAL,total REAL,cost REAL,pay TEXT,date TEXT);
CREATE TABLE IF NOT EXISTS wa_numbers(id INTEGER PRIMARY KEY,label TEXT,phone TEXT,phone_number_id TEXT,is_sender INT DEFAULT 0,gets_copy INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,from_phone TEXT,text TEXT,date TEXT)`);
if(!db.prepare('SELECT 1 FROM users').get())db.prepare('INSERT INTO users(username,password,role) VALUES(?,?,?)').run('admin',bcrypt.hashSync('admin123',10),'admin');

const auth=a=>(q,r,n)=>{try{q.user=jwt.verify((q.headers.authorization||'').replace('Bearer ',''),SECRET);if(a&&q.user.role!=='admin')return r.status(403).json({error:'Admin only'});n()}catch{r.status(401).json({error:'Login required'})}};
app.post('/api/login',(q,r)=>{const u=db.prepare('SELECT * FROM users WHERE username=?').get(q.body.username);if(!u||!bcrypt.compareSync(q.body.password||'',u.password))return r.status(401).json({error:'Wrong username or password'});r.json({token:jwt.sign({id:u.id,role:u.role},SECRET,{expiresIn:'12h'}),role:u.role})});
app.post('/api/users',auth(1),(q,r)=>{const{username,password,role}=q.body;try{db.prepare('INSERT INTO users(username,password,role) VALUES(?,?,?)').run(username,bcrypt.hashSync(password,10),role==='admin'?'admin':'staff');r.json({ok:1})}catch{r.status(400).json({error:'User exists'})}});

// ---- WhatsApp: Cloud API if token set, otherwise returns a wa.me link ----
async function wa(to,text,sid){
  const s=sid?db.prepare('SELECT * FROM wa_numbers WHERE id=?').get(sid):db.prepare('SELECT * FROM wa_numbers WHERE is_sender=1').get();
  const num=String(to||'').replace(/\D/g,'');
  if(!process.env.WA_TOKEN||!s?.phone_number_id)return{link:`https://wa.me/${num}?text=${encodeURIComponent(text)}`};
  try{const r=await fetch(`https://graph.facebook.com/v20.0/${s.phone_number_id}/messages`,{method:'POST',headers:{Authorization:'Bearer '+process.env.WA_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to:num,type:'text',text:{body:text}})});return{ok:r.ok}}catch{return{ok:false}}
}
const copies=(t,sid)=>db.prepare('SELECT phone FROM wa_numbers WHERE gets_copy=1').all().forEach(n=>wa(n.phone,t,sid));

// ---- Generic CRUD ----
const crud=(t,cols,adm)=>{const L=cols.split(','),pick=b=>L.reduce((o,c)=>(o[c]=b[c]??null,o),{});
  app.get('/api/'+t,auth(),(q,r)=>r.json(db.prepare(`SELECT * FROM ${t}`).all()));
  app.post('/api/'+t,auth(adm),(q,r)=>r.json({id:db.prepare(`INSERT INTO ${t}(${cols}) VALUES(${L.map(c=>'@'+c)})`).run(pick(q.body)).lastInsertRowid}));
  app.put('/api/'+t+'/:id',auth(adm),(q,r)=>{db.prepare(`UPDATE ${t} SET ${L.map(c=>c+'=@'+c)} WHERE id=@id`).run({...pick(q.body),id:q.params.id});r.json({ok:1})});
  app.delete('/api/'+t+'/:id',auth(1),(q,r)=>{db.prepare(`DELETE FROM ${t} WHERE id=?`).run(q.params.id);r.json({ok:1})});};
crud('products','name,stock,buy_price,sell_price,min_stock');
crud('parties','name,phone,type,balance');
crud('wa_numbers','label,phone,phone_number_id,is_sender,gets_copy',1);

// ---- Purchases ----
app.get('/api/purchases',auth(),(q,r)=>r.json(db.prepare('SELECT * FROM purchases ORDER BY id DESC').all()));
app.post('/api/purchases',auth(),(q,r)=>{const{product_id,supplier_id,qty,price}=q.body;
  db.transaction(()=>{db.prepare('INSERT INTO purchases(product_id,supplier_id,qty,price,date) VALUES(?,?,?,?,?)').run(product_id,supplier_id||null,qty,price,new Date().toISOString());db.prepare('UPDATE products SET stock=stock+?,buy_price=? WHERE id=?').run(qty,price,product_id)})();r.json({ok:1})});

// ---- Sales (stock reduces automatically, receipt goes to WhatsApp) ----
app.post('/api/sales',auth(),async(q,res)=>{const{customer_id,items,discount=0,pay,sender_id}=q.body;let total=0,cost=0,id,lines=[];
  try{db.transaction(()=>{for(const it of items){const p=db.prepare('SELECT * FROM products WHERE id=?').get(it.product_id);if(!p||p.stock<it.qty)throw Error('Not enough stock: '+(p?.name||it.product_id));total+=it.qty*it.price;cost+=it.qty*p.buy_price;lines.push(`${p.name} x${it.qty} = ${it.qty*it.price}`);db.prepare('UPDATE products SET stock=stock-? WHERE id=?').run(it.qty,p.id)}
    total-=discount;if(pay==='credit'&&customer_id)db.prepare('UPDATE parties SET balance=balance+? WHERE id=?').run(total,customer_id);
    id=db.prepare('INSERT INTO sales(customer_id,items,discount,total,cost,pay,date) VALUES(?,?,?,?,?,?,?)').run(customer_id||null,JSON.stringify(lines),discount,total,cost,pay,new Date().toISOString()).lastInsertRowid})()}catch(e){return res.status(400).json({error:e.message})}
  const text=`Receipt #${id}\n${lines.join('\n')}\nDiscount: ${discount}\nTotal: ${total} (${pay})\nThank you!`;
  const c=customer_id&&db.prepare('SELECT * FROM parties WHERE id=?').get(customer_id);
  const sent=c?.phone?await wa(c.phone,text,sender_id):{};copies('New sale\n'+text,sender_id);res.json({id,total,text,link:sent.link})});

// ---- Reports ----
app.get('/api/reports',auth(),(q,r)=>{const since=new Date(Date.now()-({day:1,week:7,month:30}[q.query.period]||1)*864e5).toISOString();
  const s=db.prepare('SELECT COALESCE(SUM(total),0) t,COALESCE(SUM(cost),0) c FROM sales WHERE date>=?').get(since),p=db.prepare('SELECT COALESCE(SUM(qty*price),0) t FROM purchases WHERE date>=?').get(since);
  r.json({sales:s.t,purchases:p.t,profit:s.t-s.c})});

// ---- Payment reminder ----
app.post('/api/remind/:id',auth(),async(q,r)=>{const c=db.prepare('SELECT * FROM parties WHERE id=?').get(q.params.id);r.json(await wa(c.phone,`Hello ${c.name}, your unpaid balance is ${c.balance}. Please pay soon. Thank you.`,q.body.sender_id))});

// ---- WhatsApp webhook: receive customer orders ----
app.get('/webhook',(q,r)=>q.query['hub.verify_token']===process.env.WA_VERIFY?r.send(q.query['hub.challenge']):r.sendStatus(403));
app.post('/webhook',(q,r)=>{try{for(const e of q.body.entry)for(const c of e.changes)for(const m of c.value.messages||[]){const t=m.text?.body||'';db.prepare('INSERT INTO orders(from_phone,text,date) VALUES(?,?,?)').run(m.from,t,new Date().toISOString());copies(`New order from ${m.from}: ${t}`)}}catch{}r.sendStatus(200)});
app.get('/api/orders',auth(),(q,r)=>r.json(db.prepare('SELECT * FROM orders ORDER BY id DESC').all()));
app.listen(process.env.PORT||3000,()=>console.log('Open http://localhost:'+(process.env.PORT||3000)));
