# Lubin ViewCamera

Statyczna aplikacja webowa z katalogiem 312 kamer Lubina w 8 grupach.
Menu na telewizorze obsłużysz strzałkami, OK oraz klawiszem Wstecz.
Katalog otwiera listę kamer po wybraniu osiedla. Pole wyszukiwania
przyjmuje także nazwy ulic.

## Uruchomienie

Rozpakuj archiwum. W folderze `Lubin-ViewCamera`, jeśli masz Pythona 3,
uruchom:

```bash
python3 -m http.server 8000 --bind 127.0.0.1 --directory dist
```

Otwórz [http://127.0.0.1:8000](http://127.0.0.1:8000) w przeglądarce.

Aby korzystać z aplikacji w przeglądarce na Android TV, umieść zawartość
`dist/` na hostingu statycznym i otwórz jego adres na telewizorze. Dostęp
do transmisji wymaga internetu i zależy od dostępności źródeł kamer.

## Pliki

- `dist/index.html` zawiera stronę startową.
- `dist/app.js` obsługuje katalog, wyszukiwanie, pilota i odtwarzacz.
- `dist/cameras.js` zawiera katalog i adresy transmisji.
- `dist/style.css` zawiera układ i style.
- `dist/hls.min.js` zawiera bibliotekę odtwarzania HLS.
- `dist/Lubin-ViewCamera.m3u` to playlista do otwarcia w VLC.

Aplikację można opublikować bez kompilacji. Archiwum zawiera wersję webową.
