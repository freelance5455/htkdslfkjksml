# Shree Sendhav Dairy V34 — Android Mobile App

This mobile package uses the **same V34 data model and Firebase project** as the Windows desktop app. A milk entry saved on the phone is uploaded to Firebase and can be downloaded/displayed by the computer; a computer entry is downloaded by the phone after sync.

## Important sync behavior

- Use the **same plant** on phone and computer (Ashta/Main, Narsinggarh, Arandiya, Aehmadpur).
- Sign in with the plant's Firebase account.
- First mobile login is **Cloud → Device first**, so an empty/new phone does not overwrite the computer's existing data.
- After that, normal background sync runs when internet is available.
- Farmer Master, Product Master and the existing V34 payment structures remain in the same Firebase dataset.
- Do not run Backup + Cloud Cleanup from both devices at the same time. Run it from one authorized desktop/plant device after the backup file has been successfully saved.

## Build on Windows

1. Install Node.js LTS.
2. Extract this ZIP.
3. Open CMD in this folder.
4. Run:

```cmd
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio will open. Connect an Android phone with USB debugging enabled or use an emulator, then Run the app.

For a debug APK:

```cmd
cd android
gradlew.bat assembleDebug
```

APK location:

`android\\app\\build\\outputs\\apk\\debug\\app-debug.apk`

## Firebase

The V34 HTML already contains the Shree Sendhav Dairy Firebase Web config and the plant login/cloud sync logic. No separate Firebase project is required.

## Features carried from V34

Farmer Master, Milk Entry, Morning/Evening shift, decimal Milk/FAT/SNF/CLR entry, separate duplicate rows in bills, Buffalo/Cow bills, 10-Day Bill, Purchase Summary, Products, Payments/Adjustments, Cow CLR Rate List, Backup/Restore, Cloud Sync, Farmer App portal, complaints and plant login are included from the current V34 source.


## Auto Sync Update

See `AUTO_SYNC_UPDATE.txt`. This build applies realtime two-way Firebase sync for V34 transactional data and merges new milk/purchase/payment rows from both devices.
