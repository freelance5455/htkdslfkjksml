@echo off
setlocal
cd /d "%~dp0"
echo =============================================
echo Shree Sendhav Dairy V34 - Android Build
echo =============================================
call npm install
if errorlevel 1 goto :fail
if not exist android call npx cap add android
if errorlevel 1 goto :fail
call npx cap sync android
if errorlevel 1 goto :fail
call android\gradlew.bat assembleDebug
if errorlevel 1 goto :fail
echo.
echo APK ready:
echo android\app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. Check the message above.
pause
exit /b 1
