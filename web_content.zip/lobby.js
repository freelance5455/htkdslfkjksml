function drawFullCatLobby(){
  if(run)return;
  pCtx.clearRect(0,0,190,165);
  var ct=CATS.at(curCat),sk=ct.skins.at(eqSkins.at(curCat));
  renderCatBody(pCtx,95,98,-0.15,sk.col,sk.helm,sk.acc,ct.type,eqWpn,0,0,0,1.45);
  requestAnimationFrame(drawFullCatLobby);
}
requestAnimationFrame(drawFullCatLobby);

function cycleCat(dir){
  curCat=(curCat+dir+CATS.length)%CATS.length;
  sfx(480,650,.08,"sine",.1);
  renderLobby();
}
function setTab(t){
  lobTab=t;
  for(var i=0;i<4;i++)document.getElementById("t"+i).className="tab"+(t==i?" act":"");
  sfx(520,700,.06,"triangle",.08);
  renderLobby();
}
function renderLobby(){
  document.getElementById("bankTuna").innerText=tunaBank;
  var ct=CATS.at(curCat),sk=ct.skins.at(eqSkins.at(curCat)),wp=WEAPONS.at(eqWpn-1);
  document.getElementById("lobCatName").innerText=ct.name+(unlocked.at(curCat)?"":" 🔒");
  document.getElementById("lobCatSub").innerText="Skin: "+sk.name+" • Arma: "+wp.name;

  var mb=document.getElementById("mainActionBtn");
  if(unlocked.at(curCat)){
    mb.innerText="GIOCA SOLO ("+ct.name+")";
    mb.style.background="#2ecc71";mb.style.boxShadow="0 3px 0 #1e8449";
  }else{
    mb.innerText="SBLOCCA "+ct.name+" ("+ct.cost+" 🐟)";
    mb.style.background="#f39c12";mb.style.boxShadow="0 3px 0 #d35400";
  }

  var p=document.getElementById("lobPanel"),h="";
  if(lobTab==0){
    var hpPct=Math.min(100,Math.round(ct.hp/5500*100));
    var dmgPct=Math.min(100,Math.round(ct.dmg/1100*100));
    var spdPct=Math.min(100,Math.round(ct.spd/5.6*100));
    h+='<div style="font-size:11px;color:#fbc531;font-weight:bold;margin-bottom:4px">'+ct.desc+'</div>';
    h+='<div class="statRow"><span class="statLbl">VITA</span><div class="statBar"><div class="statFill" style="width:'+hpPct+'%;background:#2ecc71"></div></div><span>'+ct.hp+'</span></div>';
    h+='<div class="statRow"><span class="statLbl">DANNO</span><div class="statBar"><div class="statFill" style="width:'+dmgPct+'%;background:#e74c3c"></div></div><span>'+ct.dmg+'</span></div>';
    h+='<div class="statRow"><span class="statLbl">VELOCITÀ</span><div class="statBar"><div class="statFill" style="width:'+spdPct+'%;background:#3498db"></div></div><span>'+ct.spd+'</span></div>';
  }else if(lobTab==1){
    h+='<div class="gridCards">';
    ct.skins.forEach(function(s,idx){
      var u=unlSkins.at(curCat).at(idx),eq=(eqSkins.at(curCat)==idx);
      h+='<div class="itemCard'+(eq?' sel':'')+(u?'':' lock')+'" onclick="buyOrEquipSkin('+idx+')">';
      h+='<b>'+s.name+'</b>';
      h+='<div class="swatch" style="background:linear-gradient(135deg,'+s.col+' 50%,'+s.helm+' 50%)"></div>';
      h+='<div class="tag '+(eq?'eq':(u?'':'buy'))+'">'+(eq?'IN USO':(u?'EQUIPAGGIA':s.cost+' 🐟'))+'</div></div>';
    });
    h+='</div>';
  }else if(lobTab==2){
    h+='<div class="gridCards">';
    WEAPONS.forEach(function(w,idx){
      var u=unlWpns.at(idx),eq=(eqWpn==w.id);
      h+='<div class="itemCard'+(eq?' sel':'')+(u?'':' lock')+'" onclick="buyOrEquipWpn('+idx+')">';
      h+='<b style="color:'+w.col+'">'+w.name+'</b>';
      h+='<div style="font-size:9px;color:#bdc3c7;margin:2px 0">'+w.bonus+'</div>';
      h+='<div class="tag '+(eq?'eq':(u?'':'buy'))+'">'+(eq?'EQUIPAGGIATA':(u?'USA':w.cost+' 🐟'))+'</div></div>';
    });
    h+='</div>';
  }else{
    h+='<div class="gridCards">';
    h+='<div class="itemCard" onclick="claimFreeTuna()"><b>Cassa Omaggio</b><div style="font-size:16px">🎁</div><div class="tag">'+(freeClaimed?'RISCOSSO':'+15 🐟 GRATIS')+'</div></div>';
    h+='<div class="itemCard" onclick="openMysteryBox()"><b>Cassa Sorpresa</b><div style="font-size:16px">📦</div><div class="tag buy">10 🐟 (Premio!)</div></div>';
    h+='</div>';
  }
  p.innerHTML=h;
}

function handleMainBtn(){
  if(unlocked.at(curCat)){startGame(0);return}
  var cost=CATS.at(curCat).cost;
  if(tunaBank>=cost){
    tunaBank-=cost;unlocked[curCat]=1;saveAll();renderLobby();sfx(400,900,.25,"sine",.18);
  }else{
    setStat("Servono "+cost+" tonni! Raccoglili nelle casse o vai nel Negozio!");sfx(180,100,.15,"sawtooth",.12);
  }
}
function buyOrEquipSkin(idx){
  if(!unlocked.at(curCat)){setStat("Sblocca prima "+CATS.at(curCat).name+"!");return}
  if(unlSkins.at(curCat).at(idx)){eqSkins[curCat]=idx;saveAll();renderLobby();sfx(550,750,.08,"sine",.1);return}
  var cost=CATS.at(curCat).skins.at(idx).cost;
  if(tunaBank>=cost){tunaBank-=cost;unlSkins.at(curCat)[idx]=1;eqSkins[curCat]=idx;saveAll();renderLobby();sfx(450,950,.22,"sine",.16)}
  else{setStat("Servono "+cost+" tonni per questa skin!");sfx(180,100,.15,"sawtooth",.12)}
}
function buyOrEquipWpn(idx){
  if(unlWpns.at(idx)){eqWpn=WEAPONS.at(idx).id;saveAll();renderLobby();sfx(550,750,.08,"sine",.1);return}
  var cost=WEAPONS.at(idx).cost;
  if(tunaBank>=cost){tunaBank-=cost;unlWpns[idx]=1;eqWpn=WEAPONS.at(idx).id;saveAll();renderLobby();sfx(450,950,.22,"sine",.16)}
  else{setStat("Servono "+cost+" tonni per quest'arma!");sfx(180,100,.15,"sawtooth",.12)}
}
function claimFreeTuna(){
  if(freeClaimed){setStat("Hai già riscosso il regalo di benvenuto!");return}
  freeClaimed=1;tunaBank+=15;saveAll();renderLobby();sfx(500,1000,.25,"sine",.18);setStat("Hai ricevuto +15 Tonni gratis!");
}
function openMysteryBox(){
  if(tunaBank<10){setStat("Servono 10 tonni per aprire la Cassa Sorpresa!");sfx(180,100,.15,"sawtooth",.12);return}
  tunaBank-=10;
  var win=Math.random()<0.65?15:(Math.random()<0.85?25:40);
  tunaBank+=win;saveAll();renderLobby();sfx(400,1100,.3,"sine",.2);
  setStat("Cassa aperta! Hai vinto "+win+" 🐟!");
}
renderLobby();

