import { query } from './db.js';
export async function audit(req, action, entityType=null, entityId=null, metadata={}) {
  await query(
    `INSERT INTO audit_logs(actor_user_id,action,entity_type,entity_id,ip_address,metadata)
     VALUES($1,$2,$3,$4,$5,$6)`,
    [req.user?.sub || null, action, entityType, entityId, req.ip || null, metadata]
  );
}
