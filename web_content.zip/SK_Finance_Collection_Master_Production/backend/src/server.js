import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { z } from 'zod';
import { query } from './db.js';
import { signToken, requireAuth, allow } from './auth.js';
import { audit } from './audit.js';

dotenv.config();
const app = express();
app.set('trust proxy', 1);
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(',') || true }));
app.use(express.json({ limit:'1mb' }));
app.use(rateLimit({ windowMs: 15*60*1000, max: 300 }));

app.get('/api/health', (_,res)=>res.json({ok:true,service:'sk-finance-collection-api'}));

app.post('/api/auth/login', async (req,res)=>{
  const s=z.object({phone:z.string().min(6),password:z.string().min(6)}).safeParse(req.body);
  if(!s.success) return res.status(400).json({error:'Invalid login data'});
  const r=await query('SELECT * FROM users WHERE phone=$1 AND is_active=true',[s.data.phone]);
  if(!r.rowCount || !(await bcrypt.compare(s.data.password,r.rows[0].password_hash))) return res.status(401).json({error:'Invalid credentials'});
  const u=r.rows[0]; await audit({user:{sub:u.id},ip:req.ip},'LOGIN','users',u.id,{});
  res.json({token:signToken(u),user:{id:u.id,name:u.full_name,role:u.role,phone:u.phone}});
});

app.get('/api/dashboard',requireAuth,allow('ADMIN','MANAGER','AGENT'),async(req,res)=>{
  const [due,collected,pending,overdue]=await Promise.all([
    query(`SELECT COALESCE(SUM(due_amount),0) total FROM emi_schedule WHERE due_date=CURRENT_DATE`),
    query(`SELECT COALESCE(SUM(amount),0) total FROM collections WHERE collected_at::date=CURRENT_DATE`),
    query(`SELECT COUNT(*) count FROM emi_schedule WHERE status='PENDING'`),
    query(`SELECT COUNT(*) count FROM emi_schedule WHERE status='PENDING' AND due_date<CURRENT_DATE`)
  ]);
  res.json({todayDue:due.rows[0].total,todayCollected:collected.rows[0].total,pending:pending.rows[0].count,overdue:overdue.rows[0].count});
});

app.get('/api/customers',requireAuth,allow('ADMIN','MANAGER','AGENT'),async(req,res)=>{
  const r=await query(`SELECT c.*,COUNT(l.id)::int loan_count FROM customers c LEFT JOIN loans l ON l.customer_id=c.id GROUP BY c.id ORDER BY c.created_at DESC`);
  res.json(r.rows);
});

app.get('/api/emi/pending',requireAuth,allow('ADMIN','MANAGER','AGENT'),async(req,res)=>{
  const r=await query(`SELECT e.*,l.loan_number,c.full_name,c.phone FROM emi_schedule e JOIN loans l ON l.id=e.loan_id JOIN customers c ON c.id=l.customer_id WHERE e.status='PENDING' ORDER BY e.due_date`);
  res.json(r.rows);
});

app.post('/api/collections',requireAuth,allow('ADMIN','MANAGER','AGENT'),async(req,res)=>{
  const s=z.object({
    emiId:z.string().uuid(), amount:z.coerce.number().positive(),
    paymentMode:z.enum(['CASH','UPI','BANK_TRANSFER']),
    referenceNumber:z.string().max(120).optional(), notes:z.string().max(500).optional()
  }).safeParse(req.body);
  if(!s.success) return res.status(400).json({error:'Invalid collection data'});
  const client = await (await import('./db.js')).pool.connect();
  try {
    await client.query('BEGIN');
    const e=await client.query(`SELECT e.*,l.customer_id,l.agent_id FROM emi_schedule e JOIN loans l ON l.id=e.loan_id WHERE e.id=$1 FOR UPDATE`,[s.data.emiId]);
    if(!e.rowCount) throw new Error('EMI not found');
    const emi=e.rows[0];
    if(Number(s.data.amount) > Number(emi.due_amount)-Number(emi.paid_amount)) throw new Error('Amount exceeds outstanding EMI');
    const receipt='SKR-'+Date.now().toString().slice(-10);
    const c=await client.query(`INSERT INTO collections(receipt_number,emi_id,customer_id,agent_id,amount,payment_mode,reference_number,notes) VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [receipt,emi.id,emi.customer_id,req.user.role==='AGENT'?req.user.sub:emi.agent_id,s.data.amount,s.data.paymentMode,s.data.referenceNumber||null,s.data.notes||null]);
    const paid=Number(emi.paid_amount)+Number(s.data.amount);
    const status=paid>=Number(emi.due_amount)?'PAID':'PARTIAL';
    await client.query(`UPDATE emi_schedule SET paid_amount=$1,status=$2 WHERE id=$3`,[paid,status,emi.id]);
    await client.query(`INSERT INTO receipts(collection_id,receipt_number) VALUES($1,$2)`,[c.rows[0].id,receipt]);
    await client.query('COMMIT');
    await audit(req,'CREATE_COLLECTION','collections',c.rows[0].id,{receipt,paymentMode:s.data.paymentMode});
    res.status(201).json({collection:c.rows[0],receiptNumber:receipt});
  } catch(e) { await client.query('ROLLBACK'); res.status(400).json({error:e.message}); }
  finally { client.release(); }
});

app.get('/api/reports/daily',requireAuth,allow('ADMIN','MANAGER'),async(req,res)=>{
  const r=await query(`SELECT collected_at::date date,payment_mode,SUM(amount) total,COUNT(*) count FROM collections WHERE collected_at::date BETWEEN COALESCE($1::date,CURRENT_DATE) AND COALESCE($2::date,CURRENT_DATE) GROUP BY 1,2 ORDER BY 1 DESC,2`,[req.query.from||null,req.query.to||null]);
  res.json(r.rows);
});

app.get('/api/reports/agent',requireAuth,allow('ADMIN','MANAGER'),async(req,res)=>{
  const r=await query(`SELECT a.employee_code,u.full_name,COALESCE(SUM(c.amount),0) total_collection,COUNT(c.id)::int collection_count FROM agents a JOIN users u ON u.id=a.user_id LEFT JOIN collections c ON c.agent_id=a.id GROUP BY a.id,u.full_name,a.employee_code ORDER BY total_collection DESC`);
  res.json(r.rows);
});

app.get('/api/receipts/:number',requireAuth,async(req,res)=>{
  const r=await query(`SELECT c.*,cu.full_name,cu.phone,l.loan_number,e.installment_no,e.due_date FROM collections c JOIN customers cu ON cu.id=c.customer_id JOIN emi_schedule e ON e.id=c.emi_id JOIN loans l ON l.id=e.loan_id WHERE c.receipt_number=$1`,[req.params.number]);
  if(!r.rowCount) return res.status(404).json({error:'Receipt not found'});
  res.json(r.rows[0]);
});

app.post('/api/grievances',requireAuth,async(req,res)=>{
  const s=z.object({customerId:z.string().uuid().optional(),subject:z.string().min(3).max(200),description:z.string().min(3).max(3000)}).safeParse(req.body);
  if(!s.success) return res.status(400).json({error:'Invalid grievance'});
  const r=await query(`INSERT INTO grievances(customer_id,created_by,subject,description) VALUES($1,$2,$3,$4) RETURNING *`,[s.data.customerId||null,req.user.sub,s.data.subject,s.data.description]);
  await audit(req,'CREATE_GRIEVANCE','grievances',r.rows[0].id,{});
  res.status(201).json(r.rows[0]);
});

app.use((err,_,res,next)=>{ console.error(err); res.status(500).json({error:'Internal server error'}); });
app.listen(process.env.PORT||4000,()=>console.log(`SK Finance API running on ${process.env.PORT||4000}`));
