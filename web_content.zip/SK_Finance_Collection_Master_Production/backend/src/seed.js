import bcrypt from 'bcryptjs';
import { query, pool } from './db.js';
const hash = await bcrypt.hash('ChangeMe123!', 12);
await query(
  `INSERT INTO users(full_name,phone,email,password_hash,role)
   VALUES($1,$2,$3,$4,'ADMIN')
   ON CONFLICT(phone) DO NOTHING`,
  ['System Admin','9000000000','admin@example.com',hash]
);
console.log('Seed complete. Demo admin: 9000000000 / ChangeMe123!');
await pool.end();
