import jwt from 'jsonwebtoken';
export function signToken(user) {
  return jwt.sign({ sub: user.id, role: user.role, name: user.full_name }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '8h' });
}
export function requireAuth(req,res,next) {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) return res.status(401).json({error:'Authentication required'});
  try { req.user = jwt.verify(h.slice(7), process.env.JWT_SECRET); next(); }
  catch { return res.status(401).json({error:'Invalid or expired token'}); }
}
export const allow = (...roles) => (req,res,next) => roles.includes(req.user.role) ? next() : res.status(403).json({error:'Forbidden'});
