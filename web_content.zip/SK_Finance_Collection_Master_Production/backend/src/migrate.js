import fs from 'fs';
import { query, pool } from './db.js';
const sql = fs.readFileSync(new URL('../../database/schema.sql', import.meta.url), 'utf8');
await query(sql);
console.log('Database schema ready');
await pool.end();
