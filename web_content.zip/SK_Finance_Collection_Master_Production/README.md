# SK Finance Collection Master — Production Starter

A production-oriented starter based on the supplied SK Finance Collection prototype.

## Modules
- Admin dashboard
- Agent login and management
- Customer master
- Loan + EMI schedule
- Daily collection: Cash / UPI / Bank Transfer
- Automatic receipt records
- Pending / overdue EMI queries
- Agent/customer reports
- Daily/monthly collection reports
- Customer portal endpoints
- Support & grievance
- Role-based access control
- Audit logging
- PostgreSQL database
- Docker Compose for local deployment

## Stack
- Backend: Node.js + Express
- Database: PostgreSQL
- Auth: JWT + bcrypt
- Frontend: vanilla HTML/CSS/JS
- Validation: Zod

## Run
1. Copy `.env.example` to `.env` and set strong secrets.
2. `docker compose up -d db`
3. `cd backend && npm install`
4. `npm run migrate`
5. `npm run seed`
6. `npm run dev`
7. Open `frontend/index.html` or serve `frontend/` from a web server.

For production, put the API behind HTTPS/reverse proxy, use managed PostgreSQL/backups, rotate secrets, configure CORS, rate limits, monitoring, and an authorised payment provider. Do not put payment credentials in the frontend.
