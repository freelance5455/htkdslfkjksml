# Production checklist

Before real customer collections go live:

- Use HTTPS everywhere.
- Replace demo JWT/database secrets.
- Use managed PostgreSQL with automated backups and point-in-time recovery.
- Add refresh-token/session strategy and account lock/rate limiting.
- Add OTP only through an authorised provider if required.
- Enforce least-privilege roles and agent-to-customer assignment checks.
- Add KYC/consent/privacy policy workflows appropriate to the business and applicable law.
- Integrate only an authorised payment/UPI provider; verify webhooks server-side and make payment operations idempotent.
- Never trust a frontend payment-success message.
- Add receipt PDF generation and immutable receipt/audit references.
- Add reconciliation for cash, UPI and bank transfers.
- Add monitoring, alerting, structured logs and error tracking.
- Test backups and restore.
- Perform security testing before deployment.
