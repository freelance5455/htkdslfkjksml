const API='http://localhost:4000/api'; let token=localStorage.getItem('sk_token');
const money=n=>'₹'+Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:2});
async function api(path,opt={}){const r=await fetch(API+path,{...opt,headers:{'Content-Type':'application/json',Authorization:token?`Bearer ${token}`:''}}); const d=await r.json(); if(!r.ok) throw new Error(d.error||'Request failed'); return d;}
async function login(){try{const d=await api('/auth/login',{method:'POST',body:JSON.stringify({phone:phone.value,password:password.value})}); token=d.token;localStorage.setItem('sk_token',token);showApp();}catch(e){loginMsg.textContent=e.message}}
function showApp(){login.hidden=true;app.hidden=false;load()}
function logout(){localStorage.removeItem('sk_token');location.reload()}
async function load(){try{const d=await api('/dashboard');due.textContent=money(d.todayDue);collected.textContent=money(d.todayCollected);pending.textContent=d.pending;overdue.textContent=d.overdue;const list=await api('/emi/pending');rows.innerHTML=list.map(x=>`<tr><td>${x.full_name}</td><td>${x.loan_number}</td><td>${x.installment_no}</td><td>${money(x.due_amount-x.paid_amount)}</td><td>${x.due_date < new Date().toISOString().slice(0,10)?'OVERDUE':x.status}</td><td><button onclick="selectEmi('${x.id}',${x.due_amount-x.paid_amount})">Collect</button></td></tr>`).join('')}catch(e){if(e.message.includes('Authentication'))logout();else alert(e.message)}}
function selectEmi(id,amt){emiId.value=id;amount.value=amt;scrollTo(0,document.body.scrollHeight)}
async function collect(){try{const d=await api('/collections',{method:'POST',body:JSON.stringify({emiId:emiId.value,amount:Number(amount.value),paymentMode:mode.value,referenceNumber:ref.value||undefined})});result.textContent=`Collection saved\\nReceipt: ${d.receiptNumber}\\nAmount: ${money(d.collection.amount)}\\nMode: ${d.collection.payment_mode}`;load()}catch(e){result.textContent=e.message}}
if(token)showApp();
