// ==================== GÖREV TAKİP UYGULAMASI ====================
const STORAGE_KEY = 'gorevTakip_v2';

// Varsayılan kategoriler
const DEFAULT_CATEGORIES = [
  { id: 'cat1', name: 'Zikirler', color: '#10b981' },
  { id: 'cat2', name: 'Dersler', color: '#3b82f6' },
  { id: 'cat3', name: 'Namazlar', color: '#8b5cf6' }
];

let state = {
  tasks: [],
  categories: [...DEFAULT_CATEGORIES],
  theme: 'dark',
  selectedPriority: 'medium',
  selectedColor: '#3b82f6'
};

// ==================== YARDIMCI FONKSİYONLAR ====================
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function formatDateTR(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  const days = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  return `${d.getDate()} ${months[d.getMonth()]} ${days[d.getDay()]}`;
}

function getDayOfWeek(dateStr) {
  return new Date(dateStr + 'T00:00:00').getDay(); // 0=Pazar
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    tasks: state.tasks,
    categories: state.categories,
    theme: state.theme
  }));
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      state.tasks = data.tasks || [];
      state.categories = data.categories || [...DEFAULT_CATEGORIES];
      state.theme = data.theme || 'dark';
    }
  } catch (e) {
    console.error('State yüklenemedi', e);
  }
  applyTheme();
}

function applyTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  const icon = document.querySelector('#theme-toggle i');
  if (icon) {
    icon.className = state.theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
  }
}

function showToast(msg, duration = 2200) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), duration);
}

// ==================== GÖREV MANTIGI ====================
function isTaskForToday(task) {
  const today = todayStr();
  const day = getDayOfWeek(today);

  // Tek seferlik: dueDate bugünse
  if (task.recurrence.type === 'none') {
    return task.dueDate === today || (!task.dueDate && !task.completed);
  }

  // Her gün
  if (task.recurrence.type === 'daily') {
    return true;
  }

  // Belirli günler
  if (task.recurrence.type === 'custom') {
    return (task.recurrence.days || []).includes(day);
  }

  return false;
}

function isTaskCompletedToday(task) {
  const today = todayStr();
  // Bugün tamamlandı mı?
  if (task.completedAt && task.completedAt.startsWith(today)) return true;
  // History'den bak
  if (task.completionHistory) {
    const entry = task.completionHistory.find(h => h.date === today);
    if (entry) return entry.completed;
  }
  return false;
}

function getSubtaskProgress(task) {
  if (!task.subtasks || task.subtasks.length === 0) {
    return { done: task.completed ? 1 : 0, total: 1, percent: task.completed ? 100 : 0 };
  }
  const done = task.subtasks.filter(s => s.completed).length;
  const total = task.subtasks.length;
  return { done, total, percent: Math.round((done / total) * 100) };
}

function updateTaskCompletion(task) {
  if (task.subtasks && task.subtasks.length > 0) {
    const allDone = task.subtasks.every(s => s.completed);
    task.completed = allDone;
    if (allDone && !task.completedAt) {
      task.completedAt = new Date().toISOString();
      logCompletion(task, true);
    } else if (!allDone) {
      task.completedAt = null;
      logCompletion(task, false);
    }
  }
}

function logCompletion(task, completed) {
  const today = todayStr();
  if (!task.completionHistory) task.completionHistory = [];
  const existing = task.completionHistory.find(h => h.date === today);
  if (existing) {
    existing.completed = completed;
  } else {
    task.completionHistory.push({ date: today, completed });
  }
  // Son 60 gün tut
  if (task.completionHistory.length > 60) {
    task.completionHistory = task.completionHistory.slice(-60);
  }
}

function toggleTaskComplete(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  if (task.subtasks && task.subtasks.length > 0) {
    // Alt görev varsa ana checkbox sadece durum gösterir, toggle etmez
    // Ama kullanıcı ana görevi tıklarsa tüm alt görevleri tamamla/boşalt
    const allDone = task.subtasks.every(s => s.completed);
    task.subtasks.forEach(s => s.completed = !allDone);
    updateTaskCompletion(task);
  } else {
    task.completed = !task.completed;
    if (task.completed) {
      task.completedAt = new Date().toISOString();
      logCompletion(task, true);
    } else {
      task.completedAt = null;
      logCompletion(task, false);
    }
  }
  saveState();
  renderAll();
  if (task.completed) showToast('Görev tamamlandı! 🎉');
}

function toggleSubtask(taskId, subId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;
  const sub = task.subtasks.find(s => s.id === subId);
  if (!sub) return;
  sub.completed = !sub.completed;
  updateTaskCompletion(task);
  saveState();
  renderAll();
  if (task.completed) showToast('Tüm alt görevler tamamlandı! 🎉');
}

// ==================== RENDER ====================
function renderAll() {
  renderToday();
  renderAllTasks();
  renderCategories();
  renderStats();
  updateHeader();
  populateCategorySelects();
}

function updateHeader() {
  const now = new Date();
  const days = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  document.getElementById('date-display').textContent =
    `${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}, ${days[now.getDay()]}`;

  const todayTasks = state.tasks.filter(isTaskForToday);
  const completed = todayTasks.filter(t => {
    if (t.subtasks && t.subtasks.length > 0) {
      return t.subtasks.every(s => s.completed);
    }
    return t.completed || isTaskCompletedToday(t);
  }).length;

  const total = todayTasks.length;
  const percent = total ? Math.round((completed / total) * 100) : 0;

  document.getElementById('today-progress').style.width = percent + '%';
  document.getElementById('progress-text').textContent = `${completed} / ${total} tamamlandı (${percent}%)`;
  document.getElementById('today-count').textContent = total;
}

function createTaskCard(task, showDate = false) {
  const cat = state.categories.find(c => c.id === task.categoryId);
  const progress = getSubtaskProgress(task);
  const isCompleted = progress.percent === 100;

  const card = document.createElement('div');
  card.className = `task-card priority-${task.priority || 'medium'} ${isCompleted ? 'completed' : ''}`;
  card.dataset.id = task.id;

  let metaHtml = '';
  if (cat) {
    metaHtml += `<span class="category-tag" style="color:${cat.color}">${cat.name}</span>`;
  }
  if (task.dueTime) {
    metaHtml += `<span><i class="far fa-clock"></i> ${task.dueTime}</span>`;
  }
  if (showDate && task.dueDate) {
    metaHtml += `<span><i class="far fa-calendar"></i> ${formatDateTR(task.dueDate)}</span>`;
  }
  if (task.recurrence.type === 'daily') {
    metaHtml += `<span><i class="fas fa-redo"></i> Her gün</span>`;
  } else if (task.recurrence.type === 'custom') {
    const dayNames = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
    const days = (task.recurrence.days || []).map(d => dayNames[d]).join(', ');
    metaHtml += `<span><i class="fas fa-redo"></i> ${days}</span>`;
  }

  let subtasksHtml = '';
  if (task.subtasks && task.subtasks.length > 0) {
    subtasksHtml = `<div class="subtasks">`;
    task.subtasks.forEach(sub => {
      const mark = sub.completed ? '✓' : '✗';
      const markClass = sub.completed ? 'done' : 'pending';
      subtasksHtml += `
        <div class="subtask-item ${sub.completed ? 'completed' : ''}">
          <span class="task-status-mark ${markClass}" style="font-size:1rem;width:22px;">${mark}</span>
          <button class="subtask-check ${sub.completed ? 'checked' : ''}" data-task="${task.id}" data-sub="${sub.id}">
            <i class="fas fa-check"></i>
          </button>
          <span>${escapeHtml(sub.title)}</span>
        </div>`;
    });
    subtasksHtml += `</div>
      <div class="task-progress">
        <div class="task-progress-bar">
          <div class="task-progress-fill" style="width:${progress.percent}%"></div>
        </div>
        <div class="task-progress-text">${progress.done}/${progress.total} alt görev (${progress.percent}%)</div>
      </div>`;
  }

  const statusMark = isCompleted
    ? '<span class="task-status-mark done">✓</span>'
    : '<span class="task-status-mark pending">✗</span>';

  card.innerHTML = `
    <div class="task-header">
      ${statusMark}
      <button class="task-check ${isCompleted ? 'checked' : ''}" data-id="${task.id}">
        <i class="fas fa-check"></i>
      </button>
      <div class="task-info">
        <div class="task-title">${escapeHtml(task.title)}</div>
        <div class="task-meta">${metaHtml}</div>
      </div>
    </div>
    ${subtasksHtml}
  `;

  // Events
  card.querySelector('.task-check').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleTaskComplete(task.id);
  });

  card.querySelectorAll('.subtask-check').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleSubtask(btn.dataset.task, btn.dataset.sub);
    });
  });

  card.addEventListener('click', (e) => {
    if (e.target.closest('.task-check') || e.target.closest('.subtask-check')) return;
    openTaskModal(task.id);
  });

  return card;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function renderToday() {
  const container = document.getElementById('today-tasks');
  const empty = document.getElementById('empty-today');
  container.innerHTML = '';

  const todayTasks = state.tasks
    .filter(isTaskForToday)
    .sort((a, b) => {
      // Önce tamamlanmayanlar, sonra öncelik, sonra saat
      const aDone = getSubtaskProgress(a).percent === 100;
      const bDone = getSubtaskProgress(b).percent === 100;
      if (aDone !== bDone) return aDone ? 1 : -1;
      const prio = { high: 0, medium: 1, low: 2 };
      if (prio[a.priority] !== prio[b.priority]) return prio[a.priority] - prio[b.priority];
      return (a.dueTime || '99:99').localeCompare(b.dueTime || '99:99');
    });

  if (todayTasks.length === 0) {
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    todayTasks.forEach(t => container.appendChild(createTaskCard(t)));
  }
}

function renderAllTasks() {
  const container = document.getElementById('all-tasks');
  const empty = document.getElementById('empty-all');
  const search = document.getElementById('search-input').value.toLowerCase();
  const catFilter = document.getElementById('category-filter').value;

  container.innerHTML = '';

  let tasks = [...state.tasks];

  if (search) {
    tasks = tasks.filter(t =>
      t.title.toLowerCase().includes(search) ||
      (t.subtasks || []).some(s => s.title.toLowerCase().includes(search))
    );
  }
  if (catFilter !== 'all') {
    tasks = tasks.filter(t => t.categoryId === catFilter);
  }

  // Kategoriye göre grupla
  tasks.sort((a, b) => {
    const aDone = getSubtaskProgress(a).percent === 100;
    const bDone = getSubtaskProgress(b).percent === 100;
    if (aDone !== bDone) return aDone ? 1 : -1;
    return (b.createdAt || '').localeCompare(a.createdAt || '');
  });

  if (tasks.length === 0) {
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    tasks.forEach(t => container.appendChild(createTaskCard(t, true)));
  }
}

function renderCategories() {
  const container = document.getElementById('categories-list');
  container.innerHTML = '';

  state.categories.forEach(cat => {
    const count = state.tasks.filter(t => t.categoryId === cat.id).length;
    const card = document.createElement('div');
    card.className = 'category-card';
    card.innerHTML = `
      <div class="color-dot" style="background:${cat.color}"></div>
      <h3>${escapeHtml(cat.name)}</h3>
      <div class="count">${count} görev</div>
    `;
    card.addEventListener('click', () => {
      document.querySelector('[data-view="all"]').click();
      document.getElementById('category-filter').value = cat.id;
      renderAllTasks();
    });
    container.appendChild(card);
  });
}

function renderStats() {
  const today = todayStr();
  const todayTasks = state.tasks.filter(isTaskForToday);
  const todayDone = todayTasks.filter(t => getSubtaskProgress(t).percent === 100).length;
  const todayRate = todayTasks.length ? Math.round((todayDone / todayTasks.length) * 100) : 0;
  document.getElementById('stat-today-rate').textContent = todayRate + '%';

  // Haftalık
  const weekRates = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.toISOString().slice(0, 10);
    const day = d.getDay();

    let total = 0, done = 0;
    state.tasks.forEach(task => {
      let applies = false;
      if (task.recurrence.type === 'daily') applies = true;
      else if (task.recurrence.type === 'custom' && (task.recurrence.days || []).includes(day)) applies = true;
      else if (task.recurrence.type === 'none' && task.dueDate === ds) applies = true;

      if (applies) {
        total++;
        const hist = (task.completionHistory || []).find(h => h.date === ds);
        if (hist && hist.completed) done++;
        else if (ds === today && getSubtaskProgress(task).percent === 100) done++;
      }
    });
    weekRates.push({ date: ds, day, total, done, rate: total ? Math.round((done / total) * 100) : 0 });
  }

  const weekAvg = weekRates.length
    ? Math.round(weekRates.reduce((s, r) => s + r.rate, 0) / weekRates.length)
    : 0;
  document.getElementById('stat-week-rate').textContent = weekAvg + '%';

  // Aylık (son 30 gün basit ortalama)
  let monthTotal = 0, monthDone = 0;
  for (let i = 0; i < 30; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.toISOString().slice(0, 10);
    state.tasks.forEach(task => {
      const hist = (task.completionHistory || []).find(h => h.date === ds);
      if (hist) {
        monthTotal++;
        if (hist.completed) monthDone++;
      }
    });
  }
  const monthRate = monthTotal ? Math.round((monthDone / monthTotal) * 100) : 0;
  document.getElementById('stat-month-rate').textContent = monthRate + '%';

  // Streak
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.toISOString().slice(0, 10);
    const day = d.getDay();

    let total = 0, done = 0;
    state.tasks.forEach(task => {
      let applies = false;
      if (task.recurrence.type === 'daily') applies = true;
      else if (task.recurrence.type === 'custom' && (task.recurrence.days || []).includes(day)) applies = true;
      else if (task.recurrence.type === 'none' && task.dueDate === ds) applies = true;
      if (applies) {
        total++;
        const hist = (task.completionHistory || []).find(h => h.date === ds);
        if (hist && hist.completed) done++;
        else if (ds === today && getSubtaskProgress(task).percent === 100) done++;
      }
    });
    if (total === 0 || done === total) {
      if (total > 0) streak++;
    } else {
      break;
    }
  }
  document.getElementById('stat-streak').textContent = streak;

  // Haftalık chart
  const chart = document.getElementById('weekly-chart');
  chart.innerHTML = '';
  const dayNames = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
  weekRates.forEach(r => {
    const wrap = document.createElement('div');
    wrap.className = 'chart-bar-wrapper';
    const height = Math.max(r.rate, 4);
    wrap.innerHTML = `
      <div class="chart-bar" style="height:${height}%"></div>
      <div class="chart-label">${dayNames[r.day]}</div>
    `;
    chart.appendChild(wrap);
  });

  // History list
  const histList = document.getElementById('history-list');
  histList.innerHTML = '';
  weekRates.slice().reverse().forEach(r => {
    const item = document.createElement('div');
    item.className = 'history-item';
    item.innerHTML = `
      <div>
        <strong>${formatDateTR(r.date)}</strong>
        <div style="font-size:0.8rem;color:var(--text-muted)">${r.done}/${r.total} görev</div>
      </div>
      <div class="rate">${r.rate}%</div>
    `;
    histList.appendChild(item);
  });

  // Kategori istatistik
  const catStats = document.getElementById('category-stats');
  catStats.innerHTML = '';
  const catCounts = {};
  state.tasks.forEach(t => {
    if (!catCounts[t.categoryId]) catCounts[t.categoryId] = { total: 0, done: 0 };
    catCounts[t.categoryId].total++;
    if (getSubtaskProgress(t).percent === 100) catCounts[t.categoryId].done++;
  });

  state.categories.forEach(cat => {
    const c = catCounts[cat.id] || { total: 0, done: 0 };
    if (c.total === 0) return;
    const percent = Math.round((c.done / c.total) * 100);
    const item = document.createElement('div');
    item.className = 'cat-stat-item';
    item.innerHTML = `
      <div class="dot" style="background:${cat.color}"></div>
      <div style="min-width:70px">${escapeHtml(cat.name)}</div>
      <div class="bar-bg"><div class="bar-fill" style="width:${percent}%;background:${cat.color}"></div></div>
      <div style="min-width:40px;text-align:right;font-size:0.85rem">${percent}%</div>
    `;
    catStats.appendChild(item);
  });
}

function populateCategorySelects() {
  const selects = [document.getElementById('task-category'), document.getElementById('category-filter')];
  selects.forEach((sel, idx) => {
    if (!sel) return;
    const current = sel.value;
    if (idx === 1) {
      sel.innerHTML = '<option value="all">Tüm Kategoriler</option>';
    } else {
      sel.innerHTML = '';
    }
    state.categories.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.name;
      sel.appendChild(opt);
    });
    if (current) sel.value = current;
  });
}

// ==================== MODAL & FORM ====================
function openTaskModal(taskId = null) {
  const modal = document.getElementById('task-modal');
  const form = document.getElementById('task-form');
  form.reset();
  document.getElementById('subtasks-container').innerHTML = '';
  document.getElementById('days-selector').classList.add('hidden');
  document.getElementById('delete-task-btn').classList.add('hidden');
  state.selectedPriority = 'medium';
  updatePriorityButtons();

  if (taskId) {
    const task = state.tasks.find(t => t.id === taskId);
    if (!task) return;
    document.getElementById('modal-title').textContent = 'Görevi Düzenle';
    document.getElementById('task-id').value = task.id;
    document.getElementById('task-title').value = task.title;
    document.getElementById('task-category').value = task.categoryId || '';
    document.getElementById('task-date').value = task.dueDate || '';
    document.getElementById('task-time').value = task.dueTime || '';
    document.getElementById('task-recurrence').value = task.recurrence.type;
    state.selectedPriority = task.priority || 'medium';
    updatePriorityButtons();

    if (task.recurrence.type === 'custom') {
      document.getElementById('days-selector').classList.remove('hidden');
      document.querySelectorAll('#days-selector input').forEach(cb => {
        cb.checked = (task.recurrence.days || []).includes(parseInt(cb.value));
      });
    }

    (task.subtasks || []).forEach(sub => addSubtaskInput(sub.title, sub.id));
    document.getElementById('delete-task-btn').classList.remove('hidden');
  } else {
    document.getElementById('modal-title').textContent = 'Yeni Görev';
    document.getElementById('task-id').value = '';
    // Varsayılan bugünün tarihi
    document.getElementById('task-date').value = todayStr();
  }

  modal.classList.remove('hidden');
  document.getElementById('task-title').focus();
}

function closeTaskModal() {
  document.getElementById('task-modal').classList.add('hidden');
}

function addSubtaskInput(value = '', id = null) {
  const container = document.getElementById('subtasks-container');
  const row = document.createElement('div');
  row.className = 'subtask-input-row';
  row.innerHTML = `
    <input type="text" placeholder="Alt görev..." value="${escapeHtml(value)}" data-id="${id || ''}">
    <button type="button" class="remove-sub"><i class="fas fa-times"></i></button>
  `;
  row.querySelector('.remove-sub').addEventListener('click', () => row.remove());
  container.appendChild(row);
}

function updatePriorityButtons() {
  document.querySelectorAll('.priority-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.priority === state.selectedPriority);
  });
}

function handleTaskSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('task-id').value;
  const title = document.getElementById('task-title').value.trim();
  if (!title) return;

  const recurrenceType = document.getElementById('task-recurrence').value;
  let days = [];
  if (recurrenceType === 'custom') {
    document.querySelectorAll('#days-selector input:checked').forEach(cb => {
      days.push(parseInt(cb.value));
    });
    if (days.length === 0) {
      showToast('En az bir gün seçmelisin');
      return;
    }
  }

  const subtasks = [];
  document.querySelectorAll('#subtasks-container input').forEach(input => {
    const t = input.value.trim();
    if (t) {
      subtasks.push({
        id: input.dataset.id || generateId(),
        title: t,
        completed: false
      });
    }
  });

  // Mevcut alt görev tamamlanma durumlarını koru
  if (id) {
    const oldTask = state.tasks.find(t => t.id === id);
    if (oldTask && oldTask.subtasks) {
      subtasks.forEach(s => {
        const old = oldTask.subtasks.find(os => os.id === s.id);
        if (old) s.completed = old.completed;
      });
    }
  }

  const taskData = {
    id: id || generateId(),
    title,
    categoryId: document.getElementById('task-category').value || state.categories[0]?.id,
    dueDate: document.getElementById('task-date').value || null,
    dueTime: document.getElementById('task-time').value || null,
    priority: state.selectedPriority,
    recurrence: { type: recurrenceType, days },
    subtasks,
    completed: false,
    completedAt: null,
    createdAt: id ? (state.tasks.find(t => t.id === id)?.createdAt || new Date().toISOString()) : new Date().toISOString(),
    completionHistory: id ? (state.tasks.find(t => t.id === id)?.completionHistory || []) : []
  };

  // Alt görevlere göre tamamlanma
  updateTaskCompletion(taskData);

  if (id) {
    const idx = state.tasks.findIndex(t => t.id === id);
    // Eski history ve completedAt'i koru
    taskData.completionHistory = state.tasks[idx].completionHistory || [];
    taskData.completedAt = state.tasks[idx].completedAt;
    state.tasks[idx] = taskData;
    showToast('Görev güncellendi');
  } else {
    state.tasks.unshift(taskData);
    showToast('Görev eklendi ✨');
  }

  saveState();
  closeTaskModal();
  renderAll();
}

function deleteTask() {
  const id = document.getElementById('task-id').value;
  if (!id || !confirm('Bu görevi silmek istediğine emin misin?')) return;
  state.tasks = state.tasks.filter(t => t.id !== id);
  saveState();
  closeTaskModal();
  renderAll();
  showToast('Görev silindi');
}

// ==================== EXCEL RAPOR ====================
function generateExcelReport(period) {
  if (typeof XLSX === 'undefined') {
    showToast('Excel kütüphanesi yüklenemedi');
    return;
  }

  const today = new Date();
  let startDate, endDate, title;

  if (period === 'week') {
    // Bu haftanın Pazartesi'si
    const day = today.getDay();
    const diff = day === 0 ? 6 : day - 1;
    startDate = new Date(today);
    startDate.setDate(today.getDate() - diff);
    endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 6);
    title = 'Haftalık Rapor';
  } else if (period === 'month') {
    startDate = new Date(today.getFullYear(), today.getMonth(), 1);
    endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    title = 'Aylık Rapor';
  } else { // year
    startDate = new Date(today.getFullYear(), 0, 1);
    endDate = new Date(today.getFullYear(), 11, 31);
    title = 'Yıllık Rapor';
  }

  const startStr = startDate.toISOString().slice(0, 10);
  const endStr = endDate.toISOString().slice(0, 10);

  // Rapor verisi hazırla
  const rows = [];
  rows.push(['Görev Takip Raporu - ' + title]);
  rows.push(['Dönem:', formatDateTR(startStr) + ' - ' + formatDateTR(endStr)]);
  rows.push(['Oluşturulma:', new Date().toLocaleString('tr-TR')]);
  rows.push([]);
  rows.push(['Görev', 'Kategori', 'Durum', 'Tarih', 'Saat', 'Tekrar', 'Alt Görevler', 'Tamamlanma %']);

  state.tasks.forEach(task => {
    const cat = state.categories.find(c => c.id === task.categoryId);
    const progress = getSubtaskProgress(task);
    const status = progress.percent === 100 ? '✓ Tamamlandı' : '✗ Eksik';
    const subText = (task.subtasks || []).map(s => (s.completed ? '✓ ' : '✗ ') + s.title).join(' | ') || '-';
    let tekrar = 'Tek seferlik';
    if (task.recurrence.type === 'daily') tekrar = 'Her gün';
    else if (task.recurrence.type === 'custom') {
      const dayNames = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
      tekrar = (task.recurrence.days || []).map(d => dayNames[d]).join(', ');
    }

    rows.push([
      task.title,
      cat ? cat.name : '-',
      status,
      task.dueDate || '-',
      task.dueTime || '-',
      tekrar,
      subText,
      progress.percent + '%'
    ]);
  });

  // Günlük özet sayfası
  const dailyRows = [];
  dailyRows.push(['Günlük Özet']);
  dailyRows.push(['Tarih', 'Gün', 'Toplam Görev', 'Tamamlanan', 'Oran %']);

  let current = new Date(startDate);
  while (current <= endDate) {
    const ds = current.toISOString().slice(0, 10);
    const day = current.getDay();
    const dayNames = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];

    let total = 0, done = 0;
    state.tasks.forEach(task => {
      let applies = false;
      if (task.recurrence.type === 'daily') applies = true;
      else if (task.recurrence.type === 'custom' && (task.recurrence.days || []).includes(day)) applies = true;
      else if (task.recurrence.type === 'none' && task.dueDate === ds) applies = true;

      if (applies) {
        total++;
        const hist = (task.completionHistory || []).find(h => h.date === ds);
        if (hist && hist.completed) done++;
        else if (ds === todayStr() && getSubtaskProgress(task).percent === 100) done++;
      }
    });

    const rate = total ? Math.round((done / total) * 100) : 0;
    dailyRows.push([ds, dayNames[day], total, done, rate]);
    current.setDate(current.getDate() + 1);
  }

  // Workbook oluştur
  const wb = XLSX.utils.book_new();

  const ws1 = XLSX.utils.aoa_to_sheet(rows);
  // Sütun genişlikleri
  ws1['!cols'] = [
    { wch: 30 }, { wch: 12 }, { wch: 14 }, { wch: 12 },
    { wch: 8 }, { wch: 16 }, { wch: 40 }, { wch: 12 }
  ];
  XLSX.utils.book_append_sheet(wb, ws1, 'Görev Listesi');

  const ws2 = XLSX.utils.aoa_to_sheet(dailyRows);
  ws2['!cols'] = [{ wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 12 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, ws2, 'Günlük Özet');

  // İndir
  const fileName = `Gorev_Raporu_${period}_${todayStr()}.xlsx`;
  XLSX.writeFile(wb, fileName);
  showToast('Excel raporu indirildi! 📊');
}

// ==================== KATEGORİ ====================
function openCategoryModal() {
  document.getElementById('category-form').reset();
  state.selectedColor = '#3b82f6';
  document.querySelectorAll('.color-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.color === state.selectedColor);
  });
  document.getElementById('category-modal').classList.remove('hidden');
}

function closeCategoryModal() {
  document.getElementById('category-modal').classList.add('hidden');
}

function handleCategorySubmit(e) {
  e.preventDefault();
  const name = document.getElementById('category-name').value.trim();
  if (!name) return;
  state.categories.push({
    id: generateId(),
    name,
    color: state.selectedColor
  });
  saveState();
  closeCategoryModal();
  renderAll();
  showToast('Kategori eklendi');
}

// ==================== NAVİGASYON ====================
function switchView(viewName) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const view = document.getElementById(viewName + '-view');
  if (view) view.classList.add('active');

  const nav = document.querySelector(`.nav-item[data-view="${viewName}"]`);
  if (nav) nav.classList.add('active');

  const titles = {
    today: 'Bugün',
    all: 'Tüm Görevler',
    categories: 'Kategoriler',
    stats: 'İstatistikler'
  };
  document.getElementById('page-title').textContent = titles[viewName] || 'Görev Takip';

  // Progress sadece bugün görünümünde
  document.querySelector('.progress-summary').style.display = viewName === 'today' ? 'block' : 'none';
}

// ==================== INIT ====================
function init() {
  loadState();
  renderAll();

  // Navigation
  document.querySelectorAll('.nav-item[data-view]').forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });

  // FAB
  document.getElementById('add-task-btn').addEventListener('click', () => openTaskModal());

  // Theme
  document.getElementById('theme-toggle').addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    saveState();
  });

  // Stats shortcut
  document.getElementById('stats-btn').addEventListener('click', () => switchView('stats'));

  // Modal
  document.getElementById('close-modal').addEventListener('click', closeTaskModal);
  document.getElementById('task-modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('task-modal')) closeTaskModal();
  });
  document.getElementById('task-form').addEventListener('submit', handleTaskSubmit);
  document.getElementById('delete-task-btn').addEventListener('click', deleteTask);
  document.getElementById('add-subtask-btn').addEventListener('click', () => addSubtaskInput());

  // Recurrence
  document.getElementById('task-recurrence').addEventListener('change', (e) => {
    document.getElementById('days-selector').classList.toggle('hidden', e.target.value !== 'custom');
  });

  // Priority
  document.querySelectorAll('.priority-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedPriority = btn.dataset.priority;
      updatePriorityButtons();
    });
  });

  // Category modal
  document.getElementById('add-category-btn').addEventListener('click', openCategoryModal);
  document.getElementById('close-category-modal').addEventListener('click', closeCategoryModal);
  document.getElementById('category-modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('category-modal')) closeCategoryModal();
  });
  document.getElementById('category-form').addEventListener('submit', handleCategorySubmit);

  document.querySelectorAll('.color-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedColor = btn.dataset.color;
      document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Search & filter
  document.getElementById('search-input').addEventListener('input', renderAllTasks);
  document.getElementById('category-filter').addEventListener('change', renderAllTasks);

  // Excel Rapor butonları
  document.querySelectorAll('.btn-report').forEach(btn => {
    btn.addEventListener('click', () => {
      generateExcelReport(btn.dataset.period);
    });
  });

  // Service Worker for PWA
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
}

document.addEventListener('DOMContentLoaded', init);
