# ✅ Görev Takip - Mobil Uygulama

Akıllı görev takip Progressive Web App (PWA).

## Özellikler

### Temel
- **Bugün görünümü**: Ana sayfa açılınca o günün görevleri gelir
- **Kategoriler**: Zikirler, Dersler, Namazlar + istediğin kadar yeni kategori ekleyebilirsin
- **Alt görevler**: Görevlere alt görev ekle. Tüm alt görevler tamamlanınca ana görev otomatik tamamlanır
- **Tarih & Saat**: Görevlere gün ve saat ekle
- **Tekrarlama**:
  - Tek seferlik
  - Her gün
  - Belirli günler (Pzt, Sal, Çar...)
- **✓ / ✗ işaretleri**: Görev listesinde tamamlananlar ✓, eksikler ✗ ile net gösterilir

### İstatistikler
- Bugün / Bu hafta / Bu ay tamamlanma oranı (%)
- Seri (streak) takibi
- Haftalık bar grafik
- Son 7 gün detayı
- Kategori bazlı başarı oranları
- **Excel Rapor**: Haftalık / Aylık / Yıllık rapor indir (görev listesi + günlük özet)

### Ekstralar
- Öncelik seviyeleri (Düşük / Orta / Yüksek)
- Koyu / Açık tema
- Arama ve kategori filtresi
- Offline çalışır (PWA)
- Telefona ana ekrana eklenebilir
- Veriler cihazında kalır (localStorage)

## Nasıl Kullanılır?

### 1. Bilgisayarda test et
Dosyaları bir klasöre koy, `index.html` dosyasını tarayıcıda aç.

### 2. Telefona yükle (Önerilen)
1. Dosyaları bir web sunucusuna yükle (GitHub Pages, Netlify, Vercel bedava)
2. Telefonda Chrome / Safari ile aç
3. "Ana ekrana ekle" / "Add to Home Screen" de
4. Artık normal uygulama gibi çalışır

### 3. Yerel sunucu ile test
```bash
# Python varsa
python -m http.server 8080

# veya Node.js
npx serve .
```
Sonra telefonda aynı ağdaki IP adresini aç.

## Dosya Yapısı
```
gorev-takip/
├── index.html      # Ana sayfa
├── styles.css      # Tasarım
├── app.js          # Tüm mantık
├── manifest.json   # PWA ayarları
├── sw.js           # Offline desteği
└── README.md
```

## Teknik
- Saf HTML + CSS + JavaScript (framework yok)
- localStorage ile veri saklama
- Mobil-first responsive tasarım
- Service Worker ile offline

---
Keyifli kullanımlar! 🚀
