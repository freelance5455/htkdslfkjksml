RedBrowser Developer and Premium Mode

Changes:
- Developer Mode asks for the password configured in index.html.
- Correct password reveals developer controls and the local Premium Mode toggle.
- Reset settings locks both modes again.

Security limitation:
This is a client-side HTML prototype. The password is present in the source and can be extracted or bypassed by someone who inspects/modifies the APK. The Premium Mode toggle only changes local UI state; it does not grant paid service access or secure server-side entitlements. For production, move authentication and premium entitlement checks to a server and do not ship the password in the APK.
