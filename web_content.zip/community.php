<?php
declare(strict_types=1);
// Explore has been retired. Keep old bookmarks from landing on a dead page.
header('Location: dashboard.php', true, 302);
exit;
