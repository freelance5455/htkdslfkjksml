/* Highland Reach - controls, settings, journal and install layer.
   Talks to game.js only through window.HR_INPUT and ordinary keyboard/mouse events. */
(() => {
'use strict';
const $ = id => document.getElementById(id), H = window.HR_INPUT;
if (!H) { console.warn('HR_INPUT missing: game.js did not start'); return; }
const TOUCH = (matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window) && !matchMedia('(pointer: fine) and (hover: hover)').matches;
const STANDALONE = matchMedia('(display-mode: standalone)').matches || navigator.standalone;
if (TOUCH) document.body.classList.add('touch');

/* ---------- synthetic keys ---------- */
const down = new Set();
const kd = c => { if (down.has(c)) return; down.add(c); dispatchEvent(new KeyboardEvent('keydown', { code: c, key: c, bubbles: true })); };
const ku = c => { if (!down.has(c)) return; down.delete(c); dispatchEvent(new KeyboardEvent('keyup', { code: c, key: c, bubbles: true })); };
const tap = c => { dispatchEvent(new KeyboardEvent('keydown', { code: c, key: c, bubbles: true })); setTimeout(() => dispatchEvent(new KeyboardEvent('keyup', { code: c, key: c, bubbles: true })), 40); };
const mouse = (type) => document.dispatchEvent(new MouseEvent(type, { button: 0, bubbles: true }));
const releaseHooks = [];
const releaseAll = () => { for (const c of [...down]) ku(c); releaseHooks.forEach(f => f()); };
setInterval(() => { if (!H.locked && (down.size)) releaseAll(); }, 250);
const buzz = ms => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} };

/* ---------- start-screen: pointer type decides lock style, fullscreen on touch ---------- */
const goBtn = $('go');
goBtn.addEventListener('pointerdown', e => {
  H.soft = e.pointerType !== 'mouse';
  if (H.soft) { goFull(); }
}, true);
function goFull() {
  const el = document.documentElement;
  if (!document.fullscreenElement && el.requestFullscreen && !STANDALONE) el.requestFullscreen({ navigationUI: 'hide' }).then(() => {
    try { screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(() => {}); } catch (e) {}
  }).catch(() => {});
}
function toggleFull() { if (document.fullscreenElement) document.exitFullscreen(); else goFull(); }
const fsBtn = $('fs'); if (fsBtn) fsBtn.onclick = toggleFull;

/* Esc / pause when there is no pointer lock to release */
addEventListener('keydown', e => { if (e.code === 'Escape' && H.locked && H.soft) H.pause(); });

/* ---------- wake lock while playing ---------- */
let wl = null;
setInterval(async () => {
  try {
    if (H.locked && !wl && navigator.wakeLock) { wl = await navigator.wakeLock.request('screen'); wl.addEventListener('release', () => wl = null); }
    else if (!H.locked && wl) { wl.release(); wl = null; }
  } catch (e) { wl = null; }
}, 1500);

/* ---------- touch controls ---------- */
if (TOUCH) {
  const ui = document.createElement('div'); ui.id = 'touchui';
  ui.innerHTML = `
    <div id="tstick"><i></i></div>
    <div id="tlook"></div>
    <div id="tbtns">
      <button data-hold="mouse" id="t-fire" aria-label="Shoot">FIRE</button>
      <button data-hold="Space" id="t-jump">JUMP</button>
      <button data-toggle="ShiftLeft" id="t-run">RUN</button>
      <button data-toggle="KeyC" id="t-crouch">DUCK</button>
      <button data-tap="KeyE" id="t-use">USE</button>
    </div>
    <div id="titems"><button data-tap="Digit1">🌿</button><button data-tap="Digit2">🍶</button><button data-tap="Digit3">🍖</button></div>
    <div id="ttop">
      <button data-act="pause">☰</button><button data-tap="KeyI">🎒</button><button data-tap="KeyM">🗺</button>
      <button data-tap="KeyV">👁</button><button data-tap="KeyF">🔦</button><button data-hold="KeyZ">🔍</button><button data-tap="KeyP">📷</button>
    </div>
    <div id="tmap">
      <button data-tap="KeyM">✕ Close</button><button data-act="travel">◎ Travel</button><button data-tap="KeyP">📍 Pin</button>
      <button data-tap="KeyH">⌖ Me</button><button data-tap="Comma">◀ Site</button><button data-tap="Period">Site ▶</button>
      <button data-tap="KeyL">Layers</button><button data-tap="KeyK">Labels</button><button data-hold="KeyX">▲</button><button data-hold="KeyZ">▼</button>
    </div>`;
  document.body.appendChild(ui);
  const rot = document.createElement('div'); rot.id = 'rotate'; rot.textContent = 'Rotate your phone sideways to play'; document.body.appendChild(rot);

  const stickEl = $('tstick'), knob = stickEl.firstElementChild, R = 58;
  let stickId = null, sx = 0, sy = 0;
  const setDir = (x, y) => {
    const m = Math.hypot(x, y);
    (y < -0.3 && m > 0.25 ? kd : ku)('KeyW'); (y > 0.3 && m > 0.25 ? kd : ku)('KeyS');
    (x < -0.3 && m > 0.25 ? kd : ku)('KeyA'); (x > 0.3 && m > 0.25 ? kd : ku)('KeyD');
    if (!toggled.has('ShiftLeft')) (m > 0.92 && y < -0.3 ? kd : ku)('ShiftLeft');
  };
  const toggled = new Set(), looks = new Map(); let pinch = 0;
  releaseHooks.push(() => { toggled.clear(); ui.querySelectorAll('.lit,.on').forEach(x => x.classList.remove('lit', 'on')); if (stickId !== null) { stickId = null; stickEl.classList.remove('on'); stickEl.style.left = stickEl.style.top = ''; knob.style.transform = ''; } looks.clear(); });
  function stickMove(t) {
    let dx = t.clientX - sx, dy = t.clientY - sy; const m = Math.hypot(dx, dy);
    if (m > R) { dx *= R / m; dy *= R / m; }
    knob.style.transform = `translate(${dx}px,${dy}px)`; setDir(dx / R, dy / R);
  }
  function stickEnd() { stickId = null; stickEl.classList.remove('on'); stickEl.style.left = stickEl.style.top = ''; knob.style.transform = ''; setDir(0, 0); if (!toggled.has('ShiftLeft')) ku('ShiftLeft'); }

  /* left half of screen = floating stick, right half = look. Each touch is tracked by id. */
  const area = e => e.clientX < innerWidth * 0.42 ? 'stick' : 'look';
  addEventListener('touchstart', e => {
    if (!H.locked) return;
    for (const t of e.changedTouches) {
      if (t.target.closest('button')) continue;
      if (area(t) === 'stick' && stickId === null && !H.map) { stickId = t.identifier; sx = t.clientX; sy = t.clientY; stickEl.style.left = sx + 'px'; stickEl.style.top = sy + 'px'; stickEl.classList.add('on'); }
      else { looks.set(t.identifier, [t.clientX, t.clientY]); }
    }
    if (looks.size === 2 && H.map) { const [a, b] = [...looks.values()]; pinch = Math.hypot(a[0] - b[0], a[1] - b[1]); }
    e.preventDefault();
  }, { passive: false });
  addEventListener('touchmove', e => {
    if (!H.locked) return;
    for (const t of e.changedTouches) {
      if (t.identifier === stickId) stickMove(t);
      else if (looks.has(t.identifier)) {
        const p = looks.get(t.identifier); const dx = t.clientX - p[0], dy = t.clientY - p[1]; p[0] = t.clientX; p[1] = t.clientY;
        if (H.map && looks.size === 2) { const [a, b] = [...looks.values()]; const d = Math.hypot(a[0] - b[0], a[1] - b[1]); if (pinch) H.mapZoom(pinch / Math.max(d, 1)); pinch = d; }
        else H.look(dx * 1.7, dy * 1.7);
      }
    }
    e.preventDefault();
  }, { passive: false });
  const endT = e => {
    for (const t of e.changedTouches) { if (t.identifier === stickId) stickEnd(); looks.delete(t.identifier); }
    if (looks.size < 2) pinch = 0;
  };
  addEventListener('touchend', endT); addEventListener('touchcancel', endT);

  /* buttons */
  ui.querySelectorAll('button').forEach(b => {
    const d = b.dataset;
    const press = e => {
      e.preventDefault(); e.stopPropagation(); b.classList.add('on'); buzz(8);
      if (d.hold === 'mouse') mouse('mousedown');
      else if (d.hold) kd(d.hold);
      else if (d.tap) tap(d.tap);
      else if (d.toggle) { if (toggled.has(d.toggle)) { toggled.delete(d.toggle); ku(d.toggle); b.classList.remove('lit'); } else { toggled.add(d.toggle); kd(d.toggle); b.classList.add('lit'); } }
      else if (d.act === 'pause') H.pause();
      else if (d.act === 'travel') mouse('mousedown');
    };
    const rel = e => { e.preventDefault(); b.classList.remove('on'); if (d.hold === 'mouse') mouse('mouseup'); else if (d.hold) ku(d.hold); };
    b.addEventListener('touchstart', press, { passive: false });
    b.addEventListener('touchend', rel, { passive: false }); b.addEventListener('touchcancel', rel, { passive: false });
    b.addEventListener('contextmenu', e => e.preventDefault());
  });
  setInterval(() => { document.body.classList.toggle('mapopen', !!H.map); }, 150);
  document.addEventListener('contextmenu', e => e.preventDefault());
}

/* ---------- gamepad ---------- */
(() => {
  let prev = [], pressedAny = 0, last = performance.now(), padHeld = new Set();
  const dz = v => Math.abs(v) < 0.16 ? 0 : (v - Math.sign(v) * 0.16) / 0.84;
  const key = (c, on) => { if (on) { padHeld.add(c); kd(c); } else if (padHeld.has(c)) { padHeld.delete(c); ku(c); } };
  let sprint = false, crouch = false;
  function poll(now) {
    requestAnimationFrame(poll);
    const dt = Math.min(0.05, (now - last) / 1000); last = now;
    const pads = navigator.getGamepads ? navigator.getGamepads() : []; let gp = null;
    for (const p of pads) if (p && p.connected && p.buttons.length >= 10) { gp = p; break; }
    if (!gp) return;
    const b = i => !!(gp.buttons[i] && gp.buttons[i].pressed), edge = i => b(i) && !prev[i];
    const any = gp.buttons.some(x => x.pressed) || gp.axes.some(a => Math.abs(a) > 0.4);
    if (any) document.body.classList.add('pad');
    if (!H.locked) {
      if (edge(0) || edge(9)) { if (!$('start').hidden && !$('go').hidden && !document.body.classList.contains('modal')) { H.soft = true; H.start(true); } }
      prev = gp.buttons.map(x => x.pressed); return;
    }
    const lx = dz(gp.axes[0] || 0), ly = dz(gp.axes[1] || 0), rx = dz(gp.axes[2] || 0), ry = dz(gp.axes[3] || 0), m = Math.hypot(lx, ly);
    key('KeyW', ly < -0.3); key('KeyS', ly > 0.3); key('KeyA', lx < -0.3); key('KeyD', lx > 0.3);
    if (edge(10)) sprint = !sprint; if (m < 0.2) sprint = false;
    key('ShiftLeft', sprint || (m > 0.93 && ly < -0.3));
    key('Space', b(0));
    if (edge(1)) { crouch = !crouch; } key('KeyC', crouch);
    if (edge(2)) tap('KeyE'); if (edge(3)) tap('KeyF');
    if (edge(4)) tap('KeyI'); if (edge(5)) tap('KeyV'); if (edge(8)) tap('KeyM');
    if (edge(12)) tap('Digit1'); if (edge(15)) tap('Digit2'); if (edge(13)) tap('Digit3'); if (edge(14)) tap('KeyP');
    if (edge(9)) H.pause();
    key('KeyZ', (gp.buttons[6] && gp.buttons[6].value > 0.4));
    const fire = gp.buttons[7] && gp.buttons[7].value > 0.4, was = prev[7];
    if (fire && !was) mouse('mousedown'); else if (!fire && was) mouse('mouseup');
    const k = 1150 * dt; if (rx || ry) H.look(rx * Math.abs(rx) * k * 1.4, ry * Math.abs(ry) * k);
    if (H.map && edge(0)) mouse('mousedown');
    prev = gp.buttons.map(x => x.pressed); prev[7] = fire;
  }
  requestAnimationFrame(poll);
})();

/* ---------- settings panel ---------- */
const S = H.settings, panel = $('settings');
function bindRange(id, key, fmt) {
  const el = $(id), out = $(id + '-v'); el.value = S[key];
  const show = () => out.textContent = fmt(+el.value); show();
  el.oninput = () => { S[key] = +el.value; show(); H.saveSettings(); };
}
bindRange('s-sens', 'sens', v => v.toFixed(2) + 'x'); bindRange('s-fov', 'fov', v => Math.round(v) + '°'); bindRange('s-vol', 'vol', v => Math.round(v * 100) + '%');
$('s-inv').checked = S.invert; $('s-inv').onchange = e => { S.invert = e.target.checked; H.saveSettings(); };
$('s-mute').checked = S.mute; $('s-mute').onchange = e => { S.mute = e.target.checked; H.saveSettings(); };
$('open-settings').onclick = () => { panel.hidden = !panel.hidden; };
$('close-settings').onclick = () => { panel.hidden = true; };

/* ---------- journal ---------- */
const jr = $('journal');
function openJournal() {
  const j = H.journal(), esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const f = t => Math.floor(t / 60) + ':' + String(Math.floor(t % 60)).padStart(2, '0');
  const rg = j.relics.filter(r => r.got).length, sg = j.sites.filter(s => s.seen).length;
  $('j-body').innerHTML =
    `<div class="jstats"><span>Relics <b>${rg}/${j.relics.length}</b></span><span>Heritage sites <b>${sg}/${j.sites.length}</b></span><span>Run time <b>${f(j.time)}</b></span>${j.best ? `<span>Best <b>${f(j.best)}</b></span>` : ''}</div>` +
    `<h3>Relics</h3><ul class="jl">${j.relics.map(r => `<li class="${r.got ? 'ok' : ''}">${r.got ? '✔' : '○'} ${esc(r.name)}</li>`).join('')}</ul>` +
    `<h3>Heritage sites</h3><ul class="jl sites">${j.sites.map(s => `<li class="${s.seen ? 'ok' : ''}"><b>${s.seen ? '✔' : '○'} ${esc(s.name)}</b>${s.seen ? `<small>${esc(s.history)}</small>` : '<small>Not yet discovered.</small>'}</li>`).join('')}</ul>`;
  jr.hidden = false; document.body.classList.add('modal');
}
function closeJournal() { jr.hidden = true; document.body.classList.remove('modal'); }
$('open-journal').onclick = openJournal; $('close-journal').onclick = closeJournal;
addEventListener('keydown', e => {
  if (e.code === 'KeyJ' && !e.repeat) { if (!jr.hidden) closeJournal(); else { if (H.locked) H.pause(); setTimeout(openJournal, 60); } }
  else if (e.code === 'Escape' && !jr.hidden) closeJournal();
});

/* ---------- installable app ---------- */
let deferred = null; const inst = $('install');
addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; if (inst && !STANDALONE) inst.hidden = false; });
addEventListener('appinstalled', () => { if (inst) inst.hidden = true; deferred = null; });
if (inst) inst.onclick = async () => { if (!deferred) return; deferred.prompt(); try { await deferred.userChoice; } catch (e) {} deferred = null; inst.hidden = true; };
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
})();
