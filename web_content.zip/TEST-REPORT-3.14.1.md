# RISEUP 3.14.1 — Original Rank Artwork

- Source: RISEUP 3.14.0 dark-hunter-rank-emblems.
- Rank badges now use six individual raster assets cropped from the exact approved fantasy rank-board reference image supplied by the user.
- The app references the assets locally from `assets/ranks/` and precaches all six in the service-worker shell.
- Responsive layout updated for the player status card.
- Existing rank unlock levels remain E=3, D=6, C=9, B=12, A=15, S=18.
- Backup deletion and gameplay logic preserved.

## Automated tests
- `npm run test:static`: passed.
- `npm run test:pwa`: passed.
- `npm run test:gameplay`: passed.
- ZIP integrity: passed.

No physical Android device test was performed. The ZIP is source project only; it is not an APK.
