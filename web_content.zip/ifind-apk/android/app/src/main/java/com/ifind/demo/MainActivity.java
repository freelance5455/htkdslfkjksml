package com.ifind.demo;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
 @Override public void onCreate(android.os.Bundle savedInstanceState) { registerPlugin(IFindNativePlugin.class); super.onCreate(savedInstanceState); }
}
