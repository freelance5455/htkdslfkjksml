import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { registerPlugin } from '@capacitor/core';
window.L = L;
window.IFindNative = registerPlugin('IFindNative');
