const CACHE='ifind-shell-v1';
const SHELL=['./','./index.html'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
 const u=new URL(event.request.url);
 const isTile=/tile\.openstreetmap\.org|\/map-cotonou\//.test(u.href);
 const isStatic=u.origin===self.location.origin || /unpkg\.com\/leaflet/.test(u.href);
 if(!isTile&&!isStatic)return;
 event.respondWith(caches.match(event.request).then(hit=>{
   const network=fetch(event.request).then(response=>{if(response&& (response.ok||response.type==='opaque')){const copy=response.clone();caches.open(CACHE).then(c=>c.put(event.request,copy));}return response;}).catch(()=>hit);
   return hit||network;
 }));
});
