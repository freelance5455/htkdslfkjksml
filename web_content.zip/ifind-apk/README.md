# iFind — projet Android (APK)

Ce projet transforme le prototype HTML en application Android Capacitor. Il garde explicitement le caractère fictif de la démonstration : aucune connexion à Apple/iCloud, aucun suivi réel d'un téléphone et aucun identifiant/code saisi dans la démo n'est enregistré ni envoyé.

## Fonctionnalités natives préparées
- Notifications locales Android programmées par `AlarmManager` et affichées par `BroadcastReceiver`, même si l'écran WebView n'est plus ouvert.
- Demande de permission de notifications Android 13+ et permission d'alarmes exactes lorsque l'OS la demande. Si l'alarme exacte est refusée, repli sur une alarme tolérée par Android (moins précise).
- Service au premier plan pour poursuivre le déplacement **simulé** lorsque l'application est minimisée. Android peut néanmoins arrêter un service selon ses règles d'économie d'énergie.
- Carte Leaflet embarquée dans le paquet (donc disponible hors réseau), cache des tuiles déjà consultées et trajet simulé de secours hors réseau.

## Préparer et construire
Prérequis : Node.js 20+, Android Studio récent, Android SDK Platform 35, JDK 17.

```bash
npm install
npm run sync:android
```

Le dossier `android/` contient le projet natif et le plugin Kotlin/Java. Ouvrir le dossier `android/` dans Android Studio, laisser Gradle se synchroniser, puis **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Le wrapper Gradle peut être généré depuis Android Studio si nécessaire.

## Cartographie hors ligne
Le cache garde les tuiles déjà affichées (cache de navigateur) ; il ne garantit pas une couverture complète. Pour une vraie carte détaillée hors ligne, ajouter un pack de tuiles `.png` sous `www/map-cotonou/{z}/{x}/{y}.png`, obtenu auprès d'un fournisseur autorisant explicitement le téléchargement et la redistribution hors ligne. Ne pas aspirer les tuiles du serveur public OpenStreetMap : son serveur standard n'est pas un service de téléchargement hors ligne.

Le tracé routier OSRM est demandé en ligne. Sans réseau, l'application réutilise le dernier tracé sauvegardé ; si aucun tracé n'existe, elle dessine un trajet direct de démonstration entre le départ et la destination.

## Limites importantes
Aucune application ne peut promettre une notification « à tous les coups » : Android contrôle les alarmes exactes, les permissions, les modes économie d'énergie et les restrictions constructeur. L'alarme exacte est utilisée quand l'OS l'autorise, sinon un repli moins précis est utilisé. Pour une fiabilité de production, tester sur les appareils ciblés et expliquer à l'utilisateur les réglages de batterie/notifications.
