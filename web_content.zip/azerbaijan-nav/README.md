# Azərbaycan Naviqasiya — Sadə Veb Tətbiqi

## Xüsusiyyətlər
- Azərbaycanın **bütün ərazisini** göstərən dəqiq xəritə (OpenStreetMap)
- **Azərbaycan, Rus və İngilis** dillərində interfeys və səsləndirmə
- Yer axtarışı (şəhər, kənd, küçə, məkan)
- Marşrut çəkmə (OSRM)
- Çox sadə və təmiz interfeys
- Mobilə uyğun

## Necə işlədirəm?

1. `index.html` faylını brauzerdə açın (Chrome, Edge, Firefox, Safari)
2. Axtarış qutusuna yer yazın (məs: Bakı, Gəncə, Şəki, Qəbələ...)
3. Nəticədən yer seçin → "Ora get" düyməsinə basın
4. Sağ yuxarıda **AZ / RU / EN** düyməsi ilə dili dəyişin
5. 🔊 düyməsi ilə son təlimatı səsləndirin

## Qeyd
- İnternet lazımdır (xəritə və axtarış üçün)
- Səsləndirmə brauzerin öz TTS sistemindən istifadə edir
- Peşəkar naviqasiya (Google Maps, Yandex) deyil — sadə prototipdir
- Məkan icazəsi verin ki, sizin yerinizdən marşrut çəkilsin

Hazırlayan: Grok
