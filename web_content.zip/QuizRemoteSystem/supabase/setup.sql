-- هذا متوافق مع مشروع Supabase الحالي وجدول public.quizzes.
alter table public.quizzes add column if not exists public_url text;
alter table public.quizzes enable row level security;

drop policy if exists "public can read active quizzes" on public.quizzes;
drop policy if exists "public can read active quiz" on public.quizzes;
create policy "public can read active quiz" on public.quizzes for select to anon, authenticated using (is_active = true);
create policy "authenticated can read quizzes" on public.quizzes for select to authenticated using (true);
create policy "authenticated can insert quizzes" on public.quizzes for insert to authenticated with check (true);
create policy "authenticated can update quizzes" on public.quizzes for update to authenticated using (true) with check (true);
create policy "authenticated can delete quizzes" on public.quizzes for delete to authenticated using (true);

insert into storage.buckets (id,name,public) values ('quiz-files','quiz-files',true)
on conflict (id) do update set public=true;

drop policy if exists "admin upload quiz files" on storage.objects;
drop policy if exists "admin delete quiz files" on storage.objects;
drop policy if exists "authenticated can upload quiz files" on storage.objects;
drop policy if exists "authenticated can update quiz files" on storage.objects;
drop policy if exists "authenticated can delete quiz files" on storage.objects;
create policy "authenticated can upload quiz files" on storage.objects for insert to authenticated with check (bucket_id='quiz-files');
create policy "authenticated can update quiz files" on storage.objects for update to authenticated using (bucket_id='quiz-files') with check (bucket_id='quiz-files');
create policy "authenticated can delete quiz files" on storage.objects for delete to authenticated using (bucket_id='quiz-files');
