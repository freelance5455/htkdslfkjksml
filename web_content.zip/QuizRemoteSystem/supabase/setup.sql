-- 1) أنشئ Bucket باسم quiz-files واجعله Public من لوحة Supabase.
create table if not exists public.quiz_apps (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  file_path text not null,
  public_url text not null,
  active boolean not null default false,
  updated_at timestamptz not null default now()
);

alter table public.quiz_apps enable row level security;

-- قراءة الاختبار النشط مسموحة للتطبيقات.
create policy "public can read active quiz"
on public.quiz_apps for select to anon
using (active = true);

-- استبدل البريد التالي ببريد حسابك الإداري في Supabase Auth.
create policy "admin can read all"
on public.quiz_apps for select to authenticated
using ((auth.jwt()->>'email') = 'YOUR_ADMIN_EMAIL');

create policy "admin can insert"
on public.quiz_apps for insert to authenticated
with check ((auth.jwt()->>'email') = 'YOUR_ADMIN_EMAIL');

create policy "admin can update"
on public.quiz_apps for update to authenticated
using ((auth.jwt()->>'email') = 'YOUR_ADMIN_EMAIL')
with check ((auth.jwt()->>'email') = 'YOUR_ADMIN_EMAIL');

create policy "admin can delete"
on public.quiz_apps for delete to authenticated
using ((auth.jwt()->>'email') = 'YOUR_ADMIN_EMAIL');

-- Storage policies: يسمح للإداري برفع وحذف الملفات، والـpublic يقرأها عبر الرابط العام.
create policy "admin upload quiz files"
on storage.objects for insert to authenticated
with check (bucket_id = 'quiz-files' and (auth.jwt()->>'email') = 'YOUR_ADMIN_EMAIL');

create policy "admin delete quiz files"
on storage.objects for delete to authenticated
using (bucket_id = 'quiz-files' and (auth.jwt()->>'email') = 'YOUR_ADMIN_EMAIL');
