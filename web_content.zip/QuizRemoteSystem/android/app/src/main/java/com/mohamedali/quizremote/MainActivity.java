package com.mohamedali.quizremote;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String SUPABASE_URL = "https://mpfxxpistympeowljaow.supabase.co";
    private static final String SUPABASE_KEY = "sb_publishable_hUoYtYxG-waeDpQMx1LDRw_E8FBXLEB";
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient());
        loadActiveQuiz();
    }

    private void loadActiveQuiz() {
        Toast.makeText(this, "جاري تحميل آخر اختبار...", Toast.LENGTH_SHORT).show();
        executor.execute(() -> {
            HttpURLConnection c = null;
            try {
                URL u = new URL(SUPABASE_URL + "/rest/v1/quizzes?select=name,public_url&is_active=eq.true&limit=1");
                c = (HttpURLConnection) u.openConnection();
                c.setRequestMethod("GET");
                c.setConnectTimeout(10000);
                c.setReadTimeout(15000);
                c.setRequestProperty("apikey", SUPABASE_KEY);
                c.setRequestProperty("Authorization", "Bearer " + SUPABASE_KEY);
                int code = c.getResponseCode();
                InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                StringBuilder b = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(in))) {
                    String line; while ((line = r.readLine()) != null) b.append(line);
                }
                String json = b.toString();
                int key = json.indexOf("\"public_url\"");
                if (key < 0) throw new Exception("no-active");
                int colon = json.indexOf(':', key);
                int start = json.indexOf('"', colon + 1) + 1;
                int end = start;
                while (end < json.length()) {
                    if (json.charAt(end) == '"' && json.charAt(end - 1) != '\\') break;
                    end++;
                }
                if (start <= 0 || end <= start) throw new Exception("bad-url");
                String quizUrl = json.substring(start, end).replace("\\/", "/").replace("\\\"", "\"");
                main.post(() -> webView.loadUrl(quizUrl));
            } catch (Exception e) {
                main.post(() -> Toast.makeText(this, "تعذر تحميل الاختبار. تأكد من الإنترنت وأن هناك اختبارًا مفعّلًا.", Toast.LENGTH_LONG).show());
            } finally {
                if (c != null) c.disconnect();
            }
        });
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
