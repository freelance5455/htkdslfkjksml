نظام اختبارات HTML قابل للتحديث عن بُعد — النسخة المصححة

ما تم إصلاحه:
1) الـAPK لا يحتاج launcher مستضاف على Vercel؛ يتصل بـSupabase مباشرة.
2) تم توحيد اسم الجدول إلى public.quizzes.
3) Storage bucket باسم quiz-files للملفات HTML.
4) لوحة التحكم ترفع HTML وتضيفه وتفعّله وتحذفه.
5) كل APK مثبت يفتح الاختبار النشط الحالي عند تشغيله.

Supabase المستخدم:
https://mpfxxpistympeowljaow.supabase.co

طريقة التشغيل:
- أنشئ مستخدمًا في Supabase Authentication > Users ببريد وكلمة مرور تعرفهما.
- افتح web/admin.html بعد رفعه على استضافة HTTPS مثل Vercel.
- سجّل الدخول وارفع ملف HTML.
- اضغط تفعيل.
- ابنِ APK من android/ عبر AIDE.

مهم: لا تغيّر SUPABASE_KEY إلى service_role. المفتاح الموجود في التطبيق هو publishable/anon ومصمم للاستخدام من تطبيق العميل مع RLS.
