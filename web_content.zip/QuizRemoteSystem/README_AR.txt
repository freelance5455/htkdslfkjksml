نظام اختبار HTML قابل للتحديث عن بعد

المكونات:
1) android/ = مشروع Android WebView. التطبيق نفسه لا يحتوي على الاختبار.
2) web/launcher.html = صفحة ثابتة يفتحها الـAPK وتبحث عن الاختبار النشط.
3) web/admin.html = لوحة تحكم لرفع HTML وإضافة اختبارات وتفعيل/حذف اختبار.
4) supabase/setup.sql = الجداول وسياسات الحماية.
5) initial-quiz.html = ملف الاختبار الذي أرسلته كبداية.

الإعداد:
- أنشئ مشروع Supabase.
- أنشئ Storage Bucket باسم quiz-files واجعله Public.
- أنشئ مستخدم Admin في Authentication > Users.
- نفذ setup.sql بعد استبدال YOUR_ADMIN_EMAIL ببريد المدير.
- في launcher.html وadmin.html ضع SUPABASE_URL وSUPABASE_ANON_KEY.
- ارفع launcher.html وadmin.html على أي استضافة HTTPS (مثل Vercel/Netlify/GitHub Pages).
- ضع رابط launcher.html داخل MainActivity.java مكان YOUR-DOMAIN.example.
- افتح المشروع في AIDE وابنِ APK.

طريقة الاستخدام:
- ادخل لوحة admin.html.
- ارفع أي ملف .html.
- اضغط تفعيل للاختبار المطلوب.
- كل APK مثبت سيفتح الاختبار النشط الجديد عند التشغيل بدون إعادة بناء APK.
