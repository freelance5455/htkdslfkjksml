# XAU Trader Command Center

A standalone, editable React + Vite project for a browser-only XAU/USD trading simulator.

## Run it locally

Requires Node.js 20.19+ (or 22.12+) and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. To create a static production build:

```bash
npm run build
```

The built website is written to `dist/` and can be uploaded to a static web host.

## Important scope

- Quotes, indicators, fills, and trade results are generated in the browser.
- There is no live market-data feed, broker, MT5, or real-money order connection.
- Demo state and history reset when the page reloads.
- Simulated results are not evidence of profitability or future performance.