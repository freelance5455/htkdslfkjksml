import { useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, Ban, CandlestickChart, CircleHelp, Clock3, Crosshair, Pause, Play, ShieldCheck, ShieldAlert, SlidersHorizontal, X } from 'lucide-react';

type RiskSettings = { risk: number; loss: number; positions: number; spread: number; hourly: number; atr: number };
type Quote = { bid: number; ask: number; price: number; tick: number; time: string };
type Candle = { p: number; v: number };
type Position = { id: number; side: 'BUY' | 'SELL'; lots: number; entry: number; stop: number; target: number; opened: string };
type ClosedTrade = Position & { exit: number; profit: number; reason: string; closed: string };
type AuditEvent = { id: number; time: string; message: string; tone?: 'good' | 'bad' };
type Indicators = { e9: number; e21: number; atr: number; rsi: number; vwap: number; regime: string; signal: 'WAIT' | 'BUY' | 'SELL'; confidence: number };

const initialSettings: RiskSettings = { risk: .25, loss: 100, positions: 1, spread: .5, hourly: 6, atr: 1.8 };
const money = (n: number, digits = 2) => n.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
const timeNow = () => new Date().toLocaleTimeString('en-US', { hour12: false });
const ema = (values: number[], period: number) => {
  if (!values.length) return 0;
  const k = 2 / (period + 1);
  return values.slice(1).reduce((value, price) => price * k + value * (1 - k), values[0]);
};
const makeSeries = (): Candle[] => {
  let price = 2350;
  return Array.from({ length: 72 }, (_, i) => {
    price += Math.sin(i / 5) * .08 + (Math.random() - .48) * .19;
    return { p: price, v: 50 + Math.random() * 150 };
  });
};
function calculate(series: Candle[], price: number): Indicators {
  const values = series.map((entry) => entry.p);
  const n = values.length;
  const e9 = ema(values.slice(-80), 9);
  const e21 = ema(values.slice(-120), 21);
  const changes = values.slice(Math.max(1, n - 15)).map((value, i) => Math.abs(value - values[Math.max(0, n - 15) + i - 1]));
  const atr = changes.length ? changes.reduce((sum, value) => sum + value, 0) / changes.length * 1.6 : .25;
  let gains = 0;
  let losses = 0;
  for (let i = Math.max(1, n - 14); i < n; i += 1) {
    const delta = values[i] - values[i - 1];
    if (delta > 0) gains += delta;
    else losses -= delta;
  }
  const rsi = 100 - 100 / (1 + (losses === 0 ? 99 : gains / Math.max(losses, .0001)));
  const recent = series.slice(-50);
  const vwap = recent.reduce((sum, row) => sum + row.p * row.v, 0) / Math.max(1, recent.reduce((sum, row) => sum + row.v, 0));
  const regime = atr > 1.2 ? 'TOO VOLATILE' : atr < .1 ? 'TOO QUIET' : Math.abs(e9 - e21) > .16 ? 'TRENDING' : 'RANGING';
  let signal: Indicators['signal'] = 'WAIT';
  let confidence = 0;
  if (n > 25 && regime === 'TRENDING') {
    if (e9 > e21 && rsi >= 35 && rsi <= 48 && price > vwap) {
      signal = 'BUY';
      confidence = Math.min(92, 62 + Math.round((e9 - e21) * 30) + (48 - rsi));
    } else if (e9 < e21 && rsi >= 52 && rsi <= 65 && price < vwap) {
      signal = 'SELL';
      confidence = Math.min(92, 62 + Math.round((e21 - e9) * 30) + (rsi - 52));
    }
  }
  return { e9, e21, atr, rsi, vwap, regime, signal, confidence };
}

function PriceChart({ series, indicators, positions }: { series: Candle[]; indicators: Indicators; positions: Position[] }) {
  const recent = series.slice(-90);
  const prices = recent.map((point) => point.p);
  const min = Math.min(...prices, ...positions.map((position) => position.stop)) - .35;
  const max = Math.max(...prices, ...positions.map((position) => position.target)) + .35;
  const x = (i: number) => 18 + i / Math.max(1, recent.length - 1) * 710;
  const y = (value: number) => 192 - ((value - min) / Math.max(.01, max - min)) * 166;
  const points = prices.map((value, i) => `${x(i)},${y(value)}`).join(' ');
  const ema9 = recent.map((_, i) => ema(prices.slice(0, i + 1), 9)).map((value, i) => `${x(i)},${y(value)}`).join(' ');
  const ema21 = recent.map((_, i) => ema(prices.slice(0, i + 1), 21)).map((value, i) => `${x(i)},${y(value)}`).join(' ');
  return <svg className="chart-svg" viewBox="0 0 750 216" role="img" aria-label="Simulated XAU USD price chart with EMA and VWAP indicators" data-testid="chart-simulated">
    <defs><linearGradient id="areaFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#d8b75d" stopOpacity=".21" /><stop offset="1" stopColor="#d8b75d" stopOpacity="0" /></linearGradient></defs>
    {[26, 68, 109, 150, 192].map((line) => <line key={line} className="chart-grid" x1="18" x2="728" y1={line} y2={line} />)}
    <polygon className="chart-area" points={`18,192 ${points} 728,192`} />
    <polyline className="chart-ma" points={ema21} />
    <polyline className="chart-ma chart-ma-fast" points={ema9} />
    <line x1="18" x2="728" y1={y(indicators.vwap)} y2={y(indicators.vwap)} className="chart-vwap" />
    {positions.map((position) => <g key={position.id}><line className="chart-trade-stop" x1="18" x2="728" y1={y(position.stop)} y2={y(position.stop)} /><line className="chart-trade-target" x1="18" x2="728" y1={y(position.target)} y2={y(position.target)} /></g>)}
    <polyline className="chart-line" points={points} />
    <text className="chart-label" x="20" y="15">{money(max)}</text>
    <text className="chart-label" x="20" y="211">{money(min)}</text>
    <text className="chart-label" x="648" y="211">SIM • 1 SEC</text>
  </svg>;
}

function Metric({ label, value, detail, testId, valueClass = '' }: { label: string; value: string; detail: string; testId: string; valueClass?: string }) {
  return <section className="metric" aria-label={label}><div className="metric-label">{label}</div><div className={`metric-value ${valueClass}`} data-testid={testId}>{value}</div><div className="metric-foot">{detail}</div></section>;
}

function App() {
  const [series, setSeries] = useState<Candle[]>(makeSeries);
  const [quote, setQuote] = useState<Quote>(() => ({ bid: 2349.88, ask: 2350.12, price: 2350, tick: 0, time: timeNow() }));
  const [settings, setSettings] = useState<RiskSettings>(initialSettings);
  const [draft, setDraft] = useState<RiskSettings>(initialSettings);
  const [positions, setPositions] = useState<Position[]>([]);
  const [history, setHistory] = useState<ClosedTrade[]>([]);
  const [audit, setAudit] = useState<AuditEvent[]>([{ id: 1, time: timeNow(), message: 'Demo engine initialized • simulated price feed only' }]);
  const [paused, setPaused] = useState(true);
  const [killed, setKilled] = useState(false);
  const [activeTab, setActiveTab] = useState<'open' | 'history'>('open');
  const [settingError, setSettingError] = useState('');
  const [clock, setClock] = useState(timeNow());
  const [tradesHour, setTradesHour] = useState<number[]>([]);
  const [dailyPnl, setDailyPnl] = useState(0);
  const [peakEquity, setPeakEquity] = useState(10000);
  const [maxDrawdown, setMaxDrawdown] = useState(0);
  const [lastTradeTick, setLastTradeTick] = useState(-999);
  const indicators = useMemo(() => calculate(series, quote.price), [series, quote.price]);
  const floating = positions.reduce((sum, p) => sum + (p.side === 'BUY' ? quote.bid - p.entry : p.entry - quote.ask) * 100 * p.lots, 0);
  const currentPnl = dailyPnl + floating;
  const equity = 10000 + currentPnl;
  const lossUsed = Math.max(0, -currentPnl);
  const exposure = positions.reduce((sum, p) => sum + p.entry * 100 * p.lots, 0);
  const winTrades = history.filter((trade) => trade.profit > 0);
  const lossTrades = history.filter((trade) => trade.profit < 0);
  const grossWins = winTrades.reduce((sum, trade) => sum + trade.profit, 0);
  const grossLoss = Math.abs(lossTrades.reduce((sum, trade) => sum + trade.profit, 0));
  const now = Date.now();

  function addAudit(message: string, tone?: 'good' | 'bad') {
    setAudit((events) => [{ id: Date.now() + Math.random(), time: timeNow(), message, tone }, ...events].slice(0, 45));
  }
  function closePosition(position: Position, exit: number, reason: string) {
    const profit = (position.side === 'BUY' ? exit - position.entry : position.entry - exit) * 100 * position.lots;
    setPositions((items) => items.filter((item) => item.id !== position.id));
    setHistory((items) => [{ ...position, exit, profit, reason, closed: timeNow() }, ...items]);
    setDailyPnl((value) => value + profit);
    addAudit(`${position.side} closed at $${money(exit)} • ${profit >= 0 ? '+' : ''}$${money(profit)} (${reason})`, profit >= 0 ? 'good' : 'bad');
  }
  function openPosition(side: 'BUY' | 'SELL', current: Indicators, bid: number, ask: number) {
    const stopDistance = Math.max(.25, current.atr * settings.atr);
    const riskCash = equity * settings.risk / 100;
    const lots = Math.floor(Math.max(.01, Math.min(.1, riskCash / (stopDistance * 100))) * 100) / 100;
    const entry = side === 'BUY' ? ask : bid;
    const stop = side === 'BUY' ? entry - stopDistance : entry + stopDistance;
    const target = side === 'BUY' ? entry + stopDistance * 1.5 : entry - stopDistance * 1.5;
    setPositions((items) => [...items, { id: Date.now(), side, lots, entry, stop, target, opened: timeNow() }]);
    setTradesHour((items) => [...items, Date.now()]);
    setLastTradeTick(quote.tick);
    addAudit(`${side} opened at $${money(entry)} • ${lots.toFixed(2)} lots`, 'good');
  }
  useEffect(() => {
    const interval = window.setInterval(() => {
      setClock(timeNow());
      const price = Math.max(2200, quote.price + Math.sin(quote.tick / 23) * .025 + (Math.random() - .49) * .34);
      const bid = price - .12;
      const ask = price + .12;
      const tick = quote.tick + 1;
      const nextSeries = [...series, { p: price, v: 50 + Math.random() * 150 }].slice(-220);
      const current = calculate(nextSeries, price);
      const existing = [...positions];
      const justClosed = new Set<number>();
      existing.forEach((position) => {
        if (position.side === 'BUY' && bid <= position.stop) { closePosition(position, position.stop, 'Stop loss'); justClosed.add(position.id); }
        else if (position.side === 'SELL' && ask >= position.stop) { closePosition(position, position.stop, 'Stop loss'); justClosed.add(position.id); }
        else if (position.side === 'BUY' && bid >= position.target) { closePosition(position, position.target, 'Take profit'); justClosed.add(position.id); }
        else if (position.side === 'SELL' && ask <= position.target) { closePosition(position, position.target, 'Take profit'); justClosed.add(position.id); }
      });
      const recentTrades = tradesHour.filter((at) => Date.now() - at < 3600000);
      if (recentTrades.length !== tradesHour.length) setTradesHour(recentTrades);
      const remaining = existing.filter((position) => !justClosed.has(position.id));
      if (!paused && !killed) {
        const runningPnl = dailyPnl + remaining.reduce((sum, p) => sum + (p.side === 'BUY' ? bid - p.entry : p.entry - ask) * 100 * p.lots, 0);
        const blocked = killed || Math.max(0, -runningPnl) >= settings.loss || remaining.length >= settings.positions ||
          ask - bid > settings.spread || recentTrades.length >= settings.hourly || tick < 2 ||
          current.regime !== 'TRENDING' || current.atr > .9 || current.atr < .1;
        if (Math.max(0, -runningPnl) >= settings.loss) {
          remaining.forEach((position) => closePosition(position, position.side === 'BUY' ? bid : ask, 'Daily loss protection'));
          setPaused(true);
          addAudit('Daily loss limit reached — bot paused', 'bad');
        } else if (!blocked && current.signal !== 'WAIT' && current.confidence >= 68 && tick - lastTradeTick > 12 && remaining.length < settings.positions) {
          openPosition(current.signal, current, bid, ask);
        }
      }
      const currentEquity = 10000 + dailyPnl + remaining.reduce((sum, p) => sum + (p.side === 'BUY' ? bid - p.entry : p.entry - ask) * 100 * p.lots, 0);
      const nextPeak = Math.max(peakEquity, currentEquity);
      setPeakEquity(nextPeak);
      setMaxDrawdown((drawdown) => Math.max(drawdown, (nextPeak - currentEquity) / nextPeak * 100));
      setQuote({ bid, ask, price, tick, time: timeNow() });
      setSeries(nextSeries);
    }, 1000);
    return () => window.clearInterval(interval);
  }, [series, positions, tradesHour, paused, killed, settings, dailyPnl, quote, peakEquity, lastTradeTick]);

  function saveSettings() {
    const next = draft;
    if (Object.values(next).some((value) => !Number.isFinite(value) || value <= 0) || next.risk > 1 || next.positions > 3 || !Number.isInteger(next.positions) || next.hourly > 20 || !Number.isInteger(next.hourly) || next.atr > 4 || next.spread < .1 || next.loss < 10) {
      setSettingError('Values are outside allowed limits. Risk ≤ 1%, positions 1–3, hourly cap ≤ 20, ATR ≤ 4.');
      addAudit('Settings rejected: values outside allowed bounds', 'bad');
      return;
    }
    setSettings(next);
    setSettingError('');
    addAudit('Risk and strategy settings updated', 'good');
  }
  function closeAll() {
    if (!positions.length) { addAudit('Close-all command executed • no open positions'); return; }
    positions.forEach((position) => closePosition(position, position.side === 'BUY' ? quote.bid : quote.ask, 'Manual close all'));
    addAudit('Close-all command executed');
  }
  function activateKill() {
    setKilled(true);
    setPaused(true);
    positions.forEach((position) => closePosition(position, position.side === 'BUY' ? quote.bid : quote.ask, 'Emergency kill'));
    addAudit('EMERGENCY KILL SWITCH ACTIVATED', 'bad');
  }
  const riskPercent = Math.min(100, lossUsed / settings.loss * 100);
  const formattedPnl = `${currentPnl >= 0 ? '+' : '−'}$${money(Math.abs(currentPnl))}`;

  return <main className="shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark" aria-hidden="true">XAU</div><div><div className="brand-name">XAU / COMMAND</div><span className="brand-sub">Strategy observation desk</span></div></div>
      <div className="top-actions"><span className="connection-note">Browser-only model · No broker connection</span><span className="sim-badge" data-testid="status-simulated">Simulated feed</span><span className="status-chip" data-testid="status-demo">Demo only</span></div>
    </header>
    <section className="headline">
      <div><div className="eyebrow">Instrument · XAU / USD · Pullback v1</div><h1>Command center</h1><p className="subtitle">A controlled sandbox for testing gold strategy behavior.</p></div>
      <div className="clock"><strong data-testid="text-clock">{clock}</strong>SESSION CLOCK · LOCAL</div>
    </section>
    <div className="disclaimer" role="note" data-testid="notice-simulation"><span className="disclaimer-mark">!</span><span><strong>DEMO SIMULATION ONLY.</strong> Prices, fills, performance and risk metrics are generated in this browser and reset when you reload. No broker or MT5 connection exists. Simulated results do not represent validated profitability or evidence of future performance.</span></div>

    <section className="metrics" aria-label="Market and account snapshot">
      <Metric label="XAU/USD bid" value={money(quote.bid)} detail={`Tick #${quote.tick} · ${quote.time}`} testId="data-bid" />
      <Metric label="Ask" value={money(quote.ask)} detail="Simulated quote" testId="data-ask" />
      <Metric label="Spread" value={money(quote.ask - quote.bid)} detail="USD per ounce" testId="data-spread" />
      <Metric label="Daily P&L" value={formattedPnl} detail="Closed + floating" testId="data-daily-pnl" valueClass={currentPnl >= 0 ? 'positive' : 'negative'} />
      <Metric label="Open positions" value={String(positions.length)} detail={`Exposure · $${money(exposure, 0)}`} testId="data-open-count" />
      <Metric label="Account equity" value={`$${money(equity)}`} detail="Demo starting balance · $10,000" testId="data-equity" />
    </section>

    <div className="workspace">
      <div>
        <section className="panel chart-panel">
          <div className="panel-head"><div><div className="panel-title">XAU/USD · PRICE & INDICATORS</div><div className="panel-kicker">Generated locally · rolling simulated ticks</div></div><div className="quote"><div className="quote-price" data-testid="chart-current-price">{money(quote.price)}</div><div className="quote-change"><Activity size={12} /> SIM</div></div></div>
          <div className="chart-wrap"><PriceChart series={series} indicators={indicators} positions={positions} /></div>
          <div className="chart-foot"><span>EMA 9 <b>{money(indicators.e9)}</b>　EMA 21 <b>{money(indicators.e21)}</b></span><span>VWAP <b>{money(indicators.vwap)}</b></span></div>
          <div className="indicator-row">
            <div className="indicator"><div className="indicator-label">RSI · 14</div><div className="indicator-value" data-testid="data-rsi">{money(indicators.rsi, 1)}</div><div className="indicator-state">{indicators.rsi < 35 ? 'Oversold' : indicators.rsi > 65 ? 'Overbought' : 'Neutral band'}</div></div>
            <div className="indicator"><div className="indicator-label">ATR · 14</div><div className="indicator-value" data-testid="data-atr">{money(indicators.atr, 3)}</div><div className="indicator-state">Volatility filter</div></div>
            <div className="indicator"><div className="indicator-label">EMA trend</div><div className="indicator-value" data-testid="data-ema-trend">{indicators.e9 > indicators.e21 ? 'BULLISH' : indicators.e9 < indicators.e21 ? 'BEARISH' : 'FLAT'}</div><div className="indicator-state">9 / 21 alignment</div></div>
            <div className="indicator"><div className="indicator-label">VWAP filter</div><div className="indicator-value" data-testid="data-vwap-filter">{quote.price > indicators.vwap ? 'ABOVE' : 'BELOW'}</div><div className="indicator-state">Price confirmation</div></div>
          </div>
          <div className="signal-row"><div><div className="signal-label">Current strategy signal</div><div className="signal-text" data-testid="data-signal">{indicators.signal} <span>· {indicators.regime}</span></div></div><div className="signal-score" data-testid="data-confidence">{indicators.confidence ? `${indicators.confidence}%` : '—'}</div></div>
        </section>

        <section className="panel controls-panel">
          <div className="panel-head"><div><div className="panel-title">SIMULATION CONTROLS</div><div className="panel-kicker">No orders leave this browser</div></div><span className="status-chip" data-testid="status-bot">{killed ? 'Killed' : paused ? 'Paused' : 'Running'}</span></div>
          <div className="control-actions">
            <button className="btn btn-primary" data-testid="button-start" disabled={killed || !paused} onClick={() => { setPaused(false); addAudit('Bot started • demo strategy active', 'good'); }}><Play size={13} />Start bot</button>
            <button className="btn" data-testid="button-pause" disabled={paused || killed} onClick={() => { setPaused(true); addAudit('Bot paused • existing simulated positions remain open'); }}><Pause size={13} />Pause</button>
            <button className="btn" data-testid="button-close-all" onClick={closeAll}><X size={13} />Close all</button>
            <button className="btn btn-kill" data-testid="button-kill-switch" disabled={killed} onClick={activateKill}><Ban size={13} />Kill switch</button>
          </div>
          <div className="risk-note">{killed ? 'Kill switch latched. Reload the page to reset this demo session.' : 'Pause stops new entries only. Close all exits simulated positions at the current quote.'}</div>
        </section>

        <div className="below-grid">
          <section className="panel">
            <div className="panel-head"><div><div className="panel-title">POSITIONS & TRADE HISTORY</div><div className="panel-kicker">{history.length} completed · {positions.length} open</div></div></div>
            <div className="tabs" role="tablist" aria-label="Position and trade history views">
              <button role="tab" aria-selected={activeTab === 'open'} className={`tab ${activeTab === 'open' ? 'active' : ''}`} data-testid="tab-open-positions" onClick={() => setActiveTab('open')}>Open positions <span>{positions.length}</span></button>
              <button role="tab" aria-selected={activeTab === 'history'} className={`tab ${activeTab === 'history' ? 'active' : ''}`} data-testid="tab-trade-history" onClick={() => setActiveTab('history')}>Trade history <span>{history.length}</span></button>
            </div>
            {activeTab === 'open' ? <div className="table-wrap"><table><thead><tr><th>Ticket</th><th>Side</th><th>Lots</th><th>Entry</th><th>Stop</th><th>Target</th><th>Floating P&L</th></tr></thead><tbody data-testid="table-open-positions">{positions.length ? positions.map((p) => { const value = (p.side === 'BUY' ? quote.bid - p.entry : p.entry - quote.ask) * 100 * p.lots; return <tr key={p.id} data-testid={`row-position-${p.id}`}><td className="mono">{String(p.id).slice(-6)}</td><td><span className={`direction ${p.side.toLowerCase()}`}>{p.side}</span></td><td className="mono">{p.lots.toFixed(2)}</td><td className="mono">{money(p.entry)}</td><td className="mono">{money(p.stop)}</td><td className="mono">{money(p.target)}</td><td className={`mono ${value >= 0 ? 'pnl-pos' : 'pnl-neg'}`}>{value >= 0 ? '+' : '−'}${money(Math.abs(value))}</td></tr>; }) : <tr><td colSpan={7}><div className="table-empty">No simulated positions open</div></td></tr>}</tbody></table></div>
              : <div className="table-wrap"><table><thead><tr><th>Closed</th><th>Side</th><th>Lots</th><th>Entry</th><th>Exit</th><th>Reason</th><th>P&L</th></tr></thead><tbody data-testid="table-trade-history">{history.length ? history.slice(0, 40).map((trade) => <tr key={trade.id} data-testid={`row-trade-${trade.id}`}><td className="mono">{trade.closed}</td><td><span className={`direction ${trade.side.toLowerCase()}`}>{trade.side}</span></td><td className="mono">{trade.lots.toFixed(2)}</td><td className="mono">{money(trade.entry)}</td><td className="mono">{money(trade.exit)}</td><td>{trade.reason}</td><td className={`mono ${trade.profit >= 0 ? 'pnl-pos' : 'pnl-neg'}`}>{trade.profit >= 0 ? '+' : '−'}${money(Math.abs(trade.profit))}</td></tr>) : <tr><td colSpan={7}><div className="table-empty">Closed trades appear here when a demo position exits</div></td></tr>}</tbody></table></div>}
          </section>

          <div className="side-stack">
            <section className="panel">
              <div className="panel-head"><div><div className="panel-title">RISK GATEWAY</div><div className="panel-kicker">Pre-entry guardrails</div></div><span className={`status-chip ${killed || lossUsed >= settings.loss ? 'status-alert' : ''}`} data-testid="status-risk">{killed ? 'Killed' : lossUsed >= settings.loss ? 'Limit hit' : 'Protected'}</span></div>
              <div className="risk-summary">
                <div className="risk-big"><strong data-testid="data-loss-used">${money(lossUsed)} <span>/ $${money(settings.loss)}</span></strong><span>DAILY LOSS USED</span></div>
                <div className="progress" aria-label={`Daily loss limit ${riskPercent.toFixed(0)} percent used`}><span style={{ width: `${riskPercent}%` }} /></div>
                <div className="risk-caption"><span>$0.00 used</span><span>{riskPercent.toFixed(0)}% limit</span></div>
                <div className="risk-grid">
                  <div className="risk-cell"><label>Trades this hour</label><b data-testid="data-hourly-count">{tradesHour.filter((t) => now - t < 3600000).length} / {settings.hourly}</b></div>
                  <div className="risk-cell"><label>Max positions</label><b data-testid="data-position-limit">{settings.positions}</b></div>
                  <div className="risk-cell"><label>Risk per trade</label><b data-testid="data-risk-percent">{settings.risk}%</b></div>
                  <div className="risk-cell"><label>Spread ceiling</label><b>${money(settings.spread)}</b></div>
                </div>
              </div>
              <div className="signal-list">
                <div className="signal-item"><div className="signal-left"><span className={`signal-led ${quote.ask - quote.bid > settings.spread ? 'warn' : ''}`} /><span className="signal-name">Spread filter</span></div><span className={`signal-status ${quote.ask - quote.bid > settings.spread ? 'warn' : ''}`}>{quote.ask - quote.bid > settings.spread ? 'Blocked' : 'Clear'}</span></div>
                <div className="signal-item"><div className="signal-left"><span className={`signal-led ${indicators.regime !== 'TRENDING' ? 'warn' : ''}`} /><span className="signal-name">Trend / volatility</span></div><span className={`signal-status ${indicators.regime !== 'TRENDING' ? 'warn' : ''}`}>{indicators.regime === 'TRENDING' ? 'Aligned' : 'Filtered'}</span></div>
              </div>
              <div className="risk-note">Checks: kill state, daily loss, position count, spread, hourly cap, fresh quotes and ATR stop distance.</div>
            </section>
            <section className="panel">
              <div className="panel-head"><div><div className="panel-title">SESSION PERFORMANCE</div><div className="panel-kicker">Simulated results only</div></div><Crosshair size={15} color="#a18c55" /></div>
              <div className="risk-summary"><div className="risk-grid performance-grid">
                <div className="risk-cell"><label>Closed trades</label><b data-testid="data-closed-count">{history.length}</b></div>
                <div className="risk-cell"><label>Win rate</label><b data-testid="data-win-rate">{history.length ? `${(winTrades.length / history.length * 100).toFixed(1)}%` : '—'}</b></div>
                <div className="risk-cell"><label>Profit factor</label><b data-testid="data-profit-factor">{history.length ? grossLoss ? money(grossWins / grossLoss) : '∞' : '—'}</b></div>
                <div className="risk-cell"><label>Max drawdown</label><b data-testid="data-drawdown">{maxDrawdown.toFixed(2)}%</b></div>
              </div></div>
            </section>
            <section className="panel">
              <div className="panel-head"><div><div className="panel-title"><SlidersHorizontal size={12} /> RISK SETTINGS</div><div className="panel-kicker">Updates apply to subsequent demo entries</div></div><ShieldCheck size={15} color="#54816a" /></div>
              <div className="settings">
                {([
                  ['risk', 'Risk per trade', 'Percent of demo equity', '%'],
                  ['loss', 'Daily loss limit', 'Stop threshold', '$'],
                  ['positions', 'Max open positions', 'Concurrent demo trades', ''],
                  ['spread', 'Max spread', 'USD per ounce', '$'],
                  ['hourly', 'Max trades / hour', 'Rolling 60-minute cap', ''],
                  ['atr', 'ATR stop multiplier', 'Target remains 1.5R', '×'],
                ] as const).map(([key, label, description, suffix]) => <div className="setting" key={key}><label htmlFor={`setting-${key}`}>{label}<small>{description}</small></label><div className="setting-input"><input id={`setting-${key}`} aria-label={label} data-testid={`input-setting-${key}`} type="number" step={key === 'risk' || key === 'spread' ? '.05' : key === 'atr' ? '.1' : '1'} min={key === 'risk' ? '.05' : key === 'loss' ? '10' : key === 'spread' ? '.1' : '1'} max={key === 'risk' ? '1' : key === 'positions' ? '3' : key === 'hourly' ? '20' : key === 'atr' ? '4' : undefined} value={draft[key]} onChange={(event) => setDraft((current) => ({ ...current, [key]: Number(event.target.value) }))} /><span>{suffix}</span></div></div>)}
              </div>
              {settingError && <div className="setting-error" role="alert" data-testid="error-settings"><AlertTriangle size={12} />{settingError}</div>}
              <div className="save-row"><button className="btn btn-primary" data-testid="button-save-settings" onClick={saveSettings}>Save settings</button></div>
            </section>
            <section className="panel">
              <div className="panel-head"><div><div className="panel-title">STRATEGY ENGINE</div><div className="panel-kicker">Pullback v1 · EMA / RSI / VWAP</div></div><span className="status-chip">Demo</span></div>
              <div className="strategy-copy">Entry requires EMA 9/21 trend alignment, RSI pullback (BUY 35–48 / SELL 52–65), price confirmation against VWAP and acceptable ATR volatility. Stops use the configured ATR multiple; target is 1.5R.</div>
              <div className="engine-state"><span>BOT STATE</span><strong data-testid="data-engine-state" className={killed ? 'state-killed' : paused ? '' : 'state-running'}>{killed ? 'KILLED' : paused ? 'PAUSED' : 'RUNNING'}</strong></div>
            </section>
            <section className="panel">
              <div className="panel-head"><div><div className="panel-title">AUDIT LOG</div><div className="panel-kicker">Latest session events · local only</div></div><Clock3 size={15} color="#829087" /></div>
              <div className="audit-list" aria-live="polite" data-testid="list-audit-events">{audit.map((event) => <div className="audit-item" key={event.id} data-testid={`event-audit-${event.id}`}><span className={`audit-dot ${event.tone ?? ''}`} /><div className="audit-copy">{event.message}<div className="audit-time">{event.time} · LOCAL</div></div></div>)}</div>
            </section>
          </div>
        </div>
      </div>
    </div>
    <footer className="footer"><span><strong>XAU TRADER / COMMAND CENTER</strong> · Browser simulation</span><span>No broker connectivity · No external price feed · Not validated profitability</span></footer>
  </main>;
}

export default App;