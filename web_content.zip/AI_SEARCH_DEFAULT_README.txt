AI SEARCH DEFAULT

The AI / search backend preference now defaults to OpenAI, and Reset Settings restores OpenAI as the selection. The existing AI API provider is also OpenAI by default with endpoint https://api.openai.com/v1 and model gpt-4.1-mini.

This is a UI/default configuration change only. It does not add an API key or implement a live search-grounding backend. Do not embed a secret API key in a public APK; production apps should call a secured backend.
