Jihad ♡ Raiba StudyMate — Android Studio Project

এই ZIP-এ Android Studio-তে খোলার মতো source project আছে। এটি এখনো compiled APK নয়।

APK বানানোর নিয়ম:
1) কম্পিউটারে Android Studio ইনস্টল করুন।
2) Android Studio থেকে Open নির্বাচন করে এই ফোল্ডারটি খুলুন।
3) Gradle sync শেষ হতে দিন (প্রথমবার ইন্টারনেট লাগবে)।
4) Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5) APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ তৈরি হবে।

ফিচার:
- Jihad ♡ Raiba / Only for you, Raiba / Made by Jihad dedication
- Offline WebView app
- To-do list, date/time, per-task 1–50 min duration
- 1–50 minute focus timer, pause/reset, four synthesized alarm tones
- local browser storage in app WebView

সীমাবদ্ধতা:
- এই source project-এ scheduled alarms are checked while the app's screen/web page is active; Android system alarm service/background alarm guarantee এখনো যোগ করা হয়নি।
- Task sync দুই ফোনের মধ্যে নেই।
- App build/sign করতে Android Studio/Android SDK প্রয়োজন।
