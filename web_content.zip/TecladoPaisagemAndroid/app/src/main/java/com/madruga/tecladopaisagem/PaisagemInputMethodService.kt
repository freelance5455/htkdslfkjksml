package com.madruga.tecladopaisagem

import android.content.Intent
import android.graphics.Color
import android.provider.Settings
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.inputmethod.InputConnection
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.inputmethodservice.InputMethodService

class PaisagemInputMethodService : InputMethodService() {
    private var webView: WebView? = null

    override fun onCreateInputView(): android.view.View {
        val w = WebView(this)
        webView = w
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            builtInZoomControls = false
            displayZoomControls = false
        }
        w.webViewClient = WebViewClient()
        w.webChromeClient = WebChromeClient()
        w.addJavascriptInterface(KeyboardBridge(), "AndroidKeyboard")
        w.loadUrl("file:///android_asset/keyboard.html")
        w.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        return w
    }

    private fun ic(): InputConnection? = currentInputConnection

    inner class KeyboardBridge {
        @JavascriptInterface fun commitText(text: String) { ic()?.commitText(text, 1) }
        @JavascriptInterface fun deleteOne() { ic()?.deleteSurroundingText(1, 0) }
        @JavascriptInterface fun enter() {
            ic()?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic()?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        @JavascriptInterface fun openImeSettings() {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    override fun onDestroy() {
        webView?.removeJavascriptInterface("AndroidKeyboard")
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
