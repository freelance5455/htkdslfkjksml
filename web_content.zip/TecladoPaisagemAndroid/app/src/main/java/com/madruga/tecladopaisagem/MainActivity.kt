package com.madruga.tecladopaisagem

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
        }
        box.addView(TextView(this).apply {
            text = "Teclado Paisagem"
            textSize = 28f
        })
        box.addView(TextView(this).apply {
            text = "Ative o teclado e depois selecione-o no campo de texto do celular.\n\nO teclado funciona como um IME real do Android: as teclas enviam texto diretamente para o aplicativo onde você estiver digitando."
            textSize = 17f
            setPadding(0, 24, 0, 24)
        })
        box.addView(Button(this).apply {
            text = "1. Ativar teclado"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        box.addView(Button(this).apply {
            text = "2. Selecionar teclado agora"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        setContentView(box)
    }
}
