# Teclado Paisagem — projeto Android nativo

Este projeto implementa um **InputMethodService (IME)** real. O arquivo `app/src/main/assets/keyboard.html` contém a interface do teclado e conversa com o serviço Android por uma ponte JavaScript.

## Como instalar
1. Abra a pasta `TecladoPaisagemAndroid` no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Execute `app` no celular/emulador ou gere um APK em **Build > Build APK(s)**.
4. No Android, abra **Configurações > Sistema > Teclado > Teclado na tela** (o nome pode variar).
5. Ative **Teclado Paisagem** e selecione-o como teclado atual.

## O que já funciona no IME
- Letras, espaço, backspace e Enter enviam texto ao aplicativo ativo.
- Teclas de símbolos/números e alternância ABC/?123.
- Interface HTML integrada ao teclado nativo.
- Botão de configurações abre as configurações de teclados do Android quando executado como IME.
- Preferências e wallpapers da interface usam armazenamento local do WebView.

## Observação
Recursos que dependem de serviços do sistema (por exemplo OCR/câmera, tradução online ou integração de clipboard do sistema) precisam de APIs Android adicionais e não são automaticamente equivalentes ao Gboard apenas por estarem no HTML.
