// ===== Matrix Rain Effect =====
function initMatrix() {
  const canvas = document.createElement('canvas');
  const container = document.getElementById('matrixRain');
  container.appendChild(canvas);
  const ctx = canvas.getContext('2d');

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const chars = '01アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲンABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const fontSize = 14;
  const columns = Math.floor(canvas.width / fontSize);
  const drops = Array(columns).fill(1);

  function draw() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#00f0ff';
    ctx.font = fontSize + 'px monospace';

    for (let i = 0; i < drops.length; i++) {
      const text = chars[Math.floor(Math.random() * chars.length)];
      ctx.fillText(text, i * fontSize, drops[i] * fontSize);
      if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
        drops[i] = 0;
      }
      drops[i]++;
    }
  }
  setInterval(draw, 50);
}

// ===== Terminal Typing Demo =====
const commands = [
  'python3 scanner.py --target demo.local',
  'sqlmap -u "http://demo.local/login" --dbs --batch',
  'hydra -l admin -P rockyou.txt ssh://127.0.0.1',
  'nikto -h http://demo.local',
  'gobuster dir -u http://demo.local -w wordlist.txt',
  'msfconsole -q -x "use exploit/multi/handler"',
  'hashcat -m 0 hashes.txt rockyou.txt',
  'wireshark -i eth0 -k',
  'clear && echo "Demo Mode Active - Safe Environment"'
];

let cmdIndex = 0;
const typingEl = document.getElementById('typingCmd');

function typeCommand() {
  const cmd = commands[cmdIndex % commands.length];
  let i = 0;
  typingEl.textContent = '';
  
  function type() {
    if (i < cmd.length) {
      typingEl.textContent += cmd[i];
      i++;
      setTimeout(type, 40 + Math.random() * 30);
    } else {
      setTimeout(() => {
        // Add output lines
        const terminal = document.getElementById('terminal');
        const outputs = [
          `[+] Module loaded successfully`,
          `[*] Scanning... 100% complete`,
          `[+] 0 vulnerabilities found (demo)`,
          `[*] Session closed safely`
        ];
        outputs.forEach((o, idx) => {
          setTimeout(() => {
            const line = document.createElement('div');
            line.className = 'terminal-line output';
            line.textContent = o;
            // Insert before the last typing line
            const last = terminal.lastElementChild;
            terminal.insertBefore(line, last);
            terminal.scrollTop = terminal.scrollHeight;
          }, idx * 400);
        });
        
        setTimeout(() => {
          cmdIndex++;
          typeCommand();
        }, 2800);
      }, 1200);
    }
  }
  type();
}

// ===== App Data =====
const apps = {
  imo: {
    name: 'imo',
    icon: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <defs><linearGradient id="imoG" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" style="stop-color:#4A90E2"/><stop offset="100%" style="stop-color:#2C58A2"/>
      </linearGradient></defs>
      <path d="M20 25 C20 15, 30 10, 50 10 C70 10, 80 15, 80 25 L80 55 C80 65, 70 70, 50 70 L35 70 L25 82 L28 70 C22 68, 20 60, 20 55 Z" fill="url(#imoG)"/>
      <text x="50" y="48" text-anchor="middle" fill="white" font-family="Arial" font-weight="bold" font-size="22">imo</text>
    </svg>`,
    actions: [
      { id: 'scan', label: 'FULL SCAN', desc: 'Device & Network Scan' },
      { id: 'null', label: 'NULL CHECK', desc: 'Null Pointer Analysis' },
      { id: 'hard', label: 'HARDEN', desc: 'Security Hardening' }
    ]
  },
  whatsapp: {
    name: 'WhatsApp',
    icon: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="45" fill="#25D366"/>
      <path d="M65 58c-1.2 3.4-6 6.2-9.8 6.8-2.6.4-6 .7-17.4-3.7-14.5-5.6-23.8-19.2-24.5-20.1-.7-.9-5.7-7.6-5.7-14.5s3.6-10.3 4.9-11.7c1.3-1.4 2.8-1.8 3.8-1.8h2.8c.9 0 2.1-.2 3.2 2.5 1.2 2.8 4 9.8 4.3 10.5.4.7.6 1.6.1 2.5-.5.9-1.1 1.5-1.8 2.3-.7.8-1.5 1.6-2.2 2.2-.7.6-1.4 1.3-.6 2.5.8 1.2 3.5 5.8 7.5 9.4 5.2 4.6 9.5 6 10.9 6.7 1.4.7 2.2.6 3-.3.8-.9 3.4-4 4.3-5.4.9-1.4 1.8-1.2 3-.7 1.2.5 7.6 3.6 8.9 4.2 1.3.7 2.2 1 2.5 1.5.4.6.4 3.3-1 6.7z" fill="white"/>
    </svg>`,
    actions: [
      { id: 'scan', label: 'FULL SCAN', desc: 'Chat Security Audit' },
      { id: 'null', label: 'NULL CHECK', desc: 'Message Integrity' },
      { id: 'hard', label: 'HARDEN', desc: 'End-to-End Check' }
    ]
  },
  telegram: {
    name: 'Telegram',
    icon: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="45" fill="#0088cc"/>
      <path d="M70 32L35 48.5c-2.4 1-2.4 2.3-.4 2.9l9 2.8 3.5 10.7c.4 1.2 1.2 1.4 2.1.4l5.5-5.3 11.4 8.4c2.1 1.2 3.6.6 4.1-1.9L75 36c.8-3.2-1.2-4.6-5-3.9z" fill="white"/>
    </svg>`,
    actions: [
      { id: 'scan', label: 'FULL SCAN', desc: 'Channel & Bot Scan' },
      { id: 'null', label: 'NULL CHECK', desc: 'API Null Safety' },
      { id: 'hard', label: 'HARDEN', desc: 'Secret Chat Verify' }
    ]
  },
  termux: {
    name: 'Termux',
    icon: `<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <rect x="12" y="18" width="76" height="64" rx="8" fill="#000" stroke="#00ff9d" stroke-width="3"/>
      <text x="28" y="55" fill="#00ff9d" font-family="monospace" font-size="22" font-weight="bold">$</text>
      <rect x="40" y="42" width="28" height="4" fill="#00ff9d"/>
    </svg>`,
    actions: [
      { id: 'scan', label: 'FULL SCAN', desc: 'System Package Scan' },
      { id: 'null', label: 'NULL CHECK', desc: 'Env Variable Check' },
      { id: 'hard', label: 'HARDEN', desc: 'Permission Lockdown' }
    ]
  }
};

// ===== Open / Close App =====
function openApp(appId) {
  const app = apps[appId];
  if (!app) return;

  // Entry animation
  const overlay = document.getElementById('entryOverlay');
  const entryText = document.getElementById('entryText');
  entryText.textContent = `ENTERING ${app.name.toUpperCase()}...`;
  overlay.classList.add('active');

  setTimeout(() => {
    overlay.classList.remove('active');
    
    // Setup modal
    document.getElementById('modalIcon').innerHTML = app.icon;
    document.getElementById('modalTitle').textContent = app.name;
    
    const body = document.getElementById('modalBody');
    body.innerHTML = `
      <div class="demo-header">
        <h3>⚡ DEMO ENVIRONMENT</h3>
        <p class="demo-status">Safe Mode • No real network actions</p>
      </div>
      <div class="action-buttons" id="actionBtns">
        ${app.actions.map(a => `
          <button class="action-btn" onclick="runDemo('${appId}', '${a.id}', this)">
            ${a.label}<br><small style="opacity:0.7;font-size:0.65rem">${a.desc}</small>
          </button>
        `).join('')}
      </div>
      <div class="progress-container" id="progressBox" style="display:none">
        <div class="progress-label">
          <span id="progressLabel">Initializing...</span>
          <span id="progressPercent">0%</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" id="progressFill"></div>
        </div>
      </div>
      <div class="demo-terminal" id="demoTerm" style="display:none"></div>
    `;
    
    document.getElementById('appModal').classList.add('active');
  }, 1400);
}

function closeApp() {
  document.getElementById('appModal').classList.remove('active');
}

// ===== Run Demo Actions =====
const demoScripts = {
  scan: {
    title: 'FULL SYSTEM SCAN',
    steps: [
      { p: 10, text: '[*] Loading scan modules...', type: 'info' },
      { p: 25, text: '[*] Enumerating network interfaces...', type: 'info' },
      { p: 40, text: '[+] Interface eth0 detected (demo)', type: 'success' },
      { p: 55, text: '[*] Port scanning 1-1024...', type: 'info' },
      { p: 70, text: '[+] 3 open ports found (simulated)', type: 'success' },
      { p: 85, text: '[*] Checking for known CVEs...', type: 'info' },
      { p: 95, text: '[+] No critical issues in demo mode', type: 'success' },
      { p: 100, text: '[✓] FULL SCAN COMPLETE — Safe environment', type: 'success' }
    ]
  },
  null: {
    title: 'NULL / NIL ANALYSIS',
    steps: [
      { p: 15, text: '[*] Starting null pointer analysis...', type: 'info' },
      { p: 30, text: '[*] Checking memory references...', type: 'info' },
      { p: 45, text: '[!] Potential null at offset 0x00 (demo)', type: 'warn' },
      { p: 60, text: '[*] Validating object graphs...', type: 'info' },
      { p: 75, text: '[+] All critical paths sanitized', type: 'success' },
      { p: 90, text: '[*] Generating safety report...', type: 'info' },
      { p: 100, text: '[✓] NULL CHECK PASSED — No real risk', type: 'success' }
    ]
  },
  hard: {
    title: 'SECURITY HARDENING',
    steps: [
      { p: 12, text: '[*] Applying security baselines...', type: 'info' },
      { p: 28, text: '[*] Disabling unnecessary services...', type: 'info' },
      { p: 45, text: '[+] Firewall rules updated (demo)', type: 'success' },
      { p: 60, text: '[*] Enforcing least privilege...', type: 'info' },
      { p: 78, text: '[+] Permissions locked down', type: 'success' },
      { p: 92, text: '[*] Verifying integrity checks...', type: 'info' },
      { p: 100, text: '[✓] HARDENING COMPLETE — Demo only', type: 'success' }
    ]
  }
};

function runDemo(appId, actionId, btn) {
  const script = demoScripts[actionId];
  if (!script) return;

  // Disable buttons
  document.querySelectorAll('.action-btn').forEach(b => b.disabled = true);
  
  const progressBox = document.getElementById('progressBox');
  const demoTerm = document.getElementById('demoTerm');
  const fill = document.getElementById('progressFill');
  const label = document.getElementById('progressLabel');
  const percent = document.getElementById('progressPercent');
  
  progressBox.style.display = 'block';
  demoTerm.style.display = 'block';
  demoTerm.innerHTML = `<div class="line info">[*] Starting ${script.title}...</div>`;
  
  let step = 0;
  
  function nextStep() {
    if (step >= script.steps.length) {
      // Re-enable after short delay
      setTimeout(() => {
        document.querySelectorAll('.action-btn').forEach(b => b.disabled = false);
      }, 800);
      return;
    }
    
    const s = script.steps[step];
    fill.style.width = s.p + '%';
    percent.textContent = s.p + '%';
    label.textContent = s.text.replace(/\[.*?\]\s*/, '');
    
    const line = document.createElement('div');
    line.className = `line ${s.type}`;
    line.textContent = s.text;
    demoTerm.appendChild(line);
    demoTerm.scrollTop = demoTerm.scrollHeight;
    
    step++;
    setTimeout(nextStep, 600 + Math.random() * 400);
  }
  
  nextStep();
}

// ===== Init =====
document.addEventListener('DOMContentLoaded', () => {
  initMatrix();
  setTimeout(typeCommand, 1500);
  
  // Close modal on overlay click
  document.getElementById('appModal').addEventListener('click', (e) => {
    if (e.target.id === 'appModal') closeApp();
  });
});
