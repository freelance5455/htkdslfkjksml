blure v0.8.0 COMPLETE UNIFIED SITE

This is ONE deployable htdocs package based on the cumulative v0.7.9 release, retaining features from v0.7.0-v0.7.9.

Upload the CONTENTS of this ZIP (not the ZIP itself) to the htdocs folder serving https://blure.gt.tc/ and replace existing files.

Open /ide.html online after uploading, allow the new service worker to activate, then test a refresh offline. PHP execution requires a connection; JavaScript runs locally.

Back up your current htdocs first. Older versions v0.7.8 and v0.7.9 are preserved in their original ZIPs separately.

Included: landing page, navigation, documentation, unified IDE, PHP playground, themes, SVG visual polish, automatic execution fallback, autocomplete, input diagnostics and offline service worker.

Local checks: ZIP CRC, JS syntax, PHP syntax (where PHP CLI available). Live host/browser testing still required.
