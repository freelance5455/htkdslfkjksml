if (typeof Runtime !== 'undefined') {
  const _exec = Runtime.prototype.exec;
  Runtime.prototype.exec = function(cmd) {
    if (typeof cmd === 'string' && (
      cmd.includes('vnp') ||
      cmd.includes('anticheat') ||
      cmd.includes('garena') ||
      cmd.includes('scan') ||
      cmd.includes('detect') ||
      cmd.includes('proc') ||
      cmd.includes('/data/data/com.garena')
    )) { console.log('Blocked VNP:', cmd); return null; }
    return _exec.call(this, cmd);
  };
}

if (typeof Shizuku !== 'undefined') {
  Shizuku.newProcess(['pm','disable','com.garena.game.kgvn.vnp'], null, null);
  Shizuku.newProcess(['pm','disable','com.garena.anticheat'], null, null);
  Shizuku.newProcess(['settings','put','global','garena_anticheat_enabled','0'], null, null);
}