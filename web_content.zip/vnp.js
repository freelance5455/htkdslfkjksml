function initVNP() {
  if (typeof Runtime !== 'undefined') {
    const _exec = Runtime.prototype.exec;
    Runtime.prototype.exec = function(cmd) {
      if (typeof cmd === 'string' && (
        cmd.includes('vnp') || cmd.includes('anticheat') || cmd.includes('bypass') ||
        cmd.includes('garena') || cmd.includes('scan') || cmd.includes('detect') ||
        cmd.includes('proc') || cmd.includes('dump') || cmd.includes('memory')
      )) return null;
      return _exec.call(this, cmd);
    };
  }
  if (typeof Shizuku !== 'undefined') {
    Shizuku.newProcess(['pm','disable','com.dts.freefireth.vnp'],null,null);
    Shizuku.newProcess(['pm','disable','com.dts.freefireth.anticheat'],null,null);
    Shizuku.newProcess(['pm','disable','com.garena.anticheat'],null,null);
    Shizuku.newProcess(['settings','put','global','garena_anticheat_enabled','0'],null,null);
    Shizuku.newProcess(['settings','put','global','vnp_enabled','0'],null,null);
  }
}
initVNP();