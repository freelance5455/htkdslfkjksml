# Cricket Scorer by JCL — PRISM realtime integration plan

## Target architecture
1. Android scorer app (Kotlin + Jetpack Compose, or a web app wrapped as Android during MVP).
2. Firebase Authentication for scorer sign-in.
3. Cloud Firestore `matches/{matchId}` document for current match state.
4. Firestore subcollections for innings, batters, bowlers and append-only scoring events.
5. Public HTTPS overlay at `https://YOUR_DOMAIN/overlay.html?match=PUBLIC_MATCH_ID`.
6. Overlay subscribes to the match document and renders the score as transparent/compact graphics.
7. PRISM Live Studio adds that HTTPS URL as a Web source (menu labels can vary by PRISM version).
8. YouTube receives the PRISM output as usual.

## One-phone reality check
The score controller and PRISM camera/broadcast need to coexist. On a single Android phone, app switching may interrupt the camera or background web source depending on device memory, Android restrictions, and PRISM version. Test before relying on it. Possible approaches:
- PRISM supports a browser/web source and keeps it running while scoring app is foregrounded: best if confirmed on the exact phone.
- Use Android split screen if PRISM and scorer both support it, while checking the camera preview and touch usability.
- Most reliable tournament workflow is a second phone/operator, even if the original requirement is one phone.
Do not assume an overlay page opened in Chrome automatically becomes an overlay inside PRISM.

## Suggested Firestore document shape
matches/{matchId}
{
  "title": "JCL T20 Match",
  "teams": [{"name":"Lions CC"},{"name":"Star CC"}],
  "inningsNo": 1,
  "status": "live",
  "current": {
    "battingTeamIndex": 0, "runs": 0, "wickets": 0,
    "legalBalls": 0, "target": null, "runRate": 0,
    "strikerId": "b1", "nonStrikerId": "b2", "bowlerId": "bw1",
    "extras": {"wides":0,"noBalls":0,"byes":0,"legByes":0,"penalty":0}
  },
  "updatedAt": "server timestamp"
}
matches/{matchId}/events/{eventId}
{
  "sequence": 1,
  "type": "RUNS | WICKET | WIDE | NO_BALL | BYE | LEG_BYE | PENALTY | UNDO",
  "payload": {},
  "createdAt": "server timestamp"
}

## Security requirements
- Only authenticated scorer/admin can write match data.
- Overlay is read-only and only gets access to the specific public match fields.
- Use a random public match token, not sequential IDs, if an unauthenticated public overlay is used.
- Do not expose service account credentials in the Android app or browser JavaScript.
- Configure Firestore rules and test them before going live.

## Scoring engine milestones before official use
- Use an event-based scoring model so every ball/extras/wicket can be undone exactly.
- Explicitly distinguish batter runs, byes/leg-byes, wides/no-balls, penalty runs and completed runs.
- Track striker/non-striker and rotate ends under the Laws of Cricket.
- Wicket type and which batter is dismissed; run-out can dismiss either batter.
- Track bowler figures, legal balls, over completion, maiden overs, wides/no-balls and wickets credited to bowler.
- Validate innings limits, all-out, target reached, tie, super over (if required), rain-shortened matches (optional).
- Unit test against hand-calculated example innings before tournament use.

## Deployment sequence
1. Create a Firebase project and register a Web app.
2. Enable Firestore and Authentication.
3. Host overlay and controller on Firebase Hosting or another HTTPS host.
4. Add the Firebase SDK and project config; create authenticated scorer UI and live listener.
5. Publish a test match and open its overlay URL in a desktop/mobile browser.
6. Add the HTTPS overlay as a Web source in PRISM; verify transparent background, readability and update latency.
7. Test YouTube unlisted stream, network drop/reconnect, phone heat/battery and app switching.
8. Package Android app, provide privacy policy, data-safety disclosures, screenshots and complete Google Play Console testing requirements.

This bundle does not yet contain production Firebase credentials or an active backend. No real-time connection is active until the project is configured and deployed.
