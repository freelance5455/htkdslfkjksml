Catering Granth - Android app (271 dishes, 270 photos, fully offline)

Build the APK:
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
   APK appears in app/build/outputs/apk/debug/

Features: search (multi-word) across dish, ingredients, equipment, code; category chips;
photo cards; full-detail sheet; "My Menu" favourites saved on device; share a dish or your whole menu.
