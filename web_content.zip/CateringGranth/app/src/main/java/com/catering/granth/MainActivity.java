package com.catering.granth;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
  private WebView web;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    FrameLayout root = new FrameLayout(this);
    web = new WebView(this);
    root.addView(web);
    setContentView(root);
    root.setOnApplyWindowInsetsListener((v, in) -> {
      v.setPadding(in.getSystemWindowInsetLeft(), in.getSystemWindowInsetTop(), in.getSystemWindowInsetRight(), in.getSystemWindowInsetBottom());
      return in;
    });
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    web.addJavascriptInterface(new Object() {
      @JavascriptInterface public void share(String t) {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t);
        startActivity(Intent.createChooser(i, "Share"));
      }
    }, "Android");
    web.setWebViewClient(new WebViewClient());
    web.loadUrl("file:///android_asset/www/index.html");
  }

  @Override public void onBackPressed() {
    web.evaluateJavascript("window.handleBack()", r -> { if (!"true".equals(r)) MainActivity.super.onBackPressed(); });
  }
}
