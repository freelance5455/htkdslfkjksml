const $=id=>document.getElementById(id);
const grid=$('grid'),q=$('q'),chips=$('chips'),stats=$('stats'),modal=$('modal'),sheet=$('sheet');
const CATS=[...new Set(DISHES.map(d=>d.category))];
let cat='',onlyFav=false,favs=new Set();
try{favs=new Set(JSON.parse(localStorage.getItem('favs')||'[]'))}catch(e){}
const save=()=>{try{localStorage.setItem('favs',JSON.stringify([...favs]))}catch(e){}$('favCount').textContent=favs.size};
const esc=s=>(s||'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));
const kind=c=>c.startsWith('Non')?'nv':c.startsWith('Veg')?'v':'ds';
const hay=DISHES.map(d=>[d.name,d.desc,d.items.join(' '),d.equipment,d.code,d.category].join(' ').toLowerCase());
function chipsRender(){chips.innerHTML=['',...CATS].map(c=>`<button class="chip ${c===cat?'on':''}" data-c="${esc(c)}">${c||'All'}</button>`).join('')}
chips.onclick=e=>{const b=e.target.closest('.chip');if(!b)return;cat=b.dataset.c;chipsRender();render()};
function list(arr,tag){return arr.length?`<ul>${arr.map(i=>`<li>${esc(i)}</li>`).join('')}</ul>`:'<div class="text">—</div>'}
function card(d,i,full){
 const img=d.image?`<img class="thumb" loading="lazy" src="${d.image}" ${full?'':`onclick="openDish(${i})"`} alt="">`:`<div class="noimg">No photo</div>`;
 const items=full?d.items:d.items.slice(0,4);
 return `${img}<div class="body"><div class="cat ${kind(d.category)}">${esc(d.category)} · ${esc(d.code)}</div>
 <div class="dish">${esc(d.name)}</div>${d.desc?`<div class="desc">${esc(d.desc)}</div>`:''}<div class="meta">${esc(d.date)}</div>
 <div class="label">Ingredients / Specifics</div>${list(items)}${!full&&d.items.length>4?`<div class="more">+${d.items.length-4} more</div>`:''}
 ${full?`<div class="label">Equipment / Method</div><div class="text">${esc(d.equipment)||'—'}</div>`:''}
 <div class="row"><button class="btn ghost ${favs.has(i)?'sel':''}" onclick="toggleFav(${i},event)">${favs.has(i)?'★ In menu':'☆ Add to menu'}</button>
 ${full?`<button class="btn" onclick="shareDish(${i})">Share</button>`:`<button class="btn" onclick="openDish(${i})">Details</button>`}</div></div>`}
function render(){
 const s=q.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
 const idx=DISHES.map((_,i)=>i).filter(i=>(!cat||DISHES[i].category===cat)&&(!onlyFav||favs.has(i))&&s.every(w=>hay[i].includes(w)));
 grid.innerHTML=idx.map(i=>`<article class="card">${card(DISHES[i],i,false)}</article>`).join('')||`<div class="empty">${onlyFav?'Your menu is empty. Tap “Add to menu” on any dish.':'No matching dishes found.'}</div>`;
 stats.innerHTML=`<span class="pill">Showing ${idx.length} of ${DISHES.length}</span>`+CATS.map(c=>`<span class="pill">${c}: ${DISHES.filter(d=>d.category===c).length}</span>`).join('')+(onlyFav&&favs.size?`<button class="pill act" onclick="shareMenu()">Share menu</button>`:'');
}
window.toggleFav=(i,e)=>{e&&e.stopPropagation();favs.has(i)?favs.delete(i):favs.add(i);save();
 if(modal.classList.contains('show'))openDish(i,true);render()};
function txt(d){return `${d.name} (${d.code})\n${d.desc?d.desc+'\n':''}\nIngredients:\n${d.items.map((x,n)=>`${n+1}. ${x}`).join('\n')}\n\nEquipment: ${d.equipment.replace(/\n/g,'; ')}`}
function send(t){if(window.Android&&Android.share)Android.share(t);else if(navigator.share)navigator.share({text:t})}
window.shareDish=i=>send(txt(DISHES[i]));
window.shareMenu=()=>send('My Catering Menu\n\n'+[...favs].sort((a,b)=>a-b).map(i=>txt(DISHES[i])).join('\n\n-----\n\n'));
window.openDish=(i,keep)=>{sheet.innerHTML=`<button class="close" onclick="closeModal()">Close</button>`+card(DISHES[i],i,true);modal.classList.add('show');if(!keep)document.body.classList.add('lock')};
window.closeModal=()=>{modal.classList.remove('show');document.body.classList.remove('lock')};
modal.addEventListener('click',e=>{if(e.target===modal)closeModal()});
window.handleBack=()=>{if(modal.classList.contains('show')){closeModal();return true}if(onlyFav){setTab(false);return true}return false};
function setTab(f){onlyFav=f;$('tabAll').classList.toggle('on',!f);$('tabFav').classList.toggle('on',f);render();scrollTo(0,0)}
$('tabAll').onclick=()=>setTab(false);$('tabFav').onclick=()=>setTab(true);
q.oninput=render;save();chipsRender();render();
