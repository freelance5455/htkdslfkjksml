@echo off
npm install
npx cap add android
npx cap sync android
npx cap open android
pause
