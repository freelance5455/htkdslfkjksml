RUANG KENANGAN — SCRAPBOOK EDITION (V11)

Website album kenangan 26 foto dengan nuansa scrapbook vintage.
- Galeri dibuat seperti papan scrapbook: foto Polaroid, selotip kertas, rotasi kecil, bayangan lembut, dan coretan dekoratif.
- Filmstrip dan foto tambahan mengikuti gaya scrapbook.
- Timeline menggunakan kartu seperti potongan kertas.
- Halaman rahasia, surat interaktif, opening 5 detik, dan fitur foto tambahan tetap dipertahankan.
- Foto tambahan dari 03 masuk ke 01 — Galeri dan tersimpan lokal di browser/perangkat.


V16 — Waterfall Card: ditambahkan kartu kenangan bertumpuk bergaya scrapbook yang bisa ditekan untuk mengalir ke kartu berikutnya.
