# Security Specification (`security_spec.md`)

## 1. Data Invariants
1. **Identity & Ownership**: A user profile `/users/{userId}` can only be created or updated by the authenticated user where `request.auth.uid == userId` and `incoming().uid == request.auth.uid`.
2. **Email Verification**: Every write operation requires `request.auth.token.email_verified == true`.
3. **PII Isolation**: Email addresses and sensitive authentication details are stored exclusively in `/users/{userId}/private/info` and can never be read or listed by anyone other than `request.auth.uid == userId`.
4. **Temporal Integrity**: `createdAt` must equal `request.time` on creation and remain immutable on update. `updatedAt` must equal `request.time` on creation and update.
5. **Strict Key & Size Bounds**: Every string field enforces exact `minLength`, `maxLength`, and regex `pattern` constraints from `firebase-blueprint.json`. No shadow/extra fields are allowed (`hasOnly`).

## 2. The "Dirty Dozen" Payloads
1. **Unauthenticated Write**: `auth = null` attempting to create `/users/user_1`.
2. **Unverified Email Write**: `auth = { uid: 'user_1', token: { email_verified: false } }` attempting to create `/users/user_1`.
3. **Identity Spoofing on Create**: `auth.uid = 'user_1'` attempting to create `/users/user_1` with `uid: 'user_2'`.
4. **Shadow Field Injection on Create**: Adding `"isAdmin": true` to `/users/user_1`.
5. **Invalid 10-Digit UserCode**: Setting `userCode: "12345"` or `"ABCDEFGHIJ"` instead of `^[0-9]{10}$`.
6. **Resource Exhaustion (Oversized DisplayName)**: Setting `displayName` to a 500-character string (`> 100`).
7. **Client Timestamp Spoofing**: Passing a past/future timestamp instead of `request.time` for `createdAt` or `updatedAt`.
8. **Immutable Field Mutation on Update**: Attempting to modify `createdAt`, `uid`, or `userCode` during an update to `/users/user_1`.
9. **Shadow Field Injection on Update**: Including `"role": "superadmin"` in an update to `/users/user_1`.
10. **Cross-User Private PII Read**: `auth.uid = 'user_2'` attempting `get` on `/users/user_1/private/info`.
11. **Invalid Document ID Poisoning**: Creating `/users/user$bad!id` or `/users/user_1/private/otherDoc`.
12. **Unauthorized Profile Deletion**: Attempting `delete` on `/users/user_1`.
