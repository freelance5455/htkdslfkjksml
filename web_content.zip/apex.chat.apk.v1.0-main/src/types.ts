export type Language = 'ar' | 'en' | 'fr';

export type ChatThemeColor = 'emerald' | 'teal' | 'blue' | 'slate';
export type ChatWallpaper = 'minimal' | 'geometric' | 'topography' | 'dots';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  avatar: string;
  statusText: string;
  twoFactorEnabled: boolean;
  twoFactorSecret: string;
  recoveryCodes: string[];
  autoBackupFrequency: 'realtime' | 'daily' | 'weekly' | 'manual';
  encryptSensitiveBackups: boolean;
  connectedProvider?: 'google' | 'apple' | 'github' | 'email';
}

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  text?: string;
  imageUrl?: string;
  imageCaption?: string;
  audioDuration?: string;
  fileAttachment?: {
    name: string;
    size: string;
    type: string;
  };
  timestamp: string;
  status: 'sent' | 'delivered' | 'read';
  isEncrypted: boolean;
  cipherSignature: string;
  reactions?: string[];
  isSensitive?: boolean;
  replyTo?: {
    id: string;
    senderName: string;
    text: string;
  };
}

export interface GroupMember {
  id: string;
  name: string;
  role: 'admin' | 'member';
  avatar: string;
  online: boolean;
}

export interface ChatConversation {
  id: string;
  name: string;
  nameEn: string;
  isGroup: boolean;
  avatar: string;
  online?: boolean;
  lastSeen?: string;
  unreadCount: number;
  pinned?: boolean;
  muted?: boolean;
  encryptionFingerprint: string;
  encryptionProtocol: string;
  description?: string;
  members?: GroupMember[];
  typingUser?: string;
}

export interface CallRecord {
  id: string;
  chatId: string;
  contactName: string;
  contactAvatar: string;
  type: 'voice' | 'video';
  direction: 'incoming' | 'outgoing' | 'missed';
  timestamp: string;
  duration: string;
  encrypted: boolean;
}

export interface LinkedDevice {
  id: string;
  name: string;
  os: string;
  browserOrApp: string;
  location: string;
  ipAddress: string;
  lastActive: string;
  isCurrent: boolean;
  syncStatus: 'synced' | 'syncing';
  trusted: boolean;
}

export interface CloudBackupSnapshot {
  id: string;
  timestamp: string;
  sizeMB: number;
  messagesCount: number;
  mediaCount: number;
  encryptedWithKey: string;
  includesSensitiveVault: boolean;
  trigger: 'auto' | 'manual';
}

export interface ExternalIntegration {
  id: string;
  name: string;
  category: string;
  descriptionAr: string;
  descriptionEn: string;
  connected: boolean;
  lastSync?: string;
  webhookUrl?: string;
  permissions: string[];
}

export interface AppNotification {
  id: string;
  titleAr: string;
  titleEn: string;
  bodyAr: string;
  bodyEn: string;
  timestamp: string;
  category: 'message' | 'security' | 'backup' | 'update' | 'call';
  read: boolean;
}
