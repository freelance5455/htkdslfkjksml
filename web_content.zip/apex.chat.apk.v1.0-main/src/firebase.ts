import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  setDoc,
  collection,
  query,
  where,
  writeBatch,
  updateDoc,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testConnection(): Promise<void> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

testConnection();

export function generateDeterministic10DigitCode(uid: string): string {
  let hash = 2166136261;
  for (let i = 0; i < uid.length; i++) {
    hash ^= uid.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  const num = (Math.abs(hash) % 9000000000) + 1000000000;
  return num.toString().slice(0, 10).padStart(10, '1');
}

export interface SyncedUserRecord {
  uid: string;
  userCode: string;
  displayName: string;
  email: string;
  photoURL: string;
  statusText: string;
}

export async function syncAuthenticatedUserToFirestore(
  fbUser: FirebaseUser,
  fallbackAvatar: string
): Promise<SyncedUserRecord> {
  const uid = fbUser.uid.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 128);
  const publicRef = doc(db, 'users', uid);
  const privateRef = doc(db, 'users', uid, 'private', 'info');

  let existingPublic: Record<string, unknown> | null = null;
  try {
    const snap = await getDoc(publicRef);
    if (snap.exists()) {
      existingPublic = snap.data() as Record<string, unknown>;
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `users/${uid}`);
  }

  const userCode =
    existingPublic &&
    typeof existingPublic.userCode === 'string' &&
    /^[0-9]{10}$/.test(existingPublic.userCode)
      ? existingPublic.userCode
      : generateDeterministic10DigitCode(uid);

  const rawName = (
    (existingPublic?.displayName as string) ||
    fbUser.displayName ||
    fbUser.email?.split('@')[0] ||
    'مستخدم أبيكس'
  ).trim();
  const displayName = (rawName.length > 0 ? rawName : 'مستخدم أبيكس').slice(0, 100);

  const rawPhoto = (
    (existingPublic?.photoURL as string) ||
    fbUser.photoURL ||
    fallbackAvatar ||
    ''
  ).trim();
  const photoURL = rawPhoto.slice(0, 200000);

  const statusText = (
    (existingPublic?.statusText as string) || 'متصل — أبيكس شات'
  ).slice(0, 160);

  const email = (fbUser.email || 'user@apexchat.cloud').slice(0, 254);
  const providerId = (fbUser.providerData[0]?.providerId || 'google.com').slice(0, 64);

  if (!existingPublic) {
    try {
      const batch = writeBatch(db);
      batch.set(publicRef, {
        uid,
        userCode,
        displayName,
        photoURL,
        statusText,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(privateRef, {
        uid,
        email,
        providerId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${uid}`);
    }
  }

  // Also register/sync with the real-time online server
  try {
    await fetch('/api/online/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uid,
        name: displayName,
        email,
        avatar: photoURL,
        preferredCode: userCode,
      }),
    });
  } catch {
    // Ignore network error if any
  }

  return {
    uid,
    userCode,
    displayName,
    email,
    photoURL,
    statusText,
  };
}

export async function updateUserAvatarInFirestore(
  uid: string,
  newPhotoURL: string,
  userCode?: string
): Promise<void> {
  const safePhoto = newPhotoURL.slice(0, 200000);
  if (userCode) {
    try {
      await fetch('/api/online/users/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userCode, avatar: safePhoto }),
      });
    } catch {
      // Ignore network error
    }
  }
  if (auth.currentUser && uid) {
    const safeUid = uid.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 128);
    const publicRef = doc(db, 'users', safeUid);
    try {
      await updateDoc(publicRef, {
        photoURL: safePhoto,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${safeUid}`);
    }
  }
}

export async function findUserBy10DigitCode(
  code: string
): Promise<{
  uid: string;
  userCode: string;
  displayName: string;
  photoURL: string;
  statusText: string;
} | null> {
  const cleanCode = code.trim();
  if (!/^[0-9]{10}$/.test(cleanCode)) return null;

  // 1. Check online real-time directory first
  try {
    const res = await fetch(`/api/online/users/${encodeURIComponent(cleanCode)}`);
    if (res.ok) {
      const data = await res.json();
      if (data?.found && data?.user) {
        return {
          uid: String(data.user.uid || cleanCode),
          userCode: String(data.user.userCode || cleanCode),
          displayName: String(data.user.displayName || `مستخدم #${cleanCode}`),
          photoURL: String(data.user.photoURL || ''),
          statusText: String(data.user.statusText || 'متصل أونلاين'),
        };
      }
    }
  } catch {
    // Fallback to Firestore if needed
  }

  // 2. Check Firestore if signed in with Firebase Auth
  if (auth.currentUser) {
    try {
      const q = query(collection(db, 'users'), where('userCode', '==', cleanCode));
      const snap = await getDocs(q);
      if (!snap.empty) {
        const d = snap.docs[0].data();
        return {
          uid: String(d.uid || snap.docs[0].id),
          userCode: String(d.userCode || cleanCode),
          displayName: String(d.displayName || `مستخدم #${cleanCode}`),
          photoURL: String(d.photoURL || ''),
          statusText: String(d.statusText || 'متصل'),
        };
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'users');
    }
  }

  return null;
}

export async function createOnlineChatRoom(
  creatorCode: string,
  targetCode: string,
  targetName: string
): Promise<{ targetUser: { displayName: string; photoURL: string; online: boolean } | null }> {
  const cleanCreator = creatorCode.trim();
  const cleanTarget = targetCode.trim();
  const cleanName = targetName.trim().slice(0, 100);

  let targetUser: { displayName: string; photoURL: string; online: boolean } | null = null;
  try {
    const res = await fetch('/api/online/chats/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ownerCode: cleanCreator,
        targetCode: cleanTarget,
        targetName: cleanName,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      targetUser = data.targetUser || null;
    }
  } catch {
    // Ignore network error
  }

  // Also persist to Firestore if authenticated via Firebase
  if (auth.currentUser && /^[0-9]{10}$/.test(cleanCreator) && /^[0-9]{10}$/.test(cleanTarget)) {
    const roomId = `chat_${[cleanCreator, cleanTarget].sort().join('_')}`;
    const chatRef = doc(db, 'chats', roomId);
    try {
      const existing = await getDoc(chatRef);
      if (!existing.exists()) {
        await setDoc(chatRef, {
          chatId: roomId,
          ownerId: auth.currentUser.uid,
          creatorCode: cleanCreator,
          targetCode: cleanTarget,
          targetName: cleanName,
          lastMessage: '',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    } catch {
      // Non-fatal if doc already owned by counterparty
    }
  }

  return { targetUser };
}

export async function sendOnlineChatMessage(params: {
  senderCode: string;
  senderName: string;
  recipientCode: string;
  text?: string;
  imageUrl?: string;
  imageCaption?: string;
  timestamp: string;
}): Promise<void> {
  try {
    await fetch('/api/online/messages/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
  } catch (err) {
    console.error('Online send error:', err);
  }

  // Also write to Firestore if authenticated via Firebase
  if (
    auth.currentUser &&
    /^[0-9]{10}$/.test(params.senderCode) &&
    /^[0-9]{10}$/.test(params.recipientCode)
  ) {
    const roomId = `chat_${[params.senderCode, params.recipientCode].sort().join('_')}`;
    const msgId = `msg_${Date.now()}`;
    const msgRef = doc(db, 'chats', roomId, 'messages', msgId);
    try {
      await setDoc(msgRef, {
        messageId: msgId,
        chatId: roomId,
        senderUid: auth.currentUser.uid,
        senderCode: params.senderCode,
        senderName: params.senderName.slice(0, 100),
        text: (params.text || params.imageCaption || '').slice(0, 4000),
        imageUrl: (params.imageUrl || '').slice(0, 200000),
        createdAt: serverTimestamp(),
      });
    } catch {
      // Non-fatal
    }
  }
}

export { signInWithPopup, firebaseSignOut, onAuthStateChanged };
export type { FirebaseUser };
