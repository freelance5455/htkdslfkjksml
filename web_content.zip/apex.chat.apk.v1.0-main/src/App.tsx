import React, { useEffect, useState } from 'react';
import {
  MessageSquare,
  Phone,
  User,
  Plus,
  Bell,
  Moon,
  Sun,
  LogOut,
  X,
  Lock,
  Loader2,
} from 'lucide-react';
import {
  AppNotification,
  CallRecord,
  ChatConversation,
  ChatThemeColor,
  ChatWallpaper,
  ExternalIntegration,
  Language,
  Message,
  UserProfile,
} from './types';
import {
  ASSETS,
  INITIAL_INTEGRATIONS,
  INITIAL_NOTIFICATIONS,
  TRANSLATIONS,
} from './data/mockData';
import { AuthPortal } from './components/AuthPortal';
import { ChatWorkspace } from './components/ChatWorkspace';
import { CallsCenter } from './components/CallsCenter';
import { IntegrationsCustomizationCenter } from './components/IntegrationsCustomizationCenter';
import { CallModal } from './components/CallModal';
import {
  auth,
  onAuthStateChanged,
  firebaseSignOut,
  syncAuthenticatedUserToFirestore,
} from './firebase';

type ActiveSection = 'chats' | 'calls' | 'integrations';

export function App() {
  const [lang, setLang] = useState<Language>('ar');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [authReady, setAuthReady] = useState<boolean>(false);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [firebaseUid, setFirebaseUid] = useState<string>('');

  const [user, setUser] = useState<UserProfile>({
    id: '0000000000',
    name: 'المستخدم',
    email: '',
    phone: '',
    avatar: ASSETS.avatarUser1,
    statusText: 'متصل أونلاين',
    twoFactorEnabled: false,
    twoFactorSecret: '',
    recoveryCodes: [],
    autoBackupFrequency: 'realtime',
    encryptSensitiveBackups: true,
    connectedProvider: 'google',
  });

  const [activeSection, setActiveSection] = useState<ActiveSection>('chats');
  const [chats, setChats] = useState<ChatConversation[]>([]);
  const [messagesByChat, setMessagesByChat] =
    useState<Record<string, Message[]>>({});
  const [activeChatId, setActiveChatId] = useState<string>('');
  const [calls, setCalls] = useState<CallRecord[]>([]);
  const [integrations, setIntegrations] =
    useState<ExternalIntegration[]>(INITIAL_INTEGRATIONS);
  const [notifications, setNotifications] =
    useState<AppNotification[]>(INITIAL_NOTIFICATIONS);

  // Customization states
  const [themeColor, setThemeColor] = useState<ChatThemeColor>('slate');
  const [wallpaper, setWallpaper] = useState<ChatWallpaper>('minimal');
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg'>('base');

  // Modals & Drawers
  const [activeCall, setActiveCall] = useState<{
    chat: ChatConversation;
    type: 'voice' | 'video';
  } | null>(null);
  const [showNewGroupModal, setShowNewGroupModal] = useState(false);
  const [showNotificationsDrawer, setShowNotificationsDrawer] = useState(false);
  const [liveToast, setLiveToast] = useState<AppNotification | null>(null);

  const isRTL = lang === 'ar';
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang, isRTL]);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Restore saved online session or Firebase session
  useEffect(() => {
    const savedRaw = localStorage.getItem('apex_chat_online_session');
    if (savedRaw) {
      try {
        const parsed = JSON.parse(savedRaw);
        if (parsed?.user?.id) {
          setUser(parsed.user);
          setFirebaseUid(parsed.uid || parsed.user.id);
          setIsAuthenticated(true);
          setActiveSection('chats');
        }
      } catch {
        // Ignore corrupt storage
      }
    }

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser && localStorage.getItem('apex_chat_online_session')) {
        try {
          const synced = await syncAuthenticatedUserToFirestore(
            fbUser,
            ASSETS.avatarUser1
          );
          const profile: UserProfile = {
            id: synced.userCode,
            name: synced.displayName,
            email: synced.email,
            phone: fbUser.phoneNumber || '',
            avatar: synced.photoURL || ASSETS.avatarUser1,
            statusText: synced.statusText,
            twoFactorEnabled: false,
            twoFactorSecret: '',
            recoveryCodes: [],
            autoBackupFrequency: 'realtime',
            encryptSensitiveBackups: true,
            connectedProvider: 'google',
          };
          setFirebaseUid(synced.uid);
          setUser(profile);
          setIsAuthenticated(true);
          setActiveSection('chats');
        } catch (err) {
          console.error('Error syncing authenticated user:', err);
        }
      }
      setAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  // 100% Online Real-Time Sync for Conversations & Messages
  useEffect(() => {
    if (!isAuthenticated || !user.id || user.id === '0000000000') return;

    let active = true;

    const syncOnlineData = async () => {
      try {
        const res = await fetch(
          `/api/online/sync?userCode=${encodeURIComponent(user.id)}`
        );
        if (!res.ok || !active) return;
        const data = await res.json();

        if (Array.isArray(data.chats)) {
          setChats((prev) => {
            const incomingChats: ChatConversation[] = data.chats.map(
              (c: ChatConversation) => ({
                ...c,
                avatar: c.avatar || ASSETS.avatarUser2,
              })
            );
            const map = new Map<string, ChatConversation>();
            for (const c of incomingChats) map.set(c.id, c);
            for (const c of prev) {
              if (!map.has(c.id)) map.set(c.id, c);
            }
            return Array.from(map.values());
          });
        }

        if (data.messagesByChat && typeof data.messagesByChat === 'object') {
          setMessagesByChat((prev) => ({
            ...prev,
            ...(data.messagesByChat as Record<string, Message[]>),
          }));
        }
      } catch {
        // Ignore transient offline poll error
      }
    };

    syncOnlineData();
    const interval = setInterval(syncOnlineData, 1500);

    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [isAuthenticated, user.id]);

  const triggerInstantNotification = (
    titleAr: string,
    titleEn: string,
    bodyAr: string,
    bodyEn: string,
    category: AppNotification['category'] = 'update'
  ) => {
    const newNotif: AppNotification = {
      id: `notif-${Date.now()}`,
      titleAr,
      titleEn,
      bodyAr,
      bodyEn,
      timestamp: isRTL ? 'الآن' : 'Just now',
      category,
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
    setLiveToast(newNotif);
    setTimeout(() => {
      setLiveToast((current) => (current?.id === newNotif.id ? null : current));
    }, 4500);
  };

  const handleRealSignOut = async () => {
    localStorage.removeItem('apex_chat_online_session');
    try {
      await firebaseSignOut(auth);
    } catch {
      // Ignore
    }
    setIsAuthenticated(false);
    setFirebaseUid('');
    setChats([]);
    setMessagesByChat({});
    setActiveChatId('');
    setActiveSection('chats');
  };

  const handleStartCall = (chat: ChatConversation, type: 'voice' | 'video') => {
    setActiveCall({ chat, type });
  };

  const handleEndCall = (durationFormatted: string) => {
    if (!activeCall) return;
    const record: CallRecord = {
      id: `call-${Date.now()}`,
      chatId: activeCall.chat.id,
      contactName: isRTL ? activeCall.chat.name : activeCall.chat.nameEn,
      contactAvatar: activeCall.chat.avatar,
      type: activeCall.type,
      direction: 'outgoing',
      timestamp: isRTL ? 'الآن' : 'Just now',
      duration: durationFormatted === '00:00' ? '00:12' : durationFormatted,
      encrypted: true,
    };
    setCalls((prev) => [record, ...prev]);
    setActiveCall(null);
  };

  if (!authReady) {
    return (
      <div
        dir={isRTL ? 'rtl' : 'ltr'}
        className={`h-[100dvh] w-full flex flex-col items-center justify-center gap-3 ${
          darkMode ? 'bg-black text-white' : 'bg-white text-black'
        }`}
      >
        <Loader2 className="w-8 h-8 animate-spin" />
        <span className="text-xs font-semibold">
          {isRTL ? 'جاري تشغيل Apex Chat...' : 'Loading Apex Chat...'}
        </span>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <AuthPortal
        lang={lang}
        setLang={setLang}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onLoginSuccess={(loggedInUser, uid) => {
          setUser(loggedInUser);
          setFirebaseUid(uid);
          setIsAuthenticated(true);
          setActiveSection('chats');
          triggerInstantNotification(
            'مرحباً بك في Apex Chat',
            'Welcome to Apex Chat',
            `تم الدخول بنجاح (${loggedInUser.name}) — معرفك الرقمي هو ID: ${loggedInUser.id}`,
            `Welcome ${loggedInUser.name} — your User ID is ${loggedInUser.id}`,
            'security'
          );
        }}
      />
    );
  }

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className={`h-[100dvh] max-h-[100dvh] w-full flex flex-col overflow-hidden transition-colors duration-200 ${
        darkMode ? 'bg-black text-white' : 'bg-white text-black'
      }`}
    >
      {/* Monochrome 3-Zone Top Bar (Fits all Android 12-15+ screens) */}
      <header
        className={`h-14 sm:h-16 flex items-center justify-between gap-4 px-3.5 sm:px-6 border-b shrink-0 z-30 ${
          darkMode ? 'bg-black border-neutral-800' : 'bg-white border-neutral-200'
        }`}
      >
        {/* Zone 1: Wordmark with logo */}
        <a
          href="#chats"
          onClick={(e) => {
            e.preventDefault();
            setActiveSection('chats');
          }}
          className="flex items-center gap-2 text-base sm:text-lg font-bold tracking-tight whitespace-nowrap shrink-0"
        >
          <div
            className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center font-bold text-xs sm:text-sm ${
              darkMode ? 'bg-white text-black' : 'bg-black text-white'
            }`}
          >
            AC
          </div>
          <span>Apex Chat</span>
        </a>

        {/* Zone 2: Navigation Links with Black Icons on Desktop */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-bold">
          <button
            type="button"
            onClick={() => setActiveSection('chats')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeSection === 'chats'
                ? darkMode
                  ? 'bg-white text-black'
                  : 'bg-black text-white'
                : 'text-black dark:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900'
            }`}
          >
            <MessageSquare className="w-4 h-4" strokeWidth={2.2} />
            <span>{isRTL ? 'المحادثات' : 'Chats'}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveSection('calls')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeSection === 'calls'
                ? darkMode
                  ? 'bg-white text-black'
                  : 'bg-black text-white'
                : 'text-black dark:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900'
            }`}
          >
            <Phone className="w-4 h-4" strokeWidth={2.2} />
            <span>{t.navCalls}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveSection('integrations')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeSection === 'integrations'
                ? darkMode
                  ? 'bg-white text-black'
                  : 'bg-black text-white'
                : 'text-black dark:text-white hover:bg-neutral-100 dark:hover:bg-neutral-900'
            }`}
          >
            <User className="w-4 h-4" strokeWidth={2.2} />
            <span>{isRTL ? 'الملف الشخصي' : 'Profile'}</span>
          </button>
        </nav>

        {/* Zone 3: Primary Action Button (Add Chat) */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              setActiveSection('chats');
              setShowNewGroupModal(true);
            }}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer ${
              darkMode
                ? 'bg-white text-black hover:bg-neutral-200'
                : 'bg-black text-white hover:bg-neutral-800'
            }`}
          >
            <Plus className="w-4 h-4" strokeWidth={2.4} />
            <span>{isRTL ? 'أضف محادثة' : 'Add Chat'}</span>
          </button>
        </div>
      </header>

      {/* Workspace Body: Fits 100% of remaining viewport height */}
      <div className="flex-1 min-h-0 flex overflow-hidden">
        {/* Compact Utility Rail (Tablet/Desktop) with Crisp Black Icons */}
        <aside
          className={`hidden sm:flex w-16 flex-col items-center justify-between py-4 border-e shrink-0 ${
            darkMode ? 'bg-black border-neutral-800' : 'bg-white border-neutral-200'
          }`}
        >
          <div className="flex flex-col items-center gap-2.5">
            <button
              type="button"
              onClick={() => setActiveSection('integrations')}
              title={`${user.name} (ID: ${user.id})`}
              className={`w-11 h-11 rounded-full overflow-hidden border-2 mb-1 cursor-pointer ${
                darkMode ? 'border-white' : 'border-black'
              }`}
            >
              <img
                src={user.avatar || ASSETS.avatarUser1}
                alt={user.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </button>

            {(
              [
                { id: 'chats', icon: MessageSquare, label: isRTL ? 'المحادثات' : 'Chats' },
                { id: 'calls', icon: Phone, label: t.navCalls },
                {
                  id: 'integrations',
                  icon: User,
                  label: isRTL ? 'الملف الشخصي' : 'Profile',
                },
              ] as const
            ).map((item) => {
              const Icon = item.icon;
              const active = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveSection(item.id)}
                  title={item.label}
                  className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${
                    active
                      ? darkMode
                        ? 'bg-white text-black border-white shadow-xs'
                        : 'bg-black text-white border-black shadow-xs'
                      : darkMode
                      ? 'bg-neutral-950 text-white border-neutral-800 hover:border-white'
                      : 'bg-white text-black border-neutral-300 hover:border-black'
                  }`}
                >
                  <Icon className="w-5 h-5" strokeWidth={2.2} />
                </button>
              );
            })}
          </div>

          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setShowNotificationsDrawer(!showNotificationsDrawer);
                setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
              }}
              title="Notifications"
              className={`relative w-11 h-11 rounded-xl flex items-center justify-center border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-neutral-800 text-white hover:bg-neutral-900'
                  : 'border-neutral-300 text-black hover:bg-neutral-100'
              }`}
            >
              <Bell className="w-5 h-5" strokeWidth={2.2} />
              {unreadNotificationsCount > 0 && (
                <span
                  className={`absolute top-1 end-1 px-1 text-[10px] font-mono font-bold rounded-md ${
                    darkMode ? 'bg-white text-black' : 'bg-black text-white'
                  }`}
                >
                  {unreadNotificationsCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setDarkMode(!darkMode)}
              title="Theme Toggle"
              className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-neutral-800 text-white hover:bg-neutral-900'
                  : 'border-neutral-300 text-black hover:bg-neutral-100'
              }`}
            >
              {darkMode ? (
                <Sun className="w-5 h-5" strokeWidth={2.2} />
              ) : (
                <Moon className="w-5 h-5" strokeWidth={2.2} />
              )}
            </button>

            <button
              type="button"
              onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
              title="Language"
              className={`w-11 h-11 rounded-xl flex items-center justify-center border text-xs font-bold transition-colors cursor-pointer ${
                darkMode
                  ? 'border-neutral-800 text-white hover:bg-neutral-900'
                  : 'border-neutral-300 text-black hover:bg-neutral-100'
              }`}
            >
              {lang.toUpperCase()}
            </button>

            <button
              type="button"
              onClick={handleRealSignOut}
              title={t.logout}
              className={`w-11 h-11 rounded-xl flex items-center justify-center border transition-colors cursor-pointer ${
                darkMode
                  ? 'border-neutral-800 text-white hover:bg-neutral-900'
                  : 'border-neutral-300 text-black hover:bg-neutral-100'
              }`}
            >
              <LogOut className="w-5 h-5" strokeWidth={2.2} />
            </button>
          </div>
        </aside>

        {/* Main Viewport Content */}
        <main className="flex-1 min-h-0 flex flex-col overflow-y-auto">
          {activeSection === 'chats' && (
            <ChatWorkspace
              lang={lang}
              darkMode={darkMode}
              user={user}
              chats={chats}
              setChats={setChats}
              messagesByChat={messagesByChat}
              setMessagesByChat={setMessagesByChat}
              activeChatId={activeChatId}
              setActiveChatId={setActiveChatId}
              themeColor={themeColor}
              wallpaper={wallpaper}
              fontSize={fontSize}
              onStartCall={handleStartCall}
              onTriggerAutoSensitiveBackup={() => {}}
              showNewGroupModal={showNewGroupModal}
              setShowNewGroupModal={setShowNewGroupModal}
            />
          )}

          {activeSection === 'calls' && (
            <CallsCenter
              lang={lang}
              darkMode={darkMode}
              calls={calls}
              chats={
                chats.length > 0
                  ? chats
                  : [
                      {
                        id: 'default',
                        name: 'محادثة جديدة',
                        nameEn: 'New Chat',
                        isGroup: false,
                        avatar: ASSETS.avatarUser2,
                        unreadCount: 0,
                        encryptionFingerprint: '8F4A',
                        encryptionProtocol: 'Signal',
                      },
                    ]
              }
              onStartCall={handleStartCall}
            />
          )}

          {activeSection === 'integrations' && (
            <IntegrationsCustomizationCenter
              lang={lang}
              setLang={setLang}
              darkMode={darkMode}
              setDarkMode={setDarkMode}
              themeColor={themeColor}
              setThemeColor={setThemeColor}
              wallpaper={wallpaper}
              setWallpaper={setWallpaper}
              fontSize={fontSize}
              setFontSize={setFontSize}
              integrations={integrations}
              setIntegrations={setIntegrations}
              user={user}
              setUser={setUser}
              firebaseUid={firebaseUid}
              onSignOut={handleRealSignOut}
              onTriggerNotification={(tAr, tEn, bAr, bEn) =>
                triggerInstantNotification(tAr, tEn, bAr, bEn, 'update')
              }
            />
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar (Android 12-15+ Optimized, Crisp Black Icons) */}
      <nav
        className={`sm:hidden h-16 shrink-0 border-t grid grid-cols-3 items-center px-2 z-40 ${
          darkMode
            ? 'bg-black border-neutral-800 text-white'
            : 'bg-white border-neutral-200 text-black'
        }`}
      >
        {(
          [
            { id: 'chats', icon: MessageSquare, label: isRTL ? 'المحادثات' : 'Chats' },
            { id: 'calls', icon: Phone, label: isRTL ? 'المكالمات' : 'Calls' },
            { id: 'integrations', icon: User, label: isRTL ? 'الملف الشخصي' : 'Profile' },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSection === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveSection(tab.id)}
              className="flex flex-col items-center justify-center h-full gap-1 cursor-pointer"
            >
              <div
                className={`px-4 py-1 rounded-xl flex items-center justify-center transition-all ${
                  isActive
                    ? darkMode
                      ? 'bg-white text-black'
                      : 'bg-black text-white'
                    : darkMode
                    ? 'text-white'
                    : 'text-black'
                }`}
              >
                <Icon className="w-5 h-5" strokeWidth={2.3} />
              </div>
              <span
                className={`text-[11px] font-bold truncate max-w-[88px] ${
                  darkMode ? 'text-white' : 'text-black'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Notifications Drawer */}
      {showNotificationsDrawer && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex justify-end">
          <div
            className={`w-full max-w-md h-full p-6 overflow-y-auto space-y-5 border-s ${
              darkMode
                ? 'bg-neutral-950 border-neutral-800 text-white'
                : 'bg-white border-neutral-200 text-black'
            }`}
          >
            <div className="flex items-center justify-between border-b border-neutral-200 dark:border-neutral-800 pb-4">
              <div className="flex items-center gap-2 font-bold text-base">
                <Bell className="w-5 h-5" strokeWidth={2.2} />
                <span>{isRTL ? 'الإشعارات الفورية' : 'Instant Notifications'}</span>
              </div>
              <button
                type="button"
                onClick={() => setShowNotificationsDrawer(false)}
                className="p-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {notifications.map((n) => (
                <div
                  key={n.id}
                  className={`p-4 rounded-xl border space-y-1.5 ${
                    darkMode ? 'bg-black border-neutral-800' : 'bg-neutral-50 border-neutral-200'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold">
                      {isRTL ? n.titleAr : n.titleEn}
                    </span>
                    <span className="font-mono text-[11px] text-neutral-400">
                      {n.timestamp}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
                    {isRTL ? n.bodyAr : n.bodyEn}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Floating Toast */}
      {liveToast && (
        <div
          className={`fixed bottom-20 sm:bottom-6 end-4 sm:end-6 z-50 max-w-sm w-[calc(100%-2rem)] sm:w-full p-4 rounded-2xl border shadow-xl flex items-start justify-between gap-3 ${
            darkMode
              ? 'bg-white text-black border-neutral-200'
              : 'bg-black text-white border-neutral-800'
          }`}
        >
          <div className="space-y-1">
            <div className="flex items-center gap-1.5 text-xs font-bold">
              <Lock className="w-3.5 h-3.5" />
              <span>{isRTL ? liveToast.titleAr : liveToast.titleEn}</span>
            </div>
            <p className="text-xs opacity-80 leading-relaxed">
              {isRTL ? liveToast.bodyAr : liveToast.bodyEn}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setLiveToast(null)}
            className="opacity-70 hover:opacity-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Call Modal */}
      {activeCall && (
        <CallModal
          chat={activeCall.chat}
          callType={activeCall.type}
          lang={lang}
          onEndCall={handleEndCall}
        />
      )}
    </div>
  );
}

export default App;
