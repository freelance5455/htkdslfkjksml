import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Video,
  VideoOff,
  PhoneOff,
  ShieldCheck,
  MonitorUp,
  Lock,
} from 'lucide-react';
import { ChatConversation, Language } from '../types';

interface CallModalProps {
  chat: ChatConversation;
  callType: 'voice' | 'video';
  lang: Language;
  onEndCall: (durationFormatted: string) => void;
}

export const CallModal: React.FC<CallModalProps> = ({
  chat,
  callType,
  lang,
  onEndCall,
}) => {
  const [seconds, setSeconds] = useState(0);
  const [muted, setMuted] = useState(false);
  const [videoEnabled, setVideoEnabled] = useState(callType === 'video');
  const [screenSharing, setScreenSharing] = useState(false);
  const [cameraAvailable, setCameraAvailable] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const isRTL = lang === 'ar';

  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let stream: MediaStream | null = null;
    if (videoEnabled && navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices
        .getUserMedia({ video: true, audio: false })
        .then((mediaStream) => {
          stream = mediaStream;
          setCameraAvailable(true);
          if (videoRef.current) {
            videoRef.current.srcObject = mediaStream;
          }
        })
        .catch(() => {
          setCameraAvailable(false);
        });
    } else {
      setCameraAvailable(false);
    }
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [videoEnabled]);

  const formatDuration = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60)
      .toString()
      .padStart(2, '0');
    const secs = (totalSec % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
    >
      <div className="w-full max-w-3xl rounded-3xl bg-neutral-950 border border-neutral-800 overflow-hidden shadow-2xl flex flex-col text-white">
        {/* Top Call Security Bar */}
        <div className="px-6 py-4 border-b border-neutral-800 flex items-center justify-between text-xs text-neutral-300">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-white" />
            <span>
              {isRTL
                ? 'مكالمة مشفرة بالكامل من الطرف إلى الطرف'
                : 'End-to-End Encrypted Call'}
            </span>
          </div>
          <span className="font-mono">Apex Chat Audio/Video</span>
        </div>

        {/* Call Stage */}
        <div className="relative h-96 bg-black flex flex-col items-center justify-center p-6 overflow-hidden">
          {videoEnabled ? (
            <div className="w-full h-full grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
              <div className="relative h-full rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-900 flex flex-col items-center justify-center">
                <img
                  src={chat.avatar}
                  alt={chat.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover opacity-85"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-4">
                  <div className="text-white font-semibold text-sm">
                    {isRTL ? chat.name : chat.nameEn}
                  </div>
                  <div className="text-neutral-300 text-xs font-mono tabular-nums">
                    HD Stream
                  </div>
                </div>
              </div>

              <div className="relative h-full rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-900 flex flex-col items-center justify-center">
                {cameraAvailable ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-6 space-y-3">
                    <div className="w-20 h-20 rounded-full bg-white text-black flex items-center justify-center mx-auto font-bold text-xl">
                      {isRTL ? 'أنت' : 'You'}
                    </div>
                    <div className="text-xs text-neutral-400">
                      {screenSharing
                        ? isRTL
                          ? 'جاري مشاركة الشاشة...'
                          : 'Sharing screen...'
                        : isRTL
                        ? 'الكاميرا المحلية نشطة'
                        : 'Local Camera Active'}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="text-center space-y-4">
              <div className="relative inline-block">
                <img
                  src={chat.avatar}
                  alt={chat.name}
                  referrerPolicy="no-referrer"
                  className="w-28 h-28 rounded-full object-cover border-2 border-white"
                />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">
                  {isRTL ? chat.name : chat.nameEn}
                </h3>
                <p className="text-sm text-neutral-300 font-mono tabular-nums mt-1">
                  {formatDuration(seconds)}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Call Controls Footer */}
        <div className="px-6 py-5 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between">
          <div className="text-xs text-neutral-400 font-mono tabular-nums">
            {formatDuration(seconds)}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMuted(!muted)}
              className={`min-w-[44px] min-h-[44px] p-3 rounded-xl border transition-colors ${
                muted
                  ? 'bg-white text-black border-white'
                  : 'bg-neutral-900 border-neutral-700 text-white hover:bg-neutral-800'
              }`}
            >
              {muted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <button
              type="button"
              onClick={() => setVideoEnabled(!videoEnabled)}
              className={`min-w-[44px] min-h-[44px] p-3 rounded-xl border transition-colors ${
                !videoEnabled
                  ? 'bg-neutral-900 border-neutral-700 text-neutral-400'
                  : 'bg-white text-black border-white'
              }`}
            >
              {videoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
            </button>

            <button
              type="button"
              onClick={() => setScreenSharing(!screenSharing)}
              className={`min-w-[44px] min-h-[44px] p-3 rounded-xl border transition-colors ${
                screenSharing
                  ? 'bg-white text-black border-white'
                  : 'bg-neutral-900 border-neutral-700 text-white hover:bg-neutral-800'
              }`}
            >
              <MonitorUp className="w-5 h-5" />
            </button>

            <button
              type="button"
              onClick={() => onEndCall(formatDuration(seconds))}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-white text-black hover:bg-neutral-200 font-bold text-sm flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              <PhoneOff className="w-4 h-4" />
              <span>{isRTL ? 'إنهاء المكالمة' : 'End Call'}</span>
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-xs text-neutral-300">
            <ShieldCheck className="w-4 h-4" />
            <span>E2EE</span>
          </div>
        </div>
      </div>
    </div>
  );
};
