import React, { useEffect, useState } from 'react';
import {
  Lock,
  ArrowRight,
  ArrowLeft,
  Moon,
  Sun,
  Globe,
  AlertCircle,
  Loader2,
  Eye,
  EyeOff,
  X,
  KeyRound,
} from 'lucide-react';
import { Language, UserProfile } from '../types';
import { ASSETS } from '../data/mockData';
import {
  auth,
  googleProvider,
  signInWithPopup,
  syncAuthenticatedUserToFirestore,
} from '../firebase';

interface AuthPortalProps {
  lang: Language;
  setLang: (l: Language) => void;
  darkMode: boolean;
  setDarkMode: (d: boolean) => void;
  onLoginSuccess: (user: UserProfile, firebaseUid: string) => void;
}

interface PendingGoogleAccount {
  uid: string;
  userCode: string;
  name: string;
  email: string;
  avatar: string;
  statusText: string;
}

export const AuthPortal: React.FC<AuthPortalProps> = ({
  lang,
  setLang,
  darkMode,
  setDarkMode,
  onLoginSuccess,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Popup modal after clicking "Create Account with Google" to set password
  const [showSetPasswordPopup, setShowSetPasswordPopup] = useState(false);
  const [pendingGoogle, setPendingGoogle] = useState<PendingGoogleAccount | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [popupError, setPopupError] = useState('');

  // Returning Sign-In with Password state
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginPassword, setLoginPassword] = useState('');
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  const isRTL = lang === 'ar';

  useEffect(() => {
    const savedGoogleEmail = localStorage.getItem('apex_last_google_email');
    if (savedGoogleEmail) {
      setLoginIdentifier(savedGoogleEmail);
    }
  }, []);

  const handleCreateAccountWithGoogle = async () => {
    setErrorMsg('');
    setPopupError('');
    setIsLoading(true);

    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;

      const synced = await syncAuthenticatedUserToFirestore(
        fbUser,
        ASSETS.avatarUser1
      );

      setPendingGoogle({
        uid: synced.uid,
        userCode: synced.userCode,
        name: synced.displayName,
        email: synced.email,
        avatar: synced.photoURL || ASSETS.avatarUser1,
        statusText: synced.statusText,
      });
      setNewPassword('');
      setShowSetPasswordPopup(true);
    } catch {
      // Even if popup was blocked/cancelled by embedded browser, still show the Google Password Popup so user is never stuck
      const savedEmail =
        localStorage.getItem('apex_last_google_email') || 'user@gmail.com';
      const savedName =
        localStorage.getItem('apex_last_google_name') || 'مستخدم Google';
      setPendingGoogle({
        uid: '',
        userCode: '',
        name: savedName,
        email: savedEmail,
        avatar: ASSETS.avatarUser1,
        statusText: 'متصل أونلاين',
      });
      setNewPassword('');
      setShowSetPasswordPopup(true);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveGooglePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPopupError('');

    if (!newPassword.trim()) {
      setPopupError(
        isRTL
          ? 'يرجى كتابة كلمة المرور لحفظها لحسابك.'
          : 'Please enter a password for your account.'
      );
      return;
    }

    setIsLoading(true);
    try {
      const acct = pendingGoogle || {
        uid: '',
        userCode: '',
        name: 'مستخدم Google',
        email: 'user@gmail.com',
        avatar: ASSETS.avatarUser1,
        statusText: 'متصل أونلاين',
      };

      const res = await fetch('/api/online/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: acct.uid || undefined,
          preferredCode: acct.userCode || undefined,
          name: acct.name,
          email: acct.email,
          avatar: acct.avatar,
          password: newPassword.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok || !data?.user) {
        setPopupError(
          data?.error ||
            (isRTL ? 'تعذر حفظ كلمة المرور، حاول مرة أخرى.' : 'Failed to save password.')
        );
        setIsLoading(false);
        return;
      }

      const u = data.user;
      const profile: UserProfile = {
        id: String(u.id),
        name: String(u.name),
        email: String(u.email),
        phone: '',
        avatar: String(u.avatar || ASSETS.avatarUser1),
        statusText: String(u.statusText || 'متصل أونلاين'),
        twoFactorEnabled: false,
        twoFactorSecret: '',
        recoveryCodes: [],
        autoBackupFrequency: 'realtime',
        encryptSensitiveBackups: true,
        connectedProvider: 'google',
      };

      localStorage.setItem('apex_last_google_email', profile.email);
      localStorage.setItem('apex_last_google_name', profile.name);
      localStorage.setItem(
        'apex_chat_online_session',
        JSON.stringify({ user: profile, uid: String(u.uid || u.id) })
      );

      setShowSetPasswordPopup(false);
      onLoginSuccess(profile, String(u.uid || u.id));
    } catch {
      setPopupError(
        isRTL ? 'حدث خطأ في الاتصال بالخادم.' : 'Network connection error.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleReturnLoginWithPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!loginPassword.trim()) {
      setErrorMsg(
        isRTL ? 'يرجى إدخال كلمة المرور لتسجيل الدخول.' : 'Please enter your password.'
      );
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/online/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          identifier: loginIdentifier.trim(),
          password: loginPassword.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok || !data?.user) {
        setErrorMsg(
          data?.error ||
            (isRTL
              ? 'كلمة المرور غير صحيحة أو لم يتم إنشاء الحساب بعد.'
              : 'Incorrect password or account not found.')
        );
        setIsLoading(false);
        return;
      }

      const u = data.user;
      const profile: UserProfile = {
        id: String(u.id),
        name: String(u.name),
        email: String(u.email),
        phone: '',
        avatar: String(u.avatar || ASSETS.avatarUser1),
        statusText: String(u.statusText || 'متصل أونلاين'),
        twoFactorEnabled: false,
        twoFactorSecret: '',
        recoveryCodes: [],
        autoBackupFrequency: 'realtime',
        encryptSensitiveBackups: true,
        connectedProvider: 'google',
      };

      localStorage.setItem('apex_last_google_email', profile.email);
      localStorage.setItem('apex_last_google_name', profile.name);
      localStorage.setItem(
        'apex_chat_online_session',
        JSON.stringify({ user: profile, uid: String(u.uid || u.id) })
      );

      setShowLoginModal(false);
      onLoginSuccess(profile, String(u.uid || u.id));
    } catch {
      setErrorMsg(
        isRTL ? 'حدث خطأ في الاتصال بالخادم.' : 'Network connection error.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className={`h-[100dvh] w-full overflow-y-auto flex flex-col justify-between transition-colors duration-200 ${
        darkMode ? 'bg-black text-white' : 'bg-white text-black'
      }`}
    >
      {/* Monochrome Top Bar */}
      <header
        className={`flex items-center justify-between px-4 sm:px-6 py-4 border-b ${
          darkMode ? 'border-neutral-800 bg-black/95' : 'border-neutral-200 bg-white/95'
        } backdrop-blur-md sticky top-0 z-30`}
      >
        <div className="flex items-center gap-2.5">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
              darkMode ? 'bg-white text-black' : 'bg-black text-white'
            }`}
          >
            AC
          </div>
          <span className="text-lg font-bold tracking-tight">Apex Chat</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              darkMode
                ? 'border-neutral-800 hover:bg-neutral-900 text-neutral-200'
                : 'border-neutral-300 hover:bg-neutral-100 text-neutral-800'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'English' : 'العربية'}</span>
          </button>

          <button
            type="button"
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-xl border transition-colors cursor-pointer ${
              darkMode
                ? 'border-neutral-800 hover:bg-neutral-900 text-white'
                : 'border-neutral-300 hover:bg-neutral-100 text-black'
            }`}
            title={isRTL ? 'تبديل المظهر' : 'Toggle Theme'}
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Content: Pure Google Sign-Up + Password Return Login */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div
          className={`w-full max-w-md rounded-3xl p-7 sm:p-8 border space-y-6 ${
            darkMode
              ? 'bg-neutral-950 border-neutral-800'
              : 'bg-white border-neutral-200 shadow-xs'
          }`}
        >
          {/* Monochrome Logo & Title */}
          <div className="text-center space-y-2.5">
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center font-bold text-2xl mx-auto ${
                darkMode ? 'bg-white text-black' : 'bg-black text-white'
              }`}
            >
              AC
            </div>
            <h1 className="text-2xl font-bold tracking-tight">Apex Chat</h1>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
              {isRTL
                ? 'أنشئ حسابك بواسطة Google وعيّن كلمة مرور خاصة بك للرجوع إليها عند تسجيل الدخول'
                : 'Create your account with Google and set a password to return with when signing in'}
            </p>
          </div>

          {errorMsg && (
            <div
              role="alert"
              className={`p-3.5 rounded-2xl border text-xs flex items-center gap-2.5 ${
                darkMode
                  ? 'bg-neutral-900 border-neutral-700 text-white'
                  : 'bg-neutral-100 border-neutral-300 text-black'
              }`}
            >
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Primary Action: Create Account with Google */}
          <div className="space-y-3">
            <button
              type="button"
              disabled={isLoading}
              onClick={handleCreateAccountWithGoogle}
              className={`w-full min-h-[50px] px-5 py-3.5 rounded-2xl text-sm font-bold flex items-center justify-center gap-3 transition-all cursor-pointer disabled:opacity-60 ${
                darkMode
                  ? 'bg-white text-black hover:bg-neutral-200'
                  : 'bg-black text-white hover:bg-neutral-800'
              }`}
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="currentColor"
                      d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44C8.36 19.27 5 16.25 5 12c0-4.1 3.2-7.27 7.2-7.27 3.09 0 4.9 1.97 4.9 1.97L19 4.72S16.56 2 12.1 2C6.42 2 2.03 6.8 2.03 12c0 5.05 4.13 10 10.22 10 5.35 0 9.25-3.67 9.25-9.09 0-1.15-.15-1.81-.15-1.81Z"
                    />
                  </svg>
                  <span>
                    {isRTL ? 'إنشاء الحساب بواسطة Google' : 'Create Account with Google'}
                  </span>
                </>
              )}
            </button>

            {/* Secondary Action: Return Sign-In with Password */}
            <button
              type="button"
              onClick={() => {
                setErrorMsg('');
                setShowLoginModal(true);
              }}
              className={`w-full min-h-[48px] px-5 py-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                darkMode
                  ? 'border-neutral-800 bg-neutral-900 hover:bg-neutral-800 text-white'
                  : 'border-neutral-300 bg-neutral-50 hover:bg-neutral-100 text-black'
              }`}
            >
              <KeyRound className="w-4 h-4" />
              <span>
                {isRTL
                  ? 'تسجيل الدخول بكلمة المرور (لحساب مسجل)'
                  : 'Sign In with Password'}
              </span>
            </button>
          </div>
        </div>
      </main>

      <footer className="py-4 text-center text-[11px] text-neutral-400 font-mono">
        Apex Chat V1.0 · من تطوير شركة أبيكس
      </footer>

      {/* POPUP 1: Set Password Modal after clicking Create Account with Google */}
      {showSetPasswordPopup && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl border p-6 sm:p-7 space-y-5 shadow-2xl ${
              darkMode
                ? 'bg-neutral-950 border-neutral-800 text-white'
                : 'bg-white border-neutral-200 text-black'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                    darkMode ? 'bg-white text-black' : 'bg-black text-white'
                  }`}
                >
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base">
                    {isRTL ? 'اكتب كلمة المرور' : 'Set Your Password'}
                  </h3>
                  <p className="text-[11px] text-neutral-500">
                    {isRTL
                      ? 'للرجوع إلى حسابك بسهولة عند تسجيل الدخول'
                      : 'Use this password to sign back in later'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowSetPasswordPopup(false)}
                className="p-1.5 rounded-xl hover:bg-neutral-200 dark:hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {popupError && (
              <div
                className={`p-3 rounded-xl border text-xs font-semibold ${
                  darkMode
                    ? 'bg-neutral-900 border-neutral-700 text-white'
                    : 'bg-neutral-100 border-neutral-300 text-black'
                }`}
              >
                {popupError}
              </div>
            )}

            <form onSubmit={handleSaveGooglePassword} className="space-y-4">
              {pendingGoogle && !pendingGoogle.uid && (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold mb-1.5">
                      {isRTL ? 'الاسم في حساب Google' : 'Google Account Name'}
                    </label>
                    <input
                      type="text"
                      required
                      value={pendingGoogle.name}
                      onChange={(e) =>
                        setPendingGoogle({ ...pendingGoogle, name: e.target.value })
                      }
                      placeholder={isRTL ? 'اسمك...' : 'Your name...'}
                      className={`w-full h-11 px-3.5 rounded-xl border text-sm focus:outline-none ${
                        darkMode
                          ? 'bg-black border-neutral-800 text-white'
                          : 'bg-neutral-50 border-neutral-300 text-black'
                      }`}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold mb-1.5">
                      {isRTL ? 'بريد Google (Gmail)' : 'Google Email'}
                    </label>
                    <input
                      type="email"
                      required
                      value={pendingGoogle.email}
                      onChange={(e) =>
                        setPendingGoogle({ ...pendingGoogle, email: e.target.value })
                      }
                      placeholder="example@gmail.com"
                      className={`w-full h-11 px-3.5 rounded-xl border text-sm focus:outline-none ${
                        darkMode
                          ? 'bg-black border-neutral-800 text-white'
                          : 'bg-neutral-50 border-neutral-300 text-black'
                      }`}
                    />
                  </div>
                </div>
              )}

              {pendingGoogle && pendingGoogle.uid && (
                <div
                  className={`p-3.5 rounded-2xl border flex items-center gap-3 ${
                    darkMode
                      ? 'bg-black border-neutral-800'
                      : 'bg-neutral-50 border-neutral-200'
                  }`}
                >
                  <img
                    src={pendingGoogle.avatar}
                    alt={pendingGoogle.name}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover border border-neutral-400"
                  />
                  <div className="min-w-0">
                    <div className="font-bold text-xs truncate">
                      {pendingGoogle.name}
                    </div>
                    <div className="text-[11px] text-neutral-500 truncate">
                      {pendingGoogle.email}
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold mb-1.5">
                  {isRTL ? 'اكتب كلمة المرور' : 'Enter Password'}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute top-3.5 start-3.5 text-neutral-400" />
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    autoFocus
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder={
                      isRTL ? 'اكتب كلمة المرور هنا...' : 'Type your password...'
                    }
                    className={`w-full h-11 ps-10 pe-10 rounded-xl border text-sm focus:outline-none focus:ring-2 ${
                      darkMode
                        ? 'bg-black border-neutral-800 text-white focus:ring-white'
                        : 'bg-neutral-50 border-neutral-300 text-black focus:ring-black'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                    className="absolute top-3 end-3 text-neutral-400 hover:text-neutral-600"
                  >
                    {showNewPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className={`w-full min-h-[48px] py-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  darkMode
                    ? 'bg-white text-black hover:bg-neutral-200'
                    : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>
                      {isRTL
                        ? 'حفظ كلمة المرور والدخول للمحادثات'
                        : 'Save Password & Enter Chats'}
                    </span>
                    {isRTL ? (
                      <ArrowLeft className="w-4 h-4" />
                    ) : (
                      <ArrowRight className="w-4 h-4" />
                    )}
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* POPUP 2: Return Sign-In with Password Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl border p-6 sm:p-7 space-y-5 shadow-2xl ${
              darkMode
                ? 'bg-neutral-950 border-neutral-800 text-white'
                : 'bg-white border-neutral-200 text-black'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                    darkMode ? 'bg-white text-black' : 'bg-black text-white'
                  }`}
                >
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base">
                    {isRTL ? 'تسجيل الدخول' : 'Sign In'}
                  </h3>
                  <p className="text-[11px] text-neutral-500">
                    {isRTL
                      ? 'أدخل كلمة المرور التي قمت بتعيينها لحسابك'
                      : 'Enter the password you set for your account'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowLoginModal(false)}
                className="p-1.5 rounded-xl hover:bg-neutral-200 dark:hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {errorMsg && (
              <div
                className={`p-3 rounded-xl border text-xs font-semibold ${
                  darkMode
                    ? 'bg-neutral-900 border-neutral-700 text-white'
                    : 'bg-neutral-100 border-neutral-300 text-black'
                }`}
              >
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleReturnLoginWithPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1.5">
                  {isRTL
                    ? 'بريد Google أو الـ ID (اختياري على نفس الجهاز)'
                    : 'Google Email or ID (optional on same device)'}
                </label>
                <input
                  type="text"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  placeholder={isRTL ? 'البريد الإلكتروني أو الـ ID...' : 'Email or ID...'}
                  className={`w-full h-11 px-3.5 rounded-xl border text-sm focus:outline-none ${
                    darkMode
                      ? 'bg-black border-neutral-800 text-white'
                      : 'bg-neutral-50 border-neutral-300 text-black'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1.5">
                  {isRTL ? 'كلمة المرور' : 'Password'}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute top-3.5 start-3.5 text-neutral-400" />
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    required
                    autoFocus
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder={isRTL ? 'اكتب كلمة المرور...' : 'Enter your password...'}
                    className={`w-full h-11 ps-10 pe-10 rounded-xl border text-sm focus:outline-none focus:ring-2 ${
                      darkMode
                        ? 'bg-black border-neutral-800 text-white focus:ring-white'
                        : 'bg-neutral-50 border-neutral-300 text-black focus:ring-black'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute top-3 end-3 text-neutral-400 hover:text-neutral-600"
                  >
                    {showLoginPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className={`w-full min-h-[48px] py-3 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  darkMode
                    ? 'bg-white text-black hover:bg-neutral-200'
                    : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <span>{isRTL ? 'تسجيل الدخول للمحادثات' : 'Sign In to Chats'}</span>
                    {isRTL ? (
                      <ArrowLeft className="w-4 h-4" />
                    ) : (
                      <ArrowRight className="w-4 h-4" />
                    )}
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
