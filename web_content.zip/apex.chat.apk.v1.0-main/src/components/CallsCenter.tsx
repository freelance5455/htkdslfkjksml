import React from 'react';
import {
  Phone,
  Video,
  PhoneIncoming,
  PhoneOutgoing,
  PhoneMissed,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { CallRecord, ChatConversation, Language } from '../types';

interface CallsCenterProps {
  lang: Language;
  darkMode: boolean;
  calls: CallRecord[];
  chats: ChatConversation[];
  onStartCall: (chat: ChatConversation, type: 'voice' | 'video') => void;
}

export const CallsCenter: React.FC<CallsCenterProps> = ({
  lang,
  darkMode,
  calls,
  chats,
  onStartCall,
}) => {
  const isRTL = lang === 'ar';

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      <div
        className={`rounded-2xl p-6 border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 ${
          darkMode ? 'bg-neutral-950 border-neutral-800' : 'bg-white border-neutral-200'
        }`}
      >
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-semibold text-neutral-500">
            <ShieldCheck className="w-4 h-4" />
            <span>
              {isRTL
                ? 'مكالمات صوتية ومرئية مشفرة بالكامل'
                : 'End-to-End Encrypted Voice & Video Calls'}
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            {isRTL ? 'سجل المكالمات الصوتية والمرئية' : 'Voice & Video Call Logs'}
          </h1>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onStartCall(chats[0], 'voice')}
            className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              darkMode
                ? 'bg-white text-black hover:bg-neutral-200'
                : 'bg-black text-white hover:bg-neutral-800'
            }`}
          >
            <Phone className="w-4 h-4" />
            <span>{isRTL ? 'مكالمة صوتية سريعة' : 'Quick Voice Call'}</span>
          </button>
          <button
            type="button"
            onClick={() => onStartCall(chats[0], 'video')}
            className={`min-h-[44px] px-4 py-2 rounded-xl border text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              darkMode
                ? 'border-neutral-700 hover:bg-neutral-900 text-white'
                : 'border-neutral-300 hover:bg-neutral-100 text-black'
            }`}
          >
            <Video className="w-4 h-4" />
            <span>{isRTL ? 'مكالمة مرئية HD' : 'HD Video Call'}</span>
          </button>
        </div>
      </div>

      <div
        className={`rounded-2xl border divide-y ${
          darkMode
            ? 'bg-neutral-950 border-neutral-800 divide-neutral-800'
            : 'bg-white border-neutral-200 divide-neutral-100'
        }`}
      >
        {calls.length === 0 ? (
          <div className="p-8 text-center text-xs text-neutral-500">
            {isRTL ? 'لا توجد مكالمات مسجلة حتى الآن.' : 'No call history yet.'}
          </div>
        ) : (
          calls.map((call) => {
            const matchedChat = chats.find((c) => c.id === call.chatId) || chats[0];
            return (
              <div
                key={call.id}
                className="p-5 flex items-center justify-between gap-4 hover:bg-neutral-50/60 dark:hover:bg-neutral-900/40 transition-colors"
              >
                <div className="flex items-center gap-4 min-w-0">
                  <img
                    src={call.contactAvatar}
                    alt={call.contactName}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full object-cover border border-neutral-300 dark:border-neutral-700 shrink-0"
                  />
                  <div className="min-w-0 space-y-1">
                    <div className="font-bold text-sm truncate">{call.contactName}</div>
                    <div className="flex items-center gap-2 text-xs text-neutral-500">
                      {call.direction === 'incoming' && <PhoneIncoming className="w-3.5 h-3.5" />}
                      {call.direction === 'outgoing' && <PhoneOutgoing className="w-3.5 h-3.5" />}
                      {call.direction === 'missed' && <PhoneMissed className="w-3.5 h-3.5" />}
                      <span>{call.timestamp}</span>
                      <span>·</span>
                      <span className="font-mono tabular-nums">{call.duration}</span>
                      <span>·</span>
                      <span className="flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>E2EE</span>
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => onStartCall(matchedChat, 'voice')}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                      darkMode
                        ? 'border-neutral-800 hover:bg-neutral-900 text-white'
                        : 'border-neutral-200 hover:bg-neutral-100 text-black'
                    }`}
                  >
                    <Phone className="w-4 h-4" />
                    <span className="hidden sm:inline">{isRTL ? 'صوتية' : 'Voice'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onStartCall(matchedChat, 'video')}
                    className={`min-h-[40px] px-3.5 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                      darkMode
                        ? 'border-neutral-800 hover:bg-neutral-900 text-white'
                        : 'border-neutral-200 hover:bg-neutral-100 text-black'
                    }`}
                  >
                    <Video className="w-4 h-4" />
                    <span className="hidden sm:inline">{isRTL ? 'مرئية' : 'Video'}</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
