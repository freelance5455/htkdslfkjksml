import React, { useState } from 'react';
import {
  ShieldCheck,
  Smartphone,
  Laptop,
  Tablet,
  KeyRound,
  RefreshCw,
  Trash2,
  Plus,
  CheckCircle2,
  Lock,
  Cpu,
  DownloadCloud,
} from 'lucide-react';
import { Language, LinkedDevice, UserProfile } from '../types';

interface SecurityDevicesCenterProps {
  lang: Language;
  darkMode: boolean;
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  devices: LinkedDevice[];
  setDevices: React.Dispatch<React.SetStateAction<LinkedDevice[]>>;
  onTriggerNotification: (titleAr: string, titleEn: string, bodyAr: string, bodyEn: string) => void;
}

export const SecurityDevicesCenter: React.FC<SecurityDevicesCenterProps> = ({
  lang,
  darkMode,
  user,
  setUser,
  devices,
  setDevices,
  onTriggerNotification,
}) => {
  const [showLinkDeviceForm, setShowLinkDeviceForm] = useState(false);
  const [newDeviceName, setNewDeviceName] = useState('Galaxy S26 Ultra — Android 16');
  const [newDeviceOS, setNewDeviceOS] = useState('Android 16 (OneUI 8.1)');
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [updateStatus, setUpdateStatus] = useState<'up-to-date' | 'installed'>('up-to-date');

  const isRTL = lang === 'ar';

  const handleAddDevice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeviceName.trim()) return;
    const added: LinkedDevice = {
      id: `dev-${Date.now()}`,
      name: newDeviceName,
      os: newDeviceOS,
      browserOrApp: 'Wissal Native Multi-Sync Client v4.2.0',
      location: isRTL ? 'الرياض، المملكة العربية السعودية' : 'Riyadh, Saudi Arabia',
      ipAddress: '192.168.1.148',
      lastActive: isRTL ? 'متصل الآن (متزامن)' : 'Active Now (Synced)',
      isCurrent: false,
      syncStatus: 'synced',
      trusted: true,
    };
    setDevices((prev) => [added, ...prev]);
    setShowLinkDeviceForm(false);
    onTriggerNotification(
      'تم ربط جهاز جديد بالحساب المشفر',
      'New Device Linked to Encrypted Account',
      `تمت مزامنة المفاتيح والمحادثات فوراً مع ${newDeviceName}`,
      `Cryptographic keys and chats synced immediately with ${newDeviceName}`
    );
  };

  const handleRevokeDevice = (id: string, name: string) => {
    setDevices((prev) => prev.filter((d) => d.id !== id));
    onTriggerNotification(
      'تم إلغاء ربط الجهاز بنجاح',
      'Device Session Revoked',
      `تم إنهاء الجلسة المشفرة ومسح المفاتيح من ${name}`,
      `Terminated E2EE session and wiped keys on ${name}`
    );
  };

  const handleRegenerateCodes = () => {
    const fresh = Array.from({ length: 4 }, () =>
      `WSSL-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(10 + Math.random() * 89)}X`
    );
    setUser((prev) => ({ ...prev, recoveryCodes: fresh }));
  };

  const handleCheckUpdate = () => {
    setCheckingUpdate(true);
    setTimeout(() => {
      setCheckingUpdate(false);
      setUpdateStatus('installed');
      onTriggerNotification(
        'تم تثبيت التحديث الأمني الدوري v4.2.1',
        'Periodic Security Update v4.2.1 Installed',
        'تم تحديث بروتوكولات التشفير وتحسين توافقية أنظمة التشغيل بنجاح.',
        'Updated cryptographic ratchets and cross-OS compatibility.'
      );
    }, 700);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Top Row: Two-Factor Authentication (2FA) & Key Security */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div
          className={`lg:col-span-7 rounded-2xl p-6 border space-y-5 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-start justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                <KeyRound className="w-4 h-4" />
                <span>
                  {isRTL
                    ? 'نظام المصادقة الثنائية (2FA) وحماية المفاتيح'
                    : 'Two-Factor Authentication (2FA) & Key Shield'}
                </span>
              </div>
              <h2 className="text-xl font-bold tracking-tight">
                {isRTL
                  ? 'حماية الحساب بالمصادقة الثنائية (TOTP + مفاتيح الاسترداد)'
                  : 'Account Two-Factor Protection (TOTP + Recovery Keys)'}
              </h2>
            </div>

            <button
              type="button"
              onClick={() =>
                setUser((prev) => ({ ...prev, twoFactorEnabled: !prev.twoFactorEnabled }))
              }
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                user.twoFactorEnabled
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
              }`}
            >
              {user.twoFactorEnabled
                ? isRTL
                  ? 'المصادقة الثنائية: مفعّلة'
                  : '2FA: Enabled'
                : isRTL
                ? 'تفعيل المصادقة الثنائية'
                : 'Enable 2FA'}
            </button>
          </div>

          <p className="text-sm text-slate-600 dark:text-slate-400">
            {isRTL
              ? 'تضمن المصادقة الثنائية عدم قدرة أي شخص على الدخول إلى محادثاتك أو نسخك الاحتياطية السحابية حتى في حال معرفة كلمة المرور.'
              : 'Two-Factor Authentication prevents unauthorized access to your encrypted chats or cloud backups even if your password is compromised.'}
          </p>

          <div
            className={`p-4 rounded-xl border space-y-3 ${
              darkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                {isRTL ? 'رموز الاسترداد الطارئة المشفرة' : 'Encrypted Emergency Recovery Codes'}
              </span>
              <button
                type="button"
                onClick={handleRegenerateCodes}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>{isRTL ? 'توليد رموز جديدة' : 'Regenerate Codes'}</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2" dir="ltr">
              {user.recoveryCodes.map((code) => (
                <div
                  key={code}
                  className={`py-2 px-3 rounded-lg border text-center font-mono text-xs tabular-nums ${
                    darkMode
                      ? 'bg-slate-900 border-slate-800 text-emerald-400'
                      : 'bg-white border-slate-200 text-slate-800'
                  }`}
                >
                  {code}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* OS Compatibility & Periodic Updates Card */}
        <div
          className={`lg:col-span-5 rounded-2xl p-6 border flex flex-col justify-between space-y-4 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                <Cpu className="w-4 h-4" />
                <span>
                  {isRTL ? 'التوافقية والتحديثات الدورية' : 'Cross-OS Compatibility & Updates'}
                </span>
              </div>
              <span className="font-mono text-xs text-slate-400 tabular-nums">
                {updateStatus === 'installed' ? 'v4.2.1-LTS' : 'v4.2.0-LTS'}
              </span>
            </div>

            <h3 className="text-lg font-bold">
              {isRTL
                ? 'توافق كامل مع مختلف إصدارات أنظمة التشغيل'
                : 'Universal Operating System Compatibility'}
            </h3>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-200/70 dark:border-slate-800">
                <span>iOS 15.0 — iOS 19.0 / iPadOS</span>
                <span className="font-mono text-emerald-600 dark:text-emerald-400">Native Metal E2EE</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-200/70 dark:border-slate-800">
                <span>Android 10 — Android 16 (ARM64)</span>
                <span className="font-mono text-emerald-600 dark:text-emerald-400">Verified Zero-Lag</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-200/70 dark:border-slate-800">
                <span>Windows 10 / 11 · macOS · Linux</span>
                <span className="font-mono text-emerald-600 dark:text-emerald-400">Multi-Thread Sync</span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleCheckUpdate}
            disabled={checkingUpdate}
            className="w-full min-h-[44px] py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <DownloadCloud className="w-4 h-4" />
            <span>
              {checkingUpdate
                ? isRTL
                  ? 'جاري فحص وتثبيت التحديثات الأمنية...'
                  : 'Checking & Installing Updates...'
                : updateStatus === 'installed'
                ? isRTL
                  ? 'أحدث إصدار مثبت (v4.2.1) — التحديث التلقائي مفعل'
                  : 'Up to Date (v4.2.1) — Auto-Update Active'
                : isRTL
                ? 'فحص وتثبيت التحديثات الدورية الآن'
                : 'Check & Install Periodic Updates'}
            </span>
          </button>
        </div>
      </div>

      {/* Multi-Device Simultaneous Usage Manager */}
      <div
        className={`rounded-2xl border overflow-hidden ${
          darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold">
              {isRTL
                ? 'الأجهزة المتصلة في وقت واحد (Multi-Device Simultaneous Sync)'
                : 'Simultaneous Multi-Device Sessions'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {isRTL
                ? 'استخدم حسابك عبر الهاتف والحاسوب والجهاز اللوحي في آنٍ واحد مع مزامنة فورية للرسائل والصور المشفرة.'
                : 'Use your account across phone, desktop, and tablet simultaneously with instant encrypted sync.'}
            </p>
          </div>

          <button
            type="button"
            onClick={() => setShowLinkDeviceForm(!showLinkDeviceForm)}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>{isRTL ? 'ربط جهاز إضافي الآن' : 'Link New Device'}</span>
          </button>
        </div>

        {showLinkDeviceForm && (
          <form
            onSubmit={handleAddDevice}
            className={`p-6 border-b grid grid-cols-1 sm:grid-cols-3 gap-4 items-end ${
              darkMode ? 'bg-slate-950/70 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div>
              <label className="block text-xs font-medium mb-1.5">
                {isRTL ? 'اسم الجهاز' : 'Device Name'}
              </label>
              <input
                type="text"
                value={newDeviceName}
                onChange={(e) => setNewDeviceName(e.target.value)}
                className={`w-full h-10 px-3 rounded-xl border text-xs ${
                  darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300'
                }`}
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1.5">
                {isRTL ? 'نظام التشغيل والإصدار' : 'Operating System Version'}
              </label>
              <input
                type="text"
                value={newDeviceOS}
                onChange={(e) => setNewDeviceOS(e.target.value)}
                className={`w-full h-10 px-3 rounded-xl border text-xs ${
                  darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-white border-slate-300'
                }`}
              />
            </div>
            <button
              type="submit"
              className="h-10 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs whitespace-nowrap shrink-0"
            >
              {isRTL ? 'تأكيد المزامنة الفورية' : 'Confirm Instant Sync'}
            </button>
          </form>
        )}

        <div className="divide-y divide-slate-200 dark:divide-slate-800">
          {devices.map((dev) => (
            <div
              key={dev.id}
              className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
            >
              <div className="flex items-start gap-4">
                <div
                  className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                    dev.isCurrent
                      ? 'bg-emerald-500/15 text-emerald-500 border border-emerald-500/30'
                      : darkMode
                      ? 'bg-slate-800 text-slate-300'
                      : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {dev.name.toLowerCase().includes('iphone') ||
                  dev.name.toLowerCase().includes('galaxy') ? (
                    <Smartphone className="w-5 h-5" />
                  ) : dev.name.toLowerCase().includes('ipad') ? (
                    <Tablet className="w-5 h-5" />
                  ) : (
                    <Laptop className="w-5 h-5" />
                  )}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm">{dev.name}</span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                      {dev.lastActive}
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-2">
                    <span>{dev.os}</span>
                    <span>·</span>
                    <span>{dev.browserOrApp}</span>
                    <span>·</span>
                    <span>{dev.location}</span>
                    <span>·</span>
                    <span className="font-mono tabular-nums">{dev.ipAddress}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                {dev.isCurrent ? (
                  <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{isRTL ? 'الجهاز الحالي' : 'Current Device'}</span>
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => handleRevokeDevice(dev.id, dev.name)}
                    className="px-3 py-2 rounded-xl border border-red-500/30 text-red-500 hover:bg-red-500/10 text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isRTL ? 'إنهاء الجلسة' : 'Revoke'}</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
