import React, { useState } from 'react';
import {
  BarChart3,
  Download,
  Lock,
  Image as ImageIcon,
  MessageSquare,
  PhoneCall,
  Zap,
  ShieldCheck,
} from 'lucide-react';
import { CallRecord, ChatConversation, Language, Message } from '../types';

interface AnalyticsCenterProps {
  lang: Language;
  darkMode: boolean;
  chats: ChatConversation[];
  messagesByChat: Record<string, Message[]>;
  calls: CallRecord[];
}

export const AnalyticsCenter: React.FC<AnalyticsCenterProps> = ({
  lang,
  darkMode,
  chats,
  messagesByChat,
  calls,
}) => {
  const [timeframe, setTimeframe] = useState<'7d' | '30d' | '90d'>('7d');
  const [exported, setExported] = useState(false);

  const isRTL = lang === 'ar';

  const allMessages = Object.values(messagesByChat).flat();
  const totalMessages = allMessages.length + (timeframe === '7d' ? 1240 : timeframe === '30d' ? 5480 : 14820);
  const totalPhotos =
    allMessages.filter((m) => m.imageUrl).length + (timeframe === '7d' ? 84 : timeframe === '30d' ? 290 : 642);
  const totalCalls = calls.length + (timeframe === '7d' ? 18 : timeframe === '30d' ? 64 : 195);

  const weeklyActivity = [
    { dayAr: 'السبت', dayEn: 'Sat', messages: 165, photos: 14, latencyMs: 28 },
    { dayAr: 'الأحد', dayEn: 'Sun', messages: 210, photos: 22, latencyMs: 24 },
    { dayAr: 'الإثنين', dayEn: 'Mon', messages: 245, photos: 19, latencyMs: 22 },
    { dayAr: 'الثلاثاء', dayEn: 'Tue', messages: 190, photos: 15, latencyMs: 25 },
    { dayAr: 'الأربعاء', dayEn: 'Wed', messages: 280, photos: 31, latencyMs: 21 },
    { dayAr: 'الخميس', dayEn: 'Thu', messages: 230, photos: 26, latencyMs: 23 },
    { dayAr: 'الجمعة', dayEn: 'Fri', messages: 155, photos: 12, latencyMs: 20 },
  ];

  const handleExportCSV = () => {
    const headers = 'Day,Encrypted_Messages,Shared_Photos,Avg_Delivery_Latency_ms\n';
    const rows = weeklyActivity
      .map((r) => `${r.dayEn},${r.messages},${r.photos},${r.latencyMs}`)
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Wissal_Activity_Analytics_${timeframe}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    setExported(true);
    setTimeout(() => setExported(false), 2500);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Header & Filter Bar */}
      <div
        className={`rounded-2xl p-6 border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 ${
          darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
            <BarChart3 className="w-4 h-4" />
            <span>
              {isRTL
                ? 'تقارير تحليلية حول نشاط المستخدم والأداء المشفر'
                : 'User Activity Analytics & Encrypted Performance Reports'}
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            {isRTL ? 'لوحة إحصائيات النشاط والتشفير' : 'Activity & Encryption Telemetry'}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div
            className={`flex items-center p-1 rounded-xl border ${
              darkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
            }`}
          >
            {(
              [
                { id: '7d', labelAr: 'آخر 7 أيام', labelEn: 'Last 7 Days' },
                { id: '30d', labelAr: '30 يوماً', labelEn: '30 Days' },
                { id: '90d', labelAr: '90 يوماً', labelEn: '90 Days' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setTimeframe(tab.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  timeframe === tab.id
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {isRTL ? tab.labelAr : tab.labelEn}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleExportCSV}
            className="min-h-[40px] px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Download className="w-4 h-4" />
            <span>
              {exported
                ? isRTL
                  ? 'تم تحميل التقرير (CSV)'
                  : 'Exported CSV'
                : isRTL
                ? 'تصدير التقرير التحليلي (CSV)'
                : 'Export Report (CSV)'}
            </span>
          </button>
        </div>
      </div>

      {/* 4 Metric Summary Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          className={`rounded-2xl p-5 border space-y-2 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>{isRTL ? 'إجمالي الرسائل المشفرة' : 'Encrypted Messages'}</span>
            <MessageSquare className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums">
            {totalMessages.toLocaleString()}
          </div>
          <div className="text-xs text-emerald-600 dark:text-emerald-400">
            100% AES-256-GCM E2EE
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 border space-y-2 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>{isRTL ? 'الصور والوسائط المشاركة' : 'Shared Photos & Media'}</span>
            <ImageIcon className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums">
            {totalPhotos.toLocaleString()}
          </div>
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {isRTL ? 'شامل الحماية من تتبع EXIF' : 'Zero-Metadata EXIF Shield'}
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 border space-y-2 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>{isRTL ? 'المكالمات الصوتية والمرئية' : 'Voice & Video Calls'}</span>
            <PhoneCall className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums">{totalCalls}</div>
          <div className="text-xs text-slate-500 dark:text-slate-400">
            {isRTL ? 'تشفير SRTP من الطرف للطرف' : 'SRTP End-to-End Encrypted'}
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 border space-y-2 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>{isRTL ? 'متوسط سرعة توصيل الرسائل' : 'Avg Delivery Latency'}</span>
            <Zap className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums">23 ms</div>
          <div className="text-xs text-emerald-600 dark:text-emerald-400">
            {isRTL ? 'أداء فائق السرعة عبر جميع الأجهزة' : 'Ultra-low latency multi-device'}
          </div>
        </div>
      </div>

      {/* Activity Chart & Conversation Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div
          className={`lg:col-span-7 rounded-2xl p-6 border space-y-5 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-base">
              {isRTL
                ? 'التوزيع اليومي للرسائل المشفرة ومشاركة الصور'
                : 'Daily Encrypted Messages & Photo Sharing Volume'}
            </h2>
            <span className="text-xs text-slate-500 font-mono">AES-256 Stream</span>
          </div>

          <div className="h-56 flex items-end justify-between gap-3 pt-6 px-2 border-b border-slate-200 dark:border-slate-800">
            {weeklyActivity.map((item) => {
              const heightPercent = Math.round((item.messages / 300) * 100);
              const photoHeight = Math.round((item.photos / 45) * 100);
              return (
                <div key={item.dayEn} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                  <div className="w-full flex items-end justify-center gap-1.5 h-40">
                    <div
                      style={{ height: `${heightPercent}%` }}
                      className="w-3 sm:w-4 bg-emerald-600 rounded-t-md transition-all"
                      title={`${item.messages} messages`}
                    />
                    <div
                      style={{ height: `${photoHeight}%` }}
                      className="w-3 sm:w-4 bg-teal-400/80 rounded-t-md transition-all"
                      title={`${item.photos} photos`}
                    />
                  </div>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                    {isRTL ? item.dayAr : item.dayEn}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-emerald-600 inline-block" />
                <span>{isRTL ? 'الرسائل المشفرة' : 'Encrypted Messages'}</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-teal-400 inline-block" />
                <span>{isRTL ? 'الصور المشاركة' : 'Shared Photos'}</span>
              </span>
            </div>
            <span className="font-mono tabular-nums">99.99% Uptime</span>
          </div>
        </div>

        {/* Active Groups & Contacts Engagement */}
        <div
          className={`lg:col-span-5 rounded-2xl p-6 border space-y-4 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <h2 className="font-bold text-base">
            {isRTL ? 'أنشط المحادثات والمجموعات المشفرة' : 'Most Active Encrypted Chats & Groups'}
          </h2>

          <div className="space-y-3">
            {chats.map((c, index) => {
              const count = (messagesByChat[c.id]?.length || 1) * 42 + (4 - index) * 35;
              const pct = Math.min(95, 35 + (4 - index) * 15);
              return (
                <div key={c.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold truncate max-w-[220px]">
                      {isRTL ? c.name : c.nameEn}
                    </span>
                    <span className="font-mono tabular-nums text-slate-500">
                      {count} {isRTL ? 'رسالة' : 'msgs'}
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-emerald-600 rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div
            className={`mt-4 p-3.5 rounded-xl border text-xs flex items-center gap-2.5 ${
              darkMode
                ? 'bg-slate-950/60 border-slate-800 text-slate-300'
                : 'bg-slate-50 border-slate-200 text-slate-600'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
            <span>
              {isRTL
                ? 'تُحسب جميع التحليلات محلياً على جهازك (On-Device Analytics) لضمان الخصوصية التامة.'
                : 'All analytics are computed locally on-device with zero telemetry leakage.'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
