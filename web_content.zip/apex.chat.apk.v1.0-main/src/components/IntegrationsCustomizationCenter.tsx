import React, { useRef, useState } from 'react';
import {
  Palette,
  Bell,
  Moon,
  Sun,
  Globe,
  Check,
  Sliders,
  Hash,
  Camera,
  LogOut,
  Mail,
  Copy,
  ShieldCheck,
} from 'lucide-react';
import {
  ChatThemeColor,
  ChatWallpaper,
  ExternalIntegration,
  Language,
  UserProfile,
} from '../types';
import { updateUserAvatarInFirestore } from '../firebase';

interface IntegrationsCustomizationCenterProps {
  lang: Language;
  setLang: (l: Language) => void;
  darkMode: boolean;
  setDarkMode: (d: boolean) => void;
  themeColor: ChatThemeColor;
  setThemeColor: (c: ChatThemeColor) => void;
  wallpaper: ChatWallpaper;
  setWallpaper: (w: ChatWallpaper) => void;
  fontSize: 'sm' | 'base' | 'lg';
  setFontSize: (s: 'sm' | 'base' | 'lg') => void;
  integrations: ExternalIntegration[];
  setIntegrations: React.Dispatch<React.SetStateAction<ExternalIntegration[]>>;
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  firebaseUid?: string;
  onSignOut?: () => void;
  onTriggerNotification: (titleAr: string, titleEn: string, bodyAr: string, bodyEn: string) => void;
}

export const IntegrationsCustomizationCenter: React.FC<IntegrationsCustomizationCenterProps> = ({
  lang,
  setLang,
  darkMode,
  setDarkMode,
  wallpaper,
  setWallpaper,
  user,
  setUser,
  firebaseUid,
  onSignOut,
  onTriggerNotification,
}) => {
  const [testingWebhook, setTestingWebhook] = useState(false);
  const [copiedId, setCopiedId] = useState(false);
  const avatarInputRef = useRef<HTMLInputElement | null>(null);

  const isRTL = lang === 'ar';

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      if (typeof reader.result === 'string') {
        const dataUrl = reader.result;
        setUser((prev) => {
          const updated = { ...prev, avatar: dataUrl };
          localStorage.setItem(
            'apex_chat_online_session',
            JSON.stringify({ user: updated, uid: firebaseUid || updated.id })
          );
          return updated;
        });
        try {
          await updateUserAvatarInFirestore(firebaseUid || '', dataUrl, user.id);
        } catch {
          // Handled by Firestore error logger
        }
        onTriggerNotification(
          'تم تحديث صورة البروفايل بنجاح',
          'Profile Picture Updated',
          'تم حفظ صورة البروفايل الجديدة في حسابك أونلاين.',
          'Your new profile picture has been saved online.'
        );
      }
    };
    reader.readAsDataURL(file);
  };

  const handleCopyUserId = () => {
    navigator.clipboard.writeText(user.id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleTestInstantNotification = () => {
    setTestingWebhook(true);
    setTimeout(() => {
      setTestingWebhook(false);
      onTriggerNotification(
        'إشعار فوري تجريبي: نظام التنبيهات نشط',
        'Instant Push Alert: Notification Engine Active',
        'يصلك هذا التنبيه الفوري لتأكيد جاهزية الإشعارات والتحديثات.',
        'This real-time alert confirms push notifications are active.'
      );
    }, 300);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Monochrome User Profile Card */}
      <div
        className={`rounded-3xl p-6 border flex flex-col sm:flex-row items-center justify-between gap-6 ${
          darkMode ? 'bg-neutral-950 border-neutral-800' : 'bg-white border-neutral-200 shadow-xs'
        }`}
      >
        <div className="flex flex-col sm:flex-row items-center gap-5">
          <div className="relative shrink-0">
            <input
              ref={avatarInputRef}
              type="file"
              accept="image/*"
              onChange={handleAvatarChange}
              className="hidden"
            />
            <img
              src={user.avatar}
              alt={user.name}
              referrerPolicy="no-referrer"
              className={`w-24 h-24 rounded-full object-cover border-2 shadow-sm ${
                darkMode ? 'border-white' : 'border-black'
              }`}
            />
            <button
              type="button"
              onClick={() => avatarInputRef.current?.click()}
              className={`absolute bottom-0 end-0 p-2 rounded-full shadow-md transition-colors cursor-pointer ${
                darkMode
                  ? 'bg-white text-black hover:bg-neutral-200'
                  : 'bg-black text-white hover:bg-neutral-800'
              }`}
              title={isRTL ? 'تغيير صورة البروفايل' : 'Change Profile Picture'}
            >
              <Camera className="w-4 h-4" />
            </button>
          </div>

          <div className="text-center sm:text-start space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
              <h2 className="text-xl font-bold">{user.name}</h2>
              <button
                type="button"
                onClick={handleCopyUserId}
                className={`px-3 py-1 rounded-xl text-xs font-mono border inline-flex items-center gap-1.5 mx-auto sm:mx-0 transition-colors cursor-pointer ${
                  darkMode
                    ? 'bg-neutral-900 border-neutral-700 text-white hover:bg-neutral-800'
                    : 'bg-neutral-100 border-neutral-300 text-black hover:bg-neutral-200'
                }`}
                title={isRTL ? 'نسخ معرف المستخدم' : 'Copy User ID'}
              >
                <Hash className="w-3.5 h-3.5" />
                <span>ID: {user.id}</span>
                {copiedId ? (
                  <Check className="w-3.5 h-3.5" />
                ) : (
                  <Copy className="w-3.5 h-3.5 opacity-70" />
                )}
              </button>
            </div>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 text-xs text-neutral-500">
              <span className="inline-flex items-center gap-1 font-medium">
                <Mail className="w-3.5 h-3.5" />
                <span>{user.email}</span>
              </span>
              <span>·</span>
              <span className="inline-flex items-center gap-1 font-semibold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{isRTL ? 'متصل أونلاين — Apex Chat' : 'Online — Apex Chat'}</span>
              </span>
            </div>

            <p className="text-xs text-neutral-500">
              {isRTL
                ? 'شارك معرف الـ 10 أرقام الخاص بك مع أصدقائك ليتمكنوا من إضافتك وبدء محادثة.'
                : 'Share your 10-digit ID with friends so they can add you to chat.'}
            </p>
          </div>
        </div>

        {onSignOut && (
          <button
            type="button"
            onClick={onSignOut}
            className={`min-h-[44px] px-4 py-2.5 rounded-xl border text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              darkMode
                ? 'border-neutral-700 hover:bg-neutral-900 text-white'
                : 'border-neutral-300 hover:bg-neutral-100 text-black'
            }`}
          >
            <LogOut className="w-4 h-4" />
            <span>{isRTL ? 'تسجيل الخروج من الحساب' : 'Sign Out'}</span>
          </button>
        )}
      </div>

      {/* Monochrome Settings Panel */}
      <div
        className={`rounded-3xl p-6 border space-y-6 ${
          darkMode ? 'bg-neutral-950 border-neutral-800' : 'bg-white border-neutral-200'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-neutral-200 dark:border-neutral-800 pb-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-neutral-500">
              <Palette className="w-4 h-4" />
              <span>{isRTL ? 'تخصيص المظهر وتجربة المستخدم' : 'Appearance & Experience'}</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight mt-1">
              {isRTL ? 'الإعدادات والمظهر' : 'Settings & Appearance'}
            </h1>
          </div>

          <button
            type="button"
            onClick={handleTestInstantNotification}
            disabled={testingWebhook}
            className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              darkMode
                ? 'bg-white text-black hover:bg-neutral-200'
                : 'bg-black text-white hover:bg-neutral-800'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>{isRTL ? 'اختبار الإشعارات الفورية' : 'Test Push Notification'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Theme Mode */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <Sliders className="w-4 h-4" />
              <span>{isRTL ? 'الوضع الفاتح والليلي' : 'Light & Dark Mode'}</span>
            </h3>

            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setDarkMode(false)}
                className={`h-11 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  !darkMode
                    ? 'bg-black text-white border-black'
                    : 'bg-neutral-900 border-neutral-800 text-neutral-300'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>{isRTL ? 'أبيض (فاتح)' : 'White (Light)'}</span>
              </button>
              <button
                type="button"
                onClick={() => setDarkMode(true)}
                className={`h-11 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  darkMode
                    ? 'bg-white text-black border-white'
                    : 'bg-neutral-50 border-neutral-200 text-neutral-700'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>{isRTL ? 'أسود (داكن)' : 'Black (Dark)'}</span>
              </button>
            </div>
          </div>

          {/* Chat Wallpaper */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold">
              {isRTL ? 'خلفية المحادثة' : 'Chat Wallpaper'}
            </h3>

            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { id: 'minimal', labelAr: 'صافي كلاسيكي', labelEn: 'Clean Minimal' },
                  { id: 'geometric', labelAr: 'نقش هندسي', labelEn: 'Geometric Grid' },
                ] as const
              ).map((w) => (
                <button
                  key={w.id}
                  type="button"
                  onClick={() => setWallpaper(w.id)}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                    wallpaper === w.id
                      ? darkMode
                        ? 'bg-white text-black border-white'
                        : 'bg-black text-white border-black'
                      : darkMode
                      ? 'bg-neutral-900 border-neutral-800 text-neutral-300'
                      : 'bg-neutral-50 border-neutral-200 text-neutral-700'
                  }`}
                >
                  {isRTL ? w.labelAr : w.labelEn}
                </button>
              ))}
            </div>
          </div>

          {/* Language Support */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold flex items-center gap-2">
              <Globe className="w-4 h-4" />
              <span>{isRTL ? 'تعدد اللغات' : 'Multi-Language'}</span>
            </h3>

            <div className="space-y-2">
              {(
                [
                  { id: 'ar', label: 'العربية (Arabic)' },
                  { id: 'en', label: 'English (International)' },
                ] as const
              ).map((l) => (
                <button
                  key={l.id}
                  type="button"
                  onClick={() => setLang(l.id)}
                  className={`w-full py-2.5 px-4 rounded-xl border text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                    lang === l.id
                      ? darkMode
                        ? 'bg-white text-black border-white'
                        : 'bg-black text-white border-black'
                      : darkMode
                      ? 'bg-neutral-900 border-neutral-800 text-neutral-300'
                      : 'bg-neutral-50 border-neutral-200 text-neutral-700'
                  }`}
                >
                  <span>{l.label}</span>
                  {lang === l.id && <Check className="w-4 h-4" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
