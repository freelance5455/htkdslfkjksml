import React, { useEffect, useRef, useState } from 'react';
import {
  Search,
  Lock,
  Phone,
  Video,
  Image as ImageIcon,
  Send,
  CheckCheck,
  Plus,
  X,
  Reply,
  ArrowRight,
  ArrowLeft,
  Hash,
  UserPlus,
  Copy,
  Check,
  MessageSquare,
} from 'lucide-react';
import {
  ChatConversation,
  ChatThemeColor,
  ChatWallpaper,
  Language,
  Message,
  UserProfile,
} from '../types';
import { ASSETS, TRANSLATIONS } from '../data/mockData';
import {
  findUserBy10DigitCode,
  createOnlineChatRoom,
  sendOnlineChatMessage,
} from '../firebase';

interface ChatWorkspaceProps {
  lang: Language;
  darkMode: boolean;
  user: UserProfile;
  chats: ChatConversation[];
  setChats: React.Dispatch<React.SetStateAction<ChatConversation[]>>;
  messagesByChat: Record<string, Message[]>;
  setMessagesByChat: React.Dispatch<React.SetStateAction<Record<string, Message[]>>>;
  activeChatId: string;
  setActiveChatId: (id: string) => void;
  themeColor: ChatThemeColor;
  wallpaper: ChatWallpaper;
  fontSize: 'sm' | 'base' | 'lg';
  onStartCall: (chat: ChatConversation, type: 'voice' | 'video') => void;
  onTriggerAutoSensitiveBackup: () => void;
  showNewGroupModal: boolean;
  setShowNewGroupModal: (b: boolean) => void;
}

export const ChatWorkspace: React.FC<ChatWorkspaceProps> = ({
  lang,
  darkMode,
  user,
  chats,
  setChats,
  messagesByChat,
  setMessagesByChat,
  activeChatId,
  setActiveChatId,
  wallpaper,
  fontSize,
  onStartCall,
  showNewGroupModal,
  setShowNewGroupModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [inputText, setInputText] = useState('');
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [selectedPhotoPreview, setSelectedPhotoPreview] = useState<string>('');
  const [photoCaption, setPhotoCaption] = useState('');
  const [lightboxImage, setLightboxImage] = useState<{ url: string; caption?: string } | null>(
    null
  );
  const [mobileShowChatList, setMobileShowChatList] = useState(true);
  const [copiedMyId, setCopiedMyId] = useState(false);

  // Add Chat Modal states (Name + ID)
  const [contactName, setContactName] = useState('');
  const [contactId, setContactId] = useState('');
  const [lookupStatus, setLookupStatus] = useState<string>('');
  const [addError, setAddError] = useState<string>('');
  const [isAddingChat, setIsAddingChat] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const isRTL = lang === 'ar';
  const t = TRANSLATIONS[lang];

  const activeChat = chats.find((c) => c.id === activeChatId) || chats[0] || null;
  const currentMessages = activeChat ? messagesByChat[activeChat.id] || [] : [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [currentMessages.length, activeChat?.id]);

  // Live lookup when user types 10-digit ID in the Add Chat modal
  useEffect(() => {
    const clean = contactId.trim();
    if (/^[0-9]{10}$/.test(clean)) {
      let cancelled = false;
      findUserBy10DigitCode(clean).then((found) => {
        if (cancelled) return;
        if (found) {
          setLookupStatus(
            isRTL
              ? `تم العثور على الحساب أونلاين: ${found.displayName}`
              : `Found online user: ${found.displayName}`
          );
          if (!contactName.trim()) {
            setContactName(found.displayName);
          }
        } else {
          setLookupStatus('');
        }
      });
      return () => {
        cancelled = true;
      };
    } else {
      setLookupStatus('');
    }
  }, [contactId, isRTL]);

  const filteredChats = chats.filter((c) => {
    const title = isRTL ? c.name : c.nameEn;
    return (
      title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.id.includes(searchQuery.trim()) ||
      (messagesByChat[c.id] || []).some((m) =>
        (m.text || '').toLowerCase().includes(searchQuery.toLowerCase())
      )
    );
  });

  const getBubbleColorClass = () => {
    return darkMode
      ? 'bg-white text-black'
      : 'bg-black text-white';
  };

  const getTextScaleClass = () => {
    if (fontSize === 'sm') return 'text-xs';
    if (fontSize === 'lg') return 'text-base';
    return 'text-sm';
  };

  const handleSelectChat = (id: string) => {
    setActiveChatId(id);
    setMobileShowChatList(false);
    setChats((prev) =>
      prev.map((c) => (c.id === id ? { ...c, unreadCount: 0 } : c))
    );
  };

  const handleCopyMyId = () => {
    navigator.clipboard.writeText(user.id);
    setCopiedMyId(true);
    setTimeout(() => setCopiedMyId(false), 2000);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeChat || !inputText.trim()) return;

    const textToSend = inputText.trim();
    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now
      .getMinutes()
      .toString()
      .padStart(2, '0')}`;

    const newMsg: Message = {
      id: `m-${Date.now()}`,
      chatId: activeChat.id,
      senderId: 'me',
      senderName: user.name,
      text: textToSend,
      timestamp: timeStr,
      status: 'read',
      isEncrypted: true,
      cipherSignature: 'ONLINE-E2EE',
      replyTo: replyingTo
        ? {
            id: replyingTo.id,
            senderName: replyingTo.senderName,
            text: replyingTo.text || (isRTL ? 'صورة' : 'Photo'),
          }
        : undefined,
    };

    setMessagesByChat((prev) => ({
      ...prev,
      [activeChat.id]: [...(prev[activeChat.id] || []), newMsg],
    }));

    setInputText('');
    setReplyingTo(null);

    await sendOnlineChatMessage({
      senderCode: user.id,
      senderName: user.name,
      recipientCode: activeChat.id,
      text: textToSend,
      timestamp: timeStr,
    });
  };

  const handleFileUploadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setSelectedPhotoPreview(reader.result);
        setShowPhotoModal(true);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSendPhoto = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeChat || !selectedPhotoPreview) return;

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now
      .getMinutes()
      .toString()
      .padStart(2, '0')}`;

    const captionText = photoCaption.trim();
    const photoMsg: Message = {
      id: `m-img-${Date.now()}`,
      chatId: activeChat.id,
      senderId: 'me',
      senderName: user.name,
      imageUrl: selectedPhotoPreview,
      imageCaption: captionText || undefined,
      timestamp: timeStr,
      status: 'read',
      isEncrypted: true,
      cipherSignature: 'ONLINE-E2EE',
    };

    setMessagesByChat((prev) => ({
      ...prev,
      [activeChat.id]: [...(prev[activeChat.id] || []), photoMsg],
    }));

    const imgToSend = selectedPhotoPreview;
    setPhotoCaption('');
    setSelectedPhotoPreview('');
    setShowPhotoModal(false);

    await sendOnlineChatMessage({
      senderCode: user.id,
      senderName: user.name,
      recipientCode: activeChat.id,
      imageUrl: imgToSend,
      imageCaption: captionText || undefined,
      timestamp: timeStr,
    });
  };

  const handleAddChatByNameAndId = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddError('');

    const cleanName = contactName.trim();
    const cleanId = contactId.trim();

    if (!cleanName || !cleanId) {
      setAddError(
        isRTL ? 'يرجى إدخال الاسم والـ ID معاً.' : 'Please enter both Name and ID.'
      );
      return;
    }

    setIsAddingChat(true);
    try {
      const { targetUser } = await createOnlineChatRoom(user.id, cleanId, cleanName);
      const foundOnline = targetUser || (await findUserBy10DigitCode(cleanId));

      const created: ChatConversation = {
        id: cleanId,
        name: cleanName,
        nameEn: cleanName,
        isGroup: false,
        avatar: foundOnline?.photoURL || ASSETS.avatarUser2,
        online: true,
        unreadCount: 0,
        encryptionFingerprint: `ID: ${cleanId}`,
        encryptionProtocol: 'Signal Double-Ratchet + AES-256-GCM',
        description: `ID: ${cleanId}`,
      };

      setChats((prev) => {
        const exists = prev.some((c) => c.id === cleanId);
        if (exists) {
          return prev.map((c) =>
            c.id === cleanId ? { ...c, name: cleanName, nameEn: cleanName } : c
          );
        }
        return [created, ...prev];
      });

      setActiveChatId(cleanId);
      setMobileShowChatList(false);
      setContactName('');
      setContactId('');
      setLookupStatus('');
      setShowNewGroupModal(false);
    } finally {
      setIsAddingChat(false);
    }
  };

  return (
    <div className="flex-1 min-h-0 flex h-full w-full overflow-hidden relative">
      {/* Left/Right Conversation History Sidebar (سجل المحادثات) */}
      <aside
        className={`${
          mobileShowChatList || !activeChat ? 'flex' : 'hidden md:flex'
        } w-full md:w-85 lg:w-96 flex-col border-e shrink-0 ${
          darkMode ? 'bg-black border-neutral-800' : 'bg-white border-neutral-200'
        }`}
      >
        {/* Top Header of Chat History: Title + User's 10-digit ID + Add Chat button */}
        <div className="p-4 space-y-3 border-b border-neutral-200 dark:border-neutral-800">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="font-bold text-base">
                {isRTL ? 'سجل المحادثات' : 'Chats'}
              </h2>
              <button
                type="button"
                onClick={handleCopyMyId}
                className="mt-0.5 inline-flex items-center gap-1 text-[11px] font-mono text-neutral-600 dark:text-neutral-400 hover:underline"
                title={isRTL ? 'انسخ الـ ID الخاص بك' : 'Copy your ID'}
              >
                <Hash className="w-3 h-3" />
                <span>ID: {user.id}</span>
                {copiedMyId ? (
                  <Check className="w-3 h-3" />
                ) : (
                  <Copy className="w-3 h-3 opacity-75" />
                )}
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setAddError('');
                setShowNewGroupModal(true);
              }}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                darkMode
                  ? 'bg-white text-black hover:bg-neutral-200'
                  : 'bg-black text-white hover:bg-neutral-800'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>{isRTL ? 'أضف محادثة' : 'Add Chat'}</span>
            </button>
          </div>

          {/* Search by Name or 10-Digit ID */}
          <div className="relative">
            <Search className="w-4 h-4 absolute top-3 start-3.5 text-neutral-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isRTL
                  ? 'ابحث في المحادثات أو اكتب ID من 10 أرقام...'
                  : 'Search chats or enter 10-digit ID...'
              }
              className={`w-full h-10 ps-10 pe-3 rounded-xl border text-xs focus:outline-none focus:ring-2 ${
                darkMode
                  ? 'bg-neutral-950 border-neutral-800 text-white placeholder:text-neutral-500 focus:ring-white'
                  : 'bg-neutral-50 border-neutral-200 text-black placeholder:text-neutral-400 focus:ring-black'
              }`}
            />
          </div>

          {/* Quick Add when typing a 10-digit ID in Search */}
          {searchQuery.trim().length === 10 &&
            /^[0-9]{10}$/.test(searchQuery.trim()) &&
            !chats.some((c) => c.id === searchQuery.trim()) && (
              <button
                type="button"
                onClick={() => {
                  setContactId(searchQuery.trim());
                  setSearchQuery('');
                  setShowNewGroupModal(true);
                }}
                className={`w-full py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  darkMode
                    ? 'bg-white text-black hover:bg-neutral-200'
                    : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                <UserPlus className="w-4 h-4" />
                <span>
                  {isRTL
                    ? `إضافة محادثة مع ID (${searchQuery.trim()})`
                    : `Add chat with ID (${searchQuery.trim()})`}
                </span>
              </button>
            )}
        </div>

        {/* Conversations List */}
        <div className="flex-1 overflow-y-auto p-3.5 space-y-2.5">
          {filteredChats.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-3">
              <div
                className={`w-14 h-14 rounded-2xl flex items-center justify-center border ${
                  darkMode
                    ? 'bg-neutral-900 border-neutral-800 text-white'
                    : 'bg-neutral-100 border-neutral-200 text-black'
                }`}
              >
                <MessageSquare className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h3 className="font-bold text-sm">
                  {isRTL ? 'سجل المحادثات فارغ حالياً' : 'No Conversations Yet'}
                </h3>
                <p className="text-xs text-neutral-500 leading-relaxed max-w-xs">
                  {isRTL
                    ? 'اضغط على زر "أضف محادثة" وأدخل الاسم والـ ID الخاص بصديقك لبدء المحادثة أونلاين.'
                    : 'Click "Add Chat" and enter your contact’s Name and ID to start chatting online.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setAddError('');
                  setShowNewGroupModal(true);
                }}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  darkMode
                    ? 'bg-white text-black hover:bg-neutral-200'
                    : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                <Plus className="w-4 h-4" />
                <span>{isRTL ? 'أضف محادثة جديدة' : 'Add New Chat'}</span>
              </button>
            </div>
          ) : (
            filteredChats.map((chat) => {
              const chatMsgs = messagesByChat[chat.id] || [];
              const lastMsg = chatMsgs[chatMsgs.length - 1];
              const isSelected = activeChat && chat.id === activeChat.id;

              return (
                <button
                  key={chat.id}
                  type="button"
                  onClick={() => handleSelectChat(chat.id)}
                  className={`w-full p-3.5 rounded-2xl border text-start transition-all flex items-center gap-3.5 cursor-pointer ${
                    isSelected
                      ? darkMode
                        ? 'bg-neutral-900 border-white'
                        : 'bg-neutral-100 border-black'
                      : darkMode
                      ? 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                      : 'bg-white border-neutral-200 hover:border-neutral-400'
                  }`}
                >
                  <div className="relative shrink-0">
                    <img
                      src={chat.avatar || ASSETS.avatarUser2}
                      alt={chat.name}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-full object-cover border border-neutral-300 dark:border-neutral-700"
                    />
                    <span
                      className={`absolute bottom-0 end-0 w-3 h-3 rounded-full border-2 ${
                        darkMode
                          ? 'bg-white border-black'
                          : 'bg-black border-white'
                      }`}
                    />
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-sm truncate">
                        {isRTL ? chat.name : chat.nameEn}
                      </span>
                      <span className="font-mono text-[11px] text-neutral-400 tabular-nums shrink-0">
                        {lastMsg ? lastMsg.timestamp : ''}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs text-neutral-500 truncate">
                        {lastMsg?.imageUrl
                          ? isRTL
                            ? '📷 صورة'
                            : '📷 Photo'
                          : lastMsg?.text || `ID: ${chat.id}`}
                      </p>
                      {chat.unreadCount > 0 && (
                        <span
                          className={`px-2 py-0.5 text-[11px] font-mono font-bold rounded-full tabular-nums ${
                            darkMode ? 'bg-white text-black' : 'bg-black text-white'
                          }`}
                        >
                          {chat.unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </aside>

      {/* Main Active Conversation Stage */}
      <section
        className={`${
          !mobileShowChatList && activeChat ? 'flex' : 'hidden md:flex'
        } flex-1 flex-col min-w-0 h-full`}
      >
        {!activeChat ? (
          <div
            className={`flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4 ${
              darkMode ? 'bg-black' : 'bg-neutral-50'
            }`}
          >
            <div
              className={`w-16 h-16 rounded-2xl flex items-center justify-center font-bold text-2xl ${
                darkMode ? 'bg-white text-black' : 'bg-black text-white'
              }`}
            >
              AC
            </div>
            <div className="space-y-1.5 max-w-sm">
              <h2 className="text-lg font-bold">
                {isRTL ? 'مرحباً بك في Apex Chat' : 'Welcome to Apex Chat'}
              </h2>
              <p className="text-xs text-neutral-500 leading-relaxed">
                {isRTL
                  ? 'اختر محادثة من السجل أو اضغط على "أضف محادثة" لإضافة صديقك بالاسم والـ ID والتحدث معه أونلاين مباشرة.'
                  : 'Select a conversation or click "Add Chat" to add a contact by Name and ID.'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setAddError('');
                setShowNewGroupModal(true);
              }}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-colors cursor-pointer ${
                darkMode
                  ? 'bg-white text-black hover:bg-neutral-200'
                  : 'bg-black text-white hover:bg-neutral-800'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>{isRTL ? 'أضف محادثة (الاسم + ID)' : 'Add Chat (Name + ID)'}</span>
            </button>
          </div>
        ) : (
          <>
            {/* Conversation Top Header */}
            <div
              className={`h-16 px-4 sm:px-6 border-b flex items-center justify-between gap-4 shrink-0 ${
                darkMode ? 'bg-black border-neutral-800' : 'bg-white border-neutral-200'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <button
                  type="button"
                  onClick={() => setMobileShowChatList(true)}
                  className="md:hidden p-2 rounded-lg border border-neutral-200 dark:border-neutral-800"
                  title={isRTL ? 'سجل المحادثات' : 'Back to Chats'}
                >
                  {isRTL ? (
                    <ArrowRight className="w-4 h-4" />
                  ) : (
                    <ArrowLeft className="w-4 h-4" />
                  )}
                </button>
                <img
                  src={activeChat.avatar || ASSETS.avatarUser2}
                  alt={activeChat.name}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full object-cover border border-neutral-300 dark:border-neutral-700 shrink-0"
                />
                <div className="min-w-0">
                  <h2 className="font-bold text-sm sm:text-base truncate">
                    {isRTL ? activeChat.name : activeChat.nameEn}
                  </h2>
                  <div className="flex items-center gap-2 text-xs text-neutral-500 font-mono truncate">
                    <span>ID: {activeChat.id}</span>
                    <span>·</span>
                    <span>{isRTL ? 'متصل أونلاين' : 'Online'}</span>
                  </div>
                </div>
              </div>

              {/* Voice & Video Call Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => onStartCall(activeChat, 'voice')}
                  className={`min-h-[38px] px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    darkMode
                      ? 'border-neutral-800 hover:bg-neutral-900 text-white'
                      : 'border-neutral-200 hover:bg-neutral-100 text-black'
                  }`}
                >
                  <Phone className="w-4 h-4" />
                  <span className="hidden sm:inline">{t.voiceCall}</span>
                </button>

                <button
                  type="button"
                  onClick={() => onStartCall(activeChat, 'video')}
                  className={`min-h-[38px] px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                    darkMode
                      ? 'border-neutral-800 hover:bg-neutral-900 text-white'
                      : 'border-neutral-200 hover:bg-neutral-100 text-black'
                  }`}
                >
                  <Video className="w-4 h-4" />
                  <span className="hidden sm:inline">{t.videoCall}</span>
                </button>
              </div>
            </div>

            {/* Messages Stream Area */}
            <div
              className={`flex-1 overflow-y-auto p-4 sm:p-6 space-y-3.5 ${
                darkMode ? 'bg-neutral-950' : 'bg-neutral-50'
              }`}
              style={
                wallpaper === 'geometric'
                  ? {
                      backgroundImage:
                        'linear-gradient(to right, rgba(120, 120, 120, 0.08) 1px, transparent 1px), linear-gradient(to bottom, rgba(120, 120, 120, 0.08) 1px, transparent 1px)',
                      backgroundSize: '32px 32px',
                    }
                  : undefined
              }
            >
              {currentMessages.length === 0 && (
                <div className="text-center py-8">
                  <span
                    className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs border ${
                      darkMode
                        ? 'bg-neutral-900 border-neutral-800 text-neutral-400'
                        : 'bg-white border-neutral-200 text-neutral-600'
                    }`}
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>
                      {isRTL
                        ? `ابدأ المحادثة الآن مع ${activeChat.name} (ID: ${activeChat.id})`
                        : `Start chatting online with ${activeChat.name} (ID: ${activeChat.id})`}
                    </span>
                  </span>
                </div>
              )}

              {currentMessages.map((msg) => {
                const isMe = msg.senderId === 'me';
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-xl sm:max-w-2xl rounded-2xl p-3.5 space-y-1.5 relative group ${
                        isMe
                          ? getBubbleColorClass()
                          : darkMode
                          ? 'bg-neutral-900 border border-neutral-800 text-white'
                          : 'bg-white border border-neutral-200 text-black shadow-2xs'
                      }`}
                    >
                      {msg.replyTo && (
                        <div
                          className={`p-2 rounded-lg text-xs border ${
                            isMe
                              ? darkMode
                                ? 'bg-neutral-100 border-neutral-300 text-black'
                                : 'bg-neutral-800 border-neutral-700 text-white'
                              : darkMode
                              ? 'bg-black border-neutral-800 text-neutral-300'
                              : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                          }`}
                        >
                          <div className="font-semibold">{msg.replyTo.senderName}</div>
                          <div className="truncate opacity-80">{msg.replyTo.text}</div>
                        </div>
                      )}

                      {msg.imageUrl && (
                        <div className="space-y-1.5">
                          <div
                            onClick={() =>
                              setLightboxImage({
                                url: msg.imageUrl!,
                                caption: msg.imageCaption,
                              })
                            }
                            className="rounded-xl overflow-hidden cursor-pointer border border-black/10 dark:border-white/10 max-h-80 bg-black"
                          >
                            <img
                              src={msg.imageUrl}
                              alt={msg.imageCaption || 'Photo'}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                          </div>
                          {msg.imageCaption && (
                            <p className={`${getTextScaleClass()} leading-relaxed`}>
                              {msg.imageCaption}
                            </p>
                          )}
                        </div>
                      )}

                      {msg.text && (
                        <p
                          className={`${getTextScaleClass()} leading-relaxed whitespace-pre-wrap`}
                        >
                          {msg.text}
                        </p>
                      )}

                      <div
                        className={`flex items-center justify-between gap-3 pt-1 text-[11px] ${
                          isMe
                            ? darkMode
                              ? 'text-neutral-600'
                              : 'text-neutral-300'
                            : 'text-neutral-400'
                        }`}
                      >
                        <span className="font-mono tabular-nums">{msg.timestamp}</span>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setReplyingTo(msg)}
                            className="opacity-70 hover:opacity-100 transition-opacity"
                            title={isRTL ? 'رد' : 'Reply'}
                          >
                            <Reply className="w-3.5 h-3.5" />
                          </button>
                          {isMe && <CheckCheck className="w-3.5 h-3.5" />}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Replying Bar */}
            {replyingTo && (
              <div
                className={`px-4 py-2 border-t flex items-center justify-between text-xs ${
                  darkMode
                    ? 'bg-neutral-900 border-neutral-800 text-neutral-300'
                    : 'bg-neutral-100 border-neutral-200 text-neutral-700'
                }`}
              >
                <div className="truncate">
                  <span className="font-bold me-2">
                    {isRTL
                      ? `الرد على ${replyingTo.senderName}:`
                      : `Replying to ${replyingTo.senderName}:`}
                  </span>
                  <span>{replyingTo.text || (isRTL ? 'صورة' : 'Photo')}</span>
                </div>
                <button
                  type="button"
                  onClick={() => setReplyingTo(null)}
                  className="p-1 hover:opacity-75"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Message Input Bar */}
            <form
              onSubmit={handleSendMessage}
              className={`p-3 sm:p-4 border-t flex items-center gap-2.5 shrink-0 ${
                darkMode ? 'bg-black border-neutral-800' : 'bg-white border-neutral-200'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUploadChange}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className={`h-11 px-3.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer ${
                  darkMode
                    ? 'border-neutral-800 bg-neutral-900 text-white hover:border-white'
                    : 'border-neutral-200 bg-neutral-50 text-black hover:border-black'
                }`}
                title={t.sendPhoto}
              >
                <ImageIcon className="w-4 h-4" />
                <span className="hidden sm:inline">{t.sendPhoto}</span>
              </button>

              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={t.typeMessage}
                className={`flex-1 h-11 px-4 rounded-xl border text-sm focus:outline-none focus:ring-2 ${
                  darkMode
                    ? 'bg-neutral-950 border-neutral-800 text-white placeholder:text-neutral-500 focus:ring-white'
                    : 'bg-neutral-50 border-neutral-200 text-black placeholder:text-neutral-400 focus:ring-black'
                }`}
              />

              <button
                type="submit"
                className={`min-w-[44px] h-11 px-5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-colors shrink-0 cursor-pointer ${
                  darkMode
                    ? 'bg-white text-black hover:bg-neutral-200'
                    : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">{isRTL ? 'إرسال' : 'Send'}</span>
              </button>
            </form>
          </>
        )}
      </section>

      {/* Photo Upload Preview Modal */}
      {showPhotoModal && selectedPhotoPreview && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-2xl border p-6 space-y-4 ${
              darkMode
                ? 'bg-neutral-950 border-neutral-800 text-white'
                : 'bg-white border-neutral-200 text-black'
            }`}
          >
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base">
                {isRTL ? 'إرسال صورة' : 'Send Photo'}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setShowPhotoModal(false);
                  setSelectedPhotoPreview('');
                }}
                className="p-1.5 rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="rounded-xl overflow-hidden border border-neutral-200 dark:border-neutral-800 max-h-64 bg-black">
              <img
                src={selectedPhotoPreview}
                alt="Preview"
                className="w-full h-full object-contain max-h-64"
              />
            </div>

            <form onSubmit={handleSendPhoto} className="space-y-3">
              <input
                type="text"
                value={photoCaption}
                onChange={(e) => setPhotoCaption(e.target.value)}
                placeholder={isRTL ? 'أضف تعليقاً مع الصورة...' : 'Add a caption...'}
                className={`w-full h-11 px-3.5 rounded-xl border text-sm ${
                  darkMode
                    ? 'bg-black border-neutral-800 text-white'
                    : 'bg-neutral-50 border-neutral-300 text-black'
                }`}
              />

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowPhotoModal(false);
                    setSelectedPhotoPreview('');
                  }}
                  className="px-4 py-2.5 rounded-xl border border-neutral-300 dark:border-neutral-700 text-xs font-semibold"
                >
                  {isRTL ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 ${
                    darkMode
                      ? 'bg-white text-black hover:bg-neutral-200'
                      : 'bg-black text-white hover:bg-neutral-800'
                  }`}
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isRTL ? 'إرسال الصورة' : 'Send Photo'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Chat Modal: Ask for Name and ID */}
      {showNewGroupModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl border p-6 space-y-5 shadow-xl ${
              darkMode
                ? 'bg-neutral-950 border-neutral-800 text-white'
                : 'bg-white border-neutral-200 text-black'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                    darkMode ? 'bg-white text-black' : 'bg-black text-white'
                  }`}
                >
                  <UserPlus className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base">
                  {isRTL ? 'إضافة محادثة جديدة' : 'Add New Chat'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowNewGroupModal(false)}
                className="p-1.5 rounded-lg hover:bg-neutral-200 dark:hover:bg-neutral-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {addError && (
              <div className="p-3 rounded-xl border border-neutral-300 dark:border-neutral-700 text-xs font-semibold">
                {addError}
              </div>
            )}

            <form onSubmit={handleAddChatByNameAndId} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold mb-1.5">
                  {isRTL ? 'الاسم' : 'Name'}
                </label>
                <input
                  type="text"
                  required
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  placeholder={isRTL ? 'أدخل اسم الشخص...' : 'Enter contact name...'}
                  className={`w-full h-11 px-3.5 rounded-xl border text-sm focus:outline-none focus:ring-2 ${
                    darkMode
                      ? 'bg-black border-neutral-800 text-white focus:ring-white'
                      : 'bg-neutral-50 border-neutral-300 text-black focus:ring-black'
                  }`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold mb-1.5">
                  {isRTL ? 'معرف الشخص (ID)' : 'User ID'}
                </label>
                <input
                  type="text"
                  required
                  value={contactId}
                  onChange={(e) => setContactId(e.target.value)}
                  placeholder={
                    isRTL ? 'أدخل رقم الـ ID (مثلاً 10 أرقام)...' : 'Enter 10-digit User ID...'
                  }
                  className={`w-full h-11 px-3.5 rounded-xl border text-sm font-mono focus:outline-none focus:ring-2 ${
                    darkMode
                      ? 'bg-black border-neutral-800 text-white focus:ring-white'
                      : 'bg-neutral-50 border-neutral-300 text-black focus:ring-black'
                  }`}
                />
                {lookupStatus && (
                  <p className="mt-1.5 text-xs font-semibold">
                    {lookupStatus}
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={isAddingChat}
                className={`w-full py-3 rounded-xl text-xs font-bold transition-colors cursor-pointer disabled:opacity-60 ${
                  darkMode
                    ? 'bg-white text-black hover:bg-neutral-200'
                    : 'bg-black text-white hover:bg-neutral-800'
                }`}
              >
                {isAddingChat
                  ? isRTL
                    ? 'جاري إضافة المحادثة...'
                    : 'Adding Chat...'
                  : isRTL
                  ? 'إضافة وبدء المحادثة'
                  : 'Add & Start Chat'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Lightbox Image Inspection Modal */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex flex-col items-center justify-center p-4"
        >
          <div
            className="max-w-4xl w-full space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-end text-white text-xs">
              <button
                type="button"
                onClick={() => setLightboxImage(null)}
                className="p-2 rounded-lg bg-white/10 hover:bg-white/20"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <img
              src={lightboxImage.url}
              alt={lightboxImage.caption || 'Full view'}
              referrerPolicy="no-referrer"
              className="w-full max-h-[75vh] object-contain rounded-2xl border border-white/15"
            />
            {lightboxImage.caption && (
              <p className="text-center text-sm text-neutral-200">
                {lightboxImage.caption}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
