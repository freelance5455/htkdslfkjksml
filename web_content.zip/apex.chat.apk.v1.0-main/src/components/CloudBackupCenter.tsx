import React, { useState } from 'react';
import {
  Cloud,
  ShieldCheck,
  Lock,
  RefreshCw,
  Download,
  CheckCircle2,
  KeyRound,
  HardDrive,
  FileSpreadsheet,
  Sparkles,
} from 'lucide-react';
import { CloudBackupSnapshot, Language, UserProfile } from '../types';

interface CloudBackupCenterProps {
  lang: Language;
  darkMode: boolean;
  user: UserProfile;
  setUser: React.Dispatch<React.SetStateAction<UserProfile>>;
  backups: CloudBackupSnapshot[];
  onCreateBackup: (includesSensitive: boolean, trigger: 'manual' | 'auto') => void;
  onRestoreBackup: (snapshot: CloudBackupSnapshot) => void;
}

export const CloudBackupCenter: React.FC<CloudBackupCenterProps> = ({
  lang,
  darkMode,
  user,
  setUser,
  backups,
  onCreateBackup,
  onRestoreBackup,
}) => {
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [backupProgress, setBackupProgress] = useState(0);
  const [customPassphrase, setCustomPassphrase] = useState('WISSAL-VAULT-KEY-2026');
  const [restoredId, setRestoredId] = useState<string | null>(null);

  const isRTL = lang === 'ar';

  const triggerManualBackup = () => {
    if (isBackingUp) return;
    setIsBackingUp(true);
    setBackupProgress(15);
    const interval = setInterval(() => {
      setBackupProgress((prev) => {
        if (prev >= 95) {
          clearInterval(interval);
          return 100;
        }
        return prev + 25;
      });
    }, 180);

    setTimeout(() => {
      onCreateBackup(user.encryptSensitiveBackups, 'manual');
      setIsBackingUp(false);
      setBackupProgress(0);
    }, 850);
  };

  const handleRestore = (snap: CloudBackupSnapshot) => {
    setRestoredId(snap.id);
    onRestoreBackup(snap);
    setTimeout(() => setRestoredId(null), 3000);
  };

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-6">
      {/* Header Banner */}
      <div
        className={`rounded-2xl p-6 border flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6 ${
          darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
            <Cloud className="w-4 h-4" />
            <span>
              {isRTL
                ? 'التخزين السحابي الآمن والنسخ الاحتياطي التلقائي للبيانات الحساسة'
                : 'Zero-Knowledge Cloud Storage & Sensitive Data Auto-Backup'}
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">
            {isRTL
              ? 'مركز النسخ الاحتياطي السحابي المشفر (AES-256-GCM)'
              : 'Encrypted Cloud Backup Vault (AES-256-GCM)'}
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 max-w-2xl">
            {isRTL
              ? 'يتم تشفير جميع الرسائل والصور والبيانات الحساسة محلياً على جهازك قبل رفعها إلى السحابة، بحيث لا يمكن لأي خادم خارجي فك تشفيرها بدون مفتاحك الخاص.'
              : 'All messages, photos, and sensitive records are encrypted locally on your device prior to cloud upload.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={triggerManualBackup}
            disabled={isBackingUp}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-60 text-white font-semibold text-sm flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${isBackingUp ? 'animate-spin' : ''}`} />
            <span>
              {isBackingUp
                ? isRTL
                  ? `جاري التشفير والرفع (${backupProgress}%)...`
                  : `Encrypting & Uploading (${backupProgress}%)...`
                : isRTL
                ? 'نسخ احتياطي سحابي فوري الآن'
                : 'Back Up to Cloud Now'}
            </span>
          </button>
        </div>
      </div>

      {/* Configuration Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Storage Quota & Sensitive Vault */}
        <div
          className={`rounded-2xl p-6 border space-y-5 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-base">
              {isRTL ? 'مساحة التخزين السحابي المشفر' : 'Encrypted Cloud Quota'}
            </h2>
            <HardDrive className="w-5 h-5 text-emerald-500" />
          </div>

          <div className="space-y-2">
            <div className="flex items-baseline justify-between text-sm">
              <span className="text-slate-500 dark:text-slate-400">
                {isRTL ? 'المستخدم حالياً' : 'Currently Used'}
              </span>
              <span className="font-mono font-bold tabular-nums">
                4.82 GB / 100 GB
              </span>
            </div>
            <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
              <div className="h-full bg-emerald-500 rounded-full" style={{ width: '18%' }} />
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-1">
              <span>{isRTL ? 'الصور والوسائط: 3.9 GB' : 'Photos & Media: 3.9 GB'}</span>
              <span>·</span>
              <span>{isRTL ? 'الرسائل الحساسة: 0.92 GB' : 'Sensitive Vault: 0.92 GB'}</span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <label className="flex items-center justify-between cursor-pointer text-sm">
              <div>
                <div className="font-semibold">
                  {isRTL ? 'خزنة البيانات الحساسة التلقائية' : 'Sensitive Data Auto-Vault'}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  {isRTL
                    ? 'نسخ فوري للرسائل المصنفة كحساسة بمفتاح مزدوج'
                    : 'Instant dual-key backup for sensitive messages'}
                </div>
              </div>
              <input
                type="checkbox"
                checked={user.encryptSensitiveBackups}
                onChange={(e) =>
                  setUser((prev) => ({ ...prev, encryptSensitiveBackups: e.target.checked }))
                }
                className="w-4 h-4 accent-emerald-600"
              />
            </label>
          </div>
        </div>

        {/* Auto-Backup Schedule */}
        <div
          className={`rounded-2xl p-6 border space-y-4 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-base">
              {isRTL ? 'جدولة النسخ الاحتياطي التلقائي' : 'Automated Backup Schedule'}
            </h2>
            <ShieldCheck className="w-5 h-5 text-emerald-500" />
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isRTL
              ? 'اختر وتيرة النسخ الاحتياطي التلقائي للرسائل والصور عبر جميع أجهزتك المتصلة:'
              : 'Select how frequently messages and photos are backed up across devices:'}
          </p>

          <div className="grid grid-cols-2 gap-2.5">
            {(
              [
                { id: 'realtime', labelAr: 'فوري (لحظي)', labelEn: 'Real-Time' },
                { id: 'daily', labelAr: 'يومياً (11:00 م)', labelEn: 'Daily (23:00)' },
                { id: 'weekly', labelAr: 'أسبوعياً', labelEn: 'Weekly' },
                { id: 'manual', labelAr: 'يدوي فقط', labelEn: 'Manual Only' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setUser((prev) => ({ ...prev, autoBackupFrequency: opt.id }))}
                className={`py-2.5 px-3 rounded-xl border text-xs font-semibold transition-all whitespace-nowrap shrink-0 ${
                  user.autoBackupFrequency === opt.id
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : darkMode
                    ? 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:border-slate-300'
                }`}
              >
                {isRTL ? opt.labelAr : opt.labelEn}
              </button>
            ))}
          </div>

          <div className="pt-2 text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>
              {isRTL
                ? 'النسخ التلقائي يعمل في الخلفية دون التأثير على سرعة الأداء.'
                : 'Runs seamlessly in background with zero performance impact.'}
            </span>
          </div>
        </div>

        {/* Private Encryption Passphrase */}
        <div
          className={`rounded-2xl p-6 border space-y-4 ${
            darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <h2 className="font-bold text-base">
              {isRTL ? 'مفتاح فك التشفير السحابي الخاص' : 'Zero-Knowledge Backup Key'}
            </h2>
            <KeyRound className="w-5 h-5 text-emerald-500" />
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isRTL
              ? 'مفتاح مخصص لتشفير أرشيف المحادثات الحساسة قبل تخزينها في السحابة:'
              : 'Dedicated cryptographic passphrase protecting your cloud archive:'}
          </p>

          <input
            type="text"
            dir="ltr"
            value={customPassphrase}
            onChange={(e) => setCustomPassphrase(e.target.value)}
            className={`w-full h-11 px-3.5 rounded-xl border font-mono text-xs focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
              darkMode
                ? 'bg-slate-950 border-slate-800 text-emerald-400'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}
          />

          <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
            PBKDF2-HMAC-SHA512 · 600,000 Iterations
          </div>
        </div>
      </div>

      {/* Snapshots History Table */}
      <div
        className={`rounded-2xl border overflow-hidden ${
          darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}
      >
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h3 className="font-bold text-base">
            {isRTL ? 'سجل النسخ الاحتياطية السحابية المشفرة' : 'Encrypted Cloud Snapshot History'}
          </h3>
          <span className="text-xs text-slate-500 font-mono tabular-nums">
            {backups.length} {isRTL ? 'نسخ محفوظة' : 'Snapshots'}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-start">
            <thead
              className={`text-xs border-b ${
                darkMode
                  ? 'bg-slate-950/60 border-slate-800 text-slate-400'
                  : 'bg-slate-50 border-slate-200 text-slate-500'
              }`}
            >
              <tr>
                <th className="py-3 px-6 text-start font-medium">
                  {isRTL ? 'تاريخ ووقت النسخة' : 'Timestamp'}
                </th>
                <th className="py-3 px-6 text-start font-medium">
                  {isRTL ? 'عدد الرسائل والصور' : 'Messages & Photos'}
                </th>
                <th className="py-3 px-6 text-start font-medium">
                  {isRTL ? 'خزنة البيانات الحساسة' : 'Sensitive Vault'}
                </th>
                <th className="py-3 px-6 text-start font-medium">
                  {isRTL ? 'خوارزمية التشفير' : 'Cipher Key'}
                </th>
                <th className="py-3 px-6 text-end font-medium">
                  {isRTL ? 'الحجم والإجراء' : 'Size & Action'}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
              {backups.map((snap) => (
                <tr
                  key={snap.id}
                  className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                >
                  <td className="py-3.5 px-6 font-mono text-xs tabular-nums">
                    {snap.timestamp}
                    <span className="ms-2 text-slate-400">
                      · {snap.trigger === 'auto' ? (isRTL ? 'تلقائي' : 'Auto') : isRTL ? 'يدوي' : 'Manual'}
                    </span>
                  </td>
                  <td className="py-3.5 px-6 font-mono text-xs tabular-nums">
                    {snap.messagesCount.toLocaleString()} {isRTL ? 'رسالة' : 'msgs'} · {snap.mediaCount}{' '}
                    {isRTL ? 'صورة' : 'photos'}
                  </td>
                  <td className="py-3.5 px-6 text-xs">
                    {snap.includesSensitiveVault ? (
                      <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                        {isRTL ? 'مشمولة ومشفرة' : 'Included & Locked'}
                      </span>
                    ) : (
                      <span className="text-slate-400">{isRTL ? 'قياسي' : 'Standard'}</span>
                    )}
                  </td>
                  <td className="py-3.5 px-6 font-mono text-xs text-slate-500 dark:text-slate-400">
                    {snap.encryptedWithKey}
                  </td>
                  <td className="py-3.5 px-6 text-end">
                    <div className="flex items-center justify-end gap-3">
                      <span className="font-mono text-xs tabular-nums">{snap.sizeMB} MB</span>
                      <button
                        type="button"
                        onClick={() => handleRestore(snap)}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
                          restoredId === snap.id
                            ? 'bg-emerald-600 text-white border-emerald-600'
                            : darkMode
                            ? 'border-slate-700 hover:bg-slate-800 text-slate-200'
                            : 'border-slate-300 hover:bg-slate-100 text-slate-700'
                        }`}
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>
                          {restoredId === snap.id
                            ? isRTL
                              ? 'تمت الاستعادة بنجاح'
                              : 'Restored'
                            : isRTL
                            ? 'استعادة النسخة'
                            : 'Restore'}
                        </span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
