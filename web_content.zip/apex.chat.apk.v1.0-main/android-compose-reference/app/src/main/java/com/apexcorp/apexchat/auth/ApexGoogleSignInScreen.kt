package com.apexcorp.apexchat.auth

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun ApexGoogleSignInScreen(
    googleAuthClient: GoogleAuthClient,
    onAuthenticated: (ApexAuthenticatedUser) -> Unit
) {
    val context: Context = LocalContext.current
    val scope = rememberCoroutineScope()

    var currentUser by remember { mutableStateOf(googleAuthClient.getCurrentUser()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(currentUser) {
        currentUser?.let { onAuthenticated(it) }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFF8FAFC)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "أبيكس شات — Apex Chat",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF059669)
                    )

                    val user = currentUser
                    if (user != null) {
                        // Authenticated User Profile Card (Name, Email, Photo, 10-Digit ID)
                        AsyncImage(
                            model = user.photoUrl,
                            contentDescription = user.displayName,
                            modifier = Modifier
                                .size(84.dp)
                                .clip(CircleShape)
                        )
                        Text(
                            text = user.displayName,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = user.email,
                            fontSize = 13.sp,
                            color = Color(0xFF64748B)
                        )
                        Surface(
                            color = Color(0xFFECFDF5),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "ID: ${user.userCode10Digits}",
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF059669)
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    googleAuthClient.signOut()
                                    currentUser = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("تسجيل الخروج من الحساب", color = Color(0xFFDC2626))
                        }
                    } else {
                        // Error or Cancellation Alert
                        errorMessage?.let { msg ->
                            Surface(
                                color = Color(0xFFFEF2F2),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = msg,
                                    color = Color(0xFFB91C1C),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        Button(
                            onClick = {
                                errorMessage = null
                                isLoading = true
                                scope.launch {
                                    when (val res = googleAuthClient.signInWithGoogle(context)) {
                                        is GoogleAuthResult.Success -> {
                                            isLoading = false
                                            currentUser = res.user
                                            onAuthenticated(res.user)
                                        }
                                        is GoogleAuthResult.CancelledByUser -> {
                                            isLoading = false
                                            errorMessage = "تم إلغاء تسجيل الدخول عبر Google من قِبل المستخدم."
                                        }
                                        is GoogleAuthResult.Error -> {
                                            isLoading = false
                                            errorMessage = res.message
                                        }
                                    }
                                }
                            },
                            enabled = !isLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("جاري التحقق عبر Google...")
                            } else {
                                Text("تسجيل الدخول باستخدام Google")
                            }
                        }
                    }

                    Text(
                        text = "Apex Chat V1.0 · من تطوير شركة أبيكس",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        }
    }
}
