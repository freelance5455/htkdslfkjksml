package com.apexcorp.apexchat.auth

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import kotlin.math.abs

data class ApexAuthenticatedUser(
    val uid: String,
    val userCode10Digits: String,
    val displayName: String,
    val email: String,
    val photoUrl: String
)

sealed interface GoogleAuthResult {
    data class Success(val user: ApexAuthenticatedUser) : GoogleAuthResult
    data object CancelledByUser : GoogleAuthResult
    data class Error(val message: String, val exception: Throwable? = null) : GoogleAuthResult
}

class GoogleAuthClient(
    private val context: Context,
    private val webClientId: String,
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val credentialManager = CredentialManager.create(context)

    fun getCurrentUser(): ApexAuthenticatedUser? {
        val fbUser = firebaseAuth.currentUser ?: return null
        return fbUser.toApexUser(generateDeterministic10DigitCode(fbUser.uid))
    }

    suspend fun signInWithGoogle(activityContext: Context): GoogleAuthResult {
        return try {
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId)
                .setAutoSelectEnabled(false)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result = credentialManager.getCredential(
                request = request,
                context = activityContext
            )

            val credential = result.credential
            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val firebaseCredential =
                    GoogleAuthProvider.getCredential(googleIdTokenCredential.idToken, null)

                val authResult = firebaseAuth.signInWithCredential(firebaseCredential).await()
                val fbUser = authResult.user
                    ?: return GoogleAuthResult.Error("تعذر استرداد بيانات مستخدم Firebase بعد تسجيل الدخول.")

                val userCode = syncUserToFirestore(fbUser)
                GoogleAuthResult.Success(fbUser.toApexUser(userCode))
            } else {
                GoogleAuthResult.Error("نوع بيانات الاعتماد المستلمة غير مدعوم.")
            }
        } catch (e: GetCredentialCancellationException) {
            GoogleAuthResult.CancelledByUser
        } catch (e: NoCredentialException) {
            GoogleAuthResult.Error(
                "لا يوجد حساب Google مسجل على هذا الجهاز أو أن بصمة SHA-1 غير مضافة في Firebase Console.",
                e
            )
        } catch (e: GetCredentialException) {
            GoogleAuthResult.Error("فشل تسجيل الدخول عبر Google: ${e.message}", e)
        } catch (e: Exception) {
            GoogleAuthResult.Error("حدث خطأ غير متوقع أثناء المصادقة: ${e.localizedMessage}", e)
        }
    }

    suspend fun signOut() {
        firebaseAuth.signOut()
        try {
            credentialManager.clearCredentialState(ClearCredentialStateRequest())
        } catch (_: Exception) {
            // Ignore credential cache clear errors on sign-out
        }
    }

    private suspend fun syncUserToFirestore(fbUser: FirebaseUser): String {
        val uid = fbUser.uid
        val publicRef = firestore.collection("users").document(uid)
        val privateRef = publicRef.collection("private").document("info")

        val snapshot = publicRef.get().await()
        val existingCode = snapshot.getString("userCode")
        val userCode = if (!existingCode.isNullOrBlank() && existingCode.length == 10) {
            existingCode
        } else {
            generateDeterministic10DigitCode(uid)
        }

        if (!snapshot.exists()) {
            val now = Timestamp.now()
            firestore.runBatch { batch ->
                batch.set(
                    publicRef,
                    mapOf(
                        "uid" to uid,
                        "userCode" to userCode,
                        "displayName" to (fbUser.displayName ?: "Apex User").take(100),
                        "photoURL" to (fbUser.photoUrl?.toString() ?: ""),
                        "statusText" to "متصل — أبيكس شات",
                        "createdAt" to now,
                        "updatedAt" to now
                    )
                )
                batch.set(
                    privateRef,
                    mapOf(
                        "uid" to uid,
                        "email" to (fbUser.email ?: ""),
                        "providerId" to "google.com",
                        "createdAt" to now,
                        "updatedAt" to now
                    )
                )
            }.await()
        }

        return userCode
    }

    private fun generateDeterministic10DigitCode(uid: String): String {
        var hash = 2166136261L
        for (ch in uid) {
            hash = hash xor ch.code.toLong()
            hash *= 16777619L
        }
        val num = (abs(hash) % 9_000_000_000L) + 1_000_000_000L
        return num.toString().take(10).padStart(10, '1')
    }

    private fun FirebaseUser.toApexUser(code: String) = ApexAuthenticatedUser(
        uid = uid,
        userCode10Digits = code,
        displayName = displayName ?: email?.substringBefore("@") ?: "مستخدم أبيكس",
        email = email ?: "",
        photoUrl = photoUrl?.toString() ?: ""
    )
}
