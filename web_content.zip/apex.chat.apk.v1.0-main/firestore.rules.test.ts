/**
 * Firestore Security Rules Verification Suite (Dirty Dozen Payloads)
 * Verifies that all 12 adversarial payloads in security_spec.md return PERMISSION_DENIED.
 */

export interface DirtyDozenTestCase {
  id: number;
  name: string;
  path: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  auth: { uid: string; email_verified: boolean } | null;
  payload?: Record<string, unknown>;
  expectedResult: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_TESTS: DirtyDozenTestCase[] = [
  {
    id: 1,
    name: 'Unauthenticated Write',
    path: '/users/user_1',
    operation: 'create',
    auth: null,
    payload: { uid: 'user_1', userCode: '1234567890', displayName: 'Test', photoURL: '', statusText: 'Online' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Unverified Email Write',
    path: '/users/user_1',
    operation: 'create',
    auth: { uid: 'user_1', email_verified: false },
    payload: { uid: 'user_1', userCode: '1234567890', displayName: 'Test', photoURL: '', statusText: 'Online' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Identity Spoofing on Create',
    path: '/users/user_1',
    operation: 'create',
    auth: { uid: 'user_1', email_verified: true },
    payload: { uid: 'user_2', userCode: '1234567890', displayName: 'Test', photoURL: '', statusText: 'Online' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'Shadow Field Injection on Create',
    path: '/users/user_1',
    operation: 'create',
    auth: { uid: 'user_1', email_verified: true },
    payload: { uid: 'user_1', userCode: '1234567890', displayName: 'Test', photoURL: '', statusText: 'Online', isAdmin: true },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Invalid 10-Digit UserCode',
    path: '/users/user_1',
    operation: 'create',
    auth: { uid: 'user_1', email_verified: true },
    payload: { uid: 'user_1', userCode: '12345', displayName: 'Test', photoURL: '', statusText: 'Online' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Oversized DisplayName (>100 chars)',
    path: '/users/user_1',
    operation: 'create',
    auth: { uid: 'user_1', email_verified: true },
    payload: { uid: 'user_1', userCode: '1234567890', displayName: 'A'.repeat(105), photoURL: '', statusText: 'Online' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Client Timestamp Spoofing',
    path: '/users/user_1',
    operation: 'create',
    auth: { uid: 'user_1', email_verified: true },
    payload: { uid: 'user_1', userCode: '1234567890', displayName: 'Test', photoURL: '', statusText: 'Online', createdAt: '2020-01-01T00:00:00Z' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Immutable Field Mutation on Update',
    path: '/users/user_1',
    operation: 'update',
    auth: { uid: 'user_1', email_verified: true },
    payload: { userCode: '9999999999' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Shadow Field Injection on Update',
    path: '/users/user_1',
    operation: 'update',
    auth: { uid: 'user_1', email_verified: true },
    payload: { displayName: 'Valid Name', role: 'superadmin' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Cross-User Private PII Read',
    path: '/users/user_1/private/info',
    operation: 'get',
    auth: { uid: 'user_2', email_verified: true },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'Invalid Document ID in Private Subcollection',
    path: '/users/user_1/private/wrong_doc',
    operation: 'create',
    auth: { uid: 'user_1', email_verified: true },
    payload: { uid: 'user_1', email: 'test@example.com', providerId: 'google.com' },
    expectedResult: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Unauthorized Profile Deletion',
    path: '/users/user_1',
    operation: 'delete',
    auth: { uid: 'user_1', email_verified: true },
    expectedResult: 'PERMISSION_DENIED',
  },
];
