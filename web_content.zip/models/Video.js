const mongoose = require('mongoose');

const VideoSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 160 },
  description: { type: String, default: '', maxlength: 5000 },
  videoUrl: { type: String, required: true },
  thumbnailUrl: { type: String, default: '' },
  type: { type: String, enum: ['video', 'shorts'], default: 'video' },
  duration: { type: Number, required: true, min: 0 },
  viewsCount: { type: Number, default: 0, min: 0 },
  likesCount: { type: Number, default: 0, min: 0 },
  uploader: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  resolutions: [{ type: String, enum: ['360p', '480p', '720p', '1080p'] }],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Video', VideoSchema);
