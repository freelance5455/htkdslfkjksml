const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true, trim: true, minlength: 3, maxlength: 30 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true, select: false },
  avatar: { type: String, default: 'default-avatar.png' },
  role: { type: String, enum: ['user', 'admin', 'super_admin'], default: 'user' },
  isVerified: { type: Boolean, default: false },
  subscribersCount: { type: Number, default: 0, min: 0 },
  lastUploadDate: { type: Date, default: null },
  isShadowbanned: { type: Boolean, default: false },
  otpCode: { type: String, default: null, select: false },
  createdAt: { type: Date, default: Date.now }
}, { timestamps: false });

module.exports = mongoose.model('User', UserSchema);
