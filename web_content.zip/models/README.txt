Place a legally licensed, compatible offline AI model and its integration assets here.
No model weights are included in this starter project.
