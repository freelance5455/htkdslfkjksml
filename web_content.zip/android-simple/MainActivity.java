
// Minimal Android WebView - MainActivity.java
// Place in android/app/src/main/java/com/ohmslaw/lab/MainActivity.java
package com.ohmslaw.lab;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        wv.loadUrl("file:///android_asset/www/index.html");
        setContentView(wv);
    }
}
