BLAZE NEXUS — JARVIS EDITION

HOW TO USE
1. Extract BLAZE_NEXUS_JARVIS.zip.
2. Open index.html in Chrome or another modern browser.
3. For APK conversion, upload the extracted project files to an HTML-to-APK/WebView wrapper that accepts a website folder or ZIP.

FEATURES
- Futuristic JARVIS-inspired dashboard
- Built-in command assistant (predefined responses; not a live AI model)
- Speech output using voices available on the device/browser
- Optional speech recognition where browser support exists
- Clock, notes with local autosave, calculator, number mini-game
- Web search shortcut and user-selected file picker
- Hidden admin setup: tap the BN logo five times quickly, then create a local PIN

IMPORTANT
- No API key is included or needed.
- Female-sounding speech depends on the voices installed on the device. The app selects a voice with a female-style name when available; otherwise the browser default is used.
- Speech recognition may require internet and browser permission, and is not supported in every browser.
- Notes, voice preference, and admin PIN are stored in this browser's localStorage.
- The admin PIN is only a convenience lock. It is not secure authentication and must not be used to protect secrets.
- Web search requires internet. Most other interface features work offline after the files are loaded.
