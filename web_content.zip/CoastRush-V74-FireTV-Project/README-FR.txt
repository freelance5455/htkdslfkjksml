COAST RUSH V74 - PROJET SOURCE ANDROID FIRE TV

Contenu :
- index.html : version V74 du jeu
- app/src/main/assets/index.html : copie embarquée utilisée par l'application Android
- app/src/main/java/.../MainActivity.java : activité Android du projet de base V71
- fichiers Gradle et manifeste Android

V74 :
- Monitoring de performances intégré à la page du jeu
- Résolution de rendu interne indépendante du mode de sortie HDMI
- Le jeu ne demande pas à Android de changer la résolution native de l'écran

IMPORTANT :
Ce ZIP contient le PROJET SOURCE Android, pas un APK déjà compilé.
Il faut ouvrir le dossier CoastRush-V74-FireTV dans Android Studio et compiler l'application.
La compilation Android et le fonctionnement sur une Fire TV Stick réelle n'ont pas été testés dans cet environnement.


V74 : correction du ratio Fire TV. Retour aux dimensions logiques natives 320x224, suppression de la couche de présentation WebGL supplémentaire sur Fire TV, conservation du monitoring permanent.
