# CPLS V2 — Stage 1155
## Cache / Recovery Foundation
- Native snapshots expose feed source, candle source, exactness and polling metadata.
- Existing last-good caches remain the recovery path after transient REST errors.
- No stale quote is relabeled as a fresh quote.
