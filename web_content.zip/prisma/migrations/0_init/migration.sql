-- Supermarket POS & Inventory Management Initial Schema Migration (PostgreSQL)

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ROLES & PERMISSIONS
CREATE TABLE "roles" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "name" VARCHAR(50) UNIQUE NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "permissions" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "code" VARCHAR(100) UNIQUE NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "description" TEXT
);

CREATE TABLE "role_permissions" (
    "role_id" VARCHAR(36) REFERENCES "roles"("id") ON DELETE CASCADE,
    "permission_id" VARCHAR(36) REFERENCES "permissions"("id") ON DELETE CASCADE,
    PRIMARY KEY ("role_id", "permission_id")
);

-- BRANCHES
CREATE TABLE "branches" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "code" VARCHAR(20) UNIQUE NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "address" TEXT NOT NULL,
    "phone" VARCHAR(50),
    "email" VARCHAR(100),
    "is_main" BOOLEAN DEFAULT FALSE,
    "active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- USERS
CREATE TABLE "users" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "email" VARCHAR(150) UNIQUE NOT NULL,
    "username" VARCHAR(50) UNIQUE NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "password_hash" TEXT NOT NULL,
    "phone" VARCHAR(50),
    "role" VARCHAR(50) NOT NULL DEFAULT 'CASHIER',
    "branch_id" VARCHAR(36) REFERENCES "branches"("id") ON DELETE SET NULL,
    "active" BOOLEAN DEFAULT TRUE,
    "failed_attempts" INT DEFAULT 0,
    "locked_until" TIMESTAMP WITH TIME ZONE,
    "last_login_at" TIMESTAMP WITH TIME ZONE,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "idx_users_email" ON "users"("email");
CREATE INDEX "idx_users_role" ON "users"("role");

-- CATEGORIES & BRANDS
CREATE TABLE "categories" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "name" VARCHAR(100) UNIQUE NOT NULL,
    "code" VARCHAR(50) UNIQUE NOT NULL,
    "description" TEXT,
    "active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "brands" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "name" VARCHAR(100) UNIQUE NOT NULL,
    "description" TEXT,
    "active" BOOLEAN DEFAULT TRUE,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- PRODUCTS
CREATE TABLE "products" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "sku" VARCHAR(50) UNIQUE NOT NULL,
    "barcode" VARCHAR(50) UNIQUE NOT NULL,
    "name" VARCHAR(150) NOT NULL,
    "description" TEXT,
    "category_id" VARCHAR(36) NOT NULL REFERENCES "categories"("id"),
    "brand_id" VARCHAR(36) REFERENCES "brands"("id"),
    "cost_price" NUMERIC(12, 2) NOT NULL CHECK (cost_price >= 0),
    "selling_price" NUMERIC(12, 2) NOT NULL CHECK (selling_price >= 0),
    "wholesale_price" NUMERIC(12, 2),
    "tax_rate" NUMERIC(5, 2) NOT NULL DEFAULT 15.00,
    "unit" VARCHAR(20) DEFAULT 'pcs',
    "min_stock_level" INT DEFAULT 5,
    "max_stock_level" INT DEFAULT 200,
    "reorder_level" INT DEFAULT 10,
    "expiry_date" DATE,
    "active" BOOLEAN DEFAULT TRUE,
    "image_url" TEXT,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "idx_products_barcode" ON "products"("barcode");
CREATE INDEX "idx_products_sku" ON "products"("sku");
CREATE INDEX "idx_products_name" ON "products"("name");
CREATE INDEX "idx_products_category" ON "products"("category_id");

-- BARCODES
CREATE TABLE "product_barcodes" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "product_id" VARCHAR(36) NOT NULL REFERENCES "products"("id") ON DELETE CASCADE,
    "barcode" VARCHAR(50) UNIQUE NOT NULL,
    "type" VARCHAR(20) DEFAULT 'EAN13',
    "is_primary" BOOLEAN DEFAULT FALSE
);

CREATE INDEX "idx_product_barcodes_barcode" ON "product_barcodes"("barcode");

-- INVENTORY & MOVEMENTS
CREATE TABLE "inventory" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "product_id" VARCHAR(36) NOT NULL REFERENCES "products"("id"),
    "branch_id" VARCHAR(36) NOT NULL REFERENCES "branches"("id"),
    "quantity" INT NOT NULL DEFAULT 0,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "uq_inventory_prod_branch" UNIQUE ("product_id", "branch_id")
);

CREATE INDEX "idx_inventory_product" ON "inventory"("product_id");
CREATE INDEX "idx_inventory_branch" ON "inventory"("branch_id");

CREATE TABLE "stock_movements" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "product_id" VARCHAR(36) NOT NULL REFERENCES "products"("id"),
    "branch_id" VARCHAR(36) NOT NULL REFERENCES "branches"("id"),
    "quantity" INT NOT NULL,
    "movement_type" VARCHAR(50) NOT NULL,
    "reference_type" VARCHAR(50),
    "reference_id" VARCHAR(50),
    "previous_quantity" INT NOT NULL,
    "new_quantity" INT NOT NULL,
    "performed_by_id" VARCHAR(36) NOT NULL REFERENCES "users"("id"),
    "notes" TEXT,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "idx_stock_movements_product" ON "stock_movements"("product_id");
CREATE INDEX "idx_stock_movements_branch" ON "stock_movements"("branch_id");
CREATE INDEX "idx_stock_movements_type" ON "stock_movements"("movement_type");
CREATE INDEX "idx_stock_movements_created" ON "stock_movements"("created_at");

-- SUPPLIERS & PURCHASING
CREATE TABLE "suppliers" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "name" VARCHAR(150) NOT NULL,
    "code" VARCHAR(50) UNIQUE NOT NULL,
    "contact_person" VARCHAR(100),
    "phone" VARCHAR(50) NOT NULL,
    "email" VARCHAR(100),
    "address" TEXT,
    "tax_number" VARCHAR(50),
    "active" BOOLEAN DEFAULT TRUE,
    "notes" TEXT,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "supplier_products" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "supplier_id" VARCHAR(36) NOT NULL REFERENCES "suppliers"("id"),
    "product_id" VARCHAR(36) NOT NULL REFERENCES "products"("id"),
    "cost_price" NUMERIC(12, 2) NOT NULL,
    CONSTRAINT "uq_supplier_product" UNIQUE ("supplier_id", "product_id")
);

CREATE TABLE "purchase_orders" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "order_number" VARCHAR(50) UNIQUE NOT NULL,
    "supplier_id" VARCHAR(36) NOT NULL REFERENCES "suppliers"("id"),
    "branch_id" VARCHAR(36) NOT NULL REFERENCES "branches"("id"),
    "status" VARCHAR(30) DEFAULT 'DRAFT',
    "total_amount" NUMERIC(12, 2) NOT NULL,
    "created_by_id" VARCHAR(36) NOT NULL REFERENCES "users"("id"),
    "approved_by_id" VARCHAR(36) REFERENCES "users"("id"),
    "notes" TEXT,
    "ordered_at" TIMESTAMP WITH TIME ZONE,
    "received_at" TIMESTAMP WITH TIME ZONE,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "purchase_order_items" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "purchase_order_id" VARCHAR(36) NOT NULL REFERENCES "purchase_orders"("id") ON DELETE CASCADE,
    "product_id" VARCHAR(36) NOT NULL REFERENCES "products"("id"),
    "ordered_quantity" INT NOT NULL,
    "received_quantity" INT DEFAULT 0,
    "unit_cost" NUMERIC(12, 2) NOT NULL,
    "total_cost" NUMERIC(12, 2) NOT NULL
);

-- CUSTOMERS
CREATE TABLE "customers" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "code" VARCHAR(50) UNIQUE NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "phone" VARCHAR(50) UNIQUE,
    "email" VARCHAR(100),
    "address" TEXT,
    "loyalty_points" INT DEFAULT 0,
    "active" BOOLEAN DEFAULT TRUE,
    "notes" TEXT,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- CASH REGISTER & SESSIONS
CREATE TABLE "cash_registers" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "branch_id" VARCHAR(36) NOT NULL REFERENCES "branches"("id"),
    "code" VARCHAR(50) UNIQUE NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "status" VARCHAR(20) DEFAULT 'CLOSED',
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "cash_sessions" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "cash_register_id" VARCHAR(36) NOT NULL REFERENCES "cash_registers"("id"),
    "cashier_id" VARCHAR(36) NOT NULL REFERENCES "users"("id"),
    "opening_balance" NUMERIC(12, 2) NOT NULL,
    "closing_balance" NUMERIC(12, 2),
    "expected_cash" NUMERIC(12, 2),
    "actual_cash" NUMERIC(12, 2),
    "difference" NUMERIC(12, 2),
    "opened_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    "closed_at" TIMESTAMP WITH TIME ZONE,
    "status" VARCHAR(20) DEFAULT 'OPEN',
    "notes" TEXT
);

CREATE TABLE "cash_movements" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "cash_session_id" VARCHAR(36) NOT NULL REFERENCES "cash_sessions"("id"),
    "type" VARCHAR(20) NOT NULL,
    "amount" NUMERIC(12, 2) NOT NULL,
    "reason" TEXT NOT NULL,
    "performed_by_id" VARCHAR(36) NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- SALES & SALE ITEMS
CREATE TABLE "sales" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "receipt_number" VARCHAR(50) UNIQUE NOT NULL,
    "branch_id" VARCHAR(36) NOT NULL REFERENCES "branches"("id"),
    "cashier_id" VARCHAR(36) NOT NULL REFERENCES "users"("id"),
    "customer_id" VARCHAR(36) REFERENCES "customers"("id"),
    "cash_session_id" VARCHAR(36) REFERENCES "cash_sessions"("id"),
    "subtotal" NUMERIC(12, 2) NOT NULL,
    "discount_total" NUMERIC(12, 2) DEFAULT 0.00,
    "tax_total" NUMERIC(12, 2) DEFAULT 0.00,
    "grand_total" NUMERIC(12, 2) NOT NULL,
    "payment_method" VARCHAR(30) DEFAULT 'CASH',
    "amount_tendered" NUMERIC(12, 2) NOT NULL,
    "change_given" NUMERIC(12, 2) DEFAULT 0.00,
    "status" VARCHAR(30) DEFAULT 'COMPLETED',
    "notes" TEXT,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "idx_sales_receipt" ON "sales"("receipt_number");
CREATE INDEX "idx_sales_cashier" ON "sales"("cashier_id");
CREATE INDEX "idx_sales_branch" ON "sales"("branch_id");
CREATE INDEX "idx_sales_created" ON "sales"("created_at");

CREATE TABLE "sale_items" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "sale_id" VARCHAR(36) NOT NULL REFERENCES "sales"("id") ON DELETE CASCADE,
    "product_id" VARCHAR(36) NOT NULL REFERENCES "products"("id"),
    "product_name" VARCHAR(150) NOT NULL,
    "barcode" VARCHAR(50) NOT NULL,
    "quantity" INT NOT NULL CHECK (quantity > 0),
    "unit_price" NUMERIC(12, 2) NOT NULL,
    "cost_price" NUMERIC(12, 2) NOT NULL,
    "tax_rate" NUMERIC(5, 2) NOT NULL,
    "tax_amount" NUMERIC(12, 2) NOT NULL,
    "discount_amount" NUMERIC(12, 2) DEFAULT 0.00,
    "total_price" NUMERIC(12, 2) NOT NULL
);

CREATE INDEX "idx_sale_items_sale" ON "sale_items"("sale_id");
CREATE INDEX "idx_sale_items_product" ON "sale_items"("product_id");

-- REFUNDS
CREATE TABLE "refunds" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "refund_number" VARCHAR(50) UNIQUE NOT NULL,
    "sale_id" VARCHAR(36) NOT NULL REFERENCES "sales"("id"),
    "amount" NUMERIC(12, 2) NOT NULL,
    "reason" TEXT NOT NULL,
    "approved_by_id" VARCHAR(36) NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE "refund_items" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "refund_id" VARCHAR(36) NOT NULL REFERENCES "refunds"("id") ON DELETE CASCADE,
    "product_id" VARCHAR(36) NOT NULL,
    "quantity" INT NOT NULL CHECK (quantity > 0),
    "refund_price" NUMERIC(12, 2) NOT NULL
);

-- EXPENSES
CREATE TABLE "expenses" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "branch_id" VARCHAR(36) NOT NULL REFERENCES "branches"("id"),
    "category" VARCHAR(50) NOT NULL,
    "amount" NUMERIC(12, 2) NOT NULL CHECK (amount > 0),
    "description" TEXT NOT NULL,
    "paid_to" VARCHAR(100),
    "created_by_id" VARCHAR(36) NOT NULL,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- AUDIT LOGS
CREATE TABLE "audit_logs" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "user_id" VARCHAR(36) NOT NULL REFERENCES "users"("id"),
    "user_name" VARCHAR(100) NOT NULL,
    "action" VARCHAR(100) NOT NULL,
    "entity" VARCHAR(100) NOT NULL,
    "entity_id" VARCHAR(50),
    "metadata" JSONB,
    "ip_address" VARCHAR(45),
    "user_agent" TEXT,
    "created_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX "idx_audit_logs_user" ON "audit_logs"("user_id");
CREATE INDEX "idx_audit_logs_action" ON "audit_logs"("action");
CREATE INDEX "idx_audit_logs_created" ON "audit_logs"("created_at");

-- SYSTEM SETTINGS
CREATE TABLE "system_settings" (
    "id" VARCHAR(36) PRIMARY KEY DEFAULT uuid_generate_v4(),
    "key" VARCHAR(100) UNIQUE NOT NULL,
    "value" TEXT NOT NULL,
    "description" TEXT,
    "updated_at" TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
