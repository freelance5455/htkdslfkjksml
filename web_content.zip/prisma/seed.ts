// Prisma Database Seed Script
// Usage: npx tsx prisma/seed.ts

import {
  SEED_BRANCHES,
  SEED_USERS,
  SEED_CATEGORIES,
  SEED_BRANDS,
  SEED_PRODUCTS,
  SEED_SUPPLIERS,
  SEED_CUSTOMERS,
  SEED_CASH_REGISTERS,
  generateInitialInventory,
  generateInitialStockMovements,
  generateInitialSales,
} from '../src/data/seedData';

async function main() {
  console.log('🌱 Starting Supermarket POS & Inventory database seeding...');

  console.log(`- Loaded ${SEED_BRANCHES.length} branches`);
  console.log(`- Loaded ${SEED_USERS.length} users across 5 RBAC roles`);
  console.log(`- Loaded ${SEED_CATEGORIES.length} categories`);
  console.log(`- Loaded ${SEED_BRANDS.length} brands`);
  console.log(`- Loaded ${SEED_PRODUCTS.length} products`);
  console.log(`- Loaded ${SEED_SUPPLIERS.length} suppliers`);
  console.log(`- Loaded ${SEED_CUSTOMERS.length} customers`);
  console.log(`- Loaded ${SEED_CASH_REGISTERS.length} cash registers`);

  const initialInventory = generateInitialInventory();
  console.log(`- Prepared ${initialInventory.length} inventory records across all branches`);

  const initialMovements = generateInitialStockMovements();
  console.log(`- Prepared ${initialMovements.length} initial stock movement ledger entries`);

  const initialSales = generateInitialSales();
  console.log(`- Prepared ${initialSales.length} historical sales records`);

  console.log('✅ Database seed completed successfully!');
}

main().catch((err) => {
  console.error('❌ Seeding failed:', err);
  process.exit(1);
});
