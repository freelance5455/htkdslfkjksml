import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "إيقاع | Iqa'" },
      { name: "description", content: "تطبيق إيقاع لتنظيم يومك وعاداتك." },
      { property: "og:title", content: "إيقاع | Iqa'" },
      { property: "og:description", content: "تطبيق إيقاع لتنظيم يومك وعاداتك." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/app.html"
      title="إيقاع"
      className="fixed inset-0 h-full w-full border-0"
    />
  );
}
