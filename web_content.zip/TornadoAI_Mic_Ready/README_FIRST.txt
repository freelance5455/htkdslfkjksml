TORNADO AI — MICROPHONE-READY HTML PACKAGE

IMPORTANT: This ZIP includes the app files and the microphone permission setup notes. An HTML ZIP cannot itself grant Android runtime permissions. Your APK converter must support microphone permission and WebView microphone requests.

FILES
- index.html (start page)
- style.css
- app.js
- ANDROID_MIC_PERMISSION_SETUP.txt (Android wrapper requirements)

HOW TO USE WITH AN HTML-TO-APK CONVERTER
1. Extract this ZIP.
2. Select index.html as the home page. Keep style.css and app.js in the same folder.
3. Enable Microphone / Record Audio permission and Internet permission in converter settings.
4. Enable WebView microphone/media capture permission if there is a separate option.
5. Build the APK, install it, then open Android Settings > Apps > Tornado AI > Permissions > Microphone > Allow.
6. Reopen Tornado AI and tap the voice button. Accept any in-app permission prompt.

IF THERE IS NO MICROPHONE OPTION IN YOUR CONVERTER
This converter cannot make voice input work from this HTML package by itself. Use a converter that supports WebView microphone permission requests or a native Android WebView wrapper configured as described in ANDROID_MIC_PERMISSION_SETUP.txt.

LIMITATIONS
- Browser speech recognition depends on Android WebView/browser support and may not work in every converter.
- The app asks for microphone access; the user must still approve Android's permission prompt.
- This is a source ZIP, not a compiled APK.


VOICE CHOICES UPDATE
The Settings screen now includes Default, Female-sounding, and Male-sounding voice options plus a test button. Voice gender/name matching is best-effort because Android/WebView only exposes voices installed and available on the device. For more choices, install voice data under Android Settings > Text-to-speech output. This ZIP is an HTML project, not a compiled APK; microphone and speech support still depend on the APK converter.
