const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];let timer;function toast(t){$('#toast').textContent=t;$('#toast').classList.add('show');clearTimeout(timer);timer=setTimeout(()=>$('#toast').classList.remove('show'),2400)}function go(id){$$('.screen').forEach(s=>s.classList.toggle('active',s.id===id));$$('nav button').forEach(b=>b.classList.toggle('selected',b.dataset.page===id));window.scrollTo(0,0)}$$('[data-page]').forEach(b=>b.onclick=()=>go(b.dataset.page));$('#settings').onclick=()=>go('settingsPage');
const STORE_KEY='tornado_groq_key', STORE_MODEL='tornado_groq_model', STORE_SPEECH='tornado_speech', STORE_VOICE='tornado_voice_type';
let speakReplies=localStorage.getItem(STORE_SPEECH)!=='off';
$('#apiKey').value=localStorage.getItem(STORE_KEY)||'';
$('#modelName').value=localStorage.getItem(STORE_MODEL)||'openai/gpt-oss-20b';
function updateAIStatus(){const ok=!!localStorage.getItem(STORE_KEY);$('#aiStatus').textContent=ok?'CONNECTED KEY SAVED':'NOT CONNECTED';}
function updateSpeechButton(){if($('#speechToggle'))$('#speechToggle').textContent='SPOKEN REPLIES: '+(speakReplies?'ON':'OFF');}
updateAIStatus();updateSpeechButton();
$('#saveSettings').onclick=()=>{const key=$('#apiKey').value.trim(),model=$('#modelName').value.trim()||'openai/gpt-oss-20b';if(!key){toast('Paste your API key first.');return}localStorage.setItem(STORE_KEY,key);localStorage.setItem(STORE_MODEL,model);updateAIStatus();toast('AI settings saved on this device.');};
$('#clearSettings').onclick=()=>{localStorage.removeItem(STORE_KEY);$('#apiKey').value='';updateAIStatus();toast('Saved API key removed.');};
$('#speechToggle').onclick=()=>{speakReplies=!speakReplies;localStorage.setItem(STORE_SPEECH,speakReplies?'on':'off');updateSpeechButton();toast('Spoken replies '+(speakReplies?'enabled':'disabled')+'.');};function getSelectedVoice(){if(!('speechSynthesis'in window))return null;const type=localStorage.getItem(STORE_VOICE)||'default';if(type==='default')return null;const voices=speechSynthesis.getVoices()||[];const female=/female|woman|zira|samantha|karen|susan|victoria|aria|jenny|sara|neerja|priya|heera|veena|google हिन्दी|google hindi/i;const male=/male|man|david|mark|daniel|alex|guy|james|george|ryan|arjun|ravi|hemant|google uk english male/i;const matches=voices.filter(v=>female.test(v.name+' '+v.voiceURI));const target=type==='female'?female:male;let found=voices.find(v=>target.test(v.name+' '+v.voiceURI));if(!found&&type==='female')found=matches[0];return found||null}function speak(t){if(!('speechSynthesis'in window)){toast('Speech output not supported here.');return}speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);const v=getSelectedVoice();if(v)u.voice=v;u.lang=(v&&v.lang)||'en-IN';speechSynthesis.speak(u)}const voiceType=$('#voiceType');if(voiceType){voiceType.value=localStorage.getItem(STORE_VOICE)||'default';voiceType.onchange=()=>{localStorage.setItem(STORE_VOICE,voiceType.value);toast('Voice preference saved.');};$('#testVoice').onclick=()=>speak('Hello Commander. This is your selected Tornado AI voice.');if('speechSynthesis'in window)speechSynthesis.onvoiceschanged=()=>{};}function act(a){if(a==='music'){window.open('https://music.youtube.com/','_blank');return}if(a==='settings')toast('Open Android Settings from your phone app list.');if(a==='volume')toast('Use your phone physical volume buttons.');if(a==='speak')speak('Hello Commander. Tornado AI systems are online.')}$$('[data-action]').forEach(b=>b.onclick=()=>act(b.dataset.action));const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)$('#voiceAvailability').textContent='BROWSER DEPENDENT';$('#voice').onclick=async()=>{
  if(!SR){speak('Voice recognition is not supported by this app wrapper.');toast('Voice recognition needs a compatible browser or APK converter.');return}
  $('#voiceStatus').textContent='REQUESTING MIC ACCESS...';
  try{
    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){
      toast('Microphone permission API unavailable. Enable microphone permission in your APK converter.');
      $('#voiceStatus').textContent='MIC PERMISSION NEEDED';return;
    }
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});
    stream.getTracks().forEach(track=>track.stop());
    const r=new SR();r.lang='en-IN';$('#voiceStatus').textContent='LISTENING...';
    r.onresult=e=>{const t=e.results[0][0].transcript;go('chat');$('#chatInput').value=t;reply(t,true)};
    r.onerror=e=>{toast(e.error==='not-allowed'?'Microphone blocked. Allow it in Android App info > Permissions.':'Voice input unavailable. Check microphone permission and try again.');};
    r.onend=()=>$('#voiceStatus').textContent='TAP TO SPEAK';
    r.start();
  }catch(e){
    $('#voiceStatus').textContent='MIC PERMISSION NEEDED';
    toast(e.name==='NotAllowedError'?'Microphone access denied. Allow Microphone in Android app permissions.':'Could not access microphone. Check Android permissions and converter settings.');
  }
};function add(t,user){let d=document.createElement('article');if(user)d.className='user';else{let b=document.createElement('b');b.textContent='TORNADO AI';d.appendChild(b);d.appendChild(document.createElement('br'))}d.appendChild(document.createTextNode(t));$('#messages').appendChild(d);$('#messages').scrollTop=$('#messages').scrollHeight}let chatHistory=[];
async function reply(t,voice=false){
 const key=localStorage.getItem(STORE_KEY),model=localStorage.getItem(STORE_MODEL)||'openai/gpt-oss-20b';
 if(key){
   const pending=(()=>{let d=document.createElement('article');d.id='typing';d.textContent='Tornado AI is thinking…';$('#messages').appendChild(d);$('#messages').scrollTop=$('#messages').scrollHeight;return d})();
   chatHistory.push({role:'user',content:t});
   if(chatHistory.length>16)chatHistory=chatHistory.slice(-16);
   try{
     const res=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+key},body:JSON.stringify({model, messages:[{role:'system',content:'You are Tornado AI, a friendly, capable personal assistant. Speak clearly and help with study, writing, planning, reasoning and everyday tasks. Be honest about limitations. You cannot directly control the phone, send messages, purchase items, or manipulate files unless a supported tool is explicitly available. Never claim you completed an action you did not perform.'},...chatHistory],temperature:0.7,max_tokens:900})});
     const data=await res.json();
     if(!res.ok)throw new Error(data?.error?.message||('API request failed ('+res.status+').'));
     const answer=data.choices?.[0]?.message?.content?.trim()||'I could not generate a response.';
     pending.remove();chatHistory.push({role:'assistant',content:answer});add(answer,false);
     if(speakReplies||voice)speak(answer);
   }catch(err){pending.remove();chatHistory.pop();add('I could not connect to the AI service. Check internet, API key, model name, and provider limits. Details: '+err.message,false);}
   return;
 }
 let q=t.toLowerCase(),a;
 if(/hello|hi\\b|hey/.test(q))a='Hello, Commander. I am ready. To enable real AI answers, open Settings and add an API key.';
 else if(/time|date/.test(q))a='Your device time is '+new Date().toLocaleString()+'.';
 else if(/who are you|your name/.test(q))a='I am Tornado AI, your futuristic assistant interface. Add an AI key in Settings for intelligent responses.';
 else if(/joke/.test(q))a='Why did the computer visit a doctor? It had a virus!';
 else if(/plan|day|schedule/.test(q))a='Plan: choose one priority, focus for 25 minutes, take a 5-minute break, and review your progress.';
 else if(/image|picture|draw|photo/.test(q))a='Open Image Studio to create a detailed image prompt. Actual image generation needs a separate image service.';
 else a='This app is not connected to an AI service yet, so I cannot answer that intelligently. Open Settings, add an API key, and save it. Then try again.';
 setTimeout(()=>{add(a,false);if(speakReplies||voice)speak(a)},200)
}
$('#chatForm').onsubmit=e=>{e.preventDefault();let i=$('#chatInput'),t=i.value.trim();if(!t)return;add(t,true);i.value='';reply(t)};$$('.chips button').forEach(b=>b.onclick=()=>{$('#chatInput').value=b.textContent;$('#chatForm').requestSubmit()});$('#generate').onclick=()=>{let t=$('#imagePrompt').value.trim();if(!t){toast('Describe the image first.');return}$('#resultText').textContent=t+', '+$('#style').value.toLowerCase()+', cinematic lighting, detailed composition, sharp focus, atmospheric depth, high quality, 4K';$('#result').classList.remove('hidden')};$('#copy').onclick=async()=>{try{await navigator.clipboard.writeText($('#resultText').textContent);toast('Prompt copied!')}catch(e){toast('Long-press the prompt to copy it.')}};