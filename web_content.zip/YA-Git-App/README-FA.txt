YA Git — نرم‌افزار مستقل مدیریت مخزن Git روی گوشی (آفلاین، بدون حساب)

ساخت: مخزن را در گیت‌هاب push کن؛ تب Actions خودش APK و AAB امضاشده می‌سازد.
امضای ثابت: چهار Secret بساز (KEYSTORE_B64, KEYSTORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD).
فایل release.keystore را حتماً بیرون از گوشی هم پشتیبان بگیر؛ با گم‌شدنش دیگر نمی‌توانی آپدیت بدهی.
برند: config.json (نام، شناسه بسته، نسخه) — آیکون YA در res و scripts/generate_icons.py

زبان‌ها: فارسی، English، العربية، Türkçe (تغییر زبان از دکمه 🌐 بالای صفحه یا تنظیمات).
ارسال به GitHub: هر مخزن تب «☁️ GitHub» دارد؛ با توکن خودت یک Commit از فایل‌ها می‌فرستد.
Releases: اگر Secrets امضا تنظیم باشد، APK و AAB امضاشده خودکار در بخش Releases گیت‌هاب می‌آید (دانلود مستقیم از گوشی).
