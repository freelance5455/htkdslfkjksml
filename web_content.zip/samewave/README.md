# SAMEWAVE starter prototype

## What is included
- Responsive website UI
- Installable PWA structure for Android (after HTTPS hosting)
- Daily prompt interaction
- Local-only nickname and wave counter
- Sample match cards and demo discovery feed
- Offline cache service worker

## Important current limitations
This is a working front-end prototype, not a live global social network yet. Matches and country pulse data are fictional demo content. User choices are stored only in the browser on the current device. There is no login, shared database, live matching, messaging, or real AI matching yet.

## Run locally
Open `index.html` in a browser for the basic demo. For PWA install/offline behavior, serve the folder over HTTPS (or localhost).

## Android
Deploy the folder to an HTTPS host such as Netlify. Open the site in Chrome on Android, then use Chrome's menu > Install app / Add to Home screen. This creates an installable web app; a signed APK/AAB can be prepared later if needed.

## Next production phase
1. Create Firebase project and enable Authentication + Firestore.
2. Add age-appropriate onboarding, nickname-only profiles, reporting/blocking, moderation, and privacy controls.
3. Store daily prompt responses with consent and minimal data.
4. Implement server-side matching and abuse prevention.
5. Add real-time global aggregates only after enough opt-in participants exist.
6. Configure domain, HTTPS, privacy policy, terms, and app-store review.
