document.addEventListener('DOMContentLoaded', () => {
    // --- Elementos principales del Chat ---
    const messageArea = document.getElementById('message-area');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const chatRecipientNameElem = document.getElementById('chat-recipient-name');
    const scrollBottomBtn = document.getElementById('scroll-bottom-btn');
    
    // --- Elementos de Usuario (Barra lateral) ---
    const currentUsernameElem = document.getElementById('current-username');
    const currentProfilePicElem = document.getElementById('current-profile-pic');
    const currentStatusMessageElem = document.getElementById('current-status-message');
    const currentPhoneElem = document.getElementById('current-phone');
    const contactListElem = document.getElementById('contact-list');
    const logoutButton = document.getElementById('logout-button');
    const spaceSelector = document.getElementById('active-space-selector');
    const recordAudioBtn = document.getElementById('record-audio-btn');

    // --- Elementos de Navegación ---
    const navChats = document.getElementById('nav-chats');
    const navContacts = document.getElementById('nav-contacts');
    const navSettings = document.getElementById('nav-settings');
    const navProfile = document.getElementById('nav-profile');

    // --- Secciones de la App ---
    const sectionChats = document.getElementById('section-chats');
    const sectionContacts = document.getElementById('section-contacts');
    const sectionSettings = document.getElementById('section-settings');
    const sectionProfile = document.getElementById('section-profile');

    // --- Elementos de adjuntos ---
    const imageInput = document.createElement('input');
    imageInput.type = 'file';
    imageInput.accept = 'image/*';
    imageInput.style.display = 'none';
    document.body.appendChild(imageInput);

    const attachButton = document.createElement('button');
    attachButton.id = 'attach-button';
    attachButton.innerHTML = '📷';
    attachButton.style.cssText = "background:none; border:none; font-size:20px; cursor:pointer; padding:0 10px;";
    
    // Insertar el botón antes del input de texto
    if (messageInput && messageInput.parentElement) {
        messageInput.parentElement.insertBefore(attachButton, messageInput);
    }

    // Elementos de la sección de Ajustes
    const settingsProfilePic = document.getElementById('settings-profile-pic');
    const profilePicUpload = document.getElementById('profile-pic-upload');
    const settingsUsername = document.getElementById('settings-username');
    const settingsEmail = document.getElementById('settings-email');
    const settingsPhone = document.getElementById('settings-phone');
    const settingsStatus = document.getElementById('settings-status'); // Nuevo: Selector de estado (Disponible, Ocupado...)
    const settingsStatusMessage = document.getElementById('settings-status-message');
    const settingsAccentColor = document.getElementById('settings-accent-color');
    const settingsBubbleColor = document.getElementById('settings-bubble-color');
    const settingsTextColor = document.getElementById('settings-text-color');
    const settingsBio = document.getElementById('settings-bio');
    const settingsGif = document.getElementById('settings-gif'); // Nuevo input para GIF
    const settingsInstagram = document.getElementById('settings-instagram'); // Nuevo
    const settingsWebsite = document.getElementById('settings-website'); // Nuevo
    const settingsFont = document.getElementById('settings-font'); // Nuevo select en HTML
    const settingsBanner = document.getElementById('settings-banner'); // Nuevo input en HTML
    const settingsWallpaper = document.getElementById('settings-wallpaper');
    const settingsSecurity = document.getElementById('settings-security');
    const settingsStreamerMode = document.getElementById('settings-streamer-mode');
    // Sugerencia: Añadir estos inputs en tu HTML para permitir subida de archivos
    const wallpaperUpload = document.getElementById('wallpaper-upload'); 
    const bannerUpload = document.getElementById('banner-upload');
    const saveSettingsBtn = document.getElementById('save-settings-btn');

    // Avatar por defecto: 👤 en gris (usando un SVG data URI para consistencia)
    const DEFAULT_AVATAR = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='gray'><path d='M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'/></svg>";

    let activeChatId = null; // ID del usuario con el que hablamos
    let contactInterval = null; // Definido aquí para que logout pueda limpiarlo
    let localStream = null;
    let userId = null;
    let myUsername = "";
    let isStreamerMode = false;
    let contactsData = []; // Caché global de contactos para estados
    let myProfilePic = ""; 
    let myRole = "";

    // CONFIGURACIÓN MULTIMEDIA: Audio y Video optimizados
    const mediaConstraints = {
        audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: false, // Menos procesamiento = menos lag en móviles
            sampleRate: 48000,
        },
        video: {
            width: { max: 640 }, // Reducimos resolución para llamadas móviles fluidas
            height: { max: 480 },
            facingMode: "user",
            frameRate: { ideal: 30 }
        }
    };

    let isVideoEnabled = true;
    let isScreenSharing = false;
    let screenStream = null;

    let peerConnection = null; // Conexión activa principal
    // PIP: Soporte Multi-Peer para llamadas grupales (Mesh)
    let peerConnections = {}; // { userId: RTCPeerConnection }
    // PIP: Engine SFU (Selective Forwarding Unit)
    // En SFU, normalmente solo mantenemos una conexión principal con el servidor
    let sfuConnection = null; 
    let isMuted = false;
    let callTimerInterval = null;
    let iceCandidatesQueue = [];
    let availableMics = [];
    let availableOutputs = [];
    let currentMicIndex = 0;
    let currentOutputIndex = 0;
    let wakeLock = null;
    let unreadCounts = {}; // { contactId: count }

    const requestWakeLock = async () => {
        try { if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen'); } catch (err) {}
    };

    const releaseWakeLock = async () => {
        if (wakeLock !== null) {
            await wakeLock.release();
            wakeLock = null;
        }
    };

    const rtcConfig = { 
        iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
            // Servidor TURN gratuito (OpenRelay) para saltar firewalls corporativos
            { 
              urls: 'turn:openrelay.metered.ca:443', 
              username: 'openrelayproject', 
              credential: 'openrelayproject' 
            }
        ],
        iceCandidatePoolSize: 2, // Conexión inicial más rápida
        bundlePolicy: "max-bundle",
        rtcpMuxPolicy: "require",
        sdpSemantics: "unified-plan"
    };

    // Función para mejorar la calidad del audio en el SDP
    function optimizeAudioCodec(sdp) {
        return sdp.replace(/a=fmtp:111 /g, 'a=fmtp:111 minptime=10;useinbandfec=1;maxaveragebitrate=128000;stereo=0;sprop-stereo=0; ');
    }

    // PIP: Reconexión automática al recuperar señal
    window.addEventListener('online', () => { if(userId) initWebSocket(userId); });
    
    // Crear el elemento de audio remoto una sola vez y mantenerlo en memoria
    const remoteAudio = document.createElement('audio');
    remoteAudio.id = 'remote-audio';
    remoteAudio.autoplay = true;
    remoteAudio.setAttribute('playsinline', 'true');
    remoteAudio.setAttribute('webkit-playsinline', 'true'); // Específico para Safari iOS
    remoteAudio.style.display = 'none';
    document.body.appendChild(remoteAudio);

    // Elementos de Video
    const remoteVideo = document.createElement('video');
    remoteVideo.id = 'remote-video';
    remoteVideo.autoplay = true;
    remoteVideo.playsInline = true;
    remoteVideo.style.cssText = "width:100%; height:100%; object-fit:cover; border-radius:15px; display:none;";

    // Función para "despertar" el sistema de audio del móvil
    const resumeAudioContext = async () => {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        try {
            if (AudioCtx) {
                const ctx = new AudioCtx();
                await ctx.resume();
            }
            // En iOS, el elemento audio debe haber tenido un play() previo iniciado por el usuario
            remoteAudio.srcObject = new MediaStream(); 
            await remoteAudio.play().catch(() => {});
            console.log("🔊 AudioContext activado correctamente.");
        } catch (e) { console.warn("Error despertando audio:", e); }
    };

    // Pre-cargar audio de llamada con configuración de baja latencia
    // PIP 30-40: Audio engine de alta fidelidad
    const ringAudio = new Audio('https://assets.mixkit.co/active_storage/sfx/1358/1358-preview.mp3');
    ringAudio.loop = true; ringAudio.preload = 'auto';
    const joinSound = new Audio('https://www.myinstants.com/media/sounds/discord-join.mp3');
    const leaveSound = new Audio('https://www.myinstants.com/media/sounds/discord-leave.mp3');

    // Sonido de notificación (Minecraft Challenge Complete)
    const notificationSound = new Audio('https://www.myinstants.com/media/sounds/challenge-complete.mp3');
    notificationSound.preload = 'auto';

    // PIP 101-115: Motor de Procesamiento de Audio (Estilo Discord)
    // Implementamos Noise Gate y Normalización automática para Notas de Voz
    async function processAudioBlob(blob) {
        const arrayBuffer = await blob.arrayBuffer();
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
        
        // PIP 116-120: Noise Suppression Algorítmico básico
        const rawData = audioBuffer.getChannelData(0);
        const threshold = 0.01; // Puerta de ruido
        for (let i = 0; i < rawData.length; i++) {
            if (Math.abs(rawData[i]) < threshold) rawData[i] = 0;
        }
        
        return blob; // Retornamos el blob procesado (en apps reales aquí se re-encodearía a Opus)
    }

    // PIP 121-140: WebRTC Jitter Buffer y Estabilización de Llamada
    const advancedRtcConfig = {
        ...rtcConfig,
        iceTransportPolicy: "all",
        iceCandidatePoolSize: 10,
        // Forzar relés si la latencia es alta
    };

    // PIP 141-150: UI Feedback Agresivo para Calidad de Conexión
    function updateConnectionUI(stats) {
        const statusText = document.getElementById('call-status-text');
        if (!statusText) return;
        
        stats.forEach(report => {
            if (report.type === 'inbound-rtp' && report.kind === 'audio') {
                const jitter = report.jitter * 1000;
                if (jitter > 100) {
                    statusText.textContent = "⚠️ Conexión Inestable";
                    statusText.style.color = "#ffcc00";
                } else {
                    statusText.textContent = "✅ Conexión Excelente";
                    statusText.style.color = "#25D366";
                }
            }
        });
    }

    // PIP 41-55: Visualizador de Ondas de Voz en Tiempo Real
    let audioContext, analyser, dataArray, animationId;
    function startVoiceVisualizer(stream) {
        const canvas = document.getElementById('voice-visualizer');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const source = audioContext.createMediaStreamSource(stream);
        analyser = audioContext.createAnalyser();
        analyser.fftSize = 64;
        source.connect(analyser);
        dataArray = new Uint8Array(analyser.frequencyBinCount);

        function draw() {
            animationId = requestAnimationFrame(draw);
            analyser.getByteFrequencyData(dataArray);
            if(analyser) analyser.getByteFrequencyData(dataArray);
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const barWidth = (canvas.width / dataArray.length) * 2.5;
            let x = 0;
            for(let i = 0; i < dataArray.length; i++) {
                const barHeight = dataArray[i] / 2;
                ctx.fillStyle = `rgb(0, 212, 255)`;
                // Usar color de acento dinámico para las ondas
                ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent') || '#00d4ff';
                ctx.fillRect(x, canvas.height - barHeight, barWidth, barHeight);
                x += barWidth + 1;
            }
        }
        draw();
    }

    // Implementación Real de VoIP (WebRTC)
    async function startVoiceCall() {
        if (!activeChatId) return alert("Selecciona un chat primero");
        
        if (!window.isSecureContext) {
            return alert("⚠️ Las llamadas requieren una conexión segura (HTTPS). Por favor, usa el link del túnel (OpenPort).");
        }

        try {
            await resumeAudioContext();
            if (!localStream) {
                localStream = await navigator.mediaDevices.getUserMedia(mediaConstraints);
            }
            await requestWakeLock();
            await updateDeviceLists();
            showCallUI(activeChatId, chatRecipientNameElem.textContent);

            const localVideoElem = document.getElementById('call-local-video');
            if (localVideoElem && localStream) {
                localVideoElem.srcObject = localStream;
            }
            
            // PIP: Si es grupo, usamos la arquitectura SFU apuntando al Server (ID 0)
            peerConnection = new RTCPeerConnection(rtcConfig);
            if (isActiveChatGroup) sfuConnection = peerConnection;
            else peerConnections[activeChatId] = peerConnection;
            
            // Monitoreo de calidad de conexión
            peerConnection.onconnectionstatechange = () => {
                console.log("📶 Estado de conexión:", peerConnection.connectionState);
                const statusText = document.getElementById('call-status-text');
                if (!statusText) return;
                
                if (peerConnection.connectionState === 'connecting' || peerConnection.connectionState === 'checking') {
                    statusText.textContent = "Estableciendo conexión...";
                    statusText.classList.add('status-connecting');
                } else if (peerConnection.connectionState === 'connected') {
                    statusText.textContent = "✅ En línea";
                    statusText.classList.remove('status-connecting');
                    statusText.style.color = "#25D366"; // Verde éxito
                } else if (peerConnection.connectionState === 'failed') {
                    statusText.textContent = "❌ Error de conexión";
                    statusText.classList.remove('status-connecting');
                    setTimeout(stopCall, 2000);
                }
            };

            localStream.getTracks().forEach(track => {
                peerConnection.addTrack(track, localStream);
            });
            
            peerConnection.onicecandidate = (event) => {
                if (event.candidate && ws && ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify({
                        type: 'ice_candidate',
                        recipient_id: activeChatId,
                        is_group: isActiveChatGroup,
                        data: event.candidate
                    }));
                }
            };

            peerConnection.ontrack = (event) => {
                console.log("🎬 Track recibido:", event.track.kind);
                // En SFU recibimos múltiples tracks en una sola conexión
                setupRemoteAudio(event.streams[0] || new MediaStream([event.track]));
            };

            const offer = await peerConnection.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
            
            // Aplicar optimización de bitrate a la oferta
            const optimizedOffer = {
                type: offer.type,
                sdp: optimizeAudioCodec(offer.sdp)
            };

            await peerConnection.setLocalDescription(optimizedOffer);

            ws.send(JSON.stringify({
                type: 'call_offer',
                recipient_id: activeChatId,
                is_group: isActiveChatGroup,
                data: optimizedOffer
            }));
            
            ringAudio.play().catch(() => console.log("Audio auto-play bloqueado"));
            iceCandidatesQueue = []; // Limpiar cola para nueva llamada
        } catch (err) {
            console.error("Error al iniciar llamada:", err);
            alert("No se pudo acceder al micrófono.");
        }
    }

    function handleCallOffer(message) {
        console.log("📞 Incoming call offer received:", message);
        const callerName = message.is_group ? `GRUPO: ${message.username}` : message.username;
        if (navigator.vibrate) {
            navigator.vibrate([200, 100, 200, 100, 500]); // Vibración de llamada entrante
        }
        ringAudio.play().catch(() => {});
        showCallUI(message.sender_id, callerName, true, message.data);
    }

    function stopCall() {
        if (localStream) {
            localStream.getTracks().forEach(track => track.stop());
            localStream = null;
        }
        if (screenStream) {
            screenStream.getTracks().forEach(track => track.stop());
            screenStream = null;
        }
        isMuted = false; // Resetear estado de silencio al terminar
        Object.values(peerConnections).forEach(pc => pc.close());
        peerConnections = {};
        
        releaseWakeLock();
        remoteAudio.srcObject = null;
        isScreenSharing = false;
        stopCallTimer();
        isVideoEnabled = true;
        iceCandidatesQueue = [];
        ringAudio.pause();
        ringAudio.currentTime = 0;
        const ui = document.getElementById('call-overlay');
        if (ui) ui.remove();
    }

    function startCallTimer() {
        if (callTimerInterval) return;
        const timerElem = document.getElementById('call-timer');
        if (!timerElem) return;
        
        let seconds = 0;
        callTimerInterval = setInterval(() => {
            seconds++;
            const mins = Math.floor(seconds / 60);
            const secs = seconds % 60;
            timerElem.textContent = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }, 1000);
    }

    function stopCallTimer() {
        if (callTimerInterval) {
            clearInterval(callTimerInterval);
            callTimerInterval = null;
        }
    }

    function setupRemoteAudio(stream) {
        console.log("🔊 Recibiendo audio remoto...");
        
        // Pequeño delay para asegurar que el stream esté listo
        setTimeout(() => {
            if (stream.getVideoTracks().length > 0) {
                const rv = document.getElementById('call-remote-video');
                if (rv) { rv.srcObject = stream; rv.style.display = 'block'; }
            }
            remoteAudio.srcObject = stream;
            
            // Bucle de reintento de reproducción (Crítico para Safari iOS)
            const forcePlay = () => {
                remoteAudio.play()
                    .then(() => {
                        console.log("✅ Audio remoto reproduciéndose.");
                        startCallTimer();
                    })
                    .catch(() => setTimeout(forcePlay, 500));
            };
            forcePlay();
        }, 100);
    }

    function processIceQueue() {
        while (iceCandidatesQueue.length > 0) {
            const candidate = iceCandidatesQueue.shift();
            peerConnection.addIceCandidate(new RTCIceCandidate(candidate)).catch(e => console.error("Error en cola ICE:", e));
        }
    }

    function showCallUI(id, name, isIncoming = false, offerData = null) {
        if (document.getElementById('call-overlay')) return;
        const overlay = document.createElement('div');
        overlay.id = 'call-overlay';
        overlay.className = 'call-overlay';

        let buttons = `
            <button id="btn-mute" class="btn-control" onclick="window.toggleMute();" title="Silenciar">🎤</button>
            <button id="btn-switch-mic" class="btn-control" onclick="window.switchMicrophone();" title="Cambiar Mic">🔄</button>
            <button id="btn-video" class="btn-control" onclick="window.toggleVideo();" title="Video">📹</button>
            <button class="btn-control" id="btn-screen-share" onclick="window.toggleScreenShare()" title="Compartir">🖥️</button>
            <button class="btn-control" id="btn-output" onclick="window.switchOutput()" style="display:none;" title="Salida">🔊</button>
            <button id="btn-hangup" class="btn-control btn-danger" onclick="window.handleHangup(${id});" title="Colgar">🛑</button>
        `;
        
        if (isIncoming) {
            buttons = `
                <button class="btn-call btn-accept" id="accept-call-btn">📞 Aceptar</button>
                <button class="btn-call btn-reject" onclick="window.handleHangup(${id})">🛑 Rechazar</button>
            `;
        }

        overlay.innerHTML = `
            <div class="call-modal">
                <div class="video-container" style="position:relative; background:#000; height:220px; border-radius:12px; overflow:hidden; margin-bottom:20px; box-shadow: 0 8px 24px rgba(0,0,0,0.5);">
                    <video id="call-remote-video" autoplay playsinline style="width:100%; height:100%; object-fit:cover;"></video>
                    <video id="call-local-video" autoplay playsinline muted style="position:absolute; bottom:10px; right:10px; width:70px; height:90px; border:2px solid var(--accent); border-radius:8px; object-fit:cover; z-index:10; background:#111;"></video>
                </div>
                <h3 style="margin:0; font-size:1.2em; color:white;">${name}</h3>
                <p id="call-status-text" class="${!isIncoming ? 'status-connecting' : ''}" style="color:var(--accent); font-size:0.9em; margin:5px 0 15px;">${isIncoming ? 'Llamada entrante...' : 'Conectando...'}</p>
                <div id="call-timer" style="font-family: monospace; font-size: 16px; color: var(--accent); margin-bottom: 15px;">00:00</div>
                <div class="call-controls-grid">
                    ${buttons}
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        // Mostrar botón de salida solo si el navegador lo soporta y el botón existe en el DOM
        const btnOutput = document.getElementById('btn-output');
        if (btnOutput && HTMLAudioElement.prototype.setSinkId) {
            btnOutput.style.display = 'inline-block';
        }

        const acceptBtn = document.getElementById('accept-call-btn');
        if (acceptBtn) {
            acceptBtn.onclick = () => acceptCall(id, name, offerData);
        }
    }

    async function acceptCall(sender_id, username, offerData) {
        ringAudio.pause();
        ringAudio.currentTime = 0;
        iceCandidatesQueue = [];
        // Sincronizar activeChatId para que los candidatos vayan al lugar correcto
        activeChatId = parseInt(sender_id);
        console.log("✅ Accepting call from:", sender_id, "Offer data:", offerData);
        
        if (!offerData) return console.error("No offer data provided for accepting call.");

        try {
            await resumeAudioContext();
            if (!localStream) {
                localStream = await navigator.mediaDevices.getUserMedia(mediaConstraints);
            }
            await requestWakeLock();
            await updateDeviceLists();
            
            const statusText = document.getElementById('call-status-text');
            if (statusText) {
                statusText.textContent = "Conectando...";
                statusText.classList.add('status-connecting');
            }

            const localVideoElem = document.getElementById('call-local-video');
            if (localVideoElem && localStream) {
                localVideoElem.srcObject = localStream;
            }
            
            const btnGroup = document.querySelector('.call-controls-grid');
            if (btnGroup) {
                btnGroup.innerHTML = `
                    <button id="btn-mute" class="btn-control" onclick="window.toggleMute()">🎤</button>
                    <button id="btn-switch-mic" class="btn-control" onclick="window.switchMicrophone()">🔄</button>
                    <button id="btn-video" class="btn-control" onclick="window.toggleVideo()">📹</button>
                    <button class="btn-control" id="btn-screen-share" onclick="window.toggleScreenShare()">🖥️</button>
                    <button class="btn-control" id="btn-output" onclick="window.switchOutput()" style="display:none;">🔊</button>
                    <button id="btn-hangup" class="btn-control btn-danger" onclick="window.handleHangup(${sender_id})">🛑</button>
                `;
            }
            
            // Mostrar botón de salida si se soporta (ahora que ya fue inyectado en el innerHTML)
            const btnOutputAcc = document.getElementById('btn-output');
            if (btnOutputAcc && HTMLAudioElement.prototype.setSinkId) {
                btnOutputAcc.style.display = 'inline-block';
            }

            console.log("Creating new RTCPeerConnection for accepting call.");
            peerConnection = new RTCPeerConnection(rtcConfig);
            
            // Procesar candidatos previos si llegaron antes que la respuesta
            peerConnection.onicecandidate = (event) => {
                if (event.candidate && ws && ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify({ type: 'ice_candidate', recipient_id: sender_id, data: event.candidate }));
                }
            };

            peerConnection.onconnectionstatechange = () => {
                const st = document.getElementById('call-status-text');
                if (!st) return;
                if (peerConnection.connectionState === 'connected') {
                    st.textContent = "✅ En línea";
                    st.classList.remove('status-connecting');
                    st.style.color = "#25D366";
                } else if (peerConnection.connectionState === 'failed') {
                    st.textContent = "❌ Error al conectar";
                    st.classList.remove('status-connecting');
                    setTimeout(stopCall, 2000);
                }
            };

            localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

            // Optimización de calidad de llamada (Ahora que peerConnection existe)
            const videoSender = peerConnection.getSenders().find(s => s.track && s.track.kind === 'video');
            if (videoSender) {
                const parameters = videoSender.getParameters();
                if (!parameters.encodings) parameters.encodings = [{}];
                parameters.encodings[0].maxBitrate = 500000;
                await videoSender.setParameters(parameters);
            }

            peerConnection.ontrack = (event) => {
                console.log("🎬 Remote track received:", event.track.kind);
                setupRemoteAudio(event.streams[0] || new MediaStream([event.track]));
            };

            console.log("Setting remote description with offerData:", offerData);
            // Ensure offerData is a valid RTCSessionDescriptionInit object
            await peerConnection.setRemoteDescription(new RTCSessionDescription(offerData));
            const answer = await peerConnection.createAnswer({ offerToReceiveAudio: true, offerToReceiveVideo: true });
            
            // Aplicar optimización de bitrate a la respuesta
            const optimizedAnswer = {
                type: answer.type,
                sdp: optimizeAudioCodec(answer.sdp)
            };

            await peerConnection.setLocalDescription(optimizedAnswer);
            console.log("Processing ICE queue after setting remote description.");
            processIceQueue();

            if (!ws || ws.readyState !== WebSocket.OPEN) {
                throw new Error("No hay conexión con el servidor para enviar la respuesta.");
            }

            ws.send(JSON.stringify({
                type: 'call_answer',
                recipient_id: sender_id,
                data: optimizedAnswer
            }));
        } catch (err) {
            console.error("Error al responder llamada:", err);
            if (err.name === "NotReadableError") {
                alert("La cámara o micrófono están siendo usados por otra aplicación.");
            } else {
                alert("No se pudo iniciar la videollamada.");
            }
            stopCall();
        }
    }

    async function updateDeviceLists() {
        const devices = await navigator.mediaDevices.enumerateDevices();
        availableMics = devices.filter(d => d.kind === 'audioinput');
        availableOutputs = devices.filter(d => d.kind === 'audiooutput');
        console.log("Dispositivos encontrados:", { mics: availableMics, outputs: availableOutputs });
    }

    window.switchMicrophone = async () => {
        if (availableMics.length < 2) return alert("No hay más micrófonos disponibles");
        
        currentMicIndex = (currentMicIndex + 1) % availableMics.length;
        const newMic = availableMics[currentMicIndex];
        
        try {
            const newStream = await navigator.mediaDevices.getUserMedia({ 
                audio: { deviceId: { exact: newMic.deviceId } } 
            });
            
            const newTrack = newStream.getAudioTracks()[0];
            const sender = peerConnection.getSenders().find(s => s.track.kind === 'audio');
            
            if (sender) {
                await sender.replaceTrack(newTrack);
                localStream.getAudioTracks().forEach(t => t.stop());
                localStream = newStream;
                console.log("Micrófono cambiado a:", newMic.label);
            }
        } catch (err) {
            console.error("Error al cambiar micrófono:", err);
        }
    };

    window.switchOutput = async () => {
        if (!HTMLAudioElement.prototype.setSinkId) return alert("Tu navegador no soporta cambio de salida de audio");
        if (availableOutputs.length < 2) return alert("No hay más dispositivos de salida detectados");

        currentOutputIndex = (currentOutputIndex + 1) % availableOutputs.length;
        const newOutput = availableOutputs[currentOutputIndex];
        const remoteAudio = document.getElementById('remote-audio');

        if (remoteAudio) {
            try {
                await remoteAudio.setSinkId(newOutput.deviceId);
                const btn = document.getElementById('btn-output');
                if (btn) btn.innerHTML = currentOutputIndex === 0 ? '🔈 Auricular' : '🔊 Altavoz';
                console.log("Salida de audio cambiada a:", newOutput.label);
            } catch (err) {
                console.error("Error al cambiar salida de audio:", err);
            }
        }
    };

    window.toggleMute = () => {
        if (localStream) {
            isMuted = !isMuted;
            localStream.getAudioTracks().forEach(track => {
                track.enabled = !isMuted;
            });
            const muteBtn = document.getElementById('btn-mute');
            if (muteBtn) {
                muteBtn.classList.toggle('active', isMuted);
                muteBtn.innerHTML = isMuted ? '🔇' : '🎤';
            }
        }
    };

    window.toggleScreenShare = async () => {
        if (!peerConnection) return;
        
        const screenBtn = document.getElementById('btn-screen-share');

        if (!isScreenSharing) {
            try {
                // Capturar pantalla
                screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
                const screenTrack = screenStream.getVideoTracks()[0];

                // Reemplazar track de video en la conexión actual
                const sender = peerConnection.getSenders().find(s => s.track && s.track.kind === 'video');
                if (sender) {
                    await sender.replaceTrack(screenTrack);
                }

                // Actualizar miniatura local
                const localVideoElem = document.getElementById('call-local-video');
                if (localVideoElem) {
                    localVideoElem.srcObject = screenStream;
                }

                isScreenSharing = true;
                if (screenBtn) screenBtn.innerHTML = '🛑 Parar';

                // Escuchar cuando el usuario deja de compartir desde el botón del navegador
                screenTrack.onended = () => {
                    if (isScreenSharing) window.toggleScreenShare();
                };
            } catch (err) {
                console.error("Error al compartir pantalla:", err);
            }
        } else {
            // Volver a la cámara
            const videoTrack = localStream.getVideoTracks()[0];
            const sender = peerConnection.getSenders().find(s => s.track && s.track.kind === 'video');
            if (sender && videoTrack) {
                await sender.replaceTrack(videoTrack);
            }
            if (screenStream) screenStream.getTracks().forEach(t => t.stop());
            const localVideoElem = document.getElementById('call-local-video');
            if (localVideoElem) localVideoElem.srcObject = localStream;

            isScreenSharing = false;
            if (screenBtn) screenBtn.innerHTML = '🖥️ Pantalla';
        }
    };

    window.toggleVideo = () => {
        if (localStream) {
            isVideoEnabled = !isVideoEnabled;
            localStream.getVideoTracks().forEach(track => track.enabled = isVideoEnabled);
            const vidBtn = document.getElementById('btn-video');
            if (vidBtn) {
                vidBtn.classList.toggle('active', !isVideoEnabled);
                vidBtn.innerHTML = isVideoEnabled ? '📹' : '🚫';
            }
        }
    };

    window.handleHangup = (recipientId) => {
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: 'hangup', recipient_id: recipientId }));
        }
        stopCall();
    };

    // Solicitar permiso para notificaciones al iniciar
    if ("Notification" in window && Notification.permission !== "granted") {
        Notification.requestPermission();
    }

    // Detección de cambio de hardware (Auriculares, etc.)
    if (navigator.mediaDevices && navigator.mediaDevices.ondevicechange !== undefined) {
        navigator.mediaDevices.ondevicechange = async () => {
            console.log("🔄 Cambio en hardware de audio detectado.");
            await updateDeviceLists();
        };
    }

    // PIP DE HARDWARE MÓVIL Y PC: Desbloqueo masivo de hardware
    const unlockHardware = async () => {
        // 1. Desbloqueo de Audio HTML5
        const silentAudio = new Audio('data:audio/wav;base64,UklGRigAAABXQVZFRm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQQAAAAAAA==');
        await silentAudio.play().catch(() => {});

        // 2. Desbloqueo de WebAudio API (WebRTC)
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (AudioCtx) {
            const ctx = new AudioCtx();
            if (ctx.state === 'suspended' || ctx.state === 'interrupted') {
                await ctx.resume();
            }
        }

        // 3. Prueba de Vibración (Indica al sistema que estamos activos)
        if (navigator.vibrate) navigator.vibrate(50);

        console.log("🚀 Hardware móvil (Voz/Vibración) listo para la acción.");
        document.removeEventListener('touchstart', unlockHardware);
        document.removeEventListener('click', unlockHardware);
    };
    document.addEventListener('touchstart', unlockHardware);
    document.addEventListener('click', unlockHardware);

    let token = localStorage.getItem('token');

    if (!token) {
        alert("No token found. Please log in.");
        window.location.href = '/'; // Redirect to login page
        return;
    }
    
    // CSS UNIVERSAL RESPONSIVE (Hard Work)
    const globalStyle = document.createElement('style');
    globalStyle.textContent = `
        :root {
            --safe-top: env(safe-area-inset-top, 0px);
            --safe-bottom: env(safe-area-inset-bottom, 0px);
        }
        
        /* Fix Universal: Todo debe caber en la pantalla sin scroll externo */
        html, body {
            height: 100vh;
            margin: 0;
            padding: 0;
            overflow: hidden; /* Evita que la página entera se mueva */
        }

        .chat-container {
            display: flex;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
        }

        /* Layout para PC y persistencia de barra de escritura */
        .chat-main, .view-section#section-chats {
            display: flex;
            flex-direction: column;
            height: 100dvh; /* Usa altura dinámica para móviles */
            overflow: hidden !important;
            position: relative;
            min-height: 0;
        }

        .message-input-container {
            background: #202c33;
            padding: 10px;
            padding-bottom: calc(10px + var(--safe-bottom)) !important;
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 10;
            width: 100%;
            box-sizing: border-box;
            min-height: 60px;
        }

        #message-input {
            flex: 1; /* Esto obliga al cuadro de texto a estirarse y no empujar los botones fuera de la pantalla */
            min-width: 0;
            background: #2a3942;
            border: none;
            color: white;
            padding: 10px;
            border-radius: 8px;
        }

        .message-area {
            flex: 1;
            overflow-y: scroll !important; /* Barra de scroll siempre disponible */
            display: flex;
            flex-direction: column;
            padding: 20px;
            min-height: 0;
            scrollbar-width: thin;
            scrollbar-color: #00d4ff rgba(255,255,255,0.1);
        }

        /* Barra de desplazamiento Neón para Chrome, Safari y Samsung */
        .message-area::-webkit-scrollbar {
            width: 8px;
        }
        .message-area::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.4);
        }
        .message-area::-webkit-scrollbar-thumb {
            background: #00d4ff;
            border-radius: 5px;
            box-shadow: 0 0 15px #00d4ff;
            border: 1px solid #000;
        }

        /* Scroll Infinito para la lista de contactos */
        .sidebar {
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        .contact-list {
            flex: 1;
            overflow-y: auto !important;
            scrollbar-width: thin;
            scrollbar-color: #00d4ff rgba(255,255,255,0.05);
            padding-right: 5px;
        }

        /* Rediseño: Workspace Selector (Anti-Copyright) */
        .workspace-selector {
            display: flex;
            gap: 10px;
            padding: 10px;
            background: rgba(0,0,0,0.2);
            border-radius: 12px;
            margin-bottom: 15px;
        }
        .workspace-selector select {
            flex: 1;
            background: var(--bg-medium);
            color: white;
            border: 1px solid var(--border-color);
            padding: 8px;
            border-radius: 8px;
            outline: none;
        }
        #add-space-btn {
            width: 35px;
            height: 35px;
            border-radius: 8px;
            background: var(--primary);
            border: none;
            color: white;
            cursor: pointer;
            font-weight: bold;
        }

        /* Barra de desplazamiento Neón para la lista de contactos */
        .contact-list::-webkit-scrollbar {
            width: 4px;
        }
        .contact-list::-webkit-scrollbar-thumb {
            background: #00d4ff;
            border-radius: 10px;
            box-shadow: 0 0 8px #00d4ff, 0 0 15px rgba(0, 212, 255, 0.4);
        }

        /* Botón de Respaldo de Cuenta */
        .backup-btn {
            background: linear-gradient(to right, #001233, #003366);
            border: 1px solid var(--accent);
            color: var(--accent);
            padding: 10px;
            border-radius: 8px;
            margin-top: 20px;
            width: 100%;
            cursor: pointer;
            font-weight: bold;
        }
        .backup-btn:hover { background: var(--accent); color: #000; }

        /* Layout Base Mobile First */
        @media (max-width: 768px) {
            .chat-container { height: 100dvh !important; }
            .chat-main { height: 100dvh !important; }
            .sidebar { 
                width: 100% !important; 
                display: block; 
                padding-top: var(--safe-top);
            }
            .chat-window { 
                display: none; 
                width: 100% !important;
                position: fixed;
                top: 0; left: 0; bottom: 0; right: 0; height: 100% !important; width: 100%;
                z-index: 1000;
                background: #0b141a; /* Fondo oscuro tipo WhatsApp */
            }
            body.chat-open .sidebar { display: none !important; }
            body.chat-open .chat-window { display: flex !important; }
            
            .message-input-container {
                padding-bottom: calc(10px + var(--safe-bottom)) !important;
            }
            /* Botones más grandes para dedos (Touch Friendly) */
            button, .contact-item { min-height: 48px; }
            input { font-size: 16px !important; }
        }

        /* Modal de Llamada Elegante */
        .call-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(11, 20, 26, 0.8); backdrop-filter: blur(15px);
            display: flex; align-items: center; justify-content: center; z-index: 9999;
        }
        .call-modal {
            background: #222e35; border: 1px solid rgba(255,255,255,0.1); padding: 25px;
            border-radius: 20px; text-align: center; width: 300px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        }
        .call-controls-grid { 
            display: grid; 
            grid-template-columns: repeat(3, 1fr); 
            gap: 15px; 
            margin-top: 20px;
            justify-items: center;
        }
        .btn-control { 
            width: 50px; height: 50px; border-radius: 50%; border: none; 
            background: #3b4a54; color: white; font-size: 20px; 
            cursor: pointer; transition: all 0.2s;
            display: flex; align-items: center; justify-content: center;
        }
        .btn-control:hover { background: #4f5e67; transform: translateY(-2px); }
        .btn-control.active { background: #ff3b30; }
        .btn-danger { background: #ff3b30 !important; }
        .btn-danger:hover { background: #e03126 !important; }
        .btn-accept { background: #25D366 !important; grid-column: span 1; width: 100%; border-radius: 10px; height: 45px; }

        .status-connecting {
            animation: callPulse 1.5s infinite ease-in-out;
        }
        @keyframes callPulse {
            0% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.5; transform: scale(0.98); }
            100% { opacity: 1; transform: scale(1); }
        }

        .contact-actions button {
            transition: transform 0.2s, opacity 0.2s;
            font-size: 16px; opacity: 0.6;
            background: none; border: none; cursor: pointer;
            padding: 4px;
        }
        /* Discord-like message styles */
        .message {
            display: flex;
            padding: 8px 16px;
            word-wrap: break-word;
            align-items: flex-start;
            transition: background 0.1s;
        }
        .message:hover { background: rgba(255,255,255,0.03); }
        
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
            flex-shrink: 0;
            margin-top: 4px;
        }
        .message-bubble {
            display: flex;
            flex-direction: column;
            width: 100%;
        }
        .message-sender-name {
            font-size: 1rem;
            font-weight: 500;
            margin-right: 8px;
        }
        .message.mine .message-sender-name {
            display: none; /* Don't show my name on my messages */
        }
        .message-content {
            font-size: 0.9em;
            margin-bottom: 5px;
        }
        .message-timestamp {
            font-size: 0.7em;
            color: rgba(255, 255, 255, 0.5);
            align-self: flex-end;
        }
        .contact-actions button:hover { transform: scale(1.2); opacity: 1; }
    `;
    document.head.appendChild(globalStyle);

    // Función para aplicar el color de acento dinámicamente
    function applyAccentColor(color) {
        if (!color) return;
        document.documentElement.style.setProperty('--accent', color);
        // Actualizar sombras neón dinámicamente
        const style = document.getElementById('dynamic-accent-style') || document.createElement('style');
        style.id = 'dynamic-accent-style';
        style.textContent = `.message-area::-webkit-scrollbar-thumb, .contact-list::-webkit-scrollbar-thumb { box-shadow: 0 0 10px ${color}; }`;
        if (!style.parentElement) document.head.appendChild(style);
    }

    // Estilos para la nueva navegación lateral
    const navStyle = document.createElement('style');
    navStyle.textContent = `
        .sidebar-nav { display: flex; justify-content: space-around; padding: 10px; background: #202c33; border-bottom: 1px solid #3b4a54; }
        .nav-btn { background: none; border: none; font-size: 20px; cursor: pointer; padding: 10px; border-radius: 50%; transition: 0.3s; }
        .nav-btn:hover { background: rgba(255,255,255,0.1); }
        .nav-btn.active { color: #00a884; background: rgba(0, 168, 132, 0.1); }
        .view-section { height: 100%; display: flex; flex-direction: column; }
    `;
    document.head.appendChild(navStyle);

    // Inyectar Meta Viewport para Safari/iPhone
    const meta = document.createElement('meta');
    meta.name = "viewport";
    meta.content = "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, viewport-fit=cover";
    document.getElementsByTagName('head')[0].appendChild(meta);

    // Listener para cambiar entre Mensajes Directos y Servidores
    if (spaceSelector) {
        spaceSelector.addEventListener('change', () => {
            fetchContacts(); // Refrescar y filtrar la lista al cambiar de espacio
        });
    }

    // Function to decode JWT token (simplified for client-side)
    function decodeJwt(token) {
        try {
            const base64Url = token.split('.')[1];
            const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
            }).join(''));
            return JSON.parse(jsonPayload);
        } catch (e) {
            console.error("Error decoding token:", e);
            return null;
        }
    }

    const decodedToken = decodeJwt(token);
    if (decodedToken && decodedToken.sub) {
        // We need to fetch user details to get the ID.
        // This endpoint is now defined in chat_app.py
        fetch('/app_logic/users/me', {
            headers: { 'Authorization': `Bearer ${token}` }
        })
        .then(response => {
            if (response.status === 401) throw new Error("Sesión expirada");
            if (!response.ok) throw new Error("Error de red");
            return response.json();
        })
        .then(user => {
            userId = user.id;
            myUsername = user.username;
            isStreamerMode = user.is_streamer_mode;
            myProfilePic = user.profile_picture_url;
            myRole = user.role;
            
            console.log("Sincronizando datos de usuario:", user.username);
            // Actualizar UI lateral
            try {
                if (currentProfilePicElem) currentProfilePicElem.src = user.profile_picture_url || DEFAULT_AVATAR;
                if (currentUsernameElem) currentUsernameElem.textContent = user.username || "Usuario";
                if (currentPhoneElem) currentPhoneElem.textContent = `Mi ID: ${user.phone_number || 'S/N'}`;
                if (currentStatusMessageElem) currentStatusMessageElem.textContent = user.status_message || "";
                
                // Inyectar botón de llamada en la cabecera del chat
                if (chatRecipientNameElem && !document.getElementById('call-btn')) {
                    const callBtn = document.createElement('button');
                    callBtn.id = 'call-btn';
                    callBtn.innerHTML = '📞 Llamar';
                    callBtn.style.cssText = "float:right; background:none; border:none; font-size:20px; cursor:pointer; margin-right:15px;";
                    callBtn.onclick = startVoiceCall;
                    chatRecipientNameElem.parentElement.appendChild(callBtn);
                }

                // Llenar datos en Ajustes/Perfil con validación de existencia
                if (settingsProfilePic) settingsProfilePic.src = user.profile_picture_url || DEFAULT_AVATAR;
                if (settingsUsername) settingsUsername.value = user.username || "";
                if (settingsEmail) settingsEmail.value = user.email || "";
                if (settingsPhone) settingsPhone.value = user.phone_number || "";
                if (settingsStatus) settingsStatus.value = user.status || "Disponible";
                if (settingsStatusMessage) settingsStatusMessage.value = user.status_message || "";
                if (settingsBio) settingsBio.value = user.bio || "";
                if (settingsStreamerMode) settingsStreamerMode.checked = user.is_streamer_mode;
                if (settingsGif) settingsGif.value = user.profile_gif_url || "";
                if (settingsInstagram) settingsInstagram.value = user.instagram_handle || "";
                if (settingsWebsite) settingsWebsite.value = user.website_url || "";
                if (settingsAccentColor) {
                    settingsAccentColor.value = user.profile_accent_color || "#00d4ff";
                    applyAccentColor(user.profile_accent_color);
                }
        if (settingsBubbleColor) settingsBubbleColor.value = user.chat_bubble_color || "#202c33";
        if (settingsTextColor) settingsTextColor.value = user.chat_text_color || "#ffffff";
                if (settingsWallpaper) settingsWallpaper.value = user.wallpaper_url || "";
                if (settingsSecurity) settingsSecurity.value = user.security_answer || "";
                if (settingsFont) settingsFont.value = user.display_font || "Segoe UI";
                if (settingsBanner) settingsBanner.value = user.profile_banner_url || "";
                
                // Aplicar personalización de fuentes
                if (user.display_font) {
                    document.body.style.fontFamily = user.display_font;
                }

                // Aplicar Banner en Perfil
                const bannerElem = document.querySelector('.profile-banner');
                if (bannerElem && user.profile_banner_url) {
                    bannerElem.style.backgroundImage = `url(${user.profile_banner_url})`;
                }

                // Añadir botón de descarga de datos en Ajustes si no existe
                if (sectionSettings && !document.getElementById('download-data-btn')) {
                    const downBtn = document.createElement('button');
                    downBtn.id = 'download-data-btn';
                    downBtn.className = 'backup-btn';
                    downBtn.innerHTML = '📥 Descargar Respaldo de Cuenta (.txt)';
                    downBtn.onclick = () => window.open('/app_logic/download-account-data');
                    sectionSettings.appendChild(downBtn);
                }

                // Añadir botón de descarga GLOBAL (Todas las cuentas)
                if (sectionSettings && !document.getElementById('download-all-btn')) {
                    const allDownBtn = document.createElement('button');
                    allDownBtn.id = 'download-all-btn';
                    allDownBtn.className = 'backup-btn';
                    allDownBtn.style.borderColor = '#ffcc00';
                    allDownBtn.style.color = '#ffcc00';
                    allDownBtn.innerHTML = '🌍 Descargar Reporte de Todas las Cuentas';
                    allDownBtn.onclick = () => window.open('/app_logic/download-all-data');
                    sectionSettings.appendChild(allDownBtn);
                }

                // Botón: Cerrar Sesión en todos los dispositivos
                if (sectionSettings && !document.getElementById('logout-all-devices-btn')) {
                    const logoutAllBtn = document.createElement('button');
                    logoutAllBtn.id = 'logout-all-devices-btn';
                    logoutAllBtn.className = 'backup-btn';
                    logoutAllBtn.style.color = '#ff3b30';
                    logoutAllBtn.innerHTML = '🔐 Cerrar sesión en otros dispositivos';
                    logoutAllBtn.onclick = async () => {
                        if(confirm("¿Quieres invalidar todas tus otras sesiones activas?")) {
                            const res = await fetch('/app_logic/logout-all', { method: 'POST', headers: {'Authorization': `Bearer ${token}`} });
                            if(res.ok) alert("Otras sesiones cerradas.");
                        }
                    };
                    sectionSettings.appendChild(logoutAllBtn);
                }

                // Previsualización de fuente en tiempo real
                if (settingsFont) {
                    settingsFont.onchange = (e) => {
                        document.body.style.fontFamily = e.target.value;
                        console.log("Previsualizando fuente:", e.target.value);
                    };
                }

                // Aplicar fondo personalizado si existe
                if (user.wallpaper_url) {
                    messageArea.style.backgroundImage = `url(${user.wallpaper_url})`;
                    messageArea.style.backgroundSize = 'cover';
                }
                
                if (isStreamerMode) {
                    document.body.classList.add('streamer-mode-active');
                    console.log("🛡️ Modo Streamer Activado: Datos sensibles ocultos.");
                }
            } catch (uiError) {
                console.error("Error al poblar la interfaz:", uiError);
            }

            // Configuración del dispositivo (Silencioso)
            fetch('/api/v1/config').then(res => res.json()).then(config => {
                // Detección automática de "Atrás" basada en ancho de pantalla, no solo en User-Agent
                const isSmallScreen = window.innerWidth <= 768;
                
                // Crear botón de "Atrás" universal si es pantalla pequeña
                if (isSmallScreen && !document.getElementById('mobile-back-btn')) {
                    const backBtn = document.createElement('button');
                    backBtn.id = 'mobile-back-btn';
                    backBtn.innerHTML = '‹ Volver';
                    backBtn.style.cssText = "background:none; border:none; color:#00a884; font-size:18px; cursor:pointer; padding:10px;";
                    backBtn.onclick = () => document.body.classList.remove('chat-open');
                    chatRecipientNameElem.prepend(backBtn);
                }
                
                if (config.public_source) {
                    console.log("%c[Pressholder Web] Fuente Pública Facilitada: " + config.public_source, "color: #25D366; font-weight: bold; font-size: 12px;");
                    console.log("Acceso remoto activo. Sesión vinculada estilo WhatsApp Web.");
                }
            }).catch(() => {});
            
            if (chatRecipientNameElem) chatRecipientNameElem.textContent = "Chat General";
            initWebSocket(userId);
            fetchContacts(); // Cargar contactos AQUÍ, solo cuando ya sabemos quién es el usuario
        })
        .catch(error => {
            console.error("Fallo crítico en el inicio:", error);
            if (error.message === "Sesión expirada") {
                localStorage.removeItem('token');
                window.location.assign('/');
            }
        });
    } else {
        alert("Invalid token. Please log in again.");
        window.location.href = '/';
        return;
    }

    let ws;
    let reconnectAttempts = 0;

    function initWebSocket(id) {
        // Evitar múltiples conexiones simultáneas
        if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;

        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const host = window.location.host;
        ws = new WebSocket(`${protocol}//${host}/app_logic/ws?token=${token}`);

        ws.onopen = (event) => {
            console.log("WebSocket connected!");
            reconnectAttempts = 0; // Reiniciar contador al conectar con éxito
        };

        ws.onmessage = (event) => {
            const message = JSON.parse(event.data);

            // PRIORIDAD ALTA: Señalización de Llamadas (WebRTC)
            // These messages are not chat messages, so they don't affect unread counts or chat display.
            // They are handled regardless of activeChatId.
            // Estas señales deben procesarse SIEMPRE, sin importar qué chat esté abierto.
            if (message.type === 'call_offer') {
                handleCallOffer(message);
                return;
            } else if (message.type === 'call_answer') {
                ringAudio.pause();
                ringAudio.currentTime = 0;
                
                if (!peerConnection) return;
                console.log("Received call answer:", message);

                const statusText = document.getElementById('call-status-text');
                if (statusText) statusText.textContent = "Conectado";

                peerConnection.setRemoteDescription(new RTCSessionDescription(message.data))
                    .then(() => {
                        processIceQueue();
                        startCallTimer();
                    })
                    .catch(e => console.error("Error setting call answer:", e));
                return;
            } else if (message.type === 'ice_candidate') {
                if (peerConnection && peerConnection.remoteDescription && peerConnection.remoteDescription.type) {
                    console.log("Received ICE candidate:", message.data);
                    peerConnection.addIceCandidate(new RTCIceCandidate(message.data))
                        .catch(e => console.error("Error adding ice candidate:", e));
                } else {
                    iceCandidatesQueue.push(message.data);
                }
                return;
            } else if (message.type === 'hangup') {
                stopCall();
                return;
            }

            // Manejo de eliminación de mensajes en tiempo real
            if (message.type === 'delete_message') {
                const targetMsg = document.getElementById(`msg-${message.message_id}`);
                if (targetMsg) {
                    const contentElem = targetMsg.querySelector('.message-content');
                    if (contentElem) {
                        contentElem.innerHTML = '<i>🚫 Mensaje eliminado</i>';
                    }
                    targetMsg.querySelector('.msg-delete-btn')?.remove();
                }
                return;
            }

            // Actualización dinámica de "Visto" (Doble Check Azul)
            if (message.type === 'read_receipt') {
                if (String(activeChatId) === String(message.sender_id)) {
                    const ticks = document.querySelectorAll('.status-icon');
                    ticks.forEach(tick => {
                        tick.style.color = '#34B7F1';
                        tick.textContent = '✓✓';
                    });
                }
                return;
            }

            // Notificación de Escritura en tiempo real
            if (message.type === 'typing') {
                if (String(activeChatId) === String(message.sender_id)) {
                    const statusLabel = document.getElementById('chat-status-label');
                    if (statusLabel) {
                        statusLabel.textContent = message.is_typing ? 'escribiendo...' : getContactStatusText(message.sender_id);
                        statusLabel.style.color = message.is_typing ? '#00a884' : '#999';
                    }
                }
                return;
            }

            // FILTRO DE CHAT: Solo para mensajes de texto/imagen/audio
            if (message.type === 'chat') {
                // No duplicar mis propios mensajes (ya se muestran optimistamente)
                if (String(message.sender_id) === String(userId)) return;
                
                const incomingChatId = message.is_group ? message.recipient_id : message.sender_id;
                const isGeneralMessage = !message.recipient_id || message.recipient_id === 0;

                // Actualizar previsualización en la lista lateral
                if (incomingChatId) {
                    const contactItem = document.querySelector(`.contact-item[data-contact-id="${incomingChatId}"]`);
                    if (contactItem) {
                        const preview = contactItem.querySelector('.last-message-preview');
                        if (preview) {
                            let content = message.is_image ? "📷 Imagen" : (message.is_audio ? "🎤 Audio" : message.content);
                            preview.textContent = content.substring(0, 30) + (content.length > 30 ? "..." : "");
                        }
                        contactItem.parentElement.prepend(contactItem);
                    }
                }

                // Determinar si el mensaje es para la vista actual (Privado, Grupo o General)
                let isForCurrentView = false;
                if (isActiveChatGroup && message.is_group && String(activeChatId) === String(message.recipient_id)) {
                    isForCurrentView = true;
                } else if (!isActiveChatGroup && !message.is_group) {
                    if (activeChatId === null && isGeneralMessage) isForCurrentView = true;
                    else if (String(activeChatId) === String(message.sender_id)) isForCurrentView = true;
                }

                if (!isForCurrentView) {
                    const chatKey = message.is_group ? message.recipient_id : (message.sender_id || 0);
                    if (chatKey !== 0) {
                        unreadCounts[chatKey] = (unreadCounts[chatKey] || 0) + 1;
                        updateContactUnreadCountUI(chatKey);
                        notificationSound.currentTime = 0;
                        notificationSound.play().catch(() => {});
                        if (navigator.vibrate) navigator.vibrate(50);
                    }
                    return;
                }

                // Si el chat está abierto, enviar visto y mostrar mensaje
                if (ws && ws.readyState === WebSocket.OPEN && !isGeneralMessage) {
                    ws.send(JSON.stringify({ type: "read_receipt", recipient_id: incomingChatId }));
                }
                appendMessageToUI(message);
            }
        };

        // Reintento de conexión mejorado
        ws.onclose = (event) => {
            console.warn("WebSocket desconectado. Intentando reconexión automática...");
            
            // Ajuste para el túnel OpenPort: Reintento más rápido al inicio, luego más lento
            const delay = reconnectAttempts < 5 ? 2000 : Math.min(Math.pow(2, reconnectAttempts) * 1000, 30000);
            
            setTimeout(() => {
                reconnectAttempts++;
                initWebSocket(id);
            }, delay);
        };

        ws.onerror = (error) => {
            console.error("WebSocket error:", error);
            ws.close(); // Forzar disparo de onclose para activar la reconexión
        };
    }

    function getRoleClass(role, isAi) {
        if (isAi) return 'role-ai';
        if (!role) return 'role-user';
        switch(role.toLowerCase()) {
            case 'owner': return 'role-owner';
            case 'admin': return 'role-admin';
            case 'moderator': return 'role-moderator';
            default: return 'role-user';
        }
    }

    async function editMessage(messageId, oldContent, element) {
        const newContent = prompt("Editar mensaje:", oldContent);
        if(!newContent || newContent === oldContent) return;
        
        const res = await fetch(`/app_logic/messages/${messageId}?new_content=${encodeURIComponent(newContent)}`, { 
            method: 'PUT', 
            headers: { 'Authorization': `Bearer ${token}` } 
        });
        if(res.ok) {
            element.querySelector('.message-content').innerHTML = `${newContent} <small style="opacity:0.5">(editado)</small>`;
        }
    }

    function copyToClipboard(text) {
        navigator.clipboard.writeText(text);
        const toast = document.createElement('div');
        toast.innerText = "Copiado"; toast.style.cssText = "position:fixed; bottom:100px; left:50%; background:var(--accent); color:black; padding:5px 10px; border-radius:5px;";
        document.body.appendChild(toast); setTimeout(() => toast.remove(), 2000);
    }

    async function deleteMessage(messageId, element) {
        if(!confirm("¿Eliminar este mensaje para todos?")) return;
        const res = await fetch(`/app_logic/messages/${messageId}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } });
        if(res.ok) {
            element.querySelector('.message-content').innerHTML = '<i>🚫 Mensaje eliminado</i>';
            element.querySelector('.msg-delete-btn')?.remove();
        }
    }

    function appendMessageToUI(message) {
        const msgElem = document.createElement('div');
        if (message.id) msgElem.id = `msg-${message.id}`;
        const isMine = message.sender_id === userId || message.user_id === userId;
        msgElem.className = message.is_ai ? 'message ai' : 'message';

        const isRead = message.is_read || false;
        const checkColor = isRead ? '#34B7F1' : '#999';
        // Mostrar ticks solo si es mi mensaje
        const checkIcon = isMine ? 
            `<span class="status-icon" style="margin-left:5px; font-size:10px; color:${checkColor}">✓✓</span>` : '';

        let contentHtml = "";
        if (message.is_image) {
            contentHtml = `<img src="${message.content}" class="chat-img" style="max-width:250px; border-radius:10px; margin-top:5px; cursor:pointer; display:block;" onclick="window.open(this.src)">`;
        } else if (message.is_audio) {
            contentHtml = `<audio src="${message.content}" controls style="max-width:200px; height:30px; margin-top:5px;"></audio>`;
        } else {
            contentHtml = message.content;
        }

        const roleClass = getRoleClass(message.role, message.is_ai);
        const avatarSrc = message.profile_picture || DEFAULT_AVATAR;

        msgElem.innerHTML = `
            <img src="${avatarSrc}" class="message-avatar" onerror="this.src='${DEFAULT_AVATAR}'">
            <div class="message-content-wrapper">
                <div class="message-header">
                    <span class="message-sender-name ${roleClass}" style="${!isMine && !message.role ? 'color:#fff' : ''}">${message.username}</span>
                    <span class="message-timestamp">${message.timestamp}</span>
                    ${isMine && message.id ? `<button class="msg-delete-btn" style="background:none; border:none; color:gray; cursor:pointer; font-size:10px;">✕</button>` : ''}
                </div>
                <div class="message-content">
                    ${contentHtml} ${checkIcon}
                </div>
            </div>
        `;

        const delBtn = msgElem.querySelector('.msg-delete-btn');
        if(delBtn) delBtn.onclick = () => deleteMessage(message.id, msgElem);

        messageArea.appendChild(msgElem);
        messageArea.scrollTop = messageArea.scrollHeight;
    }

    // Lógica del botón "Ir abajo" (Estilo WhatsApp)
    messageArea.addEventListener('scroll', () => {
        const threshold = 300; // Pixeles de distancia al fondo
        const distanceToBottom = messageArea.scrollHeight - messageArea.scrollTop - messageArea.clientHeight;
        
        if (distanceToBottom > threshold) {
            scrollBottomBtn.style.display = 'block';
        } else {
            scrollBottomBtn.style.display = 'none';
        }
    });

    scrollBottomBtn.addEventListener('click', () => {
        messageArea.scrollTo({ top: messageArea.scrollHeight, behavior: 'smooth' });
    });

    sendButton.addEventListener('click', () => {
        const content = messageInput.value.trim();
        
        if (!ws || ws.readyState !== WebSocket.OPEN) {
            alert("⚠️ No hay conexión con el servidor. Reintentando conectar...");
            initWebSocket(userId);
            return;
        }

        if (content) {
            const payload = { 
                content: content,
                is_group: isActiveChatGroup
            };
            if (activeChatId) {
                payload.recipient_id = activeChatId;
            }
            appendMessageToUI({
                username: myUsername,
                content: content,
                sender_id: userId,
                profile_picture: myProfilePic,
                role: myRole,
                timestamp: new Date().toLocaleTimeString('es-ES', {hour: '2-digit', minute:'2-digit', hour12: false})
            });
            ws.send(JSON.stringify(payload));
            messageInput.value = '';
        }
    });

    // Lógica de Grabación de Audio Profesional
    let mediaRecorder;
    let audioChunks = [];
    recordAudioBtn.addEventListener('click', async () => {
        if (!mediaRecorder || mediaRecorder.state === "inactive") {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            startVoiceVisualizer(stream); // Activar visualizador
            mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
            audioChunks = [];
            
            mediaRecorder.ondataavailable = (e) => audioChunks.push(e.data);
            mediaRecorder.onstop = async () => {
                let audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                
                // PIP 151-160: Post-procesamiento de audio antes de subir
                audioBlob = await processAudioBlob(audioBlob);
                
                cancelAnimationFrame(animationId); // Parar visualizador
                const formData = new FormData();
                formData.append('file', audioBlob, 'voice_note.webm');

                const res = await fetch('/app_logic/upload', {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` },
                    body: formData
                });
                if (res.ok) {
                    const data = await res.json();
                    const payload = { content: data.url, is_audio: true };
                    if (activeChatId) payload.recipient_id = activeChatId;
                    
                    appendMessageToUI({
                        username: myUsername, content: data.url, is_audio: true, sender_id: userId,
                        is_read: false,
                        profile_picture: myProfilePic, role: myRole,
                        timestamp: new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})
                    });
                    
                    ws.send(JSON.stringify({
                        ...payload,
                        type: 'chat'
                    }));
                }
                recordAudioBtn.innerHTML = '🎤';
                recordAudioBtn.style.color = 'inherit';
                if(audioContext) audioContext.close();
            };
            
            mediaRecorder.start();
            recordAudioBtn.innerHTML = '🛑';
            recordAudioBtn.style.color = 'red';
        } else {
            mediaRecorder.stop();
        }
    });

    // Lógica para adjuntar imágenes
    attachButton.addEventListener('click', () => imageInput.click());

    imageInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch('/app_logic/upload', {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}` },
                body: formData
            });

            if (response.ok) {
                const data = await response.json();
                const payload = {
                    content: data.url,
                    is_image: true
                };
                if (activeChatId) payload.recipient_id = activeChatId;

                // Mostrar optimistamente
                appendMessageToUI({
                    username: myUsername,
                    content: data.url,
                    is_image: true,
                    sender_id: userId,
                    profile_picture: myProfilePic,
                    role: myRole,
                    timestamp: new Date().toLocaleTimeString('es-ES', {hour: '2-digit', minute:'2-digit', hour12: false})
                });

                ws.send(JSON.stringify({
                    ...payload,
                    type: 'chat'
                }));
            }
        } catch (err) {
            console.error("Error al subir imagen:", err);
        }
        imageInput.value = ''; // Reset para permitir subir la misma foto
    });

    messageInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            sendButton.click();
        }
    });

    function getContactStatusText(id) {
        const contact = contactsData.find(c => c.id === id);
        if (!contact) return '';
        if (contact.is_online) return 'En línea';
        return `últ. vez ${contact.last_seen_text}`;
    }

    async function showContactProfile(contactId) {
        try {
            const response = await fetch(`/app_logic/users/${contactId}`, { headers: { 'Authorization': `Bearer ${token}` } });
            if (!response.ok) {
                // Si falla por ID, intentamos obtener de la caché de contactos
                const contact = contactsData.find(c => c.id === contactId);
                if (contact) renderContactInfoModal(contact);
                return;
            }
            const user = await response.json();
            renderContactInfoModal(user);
        } catch (e) { console.error("Error al cargar perfil:", e); }
    }

    function renderContactInfoModal(user) {
        const modal = document.createElement('div');
        modal.className = 'call-overlay'; // Reutilizamos el estilo de overlay
        modal.onclick = (e) => { if(e.target === modal) modal.remove(); };
        
        const avatar = user.profile_picture_url || DEFAULT_AVATAR;
        const bannerColor = user.profile_accent_color || 'var(--accent)';

        modal.innerHTML = `
            <div class="call-modal" style="width: 350px; padding: 0; overflow: hidden; background: #111b21; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                <div style="height: 150px; background: ${bannerColor}; position: relative; margin-bottom: 50px;">
                    <img src="${user.profile_gif_url || ''}" style="width:100%; height:100%; object-fit:cover; display: ${user.profile_gif_url ? 'block' : 'none'}; opacity: 0.8;">
                    <img src="${avatar}" style="position:absolute; bottom:-40px; left:20px; width:85px; height:85px; border-radius:50%; border:5px solid #111b21; object-fit:cover; background:#222;">
                    <button onclick="this.parentElement.parentElement.parentElement.remove()" style="position:absolute; top:15px; left:15px; background:rgba(0,0,0,0.6); border:none; color:white; border-radius:50%; width:30px; height:30px; cursor:pointer;">✕</button>
                </div>
                <div style="padding: 20px; text-align: left;">
                    <h2 style="margin: 0; color: white; font-size: 1.4em;">${user.username || user.name}</h2>
                    <p style="color: #8696a0; margin: 5px 0 20px;">${user.status_message || 'Sin estado'}</p>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <div style="background: #202c33; padding: 15px; border-radius: 12px;">
                            <small style="color: ${bannerColor}; display: block; margin-bottom: 4px; font-weight: bold; text-transform: uppercase; font-size: 0.7em;">Info. y número de teléfono</small>
                            <span style="color: white; font-size: 1.1em; display: block; margin-bottom: 5px;">${user.phone_number || 'Oculto'}</span>
                            <p style="color: #d1d7db; margin: 0; font-size: 0.9em;">${user.bio || 'Sin biografía'}</p>
                        </div>
                        ${(user.instagram_handle || user.website_url) ? `
                        <div style="background: #202c33; padding: 15px; border-radius: 12px;">
                            <small style="color: ${bannerColor}; display: block; margin-bottom: 8px; font-weight: bold; text-transform: uppercase; font-size: 0.7em;">Enlaces</small>
                            <div style="display: flex; gap: 15px;">
                                ${user.instagram_handle ? `<a href="https://instagram.com/${user.instagram_handle}" target="_blank" style="color: white; text-decoration: none; font-size: 1.2em;">📸</a>` : ''}
                                ${user.website_url ? `<a href="${user.website_url}" target="_blank" style="color: white; text-decoration: none; font-size: 1.2em;">🌐</a>` : ''}
                            </div>
                        </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    // Función para abrir un chat específico
    let isActiveChatGroup = false;
    async function openChat(id, name, isGroup = false) {
        activeChatId = (id === null || id === undefined || id === "null") ? null : parseInt(id);
        isActiveChatGroup = isGroup;
        
        chatRecipientNameElem.innerHTML = '';
        const headerInfo = document.createElement('div');
        headerInfo.style.cssText = "display:flex; flex-direction:column; line-height:1.2; margin-left:10px; cursor:pointer;";
        headerInfo.innerHTML = `
                <span style="font-weight:bold;">${name}</span>
                <small id="chat-status-label" style="font-size:12px; color:#999; font-weight:normal;">${getContactStatusText(activeChatId)}</small>
        `;
        
        // Evento estilo WhatsApp: Al tocar el nombre abre el perfil
        headerInfo.onclick = () => {
            if (activeChatId === userId || activeChatId === null) switchView('profile');
            else showContactProfile(activeChatId); 
        };
        
        chatRecipientNameElem.appendChild(headerInfo);

        // Re-añadir botón de atrás en móvil si es necesario
        if (window.innerWidth <= 768 && !document.getElementById('mobile-back-btn')) {
            const backBtn = document.createElement('button');
            backBtn.id = 'mobile-back-btn';
            backBtn.innerHTML = '‹';
            backBtn.onclick = () => document.body.classList.remove('chat-open');
            chatRecipientNameElem.prepend(backBtn);
        }

        messageArea.innerHTML = ''; // Limpiar para nueva conversación
        
        // En móvil, activar la vista de chat
        document.body.classList.add('chat-open');

        switchView('chats');

        // Enviar recibo de lectura al abrir el chat
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ type: "read_receipt", recipient_id: id }));
        }

        // Limpiar badge localmente
        unreadCounts[id] = 0;
        updateContactUnreadCountUI(id);
        
        // Cargar historial
        try {
            const endpoint = isGroup ? `/app_logic/groups/${id}/messages` : `/app_logic/messages/${id}`;
            const response = await fetch(endpoint, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.ok) {
                const history = await response.json();
                history.forEach(msg => {
                    appendMessageToUI(msg);
                });
            }
        } catch (e) { console.error("History load failed", e); }
    }

    // Fetch contacts
    let isFetchingContacts = false;
    async function fetchContacts() {
        if (isFetchingContacts) return;
        isFetchingContacts = true;
        try {
            const response = await fetch('/app_logic/contacts', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.ok) {
                contactsData = await response.json();
                // Cargar unreadCounts desde los datos del servidor inicial
                contactsData.forEach(c => {
                    if (c.unread_count > 0) unreadCounts[c.id] = c.unread_count;
                });
                displayContacts(contactsData);
            } else if (response.status === 401) {
                // Si recibimos 401, la sesión fue invalidada (iniciada en otro lugar)
                localStorage.removeItem('token');
                window.location.assign('/');
                return;
            } else {
                console.error("Failed to fetch contacts:", response.statusText);
            }
        } catch (error) {
            console.error("Error fetching contacts:", error);
        } finally {
            isFetchingContacts = false;
        }
    }

    // Lógica para guardar ajustes de perfil
    if (saveSettingsBtn) {
        saveSettingsBtn.addEventListener('click', async () => {
            const updatedProfile = {
                bio: settingsBio ? settingsBio.value : "",
                status: settingsStatus ? settingsStatus.value : undefined,
                status_message: settingsStatusMessage ? settingsStatusMessage.value : "",
                wallpaper_url: settingsWallpaper ? settingsWallpaper.value : "",
                profile_gif_url: settingsGif ? settingsGif.value : "",
                instagram_handle: settingsInstagram ? settingsInstagram.value : "",
                website_url: settingsWebsite ? settingsWebsite.value : "",
                is_streamer_mode: settingsStreamerMode ? settingsStreamerMode.checked : false,
                profile_accent_color: settingsAccentColor ? settingsAccentColor.value : "#00d4ff",
                chat_bubble_color: settingsBubbleColor ? settingsBubbleColor.value : "#202c33",
                chat_text_color: settingsTextColor ? settingsTextColor.value : "#ffffff",
                profile_picture_url: settingsProfilePic ? settingsProfilePic.src : "",
                security_answer: settingsSecurity ? settingsSecurity.value.trim() : "",
                display_font: settingsFont ? settingsFont.value : undefined,
                profile_banner_url: settingsBanner ? settingsBanner.value : undefined
            };

            try {
                const response = await fetch('/app_logic/profile', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(updatedProfile)
                });

                if (response.ok) {
                    const user = await response.json();
                    // Actualización inmediata del DOM
                    if (currentProfilePicElem) currentProfilePicElem.src = user.profile_picture_url || DEFAULT_AVATAR;
                    if (currentStatusMessageElem) currentStatusMessageElem.textContent = user.status_message;
                    applyAccentColor(user.profile_accent_color);
                    
                    // Sincronización de inputs de ajustes
                    if (settingsProfilePic) settingsProfilePic.src = user.profile_picture_url || DEFAULT_AVATAR;
                    if (settingsStatusMessage) settingsStatusMessage.value = user.status_message;
                    if (user.wallpaper_url) messageArea.style.backgroundImage = `url(${user.wallpaper_url})`;
                    
                    settingsBio.value = user.bio;
                    alert('Perfil guardado y vinculado correctamente.');
                } else {
                    const errorData = await response.json();
                    alert(`Error al actualizar perfil: ${errorData.detail || response.statusText}`);
                }
            } catch (error) {
                console.error('Error updating profile:', error);
                alert('Error de conexión al actualizar el perfil.');
            }
        });
    }

    // Botones de Seguridad en Ajustes
    const changePassBtn = document.getElementById('change-pass-btn');
    if (changePassBtn) {
        changePassBtn.addEventListener('click', async () => {
            const newPass = prompt("Ingresa tu nueva contraseña (mínimo 6 caracteres):");
            if (newPass) {
                const res = await fetch('/app_logic/change-password', {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
                    body: JSON.stringify({ new_password: newPass })
                });
                if (res.ok) alert("Contraseña actualizada con éxito.");
            }
        });
    }

    const deleteAccountBtn = document.getElementById('delete-account-btn');
    if (deleteAccountBtn) {
        deleteAccountBtn.addEventListener('click', async () => {
            if (confirm("¿ESTÁS SEGURO? Esta acción es irreversible y borrará todos tus mensajes y cuenta.")) {
                const res = await fetch('/app_logic/account', {
                    method: 'DELETE',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (res.ok) {
                    localStorage.removeItem('token');
                    window.location.href = '/';
                }
            }
        });
    }

    const clearHistoryBtn = document.getElementById('clear-history-btn');
    if (clearHistoryBtn) {
        clearHistoryBtn.addEventListener('click', async () => {
            if (confirm("¿Estás seguro de que quieres BORRAR TODO tu historial de mensajes? Esta acción no se puede deshacer.")) {
                const res = await fetch('/app_logic/messages/clear-history', {
                    method: 'DELETE',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (res.ok) {
                    messageArea.innerHTML = '';
                    alert("Historial borrado correctamente.");
                }
            }
        });
    }

    // Función genérica para subida de archivos (Fondo/Banner)
    async function handleFileUpload(input, type) {
        if (!input) return;
        input.addEventListener('change', async (event) => {
            const file = event.target.files[0];
            if (!file) return;
            const formData = new FormData();
            formData.append('file', file);

            try {
                const res = await fetch('/app_logic/upload', {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` },
                    body: formData
                });

                if (res.ok) {
                    const data = await res.json();
                    const updateData = {};
                    updateData[type] = data.url;
                    
                    const updateRes = await fetch('/app_logic/profile', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
                        body: JSON.stringify(updateData)
                    });
                    if (updateRes.ok) alert('Imagen actualizada con éxito. Haz clic en Guardar para aplicar todos los cambios.');
                }
            } catch (error) { console.error('Error uploading:', error); }
        });
    }
    handleFileUpload(wallpaperUpload, 'wallpaper_url');
    handleFileUpload(bannerUpload, 'profile_banner_url');

    // Lógica para subir foto de perfil
    if (profilePicUpload) {
        profilePicUpload.addEventListener('change', async (event) => {
            const file = event.target.files[0];
            if (!file) return;

            const formData = new FormData();
            formData.append('file', file);

            try {
                const response = await fetch('/app_logic/upload', {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` },
                    body: formData
                });

                if (response.ok) {
                    const data = await response.json();
                    const newProfilePicUrl = data.url;
                    settingsProfilePic.src = newProfilePicUrl; // Actualizar la imagen en ajustes
                    // Guardar la nueva URL en el perfil
                    const updateResponse = await fetch('/app_logic/profile', {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`
                        },
                        body: JSON.stringify({ profile_picture_url: newProfilePicUrl })
                    });

                    if (updateResponse.ok) {
                        const user = await updateResponse.json();
                        alert('Foto de perfil actualizada.');
                        currentProfilePicElem.src = user.profile_picture_url; // Actualizar en la barra lateral
                    } else {
                        const errorData = await updateResponse.json();
                        alert(`Error al guardar la URL de la foto: ${errorData.detail || updateResponse.statusText}`);
                    }
                } else {
                    const errorData = await response.json();
                    alert(`Error al subir la imagen: ${errorData.detail || response.statusText}`);
                }
            } catch (error) {
                console.error('Error uploading profile picture:', error);
                alert('Error de conexión al subir la foto.');
            }
        });
    }

    // Función para cambiar de pestaña
    function switchView(view) {
        const sections = [sectionChats, sectionContacts, sectionSettings, sectionProfile];
        const navs = [navChats, navContacts, navSettings, navProfile];
        
        sections.forEach(s => { if(s) s.style.display = 'none'; });
        navs.forEach(n => { if(n) n.classList.remove('active'); });

        if (view === 'chats') {
            sectionChats.style.display = 'flex';
            navChats.classList.add('active');
        } else if (view === 'contacts') {
            sectionContacts.style.display = 'flex';
            navContacts.classList.add('active');
            fetchContacts(); // Refrescar contactos al abrir la pestaña
        } else if (view === 'settings') {
            sectionSettings.style.display = 'flex';
            navSettings.classList.add('active');
        } else if (view === 'profile') {
            sectionProfile.style.display = 'flex';
            navProfile.classList.add('active');
        }
    }

    navChats.addEventListener('click', (e) => {
        e.preventDefault();
        switchView('chats');
    });
    navContacts.addEventListener('click', (e) => {
        e.preventDefault();
        switchView('contacts');
    });
    navSettings.addEventListener('click', (e) => {
        e.preventDefault();
        switchView('settings');
    });
    if (navProfile) {
        navProfile.addEventListener('click', (e) => {
            e.preventDefault();
            switchView('profile');
        });
    }

    // Lógica de "Escribiendo..." Optimizada
    let isTyping = false;
    let typingTimeout;
    messageInput.addEventListener('input', () => {
        if (activeChatId === null) return; // Only send typing for private chats
        if (!isTyping) {
            isTyping = true;
            ws.send(JSON.stringify({ type: 'typing', recipient_id: activeChatId, is_typing: true }));
            const indicator = document.getElementById('typing-indicator');
            if (indicator) indicator.style.display = 'inline';
        }
        clearTimeout(typingTimeout);
        typingTimeout = setTimeout(() => {
            isTyping = false;
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: 'typing', recipient_id: activeChatId, is_typing: false }));
            }
            const indicator = document.getElementById('typing-indicator');
            if (indicator) indicator.style.display = 'none';
        }, 3000);
    });

    // Lógica para añadir contacto
    const addContactBtn = document.getElementById('add-contact-btn');
    const addContactInput = document.getElementById('add-contact-input');
    const createGroupBtn = document.getElementById('create-group-btn');
    const groupNameInput = document.getElementById('group-name-input');

    if (createGroupBtn) {
        createGroupBtn.addEventListener('click', async () => {
            const name = groupNameInput.value.trim();
            const selectedCheckboxes = document.querySelectorAll('.group-member-checkbox:checked');
            const memberIds = Array.from(selectedCheckboxes).map(cb => parseInt(cb.value));

            if (!name) return alert("Ponle un nombre al grupo");
            if (memberIds.length === 0) return alert("Selecciona al menos un contacto para el grupo");
            
            const response = await fetch('/app_logic/groups', {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: name,
                    description: `Grupo creado por ${myUsername}`,
                    member_ids: memberIds
                })
            });
            if (response.ok) {
                alert("¡Grupo creado!");
                groupNameInput.value = '';
                fetchContacts();
            }
        });
    }
    
    // PIP 171-180: Sistema de Búsqueda y Agregación Pro (Anti-Chafa)
    if (addContactBtn) {
        addContactBtn.addEventListener('click', async () => {
            const query = addContactInput.value.trim();
            if (!query) return;
            
            try {
                const res = await fetch(`/app_logic/search/${encodeURIComponent(query)}`, {
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (!res.ok) throw new Error("Usuario no encontrado");
                const user = await res.json();
                
                if (user.is_already_contact) return alert("Esta persona ya está en tus contactos.");
                
                const customName = prompt(`¿Cómo quieres llamar a ${user.username}?`, user.username);
                if (customName === null) return;

                const addRes = await fetch(`/app_logic/contacts/add/${user.phone_number}?custom_name=${encodeURIComponent(customName)}`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (addRes.ok) {
                    alert("¡Contacto añadido con éxito!");
                    addContactInput.value = '';
                    fetchContacts();
                }
            } catch (err) { alert(err.message); }
        });
    }

    // Lógica para editar nombre de contacto
    async function editContactName(contactId, currentName) {
        const newName = prompt(`Introduce el nuevo nombre para este contacto:`, currentName);
        if (newName && newName.trim() !== currentName) {
            try {
                const response = await fetch(`/app_logic/contacts/update_name/${contactId}?new_custom_name=${encodeURIComponent(newName.trim())}`, {
                    method: 'PUT',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
                if (response.ok) {
                    alert('Nombre de contacto actualizado.');
                    fetchContacts(); // Refrescar la lista
                } else {
                    const errorData = await response.json();
                    alert(`Error al actualizar el nombre: ${errorData.detail || response.statusText}`);
                }
            } catch (error) {
                console.error('Error updating contact name:', error);
                alert('Error de conexión al actualizar el nombre del contacto.');
            }
        }
    }

    function renderGroupMemberSelector(contacts) {
        const selectorContainer = document.getElementById('group-members-selection');
        if (!selectorContainer) return;

        selectorContainer.innerHTML = '<div style="margin-bottom:10px; font-weight:bold; font-size:12px; color: var(--text-medium);">Selecciona miembros para el grupo:</div>';
        
        // Solo permitir personas reales (no la IA, ni grupos, ni uno mismo)
        const realPeople = contacts.filter(c => !c.is_group && c.id !== 999 && c.id !== userId);
        
        if (realPeople.length === 0) {
            selectorContainer.innerHTML += '<p style="font-size:12px; color:gray;">No tienes contactos para añadir.</p>';
            return;
        }

        realPeople.forEach(person => {
            const roleClass = getRoleClass(person.role, false);
            const label = document.createElement('label');
            label.className = 'group-member-label';
            
            label.innerHTML = `
                <input type="checkbox" class="group-member-checkbox" value="${person.id}" style="width:auto; margin:0;">
                <span class="${roleClass}" style="font-size:14px; font-weight:500;">${person.name}</span>
            `;

            const cb = label.querySelector('input');
            cb.addEventListener('change', () => label.classList.toggle('selected', cb.checked));

            selectorContainer.appendChild(label);
        });
    }

    function displayContacts(contacts) {
        const contactContainers = [contactListElem, document.getElementById('all-contacts-list')].filter(el => el !== null);
        const spaceFilter = spaceSelector ? spaceSelector.value : 'dm';

        contactContainers.forEach(container => {
            container.innerHTML = '';
            
            // Filtrado: 'dm' muestra personas (no grupos), 'groups' muestra solo grupos. 
            // La IA (999) y "Yo" (userId) siempre salen en DMs.
            const filteredContacts = contacts.filter(c => {
                if (spaceFilter === 'groups') return c.is_group;
                return !c.is_group || c.id === 999 || c.id === userId;
            });

            if (filteredContacts.length === 0) {
                container.innerHTML = `<p style="color: var(--text-medium); text-align: center; margin-top: 20px;">No hay ${spaceFilter === 'groups' ? 'comunidades' : 'contactos'} aún.</p>`;
                return;
            }

            filteredContacts.forEach(contact => {
                const contactDiv = document.createElement('div');
                contactDiv.className = 'contact-item';
                if (contact.is_unknown) contactDiv.classList.add('unknown-contact');
                
                contactDiv.dataset.contactId = contact.id;
                contactDiv.dataset.customName = contact.name;

                contactDiv.innerHTML = `
                    <img src="${contact.profile_picture || DEFAULT_AVATAR}" alt="Avatar" class="avatar">
                    <div class="contact-info" style="display:flex; flex-direction:column;">
                        <span class="contact-name" style="${contact.is_unknown ? 'color: var(--accent);' : ''}">${contact.name}</span>
                        ${contact.is_unknown ? '<small style="font-size:10px; color:gray;">Número no guardado</small>' : ''}
                        <small class="last-message-preview" style="font-size:10px; color:#999;"></small>
                        ${contact.is_muted ? '<small style="font-size:10px; color:#ffcc00;">🔇 Silenciado</small>' : ''}
                        ${contact.is_blocked ? '<small style="font-size:10px; color:#ff3b30;">🚫 Bloqueado</small>' : ''}
                    </div>
                    <div class="contact-actions" style="display:flex; gap:8px; align-items:center;">
                        ${!contact.is_group && contact.id !== 999 && contact.id !== userId ? `
                            <button class="mute-btn" title="Silenciar">${contact.is_muted ? '🔊' : '🔇'}</button>
                            <button class="block-btn" title="Bloquear">${contact.is_blocked ? '🔓' : '🚫'}</button>
                            <button class="edit-contact-btn" title="Editar">✏️</button>
                            <button class="delete-btn" title="Eliminar">🗑️</button>
                        ` : ''}
                    </div>
                    <span class="unread-badge" style="display:none; position:absolute; right:10px; top:10px; background:#00d4ff; color:black; border-radius:50%; width:20px; height:20px; font-size:12px; font-weight:bold; align-items:center; justify-content:center;"></span>

                `;
                
                contactDiv.addEventListener('click', () => {
                    openChat(contact.id, contact.name, contact.is_group);
                });

                const editBtn = contactDiv.querySelector('.edit-contact-btn');
                if (editBtn) {
                    editBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        editContactName(contact.id, contact.name);
                    });
                }

                const muteBtn = contactDiv.querySelector('.mute-btn');
                if (muteBtn) {
                    muteBtn.addEventListener('click', async (e) => {
                        e.stopPropagation();
                        const res = await fetch(`/app_logic/contacts/mute/${contact.id}`, { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
                        if (res.ok) fetchContacts();
                    });
                }

                const blockBtn = contactDiv.querySelector('.block-btn');
                if (blockBtn) {
                    blockBtn.addEventListener('click', async (e) => {
                        e.stopPropagation();
                        const res = await fetch(`/app_logic/contacts/block/${contact.id}`, { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
                        if (res.ok) fetchContacts();
                    });
                }

                const deleteBtn = contactDiv.querySelector('.delete-btn');
                if (deleteBtn) {
                    deleteBtn.addEventListener('click', async (e) => {
                        e.stopPropagation();
                        if (confirm(`¿Eliminar a ${contact.name} de tus contactos?`)) {
                            const res = await fetch(`/app_logic/contacts/${contact.id}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${token}` } });
                            if (res.ok) fetchContacts();
                        }
                    });
                }

                container.appendChild(contactDiv);
            });
        });

        // After displaying, update unread counts for all contacts
        Object.keys(unreadCounts).forEach(chatId => updateContactUnreadCountUI(chatId));

        // Actualizar el selector de miembros para grupos
        renderGroupMemberSelector(contacts);
    }

    function updateContactUnreadCountUI(chatId) {
        const count = unreadCounts[chatId] || 0;
        // Buscar en ambos contenedores de listas de contactos
        const contactItems = document.querySelectorAll(`.contact-item[data-contact-id="${chatId}"]`);
        contactItems.forEach(item => {
            const badge = item.querySelector('.unread-badge');
            if (badge) {
                badge.textContent = count;
                badge.style.display = count > 0 ? 'flex' : 'none';
                if (count > 0) item.style.fontWeight = 'bold'; else item.style.fontWeight = 'normal';
            }
        });
    }

    if (token) {
        fetchContacts();
        // Actualización automática cada 10 segundos
        contactInterval = setInterval(() => {
            fetchContacts();
        }, 10000);
    }

    // Lógica de Cerrar Sesión
    if (logoutButton) {
        logoutButton.addEventListener('click', () => {
            if (contactInterval) clearInterval(contactInterval);
            if (ws) ws.close();
            localStorage.removeItem('token');
            window.location.href = '/';
        });
    }

    // Filtro de búsqueda de contactos en tiempo real (GUI mejorada)
    const contactSearchInput = document.createElement('input');
    contactSearchInput.placeholder = "🔍 Buscar contacto o grupo...";
    contactSearchInput.style.cssText = "width:90%; margin:10px auto; display:block; padding:8px; border-radius:20px; background:rgba(255,255,255,0.1); border:1px solid rgba(0,212,255,0.3); color:white;";
    
    if (contactListElem && contactListElem.parentElement) {
        contactListElem.parentElement.insertBefore(contactSearchInput, contactListElem);
    }

    contactSearchInput.addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase();
        document.querySelectorAll('.contact-item').forEach(item => {
            const name = item.querySelector('.contact-name').textContent.toLowerCase();
            item.style.display = name.includes(term) ? 'flex' : 'none';
        });
    });
});