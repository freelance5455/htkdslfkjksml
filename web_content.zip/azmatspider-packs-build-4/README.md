# AZMATSPIDER PACKS — BUILD 4 ULTIMATE EDITION

A mobile-first, Minecraft-inspired community pack catalog built with HTML5, CSS3 and vanilla JavaScript.

## Run locally
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Run a static server (recommended): `python -m http.server 8000`
4. Visit `http://localhost:8000` on desktop or your Android browser on the same network.

You can open `index.html` directly for most features, but the sample `data/packs.json` fetch and PWA behavior work best through HTTP.

## Files
- `index.html` — semantic app shell and dialogs
- `style.css` — responsive premium dark/red theme
- `script.js` — catalog, search, filters, favorites, detail view, downloads, admin and backup
- `data/packs.json` — editable starter catalog data
- `assets/` — local SVG logo and original decorative cover art
- `manifest.webmanifest` — installable web app metadata\n- `service-worker.js` — caches the app shell and sample catalog for repeat/offline visits

## Admin panel
Select **Admin** and enter demo PIN `6266`. This is intentionally a local demonstration only:
- The PIN is visible in `script.js` and can be bypassed.
- Catalog changes are stored in the current browser's LocalStorage.
- Changes are not uploaded, synchronized, or protected from other visitors.
- The preview image field accepts a URL or relative path; this static app does not upload image files.
- Export a JSON backup before clearing browser storage.

For a public deployment, move admin authentication, pack storage, file upload, validation, and download authorization to a server. Use password hashing, sessions, CSRF protection, role-based access control, rate limiting, HTTPS, and a database. Never rely on a frontend PIN for security.

## Downloads and redistribution
Sample entries intentionally have no download URLs. They are catalog examples, not downloadable pack files. Add a valid HTTP(S) creator-provided URL only when redistribution is authorized. Download counters count clicks on configured external URLs, not confirmed successful transfers.

Supported metadata formats: `.mcpack`, `.mcaddon`, `.mcworld`, `.zip`, `.jar`, `.mrpack`. The app explains typical installation paths, but it cannot guarantee direct installation on every device or launcher. `.jar` mods and `.mrpack` modpacks generally require compatible Java loaders/launchers. Do not upload stolen files, unauthorized images, or paid Marketplace content.

## Android / APK
The responsive web app can be wrapped later using Capacitor or another WebView wrapper. Test downloads, file handling, external links, and Android back navigation in the target wrapper; browser behavior varies by Android version and Minecraft installation.

## Offline behavior
The UI, styles, script and bundled SVG assets are local. The app stores the catalog and favorites in LocalStorage after first load. The service worker caches the app shell and sample catalog after the first successful visit. Serve over HTTPS (or localhost) for service-worker support. Creator-hosted downloads still require an internet connection; changes remain in LocalStorage.

## Data model
The starter JSON shows the pack object fields. The Admin panel can add/edit entries and export/import the complete browser data backup.
