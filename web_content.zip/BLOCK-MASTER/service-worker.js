/* service-worker.js — offline cache (cache-first, refreshed by version) */
var CACHE = 'block-master-v16';
var FILES = [
  './', 'index.html', 'manifest.json',
  'css/main.css', 'css/home.css', 'css/blocks.css', 'css/animations.css', 'css/game.css', 'css/responsive.css',
  'js/storage.js', 'js/settings.js', 'js/audio.js', 'js/scoring.js', 'js/rewards.js', 'js/board.js', 'js/pieces.js',
  'js/drag-drop.js', 'js/game.js', 'js/navigation.js', 'js/animations.js', 'js/main.js',
  'assets/icons/icon-192.png', 'assets/icons/icon-512.png', 'assets/icons/icon-maskable-512.png'
];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(FILES); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(function (hit) { return hit || fetch(e.request); }));
});
