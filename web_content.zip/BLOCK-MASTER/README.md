# BLOCK MASTER

لعبة ألغاز مكعبات (HTML5 / CSS3 / JavaScript) جاهزة كتطبيق PWA ومهيّأة للتحويل إلى تطبيق Android.

## الطريقة 1: تثبيت كتطبيق (الأسرع، بدون APK)

1. ارفع محتوى المجلد إلى استضافة https مجانية (Netlify Drop أو GitHub Pages أو Cloudflare Pages).
2. افتح الرابط في Chrome على الهاتف.
3. القائمة (⋮) ثم "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".

يعمل بعدها بدون إنترنت وبملء الشاشة وبأيقونته الخاصة.

## الطريقة 2: ملف APK عبر GitHub (من الهاتف أو الحاسوب)

1. أنشئ مستودعاً على GitHub وارفع إليه كل ملفات المشروع (بما فيها المجلد `.github`).
2. افتح تبويب **Actions** ثم **Build Android APK**. يبدأ البناء تلقائياً، أو اضغط **Run workflow**.
3. بعد دقائق افتح التشغيل المكتمل ونزّل **BLOCK-MASTER-APK** من قسم Artifacts، ثم ثبّت `app-debug.apk`.

هذا APK تجريبي (debug) للتثبيت المباشر. للنشر في Google Play يلزم توقيع نسخة release بمفتاح خاص بك.

## الطريقة 3: على حاسوب فيه Node و Android Studio

```
npm install
npm run build:web
npx cap add android
npx cap sync android
npx cap open android
```

## هيكل المشروع

- `index.html`, `css/`, `js/`: اللعبة.
- `manifest.json`, `service-worker.js`, `assets/icons/`: PWA.
- `capacitor.config.json`, `package.json`, `scripts/`, `.github/`: تغليف Android.
