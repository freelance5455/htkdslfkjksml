# BLOCK MASTER

لعبة ألغاز مكعبات مبنية بـ HTML5 وCSS3 وJavaScript، ومهيّأة كتطبيق Android باستخدام Capacitor. تم الحفاظ على ملفات اللعبة وآلياتها؛ التغييرات هنا خاصة بأيقونة التطبيق وتجهيز بناء APK عبر GitHub Actions.

## إنشاء APK من GitHub (بدون Android Studio)

1. ارفع محتويات مجلد `BLOCK-MASTER` إلى مستودع GitHub، مع التأكد من رفع مجلد `.github`.
2. افتح المستودع ثم **Actions**.
3. اختر **Build Android APK** ثم اضغط **Run workflow** (أو انتظر انتهاء البناء بعد `push`).
4. افتح عملية البناء المكتملة.
5. من قسم **Artifacts** نزّل `BLOCK-MASTER-APK` وفك ضغطه لتحصل على `app-debug.apk`.
6. انقل APK إلى هاتف Android وثبّته. قد يطلب Android السماح بالتثبيت من مصدر الملفات الذي استخدمته.

## ملاحظات

- ملف APK ينتج سحابياً بواسطة GitHub Actions؛ لا يوجد APK مبني مسبقاً داخل هذا الأرشيف.
- الناتج `debug APK` للتجربة والتثبيت المباشر، وليس إصدار Google Play.
- للنشر في Google Play يلزم إعداد توقيع إصدار `release` بمفتاح خاص.
- الأيقونة الجديدة موجودة في `resources/icon.png`، وفي `assets/icons/` لنسخة PWA.

## بناء الويب محلياً

```bash
npm install
npm run build:web
```
