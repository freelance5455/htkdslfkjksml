// Copies only the web game files into www/ for the Android wrapper.
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const OUT = path.join(ROOT, 'www');
const ITEMS = ['index.html', 'manifest.json', 'service-worker.js', 'css', 'js', 'assets'];

fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });
ITEMS.forEach((item) => {
  fs.cpSync(path.join(ROOT, item), path.join(OUT, item), { recursive: true });
});
console.log('www/ ready:', fs.readdirSync(OUT).join(', '));
