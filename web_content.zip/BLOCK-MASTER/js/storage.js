/* ==========================================================
   storage.js — LocalStorage wrapper
   Phase 2 stores only the best score. Progress and settings
   keys are added in later phases.
   ========================================================== */
(function (BM) {
  'use strict';

  var PREFIX = 'blockmaster.';

  var pending = {}, timer = 0;

  function read(key, fallback) {
    if (Object.prototype.hasOwnProperty.call(pending, key)) return pending[key];
    try {
      var raw = window.localStorage.getItem(PREFIX + key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch (e) {
      return fallback; // storage blocked or corrupted: play without saving
    }
  }

  function write(key, value) {
    try {
      window.localStorage.setItem(PREFIX + key, JSON.stringify(value));
      return true;
    } catch (e) {
      return false;
    }
  }

  // Writes are batched and done off the move, so placing a piece never waits on disk
  function flush() {
    window.clearTimeout(timer); timer = 0;
    var batch = pending; pending = {};
    Object.keys(batch).forEach(function (k) { write(k, batch[k]); });
  }
  function later(key, value) {
    pending[key] = value;
    if (!timer) timer = window.setTimeout(flush, 600);
  }
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', function () { if (document.hidden) flush(); });

  BM.storage = {
    later: later,
    flush: flush,
    get: read,
    set: write,
    getBest: function () {
      var best = read('best', 0);
      return typeof best === 'number' && best >= 0 ? best : 0;
    },
    setBest: function (value) {
      later('best', value); return true;
    }
  };
})(window.BlockMaster = window.BlockMaster || {});
