/* board.js — 8x8 grid: model, placement rules, line detection, rendering */
(function (BM) {
  'use strict';
  var N = 8, grid = [], cells = [], cls = [], ghostIdx = [], geo = null;

  function reset() {
    grid = [];
    for (var r = 0; r < N; r++) grid.push(new Array(N).fill(null));
  }
  function setClass(i, name) {
    if (cls[i] !== name) { cls[i] = name; cells[i].className = name; }
  }
  function cellClass(r, c) {
    var color = grid[r][c];
    return color ? 'cell tile block--' + color : ((r + c) % 2 ? 'cell cell--alt' : 'cell');
  }
  function render() {
    ghostIdx = [];
    for (var r = 0; r < N; r++) for (var c = 0; c < N; c++) {
      setClass(r * N + c, cellClass(r, c));
    }
  }
  function init(container) {
    cells = []; cls = []; geo = null; container.textContent = '';
    container.style.setProperty('--cols', N);
    var f = document.createDocumentFragment();
    for (var i = 0; i < N * N; i++) { var d = document.createElement('div'); cells.push(d); f.appendChild(d); }
    container.appendChild(f);
    reset(); render();
  }
  function canPlace(p, r, c) {
    return p.cells.every(function (k) {
      var y = r + k.r, x = c + k.c;
      return y >= 0 && y < N && x >= 0 && x < N && !grid[y][x];
    });
  }
  function anyFit(p) {
    for (var r = 0; r < N; r++) for (var c = 0; c < N; c++) if (canPlace(p, r, c)) return true;
    return false;
  }
  function place(p, r, c) {
    return p.cells.map(function (k) { grid[r + k.r][c + k.c] = p.color; return (r + k.r) * N + c + k.c; });
  }
  function pop(idx) { idx.forEach(function (i) { setClass(i, cls[i] + ' pop'); }); }

  function fullLines() {
    var rows = [], cols = [], i, j;
    for (i = 0; i < N; i++) {
      var rf = true, cf = true;
      for (j = 0; j < N; j++) { if (!grid[i][j]) rf = false; if (!grid[j][i]) cf = false; }
      if (rf) rows.push(i);
      if (cf) cols.push(i);
    }
    return { rows: rows, cols: cols, count: rows.length + cols.length };
  }
  function lineIndexes(l) {
    var out = {};
    l.rows.forEach(function (r) { for (var c = 0; c < N; c++) out[r * N + c] = 1; });
    l.cols.forEach(function (c) { for (var r = 0; r < N; r++) out[r * N + c] = 1; });
    return Object.keys(out).map(Number);
  }
  function cellsOf(l) { return lineIndexes(l).map(function (i) { return { i: i, color: grid[Math.floor(i / N)][i % N] }; }); }
  function markClearing(l) { lineIndexes(l).forEach(function (i) { setClass(i, cls[i] + ' clearing'); }); }
  function removeLines(l) {
    lineIndexes(l).forEach(function (i) { grid[Math.floor(i / N)][i % N] = null; });
  }
  function isEmpty() { return grid.every(function (row) { return row.every(function (v) { return !v; }); }); }

  // Measure once per drag: layout reads on every pointer move cause lag
  function measure() {
    var a = cells[0].getBoundingClientRect(), b = cells[1].getBoundingClientRect();
    var bd = document.getElementById('board').getBoundingClientRect();
    geo = { left: a.left, top: a.top, pitch: b.left - a.left, bx: a.left - bd.left, by: a.top - bd.top };
    return geo;
  }
  function pitch() { return (geo || measure()).pitch; }
  function locate(x, y) {
    var g = geo || measure();
    return { r: Math.round((y - g.top) / g.pitch), c: Math.round((x - g.left) / g.pitch) };
  }
  function clearGhost() {
    ghostIdx.forEach(function (i) { setClass(i, cellClass(Math.floor(i / N), i % N)); });
    ghostIdx = [];
  }
  // Preview the piece and highlight the lines it would complete
  function showGhost(p, r, c) {
    clearGhost();
    var own = {};
    p.cells.forEach(function (k) { own[(r + k.r) * N + c + k.c] = 1; });
    var saved = p.cells.map(function (k) { grid[r + k.r][c + k.c] = p.color; });
    var lines = fullLines();
    p.cells.forEach(function (k) { grid[r + k.r][c + k.c] = null; });
    Object.keys(own).forEach(function (i) {
      setClass(Number(i), 'cell ghost block--' + p.color); ghostIdx.push(Number(i));
    });
    lineIndexes(lines).forEach(function (i) {
      setClass(i, cls[i] + ' will-clear'); if (!own[i]) ghostIdx.push(i);
    });
  }
  function load(saved) {
    grid = saved.map(function (row) { return row.slice(); });
    render();
  }

  BM.board = {
    SIZE: N, init: init, reset: reset, render: render, canPlace: canPlace, anyFit: anyFit,
    place: place, fullLines: fullLines, markClearing: markClearing, cellsOf: cellsOf, removeLines: removeLines,
    isEmpty: isEmpty, pitch: pitch, measure: measure, geometry: function () { return geo || measure(); }, clearGhost: clearGhost, pop: pop, locate: locate, showGhost: showGhost, load: load,
    getGrid: function () { return grid; }
  };
})(window.BlockMaster = window.BlockMaster || {});
