/* ==========================================================
   main.js — boot sequence
   Loaded last; starts each module once the DOM is ready.
   ========================================================== */
(function (BM) {
  'use strict';

  function boot() {
    if (BM.settings) {
      BM.settings.init();
    }
    if (BM.animations) {
      BM.animations.init();
    }
    if (BM.game) {
      BM.game.init();
    }
    if (BM.navigation) {
      BM.navigation.init();
    }
    if (BM.dragDrop) {
      BM.dragDrop.init(document.getElementById('tray'));
    }
    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
      navigator.serviceWorker.register('service-worker.js').catch(function () {});
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})(window.BlockMaster = window.BlockMaster || {});
