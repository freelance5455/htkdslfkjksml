/* rewards.js — end-of-round medal tier and coins (coins are saved) */
(function (BM) {
  'use strict';
  var TIERS = [
    { min: 3000, name: 'diamond', color: '#6fd6ff' },
    { min: 1000, name: 'gold',    color: '#ffc83a' },
    { min: 300,  name: 'silver',  color: '#dfe7f5' },
    { min: 0,    name: 'bronze',  color: '#d98a4a' }
  ];

  BM.rewards = {
    tierFor: function (score) {
      for (var i = 0; i < TIERS.length; i++) if (score >= TIERS[i].min) return TIERS[i];
      return TIERS[TIERS.length - 1];
    },
    award: function (score) {
      var coins = Math.floor(score / 5);
      var total = BM.storage.get('coins', 0) + coins;
      BM.storage.later('coins', total);
      return { tier: this.tierFor(score), coins: coins, total: total };
    }
  };
})(window.BlockMaster = window.BlockMaster || {});
