/* ==========================================================
   navigation.js — screen switching
   Screens are addressed by hash (#home, #game) so the browser
   and Android back buttons move between them.
   ========================================================== */
(function (BM) {
  'use strict';

  var SCREEN_IDS = {
    home: 'screen-home',
    game: 'screen-game'
  };

  var PRESS_DELAY_MS = 160; // lets the press animation read before the screen changes

  var screens = {};
  var isNavigating = false;

  function readScreenFromHash() {
    var name = window.location.hash.replace('#', '');
    return Object.prototype.hasOwnProperty.call(screens, name) ? name : 'home';
  }

  function showScreen(name) {
    Object.keys(screens).forEach(function (key) {
      var el = screens[key];
      var isActive = key === name;
      el.classList.toggle('is-active', isActive);
      el.setAttribute('aria-hidden', isActive ? 'false' : 'true');
      el.inert = !isActive;
    });
    document.body.dataset.screen = name;
    if (BM.animations && BM.animations.setDecoActive) BM.animations.setDecoActive(name === 'home');
    window.scrollTo(0, 0);
    isNavigating = false;
  }

  function routeFromHash() {
    showScreen(readScreenFromHash());
  }

  function handleClassicPress(event) {
    var button = event.currentTarget;
    if (isNavigating) return;
    isNavigating = true;
    button.classList.add('is-pressed');

    window.setTimeout(function () {
      button.classList.remove('is-pressed');
      if (window.location.hash === '#game') {
        routeFromHash(); // hash already points at game: no hashchange will fire
      } else {
        window.location.hash = 'game'; // hashchange triggers routeFromHash
      }
    }, PRESS_DELAY_MS);
  }

  function init() {
    screens.home = document.getElementById(SCREEN_IDS.home);
    screens.game = document.getElementById(SCREEN_IDS.game);
    var classicButton = document.getElementById('classic-btn');

    if (!screens.home || !screens.game || !classicButton) {
      return;
    }

    classicButton.addEventListener('click', handleClassicPress);
    window.addEventListener('hashchange', routeFromHash);
    routeFromHash();
  }

  BM.navigation = {
    init: init,
    show: function (name) {
      if (Object.prototype.hasOwnProperty.call(screens, name)) {
        showScreen(name);
      }
    }
  };
})(window.BlockMaster = window.BlockMaster || {});
