/* ==========================================================
   animations.js — decorative cubes for the Home screen
   Phase 1 only. Gameplay motion is added in phase 5.
   ========================================================== */
(function (BM) {
  'use strict';

  var FACES = ['front', 'top', 'right', 'left', 'back', 'bottom'];

  /*
    Background cubes.
    x, y   : position in % of the screen
    n      : size in cube units (see --cube-unit in main.css)
    c      : colour name (block--NAME in blocks.css)
    o      : opacity; lower values read as further back
    float  : seconds for one up/down drift
    spin   : seconds for one full turn
    delay  : seconds offset so cubes do not move in step
  */
  var DECO_CUBES = [
    { x: '7%',  y: '14%', n: 2.6, c: 'yellow', o: 1,   float: 6.2, spin: 16, delay: 0 },
    { x: '74%', y: '27%', n: 2.0, c: 'sky',    o: 0.9, float: 7.4, spin: 20, delay: -2.1 },
    { x: '14%', y: '70%', n: 2.2, c: 'pink',   o: 0.95, float: 6.8, spin: 18, delay: -1.3 },
    { x: '82%', y: '78%', n: 3.0, c: 'orange', o: 1,   float: 8.1, spin: 22, delay: -4 },
    { x: '42%', y: '88%', n: 1.7, c: 'green',  o: 0.8, float: 5.6, spin: 14, delay: -0.8 },
    { x: '3%',  y: '46%', n: 1.6, c: 'purple', o: 0.85, float: 7.0, spin: 19, delay: -3.2 },
    { x: '92%', y: '40%', n: 1.8, c: 'green',  o: 0.8, float: 6.5, spin: 17, delay: -2.6 },
    { x: '68%', y: '91%', n: 2.4, c: 'yellow', o: 0.95, float: 7.7, spin: 21, delay: -5 },
    { x: '34%', y: '6%',  n: 1.5, c: 'pink',   o: 0.5, float: 8.5, spin: 24, delay: -1.7 },
    { x: '22%', y: '40%', n: 1.3, c: 'sky',    o: 0.5, float: 6.0, spin: 26, delay: -3.8 }
  ];

  function createFace(name) {
    var face = document.createElement('span');
    face.className = 'block-3d__face block-3d__face--' + name;
    return face;
  }

  function createCube(config) {
    var wrap = document.createElement('div');
    wrap.className = 'deco-cube';
    wrap.style.setProperty('--x', config.x);
    wrap.style.setProperty('--y', config.y);
    wrap.style.setProperty('--s', 'calc(var(--cube-unit) * ' + config.n + ')');
    wrap.style.setProperty('--o', String(config.o));
    wrap.style.setProperty('--float-dur', config.float + 's');
    wrap.style.setProperty('--spin-dur', config.spin + 's');
    wrap.style.setProperty('--delay', config.delay + 's');

    var cube = document.createElement('div');
    cube.className = 'block-3d block--' + config.c;
    FACES.forEach(function (name) {
      cube.appendChild(createFace(name));
    });

    wrap.appendChild(cube);
    return wrap;
  }

  function spawnDecoCubes(container) {
    var fragment = document.createDocumentFragment();
    DECO_CUBES.forEach(function (config) {
      fragment.appendChild(createCube(config));
    });
    container.appendChild(fragment);
  }

  function init() {
    var container = document.getElementById('deco-cubes');
    if (container) {
      spawnDecoCubes(container);
    }
  }

  // Floating feedback text over the board ("+40", "COMBO x2")
  function floatText(text, cls, level) {
    var board = document.getElementById('board');
    if (!board) return;
    var node = document.createElement('div');
    node.className = 'float ' + cls;
    node.style.setProperty('--lvl', level || 0);
    node.textContent = text;
    node.addEventListener('animationend', function () { node.remove(); });
    board.appendChild(node);
  }

  // Sparks fly out of cleared cells (capped so phones stay smooth)
  function burst(list) {
    var board = document.getElementById('board'), g = BM.board.geometry();
    var f = document.createDocumentFragment(), N = BM.board.SIZE;
    var step = Math.max(1, Math.ceil(list.length / 10)); // at most ~10 sparks
    for (var n = 0; n < list.length; n += step) {
      var i = list[n].i, half = g.pitch * 0.5;
      var s = document.createElement('i');
      s.className = 'spark block--' + (list[n].color || 'yellow');
      s.style.left = (g.bx + (i % N) * g.pitch + half) + 'px';
      s.style.top = (g.by + Math.floor(i / N) * g.pitch + half) + 'px';
      s.style.setProperty('--dx', Math.round((Math.random() - .5) * 150) + 'px');
      s.style.setProperty('--dy', Math.round((Math.random() - .8) * 130) + 'px');
      s.addEventListener('animationend', function () { this.remove(); });
      f.appendChild(s);
    }
    board.appendChild(f);
  }

  function shake() {
    var board = document.getElementById('board');
    board.classList.remove('shake'); void board.offsetWidth; board.classList.add('shake');
  }

  var decoTimer = 0;
  // Decorative 3D cubes cost GPU memory; drop them while playing
  function setDecoActive(active) {
    var box = document.getElementById('deco-cubes');
    if (!box) return;
    window.clearTimeout(decoTimer);
    if (active) { box.style.display = ''; }
    else { decoTimer = window.setTimeout(function () { box.style.display = 'none'; }, 600); }
  }

  BM.animations = {
    setDecoActive: setDecoActive,
    shake: shake,
    burst: burst,
    floatText: floatText,
    init: init,
    spawnDecoCubes: spawnDecoCubes
  };
})(window.BlockMaster = window.BlockMaster || {});
