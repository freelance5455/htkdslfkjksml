/* scoring.js — tiered points
   Each cleared line is worth 4 and the value keeps doubling as the score grows.
   The score passed in is the player's all-time total, so the value is kept
   between rounds and never resets on replay. */
(function (BM) {
  'use strict';
  var BASE = 4;
  // Each limit reached doubles the value of a line:
  // 100 -> 8, 500 -> 16, 1000 -> 32, 10000 -> 64, 50000 -> 128, 100000 -> 256, 250000 -> 512.
  // After that it keeps doubling every time the score doubles (500000, 1000000, ...), no upper limit.
  var LIMITS = [100, 500, 1000, 10000, 50000, 100000, 250000];
  function tier(score) {
    var t = 0;
    while (t < LIMITS.length && score >= LIMITS[t]) t++;
    var next = LIMITS[LIMITS.length - 1] * 2;
    while (score >= next) { t++; next *= 2; }
    return t;
  }
  function perLine(score) { return BASE * Math.pow(2, tier(score)); }

  BM.scoring = {
    tier: tier,
    perLine: perLine,
    placement: function (cellCount) { return cellCount; },
    // lines cleared together grow by lines^2, and the whole result is multiplied by the combo streak
    clear: function (lines, combo, score) {
      return Math.round(perLine(score) * lines * lines * Math.max(combo, 1));
    },
    perfect: function (score) { return perLine(score) * 100; }
  };
})(window.BlockMaster = window.BlockMaster || {});
