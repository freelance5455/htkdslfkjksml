/* scoring.js — fixed, easy-to-understand scoring inspired by the reference game */
(function (BM) {
  'use strict';

  // Every placed block is +1. Line rewards stay fixed for the whole game.
  // This keeps scoring rewarding without making the game progressively harder.
  var LINE_BASE = 10;
  var PERFECT_BONUS = 200;

  BM.scoring = {
    tier: function () { return 0; },
    perLine: function () { return LINE_BASE; },
    placement: function (cellCount) { return cellCount; },
    clear: function (lines, combo) {
      var count = Math.max(0, lines | 0);
      var streak = Math.max(1, combo | 0);
      if (!count) return 0;
      // More simultaneous lines and consecutive clears earn a clear bonus.
      return LINE_BASE * count * count + (streak - 1) * 5;
    },
    perfect: function () { return PERFECT_BONUS; }
  };
})(window.BlockMaster = window.BlockMaster || {});
