/* scoring.js — tiered points
   Each cleared line is worth 4. The value doubles every time the score
   reaches 100, 1,000, 10,000, 100,000 ... (4 -> 8 -> 16 -> 32 ...). */
(function (BM) {
  'use strict';
  var BASE = 4;
  var THRESHOLDS = [100, 1000, 10000, 100000, 1000000, 10000000];

  function tier(score) {
    var t = 0;
    while (t < THRESHOLDS.length && score >= THRESHOLDS[t]) t++;
    return t;
  }
  function perLine(score) { return BASE * Math.pow(2, tier(score)); }

  BM.scoring = {
    tier: tier,
    perLine: perLine,
    placement: function (cellCount) { return cellCount; },
    // lines cleared together grow by lines^2; each extra combo step adds +50%
    clear: function (lines, combo, score) {
      return Math.round(perLine(score) * lines * lines * (1 + (Math.max(combo, 1) - 1) / 2));
    },
    perfect: function (score) { return perLine(score) * 25; }
  };
})(window.BlockMaster = window.BlockMaster || {});
