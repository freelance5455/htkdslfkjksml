/* scoring.js — generous, fixed scoring; difficulty never scales with score */
(function (BM) {
  'use strict';

  // Every completed row OR column is worth at least 200 points.
  // Extra simultaneous lines and consecutive clears add separate bonuses.
  var POINTS_PER_LINE = 200;
  var MULTI_LINE_BONUS = 100;
  var COMBO_BONUS = 50;
  var PERFECT_BONUS = 300;

  BM.scoring = {
    tier: function () { return 0; },
    perLine: function () { return POINTS_PER_LINE; },
    placement: function (cellCount) { return Math.max(0, cellCount | 0); },
    clear: function (lines, combo) {
      var count = Math.max(0, lines | 0);
      var streak = Math.max(1, combo | 0);
      if (!count) return 0;
      return (POINTS_PER_LINE * count) +
        (MULTI_LINE_BONUS * Math.max(0, count - 1)) +
        (COMBO_BONUS * Math.max(0, streak - 1));
    },
    perfect: function () { return PERFECT_BONUS; }
  };
})(window.BlockMaster = window.BlockMaster || {});
