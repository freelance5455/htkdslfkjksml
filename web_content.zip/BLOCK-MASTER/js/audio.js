/* audio.js — synthesized sounds (Web Audio), no sound files needed */
(function (BM) {
  'use strict';
  var ctx = null;

  function ensure() {
    if (!ctx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, start, dur, type, vol, endFreq) {
    var c = ctx, t = c.currentTime + start;
    var o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(c.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }

  var SOUNDS = {
    click: function () { tone(520, 0, .06, 'sine', .15); },
    pick:  function () { tone(440, 0, .07, 'triangle', .14, 660); },
    place: function () { tone(190, 0, .12, 'sine', .3, 90); tone(380, 0, .05, 'triangle', .1); },
    clear: function (n) {
      var base = [523, 587, 659, 784, 880, 988, 1047, 1175];
      for (var i = 0; i < Math.min(2 + n, 5); i++) tone(base[i], i * .06, .22, 'triangle', .2);
    },
    perfect: function () { [523, 659, 784, 1047, 1319].forEach(function (f, i) { tone(f, i * .09, .35, 'sine', .22); }); },
    over: function () { tone(330, 0, .3, 'sawtooth', .16, 220); tone(220, .25, .5, 'sawtooth', .16, 110); }
  };

  BM.audio = {
    unlock: ensure,
    play: function (name, n) {
      if (!BM.settings || !BM.settings.get('sound') || !ensure()) return;
      window.setTimeout(function () { SOUNDS[name](n || 1); }, 0);
    }
  };
  document.addEventListener('pointerdown', ensure, { once: true });
})(window.BlockMaster = window.BlockMaster || {});
