/* drag-drop.js — low-overhead pointer dragging for touch and mouse */
(function (BM) {
  'use strict';

  function init(tray) {
    if (!tray) return;

    tray.addEventListener('pointerdown', function (e) {
      if (e.button !== undefined && e.button !== 0) return;
      var slot = e.target.closest('.tray__slot');
      if (!slot || BM.game.isLocked()) return;

      var index = Number(slot.dataset.index);
      var piece = BM.game.state.pieces[index];
      if (!piece) return;

      e.preventDefault();
      if (slot.setPointerCapture) slot.setPointerCapture(e.pointerId);
      BM.audio.play('pick');
      BM.board.measure();

      var cellSize = BM.board.pitch() / 1.06;
      var width = piece.cols * cellSize * 1.06;
      var height = piece.rows * cellSize * 1.06;
      var lift = Math.max(42, Math.min(72, BM.board.pitch() * 1.35));
      var dragEl = BM.pieces.createElement(piece);
      dragEl.classList.add('piece--drag');
      dragEl.style.fontSize = cellSize + 'px';
      document.body.appendChild(dragEl);
      slot.classList.add('is-dragging');

      var pointer = { x: e.clientX, y: e.clientY };
      var target = null;
      var lastKey = '';
      var frame = 0;
      var ended = false;

      function update() {
        frame = 0;
        var left = pointer.x - width / 2;
        var top = pointer.y - height - lift;
        dragEl.style.transform = 'translate3d(' + left + 'px,' + top + 'px,0)';

        var loc = BM.board.locate(left, top);
        var key = loc.r + ',' + loc.c;
        if (key === lastKey) return;
        lastKey = key;

        if (BM.board.canPlace(piece, loc.r, loc.c)) {
          target = loc;
          BM.board.showGhost(piece, loc.r, loc.c);
        } else {
          target = null;
          BM.board.clearGhost();
        }
      }

      function schedule(ev) {
        pointer.x = ev.clientX;
        pointer.y = ev.clientY;
        if (!frame) frame = window.requestAnimationFrame(update);
      }

      function cleanup(ev) {
        if (ended) return;
        ended = true;

        // Cancel a queued frame first, then use the final pointerup coordinates.
        if (frame) window.cancelAnimationFrame(frame);
        frame = 0;
        if (ev && ev.type === 'pointerup') {
          pointer.x = ev.clientX;
          pointer.y = ev.clientY;
          update();
        }

        slot.removeEventListener('pointermove', schedule);
        slot.removeEventListener('pointerup', cleanup);
        slot.removeEventListener('pointercancel', cleanup);
        slot.removeEventListener('lostpointercapture', cleanup);
        dragEl.remove();
        slot.classList.remove('is-dragging');
        BM.board.clearGhost();

        if (ev && ev.type === 'pointerup' && target) {
          BM.game.place(index, target.r, target.c);
        }
      }

      slot.addEventListener('pointermove', schedule);
      slot.addEventListener('pointerup', cleanup);
      slot.addEventListener('pointercancel', cleanup);
      slot.addEventListener('lostpointercapture', cleanup);
      update();
    });
  }

  BM.dragDrop = { init: init };
})(window.BlockMaster = window.BlockMaster || {});
