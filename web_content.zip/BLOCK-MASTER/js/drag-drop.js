/* drag-drop.js — drag a tray piece onto the board (touch and mouse) */
(function (BM) {
  'use strict';
  var LIFT = 64; // piece floats above the finger so it stays visible

  function init(tray) {
    tray.addEventListener('pointerdown', function (e) {
      var slot = e.target.closest('.tray__slot');
      if (!slot || BM.game.isLocked()) return;
      var index = Number(slot.dataset.index);
      var piece = BM.game.state.pieces[index];
      if (!piece) return;
      e.preventDefault();
      slot.setPointerCapture(e.pointerId);
      BM.audio.play('pick');

      BM.board.measure();
      var size = BM.board.pitch() / 1.06;
      var w = piece.cols * size * 1.06, h = piece.rows * size * 1.06;
      var el = BM.pieces.createElement(piece);
      el.classList.add('piece--drag');
      el.style.fontSize = size + 'px';
      document.body.appendChild(el);
      slot.classList.add('is-dragging');
      var target = null;

      var last = null, key = '', frame = 0;
      function update() {
        frame = 0;
        var left = last.clientX - w / 2, top = last.clientY - h - LIFT;
        el.style.transform = 'translate3d(' + left + 'px,' + top + 'px,0)';
        var loc = BM.board.locate(left, top);
        var k = loc.r + ',' + loc.c;
        if (k === key) return; // same cell: nothing to redraw
        key = k;
        if (BM.board.canPlace(piece, loc.r, loc.c)) { target = loc; BM.board.showGhost(piece, loc.r, loc.c); }
        else { target = null; BM.board.clearGhost(); }
      }
      function move(ev) {
        last = ev;
        if (!frame) frame = window.requestAnimationFrame(update);
      }
      function end(ev) {
        if (frame) window.cancelAnimationFrame(frame);
        slot.removeEventListener('pointermove', move);
        slot.removeEventListener('pointerup', end);
        slot.removeEventListener('pointercancel', end);
        el.remove();
        slot.classList.remove('is-dragging');
        BM.board.clearGhost();
        if (ev.type === 'pointerup' && target) BM.game.place(index, target.r, target.c);
      }
      slot.addEventListener('pointermove', move);
      slot.addEventListener('pointerup', end);
      slot.addEventListener('pointercancel', end);
      last = e; update();
    });
  }

  BM.dragDrop = { init: init };
})(window.BlockMaster = window.BlockMaster || {});
