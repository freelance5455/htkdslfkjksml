/* settings.js — sound and vibration switches, saved in LocalStorage */
(function (BM) {
  'use strict';
  var values = { sound: true, vibrate: true };
  var panel = null;

  function paint() {
    [['set-sound', 'sound'], ['set-vibrate', 'vibrate']].forEach(function (p) {
      document.getElementById(p[0]).setAttribute('aria-checked', String(values[p[1]]));
    });
  }
  function toggle(key) {
    values[key] = !values[key];
    BM.storage.set('settings', values);
    paint();
    if (BM.audio) BM.audio.play('click');
  }
  function open(isOpen) { panel.hidden = !isOpen; }

  BM.settings = {
    get: function (key) { return values[key]; },
    vibrate: function (ms) {
      if (values.vibrate && navigator.vibrate) navigator.vibrate(ms);
    },
    init: function () {
      var saved = BM.storage.get('settings', null);
      if (saved) { values.sound = saved.sound !== false; values.vibrate = saved.vibrate !== false; }
      panel = document.getElementById('settings-panel');
      paint();
      ['settings-btn', 'game-settings-btn'].forEach(function (id) {
        document.getElementById(id).addEventListener('click', function () { open(true); });
      });
      document.getElementById('set-close').addEventListener('click', function () { open(false); });
      panel.addEventListener('click', function (e) { if (e.target === panel) open(false); });
      document.getElementById('set-sound').addEventListener('click', function () { toggle('sound'); });
      document.getElementById('set-vibrate').addEventListener('click', function () { toggle('vibrate'); });
    }
  };
})(window.BlockMaster = window.BlockMaster || {});
