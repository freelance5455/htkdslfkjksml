/* ==========================================================
   pieces.js — easy, stable piece pool and tray rendering
   ========================================================== */
(function (BM) {
  'use strict';

  // Shapes are deliberately limited to familiar 1–4 block pieces.
  // Repeated entries weight simple pieces more often, keeping the game fair.
  var SHAPES = [
    ['X'], ['X'],
    ['XX'], ['X', 'X'], ['XX'], ['X', 'X'],
    ['XXX'], ['X', 'X', 'X'],
    ['XXXX'], ['X', 'X', 'X', 'X'],
    ['XX', 'XX'], ['XX', 'XX'],
    ['X.', 'XX'], ['.X', 'XX'], ['XX', 'X.'], ['XX', '.X'],
    ['XXX', 'X..'], ['XXX', '..X'], ['X..', 'XXX'], ['..X', 'XXX'],
    ['X.', 'XX', 'X.'], ['.X', 'XX', '.X'],
    ['XX.', '.XX'], ['.XX', 'XX.']
  ];

  var COLORS = ['yellow', 'orange', 'sky', 'purple', 'green', 'pink'];
  var PIECES_PER_DEAL = 3;
  var trayEl = null;

  function pick(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  function toCells(shape) {
    var out = [];
    shape.forEach(function (row, r) {
      for (var c = 0; c < row.length; c++) {
        if (row.charAt(c) === 'X') out.push({ r: r, c: c });
      }
    });
    return out;
  }

  function build(shape, color) {
    return { shape: shape, cells: toCells(shape), rows: shape.length, cols: shape[0].length, color: color };
  }

  function createPiece() {
    return build(pick(SHAPES), pick(COLORS));
  }

  function deal() {
    var set = [];
    for (var i = 0; i < PIECES_PER_DEAL; i++) set.push(createPiece());
    return set;
  }

  function createPieceElement(piece) {
    var el = document.createElement('div');
    el.className = 'piece block--' + piece.color;
    el.style.setProperty('--rows', piece.rows);
    el.style.setProperty('--cols', piece.cols);
    piece.cells.forEach(function (cell) {
      var tile = document.createElement('div');
      tile.className = 'tile';
      tile.style.gridRow = String(cell.r + 1);
      tile.style.gridColumn = String(cell.c + 1);
      el.appendChild(tile);
    });
    return el;
  }

  function renderTray(pieces) {
    trayEl.textContent = '';
    var fragment = document.createDocumentFragment();
    pieces.forEach(function (piece, index) {
      var slot = document.createElement('div');
      slot.className = 'tray__slot';
      slot.dataset.index = index;
      if (piece) slot.appendChild(createPieceElement(piece));
      fragment.appendChild(slot);
    });
    trayEl.appendChild(fragment);
  }

  function clearSlot(index) {
    var slot = trayEl.children[index];
    if (slot) slot.textContent = '';
  }

  function init(container) { trayEl = container; }

  BM.pieces = {
    SHAPES: SHAPES,
    init: init,
    create: createPiece,
    build: build,
    createElement: createPieceElement,
    deal: deal,
    renderTray: renderTray,
    clearSlot: clearSlot
  };
})(window.BlockMaster = window.BlockMaster || {});
