/* game.js — rules loop: place, score, clear, deal, game over, save/resume */
(function (BM) {
  'use strict';
  var CLEAR_MS = 280;
  var state = { score: 0, best: 0, combo: 0, pieces: [], over: false, newBest: false };
  var locked = false;
  var snapshot = null;
  var coinsCache = 0;
  var free = { undo: 1, shuffle: 1 };
  var COST = { undo: 20, shuffle: 30 };
  var el = {};

  function renderHud() {
    if (el.score.textContent !== String(state.score)) {
      el.score.classList.remove('bump'); void el.score.offsetWidth; el.score.classList.add('bump');
    }
    el.score.textContent = String(state.score);
    el.best.textContent = String(state.best);
    el.coins.textContent = String(coinsCache);
    ['undo', 'shuffle'].forEach(function (k) {
      var tag = document.getElementById(k + '-tag');
      tag.textContent = free[k] > 0 ? String(free[k]) : String(COST[k]);
      tag.classList.toggle('act__tag--paid', free[k] <= 0);
    });
    document.getElementById('btn-undo').disabled = !snapshot;
  }
  function addCoins(n) { coinsCache += n; BM.storage.later('coins', coinsCache); }
  // free use first, then coins; returns false if the player cannot pay
  function pay(kind) {
    if (free[kind] > 0) { free[kind]--; return true; }
    var have = coinsCache;
    if (have < COST[kind]) {
      var btn = document.getElementById('btn-' + kind);
      btn.classList.remove('deny'); void btn.offsetWidth; btn.classList.add('deny');
      BM.settings.vibrate(40);
      return false;
    }
    coinsCache = have - COST[kind];
    BM.storage.later('coins', coinsCache);
    return true;
  }
  function undo() {
    if (!snapshot || locked || state.over || !pay('undo')) { renderHud(); return; }
    BM.board.load(snapshot.grid);
    state.pieces = snapshot.pieces.slice();
    state.score = snapshot.score; state.combo = snapshot.combo;
    snapshot = null;
    BM.audio.play('click');
    BM.pieces.renderTray(state.pieces); renderHud(); save();
  }
  function shuffle() {
    if (locked || state.over || !pay('shuffle')) { renderHud(); return; }
    snapshot = null;
    state.pieces = dealFair();
    BM.audio.play('pick');
    BM.pieces.renderTray(state.pieces); renderHud(); save();
    checkOver();
  }
  function addScore(n) {
    state.score += n;
    if (state.score > state.best) {
      if (state.best > 0) state.newBest = true;
      state.best = state.score;
      BM.storage.setBest(state.best);
    }
    renderHud();
  }
  function save() {
    BM.storage.later('game', state.over ? null : {
      grid: BM.board.getGrid().map(function (row) { return row.slice(); }), score: state.score, combo: state.combo, free: free,
      pieces: state.pieces.map(function (p) { return p && { shape: p.shape, color: p.color }; })
    });
  }
  function dealFair() {
    var set, tries = 0;
    do { set = BM.pieces.deal(); tries++; }
    while (tries < 30 && !set.some(function (p) { return BM.board.anyFit(p); }));
    return set;
  }
  function checkOver() {
    var alive = state.pieces.some(function (p) { return p && BM.board.anyFit(p); });
    if (!alive) endGame();
  }
  function endGame() {
    state.over = true; save();
    var reward = BM.rewards.award(state.score);
    coinsCache = reward.total;
    BM.storage.flush();
    BM.audio.play('over'); BM.settings.vibrate([60, 40, 120]);
    document.getElementById('over-score').textContent = String(state.score);
    document.getElementById('over-coins').textContent = '+' + reward.coins;
    document.getElementById('over-medal').style.color = reward.tier.color;
    document.getElementById('over-new').hidden = !state.newBest;
    document.getElementById('over').hidden = false;
  }

  function place(index, r, c) {
    var piece = state.pieces[index];
    if (!piece || locked || !BM.board.canPlace(piece, r, c)) return;
    snapshot = {
      grid: BM.board.getGrid().map(function (row) { return row.slice(); }),
      pieces: state.pieces.slice(), score: state.score, combo: state.combo
    };
    var placed = BM.board.place(piece, r, c);
    state.pieces[index] = null;
    BM.pieces.clearSlot(index);
    BM.audio.play('place'); BM.settings.vibrate(12);
    addScore(BM.scoring.placement(piece.cells.length));
    BM.board.render();
    BM.board.pop(placed);

    var lines = BM.board.fullLines();
    if (!lines.count) {
      state.combo = 0;
      afterMove();
      return;
    }
    state.combo++;
    var gained = BM.scoring.clear(lines.count, state.combo, state.score);
    locked = true;
    BM.board.markClearing(lines);
    BM.animations.burst(BM.board.cellsOf(lines));
    addCoins(lines.count);
    BM.audio.play('clear', state.combo); BM.settings.vibrate(30);
    window.setTimeout(function () {
      BM.board.removeLines(lines);
      BM.board.render();
      var perfect = BM.board.isEmpty();
      if (perfect) { gained += BM.scoring.perfect(state.score); BM.audio.play('perfect'); }
      var tierBefore = BM.scoring.tier(state.score);
      addScore(gained);
      if (BM.scoring.tier(state.score) > tierBefore) {
        BM.animations.floatText('LINE +' + BM.scoring.perLine(state.score), 'float--tier', 2);
      }
      BM.animations.floatText('+' + gained, 'float--score');
      if (perfect) BM.animations.floatText('PERFECT', 'float--combo', 1);
      else if (state.combo > 1) BM.animations.floatText('COMBO x' + state.combo, 'float--combo', 1);
      locked = false;
      afterMove();
    }, CLEAR_MS);
  }

  function afterMove() {
    if (state.pieces.every(function (p) { return !p; })) {
      state.pieces = dealFair();
      BM.pieces.renderTray(state.pieces);
    }
    save();
    checkOver();
  }

  function newGame() {
    state.score = 0; state.combo = 0; state.over = false; state.newBest = false;
    free = { undo: 1, shuffle: 1 }; snapshot = null;
    state.best = BM.storage.getBest();
    locked = false;
    BM.board.reset(); BM.board.render();
    state.pieces = dealFair();
    BM.pieces.renderTray(state.pieces);
    document.getElementById('over').hidden = true;
    renderHud(); save();
  }

  function resume(saved) {
    state.score = saved.score; state.combo = saved.combo; state.over = false;
    if (saved.free) free = { undo: saved.free.undo | 0, shuffle: saved.free.shuffle | 0 };
    state.best = BM.storage.getBest();
    BM.board.load(saved.grid);
    state.pieces = saved.pieces.map(function (p) { return p && BM.pieces.build(p.shape, p.color); });
    BM.pieces.renderTray(state.pieces);
    renderHud(); checkOver();
  }

  function valid(s) {
    return s && Array.isArray(s.grid) && s.grid.length === 8 && Array.isArray(s.pieces) && s.pieces.length === 3 &&
      typeof s.score === 'number' && s.pieces.some(Boolean);
  }

  function init() {
    el.score = document.getElementById('score-value');
    el.best = document.getElementById('best-value');
    el.coins = document.getElementById('coins-value');
    coinsCache = BM.storage.get('coins', 0);
    BM.board.init(document.getElementById('board-grid'));
    BM.pieces.init(document.getElementById('tray'));
    document.getElementById('over-replay').addEventListener('click', function () { BM.audio.play('click'); newGame(); });
    document.getElementById('over-home').addEventListener('click', function () { newGame(); window.location.hash = 'home'; });
    document.getElementById('btn-undo').addEventListener('click', undo);
    document.getElementById('btn-shuffle').addEventListener('click', shuffle);
    document.getElementById('game-home-btn').addEventListener('click', function () { BM.audio.play('click'); window.location.hash = 'home'; });
    var saved = BM.storage.get('game', null);
    if (valid(saved)) resume(saved); else newGame();
  }

  BM.game = { init: init, newGame: newGame, place: place, state: state, isLocked: function () { return locked || state.over; } };
})(window.BlockMaster = window.BlockMaster || {});
