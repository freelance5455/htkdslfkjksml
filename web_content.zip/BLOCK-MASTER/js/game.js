/* game.js — rules loop: place, score, clear, deal, game over, save/resume */
(function (BM) {
  'use strict';
  var CLEAR_MS = 280;
  var state = { score: 0, best: 0, combo: 0, pieces: [], over: false, newBest: false };
  var locked = false;
  var snapshot = null;
  var coinsCache = 0;
  var free = { undo: 1, shuffle: 1 };
  var COST = { undo: 20, shuffle: 30 };
  var el = {};

  // Score rolls up to its new value instead of jumping
  var shown = 0, target = 0, rollFrame = 0;
  function rollTo(to) {
    window.cancelAnimationFrame(rollFrame);
    var from = shown, t0 = performance.now(), dur = Math.min(1300, 300 + (to - from) * 1.5);
    if (to <= from) { shown = to; el.score.textContent = String(to); return; }
    (function step(t) {
      var k = Math.min(1, (t - t0) / dur);
      shown = Math.round(from + (to - from) * (1 - Math.pow(1 - k, 3)));
      el.score.textContent = String(shown);
      if (k < 1) rollFrame = window.requestAnimationFrame(step);
    })(t0);
  }
  function renderHud() {
    if (target !== state.score) {
      el.score.classList.remove('bump'); void el.score.offsetWidth; el.score.classList.add('bump');
      target = state.score;
    }
    rollTo(state.score);
    el.best.textContent = String(state.best);
    el.coins.textContent = String(coinsCache);
    ['undo', 'shuffle'].forEach(function (k) {
      var tag = document.getElementById(k + '-tag');
      tag.textContent = free[k] > 0 ? String(free[k]) : String(COST[k]);
      tag.classList.toggle('act__tag--paid', free[k] <= 0);
    });
    document.getElementById('btn-undo').disabled = !snapshot;
  }
  function addCoins(n) { coinsCache += n; BM.storage.later('coins', coinsCache); }
  // free use first, then coins; returns false if the player cannot pay
  function pay(kind) {
    if (free[kind] > 0) { free[kind]--; return true; }
    var have = coinsCache;
    if (have < COST[kind]) {
      var btn = document.getElementById('btn-' + kind);
      btn.classList.remove('deny'); void btn.offsetWidth; btn.classList.add('deny');
      BM.settings.vibrate(40);
      return false;
    }
    coinsCache = have - COST[kind];
    BM.storage.later('coins', coinsCache);
    return true;
  }
  function undo() {
    if (!snapshot || locked || state.over || !pay('undo')) { renderHud(); return; }
    BM.board.load(snapshot.grid);
    state.pieces = snapshot.pieces.slice();
    state.score = snapshot.score; state.combo = snapshot.combo;
    snapshot = null;
    BM.audio.play('click');
    BM.pieces.renderTray(state.pieces); renderHud(); save();
  }
  function shuffle() {
    if (locked || state.over || !pay('shuffle')) { renderHud(); return; }
    snapshot = null;
    state.pieces = dealFair();
    BM.audio.play('pick');
    BM.pieces.renderTray(state.pieces); renderHud(); save();
    checkOver();
  }
  function addScore(n) {
    state.score += n;
    if (state.score > state.best) {
      if (state.best > 0) state.newBest = true;
      state.best = state.score;
      BM.storage.setBest(state.best);
    }
    renderHud();
  }
  function save() {
    BM.storage.later('game', state.over ? null : {
      grid: BM.board.getGrid().map(function (row) { return row.slice(); }), score: state.score, combo: state.combo, free: free,
      pieces: state.pieces.map(function (p) { return p && { shape: p.shape, color: p.color }; })
    });
  }
  function dealFair() {
    var set, tries = 0;
    do { set = BM.pieces.deal(); tries++; }
    while (tries < 30 && !set.some(function (p) { return BM.board.anyFit(p); }));
    return set;
  }
  function checkOver() {
    var alive = state.pieces.some(function (p) { return p && BM.board.anyFit(p); });
    if (alive) return;
    var banner = document.getElementById('nospace');
    locked = true; banner.hidden = false;
    window.setTimeout(function () { banner.hidden = true; locked = false; endGame(); }, 1100);
  }
  function endGame() {
    if (state.over) return;
    state.over = true; save();
    var reward = BM.rewards.award(state.score);
    coinsCache = reward.total;
    BM.storage.flush();
    BM.audio.play('over'); BM.settings.vibrate([60, 40, 120]);
    document.getElementById('over-score').textContent = String(state.score);
    document.getElementById('over-coins').textContent = '+' + reward.coins;
    document.getElementById('over-medal').style.color = reward.tier.color;
    document.getElementById('over-new').hidden = !state.newBest;
    document.getElementById('over').hidden = false;
  }

  function place(index, r, c) {
    var piece = state.pieces[index];
    if (!piece || locked || !BM.board.canPlace(piece, r, c)) return;
    snapshot = {
      grid: BM.board.getGrid().map(function (row) { return row.slice(); }),
      pieces: state.pieces.slice(), score: state.score, combo: state.combo
    };
    var placed = BM.board.place(piece, r, c);
    state.pieces[index] = null;
    BM.pieces.clearSlot(index);
    BM.audio.play('place'); BM.settings.vibrate(12);
    addScore(BM.scoring.placement(piece.cells.length));
    BM.board.render();
    BM.board.pop(placed);
    if (BM.animations.plusOnes) BM.animations.plusOnes(placed);

    var lines = BM.board.fullLines();
    if (!lines.count) {
      state.combo = 0;
      afterMove();
      return;
    }
    state.combo++;
    var gained = BM.scoring.clear(lines.count, state.combo);
    locked = true;
    BM.board.markClearing(lines);
    BM.animations.burst(BM.board.cellsOf(lines));
    addCoins(lines.count);
    BM.audio.play('clear', state.combo); BM.settings.vibrate(30);
    window.setTimeout(function () {
      BM.board.removeLines(lines);
      BM.board.render();
      var perfect = BM.board.isEmpty();
      if (perfect) { gained += BM.scoring.perfect(); BM.audio.play('perfect'); }
      addScore(gained);
      var big = lines.count >= 3 || state.combo >= 3 || perfect;
      BM.animations.floatText('+' + gained, big ? 'float--score float--big' : 'float--score');
      if (big) {
        var boardEl = document.getElementById('board');
        boardEl.classList.add('board--gold');
        window.setTimeout(function () { boardEl.classList.remove('board--gold'); }, 1000);
      }
      if (perfect) BM.animations.floatText('Perfect!', 'float--perfect', 1);
      else if (state.combo > 1) BM.animations.floatText('Combo x' + state.combo, 'float--combo', 1);
      locked = false;
      afterMove();
    }, CLEAR_MS);
  }

  function afterMove() {
    if (state.pieces.every(function (p) { return !p; })) {
      state.pieces = dealFair();
      BM.pieces.renderTray(state.pieces);
    }
    save();
    checkOver();
  }

  function newGame() {
    state.score = 0; state.combo = 0; state.over = false; state.newBest = false;
    free = { undo: 1, shuffle: 1 }; snapshot = null;
    state.best = BM.storage.getBest();
    locked = false;
    BM.board.reset(); BM.board.render();
    state.pieces = dealFair();
    BM.pieces.renderTray(state.pieces);
    document.getElementById('over').hidden = true;
    renderHud(); save();
  }

  function resume(saved) {
    state.score = saved.score; state.combo = saved.combo; state.over = false;
    if (saved.free) free = { undo: saved.free.undo | 0, shuffle: saved.free.shuffle | 0 };
    state.best = BM.storage.getBest();
    BM.board.load(saved.grid);
    state.pieces = saved.pieces.map(function (p) {
      if (!p) return null;
      var supported = BM.pieces.SHAPES.some(function (shape) {
        return JSON.stringify(shape) === JSON.stringify(p.shape);
      });
      // Replace legacy oversized pieces in saved games with a current easy piece.
      return supported ? BM.pieces.build(p.shape, p.color) : BM.pieces.create();
    });
    BM.pieces.renderTray(state.pieces);
    renderHud(); checkOver();
  }

  function valid(s) {
    return s && Array.isArray(s.grid) && s.grid.length === 8 && Array.isArray(s.pieces) && s.pieces.length === 3 &&
      typeof s.score === 'number' && s.pieces.some(Boolean);
  }

  function init() {
    el.score = document.getElementById('score-value');
    el.best = document.getElementById('best-value');
    el.coins = document.getElementById('coins-value');
    coinsCache = BM.storage.get('coins', 0);
    BM.board.init(document.getElementById('board-grid'));
    BM.pieces.init(document.getElementById('tray'));
    document.getElementById('over-replay').addEventListener('click', function () { BM.audio.play('click'); newGame(); });
    document.getElementById('over-home').addEventListener('click', function () { newGame(); window.location.hash = 'home'; });
    document.getElementById('btn-undo').addEventListener('click', undo);
    document.getElementById('btn-shuffle').addEventListener('click', shuffle);
    document.getElementById('game-home-btn').addEventListener('click', function () { BM.audio.play('click'); window.location.hash = 'home'; });
    var saved = BM.storage.get('game', null);
    if (valid(saved)) resume(saved); else newGame();
  }

  BM.game = { init: init, newGame: newGame, place: place, state: state, isLocked: function () { return locked || state.over; } };
})(window.BlockMaster = window.BlockMaster || {});
