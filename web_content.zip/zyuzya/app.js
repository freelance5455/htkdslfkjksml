(() => {
'use strict';

/* ================= Допоміжне ================= */
const KEY = 'zyuzya.v1';
const $ = (s, r = document) => r.querySelector(s);
const p2 = n => String(n).padStart(2, '0');
const iso = d => d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
const today = () => iso(new Date());
const addDays = (n, from = new Date()) => { const d = new Date(from); d.setDate(d.getDate() + n); return d; };
const fmtDate = s => { if (!s) return ''; const [y, m, d] = s.split('-'); return d + '.' + m + '.' + y; };
const fmtShort = s => { if (!s) return ''; const [, m, d] = s.split('-'); return d + '.' + m; };
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const parseNum = s => { const n = parseFloat(String(s).replace(/\s/g, '').replace(',', '.')); return isFinite(n) ? n : NaN; };
const shuffle = a => { a = [...a]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const weekStart = () => { const d = new Date(); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return iso(d); };
const DAY = 86400000;

/* ================= Дані ================= */
const SEED = [
  ['hello', '/həˈləʊ/', 'привіт'], ['goodbye', '/ˌɡʊdˈbaɪ/', 'до побачення'], ['thank you', '/ˈθæŋk juː/', 'дякую'],
  ['please', '/pliːz/', 'будь ласка'], ['sorry', '/ˈsɒri/', 'вибач'], ['yes', '/jes/', 'так'], ['no', '/nəʊ/', 'ні'],
  ['water', '/ˈwɔːtə/', 'вода'], ['food', '/fuːd/', 'їжа'], ['friend', '/frend/', 'друг'], ['family', '/ˈfæməli/', 'сім’я'],
  ['home', '/həʊm/', 'дім'], ['money', '/ˈmʌni/', 'гроші'], ['work', '/wɜːk/', 'робота'], ['school', '/skuːl/', 'школа'],
  ['book', '/bʊk/', 'книга'], ['phone', '/fəʊn/', 'телефон'], ['motorcycle', '/ˈməʊtəˌsaɪkl/', 'мотоцикл'],
  ['road', '/rəʊd/', 'дорога'], ['fast', '/fɑːst/', 'швидкий'], ['strong', '/strɒŋ/', 'сильний'], ['train', '/treɪn/', 'тренуватися'],
  ['learn', '/lɜːn/', 'вчити'], ['time', '/taɪm/', 'час'], ['today', '/təˈdeɪ/', 'сьогодні'], ['tomorrow', '/təˈmɒrəʊ/', 'завтра'],
  ['goal', '/ɡəʊl/', 'ціль'], ['save', '/seɪv/', 'заощаджувати'], ['buy', '/baɪ/', 'купувати'], ['happy', '/ˈhæpi/', 'щасливий'],
  ['big', '/bɪɡ/', 'великий'], ['small', '/smɔːl/', 'малий'], ['new', '/njuː/', 'новий'], ['good', '/ɡʊd/', 'добрий'], ['help', '/help/', 'допомога']
];

const LESSONS = [
  { id: 'l1', title: 'Привітання', icon: 'star', tip: 'Починай розмову з простих фраз. Повтори кожну вголос.', items: [
    ['Hello', 'Привіт'], ['Good morning', 'Доброго ранку'], ['Good afternoon', 'Доброго дня'], ['Good evening', 'Добрий вечір'],
    ['Good night', 'На добраніч'], ['Goodbye', 'До побачення'], ['See you later', 'Побачимося пізніше'], ['How are you?', 'Як справи?'],
    ['I’m fine, thanks', 'Усе добре, дякую'], ['Nice to meet you', 'Приємно познайомитись']] },
  { id: 'l2', title: 'Знайомство', icon: 'star', tip: 'Про себе: ім’я, країна, мова.', items: [
    ['My name is…', 'Мене звати…'], ['What is your name?', 'Як тебе звати?'], ['I am from Ukraine', 'Я з України'],
    ['Where are you from?', 'Звідки ти?'], ['I am … years old', 'Мені … років'], ['I live in…', 'Я живу в…'],
    ['I speak Ukrainian', 'Я говорю українською'], ['I am learning English', 'Я вчу англійську'],
    ['Do you understand?', 'Ти розумієш?'], ['Please speak slowly', 'Говори повільніше, будь ласка']] },
  { id: 'l3', title: 'Числа 1–10', icon: 'list', tip: 'Числа потрібні скрізь: ціни, час, підходи.', items: [
    ['one', 'один'], ['two', 'два'], ['three', 'три'], ['four', 'чотири'], ['five', 'п’ять'], ['six', 'шість'],
    ['seven', 'сім'], ['eight', 'вісім'], ['nine', 'дев’ять'], ['ten', 'десять']] },
  { id: 'l4', title: 'Їжа та напої', icon: 'star', tip: 'Слова для кафе та магазину.', items: [
    ['bread', 'хліб'], ['water', 'вода'], ['milk', 'молоко'], ['apple', 'яблуко'], ['coffee', 'кава'], ['tea', 'чай'],
    ['meat', 'м’ясо'], ['soup', 'суп'], ['I am hungry', 'Я голодний'], ['I am thirsty', 'Я хочу пити']] },
  { id: 'l5', title: 'Тренування', icon: 'dumbbell', tip: 'Слова із залу та турніка.', items: [
    ['pull-up', 'підтягування'], ['push-up', 'віджимання'], ['dips', 'віджимання на брусах'], ['abs', 'прес'],
    ['squat', 'присідання'], ['set', 'підхід'], ['repetition', 'повторення'], ['rest', 'відпочинок'],
    ['muscle', 'м’яз'], ['warm-up', 'розминка']] },
  { id: 'l6', title: 'Гроші та покупки', icon: 'wallet', tip: 'Для магазину, банку й онлайн-покупок.', items: [
    ['money', 'гроші'], ['price', 'ціна'], ['cheap', 'дешевий'], ['expensive', 'дорогий'], ['to buy', 'купувати'],
    ['to sell', 'продавати'], ['to pay', 'платити'], ['savings', 'заощадження'], ['salary', 'зарплата'], ['discount', 'знижка']] },
  { id: 'l7', title: 'Дні тижня', icon: 'calendar', tip: 'Дні тижня в англійській пишуться з великої літери.', items: [
    ['Monday', 'понеділок'], ['Tuesday', 'вівторок'], ['Wednesday', 'середа'], ['Thursday', 'четвер'], ['Friday', 'п’ятниця'],
    ['Saturday', 'субота'], ['Sunday', 'неділя'], ['week', 'тиждень'], ['weekend', 'вихідні']] },
  { id: 'l8', title: 'Дорога й транспорт', icon: 'bike', tip: 'Корисно для мандрівок і мотоцикла.', items: [
    ['motorcycle', 'мотоцикл'], ['helmet', 'шолом'], ['road', 'дорога'], ['bus', 'автобус'], ['train', 'потяг'],
    ['station', 'станція'], ['ticket', 'квиток'], ['fast', 'швидко'], ['slow', 'повільно'], ['Where is…?', 'Де знаходиться…?']] }
];

const EXP_CATS = ['Їжа', 'Транспорт', 'Розваги', 'Одяг', 'Зв’язок', 'Здоров’я', 'Навчання', 'Накопичення', 'Інше'];
const INC_CATS = ['Зарплата', 'Підробіток', 'Подарунок', 'Кишенькові', 'Повернення з цілі', 'Інше'];
const PRESET_EX = ['Підтягування', 'Віджимання', 'Бруси', 'Прес', 'Присідання', 'Планка'];
const INTERVALS = [0, 1, 2, 4, 8, 16];
const GOAL_KINDS = { moto: ['Мотоцикл', 'bike'], phone: ['Телефон', 'phone'], other: ['Інша ціль', 'star'] };
const PRIO = { 0: ['Високий', 'red'], 1: ['Середній', 'vio'], 2: ['Низький', 'grn'] };

const mkWord = (en, uk, ipa) => ({ id: uid(), en, uk, ipa: ipa || '', box: 0, due: 0 });
function defaults() {
  return { v: 1, name: '', cur: '₴', tx: [], goals: [], work: [], words: SEED.map(([e, i, u]) => mkWord(e, u, i)),
    lessons: {}, tasks: [], daily: { tasks: 3, words: 10, workout: 1 }, revByDay: {}, lastBackup: null, welcomed: false };
}
function migrate(o) {
  const d = defaults(); const s = { ...d, ...o };
  s.daily = { ...d.daily, ...(o.daily || {}) };
  ['tx', 'goals', 'work', 'words', 'tasks'].forEach(k => { if (!Array.isArray(s[k])) s[k] = d[k]; });
  if (!s.lessons || typeof s.lessons !== 'object') s.lessons = {};
  if (!s.revByDay || typeof s.revByDay !== 'object') s.revByDay = {};
  return s;
}
function load() {
  let raw = null;
  try { raw = localStorage.getItem(KEY); if (raw) return migrate(JSON.parse(raw)); }
  catch (e) { try { if (raw) localStorage.setItem(KEY + '.corrupt', raw); } catch (_) {} }
  return defaults();
}
let S = load();
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(S)); }
  catch (e) { toast('Не вдалося зберегти: немає місця в пам’яті'); }
}

/* ================= Іконки ================= */
const IC = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  wallet: '<path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v11a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1v-9a1 1 0 0 0-1-1H5a2 2 0 0 1-2-2z"/><circle cx="16" cy="14" r="1.2"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  dumbbell: '<path d="M6 6v12M18 6v12M3 9v6M21 9v6M6 12h12"/>',
  more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
  book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5z"/><path d="M6.5 17v4H20"/>',
  check: '<path d="M5 12l5 5L20 7"/>',
  checksq: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M8 12l3 3 5-6"/>',
  sliders: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M13.5 6.5l4 4"/>',
  volume: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  upload: '<path d="M12 16V5M7 10l5-5 5 5M5 20h14"/>',
  bike: '<circle cx="6" cy="16" r="3.5"/><circle cx="18" cy="16" r="3.5"/><path d="M6 16l3-6h5l4 6M9 10L8 7H6M14 10l-1-3h3"/>',
  phone: '<rect x="7" y="2" width="10" height="20" rx="2.5"/><path d="M11 18h2"/>',
  flame: '<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3-1-6 1-9z"/>',
  repeat: '<path d="M4 11V9a3 3 0 0 1 3-3h12l-3-3M20 13v2a3 3 0 0 1-3 3H5l3 3"/>',
  cap: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c3 2.5 9 2.5 12 0v-5"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  star: '<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
  chevron: '<path d="M9 6l6 6-6 6"/>',
  back: '<path d="M15 6l-6 6 6 6"/>',
  share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',
  inbox: '<path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 3h6l1-3h5"/>'
};
const ICON = (n, s = 22) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`;

function ring(p, size = 100, sw = 10) {
  const r = (size - sw) / 2, c = 2 * Math.PI * r, h = size / 2;
  return `<svg class="ring" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" style="--c:${c}" role="img" aria-label="${Math.round(p * 100)}%">
  <defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#22d3a0"/></linearGradient></defs>
  <circle cx="${h}" cy="${h}" r="${r}" fill="none" stroke="#241f38" stroke-width="${sw}"/>
  <circle class="rp" cx="${h}" cy="${h}" r="${r}" fill="none" stroke="url(#rg)" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - p)}" transform="rotate(-90 ${h} ${h})"/>
  <text x="${h}" y="${h + 6}" text-anchor="middle" fill="#ece9f6" font-size="${size * 0.22}" font-weight="800" font-family="system-ui">${Math.round(p * 100)}%</text></svg>`;
}
const bar = (p, cls = '') => `<div class="bar ${cls}"><i style="width:${Math.max(0, Math.min(100, p))}%"></i></div>`;
const money = n => (Math.round(n * 100) / 100).toLocaleString('uk-UA') + ' ' + S.cur;
const fld = (label, inner) => `<label class="fld"><span>${label}</span>${inner}</label>`;
const opts = (arr, sel) => arr.map(x => `<option ${x === sel ? 'selected' : ''}>${esc(x)}</option>`).join('');
const empty = (icon, text) => `<div class="empty">${ICON(icon, 36)}<div>${text}</div></div>`;

/* ================= Тости та шторки ================= */
let toastT;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2400);
}
const stack = [];
function openSheet(title, html) {
  const ov = document.createElement('div'); ov.className = 'ov';
  ov.innerHTML = `<div class="sheet" role="dialog" aria-label="${esc(title)}"><div class="grab"></div><div class="sh-head"><h3>${esc(title)}</h3><button class="icon-btn" data-act="closeTop" aria-label="Закрити">${ICON('x', 20)}</button></div>${html}</div>`;
  ov.addEventListener('click', e => { if (e.target === ov) closeTop(); });
  document.body.appendChild(ov); stack.push(ov);
  history.pushState({ tab: ui.tab, sheet: stack.length }, '');
  requestAnimationFrame(() => requestAnimationFrame(() => ov.classList.add('in')));
  return ov;
}
function removeTop() {
  const ov = stack.pop(); if (!ov) return;
  ov.classList.remove('in'); setTimeout(() => ov.remove(), 260);
}
const closeTop = () => { if (stack.length) history.go(-1); };
const closeAll = () => { if (stack.length) history.go(-stack.length); };

function openForm({ title, body, submit = 'Зберегти', onSubmit, del }) {
  const html = `<form class="sheet-body" autocomplete="off">${body}<div class="row gap"><button class="btn primary grow" type="submit">${submit}</button>${del ? `<button class="btn danger" type="button" data-form-del aria-label="Видалити">${ICON('trash', 20)}</button>` : ''}</div></form>`;
  const el = openSheet(title, html);
  const f = $('form', el);
  f.addEventListener('submit', e => {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(f));
    if (onSubmit(fd, f) !== false) closeAll();
  });
  if (del) $('[data-form-del]', el).onclick = () => confirmBox(del.text, del.fn);
  return el;
}
function confirmBox(text, fn, label = 'Так, видалити') {
  const el = openSheet('Підтвердження', `<p style="margin:0 0 16px">${esc(text)}</p><div class="row gap"><button class="btn grow" data-act="closeTop">Скасувати</button><button class="btn danger grow" id="cfy">${label}</button></div>`);
  $('#cfy', el).onclick = () => { fn(); closeAll(); };
}

/* ================= Стан інтерфейсу ================= */
const ui = { tab: 'home', anim: true, q: {}, f: { fin: 'all', task: 'active' }, engTab: 'dict', lesson: null, quiz: null, rev: null, exSel: null };
const TITLES = { home: 'Зюзя', fin: 'Фінанси', goals: 'Мої цілі', train: 'Тренування', more: 'Ще', eng: 'Англійська', tasks: 'Завдання', settings: 'Налаштування' };
const NAV = [['home', 'home', 'Головна'], ['fin', 'wallet', 'Фінанси'], ['goals', 'target', 'Цілі'], ['train', 'dumbbell', 'Тренування'], ['more', 'more', 'Ще']];
const navOf = t => (['eng', 'tasks', 'settings'].includes(t) ? 'more' : t);

/* ================= Обчислення ================= */
const balance = () => S.tx.reduce((a, t) => a + (t.type === 'in' ? t.amt : -t.amt), 0);
const goalPct = g => (g.target > 0 ? Math.min(100, Math.floor(g.saved / g.target * 100)) : 0);
const learned = () => S.words.filter(w => w.box >= 3).length;
function daily() {
  const t = today();
  const g = [
    { name: 'Завдання', icon: 'checksq', tab: 'tasks', done: S.tasks.filter(x => x.doneAt === t).length, target: +S.daily.tasks || 0 },
    { name: 'Тренування', icon: 'dumbbell', tab: 'train', done: S.work.filter(w => w.date === t).length, target: +S.daily.workout || 0 },
    { name: 'Слова', icon: 'book', tab: 'eng', done: S.revByDay[t] || 0, target: +S.daily.words || 0 }
  ];
  const act = g.filter(x => x.target > 0);
  const p = act.length ? act.reduce((a, x) => a + Math.min(1, x.done / x.target), 0) / act.length : 0;
  return { g, p };
}
function streak() {
  const days = new Set(S.work.map(w => w.date)); let n = 0, d = new Date();
  if (!days.has(iso(d))) d = addDays(-1, d);
  while (days.has(iso(d))) { n++; d = addDays(-1, d); }
  return n;
}
function speak(text) {
  if (!('speechSynthesis' in window)) { toast('Озвучення недоступне на цьому пристрої'); return; }
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text); u.lang = 'en-US'; u.rate = 0.85;
    speechSynthesis.speak(u);
  } catch (e) { toast('Не вдалося озвучити'); }
}

/* ================= Екрани ================= */
const views = {}, lists = {};

/* ---- Головна ---- */
views.home = () => {
  const D = daily(), h = new Date().getHours();
  const hello = h < 5 ? 'Доброї ночі' : h < 12 ? 'Доброго ранку' : h < 18 ? 'Доброго дня' : 'Добрий вечір';
  const date = cap(new Date().toLocaleDateString('uk-UA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }));
  const weekDays = new Set(S.work.filter(w => w.date >= weekStart()).map(w => w.date)).size;
  const activeTasks = S.tasks.filter(t => !t.done).length;
  const goals = S.goals.slice().sort((a, b) => goalPct(b) - goalPct(a)).slice(0, 2);
  const st = streak();
  return `
  <div class="card hero">
    <div class="muted" style="font-size:13px">${esc(date)}</div>
    <div style="font-size:22px;font-weight:800;margin:2px 0 14px">${hello}${S.name ? ', ' + esc(S.name) : ''}!</div>
    <div class="row gap">
      ${ring(D.p, 104, 11)}
      <div class="grow">
        <div style="font-weight:700">Цілі на день</div>
        ${D.g.map(x => x.target > 0 ? `<div class="gline" data-act="go" data-t="${x.tab}">${ICON(x.icon, 18)}<div class="bar"><i style="width:${Math.min(100, x.done / x.target * 100)}%"></i></div><small>${x.done}/${x.target}</small></div>` : '').join('') || '<div class="sub">Увімкни цілі в налаштуваннях</div>'}
      </div>
    </div>
  </div>
  <div class="grid2 mb">
    <div class="card tile" data-act="go" data-t="fin"><div class="l">${ICON('wallet', 16)} Баланс</div><div class="v ${balance() < 0 ? 'red' : ''}">${money(balance())}</div></div>
    <div class="card tile" data-act="go" data-t="tasks"><div class="l">${ICON('checksq', 16)} Активні завдання</div><div class="v">${activeTasks}</div></div>
    <div class="card tile" data-act="go" data-t="train"><div class="l">${ICON('flame', 16)} Тренувань за тиждень</div><div class="v">${weekDays}${st > 1 ? `<span class="sub" style="font-size:12px;font-weight:600"> · серія ${st} дн.</span>` : ''}</div></div>
    <div class="card tile" data-act="go" data-t="eng"><div class="l">${ICON('cap', 16)} Слів вивчено</div><div class="v">${learned()}<span class="sub" style="font-size:14px"> / ${S.words.length}</span></div></div>
  </div>
  <h2>Швидкі дії</h2>
  <div class="grid2 mb">
    <button class="btn" data-act="addTx" data-type="out">${ICON('down', 20)} Витрата</button>
    <button class="btn" data-act="addTx" data-type="in">${ICON('up', 20)} Дохід</button>
    <button class="btn" data-act="addWork">${ICON('dumbbell', 20)} Тренування</button>
    <button class="btn" data-act="addTask">${ICON('checksq', 20)} Завдання</button>
  </div>
  <h2>Мої цілі</h2>
  ${goals.length ? goals.map(g => goalCard(g, true)).join('') : `<div class="card empty">${ICON('target', 34)}<div>Ще немає цілей накопичення</div><button class="btn primary sm" style="margin-top:12px" data-act="addGoal">Створити ціль</button></div>`}`;
};

/* ---- Фінанси ---- */
views.fin = () => {
  const m = today().slice(0, 7); let inc = 0, exp = 0; const cats = {};
  S.tx.forEach(t => { if (t.date.startsWith(m)) { if (t.type === 'in') inc += t.amt; else { exp += t.amt; cats[t.cat] = (cats[t.cat] || 0) + t.amt; } } });
  const bal = balance(), top = Object.entries(cats).sort((a, b) => b[1] - a[1]);
  const mon = cap(new Date().toLocaleDateString('uk-UA', { month: 'long', year: 'numeric' }));
  const f = ui.f.fin;
  return `
  <div class="card hero">
    <div class="muted" style="font-size:13px">Грошей зараз</div>
    <div class="big ${bal < 0 ? 'red' : ''}">${money(bal)}</div>
    <div class="grid2" style="margin-top:12px">
      <div><div class="sub">Доходи, ${mon}</div><b class="grn">+${money(inc)}</b></div>
      <div><div class="sub">Витрати, ${mon}</div><b class="red">−${money(exp)}</b></div>
    </div>
  </div>
  <div class="grid2 mb">
    <button class="btn green" data-act="addTx" data-type="in">${ICON('plus', 20)} Дохід</button>
    <button class="btn primary" data-act="addTx" data-type="out">${ICON('plus', 20)} Витрата</button>
  </div>
  ${top.length ? `<h2>Витрати за категоріями</h2><div class="card">${top.map(([c, v]) => `<div style="margin-bottom:12px"><div class="row between" style="margin-bottom:6px"><span>${esc(c)}</span><b>${money(v)}</b></div>${bar(v / exp * 100)}</div>`).join('').replace(/margin-bottom:12px"><div class="row between"(?![\s\S]*margin-bottom:12px)/, '"><div class="row between"')}</div>` : ''}
  <h2>Історія операцій</h2>
  <div class="search">${ICON('search', 20)}<input data-q="fin" type="search" placeholder="Пошук за категорією, нотаткою, сумою" value="${esc(ui.q.fin || '')}"></div>
  <div class="chips">${[['all', 'Усі'], ['in', 'Доходи'], ['out', 'Витрати']].map(([k, l]) => `<button class="chip ${f === k ? 'on' : ''}" data-act="chip" data-g="fin" data-v="${k}">${l}</button>`).join('')}</div>
  <div id="list">${lists.fin()}</div>`;
};
lists.fin = () => {
  const q = (ui.q.fin || '').toLowerCase().trim(), f = ui.f.fin;
  const arr = S.tx.filter(t => (f === 'all' || t.type === f) && (!q || (t.cat + ' ' + t.note + ' ' + t.amt + ' ' + fmtDate(t.date)).toLowerCase().includes(q)))
    .sort((a, b) => b.date.localeCompare(a.date) || (b.ts || 0) - (a.ts || 0));
  if (!arr.length) return empty('inbox', S.tx.length ? 'Нічого не знайдено' : 'Операцій ще немає. Додай першу!');
  return arr.slice(0, 200).map(t => `<div class="item" data-act="editTx" data-id="${t.id}">
    <div class="badge ${t.type}">${ICON(t.type === 'in' ? 'up' : 'down', 20)}</div>
    <div class="grow"><b>${esc(t.cat)}</b><div class="sub">${esc(t.note || '')}${t.note ? ' · ' : ''}${fmtDate(t.date)}</div></div>
    <div class="amt ${t.type === 'in' ? 'grn' : 'red'}">${t.type === 'in' ? '+' : '−'}${money(t.amt)}</div></div>`).join('') + (arr.length > 200 ? '<div class="sub" style="text-align:center">Показано 200 останніх. Уточни пошук.</div>' : '');
};
function txSheet(type, id) {
  const t = id ? S.tx.find(x => x.id === id) : null; if (t) type = t.type;
  const body = `
    <div class="seg mb"><label><input type="radio" name="type" value="out" ${type === 'out' ? 'checked' : ''}><span>Витрата</span></label><label><input type="radio" name="type" value="in" ${type === 'in' ? 'checked' : ''}><span>Дохід</span></label></div>
    ${fld('Сума (' + S.cur + ')', `<input name="amt" inputmode="decimal" placeholder="0" required value="${t ? t.amt : ''}">`)}
    ${fld('Категорія', `<select name="cat">${opts(type === 'in' ? INC_CATS : EXP_CATS, t && t.cat)}</select>`)}
    ${fld('Нотатка', `<input name="note" maxlength="80" placeholder="Необов’язково" value="${esc(t ? t.note : '')}">`)}
    ${fld('Дата', `<input type="date" name="date" required value="${t ? t.date : today()}">`)}`;
  const el = openForm({
    title: t ? 'Редагувати операцію' : (type === 'in' ? 'Новий дохід' : 'Нова витрата'), body,
    onSubmit: fd => {
      const amt = parseNum(fd.amt);
      if (!(amt > 0)) { toast('Введи суму більше нуля'); return false; }
      const o = { type: fd.type, amt, cat: fd.cat, note: (fd.note || '').trim(), date: fd.date || today() };
      if (t) Object.assign(t, o); else S.tx.push({ id: uid(), ts: Date.now(), ...o });
      save(); render(); toast(t ? 'Збережено' : 'Операцію додано');
    },
    del: t && { text: 'Видалити цю операцію?', fn: () => { S.tx = S.tx.filter(x => x.id !== t.id); save(); render(); toast('Видалено'); } }
  });
  el.querySelectorAll('input[name=type]').forEach(r => r.addEventListener('change', () => {
    const sel = $('select[name=cat]', el); sel.innerHTML = opts(r.value === 'in' ? INC_CATS : EXP_CATS);
  }));
}

/* ---- Цілі ---- */
function goalCard(g, compact) {
  const p = goalPct(g), left = Math.max(0, g.target - g.saved), icon = (GOAL_KINDS[g.kind] || GOAL_KINDS.other)[1];
  return `<div class="card">
    <div class="row gap"><div class="badge">${ICON(icon, 22)}</div>
      <div class="grow"><b style="font-size:17px">${esc(g.name)}</b><div class="sub">${money(g.saved)} з ${money(g.target)}</div></div>
      <div style="font-size:22px;font-weight:800" class="${p >= 100 ? 'grn' : 'vio'}">${p}%</div></div>
    <div style="margin:14px 0 8px">${bar(p)}</div>
    <div class="row between sub"><span>${p >= 100 ? 'Ціль досягнуто!' : 'Залишилось ' + money(left)}</span><span>${p}% виконано</span></div>
    ${compact ? '' : `<div class="row gap" style="margin-top:14px"><button class="btn green grow" data-act="goalMoney" data-id="${g.id}">${ICON('plus', 18)} Рух коштів</button><button class="btn" data-act="editGoal" data-id="${g.id}" aria-label="Редагувати">${ICON('edit', 18)}</button></div>
    ${(g.log || []).length ? `<div class="sub" style="margin-top:12px">${g.log.slice(-3).reverse().map(l => `${fmtShort(l.date)}: ${l.amt > 0 ? '+' : '−'}${money(Math.abs(l.amt))}`).join(' · ')}</div>` : ''}`}
  </div>`;
}
views.goals = () => `
  <button class="btn primary block mb" data-act="addGoal">${ICON('plus', 20)} Нова ціль</button>
  ${S.goals.length ? S.goals.map(g => goalCard(g)).join('') : `<div class="card empty">${ICON('target', 36)}<div>Додай мрію: мотоцикл, телефон чи щось своє. Я рахуватиму прогрес.</div></div>`}`;
function goalSheet(id) {
  const g = id ? S.goals.find(x => x.id === id) : null; const kind = g ? g.kind : 'moto';
  const body = `
    ${fld('Тип', `<select name="kind">${Object.entries(GOAL_KINDS).map(([k, v]) => `<option value="${k}" ${k === kind ? 'selected' : ''}>${v[0]}</option>`).join('')}</select>`)}
    ${fld('Назва', `<input name="name" maxlength="40" required value="${esc(g ? g.name : GOAL_KINDS.moto[0])}">`)}
    ${fld('Цільова сума (' + S.cur + ')', `<input name="target" inputmode="decimal" required value="${g ? g.target : ''}" placeholder="Наприклад, 80000">`)}
    ${fld('Вже накопичено (' + S.cur + ')', `<input name="saved" inputmode="decimal" value="${g ? g.saved : 0}">`)}`;
  const el = openForm({
    title: g ? 'Редагувати ціль' : 'Нова ціль', body,
    onSubmit: fd => {
      const target = parseNum(fd.target), saved = fd.saved === '' ? 0 : parseNum(fd.saved);
      if (!(target > 0)) { toast('Введи цільову суму'); return false; }
      if (!(saved >= 0)) { toast('Накопичено: введи число'); return false; }
      const o = { kind: fd.kind, name: fd.name.trim() || GOAL_KINDS[fd.kind][0], target, saved };
      if (g) Object.assign(g, o); else S.goals.push({ id: uid(), log: [], ...o });
      save(); render(); toast('Збережено');
    },
    del: g && { text: 'Видалити ціль «' + g.name + '»?', fn: () => { S.goals = S.goals.filter(x => x.id !== g.id); save(); render(); toast('Ціль видалено'); } }
  });
  const kindSel = $('select[name=kind]', el), nameIn = $('input[name=name]', el);
  kindSel.addEventListener('change', () => {
    const defs = Object.values(GOAL_KINDS).map(v => v[0]);
    if (!nameIn.value.trim() || defs.includes(nameIn.value.trim())) nameIn.value = GOAL_KINDS[kindSel.value][0];
  });
}
function goalMoneySheet(id) {
  const g = S.goals.find(x => x.id === id); if (!g) return;
  openForm({
    title: g.name + ': рух коштів',
    body: `<div class="seg mb"><label><input type="radio" name="dir" value="add" checked><span>Поповнити</span></label><label><input type="radio" name="dir" value="sub"><span>Зняти</span></label></div>
    ${fld('Сума (' + S.cur + ')', `<input name="amt" inputmode="decimal" required placeholder="0">`)}
    <label class="row gap mb" style="cursor:pointer"><input type="checkbox" name="mirror" checked style="width:20px;height:20px"><span>Показати у фінансах (витрата / дохід)</span></label>`,
    submit: 'Підтвердити',
    onSubmit: fd => {
      const amt = parseNum(fd.amt);
      if (!(amt > 0)) { toast('Введи суму більше нуля'); return false; }
      const sub = fd.dir === 'sub';
      if (sub && amt > g.saved) { toast('На цілі лише ' + money(g.saved)); return false; }
      g.saved += sub ? -amt : amt;
      (g.log = g.log || []).push({ date: today(), amt: sub ? -amt : amt });
      if (fd.mirror) S.tx.push({ id: uid(), ts: Date.now(), type: sub ? 'in' : 'out', amt, cat: sub ? 'Повернення з цілі' : 'Накопичення', note: g.name, date: today() });
      save(); render(); toast(goalPct(g) >= 100 ? 'Ціль досягнуто! Вітаю!' : 'Збережено');
    }
  });
}

/* ---- Тренування ---- */
const exNames = () => [...new Set([...PRESET_EX, ...S.work.map(w => w.ex)])];
views.train = () => {
  const used = [...new Set(S.work.slice().sort((a, b) => b.date.localeCompare(a.date) || (b.ts || 0) - (a.ts || 0)).map(w => w.ex))];
  if (!ui.exSel || !used.includes(ui.exSel)) ui.exSel = used[0] || null;
  const days = new Set(S.work.map(w => w.date)).size, wk = new Set(S.work.filter(w => w.date >= weekStart()).map(w => w.date)).size;
  return `
  <div class="grid2 mb">
    <div class="card tile" style="cursor:default"><div class="l">${ICON('flame', 16)} Серія днів</div><div class="v">${streak()}</div></div>
    <div class="card tile" style="cursor:default"><div class="l">${ICON('calendar', 16)} Цього тижня</div><div class="v">${wk}<span class="sub" style="font-size:14px"> / всього ${days}</span></div></div>
  </div>
  <button class="btn primary block mb" data-act="addWork">${ICON('plus', 20)} Записати тренування</button>
  ${ui.exSel ? progressCard(ui.exSel, used) : ''}
  <h2>Історія</h2>
  <div class="search">${ICON('search', 20)}<input data-q="train" type="search" placeholder="Пошук вправи" value="${esc(ui.q.train || '')}"></div>
  <div id="list">${lists.train()}</div>`;
};
function progressCard(ex, used) {
  const by = {}; S.work.filter(w => w.ex === ex).forEach(w => { by[w.date] = (by[w.date] || 0) + w.sets * w.reps; });
  const ds = Object.keys(by).sort().slice(-8), vals = ds.map(d => by[d]), mx = Math.max(...vals, 1);
  const all = S.work.filter(w => w.ex === ex), rec = Math.max(...all.map(w => w.reps)), tot = all.reduce((a, w) => a + w.sets * w.reps, 0);
  let diff = '';
  if (vals.length > 1 && vals[vals.length - 2] > 0) { const d = Math.round((vals[vals.length - 1] / vals[vals.length - 2] - 1) * 100); diff = `<span class="pill ${d >= 0 ? 'grn' : 'red'}">${d >= 0 ? '+' : ''}${d}% до попереднього</span>`; }
  const W = 300, H = 120, bw = Math.min(26, (W - 10) / ds.length - 8);
  const svg = ds.map((d, i) => {
    const x = 10 + i * ((W - 20) / ds.length) + ((W - 20) / ds.length - bw) / 2, h = Math.max(4, vals[i] / mx * 78), y = 96 - h;
    return `<rect class="b" x="${x}" y="${y}" width="${bw}" height="${h}" rx="6" fill="${i === ds.length - 1 ? '#22d3a0' : '#8b5cf6'}" style="animation-delay:${i * 60}ms"/>
    <text x="${x + bw / 2}" y="${y - 5}" text-anchor="middle" fill="#ece9f6" font-size="10" font-weight="700">${vals[i]}</text>
    <text x="${x + bw / 2}" y="112" text-anchor="middle" fill="#8d87a6" font-size="9">${fmtShort(d)}</text>`;
  }).join('');
  return `<div class="card"><div class="row between mb"><h3>Прогрес</h3><select data-chg="exSel" style="width:auto;min-height:38px;padding:6px 10px">${opts(used, ex)}</select></div>
    <svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Обсяг за тренування">${svg}</svg>
    <div class="sub" style="margin:6px 0 10px">Обсяг (підходи × повторення) за останні тренування</div>
    <div class="row wrap gap"><span class="pill vio">Рекорд: ${rec} повт.</span><span class="pill">Усього: ${tot}</span>${diff}</div></div>`;
}
lists.train = () => {
  const q = (ui.q.train || '').toLowerCase().trim();
  const arr = S.work.filter(w => !q || (w.ex + ' ' + (w.note || '')).toLowerCase().includes(q)).sort((a, b) => b.date.localeCompare(a.date) || (b.ts || 0) - (a.ts || 0));
  if (!arr.length) return empty('dumbbell', S.work.length ? 'Нічого не знайдено' : 'Записів ще немає. Додай перше тренування!');
  let last = '', out = '';
  arr.slice(0, 200).forEach(w => {
    if (w.date !== last) { last = w.date; out += `<div class="dgroup">${w.date === today() ? 'Сьогодні' : fmtDate(w.date)}</div>`; }
    out += `<div class="item" data-act="editWork" data-id="${w.id}"><div class="badge">${ICON('dumbbell', 20)}</div>
      <div class="grow"><b>${esc(w.ex)}</b><div class="sub">${esc(w.note || '')}</div></div>
      <div class="amt">${w.sets} × ${w.reps}${w.weight ? `<div class="sub" style="text-align:right">${w.weight} кг</div>` : ''}</div></div>`;
  });
  return out;
};
function workSheet(id) {
  const w = id ? S.work.find(x => x.id === id) : null;
  const body = `
    ${fld('Вправа', `<input name="ex" list="exl" required maxlength="40" placeholder="Обери або введи свою" value="${esc(w ? w.ex : (ui.exSel || ''))}"><datalist id="exl">${exNames().map(x => `<option value="${esc(x)}">`).join('')}</datalist>`)}
    <div class="grid2">${fld('Підходи', `<input name="sets" type="number" inputmode="numeric" min="1" max="99" required value="${w ? w.sets : 3}">`)}${fld('Повторення / сек.', `<input name="reps" type="number" inputmode="numeric" min="1" max="9999" required value="${w ? w.reps : ''}">`)}</div>
    <div class="grid2">${fld('Вага, кг (необов’язково)', `<input name="weight" inputmode="decimal" value="${w && w.weight ? w.weight : ''}">`)}${fld('Дата', `<input type="date" name="date" required value="${w ? w.date : today()}">`)}</div>
    ${fld('Нотатка', `<input name="note" maxlength="80" value="${esc(w ? w.note : '')}" placeholder="Необов’язково">`)}`;
  openForm({
    title: w ? 'Редагувати запис' : 'Нове тренування', body,
    onSubmit: fd => {
      const sets = parseInt(fd.sets, 10), reps = parseInt(fd.reps, 10), weight = fd.weight ? parseNum(fd.weight) : 0;
      if (!fd.ex.trim()) { toast('Введи назву вправи'); return false; }
      if (!(sets > 0) || !(reps > 0)) { toast('Вкажи підходи та повторення'); return false; }
      if (fd.weight && !(weight >= 0)) { toast('Вага: введи число'); return false; }
      const o = { ex: fd.ex.trim(), sets, reps, weight: weight || 0, date: fd.date || today(), note: (fd.note || '').trim() };
      if (w) Object.assign(w, o); else S.work.push({ id: uid(), ts: Date.now(), ...o });
      ui.exSel = o.ex; save(); render(); toast(w ? 'Збережено' : 'Тренування записано');
    },
    del: w && { text: 'Видалити цей запис?', fn: () => { S.work = S.work.filter(x => x.id !== w.id); save(); render(); toast('Видалено'); } }
  });
}

/* ---- Англійська ---- */
views.eng = () => {
  if (ui.quiz) return quizView();
  if (ui.rev) return revView();
  if (ui.lesson) return lessonView();
  const tabs = `<div class="tabs">${[['dict', 'Словник'], ['lessons', 'Уроки'], ['review', 'Повторення']].map(([k, l]) => `<button class="${ui.engTab === k ? 'on' : ''}" data-act="engTab" data-v="${k}">${l}</button>`).join('')}</div>`;
  if (ui.engTab === 'lessons') return tabs + LESSONS.map(L => {
    const pr = S.lessons[L.id];
    return `<div class="item" data-act="openLesson" data-id="${L.id}"><div class="badge">${ICON(L.icon, 20)}</div>
      <div class="grow"><b>${L.title}</b><div class="sub">${L.items.length} фраз${pr ? ' · кращий результат ' + pr.best + '%' : ''}</div></div>
      ${pr && pr.done ? `<span class="pill grn">Пройдено</span>` : ICON('chevron', 20)}</div>`;
  }).join('');
  if (ui.engTab === 'review') {
    const due = S.words.filter(w => w.due <= Date.now()).length, rv = S.revByDay[today()] || 0;
    return tabs + `<div class="card hero" style="text-align:center">${ICON('repeat', 34)}<div class="big" style="margin-top:6px">${due}</div><div class="muted">слів чекають на повторення</div>
      <button class="btn primary block" style="margin-top:16px" data-act="startReview" ${due ? '' : 'disabled style="opacity:.5;margin-top:16px"'}>Почати повторення</button></div>
      <div class="grid2"><div class="card tile" style="cursor:default"><div class="l">Сьогодні повторено</div><div class="v">${rv}</div></div><div class="card tile" style="cursor:default"><div class="l">Вивчено слів</div><div class="v">${learned()}</div></div></div>
      <div class="sub" style="padding:4px">Слово вважається вивченим, коли ти відповів «Знаю» кілька разів поспіль. Інтервали зростають: 1, 2, 4, 8, 16 днів.</div>`;
  }
  return tabs + `<div class="row gap mb"><div class="search grow" style="margin:0">${ICON('search', 20)}<input data-q="eng" type="search" placeholder="Пошук слова або перекладу" value="${esc(ui.q.eng || '')}"></div><button class="btn primary" data-act="addWord" aria-label="Додати слово">${ICON('plus', 20)}</button></div>
    <div class="sub mb" style="padding:0 4px">Слів: ${S.words.length} · вивчено: ${learned()}</div><div id="list">${lists.eng()}</div>`;
};
lists.eng = () => {
  const q = (ui.q.eng || '').toLowerCase().trim();
  const arr = S.words.filter(w => !q || (w.en + ' ' + w.uk).toLowerCase().includes(q)).sort((a, b) => a.en.localeCompare(b.en));
  if (!arr.length) return empty('book', S.words.length ? 'Нічого не знайдено' : 'Словник порожній. Додай перше слово!');
  return arr.map(w => `<div class="item" data-act="editWord" data-id="${w.id}"><div class="grow"><b style="font-size:17px">${esc(w.en)}</b> <span class="muted">${esc(w.ipa)}</span><div class="sub">${esc(w.uk)}</div></div>
    <div class="dots" title="Рівень запам’ятовування">${[1, 2, 3, 4, 5].map(i => `<i class="${w.box >= i ? 'on' : ''}"></i>`).join('')}</div>
    <button class="icon-btn" data-act="speak" data-t="${esc(w.en)}" aria-label="Озвучити">${ICON('volume', 22)}</button></div>`).join('');
};
function wordSheet(id) {
  const w = id ? S.words.find(x => x.id === id) : null;
  openForm({
    title: w ? 'Редагувати слово' : 'Нове слово',
    body: fld('Англійською', `<input name="en" required maxlength="60" value="${esc(w ? w.en : '')}">`) + fld('Транскрипція (необов’язково)', `<input name="ipa" maxlength="60" placeholder="/həˈləʊ/" value="${esc(w ? w.ipa : '')}">`) + fld('Переклад українською', `<input name="uk" required maxlength="80" value="${esc(w ? w.uk : '')}">`)
      + `<button type="button" class="btn block mb" data-act="speakForm">${ICON('volume', 20)} Прослухати вимову</button>`,
    onSubmit: fd => {
      const en = fd.en.trim(), uk = fd.uk.trim();
      if (!en || !uk) { toast('Заповни слово та переклад'); return false; }
      if (!w && S.words.some(x => x.en.toLowerCase() === en.toLowerCase())) { toast('Таке слово вже є'); return false; }
      if (w) Object.assign(w, { en, uk, ipa: fd.ipa.trim() }); else S.words.push(mkWord(en, uk, fd.ipa.trim()));
      save(); render(); toast('Збережено');
    },
    del: w && { text: 'Видалити слово «' + w.en + '»?', fn: () => { S.words = S.words.filter(x => x.id !== w.id); save(); render(); toast('Видалено'); } }
  });
}
function lessonView() {
  const L = LESSONS.find(x => x.id === ui.lesson), pr = S.lessons[L.id];
  return `<div class="row gap mb"><button class="icon-btn" data-act="engBack" aria-label="Назад">${ICON('back', 24)}</button><h3 class="grow">${L.title}</h3>${pr && pr.done ? '<span class="pill grn">Пройдено</span>' : ''}</div>
  <div class="card sub" style="color:var(--tx)">${L.tip}</div>
  ${L.items.map(([en, uk]) => `<div class="item" data-act="speak" data-t="${esc(en)}"><div class="grow"><b>${esc(en)}</b><div class="sub">${esc(uk)}</div></div>${ICON('volume', 22)}</div>`).join('')}
  <div class="grid2" style="margin-top:14px"><button class="btn primary" data-act="startQuiz" data-id="${L.id}">Пройти тест</button><button class="btn" data-act="lessonToDict" data-id="${L.id}">До словника</button></div>`;
}
function startQuiz(lid) {
  const L = LESSONS.find(x => x.id === lid);
  const qs = shuffle(L.items).slice(0, 8).map(it => ({ en: it[0], ans: it[1], opts: shuffle([it[1], ...shuffle(L.items.filter(x => x[0] !== it[0])).slice(0, 3).map(x => x[1])]) }));
  ui.quiz = { lid, qs, i: 0, score: 0, pick: null }; render();
}
function quizView() {
  const z = ui.quiz, L = LESSONS.find(x => x.id === z.lid);
  if (z.i >= z.qs.length) {
    const pct = Math.round(z.score / z.qs.length * 100), ok = pct >= 70;
    return `<div class="card hero" style="text-align:center"><div class="muted">Результат тесту</div>${ring(pct / 100, 120, 12)}
      <div style="font-size:18px;font-weight:700;margin:10px 0">${z.score} з ${z.qs.length}. ${ok ? 'Урок пройдено!' : 'Потрібно щонайменше 70%.'}</div>
      <div class="grid2"><button class="btn primary" data-act="startQuiz" data-id="${L.id}">Ще раз</button><button class="btn" data-act="quizEnd">До уроку</button></div></div>`;
  }
  const q = z.qs[z.i];
  return `<div class="row gap mb"><button class="icon-btn" data-act="quizEnd" aria-label="Вийти">${ICON('x', 24)}</button><div class="grow">${bar((z.i) / z.qs.length * 100)}</div><span class="sub">${z.i + 1}/${z.qs.length}</span></div>
  <div class="card flash"><div class="sub">Обери переклад</div><div class="w">${esc(q.en)}</div><button class="btn sm" data-act="speak" data-t="${esc(q.en)}">${ICON('volume', 18)} Прослухати</button></div>
  ${q.opts.map(o => `<button class="opt ${z.pick !== null ? (o === q.ans ? 'ok' : o === z.pick ? 'bad' : '') : ''}" data-act="pickOpt" data-v="${esc(o)}">${esc(o)}</button>`).join('')}
  ${z.pick !== null ? `<button class="btn primary block" data-act="quizNext">${z.i + 1 >= z.qs.length ? 'Результат' : 'Далі'}</button>` : ''}`;
}
function startReview() {
  const q = shuffle(S.words.filter(w => w.due <= Date.now())).slice(0, 15).map(w => w.id);
  if (!q.length) { toast('Немає слів для повторення'); return; }
  ui.rev = { q, i: 0, shown: false, ok: 0, bad: 0, again: new Set() }; render();
}
function revView() {
  const r = ui.rev;
  if (r.i >= r.q.length) return `<div class="card hero" style="text-align:center">${ICON('cap', 40)}<div class="big">${r.ok}</div><div class="muted">слів ти знаєш · не знаєш: ${r.bad}</div><button class="btn primary block" style="margin-top:16px" data-act="revEnd">Готово</button></div>`;
  const w = S.words.find(x => x.id === r.q[r.i]);
  if (!w) { r.i++; return revView(); }
  return `<div class="row gap mb"><button class="icon-btn" data-act="revEnd" aria-label="Вийти">${ICON('x', 24)}</button><div class="grow">${bar(r.i / r.q.length * 100)}</div><span class="sub">${r.i + 1}/${r.q.length}</span></div>
  <div class="card flash" data-act="${r.shown ? 'noop' : 'revShow'}"><div class="w">${esc(w.en)}</div><div class="muted">${esc(w.ipa)}</div>
    <button class="btn sm" data-act="speak" data-t="${esc(w.en)}">${ICON('volume', 18)} Прослухати</button>
    ${r.shown ? `<div style="font-size:24px;font-weight:700;color:var(--grn);margin-top:10px">${esc(w.uk)}</div>` : '<div class="sub" style="margin-top:12px">Торкнись, щоб побачити переклад</div>'}</div>
  ${r.shown ? `<div class="grid2"><button class="btn danger" data-act="revAns" data-v="0">Не знаю</button><button class="btn green" data-act="revAns" data-v="1">Знаю</button></div>` : `<button class="btn primary block" data-act="revShow">Показати переклад</button>`}`;
}

/* ---- Завдання ---- */
views.tasks = () => {
  const f = ui.f.task, done = S.tasks.filter(t => t.done).length;
  return `<form id="qa" class="qa"><input name="t" maxlength="200" placeholder="Нове завдання…" autocomplete="off"><button class="btn primary" type="submit" aria-label="Додати" style="padding:0 16px">${ICON('plus', 22)}</button></form>
  <div class="search">${ICON('search', 20)}<input data-q="task" type="search" placeholder="Пошук завдань" value="${esc(ui.q.task || '')}"></div>
  <div class="chips">${[['active', 'Активні'], ['done', 'Виконані'], ['all', 'Усі']].map(([k, l]) => `<button class="chip ${f === k ? 'on' : ''}" data-act="chip" data-g="task" data-v="${k}">${l}</button>`).join('')}${done ? `<button class="chip" data-act="clearDone">Очистити виконані</button>` : ''}</div>
  <div id="list">${lists.tasks()}</div>`;
};
lists.tasks = () => {
  const q = (ui.q.task || '').toLowerCase().trim(), f = ui.f.task, t0 = today(), tm = iso(addDays(1));
  const arr = S.tasks.filter(t => (f === 'all' || (f === 'done') === !!t.done) && (!q || t.title.toLowerCase().includes(q)))
    .sort((a, b) => (a.done - b.done) || (a.done ? (b.doneAt || '').localeCompare(a.doneAt || '') : (a.prio - b.prio) || (a.due || '9').localeCompare(b.due || '9') || a.ts - b.ts));
  if (!arr.length) return empty('checksq', S.tasks.length ? 'Тут порожньо' : 'Справ ще немає. Додай першу вище!');
  return arr.map(t => {
    const due = t.due ? (t.due < t0 && !t.done ? '<span class="pill red">Прострочено</span>' : `<span class="pill ${t.due === t0 ? 'vio' : ''}">${t.due === t0 ? 'Сьогодні' : t.due === tm ? 'Завтра' : fmtShort(t.due)}</span>`) : '';
    return `<div class="item ${t.done ? 'done' : ''}"><button class="check ${t.done ? 'on' : ''}" data-act="toggleTask" data-id="${t.id}" aria-label="Позначити виконаним">${t.done ? ICON('check', 16) : ''}</button>
      <div class="grow" data-act="editTask" data-id="${t.id}"><div class="tt">${esc(t.title)}</div><div class="row gap wrap" style="margin-top:4px">${due}<span class="pill ${PRIO[t.prio][1]}">${PRIO[t.prio][0]}</span></div></div>
      <button class="icon-btn" data-act="editTask" data-id="${t.id}" aria-label="Редагувати">${ICON('edit', 20)}</button></div>`;
  }).join('');
};
function taskSheet(id) {
  const t = id ? S.tasks.find(x => x.id === id) : null;
  openForm({
    title: t ? 'Редагувати завдання' : 'Нове завдання',
    body: fld('Що зробити', `<input name="title" required maxlength="200" value="${esc(t ? t.title : '')}">`) + `<div class="grid2">${fld('Термін', `<input type="date" name="due" value="${t && t.due ? t.due : ''}">`)}${fld('Важливість', `<select name="prio">${Object.entries(PRIO).map(([k, v]) => `<option value="${k}" ${(t ? t.prio : 1) == k ? 'selected' : ''}>${v[0]}</option>`).join('')}</select>`)}</div>`,
    onSubmit: fd => {
      if (!fd.title.trim()) { toast('Введи назву завдання'); return false; }
      const o = { title: fd.title.trim(), due: fd.due || '', prio: +fd.prio };
      if (t) Object.assign(t, o); else S.tasks.push({ id: uid(), ts: Date.now(), done: false, ...o });
      save(); render(); toast('Збережено');
    },
    del: t && { text: 'Видалити це завдання?', fn: () => { S.tasks = S.tasks.filter(x => x.id !== t.id); save(); render(); toast('Видалено'); } }
  });
}

/* ---- Ще ---- */
views.more = () => {
  const link = (t, ic, title, sub) => `<div class="item" data-act="go" data-t="${t}"><div class="badge">${ICON(ic, 22)}</div><div class="grow"><b>${title}</b><div class="sub">${sub}</div></div>${ICON('chevron', 20)}</div>`;
  return link('eng', 'cap', 'Англійська', `Словник, уроки, повторення · вивчено ${learned()}`)
    + link('tasks', 'checksq', 'Завдання', `Активних: ${S.tasks.filter(t => !t.done).length}`)
    + link('settings', 'sliders', 'Налаштування', 'Ім’я, резервна копія, відновлення');
};

/* ---- Налаштування ---- */
let installEvt = null;
views.settings = () => {
  const lb = S.lastBackup ? new Date(S.lastBackup).toLocaleString('uk-UA') : 'ще не робилась';
  return `<form id="setf" class="card">
    ${fld('Твоє ім’я', `<input name="name" maxlength="30" value="${esc(S.name)}" placeholder="Як до тебе звертатись?">`)}
    ${fld('Валюта', `<select name="cur">${opts(['₴', '$', '€'], S.cur)}</select>`)}
    <div class="sub mb" style="font-weight:700">Цілі на день</div>
    <div class="grid2">${fld('Завдань', `<input name="d_tasks" type="number" inputmode="numeric" min="0" max="99" value="${S.daily.tasks}">`)}${fld('Слів на повторення', `<input name="d_words" type="number" inputmode="numeric" min="0" max="999" value="${S.daily.words}">`)}</div>
    ${fld('Записів тренувань', `<input name="d_work" type="number" inputmode="numeric" min="0" max="99" value="${S.daily.workout}">`)}
    <button class="btn primary block" type="submit">Зберегти</button></form>
  <h2>Резервна копія</h2>
  <div class="card"><div class="sub mb">Остання копія: ${lb}. Файл можна зберегти в «Завантаження» або надіслати собі, щоб відновити дані на новому телефоні.</div>
    <div class="grid2"><button class="btn green" data-act="export">${ICON('download', 20)} Зберегти</button><button class="btn" data-act="import">${ICON('upload', 20)} Відновити</button></div>
    ${navigator.share ? `<button class="btn block" style="margin-top:10px" data-act="shareBackup">${ICON('share', 20)} Поділитися копією</button>` : ''}</div>
  <h2>Застосунок</h2>
  <div class="card">${installEvt ? `<button class="btn primary block mb" data-act="install">Встановити на екран</button>` : `<div class="sub mb">Щоб встановити: у Chrome натисни ⋮ → «Встановити застосунок» або «Додати на головний екран».</div>`}
    <div class="sub">Усі дані зберігаються лише на цьому пристрої. Реєстрація не потрібна. Версія 1.0</div>
    <button class="btn danger block" style="margin-top:12px" data-act="reset">Видалити всі дані</button></div>`;
};
function backupObj() { return { app: 'zyuzya', version: 1, exported: new Date().toISOString(), data: S }; }
function backupFile() {
  const name = `zyuzya-backup-${today()}.json`;
  return new File([JSON.stringify(backupObj(), null, 2)], name, { type: 'application/json' });
}
function exportBackup() {
  try {
    const f = backupFile(), url = URL.createObjectURL(f), a = document.createElement('a');
    a.href = url; a.download = f.name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    S.lastBackup = Date.now(); save(); render(); toast('Копію збережено: ' + f.name);
  } catch (e) { toast('Не вдалося створити копію'); }
}
async function shareBackup() {
  try {
    const f = backupFile();
    if (navigator.canShare && navigator.canShare({ files: [f] })) { await navigator.share({ files: [f], title: 'Копія Зюзя' }); S.lastBackup = Date.now(); save(); render(); }
    else exportBackup();
  } catch (e) { if (e && e.name !== 'AbortError') toast('Не вдалося поділитися'); }
}
function importBackup(file) {
  const r = new FileReader();
  r.onload = () => {
    try {
      const o = JSON.parse(r.result);
      if (!o || o.app !== 'zyuzya' || !o.data || typeof o.data !== 'object') throw new Error('bad');
      confirmBox('Замінити всі поточні дані даними з копії?', () => { S = migrate(o.data); save(); render(); toast('Дані відновлено'); }, 'Так, відновити');
    } catch (e) { toast('Це не файл копії «Зюзя»'); }
  };
  r.onerror = () => toast('Не вдалося прочитати файл');
  r.readAsText(file);
}

/* ================= Рендер і навігація ================= */
function render() {
  const v = $('#view'), y = window.scrollY;
  v.className = ui.anim ? 'anim' : '';
  v.innerHTML = views[ui.tab]();
  if (ui.anim) { window.scrollTo(0, 0); ui.anim = false; } else window.scrollTo(0, y);
  $('#ttl').textContent = TITLES[ui.tab];
  const nv = navOf(ui.tab);
  $('#nav').innerHTML = NAV.map(([t, ic, l]) => `<button class="${t === nv ? 'on' : ''}" data-act="go" data-t="${t}" aria-label="${l}" ${t === nv ? 'aria-current="page"' : ''}>${ICON(ic, 24)}<span>${l}</span></button>`).join('');
  if (ui.refocus) { ui.refocus = false; const i = $('#qa input'); if (i) i.focus(); }
}
function go(t) {
  if (t === ui.tab) return;
  ui.tab = t; ui.anim = true; ui.lesson = ui.quiz = ui.rev = null;
  history.pushState({ tab: t, sheet: 0 }, ''); render();
}
window.addEventListener('popstate', e => {
  const target = (e.state && e.state.sheet) || 0;
  if (stack.length > target) { while (stack.length > target) removeTop(); return; }
  const t = (e.state && e.state.tab) || 'home';
  if (t !== ui.tab) { ui.tab = t; ui.anim = true; ui.lesson = ui.quiz = ui.rev = null; render(); }
});

/* ================= События ================= */
const actions = {
  go: d => go(d.t),
  noop: () => {},
  closeTop,
  chip: d => { ui.f[d.g] = d.v; render(); },
  engTab: d => { ui.engTab = d.v; render(); },
  speak: d => speak(d.t),
  speakForm: (d, el) => { const i = el.closest('form').elements.en.value.trim(); if (i) speak(i); else toast('Спочатку введи слово'); },
  addTx: d => txSheet(d.type), editTx: d => txSheet(null, d.id),
  addGoal: () => goalSheet(), editGoal: d => goalSheet(d.id), goalMoney: d => goalMoneySheet(d.id),
  addWork: () => workSheet(), editWork: d => workSheet(d.id),
  addWord: () => wordSheet(), editWord: d => wordSheet(d.id),
  addTask: () => taskSheet(), editTask: d => taskSheet(d.id),
  toggleTask: d => { const t = S.tasks.find(x => x.id === d.id); if (!t) return; t.done = !t.done; t.doneAt = t.done ? today() : ''; save(); render(); },
  clearDone: () => confirmBox('Видалити всі виконані завдання?', () => { S.tasks = S.tasks.filter(t => !t.done); save(); render(); toast('Очищено'); }),
  openLesson: d => { ui.lesson = d.id; ui.anim = true; render(); },
  engBack: () => { ui.lesson = null; ui.anim = true; render(); },
  lessonToDict: d => {
    const L = LESSONS.find(x => x.id === d.id); let n = 0;
    L.items.forEach(([en, uk]) => { if (!S.words.some(w => w.en.toLowerCase() === en.toLowerCase())) { S.words.push(mkWord(en, uk, '')); n++; } });
    save(); toast(n ? `Додано слів: ${n}` : 'Усі слова вже у словнику');
  },
  startQuiz: d => startQuiz(d.id),
  quizEnd: () => { ui.quiz = null; ui.anim = true; render(); },
  pickOpt: d => { const z = ui.quiz; if (z.pick !== null) return; z.pick = d.v; if (d.v === z.qs[z.i].ans) z.score++; render(); },
  quizNext: () => {
    const z = ui.quiz; z.i++; z.pick = null;
    if (z.i >= z.qs.length) {
      const pct = Math.round(z.score / z.qs.length * 100), pr = S.lessons[z.lid] || { best: 0, done: false };
      pr.best = Math.max(pr.best, pct); if (pct >= 70) pr.done = true; S.lessons[z.lid] = pr; save();
    }
    render();
  },
  startReview, revShow: () => { ui.rev.shown = true; render(); },
  revAns: d => {
    const r = ui.rev, w = S.words.find(x => x.id === r.q[r.i]); if (!w) return;
    if (d.v === '1') { w.box = Math.min(5, w.box + 1); w.due = Date.now() + INTERVALS[w.box] * DAY; r.ok++; }
    else { w.box = Math.max(0, w.box - 1); w.due = Date.now() + 10 * 60000; r.bad++; if (!r.again.has(w.id)) { r.again.add(w.id); r.q.push(w.id); } }
    S.revByDay[today()] = (S.revByDay[today()] || 0) + 1; save(); r.i++; r.shown = false; render();
  },
  revEnd: () => { ui.rev = null; ui.anim = true; render(); },
  export: exportBackup, shareBackup,
  import: () => { const i = $('#imp'); i.value = ''; i.click(); },
  reset: () => confirmBox('Видалити ВСІ дані назавжди? Спершу зроби резервну копію.', () => { S = defaults(); S.welcomed = true; save(); ui.tab = 'home'; ui.anim = true; render(); toast('Дані видалено'); }, 'Так, видалити все'),
  install: async () => { if (!installEvt) return; installEvt.prompt(); try { await installEvt.userChoice; } catch (e) {} installEvt = null; render(); }
};
const chg = { exSel: v => { ui.exSel = v; render(); } };
const refreshList = () => { const l = $('#list'); if (!l) return; const fn = ui.tab === 'eng' ? lists.eng : lists[ui.tab]; if (fn) l.innerHTML = fn(); };

document.addEventListener('click', e => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const fn = actions[el.dataset.act]; if (fn) fn(el.dataset, el);
});
document.addEventListener('input', e => {
  const q = e.target.dataset && e.target.dataset.q;
  if (q) { ui.q[q] = e.target.value; refreshList(); }
});
document.addEventListener('change', e => {
  const c = e.target.dataset && e.target.dataset.chg; if (c && chg[c]) chg[c](e.target.value);
});
document.addEventListener('submit', e => {
  const f = e.target;
  if (f.id === 'qa') {
    e.preventDefault(); const v = f.elements.t.value.trim();
    if (!v) { toast('Введи назву завдання'); return; }
    S.tasks.push({ id: uid(), ts: Date.now(), title: v, due: '', prio: 1, done: false }); ui.refocus = true; ui.f.task = ui.f.task === 'done' ? 'active' : ui.f.task; save(); render();
  } else if (f.id === 'setf') {
    e.preventDefault(); const fd = Object.fromEntries(new FormData(f)), n = k => Math.max(0, parseInt(fd[k], 10) || 0);
    S.name = fd.name.trim(); S.cur = fd.cur; S.daily = { tasks: n('d_tasks'), words: n('d_words'), workout: n('d_work') };
    save(); render(); toast('Налаштування збережено');
  }
});
$('#imp').addEventListener('change', e => { const f = e.target.files && e.target.files[0]; if (f) importBackup(f); });
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvt = e; if (ui.tab === 'settings' && !stack.length) render(); });
window.addEventListener('appinstalled', () => { installEvt = null; toast('Застосунок встановлено'); });
$('#gear').innerHTML = ICON('sliders', 22);

/* ================= Запуск ================= */
function welcome() {
  const el = openForm({
    title: 'Ласкаво просимо до «Зюзя»', submit: 'Почати',
    body: `<p class="sub" style="margin:0 0 14px">Усе зберігається лише на твоєму телефоні. Реєстрація не потрібна. Як до тебе звертатись?</p>${fld('Ім’я', `<input name="name" maxlength="30" placeholder="Наприклад, Віталій">`)}`,
    onSubmit: fd => { S.name = (fd.name || '').trim(); S.welcomed = true; save(); render(); }
  });
  // закриття без збереження теж запам’ятовуємо
  el.addEventListener('click', e => { if (e.target === el) { S.welcomed = true; save(); } });
}
history.replaceState({ tab: 'home', sheet: 0 }, '');
render();
if (!S.welcomed) setTimeout(() => { S.welcomed = true; save(); welcome(); }, 350);
if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
